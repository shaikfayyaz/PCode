package com.kohls.util.webserviceUtil;

import com.kohls.common.util.XMLUtil;
import org.junit.Assert;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.io.StringWriter;

public class KohlsPoCEReceiptWSCallerTest {
    private final String TARGET_NS = "http://webservice.services.cc.ch.kohls.com";


    @Test
    public void testcreateCCSSoapRequest_happy() throws Exception {
        KohlsPoCEReceiptWSCaller caller = new KohlsPoCEReceiptWSCaller();

        String input = "<EmailReceipt Email=\"user@domain.com\" ReceiptData=\" Total: $100.00 \"/>";
        Document document = XMLUtil.getDocument(input);

        SOAPMessage ccsSoapRequest = caller.createCCSSoapRequest(document);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ccsSoapRequest.writeTo(out);
        String strMsg = out.toString();
        System.out.println(strMsg);


        Document nsDocument = getNsDocument(ccsSoapRequest);


        // list,objectName element must be within namespace "http://webservice.services.cc.ch.kohls.com"
        Element campaign = (Element) nsDocument.getElementsByTagNameNS(TARGET_NS, "campaign").item(0);
        Element folderName1 = (Element) campaign.getElementsByTagNameNS(TARGET_NS, "folderName").item(0);
        Element objectName = (Element) campaign.getElementsByTagNameNS(TARGET_NS, "objectName").item(0);

        Assert.assertEquals("EReceipt", folderName1.getTextContent());
        Assert.assertEquals("EReceipt", objectName.getTextContent());


        Element recipientData = (Element) nsDocument.getElementsByTagNameNS(TARGET_NS, "recipientData").item(0);
        Element folderName2 = (Element) recipientData.getElementsByTagNameNS(TARGET_NS, "folderName").item(0);
        Element objectName2 = (Element) recipientData.getElementsByTagNameNS(TARGET_NS, "objectName").item(0);
        Element optionalData = (Element) recipientData.getElementsByTagNameNS(TARGET_NS, "optionalData").item(0);

        Assert.assertEquals("!MasterData", folderName2.getTextContent());
        Assert.assertEquals("CONTACTS_LIST", objectName2.getTextContent());
        Assert.assertEquals(TARGET_NS, optionalData.getNamespaceURI());


    }

    private Document getNsDocument(SOAPMessage message) throws Exception {

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        message.writeTo(out);
        String strMsg = out.toString();


        SOAPBody body = message.getSOAPBody();
        System.out.println("original document: " + toString(body.getOwnerDocument()));
        DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
        fact.setNamespaceAware(true);
        return fact.newDocumentBuilder().parse(new InputSource(new StringReader(strMsg)));

    }

    private void assertNamespace(SOAPBody body, String element) {
        NodeList list = body.getElementsByTagNameNS(TARGET_NS, element);
        Assert.assertEquals(1, list.getLength());

    }

    private String toString(Document doc) throws Exception {
        StringWriter sw = new StringWriter();
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        transformer.setOutputProperty(OutputKeys.METHOD, "xml");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        transformer.transform(new DOMSource(doc), new StreamResult(sw));
        return sw.toString();

    }
}
