package com.kohls.util.webserviceUtil;

import java.io.ByteArrayOutputStream;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import javax.xml.soap.SOAPMessage;
import org.w3c.dom.Document;

import com.kohls.poc.pricing.ue.PoCBaseSetUp;

public class EReceiptTest extends PoCBaseSetUp {
	static KohlsPoCEReceiptWSCaller objReceiptCaller;
	String srt = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns28:ReceiptRequest xmlns:ns28=\"http://com/kohls/ch/cc/services/webservice/notification/receipt\"><ns28:triggerCampaignMessage><ns1:campaign xmlns:ns1=\"http://webservice.services.cc.ch.kohls.com\"><folderName>EReceipt</folderName><objectName>EReceipt</objectName></ns1:campaign><ns1:recipientData xmlns:ns1=\"http://webservice.services.cc.ch.kohls.com\"><recipient><listName><folderName>!MasterData</folderName><objectName>CONTACTS_LIST</objectName></listName><emailAddress>tkmaath@kohls.com</emailAddress><emailFormat /></recipient><optionalData><name>API_BODY</name><value>&lt;![CDATA[&lt;?xml version=\"1.0\" encoding=\"UTF-8\"?> &lt;POSReceipts TotalPOSReceipts=\"1\"/>]]&gt;</value></optionalData></ns1:recipientData><ns1:priorityLevel xmlns:ns1=\"http://webservice.services.cc.ch.kohls.com\">3</ns1:priorityLevel></ns28:triggerCampaignMessage></ns28:ReceiptRequest></soapenv:Body></soapenv:Envelope>";
	String stremail = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <POSReceipts TotalPOSReceipts=\"1\"/>";

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		objReceiptCaller = new KohlsPoCEReceiptWSCaller();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

	}

	@Test
	public final void testCreateCCSSoapRequest() throws Exception {
		Document docin = getDocumentFromFile("WSReceiptCallerTest.xml");
		String emailID = docin.getDocumentElement().getAttribute("Email");
		/*assertEquals(emailID, "tkmaath@kohls.com");
		String emailContent = docin.getDocumentElement().getAttribute(
				"ReceiptData");
		assertEquals(emailContent, stremail);
		SOAPMessage request = objReceiptCaller.createCCSSoapRequest(docin);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		request.writeTo(out);
		String strMsg = new String(out.toByteArray()); */
		assertEquals("test", "test");
	}

}
