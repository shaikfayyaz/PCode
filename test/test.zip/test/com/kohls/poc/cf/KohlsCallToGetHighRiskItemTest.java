package com.kohls.poc.cf;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.TreeMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.cf.KohlsCallToGetHighRiskItem;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCTVSOrderPromotionsCaller;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

@SuppressWarnings("unused")
public class KohlsCallToGetHighRiskItemTest  extends PoCBaseSetUp{

private KohlsCallToGetHighRiskItem toTest = null;
HashMap<String,String> mpRiskData =  new HashMap<String,String>();
	@Before
	public void setUp() throws Exception {
		
		mpRiskData.put("17_00_00","1");
		mpRiskData.put("834_40_45","1");
	}

	@After
	public void tearDown() throws Exception {
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getOrderDetailsForHighRiskItem() throws Exception {
		Document docIput = getDocumentFromFile("getOrderDetails_CF.xml");
		Document docOutput = getDocumentFromFile("getHighRiskItem_CF.xml");
		HashMap<String,HashMap> mpLoadRiskTable =  new HashMap<String,HashMap>();
		
		KohlsCallToGetHighRiskItem toTest = spy(new KohlsCallToGetHighRiskItem()); 
		doReturn(docIput).when(toTest).invokeAPI(Matchers.any(YFSEnvironment.class), 
				Matchers.any(String.class),Matchers.any(String.class), Matchers.any(Document.class));
		
		
		toTest.todaysDate="20180122";
		toTest.mpLoadRiskTable.put("20180122", mpRiskData);
		
		Document docInput = toTest.getOrderDetailsForHighRiskItem(yfsEnv,docIput);
		HashMap<String,String> highRiskItem = toTest.getRiskItemMap(docInput, yfsEnv);
		
		assertTrue(!highRiskItem.isEmpty() && highRiskItem.size()==2);
		assertTrue(toTest.tranAmount == 25);
		
		toTest.highRiskItem = highRiskItem;
		TreeMap<Double, String> finalMap =  toTest.sortRiskItem();
		
		Document docOut = toTest.getXMLFormatOfhighRiskItem(finalMap,true);
		assertTrue(docOut.getChildNodes().getLength()>=1);

	}
}
