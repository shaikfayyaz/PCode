package com.kohls.poc.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.api.KohlsUpdateSAFRecords;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPocCreateReprocessMessageWrapperTest extends PoCBaseSetUp {

	Document inputDoc;
	Document outDocReprocess;
	@Before
	public void setUp() throws Exception {
		inputDoc=getDocumentFromFile("KohlsReprocessWrapperInput.xml");
		outDocReprocess = getDocumentFromFile("KohlsReprocessWrapperOutput.xml");
	
	}

	@SuppressWarnings("unchecked")
	@Test
	public final void testprepareInputForReprocessApi() throws Exception {
		KohlsPocCreateReprocessMessageWrapper  toTest = spy(new KohlsPocCreateReprocessMessageWrapper ());
	Document outDoc=	toTest.prepareInputForReprocessApi(yfsEnv, inputDoc);
	
	assertEquals(XMLUtil.getXMLString(outDoc), XMLUtil.getXMLString(outDocReprocess));
     
	}//Document outDocFromRP =toTest.parseAndBuildGravityToRPandRS(yfsEnv, inputDoc);

}
