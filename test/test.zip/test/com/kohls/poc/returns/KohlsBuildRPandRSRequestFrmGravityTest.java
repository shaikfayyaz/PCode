package com.kohls.poc.returns;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsBuildRPandRSRequestFrmGravityTest extends PoCBaseSetUp {

YFSEnvironment env ;
	
	private Document outDoc;
	private Document inputDoc;
	private Document outDocRsReq;
	private Document FinalOutDoc;
	//private Document getRuleValue;
	
	@Before
	public void setUp() throws Exception {
		

		inputDoc=getDocumentFromFile("returns/orderXmlFromGravity.xml");
		outDoc=getDocumentFromFile("returns/outDocRpResponse.xml");
		outDocRsReq=getDocumentFromFile("returns/OutputOfParseRSReq.xml");
		FinalOutDoc=getDocumentFromFile("returns/FinalOutputXml.xml");
		//getRuleValue=getDocumentFromFile("returns/api/getRuleValueXml.xml");
	}
	

	@Test
	public final void testParseAndBuildGravityToRPandRS() throws Exception {
		
		KohlsBuildRPandRSRequestFrmGravity toTest = spy(new KohlsBuildRPandRSRequestFrmGravity());
		toTest.storeType = "V2Pilot";
		
		doReturn(outDoc).when(toTest).getRpResponseDetails(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
		doNothing().when(toTest).setLoyaltyStoreType(Matchers.any(YFSEnvironment.class), Matchers.any(String.class));
        
		doNothing().when(yfsEnv).setTxnObject("", "");
		
		doReturn(outDocRsReq).when(toTest).getGravityRequestAndBuildRSReq( Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
	
		Document outDocFromRP =toTest.parseAndBuildGravityToRPandRS(yfsEnv, inputDoc);
		assertEquals(XMLUtil.getXMLString(FinalOutDoc), XMLUtil.getXMLString(outDocFromRP));
		String sReturnPassStatus= XPathUtil.getString(outDocFromRP, "//Order/OrderLines/OrderLine/@ReturnPassItemStatus");
		assertEquals(sReturnPassStatus, "PENDING");
		
	}

	
}
