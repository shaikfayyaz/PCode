package com.kohls.poc.returns.api;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.agent.process.ApiInvoker;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.transform.TransformerException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class KohlsPoCMatchItemFromOTRResponseTest extends PoCBaseSetUp {
    private ApiInvoker mock;

    @Before
    public void before() {
        mock = Mockito.mock(ApiInvoker.class);
    }

    // @Test  For future.
    public void testMatchItemDetails() throws Exception {
        mock = Mockito.mock(ApiInvoker.class);
        KohlsPoCMatchItemFromOTRResponse subject = new KohlsPoCMatchItemFromOTRResponse();
        this.injectMock(subject, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"\" />" +
                "</Item>" +
                "</ItemList>";

        String getOrderListResponse = "<OrderList/>";

        this.setUpItemListCall(mock, getItemListReponse);
        this.setUpOrderListCall(mock, getOrderListResponse);

        YFSEnvironment env = mock(YFSEnvironment.class);
        Document doc = getDocumentFromFile("returns/api/otrResponse.xml");
        Document actual = subject.matchItemDetails(env, doc);
        String actualXml = getAsXml(actual);
        String expectedXml = "<Whatever/>";
        assertEquals(expectedXml, actualXml);
    }

    @Test
    public void testGetAlternateSkusNullSku() throws Exception {
        KohlsPoCMatchItemFromOTRResponse subject = new KohlsPoCMatchItemFromOTRResponse();
        String[] actual = callAlternateSkus(subject, null);

        assertArrayEquals(new String[]{}, actual);
    }

    @Test
    public void testGetAlternateSkusEmptySku() throws Exception {
        KohlsPoCMatchItemFromOTRResponse subject = new KohlsPoCMatchItemFromOTRResponse();
        String[] actual = callAlternateSkus(subject, "");
        assertArrayEquals(new String[]{}, actual);
    }

    @Test
    public void testGetAlternateSkusValidSkuWithNoSkus() throws Exception {
        KohlsPoCMatchItemFromOTRResponse subject = new KohlsPoCMatchItemFromOTRResponse();
        this.injectMock(subject, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"\" />" +
                "</Item>" +
                "</ItemList>";

        this.setUpItemListCall(mock, getItemListReponse);

        String[] actual = callAlternateSkus(subject, "12345678");
        assertArrayEquals(new String[]{}, actual);
    }

    @Test
    public void testGetAlternateSkusValidSkuWithSkus() throws Exception {
        KohlsPoCMatchItemFromOTRResponse subject = new KohlsPoCMatchItemFromOTRResponse();
        this.injectMock(subject, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"11111111,22222222\" />" +
                "</Item>" +
                "</ItemList>";

        this.setUpItemListCall(mock, getItemListReponse);

        String[] actual = callAlternateSkus(subject, "12345678");
        assertArrayEquals(new String[]{"11111111", "22222222"}, actual);
    }

    @Test
    public void testUpdateSku() throws Exception {
        KohlsPoCMatchItemFromOTRResponse subject = new KohlsPoCMatchItemFromOTRResponse();

        Document document = getDocumentFromFile("returns/api/otrResponse.xml");
        String sku = "88888888";

        Method updateSku = KohlsPoCMatchItemFromOTRResponse.class.getDeclaredMethod("updateSku", Document.class, String.class);
        updateSku.setAccessible(true);
        updateSku.invoke(subject, document, sku);

        Element orderLine = (Element) document.getElementsByTagName("OrderLine").item(0);
        String barcodeData = orderLine.getAttribute("BarcodeData");
        String itemId = orderLine.getAttribute("ItemID");
        String UPCCode = orderLine.getAttribute("UPCCode");

        assertEquals("88888888", barcodeData);
        assertEquals("88888888", itemId);
        assertEquals("", UPCCode);
    }

    private String[] callAlternateSkus(KohlsPoCMatchItemFromOTRResponse subject, String sku) throws Exception {
        Method getAlternateSkus = KohlsPoCMatchItemFromOTRResponse.class.getDeclaredMethod("getAlternateSkus", YFSEnvironment.class, String.class);
        getAlternateSkus.setAccessible(true);
        YFSEnvironment env = mock(YFSEnvironment.class);
        return (String[]) getAlternateSkus.invoke(subject, env, sku);
    }

    private void injectMock(KohlsPoCMatchItemFromOTRResponse subject, ApiInvoker mock) throws NoSuchFieldException, IllegalAccessException {
        Field invoker = KohlsPoCMatchItemFromOTRResponse.class.getDeclaredField("invoker");
        invoker.setAccessible(true);
        invoker.set(subject, mock);
    }

    private String getAsXml(Document doc) throws TransformerException {
        javax.xml.transform.dom.DOMSource source = new javax.xml.transform.dom.DOMSource(doc);
        javax.xml.transform.Transformer transformer = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        transformer.setOutputProperty(javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "yes");
        javax.xml.transform.stream.StreamResult result = new javax.xml.transform.stream.StreamResult(new java.io.StringWriter());
        transformer.transform(source, result);
        return result.getWriter().toString();
    }

    private void setUpOrderListCall(ApiInvoker mock, String xml) throws Exception {
        Document itemResponse = XMLUtil.getDocument(xml);

        Mockito.when(mock.invokeApi(any(YFSEnvironment.class),
                eq(KohlsPOCConstant.GET_ORDER_LIST_FOR_ITEM_MATCHING_TEMPLATE),
                eq(KohlsPOCConstant.API_GET_ORDER_LIST),
                any(Document.class))).thenReturn(itemResponse);
    }

    private void setUpItemListCall(ApiInvoker mock, String xml) throws Exception {
        Document itemResponse = XMLUtil.getDocument(xml);

        Mockito.when(mock.invokeApi(any(YFSEnvironment.class),
                eq(KohlsPOCConstant.GET_ITEM_LIST_FOR_ITEM_VALIDATION),
                eq(KohlsPOCConstant.API_GET_ITEM_LIST),
                any(Document.class))).thenReturn(itemResponse);
    }
}
