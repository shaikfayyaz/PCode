package com.kohls.poc.returns.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCUpdateOTRResponseToDBTest extends PoCBaseSetUp {
	private Document inputDoc,outDoc, returnPassItemDoc;
	private Element returnPassItemEle;
	private String returnPassNo = "RIcf3a78317368663f217fc9ac7ee51bb6348482";
	protected static YFSEnvironment env;
	@Before
	public void setUp() throws Exception {
		inputDoc = getDocumentFromFile("returns/UpdateOTRResponseToDBInput.xml");
		outDoc = getDocumentFromFile("returns/UpdateOTRResponseToDBOutput.xml");
		returnPassItemDoc = getDocumentFromFile("returns/returnPassItemDoc.xml");
		returnPassItemEle = returnPassItemDoc.getDocumentElement();
	}

	@SuppressWarnings("unchecked")
	@Test
	public final void testUpdateOTRLinesMatchingReturnPassLines() throws Exception {
		doReturn(returnPassNo).when(yfsEnv).getTxnObject(KohlsPOCConstant.RETURN_PASS_NUMBER);  
		doReturn(returnPassItemEle).when(yfsEnv).getTxnObject(KohlsPOCConstant.RETURN_PASS_ITEMS);
		doReturn("E_ONLY").when(yfsEnv).getTxnObject(KohlsPOCConstant.RP_RECEIPT_PREF_METHOD);
		doReturn("xyz10@gmail.com").when(yfsEnv).getTxnObject(KohlsPOCConstant.RP_RECEIPT_PREF_EMAIL_ID);
		doReturn("DEFAULT").when(yfsEnv).getTxnObject(KohlsPOCConstant.RP_REFUND_PREF_METHOD);
		KohlsPoCUpdateOTRResponseToDB tooTest = spy(new KohlsPoCUpdateOTRResponseToDB());
		tooTest.updateOTRLinesMatchingReturnPassLines(yfsEnv, inputDoc,returnPassNo);
		assertNotNull(outDoc);
	}
}
