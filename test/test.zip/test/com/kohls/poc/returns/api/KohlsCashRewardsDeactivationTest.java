package com.kohls.poc.returns.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.util.Date;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.kohls.poc.psa.api.KohlsPSAKohlsCashDeactivation;
import com.kohls.poc.rest.KohlsReturnsLCSCallWrapper;
import com.yantra.yfs.japi.YFSEnvironment;
public class KohlsCashRewardsDeactivationTest extends PoCBaseSetUp {
	private Document inputDoc,orderOutDoc,kcsOutput,lcsOuptut,output;
	
	@Before
	public void setUp() throws Exception {
		inputDoc=getDocumentFromFile("returns/api/deactivate_input.xml");
		orderOutDoc = getDocumentFromFile("returns/api/getOrderListOut.xml");
		kcsOutput = getDocumentFromFile("returns/api/kcsOutput.xml");
		lcsOuptut = getDocumentFromFile("returns/api/lcsOutput.xml");
		output = getDocumentFromFile("returns/api/apiOutput.xml");
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Test
	public void test() {
		
		
		try {
			
			
			KohlsReturnsLCSDeactivation returnLcsobj = spy( new KohlsReturnsLCSDeactivation());
			KohlsReturnsKCDeactivation returnKCSobj = spy( new KohlsReturnsKCDeactivation());
			KohlsReturnsLCSCallWrapper  returnsLcsWrapper = spy(  new KohlsReturnsLCSCallWrapper());
			KohlsPSAKohlsCashDeactivation psaKCDeactiveObj = spy(  new KohlsPSAKohlsCashDeactivation());
			KohlsCashRewardsDeactivation objTest = spy(new KohlsCashRewardsDeactivation());
			
			objTest.returnLcsobj= returnLcsobj;
			objTest.returnKCSobj= returnKCSobj;
			objTest.returnsLcsWrapper= returnsLcsWrapper;
			objTest.psaKCDeactiveObj= psaKCDeactiveObj;
			Date currentBusinessDay = new Date();
				
			doReturn(orderOutDoc).when(objTest).getOrderListForUnearning(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class), Matchers.any(String.class), Matchers.any(String.class));
			doReturn(kcsOutput).when(returnKCSobj).deactivateKohlsCash(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
			doReturn(lcsOuptut).when(objTest).invokeServiceLocal(Matchers.any(YFSEnvironment.class), Matchers.any(String.class),Matchers.any(Document.class));
			doNothing().when(objTest).clearPreviousKCPromotions(Matchers.any(YFSEnvironment.class), Matchers.any(Element.class),Matchers.any(String.class), Matchers.any(String.class));
			doReturn(currentBusinessDay).when(returnsLcsWrapper).getCurrentBusinessDay(Matchers.any(YFSEnvironment.class), Matchers.any(String.class),Matchers.any(String.class));
			Document docOut = objTest.deactivateKohlsCashRewards(yfsEnv, inputDoc);
			//System.out.println("XML is"+XMLUtil.getXMLString(docOut));
			assertEquals(XMLUtil.getXMLString(output), XMLUtil.getXMLString(docOut));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
