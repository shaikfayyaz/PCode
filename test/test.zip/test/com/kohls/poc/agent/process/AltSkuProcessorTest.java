package com.kohls.poc.agent.process;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfs.japi.YFSEnvironment;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;

/**
 * Created by tkma36l on 3/17/21.
 */
public class AltSkuProcessorTest {

    private YFSEnvironment yfsEnvironment;

    @Test
    public void test_NoExistingSkus() throws Exception {

        //Arrange
        String getJobsResponse = "<AltSkuMapEntries>\n" +
                "    <AltSkuMap SkuNbr=\"61470639\" VendorUpcNumber=\"662136037208\"/>" +
                "</AltSkuMapEntries>";

        Document document = XMLUtil.getDocument(getJobsResponse);
        AltSkuProcessor altSkuProcessor = new AltSkuProcessor(yfsEnvironment);

        // use mock invoker
        ApiInvoker mock = Mockito.mock(ApiInvoker.class);
        this.injectMock(altSkuProcessor, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"\" />" +
                "</Item>" +
                "</ItemList>";

        this.setUpItemListCall(mock, getItemListReponse);
        ArgumentCaptor<Document> docCaptor = this.getCaptor(mock);

        //Act
        altSkuProcessor.process(document);

        //Assert
        String actual = this.getArgumentAttribute(docCaptor);

        String expected = "61470639";
        assertEquals(expected, actual);
    }

    @Test
    public void test_ExistingSku_New() throws Exception {

        //Arrange
        String getJobsResponse = "<AltSkuMapEntries>\n" +
                "    <AltSkuMap SkuNbr=\"61470638\" VendorUpcNumber=\"662136037208\"/>" +
                "</AltSkuMapEntries>";

        Document document = XMLUtil.getDocument(getJobsResponse);
        AltSkuProcessor altSkuProcessor = new AltSkuProcessor(yfsEnvironment);

        // use mock invoker
        ApiInvoker mock = Mockito.mock(ApiInvoker.class);
        this.injectMock(altSkuProcessor, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"61470639\" />" +
                "</Item>" +
                "</ItemList>";

        this.setUpItemListCall(mock, getItemListReponse);
        ArgumentCaptor<Document> docCaptor = this.getCaptor(mock);

        //Act
        altSkuProcessor.process(document);

        //Assert
        String actual = this.getArgumentAttribute(docCaptor);

        String expected = "61470639,61470638";
        assertEquals(expected, actual);

    }

    @Test
    public void test_ExistingSku_Same() throws Exception {

        //Arrange
        String getJobsResponse = "<AltSkuMapEntries>\n" +
                "    <AltSkuMap SkuNbr=\"61470638\" VendorUpcNumber=\"662136037208\"/>" +
                "</AltSkuMapEntries>";

        Document document = XMLUtil.getDocument(getJobsResponse);
        AltSkuProcessor altSkuProcessor = new AltSkuProcessor(yfsEnvironment);

        // use mock invoker
        ApiInvoker mock = Mockito.mock(ApiInvoker.class);
        this.injectMock(altSkuProcessor, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"61470638\" />" +
                "</Item>" +
                "</ItemList>";

        this.setUpItemListCall(mock, getItemListReponse);
        ArgumentCaptor<Document> docCaptor = this.getCaptor(mock);

        //Act
        altSkuProcessor.process(document);

        //Assert
        assertEquals(0, docCaptor.getAllValues().size());

    }

    @Test
    public void test_ExistingMultipleSkus() throws Exception {

        //Arrange
        String getJobsResponse = "<AltSkuMapEntries>\n" +
                "    <AltSkuMap SkuNbr=\"61470639\" VendorUpcNumber=\"662136037208\"/>" +
                "</AltSkuMapEntries>";

        Document document = XMLUtil.getDocument(getJobsResponse);
        AltSkuProcessor altSkuProcessor = new AltSkuProcessor(yfsEnvironment);

        // use mock invoker
        ApiInvoker mock = Mockito.mock(ApiInvoker.class);
        this.injectMock(altSkuProcessor, mock);

        // Arrange - setup getItemList Response
        String getItemListReponse = "<ItemList>" +
                "<Item ItemKey=\"324\">" +
                "<Extn ExtnAlternateSkus=\"61470638,61470639\" />" +
                "</Item>" +
                "</ItemList>";

        this.setUpItemListCall(mock, getItemListReponse);
        ArgumentCaptor<Document> docCaptor = this.getCaptor(mock);

        //Act
        altSkuProcessor.process(document);

        //Assert
        assertEquals(0, docCaptor.getAllValues().size());
    }

    @Test
    public void testsku() throws Exception {

        Method validateSkuNbr = AltSkuProcessor.class.getDeclaredMethod("validateSkuNbr", String.class);
        validateSkuNbr.setAccessible(true);
        AltSkuProcessor altSkuProcessor = new AltSkuProcessor(this.yfsEnvironment);

        //Act
        String result = (String) validateSkuNbr.invoke(altSkuProcessor, "1234567");
        assertEquals("01234567", result);
    }

    @Test
    public void testupc() throws Exception {

        Method validateUpcNbr = AltSkuProcessor.class.getDeclaredMethod("validateUpcNbr", String.class);
        validateUpcNbr.setAccessible(true);
        AltSkuProcessor altSkuProcessor = new AltSkuProcessor(this.yfsEnvironment);

        //Act
        String result = (String) validateUpcNbr.invoke(altSkuProcessor, "000920033889048");
        assertEquals("920033889048", result);
    }

    private String getArgumentAttribute(ArgumentCaptor<Document> docCaptor) {
        Document argument = docCaptor.getAllValues().get(0);

        Element extn = (Element) argument.getElementsByTagName("Extn").item(0);
        String actual = extn.getAttribute("ExtnAlternateSkus");
        return actual;
    }

    private void injectMock(AltSkuProcessor altSkuProcessor, ApiInvoker mock) throws NoSuchFieldException, IllegalAccessException {
        Field invoker = AltSkuProcessor.class.getDeclaredField("invoker");
        invoker.setAccessible(true);
        invoker.set(altSkuProcessor, mock);
    }

    private ArgumentCaptor<Document> getCaptor(ApiInvoker mock) throws Exception {
        // Arrange - setup expected input into manageItem
        // created expected document
        //  matcher for expected document
        ArgumentCaptor<Document> docCaptor = ArgumentCaptor.forClass(Document.class);
        Mockito.doNothing().when(mock).invokeApi(any(YFSEnvironment.class), eq("manageItem"), docCaptor.capture());
        return docCaptor;
    }

    private void setUpItemListCall(ApiInvoker mock, String getItemListReponse) throws Exception {
        Document itemResponse = XMLUtil.getDocument(getItemListReponse);

        Mockito.when(mock.invokeApi(any(YFSEnvironment.class),
                eq(KohlsPOCConstant.GET_ITEM_LIST_FOR_ALTERNATE_SKUS),
                eq(KohlsPOCConstant.API_GET_ITEM_LIST),
                any(Document.class))).thenReturn(itemResponse);
    }
}