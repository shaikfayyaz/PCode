package com.kohls.poc.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;


public class KohlsUpdateSAFRecordsTest extends PoCBaseSetUp{
	private Document inputDoc,outDoc;
	private String compressedRecord = "";

	@Before
	public void setUp() throws Exception {
		inputDoc=getDocumentFromFile("returns/saf/SAF_INPUT.xml");
		outDoc = getDocumentFromFile("returns/saf/SAF_OUTPUT.xml");
		compressedRecord =  new String(Files.readAllBytes(Paths.get(TEST_FILE_PATH+"returns/saf/RECORD_COMPRESSED.txt")));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public final void testupdateProcessedSOrder() throws Exception {
	   KohlsUpdateSAFRecords toTest = spy(new KohlsUpdateSAFRecords());
		doReturn("2019-06-12").when(toTest).getPurgeDate( Matchers.any(YFSEnvironment.class));
        doReturn(outDoc).when(toTest).createSAFRecord(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
        doReturn("DEFERRED,ELIGIBLE,IN_PROCESS").when(toTest).getSAFStatusRule(Matchers.any(YFSEnvironment.class), Matchers.any(String.class), Matchers.any(String.class), Matchers.any(String.class));
        doReturn(0).when(toTest).getNumberOfRecordsInSAFTable(Matchers.any(YFSEnvironment.class), Matchers.any(String.class), Matchers.any(String.class),  Matchers.any(String.class),Matchers.any(String.class));
        doReturn(0).when(toTest).getNumberofRecordsinPSISAFTable(Matchers.any(YFSEnvironment.class), Matchers.any(String.class),  Matchers.any(String.class));
        doReturn(compressedRecord).when(toTest).compressRecordXML(Matchers.any(String.class));
        doReturn("N").when(toTest).getCompressPropertyValue();
        Document outDocFromSAFRecords =toTest.updateProcessedSOrder(yfsEnv, inputDoc);
		assertEquals(XMLUtil.getXMLString(inputDoc), XMLUtil.getXMLString(outDocFromSAFRecords));
	}
}
