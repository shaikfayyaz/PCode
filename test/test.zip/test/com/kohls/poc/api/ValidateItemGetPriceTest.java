package com.kohls.poc.api;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Matchers;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;

public class ValidateItemGetPriceTest extends PoCBaseSetUp {

	@BeforeClass
	public static void  setUpBeforeClass() throws Exception {
		//super.setUpBeforeClass();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		//super.tearDownAfterClass();
	}

	@Test
	public void testValidateItemGetPrice() throws Exception {
		Document document = getDocumentFromFile("ValidateItemGetPrice.xml");
		Document document2 = getDocumentFromFile("ValidateitemGetItemPrice/ItemValidate.xml");
		Document document3 = getDocumentFromFile("ValidateitemGetItemPrice/CommonCodeList.xml");
		Document document4 = getDocumentFromFile("ValidateitemGetItemPrice/TVSOutput.xml");
		Document document5 = getDocumentFromFile("ValidateitemGetItemPrice/Output.xml");
		
		KohlsPoCValidateItemGetPriceAPI toTest = spy(new KohlsPoCValidateItemGetPriceAPI()); 
		doReturn(document2).when(toTest).validateItem(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
		doReturn(document3).when(toTest).getCommonCodeListForRecycleSKU(Matchers.any(YFSEnvironment.class));
		doReturn(document4).when(toTest).callTVS(Matchers.any(YFSEnvironment.class),Matchers.any(Document.class));
		Document docOutput = toTest.validateItemGetPrice(yfsEnv, document);
		
		assertEquals(XMLUtil.getXMLString(docOutput), XMLUtil.getXMLString(document5));
	}

	
}
