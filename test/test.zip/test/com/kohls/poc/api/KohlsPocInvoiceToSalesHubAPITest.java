package com.kohls.poc.api;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.spy;

/**
 * Created to Test checkEmvDataForPOS method KohlsPocInvoiceToSalesHubAPI.java in  on 2/4/18.
 */
public class KohlsPocInvoiceToSalesHubAPITest extends PoCBaseSetUp {

    @BeforeClass
    public static void  setUpBeforeClass() throws Exception {

    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Test
    public void checkForEMVDataForSPS() throws Exception {
        Document document1 = getDocumentFromFile("MobilePoC/PaymentMethod_EMVData.xml");

        KohlsPocInvoiceToSalesHubAPI toTest = spy(new KohlsPocInvoiceToSalesHubAPI());
        Element eleOutput = toTest.checkForEMVDataForSPS(document1.getDocumentElement());
        Element eleExtn = xmlUtil.getChildElement(eleOutput, "Extn");
        Element eleEmvTags = xmlUtil.getChildElement(eleExtn, "ExtnEmvResponseTags");

        assertEquals("CONTACT", eleEmvTags.getAttribute("EMV_CHIP_INDICATOR"));
        assertEquals("SIGNATURE", eleEmvTags.getAttribute("EMV_CVM"));
        assertEquals("ISSUER", eleEmvTags.getAttribute("EMV_MODE"));
        assertEquals("A0000001523010", eleEmvTags.getAttribute("EMV_TAG_4F"));
        assertEquals("DISCOVER", eleEmvTags.getAttribute("EMV_TAG_50"));
        assertEquals("01", eleEmvTags.getAttribute("EMV_TAG_5F34"));
        assertEquals("Z3", eleEmvTags.getAttribute("EMV_TAG_8A"));
        assertEquals("8000008000", eleEmvTags.getAttribute("EMV_TAG_95"));
        assertEquals("6800", eleEmvTags.getAttribute("EMV_TAG_9B"));
        assertEquals("0105A00003800000", eleEmvTags.getAttribute("EMV_TAG_9F10"));

    }

}