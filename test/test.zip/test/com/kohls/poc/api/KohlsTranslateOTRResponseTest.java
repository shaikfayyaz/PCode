package com.kohls.poc.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsTranslateOTRResponseTest extends PoCBaseSetUp {

	private Document inputDoc,outDoc;
	private Map<String, String> getConfigMapInput;
	private String modifyFeeDetailsInput;
	private double getRateBasedLineTaxFeeAmountInput;
	private double getConvertToDoubleValInput;
	private String decryptExpirationDateInput;
	private String getUseTimeInOrderNoRuleValueInput;

	@Before
	public void setUp() throws Exception {
		inputDoc=getDocumentFromFile("returns/TranslateOTRInput.xml");
		outDoc = getDocumentFromFile("returns/OTROutput.xml");
		getConfigMapInput = new HashMap<String, String>();
		getConfigMapInput.put("OMNI2_ENABLED", "N"); 
		modifyFeeDetailsInput="0.0_0.0";
		getRateBasedLineTaxFeeAmountInput=5.00;
		getConvertToDoubleValInput=5.00;
		decryptExpirationDateInput="";
		getUseTimeInOrderNoRuleValueInput="N";
	}

	@SuppressWarnings("unchecked")
	@Test
	public final void testParseAndBuildGravityToRPandRS() throws Exception {
		KohlsTranslateOTRResponse toTest = spy(new KohlsTranslateOTRResponse());
		doReturn(getConfigMapInput).when(toTest).getConfigMap(Matchers.any(YFSEnvironment.class));
		doReturn(modifyFeeDetailsInput).when(toTest).modifyFeeDeatils(Matchers.any(List.class), Matchers.any(Element.class),Matchers.any(String.class),Matchers.any(String.class));
		doReturn(getRateBasedLineTaxFeeAmountInput).when(toTest).getRateBasedLineTaxFeeAmount(Matchers.any(String.class));
		doReturn(getConvertToDoubleValInput).when(toTest).getConvertToDoubleVal(Matchers.any(String.class));
		doReturn(decryptExpirationDateInput).when(toTest).decryptExpirationDate(Matchers.any(String.class));
		doReturn(getUseTimeInOrderNoRuleValueInput).when(toTest).getUseTimeInOrderNoRuleValue(Matchers.any(YFSEnvironment.class), Matchers.any(String.class));
		Document outDocFromRP =toTest.translateRSResponse(yfsEnv, inputDoc,"ReceiptedReturn");
		assertEquals(XMLUtil.getXMLString(outDoc), XMLUtil.getXMLString(outDocFromRP));
	}
}
