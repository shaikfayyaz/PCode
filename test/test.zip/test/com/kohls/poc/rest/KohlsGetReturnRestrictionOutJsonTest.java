package com.kohls.poc.rest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.spy;

import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class KohlsGetReturnRestrictionOutJsonTest {

	@SerializedName("restrictedReturnPolicyDate")
	@Expose
	private String restrictedReturnPolicyDate;

	@Test
	public void test() {

		String outputjson = "{\"restrictedReturnPolicyDate\":\"09-01-2019\",\"restrictedReturnPolicyDays\":180}";
		Gson outGson = new Gson();
		KohlsGetReturnRestrictionOutJson parsedClass = outGson.fromJson(outputjson, KohlsGetReturnRestrictionOutJson.class);

		String strpolicyDate = parsedClass.getReturnPolicyDate();
		String strpolicyDays = parsedClass.getReturnPolicyDays();
		assertEquals("09-01-2019", strpolicyDate);
		assertEquals("180", strpolicyDays);

	}

}
