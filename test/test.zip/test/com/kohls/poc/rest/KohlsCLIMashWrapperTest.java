package com.kohls.poc.rest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.core.YFSSystem;

public class KohlsCLIMashWrapperTest extends PoCBaseSetUp
{
   Document                inDoc;
   Properties              props;
   Gson                    gson;
   Document                outDoc;
   String                  sOutJson;
   HashMap<String, String> Source = new HashMap<String, String>();
   private String          sCLIOfferResJson;

   @Before
   public void setUp() throws Exception
   {

      inDoc = getDocumentFromFile( "rest/CLIELigibilityReq.xml" );
      GsonBuilder builder = new GsonBuilder();
      gson = builder.create();
      Source.put( "CLIELigibilityReq", "CLIELigibilityReq" );
      Source.put( "CLICustVerfication", "CLICustVerfication" );
      Source.put( "CLIOfferRequest", "CLIOfferRequest" );

   }

   @Test
   public void testCallCLIWrapper() throws Exception
   {

	   KohlsCLIMashWrapper toTest = spy( new KohlsCLIMashWrapper() );
      for ( String source : Source.values() )
      {
         sCLIOfferResJson = readFile( "rest/" + source + ".json" );
         outDoc = toTest.getDocumentFromJson( source, sCLIOfferResJson );
         assertNotNull( outDoc );

      }

   }

   private String readFile( String filePath ) throws IOException
   {

      File file = new File( TEST_FILE_PATH + filePath );
      System.out.println( "Abs Path:::" + file.getAbsolutePath() );
      String temp = "", returnString = "";
      BufferedReader br = new BufferedReader( new FileReader( file ) );
      while ( ( temp = br.readLine() ) != null )
      {
         returnString = returnString + temp;
      }
      return returnString;
   }

}