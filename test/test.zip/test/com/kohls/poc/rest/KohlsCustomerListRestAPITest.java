package com.kohls.poc.rest;

import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;
import org.junit.Ignore;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import static org.junit.Assert.*;

import java.util.Properties;

import static org.mockito.Mockito.mock;

public class KohlsCustomerListRestAPITest extends PoCBaseSetUp {

    // To be replaced by integration test, probably can delete this test
    @Ignore
    @Test
    public void getCustomerList_returnsSephoraDataForSephoraBeautyInsiders() throws Exception {

        KohlsCustomerListRestAPI subject = null;
        try {
            subject = new KohlsCustomerListRestAPI();
        } catch (Exception e) {
            // swallow setup errors for now
        }

        Properties testProperties = new Properties();
        testProperties.setProperty("CUST_DOMAIN", "test.com");
        subject.setProperties(testProperties);

        YFSEnvironment yfsEnvironment = mock(YFSEnvironment.class);

        Document requestDoc = getDocumentFromFile2("rest/CustomerListRestAPIRequestTemplate.xml");
        requestDoc.getElementsByTagName("Customer").item(0).getAttributes().getNamedItem("DayPhone").setNodeValue("test-day-phone");

        Document actual = null;
        try {
            actual = subject.getCustomerList(yfsEnvironment, requestDoc);
        } catch (Exception e) {
            assertNull(e);
        }

        assertNotNull(actual);
        NodeList sephoraBeautyInsiderNodes = actual.getElementsByTagName("ExtnSephoraBeautyInsider");
        assertEquals(1, sephoraBeautyInsiderNodes.getLength());
        assertEquals("Y", sephoraBeautyInsiderNodes.item(0).getTextContent());
    }

}
