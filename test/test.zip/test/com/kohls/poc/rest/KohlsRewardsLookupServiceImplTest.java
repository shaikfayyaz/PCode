package com.kohls.poc.rest;

import com.kohls.common.util.XMLUtil;
import org.junit.Test;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

@SuppressWarnings("ConstantConditions")
public class KohlsRewardsLookupServiceImplTest {


    String emailLookup = "<Customer>\n" +
            "    <CustomerContactList>\n" +
            "        <CustomerContact EmailID=\"job55@job.com\"/>\n" +
            "    </CustomerContactList>\n" +
            "</Customer>";
    String kccLookup = "<Customer CustomerChargeCardNo=\"654322133608\" CustomerRewardsNo=\"\"\n" +
            "          DisplayLocalizedFieldInLocale=\"en_US\" ExtnReturnCustomerName=\"Y\"\n" +
            "          IgnoreOrdering=\"Y\" OrganizationCode=\"KOHLS-RETAIL\" SellerOrganizationCode=\"9954\"/>";

    String lylLookup = "<Customer CustomerRewardsNo=\"81116235292\"\n" +
            "          DisplayLocalizedFieldInLocale=\"en_US\" ExtnReturnCustomerName=\"Y\"\n" +
            "          IgnoreOrdering=\"Y\" OrganizationCode=\"KOHLS-RETAIL\" SellerOrganizationCode=\"9954\"/>";

    String phoneLookup = "<Customer DisplayLocalizedFieldInLocale=\"en_US\" IgnoreOrdering=\"Y\"\n" +
            "          MaximumRecords=\"5000\" OrganizationCode=\"KOHLS-RETAIL\" SellerOrganizationCode=\"9918\">\n" +
            "    <CustomerContactList>\n" +
            "        <CustomerContact DayPhone=\"4145551212\" EmailID=\"\" RewardsInputMethod=\"\"/>\n" +
            "    </CustomerContactList>\n" +
            "</Customer>";

//
//    @Test
//    public void testPhoneLookup_FirstHappy() throws Exception {
//        KohlsSephoraLookupServiceImpl service = new KohlsSephoraLookupServiceImpl();
//
//        System.setProperty("yantra.ignore.yfs.properties", "Y");
//
//        Document document = XMLUtil.getDocument(emailLookup);
//        Properties props = new Properties();
//        props.setProperty("SR_LOOKUP_BASE_URL", "https://qa02-accservices.kohls.com/v1/customer/sephora/search");
//        props.setProperty("SR_LOOKUP_API_SECRET", "GVc45Fdcxs3Ds56OvQ");
//        props.setProperty("SR_LOOKUP_API_KEY", "v4ZyXxePFuEFnVrgBtM11f5jcUCeZnIU");
//        props.setProperty("SR_LOOKUP_TIMEOUT", "8000");
//
//
//        Document result = service.getCustomerList(document, props);
//        System.out.println(XMLUtil.getXMLString(result));
//
//    }

    private void callKrService(String xml) throws Exception {

        KohlsRewardsLookupServiceImpl service = new KohlsRewardsLookupServiceImpl();

        Document document = XMLUtil.getDocument(xml);
        Properties props = new Properties();
        props.setProperty("KR_LOOKUP_BASE_URL", "https://customer-wac-customer-staging.apps.gcpusc1.lle.xpaas.kohls.com/v1/customer/search");
        props.setProperty("KR_LOOKUP_API_SECRET_DECRYPTED", "KSp3KJOs01QcThxAc");
        props.setProperty("KR_LOOKUP_API_KEY", "b7RSNdSYkDUOJq2IXDQdd6GgAFLqguGT");
        props.setProperty("KR_LOOKUP_TIMEOUT", "8000");


        Document result = service.getCustomerList(document, props, 1);
        System.out.println(XMLUtil.getXMLString(result));

    }

    @Test
    public void test_nop() {
    }

    /**** Integration Tests ******/

    @Test
    public void test_email() throws Exception {
        // callKrService(emailLookup);
//        ArrayList<String> segments = new ArrayList<>();
//        // segments.add("one");
//        //  segments.add("two");
//        // segments.add("three");
//
//        StringBuilder sb = new StringBuilder();
//        for (String segment : segments) {
//            sb.append(segment);
//            sb.append(",");
//        }
//        if (sb.length() > 0)
//            sb.deleteCharAt(sb.length() - 1);
//
//        System.out.println(sb.toString());


    }

    //
//    @Test
//    public void test_nop2() throws Exception {
//
//        callKrService(phoneLookup);
//    }
//
    @Test
    public void test_nop3() throws Exception {

        // callKrService(kccLookup);
    }
//
//    @Test
//    public void test_bylyl() throws Exception {
//        callKrService(lylLookup);
//    }
//
//

    private Document loadTestDocument(String s) throws Exception {
        InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("testXMLFiles/CustomerList/" + s);
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(resourceAsStream);
    }

    private String loadTestString(String s) throws Exception {
        InputStream resourceAsStream = getClass().getClassLoader().getResourceAsStream("testXMLFiles/CustomerList/" + s);
        InputStreamReader reader = new InputStreamReader(resourceAsStream);
        StringBuilder sb = new StringBuilder();
        BufferedReader bufferedReader = new BufferedReader(reader);

        String line = bufferedReader.readLine();
        while (line != null) {
            sb.append(line);
            line = bufferedReader.readLine();
        }

        return sb.toString();
    }


}
