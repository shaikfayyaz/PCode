package com.kohls.poc.rest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.w3c.dom.Document;


import com.google.gson.Gson;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCallToLCSWrapperTest extends PoCBaseSetUp
{
   String                lcsResponse    = null;
   String                lcsResponse_2  = null;
   Document              outputDoc      = null;
   String                inJsonString   = null;
   String                inJsonString_2 = null;
   String                outJsonString  = null;
   KohlsReturnLCSOutJson outJson;
   String                strApiKey      = null;
   KohlsReturnLCSInJson  inJson;
   java.util.Properties  props;
   KohlsCallToLCSWrapper test           = new KohlsCallToLCSWrapper();
   int                   maxRetry       = 3;
   Gson                  g              = new Gson();
   int                   count          = 0;

   @Before
   public void setUp() throws Exception
   {
      outputDoc = getDocumentFromFile( "rest/LCSResponse.xml" );
      inJsonString = readFile( "rest/LCS_Input.json" );
      inJson = g.fromJson( inJsonString, KohlsReturnLCSInJson.class );
      outJsonString = readFile( "rest/LCS_Output.json" );
      outJson = g.fromJson( outJsonString, KohlsReturnLCSOutJson.class );
     
   }

   @Test
   public void test() throws Exception
   {
      KohlsCallToLCSWrapper toTest = spy( new KohlsCallToLCSWrapper() );

      String statusCode = "";

      statusCode = getStatusCode( inJson.getRequestDetails().size(), outJson.getResponseDetails().size() );

      if ( statusCode.equals( "206" ) )
      {
         doReturn( outputDoc ).when( toTest ).callToLCS( Matchers.any( YFSEnvironment.class ), Matchers.any( Document.class ) );
         assertTrue( true );

      }
      inJsonString = readFile( "rest/LCS_Input_200.json" );

      inJson = g.fromJson( inJsonString, KohlsReturnLCSInJson.class );
      statusCode = getStatusCode( inJson.getRequestDetails().size(), outJson.getResponseDetails().size() );

      if ( statusCode.equals( "200" ) )
      {
         doReturn( outputDoc ).when( toTest ).callToLCS( Matchers.any( YFSEnvironment.class ), Matchers.any( Document.class ) );
         assertTrue( true );

      }

      statusCode = getStatusCode( 1, -1 );
      if ( statusCode.equals( "500" ) && count < maxRetry )
      {

         doReturn( outputDoc ).when( toTest ).callToLCS( Matchers.any( YFSEnvironment.class ), Matchers.any( Document.class ) );
         assertTrue( true );

      }

   }

   public String getStatusCode( int iReqsize, int iResSize )
   {
      String statusCode = "";

      if ( iReqsize == iResSize )
      {
         return statusCode = "200";
      }
      else if ( iReqsize > iResSize && iResSize != -1 )
      {
         return statusCode = "206";
      }
      else
      {
         return statusCode = "500";
      }

      // return null;

   }

   private String readFile( String filePath ) throws IOException
   {

      File file = new File( TEST_FILE_PATH + filePath );
      String temp = "", returnString = "";
      BufferedReader br = new BufferedReader( new FileReader( file ) );
      while ( ( temp = br.readLine() ) != null )
      {
         returnString = returnString + temp;
      }
      return returnString;
   }

}
