package com.kohls.poc.rest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.spy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import com.kohls.poc.util.KohlsPoCRPUtil;

public class KohlslRPUtilTest  extends PoCBaseSetUp{
	Element OrderOnSuccesElement= null;
	String sInputJson=""; 
	Document outputDocTest = null;
	String outJsonString = null;

	@Before
	public void setUp() throws Exception {

		outJsonString = readFile("rest/RPUtil_ReturnOutput.json");
		sInputJson = readFile("rest/RPUtil_Input.json");
		Document docInput = getDocumentFromFile("rest/RPUtil_OrderOnSuccess_Input.xml");
		outputDocTest = getDocumentFromFile("rest/RPUtil_Output.xml");
		OrderOnSuccesElement = docInput.getDocumentElement();
	}

	private String readFile(String filePath) throws IOException {
		
		File file = new File(TEST_FILE_PATH+filePath);
		System.out.println("Abs Path:::"+file.getAbsolutePath());
		String temp="",returnString="";
		BufferedReader br = new BufferedReader(new FileReader(file)); 
		while ((temp = br.readLine()) != null) {
			returnString = returnString+ temp;
		}
		return returnString;
	}

	@After
	public void tearDown() throws Exception {
	}
	@SuppressWarnings("unchecked")
	@Test
	public void callRPAPI() throws Exception {

		KohlsPoCRPUtil toTest = spy(new KohlsPoCRPUtil()); 
		
		Document doc = toTest.processGetReturnPassDetailsOutput(sInputJson);
		String testJsonString = toTest.processUpdateReturnPassJSonInput(OrderOnSuccesElement, "PostVoidReturnPass");
		assertEquals(XMLUtil.getXMLString(doc), XMLUtil.getXMLString(outputDocTest));
		assertEquals(testJsonString,outJsonString);
	}

}
