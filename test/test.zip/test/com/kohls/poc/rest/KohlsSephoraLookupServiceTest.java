package com.kohls.poc.rest;

import org.junit.Test;

public class KohlsSephoraLookupServiceTest {

    private String lookupByEmail = "<Customer>\n" +
            "    <CustomerContactList>\n" +
            "        <CustomerContact EmailID=\"pos@test.com\"/>\n" +
            "    </CustomerContactList>\n" +
            "</Customer>";

    @Test
    public void test_nop() throws Exception {


//        InputSource inputSource = new InputSource(new StringReader(lookupByEmail));
//        Document inDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputSource);
//
//        Properties properties = new Properties();
//        properties.setProperty("SR_LOOKUP_BASE_URL", "https://customer-wac-customer-staging.apps.gcpusc1.lle.xpaas.kohls.com/v1/customer/sephora/search");
//        properties.setProperty("SR_LOOKUP_API_KEY", "v4ZyXxePFuEFnVrgBtM11f5jcUCeZnIU");
//        // secret
//        properties.setProperty("SR_LOOKUP_API_SECRET_DECRYPTED", "GVc45Fdcxs3Ds56OvQ");
//        properties.setProperty("SR_LOOKUP_TIMEOUT", "10000");
//
//        new KohlsSephoraLookupServiceImpl().getCustomerList(inDoc, properties, 1);
    }

    @Test
    public void test_decrypt() {

    }

}
