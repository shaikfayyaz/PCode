/**
 * 
 */
package com.kohls.poc.rest;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

/**
 * @author tkmaagk
 *
 */
public class KohlsRestAPIPooledExecutorServiceTest {

	KohlsRestAPICallableRequest timedoutRequest;
	KohlsRestAPICallableRequest cancelledtRequest;
	KohlsRestAPICallableRequest executionErrorRequest;
	KohlsRestAPICallableRequest interruptedRequest;
	KohlsRestAPICallableRequest applicationExceptionRequest;
	KohlsRestAPICallableRequest okResponse;
	int hardTimeout = 5000;

	@Before
	public void setUp() throws Exception {

		okResponse = new KohlsRestAPICallableRequest() {
			@Override
			public ResponseEntity<String> call() throws Exception {
				// TODO Auto-generated method stub
				return new ResponseEntity<String>(HttpStatus.OK);
			}
		};

		timedoutRequest = new KohlsRestAPICallableRequest() {
			@Override
			public ResponseEntity<String> call() throws Exception {
				// TODO Auto-generated method stub
				Thread.sleep(hardTimeout * 2);
				return new ResponseEntity<String>(HttpStatus.OK);
			}
		};

		interruptedRequest = new KohlsRestAPICallableRequest() {
			@Override
			public ResponseEntity<String> call() throws Exception {
				// TODO Auto-generated method stub
				Thread.currentThread().getThreadGroup().interrupt();
				return null;
			}
		};

		applicationExceptionRequest = new KohlsRestAPICallableRequest() {
			@Override
			public ResponseEntity<String> call() throws Exception {
				// TODO Auto-generated method stub
				throw new Exception("Request exception thrown from KohlsRestAPIUtil.");
			}
		};

	}

	@Test
	public void testTimeoutException() throws Exception {
		ResponseEntity<String> resp = KohlsRestAPIPooledExecutorService.instance.blockingCall(timedoutRequest, hardTimeout, "JUnit");
		assertEquals(HttpStatus.GATEWAY_TIMEOUT, resp.getStatusCode());
	}

	@Test
	public void testInterruptedException() throws Exception {
		ResponseEntity<String> resp = KohlsRestAPIPooledExecutorService.instance.blockingCall(interruptedRequest, hardTimeout, "JUnit");
		assertEquals(HttpStatus.SERVICE_UNAVAILABLE, resp.getStatusCode());
	}


	@Test
	public void testApplicationExceptionRequest() {
		try {
			KohlsRestAPIPooledExecutorService.instance.blockingCall(applicationExceptionRequest, hardTimeout, "JUnit");
		} catch (Exception e) {
			assertThat(e.getMessage(), containsString("exception thrown from KohlsRestAPIUtil"));
		}
	}

	@Test
	public void test200Response() {
		try {
			ResponseEntity<String> resp = KohlsRestAPIPooledExecutorService.instance.blockingCall(okResponse, hardTimeout, "JUnit");
			assertEquals(HttpStatus.OK, resp.getStatusCode());
		} catch (Exception e) {
			fail("Exception not Expected: " + e.toString());
		}

	}

}
