package com.kohls.poc.pricing.ue;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.mockito.Mockito;
import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;


public class PoCBaseSetUp {
	
	protected static YFSEnvironment yfsEnv;
	protected static XMLUtil xmlUtil;
	protected static Document document;
	
	protected final String TEST_FILE_PATH="build/Foundation/test/resources/testXMLFiles/";
	protected final String TEST_FILE_PATH2="test/resources/testXMLFiles/";

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		yfsEnv = Mockito.mock(YFSEnvironment.class);
		xmlUtil = Mockito.mock(XMLUtil.class);
		document = Mockito.mock(Document.class);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		yfsEnv = null;
		xmlUtil =null;
		
	}
	
	public Document getDocumentFromFile(String fileName){
		
		if(YFCCommon.isVoid(fileName)){
			return null;
		}
		
		File file = new File(TEST_FILE_PATH+fileName);
		System.out.println("Abs Path:::"+file.getAbsolutePath());
        if(YFCCommon.isVoid(file)){
			return null;
		}
        
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
	    DocumentBuilder builder;
	          
	    Document document=null;
		try  
	    {  
	        builder = factory.newDocumentBuilder();  
	        document = builder.parse(file);  
	    } catch (Exception e) {  
	        e.printStackTrace();  
	    } 
		
		return document;
	}

	public Document getDocumentFromFile2(String fileName){

		if(YFCCommon.isVoid(fileName)){
			return null;
		}

		File file = new File(TEST_FILE_PATH2+fileName);
		System.out.println("Abs Path:::"+file.getAbsolutePath());
		if(YFCCommon.isVoid(file)){
			return null;
		}

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;

		Document document=null;
		try
		{
			builder = factory.newDocumentBuilder();
			document = builder.parse(file);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return document;
	}
}
