package com.kohls.poc.pricing.ue;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;

public class KohlsPoCTVSPrepareUEResponseTest extends PoCBaseSetUp {

	private KohlsPoCTVSPrepareUEResponse kohlsPoCTVSPrepareUEResponse;
	private Document awardsDocument;
	private Document tvsResponseDocument;

	@Before
	public void setUp() throws Exception {
		kohlsPoCTVSPrepareUEResponse = new KohlsPoCTVSPrepareUEResponse();
		
	}

	@After
	public void tearDown() throws Exception {
		kohlsPoCTVSPrepareUEResponse = null;
		awardsDocument=null;
		tvsResponseDocument=null;
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCheckAwardsDiff() {

		awardsDocument = getDocumentFromFile("Awards.xml");
		Element awardsElement = awardsDocument.getDocumentElement();

		List<Element> awardElementList = XMLUtil.getElementsByTagName(
				awardsDocument.getDocumentElement(), "Award");

		boolean checkAwardsDiff = kohlsPoCTVSPrepareUEResponse
				.checkAwardsDiff(awardsElement, awardElementList.get(0),
						awardElementList.get(1));

		assertTrue(checkAwardsDiff);

	}
	
	@Test
	public void testGetEmpDscCode() {
		
		Element element =  Mockito.mock(Element.class);
		NodeList ndReference = Mockito.mock(NodeList.class);
		
		when(element.getElementsByTagName(KohlsPOCConstant.A_REFERENCE)).thenReturn(ndReference);
		when(ndReference.getLength()).thenReturn(1);
		when(ndReference.item(0)).thenReturn(element);
		when(element.getAttribute("Name")).thenReturn("ExtnEmpDiscCode");
		when(element.getAttribute(KohlsPOCConstant.A_VALUE)).thenReturn("10");
		
		String empDscCode = kohlsPoCTVSPrepareUEResponse.getEmpDscCode(element);

		assertEquals("10", empDscCode);
	}
	
	@Test
	public void testGetNetPriceDelta() {
		
		tvsResponseDocument = getDocumentFromFile("TVSResponse.xml");
		Element tvsResponseEle = tvsResponseDocument.getDocumentElement();
		KohlsPoCTVSOrderPromotionsCaller orderPromoObj = Mockito.mock(KohlsPoCTVSOrderPromotionsCaller.class);
		
		Map<String, Element> orderTLDHM = new HashMap<String, Element>();
		Element element =  Mockito.mock(Element.class);
		orderTLDHM.put("426022", element);
		
		when(orderPromoObj.getOrderTLDHM()).thenReturn(orderTLDHM);		
		when(XMLUtil.getAttribute(element, KohlsPOCConstant.A_PROMOTION_TYPE)).thenReturn("ASSOCIATE_DISCOUNT");
		
		NodeList tvsItemList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM);
		
		Element itemTVSEle = ((Element)tvsItemList.item(0));
		
		NodeList modifierEleList = itemTVSEle.getElementsByTagName(KohlsPOCConstant.ELEM_MODIFIER);
		
		String netPriceDelta = kohlsPoCTVSPrepareUEResponse.getNetPriceDelta(tvsResponseEle, orderPromoObj, modifierEleList);
 
		assertEquals("-0.49", netPriceDelta);
		
	}
}
