package com.kohls.poc.pricing.ue;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.kohlscash.ue.KohlsPoCKohlsCashInquiryRequestCreator;
import com.yantra.yfs.japi.YFSEnvironment;


public class KohlsPoCTVSOrderPromotionsCallerTest extends PoCBaseSetUp {
	
	private KohlsPoCTVSOrderPromotionsCaller kohlsPoCTVSOrderPromotionsCaller;
	
	@Before
	public void setUp() throws Exception {
		kohlsPoCTVSOrderPromotionsCaller = new KohlsPoCTVSOrderPromotionsCaller();
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testNonAssociateDiscountFlowOffer() throws Exception {
		
		Element element =  Mockito.mock(Element.class);
		
		List<Element> orderPromotionList = new ArrayList<Element>();
		orderPromotionList.add(element);
		
		when(XMLUtil.getAttribute(element, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)).thenReturn("24");
		when(element.getOwnerDocument()).thenReturn(document);
		when(element.getOwnerDocument().createElement("Temp")).thenReturn(element);
		when(XMLUtil.getAttribute(element, KohlsPOCConstant.A_PROMOTION_TYPE)).thenReturn("OFFER");
		
		Map<String, Element> orderTLDHM = new HashMap<String, Element>();
		assertTrue(orderTLDHM.size()==0);
		
		//kohlsPoCTVSOrderPromotionsCaller.nonAssociateDiscountFlow("OFFER", "", yfsEnv, element, "N");
		kohlsPoCTVSOrderPromotionsCaller.updateUeDocumentForTLD(orderPromotionList, yfsEnv, element, null);
		
		orderTLDHM = kohlsPoCTVSOrderPromotionsCaller.getOrderTLDHM();
		
		assertTrue(orderTLDHM.size()==1);
	}
	
	
	@SuppressWarnings("static-access")
	@Test
	public void testNonAssociateDiscountFlowKohlsCash() throws Exception {
		
		Element element =  Mockito.mock(Element.class);
		
		List<Element> orderPromotionList = new ArrayList<Element>();
		orderPromotionList.add(element);
		
		when(XMLUtil.getAttribute(element, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)).thenReturn("24");
		when(XMLUtil.getAttribute(element, KohlsPOCConstant.A_PROMOTION_ID)).thenReturn("10000");
		when(element.getOwnerDocument()).thenReturn(this.document);
		when(element.getOwnerDocument().createElement("Temp")).thenReturn(element);
		when(XMLUtil.getAttribute(element, KohlsPOCConstant.A_PROMOTION_TYPE)).thenReturn("KC");
		
		Document document = getDocumentFromFile("KohlsCashResponse.xml");
		
		KohlsPoCTVSOrderPromotionsCaller toTest = spy(new KohlsPoCTVSOrderPromotionsCaller()); 
		
		KohlsPoCKohlsCashInquiryRequestCreator rc = Mockito.mock(KohlsPoCKohlsCashInquiryRequestCreator.class);
		doReturn(rc).when(toTest).createkohlsCashInquiryRequest(); 
		doReturn(document).when(toTest).executeKohlsCashService(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
		
		Map<String, Element> orderTLDHM = new HashMap<String, Element>();
		
		assertTrue(orderTLDHM.size()==0);
		
		toTest.updateUeDocumentForTLD(orderPromotionList, yfsEnv, element, null);
		orderTLDHM = toTest.getOrderTLDHM();
		
		assertTrue(orderTLDHM.size()==1);
		
	}
	
}
