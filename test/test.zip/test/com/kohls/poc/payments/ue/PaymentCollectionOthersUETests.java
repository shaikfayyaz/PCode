package com.kohls.poc.payments.ue;

import com.kohls.poc.payments.ue.pinpad.CheckCaptureResponse;
import com.yantra.interop.japi.YIFApi;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import org.junit.Test;
import org.w3c.dom.Document;
import weblogic.xml.util.StringInputStream;

import javax.xml.parsers.DocumentBuilderFactory;

public class PaymentCollectionOthersUETests {

    @Test
    public void checkApproved() throws Exception {
        //Arrange
       // KohlsPoCCollectionOthersUE unit = new KohlsPoCCollectionOthersUE();
        // mock api
        // mock ENV
        YFSEnvironment env=null;
        YIFApi api;

        // Act
        YFSExtnPaymentCollectionInputStruct input = new YFSExtnPaymentCollectionInputStruct();
        //YFSExtnPaymentCollectionOutputStruct yfsExtnPaymentCollectionOutputStruct = unit.collectionOthers(env, input);

        //Assert
    }

    @Test
    public void tryApiStuff() throws Exception{
       // YIFApi api = YIFClientFactory.getInstance().getApi();

    }

    @Test
    public void trySerialize() throws Exception {

        CheckCaptureResponse response = new CheckCaptureResponse();
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new StringInputStream(
                "<RESPONSE>\n" +
                "    <RESPONSE_TEXT>Check Approved</RESPONSE_TEXT>\n" +
                "    <RESULT>APPROVED</RESULT>\n" +
                "    <RESULT_CODE>5</RESULT_CODE>\n" +
                "    <TERMINATION_STATUS>SUCCESS</TERMINATION_STATUS>\n" +
                "    <COUNTER>3094</COUNTER>\n" +
                "    <TRANS_SEQ_NUM>612972</TRANS_SEQ_NUM>\n" +
                "    <INTRN_SEQ_NUM>6231193</INTRN_SEQ_NUM>\n" +
                "    <AUTH_CODE>00333333</AUTH_CODE>\n" +
                "    <TROUTD>6231193</TROUTD>\n" +
                "    <CTROUTD>2339231193</CTROUTD>\n" +
                "    <PAYMENT_TYPE>CHECK</PAYMENT_TYPE>\n" +
                "    <AUTH_RESP_CODE>08</AUTH_RESP_CODE>\n" +
                "    <TRANS_DATE>2017.12.05</TRANS_DATE>\n" +
                "    <TRANS_TIME>16:40:59</TRANS_TIME>\n" +
                "    <PAYMENT_MEDIA>CHECK</PAYMENT_MEDIA>\n" +
                "</RESPONSE>"));

        response.parseDocument(doc);

        org.junit.Assert.assertEquals("5", response.RESULT_CODE);
        org.junit.Assert.assertEquals("2017.12.05", response.TRANS_DATE);

    }



}
