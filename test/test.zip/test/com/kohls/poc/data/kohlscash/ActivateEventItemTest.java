package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

public class ActivateEventItemTest {

	@Test
	public void testActivateEventItem() {
		ActivateEventItem toTest = new ActivateEventItem();
		
		toTest.setLimit("5");
		assertTrue(toTest.getLimitInt() == 5);
		
		toTest.setCashValue("1000");
		assertTrue(toTest.getCashValueInt() == 1000);
		
		ArrayList<String> departments = new ArrayList<String>();
		departments.add("833");
		departments.add("844");
		toTest.setDepartments(departments);
		assertTrue(toTest.getDepartments().equals(departments));
		
		toTest.setReceiptMessageLine1("Test");
		assertTrue(toTest.getReceiptMessageLine1().equals("Test"));
		
		toTest.setReceiptMessageLine1("Test1Insert");
		assertTrue(toTest.getReceiptMessageLine1().equals("Test1Insert"));
		
		toTest.setReceiptMessageLine2("Test2");
		assertTrue(toTest.getReceiptMessageLine2().equals("Test2"));
		
		toTest.setReceiptMessageLine2("Test2Insert");
		assertTrue(toTest.getReceiptMessageLine2().equals("Test2Insert"));
		
		toTest.setReceiptMsgLines(departments);
		assertTrue(toTest.getReceiptMsgLines().equals(departments));
		
		toTest.setOriginalData("test");
		assertTrue(toTest.getOriginalData().equals("test"));
		
		toTest.setEventID("12345");
		assertTrue(toTest.getEventItemID().equals("12345"));
	}
	
	@Test
	public void testBuildActivateItemFromString() {
		String event = "24397,12092018,12242018,000,05000,0200,150,01000,0,0070,0817,0833,0834,0983,Kohl's Cash 12/9 Non-Pil,$10 EARNED FOR EVERY|$50 PURCHASED;";
		
		ActivateEventItem actv = new ActivateEventItem();
		actv.createItem(event);
		
		assertTrue(actv.getDepartmentNumbersString().equals("0070,0817,0833,0834,0983"));
		assertTrue(actv.getDepartments().size() == 5);
	}
	
	@Test
	public void testBuildRedeemItemFromString() {
		String event = "24379,01012019,02282019,1,D,00000,0,0817,0830,0833,0834,0983;";
		
		RedeemEventItem redm = new RedeemEventItem();
		redm.createItem(event);
		
		assertTrue(redm.getDepartmentNumbersString().equals("0817,0830,0833,0834,0983"));
		assertTrue(redm.getDepartments().size() == 5);
	}
	
}
