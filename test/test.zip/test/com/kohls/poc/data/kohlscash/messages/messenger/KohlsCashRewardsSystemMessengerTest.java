package com.kohls.poc.data.kohlscash.messages.messenger;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;
import com.kohls.poc.data.kohlscash.KohlsCashRewardsSystemMessengerImpl;
import com.kohls.poc.data.kohlscash.dkc.DKCInquiryRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCTenderRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCVoidTransactionRequestMessage;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;

public class KohlsCashRewardsSystemMessengerTest extends BaseKohlsCashTest {

	private KohlsCashRewardsSystemMessengerImpl messenger; 
	private CouponInquiryResponseMsg response;
	
	DocumentBuilderFactory documentFactory;
	DocumentBuilder documentBuilder;
	ResponseEntity<String> http400response;
	ResponseEntity<String> http500response;
	    	
	@Before
	public void setUp() throws Exception {
	
		messenger = spy(new KohlsCashRewardsSystemMessengerImpl());
		
		documentFactory = DocumentBuilderFactory.newInstance();
		documentBuilder = documentFactory.newDocumentBuilder();
		http400response = new ResponseEntity<String>("", HttpStatus.BAD_REQUEST);
		http500response = new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_HTTP200() {
		
		try {

	        Document dkcInquiryResponseDoc = documentBuilder.parse(new File(DKC_INQUIRY_RESPONSE_XML));
	        dkcInquiryResponseDoc.normalizeDocument();
	        
	        String dkcInquiryResponse = XMLUtil.getXMLString(dkcInquiryResponseDoc);
	        
			ResponseEntity<String> dkcResponse = new ResponseEntity<String>(dkcInquiryResponse, HttpStatus.OK);
			doReturn(dkcResponse).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	        assertTrue(response.getAuthResponseCode().equals("0"));
	        assertTrue(response.getCouponBalance() == 0);
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_HTTP400() {
		
		try {
	        
			doReturn(http400response).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_HTTP500() {
		
		try {
	        
			doReturn(http500response).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_NULL() {
		
		try {
	        
			doReturn(null).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_Test_Try_Catch() {
		
		try {
			
			doThrow(NullPointerException.class).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	
	    	assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_ActivationNotFound() {
		
		try {

	        Document dkcInquiryResponseDoc = documentBuilder.parse(new File(DKC_INQUIRY_RESPONSE_ACTIVATION_NOT_FOUND_XML));
	        dkcInquiryResponseDoc.normalizeDocument();
	        
	        String dkcInquiryResponse = XMLUtil.getXMLString(dkcInquiryResponseDoc);
	        
			ResponseEntity<String> dkcResponse = new ResponseEntity<String>(dkcInquiryResponse, HttpStatus.OK);
			doReturn(dkcResponse).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
	        assertTrue(response.getCouponBalance() == 0);
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_ActivationNotFoundWithReceipt() {
		
		try {

	        Document dkcInquiryResponseDoc = documentBuilder.parse(new File(DKC_INQUIRY_RESPONSE_ACTIVATION_NOT_FOUND_XML));
	        dkcInquiryResponseDoc.normalizeDocument();
	        
	        String dkcInquiryResponse = XMLUtil.getXMLString(dkcInquiryResponseDoc);
	        
			ResponseEntity<String> dkcResponse = new ResponseEntity<String>(dkcInquiryResponse, HttpStatus.OK);
			doReturn(dkcResponse).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST_WITH_RECEIPT));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700003"));
	        assertTrue(response.getCouponBalance() == 0);
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_ActivationVoided() {
	
		try {

	        Document dkcInquiryResponseDoc = documentBuilder.parse(new File(DKC_INQUIRY_RESPONSE_ACTIVATION_VOIDED_XML));
	        dkcInquiryResponseDoc.normalizeDocument();
	        
	        String dkcInquiryResponse = XMLUtil.getXMLString(dkcInquiryResponseDoc);
	        
			ResponseEntity<String> dkcResponse = new ResponseEntity<String>(dkcInquiryResponse, HttpStatus.OK);
			doReturn(dkcResponse).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST_WITH_RECEIPT));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getCouponBalance() == 0);
	        assertTrue(response.getAuthApprovalNum().equals("700004"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_Referral() {
		
		try {

	        Document dkcInquiryResponseDoc = documentBuilder.parse(new File(DKC_INQUIRY_RESPONSE_REFERRAL_XML));
	        dkcInquiryResponseDoc.normalizeDocument();
	        
	        String dkcInquiryResponse = XMLUtil.getXMLString(dkcInquiryResponseDoc);
	        
			ResponseEntity<String> dkcResponse = new ResponseEntity<String>(dkcInquiryResponse, HttpStatus.OK);
			doReturn(dkcResponse).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST_WITH_RECEIPT));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("8"));
	        assertTrue(response.getCouponBalance() == 0);
	        assertTrue(response.getAuthApprovalNum().equals("800001"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashInquiryAJBMessage_Error_Default() {
		
		try {

	        Document dkcInquiryResponseDoc = documentBuilder.parse(new File(DKC_INQUIRY_RESPONSE_ERROR_DEFAULT_XML));
	        dkcInquiryResponseDoc.normalizeDocument();
	        
	        String dkcInquiryResponse = XMLUtil.getXMLString(dkcInquiryResponseDoc);
	        
			ResponseEntity<String> dkcResponse = new ResponseEntity<String>(dkcInquiryResponse, HttpStatus.OK);
			doReturn(dkcResponse).when(messenger).SendInquiryRequestMessage(Matchers.any(DKCInquiryRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
	        documentBuilder = documentFactory.newDocumentBuilder();
	        Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST_WITH_RECEIPT));
	        
	        JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        
	        response = new CouponInquiryResponseMsg(request);
	        
	        //use messenger
	        response = messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getCouponBalance() == 0);
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
		
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_HTTP200() {
		
		try {
			
	        Document dkcVoidRedeemResponseDoc = documentBuilder.parse(new File(DKC_VOID_REDEMPTION_RESPONSE_XML));
	        dkcVoidRedeemResponseDoc.normalizeDocument();
	        
	        String dkcVoidRedeemResponse = XMLUtil.getXMLString(dkcVoidRedeemResponseDoc);
	        
			ResponseEntity<String> dkcVoidResponse = new ResponseEntity<String>(dkcVoidRedeemResponse, HttpStatus.OK);
			doReturn(dkcVoidResponse).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("0"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_HTTP400() {
		
		try {
	        
			doReturn(http400response).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_HTTP500() {
		
		try {
	        
			doReturn(http500response).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_NO_STATUS() {
		
		try {
			
	        Document dkcVoidRedeemResponseDoc = documentBuilder.parse(new File(DKC_VOID_REDEMPTION_RESPONSE_NO_STATUS_XML));
	        dkcVoidRedeemResponseDoc.normalizeDocument();
	        
	        String dkcVoidRedeemResponse = XMLUtil.getXMLString(dkcVoidRedeemResponseDoc);
	        
			ResponseEntity<String> dkcVoidResponse = new ResponseEntity<String>(dkcVoidRedeemResponse, HttpStatus.OK);
			doReturn(dkcVoidResponse).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_NULL() {
		
		try {
	        
			doReturn(null).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_Test_Try_Catch() {
		
		try {
				        
			doThrow(NullPointerException.class).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_VOID_ERROR() {
		
		try {
			
	        Document dkcVoidRedeemResponseDoc = documentBuilder.parse(new File(DKC_VOID_REDEMPTION_RESPONSE_VOID_ERROR_XML));
	        dkcVoidRedeemResponseDoc.normalizeDocument();
	        
	        String dkcVoidRedeemResponse = XMLUtil.getXMLString(dkcVoidRedeemResponseDoc);
	        
			ResponseEntity<String> dkcVoidResponse = new ResponseEntity<String>(dkcVoidRedeemResponse, HttpStatus.OK);
			doReturn(dkcVoidResponse).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashVoidTransactionAJBMessage_VOID_ERROR_DEFAULT() {
		
		try {
			
	        Document dkcVoidRedeemResponseDoc = documentBuilder.parse(new File(DKC_VOID_REDEMPTION_RESPONSE_VOID_ERROR_DEFAULT_XML));
	        dkcVoidRedeemResponseDoc.normalizeDocument();
	        
	        String dkcVoidRedeemResponse = XMLUtil.getXMLString(dkcVoidRedeemResponseDoc);
	        
			ResponseEntity<String> dkcVoidResponse = new ResponseEntity<String>(dkcVoidRedeemResponse, HttpStatus.OK);
			doReturn(dkcVoidResponse).when(messenger).SendVoidRedemptionRequestMessage(Matchers.any(DKCVoidTransactionRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}

	@Test
	public void testSendKohlsCashRedemptionAJBMessage_HTTP200() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getCouponBalance().equals("1082.98"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	        assertTrue(response.getAuthResponseCode().equals("0"));
	        assertTrue(response.getLineToPrint().equals("12"));
	        assertTrue(response.getCouponValue().equals(request.getDiscountAmount()));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_HTTP400() {
		
		try {
	        
			doReturn(http400response).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_HTTP500() {
		
		try {
	        
			doReturn(http500response).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_NULL() {
		
		try {
	        
			doReturn(null).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_Test_Try_Catch() {
		
		try {
	       
			doThrow(NullPointerException.class).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_ActivationNotFound() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_ACTIVATION_NOT_FOUND_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_ActivationNotFoundWithReceipt() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_ACTIVATION_NOT_FOUND_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_WITH_RECEIPT_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700003"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_ActivationNotFound_Edit_Error() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_ACTIVATION_NOT_FOUND_EDIT_ERROR_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("2"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_ActivationVoided() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_ACTIVATION_VOIDED_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700004"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_Referral() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_REFERRAL_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("8"));
	        assertTrue(response.getAuthApprovalNum().equals("800001"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
	
	@Test
	public void testSendKohlsCashRedemptionAJBMessage_Error_Default() {
		
		try {
						
	        Document dkcRedeemResponseDoc = documentBuilder.parse(new File(DKC_REDEMPTION_RESPONSE_ERROR_DEFAULT_XML));
	        dkcRedeemResponseDoc.normalizeDocument();
	        
	        String dkcRedeemResponseStr = XMLUtil.getXMLString(dkcRedeemResponseDoc);
	        
			ResponseEntity<String> dkcRedeemResponse = new ResponseEntity<String>(dkcRedeemResponseStr, HttpStatus.OK);
			doReturn(dkcRedeemResponse).when(messenger).SendRedemptionRequestMessage(Matchers.any(DKCTenderRequestMessage.class));
			
			//Read the XML file into a document
			documentFactory = DocumentBuilderFactory.newInstance();
        	documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
	    catch(Exception ex) {
	    	ex.printStackTrace();
	    	assertTrue(false);
	    }
	}
}
