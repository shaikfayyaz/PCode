package com.kohls.poc.data.kohlscash.messages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashActivationRequestMsg.Item;

public class DetermineKohlsCashActivationMsgTest extends BaseKohlsCashTest {

	@Test
	public void testRequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(DETERMINE_ACTIVATION_REQUEST));
            
			JAXBContext reqContext = JAXBContext.newInstance(DetermineKohlsCashActivationRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        DetermineKohlsCashActivationRequestMsg request = (DetermineKohlsCashActivationRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        
	        //Test other properties
	        assertFalse(request.isApprovedKohlsChargeTendered());
	        assertTrue(request.isApprovedKohlsChargeTenderedStr().equals(""));
	        
	        final Item item = new Item();
	        ArrayList<Item> items = new ArrayList<Item>();
	        
	        request.setItems(items);
	        assertTrue(request.getItems().equals(items));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
    public void testBadUERequest() {
        try {
            //Read the XML file into a document
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(DETERMINE_ACTIVATION_BAD_UE_REQUEST));
            
            JAXBContext reqContext = JAXBContext.newInstance(DetermineKohlsCashActivationRequestMsg.class);
            Unmarshaller um = reqContext.createUnmarshaller();
            
            //Unmarshal the XML file document into an object
            DetermineKohlsCashActivationRequestMsg request = (DetermineKohlsCashActivationRequestMsg) um.unmarshal(requestDocument);
            
            //Marshal the object back into a document
            Marshaller m = reqContext.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            DOMResult res = new DOMResult();
            m.marshal(request, res);
            Document jaxbDoc = (Document) res.getNode();
            
            requestDocument.normalizeDocument();
            jaxbDoc.normalizeDocument();
            
            //Get the XML strings from the documents
            String output1 = XMLUtil.getXMLString(requestDocument);
            String output2 = XMLUtil.getXMLString(jaxbDoc);
            
            //Make sure the XML strings are NOT the same
            assertFalse(output1.equals(output2));
        }
        catch(Exception ex) {
            ex.printStackTrace();
            assertTrue(false);
        }
    }
	
	@Test
	public void testResponse() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document responseDocument = documentBuilder.parse(new File(DETERMINE_ACTIVATION_RESPONSE));
            
			JAXBContext reqContext = JAXBContext.newInstance(DetermineKohlsCashActivationResponseMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        DetermineKohlsCashActivationResponseMsg response = (DetermineKohlsCashActivationResponseMsg) um.unmarshal(responseDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(response, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        //Test the generateResponseXml method
	        Document fromGenerate = response.generateResponseXml();
	        
	        responseDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        fromGenerate.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(responseDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        String output3 = XMLUtil.getXMLString(fromGenerate);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        assertTrue(output1.equals(output3));
	        
	        //Test other properties
	        response.setEventID("12345");
	        assertTrue(response.getEventID().equals("12345"));
	        
	        response.setEventName("Kohls Cash Test");
	        assertTrue(response.getEventName().equals("Kohls Cash Test"));
	        
	        response.setThresholdRequired("true");
	        assertTrue(response.isThresholdRequired());
	        
	        response.setThresholdRequired(null);
	        assertFalse(response.isThresholdRequired());
	        
	        response.setQualifyingPurchaseAmount("5.51");
	        assertTrue(response.getQualifyingPurchaseAmount().equals("5.51"));
	        
	        response.setKohlsCashAmount("5.52");
	        assertTrue(response.getKohlsCashAmount().equals("5.52"));
	        
	        response.setReceiptMessageLine1("test");
	        assertTrue(response.getReceiptMessageLine1().equals("test"));
	        
	        response.setReceiptMessageLine2("test2");
	        assertTrue(response.getReceiptMessageLine2().equals("test2"));
	        
	        response.setValidationCode("12345");
	        assertTrue(response.getValidationCode().equals("12345"));
	        
	        response.setThreshold("2");
	        assertTrue(response.getThreshold().equals("2"));
	        
	        response.setNextKohlsCashEarned("3.30");
	        assertTrue(response.getNextKohlsCashEarned().equals("3.30"));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
}
