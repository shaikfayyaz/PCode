package com.kohls.poc.data.kohlscash.messages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;
import com.kohls.poc.data.kohlscash.KohlsCashStatus;
import com.kohls.poc.data.kohlscash.ReturnableItem;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg.DeactivationOptions;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg.MaximizeKohlsCash;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg.MaximizeRefund;

public class DetermineKohlsCashDeactivationMsgTest extends BaseKohlsCashTest {

	@Test
	public void testRequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(DETERMINE_DEACTIVATION_REQUEST_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(DetermineKohlsCashDeactivationRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        DetermineKohlsCashDeactivationRequestMsg request = (DetermineKohlsCashDeactivationRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        
	        //Test other properties
	        request.setReceiptId("132324234");
	        assertTrue(request.getReceiptId().equals("132324234"));
	        
	        final KohlsCashStatus kcs = new KohlsCashStatus();
	        request.setKcStatus(kcs);
	        assertTrue(request.getKcStatus().equals(kcs));
	        
	        assertTrue(request.getKohlsCashEventId().equals("65001"));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
	public void testBadUERequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(DETERMINE_DEACTIVATION_BAD_UE_REQUEST));
            
			JAXBContext reqContext = JAXBContext.newInstance(DetermineKohlsCashDeactivationRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        DetermineKohlsCashDeactivationRequestMsg request = (DetermineKohlsCashDeactivationRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are NOT the same
	        assertFalse(output1.equals(output2));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
	public void testResponse() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document responseDocument = documentBuilder.parse(new File(DETERMINE_DEACTIVATION_RESPONSE_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(DetermineKohlsCashDeactivationResponseMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        DetermineKohlsCashDeactivationResponseMsg response = (DetermineKohlsCashDeactivationResponseMsg) um.unmarshal(responseDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(response, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        //Test the generateResponseXml method
	        Document fromGenerate = response.generateResponseXml();
	        
	        responseDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        fromGenerate.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(responseDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        String output3 = XMLUtil.getXMLString(fromGenerate);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        assertTrue(output1.equals(output3));
	        
	        //Test other properties
	        response.setAuthResponseCode(0);
	        assertTrue(response.getAuthResponseCodeStr().equals("0"));
	        response.setEligibilityDeduction(5.5);
	        assertTrue(response.getEligibilityDeductionStr().equals("5.50"));
	        response.setUnearnedValue(5.5);
	        assertTrue(response.getUnearnedValueStr().equals("5.50"));
	        response.setKohlsCashBalance(5.5);
	        assertTrue(response.getKohlsCashBalanceStr().equals("5.50"));
	        
	        response.setKohlsCashId("12345");
	        assertTrue(response.getKohlsCashId().equals("12345"));
	        
	        response.setAuthResponseCode(0);
	        assertTrue(response.getAuthResponseCode() == 0);
	        
	        assertTrue(response.getKohlsCashBalance() == 5.5);
	        
	        final MaximizeKohlsCash maxKC = new MaximizeKohlsCash("10.00", "0.00");
	        assertTrue(maxKC.getKohlsCashReductionStr().equals("10.00"));
	        assertTrue(maxKC.getRefundDeductionStr().equals("0.00"));
	        
	        final MaximizeRefund maxRefund = new MaximizeRefund("0.00", "10.00");
	        assertTrue(maxRefund.getKohlsCashReductionStr().equals("0.00"));
	        assertTrue(maxRefund.getRefundDeductionStr().equals("10.00"));
	        
	        final DeactivationOptions options = new DeactivationOptions();
	        options.setMaxKohlsCash(maxKC);
	        options.setMaxRefund(maxRefund);
	        assertTrue(options.getMaxKohlsCash().equals(maxKC));
	        assertTrue(options.getMaxRefund().equals(maxRefund));
	        
	        response.setDeactivationOptions(options);
	        assertTrue(response.getDeactivationOptions().equals(options));
	        
	        ArrayList<ReturnableItem> returnableItemList = new ArrayList<ReturnableItem>();
	        response.setReturnableItemList(returnableItemList);
	        assertTrue(response.getReturnableItemList().equals(returnableItemList));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
}
