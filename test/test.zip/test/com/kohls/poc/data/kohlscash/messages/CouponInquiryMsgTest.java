package com.kohls.poc.data.kohlscash.messages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg.EventDepartment;

public class CouponInquiryMsgTest extends BaseKohlsCashTest {

	@Test
	public void testRequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
            
			JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
    public void testBadUERequest() {
        try {
            //Read the XML file into a document
            DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(INQUIRY_BAD_UE_REQUEST));
            
            JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
            Unmarshaller um = reqContext.createUnmarshaller();
            
            //Unmarshal the XML file document into an object
            CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
            
            //Marshal the object back into a document
            Marshaller m = reqContext.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            DOMResult res = new DOMResult();
            m.marshal(request, res);
            Document jaxbDoc = (Document) res.getNode();
            
            requestDocument.normalizeDocument();
            jaxbDoc.normalizeDocument();
            
            //Get the XML strings from the documents
            String output1 = XMLUtil.getXMLString(requestDocument);
            String output2 = XMLUtil.getXMLString(jaxbDoc);
            
            //Make sure the XML strings are NOT the same
            assertFalse(output1.equals(output2));
        }
        catch(Exception ex) {
            ex.printStackTrace();
            assertTrue(false);
        }
    }
	
	@Test
	public void testResponse() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document responseDocument = documentBuilder.parse(new File(INQUIRY_RESPONSE));
            
			JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryResponseMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        CouponInquiryResponseMsg response = (CouponInquiryResponseMsg) um.unmarshal(responseDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(response, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        //Test the generateResponseXml method
	        Document fromGenerate = response.generateResponseXml();
	        
	        responseDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        fromGenerate.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(responseDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        String output3 = XMLUtil.getXMLString(fromGenerate);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        assertTrue(output1.equals(output3));
	        
	        //Test other properties
	        response.setExpirationDate("20180610");
	        assertTrue(response.getExpirationDate() == null);
	        
	        ArrayList<String> eventDepartments = new ArrayList<String>();
	        eventDepartments.add("833");
	        
	        response.setDepartments(eventDepartments);
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
}
