package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ReturnableItemTest {
	
	@Test
	public void testReturnableItem() {
		
		ReturnableItem toTest = new ReturnableItem();
		toTest.setIsReturn(true);
		toTest.setKohlsCashEligible(true);
		
		assertTrue(toTest.getIsReturnStr().equals("True"));
		assertTrue(toTest.isReturn());
		assertTrue(toTest.getIsKohlsCashEligibleStr().equals("True"));
		assertTrue(toTest.isKohlsCashEligible());
		
		toTest = null;
		toTest = new ReturnableItem(5, 5, 5.5, true);
		
		assertTrue(toTest.getLineNo() == 5);
		assertTrue(toTest.getLineNoStr().equals("5"));
		assertTrue(toTest.getDept() == 5);
		assertTrue(toTest.getDeptStr().equals("5"));
		assertTrue(toTest.getNetPrice() == 5.5);
		assertTrue(toTest.getNetPriceStr().equals("5.50"));
		assertTrue(toTest.isReturn());
		assertTrue(toTest.getIsReturnStr().equals("True"));
		assertFalse(toTest.isKohlsCashEligible());
		assertTrue(toTest.getIsKohlsCashEligibleStr().equals("False"));
		
		toTest = null;
		toTest = new ReturnableItem("5", "5", "5.5", "True");
		assertTrue(toTest.getLineNo() == 5);
		assertTrue(toTest.getLineNoStr().equals("5"));
		assertTrue(toTest.getDept() == 5);
		assertTrue(toTest.getDeptStr().equals("5"));
		assertTrue(toTest.getNetPrice() == 5.5);
		assertTrue(toTest.getNetPriceStr().equals("5.5"));
		assertTrue(toTest.isReturn());
		assertTrue(toTest.getIsReturnStr().equals("True"));
		assertFalse(toTest.isKohlsCashEligible());
		assertTrue(toTest.getIsKohlsCashEligibleStr().equals("False"));
	}

}
