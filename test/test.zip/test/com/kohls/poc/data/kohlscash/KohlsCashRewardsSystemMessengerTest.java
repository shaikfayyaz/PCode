package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertTrue;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Ignore;
import org.junit.Test;
import org.w3c.dom.Document;

import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;

@Ignore
public class KohlsCashRewardsSystemMessengerTest extends BaseKohlsCashTest {
	
	//@Test
	public void testInquiry_200() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(200);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	        assertTrue(response.getAuthResponseCode().equals("0"));
	        assertTrue(response.getCouponBalance() == 90);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_400() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(400);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_500() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(500);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_nullResponse() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(-1);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_ErrorActivationNotFound() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(600);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
	        assertTrue(response.getCouponBalance() == 0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_ErrorActivationNotFoundWithReceipt() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(600);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST_WITH_RECEIPT));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700003"));
	        assertTrue(response.getCouponBalance() == 0);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_ErrorActivationVoided() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(601);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getCouponBalance() == 0);
	        assertTrue(response.getAuthApprovalNum().equals("700004"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_ErrorReferral() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(602);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("8"));
	        assertTrue(response.getCouponBalance() == 0);
	        assertTrue(response.getAuthApprovalNum().equals("800001"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testInquiry_ErrorDefault() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(603);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) um.unmarshal(requestDocument);
	        CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
	        
	        messenger.sendKohlsCashInquiryAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getCouponBalance() == 0);
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_200() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(200);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("0"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_200_NoStatus() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(201);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_400() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(400);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_500() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(500);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_nullResponse() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(-1);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_ErrorVoidError() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(600);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testVoidTransaction_ErrorDefault() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(601);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashVoidTransactionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_200() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(200);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getCouponBalance().equals("1082.98"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
	        assertTrue(response.getAuthResponseCode().equals("0"));
	        assertTrue(response.getLineToPrint().equals("12"));
	        assertTrue(response.getCouponValue().equals(request.getDiscountAmount()));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_400() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(400);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_500() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(500);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_nullResponse() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(-1);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_ErrorActivationNotFound() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(600);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700002"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_ErrorActivationNotFoundWithReceipt() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(600);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_WITH_RECEIPT_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700003"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_ErrorActivationNotFoundEditError() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(601);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("2"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_ErrorActivationVoided() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(602);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("7"));
	        assertTrue(response.getAuthApprovalNum().equals("700004"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_ErrorReferral() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(603);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getLineToPrint().equals("0"));
	        assertTrue(response.getCouponValue().equals("0"));
	        assertTrue(response.getCouponBalance().equals("0"));
	        assertTrue(response.getAuthResponseCode().equals("8"));
	        assertTrue(response.getAuthApprovalNum().equals("800001"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testRedemption_ErrorDefault() {
		KohlsCashRewardsSystemMessengerImpl messenger = new KohlsCashRewardsSystemMessengerImpl();
		
		try{
			messenger.messageFactory = new DKCMessageFactoryTestImpl(604);
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        	DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        	Document requestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
        	
        	JAXBContext reqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        CouponRedemptionRequestMsg request = (CouponRedemptionRequestMsg) um.unmarshal(requestDocument);
	        CouponRedemptionResponseMsg response = new CouponRedemptionResponseMsg(request);
	        
	        messenger.sendKohlsCashRedemptionAJBMessage(request, response);
	        
	        assertTrue(response.getAuthResponseCode().equals("9"));
	        assertTrue(response.getAuthApprovalNum().equals("000000"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
}
