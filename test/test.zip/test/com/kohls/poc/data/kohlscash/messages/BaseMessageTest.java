package com.kohls.poc.data.kohlscash.messages;

import static org.junit.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

public class BaseMessageTest {

	@Test
	public void testBaseMessage() {
		try{
			BaseMessage message = new BaseMessage();
			
			SimpleDateFormat businessDayDateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date date = businessDayDateFormat.parse("2018/06/10");
			
			SimpleDateFormat tranStartDateTimeFormat = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss");
			Date tranStartDateTime = tranStartDateTimeFormat.parse("2018/06/10T02:43:13");
			
			message.setBusinessDate("2018/06/10");
			assertTrue(message.getBusinessDate().compareTo(date) == 0);
			
			message.setBusinessDate("2018-06-10");
			assertTrue(message.getBusinessDate().compareTo(date) == 0);
			
			message.setBusinessDate("20180610");
			assertTrue(message.getBusinessDate() == null);
			
			message.setTranStartDateTime("2018/06/10T02:43:13");
			assertTrue(message.getTranStartDateTime().compareTo(tranStartDateTime) == 0);
			
			message.setTranStartDateTime("2018-06-10T02:43:13");
			assertTrue(message.getTranStartDateTime() == null);
			
			message.setTrainingMode("true");
			assertTrue(message.getTrainingMode().equals("true"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
}
