package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfs.japi.YFSEnvironment;

@Ignore
public class KohlsPocKohlsCashFeedAPITest extends BaseKohlsCashTest {
	
	KohlsPocKohlsCashFeedAPI api;
	ArrayList<ActivateEventItem> activateEvents;
	ArrayList<RedeemEventItem> redeemEvents;
	Document activationsDocument;
	Document transformedActivations;
	Document redemptionsDocument;
	Document transformedRedemptions;
	static YFSEnvironment yfsEnv;
	
	//@Before
	public void setup() {
		api = new KohlsPocKohlsCashFeedAPI();
		yfsEnv = Mockito.mock(YFSEnvironment.class);
		
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        activationsDocument = documentBuilder.parse(new File(KOHLS_CASH_ACTIVATIONS));
	        redemptionsDocument = documentBuilder.parse(new File(KOHLS_CASH_REDEMPTIONS));
	        transformedActivations = documentBuilder.parse(new File(TRANSFORMED_ACTIVATIONS));
	        transformedRedemptions = documentBuilder.parse(new File(TRANSFORMED_REDEMPTIONS));
	        
	        KohlsCashManager kcm = new KohlsCashManager(null);
	        
	        activateEvents = kcm.processDatabaseActivationEvents(activationsDocument);
	        redeemEvents = kcm.processDatabaseRedemptionEvents(redemptionsDocument);
	        
	        api.existingActivationEvents = SCXmlUtil.getChildren(activationsDocument.getDocumentElement(), KohlsPOCConstant.ELEM_KC_ACTIVATION_EVENT);
	        api.existingRedemptionEvents = SCXmlUtil.getChildren(redemptionsDocument.getDocumentElement(), KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENT);
		
	        api.populateActvObjects();
	        api.populateRedmObjects();
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}

	//@Test
	public void testCreateActivationDocument() {
		try {
			Document actvDoc = api.createActivationDocument(activateEvents.get(0));
			Element actvEle = actvDoc.getDocumentElement();
			
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID).equals(activateEvents.get(0).getStoreNum()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_ID).equals(activateEvents.get(0).getEventID()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_ACTV_FILE_DATE).equals(activateEvents.get(0).getFormattedFileDate()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_START_DATE).equals(activateEvents.get(0).getFormattedStartDate()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_END_DATE).equals(activateEvents.get(0).getFormattedEndDate()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_TENDER_TYPE_ALLOWED).equals(activateEvents.get(0).getQualifyingTender()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_QUALIFICATION_THRESHOLD).equals(activateEvents.get(0).getQualifyingAmount()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_QUALIFICATION_TOLERANCE).equals(activateEvents.get(0).getTolerance()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_VALUE).equals(activateEvents.get(0).getCashValue()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_DEPT_EXCL_INCL_FLAG).equals(activateEvents.get(0).getIncludeExcludeFlag()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_DEPARTMENT_NUMBERS).equals(activateEvents.get(0).getDepartmentNumbersString()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_NAME).equals(activateEvents.get(0).getEventName()));
			assertTrue(actvEle.getAttribute(KohlsPOCConstant.ATTR_KC_RCPT_MESSAGE_LINES).equals(activateEvents.get(0).getReceiptMsg()));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testCreateRedemptionDocument() {
		try {
			Document redmDoc = api.createRedemptionDocument(redeemEvents.get(0));
			Element redmEle = redmDoc.getDocumentElement();
			
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID).equals(redeemEvents.get(0).getStoreNum()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_ID).equals(redeemEvents.get(0).getEventID()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_ACTV_FILE_DATE).equals(redeemEvents.get(0).getFormattedFileDate()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_START_DATE).equals(redeemEvents.get(0).getFormattedStartDate()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_END_DATE).equals(redeemEvents.get(0).getFormattedEndDate()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_AUTHORIZATION_INDICATOR).equals(redeemEvents.get(0).getAuthorizationIndicator()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_DISCOUNT_TYPE).equals(redeemEvents.get(0).getDiscountType()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_DISCOUNT_AMOUNT).equals(redeemEvents.get(0).getDiscountAmountString()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_DEPT_EXCL_INCL_FLAG).equals(redeemEvents.get(0).getIncludeExcludeFlag()));
			assertTrue(redmEle.getAttribute(KohlsPOCConstant.ATTR_KC_DEPARTMENT_NUMBERS).equals(redeemEvents.get(0).getDepartmentNumbersString()));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testDoesActivationEventExist() {
		KohlsPocKohlsCashFeedAPI toTest = spy(new KohlsPocKohlsCashFeedAPI());
		toTest.existingActvEvents = activateEvents;
		doNothing().when(toTest).updateActivationEvent(Matchers.any(ActivateEventItem.class), Matchers.any(String.class));
		assertTrue(toTest.doesActivationEventExist(activateEvents.get(0)));
	}
	
	//@Test
	public void testDoesRedemptionEventExist() {
		KohlsPocKohlsCashFeedAPI toTest = spy(new KohlsPocKohlsCashFeedAPI());
		toTest.existingRedmEvents = redeemEvents;
		doNothing().when(toTest).updateRedemptionEvent(Matchers.any(RedeemEventItem.class), Matchers.any(String.class));
		assertTrue(toTest.doesRedemptionEventExist(redeemEvents.get(0)));
	}
	
	//@Test
	public void testKohlsCashFeedMain() {
		KohlsPocKohlsCashFeedAPI toTest = spy(new KohlsPocKohlsCashFeedAPI()); 
		
		doReturn(activationsDocument).when(toTest).getActivationsFromDatabase(Matchers.any(YFSEnvironment.class), Matchers.any(String.class));
		doReturn(true).when(toTest).addActivationEventToDatabase(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
		doNothing().when(toTest).removeUnprocessedActivateEvents(Matchers.any(YFSEnvironment.class));
		
		try {
			toTest.kohlsCashFeedMain(yfsEnv, transformedActivations);
			assertTrue(toTest.activationEventsAdded == 49940);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	//@Test
	public void testKohlsCashRedemptionFeedMain() {
		KohlsPocKohlsCashFeedAPI toTest = spy(new KohlsPocKohlsCashFeedAPI()); 
		
		doReturn(redemptionsDocument).when(toTest).getRedemptionEventsFromDatabase(Matchers.any(YFSEnvironment.class), Matchers.any(String.class));
		doReturn(true).when(toTest).addRedemptionEventToDatabase(Matchers.any(YFSEnvironment.class), Matchers.any(Document.class));
		doNothing().when(toTest).removeUnprocessedRedeemEvents(Matchers.any(YFSEnvironment.class));
		
		try {
			toTest.kohlsCashRedemptionFeedMain(yfsEnv, transformedRedemptions);
			assertTrue(toTest.redemptionEventsAdded == 2820);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
}
