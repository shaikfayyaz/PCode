package com.kohls.poc.data.kohlscash.messages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;
import com.kohls.poc.data.kohlscash.KohlsCouponType;

public class KohlsCashActivationTransactionMsgTest extends BaseKohlsCashTest {

	@Test
	public void testRequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_REQUEST_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(KohlsCashActivationTransactionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        KohlsCashActivationTransactionRequestMsg request = (KohlsCashActivationTransactionRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
	public void testBadUERequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_BAD_UE_REQUEST_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(KohlsCashActivationTransactionRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        KohlsCashActivationTransactionRequestMsg request = (KohlsCashActivationTransactionRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are NOT the same
	        assertFalse(output1.equals(output2));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
	public void testResponse() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document responseDocument = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_RESPONSE_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(KohlsCashActivationTransactionResponseMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        KohlsCashActivationTransactionResponseMsg response = (KohlsCashActivationTransactionResponseMsg) um.unmarshal(responseDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(response, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        //Test the generateResponseXml method
	        Document fromGenerate = response.generateResponseXml();
	        
	        responseDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        fromGenerate.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(responseDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        String output3 = XMLUtil.getXMLString(fromGenerate);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        assertTrue(output1.equals(output3));
	        
	        //Test other properties
	        response.setCouponType(KohlsCouponType.KOHLSCASHAUTH);
	        assertTrue(response.getCouponType() == KohlsCouponType.KOHLSCASHAUTH);
	        
	        response.setEventId("12345");
	        assertTrue(response.getEventId().equals("12345"));
	        
	        response.setActivationStartDate("2018-06-10");
	        assertTrue(response.getActivationStartDate().equals("2018-06-10"));
	        
	        response.setActivationEndDate("2018-06-10");
	        assertTrue(response.getActivationEndDate().equals("2018-06-10"));
	        
	        response.setEventName("Kohls Cash Test");
	        assertTrue(response.getEventName().equals("Kohls Cash Test"));
	        
	        response.setReceiptMessageLine1("test");
	        assertTrue(response.getReceiptMessageLine1().equals("test"));
	        
	        response.setReceiptMessageLine2("test2");
	        assertTrue(response.getReceiptMessageLine2().equals("test2"));
	        
	        response.setValidationCode("9316");
	        assertTrue(response.getValidationCode().equals("9316"));
	        
	        response.setErrorMessageToDisplay("error");
	        assertTrue(response.getErrorMessageToDisplay().equals("error"));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
}
