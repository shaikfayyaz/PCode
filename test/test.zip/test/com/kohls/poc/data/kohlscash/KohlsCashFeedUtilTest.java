package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class KohlsCashFeedUtilTest {

	@Test
	public void testKohlsCashFeedUtil() {
		assertTrue(KohlsCashFeedUtil.getInstance().convertCharToInt('5') == 5);
		assertTrue(KohlsCashFeedUtil.getInstance().convertBoolToString(false).equals("False"));
		assertTrue(KohlsCashFeedUtil.getInstance().convertStringToLong("fail") == 0);
		assertTrue(KohlsCashFeedUtil.getInstance().convertStringToDouble("fail") == 0.0);
		assertTrue(KohlsCashFeedUtil.getInstance().convertStringToBool("true"));
		assertTrue(KohlsCashFeedUtil.getInstance().CheckDigitCreate("") == -1);
		assertTrue(KohlsCashFeedUtil.getInstance().CheckDigitCreate("12121212121212112312122131212312") == -1);
		assertTrue(KohlsCashFeedUtil.getInstance().getStoreNumberFromHeader("").equals(""));
	}
	
}
