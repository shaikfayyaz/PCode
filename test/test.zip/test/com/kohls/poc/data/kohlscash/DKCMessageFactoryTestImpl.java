package com.kohls.poc.data.kohlscash;

import org.junit.Ignore;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.kohls.poc.data.kohlscash.dkc.DKCInquiryRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCMessageFactory;
import com.kohls.poc.data.kohlscash.dkc.DKCTenderRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCVoidTransactionRequestMessage;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;

@Ignore
public class DKCMessageFactoryTestImpl implements DKCMessageFactory {
	
	private int statusCode;
	
	public DKCMessageFactoryTestImpl(int statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public DKCInquiryRequestMessage createDKCInquiryRequestMessage(CouponInquiryRequestMsg inquiryRequestMsg) {
		switch(this.statusCode) {
			case -1:
				return new DKCInquiryRequestMessageTest_NULL();
			case 200:
				return new DKCInquiryRequestMessageTest_200();
			case 400:
				return new DKCInquiryRequestMessageTest_400();
			case 500:
				return new DKCInquiryRequestMessageTest_500();
			case 600:
				return new DKCInquiryRequestMessageTest_DKCError_ActivationNotFound();
			case 601:
				return new DKCInquiryRequestMessageTest_DKCError_ActivationVoided();
			case 602:
				return new DKCInquiryRequestMessageTest_DKCError_Referral();
			case 603:
				return new DKCInquiryRequestMessageTest_DKCError_Default();
			default:
				return new DKCInquiryRequestMessageTest_200();
		}
		
	}
	
	@Override
	public DKCVoidTransactionRequestMessage createDKCVoidTransactionRequestMessage(CouponRedemptionRequestMsg inMsg,
			String voidTimestamp) {
		switch(this.statusCode) {
			case -1:
				return new DKCVoidTransactionRequestMessageTest_NULL();
			case 200:
				return new DKCVoidTransactionRequestMessageTest_200();
			case 201:
				return new DKCVoidTransactionRequestMessageTest_NoStatus();
			case 400:
				return new DKCVoidTransactionRequestMessageTest_400();
			case 500:
				return new DKCVoidTransactionRequestMessageTest_500();
			case 600:
				return new DKCVoidTransactionRequestMessageTest_DKCError_VoidError();
			case 601:
				return new DKCVoidTransactionRequestMessageTest_DKCError_Default();
			default:
				return new DKCVoidTransactionRequestMessageTest_200();
		}
	}

	@Override
	public DKCTenderRequestMessage createDKCTenderRequestMessage(CouponRedemptionRequestMsg inMsg) {
		switch(this.statusCode) {
			case -1:
				return new DKCTenderRequestMessageTest_NULL();
			case 200:
				return new DKCTenderRequestMessageTest_200();
			case 400:
				return new DKCTenderRequestMessageTest_400();
			case 500:
				return new DKCTenderRequestMessageTest_500();
			case 600:
				return new DKCTenderRequestMessageTest_DKCError_ActivationNotFound();
			case 601:
				return new DKCTenderRequestMessageTest_DKCError_ActivationNotFoundEditError();
			case 602:
				return new DKCTenderRequestMessageTest_DKCError_ActivationVoided();
			case 603:
				return new DKCTenderRequestMessageTest_DKCError_Referral();
			case 604:
				return new DKCTenderRequestMessageTest_DKCError_Default();
			default:
				return new DKCTenderRequestMessageTest_200();
		}
	}
	
	static class DKCInquiryRequestMessageTest_NULL extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	return null;
	    }
	}
	
	static class DKCInquiryRequestMessageTest_200 extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:InquiryResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<InquiryResponse>"
		    						+ "<Balance>90.0</Balance>"
		    						+ "<TransactionDetails>"
		    							+ "<StoreNumber>32</StoreNumber>"
		    							+ "<StoreName>LAKE WORTH</StoreName><"
		    							+ "TransactionType>ISSUE</TransactionType>"
		    							+ "<TransactionAmount>90.0</TransactionAmount>"
		    							+ "<TransactionTimestamp>2016-03-22T19:07:10.000</TransactionTimestamp>"
	    							+ "</TransactionDetails>"
    							+ "</InquiryResponse>"
							+ "</ns0:InquiryResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCInquiryRequestMessageTest_400 extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("", HttpStatus.BAD_REQUEST);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCInquiryRequestMessageTest_500 extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCInquiryRequestMessageTest_DKCError_ActivationNotFound extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:InquiryResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>300</ErrorCode>"
		    						+ "<ErrorDescription>Activation not found test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:InquiryResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCInquiryRequestMessageTest_DKCError_ActivationVoided extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:InquiryResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>301</ErrorCode>"
		    						+ "<ErrorDescription>Activation voided test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:InquiryResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCInquiryRequestMessageTest_DKCError_Referral extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:InquiryResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>302</ErrorCode>"
		    						+ "<ErrorDescription>Referral test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:InquiryResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCInquiryRequestMessageTest_DKCError_Default extends DKCInquiryRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:InquiryResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>999</ErrorCode>"
		    						+ "<ErrorDescription>Default test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:InquiryResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_NULL extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	return null;
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_200 extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:VoidTransactionResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<VoidTransactionResponse>"
		    						+ "<TransactionStatus>VOIDED</TransactionStatus>"
    							+ "</VoidTransactionResponse>"
							+ "</ns0:VoidTransactionResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_NoStatus extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:VoidTransactionResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<VoidTransactionResponse>"
    							+ "</VoidTransactionResponse>"
							+ "</ns0:VoidTransactionResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_400 extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("", HttpStatus.BAD_REQUEST);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_500 extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_DKCError_VoidError extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:VoidTransactionResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>900</ErrorCode>"
		    						+ "<ErrorDescription>Default test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:VoidTransactionResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCVoidTransactionRequestMessageTest_DKCError_Default extends DKCVoidTransactionRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:VoidTransactionResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>999</ErrorCode>"
		    						+ "<ErrorDescription>Default test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:VoidTransactionResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_NULL extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	return null;
	    }
	}
	
	static class DKCTenderRequestMessageTest_200 extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:TenderKohlsCashResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<TenderKohlsCashSuccessList>"
		    						+ "<Balance>90.0</Balance>"
		    						+ "<TenderKohlsCashSuccess>"
		    							+ "<Barcode>123457899896868</Barcode>"
		    							+ "<RemainingBalance>1082.98</RemainingBalance>"
		    							+ "<LineToPrint>12</LineToPrint>"
	    							+ "</TenderKohlsCashSuccess>"
    							+ "</TenderKohlsCashSuccessList>"
							+ "</ns0:TenderKohlsCashResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_400 extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("", HttpStatus.BAD_REQUEST);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_500 extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("", HttpStatus.INTERNAL_SERVER_ERROR);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_DKCError_ActivationNotFound extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:TenderKohlsCashResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>300</ErrorCode>"
		    						+ "<ErrorDescription>Activation not found test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:TenderKohlsCashResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_DKCError_ActivationNotFoundEditError extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:TenderKohlsCashResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>300</ErrorCode>"
		    						+ "<ErrorDescription>Transaction amount must be greater test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:TenderKohlsCashResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_DKCError_ActivationVoided extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:TenderKohlsCashResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>301</ErrorCode>"
		    						+ "<ErrorDescription>Activation voided test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:TenderKohlsCashResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_DKCError_Referral extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:TenderKohlsCashResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>302</ErrorCode>"
		    						+ "<ErrorDescription>Referral test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:TenderKohlsCashResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
	
	static class DKCTenderRequestMessageTest_DKCError_Default extends DKCTenderRequestMessage {
		@Override
		public ResponseEntity<String> sendRequest() {
	    	try{
		    	ResponseEntity<String> response = new ResponseEntity<String>("<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">"
		    			+ "<env:Header />"
		    			+ "<env:Body>"
		    				+ "<ns0:TenderKohlsCashResponse xmlns:ns0=\"http://kohls.com/DKCService/\">"
		    					+ "<Error>"
		    						+ "<ErrorCode>999</ErrorCode>"
		    						+ "<ErrorDescription>Default test</ErrorDescription>"
    							+ "</Error>"
							+ "</ns0:TenderKohlsCashResponse>"
						+ "</env:Body>"
					+ "</env:Envelope>", HttpStatus.OK);
				
				return response;
	    	}
	    	catch(Exception ex) {
	    		return null;
	    	}
	    }
	}
}
