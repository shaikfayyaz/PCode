package com.kohls.poc.data.kohlscash.dkc;

import static org.junit.Assert.assertTrue;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Ignore;
import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;

@Ignore
public class DKCRequestMessageTest extends BaseKohlsCashTest {

	//@Test
	public void testDKCRequestMessageBase() {
		
		DKCInquiryRequestMessage req = new DKCInquiryRequestMessage();
		
		Document header = req.createDocumentHeader();
		
		String headerStr = XMLUtil.getXMLString(header);
		
		assertTrue(headerStr.contains("<From app=\"POC\" module=\"POC\" nodeID=\"POC\" systemCode=\"POC\"/>"));
		
		req.createHttpHeaders();
		
		assertTrue(req.headers.containsKey(KohlsPOCConstant.CONTENT_TYPE_STRING));
	}
	
	//@Test
	public void testDKCInquiryRequest() {
		DKCInquiryRequestMessage req = new DKCInquiryRequestMessage("9951", "10", "26", "2018-06-10T01:43:15", true, "12", "12", "9316");
		
		Document reqDoc = req.toDocument();
		String reqStr = XMLUtil.getXMLString(reqDoc);
		
		assertTrue(reqStr.contains("<RewardNumber>12</RewardNumber>"));
		assertTrue(reqStr.contains("<TransactionTimestamp>2018-06-10T01:43:15</TransactionTimestamp>"));
		assertTrue(reqStr.contains("<StoreNumber>9951</StoreNumber>"));
		assertTrue(reqStr.contains("<RegisterId>26</RegisterId>"));
		assertTrue(reqStr.contains("<TransactionNumber>10</TransactionNumber>"));
		assertTrue(reqStr.contains("<ScannedIndicator>true</ScannedIndicator>"));
		assertTrue(reqStr.contains("<Pin>9316</Pin>"));
		assertTrue(reqStr.contains("<ReceiptNumber>12</ReceiptNumber>"));
		assertTrue(reqStr.contains("<MessageType>Coupon</MessageType>"));
	}
	
	//@Test
	public void testDKCVoidTransactionRequest() {
		DKCVoidTransactionRequestMessage req = new DKCVoidTransactionRequestMessage("23452342", "2343456", "2018-06-10T01:50:03",
				"9951", "26", "10", "11", "96000001", "2018-06-10T01:50:36");
		
		Document reqDoc = req.toDocument();
		String reqStr = XMLUtil.getXMLString(reqDoc);
		
		assertTrue(reqStr.contains("<Barcode>23452342</Barcode>"));
		assertTrue(reqStr.contains("<ReceiptNumber>2343456</ReceiptNumber>"));
		assertTrue(reqStr.contains("<SalesDate>2018-06-10T01:50:03</SalesDate>"));
		assertTrue(reqStr.contains("<StoreNumber>9951</StoreNumber>"));
		assertTrue(reqStr.contains("<RegisterId>26</RegisterId>"));
		assertTrue(reqStr.contains("<TransactionNumber>10</TransactionNumber>"));
		assertTrue(reqStr.contains("<CustomerOrderNumber>11</CustomerOrderNumber>"));
		assertTrue(reqStr.contains("<VoidUserId>96000001</VoidUserId>"));
		assertTrue(reqStr.contains("<VoidTimestamp>2018-06-10T01:50:36</VoidTimestamp>"));
	}
	
	//@Test
	public void testDKCTenderRequest() {
		DKCTenderRequestMessage req = new DKCTenderRequestMessage("9951", "10", "26", "2018-06-10T01:55:43", "324234234", "10.00", "9316", "234243423");
		
		Document reqDoc = req.toDocument();
		String reqStr = XMLUtil.getXMLString(reqDoc);
		
		assertTrue(reqStr.contains("<Barcode>324234234</Barcode>"));
		assertTrue(reqStr.contains("<ReceiptNumber>234243423</ReceiptNumber>"));
		assertTrue(reqStr.contains("<Timestamp>2018-06-10T01:55:43</Timestamp>"));
		assertTrue(reqStr.contains("<StoreNumber>9951</StoreNumber>"));
		assertTrue(reqStr.contains("<RegisterID>26</RegisterID>"));
		assertTrue(reqStr.contains("<TransactionNumber>10</TransactionNumber>"));
		assertTrue(reqStr.contains("<Amount>10.00</Amount>"));
		assertTrue(reqStr.contains("<PIN>9316</PIN>"));
	}
	
	//@Test
	public void testDKCMessageFactoryImpl() {
		DKCMessageFactoryImpl factory = new DKCMessageFactoryImpl();
		
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inquiryReqDocument = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        Document redeemRequestDocument = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
	        
			JAXBContext inqReqContext = JAXBContext.newInstance(CouponInquiryRequestMsg.class);
	        Unmarshaller inqUM = inqReqContext.createUnmarshaller();
	        JAXBContext redeemReqContext = JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
	        Unmarshaller redeemUM = redeemReqContext.createUnmarshaller();
	        
	        CouponInquiryRequestMsg inquiryRequestMsg = (CouponInquiryRequestMsg) inqUM.unmarshal(inquiryReqDocument);
	        CouponRedemptionRequestMsg redemptionRequest = (CouponRedemptionRequestMsg) redeemUM.unmarshal(redeemRequestDocument);
			
			DKCInquiryRequestMessage inq = factory.createDKCInquiryRequestMessage(inquiryRequestMsg);
			DKCVoidTransactionRequestMessage voidTran = factory.createDKCVoidTransactionRequestMessage(redemptionRequest, "2018-06-10T02:04:36");
			DKCTenderRequestMessage tender = factory.createDKCTenderRequestMessage(redemptionRequest);
			
			assertTrue(inq != null);
			assertTrue(voidTran != null);
			assertTrue(tender != null);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
}
