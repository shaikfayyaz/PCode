package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class KohlsCashStatusTest {

	@Test
	public void testKohlsCashStatus() {
		KohlsCashStatus toTest = new KohlsCashStatus(5.5, 5.5, 5.5);
		
		assertTrue(toTest.getKohlsCashBalance() == 5.5);
		assertTrue(toTest.getKohlsCashBalanceStr().equals("5.50"));
		assertTrue(toTest.getEarnedAmt() == 5.5);
		assertTrue(toTest.getEarnedAmtStr().equals("5.50"));
		assertTrue(toTest.getEligibleAmt() == 5.5);
		assertTrue(toTest.getEligibleAmtStr().equals("5.50"));
		
		toTest = null;
		toTest = new KohlsCashStatus("5.5", "5.5", "5.5");
		
		assertTrue(toTest.getKohlsCashBalance() == 5.5);
		assertTrue(toTest.getKohlsCashBalanceStr().equals("5.5"));
		assertTrue(toTest.getEarnedAmt() == 5.5);
		assertTrue(toTest.getEarnedAmtStr().equals("5.5"));
		assertTrue(toTest.getEligibleAmt() == 5.5);
		assertTrue(toTest.getEligibleAmtStr().equals("5.5"));
		
	}
	
}
