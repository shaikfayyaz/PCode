package com.kohls.poc.data.kohlscash;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.spy;

import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;

public class KohlsCashManagerTest extends BaseKohlsCashTest {
	
	KohlsCashManager kcm = new KohlsCashManager(null);
	Document activationsDocument = null;
    Document redemptionsDocument = null;
    ArrayList<ActivateEventItem> activateEvents = null;
    ArrayList<RedeemEventItem> redeemEvents = null;
	
	@Before
	public void setUp() throws Exception {
		DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        activationsDocument = documentBuilder.parse(new File(KOHLS_CASH_ACTIVATIONS));
        redemptionsDocument = documentBuilder.parse(new File(KOHLS_CASH_REDEMPTIONS));
        
        activateEvents = kcm.processDatabaseActivationEvents(activationsDocument);
        redeemEvents = kcm.processDatabaseRedemptionEvents(redemptionsDocument);
		
        kcm.couponManager = new CouponManager(activateEvents, redeemEvents);
	}
	
	@Test
	public void testLoadEvents() {
		KohlsCashManager toTest = spy(new KohlsCashManager(null)); 
		
		try {
			doReturn(activationsDocument).when(toTest).getActivationEventsFromDatabase(Matchers.any(String.class));
			doReturn(redemptionsDocument).when(toTest).getRedemptionEventsFromDatabase(Matchers.any(String.class));
			
			toTest.loadEvents("9951");
			
			assertTrue(toTest.couponManager != null);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testBadCouponManager() {
		try {
			kcm.couponManager = null;
			Document nullDoc = kcm.determineKohlsCashActivation(null);
			
			assertTrue(nullDoc == null);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test public void testEmptyEventsCouponManager() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_REQUEST));
	        
			kcm.couponManager = new CouponManager(new ArrayList<ActivateEventItem>(), new ArrayList<RedeemEventItem>());
			
			kcm.determineKohlsCashActivation(inDoc);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testDetermineKohlsCashActivation() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_REQUEST));
	        Document goldOutDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_RESPONSE));
			
			Document outDoc = kcm.determineKohlsCashActivation(inDoc);
			
			String outXml = XMLUtil.getXMLString(outDoc);
			String goldOutXml = XMLUtil.getXMLString(goldOutDoc);
			assertTrue(outXml.equals(goldOutXml));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testDetermineKohlsCashActivationOver100() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_OVER100_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_OVER100_RESPONSE_XML));
			
			Document outDoc = kcm.determineKohlsCashActivation(inDoc);
			
			String outXml = XMLUtil.getXMLString(outDoc);
			String goldOutXml = XMLUtil.getXMLString(goldOutDoc);
			assertTrue(outXml.equals(goldOutXml));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testDetermineKohlsCashActivation_NoEarning() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_NO_EARNING_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_NO_EARNING_RESPONSE_XML));
			
			Document outDoc = kcm.determineKohlsCashActivation(inDoc);
			
			String outXml = XMLUtil.getXMLString(outDoc);
			String goldOutXml = XMLUtil.getXMLString(goldOutDoc);
			assertTrue(outXml.equals(goldOutXml));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testDetermineKohlsCashActivation_NoEarning_NoThreshold() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_NO_EARNING_NT_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(DETERMINE_ACTIVATION_NO_EARNING_NT_RESPONSE_XML));
			
			Document outDoc = kcm.determineKohlsCashActivation(inDoc);
			
			String outXml = XMLUtil.getXMLString(outDoc);
			String goldOutXml = XMLUtil.getXMLString(goldOutDoc);
			assertTrue(outXml.equals(goldOutXml));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquirySuccess() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryTokenized() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_TOKENIZED));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_TOKENIZED));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryPreRedemption() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_PRE));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_PRE));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryPostRedemption() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_POST));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_POST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryNoEvent() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_NOEVENT));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_NOEVENT));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryNoAuth() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_NOAUTH));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_NOAUTH));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryNoAuthPreRedemption() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_NOAUTH_PRE));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_NOAUTH_PRE));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryNoAuthPostRedemption() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_NOAUTH_POST));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_NOAUTH_POST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryLegacyPercent() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_LEGACY_P));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_LEGACY_P));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryLegacyDollar() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_LEGACY_D));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_LEGACY_D));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryPreRedemptionLegacyPercent() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_PRE_LEGACY_P));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_PRE_LEGACY_P));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryPostRedemptionLegacyPercent() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_POST_LEGACY_P));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_POST_LEGACY_P));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryPreRedemptionLegacyDollar() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_PRE_LEGACY_D));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_PRE_LEGACY_D));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryPostRedemptionLegacyDollar() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST_POST_LEGACY_D));
	        Document goldOutDoc = documentBuilder.parse(new File(INQUIRY_RESPONSE_POST_LEGACY_D));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryF0NoBalance() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImplInqF0();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        assertTrue(outString.contains("CouponBalance=\"0.0\""));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryF8Duplicate() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImplInqF8();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        assertTrue(outString.contains(KohlsPOCConstant.F8_DUPLICATE_ERROR));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryF72() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImplInqF72();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        assertTrue(outString.contains(KohlsPOCConstant.F7_700002_INQ_TRANS_DECLINE_ERROR));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryF73() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImplInqF73();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        assertTrue(outString.contains(KohlsPOCConstant.F7_700003_INQ_TRANS_DECLINE_ERROR));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryF74() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImplInqF74();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        assertTrue(outString.contains(KohlsPOCConstant.F7_700004_INQ_TRANS_DECLINE_ERROR));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashInquiryF2() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(INQUIRY_REQUEST));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImplInqF2();
	        
	        Document outDoc = kcm.kohlsCashInquiry(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        assertTrue(outString.contains(KohlsPOCConstant.F9_OFFLINE_ERROR));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashRedemptionSuccess() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(COUPON_REDEMPTION_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(COUPON_REDEMPTION_RESPONSE_XML));
	        
	        kcm.messenger = new KohlsCashRewardsSystemMessengerTestImpl();
	        
	        Document outDoc = kcm.kohlsCashRedemption(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashActivationTransaction() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_RESPONSE_XML));
	        
	        Document outDoc = kcm.kohlsCashActivationTransaction(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashActivationTransaction_NoEvent() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_REQUEST_NO_EVENT_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_RESPONSE_NO_EVENT_XML));
	        
	        Document outDoc = kcm.kohlsCashActivationTransaction(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashActivationTransaction_Legacy() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_REQUEST_LEGACY_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_RESPONSE_LEGACY_XML));
	        
	        Document outDoc = kcm.kohlsCashActivationTransaction(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashActivationTransaction_NoActivation() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_REQUEST_NO_ACTIVATE_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_RESPONSE_NO_ACTIVATE_XML));
	        
	        Document outDoc = kcm.kohlsCashActivationTransaction(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashActivationTransaction_RKC() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(ACTIVATION_TRANSACTION_REQUEST_RKC_XML);
	        Document goldOutDoc = documentBuilder.parse(new File(ACTIVATION_TRANSACTION_RESPONSE_RKC_XML));
	        
	        Document outDoc = kcm.kohlsCashActivationTransaction(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testKohlsCashDetermineDeactivation() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(DETERMINE_DEACTIVATION_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(DETERMINE_DEACTIVATION_RESPONSE_XML));
	        
	        Document outDoc = kcm.determineKohlsCashDeactivation(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testGetActiveRKCEventsWithEventID() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_RESPONSE_XML));
	        
	        Document outDoc = kcm.getActiveRKCEvents(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testGetActiveRKCEventsWithoutEventID() {
		try {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
	        Document inDoc = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_NO_ID_REQUEST_XML));
	        Document goldOutDoc = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_NO_ID_RESPONSE_XML));
	        
	        Document outDoc = kcm.getActiveRKCEvents(inDoc);
	        
	        String outString = XMLUtil.getXMLString(outDoc);
	        String goldOutString = XMLUtil.getXMLString(goldOutDoc);
	        assertTrue(outString.equals(goldOutString));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testIsOMSKohlsCashEnabled_Yes() {
		KohlsCashManager kcm = Mockito.spy(new KohlsCashManager(null));
		try {
			Mockito.doReturn("Y").when(kcm).getOMSKohlsCashEnabledRule(Matchers.any(String.class));
			
			assertTrue(kcm.isOMSKohlsCashEnabled("9951"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testIsOMSKohlsCashEnabled_No() {
		KohlsCashManager kcm = Mockito.spy(new KohlsCashManager(null));
		try {
			Mockito.doReturn("N").when(kcm).getOMSKohlsCashEnabledRule(Matchers.any(String.class));
			
			assertFalse(kcm.isOMSKohlsCashEnabled("9951"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testIsOMSKohlsCashEnabled_InvalidOrg() {
		KohlsCashManager kcm = Mockito.spy(new KohlsCashManager(null));
		try {
			Mockito.doReturn("N").when(kcm).getOMSKohlsCashEnabledRule(Matchers.any(String.class));
			
			assertFalse(kcm.isOMSKohlsCashEnabled(""));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testIsOMSKohlsCashEnabled_NonIntOrg() {
		KohlsCashManager kcm = Mockito.spy(new KohlsCashManager(null));
		try {
			Mockito.doReturn("N").when(kcm).getOMSKohlsCashEnabledRule(Matchers.any(String.class));
			
			assertFalse(kcm.isOMSKohlsCashEnabled("Test"));
		}
		catch(Exception ex) {
			ex.printStackTrace();
			assertTrue(false);
		}
	}
	
	@Test
	public void testFixStoreId() {
		String fixMe = kcm.fixStoreId("9953");
		assertTrue(fixMe.equals("9953"));
		
		fixMe = kcm.fixStoreId("0953");
		assertTrue(fixMe.equals("953"));
		
		fixMe = kcm.fixStoreId("0053");
		assertTrue(fixMe.equals("53"));
		
		fixMe = kcm.fixStoreId("0003");
		assertTrue(fixMe.equals("3"));
	}
}
