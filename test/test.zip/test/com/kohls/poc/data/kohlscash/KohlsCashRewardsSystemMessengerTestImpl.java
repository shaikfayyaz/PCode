package com.kohls.poc.data.kohlscash;

import java.util.ArrayList;

import org.junit.Ignore;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.dkc.DKCResponseHelper;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;

@Ignore
public class KohlsCashRewardsSystemMessengerTestImpl implements KohlsCashRewardsSystemMessenger {
	
	@Override
	public CouponInquiryResponseMsg sendKohlsCashInquiryAJBMessage(CouponInquiryRequestMsg inquiryRequestMsg,
			CouponInquiryResponseMsg inquiryResponseMsg) {
		try {
			TransactionDetail detail = new TransactionDetail();
			detail.setStoreName("LAKE WORTH");
			detail.setStoreNumber("32");
			detail.setTransactionAmount("57.0");
			detail.setTransactionTimestamp("2016-03-22T19:07:10.000");
			detail.setTransactionType("ISSUE");
			
			ArrayList<TransactionDetail> details = new ArrayList<TransactionDetail>();
			details.add(detail);
			
			inquiryResponseMsg.setCouponBalance("10.0");
			inquiryResponseMsg.setHistoryData(DKCResponseHelper.asHistoryData(details));
			inquiryResponseMsg.setExpirationDate("2030-01-01T00:00:00.000");
			inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.Approved.getValue());
			inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
			
			return inquiryResponseMsg;
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return null;
	}

	@Override
	public CouponRedemptionResponseMsg sendKohlsCashVoidTransactionAJBMessage(CouponRedemptionRequestMsg inMsg,
			CouponRedemptionResponseMsg outMsg) {
		
		
		return null;
	}

	@Override
	public CouponRedemptionResponseMsg sendKohlsCashRedemptionAJBMessage(CouponRedemptionRequestMsg inMsg,
			CouponRedemptionResponseMsg outMsg) {
		
		try {
			outMsg.setLineToPrint("5");
			outMsg.setCouponBalance("10.00");
			outMsg.setCouponValue(inMsg.getDiscountAmount());
			outMsg.setAuthResponseCode(KohlsCashResponseCode.Approved.getValue());
			outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
			
			return outMsg;
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return null;
	}
	
}
