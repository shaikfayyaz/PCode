package com.kohls.poc.data.kohlscash;

import org.junit.Ignore;

import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;

@Ignore
public class KohlsCashRewardsSystemMessengerTestImplInqF2 implements KohlsCashRewardsSystemMessenger {

	@Override
	public CouponInquiryResponseMsg sendKohlsCashInquiryAJBMessage(CouponInquiryRequestMsg inquiryRequestMsg,
			CouponInquiryResponseMsg inquiryResponseMsg) {
		
		inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.EditError.getValue());
		
		return inquiryResponseMsg;
	}

	@Override
	public CouponRedemptionResponseMsg sendKohlsCashVoidTransactionAJBMessage(CouponRedemptionRequestMsg inMsg,
			CouponRedemptionResponseMsg outMsg) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CouponRedemptionResponseMsg sendKohlsCashRedemptionAJBMessage(CouponRedemptionRequestMsg inMsg,
			CouponRedemptionResponseMsg outMsg) {
		// TODO Auto-generated method stub
		return null;
	}
}
