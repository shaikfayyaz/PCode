package com.kohls.poc.data.kohlscash.messages;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.dom.DOMResult;

import org.junit.Test;
import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.data.kohlscash.BaseKohlsCashTest;

public class GetActiveRKCEventsMsgTest extends BaseKohlsCashTest {
	
	@Test
	public void testRequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_REQUEST_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(GetActiveRKCEventsRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        GetActiveRKCEventsRequestMsg request = (GetActiveRKCEventsRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
	public void testBadUERequest() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document requestDocument = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_BAD_UE_REQUEST_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(GetActiveRKCEventsRequestMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        GetActiveRKCEventsRequestMsg request = (GetActiveRKCEventsRequestMsg) um.unmarshal(requestDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        requestDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(requestDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        
	        //Make sure the XML strings are NOT the same
	        assertFalse(output1.equals(output2));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}
	
	@Test
	public void testResponse() {
		try {
			//Read the XML file into a document
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
            Document responseDocument = documentBuilder.parse(new File(GET_ACTIVE_RKC_EVENTS_RESPONSE_XML));
            
			JAXBContext reqContext = JAXBContext.newInstance(GetActiveRKCEventsResponseMsg.class);
	        Unmarshaller um = reqContext.createUnmarshaller();
	        
	        //Unmarshal the XML file document into an object
	        GetActiveRKCEventsResponseMsg request = (GetActiveRKCEventsResponseMsg) um.unmarshal(responseDocument);
			
	        //Marshal the object back into a document
			Marshaller m = reqContext.createMarshaller();
	        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        DOMResult res = new DOMResult();
	        m.marshal(request, res);
	        Document jaxbDoc = (Document) res.getNode();
	        
	        //Test the generateResponseXml method
	        Document fromGenerate = request.generateResponseXml();
	        
	        responseDocument.normalizeDocument();
	        jaxbDoc.normalizeDocument();
	        fromGenerate.normalizeDocument();
	        
	        //Get the XML strings from the documents
	        String output1 = XMLUtil.getXMLString(responseDocument);
	        String output2 = XMLUtil.getXMLString(jaxbDoc);
	        String output3 = XMLUtil.getXMLString(fromGenerate);
	        
	        //Make sure the XML strings are the same
	        assertTrue(output1.equals(output2));
	        assertTrue(output1.equals(output3));
		}
        catch(Exception ex) {
        	ex.printStackTrace();
        	assertTrue(false);
        }
	}

}
