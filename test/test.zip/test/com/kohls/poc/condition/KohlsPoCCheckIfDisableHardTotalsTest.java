package com.kohls.poc.condition;

import com.kohls.poc.pricing.ue.PoCBaseSetUp;
import org.junit.*;
import org.w3c.dom.Document;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.spy;

/**
 * Created on 1/30/18.
 */
public class KohlsPoCCheckIfDisableHardTotalsTest extends PoCBaseSetUp {

    @BeforeClass
    public static void  setUpBeforeClass() throws Exception {
        //super.setUpBeforeClass();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        //super.tearDownAfterClass();
    }

    @Test
    public void testValidateDisableHardTotals() throws Exception {
        Document document1 = getDocumentFromFile("MobilePoC/OrderXML_DisableHardTotals.xml");
        Document document2 = getDocumentFromFile("MobilePoC/OrderXML_EnableHardTotals.xml");
        Document document3 = getDocumentFromFile("MobilePoC/OrderXML_HardTotalsNotPresent.xml");
        Document document4 = getDocumentFromFile("MobilePoC/OrderXML_POC.xml");

        Map map = new HashMap();
        map.put("SellerOrganizationCode", "9953");
        map.put("TerminalID", "74");

        KohlsPoCCheckIfDisableHardTotals toTest = spy(new KohlsPoCCheckIfDisableHardTotals());
        boolean output1 = toTest.evaluateCondition(yfsEnv, "Enable Hard Totals",map, document1);
        boolean output2 = toTest.evaluateCondition(yfsEnv, "Enable Hard Totals",map, document2);
        boolean output3 = toTest.evaluateCondition(yfsEnv, "Enable Hard Totals",map, document3);
        boolean output4 = toTest.evaluateCondition(yfsEnv, "Enable Hard Totals",map, document4);

        assertEquals(false, output1);
        assertEquals(true, output2);
        assertEquals(true, output3);
        assertEquals(true, output4);

    }

}