package com.kohls.devops.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.io.IOUtils;

public class JNDI_Handler {

	public static void main(String args[]) throws Exception {

		inputArgsValidation(args);

		String environment = args[0];
		String configData=args[1]+".data";
		String fileName = args[1]+".in";
		String outFileName=args[1];

System.out.println("environment -->>>>> ="+environment);
System.out.println("configData -->>>>> ="+configData);
System.out.println("fileName -->>>>> ="+fileName);
System.out.println("outFileName -->>>>> ="+outFileName);
		
		
		inputFilesValidation(configData, fileName);
		
		Set <String> setEnvironment=JNDI_Data_Handler.getEnvs(configData);		
		
		if (environment.equals("ALL"));else {setEnvironment.clear();setEnvironment.add(environment);}

		try {

		    Iterator<String> iterator = setEnvironment.iterator();
		    while(iterator.hasNext()) {
		    	environment=iterator.next();
			FileInputStream fis = new FileInputStream(fileName);
			Properties prop = new Properties();
			InputStream input = null;
			input = new FileInputStream(configData);
			if(JNDI_Data_Handler.getEnvs(configData).contains(environment))
			{
				Set<String> configDataSet=JNDI_Data_Handler.inputDataValidation(configData, environment);
				Set<String> configInSet=getArgs(fileName);
				Set<String> configDataDiffSet=difference(configDataSet,configInSet);
				Set<String> configInDiffSet=difference(configInSet,configDataSet);
				if (configDataDiffSet.size()>0) System.out.println("Warning! "+configDataDiffSet.size()+" are missing in configData");
				if (configInDiffSet.size()>0) System.out.println("Warning! "+configInDiffSet.size()+" are missing in configInput");
				
			}
			else{
				System.out.println("Error! :Requested Environment Config is not present in "+configData+" file");
				System.exit(1);
			}
			
			prop.load(input);
			String content = IOUtils.toString(fis);

			@SuppressWarnings("rawtypes")
			Enumeration enuKeys = prop.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
			
				if (key.contains(environment)) {
					String value = prop.getProperty(key);
					if ((value.equals(""))||(value==null)) {System.out.println("Error! : "+key+"is missing the value assigned" );System.exit(1);}				
					if (value.equals("NULL")) value = "";
					content = content.replaceAll(
							"\\$\\{" + key.replaceFirst(environment + "-", "")
									+ "\\}", value);
				}

			}

			fis.close();
			outFileName=args[1]+"."+environment;

	System.out.println("outFileName -->>>>> ="+outFileName);
			
			FileOutputStream fos = new FileOutputStream(outFileName);
			IOUtils.write(content, fos);
			fos.close();
			
			Set<String> outFileArgs=getArgs(outFileName);

    System.out.println("outFileArgs --->>>>>>"+outFileArgs);

			
			if(outFileArgs.size()>0){
			System.out.println("Error!   :No of variables that remain unreplaced ="+outFileArgs.size());
			System.out.println("Error!   :Variables that remain unreplaced ="+outFileArgs);
			System.exit(1);
			}
			
		} }
	catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void inputFilesValidation(String configData, String fileName) {
		// TODO Auto-generated method stub
		File configDataFile=new File(configData);
	    if (configDataFile.exists()); else {System.out.println("Error! : Unable to find or access the file "+configData); System.exit(1);}
	    File configInFile=new File(fileName);
	    if (configInFile.exists()); else {System.out.println("Error! : Unable to find or access the file "+configInFile); System.exit(1);}
		
	}

	public static <T> Set<T> difference(Set<T> setA, Set<T> setB) {
	    Set<T> tmp = new TreeSet<T>(setA);
	    tmp.removeAll(setB);
	    return tmp;
	  }

	private static Set<String> getArgs(String fileName) throws Exception {
		// TODO Auto-generated method stub
		File file = new File(fileName);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		Set<String> set = new HashSet<String>();
		while ((line = bufferedReader.readLine()) != null) {
			
			//System.out.println("No Of Args="+(line.length() - line.replaceAll("\\$", "").length()));
			String[] parts = line.split("\\$\\{");
			for(int i=0;i<parts.length;i++){
				String[] parts1=parts[i].split("\\}");
				for(int j=0;j<parts1.length;j++){
				if((i>0)&&(j%2 == 0)) set.add(parts1[j]);
				}
				
			}
		}
		//System.out.println(set);
		bufferedReader.close();
		return set;
	}

	private static void inputArgsValidation(String args[]) {
		if ((args.length != 2)) {
			// TODO Auto-generated method stub
			System.out
					.println("Error! :Number of input argument violation. ");
			System.out
					.println("Expected 2 arguments but received "
							+ args.length + " arguments");
			System.exit(1);
		}	

	}

}
