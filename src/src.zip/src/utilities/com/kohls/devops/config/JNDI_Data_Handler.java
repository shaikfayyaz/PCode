package com.kohls.devops.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
 
public class JNDI_Data_Handler {
 
    private Properties prop = null;
     
    public JNDI_Data_Handler(String fileName){
         
        InputStream is = null;
        try {
            this.prop = new Properties();
            //is = this.getClass().getResourceAsStream(fileName);
			is = new FileInputStream(fileName);
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     
    public Set<Object> getAllKeys(){
        Set<Object> keys = prop.keySet();
        return keys;
    }
     
    public String getPropertyValue(String key){
        return this.prop.getProperty(key);
    }
     
    public static Set<String> inputDataValidation(String fileName, String environment){
         
        JNDI_Data_Handler mpc = new JNDI_Data_Handler(fileName);
        Set<Object> keys = mpc.getAllKeys();
		Set<String> set = new HashSet<String>();
        for(Object k:keys){
            //String key = (String)k;
            //set.add(key);
            //System.out.println(key+": "+mpc.getPropertyValue(key));
        	String[] env = (String[])((String) k).split("-");
        	if (environment.equals(env[0]))
            set.add(env[1]);
        }
        return set;
    }
    public static Set<String> getEnvs(String fileName){
         
        JNDI_Data_Handler mpc = new JNDI_Data_Handler(fileName);
        Set<Object> keys = mpc.getAllKeys();
		Set<String> set = new HashSet<String>();
        for(Object k:keys){
            String[] env = (String[])((String) k).split("-");
            set.add(env[0]);
            //System.out.println(key+": "+mpc.getPropertyValue(key));
        }
        return set;
    }
    
}
