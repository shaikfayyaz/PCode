/**
 * 
 */
package com.kohls.bopus.ue;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.w3c.dom.Document;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSTxnCoordinatorUE;

/**
 * @author dh1user
 *
 */
public class KohlsBOPUSYFSTxnCoordinatorUE implements YFSTxnCoordinatorUE {


	private static final YFCLogCategory LOG = YFCLogCategory.instance(KohlsBOPUSYFSTxnCoordinatorUE.class.getName());
	
	/**
	 * 
	 */
	public KohlsBOPUSYFSTxnCoordinatorUE() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.yantra.yfs.japi.ue.YFSTxnCoordinatorUE#afterYantraTxnCommit(com.yantra.yfs.japi.YFSEnvironment)
	 */
	@Override
	public void afterYantraTxnCommit(YFSEnvironment env)
			throws YFSUserExitException {
		
		HashMap<String,Document> map = (HashMap<String,Document>) env.getTxnObject(KohlsConstant.BOPUS_DEVICE_NOTIFICATION_MAP);
		if (!YFCCommon.isVoid(map) && !map.isEmpty()) {
			Document dnInputDoc = null;
			String shipmentKey = null;
			Iterator it = map.entrySet().iterator();
			while (it.hasNext()) {
				LOG.debug("inside iteration");
			 	Map.Entry record = (Map.Entry) it.next();
			     shipmentKey = (String) record.getKey();
			     dnInputDoc = (Document) record.getValue();
			     try {
			    	 LOG.debug("before invoking inDoc:" + SCXmlUtil.getString(dnInputDoc));
			    	 KOHLSBaseApi.invokeService(env, KohlsConstant.BOPUS_DEVICE_SEND_NOTIFICATION_SERVICE,dnInputDoc);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				   
			}
			env.setTxnObject(KohlsConstant.BOPUS_DEVICE_NOTIFICATION_MAP, new HashMap<String, Document>());
		}
	}

	/* (non-Javadoc)
	 * @see com.yantra.yfs.japi.ue.YFSTxnCoordinatorUE#afterYantraTxnRollback(com.yantra.yfs.japi.YFSEnvironment)
	 */
	@Override
	public void afterYantraTxnRollback(YFSEnvironment arg0)
			throws YFSUserExitException {
	}

	/* (non-Javadoc)
	 * @see com.yantra.yfs.japi.ue.YFSTxnCoordinatorUE#beforeYantraTxnCommit(com.yantra.yfs.japi.YFSEnvironment)
	 */
	@Override
	public void beforeYantraTxnCommit(YFSEnvironment arg0)
			throws YFSUserExitException {

	}

}