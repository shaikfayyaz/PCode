package com.kohls.wsc.core.auth;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.text.ParseException;

import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.ParserConfigurationException;

import net.minidev.json.JSONObject;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.util.Base64URL;
import com.nimbusds.jwt.SignedJWT;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.ui.web.framework.context.SCUIContext;
import com.sterlingcommerce.ui.web.framework.utils.SCUIUtils;
import com.yantra.interop.client.InteropEnvStub;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;



public class KohlsWSCRequestValidator {



	/**

	 * Servlet to validate all the login requests to decrypt the JWT(JSON web token)

	 */

	private static final long serialVersionUID = 1L;





	private static YFCLogCategory log = YFCLogCategory.instance(KohlsWSCRequestValidator.class.getName());



	public boolean validateRequest(SCUIContext uiContext) throws Exception {

		String requestUrl = uiContext.getRequest().getRequestURI();
		
		boolean isEncryptedJWT = false;



		if(YFCLogUtil.isDebugEnabled()) {

			log.debug("###The requested  path is "+ requestUrl+" and the requested URL"+uiContext.getRequest().getRequestURI());			

		}



		try {

			String encryptedJWT =  uiContext.getRequest().getParameter("Jwt");

			String StoreId = uiContext.getRequest().getParameter("StoreId");

			log.debug("Jwt Parameter:"+encryptedJWT);

			try {

				if (!YFCCommon.isVoid(encryptedJWT)){

					try {

						isEncryptedJWT = validateUserData(uiContext, encryptedJWT, StoreId);

					} catch (InvalidKeySpecException e) {

						log.error(e);

					} catch (ParseException e) {

						log.error(e);

					}

				}

			} catch (NoSuchAlgorithmException e) {

				log.error(e);

			} catch (NoSuchPaddingException e) {

				log.error(e);

			} catch (KeyStoreException e) {

				log.error(e);

			} catch (CertificateException e) {

				log.error(e);

			}	

		} catch (IOException e) {

			log.error(e);

		}

		if(YFCLogUtil.isDebugEnabled()) {

			log.debug("### Returning this for request validation:" + isEncryptedJWT);			

		}

		return isEncryptedJWT;

	}

	public static boolean revalidateToken(String encryptedJWT) throws NoSuchAlgorithmException, NoSuchPaddingException, KeyStoreException, CertificateException, IOException, ParseException, InvalidKeySpecException, ParserConfigurationException, SAXException	
		{
		boolean tokenValidated = false;

		log.debug("Encrypted JWT:"+encryptedJWT);
		log.debug("revalidationg and deciphering the token again to make sure this is from devices");
		
		SignedJWT signedJWT = SignedJWT.parse(encryptedJWT);

		JSONObject payload = signedJWT.getPayload().toJSONObject();

		String keyId = (String) payload.get("keyId");
		
		// Public file path

				if (YFCCommon.isVoid(keyId)) {

					// invalid payload key id, return false

					return false;

				}

				

				BufferedReader reader = null;

				String keyFilePath = "";

				String input = null;

				String keyValue = "";

				String Modulus = null;

				String Exponent = null;

				try {

					if (keyId.indexOf(KohlsConstant.SSO_POS) != -1) {

						// load the POS key

						keyFilePath = YFSSystem.getProperty(KohlsConstant.SSO_PUB_KEY_PATH) + YFSSystem.getProperty(KohlsConstant.SSO_KEYID_POS);				

					} else {

						// use the key id passed in and load the mobile key

						keyFilePath = YFSSystem.getProperty(KohlsConstant.SSO_PUB_KEY_PATH) + keyId + KohlsConstant.SSO_KEY_FILE_SUFFIX;

					}

					log.debug("SSO PUBLIC Key File Path::" + keyFilePath);

					reader = new BufferedReader(new FileReader(new File(keyFilePath)));

					

					while ((input = reader.readLine()) != null) {

						keyValue += input;

					}

				} catch (Exception ex) {

					// problem loading the key

					log.warn("Problem loading the key" + ex);

				} finally {

					if (reader != null) {

						reader.close();

					}

				}

				

				if (YFCCommon.isVoid(keyValue)) {

					// problem reading the key, return false;

					return false;

				}



				Document Keyfile = SCXmlUtil.createFromString(keyValue);

				log.debug("key file:"+XMLUtil.getXMLString(Keyfile));

				NodeList Nodes = Keyfile.getDocumentElement().getChildNodes();

				for (int i=0;i<Nodes.getLength();i++) {

					Node node = Nodes.item(i);

					log.debug("Node name:"+node.getNodeName());

					if(node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName()==KohlsConstant.MODULUS){

						Modulus =node.getTextContent().trim();

						log.debug("Modulus is:"+Modulus);

					} else if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName()==KohlsConstant.EXPONENT){

						Exponent =node.getTextContent().trim();

						log.debug("Exponent is:"+Exponent);

					}						

				}



				BigInteger Mod = new Base64URL(Modulus).decodeToBigInteger();

				BigInteger Exp = new BigInteger((new Base64URL(Exponent).decode()));



				RSAPublicKeySpec spec = new RSAPublicKeySpec(Mod, Exp);

				KeyFactory factory = KeyFactory.getInstance("RSA");

				PublicKey publicKey = factory.generatePublic(spec);

				JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) publicKey);



			



				try {
					tokenValidated = signedJWT.verify(verifier);
					log.debug("Verification again:" + tokenValidated);

				} catch (JOSEException e1) {

					// TODO Auto-generated catch block

					e1.printStackTrace();

					// problem verifying key, return false

					return false;

				}
		
		return tokenValidated;
		}


	public boolean validateUserData(SCUIContext uiContext, String encryptedJWT, String StoreId) throws 

	NoSuchAlgorithmException, NoSuchPaddingException, KeyStoreException, CertificateException, IOException, ParseException, InvalidKeySpecException, ParserConfigurationException, SAXException{	



		log.debug("Encrypted JWT:"+encryptedJWT);

		boolean isValidToken = false;

		/**

		 * TODO : 1) Grab the key from the payload

		 * 2) Load the key indicated and verify the signature

		 */



		SignedJWT signedJWT = SignedJWT.parse(encryptedJWT);

		JSONObject payload = signedJWT.getPayload().toJSONObject();

		String keyId = (String) payload.get("keyId");

		

		// Public file path

		if (YFCCommon.isVoid(keyId)) {

			// invalid payload key id, return false

			return false;

		}

		

		BufferedReader reader = null;

		String keyFilePath = "";

		String input = null;

		String keyValue = "";

		String Modulus = null;

		String Exponent = null;

		try {

			if (keyId.indexOf(KohlsConstant.SSO_POS) != -1) {

				// load the POS key

				keyFilePath = YFSSystem.getProperty(KohlsConstant.SSO_PUB_KEY_PATH) + YFSSystem.getProperty(KohlsConstant.SSO_KEYID_POS);				

			} else {

				// use the key id passed in and load the mobile key

				keyFilePath = YFSSystem.getProperty(KohlsConstant.SSO_PUB_KEY_PATH) + keyId + KohlsConstant.SSO_KEY_FILE_SUFFIX;

			}

			log.debug("SSO PUBLIC Key File Path::" + keyFilePath);

			reader = new BufferedReader(new FileReader(new File(keyFilePath)));

			

			while ((input = reader.readLine()) != null) {

				keyValue += input;

			}

		} catch (Exception ex) {

			// problem loading the key

			log.warn("Problem loading the key" + ex);

		} finally {

			if (reader != null) {

				reader.close();

			}

		}

		

		if (YFCCommon.isVoid(keyValue)) {

			// problem reading the key, return false;

			return false;

		}



		Document Keyfile = SCXmlUtil.createFromString(keyValue);

		log.debug("key file:"+XMLUtil.getXMLString(Keyfile));

		NodeList Nodes = Keyfile.getDocumentElement().getChildNodes();

		for (int i=0;i<Nodes.getLength();i++) {

			Node node = Nodes.item(i);

			log.debug("Node name:"+node.getNodeName());

			if(node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName()==KohlsConstant.MODULUS){

				Modulus =node.getTextContent().trim();

				log.debug("Modulus is:"+Modulus);

			} else if (node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName()==KohlsConstant.EXPONENT){

				Exponent =node.getTextContent().trim();

				log.debug("Exponent is:"+Exponent);

			}						

		}



		BigInteger Mod = new Base64URL(Modulus).decodeToBigInteger();

		BigInteger Exp = new BigInteger((new Base64URL(Exponent).decode()));



		RSAPublicKeySpec spec = new RSAPublicKeySpec(Mod, Exp);

		KeyFactory factory = KeyFactory.getInstance("RSA");

		PublicKey publicKey = factory.generatePublic(spec);

		JWSVerifier verifier = new RSASSAVerifier((RSAPublicKey) publicKey);



	



		try {

			log.debug("Verification:" + signedJWT.verify(verifier));

		} catch (JOSEException e1) {

			// TODO Auto-generated catch block

			e1.printStackTrace();

			// problem verifying key, return false

			return false;

		}



		try {

			if (signedJWT.verify(verifier)) {

				// we can trust

				String userId = (String) payload.get("userId");
				// convert to lowercase
				userId = userId.toLowerCase();

				// validate the remaining values

				String version = (String) payload.get(KohlsConstant.JWT_VERSION);

				String audience = (String) payload.get("aud");

				String exp = String.valueOf(((Long) payload.get("exp")).longValue());

				if (exp.length() < 13 && exp.length() == 10) {

					// convert it to long, its coming in as int

					exp = String.valueOf((long) Integer.parseInt(exp) * 1000L);

				}

				if (log.isDebugEnabled()) {

					log.debug("The userid is:" + userId);

					log.debug("The version is:" + version);

					log.debug("The keyId is:" + keyId);

					log.debug("The audience is:" + audience);

					log.debug("The exp is:" + exp);

				}

				if (uiContext.getRequest().getRequestURI().indexOf("mobile") >=0) {

					// this is for mobile

					if (version.indexOf(YFSSystem.getProperty(KohlsConstant.SSO_JWT_VERSION)) == -1 ||

							audience.indexOf(YFSSystem.getProperty(KohlsConstant.SSO_AUDIENCE_MOBILE)) == -1 ||

							System.currentTimeMillis() > Long.valueOf(exp)) {

						// something wrong with the token, return false

						return false;

					}						

				} else {

					// this is for POS

					if (version.indexOf(YFSSystem.getProperty(KohlsConstant.SSO_JWT_VERSION)) == -1 ||

							audience.indexOf(YFSSystem.getProperty(KohlsConstant.SSO_AUDIENCE_POS)) == -1 ||

							System.currentTimeMillis() > Long.valueOf(exp)) {

						// something wrong with the token, return false

						return false;

					}		

				}

	

				// set the session variable so we don't have to show password on page

				uiContext.getRequest().getSession().setAttribute(KohlsConstant.JWT_VERIFIED_PARAMETER, KohlsXMLLiterals.$$_UNIQUE_PASSWORD);
				uiContext.getRequest().getSession().setAttribute(KohlsConstant.JWT_PARAMETER, encryptedJWT);

				uiContext.getRequest().setAttribute(KohlsConstant.UserId, userId);
				uiContext.getRequest().setAttribute(KohlsConstant.Password, KohlsConstant.JWT_PARAMETER + encryptedJWT);
					
				if (!SCUIUtils.isVoid(uiContext.getRequest().getParameter(KohlsConstant.A_SHIPMENT_KEY))) {
					
					log.debug("The shipment key is:" + uiContext.getRequest().getParameter(KohlsConstant.A_SHIPMENT_KEY));
					
					uiContext.getRequest().getSession().setAttribute("BOPUS_SHIPMENT_KEY", uiContext.getRequest().getParameter(KohlsConstant.A_SHIPMENT_KEY));
				} else {
					log.debug("couldn't find shipment key for some reason");
				}

				if (!YFCCommon.isVoid(StoreId)) {

					uiContext.getRequest().setAttribute(KohlsConstant.STORE_ID_PARAMETER, StoreId);

				}

	

				isValidToken = isValidStoreUser(StoreId, userId, uiContext);

			}

		} catch (JOSEException jse) {

			// problem verifying loektn

			log.warn("Problem lodaing token" + jse.getMessage());

			return false;

		}

		return isValidToken;



	}



	public boolean isValidStoreUser(String strShipNode, String UserID, SCUIContext uiContext) {

		boolean isValidStoreUserID = false;

		int totalNumberOfRec = 0;

		log.beginTimer(this.getClass() + ".isValidStoreUser");



		if (YFCLogUtil.isDebugEnabled()) {

			log.debug("ShipNode: " + strShipNode);

			log.debug(("UserID:"+UserID));

		}



		// Creating Input for getUserList API Call.

		Document inDoc = SCXmlUtil.createDocument(KohlsXMLLiterals.A_APP_USER);

		inDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_LOGIN_ID,

				UserID);

		inDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORGANIZATION_KEY,

				strShipNode);

		if (YFCLogUtil.isDebugEnabled()) {

			log.debug("Input to getUserList: " + inDoc);

		}



		Document templateDoc = SCXmlUtil.createDocument(KohlsXMLLiterals.E_USER_LIST);

		templateDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_TOTAL_NUMBER_OF_RECORDS,"");

		// Calling getuserList API with template

		// template is getUserListTemplate_StoreUserValidation.xml

		Document outDoc = null;



		try {

			String applicationId = SCUIUtils.getApplicationId(uiContext.getServletContext());

			InteropEnvStub envStub = new InteropEnvStub(UserID, applicationId);

			YIFApi api = YIFClientFactory.getInstance().getApi();
			envStub.setApiTemplate("getUserList", templateDoc);

			outDoc = api.invoke(envStub, "getUserList", inDoc);

			log.debug("The output is:" + SCXmlUtil.getString(outDoc));

			envStub.clearApiTemplate("getUserList");



		} catch (Exception e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}



		if(!YFCObject.isVoid(outDoc)){

			if (YFCLogUtil.isDebugEnabled()) {

				log.debug("Output of getUserList: "+ SCXmlUtil.getString(outDoc));

			}





			// Retrieving the TotalNumberOfRecords to check if the user is a store user or not.

			String totalNumOfRecords = outDoc.getDocumentElement().getAttribute(KohlsConstant.ATTR_TOT_NO_RECORDS);

			if (YFCLogUtil.isDebugEnabled()) {

				log.debug("totalNumOfRecords: " + totalNumOfRecords);

			}

			int iNumOfRecords = Integer.parseInt(totalNumOfRecords);



			if(iNumOfRecords == totalNumberOfRec){

				isValidStoreUserID = false;	

				log.debug("After Validating with the database isValidStoreUserID is:"+isValidStoreUserID);

			} else {

				isValidStoreUserID = true;

				log.debug("After Validating with the database isValidStoreUserID is:"+isValidStoreUserID);

			}

			log.endTimer(this.getClass() + ".isValidStoreUser");

		}

		return isValidStoreUserID;

	}



}