/** 
 * IBM and Sterling Commerce Confidential
 * OCO Source Materials
 * IBM Sterling Call Center and Store
 * (C) Copyright Sterling Commerce, an IBM Company 2008, 2013
 * The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
 */
package com.kohls.security.sso;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.util.StringUtils;

import com.kohls.common.util.AESEncryptionUtil;
import com.sterlingcommerce.ui.web.framework.context.SCUISecurityContext;
import com.yantra.ycp.japi.util.YCPSSOManager;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.ui.backend.IYFSAuthenticateType;

public class KohlsCorpSSOManager implements YCPSSOManager, IYFSAuthenticateType {

	private static YFCLogCategory log = YFCLogCategory.instance(KohlsCorpSSOManager.class.getName());

	private static final String REQUESTHEADER_STORE_ID = "X-StoreId";
	private static final String REQUESTHEADER_TERMINAL_ID = "X-TerminalId";
	private static final String TIME_STAMP = "timeStamp";
	private static final String CURRENT_USER_ID = "CurrentUserId";
	private static final String REQUEST_ATTR_SSO_COOKIE_UPDATED = "SSOCOOKIEUPDATED";

	private static final String SSO_COOKIE;
	private static final String SSO_COOKIE_DOMAIN;
	private static final String SSO_COOKIE_PATH;
	private static final String SSO_COOKIE_MAX_AGE;
	private static final int SSO_COOKIE_MAXAGE;

	static {
		SSO_COOKIE = defaultIfEmpty(YFSSystem.getProperty("kohls.sso.name"), "KOHLS_SSO_TOKEN");
		SSO_COOKIE_DOMAIN = defaultIfEmpty(YFSSystem.getProperty("kohls.sso.domain"), ".kohls.com");
		SSO_COOKIE_PATH = defaultIfEmpty(YFSSystem.getProperty("kohls.sso.path"), "/");
		SSO_COOKIE_MAX_AGE = defaultIfEmpty(YFSSystem.getProperty("kohls.sso.maxAge"), "600");
		SSO_COOKIE_MAXAGE = Integer.parseInt(SSO_COOKIE_MAX_AGE);
	}

	private static String defaultIfEmpty(String value, String defaultValue) {
		String finalValue = defaultValue;
		if (StringUtils.hasText(value)) {
			finalValue = value;
		}
		return finalValue;
	}

	/**
	 * This method is overridden from the IYFSAuthenticateType interface. This
	 * method determines when authentication through sterling is needed and when
	 * it is needed through SSO.
	 */
	public boolean isPlatformLoginNeeded(HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean loginNeeded = true;

		HttpSession session = request.getSession(Boolean.FALSE);

		if (session != null && session.getAttribute("SCUI_SECURITY_CONTEXT") != null) {
			SCUISecurityContext securityContext = (SCUISecurityContext) session.getAttribute("SCUI_SECURITY_CONTEXT");

			String currentUser = securityContext.getLoginId();

			if (log.isDebugEnabled()) {
				log.debug("current user from session: " + currentUser);
			}
			if (StringUtils.hasText(currentUser) && isValidRequest(request)) {
				if (request.getAttribute(REQUEST_ATTR_SSO_COOKIE_UPDATED) == null) {
					manageSSOCookie(request, response, currentUser);
					request.setAttribute(REQUEST_ATTR_SSO_COOKIE_UPDATED, "true");
				}
				loginNeeded = false;
			}

		} else {
			if (isValidRequest(request) && getSSOCookie(request) != null) {
				if (log.isDebugEnabled()) {
					log.debug("SSO cookie exist in request");
				}
				loginNeeded = false;
			}

		}

		return loginNeeded;
	}

	/**
	 * Add SSO_COOKIE to httpResponse with storeId, terminalId, currentUserId
	 * and currentTimestamp
	 * 
	 * @param request
	 * @param response
	 * @param currentUser
	 * @throws Exception
	 */
	private void manageSSOCookie(HttpServletRequest request, HttpServletResponse response, String currentUser)
			throws Exception {

		Cookie ssoCookie = getSSOCookie(request);
		if (ssoCookie != null) {
			String decryptedString = "";
			try {
				decryptedString = AESEncryptionUtil.decrypt(ssoCookie.getValue());

				String[] cookieParams = StringUtils.delimitedListToStringArray(decryptedString, "|");
				if (!isMalformedCookie(cookieParams)) {

					String timestampFromCookie = getCookieParamValue(cookieParams[3]);
					if (!isCookieExpired(timestampFromCookie)) {
						if (log.isDebugEnabled()) {
							log.debug("SSO Cookie is not expired.");
						}
					} else {
						if (log.isDebugEnabled()) {
							log.debug("SSO Cookie is expired. Renewing sso cookie: " + SSO_COOKIE);
						}
						addSSOCookie(request, response, currentUser);
					}
				} else {
					log.error("could not update SSO cookie. SSO cookie is malformed." + decryptedString);
				}
			} catch (Exception ex) {
				// printing exception and continuing
				log.error("could not update sso cookie " + ssoCookie.getValue(), ex);
			}

		} else {
			if (log.isDebugEnabled()) {
				log.debug(" Adding sso cookie " + SSO_COOKIE);
			}
			addSSOCookie(request, response, currentUser);
			if (log.isDebugEnabled()) {
				log.debug(" sso cookie added " + SSO_COOKIE);
			}
		}
	}

	private void addSSOCookie(HttpServletRequest request, HttpServletResponse response, String currentUser)
			throws Exception {
		String storeID = request.getHeader(REQUESTHEADER_STORE_ID);
		String terminalID = request.getHeader(REQUESTHEADER_TERMINAL_ID);

		StringBuilder ssoCookieValue = new StringBuilder();
		ssoCookieValue.append(REQUESTHEADER_STORE_ID).append(":").append(storeID).append("|");
		ssoCookieValue.append(REQUESTHEADER_TERMINAL_ID).append(":").append(terminalID).append("|");
		ssoCookieValue.append(CURRENT_USER_ID).append(":").append(currentUser).append("|");
		ssoCookieValue.append(TIME_STAMP).append(":").append(System.currentTimeMillis());

		if (log.isDebugEnabled()) {
			log.debug(" before encrypt : " + ssoCookieValue);
		}

		try {
			String encryptedString = AESEncryptionUtil.encrypt(ssoCookieValue.toString());

			if (log.isDebugEnabled()) {
				log.debug(" after encrypt : " + encryptedString);
			}

			Cookie ssoCookie = new Cookie(SSO_COOKIE, encryptedString);
			ssoCookie.setMaxAge(SSO_COOKIE_MAXAGE);
			ssoCookie.setDomain(SSO_COOKIE_DOMAIN);
			ssoCookie.setPath(SSO_COOKIE_PATH);
			ssoCookie.setSecure(true);
			response.addCookie(ssoCookie);
		} catch (Exception ex) {
			// printing exception and continuing
			log.error("could not encrypt sso cookie " + ssoCookieValue, ex);
		}

	}

	/**
	 * Checks whether httpRequest has SSO_COOKIE
	 * 
	 * @param request
	 * @return true if SSO_COOKIE is present
	 */
	private Cookie getSSOCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();

		if (cookies != null && cookies.length > 0) {
			for (Cookie cookie : cookies) {
				if (SSO_COOKIE.equals(cookie.getName())) {
					return cookie;
				}
			}
		}
		if (log.isDebugEnabled()) {
			log.debug("No cookies found in request");
		}
		return null;
	}

	/**
	 * Validate the cookie creation time with the configured max age value.
	 * 
	 * @param timeStamp
	 * @return Return true, if cookie is invalid else false.
	 */
	private boolean isCookieExpired(String timeStamp) {
		boolean isCookieExpired = true;
		if (StringUtils.hasText(timeStamp)) {
			long cookieGenTimeInMsec;
			try {
				cookieGenTimeInMsec = Long.valueOf(timeStamp).longValue();
			} catch (NumberFormatException nfe) {
				log.error("Error converting cookie timestamp value to long " + timeStamp + ". " + nfe.getMessage());
				cookieGenTimeInMsec = System.currentTimeMillis() - 999999999;
			}

			long currentTimeinMSec = System.currentTimeMillis();

			long diffInMillies = currentTimeinMSec - cookieGenTimeInMsec;

			long inSeconds = Math.abs(diffInMillies / 1000);

			if (inSeconds < SSO_COOKIE_MAXAGE) {
				isCookieExpired = false;
			}

		}
		return isCookieExpired;
	}

	/**
	 * This method is invoked every time authentication is required outside of
	 * platform based on the above method. This will is used to verify the
	 * session id. sessionId=<.kohls.com session id>
	 */
	public String getUserData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession(Boolean.FALSE);
		String user = null;

		if (session != null) {
			SCUISecurityContext securityContext = (SCUISecurityContext) session.getAttribute("SCUI_SECURITY_CONTEXT");

			if (securityContext != null) {
				user = securityContext.getLoginId();
				if (log.isDebugEnabled()) {
					log.debug("getUserData() getting user from session: " + user);
				}
				return user;
			}

		}
		if (isValidRequest(request)) {

			Cookie cookie = getSSOCookie(request);
			if (cookie != null) {
				user = getUserFromSSOCookie(request, response, cookie);
				if (log.isDebugEnabled()) {
					log.debug("getUserData() getting user from cookie: " + user);
				}
			}
		}

		return user;
	}

	/**
	 * If the cookie is valid, return the user id.
	 * 
	 * @param response
	 * @param storeID
	 * @param terminalID
	 * @param currentUser
	 * @param cookie
	 * @return
	 * @throws Exception
	 */
	private String getUserFromSSOCookie(HttpServletRequest request, HttpServletResponse response, Cookie cookie)
			throws Exception {

		String storeID = request.getHeader(REQUESTHEADER_STORE_ID);
		String terminalID = request.getHeader(REQUESTHEADER_TERMINAL_ID);
		String userFromCookie = null;
		String decryptedString = AESEncryptionUtil.decrypt(cookie.getValue());

		String[] cookieParams = StringUtils.delimitedListToStringArray(decryptedString, "|");

		if (isMalformedCookie(cookieParams)) {
			log.error("could not retrieve user from SSO cookie. SSO cookie is malformed." + decryptedString);

		} else {

			String storeIdFromCookie = getCookieParamValue(cookieParams[0]);
			String terminalIdFromCookie = getCookieParamValue(cookieParams[1]);
			String userIdFromCookie = getCookieParamValue(cookieParams[2]);
			String timestampFromCookie = getCookieParamValue(cookieParams[3]);

			if (isCookieExpired(timestampFromCookie)) {
				Cookie newCookie = new Cookie(SSO_COOKIE, "");
				newCookie.setPath(SSO_COOKIE_PATH);
				newCookie.setSecure(true);
				newCookie.setDomain(SSO_COOKIE_DOMAIN);
				newCookie.setMaxAge(0);
				response.addCookie(newCookie);
				log.error("could not retrieve user from SSO cookie. SSO cookie is expired. " + timestampFromCookie);

			} else if (storeIdFromCookie.equals(storeID) && terminalIdFromCookie.equals(terminalID)) {
				if (log.isDebugEnabled()) {
					log.debug(" getUserFromSSOCookie(): userIdFromCookie :- " + userIdFromCookie);
				}
				userFromCookie = userIdFromCookie;

			} else {
				log.error("request params " + storeID + ", " + terminalID + " did not match with cookie params "
						+ storeIdFromCookie + ", " + terminalIdFromCookie);
			}
		}

		return userFromCookie;
	}

	private boolean isMalformedCookie(String[] cookieParams) {
		return (cookieParams == null || cookieParams.length != 4);
	}

	private String getCookieParamValue(String cookieParam) {
		String paramValue = cookieParam.substring(cookieParam.indexOf(":") + 1, cookieParam.length());
		return paramValue;
	}

	private boolean isValidRequest(HttpServletRequest request) {
		return StringUtils.hasText(request.getHeader(REQUESTHEADER_STORE_ID))
				&& StringUtils.hasText(request.getHeader(REQUESTHEADER_TERMINAL_ID));
	}

}
