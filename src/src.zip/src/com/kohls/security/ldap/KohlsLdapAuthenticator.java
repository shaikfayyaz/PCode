package com.kohls.security.ldap;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.wsc.core.auth.KohlsWSCRequestValidator;
import com.yantra.interop.client.SystemEnv;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.ycp.YCPErrorCodes;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.util.YFSAuthenticator;

public class KohlsLdapAuthenticator implements YFSAuthenticator {

	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsLdapAuthenticator.class.getName());

	public Map authenticate(String sLoginID, String sPassword) throws Exception {


		log.debug("Inside method : authenticate()");
		log.debug("****************** Entered KohlsLdapAuthenticator - authenticate method ********************");
		log.debug("***** Login *********      " + sLoginID);

		
		/**
		 * Validate whether the user is a web-service consumer or not. If
		 * web-service consumer, then by-pass LDAP authentication and pass on
		 * the control to WS handler for authenticating the user by Sterling OMS
		 * internally
		 * 
		 */
		
		//LDAP Prod Issue - 10/22 - Start
		
		/*CharSequence uniquePasswordIdentifier = KohlsXMLLiterals.$$_UNIQUE_PASSWORD;
		boolean flag = sPassword.contains(uniquePasswordIdentifier);		
		System.out.println(" Will I bypass LDAP authentication for webservice user --- "+flag);*/
		
		boolean flag = false;	
		
		String path = YFSSystem.getProperty(KohlsConstant.AUTHENTICATE_PROPERTY_FILE_PATH);	
		log.debug("path "+path);
		
		 if(!YFCCommon.isVoid(path))
		 {
			 
			try{
			    Path filePath = Paths.get(path);
			    //Read the file only if it is configured for & present
			    
			   if(Files.exists(filePath)) {
					Properties props = new Properties();
						InputStream input = new FileInputStream(path);
			            props.load(input);
			            log.debug("Webservice users are "+props.getProperty(KohlsConstant.WSUSERS_PROPERTY));
			            
			            String[] users = props.getProperty(KohlsConstant.WSUSERS_PROPERTY).split(",");
			            for (String user : users) 
			    		{
			            	log.debug("Webservice user is " + user);
			            	if(sLoginID.equalsIgnoreCase(user))
							{
			            		flag = true;
			            		log.debug("flag is:"+flag);
							}
			    		}
			  }
		    else
		    {
		    		log.error("Enhanced Signon logger: LDAP - Error while reading authenticate.properties file ---> File not configured or doesn't exist");
		    }
	        }
	        catch(Exception e){
	        	log.error("Enhanced Signon logger: LDAP - In catch block - Error while reading authenticate.properties file ---> " + e.getMessage());
				
	        }
		 }
		
		log.debug("after webservice user validation:"+flag);
		//log.debug("after webservice user validation:"+sPassword);
		
		//LDAP Prod Issue - 10/22 - End
		
		// for SSO
		if (sPassword.startsWith(KohlsConstant.JWT_PARAMETER)) {
			// ignore the Jwt in front of the password
			flag = KohlsWSCRequestValidator.revalidateToken(sPassword.substring(3));
			log.debug("after device user validation:"+flag);
		}
		
		if (flag) {
			System.out.println("Now bypassing ldap authentication for webservice user ");
			log.debug("*******  Authenticated for WS users **************    ");
			return null;
		}
		
		String ldapFactory = YFSSystem.getProperty("yfs.security.ldap.factory");
		log.debug("*********ldap factory property obtained" + ldapFactory);
		String adminUserDN = YFSSystem.getProperty("yfs.security.ldap.defaultuserdn");
		String adminUserCredentials = YFSSystem.getProperty("yfs.security.ldap.defaultuserpwd");
		String securityProtocol = YFSSystem.getProperty("yfs.security.ldap.protocol");
		
		log.debug("*******  ldapFactory **************" + ldapFactory);
		log.debug("*******  adminUserDN **************" + adminUserDN);
		log.debug("*******  security protocol **************" + securityProtocol);
		
		YFSException yfe = new YFSException();
		String ldapURL = YFSSystem.getProperty("yfs.security.ldap.url");
		
		log.debug("*******  ldapURL **************    " + ldapURL);
		
		// if any of the ldap params are not set, throw exception
		if (YFCObject.isVoid(ldapURL) || YFCObject.isVoid(ldapFactory)) {
			YFCException ex = new YFCException(
					YCPErrorCodes.YCP_INVALID_LDAP_AUTHENTICATOR_CONFIGURATION);
			//ex.setAttribute("yfs.yfs.security.ldap.factory", ldapFactory);
			//ex.setAttribute("yfs.yfs.security.ldap.url", ldapURL);
			log.debug("*******  if any of the ldap params are not set, throw exception **************    ");
			throw ex;
		} else {
			log.debug("********ldap params are set hence no exception so continue **********************");
			log.debug("*******ldapFactory***********" +ldapFactory);
			log.debug("********ldapURL*************" +ldapURL);
			log.debug("********adminUserDN**************" +adminUserDN);
			log.debug("********adminUserCredentials********" +adminUserCredentials);
			Hashtable env = new Hashtable();
			env.put(Context.INITIAL_CONTEXT_FACTORY, ldapFactory);
			env.put(Context.SECURITY_AUTHENTICATION, YFSSystem.getProperty("yfs.security.ldap.auth"));
			env.put(Context.PROVIDER_URL, ldapURL);
			env.put(Context.SECURITY_PRINCIPAL, adminUserDN);
			env.put(Context.SECURITY_CREDENTIALS, adminUserCredentials);
			if(!YFCObject.isNull(securityProtocol)){
				env.put(Context.SECURITY_PROTOCOL, securityProtocol);
			}
			//MAD-582 - start
			String strLdapTimeoutProperty = YFSSystem.getProperty("yfs.security.ldap.timeout.property");
			if (log.isDebugEnabled()){
				log.debug("ldap timeout property::::" + strLdapTimeoutProperty);
			}
			if(!YFCObject.isNull(strLdapTimeoutProperty)){
				String strLdapTimeout = YFSSystem.getProperty("yfs.security.ldap.timeout");
				env.put(strLdapTimeoutProperty, strLdapTimeout);
				if (log.isDebugEnabled()){
					log.debug("ldap timeout vlaue::::" + YFSSystem.getProperty("yfs.security.ldap.timeout"));
				}
			}
			//MAD-582 - end

			log.debug("LDAP URL: " + ldapURL);
			
			DirContext ctx = null;
			DirContext userCtx = null;
			log.debug("**********************set the context now ******************");

			try {
				// Create the initial context for admin binding
				log.debug("*******  Creating initial context  **************    ");
				ctx = new InitialDirContext(env);
				//log.info(">>>>>>>>>>"
				//		+ (ctx.getEnvironment().get(Context.PROVIDER_URL))
				//				.toString());
				SearchControls ctls = new SearchControls();
				ctls.setSearchScope(ctls.SUBTREE_SCOPE);
				
				log.debug("Admin App Authentication Success");

				NamingEnumeration results = ctx.search("", "uid=" + sLoginID,
						ctls);
				log.debug("********************** post results ********************");

				if (!(results.hasMoreElements())) {
					log.debug("*******  no results  obtained **************    ");
					log.debug("Invalid Credential");
					yfe.setErrorCode("LDAP_002");
					yfe.setErrorDescription("Unable to find user: " + sLoginID
							+ " in LDAP directory");
					throw yfe;

				} else {
					log.debug("*******  results obtained, hence proceed **************    ");
					// Get fully qualified "dn" for the logged in user
					log.debug("UserID: " + sLoginID);
					SearchResult sr = (SearchResult) results.next();
					String userDN = sr.getName();
					log.debug("User DN is:" + userDN);
					// Do User Bind using users "dn"
					Hashtable userBindEnv = new Hashtable();
					userBindEnv.put(Context.INITIAL_CONTEXT_FACTORY,
							ldapFactory);
					userBindEnv.put(Context.SECURITY_AUTHENTICATION, YFSSystem.getProperty("yfs.security.ldap.auth"));
					userBindEnv.put(Context.PROVIDER_URL, ldapURL);
					userBindEnv.put(Context.SECURITY_PRINCIPAL, userDN);
					userBindEnv.put(Context.SECURITY_CREDENTIALS, sPassword);
					if(!YFCObject.isNull(securityProtocol)){
						userBindEnv.put(Context.SECURITY_PROTOCOL, securityProtocol);
					}
					// Create the initial context for User bind.
					userCtx = new InitialDirContext(userBindEnv);
					log.debug("Enhanced Signon logger: LDAP - User Bind Successful "+sLoginID);
				}
			} catch (Exception e  ) {
				Throwable tmp = e;
				// if LDAP server is down, authenticate locally -- start
				if(tmp != null){
					if (tmp.getCause() instanceof java.net.ConnectException ||
							tmp.getCause() instanceof java.io.IOException
							|| tmp.getCause() instanceof java.net.SocketTimeoutException
							||  tmp.getCause() instanceof java.net.NoRouteToHostException 
					   		|| tmp.getCause() instanceof java.net.UnknownHostException) {
						log.error("Connectivity issue with LDAP and the cause is ---> "+tmp.getCause());
						log.error("falling back to OMSd DB for the user "+sLoginID);
						Document doc = XMLUtil.createDocument("YFSEnvironment");
						Element elem = doc.getDocumentElement();
						elem.setAttribute("userId", "admin");
						elem.setAttribute("progId", "loginAuthenticator");
						YIFApi api = YIFClientFactory.getInstance().getApi();
						
						YFSEnvironment yfsEnv = api.createEnvironment(doc);
						//yfsEnv.setTokenID(KohlsConstant.HUNDRED_INT);
					    ((SystemEnv)yfsEnv).setUserTokenIgnored(true);
						Document docOutTemp = XMLUtil.getDocument("<UserList><User DisplayUserID='' Loginid=''/></UserList>");
						yfsEnv.setApiTemplate(KohlsConstant.API_GET_USER_LIST, docOutTemp);
						Document docGetUserInput = XMLUtil.getDocument("<User Loginid='"+sLoginID+"'/>");
						Document docGetUserListOutput = null;
						String loginId=null;
						try{
							docGetUserListOutput = api.getUserList(yfsEnv, docGetUserInput);
							loginId = XPathUtil.getString(docGetUserListOutput.getDocumentElement(), "/UserList/User/@Loginid");
							
						}catch(Exception eYFS) {
							log.error("Enhanced Signon logger: LDAP - Unable to fetch the user list from OMS"+sLoginID);
							throw new YFCException(eYFS,"OMS_USERFETCHFAILED"+eYFS.getMessage());
						}
						yfsEnv.clearApiTemplate(KohlsConstant.API_GET_USER_LIST);

						if(YFCCommon.isVoid(loginId)) {
							log.error("Enhanced Signon logger: LDAP - No record found in OMS DB for the user "+sLoginID);
							throw new YFCException("OMS_NOUSERFOUND", "No record found in OMS DB for the user "+sLoginID);
						}
						/*else
						{
							try{
								log.debug("loginId from API: " +loginId);
								// commenting out this call as we don't want to update anything related to master table as part of application calls. 
								// Entity change process may kick in and affect this one
								//Document docInUserHeirarchy = XMLUtil.getDocument("<User Longdesc='LDAP_OFFLINE' Loginid='"+sLoginID+"'/>");
								//api.modifyUserHierarchy(yfsEnv, docInUserHeirarchy);
							}catch(Exception eYFS) {
								log.error("Enhanced Signon logger: LDAP - Unable to update the user list in OMS"+sLoginID);
								throw new YFCException(e,"OMS_USERUPDATEFAILED"
										+ eYFS.getMessage());
							}
						} **/
						api.releaseEnvironment(yfsEnv);
						log.debug("Enhanced Signon logger: LDAP - User Bind Successful via OMS fallback");
					}
					else {												
						String errorMessage = e.getMessage();
						if(!YFCCommon.isVoid(errorMessage) && 
								errorMessage.contains("LDAP_002"))
						{
							log.error("Enhanced Signon logger: LDAP - User not found "+sLoginID);
							throw new YFCException(e,"LDAP_NOUSERFOUND",
									"Unable to find user: " + sLoginID
									+ " in LDAP directory");
						}
						else
						{
							log.error("Enhanced Signon logger: LDAP - Other functional error "+sLoginID);
							throw new YFCException(e,"LDAP_OTHERERROR",e.getMessage());
						}
						
					}
				}
			} finally {
				if (ctx != null) {
					log.debug("ctx not null");
					ctx.close();
				}
				if (userCtx != null) {
					log.debug("userctx not null");
					userCtx.close();
				}
			}
		}
		log.debug("*******  Authenticated **************    ");
		return null;
	
	}
}
