package com.kohls.security.ldap;

import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.util.YFSAuthenticator;

import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;


public class KohlsISSADAuthenticator implements YFSAuthenticator {
  private String domain;
	private String ldapHostBackup;
	private String ldapHostPrimary;
	private String isAuthFailADSwitchEnabled;

  private static final YFCLogCategory log =
      YFCLogCategory.instance(KohlsISSADAuthenticator.class.getName());
  private static int iMaxPassAge = 0;
	private static String TK_ID = "tk";
	private static String PWD_LAST_SET = "pwdLastSet";
	private static String USER_NAME = "username";

  /**
   * 
   */
  public KohlsISSADAuthenticator() {
    log.beginTimer("KohlsISSADAuthenticator.KohlsISSADAuthenticator");
		this.domain = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_DOMAIN);
		if (ServerTypeHelper.amIOnEdgeServer()) {
			this.isAuthFailADSwitchEnabled = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_CREDENTIALS);
			this.ldapHostBackup = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_URL_BACKUP);
			this.ldapHostPrimary = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_URL_PRIMARY);
			log.debug("*** Domain, ldapHost Primary, Backup hosts and isAuthFailADSwitchEnabled *** " + domain + ", "
					+ ldapHostPrimary + ", " + ldapHostBackup + ", " + isAuthFailADSwitchEnabled);
		} else {
			this.isAuthFailADSwitchEnabled = "Y";
			log.debug("*** Domain and isAuthFailADSwitchEnabled *** " + domain + ", " + isAuthFailADSwitchEnabled);
		}


    log.endTimer("KohlsISSADAuthenticator.KohlsISSADAuthenticator");
  }

  /**
   * @param domain
   * @param host
   */
	public KohlsISSADAuthenticator(String domain, String hostBackup, String hostPrimary, String eLDAPEnabled) {
		log.beginTimer("KohlsISSADAuthenticator.KohlsISSADAuthenticator<String, String,String, String>");
    this.domain = domain;
		this.ldapHostBackup = hostBackup;
		this.ldapHostPrimary = hostPrimary;
		this.isAuthFailADSwitchEnabled = eLDAPEnabled;
		log.debug("*** ldapHost Primary, Backup hosts and isAuthFailADSwitchEnabled *** " + domain + ", " + hostBackup
				+ ", " + hostPrimary + "," + eLDAPEnabled);
		log.endTimer("KohlsISSADAuthenticator.KohlsISSADAuthenticator<String, String,String, String>");
  }


  /*
   * (non-Javadoc)
   * 
   * @see com.yantra.yfs.japi.util.YFSAuthenticator#authenticate(java.lang.String, java.lang.String)
   */
	public Map authenticate(String user, String pass) throws Exception {
		log.beginTimer("KohlsISSADAuthenticator.authenticate");
		Map<String, String> mapOut = null;
		Hashtable<String, String> env = new Hashtable<String, String>();

		env.put(Context.INITIAL_CONTEXT_FACTORY, YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_FACTORY));
		env.put(Context.SECURITY_AUTHENTICATION, YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_AUTH));
		env.put(Context.SECURITY_PRINCIPAL, user + "@" + domain);
		env.put(Context.SECURITY_CREDENTIALS, pass);
		// MAD-582 - start
		String strLdapTimeoutProperty = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_LDAP_TIMEOUT);
		if (log.isDebugEnabled()) {
			log.debug("ldap user and timeout property ::::" + user + ", " + strLdapTimeoutProperty);
		}
		if (!YFCObject.isNull(strLdapTimeoutProperty)) {
			String strLdapTimeout = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_TIMEOUT);
			env.put(strLdapTimeoutProperty, strLdapTimeout);
			if (log.isDebugEnabled()) {
				log.debug("ldap timeout value::::" + strLdapTimeout);
			}
		}
    // MAD-582 - end

		// LdapContext ctxGC = null;
		DirContext ctxGC = null;
		String userStartWithTK = KohlsPOCConstant.NO;
		try {
			// Checking for TKID and auth on CP domain
			if (user.toLowerCase().startsWith(TK_ID)) {
				userStartWithTK = KohlsPOCConstant.YES;
				inStoreContextForTKID(env, user);
				return null;
			} 
			else if (ServerTypeHelper.amIOnEdgeServer()) {
				ctxGC = inStoreContext(ctxGC, env, user);
			} else {
				// this is corp only auth property
				env.put(Context.PROVIDER_URL, YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_URL));
				log.debug("Context initiated with corp primary " + env.get(Context.PROVIDER_URL));
				ctxGC = new InitialDirContext(env);
			}
			log.debug("******* LdapContext ******* " + ctxGC);
			if (userStartWithTK.equals(KohlsPOCConstant.NO)) {
				// Create the search controls
				SearchControls searchCtls = new SearchControls();
				// Specify the attributes to return

				String returnedAtts[] = { PWD_LAST_SET };
				searchCtls.setReturningAttributes(returnedAtts);

				// Specify the search scope
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

				// specify the LDAP search filter
				String searchFilter = getFilter(user, USER_NAME);

				String searchBase = getDomainBase(domain);

				// Search for objects using the filter
				NamingEnumeration result = ctxGC.search(searchBase, searchFilter, searchCtls);

				if (result.hasMore()) {
					SearchResult rs = (SearchResult) result.next();
					Attributes attrs = rs.getAttributes();
					String temp = attrs.get(PWD_LAST_SET).toString();
					log.debug("PasswordLastSet : " + temp.substring(temp.indexOf(":") + 1) + "\n\n");
					Date sConvertedDate = fileTime2timestamp((temp.substring(temp.indexOf(":") + 1)).trim());
					log.debug("Converted Date is : " + sConvertedDate);
					String maxPwdAge = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_MAX_PWDAGE);
					if (YFCCommon.isVoid(maxPwdAge)) {
						maxPwdAge = "90";
					}
					String notificationDays = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_PWD_EXP_DAYS);
					if (YFCCommon.isVoid(notificationDays)) {
						notificationDays = "10";
					}
					int iDiffDate = (int) TimeUnit.DAYS.convert(new Date().getTime() - sConvertedDate.getTime(),
							TimeUnit.MILLISECONDS);
					if ((Integer.parseInt(maxPwdAge) - iDiffDate) <= Integer.parseInt(notificationDays)) {
						mapOut = new HashMap<String, String>();
						mapOut.put("ExpiresInDays", String.valueOf((Integer.parseInt(maxPwdAge) - iDiffDate)));
						mapOut.put("DaysUntilExpiration", String.valueOf((Integer.parseInt(maxPwdAge) - iDiffDate)));
						log.debug("Password will expire in " + (Integer.parseInt(maxPwdAge) - iDiffDate) + " days");
					}
				}
			}
		} catch (AuthenticationException ae) {
			log.error("Authentication Failed due to incorrect user id / password / domain for user " + user, ae);
			if (userStartWithTK.equals(KohlsPOCConstant.NO)) {
				String sErrorCode = ae.getMessage();
				if (sErrorCode.contains("data 52e")) {
					if (KohlsPOCConstant.YES.equalsIgnoreCase(isAuthFailADSwitchEnabled)) {
						log.error("Enhanced Signon logger: AD - Issue with credentials. falling back to LDAP");
						return fallbackAuthenticate(user, pass);
					} else {
						throw new YFSException("Auth failed due to incorrect user id / password / domain");
					}
				} else if (sErrorCode.contains("data 701") || sErrorCode.contains("data 532")) {
					mapOut = new HashMap<String, String>();
					mapOut.put("ExpiresInDays", "0");
					mapOut.put("DaysUntilExpiration", "0");
				} else {
					log.error("Enhanced Signon logger: AD - Issue with credentials. falling back to LDAP");
					return fallbackAuthenticate(user, pass);
				}
			} else {
				log.error("Enhanced Signon logger: CP - Issue with tkid credentials. falling back to LDAP");
				return fallbackAuthenticate(user, pass);
			}
		} catch (Exception e) {
			log.error("Enhanced AD Signon logger: AD - System error. falling back to LDAP ", e);

			return fallbackAuthenticate(user, pass);
		} finally {
			if (ctxGC != null) {
				log.debug("******** Initial LDAP Context not null ********");
				ctxGC.close();
			}
		}
		return mapOut;
  }


  /**
   * Create By *
   * 
   * @param user
   * @param pass
   * @return
   * @throws Exception
   */
  protected Map fallbackAuthenticate(String user, String pass) throws Exception {
    log.beginTimer("KohlsISSADAuthenticator.fallbackAuthenticate");
		String fallBackFlag = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_FALLBACK);
    log.debug("******* Fallback flag ******* " + fallBackFlag);

		String fallBackAuthClass = YFSSystem.getProperty(KohlsPOCConstant.SECURITY_AD_FALLBACKAUTH);
    log.debug("******* Fallback flag Authenticator class ******* " + fallBackAuthClass);

    if (fallBackFlag != null && fallBackFlag.trim().equalsIgnoreCase("TRUE")
        && fallBackAuthClass != null) {
      log.debug(
          "******* Fallback flag is TRUE & Fallback Authenticator class is available ******* ");
      Class<?> fallBackClass = Class.forName(fallBackAuthClass);
      KohlsLdapAuthenticator fallBackLdapAuthenticator =
          (KohlsLdapAuthenticator) fallBackClass.newInstance();

      log.endTimer("KohlsISSADAuthenticator.fallbackAuthenticate");
      return fallBackLdapAuthenticator.authenticate(user, pass);
    }

    log.endTimer("KohlsISSADAuthenticator.fallbackAuthenticate");
    throw new YFSException("Fallback information is not set ");

  }

  /**
   * Create By mrjoshi *
   * 
   * @param s
   * @return
   */
  public static Date fileTime2timestamp(String s) {
    log.beginTimer("KohlsISSADAuthenticator.fileTime2timestamp");
    long pwdSetDate = Long.parseLong(s);
    long timeAdjust = 11644473600000L; // adjust factor for converting it to java
    Date pwdSet = new Date(pwdSetDate / 10000 - timeAdjust); //
    log.endTimer("KohlsISSADAuthenticator.fileTime2timestamp");
    return pwdSet;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param searchValue
   * @param searchBy
   * @return
   */
  private String getFilter(String searchValue, String searchBy) {
    log.beginTimer("KohlsISSADAuthenticator.getFilter");
    String filter = "(&((&(objectCategory=Person)(objectClass=User)))";
    if (searchBy.equals("email")) {
      filter += "(mail=" + searchValue + "))";
    } else if (searchBy.equals("username")) {
      filter += "(samaccountname=" + searchValue + "))";
    }
    log.endTimer("KohlsISSADAuthenticator.getFilter");
    return filter;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param base
   * @return
   */
  private String getDomainBase(String base) {
    log.beginTimer("KohlsISSADAuthenticator.getDomainBase");
    char[] namePair = base.toUpperCase().toCharArray();
    String dn = "DC=";
    for (int i = 0; i < namePair.length; i++) {
      if (namePair[i] == '.') {
        dn += ",DC=" + namePair[++i];
      } else {
        dn += namePair[i];
      }
    }
    log.endTimer("KohlsISSADAuthenticator.getDomainBase");
    return dn;
  }

	private DirContext inStoreContext(DirContext ctxGC, Hashtable<String, String> env, String user) throws Exception {
		try {
			// Set the ISS ldap properties, primary as O-Server and back up as st.kohls.com
			env.put(Context.PROVIDER_URL, ldapHostPrimary);
			log.debug("Context url setup with primary host " + env.get(Context.PROVIDER_URL));
			ctxGC = new InitialDirContext(env);
		} catch (AuthenticationException au) {
			log.error("Auth failed - Incorrect user id / password / domain with primary host for user " + user + ", "
					+ env.get(Context.PROVIDER_URL), au);
			String sInValidCredentailsCode = au.getMessage();
			if (sInValidCredentailsCode.contains("data 52e")) {
				if (KohlsPOCConstant.YES.equalsIgnoreCase(isAuthFailADSwitchEnabled)) {
					env.put(Context.PROVIDER_URL, ldapHostBackup); // Env set to backup url st.kohls.com
					log.info("User Authentication failed - Context url setup with backup host "
							+ env.get(Context.PROVIDER_URL));
					ctxGC = new InitialDirContext(env);
				} else {
					// Throw the Auth Invalid Credentials and stop the process
					log.error(
							"Throw the Auth error with invalid Credentials and stop the process, isAuthFailADSwitchEnabled value "
									+ isAuthFailADSwitchEnabled);
					throw au;
				}
			} else {
				env.put(Context.PROVIDER_URL, ldapHostBackup);
				log.info("Auth failed - Context url setup with backup host " + env.get(Context.PROVIDER_URL));
				ctxGC = new InitialDirContext(env);
			}
		} catch (Exception exp) {
			env.put(Context.PROVIDER_URL, ldapHostBackup);
			log.error("After Context url setup with backup host " + env.get(Context.PROVIDER_URL), exp);
			ctxGC = new InitialDirContext(env);
		}
		return ctxGC;
	}

	private DirContext inStoreContextForTKID(Hashtable<String, String> env, String user) throws Exception {
		env.put(Context.SECURITY_PRINCIPAL, user + "@" + YFSSystem.getProperty(KohlsPOCConstant.SECURITY_TK_AD_DOMAIN));
		env.put(Context.PROVIDER_URL, YFSSystem.getProperty(KohlsPOCConstant.SECURITY_TK_AD_URL));
		log.debug("Context url setup with cp host " + env.get(Context.PROVIDER_URL));
		return new InitialDirContext(env);
	}
}
