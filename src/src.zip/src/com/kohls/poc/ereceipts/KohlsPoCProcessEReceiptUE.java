package com.kohls.poc.ereceipts;
import org.w3c.dom.Document;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.pos.japi.ue.order.POSProcessElectronicReceiptUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

public class KohlsPoCProcessEReceiptUE extends KOHLSBaseApi implements POSProcessElectronicReceiptUE {
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCProcessEReceiptUE.class);
	@Override
	public Document processElectronicReceipt(YFSEnvironment env, Document inDoc)
			throws YFSUserExitException {
		
		
		if(logger.isVerboseEnabled()){
			logger.verbose("***Started Verbose for KohlsPoCProcessEReceiptUE****");
			logger.verbose(XMLUtil.getXMLString(inDoc));
		}
		try {


			//changes as part of release 01 -- 2016 --createAsyncRequest-- start
			//Commented as part of release 1 as part of createAsyncRequest api changes
			/*Document outDoc=invokeService(env,"KohlsPoCEReceiptToQ",inDoc);*/

			new KohlsPoCProcessEReceiptAPI().createAsyncRequest(env, inDoc);


			// changes as part of release 01 -- 2016 -- End


		} catch (Exception e) {
			logger.error(e.getStackTrace());
			return inDoc;
		}
		
		if(logger.isVerboseEnabled())
			logger.verbose("***Entered Verbose for KohlsPoCProcessEReceiptUE****");

		return inDoc;
	}

}
