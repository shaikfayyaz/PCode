package com.kohls.poc.ereceipts;


import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.woodstock.util.Base64;
import com.tgcs.tcx.gravity.pos.offline.util.OfflineApiHelper;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;

public class KohlsPoCProcessEReceiptAPI extends KOHLSBaseApi {
	public static final String EMAIL_RESPONSE_SUCCESS="SUCCESS";
	public static final String EMAIL_RESPONSE_FAIL="FAIL";
	public static final String EMAIL_RESPONSE_RETRY="FAIL_RETRY";
	String decodedReceiptData=null;

	private   String storeNo="";
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCProcessEReceiptUE.class);
	private Properties props;
	public Document processEReceipt(YFSEnvironment env,Document inDoc) throws Exception{
		Document outDoc=XMLUtil.createDocument("Order");
		Document outTempDoc=null;
		String status=null;
		int retry=0;
		if(!YFCCommon.isVoid(props.getProperty("Retry")))
			retry=Integer.parseInt(props.getProperty("Retry"));
		String strHeaderKey="";
		try{

			Element eleOrder = inDoc.getDocumentElement();
			decodedReceiptData = decodeReceiptData(eleOrder.getAttribute("ReceiptData"));
			strHeaderKey=eleOrder.getAttribute("OrderHeaderKey");
			Document ordIndoc = XMLUtil.createDocument("Order");

			Document templateDoc=XMLUtil.getDocument("<OrderList><Order OrderHeaderKey='' SellerOrganizationCode=''><Extn ExtnEReceiptEmailID=''/></Order></OrderList>");
			ordIndoc.getDocumentElement().setAttribute("OrderHeaderKey", strHeaderKey);


			//Get the emailID using getOrderList
			Document orListOut=invokeAPI(env,templateDoc,"getOrderList",ordIndoc);
			
			
			if(logger.isVerboseEnabled())
				logger.verbose("getOrderListInput "+XMLUtil.getXMLString(orListOut));
			
			String storeId = null;
			if (orListOut!=null){
				Element orListElem = orListOut.getDocumentElement();
				if(orListElem!=null){					
					storeId = orListElem.getAttribute("SellerOrganizationCode");
					logger.debug("storeId is "+storeId);
				}
			}


			Document reqDoc=createInputDocForWS(env,orListOut);
			
			
			if(logger.isVerboseEnabled())
				logger.verbose("Input to webservice call "+XMLUtil.getXMLString(reqDoc));
			
			//Make a webservice call using receiptdata
			outTempDoc=invokeService(env,"KohlsPoCSendEmailService",reqDoc);

			
			if(logger.isVerboseEnabled())
				logger.verbose("Output of Webservice call "+XMLUtil.getXMLString(outTempDoc));
			
			status=outTempDoc.getDocumentElement().getAttribute("Status");
			int counter=1;
			//Retry logic for FailedRetry
			while (status.equalsIgnoreCase(EMAIL_RESPONSE_RETRY)){
					throw new YFSException("FailedAsyncAgentDuringRetry");
			}
		} catch (Exception e) {
			 logger.error(e.getMessage()+"for OHK::"+strHeaderKey);
				throw e;
		}

		try{
			
			outDoc=changeOrderInput(env,status,strHeaderKey);
			
		}catch(YFSException ef){
			//Do not throw exception as Email is already sent
			logger.error("KohlsPoCProcessEReceiptAPI.processEReceipt -- ChangeOrder call failed but email sent successfully for OHK::"+strHeaderKey);
		}
			
		return outDoc;

	}
	private Document changeOrderInput(YFSEnvironment env,String statusTemp,String strHeaderKeyTemp) throws Exception{

		Document chgIndoc = XMLUtil.createDocument("Order");
		chgIndoc.getDocumentElement().setAttribute("SelectMethod", "WAIT");
		//CPE-2595 change start
		chgIndoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_OVERRIDE, "Y");
		//CPE-2595 change end
		Element eleExtn=XMLUtil.createChild(chgIndoc.getDocumentElement(), "Extn");

		eleExtn.setAttribute("ExtnEmailEreceiptResp", statusTemp);
		chgIndoc.getDocumentElement().setAttribute("OrderHeaderKey", strHeaderKeyTemp);
		
		if(logger.isVerboseEnabled())
			logger.verbose("ChangeOrder Input xml "+XMLUtil.getXMLString(chgIndoc));
		Document chgoutDoc=invokeAPI(env,chgIndoc,"changeOrder",chgIndoc);
		
		if(logger.isVerboseEnabled())
			logger.verbose("ChangeOrder output xml "+XMLUtil.getXMLString(chgoutDoc));
		return chgoutDoc;

	}
	public Document createInputDocForWS(YFSEnvironment env,Document orListOut) throws Exception{
		Document reqDoc=XMLUtil.createDocument("EmailReceipt");
		storeNo=((Element)orListOut.getElementsByTagName("Order").item(0)).getAttribute("SellerOrganizationCode");
		Element eleHeaderKey = (Element)(XPathUtil.getNodeList(orListOut.getDocumentElement(), "/OrderList/Order/Extn").item(0));
		reqDoc.getDocumentElement().setAttribute("Email", eleHeaderKey.getAttribute("ExtnEReceiptEmailID"));		
		reqDoc.getDocumentElement().setAttribute("ReceiptData",decodedReceiptData);
		return reqDoc;

	}

	protected String decodeReceiptData(String encodedData)
			throws Exception
			{
		byte[] encodedDataBytes = encodedData.getBytes("UTF-8");
		byte[] decodedDataBytes = Base64.decode(encodedDataBytes);

		return new String(decodedDataBytes);
			}
	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		//this.LOG_CAT.debug("In the set properties method");

	}

	//changed access specifier from private to protected as part of release 01 -- 2016 --createAsyncRequest
	protected void createAsyncRequest(YFSEnvironment env, Document docInput) throws Exception
	{
		/* Manoj (06/14) - changes for defect 2607 - Start */
		Element inElem = docInput.getDocumentElement();		
		// Start chnages to get ColonyID 02/20/2014
		String sStoreNo = docInput.getDocumentElement().getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
		if(!YFCCommon.isVoid(sStoreNo)){
			Document getOrganizationListInput = XMLUtil.getDocument("<Organization "
					+ "OrganizationCode=\"" + sStoreNo + "\" ></Organization>");
			Document getOrganizationListTemplate = XMLUtil.getDocument("<OrganizationList><Organization "
					+ "OrganizationName='' AssignedColonyId=''> </Organization></OrganizationList>");

			Document getOrganizationListOutput = invokeAPI(env,getOrganizationListTemplate,"getOrganizationList",getOrganizationListInput);
			String colonyID=((Element)getOrganizationListOutput.getElementsByTagName("Organization").item(0)).getAttribute("AssignedColonyId");
			// End chnages to get ColonyID 02/20/2014
			if(YFCCommon.isVoid(colonyID)){
				throw new YFSException("Blank Colony ID for store "+sStoreNo+" in EReceipt User Exit");
			}
			 if(!ServerTypeHelper.amIOnEdgeServer())
			inElem.setAttribute("ColonyId", colonyID);		
			
			//CPE-4521 - Start
			//invokeAPI(env,"createAsyncRequest",inputDoc);
			invokeService(env,"KohlsPoCStoreEReceiptMsg",docInput);
		} else {
			throw new YFSException("Blank store no in the EReceipt User Exit");
		}
		/* Manoj (06/14) - changes for defect 2607 - End */
	}

}
