/*
*
* Copyright 2016 Kohls All rights reserved.
* This program connects to Kohls Return service through web service 
* 
* Customer specific copyright notice     :Kohls
* 
* File Name       : POCReturnWebServiceCaller.java
*
* Description     :Kohls POC Returns
*
* Version         : 1.0.0.
*
* Created Date    :30-DEC-2016
* 
* Modification History:Modified by, on date.
*/
package com.kohls.poc.returns;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import javax.xml.namespace.QName;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

import org.w3c.dom.Document;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.messaging.v1_0.header.MessageHeaderCreator;
import com.kohls.messaging.v1_0.header.MessageHeaderException;
import com.kohls.messaging.v1_0.header.MessageSenderNodeInfo;
import com.kohls.messaging.v1_0.header.jaxb.MessageHeader;
import com.kohls.messaging.v1_0.header.util.SoapMessageUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * 
 * This program connects to Kohls Return service through web service 
 * This will be invoked through Sterling OMS service 
 * 
 *@version 1.0
 *@author POC Returns Team
 * 
 */
public class POCReturnWebServiceCaller implements YIFCustomApi {

    private YFCLogCategory log = YFCLogCategory.instance(POCReturnWebServiceCaller.class);
    private Properties props;

    /**
     * 
     * @throws Exception exception
     */
    public POCReturnWebServiceCaller() throws Exception {
        super();
    }

    /**
     * This function 1.Prepares the SOAP Request 2.Invokes the webservice endpoint 
     * 3.Returns the SOAP response as a Document
     * 
     *@param env environment variable
     *@param requestDoc request Document
     *@return Document webservice response
     */
    //verified
    public Document invokeWS(YFSEnvironment env, Document requestDoc) {

    	
       log.debug("call to createSoapMessage" + env.getVersion());
        
        SOAPMessage request = this.createSoapRequest(requestDoc);
		this.addHeader(request);
		
        String message = soapMessageToString(request);
      //TODO to remove the below line later
       log.debug("request message " + message);
        if (YFCLogUtil.isDebugEnabled()) {
//        	 String message = soapMessageToString(request);
            log.debug("message before endpoint call:::::::::::::: : " + message);
        }

        // log.debug("Call the end point");
        SOAPMessage response=null;
      response = this.callEndpoint(request);
        
/*		try {
			response = this.callEndpoint2();
		} catch (Exception e1) {
			e1.printStackTrace();
		}*/

        SOAPBody responseBody=null;
        try {
        // log.debug("Get the SoapBody from the response");
         responseBody = response.getSOAPBody();
        
        // log.debug("Check whether the response is having any fault in the body");
	        if (responseBody.hasFault()) {
	            this.logSoapFault(responseBody);
	            if (this.getPropertyValue(this.props.getProperty("appName")).compareToIgnoreCase(
	                    "PAYMENTS") != 0) {
	                        responseBody = this.getFaultformated(responseBody);
	            }     
	        }
	        
	        return responseBody.extractContentAsDocument();
        } catch (SOAPException se) {
        	log.debug("Soap Exception while getting soap body in POCReturnWebServiceCaller " + se.getMessage());
        }

        // log.debug("return the soapbody");
       return null;
    }
    
    /**
     * This function is used for creating a SOAPRequest with requestDoc added to the SOAPBody.
     * 
     *@param requestDoc Input Document using which we need to prepare a SOAPMessage.
     *@return SOAPMessage SOAPMessage
     */
    public SOAPMessage createSoapRequest(Document requestDoc) {

        log.debug("In createSoapMessage method in the ");
      //TODO to remove the below line later
        //System.out.println("In createSoapMessage method in the ");

        //System.setProperty("javax.xml.soap.MessageFactory", "weblogic.xml.saaj.MessageFactoryImpl");

        SOAPMessage request = null;
		try {
			MessageFactory mf = MessageFactory.newInstance();
			request = mf.createMessage();
			
			SOAPPart soapPart = request.getSOAPPart();
			
			String val = SCXmlUtil.getString(requestDoc);
			SOAPEnvelope env = null;
			SOAPElement requestElement = null;
			env = soapPart.getEnvelope();
			
			env.addNamespaceDeclaration(KohlsConstant.REGION_AU, KohlsConstant.KOHLS_URL_AU);
			SOAPBody soapBody = env.getBody();
			SOAPElement processElement = soapBody.addChildElement(KohlsXMLLiterals.E_PROCESS_MESSAGE, KohlsConstant.REGION_AU);
			requestElement = processElement.addChildElement(KohlsXMLLiterals.E_REQUEST, KohlsConstant.REGION_AU);
			
			log.debug("val is ................................." + val);
			  //TODO to remove the below line later
			//System.out.println("val is ................................." + val);
			// val=val.replaceAll("amp;","");
			requestElement.setValue(val);
			return request;
		}
		catch(NullPointerException e){
			log.error("NullPointerException in createSoapRequest of POCReturnWebServiceCaller. Details:"+e.getMessage());
        }
		catch (SOAPException e) {
			log.error("SOAPException in createSoapRequest of POCReturnWebServiceCaller. Details:"+e.getMessage());
		}
		return null;
    }

    /**
     * This function is used for adding Header based on Kohls standards to the SOAPMessage Message.
     * ID and Node ID will be added to the header using the createRequestMessageHeader() function
     * 
     *@param request to which MessageHeader is added
     *@return SOAPMessage soapmessage
     */
    public SOAPMessage addHeader(SOAPMessage request) {

        try {
//            log.debug("In call to addHeader method in webservice");
            //System.out.print("In call to addHeader method in webservice ############");
//            MessageHeaderProcessorImpl headprocessorimpl = new MessageHeaderProcessorImpl();
            MessageHeaderCreator headerCreator = new MessageHeaderCreator();
            MessageSenderNodeInfo msgsendernodeinfo = new MessageSenderNodeInfo();

//            log.debug("Set message header details");
            msgsendernodeinfo.setSystemCode(this.getPropertyValue(this.props
                    .getProperty(KohlsConstant.SYSTEM_CODE)));
            msgsendernodeinfo.setModule(this.getPropertyValue(this.props.getProperty(KohlsConstant.MODULE)));
            msgsendernodeinfo.setAppName(this.getPropertyValue(this.props.getProperty(KohlsConstant.APP_NAME)));

//            log.debug("Set message sender node info");
//            headprocessorimpl.setMessageSenderNodeInfo(msgsendernodeinfo);
            headerCreator.setMessageSenderNodeInfo(msgsendernodeinfo);

            // soapMessage.getMimeHeaders().addHeader("SOAPAction", yfsSoapActionOperation);
//            log.debug("Add SOAPAction");
            MimeHeaders hd = request.getMimeHeaders();
            if (!YFCCommon.isVoid(this.props.getProperty(KohlsConstant.SOAP_ACTION))) {
                hd.addHeader(KohlsConstant.SOAP_ACTION,
                        this.getPropertyValue(this.props.getProperty(KohlsConstant.SOAP_ACTION)));
            }

//            log.debug("call to create Request Message Header");
//            MessageHeader header = headprocessorimpl.createRequestMessageHeader();
            MessageHeader header = headerCreator.createMessageHeader();
            
            
			// Added for PST-443 - Start
         	// Added the Kohls Soap Standard CorrelationID
         	header.setCorrelationID(KohlsPoCCommonAPIUtil.getCorrelationID());
			
			// Added for PST-443 - End
         			
         			
//            log.debug("Add Version");
            if (!YFCCommon.isVoid(this.props.getProperty(KohlsConstant.HDR_VERSION))) {
                header.setVersion(this.getPropertyValue(this.props.getProperty(KohlsConstant.HDR_VERSION)));
            }

//            log.debug("Add Action");
            if (!YFCCommon.isVoid(this.props.getProperty(KohlsConstant.ACTION))) {
                header.setAction(this.getPropertyValue(this.props.getProperty(KohlsConstant.ACTION)));
            }

//            log.debug("Put header to the soap message");
            SoapMessageUtil.putMessageHeader(request, header);
            /*ByteArrayOutputStream out = new ByteArrayOutputStream();
           
            try {
				request.writeTo(out);
			} catch (SOAPException e) {
				log.error("SOAPException in addHeader of POCReturnWebServiceCaller. Details:"+e.getMessage());
			} catch (IOException e) {
				log.error("IOException in addHeader of POCReturnWebServiceCaller. Details:"+e.getMessage());
			}

            if (YFCLogUtil.isDebugEnabled()) {
                log.debug("request after adding header :::::::::::::: : " + out.toString());
            }*/

        } catch (MessageHeaderException e) {
            log.error("MessageHeaderException in the calladdHeader method in the webservice" + e.getMessage());
        }
        return request;

    }


    /**
     * This function is used for calling the endpoint and fetching SOAP Response from it.
     * 
     *@param request  Using which we will call the endpoint
     *@return SOAPMessage soapmessage
     */
    public SOAPMessage callEndpoint(SOAPMessage request) {
        long beginTime = System.currentTimeMillis();
        
    	SOAPConnection connection = null;
    	SOAPMessage response = null;
        try {
            log.debug("In callendpoint method in the webservice");
          //TODO to remove the below line later
            //System.out.println("In callendpoint method in the webservice");
            
            connection = this.createSOAPConnection();
            QName serviceName = new QName(KohlsConstant.STRELING_SERVICES);
            QName portName = new QName(KohlsConstant.PORT_NAME);

            String soapAction = KohlsConstant.BLANK;
            if (!YFCCommon.isVoid(this.getPropertyValue(this.props.getProperty(KohlsConstant.SOAP_ACTION)))) {
                soapAction = this.getPropertyValue(this.props.getProperty(KohlsConstant.SOAP_ACTION));
            }

            // log.debug("the input is :"+soapMessageToString(request));
            Service service = Service.create(serviceName);
            service.addPort(portName, SOAPBinding.SOAP11HTTP_BINDING,
                    this.getPropertyValue(this.props.getProperty(KohlsConstant.END_POINT_URL)));

            Dispatch<SOAPMessage> dispatch = service.createDispatch(portName, SOAPMessage.class,
                    Service.Mode.MESSAGE);
            Map<String, Object> map = dispatch.getRequestContext();

            map.put(BindingProvider.SOAPACTION_USE_PROPERTY, Boolean.TRUE);
            map.put(BindingProvider.SOAPACTION_URI_PROPERTY, soapAction);

            if (!YFCCommon.isVoid(this.getPropertyValue(props.getProperty(KohlsConstant.TIME_OUT)))) {

                map.put("com.sun.xml.ws.connect.timeout",
                        Integer.parseInt(this.getPropertyValue(props.getProperty(KohlsConstant.TIME_OUT))));
                map.put(KohlsConstant.TIME_OUT_PACKAGE,
                        Integer.parseInt(this.getPropertyValue(props.getProperty(KohlsConstant.TIME_OUT))));
            }

            log.debug("###### End point URL is ##### : "
                    + this.getPropertyValue(this.props.getProperty(KohlsConstant.END_POINT_URL)));
            //System.out.println("###### End point URL is ##### : "
             //     + this.getPropertyValue(this.props.getProperty("endPointURL")));
            if (log.isDebugEnabled()) {
                ByteArrayOutputStream req = new ByteArrayOutputStream();
                request.writeTo(req);
                log.debug("###### Request is ##### : " + req.toString());
                req.flush();
            }

            log.beginTimer("Webservice Call");

            response = dispatch.invoke(request);

            log.endTimer("Webservice Call");
            if (log.isDebugEnabled()) {
                ByteArrayOutputStream resp = new ByteArrayOutputStream();
                response.writeTo(resp);
                log.debug("###### response is ##### : "
                        + XMLUtil.getXMLString(XMLUtil.getDocument(resp.toString())));
                resp.flush();
            }

        } catch (Exception e) {

        	log.error("Exception in callEndpoint of POCReturnWebServiceCaller. Details:"+e.getMessage());
//        	e.printStackTrace();

            if (e.getCause() instanceof java.net.ConnectException) {
                throw new YFCException(KohlsConstant.EXTN_CONNECT);
            } else if (e.getCause() instanceof java.io.IOException) {
                throw new YFCException(KohlsConstant.EXTN_IO);
            } else if (e.getCause() instanceof javax.xml.soap.SOAPException
                    || e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
                throw new YFCException(KohlsConstant.SOAP_EXCEPTION);
            } else if(e.getCause() instanceof javax.xml.ws.WebServiceException){
            	throw new YFCException(KohlsConstant.WEB_SERVICE_EXCEPTION);
            }
            else {
                throw new YFCException(KohlsConstant.EXTN_OTHER);
            }
        } finally {
            if (!YFCCommon.isVoid(System.getProperty(KohlsConstant.DEFAULT_READ_TIMEOOUT_PACKAGE))) {
                System.clearProperty(KohlsConstant.DEFAULT_READ_TIMEOOUT_PACKAGE);
            }
            // connection.close();
        }
      	long endTime = System.currentTimeMillis();
      	long responseTime = endTime-beginTime;
      	String endPoint = this.props.getProperty(KohlsConstant.END_POINT_URL);
		
      	log.info("SOAP WebService Enpoint - " + endPoint + " took " + responseTime + " ms");

        return response;
    }

    /**
     * This function is used for creating a SOAPConnection.
     * 
     *@return SOAPConnection connection
     */
    public SOAPConnection createSOAPConnection() {

        System.setProperty("javax.xml.soap.SOAPConnectionFactory",
                "weblogic.wsee.saaj.SOAPConnectionFactoryImpl");
        System.setProperty("sun.net.client.defaultConnectTimeout",
                this.getPropertyValue(this.props.getProperty("timeOut")));
        SOAPConnection connection = null;
        try {
            // log.debug("Create Soap Connection");
            connection = SOAPConnectionFactory.newInstance().createConnection();
        } catch (SOAPException e) {
        	log.error("SOAPException in createSOAPConnection of POCReturnWebServiceCaller. Details:"+e.getMessage());
            // log.debug("SOAPException in the creation of SOAPConnection");
        }

        return connection;
    }

    /**
     * This method handles all soap fault message body.
     * 
     *@param responseBody which contain SAOPFault
     *@return SOAPBody in well formated manner
     */

    public SOAPBody getFaultformated(SOAPBody responseBody) {

        String faultcode = responseBody.getFault().getFaultCode();
        String faultstring = responseBody.getFault().getFaultString();

        String code = null;
        String msg = null;
        Detail soapDetail = responseBody.getFault().getDetail();
        try{
	        if (!YFCCommon.isVoid(soapDetail)) {
	
	            code = XPathUtil.getString(soapDetail, KohlsConstant.CODE);
	
	            msg = XPathUtil.getString(soapDetail, KohlsConstant.MESSAGE);
	
	        }
	
	        if (YFCCommon.isVoid(code)) {
	            code = faultstring;
	        }
	
	        if (YFCCommon.isVoid(msg)) {
	            msg = KohlsConstant.ERROR_DESCRIPTION;
	        }
	
	        System.setProperty(KohlsConstant.MESSAGE_FACTORY_PACKAGE, KohlsConstant.MESSAGE_FACTORY_IMPL_PACKAGE);
	
	        MessageFactory mf = MessageFactory.newInstance();
	        SOAPMessage faultresponse = mf.createMessage();
	        SOAPPart soapPart = faultresponse.getSOAPPart();
	
	        SOAPEnvelope env = soapPart.getEnvelope();
	        SOAPBody soapBody = env.getBody();
	
	        SOAPFault fault = soapBody.addFault();
	
	        fault.addNamespaceDeclaration(KohlsConstant.WRAP_SINGLE_TO_S, KohlsConstant.PATH_SOAP_ENVELOPE);
	        fault.addNamespaceDeclaration(soapBody.getPrefix(),KohlsConstant.PATH_SOAP_ENVELOPE);
	
	        fault.setFaultCode(faultcode);
	        fault.setFaultString(faultstring);
	
	        Detail myDetail = fault.addDetail();
	
	        QName entryName = new QName(KohlsConstant.CODE);
	        DetailEntry entry = myDetail.addDetailEntry(entryName);
	        entry.addTextNode(code);
	
	        QName entryName2 = new QName(KohlsConstant.MESSAGE);
	        DetailEntry entry2 = myDetail.addDetailEntry(entryName2);
	        entry2.addTextNode(msg);
	
	        return faultresponse.getSOAPBody();
        }
        catch(Exception e){
        	log.error("Exception in getFaultformated of POCReturnWebServiceCaller. Details:"+e.getMessage());
        }
        return null;
    }

      /**
     * This public method is used for logging the SOAPFault.
     * 
     *@param responseBody of the response we got from the Soap call
     */
    public void logSoapFault(SOAPBody responseBody) {
        SOAPFault fault = responseBody.getFault();
        String msg = KohlsConstant.MESSAGE_SOAP_FAULT.concat(fault.getFaultCode()).concat(KohlsConstant.MESSAGE_CALLING_END_POINT);
        log.error(msg);
    }

    /**
     * Sets the properties.
     * 
     *@param prop Properties that need to be set
     */

    public void setProperties(Properties prop) {
        try{
        	this.props = prop;
        }
        catch(Exception e){
        	log.error("Exception in setProperties of POCReturnWebServiceCaller. Details:"+e.getMessage());
        }
    }

    /**
     * This function is used to get the value for a property.
     * 
     *@param property name in string format
     *@return String propValue
     */
    public String getPropertyValue(String property) {

        String propValue=null;
        propValue = YFSSystem.getProperty(property);
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        return propValue;

    }

    /**
     *@param message the message
     *@return String
     */
    public String soapMessageToString(SOAPMessage message) {
        String result = null;

        if (message != null) {
            ByteArrayOutputStream baos = null;
            try {
                baos = new ByteArrayOutputStream();
                message.writeTo(baos);
                result = baos.toString();
            }catch (SOAPException e) {
            	log.error("SOAPException in soapMessageToString of POCReturnWebServiceCaller. Details:"+e.getMessage());
			} catch (IOException e) {
				log.error("IOException in soapMessageToString of POCReturnWebServiceCaller. Details:"+e.getMessage());
			} finally {
                if (baos != null) {
                    try {
						baos.close();
					} catch (IOException e) {
						log.error("IOException in soapMessageToString of POCReturnWebServiceCaller. Details:"+e.getMessage());
					}
                    
                }
            }
        }
        return result;
    }
    
    /**
     * This is used for local testing only
     * @return
     * @throws Exception
     */
    private SOAPMessage callEndpoint2() throws Exception {
    	String filename="C:/temp/881154000458OTRresponse.xml";
	    SOAPMessage message = MessageFactory.newInstance().createMessage();
	    SOAPPart soapPart = message.getSOAPPart();
	    soapPart.setContent(new StreamSource(new FileInputStream(filename)));
	    message.saveChanges();
	    return message;
    }

}
