/*
 * 
 * Copyright 2016 Kohls All rights reserved. Parses the Return servce response, merges with the
 * getorder details Customer specific copyright notice :Kohls File Name :
 * KohlsPoCCheckAndMergeOrderWithRSResponse.java
 * 
 * Description :Kohls POC Returns
 * 
 * Version : 1.0.0.
 * 
 * Created Date :30-DEC-2016
 * 
 * Modification History:Modified by, on date.
 */
package com.kohls.poc.returns;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.returns.api.KohlsPoCRKC;
import com.kohls.poc.returns.api.KohlsPoCUpdateOTRResponseToDB;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.nrsc.kohls.receipt.ReceiptUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.receipt.TransactionNumberUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * 
 * @author Kohls POC Team
 * 
 */
public class KohlsPoCCheckAndMergeOrderWithRSResponse implements YIFCustomApi {

  private static final YFCLogCategory log =
      YFCLogCategory.instance(KohlsPoCCheckAndMergeOrderWithRSResponse.class.getName());
  private YIFApi api;
  String sExtnPocFeature = "";
  boolean isPickInvoice = false; 

  /**
   * 
   * @throws YIFClientCreationException exception
   */
  public KohlsPoCCheckAndMergeOrderWithRSResponse() throws YIFClientCreationException {
    api = YIFClientFactory.getInstance().getLocalApi();

  }

  @Override
  public void setProperties(Properties arg0) throws Exception {

  }

  /**
   * 
   * @param env env
   * @param retSvcResponseDoc RS Response
   * @return Document response
   * @throws Exception
   * @throws IOException
   */
  // verified
  public Document parseReturnServiceResponse(YFSEnvironment env, Document retSvcResponseDoc)
      throws IOException, Exception {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.parseReturnServiceResponse");
    Document inXML = (Document) env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
    // commenting this out so we can prevent the null pointer exception
    // later during the
    // KohlsImportPOSOrderForPSA
    // env.setTxnObject(KohlsConstant.GRAVITY_IN_REQ, null);
    Document ordDetDoc = null;
    Document mergedOrderXML = null;
    KohlsPoCUpdateOTRResponseToDB otrResponse = new KohlsPoCUpdateOTRResponseToDB();
    // CAPE-78
    sExtnPocFeature = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.POC_FEATURE);
    //OMNI2 change for passing Clean indicator and OmniBagInd - Begin
    Element eleCleanInd = (Element) retSvcResponseDoc.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0);
    if(!YFCCommon.isVoid(eleCleanInd)) {
    String strCleanInd = eleCleanInd.getTextContent();
    if(!YFCCommon.isVoid(strCleanInd) && "true".equals(strCleanInd)) {
    	inXML.getDocumentElement().setAttribute(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND, "Y");
    	}
    }
    Element eleRootInxml = inXML.getDocumentElement();
    Element eleRetSvcResp = retSvcResponseDoc.getDocumentElement();
    Element eleOmniBagInd = (Element) retSvcResponseDoc.getDocumentElement().getElementsByTagName("OmniBagInd").item(0);
    if(!YFCCommon.isVoid(eleOmniBagInd)) {
    String strOmniBagInd = eleOmniBagInd.getTextContent();
    if(!YFCCommon.isVoid(strOmniBagInd) && "true".equals(strOmniBagInd)) {
    	inXML.getDocumentElement().setAttribute("OmniBagInd", "Y");
    	}
    }
    //OMNI2 change for passing Clean indicator and OmniBagInd - END
    // MJ 03/24 - Skipping getOrderList api call for Price Adjustment
    if (!KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPocFeature)) {
      if (inXML != null) {
        try {
        	eleRootInxml.setAttribute(KohlsXMLLiterals.A_TERMINAL_ID, eleRetSvcResp.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
        	eleRootInxml.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER, eleRetSvcResp.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
        	eleRootInxml.setAttribute(KohlsXMLLiterals.A_TRANS_TIME_STAMP,eleRetSvcResp.getAttribute(KohlsXMLLiterals.A_TRANS_TIME_STAMP));
        	Element eleExtnRetResp = XMLUtil.getChildElement(eleRetSvcResp, "Extn");
        	eleRootInxml.setAttribute(KohlsXMLLiterals.CUST_ASSOCIATE_NO,eleExtnRetResp.getAttribute(KohlsXMLLiterals.CUST_ASSOCIATE_NO));
        	eleRootInxml.setAttribute(KohlsXMLLiterals.A_POS_SEQ_NO, eleExtnRetResp.getAttribute(KohlsXMLLiterals.A_EXTN_ORIGINAL_POS_SEQ_NO));
          ordDetDoc = getOMSOrderDetails(env, inXML);
          if (ordDetDoc != null) {
            // If Price Adjustment then import and return
            // CAPE-78
            /*
             * if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPocFeature)) {
             * KohlsImportPOSOrderForPA impCls = new KohlsImportPOSOrderForPA(); retSvcResponseDoc =
             * impCls.importPOSOrderForPA(env, retSvcResponseDoc);
             * 
             * otrResponse.updateOTRResponse(env, retSvcResponseDoc); createRKCPromotions(env,
             * retSvcResponseDoc); //update custom table // Document docOutOrginalSalesOrder
             * =updateOrginalSaleData(env,retSvcResponseDoc); return retSvcResponseDoc; }
             */
          }
        } catch (YFCException ef) {
          throw ef;
        } catch (Exception e) {
          log.error(
              "Exception in getOMSOrderDetails of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
                  + e.getMessage());
          throw new YFCException(KohlsConstant.EXTN_OTHER);
        }
      }
    }

    if (ordDetDoc == null) {
      // Add pocReturn Order as false
      Element eleOTR = retSvcResponseDoc.getDocumentElement();
      // Element eleOTR =
      // (Element)rootEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
      // Element eleOTR = SCXmlUtil.getChildElement(rootEle,
      // KohlsXMLLiterals.E_ORDER);
      // Element orderExtnEle=(Element)
      // eleOTR.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
      Element orderExtnEle = SCXmlUtil.getChildElement(eleOTR, KohlsXMLLiterals.E_EXTN);
      Element eleDeductibleOffers =
          SCXmlUtil.getChildElement(eleOTR, KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS);
      if (!YFCCommon.isVoid(eleDeductibleOffers)) {
        orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS,
            XMLUtil.getElementXMLString(eleDeductibleOffers));
        eleOTR.removeChild(SCXmlUtil.getChildElement(eleOTR, KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS));
      }

      // Check if RKCEventList is present and form RKC Promotion in the order document
      if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPocFeature)) {

        // Document docOutOrginalSalesOrder =updateOrginalSaleData(env,retSvcResponseDoc);
      }
      createRKCPromotions(env, retSvcResponseDoc);
      if (!KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPocFeature)) {
          otrResponse.updateOTRResponse(env, retSvcResponseDoc);
      }
      // If this is PSA, perform importOrder
      String pocFeature = inXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_POC_FEATURE);// POCFeature="PSA"
      if (pocFeature.equalsIgnoreCase("PSA")) {
        try {
          KohlsImportPOSOrderForPSA impCls = new KohlsImportPOSOrderForPSA();
          retSvcResponseDoc = impCls.importPOSOrderForPSA(env, retSvcResponseDoc);
        } catch (Exception ex) {
          log.error(
              "Exception in KohlsPoCCheckAndMergeOrderWithRSResponse. Details:" + ex.getMessage());
          throw new YFCException(KohlsConstant.EXTN_OTHER);
        }

      }
      // CAPE-78
      if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPocFeature)) {
        try {
          KohlsImportPOSOrderForPA impCls = new KohlsImportPOSOrderForPA();
          retSvcResponseDoc = impCls.importPOSOrderForPA(env, retSvcResponseDoc);
    	  env.setTxnObject(KohlsPOCConstant.EXTN_POC_FEATURE, KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT);
          otrResponse.updateOTRResponse(env, retSvcResponseDoc);
          // Document docOutOrginalSalesOrder =updateOrginalSaleData(env,retSvcResponseDoc);
        } catch (YFCException ef) {
          throw ef;
        } catch (Exception ex) {
          log.error(
              "Exception in KohlsPoCCheckAndMergeOrderWithRSResponse. Details:" + ex.getMessage());
          throw new YFCException(KohlsConstant.EXTN_OTHER);
        }

      }
      return retSvcResponseDoc;
    } else {

      try {
        // Manoj modified the logic to optimize the performance.
        // mergedOrderXML =
        // parseAndMergeReturnServiceResponse(env,ordDetDoc,retSvcResponseDoc);

        mergedOrderXML = mergeRSXmlWithOMSXml(env, retSvcResponseDoc, ordDetDoc);
        if (mergedOrderXML != null) {
          Element isPOCOrderEle = XMLUtil.createChild(mergedOrderXML.getDocumentElement(),
              KohlsXMLLiterals.E_POC_ORDER);
          XMLUtil.setNodeValue(isPOCOrderEle, KohlsConstant.TRUE);
          mergedOrderXML.getDocumentElement().setAttribute(KohlsXMLLiterals.E_POC_ORDER,
              KohlsConstant.TRUE);
        }
        log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.parseReturnServiceResponse");

        otrResponse.updateOTRResponse(env, mergedOrderXML);
        createRKCPromotions(env, mergedOrderXML);
      } catch (Exception e) {
        log.error(
            "Exception in parseAndMergeReturnServiceResponse of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
                + e.getMessage());
      }
    }
    return mergedOrderXML;
  }


  /**
   * updates few parameter of the existing POC order based on Kohls return service response
   * 
   * @param env env
   * @param ordDetailXml poc order details
   * @param otrResponseXml rs response xml
   * @return Document type
   * 
   */
  private Document parseAndMergeReturnServiceResponse(YFSEnvironment env, Document ordDetailXml,
      Document otrResponseXml) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.parseAndMergeReturnServiceResponse");
    Element eleOrder = ordDetailXml.getDocumentElement();
    // Element eleOrder =
    // (Element)rootEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
    Element eleOTR = otrResponseXml.getDocumentElement();
    // Element eleOTR =
    // (Element)rootEleOtr.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
    eleOrder.setAttribute(KohlsXMLLiterals.A_OPERATOR_ID,
        eleOTR.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID));
    NodeList orderLineList = eleOrder.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
    NodeList otrLineList = eleOTR.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
    // MAD-286 - Start
    Element eleAddtionalInfo =
        XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
    // MAD-286 - End
    Element orderLineEle = null;
    Element otrLineEle = null;
    String otrExtnReturnPrice = null;
    String otrExtnTaxableAmount = null;
    boolean invokeChgOrder = false;
    boolean addOrderLineItem = false;
    boolean isChgOrdStatusReqd = false;
    // Create changeOrder document
    Document chgOrdDoc = null;
    try {
      chgOrdDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);

      Element chgOrdDocEle = chgOrdDoc.getDocumentElement();
      Element cheOrdLinesElement =
          XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_ORDER_LINES);
      // Contains the to append orderliens from RS Response
      Element otrTobeAddedOrdLinesElement =
          XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_LINES).getDocumentElement();
      // Contains the orderlines that require status change
      Element chgStatuOrdLinesElement =
          XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_LINES).getDocumentElement();

      // loop through the original order for merge
      for (int i = 0; i < orderLineList.getLength(); i++) {
        orderLineEle = (Element) orderLineList.item(i);
        Element eleOrderItem = null;
        try {
          eleOrderItem = (Element) (XPathUtil.getNode(orderLineEle, KohlsXMLLiterals.E_ITEM));
        } catch (Exception e) {
          log.error(
              "Exception in getNode - parseAndMergeReturnServiceResponse of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
                  + e.getMessage());
        }
        String ordPrimeLineNo = orderLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
        String ordItemId = eleOrderItem.getAttribute(KohlsConstant.A_ITEM_ID);
        addOrderLineItem = false;
        for (int j = 0; j < otrLineList.getLength(); j++) {
          otrLineEle = (Element) otrLineList.item(j);
          Element eleOtrItem = null;

          // Added for Extn attributes --start
          Element eleOtrExtn = null;

          try {
            eleOtrItem = (Element) (XPathUtil.getNode(otrLineEle, KohlsXMLLiterals.E_ITEM));

            String otrPrimeLineNo = otrLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
            String otrItemId = eleOtrItem.getAttribute(KohlsConstant.A_ITEM_ID);

            eleOtrExtn = (Element) (XPathUtil.getNode(otrLineEle, KohlsXMLLiterals.E_EXTN));
            otrExtnReturnPrice = eleOtrExtn.getAttribute(KohlsConstant.A_EXTN_RETURN_PRICE);
            otrExtnTaxableAmount = eleOtrExtn.getAttribute(KohlsConstant.A_EXTN_TAXABLE_AMOUNT);

            // Added for Extn attributes --end

            if (ordPrimeLineNo.equals(otrPrimeLineNo)) {
              // Due to RS first 0 trimming issue, compare with
              // that string too for item id
              if (ordItemId.equals(otrItemId) || ordItemId.substring(1).equals(otrItemId)) {
                // See if isReturnIndicator true
                String ordIsReturned =
                    orderLineEle.getAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM);
                String otrIsReturned = otrLineEle.getAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM);
                if (!ordIsReturned.equalsIgnoreCase(otrIsReturned)) {
                  addOrderLineItem = true;
                  invokeChgOrder = true;
                  break;
                }
              } else {
                // Item got exchanged; add to order line
                // IsLastExchangedInRs attribute, call
                // ChangeOrderStatus for orderLineEle

                otrLineEle.setAttribute(KohlsXMLLiterals.A_IS_LAST_EXCHANGED_IN_RS,
                    KohlsConstant.YES);
                XMLUtil.importElement(otrTobeAddedOrdLinesElement, otrLineEle);
                // Add it to changeOrderStatus orderLine input
                Element chngStatusLineEle = orderStatusChangeOrdLineInput(env, orderLineEle);
                Element lineStatus = (Element) orderLineEle
                    .getElementsByTagName(KohlsXMLLiterals.E_ORDER_STATUS).item(0);
                if (!YFCCommon.isVoid(lineStatus)) {
                  String ordLineStsString = lineStatus.getAttribute(KohlsXMLLiterals.A_STATUS);
                  if (!YFCCommon.isVoid(ordLineStsString) && !ordLineStsString
                      .equalsIgnoreCase(KohlsXMLLiterals.A_RETURN_CREATED_STATUS)) {
                    isChgOrdStatusReqd = true;
                    XMLUtil.importElement(chgStatuOrdLinesElement, chngStatusLineEle);
                  }
                }

              }
            }
          } catch (Exception e) {
            log.error(
                "Exception in looping of parseAndMergeReturnServiceResponse of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
                    + e.getMessage());
          }
        }
        // System.out.println("New elements from OTR Resposen are: " +
        // XMLUtil.getElementXMLString(otrTobeAddedOrdLinesElement));
        if (addOrderLineItem) {
          Element chgOrdLnEle =
              XMLUtil.createChild(cheOrdLinesElement, KohlsXMLLiterals.E_ORDER_LINE);
          chgOrdLnEle.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY,
              orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));
          chgOrdLnEle.setAttribute(KohlsXMLLiterals.A_SHIPNODE,
              orderLineEle.getAttribute(KohlsXMLLiterals.A_SHIPNODE));
          chgOrdLnEle.setAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM,
              otrLineEle.getAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM));

        }

      }

      Element orderExtnEle =
          (Element) eleOrder.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
      Element extnElement = (Element) eleOTR.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
      // orderExtnEle.setAttribute("ExtnDeductibleOffers",
      // XMLUtil.getElementXMLString((Element)eleOTR.getElementsByTagName("DeductibleOffers").item(0)));

      if (!orderExtnEle.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE)
          .equalsIgnoreCase(extnElement.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE))) {
        invokeChgOrder = true;
        orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE,
            extnElement.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE));
        orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE,
            extnElement.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE));
        orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS,
            XMLUtil.getElementXMLString((Element) eleOTR
                .getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0)));

        XMLUtil.importElement(chgOrdDocEle, orderExtnEle);
      }

      if (invokeChgOrder) {
        // invoke change Order API
        chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE,
            eleOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE));
        chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE,
            eleOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE));
        chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
        chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE,
            eleOrder.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
        chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsConstant.YES);
        try {
          // MAD-286 - Start
          log.debug("Before ChangeOrderStatus ::" + ServerTypeHelper.amIOnEdgeServer());
          if (ServerTypeHelper.amIOnEdgeServer()) {
            Element eleAdditionalInfo =
                SCXmlUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_YFCADDITIONALINFO);
            if (!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()) {
              String endPoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
              eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endPoint);
            }
          }
          // MAD-286 - End
          chgOrdDoc = KohlsCommonUtil.invokeAPI(env,
              KohlsXMLLiterals.CHG_ORDERDETAILS_FOR_RS_RESPONSE_TEMPLATE,
              KohlsConstants.CHANGE_ORDER_API, chgOrdDoc);
        } catch (Exception e) {
          log.error(
              "Exception in changeOrder invoke API of parseAndMergeReturnServiceResponse of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
                  + e.getMessage());
        }
      } else {
        chgOrdDoc = XMLUtil.createDocument(ordDetailXml.getFirstChild());
      }

      // change Order line status for returned items from RS Response
      if (isChgOrdStatusReqd) {
        Document ordStatusInDoc =
            orderStatusChangeInput(env, eleOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE),
                eleOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE),
                eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));

        NodeList statusChgLineList =
            chgStatuOrdLinesElement.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
        Element rootOrdStatus = ordStatusInDoc.getDocumentElement();
        Element ordLineListEle =
            (Element) rootOrdStatus.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);

        if (!YFCCommon.isVoid(statusChgLineList) || !YFCCommon.isVoid(ordLineListEle)) {
          for (int cnt = 0; cnt < statusChgLineList.getLength(); cnt++) {
            Element eleLineElement = (Element) statusChgLineList.item(cnt);
            XMLUtil.importElement(ordLineListEle, eleLineElement);
          }
        }

        try {
          // MAD-286 - Start
          log.debug("Before ChangeOrderStatus ::" + ServerTypeHelper.amIOnEdgeServer());
          if (ServerTypeHelper.amIOnEdgeServer()) {
            Element orderEle = ordStatusInDoc.getDocumentElement();
            Element eleAdditionalInfo =
                SCXmlUtil.createChild(orderEle, KohlsXMLLiterals.E_YFCADDITIONALINFO);
            if (!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()) {
              String endPoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
              eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endPoint);
            }
          }
          // MAD-286 - End
          // Adding logger condition check as per PRF-208
          if (log.isDebugEnabled())
            log.debug("changeOrderStatus input: " + XMLUtil.getXMLString(ordStatusInDoc));

          KohlsCommonUtil.invokeAPI(env, KohlsXMLLiterals.CHG_ORDERDETAILS_FOR_RS_RESPONSE_TEMPLATE,
              KohlsConstant.CHANGE_ORDER_STAT_API, ordStatusInDoc);
        } catch (Exception e) {
          log.error(
              "Exception in invokeAPI changeOrderStatus of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
                  + e.getMessage());
        }

      }

      // Document
      // inXML=(Document)env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
      // chgOrdDoc=getOMSOrderDetails(env, inXML);
      // System.out.println("response from schgOrder XML\n" +
      // XMLUtil.getXMLString(chgOrdDoc));
      Element rootEleChgOrd = chgOrdDoc.getDocumentElement();
      chgOrdDocEle = (Element) rootEleChgOrd.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
      Element cleanRecptInd =
          XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
      XMLUtil.setNodeValue(cleanRecptInd, eleOTR
          .getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0).getTextContent());
      Element trainingModeInd =
          XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_TRAINING_MODE_IND);
      XMLUtil.setNodeValue(trainingModeInd,
          eleOTR.getAttribute(KohlsXMLLiterals.E_TRAINING_MODE_IND));
      Element txnAvblAmount =
          XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT);
      XMLUtil.setNodeValue(txnAvblAmount,
          eleOTR.getAttribute(KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT));
      Element responseReasonDesc =
          XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_REPONSE_REASON_DESC);
      XMLUtil.setNodeValue(responseReasonDesc, eleOTR
          .getElementsByTagName(KohlsXMLLiterals.E_REPONSE_REASON_DESC).item(0).getTextContent());

      // Added for Extn attributes --start

      // Added for defect 3317-start

      NodeList chgOrdLnEle = chgOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
      Element eleOtrDiscounts = null;
      // Changes for PR-400 - Start
      Element eleOtrOrderLineExtn = null;
      for (int i = 0; i < chgOrdLnEle.getLength(); i++) {
        Element chgOrdLnEleOtr = (Element) chgOrdLnEle.item(i);
        Element ReturnPriceAmt =
            XMLUtil.createChild(chgOrdLnEleOtr, KohlsXMLLiterals.E_RETURN_PRICE_AMOUNT);
        XMLUtil.setNodeValue(ReturnPriceAmt, otrExtnReturnPrice);
        Element TaxableAmt = XMLUtil.createChild(chgOrdLnEleOtr, KohlsXMLLiterals.E_TAXABLE_AMOUNT);
        // otrLineEle = (Element) otrLineList.item( i );
        String sPrimeLineno = chgOrdLnEleOtr.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
        otrLineEle = SCXmlUtil.getXpathElement(eleOTR,
            "OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineno + "']");
        // PR-621 - Start - Adding Null Check for otrLineEle
        if (!YFCCommon.isVoid(otrLineEle)) {
          eleOtrDiscounts = SCXmlUtil.getXpathElement(otrLineEle, KohlsXMLLiterals.E_DISCOUNTS);
          eleOtrOrderLineExtn =
              (Element) otrLineEle.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
          if (!YFCCommon.isVoid(eleOtrOrderLineExtn)) {
            XMLUtil.setNodeValue(ReturnPriceAmt,
                eleOtrOrderLineExtn.getAttribute(KohlsConstant.A_EXTN_RETURN_PRICE));
            XMLUtil.setNodeValue(TaxableAmt,
                eleOtrOrderLineExtn.getAttribute(KohlsConstant.A_EXTN_TAXABLE_AMOUNT));
          }

          if (!YFCCommon.isVoid(eleOtrDiscounts)) {
            chgOrdDoc.adoptNode(eleOtrDiscounts);
            XMLUtil.appendChild(chgOrdLnEleOtr, eleOtrDiscounts);

          }
        } else {
          log.debug(
              "The chgOrdLnEleOtr element value is " + XMLUtil.getElementXMLString(chgOrdLnEleOtr));
          Element chgOrdLnExtnEle = XMLUtil.getChildElement(chgOrdLnEleOtr, "Extn");
          log.debug("The chgOrdLnExtnEle element value is "
              + XMLUtil.getElementXMLString(chgOrdLnExtnEle));
          if (!YFCCommon.isVoid(chgOrdLnExtnEle)) {
            XMLUtil.setNodeValue(ReturnPriceAmt,
                chgOrdLnExtnEle.getAttribute(KohlsConstant.A_EXTN_RETURN_PRICE));
            XMLUtil.setNodeValue(TaxableAmt,
                chgOrdLnExtnEle.getAttribute(KohlsConstant.A_EXTN_TAXABLE_AMOUNT));
          }
        }
        // PR-621 - End
      }
      // Changes for PR-400 - End
      // Added for defect 3317-end
      // Added for Extn attributes --end

      XMLUtil.importElement(chgOrdDocEle,
          (Element) eleOTR.getElementsByTagName(KohlsXMLLiterals.TENDERS_AVAILABLE_RETURN).item(0));
      // Append orderline elements got from RS response that are
      // potentially exchanged for gravity
      // usage and check
      NodeList toAddLineList =
          otrTobeAddedOrdLinesElement.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
      Element ordLineListEle =
          (Element) chgOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);

      if (!YFCCommon.isVoid(toAddLineList) || !YFCCommon.isVoid(ordLineListEle)) {
        for (int cnt = 0; cnt < toAddLineList.getLength(); cnt++) {
          Element cv1 = (Element) toAddLineList.item(cnt);
          XMLUtil.importElement(ordLineListEle, cv1);
        }
      }

      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("response to gravity XML\n" + XMLUtil.getXMLString(chgOrdDoc));
      }
    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException changeOrder build in parseAndMergeReturnServiceResponse of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
      throw new YFCException(KohlsConstant.EXTN_OTHER);
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.parseAndMergeReturnServiceResponse");
    return chgOrdDoc;
  }

  /**
   * 
   * @param env env
   * @param inXML input
   * @return Document document
   */
  // verified
  public Document getOMSOrderDetails(YFSEnvironment env, Document inXML) {
    // PR-621 and PDB-277 - Start
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getOMSOrderDetails");
    Document outputDoc = null;
    try {
      Document ordINXML = getOMSOrderList(env, inXML);

      if (ordINXML != null)
      // Start - Check if order exists in OMS - IBM
      {
        Element rootEleOrd = ordINXML.getDocumentElement();
        NodeList nlOrderList = (NodeList) rootEleOrd.getElementsByTagName(KohlsXMLLiterals.E_ORDER);
        if (nlOrderList.getLength() > 0) {
          log.debug("Order exist in OMS...");
          // Changes for Cape 840 - Sudina - Start
          Element eleOrder = (Element) nlOrderList.item(0);
          // Changes for CAPE 873 - Manoj - start
      /*    Element eleOrderLines = (Element) eleOrder.getElementsByTagName("OrderLines").item(0);
          NodeList nlOrderLine = eleOrder.getElementsByTagName("OrderLine");
          if (nlOrderLine.getLength() > 0) {
            for (int i = 0; i < nlOrderLine.getLength(); i++) {
              Element eleOrderLine = (Element) nlOrderLine.item(i);
              String sOrderedQty = eleOrderLine.getAttribute("OrderedQty");
              if (!YFCCommon.isVoid(sOrderedQty)) {
                Double dOrderedQty = Double.parseDouble(sOrderedQty);
                if (dOrderedQty == 0.0D) {
                  eleOrderLines.removeChild(eleOrderLine);
                }
              }
            }
          } */
          // Changes for CAPE 873 - Manoj - End
          // Changes for Cape 840 - Sudina - End

          outputDoc = XMLUtil.createDocument(nlOrderList.item(0));

          // Changes for ISS - Begin
          if (ServerTypeHelper.amIOnEdgeServer()) {
            Element eleAdditionalInfo =
                XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
            if (!YFCCommon.isVoid(eleAdditionalInfo)) {
              String sEndPoint = eleAdditionalInfo.getAttribute(KohlsXMLLiterals.A_ENDPOINT);
              env.setTxnObject("GET_ORDER_LIST_ENDPOINT", sEndPoint);
            }
          }
          // Changes for ISS - End

        }
      }
      // End - Check if order exists in OMS - IBM
    } catch (Exception yfc) {
      log.error(
          "Exception in getOMSOrderDetails invokeAPI of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + yfc.getMessage());
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getOMSOrderDetails");
    // PR-621 and PDB-277 - End
    return outputDoc;

  }

  /**
   * getOrderList API call with Extn/ExtnReceiptId
   * 
   * @param env env
   * @param inXML inxml with receipt id
   * @return orderlist response document
   */
  private Document getOMSOrderList(YFSEnvironment env, Document inXML) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getOMSOrderList");
    Document outputDoc = null;
    try {
      Element eleInputOrder = inXML.getDocumentElement();
      String strEnterpriseCode = eleInputOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
      String strDocumentType = eleInputOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE);
      String strExtnRecp = null;
      String strStoreNo = eleInputOrder.getAttribute(KohlsXMLLiterals.A_STORE_NUMBER);
      String strTerminalId = eleInputOrder.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID);
      String strTransTmst = eleInputOrder.getAttribute(KohlsXMLLiterals.A_TRANS_TIME_STAMP);
      Date date = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss" ).parse( strTransTmst );
      String dateStr = new SimpleDateFormat( "MMddyyHHmmss" ).format( date );
      String strPosSeqNo = eleInputOrder.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO);
      String strAssociateId = eleInputOrder.getAttribute(KohlsXMLLiterals.CUST_ASSOCIATE_NO);
     
      // Check if Receipt is already present in env object
      if(!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_EXTN_RECEIPT_ID))) {
    	  strExtnRecp = (String) env.getTxnObject(KohlsXMLLiterals.A_EXTN_RECEIPT_ID);
      }
      // If receipt is present in env object then dont generate the ID.
      if(YFCCommon.isVoid(strExtnRecp)) {
    	  //generate Trxn#
    	  String transNumber = TransactionNumberUtil.generateTransactionNumber( strStoreNo, strTerminalId, strPosSeqNo, dateStr );

    	  if(YFCCommon.isVoid(strAssociateId)){
    		  strExtnRecp = ReceiptUtil.generateReceiptID( transNumber, ReceiptUtil.SALE_LINE_NUMBER_DEFAULT );
    	  } else {
    		  String assocLineNo = KohlsPoCCommonAPIUtil.getRuleValue(env, "ASSOCIATE_LINE_NUMBER", "KOHLS-RETAIL", "223");
    		  strExtnRecp = ReceiptUtil.generateReceiptID( transNumber, assocLineNo );
    	  }
    	  env.setTxnObject(KohlsPOCConstant.RP_RECEIPT_ID, strExtnRecp);
      }
      Document ordINXML = getOrderListInputXML(strExtnRecp, strEnterpriseCode, strDocumentType);
  	      
      KohlsPoCCommonAPIUtil.setQueryTimeOut(env, ordINXML.getDocumentElement(), false);  

      // log.debug("GetOrderList input is: " + XMLUtil.getXMLString(ordINXML));
        outputDoc =
            KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.ORDERDETAILS_WITH_RS_RESPONSE_TEMPLATE,
                KohlsConstant.API_GET_ORDER_LIST, ordINXML);
        if (log.isDebugEnabled()) {
          log.debug("GetOrderList out is: " + XMLUtil.getXMLString(outputDoc));
        }
        
        String totalOrderList = outputDoc.getDocumentElement().getAttribute(KohlsXMLLiterals.A_TOTAL_ORDER_LIST);
        //OMNI2 Call getOrderList for PickInvoice -BEGIN
        String strCleanReceiptInd = inXML.getDocumentElement().getAttribute(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
        String strOmniBagInd = inXML.getDocumentElement().getAttribute("OmniBagInd");
        if("0".equals(totalOrderList) && !YFCCommon.isVoid(strExtnRecp) && "Y".equals(strCleanReceiptInd) && "Y".equals(strOmniBagInd)) {
        	log.debug("KohlsPoCCheckAndMergeOrderWithRSResponse.getOMSOrderList - Inside if condition for OMNI2" + XMLUtil.getXMLString(inXML));
        	isPickInvoice = true;
        	Document gOLInXML = prepareGetOrderListInput(env, strExtnRecp);
        	if(gOLInXML.getDocumentElement().hasAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY)) {
			KohlsPoCCommonAPIUtil.setQueryTimeOut(env, gOLInXML.getDocumentElement(), false);
        		outputDoc =
        	            KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.ORDERDETAILS_WITH_RS_RESPONSE_TEMPLATE,
        	                KohlsConstant.API_GET_ORDER_LIST, gOLInXML);
        	}
        }
        //OMNI2 Call getOrderList for PickInvoice - END
      
    } catch (Exception yfc) {
      log.error("Exception in getOMSOrderList of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
          + yfc.getMessage());
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getOMSOrderList");
    return outputDoc;
  }

  private Document prepareGetOrderListInput(YFSEnvironment env, String strExtnRecp) throws Exception {
	  log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.prepareGetOrderListInput");
	  log.debug("Inside  KohlsPoCCheckAndMergeOrderWithRSResponse.prepareGetOrderListInput method");
	 //Prepare getShipmentList to fetch OrderHeaderKey 
	 Document docGetShipmentListInput = SCXmlUtil.createDocument(KohlsXMLLiterals.E_SHIPMENT);  
	 Element eleShipment = docGetShipmentListInput.getDocumentElement();
	 
	 Element shipExtn = docGetShipmentListInput.createElement(KohlsXMLLiterals.E_EXTN);
	 String strFormattedReceiptId =  strExtnRecp.substring(KohlsConstant.NUMBER_0,
             KohlsConstant.NUMBER_3)
             + "-"
             + strExtnRecp.substring(KohlsConstant.NUMBER_3,(KohlsConstant.NUMBER_3+KohlsConstant.NUMBER_4))+   "-"
                     + strExtnRecp.substring((KohlsConstant.NUMBER_3+KohlsConstant.NUMBER_4),(KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_2)))+  "-"
                             + strExtnRecp.substring(KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_2),(KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_3)))+  "-"
                                     + strExtnRecp.substring(KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_3),(KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_4)))+  "-"
                                             + strExtnRecp.substring((KohlsConstant.NUMBER_3+KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_4),(KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_5)))+  "-"
                                                     + strExtnRecp.substring((KohlsConstant.NUMBER_3+(KohlsConstant.NUMBER_4*KohlsConstant.NUMBER_5)));
	shipExtn.setAttribute("ExtnStorePreencReceiptID", strFormattedReceiptId);
	log.debug("Inside prepareGetOrderListInput - Formatted ReceiptID with Hyphens" + strFormattedReceiptId);
	
	eleShipment.appendChild(shipExtn);
	Document getShipmentListTemplate = XMLUtil.getDocument("<Shipments><Shipment OrderHeaderKey=''/></Shipments>");
	Document outputShipmentDoc = KOHLSBaseApi.invokeAPI(env, getShipmentListTemplate,KohlsConstants.API_GET_SHIPMENT_LIST,docGetShipmentListInput);
	if(log.isDebugEnabled()) {
		log.debug("Inside prepareGetOrderListInput - getShipmentList API output " + XMLUtil.getXMLString(outputShipmentDoc));
	}
	
	Element eleOutputShipment = (Element) outputShipmentDoc.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_SHIPMENT).item(0);
	String ordHeaderKey = eleOutputShipment.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
	
	Document docGetOrderList = SCXmlUtil.createDocument(KohlsXMLLiterals.E_ORDER);
	
	if(!YFCCommon.isVoid(ordHeaderKey)) {
		Element eleGOLOrder = docGetOrderList.getDocumentElement();
		eleGOLOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, ordHeaderKey);	
	}
	if(log.isDebugEnabled()) {
		log.debug("Inside prepareGetOrderListInput - getOrderList API input prepared " + XMLUtil.getXMLString(docGetOrderList));
	}
	log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.prepareGetOrderListInput");
	return docGetOrderList;
	
}

/**
   * OrderStatusChange API call
   * 
   * @param env env
   * @param inXML inxml with receipt id
   * @return input document
   */
  private Document orderStatusChangeInput(YFSEnvironment env, String strEnterpriseCode,
      String strDocumentType, String strOrderHeaderKey) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.orderStatusChangeInput");
    Document yfcDocOrderStatus = null;
    try {
      yfcDocOrderStatus = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_STATUS_CHANGE);

      Element yfcEleGetOrderStatus = yfcDocOrderStatus.getDocumentElement();
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_TRANSACTIONID,
          KohlsXMLLiterals.A_INCLUDE_IN_RETURN);
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_IGNORE_TRAN_DEPENDENCIES,
          KohlsConstant.YES);
      Element ordLinesEle =
          XMLUtil.createChild(yfcEleGetOrderStatus, KohlsXMLLiterals.E_ORDER_LINES);

      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("orderStatusChangeInput Input :" + XMLUtil.getXMLString(yfcDocOrderStatus));
      }

    } catch (DOMException e) {
      log.error(
          "DOMException in getOrderListInputXML of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in getOrderListInputXML of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.orderStatusChangeInput");
    return yfcDocOrderStatus;
  }

  private Element orderStatusChangeOrdLineInput(YFSEnvironment env, Element orderLineEle) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.orderStatusChangeOrdLineInput");
    Document yfcDocOrderLine = null;
    try {
      yfcDocOrderLine = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_LINE);

      Element yfcEleGetOrderStatus = yfcDocOrderLine.getDocumentElement();
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_BASEDROPSTATUS,
          KohlsXMLLiterals.A_RETURN_CREATED_STATUS);
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_SUB_LINE_NO,
          orderLineEle.getAttribute(KohlsXMLLiterals.A_SUB_LINE_NO));
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_QUANTITY,
          orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDERED_QUANTITY));
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO,
          orderLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO));
      yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY,
          orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));

      Element ordLineTranQtyEle =
          XMLUtil.createChild(yfcEleGetOrderStatus, KohlsXMLLiterals.A_ORDER_LINE_TRAN_QUANTITY);
      ordLineTranQtyEle.setAttribute(KohlsXMLLiterals.A_QUANTITY,
          orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDERED_QUANTITY));
      ordLineTranQtyEle.setAttribute(KohlsXMLLiterals.A_TRANSACTIONAL_UOM,
          KohlsConstant.UNIT_OF_MEASURE);

      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("orderStatusChangeInput Input :" + XMLUtil.getXMLString(yfcDocOrderLine));
      }

    } catch (DOMException e) {
      log.error(
          "DOMException in orderStatusChangeOrdLineInput of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in orderStatusChangeOrdLineInput of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.orderStatusChangeOrdLineInput");
    return yfcDocOrderLine.getDocumentElement();
  }

  /**
   * Constructs input xml for getOrderList input xml
   * 
   * @param strExtnRecp receipt no
   * @param strEnterpriseCode ent code
   * @param strDocumentType doc type
   * @return Document req document
   */
  private Document getOrderListInputXML(String strExtnRecp,String strEnterpriseCode, String strDocumentType) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getOrderListInputXML");
    Document yfcDocOrder = null;
    try {
      yfcDocOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);

      Element yfcEleGetOrder = yfcDocOrder.getDocumentElement();
      yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
      yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);
      // Passing SellerOrganizationCode to make sure sterling Identifies the Shard correctly.
      String originalSaleStoreNumber = "";
      try {
        originalSaleStoreNumber = getStoreNumberFromTransactionNumber(ReceiptUtil.getTransactionIdFromReceiptID(strExtnRecp));
      } catch (Exception e){
        originalSaleStoreNumber = "";
      }
      if(!YFCCommon.isVoid(originalSaleStoreNumber)){
        yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, String.valueOf(Integer.parseInt(originalSaleStoreNumber)));
      }
      Element extnElement = XMLUtil.createChild(yfcEleGetOrder, KohlsXMLLiterals.E_EXTN);
      extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, strExtnRecp);
      extnElement.setAttribute(KohlsPOCConstant.EXTN_IS_LATEST, "Y");

      // MAD-286 - Start
      log.debug("Checking if it is edge Deployemnt::" + ServerTypeHelper.amIOnEdgeServer());
      if (ServerTypeHelper.amIOnEdgeServer()) {
        Element eleAdditionalInfo =
            SCXmlUtil.createChild(yfcEleGetOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
            KohlsXMLLiterals.V_LOCALANDMOTHERSHIP);
      }
      // MAD-286 - End
      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("getOrderDetails Input :" + XMLUtil.getXMLString(yfcDocOrder));
      }

    } catch (DOMException e) {
      log.error(
          "DOMException in getOrderListInputXML of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in getOrderListInputXML of KohlsPoCCheckAndMergeOrderWithRSResponse. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getOrderListInputXML");
    return yfcDocOrder;
  }

  /**
   * Constructs the getOrderDetails input xml
   * 
   * @param strOrderNo order number of the order
   * @param strEnterpriseCode ent code
   * @param strDocumentType document type
   * @return Document input xml
   * @throws Exception
   */
  /*
   * private Document getOrderInputXML(String strOrderNo, String strEnterpriseCode, String
   * strDocumentType){ YFCDocument yfcDocOrder =
   * YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER); YFCElement yfcEleGetOrder =
   * yfcDocOrder.getDocumentElement(); yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ORDERNO,
   * strOrderNo); yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE,
   * strEnterpriseCode); yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE,
   * strDocumentType);
   * 
   * if(YFCLogUtil.isDebugEnabled()){ log.debug("getOrderDetails Input" +
   * XMLUtil.getXMLString(yfcDocOrder.getDocument())); }
   * 
   * return yfcDocOrder.getDocument(); }
   */
  /**
   * Constructs the Checks if OMS Order line is modified outside of OMS and if not then replace RS
   * line with OMS line
 * @param env 
   * 
   * @return Document input xml
   * @throws Exception
   */
  public Document mergeRSXmlWithOMSXml(YFSEnvironment env, Document docRSXml, Document docOMSXml) throws Exception {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.mergeRSXmlWithOMSXml");
    
    // Replacing the PaymentMethods in OMS XML with PaymentMethods from RS>.
    Element eleOMSPmtMthds = (Element) docOMSXml.getElementsByTagName("PaymentMethods").item(0);    
    Element eleRSPmtMthds = (Element) docRSXml.getElementsByTagName("PaymentMethods").item(0);
    if (!YFCCommon.isVoid(eleRSPmtMthds) && !YFCCommon.isVoid(eleOMSPmtMthds)) {
      docOMSXml.getDocumentElement().removeChild(eleOMSPmtMthds);
      Element tempPaymentMethod = (Element) docOMSXml.importNode(eleRSPmtMthds, true);
      docOMSXml.getDocumentElement().appendChild(tempPaymentMethod);
    }
    
    // This method will adjust the prime line nos as per sent by RS in case 
    // we have cancelled lines in OMS
      boolean isOmni=false;
    //  Element  eleOmni= (Element)docRSXml.getElementsByTagName("OmniBagInd").item(0);
     Element eleOmni = (Element) docRSXml.getDocumentElement().getElementsByTagName("OmniBagInd").item(0);
      if(!YFCCommon.isVoid(eleOmni)) {
      String strOmni = eleOmni.getTextContent();
      if(!YFCCommon.isVoid(strOmni) && KohlsPOCConstant.TRUE.equalsIgnoreCase(strOmni)) {
    	  isOmni=true;
      	}
      }
     
     
	  if(!isOmni)
		  adjustPrimeLineNo (docOMSXml);

    String sCleanReceiptInd =
        docRSXml.getElementsByTagName("CleanReceiptInd").item(0).getTextContent();
    log.debug("Clean receipt Ind is: " + sCleanReceiptInd);

    // Commenting as we are considering only RS XML

    /*
     * if (!YFCCommon.isVoid(sCleanReceiptInd) && "true".equals(sCleanReceiptInd)) { Element
     * eleCleanReceiptInd = XMLUtil.createChild(docOMSXml.getDocumentElement(), "CleanReceiptInd");
     * XMLUtil.setNodeValue(eleCleanReceiptInd, KohlsConstant.TRUE); Element eleRSExtn = (Element)
     * docRSXml.getElementsByTagName("Extn").item(0); String sExtnOTRResponse =
     * eleRSExtn.getAttribute("ExtnOTRResponse"); String sExtnOTRResponseType =
     * eleRSExtn.getAttribute("ExtnOTRResponseType"); Element eleOMSExtn = (Element)
     * docOMSXml.getElementsByTagName("Extn").item(0); eleOMSExtn.setAttribute("ExtnOTRResponse",
     * sExtnOTRResponse); eleOMSExtn.setAttribute("ExtnOTRResponseType", sExtnOTRResponseType);
     * eleOMSExtn.setAttribute( KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS,
     * XMLUtil.getElementXMLString((Element) docRSXml.getElementsByTagName(
     * KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0)));
     * log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.mergeRSXmlWithOMSXml"); //return
     * docOMSXml; }
     */
    if (!YFCCommon.isVoid(docOMSXml)) {
      // Updated for CAPE 1539 - begin
      Element eleRSOrderExtn = (Element) docRSXml.getElementsByTagName("Extn").item(0);
      NodeList nlDeductibleOffers = docRSXml.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS);
      if(!YFCCommon.isVoid(nlDeductibleOffers) && nlDeductibleOffers.getLength()>0){
    	  eleRSOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS,
    			  XMLUtil.getElementXMLString((Element) docRSXml
    					  .getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0)));
      }
      // Updated for CAPE 1539 - end
      Element eleOMSOrder = docOMSXml.getDocumentElement();
      String sOrderHeaderKey = eleOMSOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      docRSXml.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
          sOrderHeaderKey);
      //OMNI2 - stamp OrderNo BEGIN
      ArrayList<String> listOrderLineKeys = new ArrayList<String>(); 
  	  ArrayList<String> listAutoReturnLineKeys = new ArrayList<String>();
  	  boolean isAutoReturn = false;
      if(isPickInvoice) {
    	  String sOrderNo = eleOMSOrder.getAttribute(KohlsXMLLiterals.A_ORDER_NO);
          docRSXml.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_NO,
        		  sOrderNo);
          Document docAutoReturn = (Document) env.getTxnObject("AUTO_RETURN_DOC");
          if(!YFCCommon.isVoid(docAutoReturn)) {
        	  NodeList nlAutoReturnOrderLines = docAutoReturn.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
        	  int nlAutoReturnOrderLinesLength = nlAutoReturnOrderLines.getLength();
        	  for(int autoRetLineCnt = 0; autoRetLineCnt < nlAutoReturnOrderLinesLength; autoRetLineCnt++) {
        		  Element eleAutoReturnOrderLine = (Element) nlAutoReturnOrderLines.item(autoRetLineCnt);
        		  listAutoReturnLineKeys.add(eleAutoReturnOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));
        		  isAutoReturn = true; 
        	  }
          }
      }
    //OMNI2 - stamp OrderNo END

      if (!(YFCCommon.isVoid(eleOMSOrder))) {
        NodeList nlRSOrderLine = docRSXml.getElementsByTagName("OrderLine");
        
        Element eleRSOrderLines = (Element) docRSXml.getElementsByTagName("OrderLines").item(0);
        if (!YFCCommon.isVoid(nlRSOrderLine)) {
        	
        	
          for (int i = 0; i < nlRSOrderLine.getLength(); i++) {
            Element eleRSOrderLine = (Element) nlRSOrderLine.item(i);
            String sRSPrimeLineNo = eleRSOrderLine.getAttribute("PrimeLineNo");
            //OMNI2 changes- get ItemID and ShipNode
            String sRSItemID = eleRSOrderLine.getAttribute(KohlsXMLLiterals.A_ITEM_ID);
            if (sRSItemID.length() == 7) {
            	sRSItemID = '0' + sRSItemID;
            }
            String sRSShipNode = eleRSOrderLine.getAttribute(KohlsXMLLiterals.A_SHIP_NODE);
            //OMNI2 changes- get ItemID and ShipNode
            String sIsReturnedItem = eleRSOrderLine.getAttribute("IsReturnedItem");
            log.debug(" sRSPrimeLineNo is: " + sRSPrimeLineNo);
            if ("N".equalsIgnoreCase(sIsReturnedItem)) {
            	Element eleOMSOrderLine = null;
            	String strOrderLineKey = "";
           
            //PST-7503 : NPE because no matching Line # was found .The logic has been enhanced to consider Item ID as well. This will be rewritten once OMS and RS line numbers start to match  :: START
            	//incase omni order, only rely on PrimeLineNo
            	NodeList nlOrderLine;
            	 if(isOmni) {
            		 nlOrderLine = XPathUtil.getNodeList(docOMSXml,
          				  "/Order/OrderLines/OrderLine[@PrimeLineNo='" + sRSPrimeLineNo+ "']");            		
            	} else {  nlOrderLine = XPathUtil.getNodeList(docOMSXml,
            			"/Order/OrderLines/OrderLine[@PrimeLineNo='" + sRSPrimeLineNo+ "' and Item/@ItemID='" + sRSItemID + "']");
            	} if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
            			  eleOMSOrderLine = (Element) nlOrderLine.item(0);
            	}
			//PST-7503 :: END							
            	//  }
              if (!YFCCommon.isVoid(eleOMSOrderLine)) {
            	  
                log.debug("OMS Order line found");
                /*
                 * Element eleRSExtn = (Element)
                 * eleRSOrderLine.getElementsByTagName("Extn").item(0); String sRSReturnPrice =
                 * eleRSExtn.getAttribute("ExtnReturnPrice"); Element eleOMSExtn1 = (Element)
                 * eleOMSOrderLine.getElementsByTagName("Extn").item(0); String sOMSReturnPrice =
                 * eleOMSExtn1.getAttribute("ExtnReturnPrice"); if
                 * (!YFCCommon.isVoid(sOMSReturnPrice) && !YFCCommon.isVoid(sRSReturnPrice) &&
                 * Double.parseDouble(sRSReturnPrice) == Double.parseDouble(sOMSReturnPrice)) {
                 * log.debug(" Both RS and OMS price is same, so merging the lines");
                 * eleRSOrderLines.removeChild(eleRSOrderLine); Node tempEle =
                 * docRSXml.importNode(eleOMSOrderLine, true); eleRSOrderLines.appendChild(tempEle);
                 * }
                 */

                // add only OrderLineKey instead of replacing the orderline
                strOrderLineKey = eleOMSOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY);
                
                if(!ServerTypeHelper.amIOnEdgeServer())
                {
                		eleRSOrderLine.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY,
                            eleOMSOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY));
                }
                
                //fix for Cape-3729 return of exchange item
                Element eleStatus = (Element)eleOMSOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_STATUS).item(0) ;
                //CPE-7079 If on ISS then dont map the Derived from Keys otherwise confirmDraftOrder will fail.
                if(!YFCCommon.isVoid(eleStatus) && "3700.01".equalsIgnoreCase(eleStatus.getAttribute(KohlsPOCConstant.ATTR_STATUS)) && !ServerTypeHelper.amIOnEdgeServer()){
                	eleRSOrderLine.setAttribute(KohlsPOCConstant.A_DERIVED_FROM_ORDER_LINE_KEY,
                			eleOMSOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY));
                	eleRSOrderLine.setAttribute("Status", eleStatus.getAttribute(KohlsPOCConstant.ATTR_STATUS));
                }
                eleRSOrderLine.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
				listOrderLineKeys.add(strOrderLineKey);

                //Added for OMNI Order Returns - start
                
                eleRSOrderLine.setAttribute("DeliveryMethod", eleOMSOrderLine.getAttribute("DeliveryMethod"));
                //Added for OMNI Order Returns - end
                log.debug("eleRSOrderLine line is "+XMLUtil.getElementXMLString(eleRSOrderLine));                
              }
            }
            }
        }
      }
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.mergeRSXmlWithOMSXml");
    return docRSXml;
  }

  
  
/**
   * Create By mrjoshi * 
   * @param docOMSXml
   */
  private void adjustPrimeLineNo(Document docOMSXml) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.adjustPrimeLineNo");
    if(log.isDebugEnabled()){
      log.debug("Input to adjustPrimeLineNo is: "+XMLUtil.getXMLString(docOMSXml));
    }
    int iPrimeLineNoIncrementFactor = 0;
    NodeList nlOrderLine = docOMSXml.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    for (int i=0; i< nlOrderLine.getLength(); i++){
      Element eleOrderLine = (Element)nlOrderLine.item(i);
      String sPrimeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
      int iPrimeLineNo = Integer.parseInt(sPrimeLineNo);
      String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
      Double dOrderedQty = 0.00;
      if(!YFCCommon.isVoid(dOrderedQty)){
        dOrderedQty = Double.parseDouble(sOrderedQty);
      }
      if( dOrderedQty == 0){
        iPrimeLineNoIncrementFactor = iPrimeLineNoIncrementFactor + 1;        
      }
      eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, String.valueOf(iPrimeLineNoIncrementFactor + iPrimeLineNo));
    }
    
    if(log.isDebugEnabled()){
      log.debug("after adjustment, OMS XML is: "+XMLUtil.getXMLString(docOMSXml));
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.adjustPrimeLineNo");
  }
  
  /**
   * Checks if RKC Event is present in the Env(transaction) if present KOHLS_CASH_REISSUE PROMOTION
   * is created
   * 
   * @param env
   * @param retSvcResponseDoc
   * @return
   * @throws Exception
   */
  Document createRKCPromotions(YFSEnvironment env, Document retSvcResponseDoc) throws Exception {

    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.createRKCPromotions");
    String sRKCEventID = (String) env.getTxnObject("GetActiveRKCEvent");
    if(!YFCCommon.isVoid(sRKCEventID)){
    KohlsPoCRKC rkc = new KohlsPoCRKC();
    String strCouponEventID = rkc.getRKCEventID(sRKCEventID);
    int countRkcEvent = rkc.getRKCEventCount(sRKCEventID);
    String strExpiryDate = sRKCEventID;
    if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(sRKCEventID)) {
      log.debug("docGetActiveRKCEvent" + sRKCEventID);
    }
    if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(strCouponEventID)) {
      log.debug("strCouponEventID" + strCouponEventID);
    }
    Element eleRoot = retSvcResponseDoc.getDocumentElement();
    String strIsMutliReceipt = "";
    strIsMutliReceipt = (String) env.getTxnObject("IsMultiReceipted");
    log.debug("strIsMutliReceipt" + strCouponEventID);
    
    if (countRkcEvent > 0 && (strIsMutliReceipt.equalsIgnoreCase(KohlsPOCConstant.NO)
        || KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPocFeature))) {
      Element elePromotions = (Element) XMLUtil.getChildElement(eleRoot, "Promotions");
      Element elePromotion = SCXmlUtil.createChild(elePromotions, "Promotion");
      elePromotion.setAttribute("PromotionApplied", "N");
      elePromotion.setAttribute("PromotionType", KohlsPOCConstant.KOHLS_CASH_REISSUE);
      elePromotion.setAttribute("PromotionId", "0");
      Element eleExtn = SCXmlUtil.createChild(elePromotion, "Extn");
      eleExtn.setAttribute("ExtnCouponEventID", strCouponEventID);
      eleExtn.setAttribute("ExtnExpiryDate", strExpiryDate);
    }
    else{
    	
    	if(log.isDebugEnabled()){
			 log.debug("strIsMutliReceipt" + strIsMutliReceipt);
    	}
    	String sTransDetails = (String) env
				.getTxnObject("TransDetails");
    	  
  	  String [] arrTranDetails=sTransDetails.split("-");
  	  String sGiftReceiptInd="";
  	  if(arrTranDetails.length==4)
  	  {
  	  if(!YFCCommon.isVoid(arrTranDetails[3]))
  		  
  		sGiftReceiptInd=arrTranDetails[3];
  	  }
  	  
    	
				if (countRkcEvent > 0
						&& (strIsMutliReceipt
								.equalsIgnoreCase(KohlsPOCConstant.YES))) {
					
		
					   if ((KohlsPOCConstant.FALSE.equals(sGiftReceiptInd)) || (sGiftReceiptInd.equals(""))) {
						     
					if(log.isDebugEnabled()){
						 log.debug("sTransDetails" + sTransDetails);
			    	}
						
					String sReturnOrderHeaderKey = getReturnOrderHeaderKey(
							sTransDetails, env);
					if(log.isDebugEnabled()){
						 log.debug("sReturnOrderHeaderKey" + sReturnOrderHeaderKey);
			    	}
					Document InDocGetOrderDetails = XMLUtil
							.createDocument(KohlsPOCConstant.ELEM_ORDER);
					Element eleOrderDetils = InDocGetOrderDetails
							.getDocumentElement();

					if(!YFCCommon.isVoid(sReturnOrderHeaderKey))
					{
					XMLUtil.setAttribute(eleOrderDetils,
							KohlsPOCConstant.ATTR_ORD_HDR_KEY,
							sReturnOrderHeaderKey);
					Document docGetOrderDetailsTemplate = XMLUtil
							.getDocument(KohlsPOCConstant.GET_ORDER_DETAILS_OUTPUT_TEMPLATE);

					Document docGetOrderDetailsOut = KOHLSBaseApi.invokeAPI(
							env, docGetOrderDetailsTemplate,
							KohlsPOCConstant.API_GET_ORDER_DETAILS,
							InDocGetOrderDetails);

					 if(log.isDebugEnabled()){
						 log.debug("docGetOrderDetailsOut" + SCXmlUtil.getString(docGetOrderDetailsOut));
						        }
				    
					if (!YFCCommon.isVoid(docGetOrderDetailsOut)) {
					
						Element elePromotionKCR = SCXmlUtil
								.getXpathElement(docGetOrderDetailsOut
										.getDocumentElement(),
										"//Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_REISSUE']");
						 if(log.isDebugEnabled()){
							 log.debug("elePromotionKCR" + SCXmlUtil.getString(elePromotionKCR));
							        }
						if (YFCCommon.isVoid(elePromotionKCR)) {
							Element elePromotions = (Element) XMLUtil
									.getChildElement(eleRoot, "Promotions");
							Element elePromotion = SCXmlUtil.createChild(
									elePromotions, "Promotion");
							elePromotion.setAttribute("PromotionApplied", "N");
							elePromotion.setAttribute("PromotionType",
									KohlsPOCConstant.KOHLS_CASH_REISSUE);
							elePromotion.setAttribute("PromotionId", "0");
							Element eleExtn = SCXmlUtil.createChild(
									elePromotion, "Extn");
							eleExtn.setAttribute("ExtnCouponEventID",
									strCouponEventID);
							eleExtn.setAttribute("ExtnExpiryDate",
									strExpiryDate);
						}

					}
					}
				}
				}
			}
    }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.createRKCPromotions");

    return retSvcResponseDoc;
  }
  
  /**
   * Create By mrjoshi * 
   * @param transactionNo
   * @return
   */
  public static String getStoreNumberFromTransactionNumber(String transactionNo) {
    log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getStoreNumberFromTransactionNumber");
     String storeNumber = "";
    if (!YFCCommon.isVoid(transactionNo))  {
       String transactionNbrLength = Integer.toString(transactionNo.length());
     if ("22".equals(transactionNbrLength)) {
        storeNumber = transactionNo.substring(12, 16);
       }
     }
    log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getStoreNumberFromTransactionNumber");
     return storeNumber;
   }
  
  public String getReturnOrderHeaderKey(String sTransDetails,YFSEnvironment env) throws Exception
  {
	  
	  log.beginTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getReturnOrderHeaderKey");
	      
	  String [] arrTranDetails=sTransDetails.split("-");
	  String sStore="";
	  String sTerminalID="";
	  String sOperator="";
	  String sReturnOrderHeaderKey="";
	  if(log.isDebugEnabled()){
			 log.debug("sTransDetails-->" + sTransDetails);
			        }
	  if(arrTranDetails.length>=3)
	  {
	  if(!YFCCommon.isVoid(arrTranDetails[0]))
	  {
		  sStore =arrTranDetails[0];
	  }
	  if(!YFCCommon.isVoid(arrTranDetails[1]))
	  {
		  sTerminalID=arrTranDetails[1];
	  }
	  if(!YFCCommon.isVoid(arrTranDetails[2]))
	  {
		  sOperator =arrTranDetails[2];
	  }
	  }
	  String sTerminalStatusDoc= "<GetPOSStatusList    OrganizationCode='"+sStore+"'  "
	  		+ "TerminalID='"+sTerminalID+"' OperatorID='"+ sOperator+ "'  TerminalType='kohls' />";
	  
	  if(log.isDebugEnabled()){
			 log.debug("sTerminalStatusDoc" + sTerminalStatusDoc);
			        }
	  Document inDoc = XMLUtil.getDocument(sTerminalStatusDoc);

	  if(log.isDebugEnabled()){
			 log.debug("sTerminalStatusDoc" + SCXmlUtil.getString(inDoc));
			        }
	  Document outDoc= KOHLSBaseApi.invokeAPI(env, "getTerminalStatusDetailsForPOS", inDoc);

	  if(log.isDebugEnabled()){
			 log.debug("sTerminalStatusDoc" + SCXmlUtil.getString(outDoc));
			        }
	  if(!YFCCommon.isVoid(outDoc))
	  {
		  
		  Element eleTerminalStatus = outDoc.getDocumentElement();
		   sReturnOrderHeaderKey=eleTerminalStatus.getAttribute("ReturnOrderHeaderKey");

			  if(log.isDebugEnabled()){
					 log.debug("sReturnOrderHeaderKey" + sReturnOrderHeaderKey);
					        }
	  }
	  log.endTimer("KohlsPoCCheckAndMergeOrderWithRSResponse.getReturnOrderHeaderKey");
	      
	  return sReturnOrderHeaderKey;
  }
}
