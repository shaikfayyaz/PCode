package com.kohls.poc.returns;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;

public class KohlsImportPOSOrderForPSA implements YIFCustomApi {

	private static final YFCLogCategory log = YFCLogCategory.instance(
			KohlsImportPOSOrderForPSA.class.getName());
	private  YIFApi api;
	
	public KohlsImportPOSOrderForPSA(){
		
	}
	public Document importPOSOrderForPSA(YFSEnvironment env, Document inXML) throws IOException, Exception {
		Document outputDoc=null;
		try {
			Element ordEle=inXML.getDocumentElement();
			String cleanRecptInd=KohlsXPathUtil.getString(ordEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
			//If not clean receipt, send RS response as-is 
			if (cleanRecptInd.equalsIgnoreCase(KohlsConstant.FALSE)||cleanRecptInd.trim()==null){
				return inXML;
			}
			Document impOrderDoc=XMLUtil.newDocument();
			XMLUtil.importElement(impOrderDoc, ordEle);
			
			
			if(log.isDebugEnabled())
				log.debug("importPOSOrderForPSA input doc: " + KohlsXMLUtil.getXMLString(impOrderDoc));
			
			Element impOrdDocEle=impOrderDoc.getDocumentElement();
			//Remove tenders available and other details from input
			Element tenderEle=(Element)impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.TENDERS_AVAILABLE_RETURN).item(0);
			XMLUtil.removeChild(impOrdDocEle, tenderEle);
//			Element deductEle=(Element)impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0);
//			XMLUtil.removeChild(impOrdDocEle, deductEle);
			XMLUtil.removeChild(impOrdDocEle, (Element)impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0));
			XMLUtil.removeChild(impOrdDocEle, (Element)impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_REPONSE_REASON_DESC).item(0));
			XMLUtil.removeChild(impOrdDocEle, (Element)impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_POC_ORDER).item(0));
		     
			 NodeList orderLineList = impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
			 Element orderLineEle=null;
			 for (int i = 0; i < orderLineList.getLength(); i++) {
				 orderLineEle = (Element) orderLineList.item(i);
				 //Fix for PR-623 - Start
				 setUnitPrice(orderLineEle);
				 if(log.isDebugEnabled()){
					 log.info("######### output3 XML setunit price #########"+ KohlsUtil.extractStringFromNode(orderLineEle));
				 }
				 //Fix for PR-623 - End
				 Element eleOrderItem = null;
				try {
					eleOrderItem = (Element)(XPathUtil.getNode(orderLineEle, KohlsXMLLiterals.E_ITEM));
				} catch (Exception e) {
					log.error("Exception in getNode - importPOSOrderForPSA of KohlsImportPOSOrderForPSA:"+e.getMessage());
				}
				String strItemId = eleOrderItem.getAttribute(KohlsConstant.A_ITEM_ID);
				Element itemEle=getItemExtnAttribs(env, strItemId);
				Element itemExtnEle=null;
				if(YFCCommon.isVoid(itemEle)){
					//Since sometimes RS trims leading 0, try with item id prefixed with 0
					strItemId="0"+strItemId;
					itemEle=getItemExtnAttribs(env, strItemId);
				}
				if(!YFCCommon.isVoid(itemEle)){
					//Set item id incase prefixed with 0 to enable TVS itg 
					eleOrderItem.setAttribute(KohlsConstant.A_ITEM_ID, strItemId);
					orderLineEle.setAttribute(KohlsConstant.A_ITEM_ID, strItemId);
					
					itemExtnEle=(Element)itemEle.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
					
					
					if(log.isDebugEnabled())
						log.debug("item element from itemlist: " + KohlsXMLUtil.getElementXMLString(itemEle));
					
					Element ordExtnEle=(Element)orderLineEle.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
					ordExtnEle.setAttribute("ExtnItemClass", itemExtnEle.getAttribute("ExtnClass"));
					ordExtnEle.setAttribute("ExtnItemDept", itemExtnEle.getAttribute("ExtnDept"));
					ordExtnEle.setAttribute("ExtnItemSubClass", itemExtnEle.getAttribute("ExtnSubClass"));
					ordExtnEle.setAttribute("ExtnVendorStyleNo", itemExtnEle.getAttribute("ExtnVendorStyleNo"));
					ordExtnEle.setAttribute("ExtnTaxProductCode", KohlsXPathUtil.getString(itemEle, "ClassificationCodes/@TaxProductCode"));
					//Start PR-661
					orderLineEle.setAttribute("TaxProductCode", KohlsXPathUtil.getString(itemEle, "ClassificationCodes/@TaxProductCode"));
					//End PR-661
					//Added for POS Import TVS Error - Start 
					String sEmpDiscCode=itemExtnEle.getAttribute(KohlsXMLLiterals.ATTR_EMP_DISC_CODE);
					Element eleReferences=XMLUtil.createChild(orderLineEle, KohlsPOCConstant.A_REFERENCES);
					Element eleReference=XMLUtil.createChild(eleReferences, KohlsPOCConstant.A_REFERENCE);
					eleReference.setAttribute(KohlsXMLLiterals.A_NAME, KohlsXMLLiterals.ATTR_EMP_DISC_CODE);
					if(!YFCCommon.isStringVoid(sEmpDiscCode)){
						eleReference.setAttribute(KohlsXMLLiterals.A_VALUE, sEmpDiscCode);
					}
					else{
					eleReference.setAttribute(KohlsXMLLiterals.A_VALUE, KohlsPOCConstant.BLANK);
					}
					//Added for POS Import TVS Error - End
				}
				
				
			 }
			 //Add ExtnReceiptId
			Document gravityInXML=(Document)env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
			String strExtnRecp=gravityInXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
			if (strExtnRecp.startsWith("0")){
				strExtnRecp=strExtnRecp.substring(1);
			}
			Element extnElement=(Element)impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
			extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, strExtnRecp);
			//MAD-395 importOrder changes Start
			log.debug("Checking if it is edge Deployemnt::"+ServerTypeHelper.amIOnEdgeServer());
			if(ServerTypeHelper.amIOnEdgeServer()){
				
				Element eleAdditionalInfo= SCXmlUtil.createChild(impOrdDocEle,KohlsXMLLiterals.E_YFCADDITIONALINFO);
				eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,KohlsXMLLiterals.V_MOTHERSHIP );
				 
			 }
			//MAD-395 importOrder changes End
			if(log.isDebugEnabled())
				log.debug("import readys doc: " + KohlsXMLUtil.getXMLString(impOrderDoc));
			
			KohlsPoCCommonAPIUtil.setQueryTimeOut(env, impOrdDocEle, true);
			Document impDoc=KohlsCommonUtil.invokeAPI(env, KohlsXMLLiterals.ORDERDETAILS_WITH_IMPORT_ORDER_TEMPLATE,"importOrder", impOrderDoc);
			
			if(log.isDebugEnabled())
				log.debug("import out  doc: " + KohlsXMLUtil.getXMLString(impDoc));
			
		//	Element impDocOrdEle=impDoc.getDocumentElement();
			
			/*Document yfcDocOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			Element yfcEleGetOrder = yfcDocOrder.getDocumentElement();
			yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, 
					impDocOrdEle.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE));
			yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, 
					impDocOrdEle.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE));
			yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, 
					impDocOrdEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
			//MAD-395 getOrderList changes Start
			log.debug("Checking if it is edge Deployemnt::"+ServerTypeHelper.amIOnEdgeServer());
			if(ServerTypeHelper.amIOnEdgeServer()){
				log.debug("If true creating order at CORP");
				Element eleAdditionalInfo= SCXmlUtil.createChild(yfcEleGetOrder,KohlsXMLLiterals.E_YFCADDITIONALINFO);
				eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,KohlsXMLLiterals.V_LOCALANDMOTHERSHIP);
				 
			 }
			*///MAD-395 getOrderList changes End
			outputDoc=impDoc;
			Element outputDocEle=outputDoc.getDocumentElement();
			
			Element isPOCOrderEle=XMLUtil.createChild(outputDoc.getDocumentElement(), KohlsXMLLiterals.E_POC_ORDER);
			XMLUtil.setNodeValue(isPOCOrderEle,KohlsConstant.FALSE);
			XMLUtil.importElement(outputDocEle, (Element)ordEle.getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0));
			XMLUtil.importElement(outputDocEle,(Element)ordEle.getElementsByTagName(KohlsXMLLiterals.E_REPONSE_REASON_DESC).item(0));
			XMLUtil.importElement(outputDocEle,(Element)ordEle.getElementsByTagName(KohlsXMLLiterals.TENDERS_AVAILABLE_RETURN).item(0));
			
			
			if(log.isDebugEnabled())
				log.debug("gravity send doc: " + KohlsXMLUtil.getXMLString(outputDoc));
		} catch(Exception ex) {
			//ex.printStackTrace();
			log.error("Exception in KohlsImportPOSOrderForPSA of KohlsImportPOSOrderForPSA. Details:"+ex.getMessage());
			 throw new YFCException(KohlsConstant.EXTN_OTHER);
		}
		
		return outputDoc;
	}
	
private  Element getItemExtnAttribs(YFSEnvironment env, String sItemID) throws Exception{
		
		Element eleItemEle=null;
		
		try{
			Document docItemListInput = XMLUtil.createDocument("Item");
			docItemListInput.getDocumentElement().setAttribute("ItemID", sItemID);
			
			// Output template for getItemList api
			Document docItemListOutputTemplate = XMLUtil
					.getDocument("<ItemList><Item TaxableFlag=''><Extn ExtnDept='' ExtnClass='' ExtnSubClass='' ExtnVendorStyleNo='' ExtnEmpDiscCode='' /><ClassificationCodes TaxProductCode='' /></Item></ItemList>");


			// Invoking getItemList api
			Document docItemListOutput = KohlsCommonUtil.invokeAPI(env,docItemListOutputTemplate, "getItemList",docItemListInput);
                        
			KohlsPoCCommonAPIUtil.setQueryTimeOut(env, docItemListInput.getDocumentElement(), false);
			
//			Document docItemListOutput=KohlsXMLUtil.getDocument("<ItemList> <Item> <Extn ExtnVendorStyleNo=\"\" ExtnSubClass=\"0051\" ExtnEmpDiscCode=\"\" ExtnDept=\"0026\" ExtnClass=\"0050\"/> <ClassificationCodes TaxProductCode=\"61000\"/> </Item> </ItemList>");
			eleItemEle=(Element)docItemListOutput.getElementsByTagName("Item").item(0);
			if(YFCCommon.isVoid(docItemListOutput)){
				YFSException yfsException = new YFSException();	
				yfsException.setErrorDescription("Value of getItemList is null");
				throw yfsException;
				
			}
			
		}catch(YFSException yfsException){
			log.error(yfsException);
	}
		return eleItemEle;
	}
	
	@Override
	public void setProperties(Properties arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	//Fix for PR-623 - Start
	private void setUnitPrice(Element orderLineEle) {
		log.beginTimer("######## KohlsImportPOSOrderForPSA.setUnitPrice ########");
		
		if(log.isDebugEnabled()){
			log.debug("Setting Unit Price for current Orderline : " +XMLUtil.getElementXMLString(orderLineEle));
		}
		try{
			Element eleLinePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_LINE_PRICE_INFO);
			Element eleOrderLineExtn = XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_EXTN);
			Double dUnitPrice = Double.valueOf(XMLUtil.getAttribute(eleLinePriceInfo, KohlsXMLLiterals.A_UNIT_PRICE));
			Double dExtnSimplePromoPrice = Double.valueOf(XMLUtil.getAttribute(eleOrderLineExtn, "ExtnSimplePromoPrice"));  
			Element eleLineCharges = XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_LINE_CHARGES);
			NodeList nlLineCharges = orderLineEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_CHARGE);
			Element eleLineCharge = null;
			if(nlLineCharges.getLength()>0 && (!dUnitPrice.equals(dExtnSimplePromoPrice))){
				for (int i = 0; i < nlLineCharges.getLength(); i++) {
					eleLineCharge = (Element) nlLineCharges.item(i);
					String strChargeName = XMLUtil.getAttribute(eleLineCharge, KohlsXMLLiterals.A_CHARGE_NAME);
					if(KohlsXMLLiterals.A_PROMO_DISCOUNT.equalsIgnoreCase(strChargeName)){
						eleLineCharges.removeChild(eleLineCharge);
						XMLUtil.setAttribute(eleLinePriceInfo, KohlsXMLLiterals.A_UNIT_PRICE, String.valueOf(dUnitPrice));
						XMLUtil.setAttribute(orderLineEle, KohlsXMLLiterals.A_INVOICED_EXTENDED_PRICE, String.valueOf(dExtnSimplePromoPrice));
						//PDB-1075 start
						//eleLinePriceInfo.setAttribute(KohlsXMLLiterals.A_LIST_PRICE, String.valueOf(dExtnSimplePromoPrice));
						eleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_CLEARANCE_AMT,String.valueOf(dUnitPrice));
						//PDB-1075 End
						XMLUtil.setAttribute(eleLineCharge, KohlsXMLLiterals.A_CHARGE_NAME,"LIDPromoDiscount");
					}
				}
			}
			
			//PR-1075 changes start
			/*Element eleAwards = XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_AWARDS);
			NodeList nlAward = orderLineEle.getElementsByTagName(KohlsXMLLiterals.E_AWARD);
			Element eleAward = null;
			if(nlAward.getLength()>0){
				for (int i = 0; i < nlAward.getLength(); i++) {
					eleAward = (Element) nlAward.item(i);
					if("Price".equalsIgnoreCase(XMLUtil.getAttribute(eleAward, KohlsXMLLiterals.A_DESCRIPTION))){
						eleAwards.removeChild(eleAward);
						eleLinePriceInfo.setAttribute(KohlsXMLLiterals.A_UNIT_PRICE, String.valueOf(dExtnSimplePromoPrice));
						eleLinePriceInfo.setAttribute("ListPrice", String.valueOf(dExtnSimplePromoPrice));
						orderLineEle.setAttribute(KohlsXMLLiterals.A_INVOICED_EXTENDED_PRICE, String.valueOf(dExtnSimplePromoPrice));
						eleOrderLineExtn.setAttribute("ExtnNonClearanceAmt",String.valueOf(dUnitPrice));
					}
				}
			}*/
			//PR-1075 changes End
		}catch(Exception e){
			log.error(e);
		}
		log.endTimer("######## KohlsImportPOSOrderForPSA.setUnitPrice ########");
	}
	//Fix for PR-623 - End

}
