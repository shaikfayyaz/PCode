/*
*
* Copyright 2016 Kohls All rights reserved.
* Parses the Return servce response, merges with the getorder details 
* Customer specific copyright notice     :Kohls
* File Name       : KohlsParseAndMergeOrderDetailsWithRSResponse.java
*
* Description     :Kohls POC Returns
*
* Version         : 1.0.0.
*
* Created Date    :30-DEC-2016
* 
* Modification History:Modified by, on date.
*/
package com.kohls.poc.returns;

import java.io.IOException;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.*;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.receipt.ReceiptUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
/**
 * 
 * @author Kohls POC Team
 *
 */
public class KohlsParseAndMergeOrderDetailsWithRSResponse implements YIFCustomApi {

	private static final YFCLogCategory log = YFCLogCategory.instance(
			KohlsParseAndMergeOrderDetailsWithRSResponse.class.getName());
	private  YIFApi api;
	
	/**
	 * 
	 * @throws YIFClientCreationException exception
	 */
	public KohlsParseAndMergeOrderDetailsWithRSResponse() throws YIFClientCreationException{		
		api = YIFClientFactory.getInstance().getLocalApi();
		
	}
	
	@Override
	public void setProperties(Properties arg0) throws Exception {

	}

	/**
	 * 
	 *@param env env
	 *@param retSvcResponseDoc RS Response
	 *@return Document response
	 * @throws Exception 
	 * @throws IOException 
	 */
	//verified
	public Document parseReturnServiceResponse(YFSEnvironment env, Document retSvcResponseDoc) throws IOException, Exception{
		if(YFCLogUtil.isDebugEnabled()){
			try {
				log.debug("######### parseReturnServiceResponse input XML #########"+ KohlsUtil.extractStringFromNode(retSvcResponseDoc));
			} catch (TransformerException e) {
				log.debug("TransformerException in parseReturnServiceResponse of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
			}
		}
		Document inXML=(Document)env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
//		System.out.println("inXML:" + XMLUtil.getXMLString(inXML));
		Document ordDetDoc=null;
		if (inXML!=null) {
			try {
				ordDetDoc=getOMSOrderDetails(env, inXML);
				
				//Adding logger condition check as per PRF-208
				if(log.isDebugEnabled())
					log.debug("getOMSOrderDetails in KohlsParseAndMergeOrderDetailsWithRSResponse:***" + XMLUtil.getXMLString(ordDetDoc));
			} catch (Exception e) {
				log.debug("Exception in getOMSOrderDetails of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
			}
		}
		if (ordDetDoc==null) {
			//Add pocReturn Order as false
			Element eleOTR = (Element)retSvcResponseDoc.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
			if(!YFCCommon.isVoid(eleOTR)){
			Element orderExtnEle=(Element) eleOTR.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
				orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, 
						XMLUtil.getElementXMLString((Element)eleOTR.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0)));
				
				Element eleDedOffers=XMLUtil.getChildElement(eleOTR, KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS);				
				NodeList nlDedOffer =null;
				if(!YFCCommon.isVoid(eleDedOffers)){
					nlDedOffer=eleDedOffers.getElementsByTagName(KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
				}
				
				if (!YFCCommon.isVoid(nlDedOffer) && nlDedOffer.getLength() > 0) {
					for (int i = 0; i <  nlDedOffer.getLength(); i++) {
						Element eleDedOffer = (Element) nlDedOffer.item(i);
                        NodeList nlCustomAttributes = retSvcResponseDoc.getElementsByTagName(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
                        Element eleCustomAttr;
                        if (!YFCCommon.isVoid(nlCustomAttributes) && nlCustomAttributes.getLength() > 0) {
                            eleCustomAttr = (Element) nlCustomAttributes.item(0);
                        } else {
                            eleCustomAttr = retSvcResponseDoc.createElement(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
                        }
                        Element eleLoyalCustDetails=(Element)eleDedOffer.getElementsByTagName(KohlsXMLLiterals.E_LOYALTY_CUSTOMER_DETAILS).item(0);
                        if(!YFCCommon.isVoid(eleLoyalCustDetails)) {
                              NodeList nlEveryNonKcEarnAmt = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_EVERY_NON_KC_EARN_AMT);
                              if (nlEveryNonKcEarnAmt.getLength() > 0) {
                                  Element eleEveryNonKcEarnAmt = (Element) nlEveryNonKcEarnAmt.item(0);
                                  String sEveryNonKcEarnAmt = eleEveryNonKcEarnAmt.getTextContent();
                                  eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_20, sEveryNonKcEarnAmt);
                              }
                              NodeList nlEveryKcEarnAmt = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_EVERY_KC_EARN_AMT);
                              if (nlEveryKcEarnAmt.getLength() > 0) {
                                  Element eleEveryKcEarnAmt = (Element) nlEveryKcEarnAmt.item(0);
                                  String sEveryKcEarnAmt = eleEveryKcEarnAmt.getTextContent();
                                  eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_19, sEveryKcEarnAmt);
                              }
                              NodeList nlLoyaltNum = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_LOYALTY_NUMBER);
                              if (nlLoyaltNum.getLength() > 0) {
                                  Element eleLoyaltNum = (Element) nlLoyaltNum.item(0);
                                  String sLoyaltNum = eleLoyaltNum.getTextContent();
                                  eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_18, sLoyaltNum);
                              }
                              //RMVP-530 Added Sephora BI number to Text1
                              NodeList nlPartnerRewardDetail = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_PARTNER_REWARD_DETAIL);
                              if (nlPartnerRewardDetail.getLength() > 0) {
                                  for (int j = 0; j < nlPartnerRewardDetail.getLength(); j++) {
                                      Element elePartnerRewardDetail = (Element) nlPartnerRewardDetail.item(j);
                                      String sPartner = elePartnerRewardDetail.getElementsByTagName(KohlsXMLLiterals.A_PARTNER).item(0).getTextContent();
                                      if (KohlsXMLLiterals.A_SEPHORA.equals(sPartner)) {
										  String partnerRewardsId = elePartnerRewardDetail.getElementsByTagName(KohlsXMLLiterals.A_PARTNER_REWARDS_ID).item(0).getTextContent();
										  log.debug("Added Sephora BI number to Text1 attribute - " + partnerRewardsId);
										  eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_1, partnerRewardsId);
                                      }
                                  }
                              }
                              eleOTR.appendChild(eleCustomAttr);
                        }
					}
				
				}	
				eleOTR.removeChild(eleOTR.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0));
				}
			//If this is PSA, perform importOrder
			String pocFeature=inXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_POC_FEATURE);//POCFeature="PSA"
			if (pocFeature.equalsIgnoreCase("PSA")){
				try{
					KohlsImportPOSOrderForPSA impCls=new KohlsImportPOSOrderForPSA();
					retSvcResponseDoc=impCls.importPOSOrderForPSA(env, retSvcResponseDoc);
				} catch (Exception ex) {
					log.error("Exception in KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+ex.getMessage());
					 throw new YFCException(KohlsConstant.EXTN_OTHER);
				}
				
			}
			return retSvcResponseDoc;
		}
		Document mergedOrderXML = null;
		try {
			mergedOrderXML = parseAndMergeReturnServiceResponse(env,ordDetDoc,retSvcResponseDoc);
		} catch (Exception e) {
			log.error("Exception in parseAndMergeReturnServiceResponse of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
		}
		if (mergedOrderXML!=null) {
			Element isPOCOrderEle=XMLUtil.createChild(mergedOrderXML.getDocumentElement(), KohlsXMLLiterals.E_POC_ORDER);
			XMLUtil.setNodeValue(isPOCOrderEle,KohlsConstant.TRUE);
		}
		return mergedOrderXML;
	}
	
	
	/**
	 * updates few parameter of the existing POC order based on Kohls return service response
	 * 
	 *@param env env
	 *@param ordDetailXml poc order details
	 *@param otrResponseXml rs response xml
	 *@return Document type 
	 * 
	 */
	private Document parseAndMergeReturnServiceResponse(YFSEnvironment env, Document ordDetailXml, Document otrResponseXml) {
		
		 Element eleOrder = (Element)ordDetailXml.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
		 Element eleOTR = (Element)otrResponseXml.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
		 eleOrder.setAttribute(KohlsXMLLiterals.A_OPERATOR_ID, eleOTR.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID));
		 NodeList orderLineList = eleOrder.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
		 NodeList otrLineList = eleOTR.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
		 //MAD-286 - Start
		 Element eleAddtionalInfo = XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
		 //MAD-286 - End
		 Element orderLineEle=null;
		 Element otrLineEle=null;
		 //Changes for PR-400 - Start
		 //String otrExtnReturnPrice=null;
		 //String otrExtnTaxableAmount=null;
		//Changes for PR-400 - End
		 boolean invokeChgOrder=false;
		 boolean addOrderLineItem=false;
		 boolean isChgOrdStatusReqd=false;
		 //Create changeOrder document
		 Document chgOrdDoc = null;
		try {
			chgOrdDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			
			Element chgOrdDocEle = chgOrdDoc.getDocumentElement();
			Element cheOrdLinesElement = XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_ORDER_LINES);
			//Contains the to append orderliens from RS Response
			Element otrTobeAddedOrdLinesElement = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_LINES).getDocumentElement();
			//Contains the orderlines that require status change
			Element chgStatuOrdLinesElement = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_LINES).getDocumentElement();
			
			 //loop through the original order for merge
			 for (int i = 0; i < orderLineList.getLength(); i++) {
				 orderLineEle = (Element) orderLineList.item(i);
				 Element eleOrderItem = null;
				 try {
					eleOrderItem = (Element)(XPathUtil.getNode(orderLineEle, KohlsXMLLiterals.E_ITEM));
				 } catch (Exception e) {
					log.error("Exception in getNode - parseAndMergeReturnServiceResponse of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
				 }
				 String ordPrimeLineNo=orderLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
				 String ordItemId = eleOrderItem.getAttribute(KohlsConstant.A_ITEM_ID);
				 addOrderLineItem=false;
				 for (int j = 0; j < otrLineList.getLength(); j++){
					 otrLineEle = (Element) otrLineList.item(j);
					 Element eleOtrItem=null;
					 
					//Added for Extn attributes --start	 
					 //Changes for PR-400 - Start
					// Element eleOtrExtn=null;
					 //Changes for PR-400 - End
					 try {
						 eleOtrItem = (Element)(XPathUtil.getNode(otrLineEle, KohlsXMLLiterals.E_ITEM));
						
						 String otrPrimeLineNo=otrLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
						 String otrItemId = eleOtrItem.getAttribute(KohlsConstant.A_ITEM_ID);
						
					
						 //Changes for PR-400 - Start
						// eleOtrExtn = (Element)(XPathUtil.getNode(otrLineEle,KohlsXMLLiterals.E_EXTN ));
						//  otrExtnReturnPrice=eleOtrExtn.getAttribute(KohlsConstant.A_EXTN_RETURN_PRICE);
						//  otrExtnTaxableAmount=eleOtrExtn.getAttribute(KohlsConstant.A_EXTN_TAXABLE_AMOUNT);
						//Changes for PR-400 - End
						//Added for Extn attributes --end	 
						 
						 if ( ordPrimeLineNo.equals(otrPrimeLineNo)){ 
							 //Due to RS first 0 trimming issue, compare with that string too for item id 
							 if (ordItemId.equals(otrItemId) || ordItemId.substring(1).equals(otrItemId)){
								//See if isReturnIndicator true
								 String ordIsReturned=orderLineEle.getAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM);
								 String otrIsReturned=otrLineEle.getAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM);
								 if (!ordIsReturned.equalsIgnoreCase(otrIsReturned)){
									 addOrderLineItem=true;
									 invokeChgOrder=true;
									 break;
								 }
							 } else { 
								 //Item got exchanged; add to order line IsLastExchangedInRs attribute, call ChangeOrderStatus for orderLineEle
								
								 otrLineEle.setAttribute(KohlsXMLLiterals.A_IS_LAST_EXCHANGED_IN_RS,  KohlsConstant.YES);
								 XMLUtil.importElement(otrTobeAddedOrdLinesElement, otrLineEle);
								 //Add it to changeOrderStatus orderLine input
								 Element chngStatusLineEle=orderStatusChangeOrdLineInput(env, orderLineEle);
								 Element lineStatus=(Element)orderLineEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_STATUS).item(0);
								 if(!YFCCommon.isVoid(lineStatus)){
									 String ordLineStsString=lineStatus.getAttribute(KohlsXMLLiterals.A_STATUS);
									 if (!YFCCommon.isVoid(ordLineStsString) && !ordLineStsString.equalsIgnoreCase(KohlsXMLLiterals.A_RETURN_CREATED_STATUS)){
										 isChgOrdStatusReqd=true; 
										 XMLUtil.importElement(chgStatuOrdLinesElement,chngStatusLineEle);
									 }
								 }
								 
							 }
						 } 
					} catch (Exception e) {
						log.error("Exception in looping of parseAndMergeReturnServiceResponse of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
					}
				 }
//				 System.out.println("New elements from OTR Resposen are: " + XMLUtil.getElementXMLString(otrTobeAddedOrdLinesElement));
				 if (addOrderLineItem) {
					 Element chgOrdLnEle = XMLUtil.createChild(cheOrdLinesElement, KohlsXMLLiterals.E_ORDER_LINE);
					 chgOrdLnEle.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));
					 chgOrdLnEle.setAttribute(KohlsXMLLiterals.A_SHIPNODE, orderLineEle.getAttribute(KohlsXMLLiterals.A_SHIPNODE)); 
					 chgOrdLnEle.setAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM, otrLineEle.getAttribute(KohlsXMLLiterals.A_IS_RETURNED_ITEM));
				
					
				 }
	
				}
			 
			 Element orderExtnEle=(Element) eleOrder.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
			 Element extnElement= (Element) eleOTR.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
			 Element extnOTRCustomAttrElement= (Element) eleOTR.getElementsByTagName(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES).item(0);
			 
			 Element eleCustomAttr=null;
			 String text13 = null;
			 String date9= null;
			 if(!YFCCommon.isVoid(extnOTRCustomAttrElement))
			 {
				 text13 = extnOTRCustomAttrElement.getAttribute(KohlsXMLLiterals.A_TEXT_13);
				 eleCustomAttr = ordDetailXml.createElement(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
				 eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_13,text13);
				 date9 = extnOTRCustomAttrElement.getAttribute( KohlsPOCConstant.ATTR_DATE_9 );
				 if( !YFCCommon.isVoid( date9 ) ) {
				 eleCustomAttr.setAttribute(KohlsPOCConstant.ATTR_DATE_9, date9);
				 }
				 eleOrder.appendChild(eleCustomAttr);
			 }

//			 orderExtnEle.setAttribute("ExtnDeductibleOffers", XMLUtil.getElementXMLString((Element)eleOTR.getElementsByTagName("DeductibleOffers").item(0)));
//			 System.out.println("extnElement: "+ XMLUtil.getElementXMLString(extnElement));
			 String strExtnDeductibleOffers = XMLUtil.getElementXMLString((Element)eleOTR.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0));
			 if (!YFCCommon.isVoid(strExtnDeductibleOffers)){
				 invokeChgOrder=true;
				 orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, extnElement.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE));
				 orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE, extnElement.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE));
				 orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, strExtnDeductibleOffers);
				 orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_PSA_STATUS, "");
				 
				 
				 Element eleDedOffers=XMLUtil.getChildElement(eleOTR, KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS);				
				 NodeList nlDedOffer =null;
				 if(!YFCCommon.isVoid(eleDedOffers)){
					nlDedOffer=eleDedOffers.getElementsByTagName(KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
				 }
					
				 if (!YFCCommon.isVoid(nlDedOffer) && nlDedOffer.getLength() > 0) {
					for (int i = 0; i <  nlDedOffer.getLength(); i++) {
						Element eleDedOffer = (Element) nlDedOffer.item(i);
							
						    Element eleLoyalCustDetails=(Element)eleDedOffer.getElementsByTagName(KohlsXMLLiterals.E_LOYALTY_CUSTOMER_DETAILS).item(0);	
						    if(!YFCCommon.isVoid(eleLoyalCustDetails)){
							   NodeList nlEveryNonKcEarnAmt = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_EVERY_NON_KC_EARN_AMT);
							   if (nlEveryNonKcEarnAmt.getLength() > 0) {
								   Element eleEveryNonKcEarnAmt = (Element) nlEveryNonKcEarnAmt.item(0);
								   String sEveryNonKcEarnAmt = eleEveryNonKcEarnAmt.getTextContent();
								   eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_20, sEveryNonKcEarnAmt);
							   }
							   NodeList nlEveryKcEarnAmt = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_EVERY_KC_EARN_AMT);
							   if (nlEveryKcEarnAmt.getLength() > 0) {
								   Element eleEveryKcEarnAmt = (Element) nlEveryKcEarnAmt.item(0);
								   String sEveryKcEarnAmt = eleEveryKcEarnAmt.getTextContent();
								   eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_19, sEveryKcEarnAmt);
							   }
							   NodeList nlLoyaltNum = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_LOYALTY_NUMBER);
							   if (nlLoyaltNum.getLength() > 0) {
								   Element eleLoyaltNum = (Element) nlLoyaltNum.item(0);
								   String sLoyaltNum = eleLoyaltNum.getTextContent();
								   eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_18, sLoyaltNum);
							   }
							   //RMVP -530 Add Sephora BI to Text1
                                NodeList nlPartnerRewardDetail = eleLoyalCustDetails.getElementsByTagName(KohlsXMLLiterals.A_PARTNER_REWARD_DETAIL);
                                if (nlPartnerRewardDetail.getLength() > 0) {
                                    for (int j = 0; j < nlPartnerRewardDetail.getLength(); j++) {
                                        Element elePartnerRewardDetail = (Element) nlPartnerRewardDetail.item(j);
                                        String sPartner = elePartnerRewardDetail.getElementsByTagName(KohlsXMLLiterals.A_PARTNER).item(0).getTextContent();
                                        if (KohlsXMLLiterals.A_SEPHORA.equals(sPartner)) {
											String partnerRewardsId = elePartnerRewardDetail.getElementsByTagName(KohlsXMLLiterals.A_PARTNER_REWARDS_ID).item(0).getTextContent();
											log.debug("Added Sephora BI number to Text1 attribute - " + partnerRewardsId);
                                            eleCustomAttr.setAttribute(KohlsXMLLiterals.A_TEXT_1, partnerRewardsId);
                                        }
                                    }
                                }
								XMLUtil.importElement(chgOrdDocEle, eleCustomAttr);
						    }
					}
				}
				 
				 XMLUtil.importElement(chgOrdDocEle, orderExtnEle);
			 }
				
			 if (invokeChgOrder){
				 //invoke change Order API
				 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, eleOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE));
				 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, eleOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE));
				 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
				 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
				 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsConstant.YES);
				 
				 if( !YFCCommon.isVoid( text13 ) || !YFCCommon.isVoid( date9 ) )
				 {
					 Element eleCustomAttrChgeOrd=null;
					 eleCustomAttrChgeOrd = chgOrdDoc.createElement(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
					 if( !YFCCommon.isVoid( text13 ) ) {
					     eleCustomAttrChgeOrd.setAttribute(KohlsXMLLiterals.A_TEXT_13, text13);
					 }
					 chgOrdDocEle.appendChild(eleCustomAttrChgeOrd);
					 if ( !YFCCommon.isVoid( date9 ) ) {
					     eleCustomAttrChgeOrd.setAttribute( KohlsPOCConstant.ATTR_DATE_9 , date9 ); 
					 }
					 chgOrdDocEle.appendChild( eleCustomAttrChgeOrd );
				 }
				 
				 
				 //PST-1568 - Start
				 chgOrdDocEle.setAttribute(KohlsPOCConstant.A_Select_Method, KohlsPOCConstant.SELECT_METHOD_WAIT);
				 //PST-1568 - End
				 try {
					 	//MAD-286 - Start
						  log.debug("Before ChangeOrder ::"+ServerTypeHelper.amIOnEdgeServer());
							if(ServerTypeHelper.amIOnEdgeServer()){
								retreiveEndpointAndSetToElementAttribute(
										eleAddtionalInfo, chgOrdDocEle);
								
							 }
						//MAD-286 - End 
						chgOrdDoc = KohlsCommonUtil.invokeAPI(env, KohlsXMLLiterals.CHG_ORDERDETAILS_FOR_RS_RESPONSE_TEMPLATE, KohlsConstants.CHANGE_ORDER_API, chgOrdDoc);
				 } catch (Exception e) {
					log.error("Exception in changeOrder invoke API of parseAndMergeReturnServiceResponse of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
					throw new YFCException(KohlsConstant.EXTN_OTHER); 
				}
			 } else {
				 chgOrdDoc =  XMLUtil.createDocument(ordDetailXml.getFirstChild());
			 }
			 
			 //change Order line status for returned items from RS Response
			 if (isChgOrdStatusReqd) {
				 Document ordStatusInDoc=orderStatusChangeInput(env, 
						 eleOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE),
						 eleOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE),
						 eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
				 
				 NodeList statusChgLineList = chgStatuOrdLinesElement.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
				 Element ordLineListEle=(Element)ordStatusInDoc.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);
				 
				 if(!YFCCommon.isVoid(statusChgLineList) || !YFCCommon.isVoid(ordLineListEle)){
					 for (int cnt=0;cnt <statusChgLineList.getLength();cnt ++) {
						 Element eleLineElement=(Element)statusChgLineList.item(cnt);
						 XMLUtil.importElement(ordLineListEle, eleLineElement);
					 }
				 }
				 
				 try {
				 	//MAD-286 - Start
						  log.debug("Before ChangeOrderStatus ::"+ServerTypeHelper.amIOnEdgeServer());
							if(ServerTypeHelper.amIOnEdgeServer()){
								retreiveEndpointAndSetToElementAttribute(
										eleAddtionalInfo, chgOrdDocEle);
								
							 }
						//MAD-286 - End 
					 //Adding logger condition check as per PRF-208
					 if(log.isDebugEnabled())
						 log.debug("changeOrderStatus input: " + XMLUtil.getXMLString(ordStatusInDoc));
					 
					 KohlsCommonUtil.invokeAPI(env, KohlsXMLLiterals.CHG_ORDERDETAILS_FOR_RS_RESPONSE_TEMPLATE, KohlsConstant.CHANGE_ORDER_STAT_API, ordStatusInDoc);
				 } catch (Exception e) {
					log.error("Exception in invokeAPI changeOrderStatus of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
				}
				 
			 }
			 
//			 Document inXML=(Document)env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
//			 chgOrdDoc=getOMSOrderDetails(env,  inXML);
//			 System.out.println("response from schgOrder XML\n" + XMLUtil.getXMLString(chgOrdDoc));
			 chgOrdDocEle = (Element)chgOrdDoc.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
			 Element cleanRecptInd=XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
			 XMLUtil.setNodeValue(cleanRecptInd,eleOTR.getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0).getTextContent());
			 Element trainingModeInd=XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_TRAINING_MODE_IND);
			 XMLUtil.setNodeValue(trainingModeInd,eleOTR.getAttribute(KohlsXMLLiterals.E_TRAINING_MODE_IND));
			 Element txnAvblAmount=XMLUtil.createChild(chgOrdDocEle,KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT);
			 XMLUtil.setNodeValue(txnAvblAmount,eleOTR.getAttribute(KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT));
			 Element responseReasonDesc=XMLUtil.createChild(chgOrdDocEle,KohlsXMLLiterals.E_REPONSE_REASON_DESC);
			 XMLUtil.setNodeValue(responseReasonDesc,eleOTR.getElementsByTagName(KohlsXMLLiterals.E_REPONSE_REASON_DESC).item(0).getTextContent());
			
			 
	//Added for Extn attributes --start	 
			 
	//Added for defect 3317-start  
			 
		   NodeList chgOrdLnEle = chgOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
		   Element eleOtrDiscounts = null;
		 //Changes for PR-400 - Start
		   Element eleOtrOrderLineExtn = null;
		   for ( int i = 0; i < chgOrdLnEle.getLength(); i++ )
         {
            Element chgOrdLnEleOtr = (Element) chgOrdLnEle.item( i );
            Element ReturnPriceAmt = XMLUtil.createChild( chgOrdLnEleOtr, KohlsXMLLiterals.E_RETURN_PRICE_AMOUNT );
            Element TaxableAmt = XMLUtil.createChild( chgOrdLnEleOtr, KohlsXMLLiterals.E_TAXABLE_AMOUNT );
           // otrLineEle = (Element) otrLineList.item( i );
            String sPrimeLineno=chgOrdLnEleOtr.getAttribute( KohlsPOCConstant.ATTR_PRIME_LINE_NO );
            otrLineEle = SCXmlUtil.getXpathElement(eleOTR, "OrderLines/OrderLine[@PrimeLineNo='"+sPrimeLineno+"']");
            //PR-621 - Start - Adding Null Check for otrLineEle
            if(!YFCCommon.isVoid(otrLineEle)){
            	eleOtrDiscounts = SCXmlUtil.getXpathElement( otrLineEle, KohlsXMLLiterals.E_DISCOUNTS );
            	eleOtrOrderLineExtn = (Element) otrLineEle.getElementsByTagName( KohlsPOCConstant.E_EXTN ).item( 0 );
            	if(!YFCCommon.isVoid( eleOtrOrderLineExtn )){
            		XMLUtil.setNodeValue( ReturnPriceAmt, eleOtrOrderLineExtn.getAttribute( KohlsConstant.A_EXTN_RETURN_PRICE ) );
            		XMLUtil.setNodeValue( TaxableAmt, eleOtrOrderLineExtn.getAttribute( KohlsConstant.A_EXTN_TAXABLE_AMOUNT ) );
            	}

            	if ( !YFCCommon.isVoid( eleOtrDiscounts ) )
            	{
            		chgOrdDoc.adoptNode( eleOtrDiscounts );
            		XMLUtil.appendChild( chgOrdLnEleOtr, eleOtrDiscounts );

            	}
            }else{
            	log.debug("The chgOrdLnEleOtr element value is " +XMLUtil.getElementXMLString(chgOrdLnEleOtr));
            	Element chgOrdLnExtnEle = XMLUtil.getChildElement(chgOrdLnEleOtr, "Extn");
            	log.debug("The chgOrdLnExtnEle element value is " +XMLUtil.getElementXMLString(chgOrdLnExtnEle));
            	if(!YFCCommon.isVoid(chgOrdLnExtnEle)){
            		XMLUtil.setNodeValue( ReturnPriceAmt, chgOrdLnExtnEle.getAttribute( KohlsConstant.A_EXTN_RETURN_PRICE ) );
            		XMLUtil.setNodeValue( TaxableAmt, chgOrdLnExtnEle.getAttribute( KohlsConstant.A_EXTN_TAXABLE_AMOUNT ) );
            	}
            }
            //PR-621 - End
         }
       //Changes for PR-400 - End
		 //Added for defect 3317-end  
	//Added for Extn attributes --end
		   
		   
		   
			
			 XMLUtil.importElement(chgOrdDocEle, (Element)eleOTR.getElementsByTagName(KohlsXMLLiterals.TENDERS_AVAILABLE_RETURN).item(0));	
			//Append orderline elements got from RS response that are potentially exchanged for gravity usage and check
			 NodeList toAddLineList = otrTobeAddedOrdLinesElement.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
			 Element ordLineListEle=(Element)chgOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);
			 
			 if(!YFCCommon.isVoid(toAddLineList) || !YFCCommon.isVoid(ordLineListEle)){
				 for (int cnt=0;cnt <toAddLineList.getLength();cnt ++) {
					 Element cv1=(Element)toAddLineList.item(cnt);
					 XMLUtil.importElement(ordLineListEle, cv1);
				 }
			 }
			 
			 //Adding logger condition check as per PRF-208
			 if(log.isDebugEnabled())
				 log.debug("response to gravity XML\n" + XMLUtil.getXMLString(chgOrdDoc));
			 
		} catch (ParserConfigurationException e) {
			log.error("ParserConfigurationException changeOrder build in parseAndMergeReturnServiceResponse of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
			 throw new YFCException(KohlsConstant.EXTN_OTHER);
		}
		 return chgOrdDoc;
	}
	
	private void retreiveEndpointAndSetToElementAttribute(
			Element eleAddtionalInfo, Element chgOrdDocEle) {
		Element eleAdditionalInfo= SCXmlUtil.createChild(chgOrdDocEle,KohlsXMLLiterals.E_YFCADDITIONALINFO);
		if(!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()){
			 eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT));
		}
	}
	/**
	 * 
	 *@param env env
	 *@param inXML input
	 *@return Document document
	 */
	//verified
	private Document getOMSOrderDetails(YFSEnvironment env, Document inXML){
		//PR-621 and PDB-277 - Start
	    log.beginTimer("KohlsParseAndMergeOrderDetailsWithRSResponse.getOMSOrderDetails");
	    Document outputDoc = null;
	    try {
	      Document ordINXML = getOMSOrderList(env, inXML);

	      if (ordINXML != null)
	      // Start - Check if order exists in OMS
	      {
	        Element rootEleOrd = ordINXML.getDocumentElement();
	        NodeList nlOrderList = (NodeList) rootEleOrd.getElementsByTagName(KohlsXMLLiterals.E_ORDER);
	        if (nlOrderList.getLength() > 0) {
	          log.debug("Order exist in OMS...");
	          Element eleOrder = (Element) nlOrderList.item(0);
	          Element eleOrderLines = (Element) eleOrder.getElementsByTagName("OrderLines").item(0);
	          NodeList nlOrderLine = eleOrder.getElementsByTagName("OrderLine");
	          if (nlOrderLine.getLength() > 0) {
	            for (int i = 0; i < nlOrderLine.getLength(); i++) {
	              Element eleOrderLine = (Element) nlOrderLine.item(i);
	              String sOrderedQty = eleOrderLine.getAttribute("OrderedQty");
	              if (!YFCCommon.isVoid(sOrderedQty)) {
	                Double dOrderedQty = Double.parseDouble(sOrderedQty);
	                if (dOrderedQty == 0.0D) {
	                  eleOrderLines.removeChild(eleOrderLine);
	                }
	              }
	            }
	          }
	          outputDoc = XMLUtil.createDocument(nlOrderList.item(0));
	        }
	      }
	      // End - Check if order exists in OMS
	    } catch (Exception yfc) {
	      log.error("Exception in getOMSOrderDetails invokeAPI of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"
	          + yfc.getMessage());
	    }
	    log.endTimer("KohlsParseAndMergeOrderDetailsWithRSResponse.getOMSOrderDetails");
	    //PR-621 and PDB-277 - End
	    return outputDoc;

	  }
	
	/**
	 * getOrderList API call with Extn/ExtnReceiptId
	 * @param env env
	 * @param inXML inxml with receipt id
	 * @return orderlist response document
	 */
	private Document getOMSOrderList(YFSEnvironment env, Document inXML) {

		Document outputDoc=null;
		try {
			Element eleInputOrder = inXML.getDocumentElement();
			String strEnterpriseCode = eleInputOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
			String strDocumentType = eleInputOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE);
			String strExtnRecp = eleInputOrder.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
			if (strExtnRecp.startsWith("0")){
				strExtnRecp=strExtnRecp.substring(1);
			}
			Document ordINXML=getOrderListInputXML(strExtnRecp,strEnterpriseCode, strDocumentType);
//			System.out.println("Order is " + XMLUtil.getXMLString(ordINXML));
			
			outputDoc = KohlsCommonUtil.invokeAPI(env,KohlsXMLLiterals.ORDERDETAILS_WITH_RS_RESPONSE_TEMPLATE, KohlsConstant.API_GET_ORDER_LIST, ordINXML);
//			System.out.println("outputDoc is " + XMLUtil.getXMLString(outputDoc));
			
		} catch (Exception yfc) {
			 log.error("Exception in getOMSOrderList of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+yfc.getMessage());
		}
		return outputDoc;
	}

	/**
	 * OrderStatusChange API call
	 * @param env
	 * @param strEnterpriseCode
	 * @param strDocumentType
	 * @param strOrderHeaderKey
	 * @return
	 */
	private Document orderStatusChangeInput(YFSEnvironment env, String strEnterpriseCode,
			String strDocumentType, String strOrderHeaderKey) {

		Document yfcDocOrderStatus=null;
		try {
			yfcDocOrderStatus = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_STATUS_CHANGE);
		
			Element yfcEleGetOrderStatus = yfcDocOrderStatus.getDocumentElement();
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_TRANSACTIONID, KohlsXMLLiterals.A_INCLUDE_IN_RETURN);
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_IGNORE_TRAN_DEPENDENCIES, KohlsConstant.YES);
			Element ordLinesEle=XMLUtil.createChild(yfcEleGetOrderStatus,KohlsXMLLiterals.E_ORDER_LINES);
			
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("orderStatusChangeInput Input :" + XMLUtil.getXMLString(yfcDocOrderStatus));
			}
	
		} catch(DOMException e){
			log.error("DOMException in getOrderListInputXML of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());		
		} catch (ParserConfigurationException e) {
			log.error("ParserConfigurationException in getOrderListInputXML of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
		}
		return yfcDocOrderStatus;
	}
	
	private Element orderStatusChangeOrdLineInput(YFSEnvironment env, Element orderLineEle) {

		Document yfcDocOrderLine=null;
		try {
			yfcDocOrderLine = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER_LINE);
		
			Element yfcEleGetOrderStatus = yfcDocOrderLine.getDocumentElement();
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_BASEDROPSTATUS, KohlsXMLLiterals.A_RETURN_CREATED_STATUS);
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_SUB_LINE_NO, orderLineEle.getAttribute(KohlsXMLLiterals.A_SUB_LINE_NO));
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_QUANTITY, orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDERED_QUANTITY));
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO, orderLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO));
			yfcEleGetOrderStatus.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));
			
			Element ordLineTranQtyEle=XMLUtil.createChild(yfcEleGetOrderStatus, KohlsXMLLiterals.A_ORDER_LINE_TRAN_QUANTITY);
			ordLineTranQtyEle.setAttribute(KohlsXMLLiterals.A_QUANTITY,  orderLineEle.getAttribute(KohlsXMLLiterals.A_ORDERED_QUANTITY));
			ordLineTranQtyEle.setAttribute(KohlsXMLLiterals.A_TRANSACTIONAL_UOM, KohlsConstant.UNIT_OF_MEASURE);
			
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("orderStatusChangeInput Input :" + XMLUtil.getXMLString(yfcDocOrderLine));
			}
	
		} catch(DOMException e){
			log.error("DOMException in orderStatusChangeOrdLineInput of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());		
		} catch (ParserConfigurationException e) {
			log.error("ParserConfigurationException in orderStatusChangeOrdLineInput of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
		}
		return yfcDocOrderLine.getDocumentElement();
	}
	
	/**
	 * Constructs input xml for getOrderList input xml
	 * 
	 * @param strExtnRecp receipt no
	 * @param strEnterpriseCode ent code
	 * @param strDocumentType doc type
	 * @return Document req document
	 */
	private Document getOrderListInputXML(String strExtnRecp, String strEnterpriseCode, String strDocumentType){		
		Document yfcDocOrder=null;
		try {
			yfcDocOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		
			Element yfcEleGetOrder = yfcDocOrder.getDocumentElement();
			yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
			yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);
			// Passing SellerOrganizationCode to make sure sterling Identifies the Shard correctly.
            String originalSaleStoreNumber = "";
            try {
              originalSaleStoreNumber = getStoreNumberFromTransactionNumber(ReceiptUtil.getTransactionIdFromReceiptID(strExtnRecp));
            } catch (Exception e){
              originalSaleStoreNumber = "";
            }
            if(!YFCCommon.isVoid(originalSaleStoreNumber)){
              yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, String.valueOf(Integer.parseInt(originalSaleStoreNumber)));
            }
			Element extnElement=XMLUtil.createChild(yfcEleGetOrder, KohlsXMLLiterals.E_EXTN);
			extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, strExtnRecp);
			
			extnElement.setAttribute(KohlsPOCConstant.EXTN_IS_LATEST, "Y");
			
			//MAD-286 - Start
			log.debug("Checking if it is edge Deployemnt::"+ServerTypeHelper.amIOnEdgeServer());
			if(ServerTypeHelper.amIOnEdgeServer()){
				Element eleAdditionalInfo= SCXmlUtil.createChild(yfcEleGetOrder,KohlsXMLLiterals.E_YFCADDITIONALINFO);
				eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_LOCALANDMOTHERSHIP);
			 }
			//MAD-286 - End 
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("getOrderDetails Input :" + XMLUtil.getXMLString(yfcDocOrder));
			}
	
		} catch(DOMException e){
			log.error("DOMException in getOrderListInputXML of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());		
		} catch (ParserConfigurationException e) {
			log.error("ParserConfigurationException in getOrderListInputXML of KohlsParseAndMergeOrderDetailsWithRSResponse. Details:"+e.getMessage());
		}
		return yfcDocOrder;
	}
	
	/**
	 * Constructs the getOrderDetails input xml
	 * 
	 *@param strOrderNo order number of the order
	 *@param strEnterpriseCode ent code
	 *@param strDocumentType document type
	 *@return Document input xml
	 */
	/*private Document getOrderInputXML(String strOrderNo, String strEnterpriseCode, String strDocumentType){		
		YFCDocument yfcDocOrder = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER);
		YFCElement yfcEleGetOrder = yfcDocOrder.getDocumentElement();
		yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ORDERNO, strOrderNo);		
		yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
		yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);

		if(YFCLogUtil.isDebugEnabled()){
			log.debug("getOrderDetails Input" + XMLUtil.getXMLString(yfcDocOrder.getDocument()));
		}

		return yfcDocOrder.getDocument();
	}*/
	
	 /**
	   * Create By mrjoshi * 
	   * @param transactionNo
	   * @return
	   */
	  public static String getStoreNumberFromTransactionNumber(String transactionNo) {
	    log.beginTimer("KohlsParseAndMergeOrderDetailsWithRSResponse.getStoreNumberFromTransactionNumber");
	     String storeNumber = "";
	    if (!YFCCommon.isVoid(transactionNo))  {
	       String transactionNbrLength = Integer.toString(transactionNo.length());
	     if ("22".equals(transactionNbrLength)) {
	        storeNumber = transactionNo.substring(12, 16);
	       }
	     }
	    log.endTimer("KohlsParseAndMergeOrderDetailsWithRSResponse.getStoreNumberFromTransactionNumber");
	     return storeNumber;
	   }
	
}
