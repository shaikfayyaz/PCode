/**
*
* Copyright 2016 Kohls All rights reserved.
* 
* Customer specific copyright notice     :General Desc of one line.
*
* File Name       : KohlsWayfairItemProcess.java
*
* Description     :Kohls POC Returns
*
* Version         : 1.0.0.
*
* Created Date    :10-Jan-2016
* 
* Modification History:Modified by, on date.
**/
package com.kohls.poc.returns;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * This program is invoked through a service. 
 * This invokes Kohls Wayfair item services, parses the response and
 * build Item kind of object for Gravity usage
 *@version 1.0
 *@author POC Returns Team
 *
 */
    
public class KohlsWayfairItemProcess implements YIFCustomApi {

	private YFCLogCategory log = YFCLogCategory.instance(KohlsWayfairItemProcess.class);
//	private  YIFApi api;
	private Properties props;
	
	/**
	 * Constructor for KohlsWayfairItemProcess
	 * @throws YIFClientCreationException exception
	 */
	public KohlsWayfairItemProcess() throws Exception{		
//		api = YIFClientFactory.getInstance().getLocalApi();
		 super();
	}
	
	/***	  
	 * This method parses gravity requests and build the web service request
	 * that is compatible with Kohls Wayfair item request
	 * 
	 *@param env env
	 *@param inXML input from Gravity
	 *@return Document Response to Gravity with Wayfiar response
	 *@throws Exception 
	 *@throws IOException 
	 */
	/*public Document parseGravityReqNBuildWayfairResp(YFSEnvironment env, Document inXML) throws IOException, Exception {
		
		Document wayFairResponseXml=connectToWayFairService(env,inXML);
		Document gravityReseponseXml=parseWayfairResponse(env, wayFairResponseXml);
		
		return gravityReseponseXml;
	}*/

	/**
	 * Connects to http url and returns value
	 * @param env env
	 * @param inXML input
	 * @return document
	 * @throws Exception exception
	 * @throws IOException ioexception
	 */
	/*
	private Document connectToWayFairService(YFSEnvironment env, Document inXML) throws Exception, IOException {
		
		Element itemEle=inXML.getDocumentElement(); 
		String upcCode=itemEle.getAttribute(KohlsXMLLiterals.A_LC_UPC);
		String itemID=itemEle.getAttribute(KohlsConstant.A_ITEM_ID);
		boolean productInfoByUPC=false;
		
		if (upcCode!=null && !upcCode.isEmpty()) {
			productInfoByUPC=true;
		} else if (itemID!=null && !itemID.isEmpty()){
			productInfoByUPC=false;
		}
		
		HttpClient srcClient = new HttpClient();
		String url="";
		String arg1="";
		
		if (productInfoByUPC) {
			if (!YFCCommon.isVoid(this.props.getProperty(KohlsXMLLiterals.A_INFO_BY_UPC_URL))) {
		          url=this.getPropertyValue(this.props.getProperty(KohlsXMLLiterals.A_INFO_BY_UPC_URL));
		    } 
			arg1=upcCode;
		} else {
			if (!YFCCommon.isVoid(this.props.getProperty(KohlsXMLLiterals.A_INFO_BY_SKU_URL))) {
		          url=this.getPropertyValue(this.props.getProperty(KohlsXMLLiterals.A_INFO_BY_SKU_URL));
		    }
			arg1=itemID;
		}
		
	    String uriString=new StringBuffer().append(url).append(KohlsXMLLiterals.A_WEBFAIR_URL_ARG1)
				  .append(arg1).append(KohlsXMLLiterals.A_WEBFAIR_URL_ARG2).toString();
//	    System.out.println("urlString1 " + uriString);
	    log.debug("urlString1 " + uriString);
//		uriString="http://www.thomas-bayer.com/sqlrest/CUSTOMER/22/";
//	    HttpGet request = new HttpGet(uriString);
//	    HttpResponse response = srcClient.execute(request);
//	    HttpEntity entity = response.getEntity();
//	    String responseString = EntityUtils.toString(entity, "UTF-8");
//	    System.out.println("str\n" + responseString);
	    HttpMethod openApiGet = new GetMethod(uriString);
	    try {
	    	if (!YFCCommon.isVoid(this.props.getProperty(KohlsConstant.V_OPEN_API_PROXY_HOST))
	    			&& YFCCommon.isVoid(this.props.getProperty(KohlsConstant.V_OPEN_API_PROXY_PORT))){
	    		srcClient.getHostConfiguration().setProxy(
	    				this.props.getProperty(KohlsConstant.V_OPEN_API_PROXY_HOST),
	    				Integer.parseInt(this.props.getProperty(KohlsConstant.V_OPEN_API_PROXY_PORT)));
	    	}
		} catch (Exception ex) {
			// problem with setting proxy, default to the following settings
			srcClient.getHostConfiguration().setProxy("proxy.kohls.com", 3128);
		}
	    srcClient.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());
	    srcClient.executeMethod(openApiGet);
		StringBuffer outputContents = new StringBuffer();
		char[] cbuf = new char[500];
		BufferedReader reader = null;
		reader = new BufferedReader(new InputStreamReader(openApiGet.getResponseBodyAsStream()));
		int retVal = 0;
		int currentIteration = 0;
		while (true) {
			retVal = reader.read(cbuf);
			if (retVal == -1) {
				break;
			}
			outputContents.append(String.valueOf(cbuf).substring(0, retVal));
			currentIteration++;
		}
		String responseString = outputContents.toString();
	   log.debug("str\n" + responseString);
	    Document wayfairRespXml=XMLUtil.getDocument(responseString);
	    
  	    return wayfairRespXml;
	}*/
	
	/**
	 * parses the response from wayfair service
	 * 
	 *@param env env
	 *@param inDoc input to parsers
	 *@return Document response document
	 *@throws Exception exception
	 */
	public Document parseWayfairResponse(YFSEnvironment env, Document respInDoc) throws Exception {
		Document itemDocument = null;
		try {
//			respInDoc=XMLUtil.getDocument("c:/temp/wayfairRsp1.xml");
			
			Element wayfairRspEle=respInDoc.getDocumentElement(); 
		  	  
		  	itemDocument = XMLUtil.createDocument(KohlsXMLLiterals.E_ITEM);
			
			Element itemElement = itemDocument.getDocumentElement();
			itemElement.setAttribute(KohlsXMLLiterals.A_ITEM_FOUND, KohlsXPathUtil.getString(wayfairRspEle, KohlsXMLLiterals.A_RSP_ITEM_FOUND));
			itemElement.setAttribute(KohlsXMLLiterals.A_ITEM_STATUS, KohlsXPathUtil.getString(wayfairRspEle, KohlsXMLLiterals.A_RSP_ITEM_STATUS));
			itemElement.setAttribute(KohlsXMLLiterals.A_MARKET_PLACE_ITEM, KohlsXPathUtil.getString(wayfairRspEle, KohlsXMLLiterals.A_RSP_MARKET_PLACE_ITEM));
			itemElement.setAttribute(KohlsXMLLiterals.A_ORIGINAL_PRICE, KohlsXPathUtil.getString(wayfairRspEle, KohlsXMLLiterals.A_RSP_ORIGINAL_PRICE));
			itemElement.setAttribute(KohlsXMLLiterals.A_SALE_PRICE, KohlsXPathUtil.getString(wayfairRspEle, KohlsXMLLiterals.A_RSP_SALE_PRICE));
			itemElement.setAttribute(KohlsXMLLiterals.A_SELLER_NAME, KohlsXPathUtil.getString(wayfairRspEle, KohlsXMLLiterals.A_RSP_SELLER_NAME));
			
			//System.out.println("out xml \n" + XMLUtil.getXMLString(itemDocument));
			log.debug("out xml \n" + XMLUtil.getXMLString(itemDocument));
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("parseWayfairResponse output XML : " + SCXmlUtil.getString(itemDocument));
			}
			
		} catch (Exception e) {
			log.error("Exception in invoking the parseWayfairResponse : " + e.getMessage());
		}
		return itemDocument;
	}

	 public void setProperties(Properties prop) {
	        try{
	        	this.props = prop;
	        }
	        catch(Exception e){
	        	log.error("Exception in setProperties of POCReturnWebServiceCaller. Details:"+e.getMessage());
	        }
	 }
	 
	 /**
     * This function is used to get the value for a property.
     * 
     * @param property
     *            name in string format
     * @return String propValue
     */
    public String getPropertyValue(String property) {

        String propValue;
        propValue = YFSSystem.getProperty(property);
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        return propValue;

    }
}
