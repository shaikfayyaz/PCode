/**
 * 
 * Copyright 2019 Kohls All rights reserved.
 * 
 * Customer specific copyright notice :General Desc of one line.
 * 
 * File Name : KohlsBuildRPandRSRequestFrmGravity.java
 * 
 * Description :Kohls POC Quick Returns
 * 
 * Version : 1.0.0.
 * 
 * Created Date :17-JAN-2019
 * 
 * Modification History:Modified by, on date.
 **/
package com.kohls.poc.returns;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kohls.common.util.KOHLSStringUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * This program is invoked from GetOrderDetailsWithRSResponse service. This invokes series of services to connect to Kohls
 * Return Pass and Return services, parses the response and build order object for Gravity usage
 * 
 * @version 1.0
 * @author POC Returns Team
 * 
 */
public class KohlsBuildRPandRSRequestFrmGravity implements YIFCustomApi {
	private Properties props;
	private static final YFCLogCategory log =
			YFCLogCategory.instance(KohlsBuildRPandRSRequestFrmGravity.class.getName());
	String strstoreNumber;
	String strterminalNumber;
	String strsequenceNumber;
	String strtrnTimeStamp;
	String strOrgCode;
	String strPOCFeature;
	String strReturnPass;
	String strRPReceiptPreferenceMethod;
	String strRPReceiptPreferenceEmailID;
	String strRPRefundMethod;
	boolean isDebitTenderEnabled = false;  
	String storeType;
	private static final String EXTN_IS_RESTRICTED_RETURN ="ExtnIsRestrictedReturn";

	@Override
	public void setProperties(Properties prop) throws Exception {
		this.props = prop;

	}

	/***
	 * This method parses gravity requests and build the web service request that is compatible with
	 * Return Pass. Gets the Quick return Pass transaction details and invoke Kohls Return service
	 * to get the complete original sale order details and send it back to Gravity.
	 * 
	 * @param env env
	 * @param inXML input from Gravity
	 * @return Document Response to Gravity with RS response
	 */
	@SuppressWarnings("rawtypes")
	public Document parseAndBuildGravityToRPandRS(YFSEnvironment env, Document inDoc)
			throws Exception {
		log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.parseAndBuildGravityToRPandRS");
		if (log.isDebugEnabled()) {
			log.debug(
					"Input in service parseAndBuildGravityToRPandRS: " + XMLUtil.getXMLString(inDoc));
		}
		Document docOutXML = null;
		String isReturnRestrictedReturnPass = null;
		Element inputEle = inDoc.getDocumentElement();
		String sFunction = inputEle.getAttribute(KohlsPOCConstant.FUNCTION);
		String currentStore = inputEle.getAttribute(KohlsXMLLiterals.A_CURRENT_STORE);
		//set LoyaltyStoreType
		setLoyaltyStoreType(env, currentStore);
		strReturnPass = inputEle.getAttribute(KohlsPOCConstant.RETURN_PASS_NO);
		if(!YFCCommon.isVoid(strReturnPass)){
			try{
				Document docRPResponse= getRpResponseDetails(env, inDoc);
				//Call RP to get the Return Pass Transaction and Item detai;ls.
				if(!YFCCommon.isVoid(docRPResponse) && docRPResponse.hasChildNodes()){
					Element eleRPResponse = docRPResponse.getDocumentElement();
					if(!YFCCommon.isVoid(eleRPResponse)){
						strRPReceiptPreferenceMethod = XMLUtil.getAttribute(eleRPResponse, KohlsPOCConstant.RECEIPT_PREFERENCE_METHOD);
						strRPReceiptPreferenceEmailID = XMLUtil.getAttribute(eleRPResponse, KohlsPOCConstant.RECEIPT_PREFERENCE_EMAIL_ID);
						strRPRefundMethod = XMLUtil.getAttribute(eleRPResponse, KohlsPOCConstant.REFUND_METHOD);
						env.setTxnObject(KohlsPOCConstant.RP_RECEIPT_PREF_METHOD, strRPReceiptPreferenceMethod);
						env.setTxnObject(KohlsPOCConstant.RP_RECEIPT_PREF_EMAIL_ID, strRPReceiptPreferenceEmailID);
						env.setTxnObject(KohlsPOCConstant.RP_REFUND_PREF_METHOD, strRPRefundMethod);
					}
					String sPassCodeStatus = XMLUtil.getAttribute(eleRPResponse, KohlsPOCConstant.STATUS_LC);
					String sReturnPassOrderNumber = XMLUtil.getAttribute(eleRPResponse, KohlsPOCConstant.ORDER_NUMBER);
					if(!YFCCommon.isVoid(sPassCodeStatus) && (KohlsPOCConstant.CREATED.equalsIgnoreCase(sPassCodeStatus)
							|| (KohlsPOCConstant.PARTIAL_USED.equalsIgnoreCase(sPassCodeStatus)))){
						Document docReferences = XMLUtil.createDocument(KohlsXMLLiterals.E_REFERENCES);
						Element eleReferences = docReferences.getDocumentElement();
						Map<String, Element> mapReturnPassTransactions = new HashMap<String, Element>();
						NodeList nlItems = docRPResponse.getElementsByTagName(KohlsPOCConstant.S_ITEM);
						if (!YFCCommon.isVoid(nlItems) && nlItems.getLength() > 0) {
							for (int i = 0; i < nlItems.getLength(); i++) {
								Element eleReturnPassitem = (Element) nlItems.item(i);
								//Update Orig Sale transaction details for RS input 
								Element eleReturnPassItemTransactionKey = XMLUtil.getChildElement(eleReturnPassitem, KohlsPOCConstant.TRANSACTION_KEY);
								String sLocationNumber = XMLUtil.getAttribute(eleReturnPassItemTransactionKey, KohlsPOCConstant.LOCATION_NUMBER);
								String sDeviceId = XMLUtil.getAttribute(eleReturnPassItemTransactionKey, KohlsPOCConstant.DEVICE_ID);
								String sTransactionNumber = XMLUtil.getAttribute(eleReturnPassItemTransactionKey, KohlsPOCConstant.TRANSACTION_NUMBER);
								String sTransactionTimestamp = XMLUtil.getAttribute(eleReturnPassItemTransactionKey, KohlsPOCConstant.TRANSACTION_TIME_STAMP);
								//Update RP service's time format to RS service's time format
								if(!sTransactionTimestamp.contains(KohlsPOCConstant.CONST_T)){
									SimpleDateFormat toFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
									SimpleDateFormat currentFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
									sTransactionTimestamp = toFormat.format(currentFormat.parse(sTransactionTimestamp)).toString();
								}
								if(!YFCCommon.isVoid(sLocationNumber) && !YFCCommon.isVoid(sDeviceId) && 
										!YFCCommon.isVoid(sTransactionNumber) && !YFCCommon.isVoid(sTransactionTimestamp)){
									//Map condition to avoid duplicate RS call
									String sKey = sLocationNumber + KohlsPOCConstant.UNDERSCORE + sDeviceId + KohlsPOCConstant.UNDERSCORE + sTransactionNumber
											+ KohlsPOCConstant.UNDERSCORE + sTransactionTimestamp;
									if (!mapReturnPassTransactions.containsKey(sKey)) {
										Document docItems = XMLUtil.createDocument(KohlsPOCConstant.S_ITEMS);
										Element eleItems = docItems.getDocumentElement();
										eleItems.appendChild(docItems.importNode(eleReturnPassitem, true));
										mapReturnPassTransactions.put(sKey, eleItems);
									} else {
										Element eleItems = mapReturnPassTransactions.get(sKey);
										eleItems.appendChild(eleItems.getOwnerDocument().importNode(eleReturnPassitem, true));
										mapReturnPassTransactions.put(sKey, eleItems);
									}
								}
							}
						}
						if(!YFCCommon.isVoid(mapReturnPassTransactions) && !mapReturnPassTransactions.isEmpty() && mapReturnPassTransactions.size()>0){
							Iterator itReturnPassTransactionsMap = mapReturnPassTransactions.entrySet().iterator();
							while (itReturnPassTransactionsMap.hasNext()) {
								Map.Entry itReturnPassTransactionsMapPair = (Map.Entry) itReturnPassTransactionsMap.next();
								String strMapKey = (String) itReturnPassTransactionsMapPair.getKey();
								Element eleMapValue = (Element) itReturnPassTransactionsMapPair.getValue();
								if(strMapKey.contains(KohlsPOCConstant.UNDERSCORE)){
									String [] delimitTransaction = strMapKey.split(KohlsPOCConstant.UNDERSCORE);
									XMLUtil.setAttribute(inputEle, KohlsXMLLiterals.A_STORE_NUMBER, delimitTransaction[0]);  
									XMLUtil.setAttribute(inputEle, KohlsXMLLiterals.A_TERMINAL_ID, delimitTransaction[1]);
									if(!YFCCommon.isVoid(delimitTransaction[2]) && delimitTransaction[2].length()<4){
										delimitTransaction[2] = KOHLSStringUtil.prepadStringWithZeros(delimitTransaction[2], 4);
									}
									XMLUtil.setAttribute(inputEle, KohlsXMLLiterals.TRANSACTION_NBR, delimitTransaction[2]);
									XMLUtil.setAttribute(inputEle, KohlsXMLLiterals.A_TRANS_TIME_STAMP, delimitTransaction[3]);
									if(!YFCCommon.isVoid(eleMapValue)){
										inputEle.appendChild(inDoc.importNode(eleMapValue, true));
										env.setTxnObject(KohlsPOCConstant.RETURN_PASS_ITEMS, eleMapValue);
										env.setTxnObject(KohlsPOCConstant.RETURN_PASS_NUMBER, strReturnPass);
									}
									//Set Receipt ID for Return Pass.
									String strStoreRPReceiptID = XMLUtil.getAttribute(eleRPResponse, KohlsPOCConstant.RECEIPT_ID);
									if(!YFCCommon.isVoid(strStoreRPReceiptID)){
										XMLUtil.setAttribute(inputEle, KohlsXMLLiterals.A_ORDER_NO, strStoreRPReceiptID);
									}
									else{
										XMLUtil.setAttribute(inputEle, KohlsXMLLiterals.A_ORDER_NO, KohlsPOCConstant.BLANK);
									}
									//Call RS to Get Original Sale order details.
									if(YFCCommon.isVoid(docOutXML)){
										docOutXML = getGravityRequestAndBuildRSReq(env, inDoc);
										createOrderReferenceWithOrigSaleDetails(inputEle, eleReferences, docOutXML, delimitTransaction);
										
									//Check for Return Restriction 
										Element eleOutXml = docOutXML.getDocumentElement();
										Element eleOutXMLExtn = XMLUtil.getChildElement(eleOutXml, KohlsPOCConstant.E_EXTN);
										isReturnRestrictedReturnPass = eleOutXMLExtn.getAttribute(EXTN_IS_RESTRICTED_RETURN);
										 if(isReturnRestrictedReturnPass.equalsIgnoreCase(KohlsConstant.TRUE))
										 {
											 isReturnRestrictedReturnPass = "true"; 
										 }
									}else{
										Document docRSOutput =getGravityRequestAndBuildRSReq(env, inDoc);
										docOutXML = checkAndUpdateDeductibleOffers(docRSOutput, docOutXML, env,currentStore);
										// true and then set value of extnRestricted = true
										Element eleRSOutput = docRSOutput.getDocumentElement();
										Element eleRSOutputExtn = XMLUtil.getChildElement(eleRSOutput, KohlsPOCConstant.E_EXTN);
										
										if(!isReturnRestrictedReturnPass.equalsIgnoreCase(KohlsConstant.TRUE))
										{
											isReturnRestrictedReturnPass = eleRSOutputExtn.getAttribute(EXTN_IS_RESTRICTED_RETURN);
										 if(isReturnRestrictedReturnPass.equalsIgnoreCase(KohlsConstant.TRUE))
										 {
											 isReturnRestrictedReturnPass = "true"; 
											 
										 }
										}
										Element eleRSOrderLines = XMLUtil.getChildElement(eleRSOutput, KohlsPOCConstant.ELEM_ORDER_LINES);
										Element eleOutOrderLines = XMLUtil.getChildElement(docOutXML.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
										if(!YFCCommon.isVoid(eleOutOrderLines) && eleOutOrderLines.hasChildNodes()){
											NodeList nlRSOrderLines = eleRSOrderLines.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
											if (!YFCCommon.isVoid(nlRSOrderLines) && nlRSOrderLines.getLength() > 0) {
												for (int l = 0; l < nlRSOrderLines.getLength(); l++) {
													Element eleRSOrderLine = (Element) nlRSOrderLines.item(l);
													if(!YFCCommon.isVoid(eleRSOrderLine)){
														eleOutOrderLines.appendChild(docOutXML.importNode(eleRSOrderLine, true));
													}
												}
											}
										}
										createOrderReferenceWithOrigSaleDetails(inputEle, eleReferences, docRSOutput, delimitTransaction);
									}
								}
							}
							Element eleOutXML = docOutXML.getDocumentElement();
							Element eleOutXMLExtn = XMLUtil.getChildElement(eleOutXML, KohlsPOCConstant.E_EXTN);
							if(isReturnRestrictedReturnPass.equalsIgnoreCase(KohlsConstant.TRUE))
							 {
								eleOutXMLExtn.setAttribute(EXTN_IS_RESTRICTED_RETURN, KohlsConstant.TRUE); 
							 }
							eleOutXML.setAttribute(KohlsPOCConstant.RETURN_PASS_NO, strReturnPass);
							eleOutXML.appendChild(docOutXML.importNode(eleReferences, true));
							if(!YFCCommon.isVoid(sReturnPassOrderNumber) && sReturnPassOrderNumber.length()>4 && strReturnPass.startsWith(KohlsPOCConstant.RO)){
								eleOutXML.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sReturnPassOrderNumber);
								eleOutXML.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO, sReturnPassOrderNumber.substring(sReturnPassOrderNumber.length()-4));
							}
							mergeRPDetailsWithRSOutput(env, docRPResponse, eleOutXML);
						}
					}else{
						String sErrorDesc = KohlsPOCConstant.INVALID_RETURN_PASS_STATUS_ERROR_DESC+sPassCodeStatus;
						throw new YFSException(sErrorDesc,KohlsPOCConstant.ERROR_PREFIX+sFunction,sErrorDesc);
					}
				}
			}
			catch(Exception e){
				log.info("KohlsBuildRPandRSRequestFrmGravity.parseAndBuildGravityToRPandRS - Error while Processing Return Pass "+strReturnPass);
				try{
					String errorDescription = ((YFSException) e).getErrorDescription();
					String errorCode = ((YFSException) e).getErrorCode();
					if(!YFCCommon.isVoid(errorDescription) && "404".equalsIgnoreCase(errorCode)){
						JsonParser parserJSON = new JsonParser();
						JsonObject rootObj = parserJSON.parse(errorDescription).getAsJsonObject();
						JsonObject statusObj = rootObj.getAsJsonObject(KohlsPOCConstant.STATUS_LC);
						String message = statusObj.get(KohlsPOCConstant.E_MESSAGE).getAsString();
						throw new YFSException(message, errorCode+KohlsPOCConstant.UNDERSCORE+sFunction, message);
					}else{
						throw new YFSException(e.getMessage());
					}
				}
				catch (Exception exe){
					if("404".equalsIgnoreCase(((YFSException) e).getErrorCode())){
						throw exe;
					}else{
						throw new YFSException(e.getMessage());
					}
				}
			}
		}
		log.endTimer("KohlsBuildRPandRSRequestFrmGravity.parseAndBuildGravityToRPandRS");
		return docOutXML;
	}

	/**
	 * Create By ibmadmin * 
	 * @param docCurrentOrder
	 * @param docExistingOrder
	 * @param currentStore 
	 * @return
	 * @throws Exception
	 */
	private Document checkAndUpdateDeductibleOffers(Document docCurrentOrder, Document docExistingOrder,YFSEnvironment env, String currentStore) throws Exception {
		log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.checkAndUpdateDeductibleOffers");
		try{
			Element eleCurrentOrder = docCurrentOrder.getDocumentElement();
			Element eleCurrentOrderExtn = XMLUtil.getChildElement(eleCurrentOrder, KohlsPOCConstant.E_EXTN);
			String strCurrentOrderExtnDeductibleOffers = XMLUtil.getAttribute(eleCurrentOrderExtn, KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS);
			if(!YFCCommon.isVoid(strCurrentOrderExtnDeductibleOffers)){
				Document docCurrentDeductibleOffers = XMLUtil.getDocument(strCurrentOrderExtnDeductibleOffers);
				Element eleCurrentDeductibleOffers = docCurrentDeductibleOffers.getDocumentElement();
				Element eleCurrentDeductibleOffer = XMLUtil.getChildElement(eleCurrentDeductibleOffers, KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
				if(!YFCCommon.isVoid(eleCurrentDeductibleOffer)){
					Element eleExistingOrder = docExistingOrder.getDocumentElement();
					Element eleExistingOrderExtn = XMLUtil.getChildElement(eleExistingOrder, KohlsPOCConstant.E_EXTN);
					String strExistingOrderExtnDeductibleOffers = XMLUtil.getAttribute(eleExistingOrderExtn, KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS);
					if(YFCCommon.isVoid(strExistingOrderExtnDeductibleOffers)){
						XMLUtil.setAttribute(eleExistingOrderExtn, KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, strCurrentOrderExtnDeductibleOffers);
						return docExistingOrder;
					}
					else if(!YFCCommon.isVoid(strExistingOrderExtnDeductibleOffers)){
						Document docExistingDeductibleOffers = XMLUtil.getDocument(strExistingOrderExtnDeductibleOffers);
						Element eleExistingDeductibleOffers = docExistingDeductibleOffers.getDocumentElement();
						Element eleExistingDeductibleOffer = XMLUtil.getChildElement(eleExistingDeductibleOffers, KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
						if(YFCCommon.isVoid(eleExistingDeductibleOffer)){
							XMLUtil.setAttribute(eleExistingOrderExtn, KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, strCurrentOrderExtnDeductibleOffers);
							return docExistingOrder;
						}

						String sRuleValue = KohlsPoCCommonAPIUtil.getRuleValue( env, KohlsPOCConstant.KOHLS_ENABLE_MRR_KOHLS_CASH, currentStore, KohlsPOCConstant.NO );
						
						// If its Loyalty V2 then appending the Deductible Offer to existing deductible offer.
						if((KohlsPOCConstant.LOYALTY_STORE_V2_PILOT.equalsIgnoreCase(storeType) || KohlsPOCConstant.LOYALTY_STORE_V2_NON_PILOT.equalsIgnoreCase(storeType)) && 
						 KohlsPOCConstant.YES.equalsIgnoreCase( sRuleValue ) ) {
						  XMLUtil.importElement(eleExistingDeductibleOffers, eleCurrentDeductibleOffer);
						  if(log.isDebugEnabled()) {
						    log.debug("Appending deductible offers to existing deductible offers"+ XMLUtil.getXMLString(docExistingDeductibleOffers));
						  }
						  XMLUtil.setAttribute(eleExistingOrderExtn, KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, XMLUtil.getXMLString(docExistingDeductibleOffers));
						  
						} else if(!YFCCommon.isVoid(docCurrentDeductibleOffers.getElementsByTagName(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID).item(0)) &&
								!YFCCommon.isVoid(docExistingDeductibleOffers.getElementsByTagName(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID).item(0))){
							String sCurrentIndividualOfferId = ((Element) docCurrentDeductibleOffers.
									getElementsByTagName(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID).item(0)).getTextContent();
							String sExistingIndividualOfferId = ((Element) docExistingDeductibleOffers.
									getElementsByTagName(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID).item(0)).getTextContent();
							if(!YFCCommon.isVoid(sCurrentIndividualOfferId) && !YFCCommon.isVoid(sExistingIndividualOfferId) &&
									sCurrentIndividualOfferId.equalsIgnoreCase(sExistingIndividualOfferId)){
								String sLoyaltyID = "";
								Element eleLoyaltyCustomer = (Element) docCurrentDeductibleOffers.getElementsByTagName(KohlsXMLLiterals.E_LOYALTY_CUSTOMER_DETAILS).item(0);
								if(!YFCCommon.isVoid(eleLoyaltyCustomer)) {
									sLoyaltyID = (eleLoyaltyCustomer.getElementsByTagName(KohlsXMLLiterals.A_LOYALTY_NUMBER).item(0)).getTextContent();
									if((YFCCommon.isVoid(sLoyaltyID) && !KohlsPOCConstant.LOYALTY_STORE_V2_PILOT.equalsIgnoreCase(storeType) 
											&& !KohlsPOCConstant.LOYALTY_STORE_V2_NON_PILOT.equalsIgnoreCase(storeType))
									         || ((KohlsPOCConstant.LOYALTY_STORE_V2_PILOT.equalsIgnoreCase(storeType) || KohlsPOCConstant.LOYALTY_STORE_V2_NON_PILOT.equalsIgnoreCase(storeType)) && 
						                   KohlsPOCConstant.NO.equalsIgnoreCase( sRuleValue ))){
										throw new YFSException(KohlsPOCConstant.SHARED_KCS_ERROR,KohlsPOCConstant.RP_CUSTOM_ERROR,KohlsPOCConstant.SHARED_KCS_ERROR);
									}
								}else{
									throw new YFSException(KohlsPOCConstant.SHARED_KCS_ERROR,KohlsPOCConstant.RP_CUSTOM_ERROR,KohlsPOCConstant.SHARED_KCS_ERROR);
								}
							}
						}
					}
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		} 
		log.endTimer("KohlsBuildRPandRSRequestFrmGravity.checkAndUpdateDeductibleOffers");
		return docExistingOrder;
	}

	/**
	 * Create By ibmadmin * 
	 * @param env
	 * @param docRPResponse
	 * @param eleOutXML
	 */
	private void mergeRPDetailsWithRSOutput(YFSEnvironment env, Document docRPResponse, Element eleOutXML) {
		log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.mergeRPDetailsWithRSOutput");
		Element eleOrderLines = (Element) eleOutXML.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES).item(0);
		if(YFCCommon.isVoid(eleOrderLines) || (!YFCCommon.isVoid(eleOrderLines) && !eleOrderLines.hasChildNodes())){
			throw new YFSException(KohlsPOCConstant.RP_NO_ELIGIBLE_ITEM_ERROR,KohlsPOCConstant.RP_CUSTOM_ERROR,KohlsPOCConstant.RP_NO_ELIGIBLE_ITEM_ERROR);
		}else{
			NodeList nlRSOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			if (!YFCCommon.isVoid(nlRSOrderLines) && nlRSOrderLines.getLength() > 0) {
				boolean isNoEligibleItemInReturnPass = true;
				for (int l = 0; l < nlRSOrderLines.getLength(); l++) {
					Element eleEligibleOrderLine = (Element) nlRSOrderLines.item(l);
					if(!YFCCommon.isVoid(eleEligibleOrderLine)){
						String sIsReturnedItem = XMLUtil.getAttribute(eleEligibleOrderLine, KohlsPOCConstant.IS_RETURNED_ITEM);
						if(!YFCCommon.isVoid(sIsReturnedItem) && "N".equalsIgnoreCase(sIsReturnedItem)){
							isNoEligibleItemInReturnPass = false;
						}
					}
				}
				if(isNoEligibleItemInReturnPass){
					throw new YFSException(KohlsPOCConstant.RP_NO_ELIGIBLE_ITEM_ERROR,KohlsPOCConstant.RP_CUSTOM_ERROR,KohlsPOCConstant.RP_NO_ELIGIBLE_ITEM_ERROR);
				}
			}
		}
		Element  eleRPResponse = docRPResponse.getDocumentElement();
		if(!YFCCommon.isVoid(eleRPResponse) && !YFCCommon.isVoid(eleOutXML)){
			Element eleCustomerInfo = XMLUtil.getChildElement(eleRPResponse, KohlsPOCConstant.CUSTOMER_INFO);
			String strCustomerEmailID = XMLUtil.getAttribute(eleCustomerInfo, KohlsPOCConstant.EMAIL_ID);
			String strCustomerLoyaltyID = XMLUtil.getAttribute(eleCustomerInfo, KohlsPOCConstant.LOYALTY_ID);
			String strCustomerProfileID = XMLUtil.getAttribute(eleCustomerInfo, KohlsPOCConstant.PROFILE_ID);

			XMLUtil.setAttribute(eleOutXML, KohlsPOCConstant.RP_RECEIPT_PREF_METHOD, strRPReceiptPreferenceMethod);
			XMLUtil.setAttribute(eleOutXML, KohlsPOCConstant.RP_RECEIPT_PREF_EMAIL_ID, strRPReceiptPreferenceEmailID);
			XMLUtil.setAttribute(eleOutXML, KohlsPOCConstant.RP_REFUND_PREF_METHOD, strRPRefundMethod);
			XMLUtil.setAttribute(eleOutXML, KohlsPOCConstant.RP_CUSTOMER_EMAIL_ID, strCustomerEmailID);
			XMLUtil.setAttribute(eleOutXML, KohlsPOCConstant.RP_CUSTOMER_LOYALTY_ID, strCustomerLoyaltyID);
			XMLUtil.setAttribute(eleOutXML, KohlsPOCConstant.RP_CUSTOMER_PROFILE_ID, strCustomerProfileID);
			Element eleOutXMLExtn = XMLUtil.getChildElement(eleOutXML, KohlsPOCConstant.E_EXTN);
			String strExtnReceiptID = XMLUtil.getAttribute(eleOutXMLExtn, KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);
			if(YFCCommon.isVoid(strExtnReceiptID)){
				if(!YFCCommon.isVoid((String)env.getTxnObject(KohlsPOCConstant.RP_RECEIPT_ID))){
					XMLUtil.setAttribute(eleOutXMLExtn, KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID, (String)env.getTxnObject(KohlsPOCConstant.RP_RECEIPT_ID));
				}
			}
		}
		log.endTimer("KohlsBuildRPandRSRequestFrmGravity.mergeRPDetailsWithRSOutput");
	}

	/**
	 * Create By ibmadmin * 
	 * @param inputEle
	 * @param eleReferences
	 * @param docRSOutput
	 * @param delimitTransaction
	 */
	private void createOrderReferenceWithOrigSaleDetails(Element inputEle,
			Element eleReferences, Document docRSOutput, String[] delimitTransaction) {
		log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.createOrderReferenceWithOrigSaleDetails");
		if(!YFCCommon.isVoid(docRSOutput) && docRSOutput.hasChildNodes()){
			Element eleRSOutput = docRSOutput.getDocumentElement();
			Element eleRSOrderExtn = XMLUtil.getChildElement(eleRSOutput, KohlsPOCConstant.E_EXTN);
			String isReturnRestricted = XMLUtil.getAttribute(eleRSOrderExtn, EXTN_IS_RESTRICTED_RETURN);
			String strResponseReasonType = XMLUtil.getAttribute(eleRSOrderExtn, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE);
			if(!KohlsPOCConstant.STR_APPROVAL.equalsIgnoreCase(strResponseReasonType)){
				throw new YFSException(KohlsPOCConstant.RETURN_PASS_INVALID_RS_RESPONSE,KohlsPOCConstant.RP_CUSTOM_ERROR,
						KohlsPOCConstant.RETURN_PASS_INVALID_RS_RESPONSE);
			}
			String strExtnOTRResponse = XMLUtil.getAttribute(eleRSOrderExtn, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE);
			String strExtnOTRResponseCode = strExtnOTRResponse + KohlsPOCConstant.GETOTRRESPONSE.get(strResponseReasonType);

			String strOTRTotalAmount = XMLUtil.getAttribute(eleRSOutput, KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT);
			String strReceiptEntryMethod = XMLUtil.getAttribute(inputEle, KohlsXMLLiterals.A_ENTRY_METHOD);
			String strStoreName = XMLUtil.getAttribute(eleRSOutput, KohlsPOCConstant.STORE_NAME);
			String strRSTimeTaken = XMLUtil.getAttribute(eleRSOutput, KohlsPOCConstant.RS_TIME_TAKEN);
			String strSellerOrganizationCode = XMLUtil.getAttribute(eleRSOutput, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
			String strTerminalID = XMLUtil.getAttribute(eleRSOutput, KohlsPOCConstant.A_TERMINAL_ID);
			String strPOSSequenceNumber = XMLUtil.getAttribute(eleRSOutput, KohlsPOCConstant.A_POS_SEQUENCE_NUMBER);

			Element eleReference = XMLUtil.createChild(eleReferences, KohlsPOCConstant.Reference);
			String strName = KohlsPOCConstant.OTR_Q+KohlsPOCConstant.MINUS+strSellerOrganizationCode+KohlsPOCConstant.MINUS+strTerminalID+
					KohlsPOCConstant.MINUS+strPOSSequenceNumber+KohlsPOCConstant.MINUS+delimitTransaction[3];
			String strValue = null;
			if(isReturnRestricted.equalsIgnoreCase(KohlsConstant.TRUE))
			{
			strValue = strExtnOTRResponseCode+KohlsPOCConstant.MINUS+strResponseReasonType+KohlsPOCConstant.MINUS+
					strOTRTotalAmount+KohlsPOCConstant.MINUS+strReturnPass+KohlsPOCConstant.UNDERSCORE+strReceiptEntryMethod+
					KohlsPOCConstant.MINUS+strStoreName+KohlsPOCConstant.MINUS+strRSTimeTaken;
			}
			else
			{
				strValue = strExtnOTRResponseCode+KohlsPOCConstant.MINUS+strResponseReasonType+KohlsPOCConstant.MINUS+
						strOTRTotalAmount+KohlsPOCConstant.MINUS+strReturnPass+KohlsPOCConstant.UNDERSCORE+strReceiptEntryMethod+
						KohlsPOCConstant.MINUS+strStoreName+KohlsPOCConstant.MINUS+strRSTimeTaken;
			}
			
			
			eleReference.setAttribute(KohlsXMLLiterals.A_NAME, strName);
			eleReference.setAttribute(KohlsXMLLiterals.A_VALUE, strValue);
			if(log.isDebugEnabled()){
				log.debug("eleReferences is updated from KohlsBuildRPandRSRequestFrmGravity.createOrderReferenceWithOrigSaleDetails : " +XMLUtil.getElementXMLString(eleReferences));
			}
		}
		log.endTimer("KohlsBuildRPandRSRequestFrmGravity.createOrderReferenceWithOrigSaleDetails");
	}
	
	/**
	 * Create By ibmadmin * 
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws Exception
	 */
	public Document getRpResponseDetails(YFSEnvironment env,Document inDoc) throws Exception
	{
	    log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.getRpResponseDetails");
		Document docRPResponse = KohlsCommonUtil.invokeService(env, KohlsPOCConstant.KOHLS_CALL_RP_WRAPPER, inDoc);
		log.endTimer("KohlsBuildRPandRSRequestFrmGravity.getRpResponseDetails");
		return docRPResponse;
	}
	
	/**
	 * Create By ibmadmin * 
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws Exception
	 */
	public Document getGravityRequestAndBuildRSReq(YFSEnvironment env,Document inDoc) throws Exception
	{
	    log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.getGravityRequestAndBuildRSReq");
		KohlsBuildReturnsRSRequestFrmGravity callRSUtil = new KohlsBuildReturnsRSRequestFrmGravity();
		Document docOutXML = callRSUtil.parseGravityRequestAndBuildRSRequest(env, inDoc);
		log.endTimer("KohlsBuildRPandRSRequestFrmGravity.getGravityRequestAndBuildRSReq");
		return docOutXML;
	}
	
	/**
	 * Create By ibmadmin * 
	 * @param env
	 * @param sCurrentStoreId
	 * @throws Exception
	 */
	public void setLoyaltyStoreType (YFSEnvironment env, String sCurrentStoreId) throws Exception {
	  log.beginTimer("KohlsBuildRPandRSRequestFrmGravity.setLoyaltyStoreType");
	  if(!YFCCommon.isVoid(sCurrentStoreId)) {
        storeType = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, 
            sCurrentStoreId, KohlsPOCConstant.EMPTY);
      }
	  log.endTimer("KohlsBuildRPandRSRequestFrmGravity.setLoyaltyStoreType");
	}
}
