/**
 * 
 * Copyright 2016 Kohls All rights reserved.
 * 
 * Customer specific copyright notice :General Desc of one line.
 * 
 * File Name : KohlsBuildReturnsRSRequestFrmGravity.java
 * 
 * Description :Kohls POC Returns
 * 
 * Version : 1.0.0.
 * 
 * Created Date :30-DEC-2016
 * 
 * Modification History:Modified by, on date.
 **/
package com.kohls.poc.returns;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.api.KohlsReturnRestrictStatus;
import com.kohls.poc.api.KohlsTranslateOTRResponse;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.returns.api.KohlsPoCRKC;
import com.kohls.poc.util.KohlcPoCWriteToFileUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * This program is invoked through a service. This invokes series of services to connect to Kohls
 * Return services, parses the response and build order object for Gravity usage
 * 
 * @version 1.0
 * @author POC Returns Team
 * 
 */
public class KohlsBuildReturnsRSRequestFrmGravity implements YIFCustomApi {
  private Properties props;
  private static final YFCLogCategory log =
      YFCLogCategory.instance(KohlsBuildReturnsRSRequestFrmGravity.class.getName());
  private YIFApi api;
  private String operatorId = KohlsConstant.BLANK;
  String strstoreNumber;
  String strterminalNumber;
  String strsequenceNumber;
  String strtrnTimeStamp;
  String strOrgCode;
  String strPOCFeature;
  boolean isDebitTenderEnabled = false; 
  public static final String RESTRICTED_RETURN_DATE = "restrictedReturnDate";
  public static final String NUMBER_OF_DAYS = "numberOfDays";
  public static final String RESTRICTED_RETURN_INDICATOR = "RestrictedReturnIndicator";
  private static final String EXTN_IS_RESTRICTED_RETURN ="ExtnIsRestrictedReturn";
  @Override
  public void setProperties(Properties prop) throws Exception {
    this.props = prop;

  }

  /***
   * 
   * This method parses gravity requests and build the web service request that is compatible with
   * Kohls Return service
   * 
   * Based on the length of the orderNo variable passed, it assumes either order no or receipt id
   * for parsing
   * 
   * @param env env
   * @param inXML input from Gravity
   * @return Document Response to Gravity with RS response
   */
  public Document parseGravityRequestAndBuildRSRequest(YFSEnvironment env, Document inXML)
      throws Exception {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.parseGravityRequestAndBuildRSRequest");
    if (log.isDebugEnabled()) {
      log.debug(
          "Input in service parseGravityRequestAndBuildRSRequest: " + XMLUtil.getXMLString(inXML));
    }
    Element inxmlEle = inXML.getDocumentElement();
  
    float timeTakenLong = 0;
    long endTime = 0;
    long beginTime = System.currentTimeMillis();
    // String scannedRecptNo =
    // inxmlEle.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
    operatorId = inxmlEle.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID);

    Document retSvcRequestDoc = null;
    strstoreNumber = inxmlEle.getAttribute(KohlsXMLLiterals.A_STORE_NUMBER);// "StoreNumber"
    String currentStoreNo = inxmlEle.getAttribute("CurrentStore");
    env.setTxnObject("CurrentStoreID",currentStoreNo);
    env.setTxnObject("CurrentTerminalID", inxmlEle.getAttribute("CurrentTerminal"));
    strterminalNumber = inxmlEle.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID); // TerminalID
    strsequenceNumber = inxmlEle.getAttribute(KohlsXMLLiterals.TRANSACTION_NBR);// TransactionNbr
    strtrnTimeStamp = inxmlEle.getAttribute(KohlsXMLLiterals.A_TRANS_TIME_STAMP);// TransactionTmst
    strOrgCode = inxmlEle.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
    strPOCFeature = inxmlEle.getAttribute(KohlsXMLLiterals.A_POC_FEATURE);
    String strScanType = inxmlEle.getAttribute(KohlsXMLLiterals.A_Entry_Method);
    // For gift receipt
    String giftReceiptInd = inxmlEle.getAttribute(KohlsXMLLiterals.GIFT_RECEIPT_IND);// GiftReceiptInd
    if (YFCCommon.isVoid(giftReceiptInd)) {
      giftReceiptInd = "false";
    }
    String sTransDetails= inxmlEle.getAttribute("CurrentStore")+"-"+ inxmlEle.getAttribute("CurrentTerminal")+"-"+ 
    	    inxmlEle.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID)+"-"+giftReceiptInd;
    
    env.setTxnObject(KohlsPOCConstant.TRAN_DETAILS, sTransDetails);
    	    
    isDebitTenderEnabled = isDebitTenderEnabled(env);
    String lineSequenceNbr = inxmlEle.getAttribute(KohlsXMLLiterals.LINE_SEQ_NO);// LineSequenceNbr
    // CAPE 973 OMS part begin
    String sRewardId = inxmlEle.getAttribute(KohlsXMLLiterals.A_REWARD_ID);// RewardID
    String sSKUNbr = inxmlEle.getAttribute(KohlsXMLLiterals.A_ITEM_ID);// ItemID
    if(sSKUNbr.length() == 12 && sSKUNbr.startsWith("400")){
      sSKUNbr = sSKUNbr.substring(3, 11);
    }
    // if(!YFCCommon.isVoid(sSKUNbr)){
    // sSKUNbr = new KohlsPoCMatchItemFromOTRResponse().checkForBarCode(env, sSKUNbr);
    // }
   
    String sOrderNbr = inxmlEle.getAttribute(KohlsXMLLiterals.A_ORDER_NO);// OrderNo
    String sGiftRegistryId = inxmlEle.getAttribute(KohlsXMLLiterals.A_GIFT_REG_ID);// GiftRegistryId
    // CAPE-2874 Start
    String sOrderHeaderKey = inxmlEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
    String returnRestrictionFlag = inxmlEle.getAttribute(RESTRICTED_RETURN_INDICATOR);
    HashMap<String, ArrayList<String>> hmTransactionData = new HashMap<String, ArrayList<String>>();
    if (!YFCCommon.isVoid(sOrderHeaderKey)) {
      hmTransactionData = getOrderListForLookup(env, sOrderHeaderKey);
    }
    String strIsMutliReceited = inxmlEle.getAttribute("IsMultiReceipted");
    env.setTxnObject("IsMultiReceipted", strIsMutliReceited);

  //Return Restriction rule 
    returnRestrictionFlag = KohlsPOCConstant.TRUE.equalsIgnoreCase(returnRestrictionFlag) ? KohlsPOCConstant.YES: KohlsPOCConstant.NO;
    Element elePaymentMethods =
        XMLUtil.getFirstElementByName(inxmlEle, KohlsXMLLiterals.E_PAYMENT_METHODS);
    Element elePaymentMethod = null;
    String sPaymentType = "";
    String sSVCNo = "";
    String sCreditCardNo = "";
    if (!YFCCommon.isVoid(elePaymentMethods)) {
      NodeList nlPaymentMethod =
          elePaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
      elePaymentMethod = (Element) nlPaymentMethod.item(0);

      if (!YFCCommon.isVoid(elePaymentMethod)) {
        sPaymentType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
        sSVCNo = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_SVCNo);
        sCreditCardNo = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
      }
      // }

    }
    Document mergeRSResponseXml = null;
    try {

      log.debug(
          "KohlsBuildReturnsRSRequestFrmGravity.parseGravityRequestAndBuildRSRequest--- fetching orde details from RS system");
      int countRkcEvent = 0;
      
      //getting active RKC events only for non GRR
      if("false".equalsIgnoreCase(giftReceiptInd)) {
        countRkcEvent = getActiveRKCEvent(env, giftReceiptInd, inXML);
      }

      if ((!YFCCommon.isVoid(sRewardId) && !YFCCommon.isVoid(sSKUNbr))
          || ((!YFCCommon.isVoid(sPaymentType) && !YFCCommon.isVoid(sCreditCardNo))
              && !YFCCommon.isVoid(sSKUNbr))
          || (!YFCCommon.isVoid(sOrderNbr) && !YFCCommon.isVoid(sSKUNbr))
          || (!YFCCommon.isVoid(sGiftRegistryId) && !YFCCommon.isVoid(sSKUNbr))
          || (!YFCCommon.isVoid(sSVCNo) && !YFCCommon.isVoid(sSKUNbr)
              && !YFCCommon.isVoid(sPaymentType))) {
        if (log.isDebugEnabled()) {
          log.debug(
              "KohlsBuildReturnsRSRequestFrmGravity Inside if block to prepare RS request with GetItemLookup ");
        }
        if (!YFCCommon.isVoid(sRewardId)) {
          if (log.isDebugEnabled()) {
            log.debug(
                "KohlsBuildReturnsRSRequestFrmGravity Inside if block to call buildRetSvcReqForReward ");
          }
          // CAPE-2874 - Start
          retSvcRequestDoc =
              buildRetSvcReqForReward(strstoreNumber, strterminalNumber, "1", strtrnTimeStamp,
                  operatorId, "false", "1", countRkcEvent, sRewardId, sSKUNbr, hmTransactionData,returnRestrictionFlag);
          // CAPE-2874 - End
        } else if (!YFCCommon.isVoid(sOrderNbr) || !YFCCommon.isVoid(sGiftRegistryId)) {
          if (log.isDebugEnabled()) {
            log.debug(
                "KohlsBuildReturnsRSRequestFrmGravity Inside if block to call buildRetSvcReqForOrderLookup ");
          }
          // CAPE-2874 Start
          retSvcRequestDoc = buildRetSvcReqForOrderLookup(strstoreNumber, strterminalNumber, "1",
              strtrnTimeStamp, operatorId, giftReceiptInd, "1", countRkcEvent, sOrderNbr,
              sGiftRegistryId, sSKUNbr, hmTransactionData,returnRestrictionFlag);
          // CAPE-2874 End
        } else if (!YFCCommon.isVoid(sSVCNo)) {
          if (log.isDebugEnabled()) {
            log.debug(
                "KohlsBuildReturnsRSRequestFrmGravity Inside if block to call buildRetSvcReqForSVC ");
          }
          // CAPE-2874 Start
          retSvcRequestDoc = buildRetSvcReqForSVC(strstoreNumber, strterminalNumber, "1",
              strtrnTimeStamp, operatorId, "false", "1", countRkcEvent, sSKUNbr, sPaymentType,
              sSVCNo, hmTransactionData,returnRestrictionFlag);
          // CAPE-2874 End
        } else {
          if (log.isDebugEnabled()) {
            log.debug(
                "KohlsBuildReturnsRSRequestFrmGravity Inside if block to call buildRetSvcReqForTender ");
          }
          // CAPE-2874 Start
          retSvcRequestDoc = buildRetSvcReqForTender(strstoreNumber, strterminalNumber, "1",
              strtrnTimeStamp, operatorId, "false", "1", countRkcEvent, sSKUNbr, sPaymentType,
              sCreditCardNo, hmTransactionData,returnRestrictionFlag);
          // CAPE-2874 End
        }
        // CAPE 973 - End and CAPE 54
      } else {

        if (strsequenceNumber != null) {
          // If its receipt scan, then store the receipt id in the env so it can used during getOrderList api call.
          env.setTxnObject(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, sOrderNbr);
          retSvcRequestDoc =
              buildRetSvcRequest(strstoreNumber, strterminalNumber, strsequenceNumber,
                  strtrnTimeStamp, operatorId, giftReceiptInd, lineSequenceNbr, countRkcEvent,returnRestrictionFlag);
        }

      }
      if (log.isDebugEnabled()) {
        log.debug("The POCREturns retSvcRequestDoc: " + XMLUtil.getXMLString(retSvcRequestDoc));
      }
      env.setTxnObject(KohlsConstant.GRAVITY_IN_REQ, inXML);
      Document otrResponseXml = null;
      Document docRSOffLineDoc = null;
      String responseReasonCde = "";
      String sFilePath = "";

      try {
        String sFileName = "";
        String sContentToWrite = "";
        boolean bAppend = true;
        KohlcPoCWriteToFileUtil fileUtil = null;
        String sLogToFile = null;
        try {
          sLogToFile = getPropertyValue(this.props.getProperty("LogRSCallToFile"));
          sFilePath = getPropertyValue(this.props.getProperty("LogRSLogDir"));
        } catch (Exception ex) {
          sLogToFile = KohlsPOCConstant.NO;
        }
        if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
          if (!sFilePath.endsWith("/")) {
            sFilePath = sFilePath + "/";
          }
          sFileName = strstoreNumber + "-" + strterminalNumber + "-" + strsequenceNumber + ".log";
          log.debug("########## Logging KC request to file: " + (sFilePath + sFileName));
          sContentToWrite = YFCDateUtils.getCurrentDate(true) + ": Request to RS service is: \n"
              + XMLUtil.getXMLString(retSvcRequestDoc) + "\n";
          fileUtil = new KohlcPoCWriteToFileUtil(sFilePath + sFileName, bAppend);
          fileUtil.writeDataToFile(sContentToWrite);
        }

        otrResponseXml = invokeRSWebServiceCall(env, retSvcRequestDoc);
        log.debug("Output of RS Response call::" + SCXmlUtil.getString(otrResponseXml));
        if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
          log.debug("Logging KC response to file");
          sContentToWrite = YFCDateUtils.getCurrentDate(true)
              + ": Response from RS   service is: \n" + XMLUtil.getXMLString(otrResponseXml) + "\n";
          fileUtil.writeDataToFile(sContentToWrite);
          fileUtil.closeFile();
        }
        if (log.isDebugEnabled()) {
          log.debug("OTR Response XML is: " + XMLUtil.getXMLString(otrResponseXml));
        }
        endTime = System.currentTimeMillis();
      } catch (Exception otre) {
        endTime = System.currentTimeMillis();
        timeTakenLong = endTime - beginTime;
        timeTakenLong = timeTakenLong / 1000;
        docRSOffLineDoc = getRSOfflineException(env, inXML.getDocumentElement(), returnRestrictionFlag);
        docRSOffLineDoc.getDocumentElement().setAttribute("RSTimeTaken",
            new DecimalFormat("#0.0##").format(timeTakenLong));
        return docRSOffLineDoc;
      }

      Document rsParseResponseXml = null;
      try {
        rsParseResponseXml = invokeRSResponseParsers(env, otrResponseXml);
      } catch (Exception parseExp) {

        log.error(
            "Exception in invokeRSResponseParsers of KohlsBuildReturnsRSRequestFrmGravity. Details:"
                + parseExp.getMessage());
        if (parseExp instanceof YFSException) {
          YFSException yfsException = (YFSException) parseExp;
          throw yfsException;
        }
      }
      // Check if the OTR response is one of the bad response, then
      // dont call OMS getOrderList
      if (!YFCCommon.isVoid(rsParseResponseXml)) {
        Element eleOrderExtn =
            (Element) rsParseResponseXml.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
        if(!YFCCommon.isVoid(eleOrderExtn))
        {
        	 	String sExtnOTRResponse = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE);
             rsParseResponseXml.getDocumentElement().setAttribute(KohlsXMLLiterals.A_Entry_Method,
                 strScanType);
             eleOrderExtn.setAttribute("ExtnReceiptID", sOrderNbr);
             if (!YFCCommon.isVoid(sExtnOTRResponse)
                 && !KohlsPOCConstant.RS_BAD_DATA_CODE.contains(sExtnOTRResponse)) {
               try {
                 mergeRSResponseXml = checkAndMergeRSResponse(env, rsParseResponseXml);
                 // Check item id for 7 digits and if its 7 digits
                 // then pad it with 0 to make it 8
                 // digit.
                 checkItemID(mergeRSResponseXml);
               } catch (Exception mergeExp) {
                 log.error(
                     "Exception in checkAndMergeRSResponse of KohlsBuildReturnsRSRequestFrmGravity. Details:"
                         + mergeExp.getMessage());
                 throw new YFCException(mergeExp);
               }
             } else {
               // mergeRSResponseXml = rsParseResponseXml;
               /* Added for CAPE-1294 START */
               mergeRSResponseXml = getRSOfflineException(env, rsParseResponseXml.getDocumentElement(), returnRestrictionFlag);
               /* Added for CAPE-1294 END */

             }
        }
        else
        {
            mergeRSResponseXml = getRSOfflineException(env, rsParseResponseXml.getDocumentElement(), returnRestrictionFlag);
        }
        // RS sends an empty response, treat it as Offline
      } else {
        mergeRSResponseXml = getRSOfflineException(env, inXML.getDocumentElement(), returnRestrictionFlag);
      }

    } catch (Exception e) {
      log.error(
          "KohlsBuildReturnsRSRequestFrmGravity.parseGravityRequestAndBuildRSRequest--- Error while checking thr RS Active flag");
      e.printStackTrace();
      throw e;
    }
    // Setting Store Name and RS Time Taken
    Element eleOutDocRSResponseXml = mergeRSResponseXml.getDocumentElement();
    timeTakenLong = endTime - beginTime;
    timeTakenLong = timeTakenLong / 1000;
    eleOutDocRSResponseXml.setAttribute("RSTimeTaken",
        new DecimalFormat("#0.00#").format(timeTakenLong));
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.parseGravityRequestAndBuildRSRequest");
    return mergeRSResponseXml;
  }



  /**
   * @param storeNumber
   * @param terminalNumber
   * @param sequenceNumber
   * @param trnTimeStamp
   * @param operatorId
   * @param giftReceiptInd
   * @param lineSequenceNbr
   * @param countRkcEvent
   * @param sSKUNbr
   * @param sPaymentType
   * @param sSVCNo
   * @param hmTransactionData
   * @param returnRestrictionFlag 
   * @return
   */
  private Document buildRetSvcReqForSVC(String storeNumber, String terminalNumber,
      String sequenceNumber, String trnTimeStamp, String operatorId, String giftReceiptInd,
      String lineSequenceNbr, int countRkcEvent, String sSKUNbr, String sPaymentType, String sSVCNo,
      HashMap<String, ArrayList<String>> hmTransactionData , String returnRestrictionFlag) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForSVC");
    Document retSvcReqDoc = null;
    try {
      retSvcReqDoc = XMLUtil.createDocument(KohlsXMLLiterals.A_GET_ITEM_LOOKUP);
      Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();
      this.buildCommonTagsForLookUpRequest(retSvcReqDocEle, storeNumber, terminalNumber,
          sequenceNumber, trnTimeStamp, operatorId, giftReceiptInd, lineSequenceNbr, countRkcEvent ,returnRestrictionFlag);
      Element eleItemLookup = XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.A_ITEM_LOOKUP);
      Element capLevelEle=XMLUtil.createChild(eleItemLookup, "CapLevel");
      XMLUtil.setNodeValue(capLevelEle, "200");
      Element eleSKUNbr = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_SKU_NUMBER);
      XMLUtil.setNodeValue(eleSKUNbr, sSKUNbr);
      // CAPE-2874 Start
      this.buildIgnoreTransaction(eleItemLookup, hmTransactionData);
      // CAPE-2874 End
      Element eleTenderTypeCde =
          XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_TENDER_TYPE_CODE);
      Element eleTenderId = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_TENDER_ID);

      if ("02".equals(sPaymentType)) {
        sPaymentType = "KohlsMerchandiseReturnCredit";
      } else {
        sPaymentType = "KohlsGiftCard";
      }
      XMLUtil.setNodeValue(eleTenderTypeCde, sPaymentType);
      XMLUtil.setNodeValue(eleTenderId, sSVCNo);
      // set the methodOfEntryCde attribute to BarCode
      eleTenderId.setAttribute(KohlsXMLLiterals.A_METHOD_OF_ENTRY_CODE, "BarCode");
    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in buildRetSvcReqForSVC of KohlsBuildReturnsRSRequestFrmGravity. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForSVC");
    return retSvcReqDoc;
  }
  // SVC Look up

  // CAPE 54
  /**
   * @param storeNumber
   * @param terminalNumber
   * @param sequenceNumber
   * @param trnTimeStamp
   * @param operatorId
   * @param giftReceiptInd
   * @param lineSequenceNbr
   * @param countRkcEvent
   * @param sSKUNbr
   * @param strPaymentType
   * @param strCreditCardNo
   * @param hmTransactionData
   * @param returnRestrictionFlag
   * @return
   */
  private Document buildRetSvcReqForTender(String storeNumber, String terminalNumber,
      String sequenceNumber, String trnTimeStamp, String operatorId, String giftReceiptInd,
      String lineSequenceNbr, int countRkcEvent, String sSKUNbr, String strPaymentType,
      String strCreditCardNo, HashMap<String, ArrayList<String>> hmTransactionData,  String returnRestrictionFlag) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForTender");
    Document retSvcReqDoc = null;
    try {
      retSvcReqDoc = XMLUtil.createDocument(KohlsXMLLiterals.A_GET_ITEM_LOOKUP);
      Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();
      this.buildCommonTagsForLookUpRequest(retSvcReqDocEle, storeNumber, terminalNumber,
          sequenceNumber, trnTimeStamp, operatorId, giftReceiptInd, lineSequenceNbr, countRkcEvent, returnRestrictionFlag);
      Element eleItemLookup = XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.A_ITEM_LOOKUP);
      Element capLevelEle=XMLUtil.createChild(eleItemLookup, "CapLevel");
      XMLUtil.setNodeValue(capLevelEle, "200");
      Element eleSKUNbr = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_SKU_NUMBER);
      XMLUtil.setNodeValue(eleSKUNbr, sSKUNbr);
      Element eleTenderTypeCde =
          XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_TENDER_TYPE_CODE);
      XMLUtil.setNodeValue(eleTenderTypeCde, strPaymentType);
      Element eleTenderId = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_TENDER_ID);
      XMLUtil.setNodeValue(eleTenderId, strCreditCardNo);
      // CAPE-2874 Start
      this.buildIgnoreTransaction(eleItemLookup, hmTransactionData);
      // CAPE-2874 End
      // set the methodOfEntryCde attribute to PinPad
      eleTenderId.setAttribute(KohlsXMLLiterals.A_METHOD_OF_ENTRY_CODE, "PinPad");

      Element transactionKeyElement =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.E_TRANSACTION_KEY);
      Element locNumberEle =
          XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.LOCATION_NBR);
      XMLUtil.setNodeValue(locNumberEle, storeNumber);
      Element deviceIdEle = XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.DEVICE_ID);
      XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
      Element txnNbrEle =
          XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.TRANSACTION_NBR);
      XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
      Element txnTimstamp =
          XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
      XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);

    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in buildRetSvcReqForTender of KohlsBuildReturnsRSRequestFrmGravity. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForTender");
    return retSvcReqDoc;
  }

  // CAPE 54
  /**
   * Build the return service request in the format required
   * 
   * @param storeNumber Store No
   * @param terminalNumber Terminal No
   * @param sequenceNumber Seq No
   * @param trnTimeStamp Timestamp
   * @param operatorId Operator
   * @param returnRestrictionFlag
   * @param sPOCFeature
   * @return req document
   */
  private Document buildRetSvcRequest(String storeNumber, String terminalNumber,
      String sequenceNumber, String trnTimeStamp, String operatorId, String giftReceiptInd,
      String lineSequenceNbr, int countRkcEvent, String returnRestrictionFlag) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcRequest");
    Document retSvcReqDoc = null;
    try {
      retSvcReqDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_GET_OPEN_TO_RETURN);
      Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();
      retSvcReqDocEle.setAttribute(KohlsXMLLiterals.A_XMLNS, KohlsXMLLiterals.A_XMLNS_VALUE_OAGIS);

      Element headerElement = XMLUtil.createChild(retSvcReqDocEle, KohlsPOCConstant.E_HEADER);
      headerElement.setAttribute(KohlsXMLLiterals.A_XMLNS_HEADER,
          KohlsXMLLiterals.A_XMLNS_HEADER_VALUE_AU);
      Element locNumberEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.LOCATION_NBR);
      XMLUtil.setNodeValue(locNumberEle, storeNumber);
      Element deviceIdEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.DEVICE_ID);
      XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
      Element txnNbrEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.TRANSACTION_NBR);
      XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
      Element txnTimstamp = XMLUtil.createChild(headerElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
      XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);
      Element txnCode = XMLUtil.createChild(headerElement, KohlsXMLLiterals.E_TRANSACTION_CODE);
      XMLUtil.setNodeValue(txnCode, KohlsXMLLiterals.A_RETURN);

      Element operatorIdEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.A_OPERATOR_ID);
      XMLUtil.setNodeValue(operatorIdEle, operatorId);
      Element trainingModeIndEle =
          XMLUtil.createChild(headerElement, KohlsXMLLiterals.E_TRAINING_MODE_IND);
      XMLUtil.setNodeValue(trainingModeIndEle, KohlsConstant.FALSE);

      Element transactionKeyElement =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.E_TRANSACTION_KEY);
      locNumberEle = XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.LOCATION_NBR);
      XMLUtil.setNodeValue(locNumberEle, storeNumber);
      deviceIdEle = XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.DEVICE_ID);
      XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
      txnNbrEle = XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.TRANSACTION_NBR);
      XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
      txnTimstamp = XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
      XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);
      Element capLevelEle=XMLUtil.createChild(retSvcReqDocEle, "CapLevel");
		 XMLUtil.setNodeValue(capLevelEle, "200");
      Element giftReceiptIndEle =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.GIFT_RECEIPT_IND);
      XMLUtil.setNodeValue(giftReceiptIndEle, giftReceiptInd);
      Element restrictedReturnIndicatorEle =
              XMLUtil.createChild(retSvcReqDocEle, RESTRICTED_RETURN_INDICATOR);
      if (KohlsPOCConstant.YES.equalsIgnoreCase(returnRestrictionFlag)) 
      {
      		log.info("KohlsReturnRestrictStatus:: Restricted Return Enabled Store? --> "+ KohlsConstant.TRUE);
         	XMLUtil.setNodeValue(restrictedReturnIndicatorEle, KohlsConstant.TRUE);
      }
      else
      {
      		log.info("KohlsReturnRestrictStatus:: Restricted Return Enabled Store? --> "+ KohlsConstant.FALSE);
      		XMLUtil.setNodeValue(restrictedReturnIndicatorEle, KohlsConstant.FALSE);
      }
      Element lineSequenceNbrEle =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.LINE_SEQ_NO);
      XMLUtil.setNodeValue(lineSequenceNbrEle, lineSequenceNbr);
      Element refundSourceCdeEle =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.E_REFUND_SOURCE_CDE);
      XMLUtil.setNodeValue(refundSourceCdeEle, KohlsXMLLiterals.A_RETURN);
      Element tenderIdProtected =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.A_TENDER_ID_PROTECTED);
      XMLUtil.setNodeValue(tenderIdProtected, KohlsConstant.TRUE);
      Element partialProtection =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.PARTIAL_PROTECTION);
      XMLUtil.setNodeValue(partialProtection, KohlsConstant.TRUE);

      if (("false".equals(giftReceiptInd)) || (giftReceiptInd.equals(""))) {

        if (countRkcEvent > 0) {
          Element returnKohlsCashInd =
              XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.RETURN_KOHLS_CASH_IND);
          XMLUtil.setNodeValue(returnKohlsCashInd, KohlsConstant.TRUE);
        }

      } else {
        Element returnKohlsCashInd =
            XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.RETURN_KOHLS_CASH_IND);
        XMLUtil.setNodeValue(returnKohlsCashInd, KohlsConstant.FALSE);
      }

      // CAPE - 2023 Changes
      if (isDebitTenderEnabled) {
        Element eleReturnDebitEnabledInd =
            XMLUtil.createChild(retSvcReqDocEle, "ReturnDebitEnabledInd");

        XMLUtil.setNodeValue(eleReturnDebitEnabledInd, KohlsConstant.TRUE);

      }

    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in buildRetSvcRequest of KohlsBuildReturnsRSRequestFrmGravity. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcRequest");
    return retSvcReqDoc;
  }

  // CAPE 973 - Begin
  /**
   * Build the return service request for Reward in the format required
   * 
   * @param storeNumber Store No
   * @param terminalNumber Terminal No
   * @param sequenceNumber Seq No
   * @param trnTimeStamp Timestamp
   * @param operatorId Operator
   * @param sRewardId RewardId
   * @param sSKUNbr SKUNbr
   * @param hmTransactionData
   * @return req document
   * @param returnRestrictionFlag 
   */
  private Document buildRetSvcReqForReward(String storeNumber, String terminalNumber,
      String sequenceNumber, String trnTimeStamp, String operatorId, String giftReceiptInd,
      String lineSequenceNbr, int countRkcEvent, String sRewardId, String sSKUNbr,
      HashMap<String, ArrayList<String>> hmTransactionData, String returnRestrictionFlag) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForReward");
    Document retSvcReqDoc = null;
    try {
      retSvcReqDoc = XMLUtil.createDocument(KohlsXMLLiterals.A_GET_ITEM_LOOKUP);
      Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();
      this.buildCommonTagsForLookUpRequest(retSvcReqDocEle, storeNumber, terminalNumber,
          sequenceNumber, trnTimeStamp, operatorId, giftReceiptInd, lineSequenceNbr, countRkcEvent,returnRestrictionFlag);
      Element eleItemLookup = XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.A_ITEM_LOOKUP);
      Element capLevelEle=XMLUtil.createChild(eleItemLookup, "CapLevel");
      XMLUtil.setNodeValue(capLevelEle, "200");
      Element eleSKUNbr = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_SKU_NUMBER);
      XMLUtil.setNodeValue(eleSKUNbr, sSKUNbr);
      Element eleTenderTypeCde =
          XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_TENDER_TYPE_CODE);
      XMLUtil.setNodeValue(eleTenderTypeCde, KohlsPOCConstant.REWARDS_ID);
      Element eleTenderId = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_TENDER_ID);
      XMLUtil.setNodeValue(eleTenderId, sRewardId);
      // CAPE-2874 Start
      this.buildIgnoreTransaction(eleItemLookup, hmTransactionData);
      // CAPE-2874 End
      Element transactionKeyElement =
          XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.E_TRANSACTION_KEY);
      Element locNumberEle =
          XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.LOCATION_NBR);
      XMLUtil.setNodeValue(locNumberEle, storeNumber);
      Element deviceIdEle = XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.DEVICE_ID);
      XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
      Element txnNbrEle =
          XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.TRANSACTION_NBR);
      XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
      Element txnTimstamp =
          XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
      XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);

    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in buildRetSvcReqForReward of KohlsBuildReturnsRSRequestFrmGravity. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForReward");
    return retSvcReqDoc;
  }

  // CAPE 973 - End

  // Order lookup - Start

  /**
   * Build the return service request for Order look up in the format required
   * 
   * @param storeNumber Store No
   * @param terminalNumber Terminal No
   * @param sequenceNumber Seq No
   * @param trnTimeStamp Timestamp
   * @param operatorId Operator
   * @param sOrderNbr OrderNo
   * @param sSKUNbr SKUNbr
   * @param hmTransactionData
   * @param returnRestrictionFlag
   * @return req document
   */
  private Document buildRetSvcReqForOrderLookup(String storeNumber, String terminalNumber,
      String sequenceNumber, String trnTimeStamp, String operatorId, String giftReceiptInd,
      String lineSequenceNbr, int countRkcEvent, String sOrderNbr, String sGiftRegistryId,
      String sSKUNbr, HashMap<String, ArrayList<String>> hmTransactionData, String returnRestrictionFlag) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForOrderLookup");
    Document retSvcReqDoc = null;
    try {
      retSvcReqDoc = XMLUtil.createDocument(KohlsXMLLiterals.A_GET_ITEM_LOOKUP);
      Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();
      this.buildCommonTagsForLookUpRequest(retSvcReqDocEle, storeNumber, terminalNumber,
          sequenceNumber, trnTimeStamp, operatorId, giftReceiptInd, lineSequenceNbr, countRkcEvent,returnRestrictionFlag);
      Element eleItemLookup = XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.A_ITEM_LOOKUP);
      Element capLevelEle=XMLUtil.createChild(eleItemLookup, "CapLevel");
      XMLUtil.setNodeValue(capLevelEle, "200");
      Element eleSKUNbr = XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_SKU_NUMBER);
      XMLUtil.setNodeValue(eleSKUNbr, sSKUNbr);
      // CAPE-2874 Start
      this.buildIgnoreTransaction(eleItemLookup, hmTransactionData);
      // CAPE-2874 End

      if (!YFCCommon.isVoid(sOrderNbr)) {
        Element eleMultiChannelOrderNbr =
            XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_MULTI_CHNL_ORD_NO);
        XMLUtil.setNodeValue(eleMultiChannelOrderNbr, sOrderNbr);
      } else {
        Element eleGiftRegistryNbr =
            XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_GIFT_REG_ID);
        XMLUtil.setNodeValue(eleGiftRegistryNbr, sGiftRegistryId);

      }

    } catch (ParserConfigurationException e) {
      log.error(
          "ParserConfigurationException in buildRetSvcReqForOrderLookup of KohlsBuildReturnsRSRequestFrmGravity. Details:"
              + e.getMessage());
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.buildRetSvcReqForOrderLookup");
    return retSvcReqDoc;
  }
  // Order lookup - End

  /**
   * Invokes the OMS services that makes use of extended API to invoke the Return service web serice
   * call
   * 
   * @param env env
   * @param inDoc document to webservice
   * @return Document response document
   * @throws Exception
   */
  public Document invokeRSWebServiceCall(YFSEnvironment env, Document inDoc) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.invokeRSWebServiceCall");
    Document rsResponseDoc = null;
    try {
      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("invokeRSWebServiceCall Input XML : " + SCXmlUtil.getString(inDoc));
      }
      rsResponseDoc = KohlsCommonUtil.invokeService(env, KohlsConstant.WEBSERVICE_CALL_RS, inDoc);

      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("invokeRSWebServiceCall Output XML : " + SCXmlUtil.getString(rsResponseDoc));
      }
    } catch (Exception e) {
      if (e.getCause() instanceof java.net.ConnectException) {
        throw new YFCException(KohlsConstant.EXTN_CONNECT);
      } else if (e.getCause() instanceof java.io.IOException) {
        throw new YFCException(KohlsConstant.EXTN_IO);
      } else if (e.getCause() instanceof javax.xml.soap.SOAPException
          || e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
        throw new YFCException(KohlsConstant.SOAP_EXCEPTION);
      } else if (e.getCause() instanceof javax.xml.ws.WebServiceException) {
        throw new YFCException(KohlsConstant.WEB_SERVICE_EXCEPTION);
      } else {
        throw new YFCException(KohlsConstant.EXTN_OTHER);
      }
    }
    if (YFCLogUtil.isDebugEnabled()) {
      log.debug("End of invokeRSWebServiceCall -- the return Doc -->"
          + SCXmlUtil.getString(rsResponseDoc));
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.invokeRSWebServiceCall");
    return rsResponseDoc;
  }

  /**
   * Invokes various services that parse the response from Return service
   * 
   * @param env env
   * @param inDoc input to parsers
   * @return Document response document
   * @throws Exception exception
   */
  public Document invokeRSResponseParsers(YFSEnvironment env, Document inDoc) throws Exception {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.invokeRSResponseParsers");
    Document rsResponseDoc = null;
    try {
      if (log.isDebugEnabled()) {
        log.debug("invokeRSResponseParsers Input XML : " + XMLUtil.getXMLString(inDoc));
      }
      Element srcElem =
          SCXmlUtil.getChildElement(inDoc.getDocumentElement(), KohlsXMLLiterals.ELE_M_RETURN);

      if (log.isDebugEnabled()) {
        log.debug(
            "invokeRSResponseParsers return element: " + XMLUtil.getElementXMLString(srcElem));
      }
      // Start - Check to see if order exists in RS - IBM
      if (YFCCommon.isVoid(srcElem)) {
        YFSException exception = new YFSException();
        exception.setErrorDescription("Receipt cannot be processed.");
        throw exception;

      } else {
        String rsResponse = SCXmlUtil.getString(srcElem);

        if (rsResponse != null
            && (rsResponse.contains("ShowOpenToReturn") || rsResponse.contains("ShowItemLookup"))) {
          rsResponse = rsResponse.replace("&lt;", "<");
          rsResponse = rsResponse.replace("&gt;", ">");
          rsResponse = rsResponse.replace("m:processMessageResponse", "processMessageResponse");
          rsResponse = rsResponse.replace("m:return", "return");
          rsResponse = rsResponse.replace("oag:", "");

          YFCDocument yfcDocument = YFCDocument.getDocumentFor(rsResponse);
          YFCElement otrYFCElement = yfcDocument.getElementsByTagName("ShowOpenToReturn").item(0);
          if (YFCCommon.isVoid(otrYFCElement)) {
            YFCElement eleShowItemElement =
                yfcDocument.getElementsByTagName("ShowItemLookup").item(0);
            eleShowItemElement.removeAttribute("xmlns:oag");
            eleShowItemElement.removeAttribute("xmlns:header");
            rsResponseDoc = XmlUtils.createFromString(eleShowItemElement.toString());
          } else {
            otrYFCElement.removeAttribute("xmlns:oag");
            otrYFCElement.removeAttribute("xmlns:header");
            rsResponseDoc = XmlUtils.createFromString(otrYFCElement.toString());
          }

          if (log.isDebugEnabled() && !YFCCommon.isVoid(otrYFCElement)) {
            log.debug("OTR Element :" + otrYFCElement.toString());
          }

        }
        if (rsResponseDoc != null) {
          KohlsTranslateOTRResponse otrObj = new KohlsTranslateOTRResponse();
          //PST-4465 - adding pocfeature parameter
          rsResponseDoc = otrObj.translateRSResponse(env, rsResponseDoc, strPOCFeature);
          // CAPE 973
          try {
            log.debug("After OTR response");
            if (!YFCCommon.isVoid(rsResponseDoc)) {
              NodeList nlResponseFmRS =
                  rsResponseDoc.getElementsByTagName(KohlsXMLLiterals.A_RESPONSE_CODE_FRM_RS);
              Element eleResponseFmRS = (Element) nlResponseFmRS.item(0);
              if (!YFCCommon.isVoid(eleResponseFmRS)) {
                String sResReasonCde =
                    eleResponseFmRS.getAttribute(KohlsXMLLiterals.A_RESPONSE_RSNCODE_FRM_RS);
                log.debug("Value of sResReasonCde " + sResReasonCde);
                if (!YFCCommon.isVoid(sResReasonCde)
                    && KohlsPOCConstant.RS_BAD_DATA_CODE.contains(sResReasonCde)) {

                  YFCException ex = new YFCException("ERROR_INVALID_TXN", "Transaction not found");
                  throw ex;
                }
              }
            }
          } catch (YFCException e) {

            YFCException YFCex = new YFCException(e);
            throw YFCex;
          }
          // CAPE 973
          if (log.isDebugEnabled()) {
            log.debug("after order format Output XML : " + SCXmlUtil.getString(rsResponseDoc));
          }
        }
      }
    } catch (YFSException e) {

      log.error("Exception in invoking the invokeRSResponseParsers : " + e.getMessage());
      throw e;
    } catch (Exception e) {

      log.error("Exception in invoking the invokeRSResponseParsers : " + e.getMessage());
    }

    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.invokeRSResponseParsers");
    return rsResponseDoc;
  }

  /**
   * Invokes check and merger service that combines the response from RS and getOrderdetails
   * 
   * @param env env
   * @param inDoc input doc to merge
   * @return Document response doc
   * @throws Exception exception
   */
  public Document checkAndMergeRSResponse(YFSEnvironment env, Document inDoc) throws Exception {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.checkAndMergeRSResponse");
    Document mergeRSResponseXml = null;
    try {
      if (YFCLogUtil.isDebugEnabled()) {
        log.debug("CheckAndMergeRSResponse Input XML : " + SCXmlUtil.getString(inDoc));
      }

      mergeRSResponseXml =
          KohlsCommonUtil.invokeService(env, "KohlsReturnCheckAndMergeOrder", inDoc);

      if (YFCLogUtil.isDebugEnabled()) {
        log.debug(
            "CheckAndMergeRSResponse Output XML : " + SCXmlUtil.getString(mergeRSResponseXml));
      }
    } catch (Exception e) {
      log.error("Exception in invoking the CheckAndMergeRSResponse : " + e.getMessage());
      throw new YFCException(e);
    }
    if (YFCLogUtil.isDebugEnabled()) {
      log.debug("End of CheckAndMergeRSResponse -- the return Doc -->"
          + SCXmlUtil.getString(mergeRSResponseXml));
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.checkAndMergeRSResponse");
    /* Added for OTR response change -START */
    invokeOTRForHangoff(env, mergeRSResponseXml);
    /* Added for OTR response change -END */
    return mergeRSResponseXml;
  }


  /**
   * This method generates the offline response xml
   * 
   * @param inxmlEle
   * @param returnRestrictionFlag
   * @return
   */
  private Document getRSOfflineException(YFSEnvironment env, Element inxmlEle, String returnRestrictionFlag) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.getRSOfflineException");

    String documentType = inxmlEle.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE);
    String enterpriseCode = inxmlEle.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
    String sellerOrgCode = strstoreNumber;
    String posSeqNo = strsequenceNumber;
    if (YFCCommon.isVoid(posSeqNo)) {
      posSeqNo = inxmlEle.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NUMBER);
    }
    Element inxmlEleExtn = XMLUtil.getChildElement(inxmlEle, KohlsXMLLiterals.E_EXTN);
    String extnReceiptID = "";
    String extnOTRResponse = "";
    String extnOTRResponseType = "";
    if (inxmlEleExtn != null) {
      extnReceiptID = inxmlEleExtn.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
      extnOTRResponse = inxmlEleExtn.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE);
      extnOTRResponseType = inxmlEleExtn.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE);
    }
    Document docResponse = null;
    String sRKCEventID = (String) env.getTxnObject("GetActiveRKCEvent");
    KohlsPoCRKC rkc = new KohlsPoCRKC();
    String strCouponEventID;
    try {
      strCouponEventID = rkc.getRKCEventID(sRKCEventID);
      String strExpiryDate = sRKCEventID;
      int countRkcEvent = rkc.getRKCEventCount(sRKCEventID);
      docResponse = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER).getDocument();
      Element eleResponse = docResponse.getDocumentElement();
      eleResponse.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, documentType);
      eleResponse.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, enterpriseCode);
      eleResponse.setAttribute(KohlsXMLLiterals.A_POS_SEQ_NO, posSeqNo);
      eleResponse.setAttribute(KohlsXMLLiterals.A_POS_SEQ_NUMBER, posSeqNo);
      eleResponse.setAttribute(KohlsXMLLiterals.A_ORDER_DATE, strtrnTimeStamp);
      eleResponse.setAttribute(KohlsXMLLiterals.A_POST_VOIDED, "N");
      eleResponse.setAttribute("ReturnByGiftRecipient", "");
      eleResponse.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, sellerOrgCode);
      eleResponse.setAttribute("StoreName", getStoreName(env, sellerOrgCode));
      eleResponse.setAttribute(KohlsXMLLiterals.A_TERMINAL_ID, strterminalNumber);
      Element eleResponseExtn = XMLUtil.createChild(eleResponse, KohlsXMLLiterals.E_EXTN);
      if (returnRestrictionFlag.equalsIgnoreCase(KohlsPOCConstant.YES) && !YFCCommon.isVoid(strtrnTimeStamp))
  	  {
  		  String sRestrictionStatus = KohlsReturnRestrictStatus.getRestrictionStatus(env,strtrnTimeStamp,(String)env.getTxnObject("CurrentStoreID"));
  		  eleResponseExtn.setAttribute(EXTN_IS_RESTRICTED_RETURN, sRestrictionStatus);
  		  
  	  }
      if (!YFCCommon.isVoid(extnOTRResponse)) {
        eleResponseExtn.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, extnOTRResponse);
        eleResponseExtn.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE,
            extnOTRResponseType);
      }
      else {
        eleResponseExtn.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, "000000F9");
        eleResponseExtn.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE, "Offline");
      }
      String sRuleValue = "";
      Document docOutRule = KohlsPoCPnPUtil.getRuleListForPOSCaller(env, inxmlEle, "OTR_AMOUNT");
      if (!YFCCommon.isVoid(docOutRule)) {
        Element eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);
        if (!YFCCommon.isVoid(eleRule)) {
          sRuleValue = eleRule.getAttribute("RuleValue");
        }
      }
      eleResponseExtn.setAttribute("ExtnOTRAmount", sRuleValue);
      eleResponse.setAttribute(KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT, sRuleValue);
      eleResponseExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ORIGINAL_POS_SEQ_NO, posSeqNo);
      eleResponseExtn.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, extnReceiptID);
      log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.getRSOfflineException");
      if (countRkcEvent > 0) {
        Element elePromotions = XMLUtil.createChild(eleResponse, "Promotions");
        Element elePromotion = SCXmlUtil.createChild(elePromotions, "Promotion");
        elePromotion.setAttribute("PromotionApplied", "N");
        elePromotion.setAttribute("PromotionType", KohlsPOCConstant.KOHLS_CASH_REISSUE);
        elePromotion.setAttribute("PromotionId", "0");
        Element eleExtn = SCXmlUtil.createChild(elePromotion, "Extn");
        eleExtn.setAttribute("ExtnCouponEventID", strCouponEventID);
        eleExtn.setAttribute("ExtnExpiryDate", strExpiryDate);
      }
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    return docResponse;
  }

  /**
   * @param yfsEnv
   * @param strStoreNum
   * @return
   * @throws Exception
   */
  private String getStoreName(YFSEnvironment yfsEnv, String strStoreNum) throws Exception {

    if (!YFCCommon.isVoid(strStoreNum)) {
      try {
        Document getOrganizationHierarchyInput =
            XMLUtil.getDocument("<Organization OrganizationCode='" + strStoreNum
                + "' OrganizationKey='" + strStoreNum + "' ></Organization>");

        Document getOrganizationHierarchyTemplate =
            XMLUtil.getDocument("<Organization OrganizationName=''></Organization>");
        Document getOrganizationListOutput =
            KOHLSBaseApi.invokeAPI(yfsEnv, getOrganizationHierarchyTemplate,
                "getOrganizationHierarchy", getOrganizationHierarchyInput);
        return getOrganizationListOutput.getDocumentElement().getAttribute("OrganizationName");
      } catch (YFSException e) {
        // if there is no org definded, ignore the error.
        return "";
      }
    } else {
      return "";
    }
  }

  // CAPE-2874 - Start
  private HashMap<String, ArrayList<String>> getOrderListForLookup(YFSEnvironment yfsEnv,
      String sOrderHeaderKey) throws Exception {
    Document getOrderListInput =
        XMLUtil.getDocument("<Order OrderHeaderKey='" + sOrderHeaderKey + "' ></Order>");
    Document getOrderListTemplate = XMLUtil.getDocument(
        "<OrderList><Order OrderNo=''><References/><OrderLines><OrderLine PrimeLineNo=''><CustomAttributes Text7='' Text8='' Text9='' Text10='' Date2=''/><Item ItemID=''/></OrderLine></OrderLines></Order></OrderList>");
    Document getOrderListOutput =
        KOHLSBaseApi.invokeAPI(yfsEnv, getOrderListTemplate, "getOrderList", getOrderListInput);
    NodeList nlOrderLine = getOrderListOutput.getElementsByTagName("OrderLine");
    HashMap<String, ArrayList<String>> hmTransactionData = new HashMap<String, ArrayList<String>>();
    for (int i = 0; i < nlOrderLine.getLength(); i++) {
      Element eleOrderLine = (Element) nlOrderLine.item(i);
      Element eleCustAttribute = XMLUtil.getChildElement(eleOrderLine, "CustomAttributes");
      String sText7 = eleCustAttribute.getAttribute("Text7");
      String sText8 = eleCustAttribute.getAttribute("Text8");
      String sText9 = eleCustAttribute.getAttribute("Text9");
      String sDate2 = eleCustAttribute.getAttribute("Date2");
      String sKey = sText7 + "_" + sText8 + "_" + sText9 + "_" + sDate2;
      String sValue = eleCustAttribute.getAttribute("Text10");

      if (hmTransactionData.containsKey(sKey)) {

        ArrayList<String> alValue = hmTransactionData.get(sKey);
        alValue.add(sValue);
        hmTransactionData.put(sKey, alValue);

      } else {

        ArrayList<String> alValue = new ArrayList<String>();
        alValue.add(sValue);
        hmTransactionData.put(sKey, alValue);
      }

    }
    //loop through  Reference for Exp- key work , then populate hashMap with the sequence no
    NodeList nlReference = getOrderListOutput.getElementsByTagName("Reference");
    for(int j = 0; j < nlReference.getLength(); j++){
    	Element eleReference = (Element) nlReference.item(j);
    	
    	if(eleReference.getAttribute("Value").contains("EXPIRED")){
    		String[] receiptValue= eleReference.getAttribute("Value").split("-");
    		String maxSeq = receiptValue[receiptValue.length -1];
    		int maxSeqNo = 1;
    		try{
    			maxSeqNo = Integer.parseInt(maxSeq);
    		} catch(Exception e){
    			//number format exception to be ignored
    		}
    	
    		String[] sReferenceName = eleReference.getAttribute("Name").split("-");
    		String sKey = sReferenceName[2]+"_"+sReferenceName[3]+"_"+sReferenceName[4]+"_"+sReferenceName[5]+"-"+sReferenceName[6]+"-"+sReferenceName[7];
    		ArrayList<String> alValue = new ArrayList<String>();
    		for(int k=1; k<= maxSeqNo;k++){
    			alValue.add(k+"");
    		}
    		hmTransactionData.put(sKey, alValue);
    	}
    	
    }
    return hmTransactionData;

  }
  // CAPE-2874 End

  /**
   * Create By mrjoshi * This method checks if item ids are 7 digit and if yes, then pad it with 0
   * to make it consistent 8 digits
   * 
   * @param docInXML
   */
  private void checkItemID(Document docInXML) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.checkItemID");
    NodeList nlOrderline = docInXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
    if (!YFCCommon.isVoid(nlOrderline) && nlOrderline.getLength() > 0) {
      for (int i = 0; i < nlOrderline.getLength(); i++) {
        Element eleOrderLine = (Element) nlOrderline.item(i);
        Element eleItem =
            (Element) eleOrderLine.getElementsByTagName(KohlsXMLLiterals.E_ITEM).item(0);
        if (!YFCCommon.isVoid(eleItem)) {
          String sItemID = eleItem.getAttribute(KohlsXMLLiterals.A_ITEM_ID);
          if (sItemID.length() == 7) {
            eleItem.setAttribute(KohlsXMLLiterals.A_ITEM_ID, "0" + sItemID);
          }
        }
      }
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.checkItemID");
  }

  /* Added for OTR Response change - START */
  private void invokeOTRForHangoff(YFSEnvironment env, Document doc) {
    Document docOutXML;
    try {
      Element eleOrderInDoc = doc.getDocumentElement();
      String strOrderHeaderKey =
          XMLUtil.getAttribute(eleOrderInDoc, KohlsXMLLiterals.A_ORDER_HEADER_KEY);
      Element eleOrderExtn = XMLUtil.getChildElement(eleOrderInDoc, KohlsXMLLiterals.E_EXTN);

      docOutXML = XMLUtil.createDocument("Order");
      Element eleOrder = docOutXML.getDocumentElement();
      Element eleExtn = docOutXML.createElement("Extn");
      Element eleKohlsOTRResponseList = XMLUtil.createChild(eleExtn, "KohlsOTRResponseList");
      Element eleKohlsOTRResponse =
          XMLUtil.createChild(eleKohlsOTRResponseList, "KohlsOTRResponse");

      eleOrder.appendChild(eleExtn);
      eleKohlsOTRResponse.setAttribute("ExtnOTRResponse",
          eleOrderExtn.getAttribute("ExtnOTRResponse"));
      eleKohlsOTRResponse.setAttribute("ExtnOTRResponseType",
          eleOrderExtn.getAttribute("ExtnOTRResponseType"));
      eleKohlsOTRResponse.setAttribute(EXTN_IS_RESTRICTED_RETURN,
              eleOrderExtn.getAttribute(EXTN_IS_RESTRICTED_RETURN));
      eleKohlsOTRResponse.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
      eleKohlsOTRResponse.setAttribute("ExtnDeductibleOffers",
          eleOrderExtn.getAttribute("ExtnDeductibleOffers"));
      eleKohlsOTRResponse.setAttribute("ExtnAuthorizedAwards",
          eleOrderExtn.getAttribute("ExtnAuthorizedAwards"));
      eleKohlsOTRResponse.setAttribute("ExtnLidOfferExempt",
          eleOrderExtn.getAttribute("ExtnLidOfferExempt"));
      eleKohlsOTRResponse.setAttribute("ExtnOrigPosSequenceNo",
          eleOrderExtn.getAttribute("ExtnOrigPosSequenceNo"));

    } catch (ParserConfigurationException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

  }
  /* Added for OTR Response change - END */

  public String getPropertyValue(String property) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.getPropertyValue");
    String propValue;
    propValue = YFSSystem.getProperty(property);
    // Manoj 10/22: updated to use configured property if
    // customer_overrides.properties does not return any value
    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.getPropertyValue");
    return propValue;

  }

  public Integer getActiveRKCEvent(YFSEnvironment env, String sGiftReceiptInd, Document docInXML) {
    log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.getRKCEvent");

    KohlsPoCRKC rkc = new KohlsPoCRKC();
    String sLogToFile = "";
    String sFilePath = "";
    String sRKCEventID = "";
    int countRkcEvent = 0;
    Document docOutRule = null;
    Element eleRule = null;
    Element eleOrder = docInXML.getDocumentElement();
    try {
      String sOrganizationCode = eleOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
      if(YFCCommon.isVoid(sOrganizationCode)){
        sOrganizationCode = "KOHLS-RETAIL";
      }
      String strRuleValue = rkc.checkRKC(env);
      if (strRuleValue != null && strRuleValue.equals("Y")) {
        try {
          sLogToFile = getPropertyValue(this.props.getProperty("LogRKCLogDir"));
          sFilePath = getPropertyValue(this.props.getProperty("LogRKCCallToFile"));
        } catch (Exception e) {
          sLogToFile = KohlsPOCConstant.NO;
        }
        if (log.isDebugEnabled()) {
          log.debug("LogRKCLogDir " + sLogToFile);
          log.debug("LogRKCCallToFile " + sFilePath);
        }
        if (("false".equals(sGiftReceiptInd)) || (sGiftReceiptInd.equals(""))) {
         /* docOutRule = rkc.getRuleList(env, "RKC_ACTIVE_EVENT",sOrganizationCode);
          eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);

          if (!YFCCommon.isVoid(eleRule)) {
            sRKCEventID = eleRule.getAttribute("RuleValue");
          }*/
          sRKCEventID = rkc.mapRKCEvent.get("RKC_ACTIVE_EVENT");
          
          if (YFCCommon.isVoid(sRKCEventID)) {
            try {

              Document docrkcResponse =
                  rkc.invokeRKCWebservice(env, docInXML, sLogToFile, sFilePath);
              rkc.getEventIDAndExpiryDate(docrkcResponse, env, sOrganizationCode);
              //docOutRule = rkc.getRuleList(env, "RKC_ACTIVE_EVENT",sOrganizationCode);
              //eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);

              sRKCEventID = rkc.mapRKCEvent.get("RKC_ACTIVE_EVENT");
              if (!YFCCommon.isVoid(sRKCEventID)) {
                //sRKCEventID = eleRule.getAttribute("RuleValue");
                countRkcEvent = rkc.getRKCEventCount(sRKCEventID);
              }
              env.setTxnObject("GetActiveRKCEvent", sRKCEventID);
            } catch (Exception e) {
            	  log.error("Exception while calling RKC Event ID webservice");
              //rkc.updateRKCEvents("", env, sOrganizationCode);
              env.setTxnObject("GetActiveRKCEvent", "");
            }
          } else {
            boolean bFlagToUpadteRKCEvent =
                rkc.checkUpdateRuleValue(sRKCEventID, env, sOrganizationCode, docOutRule);
            if (bFlagToUpadteRKCEvent) {
              try {
                Document docrkcResponse =
                    rkc.invokeRKCWebservice(env, docInXML, sLogToFile, sFilePath);
                rkc.getEventIDAndExpiryDate(docrkcResponse, env, sOrganizationCode);
                //docOutRule = rkc.getRuleList(env, "RKC_ACTIVE_EVENT",sOrganizationCode);
                //eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);

                sRKCEventID = rkc.mapRKCEvent.get("RKC_ACTIVE_EVENT");
                env.setTxnObject("GetActiveRKCEvent", sRKCEventID);
                /*if (!YFCCommon.isVoid(eleRule)) {
                  sRKCEventID = eleRule.getAttribute("RuleValue");
                  env.setTxnObject("GetActiveRKCEvent", sRKCEventID);
                }*/
              } catch (Exception e) {
                rkc.updateRKCEvents("", env,
                    eleOrder.getAttribute(KohlsXMLLiterals.A_CURRENT_STORE));
                env.setTxnObject("GetActiveRKCEvent", "");
              }

            } else {
              env.setTxnObject("GetActiveRKCEvent", sRKCEventID);
            }
            sRKCEventID = (String) env.getTxnObject("GetActiveRKCEvent");
            countRkcEvent = rkc.getRKCEventCount(sRKCEventID);
            if (log.isDebugEnabled()) {
              log.debug("The POCREturns docrkcResponse: " + sRKCEventID);

            }
          }
        }
      }
    } catch (Exception e) {
      log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.getRKCEvent");
      e.printStackTrace();
    }
    log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.getRKCEvent");
    return countRkcEvent;
  }

  private boolean isDebitTenderEnabled(YFSEnvironment env) throws Exception {

    if (log.isDebugEnabled()) {
      log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.isDebitTenderEnabled");
    }

    Document inDocGetRuleListForPOS = XmlUtils.createDocument(KohlsXMLLiterals.E_RULE);
    Element eleRule = inDocGetRuleListForPOS.getDocumentElement();
    eleRule.setAttribute(KohlsXMLLiterals.A_RULE_ID, "RET_DEBIT_ENABLER");
    eleRule.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, strOrgCode);
    if (log.isDebugEnabled())
      log.debug("Input to getRuleListForPOS  :" + XMLUtil.getXMLString(inDocGetRuleListForPOS));

    // invoke getRuleListForPOS API
    Document outDocGetRuleListForPOS = KOHLSBaseApi.invokeAPI(env,
        KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, inDocGetRuleListForPOS);

    if (log.isDebugEnabled())
      log.debug(
          "Output from  getRuleListForPOS  :" + XMLUtil.getXMLString(outDocGetRuleListForPOS));
    Element eleOutRule = XmlUtils.getChildElement(outDocGetRuleListForPOS.getDocumentElement(),
        KohlsXMLLiterals.E_RULE);
    if (!YFCCommon.isVoid(eleOutRule)) {

      if (eleOutRule.getAttribute(KohlsXMLLiterals.A_RULE_VALUE).equals(KohlsPOCConstant.YES)) {

        if (log.isDebugEnabled())
          log.debug("Debit Tender Enabled ");
        return true;
      }

    }

    return false;
  }

  /**
   * @param retSvcReqDocEle
   * @param storeNumber
   * @param terminalNumber
   * @param sequenceNumber
   * @param trnTimeStamp
   * @param operatorId
   * @param giftReceiptInd
   * @param lineSequenceNbr
   * @param countRkcEvent
   * @param returnRestrictionFlag
   */
  private void buildCommonTagsForLookUpRequest(Element retSvcReqDocEle, String storeNumber,
      String terminalNumber, String sequenceNumber, String trnTimeStamp, String operatorId,
      String giftReceiptInd, String lineSequenceNbr, int countRkcEvent ,String returnRestrictionFlag) {

    retSvcReqDocEle.setAttribute(KohlsXMLLiterals.A_XMLNS, KohlsXMLLiterals.A_XMLNS_VALUE_OAGIS);

    Element headerElement = XMLUtil.createChild(retSvcReqDocEle, KohlsPOCConstant.E_HEADER);
    headerElement.setAttribute(KohlsXMLLiterals.A_XMLNS_HEADER,
        KohlsXMLLiterals.A_XMLNS_HEADER_VALUE_AU);
    Element locNumberEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.LOCATION_NBR);
    XMLUtil.setNodeValue(locNumberEle, storeNumber);
    Element deviceIdEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.DEVICE_ID);
    XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
    Element txnNbrEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.TRANSACTION_NBR);
    XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
    Element txnTimstamp = XMLUtil.createChild(headerElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
    XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);
    
    Element txnCode = XMLUtil.createChild(headerElement, KohlsXMLLiterals.E_TRANSACTION_CODE);
    XMLUtil.setNodeValue(txnCode, KohlsXMLLiterals.A_RETURN);

    Element operatorIdEle = XMLUtil.createChild(headerElement, KohlsXMLLiterals.A_OPERATOR_ID);
    XMLUtil.setNodeValue(operatorIdEle, operatorId);
    Element trainingModeIndEle =
        XMLUtil.createChild(headerElement, KohlsXMLLiterals.E_TRAINING_MODE_IND);
    XMLUtil.setNodeValue(trainingModeIndEle, KohlsConstant.FALSE);
    Element giftReceiptIndEle =
        XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.GIFT_RECEIPT_IND);
    XMLUtil.setNodeValue(giftReceiptIndEle, giftReceiptInd);
    Element restrictedReturnIndicatorEle =
            XMLUtil.createChild(retSvcReqDocEle, RESTRICTED_RETURN_INDICATOR);
    
    if (KohlsPOCConstant.YES.equalsIgnoreCase(returnRestrictionFlag)) 
    {
    		log.info("KohlsReturnRestrictStatus:: Restricted Return Enabled Store? --> "+ KohlsConstant.TRUE);
       	XMLUtil.setNodeValue(restrictedReturnIndicatorEle, KohlsConstant.TRUE);
    }
    else
    {
    		log.info("KohlsReturnRestrictStatus:: Restricted Return Enabled Store? --> "+ KohlsConstant.FALSE);
    		XMLUtil.setNodeValue(restrictedReturnIndicatorEle, KohlsConstant.FALSE);
    }

    Element lineSequenceNbrEle = XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.LINE_SEQ_NO);
    XMLUtil.setNodeValue(lineSequenceNbrEle, lineSequenceNbr);
    Element refundSourceCdeEle =
        XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.E_REFUND_SOURCE_CDE);
    XMLUtil.setNodeValue(refundSourceCdeEle, KohlsXMLLiterals.A_RETURN);
    Element tenderIdProtected =
        XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.A_TENDER_ID_PROTECTED);
    XMLUtil.setNodeValue(tenderIdProtected, KohlsConstant.TRUE);
    Element partialProtection =
        XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.PARTIAL_PROTECTION);
    XMLUtil.setNodeValue(partialProtection, KohlsConstant.TRUE);

    if (("false".equals(giftReceiptInd)) || (giftReceiptInd.equals(""))) {

      if (countRkcEvent > 0) {
        Element returnKohlsCashInd =
            XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.RETURN_KOHLS_CASH_IND);
        XMLUtil.setNodeValue(returnKohlsCashInd, KohlsConstant.TRUE);
      }

    }

    // CAPE - 2023 Changes
    if (isDebitTenderEnabled) {
      Element eleReturnDebitEnabledInd =
          XMLUtil.createChild(retSvcReqDocEle, "ReturnDebitEnabledInd");

      XMLUtil.setNodeValue(eleReturnDebitEnabledInd, KohlsConstant.TRUE);

    }

  }

  /**
   * @param eleItemLookup
   * @param hmTransactionData
   */
  private void buildIgnoreTransaction(Element eleItemLookup,
      HashMap<String, ArrayList<String>> hmTransactionData) {

    boolean bPrevtranPresent = true;
    try {
    	Element eleTransactionsToIgnore = XMLUtil.createChild(eleItemLookup, "TransactionsToIgnore");
    	Iterator iterTranDate = hmTransactionData.keySet().iterator();
    	while (iterTranDate.hasNext()) {
    		bPrevtranPresent = false;
    		String sKey = (String) iterTranDate.next();
    		ArrayList<String> alValue = hmTransactionData.get(sKey);
    		String[] sCustAttributes = sKey.split("_");
    		String sText7 = sCustAttributes[0];
    		String sText8 = sCustAttributes[1];
    		String sText9 = sCustAttributes[2];
    		String sDate2 = sCustAttributes[3];
    		//removing locale code timezone from RS request
    		if(!YFCCommon.isVoid(sDate2)) {
    			SimpleDateFormat sdf = new SimpleDateFormat (KohlsPOCConstant.INV_DATE_FORMAT);
    			sDate2 = sdf.format(sdf.parse(sDate2));
    		}
    		Element eleTransaction = XMLUtil.createChild(eleTransactionsToIgnore, "Transaction");
    		Element eleTransactionKey = XMLUtil.createChild(eleTransaction, "TransactionKey");
    		Element eleLocationNbr = XMLUtil.createChild(eleTransactionKey, "LocationNbr");
    		XMLUtil.setNodeValue(eleLocationNbr, sText7);
    		Element eleDeviceId = XMLUtil.createChild(eleTransactionKey, "DeviceId");
    		XMLUtil.setNodeValue(eleDeviceId, sText8);
    		Element eleTransactionNbr = XMLUtil.createChild(eleTransactionKey, "TransactionNbr");
    		XMLUtil.setNodeValue(eleTransactionNbr, sText9);
    		Element eleTransactionTmst = XMLUtil.createChild(eleTransactionKey, "TransactionTmst");
    		XMLUtil.setNodeValue(eleTransactionTmst, sDate2);
    		Element eleItemsToIgnore = XMLUtil.createChild(eleTransaction, "ItemsToIgnore");
    		for (int i = 0; i < alValue.size(); i++) {
    			Element eleLineSequenceNbr = XMLUtil.createChild(eleItemsToIgnore, "LineSequenceNbr");
    			XMLUtil.setNodeValue(eleLineSequenceNbr, alValue.get(i));
    		}
    	}

    	if (bPrevtranPresent) {
    		Element eleCompleteSearchIndicator =
    				XMLUtil.createChild(eleItemLookup, KohlsXMLLiterals.A_COMPLETE_SEARCH_IND);
    		XMLUtil.setNodeValue(eleCompleteSearchIndicator, KohlsPOCConstant.FALSE);
    	}
    }
    catch (ParseException e) {
    	log.endTimer("KohlsBuildReturnsRSRequestFrmGravity.buildIgnoreTransaction");
    	e.printStackTrace();
    }
  }

}
