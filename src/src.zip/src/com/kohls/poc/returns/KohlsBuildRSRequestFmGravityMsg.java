/**
*
* Copyright 2016 Kohls All rights reserved.
* 
* Customer specific copyright notice     :General Desc of one line.
*
* File Name       : KohlsBuildRSRequestFmGravityMsg.java
*
* Description     :Kohls POC Returns
*
* Version         : 1.0.0.
*
* Created Date    :30-DEC-2016
* 
* Modification History:Modified by, on date.
**/
package com.kohls.poc.returns;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.CharacterData;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import com.kohls.poc.api.KohlsPoCGetOrderDetailForRSOffline;  
import com.kohls.poc.api.KohlsTranslateOTRResponse;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.common.util.KohlsXPathUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;

/**
 * This program is invoked through a service. 
 * This invokes series of services to connect to
 * Kohls Return services, parses the response and
 * build order object for Gravity usage
 *@version 1.0
 *@author POC Returns Team
 *
 */
public class KohlsBuildRSRequestFmGravityMsg implements YIFCustomApi {

    private static final YFCLogCategory log = YFCLogCategory.instance(KohlsBuildRSRequestFmGravityMsg.class.getName());
    private YIFApi api;
    private String operatorId = KohlsConstant.BLANK;
    //PST-4465
    String sPOCFeature = KohlsConstant.BLANK;
    String strOrgCode;
    boolean isDebitTenderEnabled = false;  

    // MAD-378 CR changes
    private Properties props;

    // MAD-378 CR changes

    /**
     * Constructor for KohlsBuildRSRequestFmGravityMsg
     * 
     * @throws YIFClientCreationException
     *             exception
     */
    public KohlsBuildRSRequestFmGravityMsg() throws YIFClientCreationException {
        api = YIFClientFactory.getInstance().getLocalApi();

    }

    @Override
    public void setProperties(Properties arg0) throws Exception {

	}
	
	
	/***	  
	 * 
	 * This method parses gravity requests and build the web service request
	 * that is compatible with Kohls Return service
	 * 
	 * Based on the length of the orderNo variable passed, it assumes
	 * either order no or receipt id for parsing
	 *@param env env
	 *@param inXML input from Gravity
	 *@return Document Response to Gravity with RS response
	 * @throws Exception 
	 */
	//Added throws for MAD-378
	public Document parseGravityRequestAndBuildRSRequest(YFSEnvironment env, Document inXML) throws Exception {
		if(YFCLogUtil.isDebugEnabled()){
			try {
				log.debug("######### connectToRSWebServiceNGetResponse input XML #########"+ KohlsUtil.extractStringFromNode(inXML));
			} catch (TransformerException e) {
				log.error("TransformerException in parseGravityRequestAndBuildRSRequest of KohlsBuildRSRequestFmGravityMsg. Details:"+e.getMessage());
			}
		}
		//System.out.print("Input in service parseGravityRequestAndBuildRSRequest: " + XMLUtil.getXMLString(inXML));
		if (YFCLogUtil.isDebugEnabled()) {
		log.debug("Input in service parseGravityRequestAndBuildRSRequest: " + XMLUtil.getXMLString(inXML));
		}
		Element inxmlEle=inXML.getDocumentElement();
		 
//		String scannedRecptNo = inxmlEle.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
		operatorId=inXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_OPERATOR_ID);

		Document retSvcRequestDoc=null;
		String storeNumber=inxmlEle.getAttribute(KohlsXMLLiterals.A_STORE_NUMBER);//  "StoreNumber"
		String terminalNumber = inxmlEle.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID); //TerminalID
		String sequenceNumber = inxmlEle.getAttribute(KohlsXMLLiterals.TRANSACTION_NBR);//TransactionNbr
		String trnTimeStamp = inxmlEle.getAttribute(KohlsXMLLiterals.A_TRANS_TIME_STAMP);//TransactionTmst
		strOrgCode = inxmlEle.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
		//Changes for PR-124 - Start
		
		sPOCFeature = inxmlEle.getAttribute( KohlsPOCConstant.POC_FEATURE );
		isDebitTenderEnabled = isDebitTenderEnabled(env);
        if(sequenceNumber!=null) {
        	retSvcRequestDoc = buildRetSvcRequest( storeNumber,  terminalNumber,  sequenceNumber,trnTimeStamp,operatorId,sPOCFeature);
        } 
        
        //Changes for PR-124 - End
        if (YFCLogUtil.isDebugEnabled()) {
		log.debug("The POCREturns retSvcRequestDoc: " + XMLUtil.getXMLString(retSvcRequestDoc));
        }
//        System.out.println("The retSvcRequestDoc: " + XMLUtil.getXMLString(retSvcRequestDoc));
//        if (scannedRecptNo.length() >=KohlsConstant.SCANNED_RECIEPT_LENGTH_26) {
//			retSvcRequestDoc=decryptReceiptId(env, inXML);
//		}else if (scannedRecptNo.length() == KohlsConstant.SCANNED_RECIEPT_LENGTH_17) {
//			retSvcRequestDoc=decryptOrderNo(scannedRecptNo);
//			orderNo=scannedRecptNo;
//		}else {
//			log.error("Invalid Receipt Id/Order No");
//			throw new YFCException("Invalid Receipt ID");
//		}
//		inXML.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_NUMBER, orderNo);
		env.setTxnObject(KohlsConstant.GRAVITY_IN_REQ, inXML);
		Document otrResponseXml=null;
	    boolean isReturnServiceOffline = false;
		try {
		otrResponseXml = invokeRSWebServiceCall(env, retSvcRequestDoc);

            if (YFCLogUtil.isDebugEnabled()) {
                log.debug("OTR Response XML is: " + XMLUtil.getXMLString(otrResponseXml));
            }
        } catch (Exception otre) {
            log.error("Exception in invokeRSWebServiceCall of KohlsBuildRSRequestFmGravityMsg. Details:"
                    + otre.getMessage());
            isReturnServiceOffline = true;
            // throw new YFCException(otre);

        }

        Document rsParseResponseXml = null;
        try {
            rsParseResponseXml = invokeRSResponseParsers(env, otrResponseXml);
        } catch (Exception parseExp) {
            log.error("Exception in invokeRSResponseParsers of KohlsBuildRSRequestFmGravityMsg. Details:"+ parseExp.getMessage());
            //OMNI2 - Added to block PSA for OMNI orders. - Start
            if(parseExp instanceof YFSException) {
				YFSException yfsEx = (YFSException) parseExp;
				if(KohlsPOCConstant.OMNI_PSA_ERR_CODE.equalsIgnoreCase(yfsEx.getErrorCode())) {
					throw yfsEx;
				}
			}
            //OMNI2 - Added to block PSA for OMNI orders. - End
            isReturnServiceOffline = true;
        }

        if (null == rsParseResponseXml) {
            log.debug("rsParseResponseXml is null   :");
            isReturnServiceOffline = true;
        }

        Document mergeRSResponseXml = null;

        try {
          
	  // MAD-377 Start
	  //PST-2405 As Transaction not found should be enabled from CORP Start
//            if (ServerTypeHelper.amIOnEdgeServer()) {
                if ((!YFCCommon.isStringVoid(sPOCFeature)) && KohlsPOCConstant.ATTR_PSA.equalsIgnoreCase(sPOCFeature)) {
                    log.debug("Entered PSAFeature is PSA");
                    if (null != rsParseResponseXml) {
                        Element eleRSRes = rsParseResponseXml.getDocumentElement();
                        Element orderExtnEle = (Element) eleRSRes.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
                        String extnOTRResponse = orderExtnEle.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE);
                        if ((!YFCCommon.isStringVoid(extnOTRResponse))
                                && KohlsXMLLiterals.V_TRANC_NOT_FOUND.equalsIgnoreCase(extnOTRResponse)) {
                            isReturnServiceOffline = true;
                        }
                    }
                }
	  //PST-2405 As Transaction not found should be enabled from CORP End
//            }
            // MAD-377 End

            // MAD-378 CR changes-enableRSOfflineHandling
	   // boolean enableRSOfflineHandling = false;
            //if( isReturnServiceOffline &&  sequenceNumber!=null && enableRSOfflineHandling){
            if (isReturnServiceOffline && sequenceNumber != null) {
                log.debug("RsOffline code starts here    :");
                // Prepare the XML to Gravity by looking into OMS
                Document OrderDetailsFromOMS = null;
                KohlsPoCGetOrderDetailForRSOffline kohlsPoCGetOrderDetailForRSOffline = new KohlsPoCGetOrderDetailForRSOffline();
                boolean checkSameDate = true;
                OrderDetailsFromOMS = kohlsPoCGetOrderDetailForRSOffline.getOrderDetailsForRSOffline(env, inXML,
                        checkSameDate);
                // MAD-590 changes
                updateIsPSASynched(env, sPOCFeature, OrderDetailsFromOMS, isReturnServiceOffline);
                return OrderDetailsFromOMS;

            }

            mergeRSResponseXml = checkAndMergeRSResponse(env, rsParseResponseXml);
            // Check if not RS offline and PSA not synched
            // MAD-590 changes
            updateIsPSASynched(env, sPOCFeature, mergeRSResponseXml, isReturnServiceOffline);

        } catch (Exception mergeExp) {
            log.error("Exception in checkAndMergeRSResponse of KohlsBuildRSRequestFmGravityMsg. Details:"
                    + mergeExp.getMessage());
            throw new YFCException(mergeExp);
        }
		
		return mergeRSResponseXml;
	}

    /**
     * Added as part of MAD-590.
     * 
     * @param env
     * @param sPOCFeature
     * @param mergeRSResponseXml
     * @throws ParserConfigurationException
     * @throws Exception
     * @throws SAXException
     * @throws IOException
     */
    void updateIsPSASynched(YFSEnvironment env, String sPOCFeature, Document mergeRSResponseXml,  boolean isReturnServiceOffline)
            throws ParserConfigurationException, Exception, SAXException, IOException {
        
       

        log.debug("KohlsBuildRSRequestFmGravityMsg.updateIsPSASynched-- Begin");
        if (ServerTypeHelper.amIOnEdgeServer()) {
            if ((!YFCCommon.isStringVoid(sPOCFeature)) && KohlsPOCConstant.ATTR_PSA.equalsIgnoreCase(sPOCFeature)) {
                log.debug("Entered as edge deployment is true and PSAFeature is PSA");
                if (null != mergeRSResponseXml) {
                    Element mergeRSElement = mergeRSResponseXml.getDocumentElement();
                    String status = mergeRSElement.getAttribute(KohlsPOCConstant.ATTR_STATUS);
                    // form the getOrderList input
                    Document orderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
                    Element orderElement = orderDoc.getDocumentElement();
                    orderElement.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
                            mergeRSElement.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
                    orderElement.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
                            mergeRSElement.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
                    orderElement.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
                            mergeRSElement.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));

                    Document orderListDoc = KohlsCommonUtil.invokeAPI(env,
                            XMLUtil.getDocument(KohlsPOCConstant.GetOrderListTemplateForPSAMidVoid),
                            KohlsPOCConstant.API_GET_ORDER_LIST, orderDoc);

                    if (!YFCCommon.isVoid(orderListDoc)) {
                        NodeList orderList = orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
                        if (orderList.getLength() > 0) {
                            Element orderListElement = (Element) orderList.item(0);
                            if (KohlsPOCConstant.STORE_ORDER_INVOICED.equals(status)) {
                                log.debug("Sale is synched to Corp   :");
                                Element extnElement = (Element) orderListElement.getElementsByTagName(
                                        KohlsPOCConstant.A_EXTN).item(0);
                                String extnPsaStatus = extnElement.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
                                if (!YFCCommon.isVoid(extnPsaStatus)
                                        && !KohlsPOCConstant.A_SYNCHED.equals(extnPsaStatus)) {
                                	//PST-3770 changes started 
                                	if(KohlsPOCConstant.EXTN_PSA_STARTED.equals(extnPsaStatus)
                                            || KohlsPOCConstant.EXTN_PSA_IN_PROGRESS.equals(extnPsaStatus)){
                                		log.debug("Inside loop as PSA status :"+XMLUtil.getElementXMLString(extnElement));
                                		String strNewOrganizationCode= XMLUtil.getAttribute(orderListElement, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
                                		XMLUtil.setAttribute(orderListElement, KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.YES);
                                		XMLUtil.setAttribute(orderListElement, KohlsPOCConstant.POC_FEATURE, KohlsPOCConstant.MID_VOID_SCENARIO);
                                		XMLUtil.setAttribute(orderListElement, KohlsPOCConstant.A_ORGANIZATION_CODE, strNewOrganizationCode);
                        				XMLUtil.setAttribute(extnElement, KohlsPOCConstant.EXTN_PSA_STATUS, "VOIDED");
                        				log.debug("extnElement ::"+XMLUtil.getElementXMLString(extnElement));
                        				XMLUtil.removeAttribute(orderListElement, KohlsPOCConstant.MAX_ORDER_STATUS);
                        				XMLUtil.removeAttribute(orderListElement, KohlsPOCConstant.A_STATUS);
                        				XMLUtil.removeAttribute(orderListElement, KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
                        				Element eleNewOrderPromotions = XMLUtil.getChildElement(orderListElement, KohlsPOCConstant.E_PROMOTIONS);
                        				if(!YFCCommon.isVoid(eleNewOrderPromotions)){
                        					NodeList nlNewPromotion = eleNewOrderPromotions.getElementsByTagName( KohlsPOCConstant.E_PROMOTION );
                        					if ( !YFCCommon.isVoid( nlNewPromotion ) && nlNewPromotion.getLength()>0)
                        					{
                        						for ( int i = 0; i < nlNewPromotion.getLength(); i++ )
                        						{
                        							Element eleNewPromotion = (Element) nlNewPromotion.item( i );
                        							Element eleNewPromotionExtn = XMLUtil.getChildElement(eleNewPromotion, KohlsPOCConstant.E_EXTN);
                        							String strExtnIsPsaPromotion = XMLUtil.getAttribute(eleNewPromotionExtn, KohlsPOCConstant.ISPSAPROMOTION);
                        							if(KohlsPOCConstant.YES.equalsIgnoreCase(strExtnIsPsaPromotion)){
                        								XMLUtil.setAttribute(eleNewPromotion, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.REMOVE);
                        							}else{
                        								eleNewOrderPromotions.removeChild(eleNewPromotion);
                        								i--;
                        							}
                        						}
                        					}
                        				}
							Document inChangeOrderDoc = XMLUtil.getDocumentForElement(orderListElement);
                        				log.debug("before calling change order ::"+XMLUtil.getXMLString(inChangeOrderDoc));
                        				Document changeOrderOutput = KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API,inChangeOrderDoc);
                                		
                                	}
                                    Element cleanRecptInd = XMLUtil.getChildElement(mergeRSElement,
                                            KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
                                    if (!YFCCommon.isVoid(cleanRecptInd) && !(KohlsPOCConstant.EXTN_PSA_STARTED.equals(extnPsaStatus)
                                            || KohlsPOCConstant.EXTN_PSA_IN_PROGRESS.equals(extnPsaStatus))) {
                                        log.debug("Set clean receipt as false for non synched PSA...:");
                                        XMLUtil.setNodeValue(cleanRecptInd, KohlsConstant.FALSE);
                                    }
                                }
                                //PST-3770 changes end

                            }
							// CPE-2472 changes start
                            if (!isReturnServiceOffline) {
                                log.debug("RS is online...");
                                NodeList additionalInfoList = mergeRSElement
                                        .getElementsByTagName(KohlsXMLLiterals.E_YFCADDITIONALINFO);
                                if (additionalInfoList.getLength() > 0) {
                                    Element additionalInfoElement = (Element) additionalInfoList.item(0);
                                    String endpoint = additionalInfoElement.getAttribute(KohlsPOCConstant.A_ENDPOINT);
                                    log.debug("The endpoint is  :" + endpoint);
                                    if (KohlsPOCConstant.ENDPOINT_LOCAL.equals(endpoint)) {
                                        Element cleanRecptInd = XMLUtil.getChildElement(mergeRSElement,
                                                KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
                                        if (!YFCCommon.isVoid(cleanRecptInd)) {
                                            log.debug("Set clean receipt as false when RSOnline and CorpDown scenario...:");
                                            // If the order is synched to Corp
                                            // we will not allow PSA
                                            XMLUtil.setNodeValue(cleanRecptInd, KohlsConstant.FALSE);
                                        }
                                    }

                                }
                            }

                            // CPE-2472 changes end
                        }
                    }

                }
            }
        }
        log.debug("KohlsBuildRSRequestFmGravityMsg.updateIsPSASynched-- End");

    
    
    }

    /**
     * Parses the order number to get store number, date and terminal ids
     * 
     * @param scannedOrderNo
     *            OrderNo or receipt number scanned/entered
     * @return Document document type with order details and additional
     *         attributes format
     */
    /*
     * private Document decryptOrderNo(String scannedOrderNo) { //
     * System.out.println(scannedOrderNo);
     * 
     * String storeNumber = null; String terminalNumber = null; StringBuffer
     * buffer = new StringBuffer(); DateFormat dateFormat = new
     * SimpleDateFormat(KohlsConstant.DATE_FORMAT); String sysdate =
     * dateFormat.format(new Date()); buffer.append(sysdate); String
     * sequenceNumber=null; if (scannedOrderNo != null) { storeNumber =
     * scannedOrderNo.substring(KohlsConstant.INDEX_6, KohlsConstant.INDEX_10);
     * terminalNumber = scannedOrderNo.substring(KohlsConstant.INDEX_10,
     * KohlsConstant.INDEX_13); sequenceNumber =
     * scannedOrderNo.substring(KohlsConstant.INDEX_13, KohlsConstant.INDEX_17);
     * }
     * 
     * String trnMonth=
     * scannedOrderNo.substring(KohlsConstant.INDEX_2,KohlsConstant.INDEX_4);
     * String trnDay=
     * scannedOrderNo.substring(KohlsConstant.INDEX_4,KohlsConstant.INDEX_6);
     * String trnYear=
     * scannedOrderNo.substring(KohlsConstant.INDEX_0,KohlsConstant.INDEX_2);
     * String trnTimeStamp=new
     * StringBuffer().append(KohlsConstant.TRN_CENTENARY)
     * .append(trnYear).append(
     * KohlsConstant.DATE_SPLIT).append(trnMonth).append(
     * KohlsConstant.DATE_SPLIT)
     * .append(trnDay).append(KohlsConstant.DAY_START_TIME).toString();
     * 
     * Document retSvcReqDoc = null; try { retSvcReqDoc = buildRetSvcRequest(
     * storeNumber, terminalNumber, sequenceNumber,trnTimeStamp,operatorId); }
     * catch (Exception e) { log.error(
     * "Exception in decryptOrderNo of KohlsBuildRSRequestFmGravityMsg. Details:"
     * +e.getMessage()); } //
     * System.out.println("XML in KohlsBuildRSRequestFmGravityMsg decryptOrderNo \n"
     * + XMLUtil.getXMLString(retSvcReqDoc)); return retSvcReqDoc; }
     */

	/**
	 * Parses the receipt id
	 * Invokes getOrderlist api with Extn/ExtnReceiptId attribute and
	 * parses the response to get order no, store number, sequence number 
	 * 
	 *@param env env variable
	 *@param inXML gravity input
	 *@return Document Document including RS Response
	 *@throws Exception
	 */
	/*private  Document decryptReceiptId(YFSEnvironment env, Document inXML)  {
		try{
		    Document docOrdList=getOMSOrderList(env,inXML);
		    Element eleDocOrdList=docOrdList.getDocumentElement();
	
			String storeNumber  = KohlsXPathUtil.getString(eleDocOrdList, KohlsXMLLiterals.XP_SELLER_ORG_CODE);
			String terminalNumber  = KohlsXPathUtil.getString(eleDocOrdList, KohlsXMLLiterals.XP_Teriminal_ID);
			String sequenceNumber  = KohlsXPathUtil.getString(eleDocOrdList, KohlsXMLLiterals.XP_POS_SEQUENCE_NO);
			
			orderNo=KohlsXPathUtil.getString(eleDocOrdList, KohlsXMLLiterals.XP_ORDER_NO);
			
			String trnTimeStamp=KohlsXPathUtil.getString(eleDocOrdList, KohlsXMLLiterals.XP_ORDER_CREATES);
		//	System.out.println("Store Id:" + storeNumber +
		//			 " terminalNo: " + terminalNumber + " transactionNo: " + sequenceNumber + " trnTimeStamp" + trnTimeStamp );
			Document retSvcReqDoc=buildRetSvcRequest( storeNumber,  terminalNumber,  sequenceNumber, trnTimeStamp,operatorId);
		//	System.out.println("XML in KohlsBuildRSRequestFmGravityMsg decryptReceiptId\n" + XMLUtil.getXMLString(retSvcReqDoc));
			return retSvcReqDoc;
		}
		catch(Exception e){
			 log.error("Exception in decryptReceiptId of KohlsBuildRSRequestFmGravityMsg. Details:"+e.getMessage());		
		}
		return null;
	}*/

	
	/**
	 * Build the return service request in the format required
	 * @param storeNumber Store No
	 * @param terminalNumber Terminal No
	 * @param sequenceNumber Seq No
	 * @param trnTimeStamp Timestamp
	 * @param operatorId Operator
	 * @param sPOCFeature 
	 * @return req document 
	 */
	private Document buildRetSvcRequest(String storeNumber, String terminalNumber, String sequenceNumber, 
				String trnTimeStamp, String operatorId, String sPOCFeature ) {
	 
		Document retSvcReqDoc = null;
		try {
		 retSvcReqDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_GET_OPEN_TO_RETURN);
		 Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();
		 retSvcReqDocEle.setAttribute(KohlsXMLLiterals.A_XMLNS, KohlsXMLLiterals.A_XMLNS_VALUE_OAGIS);
			 
		 Element headerElement = XMLUtil.createChild(retSvcReqDocEle, KohlsPOCConstant.E_HEADER);
		 headerElement.setAttribute(KohlsXMLLiterals.A_XMLNS_HEADER, KohlsXMLLiterals.A_XMLNS_HEADER_VALUE_AU);
		 Element locNumberEle=XMLUtil.createChild(headerElement, KohlsXMLLiterals.LOCATION_NBR);
		 XMLUtil.setNodeValue(locNumberEle,storeNumber);
		 Element deviceIdEle=XMLUtil.createChild(headerElement, KohlsXMLLiterals.DEVICE_ID);
		 XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
		 Element txnNbrEle=XMLUtil.createChild(headerElement, KohlsXMLLiterals.TRANSACTION_NBR);
		 XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
		 Element txnTimstamp=XMLUtil.createChild(headerElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
		 XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);
		 Element txnCode=XMLUtil.createChild(headerElement, KohlsXMLLiterals.E_TRANSACTION_CODE);
		 XMLUtil.setNodeValue(txnCode, KohlsXMLLiterals.A_RETURN);
		 
		 Element operatorIdEle=XMLUtil.createChild(headerElement, KohlsXMLLiterals.A_OPERATOR_ID);
		 XMLUtil.setNodeValue(operatorIdEle, operatorId);
		 Element trainingModeIndEle=XMLUtil.createChild(headerElement, KohlsXMLLiterals.E_TRAINING_MODE_IND);
		 XMLUtil.setNodeValue(trainingModeIndEle, KohlsConstant.FALSE);
		 
		 Element transactionKeyElement = XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.E_TRANSACTION_KEY);
		 locNumberEle=XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.LOCATION_NBR);
		 XMLUtil.setNodeValue(locNumberEle,storeNumber);
		 deviceIdEle=XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.DEVICE_ID);
		 XMLUtil.setNodeValue(deviceIdEle, terminalNumber);
		 txnNbrEle=XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.TRANSACTION_NBR);
		 XMLUtil.setNodeValue(txnNbrEle, sequenceNumber);
		 txnTimstamp=XMLUtil.createChild(transactionKeyElement, KohlsXMLLiterals.A_TRANS_TIME_STAMP);
		 XMLUtil.setNodeValue(txnTimstamp, trnTimeStamp);
		 Element capLevelEle=XMLUtil.createChild(retSvcReqDocEle, "CapLevel");
		 XMLUtil.setNodeValue(capLevelEle, "200");
		 
		 Element giftReceiptIndEle=XMLUtil.createChild(retSvcReqDocEle, KohlsXMLLiterals.GIFT_RECEIPT_IND);
		 XMLUtil.setNodeValue(giftReceiptIndEle, KohlsConstant.FALSE);
		 Element refundSourceCdeEle=XMLUtil.createChild(retSvcReqDocEle,KohlsXMLLiterals.E_REFUND_SOURCE_CDE);
		 XMLUtil.setNodeValue(refundSourceCdeEle,KohlsXMLLiterals.A_RETURN);
		 //Changes for PR-124 - Start
		 if((!YFCCommon.isStringVoid( sPOCFeature )) && KohlsPOCConstant.ATTR_PSA.equalsIgnoreCase( sPOCFeature )){
		 Element eleReturnKohlsCashInd = XMLUtil.createChild( retSvcReqDocEle, KohlsPOCConstant.E_RETURN_KOHLS_CASH_IND );
		 XMLUtil.setNodeValue( eleReturnKohlsCashInd, KohlsPOCConstant.TRUE );
		 if(isDebitTenderEnabled){
			 Element eleReturnDebitEnabledInd = XMLUtil.createChild(retSvcReqDocEle, KohlsPOCConstant.E_RETURN_DEBIT_ENABLED_IND);
			 XMLUtil.setNodeValue(eleReturnDebitEnabledInd, KohlsPOCConstant.TRUE);
		 }
		 }
		 //Changes for PR-124 - End
		}catch (ParserConfigurationException e) {
			 log.error("ParserConfigurationException in buildRetSvcRequest of KohlsBuildRSRequestFmGravityMsg. Details:"+e.getMessage());
		}
		 return retSvcReqDoc;
	}

	/**
	 * Invokes the OMS services that makes use of extended API
	 * to invoke the Return service web serice call
	 * 
	 *@param env env
	 *@param inDoc document to webservice
	 *@return Document response document
	 *@throws Exception
	 */
	public Document invokeRSWebServiceCall(YFSEnvironment env, Document inDoc) {
		Document rsResponseDoc = null;
		try {
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("invokeRSWebServiceCall Input XML : " + SCXmlUtil.getString(inDoc));
			}
			rsResponseDoc = KohlsCommonUtil.invokeService(env, KohlsConstant.WEBSERVICE_CALL_RS, inDoc); 

			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("invokeRSWebServiceCall Output XML : " + SCXmlUtil.getString(rsResponseDoc));
			}
		} catch (Exception e) {
			log.error("Exception in invoking the Return OTR service in invokeRSWebServiceCall " + e.getMessage());
			 throw new YFCException(e);
		}
		if (YFCLogUtil.isDebugEnabled()) {
			log.debug("End of invokeRSWebServiceCall -- the return Doc -->" + SCXmlUtil.getString(rsResponseDoc));
		}
		return rsResponseDoc;
	}
	
	/**
	 * Invokes various services that parse the response from Return service
	 * 
	 *@param env env
	 *@param inDoc input to parsers
	 *@return Document response document
	 *@throws Exception exception
	 */
	public Document invokeRSResponseParsers(YFSEnvironment env, Document inDoc) throws Exception {
		Document rsResponseDoc = null;
		try {
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("invokeRSResponseParsers Input XML : " + SCXmlUtil.getString(inDoc));
			}
			//since the response data is in Cdata section retrieve and handle
			//Element srcElem= (Element) inDoc.getElementsByTagName(KohlsXMLLiterals.ELE_M_RETURN).item(0);
			Element srcElem =  SCXmlUtil.getChildElement(inDoc.getDocumentElement(), KohlsXMLLiterals.ELE_M_RETURN);
			if (YFCLogUtil.isDebugEnabled()) {
			log.debug("invokeRSResponseParsers return element: " + SCXmlUtil.getString(srcElem));
			}
			/*---------------------------------------------------------------------------------------------------
			* Modified this code for the OTR response truncated issue. Also block the above code the the same.
			* * Defect#2682, 2685 and 1731 are raised for the this issue, this solution fix for those issues.
			*----------------------------------------start-------------------------------------------------------*/
			
			/*String srcElemStr=SCXmlUtil.getString(srcElem);
	    	int end11=srcElemStr.lastIndexOf(KohlsXMLLiterals.ELE_M_RETURN);
	    	log.error("end11: " + end11 + " lenght: " + srcElemStr.length());
	    	 Object childSrcNode = srcElem.getChildNodes().item(0);
	    	String cData= ((CharacterData)(childSrcNode)).substringData(0, end11);*/
	    	
	    	/*String cData="";
	    	StringBuffer cDataBuf=new StringBuffer();
	    	if( srcElem.hasChildNodes() ) {
	            NodeList childList = srcElem.getChildNodes();
	            int numOfChildren = childList.getLength();
	            for( int cnt=0; cnt<numOfChildren; cnt++ ) {
	                Object childSrcNode = childList.item(cnt);
	                if( childSrcNode instanceof CharacterData ) {
	                    if( childSrcNode instanceof Text ) {
	                    	int cDataLen=((CharacterData)(childSrcNode)).getLength();
							log.error("cDataLen :"+ cDataLen);							
	                    	int chunksize=1024;
	                    	for(int i=0;i<cDataLen;i=i+chunksize){
	                    		String subData= ((CharacterData)(childSrcNode)).substringData(i, chunksize);
								log.error("subData is: " +i+" "+ subData);
	                    		cDataBuf.append(subData);
	                    	}
	                    	cData = cDataBuf.toString();
	                        break;
	                    } 
	                } 
	            }
	    	}*/
			/*log.error("cdata is: " + cData);
	    	if (cData.trim() !=null){
	    		rsResponseDoc = KohlsCommonUtil.invokeService(env, KohlsConstant.Name_SPACE_REMOVER, XMLUtil.getDocument(cData));
				log.error("after space removal Output XML : " + SCXmlUtil.getString(rsResponseDoc));
	    		if (rsResponseDoc !=null)
	    			rsResponseDoc = KohlsCommonUtil.invokeService(env, KohlsConstant.KOHLS_RESPONSE_ORDER_FORMAT, rsResponseDoc);
				log.error("after order format Output XML : " + SCXmlUtil.getString(rsResponseDoc));
	    	}*/
			
			
			/*======================================Start modified code ===========================================*/
			String rsResponse = SCXmlUtil.getString(srcElem);
			if(rsResponse != null && rsResponse.contains("ShowOpenToReturn")){
				rsResponse = rsResponse.replace("&lt;", "<");
				rsResponse = rsResponse.replace("&gt;", ">");
				rsResponse = rsResponse.replace("m:processMessageResponse", "processMessageResponse");
				rsResponse = rsResponse.replace("m:return", "return");
				rsResponse = rsResponse.replace("oag:", "");
				
				YFCDocument yfcDocument=YFCDocument.getDocumentFor(rsResponse);
				YFCElement otrYFCElement = yfcDocument.getElementsByTagName("ShowOpenToReturn").item(0);
				
				otrYFCElement.removeAttribute("xmlns:oag");
				otrYFCElement.removeAttribute("xmlns:header");
				if (YFCLogUtil.isDebugEnabled()) {
				log.debug("OTR Element :"+otrYFCElement.toString());
				}
				rsResponseDoc = XmlUtils.createFromString(otrYFCElement.toString());
			}
			if (rsResponseDoc !=null) {
	    		//rsResponseDoc = KohlsCommonUtil.invokeService(env, KohlsConstant.KOHLS_RESPONSE_ORDER_FORMAT, rsResponseDoc);
				//PST-4465 - adding pocfeature parameter
	    		rsResponseDoc = (new KohlsTranslateOTRResponse()).translateRSResponse(env, rsResponseDoc, sPOCFeature);
	    		if (YFCLogUtil.isDebugEnabled()) {
				log.debug("after order format Output XML : " + SCXmlUtil.getString(rsResponseDoc));
	    		}
			}
			/*======================================End modified code ===========================================*/
			/*-------------------------------------------------------------------------------------------------
			* Modified this code for the OTR response truncated issue. Also block the above code the the same.
			* Defect#2682, 2685 and 1731 are raised for the this issue, this solution fix for those issues.
			*-----------------------------------------end------------------------------------------------------*/
			
			
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("invokeRSResponseParsers Output XML : " + SCXmlUtil.getString(rsResponseDoc));
			}
		} catch (Exception e) {
			log.error("Exception in invoking the invokeRSResponseParsers : " + e.getMessage());
			//OMNI2 - Added to block PSA for OMNI orders. - Start
			if(e instanceof YFSException) {
				YFSException yfsEx = (YFSException) e;
				if(KohlsPOCConstant.OMNI_PSA_ERR_CODE.equalsIgnoreCase(yfsEx.getErrorCode())) {
					throw yfsEx;
				}
			}
			//OMNI2 - Added to block PSA for OMNI orders. - End
		}
		if (YFCLogUtil.isDebugEnabled()) {
		log.debug("End of invokeRSResponseParsers -- the return Doc -->" + SCXmlUtil.getString(rsResponseDoc));
		}
		return rsResponseDoc;
	}
	
	
	/**
	 * Invokes check and merger service that combines the response from RS and getOrderdetails
	 * @param env env
	 * @param inDoc input doc to merge
	 * @return Document response doc
	 * @throws Exception exception
	 */
	public Document checkAndMergeRSResponse(YFSEnvironment env, Document inDoc) throws Exception {
		Document mergeRSResponseXml = null;
		try {
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("CheckAndMergeRSResponse Input XML : " + SCXmlUtil.getString(inDoc));
			}
			mergeRSResponseXml = KohlsCommonUtil.invokeService(env, KohlsConstant.CHEKCK_MERGE_RS_RESPONSE, inDoc);
			
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("CheckAndMergeRSResponse Output XML : " + SCXmlUtil.getString(mergeRSResponseXml));
			}
		} catch (Exception e) {
			log.error("Exception in invoking the CheckAndMergeRSResponse : " + e.getMessage());
			 throw new YFCException(e);
		}
		if (YFCLogUtil.isDebugEnabled()) {
		log.debug("End of CheckAndMergeRSResponse -- the return Doc -->" + SCXmlUtil.getString(mergeRSResponseXml));
		}
		return mergeRSResponseXml;
	}
	
	
	/**
	 * getOrderList API call with Extn/ExtnReceiptId
	 * @param env env
	 * @param inXML inxml with receipt id
	 * @return orderlist response document
	 */
	/*private Document getOMSOrderList(YFSEnvironment env, Document inXML) {

		Document outputDoc=null;
		try {
		Element eleInputOrder = inXML.getDocumentElement();
		String strEnterpriseCode = eleInputOrder.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
		String strDocumentType = eleInputOrder.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE);
		String strExtnRecp = eleInputOrder.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
		Document ordINXML=getOrderListInputXML(strExtnRecp,strEnterpriseCode, strDocumentType);
		
		outputDoc = KohlsCommonUtil.invokeAPI(env,KohlsXMLLiterals.XP_GET_ORDER_LIST_RECIEPT_ID, KohlsConstant.API_GET_ORDER_LIST, ordINXML);
		//Verified

		} catch (Exception yfc) {
			 log.error("Exception in getOMSOrderList of KohlsBuildRSRequestFmGravityMsg. Details:"+yfc.getMessage());
		}
		return outputDoc;
	}*/
	
	
	/**
	 * Constructs input xml for getOrderList input xml
	 * 
	 * @param strExtnRecp receipt no
	 * @param strEnterpriseCode ent code
	 * @param strDocumentType doc type
	 * @return Document req document
	 */
	/*private Document getOrderListInputXML(String strExtnRecp, String strEnterpriseCode, String strDocumentType){		
		Document yfcDocOrder=null;
		try {
			yfcDocOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		
		Element yfcEleGetOrder = yfcDocOrder.getDocumentElement();
		yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
		yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);
		Element extnElement=XMLUtil.createChild(yfcEleGetOrder, KohlsXMLLiterals.E_EXTN);
		extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, strExtnRecp);
		if(YFCLogUtil.isDebugEnabled()){
			log.error("getOrderDetails Input :" + XMLUtil.getXMLString(yfcDocOrder));
		}

		}
		catch(DOMException e){
			log.error("DOMException in getOrderListInputXML of KohlsBuildRSRequestFmGravityMsg. Details:"+e.getMessage());		
		}
		catch (ParserConfigurationException e) {
			log.error("ParserConfigurationException in getOrderListInputXML of KohlsBuildRSRequestFmGravityMsg. Details:"+e.getMessage());
		}
		return yfcDocOrder;
	}*/
	 
	private boolean isDebitTenderEnabled(YFSEnvironment env) throws Exception {

		    if (log.isDebugEnabled()) {
		      log.beginTimer("KohlsBuildReturnsRSRequestFrmGravity.isDebitTenderEnabled");
		    }

		    Document inDocGetRuleListForPOS = XmlUtils.createDocument(KohlsXMLLiterals.E_RULE);
		    Element eleRule = inDocGetRuleListForPOS.getDocumentElement();
		    eleRule.setAttribute(KohlsXMLLiterals.A_RULE_ID, "RET_DEBIT_ENABLER");
		    eleRule.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, strOrgCode);
		    if (log.isDebugEnabled())
		      log.debug("Input to getRuleListForPOS  :" + XMLUtil.getXMLString(inDocGetRuleListForPOS));

		    // invoke getRuleListForPOS API
		    Document outDocGetRuleListForPOS = KOHLSBaseApi.invokeAPI(env,
		        KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, inDocGetRuleListForPOS);

		    if (log.isDebugEnabled())
		      log.debug(
		          "Output from  getRuleListForPOS  :" + XMLUtil.getXMLString(outDocGetRuleListForPOS));
		    Element eleOutRule = XmlUtils.getChildElement(outDocGetRuleListForPOS.getDocumentElement(),
		        KohlsXMLLiterals.E_RULE);
		    if (!YFCCommon.isVoid(eleOutRule)) {

		      if (eleOutRule.getAttribute(KohlsXMLLiterals.A_RULE_VALUE).equals(KohlsPOCConstant.YES)) {

		        if (log.isDebugEnabled())
		          log.debug("Debit Tender Enabled ");
		        return true;
		      }

		    }

		    return false;
		  }
}
