package com.kohls.poc.returns.api;

/*
 * import java.io.File;
 * 
 * import javax.xml.parsers.DocumentBuilder; import javax.xml.parsers.DocumentBuilderFactory;
 */

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSStringUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
// import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCUpdateOTRResponseToDB {

  private static YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCUpdateOTRResponseToDB.class.getName());

  public static void main(String[] args) throws Exception {}

  public void updateOTRResponse(YFSEnvironment env, Document docInXML) throws Exception {

    logger.beginTimer("KohlsPoCUpdateOTRResponseToDB.updateOTRResponse");
    Document docKohlsOTROrder = XMLUtil.createDocument("KohlsOTROrder");
    Element eleKohlsOTROrder = docKohlsOTROrder.getDocumentElement();
    Element eleOrder = docInXML.getDocumentElement();
    Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
    String sCurrentStoreId = "";
    String sStoreNum = "";
    String sTerminalID = "";
    String sTranNo = "";
    String sOrderDate = "";
    String sTranAvailableAmt = "";
    String sEndPoint = "";
    String sPOSGiftReceiptOTROrderKey = "";
    boolean bIsPOSGiftReceipt = false;
    boolean bIsOTRRecordAlreadyPresent = false;

    if (ServerTypeHelper.amIOnEdgeServer()) {
      sEndPoint = (String) env.getTxnObject("GET_ORDER_LIST_ENDPOINT");
      env.setTxnObject("GET_ORDER_LIST_ENDPOINT", "");
      String sExtnPOCFeature = (String) env.getTxnObject(KohlsPOCConstant.EXTN_POC_FEATURE);
      if(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
    	  Element eleAdditionalInfo= XMLUtil.createChild(docKohlsOTROrder.getDocumentElement(),KohlsXMLLiterals.E_YFCADDITIONALINFO);
          eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,KohlsXMLLiterals.V_MOTHERSHIP);
      }
    }

    Document gravityInXML = (Document) env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
    sCurrentStoreId = gravityInXML.getDocumentElement().getAttribute("CurrentStore");

    // MJ 06-22: Changes for CAPE-3613 - start
    String LineSequenceNbr = gravityInXML.getDocumentElement().getAttribute("LineSequenceNbr");
    if (!YFCCommon.isVoid(LineSequenceNbr) && !("-1".equals(LineSequenceNbr))) {
      bIsPOSGiftReceipt = true;
    }
    // MJ 06-22: Changes for CAPE-3613 - end

    if (logger.isDebugEnabled()) {
      logger.debug("Order is" + XMLUtil.getXMLString(docInXML));
    }
    if (eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE)
        .equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
      sStoreNum = XPathUtil.getString(eleOrder, "//OrderLine/CustomAttributes/@Text7");
      sTerminalID = XPathUtil.getString(eleOrder, "//OrderLine/CustomAttributes/@Text8");
      sTranNo = XPathUtil.getString(eleOrder, "//OrderLine/CustomAttributes/@Text9");
      sOrderDate = XPathUtil.getString(eleOrder, "//OrderLine/CustomAttributes/@Date2");
      sTranAvailableAmt = eleOrder.getAttribute("OriginalTotalAmount");
    } else {
      sStoreNum = eleOrder.getAttribute("SellerOrganizationCode");
      sTerminalID = eleOrder.getAttribute("TerminalID");
      sTranNo = eleOrderExtn.getAttribute("ExtnOrigPosSequenceNo");
      sOrderDate = eleOrder.getAttribute("OrderDate");
      sTranAvailableAmt = eleOrder.getAttribute("TransactionAvailableAmt");
    }

    eleKohlsOTROrder.setAttribute("CurrentStoreID", sCurrentStoreId);
    eleKohlsOTROrder.setAttribute("StoreID", sStoreNum);
    eleKohlsOTROrder.setAttribute("TerminalID", sTerminalID);
    eleKohlsOTROrder.setAttribute("TranNo", sTranNo);
    String strEnvReturnPassNo = (String) env.getTxnObject(KohlsPOCConstant.RETURN_PASS_NUMBER);
    if(!YFCCommon.isVoid(strEnvReturnPassNo)){
    	if(!YFCCommon.isVoid(sTranNo) && sTranNo.length()<4){
    		eleKohlsOTROrder.setAttribute("TranNo", KOHLSStringUtil.prepadStringWithZeros(sTranNo, 4));
    	}
    	updateOTRLinesMatchingReturnPassLines(env, docInXML, strEnvReturnPassNo);
    }
    String sOTROrderListTemplate =
        "<KohlsOTROrderList><KohlsOTROrder OTROrderKey='' CurrentStoreID='' StoreID='' TerminalID='' TranNo='' ReturnPassNo=''/></KohlsOTROrderList>";
    env.setApiTemplate("getKohlsOTROrderList", XMLUtil.getDocument(sOTROrderListTemplate));
    KOHLSBaseApi objKOHLSBaseApi = new KOHLSBaseApi();
    Document docOutput = objKOHLSBaseApi.invokeService(env, "KohlsPoCGetKohlsOTROrderList", docKohlsOTROrder);
    env.clearApiTemplate("getKohlsOTROrderList");
    NodeList nOrderList = docOutput.getDocumentElement().getElementsByTagName("KohlsOTROrder");
    if (!YFCCommon.isVoid(nOrderList) && nOrderList.getLength() > 0) {
      for (int i = 0; i < nOrderList.getLength(); i++) {
        Element eleOTROrder = (Element) nOrderList.item(0);
        String sOtrKey = eleOTROrder.getAttribute("OTROrderKey");
        String sOTRCurrentStoreID = eleOTROrder.getAttribute("CurrentStoreID");
        String sOTRStoreID = eleOTROrder.getAttribute("StoreID");
        String sOTRTerminalID = eleOTROrder.getAttribute("TerminalID");
        String sOTRTranNo = eleOTROrder.getAttribute("TranNo");

        if (!(bIsPOSGiftReceipt && sOTRCurrentStoreID.equals(sCurrentStoreId)
            && sOTRStoreID.equals(sStoreNum) && sOTRTerminalID.equals(sTerminalID)
            && sOTRTranNo.equals(sTranNo))) {
          eleKohlsOTROrder.setAttribute("OTROrderKey", sOtrKey);
          objKOHLSBaseApi.invokeService(env, "KohlsPoCDeleteKohlsOTROrder", docKohlsOTROrder);
        } else {
          bIsOTRRecordAlreadyPresent = true;
          sPOSGiftReceiptOTROrderKey = sOtrKey;
        }
      }
      eleKohlsOTROrder.removeAttribute("OTROrderKey");
    }

    eleKohlsOTROrder.setAttribute("OrderDate", sOrderDate);
    eleKohlsOTROrder.setAttribute("TransactionAvailableAmt", sTranAvailableAmt);
    eleKohlsOTROrder.setAttribute("ResponseCode", eleOrderExtn.getAttribute("ExtnOTRResponse"));
    eleKohlsOTROrder.setAttribute("ResponseText", eleOrderExtn.getAttribute("ExtnOTRResponseType"));
    eleKohlsOTROrder.setAttribute("OrderNo", eleOrder.getAttribute("OrderNo"));
    if(!YFCCommon.isVoid(strEnvReturnPassNo)){
    	eleKohlsOTROrder.setAttribute(KohlsPOCConstant.RETURN_PASS_NO, strEnvReturnPassNo);
    }
    NodeList nlOrderLine = docInXML.getElementsByTagName("OrderLine");
    if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
      Element eleOTROrderLines = XMLUtil.createChild(eleKohlsOTROrder, "KohlsOTROrderLineList");
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        Element eleOTROrderLine = XMLUtil.createChild(eleOTROrderLines, "KohlsOTROrderLine");
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        // Changes for ISS - start
        /**if (!YFCCommon.isVoid(sEndPoint) && "MOTHERSHIP".equals(sEndPoint)) {
          eleOrderLine.setAttribute("DerivedFromExternalOrder", "Y");
          eleOrderLine.setAttribute("DerivedFromOrderHeaderKey",
              eleOrder.getAttribute("OrderHeaderKey"));
          eleOrderLine.setAttribute("DerivedFromOrderLineKey",
              eleOrderLine.getAttribute("OrderLineKey"));
        } **/
        // Changes for ISS - end
        Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, "Extn");
        Element eleItem = XMLUtil.getChildElement(eleOrderLine, "Item");
        eleOTROrderLine.setAttribute("OrderLineInfo", XMLUtil.getElementXMLString(eleOrderLine));
        eleOTROrderLine.setAttribute("IsItemReturned", eleOrderLine.getAttribute("IsReturnedItem"));
        eleOTROrderLine.setAttribute("PrimeLineNo", eleOrderLine.getAttribute("PrimeLineNo"));
        eleOTROrderLine.setAttribute("ItemID", eleItem.getAttribute("ItemID"));
        eleOTROrderLine.setAttribute("UPCCode", eleItem.getAttribute("UPCCode"));
        eleOTROrderLine.setAttribute("ReturnPrice", eleOrderLineExtn.getAttribute("ExtnReturnPrice"));
        eleOTROrderLine.setAttribute(KohlsPOCConstant.RETURN_PASS_NO, eleOrderLine.getAttribute(KohlsPOCConstant.RETURN_PASS_NO));
        eleOTROrderLine.setAttribute(KohlsPOCConstant.RETURN_PASS_ITEM_SEQ_NO, eleOrderLine.getAttribute(KohlsPOCConstant.RETURN_PASS_ITEM_SEQ_NO));
        eleOTROrderLine.setAttribute(KohlsPOCConstant.RETURN_PASS_ITEM_STATUS, eleOrderLine.getAttribute(KohlsPOCConstant.RETURN_PASS_ITEM_STATUS));
      }
    }
    Element elePaymentMethods = (Element) eleOrder.getElementsByTagName("PaymentMethods").item(0);

    NodeList nlPaymentMethod = elePaymentMethods.getElementsByTagName("PaymentMethod");
    if (!YFCCommon.isVoid(nlPaymentMethod) && nlPaymentMethod.getLength() > 0) {
      Element eleOTRPaymentMethods = XMLUtil.createChild(eleKohlsOTROrder, "KohlsOTRPaymentList");
      for (int i = 0; i < nlPaymentMethod.getLength(); i++) {
        Element eleOTRPaymentMethod = XMLUtil.createChild(eleOTRPaymentMethods, "KohlsOTRPayment");
        Element elePymtMethod = (Element) nlPaymentMethod.item(i);
        eleOTRPaymentMethod.setAttribute("PaymentType", elePymtMethod.getAttribute("PaymentType"));
        if ("DEBIT_CARD".equalsIgnoreCase(elePymtMethod.getAttribute("PaymentType"))) {
          eleOTRPaymentMethod.setAttribute("CreditCardNo",
              elePymtMethod.getAttribute("DebitCardNo"));
        } else {
          eleOTRPaymentMethod.setAttribute("CreditCardNo",
              elePymtMethod.getAttribute("CreditCardNo"));
        }
        eleOTRPaymentMethod.setAttribute("CreditCardType",
            elePymtMethod.getAttribute("CreditCardType"));
        if (eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE)
            .equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
          eleOTRPaymentMethod.setAttribute("AvailableAmount",
              elePymtMethod.getAttribute("TotalCharged"));
        } else {
          eleOTRPaymentMethod.setAttribute("AvailableAmount",
              elePymtMethod.getAttribute("RequestAmount"));
        }
        eleOTRPaymentMethod.setAttribute("RefundSeqNo",
            elePymtMethod.getAttribute("PaymentReference2"));
        eleOTRPaymentMethod.setAttribute("ExpirationDate",
            elePymtMethod.getAttribute("CreditCardExpDate"));
      //CAPE-4074 - start
        eleOTRPaymentMethod.setAttribute("EntryMethod",
            elePymtMethod.getAttribute("EntryMethod"));
      //CAPE-4074 - end
      }
    }

    if (bIsPOSGiftReceipt && bIsOTRRecordAlreadyPresent) {
      if (logger.isDebugEnabled()) {
        logger.debug("POS Order already present in OTR Table. So calling service KohlsPoCChangeKohlsOTROrder with input xml: \n"
            + XMLUtil.getXMLString(docKohlsOTROrder));
      }
      docKohlsOTROrder.getDocumentElement().setAttribute("OTROrderKey", sPOSGiftReceiptOTROrderKey);
      Document docTemplateDoc = XMLUtil.getDocument("<KohlsOTROrder OTROrderKey=''/>");
      env.setApiTemplate("changeKohlsOTROrder", docTemplateDoc);
      objKOHLSBaseApi.invokeService(env, "KohlsPoCChangeKohlsOTROrder", docKohlsOTROrder);
      env.clearApiTemplate("changeKohlsOTROrder");
    } else {
      if (logger.isDebugEnabled()) {
        logger.debug("Calling service KohlsPoCCreateKohlsOTROrder with input xml: \n"
            + XMLUtil.getXMLString(docKohlsOTROrder));
      }
      Document docTemplateDoc = XMLUtil.getDocument("<KohlsOTROrder OTROrderKey=''/>");
      env.setApiTemplate("createKohlsOTROrder", docTemplateDoc);
      objKOHLSBaseApi.invokeService(env, "KohlsPoCCreateKohlsOTROrder", docKohlsOTROrder);
      env.clearApiTemplate("createKohlsOTROrder");
    }

  }

  /** This method compares RS OrderLines with ReturnPass OrderLines. 
   * Allows only to store the OrderLines that are available in ReturnPass.
   * OrderLines matching ReturnPass response is stamped with ReturnPassNo
   * in Text3 of Order/CustomOverrides.
 * @param env
 * @param docInXML
 * @param strEnvReturnPassNo 
 */
  public void updateOTRLinesMatchingReturnPassLines(YFSEnvironment env, Document docInXML, String strEnvReturnPassNo) throws Exception{
	  logger.beginTimer("KohlsPoCUpdateOTRResponseToDB.updateOTRLinesMatchingReturnPassLines");

	  Element eleReturnPassItemLines = (Element) env.getTxnObject(KohlsPOCConstant.RETURN_PASS_ITEMS);
	  String strRPReceiptPreferenceMethod = (String) env.getTxnObject(KohlsPOCConstant.RP_RECEIPT_PREF_METHOD);
	  String strRPReceiptPreferenceEmailID = (String) env.getTxnObject(KohlsPOCConstant.RP_RECEIPT_PREF_EMAIL_ID);
	  String strRPRefundMethod = (String) env.getTxnObject(KohlsPOCConstant.RP_REFUND_PREF_METHOD);
	  
	  if(!YFCCommon.isVoid(eleReturnPassItemLines)){
		  try{
			  Document inDocClone = (Document) docInXML.cloneNode(true);
			  Element eleInXML = docInXML.getDocumentElement();
			  Element eleInXMLExtn = XMLUtil.getChildElement(eleInXML, KohlsPOCConstant.E_EXTN);
			  Element eleOrderLines = XMLUtil.getChildElement(eleInXML, KohlsPOCConstant.ELEM_ORDER_LINES);
			  eleInXML.removeChild(eleOrderLines);
			  Element eleEligibleOrderLines = XMLUtil.createChild(eleInXML, KohlsPOCConstant.ELEM_ORDER_LINES);
			  NodeList nlReturnPassItemLines = eleReturnPassItemLines.getElementsByTagName(KohlsPOCConstant.S_ITEM);
			  if (!YFCCommon.isVoid(nlReturnPassItemLines) && nlReturnPassItemLines.getLength() > 0) {
				  for (int i = 0; i < nlReturnPassItemLines.getLength(); i++) {
					  Element eleReturnPassItemLine = (Element) nlReturnPassItemLines.item(i);
					  String strReturnPassSkuNumber = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.SKU_NUMBER);
					  String strReturnPassLineSequenceNumber = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.LINE_SEQUENCE_NUMBER);
					  String strReturnPassReturnReasonCode = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.REASON_CODE);
					  String strReturnPassReturnReasonDesc = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.REASON_DESC);
					  String strReturnPassLineStatus = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.STATUS_LC);
					  NodeList nlOrderLine = XPathUtil.getNodeList(inDocClone,
							  "/Order/OrderLines/OrderLine[@PrimeLineNo='" + strReturnPassLineSequenceNumber+ "' and Item/@ItemID='" + strReturnPassSkuNumber + "']");
					  if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
						  Element eleEligibleOrderLine = (Element) nlOrderLine.item(0);
						  Element eleEligibleOrderLineExtn = XMLUtil.getChildElement(eleEligibleOrderLine, KohlsPOCConstant.E_EXTN, true);
						  Element eleCustomOverrides = XMLUtil.getChildElement(eleEligibleOrderLine, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
						  //Stamp ReturnPassNo
						  XMLUtil.setAttribute(eleCustomOverrides, KohlsPOCConstant.TEXT3, strEnvReturnPassNo);
						  XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.RETURN_PASS_NO, strEnvReturnPassNo);
						  XMLUtil.setAttribute(eleCustomOverrides, KohlsPOCConstant.TEXT9, eleInXMLExtn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO));
						  XMLUtil.setAttribute(eleCustomOverrides, KohlsPOCConstant.TEXT10, eleEligibleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
						  XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.RETURN_PASS_ITEM_SEQ_NO, strReturnPassLineSequenceNumber);
						  XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.RETURN_PASS_ITEM_STATUS, strReturnPassLineStatus);
						  XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.RP_RETURN_REASON_CODE, strReturnPassReturnReasonCode);
						  XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.RP_RETURN_REASON_DESC, strReturnPassReturnReasonDesc);
						  if(!(KohlsPOCConstant.PENDING.equalsIgnoreCase(strReturnPassLineStatus))){
							  XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.IS_RETURNED_ITEM, KohlsPOCConstant.YES);
						  }
						  Element eleItem = XMLUtil.getChildElement(eleEligibleOrderLine, KohlsPOCConstant.E_ITEM);
						  String strRPItemDescription = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.TITLE);
						  String strRPUPC = XMLUtil.getAttribute(eleReturnPassItemLine, KohlsPOCConstant.UPC);
						  if(!YFCCommon.isVoid(eleItem)){
							  if(!YFCCommon.isVoid(strRPItemDescription)){
							     XMLUtil.setAttribute(eleEligibleOrderLine, KohlsPOCConstant.RP_ITEM_DESC, strRPItemDescription);
							  }if(!YFCCommon.isVoid(strRPUPC)){
								  eleItem.setAttribute(KohlsPOCConstant.RP_UPC_CODE, strRPUPC);
							  }
						  }
						  Element eleOLAddnlDataList = XMLUtil.getChildElement(eleEligibleOrderLineExtn, KohlsPOCConstant.OL_ADDNL_DATA_LIST, true);

						  Element eleOLAddnlDataReturnPass = XMLUtil.createChild(eleOLAddnlDataList, KohlsPOCConstant.OL_ADDNL_DATA);
						  eleOLAddnlDataReturnPass.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.RETURN_PASS_NO);
						  eleOLAddnlDataReturnPass.setAttribute(KohlsPOCConstant.A_VALUE, strEnvReturnPassNo);

						  Element eleOLAddnlDataReceiptPrefMethod = XMLUtil.createChild(eleOLAddnlDataList, KohlsPOCConstant.OL_ADDNL_DATA);
						  eleOLAddnlDataReceiptPrefMethod.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.RP_RECEIPT_PREF_METHOD);
						  eleOLAddnlDataReceiptPrefMethod.setAttribute(KohlsPOCConstant.A_VALUE, strRPReceiptPreferenceMethod);

						  Element eleOLAddnlDataReceiptPrefEmailID = XMLUtil.createChild(eleOLAddnlDataList, KohlsPOCConstant.OL_ADDNL_DATA);
						  eleOLAddnlDataReceiptPrefEmailID.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.RP_RECEIPT_PREF_EMAIL_ID);
						  eleOLAddnlDataReceiptPrefEmailID.setAttribute(KohlsPOCConstant.A_VALUE, strRPReceiptPreferenceEmailID);

						  Element eleOLAddnlDataRefundPrefMethod = XMLUtil.createChild(eleOLAddnlDataList, KohlsPOCConstant.OL_ADDNL_DATA);
						  eleOLAddnlDataRefundPrefMethod.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.RP_REFUND_PREF_METHOD);
						  eleOLAddnlDataRefundPrefMethod.setAttribute(KohlsPOCConstant.A_VALUE, strRPRefundMethod);

						  Element eleOLAddnlDataRPItemEle = XMLUtil.createChild(eleOLAddnlDataList, KohlsPOCConstant.OL_ADDNL_DATA);
						  eleOLAddnlDataRPItemEle.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.RETURN_PASS_ITEM);
						  eleOLAddnlDataRPItemEle.setAttribute(KohlsPOCConstant.A_VALUE, KohlsXMLUtil.getElementXMLString(eleReturnPassItemLine));

						  eleEligibleOrderLines.appendChild(docInXML.importNode(eleEligibleOrderLine, true));
					  }
				  }
			  }
		  }catch(Exception e){
			  logger.error("Exception while parsing KohlsPoCUpdateOTRResponseToDB.updateOTRLinesMatchingReturnPassLines : ");
			  e.printStackTrace();
		  }
	  }
	  logger.endTimer("KohlsPoCUpdateOTRResponseToDB.updateOTRLinesMatchingReturnPassLines");
  }
}
