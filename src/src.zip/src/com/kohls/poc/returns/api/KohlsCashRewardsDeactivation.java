package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.psa.api.KohlsKCSCallForPSA;
import com.kohls.poc.psa.api.KohlsPSAKohlsCashDeactivation;
import com.kohls.poc.rest.KohlsReturnsLCSCallWrapper;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCashRewardsDeactivation {
    private static YFCLogCategory logger;
    private Properties props;
    String sExtnCouponSourceCode = "";

    static {
        logger = YFCLogCategory.instance(KohlsCashRewardsDeactivation.class.getName());

    }
   
    KohlsReturnsLCSDeactivation returnLcsobj = new KohlsReturnsLCSDeactivation();
    KohlsReturnsKCDeactivation returnKCSobj = new KohlsReturnsKCDeactivation();
    KohlsReturnsLCSCallWrapper  returnsLcsWrapper = new KohlsReturnsLCSCallWrapper();
    KohlsPSAKohlsCashDeactivation psaKCDeactiveObj = new KohlsPSAKohlsCashDeactivation();
    HashMap<String, Double> mpRefundAmtByTrans = new HashMap<String, Double>();
    HashMap<String, Element> mpCouponToPromotion = new HashMap<String, Element>();
    HashMap<String, Double> mpKCDeactivation = new HashMap<String, Double>();
    HashMap<String, Double> mpRefundDeductionHash = new HashMap<String, Double>();
    HashMap<String, String> mapReceiptDateTimeAscending = new HashMap<String, String>();
    HashMap<String, Double> mpFinalRefundDeductionMapByTransaction = new HashMap<String, Double>();
    public Element eleOrder = null;
    String sOHK ="";
    DecimalFormat df = new DecimalFormat("#0.00");
    boolean bProrationExists =false;
    
    
    @SuppressWarnings("unchecked")
    public Document deactivateKohlsCashRewards(YFSEnvironment env, Document orderInDoc ) throws Exception {
        logger.beginTimer("KohlsCashRewardsDeactivation.deactivateKohlsCashRewards");
        if(logger.isDebugEnabled()) {
          logger.debug("Input XML to KohlsCashRewardsDeactivation.deactivateKohlsCashRewards is: "+XMLUtil.getXMLString(orderInDoc));
        }
                
        Element eleOrderExtn = XMLUtil.getChildElement(orderInDoc.getDocumentElement(), KohlsXMLLiterals.E_EXTN);
        String sPOCFeature = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE);
        if(YFCCommon.isVoid(sPOCFeature)){
            sPOCFeature = "PostSaleAdjustment";
        }

        Document orderDetailsDoc = (Document) orderInDoc.cloneNode(true);
        Element eleInOrderRoot = orderInDoc.getDocumentElement();
        String sEndpoint = eleInOrderRoot.getAttribute(KohlsPOCConstant.A_ENDPOINT);
        String sCurrentStore = eleInOrderRoot.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
        
        //Call getOrderList api to unearn
        orderDetailsDoc = getOrderListForUnearning(env, orderInDoc, sPOCFeature, sEndpoint);
        
        eleOrder = XMLUtil.getChildElement(orderDetailsDoc.getDocumentElement(),KohlsPOCConstant.E_ORDER);
        
        if(YFCCommon.isVoid(eleOrder)) {
          logger.error("Order Not found. Hence KC not unearned");
          return XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
        }
        
        // Clear any previous promotions from previous unearning
        clearPreviousKCPromotions(env, eleOrder, sEndpoint, sPOCFeature);
        
        sOHK = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
         String sTerminalID = eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        //Getting current businessDate
        Date currentBusinessDay = returnsLcsWrapper.getCurrentBusinessDay (env, sCurrentStore, sTerminalID);
        logger.debug("Current business Date is: "+currentBusinessDay);
        Double dTotalRefundAmount = 0.00;
         Document docOut = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
        //If PA or returns, loop through KOHLS_CASH_UNEARNED promotions to call deactivate
        if(sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.RECEIPTED_RET) || 
                sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
            
            // Populate pricing map for Returns and PA
            dTotalRefundAmount = populatePricingMapForPAReturns(env, eleOrder, sPOCFeature); 
            
            logger.debug("mapReceiptDateTimeDescending value is: "+mapReceiptDateTimeAscending);
            
            //set Total refund amt for refund deduction
            returnLcsobj.dRefundAmount_Temp = dTotalRefundAmount;
            docOut.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dTotalRefundAmount));
            logger.debug("Initial Refund Amount is: "+df.format(dTotalRefundAmount));
            
            // if KC deactivation needs to be done - call KCS webservice
            NodeList nlUnearnPromotions = XPathUtil.getNodeList(eleOrder, 
                    "//Order/Promotions/Promotion[@PromotionType='"+ KohlsPOCConstant.KOHLS_CASH_UNEARNED + "']");
            if(!YFCCommon.isVoid(nlUnearnPromotions) && nlUnearnPromotions.getLength() >0){
              //KOHLS_CASH_UNEARNED is present, so unearning it.
              callKCSForReturnsPA(env, nlUnearnPromotions, orderDetailsDoc, dTotalRefundAmount, sPOCFeature);
            }
            logger.debug("After KCS Calls HashMap Values are: ");
            logger.debug("mpRefundDeductionHash: "+mpRefundDeductionHash);
            logger.debug("mpKCDeactivation: "+mpKCDeactivation);
            logger.debug("mpCouponToPromotion: "+mpCouponToPromotion);
        } else {
          // if PSA - call deactivation class 
          
          //Populate Pricing hash map
          populatePricingMapForPSA (env, eleOrder);
        	
          // Unearn Event KC for PSA
          callKCSForPSA(env, orderInDoc, sCurrentStore, sEndpoint, docOut);
          
          logger.debug("After KCS Call for PSA HashMap Values are: ");
          logger.debug("mpRefundDeductionHash: "+mpRefundDeductionHash);
          logger.debug("mpKCDeactivation: "+mpKCDeactivation);
          logger.debug("mpCouponToPromotion: "+mpCouponToPromotion);
          logger.debug("mpRefundAmtByTrans: "+mpRefundAmtByTrans);
        }

        // if Customer Loyalty is present - call LCS deactivation
        Document docLCSOut = null;
        Element eleLoyaltyList = XMLUtil.getChildElement(orderInDoc.getDocumentElement(), KohlsXMLLiterals.E_LOYALTY_LIST);
        if(!YFCCommon.isVoid(eleLoyaltyList)) {
            NodeList nlLoyalty = eleLoyaltyList.getElementsByTagName("Loyalty");
            if (nlLoyalty.getLength()>0) {
                Element inDocEle  = orderInDoc.getDocumentElement();
                inDocEle.setAttribute("Source", "ReturnLCSUnearn");
                try{
                  if(logger.isDebugEnabled()) {
                    logger.debug("LoyaltyCustomerDetails is present for atleast one transaction. So calling LCS with Inpout xml: "+XMLUtil.getXMLString(orderInDoc));
                  }
                  docLCSOut  = invokeServiceLocal(env, "KohlsPoCCallToLCSWrapper", orderInDoc);
                  if(logger.isDebugEnabled()) {
                    logger.debug("Output of LCS call is: "+XMLUtil.getXMLString(docLCSOut));
                  }
              }catch(Exception ex){
                  logger.error("Exception while LCS unearn"+ex.getMessage() );
              }
            }
        }
        //Updating LCS Coupons to CouponToPromotionMap
        if(!YFCCommon.isVoid(docLCSOut)) {
          // Process o/p of LCS 
          processLCSOutput(docLCSOut, sPOCFeature);
        }
        
        // Sort the mpRefundDeductionHash hasmap by refund deduction amt
        mpRefundDeductionHash = (HashMap<String, Double>) KohlsPoCCommonAPIUtil.sortHashMapByValue(mpRefundDeductionHash, "");
        
        //Sort mapReceiptDateTimeAscending by asc value of timestamp
        mapReceiptDateTimeAscending = (HashMap<String, String>)KohlsPoCCommonAPIUtil.sortHashMapByValue(mapReceiptDateTimeAscending, "ASC");
        
        // Prepare FinalRefundDeductionMap
        for(String key : mpRefundDeductionHash.keySet()){
            String strSource = key.substring(key.indexOf("-")+1,key.length());
            double dRefAmt = mpRefundAmtByTrans.get(strSource);
            double dRefDeductAmt = mpRefundDeductionHash.get(key);
            if(dRefAmt > dRefDeductAmt){
                mpRefundAmtByTrans.put(strSource , dRefAmt-dRefDeductAmt);
                if(mpFinalRefundDeductionMapByTransaction.containsKey(strSource)) {
                  mpFinalRefundDeductionMapByTransaction.put(strSource, dRefDeductAmt + mpFinalRefundDeductionMapByTransaction.get(strSource));
                } else {
                  mpFinalRefundDeductionMapByTransaction.put(strSource,dRefDeductAmt);
                }
            } else {
                if (mpKCDeactivation.containsKey(key)){
                    // If KC is also deactivated for same coupon then update the promotion 
                    //with refund deduction = 0 as we are going to ignore the refund deduction
                    mpKCDeactivation.remove(key);
                    Element promotion = mpCouponToPromotion.get(key);
                    XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN).setAttribute("ExtnRefundDeduction", "0");
                    
                } else {
                    // If there is no KC deactivated for this coupon and cannot process the refund 
                    //deduction then remove the promotion. We are not going to store that promotion.
                      mpRefundDeductionHash.remove(key);
                      mpCouponToPromotion.remove(key);
                }
            }
        }
        
        logger.debug("mpFinalRefundDeductionMapByTransaction values are: "+mpFinalRefundDeductionMapByTransaction);
           
        
        // Group the Promotions by Transaction, sort by refund deduction and append final list of promotions to out doc
        HashMap <String, Element> mpCouponToPromotion_temp = (HashMap<String, Element>) mpCouponToPromotion.clone();
        Element elePromotionsOut = XMLUtil.getChildElement(docOut.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS, true);

        // Use sorted hashmap based on transaction date time to start processing promotions
        for (String tranKey : mapReceiptDateTimeAscending.keySet()) {
            String tranDetails = tranKey;
            String sOriginalRefundAmt =
                docOut.getDocumentElement().getAttribute(KohlsPOCConstant.REFUND_AMT);
    
            String sRefundAmt = "";
            String strUnearnedKohlsCash = "";
            // Call TVS and prorate the refund deduction
            if(mpFinalRefundDeductionMapByTransaction.containsKey(tranDetails)) {
              // Process the refund deduction 
              sRefundAmt = processRefundDeductuionForTransaction(env, sPOCFeature, docOut, tranDetails, sOriginalRefundAmt);
            }
            logger.debug("Refund Amount for Transaction: " + tranDetails +" after refund deduction is: "+sRefundAmt);
            // Update the refund amount on all the coupons for this transaction
            for (String couponKeys : mpCouponToPromotion.keySet()) {
              if (couponKeys.contains(tranDetails)) {
                Element elePromoToBeUpdated = mpCouponToPromotion.get(couponKeys);
                Element elePromoToBeUpdatedExtn =
                    XMLUtil.getChildElement(elePromoToBeUpdated, KohlsPOCConstant.E_EXTN);
                String sExtnRefundDeduction =
                    elePromoToBeUpdatedExtn.getAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION);
                String sPromotionApplied = elePromoToBeUpdated.getAttribute(KohlsPOCConstant.PROMO_APPLIED);
                if(YFCCommon.isVoid(sPromotionApplied)) {
                  sPromotionApplied = "Y";
                }
                if (!YFCCommon.isVoid(sExtnRefundDeduction)
                    && Double.parseDouble(sExtnRefundDeduction) > 0.00D) {
                  returnLcsobj.updateOutputDocPromotion(env, elePromoToBeUpdated, sPromotionApplied, sRefundAmt,
                      "MaximizeRefund", currentBusinessDay);
                } else {
                  returnLcsobj.updateOutputDocPromotion(env, elePromoToBeUpdated, sPromotionApplied,
                      sOriginalRefundAmt, "MaximizeRefund", currentBusinessDay);
                }
                elePromoToBeUpdated.setAttribute("PreviousRefundAmount", sOriginalRefundAmt);
                // XMLUtil.removeChild(eleOrderPromotion, eleRfundDeduction);
              }
            }
            
            // Grouping the Promotions by transaction
            for (String key : mpCouponToPromotion.keySet()) {
            	// Append all deactivation coupons first and then refund deduction coupons
                String strSource = tranDetails;
              if (mpCouponToPromotion_temp.containsKey(key) &&
            		  key.contains(strSource)) {
               for (String temp_key : mpCouponToPromotion.keySet()) {
                  if (temp_key.contains(strSource)) {
                    Element eleOrderPromotion = mpCouponToPromotion.get(temp_key);
                    Element elePromoToBeUpdatedExtn =
                        XMLUtil.getChildElement(eleOrderPromotion, KohlsPOCConstant.E_EXTN);
                    String sExtnRefundDeduction =
                        elePromoToBeUpdatedExtn.getAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION);
                    if (YFCCommon.isVoid(sExtnRefundDeduction) || Double.parseDouble(sExtnRefundDeduction) == 0.00D) {
                      if(logger.isDebugEnabled()) {
                        logger.debug("Appending Deactivation promotion "+temp_key+" on the order "+XMLUtil.getElementXMLString(eleOrderPromotion));
                      }
                      XMLUtil.importElement(elePromotionsOut, eleOrderPromotion);
                      mpCouponToPromotion_temp.remove(temp_key);
                    }
                  }
                }
                // Add refund deduction coupons now
                for (String temp_key : mpCouponToPromotion.keySet()) {
                  if (temp_key.contains(strSource)) {
                    Element eleOrderPromotion = mpCouponToPromotion.get(temp_key);
                    Element elePromoToBeUpdatedExtn =
                        XMLUtil.getChildElement(eleOrderPromotion, KohlsPOCConstant.E_EXTN);
                    String sExtnRefundDeduction =
                        elePromoToBeUpdatedExtn.getAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION);
                    if (!YFCCommon.isVoid(sExtnRefundDeduction) && Double.parseDouble(sExtnRefundDeduction) > 0.00D) {
                        if(logger.isDebugEnabled()) {
                          logger.debug("Appending Refund deduction promotion "+temp_key+" on the order "+XMLUtil.getElementXMLString(eleOrderPromotion));
                        }
                        XMLUtil.importElement(elePromotionsOut, eleOrderPromotion);
                        mpCouponToPromotion_temp.remove(temp_key);
                    }
                  }
                }
              }
            }
            sOriginalRefundAmt = sRefundAmt;
        }
        
        // FOR PSA persists promotion and prorated document in KOHLS_SALES_FOR_PSA
        if(sPOCFeature.equalsIgnoreCase("PostSaleAdjustment")){
            postProcessingForPSA(env, docOut, sEndpoint);
        }
        
        //Import RKC Promotion if available
        updateOutputDocWithKCR(docOut, eleOrder);
        
        if(logger.isDebugEnabled()) {
          logger.debug("Out xml of KohlsCashRewardsDeactivation.deactivateKohlsCashRewards is: "+XMLUtil.getXMLString(docOut));
        }
        logger.endTimer("KohlsCashRewardsDeactivation.deactivateKohlsCashRewards");
        return docOut;

    }
    
    /**
     * @param constructs Promotions Kohls_CAsh_Unearned from the output
     * @return
     * @throws ParserConfigurationException 
     */
    private Document createPSAKohlsCashUnearnPromotions(Document docOut, String sSource) throws ParserConfigurationException {
        logger.beginTimer("KohlsCashRewardsDeactivation.createPSAKohlsCashUnearnPromotions");
        Element outEleRoot = docOut.getDocumentElement();
        Document docOrderOut = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
        DecimalFormat df = new DecimalFormat("#0.00");
        Element outOrderEleRoot = docOrderOut.getDocumentElement();
        outOrderEleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, outEleRoot.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
        String sCurrTrans = sSource.split("-")[2];
        Element elePSARedemptionPeriod  =XMLUtil.getChildElement(outEleRoot, KohlsPOCConstant.REDEMPTION_PERIOD); 
        Element elePSAUnearnedValue = XMLUtil.getChildElement(outEleRoot, KohlsPOCConstant.UNEARNED_VALUE); 
        Element elePSAKohlsCashBalance = XMLUtil.getChildElement(outEleRoot, KohlsPOCConstant.KC_BAL); 
        Element elePSAEarnedAmt = XMLUtil.getChildElement(outEleRoot, KohlsPOCConstant.EARNED_AMT); 
        Element eleKohlscashId  = XMLUtil.getChildElement(outEleRoot, KohlsXMLLiterals.A_KOHLS_CASH_ID); 
        Element elePSAMaximizeRefund = XMLUtil.getChildElement(outEleRoot, KohlsPOCConstant.MAX_REFUND, true); 
        String sRedeemPeriod ="", sUnearnedValue="", sKohlsCashBalance="",sEarnedAmt="",sKohlsCashId="";
        if(!YFCCommon.isVoid(elePSARedemptionPeriod)){
            sRedeemPeriod = elePSARedemptionPeriod.getTextContent();
        }
        if(!YFCCommon.isVoid(elePSAUnearnedValue)){
            sUnearnedValue = elePSAUnearnedValue.getTextContent();
        }
        if(!YFCCommon.isVoid(elePSAKohlsCashBalance)){
            sKohlsCashBalance = elePSAKohlsCashBalance.getTextContent();
        }
        if(!YFCCommon.isVoid(elePSAEarnedAmt)){
            sEarnedAmt = elePSAEarnedAmt.getTextContent();
        }
        if(!YFCCommon.isVoid(eleKohlscashId)){
            sKohlsCashId = eleKohlscashId.getTextContent();
        }
        if(!YFCCommon.isVoid(elePSARedemptionPeriod)){
        Element elePromos = XMLUtil.createChild(outOrderEleRoot, KohlsPOCConstant.E_PROMOTIONS);
        Element elePSAKCPromo = XMLUtil.createChild(elePromos,KohlsPOCConstant.E_PROMOTION);
        if(!YFCCommon.isVoid(outEleRoot.getAttribute(KohlsXMLLiterals.A_DISPLAY_PSA_KC_PROMPT))){
          elePSAKCPromo.setAttribute(KohlsXMLLiterals.A_DISPLAY_PSA_KC_PROMPT, outEleRoot.getAttribute(KohlsXMLLiterals.A_DISPLAY_PSA_KC_PROMPT));
        }
        elePSAKCPromo.setAttribute(KohlsPOCConstant.A_IS_PROCESSED, KohlsPOCConstant.NO);
        elePSAKCPromo.setAttribute(KohlsPOCConstant.KC_BAL, sKohlsCashBalance);
        elePSAKCPromo.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, sEarnedAmt);
        elePSAKCPromo.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.ACTION_CREATE);
        elePSAKCPromo.setAttribute(KohlsPOCConstant.PROMOTIONID, sKohlsCashId+"_"+sCurrTrans);
        //elePSAKCPromo.setAttribute(KohlsPOCConstant.A_PROMOTION_KEY, sKohlsCashId);
        elePSAKCPromo.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_UNEARNED);
        elePSAKCPromo.setAttribute(KohlsPOCConstant.REDEMPTION_PERIOD, sRedeemPeriod);
        if(!YFCCommon.isVoid(sUnearnedValue) && Double.parseDouble(sUnearnedValue) > 0.00D) {
          elePSAKCPromo.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
        } else {
          elePSAKCPromo.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
        }
        elePSAKCPromo.setAttribute(KohlsPOCConstant.UNEARNED_VALUE, sUnearnedValue);
        Element elePSAKCPromoExtn = XMLUtil.createChild(elePSAKCPromo, KohlsPOCConstant.E_EXTN);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE, sSource);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE, sKohlsCashBalance);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, outEleRoot.getAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION));
        double dAmtInitial=0;
        try{
            dAmtInitial= Double.parseDouble(sKohlsCashBalance) + Double.parseDouble(sUnearnedValue);
        }catch(Exception e){
            logger.error("recheck math values"+e.getMessage());
        }
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.A_EXTN_INITIAL_OFFER_AMT, sEarnedAmt);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.A_EXTN_OFFLINE_MODE, KohlsPOCConstant.NO);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE, sRedeemPeriod);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE, sUnearnedValue);
        elePSAMaximizeRefund.setAttribute(KohlsPOCConstant.PROMOTIONID, sKohlsCashId+"_"+sCurrTrans);
        XMLUtil.appendChild(elePSAKCPromo, (Element)docOrderOut.importNode(elePSAMaximizeRefund,true));
        // Set IsProcessed=Y
        elePSAKCPromo.setAttribute(KohlsPOCConstant.A_IS_PROCESSED, KohlsPOCConstant.YES);
        String sRefundDeduction="",strKCUnearnedValue="", strRefundAMount="";
        if(!YFCCommon.isVoid(elePSAMaximizeRefund)){
        	strRefundAMount = elePSAMaximizeRefund.getAttribute(KohlsPOCConstant.REFUND_AMT);
        	sRefundDeduction= elePSAMaximizeRefund.getAttribute(KohlsPOCConstant.REF_DEDUCTION);
        	strKCUnearnedValue =  elePSAMaximizeRefund.getAttribute(KohlsPOCConstant.UNEARNED_KC);
        }
        elePSAKCPromo.setAttribute(KohlsPOCConstant.REFUND_AMT, strRefundAMount);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.A_EXTNCOUPONNO, sKohlsCashId);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
        elePSAKCPromoExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED, KohlsXMLLiterals.CONST_Y);
        elePSAKCPromoExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KC_UNEARNED_VALUE, strKCUnearnedValue);
        elePSAKCPromoExtn.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION, sRefundDeduction);
        
        if(logger.isDebugEnabled()) {
          logger.debug("Promotion Element for PSA KCS is :"+XMLUtil.getElementXMLString(elePromos));
        }
       }
       
        logger.endTimer("KohlsCashRewardsDeactivation.createPSAKohlsCashUnearnPromotions");
        return docOrderOut;
    }
    
    /** 
     * @param env
     * @param serviceName
     * @param inDoc
     * @return
     * @throws Exception
     */
    Document invokeServiceLocal(YFSEnvironment env, String serviceName,
			Document inDoc) throws Exception {
        logger.beginTimer("KohlsCashRewardsDeactivation.invokeServiceLocal");
		Document docServiceOutput = KOHLSBaseApi.invokeService(env, serviceName, inDoc);
		logger.endTimer("KohlsCashRewardsDeactivation.invokeServiceLocal");
		return docServiceOutput;
	}
    
    /**
     * @param prop
     * @throws Exception
     */
    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
        // LOG_CAT.debug("In the set properties method");

    }
    /**
     * @param property
     * @return
     */
    public String getPropertyValue(String property) {
        logger.beginTimer("KohlsCashRewardsDeactivation.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        // Manoj 10/22: updated to use configured property if
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        logger.endTimer("KohlsCashRewardsDeactivation.getPropertyValue");
        return propValue;

    }
    /**
     * Create By mrjoshi * 
     * @param env
     * @param docOutput
     * @param sEndpoint
     * @param sPOCFeature
     * @return
     * @throws Exception
     */
    public void clearPreviousKCPromotions(YFSEnvironment env, Element eleOrder, String sEndpoint, String sPOCFeature) throws Exception {
        logger.beginTimer("KohlsCashRewardsDeactivation.clearPreviousKCPromotions");
        Document docChangeOrder = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleChangeOrderRoot = docChangeOrder.getDocumentElement();
        String sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        eleChangeOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
        eleChangeOrderRoot.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
        eleChangeOrderRoot.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
        eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_ACTION, KohlsConstant.MODIFY);
        eleChangeOrderRoot.setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.YES);
        Element eleChangeOrderPromotions = docChangeOrder.createElement(KohlsPOCConstant.E_PROMOTIONS);
        eleChangeOrderRoot.appendChild(eleChangeOrderPromotions);
        Element eleExtn = XMLUtil.createChild(eleChangeOrderRoot, KohlsXMLLiterals.E_EXTN);
        eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE, KohlsPOCConstant.EMPTY);
        eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_DEACTIVATED, KohlsPOCConstant.EMPTY);
        
        boolean bPromotionPresentForChangeOrder = false;
        
        Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
        if(!YFCCommon.isVoid(eleOrderExtn)) {
           Element elePromotions = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
            if(!YFCCommon.isVoid(elePromotions)) {
              NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
              for (int i=0; i< nlPromotion.getLength(); i++) {
                Element elePromotion = (Element) nlPromotion.item(i);
                String sPromotionType = elePromotion.getAttribute(KohlsCorpReturnsConstants.PROMOTION_TYPE);
                if((KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(sPromotionType) && "PostSaleAdjustment".equalsIgnoreCase(sPOCFeature)) 
                    || KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType)) {
                  Element eleChageOrderPomotion = XMLUtil.importElement(eleChangeOrderPromotions, elePromotion);
                  eleChageOrderPomotion.setAttribute("Action", "REMOVE");
                  bPromotionPresentForChangeOrder = true;
                }
            }
          } 
        }
        if(bPromotionPresentForChangeOrder) {
            Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
            
            //ISS change - start
            if (ServerTypeHelper.amIOnEdgeServer() && !YFCCommon.isVoid(sEndpoint)) {
              Element eleAdditionalInfo =
                    SCXmlUtil.createChild(eleChangeOrderRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
            }
            //ISS change - end
            
            if(logger.isDebugEnabled()) {
              logger.debug("KohlsCashRewardsDeactivation.clearPreviousLCSPromotions Input to changeOrder is: "+XMLUtil.getXMLString(docChangeOrder));
            }
            KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API, docChangeOrder);
            
            // If PSA, then update the KohlSaleForPSA table to set the PSAKCData as "" (blank)
            if("PostSaleAdjustment".equalsIgnoreCase(sPOCFeature)) {
              Document docInputForPSAData = XMLUtil.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA);
              Element eleInputForPSAData = docInputForPSAData
                      .getDocumentElement();
              eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
              eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_PSA_KC_DATA, "");
              //ISS change - start
              if (ServerTypeHelper.amIOnEdgeServer() && !YFCCommon.isVoid(sEndpoint)) {
                Element eleAdditionalInfo = XMLUtil.createChild(eleInputForPSAData, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
              }
              //ISS change - end
              KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docInputForPSAData);
            }
            
          } else {
            logger.debug("KohlsCashRewardsDeactivation.clearPreviousKCPromotions: Promotion not present to remove. Hence ChangeOrder is not called");
          }
        logger.endTimer("KohlsCashRewardsDeactivation.clearPreviousKCPromotions");
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param eleOrder
     * @throws Exception
     */
    public void populatePricingMapForPSA(YFSEnvironment env, Element eleOrder) throws Exception {
      logger.beginTimer("KohlsCashRewardsDeactivation.populatePricingMapForPSA");
      // getting original sale  from Kohls_sale_for_psa table to compare the changed awards
      Document docKohlsSaleForPSAIn = XMLUtil.createDocument("KOHLSSalesForPsa");
      Element eleKohlsSaleForPSAInRoot = docKohlsSaleForPSAIn.getDocumentElement();
      eleKohlsSaleForPSAInRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
      // ISS changes - start
      if (ServerTypeHelper.amIOnEdgeServer()) {
          String sEndpoint = "";
          if(!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
            sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
          }
          if(!YFCCommon.isVoid(sEndpoint)) {
            Element eleAdditionalInfo = SCXmlUtil.createChild(
                eleKohlsSaleForPSAInRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
            eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
          }
      }
      // ISS changes - end
      if(logger.isDebugEnabled()) {
        logger.debug("Input xml to service "+KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA+" is: "+XMLUtil.getXMLString(docKohlsSaleForPSAIn));
      }
      Document docKohlsSaleForPSAOut = KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docKohlsSaleForPSAIn);
      String sOriginalSaleData = docKohlsSaleForPSAOut.getDocumentElement().getAttribute("OriginalSaleData");
      Element eleOrigOrderLines = null;
      if(!YFCCommon.isVoid(sOriginalSaleData)) {
        Document docOrigSaleData = XMLUtil.getDocument(sOriginalSaleData);
        eleOrigOrderLines = XMLUtil.getChildElement(docOrigSaleData.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
      }
      KohlsKCSCallForPSA kcsForPSA = new KohlsKCSCallForPSA();
      Element promotions = XMLUtil.getChildElement(eleOrder ,KohlsXMLLiterals.E_PROMOTIONS);
      NodeList nlOrderLine = eleOrder.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        eleOrderLine.setAttribute("CallingSource",KohlsPOCConstant.V2_UNEARN);
        String sPrimeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
        Double dNetPrice = kcsForPSA.calculateItemDeltaPrice(eleOrderLine, promotions, eleOrigOrderLines);
        eleOrderLine.removeAttribute("CallingSource");
        if(dNetPrice > 0) {
          returnLcsobj.mapLinePrice.put(sPrimeLineNo, dNetPrice);
        }
      }
      logger.debug("returnLcsobj.mapLinePrice HashMap is: "+returnLcsobj.mapLinePrice);
      logger.endTimer("KohlsCashRewardsDeactivation.populatePricingMapForPSA");
    }
    
    /**
     * Create By mrjoshi * 
     * @param outDoc
     * @param elePromotionIn
     * @return
     * @throws Exception 
     * @throws ParserConfigurationException
     */
    private void updateOutputDocWithKCR(Document outDoc, Element eleOrder) throws Exception{
      logger.beginTimer("KohlsCashRewardsDeactivation.updateOutputDocWithKCR");
      Element eleOutPromotions = XMLUtil.getChildElement(outDoc.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS, true);
      Element eleRKCPromotion = (Element) XPathUtil.getNode(eleOrder, "//Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_REISSUE']");
      if(!YFCCommon.isVoid(eleRKCPromotion)) {
        if(logger.isDebugEnabled()) {
          logger.debug("RKC Promotion is available, hence importing"+ XMLUtil.getElementXMLString(eleRKCPromotion));
        }
        XMLUtil.importElement(eleOutPromotions, eleRKCPromotion);
      } else {
        logger.debug("RKC Promotion is not available, hence importing is skipped");
      }
      logger.endTimer("KohlsCashRewardsDeactivation.updateOutputDocWithKCR");
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param eleOrder
     * @param sPOCFeature
     * @return
     */
    private double populatePricingMapForPAReturns (YFSEnvironment env, Element eleOrder, String sPOCFeature) {
      logger.beginTimer("KohlsCashRewardsDeactivation.populatePricingMapForPAReturns");
      Double dTotalRefundAmount = 0.00D;
      //mpRefundAmtByTrans (sum of ExtnReturnPrice for each line belongs to the transaction)
      NodeList nlLines = eleOrder.getElementsByTagName("OrderLine");
      if(!YFCCommon.isVoid(nlLines) && nlLines.getLength()>0){
        for (int iLine = 0; iLine < nlLines.getLength(); iLine++) {
            Element eleLine = (Element)nlLines.item(iLine);
            String sOrderedQty = XMLUtil.getAttribute(eleLine, KohlsPOCConstant.ATTR_ORDERED_QTY);
            if (Double.parseDouble(sOrderedQty) == 0) {
                continue;
            }
            String sPrimeLineNo = eleLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
            Element extnLine = XMLUtil.getChildElement(eleLine,KohlsPOCConstant.E_EXTN);
            String sRetPrice = extnLine.getAttribute("ExtnReturnPrice");
            Element eleCustomAttributes = XMLUtil.getChildElement(eleLine,"CustomAttributes");
            String sOrigStore = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
            String sOrigTerminalId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
            String sOrigTranNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
            String sOrigLineId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT10);
            String sMultiChannelOrderNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT13);
            String sOriginalNetPrice = eleCustomAttributes.getAttribute("Text12");
            String sPAEligibleStatus = eleCustomAttributes.getAttribute("Text11");
            String sOrigDateTime = eleCustomAttributes.getAttribute("Date2");

            String sSourceTrans = sOrigStore+"-"+sOrigTerminalId+"-"+sOrigTranNo;

            //For PA, Use the adjusted amt as ReturnPrice
            if (sPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                Double dOriginalNetPrice = 0.00D;
                if (!YFCCommon.isVoid(sOriginalNetPrice)) {
                    dOriginalNetPrice = Double.parseDouble(sOriginalNetPrice);
                }
                double dTempTotal = dOriginalNetPrice - Double.parseDouble(sRetPrice);
                sRetPrice = df.format(dTempTotal);
                // If line is no PA Eligible or PA Adjusted amt is 0 then ignore the line.
                Double dDeltaTaxForPA = 0.00;
                if (dTempTotal > 0 && sPAEligibleStatus.equalsIgnoreCase("Eligible")) {
                    Element eleOrderLineTax = (Element) eleLine
                            .getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
                    Element eleOrderLineTaxExtn =
                            XMLUtil.getChildElement(eleOrderLineTax, KohlsPOCConstant.E_EXTN);
                    String strCurrentTax =
                            eleOrderLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                    String strInitialTax = eleOrderLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
                    if ((!YFCCommon.isVoid(strCurrentTax))
                            && (!YFCCommon.isVoid(strInitialTax))) {
                        dDeltaTaxForPA =
                                Double.parseDouble(strInitialTax) - Double.parseDouble(strCurrentTax);
                    }
                    NodeList nlCharges  = eleLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
                    Double deltaFee = KohlsPOCConstant.ZERO_DBL;
                    if(!YFCCommon.isVoid(nlCharges) && nlCharges.getLength()>0){
                        for (int iCharge = 0; iCharge < nlCharges.getLength(); iCharge++) {
                            Element eleCharge = (Element) nlCharges.item(iCharge);
                            if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))){
                              Element eleChargeExtn = XMLUtil.getChildElement(eleCharge, KohlsPOCConstant.E_EXTN);
                              String sOrigFeeAmt = eleChargeExtn.getAttribute(KohlsXMLLiterals.A_EXTN_ORIG_CHARGE_PER_LINE);
                              String sCurrentFeeAmt = eleCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
                              deltaFee = deltaFee + Double.parseDouble(sOrigFeeAmt) - (Double.parseDouble(sCurrentFeeAmt));
                            }
                        }
                    }
                    Double dAdjustedLineTotal = dTempTotal + dDeltaTaxForPA + deltaFee;
                    returnLcsobj.mapLinePrice.put(sPrimeLineNo, dAdjustedLineTotal);
                    dDeltaTaxForPA = 0.00;
                    dTotalRefundAmount = dTotalRefundAmount + dAdjustedLineTotal;
                } else {
                    continue;
                }
            } else {
                Element eleLinePriceInfo = (Element) eleLine
                        .getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
                String sLineTotal = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_LINE_TOTAL);
                returnLcsobj.mapLinePrice.put(sPrimeLineNo, Double.parseDouble(sLineTotal));
                dTotalRefundAmount = dTotalRefundAmount + Double.parseDouble(sLineTotal);
            }
            
            // If its ECOM order then store the LineTax rate in hashmap
            if(!YFCCommon.isVoid(sMultiChannelOrderNo)) {
              Double dTaxRate = 0.00D;
              Element eleOrderLineTax = (Element) eleLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
              if(!YFCCommon.isVoid(eleOrderLineTax)) {
                String sTaxRate = eleOrderLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
                if(!YFCCommon.isVoid(sTaxRate)) {
                  dTaxRate = Double.parseDouble(sTaxRate);
                }
              }
              returnLcsobj.mapOrigtaxRate.put(sOrigStore+"-"+sOrigTerminalId+"-"+sOrigTranNo+"-"+sOrigLineId, dTaxRate);
            }
            
            //Update the info in mpRefundAmtByTrans map
            if( !mpRefundAmtByTrans.isEmpty() && mpRefundAmtByTrans.containsKey(sSourceTrans)){
                mpRefundAmtByTrans.put(sSourceTrans,mpRefundAmtByTrans.get(sSourceTrans)+Double.parseDouble(sRetPrice));
            } else {
                mpRefundAmtByTrans.put(sSourceTrans, Double.parseDouble(sRetPrice));
            }
            // Update the map to sort the transaction desc based on Receipt Date time
            mapReceiptDateTimeAscending.put(sSourceTrans, sOrigDateTime);
        }
      }
      logger.debug("returnLcsobj.mapLinePrice HashMap is: "+returnLcsobj.mapLinePrice);
      logger.endTimer("KohlsCashRewardsDeactivation.populatePricingMapForPAReturns");
      return dTotalRefundAmount;
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param nlUnearnPromotions
     * @param orderDetailsDoc
     * @param dTotalRefundAmount
     * @param sPOCFeature
     * @throws Exception
     */
    private void callKCSForReturnsPA (YFSEnvironment env, NodeList nlUnearnPromotions, Document orderDetailsDoc, Double dTotalRefundAmount, String sPOCFeature) throws Exception {
      logger.beginTimer("KohlsCashRewardsDeactivation.callKCSForReturnsPA");
      String sPromoId ="";
      Document docKCSOut = null;
      String sCouponNo="";
      String sCouponBalance="";
      String sCouponAmt="";
      String sQualifyAmt="";
      HashMap<String,String> mapRunningKCUnearnInfo = new HashMap <String, String> ();
      for (int i = 0; i < nlUnearnPromotions.getLength(); i++) {
          Element eleOrderPromo = (Element)nlUnearnPromotions.item(i);
          Element elePromotionExtn = XMLUtil.getChildElement(eleOrderPromo, KohlsPOCConstant.E_EXTN);
          String sCouponSrcCode =  elePromotionExtn.getAttribute("ExtnCouponSourceCode");
          logger.debug("Calling KCS for transaction: "+sCouponSrcCode);
          env.setTxnObject(KohlsPOCConstant.CURR_PROCESS_TRANSACTION, sCouponSrcCode);
          sPromoId = eleOrderPromo.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
          eleOrder.setAttribute("LastReceiptProcessed", sExtnCouponSourceCode);
          returnKCSobj.callingSource = KohlsPOCConstant.V2_UNEARN;;
          returnKCSobj.docGetOrderListOuput = orderDetailsDoc;
          sCouponBalance = elePromotionExtn.getAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE);
          sCouponAmt = elePromotionExtn.getAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT);
          sQualifyAmt = elePromotionExtn.getAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT);
          sCouponNo = elePromotionExtn.getAttribute(KohlsPOCConstant.A_EXTNCOUPONNO);
          // If hashmpa does not have coupon then set the coupon info in it
          if(!mapRunningKCUnearnInfo.containsKey(sCouponNo)){
            mapRunningKCUnearnInfo.put(sCouponNo, sCouponAmt+"_"+sCouponBalance+"_"+sQualifyAmt);
          } else if (mapRunningKCUnearnInfo.containsKey(sCouponNo)){
            // if Hashmap already has same coupon then set the Promotion values from hashmap
            String[] sCouponRunningValue = mapRunningKCUnearnInfo.get(sCouponNo).split("_");
            elePromotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT, sCouponRunningValue[0]);
            elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE, sCouponRunningValue[1]);
            elePromotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, sCouponRunningValue[2]);
          }
          logger.debug("Current values in mapRunningKCUnearnInfo are: "+mapRunningKCUnearnInfo);
          if(i==0) {
              docKCSOut = XMLUtil.createDocument("Order");
              Element eleKCSOut = docKCSOut.getDocumentElement();
              eleKCSOut.setAttribute("OrderHeaderKey", eleOrder.getAttribute("OrderHeaderKey"));
              eleKCSOut.setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dTotalRefundAmount));
              Element eleExtn = XMLUtil.createChild(eleKCSOut, KohlsPOCConstant.E_EXTN);
              eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE, sPOCFeature);
          }
          
          docKCSOut = returnKCSobj.deactivateKohlsCash(env, docKCSOut);
          
          if(logger.isDebugEnabled()) {
            logger.debug("Output of KCS Call is: "+XMLUtil.getXMLString(docKCSOut));
          }
          // get the recently processed Promotions
          Element eleProcessedPromotion = (Element) XPathUtil.getNode(docKCSOut, "//Order/Promotions/Promotion[Extn/@ExtnCouponSourceCode='"+sCouponSrcCode+"']");
          if(!YFCCommon.isVoid(eleProcessedPromotion)) {
              sPromoId = eleProcessedPromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
              Element eleProcessedPromotionExtn = XMLUtil.getChildElement(eleProcessedPromotion, KohlsPOCConstant.E_EXTN);
              Element eleProcessedPromotionmaxRefund = XMLUtil.getChildElement(eleProcessedPromotion, KohlsPOCConstant.MAX_REFUND);
              eleProcessedPromotionExtn.setAttribute(KohlsPOCConstant.A_EXTNCOUPONNO, sCouponNo);
              
              String sRefundDeduction="0",sUnearnValue="0" ;
              if(!YFCCommon.isVoid(eleProcessedPromotionmaxRefund)){
                  sRefundDeduction= eleProcessedPromotionmaxRefund.getAttribute(KohlsPOCConstant.REF_DEDUCTION);
                  sUnearnValue =  eleProcessedPromotionmaxRefund.getAttribute(KohlsPOCConstant.UNEARNED_KC);
              }
              eleProcessedPromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION, sRefundDeduction);
              eleProcessedPromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
              eleProcessedPromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED, KohlsXMLLiterals.CONST_Y);
              //RefundReduction > 0 then put in details to map for futher TVS calls
              if(!YFCCommon.isVoid(sRefundDeduction) && Double.parseDouble(sRefundDeduction) > 0 ){
                  mpRefundDeductionHash.put(sPromoId+"-"+sCouponSrcCode, Double.parseDouble(sRefundDeduction));
              }
              // Check if the promotion has KC Deactivated, then add to the mpKCDeactivation map
              //String sUnearnValue =  eleProcessedPromotionExtn.getAttribute(KohlsPOCConstant.EXTN_KC_UNEARNED_VALUE);
              
              eleProcessedPromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_UNEARNED_VALUE, sUnearnValue);
              if(!YFCCommon.isVoid(sUnearnValue) && Double.parseDouble(sUnearnValue) >0) {
                mpKCDeactivation.put(sPromoId+"-"+sCouponSrcCode, Double.parseDouble(sUnearnValue));
              }
               
               // Set IsProcessed=Y
               eleProcessedPromotion.setAttribute("IsProcessed", "Y");
               
               // If hashmap has the coupon then update the values after unearning
               if(mapRunningKCUnearnInfo.containsKey(sCouponNo)){
                 String[] sCouponRunningValue = mapRunningKCUnearnInfo.get(sCouponNo).split("_");
                 Double dCouponAmt = Double.parseDouble(sCouponRunningValue[0]) - (Double.parseDouble(sUnearnValue) + Double.parseDouble(sRefundDeduction));
                 Double dCouponBalance = Double.parseDouble(sCouponRunningValue[1]) - Double.parseDouble(sUnearnValue);
                 String sEligibilityDeduction = eleProcessedPromotionExtn.getAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION);
                 Double dCouponQualifyAmt = Double.parseDouble(sCouponRunningValue[2]) - Double.parseDouble(sEligibilityDeduction);
                 
                 mapRunningKCUnearnInfo.put(sCouponNo, df.format(dCouponAmt)+"_"+df.format(dCouponBalance)+"_"+df.format(dCouponQualifyAmt));
               }
               
               // Add Promotion element to mpCouponToPromotion map
               mpCouponToPromotion.put(sPromoId+"-"+sCouponSrcCode,eleProcessedPromotion);
               
               // Set Eligible Lines for KCS
               if(!YFCCommon.isVoid(returnKCSobj.kcsResponseDoc)) {
                 if(logger.isDebugEnabled()) {
                   logger.debug("KCS Response is: "+XMLUtil.getXMLString(returnKCSobj.kcsResponseDoc));
                 }
                 logger.debug("Setting eligibleItems from KCS response");
                 Element eleKCSOutput = returnKCSobj.kcsResponseDoc.getDocumentElement(); 
                 Element eleData = (Element) eleKCSOutput.getElementsByTagName(KohlsPOCConstant.E_DATA).item(0);
                 if (!YFCCommon.isVoid(eleData)) {
                   Element eleReturnableItemList =
                       XMLUtil.getChildElement(eleData, KohlsXMLLiterals.E_RETURNABLE_ITEMLIST);
                   if (!YFCCommon.isVoid(eleReturnableItemList)) {
                     NodeList nlReturnableItemList = eleReturnableItemList.getElementsByTagName(KohlsXMLLiterals.E_RETURNABLE_ITEM);
                     for (int j=0; j<nlReturnableItemList.getLength(); j++) {
                       Element eleReturnableItem = (Element)nlReturnableItemList.item(j);
                       Element eleKohlsCashEligible =
                           XMLUtil.getChildElement(eleReturnableItem, KohlsXMLLiterals.E_KOHLS_CASH_ELIGIBLE);
                       String sKohlsCashEligible = XMLUtil.getNodeValue(eleKohlsCashEligible);
                       if ((KohlsPOCConstant.TRUE).equalsIgnoreCase(sKohlsCashEligible)) {
                        Element eleLineNo = XMLUtil.getChildElement(eleReturnableItem, KohlsXMLLiterals.E_LINE_NO);
                        String strLineNo = XMLUtil.getNodeValue(eleLineNo);
                        Element eleKCEligibleOrderLine = SCXmlUtil.getXpathElement(eleOrder,
                            "OrderLines/OrderLine[@PrimeLineNo=" + strLineNo + "]");
                        Element eleKCEligibleOrderLineExtn = XMLUtil.getChildElement(eleKCEligibleOrderLine, KohlsXMLLiterals.E_EXTN);
                        eleKCEligibleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE, KohlsXMLLiterals.CONST_TRUE);
                       }
                     }
                   }
                 }
               }
          }
          // Set the current promotion as processed promotion
          sExtnCouponSourceCode = sCouponSrcCode;
      }
      logger.endTimer("KohlsCashRewardsDeactivation.callKCSForReturnsPA");
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param orderInDoc
     * @param sCurrentStore
     * @param sEndpoint
     * @param docOut
     * @throws Exception
     */
    private void callKCSForPSA(YFSEnvironment env, Document orderInDoc, String sCurrentStore, String sEndpoint, Document docOut) throws Exception {
      logger.beginTimer("KohlsCashRewardsDeactivation.callKCSForPSA");
      Document docPSAKCSOut = null;
      orderInDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_STORE_ID, sCurrentStore);
      String sOrigRefundAmount = orderInDoc.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT);
      Double dOrigRefundAmount = Double.valueOf(sOrigRefundAmount);
      orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dOrigRefundAmount));
      docOut.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dOrigRefundAmount));
      Document docPSAKCSInput = (Document)orderInDoc.cloneNode(true);
      docPSAKCSInput.getDocumentElement().setAttribute("CallingSource", KohlsPOCConstant.V2_UNEARN);
      Element eleKCInputExtn = XMLUtil.getChildElement(docPSAKCSInput.getDocumentElement(),KohlsPOCConstant.E_EXTN);
      if(!YFCCommon.isVoid(eleKCInputExtn)) {
        docPSAKCSInput.getDocumentElement().removeChild(eleKCInputExtn);
      }
      if (ServerTypeHelper.amIOnEdgeServer() && !YFCCommon.isVoid(sEndpoint)) {
          Element eleAdditionalInfo = XMLUtil.createChild(docPSAKCSInput.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
          eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
      }
      docPSAKCSOut = KOHLSBaseApi.invokeService(env, "KohlsCashDeactivation", docPSAKCSInput);
      if(logger.isDebugEnabled()) {
        logger.debug("Output of KCS call is: "+XMLUtil.getXMLString(docPSAKCSOut));
      }
      Element eleKCSReturnableItemList = XMLUtil.getChildElement(docPSAKCSOut.getDocumentElement(), "ReturnableItemList");
      Double dEligibilityDeduction = 0.00D;
      Double dRefundAmtWithoutTax = 0.00D;
      if(!YFCCommon.isVoid(eleKCSReturnableItemList)) {
        NodeList nlReturnableItem = eleKCSReturnableItemList.getElementsByTagName("ReturnableItem");
        for (int i=0; i<nlReturnableItem.getLength(); i++) {
          Element eleReturnableItem = (Element) nlReturnableItem.item(i);
          String sLineNo = XMLUtil.getChildElement(eleReturnableItem, "LineNo").getTextContent();
          String sNetPrice = XMLUtil.getChildElement(eleReturnableItem, "NetPrice").getTextContent();
          dRefundAmtWithoutTax = dRefundAmtWithoutTax + Double.parseDouble(sNetPrice);
          String sKohlsCashEligible = XMLUtil.getChildElement(eleReturnableItem, "KohlsCashEligible").getTextContent();
          if((KohlsPOCConstant.TRUE).equalsIgnoreCase(sKohlsCashEligible)) {
            Element eleKCEligibleOrderLine = SCXmlUtil.getXpathElement(eleOrder, "OrderLines/OrderLine[@PrimeLineNo=" + sLineNo + "]");
            Element eleKCEligibleOrderLineExtn = XMLUtil.getChildElement(eleKCEligibleOrderLine, KohlsXMLLiterals.E_EXTN, true);
            eleKCEligibleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE, KohlsXMLLiterals.CONST_TRUE);
            eleKCEligibleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, String.valueOf(sNetPrice));
            eleKCEligibleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE,String.valueOf(sNetPrice));
            dEligibilityDeduction = dEligibilityDeduction + Double.parseDouble(sNetPrice);
          }
        }
        docPSAKCSOut.getDocumentElement().setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, df.format(dEligibilityDeduction));
      }
      //sStoreID = eleOrder.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE);
      //String strEligibleAmt = docPSAKCSOut.getDocumentElement().getAttribute(KohlsXMLLiterals.E_ELIGIBLE_AMOUNT);
      NodeList nlLoyalty = orderInDoc.getDocumentElement().getElementsByTagName("Loyalty");
      Element eleLoyalty = null;
      String sTransactionNo = eleOrder.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO);
      if(!YFCCommon.isVoid(nlLoyalty) && nlLoyalty.getLength() >0){
          eleLoyalty = (Element) nlLoyalty.item(0);
          sTransactionNo = eleLoyalty.getAttribute("TransactionNumber");
          sTransactionNo = KohlsPoCPnPUtil.prepadString(sTransactionNo, 4, "0");
          }
      Element eleExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
      // get PSA Original Store, terminal, Tran, date time based on Receipt id
      String originalSaleTransactionNo, originalSaleStoreNumber, originalSaleTerminalId, originalSaleSequenceNumber, originalSaleTransactionDateTime="";
      if(!YFCCommon.isVoid(eleExtn)) {
        String sReceiptID = eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);
        originalSaleTransactionNo = KohlsPoCCommonAPIUtil.getTransactionIdFromReceiptID(sReceiptID);
        originalSaleStoreNumber = KohlsPoCCommonAPIUtil.getStoreNumberFromTransactionNumber( originalSaleTransactionNo );
        originalSaleTerminalId = KohlsPoCCommonAPIUtil.getTerminalIdFromTransactionNumber( originalSaleTransactionNo );
        originalSaleSequenceNumber = KohlsPoCCommonAPIUtil.getSequenceNbrFromTransactionNumber( originalSaleTransactionNo );
        originalSaleTransactionDateTime = KohlsPoCCommonAPIUtil.getOrderDateFromTransactionNumber( originalSaleTransactionNo );
      } else {
        // use current values
        originalSaleStoreNumber = eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
        originalSaleTerminalId = eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        originalSaleSequenceNumber = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
        originalSaleTransactionDateTime = eleOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
      }
      String sCouponSrcCode=originalSaleStoreNumber+"-"+originalSaleTerminalId+"-"+originalSaleSequenceNumber;
      docPSAKCSOut = createPSAKohlsCashUnearnPromotions(docPSAKCSOut,sCouponSrcCode);
      Element eleProcessedPromotion = (Element) XPathUtil.getNode(docPSAKCSOut.getDocumentElement(), "//Order/Promotions/Promotion[Extn/@ExtnCouponSourceCode='"+sCouponSrcCode+"']");
      Element eleProcessedPromotionmaxRefund = (Element) XPathUtil.getNode(docPSAKCSOut.getDocumentElement(), "//Order/Promotions/Promotion/MaximizeRefund");
      //RefundReduction > 0 then put in details to map for futher TVS calls
      String sRefundDeduction="",sUnearnValue="",sPromoId=""; 
      if(!YFCCommon.isVoid(eleProcessedPromotionmaxRefund)){
          sRefundDeduction= eleProcessedPromotionmaxRefund.getAttribute(KohlsPOCConstant.REF_DEDUCTION);
          sUnearnValue =  eleProcessedPromotionmaxRefund.getAttribute(KohlsPOCConstant.UNEARNED_KC);
          sPromoId = eleProcessedPromotionmaxRefund.getAttribute("PromotionId");
      }
      if(!YFCCommon.isVoid(sRefundDeduction) && Double.parseDouble(sRefundDeduction) > 0 ){
          mpRefundDeductionHash.put(sPromoId+"-"+sCouponSrcCode, Double.parseDouble(sRefundDeduction));
      }
      // Check if the promotion has KC Deactivated, then add to the mpKCDeactivation map
      
      if(!YFCCommon.isVoid(sUnearnValue) && Double.parseDouble(sUnearnValue) >0) {
        mpKCDeactivation.put(sPromoId+"-"+sCouponSrcCode, Double.parseDouble(sUnearnValue));
      }
      if(dRefundAmtWithoutTax >0) {
          mpRefundAmtByTrans.put(sCouponSrcCode, dRefundAmtWithoutTax);
        }
      // Add Promotion element to mpCouponToPromotion map
      if(!YFCCommon.isVoid(eleProcessedPromotion)) {
        mpCouponToPromotion.put(sPromoId+"-"+sCouponSrcCode,eleProcessedPromotion);
      }
      mapReceiptDateTimeAscending.put(sCouponSrcCode, originalSaleTransactionDateTime);
      logger.endTimer("KohlsCashRewardsDeactivation.callKCSForPSA");
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param docInOrder
     * @return
     * @throws Exception 
     */
    Document getOrderListForUnearning(YFSEnvironment env, Document orderInDoc, String sPOCFeature, String sEndpoint) throws Exception {
      logger.beginTimer("KohlsCashRewardsDeactivation.getOrderListForUnearning");
      Document orderDetailsDoc = null;
      //preparing getOrderList input xml
      Document docGetOrderListIn = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
      String sOrderHeaderKey = orderInDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      if(!YFCCommon.isVoid(sOrderHeaderKey)) {
        docGetOrderListIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
        // Returns or PA
        if(sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.RECEIPTED_RET) || 
            sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
          if(logger.isDebugEnabled()) {
            logger.debug("Calling getOrderList API with input xml: "+XMLUtil.getXMLString(orderInDoc));
          }
          orderDetailsDoc = returnLcsobj.getOrderListDetails(env,orderInDoc);
        }else{
            // PSA
            if(!YFCCommon.isVoid(sEndpoint)) {
              Element eleAdditionalInfo = XMLUtil.createChild(docGetOrderListIn.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
              eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
              env.setTxnObject(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
            }
            if(logger.isDebugEnabled()) {
              logger.debug("Calling getOrderList API with input xml: "+XMLUtil.getXMLString(docGetOrderListIn));
            }
            orderDetailsDoc = KOHLSBaseApi.invokeService(env,
                    KohlsConstant.PSA_GET_ORDER_LIST, docGetOrderListIn);          
        }
        if(logger.isDebugEnabled()) {
          logger.debug("Output of getOrderList api is: "+XMLUtil.getXMLString(orderDetailsDoc));
        }
      }
      if(YFCCommon.isVoid(orderDetailsDoc)) {
        logger.error("Error in calling getOrderList api.");
        orderDetailsDoc = (Document)orderInDoc.cloneNode(true);
      }
      logger.endTimer("KohlsCashRewardsDeactivation.getOrderListForUnearning");
      return orderDetailsDoc;
    }
    
    /**
     * Create By mrjoshi * 
     * @param docLCSOut
     * @param sPOCFeature 
     * @throws Exception
     */
    private void processLCSOutput(Document docLCSOut, String sPOCFeature) throws Exception {
      logger.beginTimer("KohlsCashRewardsDeactivation.processLCSOutput");
      Element eleOutput = docLCSOut.getDocumentElement();
      Element eleOutPromotions = (Element) XPathUtil.getNode(eleOutput, "//Order/Promotions");
      NodeList nlPromotions =  XPathUtil.getNodeList(eleOutput, "//Order/Promotions/Promotion[@PromotionType='LOYALTY_KC_UNEARNED']");
      String sPromoId ="";
      String sCounponSrcCode = "";
      for (int p = 0; p < nlPromotions.getLength(); p++) {
          Element eleOrderPromo = (Element)nlPromotions.item(p);
          Element extnNode = XMLUtil.getChildElement(eleOrderPromo, KohlsXMLLiterals.E_EXTN);
          sPromoId = eleOrderPromo.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
          sCounponSrcCode = extnNode.getAttribute(KohlsXMLLiterals.A_EXTN_COUPON_SOURCE_CODE);
          // Add Promotion element to mpCouponToPromotion map
          if(!mpCouponToPromotion.containsKey(sPromoId+"-"+sCounponSrcCode)){
              mpCouponToPromotion.put(sPromoId+"-"+sCounponSrcCode,eleOrderPromo);
          }

          // Check if the promotion has KC Deactivated, then add to the mpKCDeactivation map
          String sUnearnValue =  extnNode.getAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE);
          if(!YFCCommon.isVoid(sUnearnValue) && Double.parseDouble(sUnearnValue) >0) {
            mpKCDeactivation.put(sPromoId+"-"+sCounponSrcCode, Double.parseDouble(sUnearnValue));
          }
          
          // Check if the promotion has refund deduction, then add to the mpRefundDeductionHash map
          String sRefundDeduction = extnNode.getAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION);
          if(!YFCCommon.isVoid(sRefundDeduction) && Double.parseDouble(sRefundDeduction) >0) {
              mpRefundDeductionHash.put(sPromoId+"-"+sCounponSrcCode, new Double(sRefundDeduction));;
          }
          eleOutPromotions.removeChild(eleOrderPromo);
      }
      logger.debug("After LCS Calls HashMap Values are: ");
      logger.debug("mpRefundDeductionHash: "+mpRefundDeductionHash);
      logger.debug("mpKCDeactivation: "+mpKCDeactivation);
      logger.debug("mpCouponToPromotion: "+mpCouponToPromotion);
      
      // Set Eligible Lines from LCS
      NodeList nlLCSOrderLine = eleOutput.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
      Double dRefundAmtWithoutTax = 0.00D;
      if(nlLCSOrderLine.getLength() > 0) {
        logger.debug("Setting eligibleItems from LCS response");
        for (int j=0; j<nlLCSOrderLine.getLength(); j++) {
          Element eleLCSOrderLine = (Element)nlLCSOrderLine.item(j);
          Element eleLCSOrderLineExtn = XMLUtil.getChildElement(eleLCSOrderLine, KohlsXMLLiterals.E_EXTN);
          String sPrimeLineNo = eleLCSOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
          String sKohlsCashEligible = eleLCSOrderLineExtn.getAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE);
          String sExtnNetPrice = eleLCSOrderLineExtn.getAttribute(KohlsXMLLiterals.A_EXTN_NET_PRICE);
          dRefundAmtWithoutTax = dRefundAmtWithoutTax + Double.parseDouble(sExtnNetPrice);
          if ((KohlsPOCConstant.TRUE).equalsIgnoreCase(sKohlsCashEligible)) {
            Element eleKCEligibleOrderLine = SCXmlUtil.getXpathElement(eleOrder,
               "OrderLines/OrderLine[@PrimeLineNo=" + sPrimeLineNo + "]");
           Element eleKCEligibleOrderLineExtn = XMLUtil.getChildElement(eleKCEligibleOrderLine, KohlsXMLLiterals.E_EXTN);
           eleKCEligibleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE, KohlsXMLLiterals.CONST_TRUE);
          if(!( KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature)) ){
        	   eleKCEligibleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_NET_PRICE, sExtnNetPrice);
        	   eleKCEligibleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_RETURN_PRICE, sExtnNetPrice);
           }
          }
        }
        if(KohlsPOCConstant.POST_SALE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature) && mpRefundAmtByTrans.isEmpty()) {
          mpRefundAmtByTrans.put(sCounponSrcCode, dRefundAmtWithoutTax);
        }
      }
      logger.endTimer("KohlsCashRewardsDeactivation.processLCSOutput");
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param sPOCFeature
     * @param docOut
     * @param tranDetails
     * @param sOriginalRefundAmt
     * @return
     * @throws Exception
     */
    private String processRefundDeductuionForTransaction(YFSEnvironment env, String sPOCFeature, Document docOut, String tranDetails, String sOriginalRefundAmt) throws Exception {
      logger.beginTimer("KohlsCashRewardsDeactivation.processRefundDeductuionForTransaction");
      String sRefundAmt = "";
      String strUnearnedKohlsCash = "";
      logger.debug("Processing Refund deduction for Transaction: " + tranDetails);
      String couponNo = "";
      for (String key : mpCouponToPromotion.keySet()) {
        if (key.contains(tranDetails)) {
          couponNo = key;
          break;
        }
      }
      Element eleOrderPromotion = mpCouponToPromotion.get(couponNo);
      Element eleRfundDeduction =
          XMLUtil.createChild(eleOrderPromotion, KohlsPOCConstant.REF_DEDUCTION);
      eleRfundDeduction.setTextContent(df.format(mpFinalRefundDeductionMapByTransaction.get(tranDetails)));
      returnLcsobj.lEcommStores = returnLcsobj.populateEcommStores(env);
      returnLcsobj.sEligibleLine = KohlsPOCConstant.TRUE;
      returnLcsobj.callingSource = KohlsPOCConstant.V2_UNEARN;
      Document docForProration = XMLUtil.createDocument(eleOrder);
      returnLcsobj.callTVSAndUpdateOrderDocument(env, eleOrder, docForProration,
          eleRfundDeduction, eleOrderPromotion);
      Element eleMaxRefund =
          XMLUtil.getChildElement(eleOrderPromotion, KohlsPOCConstant.MAX_REFUND, true);
      sRefundAmt = XMLUtil.getAttribute(eleMaxRefund, KohlsPOCConstant.REFUND_AMT);
      if("PostSaleAdjustment".equalsIgnoreCase(sPOCFeature) && !YFCCommon.isVoid(sRefundAmt)) {
        sRefundAmt = df.format(Double.parseDouble(sOriginalRefundAmt) + Double.parseDouble(sRefundAmt));
      }
      strUnearnedKohlsCash = XMLUtil.getAttribute(eleMaxRefund, KohlsPOCConstant.UNEARNED_KC);
      docOut.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT, sRefundAmt);
      //Required data collection attributes for PSA changeOrder call
      Element eleExtn = XMLUtil.getChildElement(docOut.getDocumentElement(), KohlsPOCConstant.E_EXTN, true);
      if (KohlsPOCConstant.POST_SALE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature)) {
          eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE, KohlsXMLLiterals.CONST_MAXIMIZE_REFUND);
          eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_DEACTIVATED, strUnearnedKohlsCash);
      }
      // copy Prorated lines to output
      Element eleProratedOrderLines = (Element) XPathUtil
          .getNode(docForProration.getDocumentElement(), "//Order/ProRatedLines/OrderLines");
      if (!YFCCommon.isVoid(eleProratedOrderLines)) {
        bProrationExists = true;
        Element eleOutProratedLines =
            XMLUtil.getChildElement(docOut.getDocumentElement(), "ProRatedLines", true);
        XMLUtil.importElement(eleOutProratedLines, eleProratedOrderLines);
      }
      logger.endTimer("KohlsCashRewardsDeactivation.processRefundDeductuionForTransaction");
      return sRefundAmt;
    }
    
    /**
     * Create By mrjoshi * 
     * @param env
     * @param docOut
     * @param sEndpoint
     */
    private void postProcessingForPSA(YFSEnvironment env, Document docOut, String sEndpoint) {
      logger.beginTimer("KohlsCashRewardsDeactivation.postProcessingForPSA");
      NodeList nlPromotion = docOut.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
      // Calling changeOrder only when there is promotion
        if(nlPromotion.getLength() > 0) {
          try{
            docOut.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,sOHK);
            // Clone the outDoc to prepare changeOrder input xml
            Document docChangeOrderIn = (Document)docOut.cloneNode(true);
            //don't copy promotions unearn into KOHLS_SALES_FOR_PSA table
            Document docClone = (Document)docOut.cloneNode(true);
            Element eleRootOut = docClone.getDocumentElement();
            eleRootOut.removeChild(XMLUtil.getChildElement(eleRootOut, KohlsPOCConstant.E_PROMOTIONS, true));
            
            String PSAKCDataXML = XMLUtil.getXMLString(docClone);
  
            Document docInputForPSAData = YFCDocument.createDocument(
                    KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
            Element eleInputForPSAData = docInputForPSAData
                    .getDocumentElement();
            eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOHK);
            eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_PSA_KC_DATA, PSAKCDataXML);
  
            //ISS change - start
            if (ServerTypeHelper.amIOnEdgeServer()) {
                if (!YFCCommon.isVoid(sEndpoint)) {
                    // setting endpoint for ManageKohlsSaleForPSA call
                    Element eleAdditionalInfo =
                            SCXmlUtil.createChild(eleInputForPSAData, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                    eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
                    // setting endpoint for changeOrder call
                    Element eleChangeOrderAdditionalInfo =
                            SCXmlUtil.createChild(docChangeOrderIn.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
                    eleChangeOrderAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
                }
            }
            //ISS change - end
  
            if(logger.isDebugEnabled()) {
                logger.debug("Input to KohlsManageSaleForPSA is: "+XMLUtil.getXMLString(docInputForPSAData) );
            }
  
            // change order to persist the promotion on the order.
            String sTemplate ="<Order OrderHeaderKey=''/>";
            Document docOutTemp = XMLUtil.getDocument(sTemplate);
            
            // Make sure every promotion has Action set
            for (int i=0; i<nlPromotion.getLength(); i++) {
              Element elePromotion = (Element)nlPromotion.item(i);
              elePromotion.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_CREATE);
            }
            
            docChangeOrderIn.getDocumentElement().setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.YES);
            if(logger.isDebugEnabled()) {
              logger.debug("Input to changeOrder is: "+XMLUtil.getXMLString(docChangeOrderIn) );
            }
            KOHLSBaseApi.invokeAPI(env, docOutTemp, KohlsPOCConstant.API_CHANGE_ORDER, docChangeOrderIn);
  
            //Persist the Prorated Lines from Refund Deduction on Kohls_Sale_for_PSA table.
             if(bProrationExists){
                 KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docInputForPSAData);
             }
             
             // Remove non displayable promotions
             for(int i = 0; i<nlPromotion.getLength(); i++) {
               Element elePromotion = (Element)nlPromotion.item(i);
               String sDisplayPSAKCPrompt = elePromotion.getAttribute(KohlsXMLLiterals.A_DISPLAY_PSA_KC_PROMPT);
               if("N".equalsIgnoreCase(sDisplayPSAKCPrompt)) {
                 XMLUtil.removeChild((Element)elePromotion.getParentNode(), elePromotion);
                 i--;
               }
             }
          } catch( Exception e){
            logger.error("Exception while calling API " +e.getMessage());
          }
       }
      logger.endTimer("KohlsCashRewardsDeactivation.postProcessingForPSA");
    }
}
