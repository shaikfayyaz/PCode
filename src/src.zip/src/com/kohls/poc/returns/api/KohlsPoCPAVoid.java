package com.kohls.poc.returns.api;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.psa.api.KohlsPSAChargeForPV;
import com.kohls.poc.psa.api.KohlsPSARefund;
import com.kohls.poc.util.KohlsPoCPinPadPostVoidOperations;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCPAVoid extends KOHLSBaseApi {

  private static YFCLogCategory logger;
  private Document docOutPAOrderDetails = null;
  private Document docOutOriginalOrderDetails = null;
  private String sPAStatus = "";
  private double timeTaken = 0.00;
  KohlsPSARefund kohlsPSARefund = new KohlsPSARefund();
  static {
    logger = YFCLogCategory.instance(KohlsPoCPAVoid.class.getName());
  }

  public Document updateVoidDetails(YFSEnvironment env, Document docInputXml) throws Exception {
    logger.beginTimer("KohlsPoCPAVoid.updateVoidDetails");

    Document docOutUpdatePAOrderDetails = null;
    Element eleOrder = docInputXml.getDocumentElement();
    Element eleOrderExtn = (Element) eleOrder.getElementsByTagName("Extn").item(0);
    sPAStatus = eleOrderExtn.getAttribute("ExtnPsaStatus");
  
    // Do Data collect for PA Mid Void
    if ("PA_MIDVOID".equals(sPAStatus)) {
      env.setTxnObject("ExtnPsaStatus", sPAStatus);
      
      //CAPE - 2755 - Murali K
  	if(ServerTypeHelper.amIOnEdgeServer()){ 
  		
  		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docInputXml.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
  		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
  			docInputXml.getDocumentElement().removeChild(eleYfcAdditionalInfo);
  		}
  		
  		eleYfcAdditionalInfo = XMLUtil.createChild(docInputXml.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
  		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
  	}
  	
    //CAPE - 2755 - Murali K
  	
      invokeService(env, "KohlsPoCPublishPAMidVoidToSalesHub", docInputXml);
    }

    if (!YFCCommon.isVoid(docInputXml)) {
      Document docOutOrderDetails = getOriginalSaleOrder(env, docInputXml);
      if (!YFCCommon.isVoid(docOutOrderDetails)) {
        Element eleOrderDetails = docOutOrderDetails.getDocumentElement();
        String sOrginalSaleData = eleOrderDetails.getAttribute("OriginalSaleData");
        docOutOriginalOrderDetails = XMLUtil.getDocument(sOrginalSaleData);
      }
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docOutOriginalOrderDetails)) {
          logger.debug("Original Sale Order  " + SCXmlUtil.getString(docOutOriginalOrderDetails));
        }
      }
      docOutPAOrderDetails = getPAOrderDeatils(env, docInputXml);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docOutPAOrderDetails)) {
          logger.debug(" PA Order Details " + SCXmlUtil.getString(docOutPAOrderDetails));
        }
      }
      docOutUpdatePAOrderDetails =
          updatePAOrderDetailsAfterVoid(env, docOutOriginalOrderDetails, docOutPAOrderDetails);

      // Importing the orderLines into the input xml

      Element eleOrderLines = XMLUtil.getChildElement(
          docOutUpdatePAOrderDetails.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
      if (!YFCCommon.isVoid(eleOrderLines)) {
        Element eleInputOrderLines = XMLUtil.getChildElement(docInputXml.getDocumentElement(),
            KohlsPOCConstant.ELEM_ORDER_LINES);
        if (!YFCCommon.isVoid(eleInputOrderLines)) {
          docInputXml.getDocumentElement().removeChild(eleInputOrderLines);
        }
        Element eleOrderLines_Temp = (Element) docInputXml.importNode(eleOrderLines, true);
        docInputXml.getDocumentElement().appendChild(eleOrderLines_Temp);
      }

      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docInputXml)) {
          logger.debug("After Update PA Order  " + SCXmlUtil.getString(docInputXml));
        }
      }
    }

    logger.endTimer("KohlsPoCPAVoid.updateMidVoidetails");

    return docInputXml;
  }

  public Document getPAOrderDeatils(YFSEnvironment env, Document docInputXml) throws Exception {

    logger.beginTimer("KohlsPoCPAVoid.getPAOrderDeatils");

    Document docOutPAOrderDetails = null;
    String strPAOHK = docInputXml.getDocumentElement().getAttribute("OrderHeaderKey");
    Document docInputPAGetOrderDetails =
        XMLUtil.getDocument("<Order OrderHeaderKey='" + strPAOHK + "'/>");

    Document docGetOrderDetailsTemplate =
        XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_DETAILS_TEMPLATE_VOID);
    
  //CAPE - 2755 - Murali K
  	if(ServerTypeHelper.amIOnEdgeServer()){ 
  		
  		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docInputXml.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
  		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
  			docInputXml.getDocumentElement().removeChild(eleYfcAdditionalInfo);
  		}
  		
  		eleYfcAdditionalInfo = XMLUtil.createChild(docInputXml.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
  		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
  	}
  	
    //CAPE - 2755 - Murali K
	
    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docInputPAGetOrderDetails)) {
        logger
            .debug("Input To Get Order Details " + SCXmlUtil.getString(docInputPAGetOrderDetails));
      }
    }

    docOutPAOrderDetails = KOHLSBaseApi.invokeAPI(env, docGetOrderDetailsTemplate,
        "getOrderDetails", docInputPAGetOrderDetails);

    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docOutPAOrderDetails)) {
        logger.debug("PA Order Details Put Put   " + SCXmlUtil.getString(docOutPAOrderDetails));
      }
    }
    logger.endTimer("KohlsPoCPAVoid.getPAOrderDeatils");

    return docOutPAOrderDetails;

  }


  public Document updatePAOrderDetailsAfterVoid(YFSEnvironment env, Document docInSaleOrder, Document docInPAOrder) {

    logger.beginTimer("KohlsPoCPAVoid.updatePAOrderDetailsAfterVoid");

    NodeList ndlOrderLine = docInSaleOrder.getElementsByTagName("OrderLine");
    HashMap<String,Element> hmPSAOrigOrderLines = new HashMap<String,Element>();
    Element eleSaleOrder = docInSaleOrder.getDocumentElement();

    Element elePAOrder = docInPAOrder.getDocumentElement();
    Element eleSaleOrdeExtn = (Element) eleSaleOrder.getElementsByTagName("Extn").item(0);
    Element elePAOrdeExtn = (Element) elePAOrder.getElementsByTagName("Extn").item(0);

    ArrayList<String> arrayPAQualifiedLines = new ArrayList<String>();

    docInPAOrder.getDocumentElement().setAttribute("ValidatePromotionAward", "N");

    XMLUtil.removeChild(elePAOrder, elePAOrdeExtn);
    Element eleNewPAOrderExtn = XMLUtil.importElement(elePAOrder, eleSaleOrdeExtn);
    eleNewPAOrderExtn.setAttribute("ExtnPsaStatus", sPAStatus);
    
    //PSA promotions reset - start
    Element eleOrderPromotions = XMLUtil.getChildElement(elePAOrder, "Promotions");
    if(!YFCCommon.isVoid(eleOrderPromotions)){
    	XMLUtil.removeChild(elePAOrder, eleOrderPromotions);
    }
    Element eleOrderSalesPromotions = XMLUtil.getChildElement(eleSaleOrder, "Promotions");
    if(!YFCCommon.isVoid(eleOrderSalesPromotions)){
    	Element elePANewPromotions = XMLUtil.importElement(elePAOrder, eleOrderSalesPromotions);
    	elePANewPromotions.setAttribute("Reset", "Y");
    }  
   //PSA promotions reset - end
    for (int i = 0; i < ndlOrderLine.getLength(); i++) {

      Element eleOrderLine = (Element) ndlOrderLine.item(i);

      Element eleLinePriceInfo =
          (Element) eleOrderLine.getElementsByTagName("LinePriceInfo").item(0);

      Element eleLineCharges = (Element) eleOrderLine.getElementsByTagName("LineCharges").item(0);


      Element elePromotions = (Element) eleOrderLine.getElementsByTagName("Promotions").item(0);

      Element eleAwards = (Element) eleOrderLine.getElementsByTagName("Awards").item(0);


      Element eleExtn = (Element) eleOrderLine.getElementsByTagName("Extn").item(0);


      Element eleLineTaxes = (Element) eleOrderLine.getElementsByTagName("LineTaxes").item(0);

      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(eleOrderLine)) {
          logger.debug("Original Order Line of sale" + SCXmlUtil.getString(eleOrderLine));
        }
      }
      String sOrginalPrimeLineNo = eleOrderLine.getAttribute("PrimeLineNo");
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(sOrginalPrimeLineNo)) {
          logger.debug("Orginal Prime line no  " + sOrginalPrimeLineNo);
        }
      }
      Element elePAOrderLines = (Element) docInPAOrder.getElementsByTagName("OrderLines").item(0);
      NodeList ndlPAOrderLine = docInPAOrder.getElementsByTagName("OrderLine");

      for (int j = 0; j < ndlPAOrderLine.getLength(); j++) {

        Element elePAOrderLine = (Element) ndlPAOrderLine.item(j);
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(elePAOrderLine)) {
            logger.debug("elePAOrderLine*************" + SCXmlUtil.getString(elePAOrderLine));
          }
        }
        String sPAPrimeLineNo = elePAOrderLine.getAttribute("PrimeLineNo");
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(sPAPrimeLineNo)) {
            logger.debug("PA Prime Line No  " + sPAPrimeLineNo);
          }
        }
        if (sPAPrimeLineNo.equals(sOrginalPrimeLineNo)) {
          if (YFCLogUtil.isDebugEnabled()) {
            logger.debug("in the if block ");
          }
          String sOriginalOrderExtnReturnPrice =
              eleExtn.getAttribute(KohlsXMLLiterals.A_EXTN_RETURN_PRICE);

          Element elePAOrderLineExtn =
              XMLUtil.getChildElement(elePAOrderLine, KohlsConstant.E_EXTN);
          String sPAOrderExtnReturnPrice =
              elePAOrderLineExtn.getAttribute(KohlsXMLLiterals.A_EXTN_RETURN_PRICE);

          if ((!YFCCommon.isVoid(sOriginalOrderExtnReturnPrice))
              && (!YFCCommon.isVoid(sPAOrderExtnReturnPrice))) {
            if (!sPAOrderExtnReturnPrice.equalsIgnoreCase(sOriginalOrderExtnReturnPrice)) {

              Element elePALineCharges =
                  (Element) elePAOrderLine.getElementsByTagName("LineCharges").item(0);

              Element elePALinePriceInfo =
                  (Element) elePAOrderLine.getElementsByTagName("LinePriceInfo").item(0);

              Element elePAPromotions =
                  (Element) elePAOrderLine.getElementsByTagName("Promotions").item(0);

              Element elePAAwards = (Element) elePAOrderLine.getElementsByTagName("Awards").item(0);

              Element elePAExtn = (Element) elePAOrderLine.getElementsByTagName("Extn").item(0);

              Element elePALineTaxes =
                  (Element) elePAOrderLine.getElementsByTagName("LineTaxes").item(0);

              XMLUtil.removeChild(elePAOrderLine, elePALinePriceInfo);
              Element elePANewLinePriceInfo = XMLUtil.createChild(elePAOrderLine, "LinePriceInfo");
              elePANewLinePriceInfo.setAttribute("UnitPrice",
                  eleLinePriceInfo.getAttribute("UnitPrice"));
              elePANewLinePriceInfo.setAttribute("InvoicedLineTotal",
                  eleLinePriceInfo.getAttribute("InvoicedLineTotal"));
              elePANewLinePriceInfo.setAttribute("TaxableFlag",
                  eleLinePriceInfo.getAttribute("TaxableFlag"));
              elePANewLinePriceInfo.setAttribute("ListPrice",
                  eleLinePriceInfo.getAttribute("ListPrice"));

              XMLUtil.removeChild(elePAOrderLine, elePALineCharges);
              Element elePANewLineCharges = XMLUtil.importElement(elePAOrderLine, eleLineCharges);
              elePANewLineCharges.setAttribute("Reset", "Y");

              XMLUtil.removeChild(elePAOrderLine, elePAPromotions);
              Element elePANewLinePromotions = XMLUtil.importElement(elePAOrderLine, elePromotions);
              elePANewLinePromotions.setAttribute("Reset", "Y");

              // Element eleNewAwards = XMLUtil.importElement(elePAOrderLine, eleAwards);

              NodeList ndlAward = elePAOrderLine.getElementsByTagName("Award");
              Element eleAward = null;
              for (int k = 0; k < ndlAward.getLength(); k++) {
                eleAward = (Element) ndlAward.item(k);
                eleAward.setAttribute("Action", "REMOVE");
              }

              NodeList ndlNewAward = eleOrderLine.getElementsByTagName("Award");
              for (int l = 0; l < ndlNewAward.getLength(); l++) {
                eleAward = (Element) ndlNewAward.item(l);
                eleAward.setAttribute("Action", "CREATE");
                XMLUtil.importElement(elePAAwards, eleAward);
              }

              if (YFCLogUtil.isDebugEnabled()) {
                if (!YFCCommon.isVoid(elePAOrderLine)) {
                  logger.debug("After Reset of awards " + SCXmlUtil.getString(elePAOrderLine));
                }
              }

              XMLUtil.removeChild(elePAOrderLine, elePAExtn);

              XMLUtil.importElement(elePAOrderLine, eleExtn);

              XMLUtil.removeChild(elePAOrderLine, elePALineTaxes);

              Element elePANewLineTaxes = XMLUtil.importElement(elePAOrderLine, eleLineTaxes);
              elePANewLineTaxes.setAttribute("Reset", "Y");

              if (YFCLogUtil.isDebugEnabled()) {
                if (!YFCCommon.isVoid(elePAOrderLine)) {
                  logger
                      .debug("After import the Order Line  " + SCXmlUtil.getString(elePAOrderLine));
                }
              }
              // Element ele=XMLUtil.importElement(eleOrderLines,
              // eleOrderLine);
              
              arrayPAQualifiedLines.add(elePAOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY));
              hmPSAOrigOrderLines.put(elePAOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY), elePAOrderLine);

            } else {
              XMLUtil.removeChild(elePAOrderLines, elePAOrderLine);
            }
          }
          break;
        }
      }
    }
    //Storing the PA Qualified lines to Env
    env.setTxnObject("PA_QALIFIED_LINES", arrayPAQualifiedLines);
    env.setTxnObject("PSA_QALIFIED_LINES", hmPSAOrigOrderLines);
    logger.endTimer("KohlsPoCPAVoid.updatePAOrderDetailsAfterVoid");
    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docInPAOrder)) {
        logger.debug("Final Output xml " + SCXmlUtil.getString(docInPAOrder));
      }
    }
    return docInPAOrder;

  }

  private Document getOriginalSaleOrder(YFSEnvironment env, Document docInputXml) throws Exception {
    logger.beginTimer("KohlsPoCPAVoid.getOriginalSaleOrder");
    Document docOutOrderDetails = null;
    if (!YFCCommon.isVoid(docInputXml)) {
      String strOriginalOHK = docInputXml.getDocumentElement().getAttribute("OrderHeaderKey");
      Document docInputGetOrginalOrder =
          XMLUtil.getDocument("<KOHLSSalesForPsa OrderHeaderKey='" + strOriginalOHK + "'/>");
      
    //CAPE - 2755 - Murali K
    	if(ServerTypeHelper.amIOnEdgeServer()){ 
    		
    		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docInputXml.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
    			docInputXml.getDocumentElement().removeChild(eleYfcAdditionalInfo);
    		}
    		
    		eleYfcAdditionalInfo = XMLUtil.createChild(docInputXml.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
    	}
    	
      //CAPE - 2755 - Murali K

      docOutOrderDetails =
          KOHLSBaseApi.invokeService(env, "GetKohlsSalesDetails", docInputGetOrginalOrder);
      logger.endTimer("KohlsPoCPAVoid.getOriginalSaleOrder");
      return docOutOrderDetails;
    }
    logger.endTimer("KohlsPoCPAVoid.getOriginalSaleOrder");
    return docOutOrderDetails;
  }

  public void updatePaymentDetailsForPV(YFSEnvironment env, Document docInputXml) throws Exception {
    logger.beginTimer("KohlsPoCPAVoid.updatePaymentDetailsForPV");

    Element eleOrder = docInputXml.getDocumentElement();
    String strOrderHeaderKey = eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);


    callRequestCollection(env, strOrderHeaderKey);
    updateChargeTransactionDetails(env, strOrderHeaderKey);
    Document docGetPayListOutput = getPaymentList(env, strOrderHeaderKey);
    createRecordExternalCharges(env, docGetPayListOutput, strOrderHeaderKey,docInputXml);

    logger.endTimer("KohlsPoCPAVoid.updatePaymentDetailsForPV");
  }

  private void callRequestCollection(YFSEnvironment yfsEnv, String strOHK) {
    logger.beginTimer("KohlsPoCPAVoid.callRequestCollection");

    try {
      Document docRequestCollectionInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
      Element eleRequestCollectionInput = docRequestCollectionInput.getDocumentElement();
      eleRequestCollectionInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOHK);
      
      if(ServerTypeHelper.amIOnEdgeServer()){
    		Element eleYfcAdditionalInfo = XMLUtil.createChild(docRequestCollectionInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
    	}
      
      
      Document outDoc = KOHLSBaseApi.invokeService(yfsEnv,
          KohlsPOCConstant.SER_REQUEST_COLLECTION_PSA, docRequestCollectionInput);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(outDoc)) {
          logger.debug("callRequestCollection  " + SCXmlUtil.getString(outDoc));
        }
      }
    } catch (Exception e) {
      logger.error("Exception occurred while calling requestcollection API:" + e.getMessage());
    }
    logger.endTimer("KohlsPoCPAVoid.callRequestCollection");
  }


  private void updateChargeTransactionDetails(YFSEnvironment yfsEnv, String strOHK) {
    logger.beginTimer("KohlsPoCPAVoid.updateChargeTransactionDetails");

    Document inDocVoidChargeTrans = null;
    try {
      Document docGetChargeTransactionListInput =
          XMLUtil.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
      Element eleChargeTransactionListInput = docGetChargeTransactionListInput.getDocumentElement();
      eleChargeTransactionListInput.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE,
          KohlsXMLLiterals.CONST_CHARGE);
      eleChargeTransactionListInput.setAttribute(KohlsXMLLiterals.A_STATUS,
          KohlsXMLLiterals.ATTR_OPEN);
      eleChargeTransactionListInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOHK);
      
      if(ServerTypeHelper.amIOnEdgeServer()){
    		Element eleYfcAdditionalInfo = XMLUtil.createChild(docGetChargeTransactionListInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
    	}

      Document docChargeTransList = KOHLSBaseApi.invokeAPI(yfsEnv,
          KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, docGetChargeTransactionListInput);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docChargeTransList)) {
          logger.debug("updateChargeTransactionDetails  - Getting ChargeTransactionList "
              + SCXmlUtil.getString(docChargeTransList));
        }
      }
      Element eleChargeTransactionDetails = docChargeTransList.getDocumentElement();


      List<Element> eleChargeTransactionDetailList = XMLUtil.getElementsByTagName(
          eleChargeTransactionDetails, KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
      if (eleChargeTransactionDetailList.size() > KohlsPOCConstant.ZERO_INT) {
        inDocVoidChargeTrans =
            XMLUtil.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAILS);
        Element eleVoidChargeTransDetails = inDocVoidChargeTrans.getDocumentElement();
        for (Element eleChargeTransactionDetail : eleChargeTransactionDetailList) {
          Element eleVoidChargeTransDtl = XMLUtil.createChild(eleVoidChargeTransDetails,
              KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
          String strChargeTransactionKey =
              eleChargeTransactionDetail.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY);
          eleVoidChargeTransDtl.setAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY,
              strChargeTransactionKey);
        }
      }
      if(ServerTypeHelper.amIOnEdgeServer()){     		
    		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(inDocVoidChargeTrans.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
    			inDocVoidChargeTrans.getDocumentElement().removeChild(eleYfcAdditionalInfo);
    		}
    		
    		eleYfcAdditionalInfo = XMLUtil.createChild(inDocVoidChargeTrans.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
    	}
      Document docOutVoidChargeTrans = KOHLSBaseApi.invokeAPI(yfsEnv,
          KohlsXMLLiterals.API_VOID_CHARGE_TRANSACTION, inDocVoidChargeTrans);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docOutVoidChargeTrans)) {
          logger.debug("updateChargeTransactionDetails  - Void Charge Transaction "
              + SCXmlUtil.getString(docOutVoidChargeTrans));
        }
      }
    } catch (Exception e) {
      logger.error(
          "Exception occurred while calling updateChargeTransactionDetails API:" + e.getMessage());
    }
    logger.endTimer("KohlsPoCPAVoid.updateChargeTransactionDetails");
  }

  private Document getPaymentList(YFSEnvironment yfsEnv, String strOHK) {
    logger.beginTimer("KohlsPoCPAVoid.getPaymentList");
    Document docOutpaymentList = null;
    try {
      Document docGetPaymentListInput = XMLUtil.createDocument(KohlsXMLLiterals.E_PAYMENT);
      Element eleGetPaymentListInput = docGetPaymentListInput.getDocumentElement();
      eleGetPaymentListInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOHK);
      eleGetPaymentListInput.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6, KohlsXMLLiterals.CONST_PA);
      Document docGetPaymentListOutTemp = XMLUtil.getDocument(KohlsXMLLiterals.TEMP_GET_PAY_LIST);
      
    //CAPE - 2755 - Murali K
    	if(ServerTypeHelper.amIOnEdgeServer()){ 
    		
    		Element eleYfcAdditionalInfo = XMLUtil.createChild(docGetPaymentListInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
    	}
    	
      //CAPE - 2755 - Murali K
      docOutpaymentList = KOHLSBaseApi.invokeAPI(yfsEnv, docGetPaymentListOutTemp,
          KohlsXMLLiterals.API_GET_PAYMENT_LIST, docGetPaymentListInput);
    } catch (Exception e) {
      logger
          .error("Exception occurred while calling inputToGetPaymentListPV API:" + e.getMessage());
    }

    logger.endTimer("KohlsPoCPAVoid.getPaymentList");
    return docOutpaymentList;
  }

  private void createRecordExternalCharges(YFSEnvironment yfsEnv, Document docPaymentList,
      String strOHK, Document docInputXml) throws Exception {
    logger.beginTimer("KohlsPoCPAVoid.createRecordExternalCharges");

    Document docSklToRecordExternalCharges =
        XMLUtil.createDocument(KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES);
    Element eleRecordExternalCharges = docSklToRecordExternalCharges.getDocumentElement();
    Element elePaymentMethod =
        XMLUtil.createChild(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION, KohlsXMLLiterals.CONST_Y);
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_OPERATION, KohlsXMLLiterals.CONST_MANAGE);
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS,
        KohlsXMLLiterals.CONST_Y);
    Element elePaymentDetailsList =
        XMLUtil.createChild(elePaymentMethod, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    Element elePaymentDetails =
        XMLUtil.createChild(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE, KohlsXMLLiterals.CONST_CHARGE);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_IN_PERSON, KohlsXMLLiterals.CONST_Y);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_PROCESSED, KohlsXMLLiterals.CONST_Y);

    NodeList ndlPaymentMethodList =
        XPathUtil.getNodeList(docPaymentList, KohlsXMLLiterals.XPATH_PAY_METH_LIST);
    for (int i = 0; i < ndlPaymentMethodList.getLength(); i++) {
      /*Element eleCurrPayMethod = (Element) ndlPaymentMethodList.item(i);
      String sPaymentType = eleCurrPayMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
      
       * boolean bIsCard=checkIfCard(sPaymentType);
       * 
       * if(bIsCard){
       
      Document docUpdateInputForRecord =
          updateInputForRecordPV(yfsEnv, docSklToRecordExternalCharges, eleCurrPayMethod, strOHK);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docUpdateInputForRecord)) {
          logger.debug("createRecordExternalCharges  - Record External Charge Input "
              + SCXmlUtil.getString(docUpdateInputForRecord));
        }
      }*/
    	

		Element eleCurrPayMeth = (Element)ndlPaymentMethodList.item(i);
		//Since the document is getting overwritten reassign the document
		if(YFCLogUtil.isDebugEnabled()){
			logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV eleCurrPayMeth="+XMLUtil.getElementXMLString(eleCurrPayMeth));
		}
		String sPaymentType=eleCurrPayMeth.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
		if(!YFCCommon.isStringVoid(sPaymentType)){
			if(YFCLogUtil.isDebugEnabled()){
				logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV sPaymentType="+sPaymentType);
			}
			//Check if the PaymentMethod Element is a Credit Card or KMC Or Not
			boolean bIsCard=kohlsPSARefund.checkIfCard(sPaymentType);
			//Check if the PaymentMethod Element is a KMC
			boolean bIsKMC=((sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC))?true:false); 
			if(YFCLogUtil.isDebugEnabled()){
				logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV bIsCard="+bIsCard+" bIsKMC="+bIsKMC);
			}
			//If it is a card
			if(bIsCard){
				//Update the input for recordExternalCharges api
				Document docUpdateInputForRecord = null;
				Document docpinpadResponse = null;
				if(bIsKMC){
				docUpdateInputForRecord = updateInputForRecordPV(yfsEnv,docSklToRecordExternalCharges,eleCurrPayMeth,strOHK, docpinpadResponse);
				}else{  
					KohlsPoCPinPadPostVoidOperations.updatePinpadSession(yfsEnv, eleCurrPayMeth,docInputXml);
					docpinpadResponse = callPinPad(yfsEnv, eleCurrPayMeth, strOHK);
					docUpdateInputForRecord = updateInputForRecordPV(yfsEnv,docSklToRecordExternalCharges,eleCurrPayMeth,strOHK,docpinpadResponse);
				}
				if(YFCLogUtil.isDebugEnabled() && (!YFCCommon.isVoid(docUpdateInputForRecord))){
					logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV docupdateInputForRecord="+docUpdateInputForRecord);
				}
				//Call recordExternalCharges api
				Document docOutputRecord=callRecordExternalPayments(yfsEnv, docUpdateInputForRecord);
				if(YFCLogUtil.isDebugEnabled() && (!YFCCommon.isVoid(docOutputRecord))){
					logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV docOutputRecord="+docOutputRecord);
				}
			}
		}  
	

    }
    // }
    logger.endTimer("KohlsPoCPAVoid.createRecordExternalCharges");
  }

  
    private Document callPinPad(YFSEnvironment env, Element elePayment, String strOHKey) throws Exception {
    	logger.beginTimer("KohlsPSARefund.callPinPad");  
    	if (YFCLogUtil.isDebugEnabled()) {
    		logger.debug("Inside callPinPad method. Payment element is: "
    				+ XMLUtil.getElementXMLString(elePayment));
    	}
    	Document docPinpadResponse = null;
    	elePayment.setAttribute("OrderNo", strOHKey);
    	timeTaken = 0.01;

    	KohlsPoCPinPadPostVoidOperations object = new KohlsPoCPinPadPostVoidOperations();
    	long start = 0;
    	try {
    		start = System.currentTimeMillis();
    		logger.debug("KohlsPSARefund.callPinPad - start time is " + start);
    		docPinpadResponse = object.doVoidRequest(env, XMLUtil.getDocumentForElement(elePayment));
    		if (logger.isDebugEnabled()) {
    			logger.debug("Response from Pinpad is: " + XMLUtil.getXMLString(docPinpadResponse));
    		}

    	} catch (Exception e) {
    		logger.error(
    				"KohlsPSARefund.formAndCallInputToRecordExternalCharges Exception while calling pinpad: "
    						+ e.getMessage());
    	} finally {
    		long end = System.currentTimeMillis();
    		logger.debug("KohlsPSARefund.callPinPad - end time is " + end);
    		timeTaken = (end - start);
    	}
    	logger.endTimer("KohlsPSARefund.callPinPad");

    	return docPinpadResponse;
    }

private boolean checkIfCard(String sPaymentType) {
    logger.beginTimer("KohlsPoCPAVoid.checkIfCard");
    boolean bIsCard = false;
    List<String> listArrayCard = Arrays.asList(KohlsXMLLiterals.ATTR_KMC,
        KohlsXMLLiterals.ATTR_CREDIT_CARD, KohlsPOCConstant.KOHL_CHARGE_CARD);

    bIsCard = listArrayCard.contains(sPaymentType);

    logger.endTimer("KohlsPSARefund.checkIfCard");
    return bIsCard;
  }

  private Document updateInputForRecordPV(YFSEnvironment yfsEnv, Document docFormInputForRecord,
      Element eleCurrPayMeth, String strOHK, Document docpinpadResponse) throws Exception {
	  if(YFCLogUtil.isDebugEnabled()){
			logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV -- Start");
		}
			if(YFCLogUtil.isDebugEnabled()){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV docFormInputForRecord="+XMLUtil.getXMLString(docFormInputForRecord)+" eleCurrPayMeth="+XMLUtil.getElementXMLString(eleCurrPayMeth));
			}
			boolean bIsUsed=false;
			boolean isPinpadResponseAvailable = false;
			String sCTRoutOutput = "";
  		String sAuthCode = "000000";
			Element ctroutdElement = null;
  		Element eleAuthCode = null;
			Element responseElement = docpinpadResponse.getDocumentElement();
			if(!YFCCommon.isVoid(responseElement)){
				isPinpadResponseAvailable = true;
			}
			Element eleRecordExtChar=docFormInputForRecord.getDocumentElement();
			eleRecordExtChar.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHK);
			Element eleRecordPayMeth = SCXmlUtil.getXpathElement(eleRecordExtChar,KohlsXMLLiterals.E_PAYMENT_METHOD);
			if(YFCLogUtil.isDebugEnabled() && (!YFCCommon.isVoid(eleRecordPayMeth))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV eleRecordPayMeth="+XMLUtil.getElementXMLString(eleRecordPayMeth));
			}
			//Get attributes from the output of Current PaymentMethod
			String sCreditCardNo=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
			
			String sCreditCardType=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
			
			String sCreditCardExpDate=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
			
			String sPaymentKey=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
			
			String sPaymentType=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
			
			String sTotalRefundedAmount=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_TOTAL_REFUNDED_AMT);
			
			String sDisplayCreditCardNo=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO);
			
			String sSvcNo=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_SVC_NO);
			
			String sStoreID=eleCurrPayMeth.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
			
			String sEntryMethod=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2);
			
			//Check if its credit card and set the attributes
			if((!YFCCommon.isStringVoid(sCreditCardNo)) && (!YFCCommon.isStringVoid(sPaymentType)) && (sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD) || sPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD))){
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, sCreditCardExpDate);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, sCreditCardNo);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, sCreditCardType);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO, sDisplayCreditCardNo);
				bIsUsed=true;
				if(isPinpadResponseAvailable){
					ctroutdElement = SCXmlUtil.getChildElement(responseElement, "CTROUTD");
	    			eleAuthCode = SCXmlUtil.getChildElement(responseElement, "AUTH_CODE");
	    			if (!YFCCommon.isVoid(ctroutdElement)) {
	    				sCTRoutOutput = ctroutdElement.getTextContent();
	    			}
	    			if (!YFCCommon.isVoid(eleAuthCode)) {
	    				sAuthCode = eleAuthCode.getTextContent();
	    			}
					eleRecordPayMeth.setAttribute("ExtraDetails10", sCTRoutOutput);
					eleRecordPayMeth.setAttribute("AuthorizationID", sAuthCode);
					eleRecordPayMeth.setAttribute("ExtraDetails7", "CREDIT");
					eleRecordPayMeth.setAttribute("IsExternalPayment", "Y");
					Element eleExtn = XMLUtil.createChild(eleRecordPayMeth, KohlsPOCConstant.A_EXTN);
	    			eleExtn.setAttribute("ExtnPSIPayment", "Y");
				}
				if(YFCLogUtil.isDebugEnabled() && (!YFCCommon.isVoid(eleRecordPayMeth))){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV CC eleRecordPayMeth="+XMLUtil.getElementXMLString(eleRecordPayMeth)+" bIsUsed="+bIsUsed);
				}
			}
    
    if ((!YFCCommon.isStringVoid(sCreditCardNo)) && (!YFCCommon.isStringVoid(sPaymentType))
        && (sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD)
            || sPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD))) {
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, sCreditCardExpDate);
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, sCreditCardNo);
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, sCreditCardType);
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
          sDisplayCreditCardNo);
      bIsUsed = true;
    }

    // Check if its KMC and set the attributes
    if ((!YFCCommon.isStringVoid(sSvcNo)) && (!YFCCommon.isStringVoid(sStoreID))
        && (!YFCCommon.isStringVoid(sPaymentType))
        && (sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC))) {
      callPAGiftCardService(yfsEnv, eleRecordPayMeth);
      Element eleRecordPayMethExtn = XMLUtil.createChild(eleRecordPayMeth, KohlsXMLLiterals.E_EXTN);
      eleRecordPayMethExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE, "");
      eleRecordPayMethExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE, "");
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_SVC_NO, sSvcNo);
      bIsUsed = true;
    }
    // If this PaymentMethod was used, set the generic attributes
    if (bIsUsed) {
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, sPaymentType);
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_KEY, sPaymentKey);
      eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, sTotalRefundedAmount);
      Element elePaymentDetailsList =
          SCXmlUtil.getXpathElement(eleRecordPayMeth, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
      Element elePaymentDetails =
          SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
      elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, sTotalRefundedAmount);
      elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, sTotalRefundedAmount);

      //callRecordExternalPayments(yfsEnv, docFormInputForRecord);
    }

    logger.beginTimer("KohlsPoCPAVoid.updateInputForRecordPV");
    return docFormInputForRecord;
  }

  private void callPAGiftCardService(YFSEnvironment yfsEnv, Element elePaymentMethod) {
    logger.beginTimer("KohlsPoCPAVoid.callPAGiftCardService");
    try {
      Element eleOrder = docOutOriginalOrderDetails.getDocumentElement();

      Document docGCRevInput = XMLUtil.createDocument(KohlsConstant.PAYMENT_REQUEST);
      Element elePayReqRev = docGCRevInput.getDocumentElement();
      Element eleTran = XMLUtil.createChild(elePayReqRev, KohlsXMLLiterals.E_TRANSACTION);
      Double dAmount =
          new Double(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_TOTAL_REFUNDED_AMT));
      eleTran.setAttribute(KohlsXMLLiterals.A_TENDER_AMOUNT,
          Double.toString(Math.abs(dAmount.doubleValue())));
      eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE,
          KohlsConstant.PSA_DRIVERS_LICENSE_NUM); /* Need to check this */
      eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,
          KohlsXMLLiterals.ATTR_ACTIVATION_REVERSAL);
      eleTran.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,
          KohlsXMLLiterals.ATTR_MERC_RETURN_CREDIT);
      eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,
          elePaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2));
      eleTran.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER,
          elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_STORE_ID));
      eleTran.setAttribute(KohlsXMLLiterals.A_REGISTER_NUMBER,
          eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
      eleTran.setAttribute(KohlsXMLLiterals.A_SVCNO,
          elePaymentMethod.getAttribute(KohlsXMLLiterals.A_SVC_NO));
      eleTran.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
          eleOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
      eleTran.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,
          eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));
      
      if(ServerTypeHelper.amIOnEdgeServer()){    		
    		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docGCRevInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
    			docGCRevInput.getDocumentElement().removeChild(eleYfcAdditionalInfo);
    		}    		
    		eleYfcAdditionalInfo = XMLUtil.createChild(docGCRevInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
    		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
    	}

      KohlsCommonUtil.invokeService(yfsEnv, KohlsXMLLiterals.SER_KOHLS_POC_SVC, docGCRevInput);
    } catch (Exception e) {
      logger.error("Exception occurred while calling callPAGiftCardService API:" + e.getMessage());
    }
    logger.endTimer("KohlsPoCPAVoid.callPAGiftCardService");
  }


  private Document callRecordExternalPayments(YFSEnvironment yfsEnv, Document docRecPayments) {
    Document docOutput = null;
    logger.beginTimer("KohlsPoCPAVoid.callRecordExternalPayments");
    try {
    	
    	if(ServerTypeHelper.amIOnEdgeServer()){      		
      		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docRecPayments.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
      			docRecPayments.getDocumentElement().removeChild(eleYfcAdditionalInfo);
      		}
      		
      		eleYfcAdditionalInfo = XMLUtil.createChild(docRecPayments.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
      	}
      docOutput = KOHLSBaseApi.invokeAPI(yfsEnv, KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES,
          docRecPayments);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docOutput)) {
          logger.debug("callRecordExternalPayments  - Record External Charge - Update "
              + SCXmlUtil.getString(docOutput));
        }
      }

    } catch (Exception e) {
      logger.error(
          "Exception occurred while calling callRecordExternalPayments API:" + e.getMessage());
    }
    logger.endTimer("KohlsPoCPAVoid.callRecordExternalPayments");
    return docOutput;
  }

  public Document updatePAData(YFSEnvironment yfsEnv, Document docPAOrder) throws Exception {
    logger.beginTimer("KohlsPoCPAVoid.updatePAData");
    Document outDoc = null;

    if (!YFCCommon.isVoid(docPAOrder)) {

      Element elePAOrder =
          (Element) XPathUtil.getNodeList(docPAOrder, KohlsPOCConstant.ELE_ORDER).item(0);
      String strPOOrder = XMLUtil.getXMLString(docPAOrder);
      String sPSAStatus = "";
      String strOHkey = elePAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      Element eleOrderExtn = XMLUtil.getChildElement(elePAOrder, KohlsPOCConstant.E_EXTN);
      if (!YFCCommon.isVoid(eleOrderExtn)) {
        sPSAStatus = eleOrderExtn.getAttribute("ExtnPsaStatus");
      }

      // Creating input for KohlsPocManageOrigSaleData service

      Document docInputForPA = XMLUtil.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA);
      Element eleInputForPA = docInputForPA.getDocumentElement();
      eleInputForPA.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
      if (sPSAStatus.equalsIgnoreCase("PA_COMPLETED")) {
        eleInputForPA.setAttribute("PostVoidData", strPOOrder);
        
        //CAPE - 2755 - Murali K
      	if(ServerTypeHelper.amIOnEdgeServer()){ 
      		
      		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docInputForPA.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
      			docInputForPA.getDocumentElement().removeChild(eleYfcAdditionalInfo);
      		}
      		
      		eleYfcAdditionalInfo = XMLUtil.createChild(docInputForPA.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
      	}
      	
        //CAPE - 2755 - Murali K
        if (logger.isDebugEnabled()) {
          logger.debug("Input Document before service all  input doc: "
              + XMLUtil.getXMLString(docInputForPA));
        }
        
      
        outDoc = KOHLSBaseApi.invokeService(yfsEnv, "KohlsPoCManageOrigSaleData", docInputForPA);
      } /*
         * else { eleInputForPA.setAttribute("PSAData", strPOOrder); }
         */
      
    //Added for CAPE - 2755.
      
     // updateOldOrderToDirty(yfsEnv,docPAOrder);
    }

    
    
    logger.endTimer("KohlsPoCPAVoid.updatePAData");
    return outDoc;
  }

 

public Document updateTransactionAuditDetailsForPV(YFSEnvironment env, Document docInput) {
    logger.beginTimer("KohlsPoCPAVoid.updateTransactionAuditDetailsForPV");
    Document docOutput = null;
    Element eleOrder = docInput.getDocumentElement();
    if (!YFCCommon.isVoid(eleOrder)) {
      try {
        Element elePayment = (Element) XPathUtil
            .getNodeList(eleOrder, "//Order/PaymentMethods/PaymentMethod[@PaymentReference6='PA']")
            .item(0);
        Document docManageTraxAuditInput = XMLUtil.createDocument("TransactionAudit");
        Element elemanageTraxAuditInput = docManageTraxAuditInput.getDocumentElement();
        elemanageTraxAuditInput.setAttribute("OrderNumber", eleOrder.getAttribute("OrderNo"));
        elemanageTraxAuditInput.setAttribute("OrganizationCode",
            eleOrder.getAttribute("SellerOrganizationCode"));
        elemanageTraxAuditInput.setAttribute("OperatorID", elePayment.getAttribute("OperatorID"));
        elemanageTraxAuditInput.setAttribute("Action", KohlsPOCConstant.ACTION_CREATE);
        elemanageTraxAuditInput.setAttribute("DateTime", eleOrder.getAttribute("OrderDate"));
        elemanageTraxAuditInput.setAttribute("TerminalID", elePayment.getAttribute("TerminalID"));
        elemanageTraxAuditInput.setAttribute("TillID", elePayment.getAttribute("TillID"));
        elemanageTraxAuditInput.setAttribute("ProcedureID", "postVoid");
        elemanageTraxAuditInput.setAttribute("DocumentType", KohlsPOCConstant.SO_DOCUMENT_TYPE);
        Element eleOverallTtotals =
            (Element) XPathUtil.getNodeList(eleOrder, "//Order/OverallTotals").item(0);
        if (!YFCCommon.isVoid(eleOverallTtotals)) {
          elemanageTraxAuditInput.setAttribute("OrderTotal",
              eleOverallTtotals.getAttribute("GrandTotal"));
        }
        
        if(ServerTypeHelper.amIOnEdgeServer()){       		
      		Element eleYfcAdditionalInfo = XMLUtil.getChildElement(docManageTraxAuditInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      		if(!YFCCommon.isVoid(eleYfcAdditionalInfo)){
      			docManageTraxAuditInput.getDocumentElement().removeChild(eleYfcAdditionalInfo);
      		}      		
      		eleYfcAdditionalInfo = XMLUtil.createChild(docManageTraxAuditInput.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
      	}
        // Call manageTransactionAuditForPOS        
        docOutput = KOHLSBaseApi.invokeAPI(env,
            XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
            "manageTransactionAuditForPOS", docManageTraxAuditInput);
      } catch (Exception e) {
        logger.error(
            "Exception occurred while calling manageTransactionAuditForPOS API in KohlsPoCPAVoid.updateTransactionAuditDetailsForPV :"
                + e.getMessage());
      }
    } else {
      logger.debug("No order information for updating transaction Audit");
    }

    logger.endTimer("KohlsPoCPAVoid.updateTransactionAuditDetailsForPV");
    return docOutput;
  }

/**
 * This method updates most recent order to dirty and makes recent order to latest.... Create By Murali K - CAPE 2755
 * @param yfsEnv *
 * 
 * @param env
 * @param strOHkey
 * @throws Exception
 */
@SuppressWarnings("unchecked")

public void updateOrderToLatest(YFSEnvironment yfsEnv, Document inDoc) throws Exception {
	
	//input to getOrderList to take receipt ID
	Document inPutGetOrderListForPA = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
	inPutGetOrderListForPA.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
			inDoc.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
	if(ServerTypeHelper.amIOnEdgeServer()){   		
  		Element eleYfcAdditionalInfo = XMLUtil.createChild(inPutGetOrderListForPA.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
  		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
  	}
	
	//temp DOc
	Document tempGetOrderListPA = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDERLIST);
	Element eleGetOrderListPA = XMLUtil.createChild(tempGetOrderListPA.getDocumentElement(), KohlsXMLLiterals.E_ORDER);
	Element eleGetOrderExtnPA = XMLUtil.createChild(eleGetOrderListPA, KohlsXMLLiterals.E_EXTN);
	eleGetOrderExtnPA.setAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID, "");
	
	String strRecID = null;
	
	if(logger.isDebugEnabled()){
		logger.debug("Input getOrderList PA "+XMLUtil.getXMLString(inPutGetOrderListForPA));
	}
	//invoke getOrderList
	Document outDocGetOrderListPA = KOHLSBaseApi.invokeAPI(yfsEnv, tempGetOrderListPA, KohlsPOCConstant.GET_ORDER_LIST, inPutGetOrderListForPA);
	if(logger.isDebugEnabled()){
		logger.debug("OutPut getOrderList PA "+XMLUtil.getXMLString(outDocGetOrderListPA));
	}
	Element outOrderPA = XMLUtil.getChildElement(outDocGetOrderListPA.getDocumentElement(), KohlsXMLLiterals.E_ORDER);
	if(!YFCCommon.isVoid(outOrderPA)){
		strRecID = XMLUtil.getChildElement(outOrderPA, KohlsXMLLiterals.E_EXTN).getAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);
		
	}
	
	
	
	
	if(!YFCCommon.isVoid(strRecID)){
		//inPut to getOrderList of all orders with same receipt id
		Document inPutGetOrderListForAllOrders = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleExtn = XMLUtil.createChild(inPutGetOrderListForAllOrders.getDocumentElement(),KohlsXMLLiterals.E_EXTN);
		eleExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID, strRecID);
		
		if(ServerTypeHelper.amIOnEdgeServer()){   		
	  		Element eleYfcAdditionalInfo = XMLUtil.createChild(inPutGetOrderListForAllOrders.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
	  		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
	  	}
		//Temp Doc
		Document tempGetOrderListAllOrders = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDERLIST);
		Element eleGetOrderAll = XMLUtil.createChild(tempGetOrderListAllOrders.getDocumentElement(), KohlsXMLLiterals.E_ORDER);
		Element eleExtnGetOrderListAll = XMLUtil.createChild(eleGetOrderAll, KohlsXMLLiterals.E_EXTN);
		eleExtnGetOrderListAll.setAttribute(KohlsPOCConstant.EXTN_IS_LATEST, "");
		if(logger.isDebugEnabled()){
			logger.debug("inPut getOrderList All "+XMLUtil.getXMLString(inPutGetOrderListForAllOrders));
		}
		//Invoke getOrderList
		Document outDocGetOrderListAll = KOHLSBaseApi.invokeAPI(yfsEnv, tempGetOrderListAllOrders, KohlsPOCConstant.GET_ORDER_LIST, inPutGetOrderListForAllOrders);
		if(logger.isDebugEnabled()){
			logger.debug("outPut getOrderList All "+XMLUtil.getXMLString(outDocGetOrderListAll));
		}
		
		  NodeList nlOrders =
				  outDocGetOrderListAll.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_ORDER);
		  
			    if (nlOrders.getLength() > 0) {
			      for (int i = 0; i < nlOrders.getLength(); i++) {
			        Element eleTemoOrder = (Element) nlOrders.item(i);
			        Element eleTempOrderExtn =
			            XMLUtil.getChildElement(eleTemoOrder, KohlsXMLLiterals.E_EXTN);
			        if (!YFCCommon.isVoid(eleTempOrderExtn)) {
			        	String strIsLates = eleTempOrderExtn.getAttribute(KohlsPOCConstant.EXTN_IS_LATEST);
			          if (!YFCCommon.isVoid(strIsLates) && strIsLates.equals(KohlsPOCConstant.YES) && !eleTemoOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY).equals(inDoc.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY))) {
			        	  //input to changeOrder.
			        	  Document inDocChangeOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			        	  inDocChangeOrder.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, eleTemoOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
			        	  inDocChangeOrder.getDocumentElement().setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsPOCConstant.YES);
			        	  inDocChangeOrder.getDocumentElement().setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.YES);			        	  
			        	  Element eleChangeOrderExtn = XMLUtil.createChild(inDocChangeOrder.getDocumentElement(), KohlsXMLLiterals.E_EXTN);
			        	  eleChangeOrderExtn.setAttribute(KohlsPOCConstant.EXTN_IS_LATEST, KohlsPOCConstant.NO);
			        	  eleChangeOrderExtn.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, KohlsPOCConstant.PA_COMPLETED_DIRTY);
			        	  
			        	  if(ServerTypeHelper.amIOnEdgeServer()){   		
			      	  		Element eleYfcAdditionalInfo = XMLUtil.createChild(inDocChangeOrder.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
			      	  		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
			      	  	}
			        	  //invoke changeOrder.
			        	  if(logger.isDebugEnabled()){
			      			logger.debug("Input  to changeOrder API to make order dirty  :: --> "+XMLUtil.getXMLString(inDocChangeOrder));
			      		}
			        	  
			        	  Document docChangeOrderTemplate = XMLUtil.getDocument(KohlsPOCConstant.CHANGE_ORDER_TEMPLATE);
			        	     
			        	  KOHLSBaseApi.invokeAPI(yfsEnv,docChangeOrderTemplate, KohlsPOCConstant.API_CHANGE_ORDER, inDocChangeOrder);
			        	  break;
			          }
			          
			        }
			      }
			    }
			    
			   
			  /* String strIsLatestCallOver =  (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_LATEST_CALL_OVER);
			   if(YFCCommon.isVoid(strIsLatestCallOver)){
				   //input changeOrder for PA	
				   Document inDocChangeOrderPA = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
				   inDocChangeOrderPA.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, 
						   inDoc.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
				   inDocChangeOrderPA.getDocumentElement().setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsPOCConstant.YES);
		           Element eleChangeOrderExtn = XMLUtil.createChild(inDocChangeOrderPA.getDocumentElement(), KohlsXMLLiterals.E_EXTN);
		           eleChangeOrderExtn.setAttribute(KohlsPOCConstant.EXTN_IS_LATEST, KohlsPOCConstant.YES);
		           
		           if(ServerTypeHelper.amIOnEdgeServer()){   		
		      	  		Element eleYfcAdditionalInfo = XMLUtil.createChild(inDocChangeOrderPA.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
		      	  		eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);  		
		      	  	}
		           
		           if(logger.isDebugEnabled()){
		      			logger.debug("Input  to changeOrder API to make order Latest  :: --> "+XMLUtil.getXMLString(inDocChangeOrderPA));
		      		}
		           
		           //setting Env valiable
		           yfsEnv.setTxnObject(KohlsPOCConstant.IS_LATEST_CALL_OVER, KohlsPOCConstant.YES);
		           //invoke changeOrder.
		          KOHLSBaseApi.invokeAPI(yfsEnv, KohlsPOCConstant.API_CHANGE_ORDER, inDocChangeOrderPA);
			   }
			    */
		
	}
		
	
}
}
