package com.kohls.poc.returns.api;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
// import com.kohls.poc.test.testTVS.KohlsPSATVSHelper;
import com.kohls.poc.psa.api.KohlsPSATVSHelper;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * This Class prepares the request for TVS call (for only kohlsCash Eligible Items).
 * 
 * @author SA345825
 * 
 */
@SuppressWarnings("deprecation")
public class KohlsTVSCallForReturnKCEligibleItems {

  private static YFCLogCategory logger;
  String sStoreId = "";
  String sTerminalID = "";
  String sTranNo = "";
  HashMap<String, Document> tvsrequest = new HashMap<String, Document>();

  static {
    logger = YFCLogCategory.instance(KohlsTVSCallForReturnKCEligibleItems.class.getName());
  }

  KohlsPSATVSHelper objTVSHelper = new KohlsPSATVSHelper();

  /**
   * This Method prepares the request to call TVS web service for KohlsCash eligible items.
   * 
   * @param env
   * @param outDocKohlsCashWebService
   * @param tempOrderEle
   * @param refundReduction
   * @return tvsResponseDoc
   * @throws Exception
   */
  public Document prepareRequestForFirstTVSCall(YFSEnvironment env,
      Document outDocKohlsCashWebService, Element tempOrderEle, Element refundReduction,
      String strStoreId, String strTerminalID, String strTranNo) throws Exception {
    logger.beginTimer("KohlsTVSCallForReturnKCEligibleItems.prepareRequestForFirstTVSCall");
    Document tvsResponseDoc = null;
    Document firstTVSRequestDoc = null;
    this.sTranNo = strTranNo;
    this.sTerminalID = strTerminalID;
    // sStoreId = strStoreId;
    // Appending zero when store number length is less than 4
    this.sStoreId = KohlsPoCPnPUtil.prepadStoreNoWithZeros(strStoreId);
    if (tvsrequest.containsKey(sStoreId + "-" + sTerminalID + "-" + sTranNo)) {
      logger.debug("TVS request is already created for previous call. So reusing it");
      firstTVSRequestDoc = tvsrequest.get(sStoreId + "-" + sTerminalID + "-" + sTranNo);
      createManualTLD(firstTVSRequestDoc.getDocumentElement(), refundReduction);
    } else {
      logger.debug("TVS request is not created. So creating it.");
      // This request is for different transaction so clearing the map.
      // and building the request again.
      tvsrequest.clear();
      // Prepare TVS request document.
      firstTVSRequestDoc = XMLUtil.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
      Element priceRequestEle = firstTVSRequestDoc.getDocumentElement();
      priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
      priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");
      Element transactionEle =
          XMLUtil.createChild(priceRequestEle, KohlsPOCConstant.ORIGINAL_TRANSACTION);

      // Adding transactionId , store number and store address to TVS request
      createConstantEleForTVSReq(env, tempOrderEle, transactionEle);
      Element eleTransactionTime = (Element) transactionEle.getElementsByTagName(KohlsPOCConstant.TRANSACTION_TIME).item(0);
      String strTransactionTime = XMLUtil.getNodeValue(eleTransactionTime);
      Element lidOfferExempt =
          XMLUtil.createChild(transactionEle, KohlsPOCConstant.LID_OFFER_EXEMPT);
      XMLUtil.setNodeValue(lidOfferExempt, KohlsPOCConstant.NO);
      // Adding itemList Element to TVS request.
      Element itemListEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
      // Adding Kohls cash eligible items to the TVS request.
      Element eleKCSOutput = outDocKohlsCashWebService.getDocumentElement();
      if (!YFCCommon.isVoid(eleKCSOutput)) {

        checkForKCEligibleItems(eleKCSOutput, tempOrderEle, itemListEle);
        Element offersEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELEM_OFFERS);
        createManualTLD(transactionEle, refundReduction);
      }

      // Adding exclusions in TVS request
      KohlsPoCPnPUtil.constructExclusionsForRefundDeduction(env, transactionEle, strTransactionTime);
      Element adjustments = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ADJUSTMENS);

      // Adding taxExempt in TVS request
      String strTaxExemptFlag =
          XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.TAX_EXEMPT_FLAG);
      String strTaxExemptCert =
          XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

      if (!YFCCommon.isVoid(strTaxExemptCert)
          || strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES)) {
        Element eleTaxExempt =
            XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
        XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
      } else {
        Element eleTaxExempt =
            XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
        XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);
      }
      // Caching the TVS request in case we have to call it multiple times within
      // same transaction
      tvsrequest.put(sStoreId + "-" + sTerminalID + "-" + sTranNo, firstTVSRequestDoc);
    }
    logger.debug("Input to first TVS call for Kohls cash unearning::"
        + XMLUtil.getXMLString(firstTVSRequestDoc));
    try {

      logger.beginTimer("KohlsTVSCallForReturnKCEligibleItems.TVSWebserviceCall");
      // tvsResponseDoc = KOHLSBaseApi.invokeService(env,
      // "KohlsPoCTVSWebService", firstTVSRequestDoc);
      tvsResponseDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_POC_PSA_WEB_SERVICE,
          firstTVSRequestDoc);
      logger.endTimer("KohlsTVSCallForReturnKCEligibleItems.TVSWebserviceCall");
      logger.debug(
          "Output of TVS call for Kohls cash unearning ::" + XMLUtil.getXMLString(tvsResponseDoc));
    } catch (Exception e) {
      logger.error(
          "Error While Calling TVS web service for Kohls cash unearning" + e.getStackTrace());
    }
    logger.endTimer("KohlsTVSCallForReturnKCEligibleItems.prepareRequestForFirstTVSCall");
    // return objTVSHelper.validateTVSResponse(tvsResponseDoc);
    return tvsResponseDoc;
  }

  /**
   * 
   * @param transactionEle
   * @param eleRefundDeduction
   * @throws ParseException
   * @throws Exception
   */
  private void createManualTLD(Element transactionEle, Element eleRefundDeduction)
      throws ParseException, Exception {
    logger.beginTimer("KohlsTVSCallForReturnKCEligibleItems.createManualTLD");
    // Checking if manualTLD already created on the TVS request
    Element manualTLDEle =
        (Element) transactionEle.getElementsByTagName(KohlsPOCConstant.ELE_MANUAL_TLD).item(0);
    if (!YFCCommon.isVoid(manualTLDEle)) {
      logger.debug("manualTLD is already created. So updating the TLD amt");
      // manualTLD is already created. So updating the TLD amt
      String strRefundDeduction = XMLUtil.getNodeValue(eleRefundDeduction);
      Element eleMarkDownValue =
          XMLUtil.getChildElement(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
      XMLUtil.setNodeValue(eleMarkDownValue, strRefundDeduction);
    } else {
      logger.debug("manualTLD is not created. So creating one");
      manualTLDEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
      Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
      int i = KohlsPOCConstant.TLD_ID;
      int j = KohlsPOCConstant.ONE_INT;
      String strRefundDeduction = XMLUtil.getNodeValue(eleRefundDeduction);
      String ordPromotionID = (String) (Integer.toString(i + j));
      XMLUtil.setNodeValue(elePromoId, ordPromotionID);
      Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
      XMLUtil.setNodeValue(eleScanOrder, KohlsConstant.STRING_ONE);

      Element eleMarkDownValue =
          XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
      XMLUtil.setNodeValue(eleMarkDownValue, strRefundDeduction);
      Element eleDiscountType =
          XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
      XMLUtil.setNodeValue(eleDiscountType, KohlsPOCConstant.MANUAL_DOLLAR_OFF);
      Element eleGift = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATT_GIFT);
      XMLUtil.setNodeValue(eleGift, KohlsPOCConstant.YES);
      Element eleLegacyFlag = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_LEGACY_FLAG);
      XMLUtil.setNodeValue(eleLegacyFlag, KohlsPOCConstant.YES);
      Element eleIEIndicator = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR);
      XMLUtil.setNodeValue(eleIEIndicator, "None");
    }
    logger.endTimer("KohlsTVSCallForReturnKCEligibleItems.createManualTLD");
  }

  /**
   * This Method checks for Kohls cash eligible items from the KCS response.
   * 
   * @param eleKCSOutput
   * @param tempOrderEle
   * @param itemListEle
   * @throws YFSException
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  private void checkForKCEligibleItems(Element eleKCSOutput, Element tempOrderEle,
      Element itemListEle) throws YFSException, Exception {
    logger.beginTimer("KohlsTVSCallForReturnKCEligibleItems.checkForKCEligibleItems");
    Element eleData = (Element) eleKCSOutput.getElementsByTagName(KohlsPOCConstant.E_DATA).item(0);
    if (!YFCCommon.isVoid(eleData)) {
      Element eleReturnableItemList =
          XMLUtil.getChildElement(eleData, KohlsXMLLiterals.E_RETURNABLE_ITEMLIST);
      if (!YFCCommon.isVoid(eleReturnableItemList)) {
        List<Element> returnableItemList =
            XMLUtil.getElementsByTagName(eleReturnableItemList, KohlsXMLLiterals.E_RETURNABLE_ITEM);
        for (Element returnableItem : returnableItemList) {
          Element eleKohlsCashEligible =
              XMLUtil.getChildElement(returnableItem, KohlsXMLLiterals.E_KOHLS_CASH_ELIGIBLE);
          String strKohlsCashEligible = XMLUtil.getNodeValue(eleKohlsCashEligible);
          if ((KohlsPOCConstant.TRUE).equalsIgnoreCase(strKohlsCashEligible)) {
            // If the Item is kohls cash eligible , add it to the
            // TVS request.
            createReqForKCEligibleItems(tempOrderEle, itemListEle, returnableItem);
          }
        }
      }
    }
    logger.endTimer("KohlsTVSCallForReturnKCEligibleItems.checkForKCEligibleItems");
  }

  /**
   * 
   * @param tempOrderEle
   * @param itemListEle
   * @param returnableItem
   * @throws YFSException
   * @throws Exception
   */
  private void createReqForKCEligibleItems(Element tempOrderEle, Element itemListEle,
      Element returnableItem) throws YFSException, Exception {
    logger.beginTimer("KohlsTVSCallForReturnKCEligibleItems.createReqForKCEligibleItems");
    Element eleOutputItem = XMLUtil.createChild(itemListEle, KohlsPOCConstant.ELEM_SMALL_ITEM);
    Element eleLineNo = XMLUtil.getChildElement(returnableItem, KohlsXMLLiterals.E_LINE_NO);
    Element eleNetPrice = XMLUtil.getChildElement(returnableItem, KohlsPOCConstant.A_NET_PRICE);
    String strLineNo = XMLUtil.getNodeValue(eleLineNo);
    Element tempOrderExtnEle = XMLUtil.getChildElement(tempOrderEle, "Extn");
    // Fetching only those orderLines from the getOrderList output which are
    // KholsCash eligible.
    Element eleKCEligibleOrderLine = SCXmlUtil.getXpathElement(tempOrderEle,
        "OrderLines/OrderLine[@PrimeLineNo=" + strLineNo + "]");
    Element eleKCOrderLineExtn =
        XMLUtil.getChildElement(eleKCEligibleOrderLine, KohlsXMLLiterals.E_EXTN);
    String strExtnReturnPrice = XMLUtil.getAttribute(eleKCOrderLineExtn, "ExtnReturnPrice");
    Element eleFeeLineChargeEle = SCXmlUtil.getXpathElement(eleKCEligibleOrderLine,
        "LineCharges/LineCharge[@ChargeCategory='FEE']");
    // contruction of sku Element
    Element ordLineItemEle =
        XMLUtil.getChildElement(eleKCEligibleOrderLine, KohlsXMLLiterals.E_ITEM);
    String strItemId = ordLineItemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID);
    String createTS = ordLineItemEle.getAttribute(KohlsPOCConstant.A_CREATE_TS);
    Element eleSku = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_SKU);
    XMLUtil.setNodeValue(eleSku, strItemId);

    // contruction of id Element
    Element eleId = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_ID);
    if (!YFCCommon.isVoid(eleKCEligibleOrderLine)) {
      String strPrimeLineNo = eleKCEligibleOrderLine.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
      XMLUtil.setNodeValue(eleId, strPrimeLineNo);
    }

    objTVSHelper.createMerchandiseHierarchy(eleOutputItem, eleKCOrderLineExtn);
    objTVSHelper.createTaxAttributes(eleKCEligibleOrderLine, eleKCOrderLineExtn, eleOutputItem);

    //MJ 04/04 changes for PA - begin
    
    Double dFinalPrice = Double
        .parseDouble(XMLUtil.getNodeValue(eleNetPrice));
    //MJ 04/04 changes for PA - end
    Element eleRegPrice = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_REGULAR_PRICE);
    if(!YFCCommon.isVoid(eleFeeLineChargeEle) && !YFCCommon.isVoid(strExtnReturnPrice) && !"PriceAdjustment".equalsIgnoreCase(tempOrderExtnEle.getAttribute("ExtnPOCFeature"))){
    	XMLUtil.setNodeValue(eleRegPrice, strExtnReturnPrice);
    }else{
    	XMLUtil.setNodeValue(eleRegPrice, Double.toString(dFinalPrice));
    }

    // contruction of regularPriceStatus Element
    String SKUStatusCode =
        XMLUtil.getAttribute(eleKCOrderLineExtn, KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
    if (YFCCommon.isVoid(SKUStatusCode)) {
      SKUStatusCode = "20";
    }
    Element regularPriceStatusElement =
        XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.REGULAR_PRICE_STATUS);
    XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);

    // contruction of empDiscCode Element
    Boolean bEmpDiscCode = false;
    Element eleEmpDiscCode =
        XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
    Element eleReference = (Element) KohlsXPathUtil.getNode(eleKCEligibleOrderLine,
        "./References/Reference[@Name='ExtnEmpDiscCode']");
    if (!YFCCommon.isVoid(eleReference)) {
      if (!YFCCommon.isVoid(eleReference.getAttribute(KohlsPOCConstant.A_VALUE))) {
        XMLUtil.setNodeValue(eleEmpDiscCode, eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
        bEmpDiscCode = true;
      }
    }
    if (!bEmpDiscCode) {
      XMLUtil.setNodeValue(eleEmpDiscCode, KohlsPOCConstant.CONST_S);
    }
    // contruction of scanTime Element
    Element eleScanTime = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_SCAN_TIME);
	logger.debug("Input to KohlsTVSCallForReturnKCEligibleItems - tempOrderEle ::" + XMLUtil.getElementXMLString(tempOrderEle));

    if (!YFCCommon.isStringVoid(createTS)) {
      XMLUtil.setNodeValue(eleScanTime, createTS);
    } else {
      YFCDate date = new YFCDate();
      String sCreateTimeStamp = date.getString(null, true);
      XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
    }
    logger.endTimer("KohlsTVSCallForReturnKCEligibleItems.createReqForKCEligibleItems");
  }

  public void createConstantEleForTVSReq(YFSEnvironment env, Element tempOrderEle,
      Element transactionEle)
      throws Exception, YFSException, ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsTVSCallForReturnKCEligibleItems.createConstantEleForTVSReq");
    logger.debug("Input to KohlsTVSCallForReturnKCEligibleItems - tempOrderEle ::" + XMLUtil.getElementXMLString(tempOrderEle));
	String transTime = "";
	// Adding transactionId as POSSeqNo to the input request

	Element eleTransactionId =
			XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
	XMLUtil.setNodeValue(eleTransactionId, sTranNo);
	transTime = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORDER_DATE);
	// Adding Date2 as the transactionTime to the input request
	Element eleCustomAttributes = SCXmlUtil.getXpathElement(tempOrderEle, KohlsPOCConstant.CUSTOM_ATRRIBUTES);
	if (!YFCCommon.isVoid(eleCustomAttributes)) {
		String sDate2 = eleCustomAttributes.getAttribute(KohlsPOCConstant.DATE2);
		if(!YFCCommon.isVoid(sDate2)) {
			SimpleDateFormat sdf = new SimpleDateFormat (KohlsPOCConstant.INV_DATE_FORMAT);
			transTime= sdf.format(sdf.parse(sDate2));
		}
	}
		    Element eletransactionTime =
		        XMLUtil.createChild(transactionEle, KohlsPOCConstant.TRANSACTION_TIME);
		    XMLUtil.setNodeValue(eletransactionTime, transTime);
			logger.debug(" *** date2 ***" + transTime);

		    Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
		    XMLUtil.setNodeValue(eleStoreNum, sStoreId);

    // Adding storeAddress details to TVS request
    Element storeAddressEle =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
    Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
    Element eleCountry =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
    Element elePostal =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
    Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
    Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
    
    Document getOrganizationHierarchyInput = XMLUtil.getDocument("<Organization OrganizationKey='" + Integer.valueOf(sStoreId) + "' ></Organization>");
    Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
        "<Organization OrganizationName=''><Node ShipNode=''><ShipNodePersonInfo City='' Country='' ZipCode='' State='' TaxGeoCode=''/></Node></Organization>");
    Document getOrganizationListOutput =
        KOHLSBaseApi.invokeAPI(env, getOrganizationHierarchyTemplate,
            KohlsConstant.GET_ORGANIZATION_HIERARCHY_API, getOrganizationHierarchyInput);
    Element eleShipNdPerInfo = ((Element) getOrganizationListOutput
        .getElementsByTagName(KohlsXMLLiterals.E_SHIPNODE_PERSON_INFO).item(0));
    XMLUtil.setNodeValue(eleCity,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
    XMLUtil.setNodeValue(eleCountry,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
    XMLUtil.setNodeValue(elePostal,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
    XMLUtil.setNodeValue(eleState,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
    XMLUtil.setNodeValue(eleGeo,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
    // }

    // }
    // MJ 01/25: Commented for CAPE 1612 - end
    logger.endTimer("KohlsTVSCallForReturnKCEligibleItems.createConstantEleForTVSReq");
  }

}
