/**
 * 
 */
package com.kohls.poc.returns.api;

import java.io.IOException;
import java.math.RoundingMode;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.text.DecimalFormat;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.psa.api.KohlsPSATVSHelper;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author chidu This class handles RS offline scenario If RS is Offline it contacts TVS to get TAX
 *         details and updates the same to Order Line
 * 
 */
@SuppressWarnings("deprecation")
public class KohlsPoCRSOffline {

  private static YFCLogCategory logger;

  boolean IsUnitPricezero = false;
  boolean isEligibleForAssocDisc = false;

  static {
    logger = YFCLogCategory.instance(KohlsPoCRSOffline.class.getName());
  }

  /**
   * @param env
   * @param eleOrderLine
   * @param inputDoc
   * @param orderLineUnitPrice
   * @param isAssocDiscPresent
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws NumberFormatException
   * @throws IOException
   */
  public boolean processOTROffline(YFSEnvironment env, Element eleCurrentOrderLine, Document inputDoc,
      String orderLineUnitPrice, boolean isAssocDiscCall)
      throws ParserConfigurationException, SAXException, NumberFormatException, IOException {

    if (logger.isDebugEnabled()) {
      logger.beginTimer("KohlsPoCRSOffline.processOTROffline");
      logger.debug("input order :::: " + XMLUtil.getXMLString(inputDoc));
      logger.debug("order  line element :::: " + XMLUtil.getElementXMLString(eleCurrentOrderLine));
      logger.debug(" is Assoc Disc Call " + isAssocDiscCall);
    }
    
    KohlsPSATVSHelper objTVSHelper = new KohlsPSATVSHelper();
    KohlsPoCProcessNonReceiptOrder objNonRec = new KohlsPoCProcessNonReceiptOrder();
    Document firstTVSRequestDoc;
    Document tvsResponseDoc = null;
    String sTVSErrorMessage = "Errors in TVS Response";
    DecimalFormat df = new DecimalFormat("#0.00");
    Double assocDiscAmt = 0.0D;
    Element eleOrderLineExtn = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN);
    Element custAttributesEle =
        XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
    try {
      firstTVSRequestDoc = XMLUtil.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
      Element priceRequestEle = firstTVSRequestDoc.getDocumentElement();
      priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
      priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");
      Element transactionEle =
          XMLUtil.createChild(priceRequestEle, KohlsPOCConstant.ORIGINAL_TRANSACTION);

      Element eleTransactionId =
          XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
      XMLUtil.setNodeValue(eleTransactionId,
          custAttributesEle.getAttribute(KohlsPOCConstant.TEXT9));

      Element eletransactionTime =
          XMLUtil.createChild(transactionEle, KohlsPOCConstant.TRANSACTION_TIME);
      XMLUtil.setNodeValue(eletransactionTime,
          custAttributesEle.getAttribute(KohlsPOCConstant.DATE2));

      Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
      XMLUtil.setNodeValue(eleStoreNum, custAttributesEle.getAttribute(KohlsPOCConstant.TEXT7));

      // Adding storeAddress details to TVS request
      Element storeAddressEle =
          XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
      Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
      Element eleCountry =
          XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
      Element elePostal =
          XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
      Element eleState =
          XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
      Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);

      Document getOrganizationListOutput =
          getOrganizationHierarchy(env, custAttributesEle.getAttribute(KohlsPOCConstant.TEXT7));

      Element eleShipNdPerInfo = ((Element) getOrganizationListOutput
          .getElementsByTagName(KohlsXMLLiterals.E_SHIPNODE_PERSON_INFO).item(0));
      XMLUtil.setNodeValue(eleCity,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
      XMLUtil.setNodeValue(eleCountry,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
      XMLUtil.setNodeValue(elePostal,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
      XMLUtil.setNodeValue(eleState,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
      XMLUtil.setNodeValue(eleGeo,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));

      Element lidOfferExempt =
          XMLUtil.createChild(transactionEle, KohlsPOCConstant.LID_OFFER_EXEMPT);
      XMLUtil.setNodeValue(lidOfferExempt, KohlsPOCConstant.NO);

      Element itemListEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
      Element eleOrderLines = (Element) eleCurrentOrderLine.getParentNode();
      NodeList nlOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
      String strTaxExemptFlag ="";
      String strTaxExemptCert ="";
	  for(int iOrderLine=0; iOrderLine < nlOrderLines.getLength();iOrderLine++){
	    	  
	  	  Element eleOrderLine = (Element)nlOrderLines.item(iOrderLine);
	      Element eleOutputItem = XMLUtil.createChild(itemListEle, KohlsPOCConstant.ELEM_SMALL_ITEM);
	
	      Element ordLineItemEle = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_ITEM);
	      eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
	
	      String sExtnEmpDiscCode = "";
	      Element eleReference = (Element) KohlsXPathUtil.getNode(eleOrderLine,
	          "./References/Reference[@Name='ExtnEmpDiscCode']");
	      if (!YFCCommon.isVoid(eleReference)) {
	        sExtnEmpDiscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
	      }
	      if (YFCCommon.isVoid(eleOrderLineExtn.getAttribute(KohlsPOCConstant.EXTN_ITEM_DEPT))) {
	        // call getItemList
	        Document getItemListInput = XMLUtil.getDocument("<Item OrganizationCode='DEFAULT' ItemID='"
	            + XMLUtil.getAttribute(ordLineItemEle, KohlsPOCConstant.A_ITEM_ID) + "' />");
	        Document getItemListTemplate = XMLUtil.getDocument(
	            "<ItemList><Item ItemID='' ><ClassificationCodes TaxProductCode='' /> <Extn ExtnEmpDiscCode='' ExtnClass='' ExtnSubClass='' ExtnDept=''/></Item></ItemList>");
	        Document getItemListOutput =
	            KOHLSBaseApi.invokeAPI(env, getItemListTemplate, "getItemList", getItemListInput);
	        NodeList nItemList = getItemListOutput.getElementsByTagName("Item");
	        if (!YFCCommon.isVoid(nItemList)) {
	          Element eleItemOut = ((Element) nItemList.item(0));
	
	          if (!YFCCommon.isVoid(eleItemOut)) {
	            Element eleItemExtn = ((Element) eleItemOut.getElementsByTagName("Extn").item(0));
	            eleOrderLineExtn.setAttribute(KohlsPOCConstant.EXTN_ITEM_DEPT,
	                eleItemExtn.getAttribute(KohlsPOCConstant.E_EXTN_DEPT));
	            eleOrderLineExtn.setAttribute(KohlsPOCConstant.EXTN_ITEM_CLASS,
	                eleItemExtn.getAttribute("ExtnClass"));
	            eleOrderLineExtn.setAttribute(KohlsPOCConstant.EXTN_ITEM_SUB_CLASS,
	                eleItemExtn.getAttribute("ExtnSubClass"));
	            sExtnEmpDiscCode = eleItemExtn.getAttribute("ExtnEmpDiscCode");
	            Element eleItemClassificationCodes =
	                ((Element) eleItemOut.getElementsByTagName("ClassificationCodes").item(0));
	            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE,
	                eleItemClassificationCodes.getAttribute(KohlsPOCConstant.A_TAX_PRODUCT_CODE));
	          } else {
	            logger.error("Item " + XMLUtil.getAttribute(ordLineItemEle, KohlsPOCConstant.A_ITEM_ID)
	                + " is not present in OMS. This is the case of Item Not On File.");
	            throw new YFSException("Item Not Found in OMS");
	          }
	        }
	      }
	
	      if (YFCCommon.isVoid(sExtnEmpDiscCode)) {
	        sExtnEmpDiscCode = "S";
	      }
	
	      String createTS = ordLineItemEle.getAttribute(KohlsPOCConstant.A_CREATE_TS);
	
	      String strItemId = ordLineItemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID);
	
	      Element eleSku = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_SKU);
	      XMLUtil.setNodeValue(eleSku, strItemId);
	
	      Element eleId = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_ID);
	      String strPrimeLineNo = eleOrderLine.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
	      XMLUtil.setNodeValue(eleId, strPrimeLineNo);
	      
	      String taxProductCode = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE);
	      if ( YFCCommon.isVoid( taxProductCode ) ) {
	    	  if( ( !YFCCommon.isVoid( ordLineItemEle ) ) && ordLineItemEle.hasAttribute( KohlsPOCConstant.A_TAX_PRODUCT_CODE ) ){
	    		  taxProductCode = ordLineItemEle.getAttribute( KohlsPOCConstant.A_TAX_PRODUCT_CODE );
		    	  if ( !YFCCommon.isVoid( taxProductCode ) ) {
		    		  eleOrderLineExtn.setAttribute( KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE, taxProductCode );
		    	  } 
	    	  }
	      }
	
	      objTVSHelper.createMerchandiseHierarchy(eleOutputItem, eleOrderLineExtn);
	      objTVSHelper.createTaxAttributes(eleOrderLine, eleOrderLineExtn, eleOutputItem);
	
	      Element eleLinePriceInfo =
	          (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
	
	      Double dFinalPrice = 0.00D;
	
	      dFinalPrice =
	          Double.parseDouble(eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE));
	
	      Element eleLineCharges =
	          (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGES).item(0);
	
	      NodeList nlLineCharge =
	          eleLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
	
	      if (nlLineCharge.getLength() > 0) {
	        for (int l = 0; l < nlLineCharge.getLength(); l++) {
	          Element eleLineCharge = (Element) nlLineCharge.item(l);
	          String sChargeCategory = eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY);
	
	          if (KohlsPOCConstant.KOHLS_CASH_DISCOUNT.equals(sChargeCategory)) {
	            String sChargePerLine = eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE);
	            dFinalPrice = dFinalPrice - Double.parseDouble(sChargePerLine);
	          }
	        }
	      }
	
	      // CAPE-2110 -- Offline Associate Discount-- Adding manualTLD -
	      // Murali K -- Start
	      // String strAssocID = "000000";
	
	      String strAssocID =
	          XMLUtil.getChildElement(inputDoc.getDocumentElement(), KohlsXMLLiterals.E_EXTN)
	              .getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
	
	      if (!YFCCommon.isVoid(strAssocID) && strAssocID.equals("000000") && isAssocDiscCall) {
	        df.setRoundingMode(RoundingMode.UP);
	        Element eleManualTLD = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
	        Element eleID = XMLUtil.createChild(eleManualTLD, KohlsPOCConstant.ATTR_ID);
	        Element elescanOrder = XMLUtil.createChild(eleManualTLD, KohlsPOCConstant.ATTR_SCAN_ORDER);
	        Element elemarkDownValue =
	            XMLUtil.createChild(eleManualTLD, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
	        Element elesecondaryMarkDownValue =
	            XMLUtil.createChild(eleManualTLD, KohlsPOCConstant.ATTR_SECONDARY_MARK_DOWN_VALUE);
	        Element elediscountType =
	            XMLUtil.createChild(eleManualTLD, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
	
	
	        String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;
	        String strDiscountValueFromUtil = objNonRec
	            .getDiscountsPercentageForPOSBydate(env, inputDoc.getDocumentElement(), ruleId).trim();
	
	        String[] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
	        int length1 = delimitedComma[0].length() - 1;
	        int length2 = delimitedComma[1].length() - 1;
	        String sAssoc_S_Percent = delimitedComma[0].substring(0, length1);
	        String sAssoc_H_Percent = delimitedComma[1].substring(0, length2);
	        if (logger.isDebugEnabled()) {
	          logger.debug(" *** soft Associate Discount   % ***" + sAssoc_S_Percent);
	          logger.debug(" *** hard  Associate Discount   % ***" + sAssoc_H_Percent);
	
	        }
	
	        eleID.setTextContent("1001");
	        elescanOrder.setTextContent("1");
	        elemarkDownValue.setTextContent(
	            String.valueOf(Double.valueOf(sAssoc_S_Percent) / KohlsPOCConstant.HUNDRED_INT));
	        elesecondaryMarkDownValue.setTextContent(
	            String.valueOf(Double.valueOf(sAssoc_H_Percent) / KohlsPOCConstant.HUNDRED_INT));
	        elediscountType.setTextContent(KohlsPOCConstant.ASSOCIATE);
	
	
	
	        if ("S".equalsIgnoreCase(sExtnEmpDiscCode)) {
	
	          // dFinalPrice = (dFinalPrice * 100) / (100 -
	          // (Double.valueOf(sAssoc_S_Percent)));
	          assocDiscAmt = Double.parseDouble(df.format((dFinalPrice * Double.valueOf(sAssoc_S_Percent))
	              / (100 - Double.valueOf(sAssoc_S_Percent))));
	
	        } else {
	          // dFinalPrice = (dFinalPrice * 100) / (100 -
	          // (Double.valueOf(sAssoc_H_Percent)));
	          assocDiscAmt = Double.parseDouble(df.format((dFinalPrice * Double.valueOf(sAssoc_H_Percent))
	              / (100 - Double.valueOf(sAssoc_H_Percent))));
	        }
	        // fix for 3533
	        // MJ 06-17: corrected this logic. Instead of adjusting dFinalPrice, adjusting
	        // strUpdatedPrice
	        // dFinalPrice =
	        // Double.parseDouble(eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE));
	        dFinalPrice = dFinalPrice + assocDiscAmt;
	        if (logger.isDebugEnabled()) {
	          logger.debug("*** Associate Discount is: " + assocDiscAmt);
	          logger.debug(" *** Regular Price to TVS is :: " + dFinalPrice);
	        }
	      }
	
	      // setting updated price as unit price.
	      String strUpdatedPrice =
	          df.format(Double.parseDouble(eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE))
	              + assocDiscAmt);
	      logger.debug("*** UnitPrice is: " + strUpdatedPrice);      
	
	      // CAPE-2110 -- Offline Associate Discount-- Adding manualTLD -
	      // Murali K -- END
	      
	      Element eleRegPrice = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_REGULAR_PRICE);
	      XMLUtil.setNodeValue(eleRegPrice, df.format(dFinalPrice));
	
	      String SKUStatusCode =
	          XMLUtil.getAttribute(eleOrderLineExtn, KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
	      if (YFCCommon.isVoid(SKUStatusCode)) {
	        SKUStatusCode = "20";
	      }
	
	      Element regularPriceStatusElement =
	          XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.REGULAR_PRICE_STATUS);
	      XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);
	
	      // contruction of empDiscCode Element
	      Boolean bEmpDiscCode = false;
	      Element eleEmpDiscCode =
	          XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
	      XMLUtil.setNodeValue(eleEmpDiscCode, sExtnEmpDiscCode);
	
	
	      // contruction of scanTime Element
	      Element eleScanTime = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_SCAN_TIME);
	
	      if (!YFCCommon.isStringVoid(createTS)) {
	        XMLUtil.setNodeValue(eleScanTime, createTS);
	      } else {
	        YFCDate date = new YFCDate();
	        String sCreateTimeStamp = date.getString(null, true);
	        XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
	      }
	      strTaxExemptFlag =
	              XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.TAX_EXEMPT_FLAG);
	      strTaxExemptCert =
	              XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);
	  }
      KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(env, transactionEle);
      // XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_EXCLUSIONS);

      XMLUtil.createChild(transactionEle, KohlsPOCConstant.ADJUSTMENS);
      // XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);

      // Adding taxExempt in TVS request
      
      if (!YFCCommon.isVoid(strTaxExemptCert)
          || strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES)) {
        Element eleTaxExempt =
            XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
        XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
      } else {
        Element eleTaxExempt =
            XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
        XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);
      }

      try {
        logger
            .debug("Input to TVS call from KohlsPoCRSOffline.processOTROffline Request is *********"
                + XMLUtil.getXMLString(firstTVSRequestDoc));
        tvsResponseDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_POC_PSA_WEB_SERVICE,
            firstTVSRequestDoc);
        logger.debug(
            "Input to TVS call from KohlsPoCRSOffline.processOTROffline Response is *********"
                + XMLUtil.getXMLString(tvsResponseDoc));
      } catch (Exception e) {
        e.printStackTrace();
        logger.error("Error While Calling TVS web service " + e.getStackTrace());
      }
      boolean bErrorsInTVS =
          new KohlsReturnsKCDeactivation().checkForTVSResponseErrors(tvsResponseDoc);
      if (bErrorsInTVS) {
        logger.debug("Errors in TVS response, Please proceed with tendering!!");
        throw new YFSException(sTVSErrorMessage);
      } else {
    	  Element itemElementlist = (Element) KohlsXPathUtil.getNode(tvsResponseDoc.getDocumentElement(), "//itemList");
    	  NodeList nlItems = itemElementlist.getElementsByTagName("item");
          NodeList nlLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
          KohlsPoCTVSReturnOrderReprice returnRepriceObj = new KohlsPoCTVSReturnOrderReprice();
          for(int iItems =0 ;iItems < nlItems.getLength();iItems++){
          	Element respItemElement = (Element)nlItems.item(iItems);
          	KohlsPoCPnPUtil.consolidateLineTaxes(respItemElement);
              for(int iLines=0;iLines <nlLines.getLength();iLines++){
              	Element eleCurrentLine = (Element) nlLines.item(iLines);
              	if(!(respItemElement.getAttribute("id").equalsIgnoreCase(
              			eleCurrentLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO)))){
              		continue;
              	}
    	  
              	eleOrderLineExtn = XMLUtil.getChildElement(eleCurrentLine, KohlsPOCConstant.E_EXTN);
              	Element eleLinePriceInfo = XMLUtil.getChildElement(eleCurrentLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
		        Element respTaxElement = (Element) KohlsXPathUtil.getNode(respItemElement, "//item/LineTaxes");
		        if (!YFCCommon.isVoid(respTaxElement)) {
		          // Checking if OrderLine already has LineTaxes element. If yes, then remove it and import
		          // the one from TVS
		          Element eleInputLineTaxes =
		              (Element) eleCurrentLine.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAXES).item(0);
		          if (!YFCCommon.isVoid(eleInputLineTaxes)) {
		        	  eleCurrentLine.removeChild(eleInputLineTaxes);
		          }
		          XMLUtil.importElement(eleCurrentLine, respTaxElement);
		        }
		        
		        //CPE -214 : start - this might be commented based on confirmation
		        //If fee is returned then updated LineTaxes , LineCharges, and Awards
		        NodeList nlFee = respItemElement.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
		        if (!YFCCommon.isVoid(nlFee)) {
		        	String sMultiOrderNbr = custAttributesEle.getAttribute(KohlsPOCConstant.TEXT13);
		        	if(YFCCommon.isVoid(sMultiOrderNbr)){
		        		returnRepriceObj.updateReturnFee(eleCurrentLine, respItemElement);
		        	}else{
		        		logger.debug("TaxFee details not updated since its ECom Store");
		        	}
		        }
		
		        // MJ Changes for CAPE-2823 - start
		        String sExtnTaxableAmount =
		            eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
		        if (YFCCommon.isVoid(sExtnTaxableAmount)) {
		          
		          String sTVSTaxableAmount = respItemElement.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
		          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, sTVSTaxableAmount);
		        }
		
		        // MJ Changes for CAPE-2823 - end
		
		        // CAPE-2110 -- Murali K - Start
		
		        Element resModifierListEle = (Element) KohlsXPathUtil
		            .getNode(respItemElement, "//item/modifierList/modifier");
		
		        if (!YFCCommon.isVoid(resModifierListEle) && isAssocDiscCall) {
		          Element eleInputLineCharges =
		              (Element) eleCurrentLine.getElementsByTagName(KohlsXMLLiterals.E_LINE_CHARGES).item(0);
		          Element eleAssocLineCharge =
		              XMLUtil.createChild(eleInputLineCharges, KohlsXMLLiterals.E_LINE_CHARGE);
		          eleAssocLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY,
		              KohlsPOCConstant.ASSOCIATE_DISCOUNT_CHARGE);
		          eleAssocLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_NAME,
		              KohlsPOCConstant.ASSOCIATE_DISCOUNT_CHARGE);
		
		          eleAssocLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE,
		              df.format(assocDiscAmt));
		          eleAssocLineCharge.setAttribute(KohlsXMLLiterals.A_IS_DISCOUNT, KohlsPOCConstant.YES);
		          eleLinePriceInfo.setAttribute(KohlsPOCConstant.A_UNIT_PRICE, respItemElement.getAttribute("regularPrice"));
		          isEligibleForAssocDisc = true;
		          returnRepriceObj.updateTaxIndicators(eleCurrentLine);
		        }
              }
          
        }
        // CAPE-2110 -- Murali K - End
      }

    } catch (Exception e) {
      e.printStackTrace();
      logger.error("Error While Calling TVS web service for processOTROffline" + e.getStackTrace());
    }

    logger.endTimer("KohlsPoCRSOffline.processOTROffline");

    return isEligibleForAssocDisc;

  }

  /**
   * @param env
   * @param sOrgCode
   * @return
   * @throws Exception
   */
  private Document getOrganizationHierarchy(YFSEnvironment env, String sOrgCode) throws Exception {
    Document getOrganizationHierarchyInput = null;
    Document getOrganizationListOutput = null;
    Document getOrganizationHierarchyTemplate = null;
    try {
      getOrganizationHierarchyTemplate =
          XMLUtil.getDocument("<Organization OrganizationName=''><Node "
              + "ShipNode=''><ShipNodePersonInfo City='' Country='' "
              + "ZipCode='' State='' TaxGeoCode=''/></Node>" + "</Organization>");
      getOrganizationHierarchyInput = XMLUtil.getDocument("<Organization OrganizationCode='"
          + sOrgCode + "' OrganizationKey='" + Integer.valueOf(sOrgCode) + "' ></Organization>");
      getOrganizationListOutput = KOHLSBaseApi.invokeAPI(env, getOrganizationHierarchyTemplate,
          KohlsConstant.GET_ORGANIZATION_HIERARCHY_API, getOrganizationHierarchyInput);
    } catch (NumberFormatException e) {
      logger.error(
          "Error While Calling getOrganizationHierarchy NumberFormatException" + e.getStackTrace());
    } catch (ParserConfigurationException e) {
      logger.error("Error While Calling getOrganizationHierarchy ParserConfigurationException"
          + e.getStackTrace());
    } catch (SAXException e) {
      logger.error("Error While Calling getOrganizationHierarchy SAXException" + e.getStackTrace());
    } catch (IOException e) {
      logger.error("Error While Calling getOrganizationHierarchy IOException" + e.getStackTrace());
    }

    return getOrganizationListOutput;
  }

}
