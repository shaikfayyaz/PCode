package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsReturnsKCOptionSelected extends KOHLSBaseApi {
  private static YFCLogCategory logger;
  private String endpoint;
  static {
    logger = YFCLogCategory.instance(KohlsReturnsKCOptionSelected.class.getName());
  }

  /**
   * 
   * @param env
   * @param orderInDoc
   * @return
   * @throws Exception
   */
  public Document callChangeOrder(YFSEnvironment env, Document orderInDoc) throws Exception {
    logger.beginTimer("KohlsReturnsKCOptionSelected.callChangeOrder");
    logger.debug("Input to this method " + XMLUtil.getXMLString(orderInDoc));
    Element eleOrder = orderInDoc.getDocumentElement();
    // changes for Consolidating order for multireceipts
    NodeList nProratedLines = orderInDoc.getElementsByTagName("ProRatedLines");
    if (!YFCCommon.isVoid(nProratedLines) && nProratedLines.getLength() > 0) {
      orderInDoc = consolidatePromotionsAndOrder(orderInDoc);
    }
    eleOrder.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsXMLLiterals.CONST_Y);
    eleOrder.setAttribute("ValidatePromotionAward", KohlsPOCConstant.NO);
    Element eleAddtionalInfo =
        XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
    if (!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()) {
      endpoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
    }
    Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
    String sExtnPoCFeature = "";
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      sExtnPoCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
    }
    if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPoCFeature)) {
      eleOrder.setAttribute("IgnoreRepricingUE", KohlsPOCConstant.YES);
      eleOrder.setAttribute("SuppressRepricingUE", KohlsPOCConstant.YES);
    }
    // removeUnwantedPromotions(orderInDoc);
    // Iterating through NodeList, so that
    // can process through more than one <Promotion/>
    
    // Preparing changeOrder input for RR
    Document docChangeOrder = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    Element eleChangeOrderRoot = docChangeOrder.getDocumentElement();
    eleChangeOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderInDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
    eleChangeOrderRoot.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
    eleChangeOrderRoot.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
    eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_ACTION, KohlsConstant.MODIFY);
    Element eleChangeOrderPromotions = docChangeOrder.createElement(KohlsPOCConstant.E_PROMOTIONS);
    eleChangeOrderRoot.appendChild(eleChangeOrderPromotions);
    
    boolean bPromotionPresentForChangeOrder = false;
    
    NodeList nlPromotion = orderInDoc.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        if (KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(sPromotionType)
            || KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType)) {
          Element elePromotionExtn =
              (Element) (elePromotion.getElementsByTagName(KohlsXMLLiterals.E_EXTN)).item(0);
          String sKCOptionSelected = null;
          if (!YFCCommon.isVoid(elePromotionExtn)) {
            sKCOptionSelected =
                elePromotionExtn.getAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED);
          }
          // Removing <OrderLines/> for
          // OrderLinesForKCOption!=<sKCOptionSelected>
          // removeOrderLines(orderInDoc, sKCOptionSelected);
          // Remove payment methods because, its called from
          // KohlsPSARefund api.
          removePaymentMethods(orderInDoc);
          //CPE-11581 create Auto Return Document
          Document docAutoReturn = (Document) env.getTxnObject("AUTO_RETURN_DOC");
          if (KohlsPOCConstant.MAX_REFUND.equalsIgnoreCase(sKCOptionSelected)) {
            // Getting unearned KC amount
            Element elePromotionMaxRefund =
                XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.MAX_REFUND);
            String sRefundDeduction =
                elePromotionMaxRefund.getAttribute(KohlsPOCConstant.REF_DEDUCTION);
            String sKohlsCashReduction =
                elePromotionMaxRefund.getAttribute(KohlsPOCConstant.UNEARNED_KC);
            elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                sKohlsCashReduction);
            elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KC_UNEARNED_VALUE,
                sKohlsCashReduction);
            elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_REFUND_DEDUCTION,
                sRefundDeduction);
          //CPE-11581 avoid ACTION=CREATE if Auto Return LCS scenario
            if(KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType) && YFCCommon.isVoid(docAutoReturn)) {
              elePromotion.setAttribute(KohlsPOCConstant.A_ACTION, "CREATE");
            }
              XMLUtil.importElement(eleChangeOrderPromotions, elePromotion);
            //logger.debug("Input to callchangeOrder:" + XMLUtil.getXMLString(orderInDoc));
          } else if (KohlsPOCConstant.MAX_KC.equalsIgnoreCase(sKCOptionSelected)) {
            Element elePromotionMaxKohlsCash =
                XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.MAX_KC);
            String sRefundDeduction =
                elePromotionMaxKohlsCash.getAttribute(KohlsPOCConstant.REF_DEDUCTION);
            String sKohlsCashReduction =
                elePromotionMaxKohlsCash.getAttribute(KohlsPOCConstant.UNEARNED_KC);
            elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KC_UNEARNED_VALUE,
                sKohlsCashReduction);
            elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_REFUND_DEDUCTION,
                sRefundDeduction);
            elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                sRefundDeduction);
            //CPE-11581 avoid ACTION=CREATE if Auto Return LCS scenario
            if(KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType) && YFCCommon.isVoid(docAutoReturn)) {
              elePromotion.setAttribute(KohlsPOCConstant.A_ACTION, "CREATE");
            }
            XMLUtil.importElement(eleChangeOrderPromotions, elePromotion);
          } else {
            logger.error(
                "KohlsReturnsKCOptionSelected.callChangeOrder : changeOrder not called because ExtnKCOptionSelected is: "
                    + sKCOptionSelected);
            continue;
          }
          // Added for Price Adjustment
          if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT
              .equalsIgnoreCase(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE))) {
            // this.removePaymentMethods(docOrderInDocClone);
            // this.removeOrderLines(docOrderInDocClone, sKCOptionSelected);
            bPromotionPresentForChangeOrder = true;
            //processKCUnearnForPriceAdjustment(env, orderInDoc);
          } 
          // PLYT-1542 moving changeOrder call outside loop.
          else {
            // setting the minimum required template
            /*Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
            KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API,
                orderInDoc); */
            if(eleChangeOrderPromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION).getLength() >0) {
              bPromotionPresentForChangeOrder = true;
            }
          }
        }
      }
    }
    //Call changeOrder only once for Return and PA
    if(bPromotionPresentForChangeOrder) {
      if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT
          .equalsIgnoreCase(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE))) {
        processKCUnearnForPriceAdjustment(env, orderInDoc);
      } else {
          Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
          
          //Checking if there any order lines to import
          Element eleOrderLines = XMLUtil.getChildElement(orderInDoc.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
          
          if(!YFCCommon.isVoid(eleOrderLines)) {
            XMLUtil.importElement(docChangeOrder.getDocumentElement(), eleOrderLines);
          }
          
          if(logger.isDebugEnabled()) {
            logger.debug("KohlsReturnsLCSCallWrapper.callChangeOrder Input to changeOrder is: "+XMLUtil.getXMLString(docChangeOrder));
          }
          //env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
          KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API, docChangeOrder);
          //env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "");
        }
      }
    
    logger.endTimer("KohlsReturnsKCOptionSelected.callChangeOrder");
    return orderInDoc;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param orderInDoc This method removes the promotion other that KOHLS_CASH_UNEARNED
   */
  private void removeUnwantedPromotions(Document orderInDoc) {
    logger.beginTimer("KohlsReturnsKCOptionSelected.removeUnwantedPromotions");
    NodeList nlPromotion = orderInDoc.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    Element elePromotions =
        XMLUtil.getChildElement(orderInDoc.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS);
    for (int i = 0; i < nlPromotion.getLength(); i++) {
      Element elePromotion = (Element) nlPromotion.item(i);
      String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
      if (!("KOHLS_CASH_UNEARNED".equals(sPromotionType))) {
        elePromotions.removeChild(elePromotion);
        i--;
      }
    }
    logger.endTimer("KohlsReturnsKCOptionSelected.removeUnwantedPromotions");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param orderInDoc
   * 
   *        This method processes the KohlsCashUnearning for Price Adjustment.
   * @throws Exception
   */
  private void processKCUnearnForPriceAdjustment(YFSEnvironment env, Document orderInDoc)
      throws Exception {
    logger.beginTimer("KohlsReturnsKCOptionSelected.processKCUnearnForPriceAdjustment");
    if (logger.isDebugEnabled()) {
      logger.debug("Document input to processKCUnearnForPriceAdjustment is::"
          + XMLUtil.getXMLString(orderInDoc));
    }
    DecimalFormat df = new DecimalFormat("#0.00");
    Double dOldLineTotalWithoutTax = 0.0;
    Double dNewLineTotalWithoutTax = 0.0;
    Double dOldTotalTax = 0.0;
    Double dNewTotalTax = 0.0;
    Element eleOrderRoot = orderInDoc.getDocumentElement();
    String sOrderHeaderKey = eleOrderRoot.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    Document docInputForOrigSale =
        XMLUtil.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA);
    Element eleInputForOrigSale = docInputForOrigSale.getDocumentElement();
    addEndpointToElement(eleInputForOrigSale);
    eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
    if (logger.isDebugEnabled()) {
      logger.debug("Document input to API call is::" + XMLUtil.getXMLString(docInputForOrigSale));
    }
    env.setApiTemplate("getKOHLSSalesForPsa",
        XMLUtil.getDocument("<KOHLSSalesForPsa OrderHeaderKey='' OriginalSaleData=''/>"));
    Document docPSASaleOut =
        invokeService(env, KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInputForOrigSale);
    env.clearApiTemplate("getKOHLSSalesForPsa");
    String sOriginalSaleData =
        docPSASaleOut.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);
    Document docOriginalSale = XMLUtil.getDocument(sOriginalSaleData);
    NodeList nlKCOrderLine = orderInDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    for (int i = 0; i < nlKCOrderLine.getLength(); i++) {
      Element eleKCOrderLine = (Element) nlKCOrderLine.item(i);
      String sKCOLPrimeLineNo = eleKCOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
      Element eleKCOLExtn = XMLUtil.getChildElement(eleKCOrderLine, KohlsPOCConstant.E_EXTN);
      Element eleKCOLLineTax =
          (Element) eleKCOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
      Element eleKCOLLineCharges =
          XMLUtil.getChildElement(eleKCOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
      // Getting Line from orig order
      Element eleOrigOrderLine = (Element) XPathUtil.getNode(docOriginalSale,
          "/Order/OrderLines/OrderLine[@PrimeLineNo='" + sKCOLPrimeLineNo + "']");
      Element eleOrigOLExtn = XMLUtil.getChildElement(eleOrigOrderLine, KohlsPOCConstant.E_EXTN);
      Element eleOrigOLLineTax = null;
      if (eleOrigOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).getLength() > 0) {
        eleOrigOLLineTax =
            (Element) eleOrigOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
      }
      Element eleOrigOLLineCharges =
          XMLUtil.getChildElement(eleOrigOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES, true);
      
      Double dOldFeeTotal = 0.00D;
      NodeList nlOrigLineCharge = eleOrigOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
      for (int lc = 0; lc < nlOrigLineCharge.getLength(); lc++) {
        Element eleLineCharge = (Element) nlOrigLineCharge.item(lc);
        String strChargeCategory = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
        String strChargePerLine = eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE);
        if (KohlsPOCConstant.CONST_FEE.equals(strChargeCategory)) {
            dOldFeeTotal = dOldFeeTotal + Double.parseDouble(strChargePerLine);
            //Remove the old Fee line Charge 
            eleOrigOLLineCharges.removeChild(eleLineCharge);
            lc--;
        }
      }
      NodeList nlKCOLLineCharge = eleKCOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
      Double dNewFeeTotal = 0.00D;
      for (int lc = 0; lc < nlKCOLLineCharge.getLength(); lc++) {
          Element eleLineCharge = (Element) nlKCOLLineCharge.item(lc);
          String strChargeCategory = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
          String strChargePerLine = eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE);
          if (KohlsPOCConstant.CONST_FEE.equals(strChargeCategory)) {
            Element eleLineChargeExtn = XMLUtil.getChildElement(eleLineCharge, KohlsPOCConstant.E_EXTN);
            if (!YFCCommon.isVoid(eleLineChargeExtn)){
              String sOrigChargerPerLine = eleLineChargeExtn.getAttribute("ExtnOrigChgPerLine");
              double dUpdatedOrigChargePerLine = Double.parseDouble(sOrigChargerPerLine) - Double.parseDouble(strChargePerLine);
              eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE, df.format(dUpdatedOrigChargePerLine));
              dNewFeeTotal = dNewFeeTotal + dUpdatedOrigChargePerLine;
              XMLUtil.importElement(eleOrigOLLineCharges, eleLineCharge);
            }
          }
      }
      dOldLineTotalWithoutTax = dOldLineTotalWithoutTax
          + Double.parseDouble(eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE)) + dOldFeeTotal;
      logger.debug("dOldLineTotalWithoutTax is: " + String.valueOf(dOldLineTotalWithoutTax));
      dNewLineTotalWithoutTax = dNewLineTotalWithoutTax
          + (Double.parseDouble(eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE)) 
              - Double.parseDouble(eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE)) + dNewFeeTotal);
      logger.debug("dNewLineTotalWithoutTax is: " + String.valueOf(dNewLineTotalWithoutTax));
      
      Double dNewReturnPrice = Double.parseDouble(eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE)) 
          - Double.parseDouble(eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
      Double dNewNetPrice = Double.parseDouble(eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE)) 
          - Double.parseDouble(eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE));
      Double dNewTaxableAmt = Double.parseDouble(eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT)) 
          - Double.parseDouble(eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT));
      // Setting Extn attributes on orig order line
      eleOrigOLExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE, df.format(dNewReturnPrice));
      eleOrigOLExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, df.format(dNewNetPrice));
      eleOrigOLExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, df.format(dNewTaxableAmt));
      // Setting LineTax attributes on orig order line
      String sTax = eleKCOLLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
      if (!YFCCommon.isVoid(eleOrigOLLineTax)) {
        double dDeltaTax = Double.parseDouble(sTax);
        String sOldTax = eleOrigOLLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
        dOldTotalTax = dOldTotalTax +Double.parseDouble(sOldTax);
        Double dNewTax = 0.00;
        if(!YFCCommon.isVoid(sOldTax)) {
          dNewTax = Double.parseDouble(sOldTax) - dDeltaTax;
        }
        dNewTotalTax = dNewTotalTax + dNewTax;
        eleOrigOLLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, df.format(dNewTax));
        // eleOrigOLLineTax.setAttribute("LineTotalTax", sTax);
        eleOrigOLLineTax.setAttribute("InvoicedTax", df.format(dNewTax));
        Element eleOrigLineTaxExtn =
            XMLUtil.getChildElement(eleOrigOLLineTax, KohlsPOCConstant.E_EXTN);
        eleOrigLineTaxExtn.setAttribute("ExtnOrigTaxAmt", df.format(dNewTax));
      }
      logger.debug("dNewTotalTax is: " + String.valueOf(dNewTotalTax));
      // Setting CustomAttributes attributes on orig order line
      Double dNewLineTotal =
          Double.parseDouble(eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE))
              + Double.parseDouble(sTax);
      Element eleOrigOLCustAttrs =
          XMLUtil.getChildElement(eleOrigOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
      eleOrigOLCustAttrs.setAttribute("Text12",
          eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
      eleOrigOLCustAttrs.setAttribute("Text13", df.format(dNewLineTotal));
      eleOrigOLCustAttrs.setAttribute("Text14",
          eleOrigOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT));
      // Setting customAttributes on current order line
      /*
       * Element eleCurrentCustAttributes = XMLUtil.getChildElement(eleKCOrderLine,
       * KohlsPOCConstant.CUST_ATTRIBUTES, true);
       * 
       * eleCurrentCustAttributes.setAttribute("Text12",
       * eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
       * eleCurrentCustAttributes.setAttribute("Text13", df.format(dNewLineTotal));
       * eleCurrentCustAttributes.setAttribute("Text14",
       * eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT)) ;
       */
      // Setting LineCharges attributes on orig order line
      if (!YFCCommon.isVoid(eleKCOLLineCharges)) {
        Element eleKCOLLineCharge = (Element)((NodeList) XPathUtil.getNodeList(eleKCOrderLine, "/Order/OrderLines/OrderLine[@PrimeLineNo='"+sKCOLPrimeLineNo+"']/LineCharges/LineCharge[@ChargeCategory='KohlsCashUnearned']")).item(0);
        if (!YFCCommon.isVoid(eleKCOLLineCharge)) {
          XMLUtil.importElement(eleOrigOLLineCharges, eleKCOLLineCharge);
        }
      } else {
        Element eleKCOLLineCharges_temp =
            (Element) docOriginalSale.importNode(eleKCOLLineCharges, true);
        eleOrigOrderLine.appendChild(eleKCOLLineCharges_temp);
      }

      // Setting LinePriceInfo attributes on orig order line
      Element eleOrigOLLinePriceInfo =
          XMLUtil.getChildElement(eleOrigOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
      eleOrigOLLinePriceInfo.setAttribute("LineTotal", df.format(dNewLineTotal));
      eleOrigOLLinePriceInfo.setAttribute("InvoicedLineTotal", df.format(dNewLineTotal));
      // Setting ComputedPrice attributes on orig order line
      Element eleOrigOLComputedPrice = XMLUtil.getChildElement(eleOrigOrderLine, "ComputedPrice");
      eleOrigOLComputedPrice.setAttribute("LineTotal", df.format(dNewLineTotal));
      eleOrigOLComputedPrice.setAttribute("LineTotalWithoutTax",
          eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
      eleOrigOLComputedPrice.setAttribute("Tax", sTax);
      Element eleOrigOLLineOverallTotals =
          XMLUtil.getChildElement(eleOrigOrderLine, "LineOverallTotals");
      eleOrigOLLineOverallTotals.setAttribute("LineTotal", df.format(dNewLineTotal));
      eleOrigOLLineOverallTotals.setAttribute("LineTotalWithoutTax",
          eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
      eleOrigOLLineOverallTotals.setAttribute("ExtendedPrice",
          eleKCOLExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
      eleOrigOLLineOverallTotals.setAttribute("Tax", sTax);
      // Removing the LineChargs, Extn and LineTaxes from current
      // orderline
      /*
       * if (!YFCCommon.isVoid(eleKCOLLineCharges)) {
       * eleKCOrderLine.removeChild(eleKCOLLineCharges); } if (!YFCCommon
       * .isVoid(XMLUtil.getChildElement(eleKCOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES))) {
       * eleKCOrderLine .removeChild(XMLUtil.getChildElement(eleKCOrderLine,
       * KohlsPOCConstant.ELEM_LINE_TAXES)); } if (!YFCCommon.isVoid(eleKCOLExtn)) {
       * eleKCOrderLine.removeChild(eleKCOLExtn); }
       */
      if (!YFCCommon.isVoid(XMLUtil.getChildElement(eleKCOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES))) {
    	       eleKCOrderLine .removeChild(XMLUtil.getChildElement(eleKCOrderLine,KohlsPOCConstant.ELEM_LINE_TAXES));
      }
      if (!YFCCommon.isVoid(eleKCOLExtn)) {
          eleKCOrderLine.removeChild(eleKCOLExtn); 
      }
    }
    // Updating Order/OverallTotals on orig order
    Element eleOverallTotals =
        XMLUtil.getChildElement(docOriginalSale.getDocumentElement(), "OverallTotals");
    Double dOldGrandTotal = Double.parseDouble(eleOverallTotals.getAttribute("GrandTotal"));
    Double dOldLineSubTotal = Double.parseDouble(eleOverallTotals.getAttribute("LineSubTotal"));
    Double dOldGrandTax = Double.parseDouble(eleOverallTotals.getAttribute("GrandTax"));
    eleOverallTotals.setAttribute("GrandTotal", df.format(dOldGrandTotal
        - (dOldLineTotalWithoutTax + dOldTotalTax) + (dNewLineTotalWithoutTax + dNewTotalTax)));
    logger.debug("GrandTotal is: " + df.format(dOldGrandTotal
        - (dOldLineTotalWithoutTax + dOldTotalTax) + (dNewLineTotalWithoutTax + dNewTotalTax)));
    eleOverallTotals.setAttribute("LineSubTotal",
        df.format(dOldLineSubTotal - dOldLineTotalWithoutTax + dNewLineTotalWithoutTax));
    eleOverallTotals.setAttribute("GrandTax",
        df.format(dOldGrandTax - dOldTotalTax + dNewTotalTax));
    logger.debug("GrandTax is: " + df.format(dOldGrandTax - dOldTotalTax + dNewTotalTax));
    // Updating modified data in KOHLSSalesForPsa table
    String sOriginalSaleData_Modified = "";
    if ((dNewLineTotalWithoutTax + dNewTotalTax) > 0) {
      sOriginalSaleData_Modified = XMLUtil.getXMLString(docOriginalSale);
      eleInputForOrigSale.setAttribute("PSAData", sOriginalSaleData_Modified);
      if (logger.isDebugEnabled()) {
        logger.debug("PSAData after modification is: " + sOriginalSaleData_Modified);
      }
      // Calling recordExternalChargs Api for adding
      // Paymentmethod=KohlsCash on the order.
      String sKCRefundAmt = df.format(
          (dOldLineTotalWithoutTax + dOldTotalTax) - (dNewLineTotalWithoutTax + dNewTotalTax));
      logger.debug("Kohls Cash Unerned Refund Deduction is: " + sKCRefundAmt);
      if ((dOldLineTotalWithoutTax + dOldTotalTax) - (dNewLineTotalWithoutTax + dNewTotalTax) > 0) {
        callRecordExternalChargesAPI(env, orderInDoc, sKCRefundAmt);
      }
    } else {
      eleInputForOrigSale.setAttribute("PSAData", sOriginalSaleData);
    }
    env.setApiTemplate("changeKOHLSSalesForPsa",
        XMLUtil.getDocument("<KOHLSSalesForPsa OrderHeaderKey=''/>"));
    invokeService(env, "KohlsPoCManageOrigSaleData", docInputForOrigSale);
    env.clearApiTemplate("changeKOHLSSalesForPsa");
    // Calling changeOrder to update the promotion on the order.
    Element eleKCOrderRoot = orderInDoc.getDocumentElement();
    Element eleKCOrderLines =
        XMLUtil.getChildElement(eleKCOrderRoot, KohlsPOCConstant.ELEM_ORDER_LINES);
    if (!YFCCommon.isVoid(eleKCOrderLines)) {
      eleKCOrderRoot.removeChild(eleKCOrderLines);
    }
    addEndpointToElement(eleKCOrderRoot);
    eleKCOrderRoot.setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FLAG_Y);
    eleKCOrderRoot.removeAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
    Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
    if (logger.isDebugEnabled()) {
      logger.debug("Input xml to changeOrder is+ " + XMLUtil.getXMLString(orderInDoc));
    }
    env.setTxnObject("SkipManagePSIOrderCall", true);
    KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API, orderInDoc);
    env.setTxnObject("SkipManagePSIOrderCall", "");
    logger.endTimer("KohlsReturnsKCOptionSelected.processKCUnearnForPriceAdjustment");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param orderInDoc This method calls the recordExternalCharges api to stamp the KohlsCash
   *        payment method
   * @throws Exception
   */
  private void callRecordExternalChargesAPI(YFSEnvironment env, Document orderInDoc,
      String sRefundAmt) throws Exception {
    Element eleOrder = orderInDoc.getDocumentElement();
    String sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    Document docRecordExternalCharges =
        XMLUtil.createDocument(KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES);
    Element eleRecordExternalCharges = docRecordExternalCharges.getDocumentElement();
    eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
    addEndpointToElement(eleRecordExternalCharges);
    Element elePaymentMethod =
        XMLUtil.createChild(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_OPERATION, KohlsXMLLiterals.CONST_MANAGE);
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS,
        KohlsXMLLiterals.CONST_Y);
    String sPayRef1 = getPayRef1();
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, sPayRef1);
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2, KohlsPOCConstant.NO);
    elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY,
        eleOrder.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
    elePaymentMethod.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
        eleOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
    elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,
        eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
    elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TILL_ID,
        eleOrder.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
    elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
        eleOrder.getAttribute(KohlsPOCConstant.ATTR_STORE_ID));
    elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID,
        eleOrder.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID));
    elePaymentMethod.setAttribute("TotalRefundedAmount",
        elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, "KOHLS_CASH");
    Element elePaymentDetailsList =
        XMLUtil.createChild(elePaymentMethod, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    Element elePaymentDetails =
        XMLUtil.createChild(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE, KohlsXMLLiterals.CONST_CHARGE);
    elePaymentDetails.setAttribute("Status", "CHECKED");
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_IN_PERSON, KohlsXMLLiterals.CONST_Y);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_PROCESSED, KohlsXMLLiterals.CONST_Y);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, "-" + sRefundAmt);
    elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, "-" + sRefundAmt);
    if (logger.isDebugEnabled()) {
      logger.debug("Input xml to recordExternalCharges is+ "
          + XMLUtil.getXMLString(docRecordExternalCharges));
    }
    invokeAPI(env, KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES, docRecordExternalCharges);
  }

  /**
   * Create By mrjoshi *
   * 
   * @param orderInDoc
   */
  private void removePaymentMethods(Document orderInDoc) {
    logger.beginTimer("KohlsReturnsKCOptionSelected.removePaymentMethods");
    Element PaymentMethods =
        (Element) orderInDoc.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHODS).item(0);
    if (!YFCCommon.isVoid(PaymentMethods)) {
      orderInDoc.getDocumentElement().removeChild(PaymentMethods);
    }
    logger.endTimer("KohlsReturnsKCOptionSelected.removePaymentMethods");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param orderInDoc
   * @param sKCOptionSelected
   */
  private void removeOrderLines(Document orderInDoc, String sKCOptionSelected) {
    logger.beginTimer("KohlsReturnsKCOptionSelected.removeOrderLines");
    NodeList nlOrderLines = orderInDoc.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES);
    if (!YFCCommon.isVoid(nlOrderLines) && nlOrderLines.getLength() > 0) {
      for (int i = 0; i < nlOrderLines.getLength(); i++) {
        Element eleOrderLines = (Element) nlOrderLines.item(i);
        String sOrderLinesForKCOption = eleOrderLines.getAttribute("OrderLinesForKCOption");
        if (!YFCCommon.isVoid(sOrderLinesForKCOption)
            && !(sOrderLinesForKCOption.equalsIgnoreCase(sKCOptionSelected))) {
          orderInDoc.getDocumentElement().removeChild(eleOrderLines);
        }
      }
    }
    logger.endTimer("KohlsReturnsKCOptionSelected.removeOrderLines");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param finalEle
   * @throws ParserConfigurationException This method adds endpoint for Instore operations
   */
  public void addEndpointToElement(Element finalEle) throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCOptionSelected.addEndpointToElement");
    logger.debug("Before Adding edge ::" + ServerTypeHelper.amIOnEdgeServer());
    if (ServerTypeHelper.amIOnEdgeServer()) {
      Element eleAdditionalInfo =
          SCXmlUtil.createChild(finalEle, KohlsXMLLiterals.E_YFCADDITIONALINFO);
      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endpoint);
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Before Adding edge ::" + XMLUtil.getElementXMLString(finalEle));
    }
    logger.endTimer("KohlsReturnsKCOptionSelected.addEndpointToElement");
  }

  /**
   * 
   * This method creates a new String based on Current TimeStamp
   * 
   * @return
   */
  private String getPayRef1() {
    logger.beginTimer("KohlsPSARefund.getPayRef1");
    logger.debug("KohlsPSARefund.getPayRef1 -- Start");
    String strPayRef1 = null;
    try {
      strPayRef1 = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()).trim();
      logger.debug("KohlsPSARefund.getPayRef1 strPayRef1=" + strPayRef1);
    } catch (Exception e) {
      logger.error("KohlsPSARefund.getPayRef1 Exception=" + e.getMessage());
    }
    logger.debug("KohlsPSARefund.getPayRef1 -- End");
    logger.endTimer("KohlsPSARefund.getPayRef1");
    return strPayRef1;
  }

  /**
   * consolidates multiple Promotions and OrderLines to changeOrder API format.
   * 
   * @param inDoc
   * @return document
   * @throws Exception
   */
  private Document consolidatePromotionsAndOrder(Document inDoc) throws Exception {
    logger.beginTimer("KohlsReturnsKCOptionSelected.consolidatePromotionsAndOrder");
    String sExtnKCOptionSelectedFromPromo = "";
    String sOrderLinesForPromotion = "";
    String sOrderLinesForKCOption = "";
    Element eleOrder = inDoc.getDocumentElement();
    Document docOut = XMLUtil.getDocument("<Order/>");
    Element eleOrderOut = docOut.getDocumentElement();
    eleOrderOut.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.YES);
    eleOrderOut.setAttribute("OrderHeaderKey", eleOrder.getAttribute("OrderHeaderKey"));
    Element eleOrderlines = docOut.createElement("OrderLines");
    Element elePromotions = docOut.createElement("Promotions");
    eleOrderOut.appendChild(eleOrderlines);
    eleOrderOut.appendChild(elePromotions);
    NodeList nOrderLines = eleOrder.getElementsByTagName("OrderLines");
    NodeList nPromotions = eleOrder.getElementsByTagName("Promotions");
    for (int i = 0; i < nPromotions.getLength(); i++) {
      Element elePromotion = (Element) nPromotions.item(i);
      NodeList nPromotion = elePromotion.getElementsByTagName("Promotion");
      for (int j = 0; j < nPromotion.getLength(); j++) {
        Element eleTempPromotion = (Element) docOut.importNode((Element) nPromotion.item(j), true);
        elePromotions.appendChild(eleTempPromotion);
      }
    }
    for (int i = 0; i < nOrderLines.getLength(); i++) {
      Element eleInDocOrderLines = (Element) nOrderLines.item(i);
      sOrderLinesForPromotion = eleInDocOrderLines.getAttribute("OrderLinesForPromotion");
      sOrderLinesForKCOption = eleInDocOrderLines.getAttribute("OrderLinesForKCOption");
      sExtnKCOptionSelectedFromPromo = KohlsXPathUtil.getString(inDoc,
          "Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_UNEARNED' or @PromotionType='LOYALTY_KC_UNEARNED']/Extn[@ExtnCouponSourceCode='"
              + sOrderLinesForPromotion + "']/@ExtnKCOptionSelected");
      NodeList nInDocOrderLine = eleInDocOrderLines.getElementsByTagName("OrderLine");
      if (!YFCCommon.isVoid(sOrderLinesForKCOption)) {
        if (sOrderLinesForKCOption.equalsIgnoreCase(sExtnKCOptionSelectedFromPromo)) {
          for (int j = 0; j < nInDocOrderLine.getLength(); j++) {
            Element eleTempOrderLine =
                (Element) docOut.importNode((Element) nInDocOrderLine.item(j), true);
            eleOrderlines.appendChild(eleTempOrderLine);
          }
        }
      }
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Consolidated XML: " + XMLUtil.getXMLString(docOut));
    }
    logger.endTimer("KohlsReturnsKCOptionSelected.consolidatePromotionsAndOrder");
    return docOut;
  }
}
