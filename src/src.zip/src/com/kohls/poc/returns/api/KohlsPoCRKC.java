package com.kohls.poc.returns.api;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.util.KohlcPoCWriteToFileUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCRKC {

  private Properties props;
  private static YFCLogCategory logger;
  // Changes for sending Correct Organization to POS Rules - Start
  String strOrgCode = "KOHLS-RETAIL";
  // Changes for sending Correct Organization to POS Rules - End
  public static HashMap<String, String> mapRKCEvent = new HashMap<String, String>();

  static {
    logger = YFCLogCategory.instance(KohlsPoCRKC.class.getName());
  }

  private Document prepareDocumentRKC(Document inXML) throws ParserConfigurationException {
    logger.beginTimer("KohlsPoCRKC.prepareDocumentRKC");

    if (YFCLogUtil.isDebugEnabled()) {
      logger.debug("prepareDocumentRKC Input XML : " + SCXmlUtil.getString(inXML));
    }
    Element inxmlEle = inXML.getDocumentElement();

    // String scannedRecptNo =
    // inxmlEle.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
    String soperatorId = inxmlEle.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID);

    DateFormat dateFormat = new SimpleDateFormat(KohlsPOCConstant.INV_DATE_FORMAT);
    DateFormat dateFormat1 = new SimpleDateFormat(KohlsPOCConstant.HD_DATE_FORMAT);
    Date date = new Date();

    String sCurrentStore = inxmlEle.getAttribute(KohlsXMLLiterals.A_CURRENT_STORE);// "StoreNumber"
    String sCurrentTerminalNo = inxmlEle.getAttribute(KohlsXMLLiterals.A_CURRENT_TERMINAL); // TerminalID
    //Changes for CAPE-4061 start
    if(YFCCommon.isVoid(sCurrentTerminalNo)){
      sCurrentTerminalNo = "00";
    }
    //Changes for CAPE-4061 end
    String sTransactionNo = inxmlEle.getAttribute(KohlsXMLLiterals.TRANSACTION_NBR);// TransactionNbr
    if (YFCCommon.isVoid(sTransactionNo)) {
      sTransactionNo = "0000";
    }
    // String sTransTimeStamp = inxmlEle.getAttribute(KohlsXMLLiterals.A_TRANS_TIME_STAMP);//
    // TransactionTmst
    String sTransTimeStamp = dateFormat.format(date);// TransactionTmst
    // For gift receipt

    Document docGetActiveRKCEvent = XMLUtil.createDocument(KohlsXMLLiterals.A_GET_ACTIVE_RKC_EVENT);
    Element elegetActiveRKCEvent = docGetActiveRKCEvent.getDocumentElement();

    Element eleHeader = XMLUtil.createChild(elegetActiveRKCEvent, KohlsXMLLiterals.E_HEADER);

    Element storeNoEle = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_STORE);
    XMLUtil.setNodeValue(storeNoEle, sCurrentStore);
    Element eleCurTerminalID = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_TERMINAL);
    XMLUtil.setNodeValue(eleCurTerminalID, sCurrentTerminalNo);
    Element eleTxnNbr = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_TRANSACTION_NBR);
    XMLUtil.setNodeValue(eleTxnNbr, sTransactionNo);
    Element eleBusinessDate = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_BUSINESS_DATE);
    XMLUtil.setNodeValue(eleBusinessDate, dateFormat1.format(date));
    Element eleTransStartDate = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_TRANS_START_DATE);
    XMLUtil.setNodeValue(eleTransStartDate, sTransTimeStamp);

    Element eleOperatorId = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_ASSOCIATE_ID);
    XMLUtil.setNodeValue(eleOperatorId, soperatorId);
    Element eleTrainingModeInd = XMLUtil.createChild(eleHeader, KohlsXMLLiterals.A_TRAINING_MODE);
    XMLUtil.setNodeValue(eleTrainingModeInd, KohlsConstant.FALSE);
    Element eleDATA = XMLUtil.createChild(elegetActiveRKCEvent, KohlsXMLLiterals.A_DATA);

    if (YFCLogUtil.isDebugEnabled() && (!(YFCCommon.isVoid(docGetActiveRKCEvent)))) {
      logger.debug("prepareDocumentRKC Output XML : " + SCXmlUtil.getString(docGetActiveRKCEvent));
    }
    logger.endTimer("KohlsPoCRKC.prepareDocumentRKC");
    return docGetActiveRKCEvent;

  }

  public Document invokeRKCWebservice(YFSEnvironment env, Document inDoc, String sLogToFile,
      String sFilePath) {
    logger.beginTimer("KohlsPoCRKC.invokeRKCWebservice");
    if (YFCLogUtil.isDebugEnabled()) {
      logger.debug("invokeRKCWebservice Input XML : " + SCXmlUtil.getString(inDoc));
    }
    Document docOutActiveRKCEventRespose = null;
    String sFileName = "";
    String sContentToWrite = "";
    boolean bAppend = true;
    KohlcPoCWriteToFileUtil fileUtil = null;
    Element inxmlEle = inDoc.getDocumentElement();


    String sCurrentStore = inxmlEle.getAttribute(KohlsXMLLiterals.A_CURRENT_STORE);// "StoreNumber"
    String sCurrentTerminalNo = inxmlEle.getAttribute(KohlsXMLLiterals.A_CURRENT_TERMINAL); // TerminalID
    String sTransactionNo = inxmlEle.getAttribute(KohlsXMLLiterals.TRANSACTION_NBR);// TransactionNbr
    try {
      Document docActiveRKCEvents = prepareDocumentRKC(inDoc);
      if (YFCLogUtil.isDebugEnabled() || true) {
        logger.debug("invokeRKCWebservice INput XML : " + SCXmlUtil.getString(inDoc));

        logger.debug("sLogToFile INput XML : " + sLogToFile + "sFilePath*************" + sFilePath);
      }



      if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
        if (!sFilePath.endsWith("/")) {
          sFilePath = sFilePath + "/";
        }
        sFileName = sCurrentStore + "-" + sCurrentTerminalNo + "-" + sTransactionNo + ".log";
        logger.debug("########## Logging RKC request to file: " + (sFilePath + sFileName));
        sContentToWrite = YFCDateUtils.getCurrentDate(true) + ": Request to RKC service is: \n"
            + XMLUtil.getXMLString(docActiveRKCEvents) + "\n";
        fileUtil = new KohlcPoCWriteToFileUtil(sFilePath + sFileName, bAppend);
        fileUtil.writeDataToFile(sContentToWrite);
      }
      
      KohlsCashManager kcm = new KohlsCashManager(env);
      
      boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(sCurrentStore);
      
      if(logger.isDebugEnabled())
			logger.debug("######Rule value for OMS KC in KohlsPoCRKC.invokeRKCWebservice: " + omsKCEnabled);
      
      if(omsKCEnabled) {
    	  kcm.loadEvents(sCurrentStore);
    	  //Use KCM
    	  docOutActiveRKCEventRespose = kcm.getActiveRKCEvents(docActiveRKCEvents);
    	  
    	  //throw exception if the response came back null
    	  if(docOutActiveRKCEventRespose == null) {
    		  throw new YFCException(KohlsConstant.EXTN_OTHER);
    	  }
      }
      else {
    	  //Use KCS
    	  docOutActiveRKCEventRespose = KohlsCommonUtil.invokeService(env,
              KohlsConstant.KOHLS_CASH_ACTIVE_RKC_WEB_SERVICE, docActiveRKCEvents);
      }

      if (YFCLogUtil.isDebugEnabled() || true) {
        if (!YFCCommon.isVoid(docOutActiveRKCEventRespose)) {
          logger.debug("invokeRKCWebservice Output XML : "
              + SCXmlUtil.getString(docOutActiveRKCEventRespose));
        }

        logger.debug(
            "Output of KohlsRKCEVENT call::" + SCXmlUtil.getString(docOutActiveRKCEventRespose));
        if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
          logger.debug("Logging KC response to file");
          sContentToWrite = YFCDateUtils.getCurrentDate(true) + ": Response from KC service is: \n"
              + XMLUtil.getXMLString(docOutActiveRKCEventRespose) + "\n";
          fileUtil.writeDataToFile(sContentToWrite);
          fileUtil.closeFile();
        }

      }

    } catch (Exception e) {
      logger.endTimer("KohlsPoCRKC.invokeRKCWebservice");
      if (e.getCause() instanceof java.net.ConnectException) {
        throw new YFCException(KohlsConstant.EXTN_CONNECT);
      } else if (e.getCause() instanceof java.io.IOException) {
        throw new YFCException(KohlsConstant.EXTN_IO);
      } else if (e.getCause() instanceof javax.xml.soap.SOAPException
          || e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
        throw new YFCException(KohlsConstant.SOAP_EXCEPTION);
      } else if (e.getCause() instanceof javax.xml.ws.WebServiceException) {
        throw new YFCException(KohlsConstant.WEB_SERVICE_EXCEPTION);
      } else {
        throw new YFCException(KohlsConstant.EXTN_OTHER);
      }

    }


    logger.endTimer("KohlsPoCRKC.invokeRKCWebservice");
    return docOutActiveRKCEventRespose;
  }

  public int getRKCEventCount(String sRKCEventID) throws Exception {

    logger.beginTimer("KohlsPoCRKC.getRKCEventCount");

    if (!YFCCommon.isVoid(sRKCEventID)) {
      if (YFCLogUtil.isDebugEnabled()) {
        logger.debug("****************in if condition ********************* ");
      }
      String[] sEventCount = sRKCEventID.split(",");
      logger.endTimer("KohlsPoCRKC.getRKCEventCount");
      return sEventCount.length;

    } else {
      logger.endTimer("KohlsPoCRKC.getRKCEventCount");
      return 0;
    }

  }

  public String getRKCEventID(String sEventID) {


    logger.beginTimer("KohlsPoCRKC.getRKCEventID");
    String sConactRKCEventID = "";

    if (!YFCCommon.isVoid(sEventID)) {
      String sRKCEventID[] = sEventID.split(",");
      if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(sEventID)) {
        logger.debug("sEventID : " + sEventID);
      }
      for (int l = 0; l < sRKCEventID.length; l++) {

    	  if(( sRKCEventID[l].indexOf("_")!=-1))
    	  {
        sConactRKCEventID =
            sConactRKCEventID.concat(sRKCEventID[l].substring(0, sRKCEventID[l].indexOf("_")));
    	  }
    	  else{
    		  sConactRKCEventID=sConactRKCEventID.concat(sRKCEventID[l]);
    	  }

        if (l != (sRKCEventID.length - 1)) {

          sConactRKCEventID = sConactRKCEventID.concat(",");

          if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(sConactRKCEventID)) {
            logger.debug("sConactRKCEventID : " + sConactRKCEventID);
          }
        }

      }
    }
    logger.endTimer("KohlsPoCRKC.getRKCEventID");

    return sConactRKCEventID;
  }

  public String getEventIDAndExpiryDate(Document docOutActiveEventResponse, YFSEnvironment env,
      String sOrganizationCode) throws Exception {

    logger.beginTimer("KohlsPoCRKC.getEventIDAndExpiryDate");

    Element eleRKCEventList =
        (Element) KohlsXPathUtil.getNode(docOutActiveEventResponse, "//Data/RKCEventList");
    if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(eleRKCEventList)) {
      logger.debug("eleRKCEventList : " + SCXmlUtil.getString(eleRKCEventList));
    }

    String strEventId = "";
    String sTempEventIdList = "";
    if (eleRKCEventList != null) {

      NodeList ndlRKCEvent = eleRKCEventList.getElementsByTagName("RKCEvent");
      for (int i = 0; i < ndlRKCEvent.getLength(); i++) {

        Element eleRKCEvent = (Element) ndlRKCEvent.item(i);
        if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(eleRKCEvent)) {
          logger.debug("eleRKCEvent : " + SCXmlUtil.getString(eleRKCEvent));
        }

        if (!YFCCommon
            .isVoid(eleRKCEvent.getElementsByTagName("EventID").item(0).getTextContent())) {
          int expiryDays = Integer.parseInt(
              eleRKCEvent.getElementsByTagName("ExpirationDays").item(0).getTextContent());
          SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

          Calendar cal = Calendar.getInstance();
          cal.add(Calendar.DATE, expiryDays);
          strEventId = strEventId
              .concat(eleRKCEvent.getElementsByTagName("EventID").item(0).getTextContent());
          sTempEventIdList = sTempEventIdList
              .concat(eleRKCEvent.getElementsByTagName("EventID").item(0).getTextContent() + "_"
                  + df.format(cal.getTime()).toString());

          if (i != (ndlRKCEvent.getLength() - 1)) {

            strEventId = strEventId.concat(",");
            sTempEventIdList = sTempEventIdList.concat(",");
            // sEventList=
            if (YFCLogUtil.isDebugEnabled()) {
              logger.debug("strEventId : " + strEventId);
            }
          }

        }

      }
      updateRKCEvents(sTempEventIdList, env, sOrganizationCode);


    }
    logger.endTimer("KohlsPoCRKC.getEventIDAndExpiryDate");
    return strEventId;
  }

  public String getExpiryDate(Document docOutActiveEventResponse) throws Exception {

    logger.beginTimer("KohlsPoCRKC.getExpiryDate");
    String strEventId = "";
    int iRKCcount = 0;
    Element eleRKCEventList =
        (Element) KohlsXPathUtil.getNode(docOutActiveEventResponse, "//Data/RKCEventList");
    if (YFCLogUtil.isDebugEnabled()) {
      logger.debug("eleRKCEventList : " + SCXmlUtil.getString(eleRKCEventList));
    }
    if (!YFCCommon.isVoid(eleRKCEventList)) {

      NodeList ndlRKCEvent = eleRKCEventList.getElementsByTagName("RKCEvent");
      iRKCcount = ndlRKCEvent.getLength();
      for (int i = 0; i < iRKCcount; i++) {
        int expiryDays = 0;

        Element eleRKCEvent = (Element) ndlRKCEvent.item(i);
        if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(eleRKCEvent)) {
          logger.debug("eleRKCEvent : " + SCXmlUtil.getString(eleRKCEvent));
        }
        Element eleExpirationDays =
            (Element) eleRKCEvent.getElementsByTagName("ExpirationDays").item(0);

        if (!YFCCommon.isVoid(eleExpirationDays)) {
          expiryDays = Integer.parseInt(eleExpirationDays.getTextContent());
        }
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, expiryDays);
        String sDate = df.format(cal.getTime()).toString();
        logger.debug("sDate : " + sDate);
        Element eleEventID = (Element) eleRKCEvent.getElementsByTagName("EventID").item(0);
        if (!YFCCommon.isVoid(eleEventID)) {
          strEventId = strEventId.concat(eleEventID.getTextContent());
          strEventId = strEventId.concat("_" + sDate);
          if (i != iRKCcount - 1) {
            strEventId = strEventId.concat(",");
          }
        }

      }

      logger.endTimer("END:KohlsPoCRKC.getExpiryDate");

    }
    logger.debug("final strEventId for UI: " + strEventId);
    return strEventId;
  }

  public String checkRKC(YFSEnvironment env) throws Exception {

    logger.beginTimer("KohlsPoCRKC.checkRKC");

    Document docRuleListForPOSOutput = null;

    // Prepare Input to call getCommomCodeList API
    Document docInput = YFCDocument.createDocument("Rule").getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute("OrganizationCode", "KOHLS-RETAIL");
    eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, "ENABLE_RETURN_KOHLS_CASH");

    docRuleListForPOSOutput =
        KohlsCommonUtil.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
    if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(docRuleListForPOSOutput)) {
      logger.debug("Rule out put xml : " + SCXmlUtil.getString(docRuleListForPOSOutput));
    }
    if (!YFCCommon.isVoid(docRuleListForPOSOutput)) {
      Element eleRule = (Element) docRuleListForPOSOutput.getDocumentElement()
          .getElementsByTagName("Rule").item(0);
      if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(eleRule)) {
        logger.debug("Rule  : " + SCXmlUtil.getString(eleRule));
      }
      if (!YFCCommon.isVoid(eleRule)) {
        logger.endTimer("checkRKC end");
        if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(eleRule)) {

          logger.debug("Rule Value : " + eleRule.getAttribute("RuleValue"));
        }
        return eleRule.getAttribute("RuleValue");
      } else {
        if (YFCLogUtil.isDebugEnabled()) {
          logger.debug("in else");
        }
        logger.endTimer("KohlsPoCRKC.checkRKC");

        return "";
      }
    }
    logger.endTimer("KohlsPoCRKC.checkRKC");

    return "";
  }

  private Document prepareResponse() throws ParserConfigurationException {
    logger.beginTimer("KohlsPoCRKC.prepareResponse");
    Document retSvcReqDoc = XMLUtil.createDocument("GetActiveRKCEventsResponseMsg");
    Element retSvcReqDocEle = retSvcReqDoc.getDocumentElement();

    Element headerElement = XMLUtil.createChild(retSvcReqDocEle, "Header");

    Element Store = XMLUtil.createChild(headerElement, "Store");
    XMLUtil.setNodeValue(Store, "9954");

    Element TerminalID = XMLUtil.createChild(headerElement, "Terminal");
    XMLUtil.setNodeValue(TerminalID, "19");

    Element BusinessDate = XMLUtil.createChild(headerElement, "BusinessDate");
    XMLUtil.setNodeValue(BusinessDate, "2014-12-12");

    Element TranscationNo = XMLUtil.createChild(headerElement, "TranscationNumber");
    XMLUtil.setNodeValue(TranscationNo, "12");

    Element associateID = XMLUtil.createChild(headerElement, "AssociateID");
    XMLUtil.setNodeValue(associateID, "1234567");

    Element TransStartDateTime = XMLUtil.createChild(headerElement, "TransStartDateTime");
    XMLUtil.setNodeValue(TransStartDateTime, "2016-06-129:78:898");
    Element trainingModeIndEle = XMLUtil.createChild(headerElement, "TrainingMode");
    XMLUtil.setNodeValue(trainingModeIndEle, "false");

    Element Data = XMLUtil.createChild(retSvcReqDocEle, "Data");
    Element eleRKCEventList = XMLUtil.createChild(Data, "RKCEventList");

    Element eleRKCEvent = XMLUtil.createChild(eleRKCEventList, "RKCEvent");
    Element eleEventID = XMLUtil.createChild(eleRKCEvent, "EventID");
    XMLUtil.setNodeValue(eleEventID, "1234567");
    Element eleEventName = XMLUtil.createChild(eleRKCEvent, "EventName");
    XMLUtil.setNodeValue(eleEventName, "Kohls Cash 1234567");

    Element eleActivationStartDate = XMLUtil.createChild(eleRKCEvent, "ActivationStartDate");
    XMLUtil.setNodeValue(eleActivationStartDate, "2016-10-10");

    Element eleActivationEndDatee = XMLUtil.createChild(eleRKCEvent, "ActivationEndDate");
    XMLUtil.setNodeValue(eleActivationEndDatee, "2016-10-20");

    Element eleReceiptMessageLine1 = XMLUtil.createChild(eleRKCEvent, "ReceiptMessageLine1");
    XMLUtil.setNodeValue(eleReceiptMessageLine1, "Text 1");

    Element eleReceiptMessageLine2 = XMLUtil.createChild(eleRKCEvent, "ReceiptMessageLine2");
    XMLUtil.setNodeValue(eleReceiptMessageLine2, "Text3");

    Element eleExpirationDays = XMLUtil.createChild(eleRKCEvent, "ExpirationDays");
    XMLUtil.setNodeValue(eleExpirationDays, "30");

    logger.debug(XMLUtil.getXMLString(retSvcReqDoc));
    logger.endTimer("KohlsPoCRKC.prepareResponse");
    return retSvcReqDoc;
  }

  public String getPropertyValue(String property) {
    logger.beginTimer("KohlsPoCRKC.getPropertyValue");
    String propValue;
    propValue = YFSSystem.getProperty(property);
    // Manoj 10/22: updated to use configured property if
    // customer_overrides.properties does not return any value
    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    logger.endTimer("KohlsPoCRKC.getPropertyValue");
    return propValue;

  }

  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */

  public void setProperties(Properties prop) throws Exception {
    logger.beginTimer("KohlsPoCRKC.setProperties");
    this.props = prop;
    logger.debug("In the set properties method");
    logger.endTimer("KohlsPoCRKC.setProperties");
  }

  public void updateRKCEvents(String sEventID, YFSEnvironment env, String sOrganizationCode)
      throws Exception {
    logger.beginTimer("KohlsPoCRKC.updateRKCEvents");

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String curDate = sdf.format(new Date());
    
    mapRKCEvent.put("RKC_ACTIVE_EVENT", sEventID);
    mapRKCEvent.put("RKC_EVENT_UPDATE_TIME", curDate);
    
    /*Document docInput = YFCDocument.createDocument("RuleList").getDocument();

    Element eleInput = docInput.getDocumentElement();

    Element eleRule = SCXmlUtil.createChild(eleInput, "Rule");
    eleRule.setAttribute("OrganizationCode", sOrganizationCode);
    eleRule.setAttribute("Action", "MODIFY");
    eleRule.setAttribute(KohlsXMLLiterals.A_RULE_ID, "RKC_ACTIVE_EVENT");

    eleRule.setAttribute(KohlsXMLLiterals.A_RULE_VALUE, sEventID);

    logger.debug("the rule value is " + SCXmlUtil.getString(docInput));
    Document docRuleForPOSOutput = KohlsCommonUtil.invokeAPI(env, "manageRuleForPOS", docInput);*/
    logger.endTimer("KohlsPoCRKC.updateRKCEvents");

  }

  public boolean checkUpdateRuleValue(String sEventID, YFSEnvironment env, String sOrganizationCode,
      Document docOutRule) throws Exception {

    logger.beginTimer("KohlsPoCRKC.checkUpdateRuleValue");

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    Date curDate = sdf.parse(sdf.format(new Date()));
    
   // Element eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);

    //String Temp = eleRule.getAttribute("Modifyts");
    
    String Temp = mapRKCEvent.get("RKC_EVENT_UPDATE_TIME");
    
    if (!YFCCommon.isVoid(Temp)) {
      Date dExpiryDate = sdf.parse(Temp);

      if (curDate.compareTo(dExpiryDate) > 0) {
        updateRKCEvents("", env, sOrganizationCode);
        logger.endTimer("KohlsPoCRKC.checkUpdateRuleValue");
        return true;
      }
    }
    logger.endTimer("KohlsPoCRKC.checkUpdateRuleValue");

    return false;
  }


  public Document getRuleList(YFSEnvironment env, String strRuleID,String sOrgCode) throws Exception {
    logger.beginTimer("KohlsPoCRKC.getRuleValue");
    Document docOutRule = null;
    String sOutTemplate = "<RuleList>" + "<Rule OrganizationCode='' RuleID='' RuleKey='' "
        + "RuleValue='' TerminalType='' Modifyts=''>    </Rule>" + "</RuleList>";
    Document docInput = YFCDocument.createDocument("Rule").getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute("OrganizationCode", sOrgCode);
    eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, strRuleID);
    Document docOutputTemplate = XMLUtil.getDocument(sOutTemplate);
    docOutRule = KOHLSBaseApi.invokeAPI(env, docOutputTemplate,
        KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docInput);
    if (!YFCCommon.isVoid(docOutRule)) {
      Element eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);

      if (!YFCCommon.isVoid(eleRule)) {
        logger.endTimer("KohlsPoCRKC.getRuleValue");
        return docOutRule;
      }
    }
    logger.endTimer("KohlsPoCRKC.getRuleValue");
    return docOutRule;
  }

}
