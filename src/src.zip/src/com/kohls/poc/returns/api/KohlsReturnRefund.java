package com.kohls.poc.returns.api;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.api.KohlsPocInvoiceToSalesHubAPI;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCPinPadOperations;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author POC Returns Team
 * 
 *         Sample Input XML
 *         <Order OrderHeaderKey="2016030919240426551" BusinessDay="2016-06-29" OperatorID="2104795"
 *         TerminalID="41" TillID="1"> <PaymentMethods> <PaymentMethod PaymentType="KOHLS_CASH"
 *         Amount="20" /> <PaymentMethod PaymentType="CASH" Amount="30"/> <PaymentMethod PaymentType
 *         ="CREDIT_CARD" CreditCardType="VISA" CreditCardNo="1245260120" Amount="20"/>
 *         <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="MASTERCARD" CreditCardNo=
 *         "8464196593" Amount="5"/> <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType=
 *         "DISCOVER" CreditCardNo= "7849216326" Amount="10"/> <PaymentMethod PaymentType=
 *         "CREDIT_CARD" CreditCardType="AMEX" CreditCardNo="4145936225" Amount="5"/> <PaymentMethod
 *         PaymentType="KOHLS_CHARGE_CARD" Amount="15"/> <PaymentMethod PaymentType="KMC" Amount=
 *         "10" ConvertedFromCash="N" ConvertedFromCC="Y" ConvertedFromKohlsCharge="N"
 *         CreditCardType="VISA" SVCNo="" entryMethod="" storeNumber= ""/> <PaymentMethod Amount=
 *         "10" PaymentType="CORPORATE_REFUND" FirstName="" LastName="" StreetAddress="" City=""
 *         State="" ZipCode="" DriversLicense="" PhoneNo="" Reason="" EMailID="" LoyalityCardNo=""/>
 *         </PaymentMethods> </Order>
 *
 */
/**************************************************************************
 * File : KohlsReturnRefund.java Author : POC Returns Team
 ***************************************************************************** 
 * This Class is handles All Tender Refunds with respect to Returns and Price Adjustment scenarios
 ***************************************************************************** 
 * 
 *****************************************************************************/

public class KohlsReturnRefund {

  private static YFCLogCategory logger;
  private String strOrdHeadKey = KohlsPOCConstant.BLANK;
  private String strKMCEntryMethod = KohlsPOCConstant.BLANK;
  private Document docGetPayOutClone = null;
  private Document docInXMLClone = null;
  private Document docOutputClone = null;
  private String strShippingItemID = "";
  private List<String> aShippingSkuArray = new ArrayList<String>();;

  private List<String> liPayKey = new ArrayList<String>();
  private boolean bIsCorpRefund = false;
  private boolean bIsKMCError = false;
  private String sOrderNo = "";
  private boolean bIsDebugEnabled = YFCLogUtil.isDebugEnabled();
  // MAD-287 Start
  private String endpoint = null;
  // MAD-287 End
  private Map<String, String> mPSAId = new HashMap<String, String>();
  private double timeTaken = 0.00;
  String sExtnPOCFeature = null;

  static {
    logger = YFCLogCategory.instance(KohlsReturnRefund.class.getName());
  }

  /**
   * This Method is called by Gravity as a parameter to the OMS Service KohlsReturnRefund.
   * 
   * Acts as a major and sole Driver for PSA Tender Refund Scenarios
   * 
   * inXML: Input From Gravity UI Trigger Point: On Confirmation of Tender Prompt Screen
   * 
   * @param env
   * @param inXML
   * @throws Exception
   */
  public Document setFinalPSARefundTypes(YFSEnvironment env, Document inXML) throws Exception {
    // long lStartTime=System.nanoTime();
    logger.beginTimer("KohlsReturnRefund.setFinalPSARefundTypes");
    if (bIsDebugEnabled) {
      logger.debug(
          "KohlsReturnRefund.setFinalPSARefundTypes InputDocument:" + XMLUtil.getXMLString(inXML));
    }
    Element eleOrder = inXML.getDocumentElement();
    eleOrder.setAttribute(KohlsPOCConstant.A_OVERRIDE, "Y");
    Element eleExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
    sExtnPOCFeature = eleExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
    Document docOutput = null;
    Document docFinalProcessOrderPayInput = null;
    boolean isReturn = false;
    boolean bIsRKCPromotionProcessed = false;
    try {

      // Save the OrderHeaderkey as a global variable to be used as a
      // parameter for rest of the functions
      strOrdHeadKey = getOHKey(inXML);
      if (KohlsPOCConstant.RECEIPTED_RET.equalsIgnoreCase(sExtnPOCFeature)) {
        Element elePaymentMethodsTemp =
            (Element) inXML.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHODS).item(0);
        NodeList ndlPaymentMethod = elePaymentMethodsTemp.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
        for (int i = 0; i < ndlPaymentMethod.getLength(); i++) {

          Element elePaymentMethod = (Element) ndlPaymentMethod.item(i);
          if (!YFCCommon.isVoid(elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE))) {
            if ((elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE).equalsIgnoreCase("KMC")
                && elePaymentMethod.getAttribute("ConvertAllToKMC").equalsIgnoreCase("Y"))
                || (elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE)
                    .equalsIgnoreCase("CORPORATE_REFUND"))) {
              KohlsPoCSysRepublic pocsysRepublic = new KohlsPoCSysRepublic();
              Document docOutGetOrderDetails = pocsysRepublic.getOrderDetails(env, inXML);
              if (bIsDebugEnabled) {
                logger.debug("KohlsReturnRefund.setFinalPSARefundTypes outDocument for :"
                    + XMLUtil.getXMLString(docOutGetOrderDetails));
              }
              HashMap<String, String> mapOTR = pocsysRepublic.getOTRKey(docOutGetOrderDetails);
              String strShippingItemID = pocsysRepublic.getRuleValue(env, "SHIPPING_CHARGE_ITEMS");
              if (!YFCCommon.isVoid(strShippingItemID)) {
                String[] sTempShippingItemID = strShippingItemID.split(",");
                for (int j = 0; j < sTempShippingItemID.length; j++) {
                  aShippingSkuArray.add(sTempShippingItemID[j]);
                }
              }
              Document outRefundAmountDoc = pocsysRepublic.getRefundAmount(mapOTR,
                  docOutGetOrderDetails, inXML, env, "Y", sExtnPOCFeature);
              if (bIsDebugEnabled) {
                logger
                    .debug("KohlsReturnRefund.setFinalPSARefundTypes out document of refund amount:"
                        + XMLUtil.getXMLString(outRefundAmountDoc));
              }
              inXML = getSplitupDetailsForKMCAndCorpRefund(outRefundAmountDoc,
                  pocsysRepublic.mapOrderRefundAmount);
              if (bIsDebugEnabled) {
                logger.debug("Final output xml is " + XMLUtil.getXMLString(inXML));
              }

              // splitRefundAmount(inSplitDoc, dRefundAmount,
              // inDoc)
            }
          }
        }
      }
      if (!YFCCommon.isStringVoid(strOrdHeadKey)) {
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setFinalPSARefundTypes strOrdHeadKey=" + strOrdHeadKey);
        }
        
        // Input to call PSAGetOrderList OMS Service is prepared
        Document docPSAGetOrderInput = inputToPSAGetOrderList(strOrdHeadKey, sExtnPOCFeature);
        // PSAGetOrderList OMS Service is called
        docOutput = callPSAGetOrderListAPI(env, docPSAGetOrderInput);

        // Added for POC Returns - Begin
        // MJ 03/24- Added for CAPE-2046 begin
        sortPaymentMethod(inXML);
        // MJ 03/24- Added for CAPE-2046 End
        
      //Remove Duplicate promotions (PST-7044)
        NodeList nlGetOrderListPromtion = XPathUtil.getNodeList(docOutput, "//Order/Promotions/Promotion");
        if(!YFCCommon.isVoid(nlGetOrderListPromtion) && nlGetOrderListPromtion.getLength()>0) {
          for (int i=0; i<nlGetOrderListPromtion.getLength(); i++) {
            Element eleGetOrderListPromotion = (Element)nlGetOrderListPromtion.item(i);
            String sGetOrderListPromotionType = eleGetOrderListPromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
            if(KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sGetOrderListPromotionType)) {
              String sGetOrderListPromotionID = eleGetOrderListPromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
              Element eleInputPromotion = (Element)XPathUtil.getNode(inXML, "//Order/Promotions/Promotion[@PromotionId='"+sGetOrderListPromotionID+"']");
              if(!YFCCommon.isVoid(eleInputPromotion)) {
                XMLUtil.removeChild((Element) eleInputPromotion.getParentNode(), eleInputPromotion);
              }
            }
          }
        }

        boolean ifChangeOrderRequired = false;

        isReturn = true;
        // CAPE 1445 - Adding CASH Payment method if no payment
        // method exists
        // for complete Returns with RKC.
        NodeList nlPaymentMethod = inXML.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
        if (!YFCCommon.isVoid(nlPaymentMethod) && nlPaymentMethod.getLength() == 0) {
          Element elePaymentMethods =
              XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PAYMENT_METHODS, true);
          Element elePaymentMethod =
              XMLUtil.createChild(elePaymentMethods, KohlsPOCConstant.E_PAYMENT_METHOD);
          elePaymentMethod.setAttribute(KohlsPOCConstant.A_AMOUNT, "0.00");
          elePaymentMethod.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY,
              eleOrder.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
          elePaymentMethod.setAttribute(KohlsPOCConstant.A_PAYMENT_TYPE, KohlsPOCConstant.CASH);
          elePaymentMethod.setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
              eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
          elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TILL_ID,
              eleOrder.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
          elePaymentMethod.setAttribute(KohlsPOCConstant.A_STORE_ID,
              eleOrder.getAttribute(KohlsPOCConstant.A_STORE_ID));
        }
        // Checking if any KC Is unearned
        NodeList nlPromotion = inXML.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
        if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
          for (int i = 0; i < nlPromotion.getLength(); i++) {
            Element elePromotion = (Element) nlPromotion.item(i);
            String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
            if (!YFCCommon.isVoid(sPromotionType)
                && (KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(sPromotionType) ||KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType))) {
              logger
                  .debug("Kohls Cash is unearned. So calling changeOrder api to update the order.");
              ifChangeOrderRequired = true;
              bIsRKCPromotionProcessed = true;
            }
          }
        }

        // Code for CAPE-1299[to accommodate changeOrder call in a
        // single step.]
        if (ifChangeOrderRequired || byPassPromotion(inXML, env)) {

          KohlsReturnsKCOptionSelected obj = new KohlsReturnsKCOptionSelected();
          Document docTemp = (Document) inXML.cloneNode(true);
          obj.callChangeOrder(env, docTemp);
          
        }

        // Save the Document Object received from Gravity as a global
        // DOM
        // document object for further use
        docInXMLClone = (Document) inXML.cloneNode(true);

        /*
         * if (!YFCCommon.isVoid(sExtnPOCFeature) && KohlsPOCConstant.RECEIPTED_RET
         * .equalsIgnoreCase(sExtnPOCFeature)) { Document docProcessOrderPaymentsOut = null; try {
         * NodeList nlPaymentMethod = eleOrder
         * .getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD); if (nlPaymentMethod.getLength()
         * > 0) { for (int i = 0; i < nlPaymentMethod.getLength(); i++) { Element elePaymentMethod =
         * (Element) nlPaymentMethod .item(0); elePaymentMethod
         * .setAttribute(KohlsPOCConstant.PLAN_REFUND_AMT, elePaymentMethod
         * .getAttribute(KohlsPOCConstant.ATTR_AMOUNT)); if (elePaymentMethod
         * .getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE) .equalsIgnoreCase(KohlsPOCConstant.CASH))
         * { elePaymentMethod.setAttribute(KohlsPOCConstant.CHANGE_DUE, elePaymentMethod
         * .getAttribute(KohlsPOCConstant.ATTR_AMOUNT)); } } } docProcessOrderPaymentsOut =
         * KOHLSBaseApi.invokeAPI( env, KohlsPOCConstant.POP_FOR_POS, inXML); return
         * docProcessOrderPaymentsOut; } catch (Exception e) { throw e; } }
         */

        // Added for POC Returns - End
        
        //MJ 07/07 Changes for CAPE-3796 - start
        if(!bIsRKCPromotionProcessed){
          Element elePaymentMethodsTemp =
              (Element) inXML.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHODS).item(0);
          NodeList ndlPaymentMethod = elePaymentMethodsTemp.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
          for (int i = 0; i < ndlPaymentMethod.getLength(); i++) {
            Element elePaymentMethod = (Element) ndlPaymentMethod.item(i);
            if("CORPORATE_REFUND".equalsIgnoreCase(elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE))){              
              //Calling change Order to set PromotionApplied = N
              Element eleOrderOut = (Element)docOutput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);
              Element eleOrderListOutPromotions = XMLUtil.getChildElement(eleOrderOut, KohlsPOCConstant.E_PROMOTIONS);
              NodeList nlPromotionOut = eleOrderListOutPromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
              for(int j=0; j<nlPromotionOut.getLength(); j++){
                Element elePromotionOut = (Element)nlPromotionOut.item(j);
                String sPromotionType = elePromotionOut.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
                if("KOHLS_CASH_REISSUE".equalsIgnoreCase(sPromotionType)){
                  Document docChangeOrderIn = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
                  docChangeOrderIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrdHeadKey);
                  docChangeOrderIn.getDocumentElement().setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.YES);
                  docChangeOrderIn.getDocumentElement().setAttribute("Override", KohlsPOCConstant.YES);
                  Element eleChangeOrderPromotions = XMLUtil.createChild(docChangeOrderIn.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS);
                  Element eleChangeOrderPromotion = XMLUtil.createChild(eleChangeOrderPromotions, KohlsPOCConstant.E_PROMOTION);
                  eleChangeOrderPromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_KEY, elePromotionOut.getAttribute(KohlsPOCConstant.A_PROMOTION_KEY));
                  eleChangeOrderPromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
                  
                  //Calling ChangeOrder
                  Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
                  if (logger.isDebugEnabled()) {
                      logger.debug("Input xml to changeOrder is+ " + XMLUtil.getXMLString(docChangeOrderIn));
                  }
                  env.setTxnObject("SkipManagePSIOrderCall", true);
                  KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API, docChangeOrderIn);
                  env.setTxnObject("SkipManagePSIOrderCall", "");
                }
              }
            }
          }
        }
      //MJ 07/07 Changes for CAPE-3796 - end
        
        if (!YFCCommon.isVoid(docOutput)) {
          // MAD-287 changes Start
          // Element eleOrder = docOutput.getDocumentElement();
          Element eleAddtionalInfo =
              XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
          if (!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()) {
            endpoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
          }
          // MAD-287 changes End
          // Save the Document Object received as output from Service
          // as a global DOM document
          // object for further use
          docOutputClone = docOutput;
          sOrderNo = ((Element) docOutputClone.getElementsByTagName("Order").item(0))
              .getAttribute("OrderNo");
          // Input to call requestCollection api is prepared
          // Can be removed as it is same as that of
          // inputToPSAGetOrderList().
          if (!YFCCommon.isVoid(sExtnPOCFeature)
              && !KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
            Document docReqCollInput = inputToRequestCollection(strOrdHeadKey);
            Document docReqCollOut = callRequestCollectionAPI(env, docReqCollInput);

          }
          // requestCollection api is called

          // Whether requestCollection is a success or not is checked
          // if ((!YFCCommon.isVoid(docReqCollOut)) &&
          // (docReqCollOut.getDocumentElement()
          // .getNodeName().equalsIgnoreCase(KohlsPOCConstant.ELEM_ORDER)))
          // {
          // Input to call getChargeTransactionList api is
          // prepared
          Document docCharTransInput = inputToGetChargeTransactionList(strOrdHeadKey);
          // getChargeTransactionList api is called
          Document docCharTransOutput = callGetChargeTransactionListAPI(env, docCharTransInput);
          // A list of ChargeTransactionKey(s) is prepared from
          // the output of getChargeTransactionList api
          List<String> chargeTrnsactionKeys = getChargeTransactionKeys(docCharTransOutput);
          // Input to voidChargeTransaction api is prepared
          Document docVoidChargTransInput = voidChargeTransactioninDoc(chargeTrnsactionKeys);
          // voidChargeTransaction api is called
          Document docVoidChargTransOutput = callvoidChargeTransaction(env, docVoidChargTransInput);
          if (!YFCCommon.isVoid(docVoidChargTransOutput)) {
            if (bIsDebugEnabled) {
              logger.debug("KohlsReturnRefund.setFinalPSARefundTypes docVoidChargTransOutput="
                  + XMLUtil.getXMLString(docVoidChargTransOutput));
            }
          }
          // Input to getPaymentList is prepared

          logger.debug("in sider ***************");
          Document docGetPayListInput = inputToGetPaymentList(strOrdHeadKey);
          // getPaymentList api is called
          Document docGetPayListOutput = callgetPaymentList(env, docGetPayListInput);
          // Save the getPaymentList api output as a global DOM
          // document object for further use
          docGetPayOutClone = docGetPayListOutput;
          // Set PSA Ids to Map
          setPSAIdsToMap();
          // Print the Map Values
          printMapValues(mPSAId);
          // Form the generic skeleton for recordExternalCharges
          // api

          Document docSklRecordExternalCharges =
              formInputSklToRecordExternalCharges(sExtnPOCFeature);
          // Update the tender specific attributes and call
          // recordExternalCharges api
          Document docUpdatedInXml = formAndCallInputToRecordExternalCharges(env,
              docSklRecordExternalCharges, inXML, sExtnPOCFeature);
          // Check if the output received from
          // formAndCallInputToRecordExternalCharges contains
          // Error xml or not
          if ((!YFCCommon.isVoid(docUpdatedInXml)) && (docUpdatedInXml.getDocumentElement()
              .getNodeName().equalsIgnoreCase(KohlsXMLLiterals.A_ERRORS))) {
            // Set a global flag as true and return the Error
            // Document to Gravity
            bIsKMCError = true;
            return docUpdatedInXml;
          }

          if (!YFCCommon.isVoid(docUpdatedInXml)) {
            if (bIsDebugEnabled) {
              logger.debug("KohlsReturnRefund.setFinalPSARefundTypes docUpdatedInXMl= "
                  + XMLUtil.getXMLString(docUpdatedInXml) + " inXML="
                  + XMLUtil.getXMLString(inXML));
            }
          }

          // }
        }
      }

    } catch (

    Exception e) {
      logger.error("KohlsReturnRefund.setFinalPSARefundTypes Exception=" + e.getMessage());
      // CAPE-563 (BUG)
      if (bIsKMCError) {

        // not sure why this is here, commenting out for CAPE 2096
        // Element inEle = inXML.getDocumentElement();
        // inEle.setAttribute("PaymentSuccess", "N");
        // return inXML;

        throw new YFSException("KMC_ERROR", "KMC_ERROR", "KMC Service is not available");
      }
    } finally {
      // Check if the KMC has error or not
      if (!bIsKMCError) {

        // Prepare input for PSAGetOrderList OMS Service

        Document docPSAGetOrderInput = inputToPSAGetOrderList(strOrdHeadKey, sExtnPOCFeature);

        // Call PSAGetOrderList OMS Service
        docOutput = callPSAGetOrderListAPI(env, docPSAGetOrderInput);
        if (bIsDebugEnabled) {

          logger.debug("KohlsReturnRefund.setFinalPSARefundTypes docGetOrderListOutput="
              + XMLUtil.getXMLString(docOutput));
        }
        // Extract Order Element from OrderList
        Element eleGetOrderOutputElement =
            XMLUtil.getChildElement(docOutput.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);
        // Get Document object from the Element
        if (!YFCCommon.isVoid(eleGetOrderOutputElement)) {
          docOutput = XMLUtil.getDocumentForElement(eleGetOrderOutputElement);
          // long lEndTime = System.nanoTime();
          if (bIsDebugEnabled) {
            logger.debug("KohlsReturnRefund.setFinalPSARefundTypes docOrderOutput="
                + XMLUtil.getXMLString(docOutput));
            // logger.debug("KohlsReturnRefund.setFinalPSARefundTypes
            // lEndTime"+lEndTime);
            // logger.debug("KohlsReturnRefund.setFinalPSARefundTypes
            // Time
            // Elapsed
            // Approx"+(lEndTime-lStartTime));

          }
          logger.endTimer("KohlsReturnRefund.setFinalPSARefundTypes");
          return docOutput;

        }

      }

    }
    logger.endTimer("KohlsReturnRefund.setFinalPSARefundTypes");

    return docOutput;
  }

  /**
   * 
   * This method by pass the Promotion getting applied in case of corporate refund.
   * 
   * @param inXML , reference to Document
   * @param env , reference to YFSEnvironment
   */
  protected boolean byPassPromotion(Document inXML, YFSEnvironment env) throws Exception {
    NodeList nlPromotion = inXML.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        String xpathFrPayType =
            "/Order/PaymentMethods/PaymentMethod/@PaymentType='CORPORATE_REFUND'";
        String isPayTypeCorpRefund = KohlsXPathUtil.getString(inXML, xpathFrPayType);
        if (!YFCCommon.isVoid(sPromotionType)
            && KohlsPOCConstant.KOHLS_CASH_REISSUE.equalsIgnoreCase(sPromotionType)
            && (isPayTypeCorpRefund != null && isPayTypeCorpRefund.equals("true"))) {
          logger.debug(
              "KohlsReturnRefund -> byPassPromotion() :-  Since, its a  corporate refund, promo need not to be applied");
          // setting PromotionApplied="N"
          elePromotion.setAttribute(KohlsPOCConstant.PROMO_APPLIED, KohlsPOCConstant.NO);
          env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
          return true;
        }
      }
    }
    return false;
  }

  /**
   * 
   * Prints the Key and Value for an Object of Map<String,String>
   * 
   * @param mKMCValues
   */
  protected void printMapValues(Map<String, String> mKMCValues) {
    logger.beginTimer("KohlsReturnRefund.printMapValues");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.printMapValues -- Start");
    }
    try {
      // If the Map is not empty proceed
      if (!mKMCValues.isEmpty()) {
        // Create a set of Entries
        Set<Entry<String, String>> hashSet = mKMCValues.entrySet();
        // Iterate over the Set
        for (Entry<String, String> entry : hashSet) {
          if (bIsDebugEnabled) {
            logger.debug("KohlsReturnRefund.printMapValues KMC Map Key=" + entry.getKey()
                + " Value=" + entry.getValue());
          }
        }
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.updateInputForRecordPV Exception=" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.printMapValues");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.printMapValues -- End");
    }
    logger.endTimer("KohlsReturnRefund.printMapValues");
  }

  /**
   * 
   * This method adds OperatorID, TerminalID, TillID, StoreID, DrawerID and BusinessDay to a map to
   * be retrieved later
   * 
   */
  private void setPSAIdsToMap() {
    logger.beginTimer("KohlsReturnRefund.setPSAIdsToMap");
    try {
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.setPSAIdsToMap -- Start");
      }
      Element eleOrder = docInXMLClone.getDocumentElement();
      String sBusinessDay = eleOrder.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY);
      if (!YFCCommon.isStringVoid(sBusinessDay)) {
        mPSAId.put(KohlsPOCConstant.ATTR_BUSINESS_DAY, sBusinessDay);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setPSAIdsToMap sBusinessDay=" + sBusinessDay);
        }
      }
      String sOperatorID = eleOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID);
      if (!YFCCommon.isStringVoid(sOperatorID)) {
        mPSAId.put(KohlsPOCConstant.A_OPERATOR_ID, sOperatorID);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setPSAIdsToMap sOperatorID=" + sOperatorID);
        }
      }
      String sTerminalID = eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
      if (!YFCCommon.isStringVoid(sTerminalID)) {
        mPSAId.put(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setPSAIdsToMap sTerminalID=" + sTerminalID);
        }
      }
      String sTillID = eleOrder.getAttribute(KohlsPOCConstant.ATTR_TILL_ID);
      if (!YFCCommon.isStringVoid(sTillID)) {
        mPSAId.put(KohlsPOCConstant.ATTR_TILL_ID, sTillID);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setPSAIdsToMap sTillID=" + sTillID);
        }
      }
      String sStoreID = eleOrder.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
      if (!YFCCommon.isStringVoid(sStoreID)) {
        mPSAId.put(KohlsPOCConstant.ATTR_STORE_ID, sStoreID);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setPSAIdsToMap sStoreID=" + sStoreID);
        }
      }
      String sDrawerID = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID);
      if (!YFCCommon.isStringVoid(sDrawerID)) {
        mPSAId.put(KohlsPOCConstant.ATTR_DRAWER_ID, sDrawerID);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setPSAIdsToMap sDrawerID=" + sDrawerID);
        }
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.setPSAId Exception" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.setPSAIdsToMap");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.setPSAIdsToMap -- End");
    }

    logger.endTimer("KohlsReturnRefund.setPSAIdsToMap");
  }

  /**
   * This is a major controller function for preparing input for recordExternalCharges api
   * 
   * @param env
   * @param docSklRecordExternalCharges
   * @param inXML
   * @return
   * @throws Exception
   */
  private Document formAndCallInputToRecordExternalCharges(YFSEnvironment env,
      Document docSklRecordExternalCharges, Document inXML, String sExtnPOCFeature)
      throws Exception {

      
    logger.beginTimer("KohlsReturnRefund.formAndCallInputToRecordExternalCharges");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges -- Start");
    }

    Document docKMCResponse = null;
    try {
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges docSklRecord="
            + XMLUtil.getXMLString(docSklRecordExternalCharges) + " inXML="
            + XMLUtil.getXMLString(inXML));
      }
      // Get the PaymentMethod(s) from the Gravity Input
      Document docCloneSklRecordExternalCharges = null;
      Document docpinpadResponse = null;
      Element eleInXML = inXML.getDocumentElement();


      Element elePaymentMethods =
          SCXmlUtil.getXpathElement(eleInXML, KohlsXMLLiterals.E_PAYMENT_METHODS);
      if (!YFCCommon.isVoid(elePaymentMethods)) {
        NodeList ndlPayMeth = XPathUtil.getNodeList(inXML, KohlsXMLLiterals.XPATH_PAY_METH);
        // Initialize a map to contain extn values for KMC
        Map<String, String> mapKMCValues = new HashMap<String, String>();
        int iPayMethSize = ndlPayMeth.getLength();
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges iPayMethSize="
              + iPayMethSize);
        }
        // Iterate over the NodeList of PaymentMethod(s)
        for (int i = 0; i < iPayMethSize; i++) {
          // Get the Current Element
          Element eleCurrElement = (Element) ndlPayMeth.item(i);
          if (bIsDebugEnabled) {
            logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges eleCurrElement="
                + XMLUtil.getElementXMLString(eleCurrElement));
          }
          String sPaymentType = eleCurrElement.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
          String sAmount = eleCurrElement.getAttribute(KohlsPOCConstant.ATTR_AMOUNT);
          if (YFCCommon.isVoid(sAmount)) {
            continue;
          } else {

            Double dAmount = Double.parseDouble(sAmount);

            eleCurrElement.setAttribute(KohlsPOCConstant.ATTR_AMOUNT,
                String.valueOf(Math.abs(dAmount)));
          }

          
          if ((Double.parseDouble(sAmount) == 0) && KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature )) {
              continue;
            }
          

          if (!YFCCommon.isStringVoid(sPaymentType)) {
            if (bIsDebugEnabled) {
              logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges sPaymentType="
                  + sPaymentType);
            }
            // Check if the PaymentMethod Element is a Credit Card
            // or KMC Or Not
            boolean bIsCard = checkIfCard(sPaymentType);
            // Check if the PaymentMethod Element is a KMC
            boolean bIsKMC =
                ((sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC)) ? true : false);
            // Check if the PaymentMethod Element is a KCC
            boolean bIsKCC =
                ((sPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD)) ? true : false);
            // Check if the PaymentMethod Element is a CREDIT CARD
            boolean bIsCC =
                ((sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD)) ? true : false);
            boolean bIsDebit = ((sPaymentType.equalsIgnoreCase("DEBIT_CARD")) ? true : false);

            if (bIsDebugEnabled) {
              logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges bIsCard="
                  + bIsCard + " bIsKMC=" + bIsKMC);
            }
            if (bIsCard) {
              if (bIsKMC) {
            	  
            	//OMNI2 - Check if SvcNo is present, if SvcNo not present, then remove - BEGIN
            	  Document autoReturninDoc = (Document) env.getTxnObject("AUTO_RETURN_DOC");
            	  if(!YFCCommon.isVoid(autoReturninDoc)) {
            		  logger.debug("formAndCallInputToRecordExternalCharges - Inside Auto Return inXML is \n" + XMLUtil.getXMLString(inXML));
            		  Element eleKMCPmntMethod = (Element) XPathUtil.getNode(inXML, "/Order/PaymentMethods/PaymentMethod[@PaymentType='KMC']");
            		  String svcNoFromPmntMethod = eleKMCPmntMethod.getAttribute(KohlsXMLLiterals.A_SVC_NO);
            		  Element eleKMCPmntMethodExtn = (Element) eleKMCPmntMethod.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
            		  if(YFCCommon.isVoid(eleKMCPmntMethodExtn)) {
            			  logger.debug("Extn inside Payment method blank");
            			  continue;
            		  }else {
            			  Document extnPmntDtlsListDoc = XMLUtil.getDocument(eleKMCPmntMethodExtn.getAttribute("ExtnPaymentDetails"));
                		  Element extnPmntDtls = (Element) extnPmntDtlsListDoc.getDocumentElement().getElementsByTagName("KohlsPayment").item(0);
                		  String svcNoFromExtn = extnPmntDtls.getAttribute(KohlsXMLLiterals.A_SVC_NO);
                		  logger.debug("Inside else block of checking SvcNo: ExtnElement: \n" + XMLUtil.getXMLString(extnPmntDtlsListDoc));
                		  if(YFCCommon.isVoid(svcNoFromPmntMethod) && YFCCommon.isVoid(svcNoFromExtn)) {
                			  logger.debug("SvcNo not present inside Payment Method and Extn");
                			  continue;
                		  }
            		  }
            	  }
              	//OMNI2 - Check if SvcNo is present, if SvcNo not present, then remove - END
            	  
                Element eleOrderList = docOutputClone.getDocumentElement();
                Element eleOrder =
                    XMLUtil.getChildElement(eleOrderList, KohlsPOCConstant.ELEM_ORDER);
                // Create a request for KMC to call Gift Card
                // Gateway
                try {
                  docKMCResponse = createPSAGCActivationRequest(env, eleCurrElement, eleOrder);
                } catch (Exception ex) {
                  // CAPE 864 starts
                  logger
                      .error("KohlsReturnRefund.formAndCallInputToRecordExternalCharges Exception="
                          + ex.getMessage());


                  docCloneSklRecordExternalCharges =
                      (Document) docSklRecordExternalCharges.cloneNode(true);
                  mapKMCValues.put(KohlsXMLLiterals.A_AUTH_CODE, KohlsPOCConstant.OFFLINE);
                  mapKMCValues.put(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE,
                      KohlsPOCConstant.OFFLINE);
                  mapKMCValues.put(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE,
                      KohlsPOCConstant.OFFLINE);
                  mapKMCValues.put(KohlsPOCConstant.A_STORE_ID,
                      eleCurrElement.getAttribute(KohlsXMLLiterals.ATTR_STORE_NUM));

                  Document docFinalRecordExtCharInput = updatesklRecordExternalCharges(
                      eleCurrElement, docpinpadResponse, docCloneSklRecordExternalCharges,
                      strOrdHeadKey, docGetPayOutClone, mapKMCValues, sExtnPOCFeature, env);

                  Document docFinalRecordExtCharOutput =
                      callRecordExternalPayments(env, docFinalRecordExtCharInput, sExtnPOCFeature);
                  if (!YFCCommon.isVoid(docFinalRecordExtCharOutput)) {
                    if (bIsDebugEnabled) {
                      logger.debug(
                          "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docFinalRecordOut="
                              + XMLUtil.getXMLString(docFinalRecordExtCharOutput));
                    }
                  }

                  throw new YFSException("KMC_ERROR", "KMC_ERROR", "KMC Service is not available");
                  // CAPE 864 ends

                }
                if (bIsDebugEnabled) {
                  logger.debug(
                      "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docKMCResposne after request="
                          + XMLUtil.getXMLString(docKMCResponse));
                }
                // Get a formatted response from the response of
                // Gift Card Gateway
                docKMCResponse = createResponseDocumentfromWS(docKMCResponse);
                if (bIsDebugEnabled) {
                  logger.debug(
                      "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docKMCResposne after response format="
                          + XMLUtil.getXMLString(docKMCResponse));
                }
                // Check if the gateway had returned Error or
                // success response
                boolean bIfKMCError = checkForKMCError(docKMCResponse);
                boolean bIfKMCSuccess = checkForKMCSuccess(docKMCResponse);
                if (bIsDebugEnabled) {
                  logger.debug(
                      "KohlsReturnRefund.formAndCallInputToRecordExternalCharges bIfKMCError="
                          + bIfKMCError + " bIfKMCSuccess=" + bIfKMCSuccess);
                }
                // If it is an error form a error document as
                // per Gravity requirements and return that
                // document
                if (bIfKMCError) {
                  Element eleStoredValueRequestResult = (Element) docKMCResponse
                      .getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT)
                      .item(0);
                  if (!YFCCommon.isVoid(eleStoredValueRequestResult)) {
                    String strStoreId =
                        eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
                    String strResponseCode = eleStoredValueRequestResult
                        .getAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE);
                    String strProcessorNetworkID = eleStoredValueRequestResult
                        .getAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID);
                    String sAuthResponse = eleStoredValueRequestResult
                        .getAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE);

                    mapKMCValues.put(KohlsXMLLiterals.A_AUTH_CODE, strResponseCode);
                    mapKMCValues.put(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE, sAuthResponse);
                    mapKMCValues.put(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE,
                        strProcessorNetworkID);
                    if (!YFCCommon.isStringVoid(strStoreId)) {
                      mapKMCValues.put(KohlsPOCConstant.A_STORE_ID, strStoreId);
                    }
                  }
                  Document docError = setErrorKMCDoc(docKMCResponse);
                  if (bIsDebugEnabled) {
                    logger
                        .debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges docError="
                            + XMLUtil.getXMLString(docError));
                  }
                  docCloneSklRecordExternalCharges =
                      (Document) docSklRecordExternalCharges.cloneNode(true);
                  Document docFinalRecordExtCharInput = updatesklRecordExternalCharges(
                      eleCurrElement, docpinpadResponse, docCloneSklRecordExternalCharges,
                      strOrdHeadKey, docGetPayOutClone, mapKMCValues, sExtnPOCFeature, env);
                  Document docFinalRecordExtCharOutput =
                      callRecordExternalPayments(env, docFinalRecordExtCharInput, sExtnPOCFeature);
                  return docError;
                } else if (bIfKMCSuccess) {
                  if (bIsDebugEnabled) {
                    logger.debug(
                        "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docKMCResposne before success doc set="
                            + XMLUtil.getXMLString(docKMCResponse));
                  }
                  // Get the Extn attributes of KMC and set it
                  // in a map
                  mapKMCValues = setSuccessKMC(docKMCResponse);
                } else {
                  if (bIsDebugEnabled) {
                    // This is an IllegalState for the
                    // application
                    logger.debug("KMC Response is wrong");
                  }
                  throw new IllegalStateException("KMC Response is wrong");
                }
              }

              // Call to pinpad for payment type credit card and
              // Kohls Charge Card

              if ((bIsKCC || bIsCC || bIsDebit)) {
                if (bIsDebugEnabled) {
                  logger.debug("Reaching out to Pinpad");
                }

                docpinpadResponse = callPinPad(env, eleCurrElement);

              }
              // Update the skeleton of recordExternalCharges api
              // input
              docCloneSklRecordExternalCharges =
                  (Document) docSklRecordExternalCharges.cloneNode(true);
              Document docFinalRecordExtCharInput = updatesklRecordExternalCharges(eleCurrElement,
                  docpinpadResponse, docCloneSklRecordExternalCharges, strOrdHeadKey,
                  docGetPayOutClone, mapKMCValues, sExtnPOCFeature, env);
              if (bIsDebugEnabled) {
                logger.debug("Final Record External Payments input ::"
                    + XMLUtil.getXMLString(docFinalRecordExtCharInput));
              }

              if (bIsDebugEnabled) {
                logger.debug(
                    "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docFinalRecordInput="
                        + XMLUtil.getXMLString(docFinalRecordExtCharInput));
              }
              // Call recordExternalCharges api

              Document docFinalRecordExtCharOutput =
                  callRecordExternalPayments(env, docFinalRecordExtCharInput, sExtnPOCFeature);
              if (!YFCCommon.isVoid(docFinalRecordExtCharOutput)) {
                if (bIsDebugEnabled) {
                  logger.debug(
                      "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docFinalRecordOut="
                          + XMLUtil.getXMLString(docFinalRecordExtCharOutput));
                }
              }

              // Set used Elements as Y to remove Element later
              eleCurrElement.setAttribute(KohlsXMLLiterals.A_USED, KohlsXMLLiterals.CONST_Y);
              if (bIsDebugEnabled) {
                logger.debug(
                    "KohlsReturnRefund.formAndCallInputToRecordExternalCharges eleCurrElement end of loop="
                        + XMLUtil.getElementXMLString(eleCurrElement));
              }
            }

            else {

              Document docFinalRecordExtCharInput = updatesklRecordExternalCharges(eleCurrElement,
                  docpinpadResponse, docSklRecordExternalCharges, strOrdHeadKey, docGetPayOutClone,
                  mapKMCValues, sExtnPOCFeature, env);
              if (bIsDebugEnabled) {
                logger.debug(
                    "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docFinalRecordInput="
                        + XMLUtil.getXMLString(docFinalRecordExtCharInput));
              }
              // Call recordExternalCharges api

              Document docFinalRecordExtCharOutput =
                  callRecordExternalPayments(env, docFinalRecordExtCharInput, sExtnPOCFeature);
              if (!YFCCommon.isVoid(docFinalRecordExtCharOutput)) {
                if (bIsDebugEnabled) {
                  logger.debug(
                      "KohlsReturnRefund.formAndCallInputToRecordExternalCharges docFinalRecordOut="
                          + XMLUtil.getXMLString(docFinalRecordExtCharOutput));
                }
              }

              eleCurrElement.setAttribute(KohlsXMLLiterals.A_USED, KohlsXMLLiterals.CONST_Y);
              if (bIsDebugEnabled) {
                logger.debug(
                    "KohlsReturnRefund.formAndCallInputToRecordExternalCharges eleCurrElement end of loop="
                        + XMLUtil.getElementXMLString(eleCurrElement));
              }

            }

          }

        }
        for (int i = (iPayMethSize - 1); i >= 0; i--) {
          Element eleCurrElement = (Element) ndlPayMeth.item(i);
          if (bIsDebugEnabled) {
            logger.debug(
                "KohlsReturnRefund.formAndCallInputToRecordExternalCharges eleCurrElement 2nd loop="
                    + XMLUtil.getElementXMLString(eleCurrElement));
          }

          String strIsUsed = eleCurrElement.getAttribute(KohlsXMLLiterals.A_USED);
          if ((!YFCCommon.isStringVoid(strIsUsed))
              && strIsUsed.equalsIgnoreCase(KohlsXMLLiterals.CONST_Y)) {
            XMLUtil.removeChild(elePaymentMethods, eleCurrElement);
          }

        }
      }
      // Iterate over the Gravity input and remove the used elements

      if (bIsDebugEnabled) {
        for (Iterator<String> iterator = liPayKey.iterator(); iterator.hasNext();) {
          String strPayKey = iterator.next();
          logger.debug(
              "KohlsReturnRefund.formAndCallInputToRecordExternalCharges liPayKey=" + strPayKey);
        }
        logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges elePaymentMethods="
            + XMLUtil.getElementXMLString(elePaymentMethods));
      }

    } catch (Exception e) {
      logger.error(
          "KohlsReturnRefund.formAndCallInputToRecordExternalCharges Exception=" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.formAndCallInputToRecordExternalCharges");
      // CAPE-563 (BUG)
      throw new YFSException("KMC_ERROR", "KMC_ERROR", "KMC Service is not available");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges inXml="
          + XMLUtil.getXMLString(inXML));
      logger.debug("KohlsReturnRefund.formAndCallInputToRecordExternalCharges -- End");
    }
    logger.endTimer("KohlsReturnRefund.formAndCallInputToRecordExternalCharges");
    return inXML;
  }

  /**
   * 
   * This method prepares a formatted input from response received from Gift Card Gateway
   * 
   * @param docGCActRequestOutput
   * @return
   * @throws YFCException
   * @throws ParserConfigurationException
   */
  private Document createResponseDocumentfromWS(Document docGCActRequestOutput)
      throws YFCException, ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.createResponseDocumentfromWS");
    Document docStoredValueRequest = null;
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.createResponseDocumentfromWS -- Start");
    }
    try {
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.createResponseDocumentfromWS docGCActRequestOutput="
            + XMLUtil.getXMLString(docGCActRequestOutput));
      }
      docStoredValueRequest = XMLUtil.createDocument(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST);
      Element eleStoredValueRequest = docStoredValueRequest.getDocumentElement();
      Element eleStoredValueRequestResult =
          docStoredValueRequest.createElement(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT);
      // Get attributes from the resposne and map to the new document
      XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
      Element sExtn = docStoredValueRequest.createElement(KohlsPOCConstant.A_EXTN);
      XMLUtil.appendChild(eleStoredValueRequestResult, sExtn);

      Element paymentResponse = docGCActRequestOutput.getDocumentElement();
      String sResultCode = paymentResponse.getAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER);
      if (!YFCCommon.isVoid(sResultCode)) {
        if (bIsDebugEnabled) {
          logger.debug("AuthCode from KMC Response::" + sResultCode);
        }
      }
      String sAuthSource = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_AUTH_SOURCE);
      String sExtnAuthSourceNode = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_NODEID);
      String sAuthResponse = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE);
      String sRemainingBalance =
          paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_REMAINING_BALANCE);
      String sStoreId = paymentResponse.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
      if (sExtnAuthSourceNode.startsWith(KohlsXMLLiterals.ATTR_ISP)) {
        sExtn.setAttribute(KohlsXMLLiterals.ATTR_EXTN_AUTH_SOURCE_NODE,
            KohlsPOCConstant.ATTR_STORE);
      } else {
        sExtn.setAttribute(KohlsXMLLiterals.ATTR_EXTN_AUTH_SOURCE_NODE, KohlsXMLLiterals.ATTR_CORP);
      }
      // If the response has success codes, then map the following
      if (KohlsPOCConstant.N_PG_SUCCESS.equals(sResultCode)) {
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE,
            KohlsXMLLiterals.ATTR_SUCCESS);
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.E_ACTION_CODE,
            KohlsXMLLiterals.ATTR_AUTHORIZED);
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE,
            sResultCode);
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID,
            sAuthSource);
        eleStoredValueRequestResult.setAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE,
            sAuthResponse);
        eleStoredValueRequestResult.setAttribute(KohlsXMLLiterals.ATTR_REMAINING_BALANCE,
            sRemainingBalance);
        if (!YFCCommon.isStringVoid(sStoreId)) {
          logger.debug("Store Id is " + sStoreId);
          eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sStoreId);
        }
      }
      // If the response has Error codes, then map the following
      else {
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE,
            KohlsXMLLiterals.ATTR_ERROR_DECLINED);
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.E_ACTION_CODE,
            KohlsXMLLiterals.ATTR_DECLINED);
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE,
            sResultCode);
        eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID,
            sAuthSource);
        eleStoredValueRequestResult.setAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE,
            sAuthResponse);
        if (!YFCCommon.isStringVoid(sStoreId)) {
          logger.debug("Store Id is " + sStoreId);
          eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sStoreId);
        }
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.createResponseDocumentfromWS Exception=" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.createResponseDocumentfromWS");
    }
    if (bIsDebugEnabled) {
      logger.debug("OutPut XML of method createResponseDocumentfromWS :"
          + XMLUtil.getXMLString(docStoredValueRequest));
      logger.debug("KohlsReturnRefund.createResponseDocumentfromWS -- End");
    }
    logger.endTimer("KohlsReturnRefund.createResponseDocumentfromWS");
    return docStoredValueRequest;
  }

  /**
   * 
   * This method return the extn attributes of KMC authorization response
   * 
   * @param docKMCOut
   * @return
   */
  private Map<String, String> setSuccessKMC(Document docKMCOut) {
    logger.beginTimer("KohlsReturnRefund.setSuccessKMC");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.setSuccessKMCDoc -- Start");
    }
    Map<String, String> mapKMCValues = new HashMap<String, String>();
    try {
      if (bIsDebugEnabled) {
        logger.debug(
            "KohlsReturnRefund.setSuccessKMCDoc docKMCOut=" + XMLUtil.getXMLString(docKMCOut));
      }
      Element eleStoredValueRequestResult = (Element) docKMCOut
          .getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
      if (!YFCCommon.isVoid(eleStoredValueRequestResult)) {
        // Extract extn attributes of KMC authorization response and set
        // it in a map
        String strAuthResponse =
            eleStoredValueRequestResult.getAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE);
        String strRemainingBalance =
            eleStoredValueRequestResult.getAttribute(KohlsXMLLiterals.ATTR_REMAINING_BALANCE);
        String strStoreId =
            eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
        String strResponseCode =
            eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE);
        String strProcessorNetworkID = eleStoredValueRequestResult
            .getAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID);
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.setSuccessKMCDoc strAuthResponse" + strAuthResponse
              + " strRemainingBalance=" + strRemainingBalance + " strResponseCode= "
              + strResponseCode);
        }
        mapKMCValues.put(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE, strAuthResponse);
        mapKMCValues.put(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE, strRemainingBalance);
        mapKMCValues.put(KohlsXMLLiterals.A_AUTH_CODE, strResponseCode);
        mapKMCValues.put(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE, strProcessorNetworkID);
        if (!YFCCommon.isStringVoid(strStoreId)) {
          mapKMCValues.put(KohlsPOCConstant.A_STORE_ID, strStoreId);
        }
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.setSuccessKMCDoc Exception=" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.setSuccessKMC");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.setSuccessKMCDoc -- End");
    }
    logger.endTimer("KohlsReturnRefund.setSuccessKMC");
    return mapKMCValues;
  }

  /**
   * 
   * This method shall return whether KMC authorization was a success or not
   * 
   * @param docKMCOut
   * @return
   */
  private boolean checkForKMCSuccess(Document docKMCOut) {
    logger.beginTimer("KohlsReturnRefund.checkForKMCSuccess");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.checkForKMCSuccess -- Start");
    }
    Element eleStoredValueRequestResult = (Element) docKMCOut
        .getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
    if (!YFCCommon.isVoid(eleStoredValueRequestResult)
        && (eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE)
            .equalsIgnoreCase(KohlsXMLLiterals.ATTR_SUCCESS))) {
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.checkForKMCSuccess Inside the if check i.e. Success");
      }
      logger.endTimer("KohlsReturnRefund.checkForKMCSuccess");
      return true;
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.checkForKMCSuccess -- End");
    }
    logger.endTimer("KohlsReturnRefund.checkForKMCSuccess");
    return false;
  }

  /**
   * 
   * This method shall form the KMC Error document
   * 
   * @param docKMCOut
   * @return
   */
  private Document setErrorKMCDoc(Document docKMCOut) {
    logger.beginTimer("KohlsReturnRefund.setErrorKMCDoc");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.setErrorKMCDoc -- Start");
    }
    Document docError = null;
    try {
      if (bIsDebugEnabled) {
        logger
            .debug("KohlsReturnRefund.setErrorKMCDoc docKMCOut=" + XMLUtil.getXMLString(docKMCOut));
      }
      Element eleStoredValueRequestResult = (Element) docKMCOut
          .getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
      if (!YFCCommon.isVoid(eleStoredValueRequestResult)) {
        // Create a new Error Document and send it back
        docError = XMLUtil.createDocument(KohlsXMLLiterals.A_ERRORS);
        Element eleErrors = docError.getDocumentElement();
        Element eleError = XMLUtil.createChild(eleErrors, KohlsPOCConstant.E_ERROR);
        eleError.setAttribute(KohlsPOCConstant.A_ERROR_CODE,
            eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE));
        eleError.setAttribute(KohlsXMLLiterals.ATTR_ERROR_ACTION_CODE,
            eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_ACTION_CODE));
        eleError.setAttribute(KohlsXMLLiterals.ATTR_ERROR_RESPONSE_CODE,
            eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE));
        eleError.setAttribute(KohlsXMLLiterals.ATTR_ERROR_PROCESSOR_NETWORK_ID,
            eleStoredValueRequestResult
                .getAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID));
        eleError.setAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION,
            "Card is Declined or Connect Timed Out");
        eleError.setAttribute("IsKMCDeclined", KohlsPOCConstant.YES);
      }
      if (bIsDebugEnabled) {
        logger.debug("Error Document for KMC:" + XMLUtil.getXMLString(docError));
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.setErrorKMCDoc Exception=" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.setErrorKMCDoc");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.setErrorKMCDoc docError=" + XMLUtil.getXMLString(docError));
      logger.debug("KohlsReturnRefund.setErrorKMCDoc -- End");
    }
    logger.endTimer("KohlsReturnRefund.setErrorKMCDoc");
    return docError;
  }

  /**
   * 
   * This method checks if KMC authorization was a failure or not
   * 
   * @param docKMCOut
   * @return
   */
  private boolean checkForKMCError(Document docKMCOut) {
    logger.beginTimer("KohlsReturnRefund.checkForKMCError");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.checkForKMCError -- Start");
    }
    Element eleStoredValueRequestResult = (Element) docKMCOut
        .getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
    if ((!(YFCCommon.isVoid(eleStoredValueRequestResult))
        && (eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE)
            .equalsIgnoreCase(KohlsXMLLiterals.ATTR_ERROR_DECLINED)))) {
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.checkForKMCError Error is the result");
      }
      logger.endTimer("KohlsReturnRefund.checkForKMCError");
      return true;
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.checkForKMCError -- End");
    }
    logger.endTimer("KohlsReturnRefund.checkForKMCError");
    return false;
  }

  /**
   * 
   * This method shall check if PaymentType is a Card or not
   * 
   * @param sPaymentType
   * @return
   */
  protected boolean checkIfCard(String sPaymentType) {
    if (bIsDebugEnabled) {
      logger.beginTimer("KohlsReturnRefund.checkIfCard");
      logger.debug("KohlsReturnRefund.checkIfCard -- Start");
    }
    List<String> listArrayCard = Arrays.asList(KohlsXMLLiterals.ATTR_KMC,
        KohlsXMLLiterals.ATTR_CREDIT_CARD, KohlsPOCConstant.KOHL_CHARGE_CARD, "DEBIT_CARD");
    boolean bIsCard = false;
    bIsCard = listArrayCard.contains(sPaymentType);
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.checkIfCard bIsCard=" + bIsCard);
      logger.debug("KohlsReturnRefund.checkIfCard -- End");
    }
    logger.endTimer("KohlsReturnRefund.checkIfCard");
    return bIsCard;
  }

  /**
   * 
   * This method makes a changeOrder API call
   * 
   * @param env
   * @param docChangeOrderInput
   */
  private Document callChangeOrder(YFSEnvironment env, Document docChangeOrderInput) {
    logger.beginTimer("KohlsReturnRefund.callChangeOrder");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callChangeOrder - Begin");
    }
    try {
      docChangeOrderInput =
          KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API, docChangeOrderInput);
    } catch (Exception e) {
      logger.error("Exception in the Method callChangeOrder of KohlsReturnRefund" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.callChangeOrder");
    }
    if (bIsDebugEnabled) {
      logger.debug(
          "KohlsReturnRefund.callChangeOrder Output:" + XMLUtil.getXMLString(docChangeOrderInput));
      logger.debug("KohlsReturnRefund.callChangeOrder - End");
    }
    logger.endTimer("KohlsReturnRefund.callChangeOrder");
    return docChangeOrderInput;
  }

  /**
   * This method forms input for Common Code API
   * 
   * @param env
   * @param inDoc
   * @return
   */
  private Document formInputForCommonCode(Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.formInputForCommonCode");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.formInputForCommonCode - Start");
    }
    Document docInputForCommonCode = null;
    try {
      // Create an input for getCommonCodeList api from the Gravity input
      Element inDocOrder = inDoc.getDocumentElement();
      Element inDocPaymentMethod = SCXmlUtil.getXpathElement(inDocOrder,
          "PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
      docInputForCommonCode = XMLUtil.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
      Element eleCommonCode = docInputForCommonCode.getDocumentElement();
      eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
          KohlsXMLLiterals.ATTR_CORP_REASON_CODE);
      eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_SHORT_DESCRIPTION,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_REASON));
    }

    catch (Exception e) {
      logger.error("Exception occurred in formInputForCommonCode  method:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.formInputForCommonCode");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.formInputForCommonCode docOutput="
          + XMLUtil.getXMLString(docInputForCommonCode));
      logger.debug("KohlsReturnRefund.formInputForCommonCode -- End");
    }
    logger.endTimer("KohlsReturnRefund.formInputForCommonCode");
    return docInputForCommonCode;

  }

  /**
   * This method returns CodeValue with respect to CodeDescription
   * 
   * @param env
   * @param inDoc
   * @return
   */
  private String getUpdatedCommonCode(Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.getUpdatedCommonCode");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getUpdatedCommonCode - Begin");
    }
    String strReasonCode = null;
    try {
      Element eleCommonCodeList = inDoc.getDocumentElement();
      Element eleCommonCode =
          (Element) eleCommonCodeList.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE).item(0);
      strReasonCode = eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE);
    } catch (Exception e) {
      logger.error("Exception in the getUpdatedCommonCode Method:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.getUpdatedCommonCode");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getUpdatedCommonCode String=" + strReasonCode);
    }
    logger.endTimer("KohlsReturnRefund.getUpdatedCommonCode");
    return strReasonCode;
  }

  /**
   * This method makes a getCommonCodeList call
   * 
   * @param env
   * @param inDoc
   * @return
   */
  private Document callGetCommonCodeList(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callGetCommonCodeList");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callGetCommonCodeList - Begin");
    }
    try {
      // Call getCommonCodeList api
      inDoc = KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.API_GET_COMMON_CODE_LIST, inDoc);
      if (bIsDebugEnabled) {
        logger
            .debug("KohlsReturnRefund.callGetCommonCodeList Output:" + XMLUtil.getXMLString(inDoc));
      }
    } catch (Exception e) {
      logger.error("Exception occurred while calling getCommonCodeList API:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.callGetCommonCodeList");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callGetCommonCodeList - End");
    }
    logger.endTimer("KohlsReturnRefund.callGetCommonCodeList");
    return inDoc;

  }

  /**
   * This method forms input for the change Order for Corporate Refund
   * 
   * @param env
   * @param inDoc
   * @return
   */
  private Document inputToChangeOrderCorporateRefund(Document inDoc,
      Document docGetCommonCodeListOutput) {
    logger.beginTimer("KohlsReturnRefund.inputToChangeOrderCorporateRefund");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToChangeOrderCorporateRefund - Begin");
      logger.debug(
          "KohlsReturnRefund.inputToChangeOrderCorporateRefund inDoc=" + XMLUtil.getXMLString(inDoc)
              + "  docGetCommonCodeListOutput=" + XMLUtil.getXMLString(docGetCommonCodeListOutput));
    }
    Document docChangeOrderCorparateRefundInput = null;
    String strReasonCode = null;
    try {
      // Get CodeValue w.r.t CodeDescription
      strReasonCode = getUpdatedCommonCode(docGetCommonCodeListOutput);
      Element inDocOrder = inDoc.getDocumentElement();
      // MAD-287 Start
      addEndpointToElement(inDocOrder);
      // MAD-287 End
      Element inDocPaymentMethod = SCXmlUtil.getXpathElement(inDocOrder,
          "PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
      docChangeOrderCorparateRefundInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
      Element eleOrderChangeOrderCorparateRefundInput =
          docChangeOrderCorparateRefundInput.getDocumentElement();
      eleOrderChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
          inDocOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
      eleOrderChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_OVERRIDE,
          KohlsPOCConstant.FLAG_Y);
      Element eleOrderExtnChangeOrderCorparateRefundInput =
          XMLUtil.createChild(eleOrderChangeOrderCorparateRefundInput, KohlsXMLLiterals.E_EXTN);
      eleOrderExtnChangeOrderCorparateRefundInput.setAttribute("ExtnDLForSys",  inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
      eleOrderExtnChangeOrderCorparateRefundInput.setAttribute("ExtnDLNumberFormat",  inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
      
      String strExtnEmailAddress = inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
      if (!YFCCommon.isStringVoid(strExtnEmailAddress)) {
        eleOrderExtnChangeOrderCorparateRefundInput
            .setAttribute(KohlsXMLLiterals.A_EXTN_EMAIL_ADDRESS, strExtnEmailAddress);
      }
      String strLoyaltyCardNo =
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_LOYALITY_CARD_NO);
      if ((!YFCCommon.isStringVoid(strLoyaltyCardNo))) {
        eleOrderExtnChangeOrderCorparateRefundInput
            .setAttribute(KohlsXMLLiterals.A_EXTN_CUSTOMER_LOYALCARD, strLoyaltyCardNo);
      }
      if (!YFCCommon.isStringVoid(strReasonCode)) {
        eleOrderExtnChangeOrderCorparateRefundInput
            .setAttribute(KohlsXMLLiterals.A_EXTN_REASON_CODE, strReasonCode);
      }
      Element eleOrderPerChangeOrderCorparateRefundInput = XMLUtil.createChild(
          eleOrderChangeOrderCorparateRefundInput, KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_ADD_LINE_1,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS).toUpperCase());
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_ADD_LINE_2,
          inDocPaymentMethod.getAttribute("StreetAddressLine2").toUpperCase());
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_ADD_LINE_3,
          KohlsPOCConstant.BLANK);
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_ADD_LINE_4,
          KohlsPOCConstant.BLANK);
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_CITY,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_CITY).toUpperCase());
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_COUNTRY,
          KohlsPOCConstant.BLANK);
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_DAY_PHONE,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
      if (!YFCCommon.isStringVoid(strExtnEmailAddress)) {
        eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_EMAIL_ID,
            strExtnEmailAddress);
      }
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_FIRST_NAME,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_FIRST_NAME).toUpperCase());
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_LAST_NAME,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_LAST_NAME).toUpperCase());
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_MOBILE_PHONE,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_STATE,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STATE).toUpperCase().toUpperCase());
      eleOrderPerChangeOrderCorparateRefundInput.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
      Element eleOrderPerExtnChangeOrderCorparateRefundInput =
          XMLUtil.createChild(eleOrderPerChangeOrderCorparateRefundInput, KohlsXMLLiterals.E_EXTN);
      eleOrderPerExtnChangeOrderCorparateRefundInput.setAttribute(
          KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE,
          inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
    } catch (Exception e) {
      logger.error(
          "Exception occurred in inputToChangeOrderCorporateRefund method:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.inputToChangeOrderCorporateRefund");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToChangeOrderCorporateRefund docOutput="
          + XMLUtil.getXMLString(docChangeOrderCorparateRefundInput));
    }
    logger.endTimer("KohlsReturnRefund.inputToChangeOrderCorporateRefund");
    return docChangeOrderCorparateRefundInput;
  }

  /**
   * 
   * Updates the capturePayment api Input with Information to be populated at PersonInfoBillTo
   * Element
   * 
   * @param inDocGravity
   * @param outUpdateInputToCapturePayment
   * @return
   */
  private Document updateCapWithPersonInfo(Document inDocGravity,
      Document outUpdateInputToCapturePayment, String sExtnPOCFeature) {
    logger.beginTimer("KohlsReturnRefund.updateCapWithPersonInfo");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.updateCapWithPersonInfo -- Start");
      logger.debug("KohlsReturnRefund.updateCapWithPersonInfo inDocGravity="
          + XMLUtil.getXMLString(inDocGravity) + " outUpdateInputToCapturePayment="
          + XMLUtil.getXMLString(outUpdateInputToCapturePayment));
    }
    try {
      Element inDocOrder = inDocGravity.getDocumentElement();
      Element inDocCapturePaymentMethod = null;
      Element inDocPaymentMethod = SCXmlUtil.getXpathElement(inDocOrder,
          "PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
      Element inDocCapturePayment = outUpdateInputToCapturePayment.getDocumentElement();

      inDocCapturePaymentMethod = SCXmlUtil.getXpathElement(inDocCapturePayment,
          "PaymentMethod[@PaymentType='CORPORATE_REFUND']");

      if ((!YFCCommon.isVoid(inDocCapturePaymentMethod))
          && (!YFCCommon.isVoid(inDocPaymentMethod))) {
        Element eleInDocCapturePersonInfoBillTo =
            XMLUtil.createChild(inDocCapturePaymentMethod, KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
        String strExtnEmailAddress = inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_1,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS).toUpperCase());
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_2,
                 inDocPaymentMethod.getAttribute("StreetAddressLine2").toUpperCase());
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_3,
            KohlsPOCConstant.BLANK);
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_4,
            KohlsPOCConstant.BLANK);
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_CITY,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_CITY).toUpperCase());
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_COUNTRY,
            KohlsPOCConstant.BLANK);
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_DAY_PHONE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
        if (!YFCCommon.isStringVoid(strExtnEmailAddress)) {
          eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_EMAIL_ID,
              strExtnEmailAddress);
        }
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_FIRST_NAME,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_FIRST_NAME).toUpperCase());
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_LAST_NAME,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_LAST_NAME).toUpperCase());
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_MOBILE_PHONE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_STATE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STATE).toUpperCase());
        eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
        Element eleInDocCapturePersonInfoBillToExtn =
            XMLUtil.createChild(eleInDocCapturePersonInfoBillTo, KohlsXMLLiterals.E_EXTN);
        eleInDocCapturePersonInfoBillToExtn.setAttribute(KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
        bIsCorpRefund = true;
      }
    } catch (Exception e) {
      logger.error("Exception in the updateCapWithPersonInfo Method:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.updateCapWithPersonInfo");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.updateCapWithPersonInfo outDoc="
          + XMLUtil.getXMLString(outUpdateInputToCapturePayment));
      logger.debug("KohlsReturnRefund.updateCapWithPersonInfo -- End");
    }
    logger.endTimer("KohlsReturnRefund.updateCapWithPersonInfo");
    return outUpdateInputToCapturePayment;
  }

  private Document updatePOWithPersonInfo(Document inDocGravity,
      Document outUpdateInputToPOPaymentPayment) {
    if (bIsDebugEnabled) {
      logger.debug("KohlsPoCReturnRefund.updateCapWithPersonInfo -- Start");
      logger.debug("KohlsPoCReturnRefund.updateCapWithPersonInfo inDocGravity="
          + XMLUtil.getXMLString(inDocGravity) + " outUpdateInputToPOPaymentPayment="
          + XMLUtil.getXMLString(outUpdateInputToPOPaymentPayment));
    }
    try {
      Element inDocOrder = inDocGravity.getDocumentElement();
      Element inDocPaymentMethod = SCXmlUtil.getXpathElement(inDocOrder,
          "PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
      Element inDocPOPayment = outUpdateInputToPOPaymentPayment.getDocumentElement();
      Element inDocPOPaymentMethod = SCXmlUtil.getXpathElement(inDocPOPayment,
          "PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
      if ((!YFCCommon.isVoid(inDocPOPaymentMethod)) && (!YFCCommon.isVoid(inDocPaymentMethod))) {
        Element eleInDocPOPersonInfoBillTo =
            XMLUtil.createChild(inDocPOPaymentMethod, KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
        String strExtnEmailAddress = inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_1,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS));
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_2,
                 inDocPaymentMethod.getAttribute("StreetAddressLine2").toUpperCase());
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_3,
            KohlsPOCConstant.BLANK);
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_4,
            KohlsPOCConstant.BLANK);
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_CITY,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_CITY));
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_COUNTRY, KohlsPOCConstant.BLANK);
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_DAY_PHONE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
        if (!YFCCommon.isStringVoid(strExtnEmailAddress)) {
          eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_EMAIL_ID, strExtnEmailAddress);
        }
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_FIRST_NAME,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_FIRST_NAME));
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_LAST_NAME,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_LAST_NAME));
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_MOBILE_PHONE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_STATE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STATE));
        eleInDocPOPersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
        Element eleInDocPOPersonInfoBillToExtn =
            XMLUtil.createChild(eleInDocPOPersonInfoBillTo, KohlsXMLLiterals.E_EXTN);
        eleInDocPOPersonInfoBillToExtn.setAttribute(KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE,
            inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
        bIsCorpRefund = true;
      }
    } catch (Exception e) {
      logger.error("Exception in the updateCapWithPersonInfo Method:" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsPoCReturnRefund.updateCapWithPersonInfo outDoc="
          + XMLUtil.getXMLString(outUpdateInputToPOPaymentPayment));
      logger.debug("KohlsPoCReturnRefund.updateCapWithPersonInfo -- End");
    }
    return outUpdateInputToPOPaymentPayment;
  }

  /**
   * This method prepares input to executeCollection API
   * 
   * @param env
   * @param strOrderHeaderkey
   * @return
   * @throws ParserConfigurationException
   */
  protected Document inputToExecuteCollection(String strOrderHeaderkey)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.inputToExecuteCollection");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToExecuteCollection - Begin");
    }
    Document docExecuteCollectionInput =
        XMLUtil.createDocument(KohlsXMLLiterals.E_EXECUTECOLLECTION);
    Element eleExecuteCollectionInput = docExecuteCollectionInput.getDocumentElement();
    if (!YFCCommon.isVoid(strOrderHeaderkey)) {
      eleExecuteCollectionInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
          strOrderHeaderkey);
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToExecuteCollection Output:"
          + XMLUtil.getXMLString(docExecuteCollectionInput));
      logger.debug("KohlsReturnRefund.inputToExecuteCollection - End");
    }
    logger.endTimer("KohlsReturnRefund.inputToExecuteCollection");
    return docExecuteCollectionInput;
  }

  /**
   * This method calls executeCollectionService
   * 
   * @param env
   * @param inDoc
   * @return
   */
  @SuppressWarnings("unused")
  protected Document callExecuteCollectionAPI(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callExecuteCollectionAPI");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callExecuteCollectionAPI - Begin");
      logger.debug("KohlsReturnRefund.callExecuteCollectionAPI InputDocument:"
          + XMLUtil.getXMLString(inDoc));
    }
    try {
      Document outDoc =
          KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SER_EXECUTE_COLLECTION_PSA, inDoc);
    } catch (Exception e) {
      logger.error("Exception occurred while calling ExecuteCollection API:");
      logger.endTimer("KohlsReturnRefund.callExecuteCollectionAPI");
    }
    logger.endTimer("KohlsReturnRefund.callExecuteCollectionAPI");
    return inDoc;
  }

  /**
   * This method invokes capturePaymentAPI
   * 
   * @param env
   * @param inDoc
   * @return
   */

  /**
   * This method prepares the input skeleton input to capturePayment API
   * 
   * @param env
   * @param inDoc
   * @return
   * @throws ParserConfigurationException
   */
  @SuppressWarnings("unchecked")

  /**
   * This method updates the capturePayment Input
   * 
   * @param env
   * @param inDoc
   * @param docCapturePaymentInput
   * @return
   */

  /**
   * This method prepares an input to getPaymentList API
   * 
   * @param env
   * @param strOrderHeaderkey
   * @return
   * @throws ParserConfigurationException
   */
  private Document inputToGetPaymentList(String strOrderHeaderkey)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.inputToGetPaymentList");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToGetPaymentList - Begin");
    }
    Document docGetPaymentListInput = XMLUtil.createDocument(KohlsXMLLiterals.E_PAYMENT);
    Element eleGetPaymentListInput = docGetPaymentListInput.getDocumentElement();
    if (!YFCCommon.isVoid(strOrderHeaderkey)) {
      eleGetPaymentListInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
      // MAD-287 Start
      addEndpointToElement(eleGetPaymentListInput);
      // MAD-287 End
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToGetPaymentList Output:"
          + XMLUtil.getXMLString(docGetPaymentListInput));
      logger.debug("KohlsReturnRefund.inputToGetPaymentList - End");
    }
    logger.endTimer("KohlsReturnRefund.inputToGetPaymentList");
    return docGetPaymentListInput;
  }

  /**
   * This method makes a getPaymentList API call
   * 
   * @param env
   * @param inDoc
   * @return
   */
  protected Document callgetPaymentList(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callgetPaymentList");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callgetPaymentList - Begin");
      logger.debug(
          "KohlsReturnRefund.callgetPaymentList InputDocument:" + XMLUtil.getXMLString(inDoc));
    }
    try {
      Document docGetPaymentListOutTemp = XMLUtil.getDocument(KohlsXMLLiterals.TEMP_GET_PAY_LIST);
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.callgetPaymentList docGetPaymentListOutTemp="
            + XMLUtil.getXMLString(docGetPaymentListOutTemp));
      }
      inDoc = KOHLSBaseApi.invokeAPI(env, docGetPaymentListOutTemp,
          KohlsXMLLiterals.API_GET_PAYMENT_LIST, inDoc);
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.callgetPaymentList Output:" + XMLUtil.getXMLString(inDoc));
      }
    } catch (Exception e) {
      logger.error("Exception occurred while calling getPaymentList API:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.callgetPaymentList");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callgetPaymentList - End");
    }
    logger.endTimer("KohlsReturnRefund.callgetPaymentList");
    return inDoc;
  }

  /**
   * This method makes a voidChargeTransaction API call
   * 
   * @param env
   * @param inDoc
   * @return
   */
  protected Document callvoidChargeTransaction(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callvoidChargeTransaction");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callvoidChargeTransaction - Begin");
      logger.debug("KohlsReturnRefund.callvoidChargeTransaction InputDocument:"
          + XMLUtil.getXMLString(inDoc));
    }
    try {
      inDoc = KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.API_VOID_CHARGE_TRANSACTION, inDoc);
      if (bIsDebugEnabled) {
        logger.debug(
            "KohlsReturnRefund.callvoidChargeTransaction Output:" + XMLUtil.getXMLString(inDoc));
      }
    } catch (Exception e) {
      logger.error("Exception occurred while calling voidChargeTransaction API:" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug(
          "KohlsReturnRefund.callvoidChargeTransaction Output:" + XMLUtil.getXMLString(inDoc));
      logger.debug("KohlsReturnRefund.callvoidChargeTransaction - End");
    }
    logger.endTimer("KohlsReturnRefund.callvoidChargeTransaction");
    return inDoc;
  }

  /**
   * This methods forms the input for voidTransactionAPI
   * 
   * @param env
   * @param inList
   * @param docCallGetChargeTransactionListOutput
   * @return
   * @throws ParserConfigurationException
   */
  protected Document voidChargeTransactioninDoc(List<String> inList)
      throws ParserConfigurationException

  {
    logger.beginTimer("KohlsReturnRefund.voidChargeTransactioninDoc");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.voidChargeTransactioninDoc - Begin");
    }
    Document inDocvoidChargeTransactionAPI =
        XMLUtil.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAILS);
    Element eleChargeTrasactionDetails = inDocvoidChargeTransactionAPI.getDocumentElement();
    for (int j = 0; j < inList.size(); j++) {
      Element eleChargeTrasactionDetail = XMLUtil.createChild(eleChargeTrasactionDetails,
          KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
      eleChargeTrasactionDetail.setAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY,
          inList.get(j));
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.voidChargeTransactioninDoc inDoc="
          + XMLUtil.getXMLString(inDocvoidChargeTransactionAPI));
    }
    logger.endTimer("KohlsReturnRefund.voidChargeTransactioninDoc");
    return inDocvoidChargeTransactionAPI;
  }

  // MAD-287 - Start
  /**
   * check isEdge deployment and setting the document with endpoint
   */
  public void addEndpointToElement(Element finalEle) throws ParserConfigurationException

  {
    logger.debug("Before Adding edge ::" + ServerTypeHelper.amIOnEdgeServer());
    if (ServerTypeHelper.amIOnEdgeServer()) {
      Element eleAdditionalInfo =
          SCXmlUtil.createChild(finalEle, KohlsXMLLiterals.E_YFCADDITIONALINFO);
      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endpoint);
    }
    logger.debug("Before Adding edge ::" + XMLUtil.getElementXMLString(finalEle));

  }

  // MAD-287 - End
  /**
   * This method saves the chargeTransactionKeys to an arrayList
   * 
   * @param env
   * @param docChargeTransactionDetailsOut
   * @return
   */
  @SuppressWarnings("unchecked")
  protected List<String> getChargeTransactionKeys(Document docChargeTransactionDetailsOut) {
    logger.beginTimer("KohlsReturnRefund.getChargeTransactionKeys");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getChargeTransactionkeys - Begin");
      logger.debug("KohlsReturnRefund.getChargeTransactionKeys InputDocument:"
          + XMLUtil.getXMLString(docChargeTransactionDetailsOut));
    }
    List<String> chargeTrnsactionKeys = new ArrayList<String>();
    try {
      Element eleChargeTransactionDetails = docChargeTransactionDetailsOut.getDocumentElement();
      List<Element> eleChargeTransactionDetailList = XMLUtil.getElementsByTagName(
          eleChargeTransactionDetails, KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
      if (eleChargeTransactionDetailList.size() > KohlsPOCConstant.ZERO_INT) {
        for (Element eleChargeTransactionDetail : eleChargeTransactionDetailList) {
          String strChargeTransactionKey =
              eleChargeTransactionDetail.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY);
          if (!YFCCommon.isVoid(strChargeTransactionKey)) {
            chargeTrnsactionKeys.add(strChargeTransactionKey);
            if (bIsDebugEnabled) {
              logger.debug("ChargeTransactionKey:" + strChargeTransactionKey);
            }
          }
        }
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.getChargeTransactionkeys Exception" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.getChargeTransactionKeys");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getChargeTransactionkeys - End");
    }
    logger.endTimer("KohlsReturnRefund.getChargeTransactionKeys");
    return chargeTrnsactionKeys;
  }

  /**
   * This method invokes getChargeTransactionList API
   * 
   * @param env
   * @param inDoc
   * @return
   */
  protected Document callGetChargeTransactionListAPI(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callGetChargeTransactionListAPI");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callGetChargeTransactionListAPI -- Start");
    }
    try {
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.callGetChargeTransactionListAPI inDoc="
            + XMLUtil.getXMLString(inDoc));
      }
      inDoc = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, inDoc);
      if (!YFCCommon.isVoid(inDoc)) {
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.callGetChargeTransactionListAPI docOutput="
              + XMLUtil.getXMLString(inDoc));
        }
      }
    } catch (Exception e) {
      logger
          .error("Exception occurred while calling getChargeTrasactionList API:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.callGetChargeTransactionListAPI");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callGetChargeTransactionListAPI Output:"
          + XMLUtil.getXMLString(inDoc));
      logger.debug("KohlsReturnRefund.callGetChargeTransactionListAPI -- End");
    }
    logger.endTimer("KohlsReturnRefund.callGetChargeTransactionListAPI");
    return inDoc;
  }

  /**
   * This method prepares input for getChargeTransactionList API
   * 
   * @param strOrderHeaderKey
   * @return
   * @throws ParserConfigurationException
   */
  protected Document inputToGetChargeTransactionList(String strOrderHeaderKey)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.inputToGetChargeTransactionList");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToGetChargeTransactionList - Begin");
    }
    Document docGetChargeTransactionListInput =
        XMLUtil.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
    Element eleChargeTransactionListInput = docGetChargeTransactionListInput.getDocumentElement();
    if (!YFCCommon.isVoid(strOrderHeaderKey)) {
      eleChargeTransactionListInput.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE,
          KohlsXMLLiterals.CONST_CHARGE);
      eleChargeTransactionListInput.setAttribute(KohlsXMLLiterals.A_STATUS,
          KohlsXMLLiterals.ATTR_OPEN);
      eleChargeTransactionListInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
          strOrderHeaderKey);
      // MAD-287 - Start
      addEndpointToElement(eleChargeTransactionListInput);
      // MAD-287 - End
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToGetChargeTransactionList Output:"
          + XMLUtil.getXMLString(docGetChargeTransactionListInput));
      logger.debug("KohlsReturnRefund.inputToGetChargeTransactionList - End");
    }
    logger.endTimer("KohlsReturnRefund.inputToGetChargeTransactionList");
    return docGetChargeTransactionListInput;
  }

  /**
   * This method calls request collection Service
   * 
   * @param env
   * @param inDoc
   * @return
   */
  protected Document callRequestCollectionAPI(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callRequestCollectionAPI");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callRequestCollectionAPI --Start");
      logger.debug("KohlsReturnRefund.callRequestCollectionAPI InputDocument:"
          + XMLUtil.getXMLString(inDoc));
    }
    try {
      inDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SER_REQUEST_COLLECTION_PSA, inDoc);
      if (bIsDebugEnabled) {
        logger.debug(
            "KohlsReturnRefund.callRequestCollectionAPI docOutput=" + XMLUtil.getXMLString(inDoc));
      }
    } catch (Exception e) {
      logger.error("Exception occurred while calling requestCollection API:" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.callRequestCollectionAPI");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callRequestCollectionAPI --End");
    }
    logger.endTimer("KohlsReturnRefund.callRequestCollectionAPI");
    return inDoc;
  }

  /**
   * This method prepares input to PSAGetOrderList service
   * 
   * @param env
   * @param strOrderHeaderkey
   * @return
   * @throws ParserConfigurationException
   */
  private Document inputToPSAGetOrderList(String strOrderHeaderkey, String sExtnPOCFeature)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.inputToPSAGetOrderList");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToPSAGetOrderList - Begin");
    }
    Document docPSAGetOrderListInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    Element elePSAGetOrderListInput = docPSAGetOrderListInput.getDocumentElement();
    if (!YFCCommon.isVoid(strOrderHeaderkey)) {

      elePSAGetOrderListInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
      // MAD-287 Start
      if (ServerTypeHelper.amIOnEdgeServer()) {
        Element eleAdditionalInfo =
            SCXmlUtil.createChild(elePSAGetOrderListInput, KohlsXMLLiterals.E_YFCADDITIONALINFO);
        if (!YFCCommon.isVoid(sExtnPOCFeature)
            && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
          eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
              KohlsXMLLiterals.V_MOTHERSHIP);
        } else {
         
                  eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
                          "LOCAL");
        }

      }
      // MAD-287 End
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToPSAGetOrderList Output:"
          + XMLUtil.getXMLString(docPSAGetOrderListInput));
      logger.debug("KohlsReturnRefund.inputToPSAGetOrderList - End");
    }
    logger.endTimer("KohlsReturnRefund.inputToPSAGetOrderList");
    return docPSAGetOrderListInput;

  }

  /**
   * This method calls PSAGetOrderListAPI
   * 
   * @param env
   * @param inDoc
   * @return
   */

  private Document callPSAGetOrderListAPI(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsReturnRefund.callPSAGetOrderListAPI");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callPSAGetOrderListAPI -- Start");
      logger.debug(
          "KohlsReturnRefund.callPSAGetOrderListAPI InputDocument:" + XMLUtil.getXMLString(inDoc));
    }
    try {
        Element elePSAGetOrderListInput = inDoc.getDocumentElement();
        //PST-4984 - Start
        String strOrderHeaderKey= XMLUtil.getAttribute(elePSAGetOrderListInput, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        if(!YFCCommon.isVoid(strOrderHeaderKey)){
            inDoc = KOHLSBaseApi.invokeService(env, KohlsConstant.PSA_GET_ORDER_LIST, inDoc);
        }
        //PST-4984 - End
      if (bIsDebugEnabled) {
        logger.debug(
            "KohlsReturnRefund.callPSAGetOrderListAPI docOutput=" + XMLUtil.getXMLString(inDoc));
      }
    } catch (Exception e) {
      logger.error("Exception occurred while calling PSAGetOrderList API:" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callPSAGetOrderListAPI -- End");
    }
    logger.endTimer("KohlsReturnRefund.callPSAGetOrderListAPI");
    return inDoc;
  }

  /**
   * This method prepares the input to requestCollection API
   * 
   * @param strOrderHeaderkey
   * @return
   * @throws ParserConfigurationException
   */
  protected Document inputToRequestCollection(String strOrderHeaderkey)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.inputToRequestCollection");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToRequestCollection - Begin");
    }
    Document docRequestCollectionInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    Element eleRequestCollectionInput = docRequestCollectionInput.getDocumentElement();
    if (!YFCCommon.isVoid(strOrderHeaderkey)) {
      eleRequestCollectionInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
          strOrderHeaderkey);
    }
    // MAD-287 - Start
    addEndpointToElement(eleRequestCollectionInput);
    // MAD-287 - End
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.inputToRequestCollection Input:"
          + XMLUtil.getXMLString(docRequestCollectionInput));
      logger.debug("KohlsReturnRefund.inputToRequestCollection - End");
    }
    logger.endTimer("KohlsReturnRefund.inputToRequestCollection");
    return docRequestCollectionInput;
  }

  /**
   * 
   * This method returns the OrderHeaderKey from the Gravity input
   * 
   * @param docInput
   * @return
   */
  protected String getOHKey(Document docInput) {
    logger.beginTimer("KohlsReturnRefund.getOHKey");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getOHKey -- Start");
      logger.debug("KohlsReturnRefund.getOHKey docInput=" + XMLUtil.getXMLString(docInput));
    }
    String strOHKey = null;
    try {
      Element eleOrder = docInput.getDocumentElement();
      strOHKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.getOHKey Exception=" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getOHKey strOHKey=" + strOHKey);
      logger.debug("KohlsReturnRefund.getOHKey -- End");
    }
    logger.endTimer("KohlsReturnRefund.getOHKey");
    return strOHKey;
  }

  /**
   * 
   * This method creates a new String based on Current TimeStamp
   * 
   * @return
   */
  private String getPayRef1() {
    logger.beginTimer("KohlsReturnRefund.getPayRef1");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getPayRef1 -- Start");
    }
    String strPayRef1 = null;
    try {
      strPayRef1 = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()).trim();
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.getPayRef1 strPayRef1=" + strPayRef1);
      }
    } catch (Exception e) {
      logger.error("KohlsReturnRefund.getPayRef1 Exception=" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.getPayRef1 -- End");
    }
    logger.endTimer("KohlsReturnRefund.getPayRef1");
    return strPayRef1;
  }

  /**
   * 
   * @param env
   * @param eleTxnPaymentMethod
   * @param elemOrder
   * @return Document
   * @throws Exception
   */
  private Document createPSAGCActivationRequest(YFSEnvironment env, Element eleTxnPaymentMethod,
      Element elemOrder) throws Exception {
    logger.beginTimer("KohlsReturnRefund.createPSAGCActivationRequest");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.createPSAGCActivationRequest -- Start");
      logger.debug("KohlsReturnRefund.createPSAGCActivationRequest eleTxnPaymentMethod="
          + XMLUtil.getElementXMLString(eleTxnPaymentMethod) + " elemOrder="
          + XMLUtil.getElementXMLString(elemOrder));
    }
    Document docGCActivationOutput = null;
    String sExtnDLForSys = "";
    String sDriverLicense= "";
    // forming input to web service KohlsPoCSVCPaymentWebService
    Document docInputToWebService =
        YFCDocument.createDocument(KohlsConstant.PAYMENT_REQUEST).getDocument();
    Element elePmntReq = docInputToWebService.getDocumentElement();
    Element eleTran = docInputToWebService.createElement(KohlsXMLLiterals.E_TRANSACTION);
    XMLUtil.appendChild(elePmntReq, eleTran);

    // Setting the attributes in the input xml.
    Double dAmount = new Double(eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    eleTran.setAttribute(KohlsXMLLiterals.A_TENDER_AMOUNT,
        Double.toString(Math.abs(dAmount.doubleValue())));
    Element eleExtn = (Element) elemOrder.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
    if (!YFCCommon.isVoid(eleExtn)) {
    	sExtnDLForSys= eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_DL_FOR_SYS);
    	if (!YFCCommon.isStringVoid(sExtnDLForSys)) {
    		KohlsPocInvoiceToSalesHubAPI kohlsPocInvoiceToSalesHubAPI = new KohlsPocInvoiceToSalesHubAPI();
    		sDriverLicense=kohlsPocInvoiceToSalesHubAPI.convertDL(sExtnDLForSys);
    	}
    }
   
    if (!YFCCommon.isStringVoid(sDriverLicense)) {
    	eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE, sDriverLicense);
    }
    else {
    	eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE, KohlsConstant.PSA_DRIVERS_LICENSE_NUM);	
    }
    eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE, KohlsConstant.ACTIVATION);

    eleTran.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, KohlsXMLLiterals.ATTR_MERC_RETURN_CREDIT);
    String sEntryMethod = eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.ATTR_ENTRY_METHOD);

    if (!YFCCommon.isStringVoid(sEntryMethod)) {
      logger.debug("KMC Entry from Gravity" + sEntryMethod);
      strKMCEntryMethod = sEntryMethod;
      if (KohlsConstant.KEYED.equalsIgnoreCase(sEntryMethod)) {
        eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method, KohlsConstant.KEYED);
      } else {
        eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method, KohlsConstant.BARCODE);
      }
    }
    // Has to be removed once Gravity implements Sending Entry method for
    // all scenarios -- Start
    else {
      eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method, KohlsConstant.BARCODE);
    }
    // Has to be removed once Gravity implements Sending Entry method for
    // all scenarios -- End
    // eleTran.setAttribute("Protected", props.getProperty("Protected"));
    String storeNo = eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.ATTR_STORE_NUM);
    // String prepadStroNo=KohlsPoCPnPUtil.prepadStoreNoWithZeros(storeNo);
    eleTran.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER, storeNo);
    eleTran.setAttribute(KohlsXMLLiterals.A_REGISTER_NUMBER,
        elemOrder.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
    eleTran.setAttribute(KohlsXMLLiterals.A_SVCNO,
        eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_SVCNo));
    
    String sOperatorID = elemOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID);
	if(!YFCCommon.isStringVoid(sOperatorID) && !sOperatorID.matches("[0-9]+")) {
		String numericOperatorID = sOperatorID.replaceAll("[A-Za-z]", "9");
		logger.debug("KohlsReturnRefund.createPSAGCActivationRequest numericOperatorID is  :" + numericOperatorID + " and sOperatorID is " + sOperatorID);
		sOperatorID = numericOperatorID;
	}
    eleTran.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
        sOperatorID);
    eleTran.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,
        elemOrder.getAttribute(KohlsConstant.POS_SEQUENCE_NO));

    if (bIsDebugEnabled) {
      logger.debug("Input to call KohlsPoCSVCPaymentWebService::"
          + XMLUtil.getXMLString(docInputToWebService));
    }
    try {
      long start = System.currentTimeMillis();
      docGCActivationOutput =
          KOHLSBaseApi.invokeService(env, KohlsXMLLiterals.SER_KOHLS_POC_SVC, docInputToWebService);
      long end = System.currentTimeMillis();
      timeTaken = end - start;
    } catch (Exception e) {
      logger.error("Exception while calling PSA KohlsPoCSVCPaymentWebService" + e.getMessage());
      logger.endTimer("KohlsReturnRefund.createPSAGCActivationRequest");
      // CAPE-563 b commented by sandya
      bIsKMCError = true;
      // throw new YFSException("KMC_ERROR", "KMC_ERROR",
      // "KMC Service is not available");
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.createPSAGCActivationRequest docGCActivationOutput="
          + XMLUtil.getXMLString(docGCActivationOutput));
      logger.debug("KohlsReturnRefund.createPSAGCActivationRequest -- End");
    }
    logger.endTimer("KohlsReturnRefund.createPSAGCActivationRequest");
    return docGCActivationOutput;

  }

  /**
   * This method forms a skeleton input to recordExternalCharges with generic items
   * 
   * @param docInXMLClone2
   * 
   * @return
   * @throws ParserConfigurationException
   */
  private Document formInputSklToRecordExternalCharges(String sExtnPOCFeature)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnRefund.formInputSklToRecordExternalCharges");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.formInputSklToRecordExternalCharges - Begin");
    }
    Document docSklToRecordExternalCharges = null;
    try {
      docSklToRecordExternalCharges =
          XMLUtil.createDocument(KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES);
      Element eleRecordExternalCharges = docSklToRecordExternalCharges.getDocumentElement();
      Element elePaymentMethod =
          XMLUtil.createChild(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
      elePaymentMethod.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION, KohlsXMLLiterals.CONST_Y);
      elePaymentMethod.setAttribute(KohlsXMLLiterals.A_OPERATION, KohlsXMLLiterals.CONST_MANAGE);
      if (!YFCCommon.isVoid(sExtnPOCFeature)) {
        if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
          elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6, "PA");
        } else if (("ReceiptedReturn".equalsIgnoreCase(sExtnPOCFeature))
            || ("NonReceiptedReturn".equalsIgnoreCase(sExtnPOCFeature))) {
          elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6, "RETURNS");
        } else {
          elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6,
              KohlsXMLLiterals.CONST_PSA);
        }
      }
      elePaymentMethod.setAttribute(KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS,
          KohlsXMLLiterals.CONST_Y);
      // MAD-287 Start
      addEndpointToElement(eleRecordExternalCharges);
      // MAD-287 End
      String sPayRef1 = getPayRef1();
      elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, sPayRef1);
      elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2, KohlsPOCConstant.NO);
      String sBusinessDay = mPSAId.get(KohlsPOCConstant.ATTR_BUSINESS_DAY);
      if (!YFCCommon.isStringVoid(sBusinessDay)) {
        if (bIsDebugEnabled) {
          logger.debug(
              "KohlsReturnRefund.formInputSklToRecordExternalCharges sBusinessDay=" + sBusinessDay);
        }
        elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, sBusinessDay);
      }
      String sOperatorID = mPSAId.get(KohlsPOCConstant.A_OPERATOR_ID);
      if (!YFCCommon.isStringVoid(sOperatorID)) {
        if (bIsDebugEnabled) {
          logger.debug(
              "KohlsReturnRefund.formInputSklToRecordExternalCharges sOperatorID=" + sOperatorID);
        }
        elePaymentMethod.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, sOperatorID);
      }
      String sTerminalID = mPSAId.get(KohlsPOCConstant.ATTR_TERMINAL_ID);
      if (!YFCCommon.isStringVoid(sTerminalID)) {
        if (bIsDebugEnabled) {
          logger.debug(
              "KohlsReturnRefund.formInputSklToRecordExternalCharges sTerminalID=" + sTerminalID);
        }
        elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
      }
      String sTillID = mPSAId.get(KohlsPOCConstant.ATTR_TILL_ID);
      if (!YFCCommon.isStringVoid(sTillID)) {
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.formInputSklToRecordExternalCharges sTillID=" + sTillID);
        }
        elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, sTillID);
      }
      String sStoreID = mPSAId.get(KohlsPOCConstant.ATTR_STORE_ID);
      if (!YFCCommon.isStringVoid(sStoreID)) {
        if (bIsDebugEnabled) {
          logger
              .debug("KohlsReturnRefund.formInputSklToRecordExternalCharges sStoreID=" + sStoreID);
        }
        elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sStoreID);
      }
      String sDrawerID = mPSAId.get(KohlsPOCConstant.ATTR_DRAWER_ID);
      if (!YFCCommon.isStringVoid(sDrawerID)) {
        if (bIsDebugEnabled) {
          logger.debug(
              "KohlsReturnRefund.formInputSklToRecordExternalCharges sDrawerID=" + sDrawerID);
        }
        elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, sDrawerID);
      }
      Element elePaymentDetailsList =
          XMLUtil.createChild(elePaymentMethod, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
      Element elePaymentDetails =
          XMLUtil.createChild(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
      elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE, KohlsXMLLiterals.CONST_CHARGE);

      elePaymentDetails.setAttribute("Status", "CHECKED");

      elePaymentDetails.setAttribute(KohlsXMLLiterals.A_IN_PERSON, KohlsXMLLiterals.CONST_Y);
      elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_PROCESSED,
          KohlsXMLLiterals.CONST_Y);
      if (bIsDebugEnabled) {
        logger.debug("KohlsReturnRefund.formInputSklToRecordExternalCharges Output:"
            + XMLUtil.getXMLString(docSklToRecordExternalCharges));
        logger.debug("KohlsReturnRefund.formInputSklToRecordExternalCharges - End");
      }
    } catch (Exception e) {
      logger.error(
          "KohlsReturnRefund.formInputSklToRecordExternalCharges Exception " + e.getMessage());
    }
    logger.endTimer("KohlsReturnRefund.formInputSklToRecordExternalCharges");
    return docSklToRecordExternalCharges;

  }

  /**
   * This method makes a recordExternalCharges API call
   * 
   * @param env
   * @param inDoc
   * @return
   */
  protected Document callRecordExternalPayments(YFSEnvironment env, Document inDoc,
      String sExtnPOCFeature) {
    logger.beginTimer("KohlsReturnRefund.callRecordExternalPayments");

    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callRecordExternalPayments - Begin");
      logger.debug("KohlsReturnRefund.callRecordExternalPayments InputDocument:"
          + XMLUtil.getXMLString(inDoc));
    }
    try {

      // CAPE - 2755 - ISS PA Happy Path - Start - Murali K
      if (ServerTypeHelper.amIOnEdgeServer()
          && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {

        Element eleYfcAdditionalInfo = XMLUtil.getChildElement(inDoc.getDocumentElement(),
            KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
        if (!YFCCommon.isVoid(eleYfcAdditionalInfo)) {
          inDoc.getDocumentElement().removeChild(eleYfcAdditionalInfo);
        }

        eleYfcAdditionalInfo =
            XMLUtil.createChild(inDoc.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
        eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT,
            KohlsPOCConstant.V_MOTHERSHIP);

      }
      // CAPE - 2755 - ISS PA Happy Path - End - Murali K

      inDoc = KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES, inDoc);

      if (!YFCCommon.isVoid(inDoc)) {
        if (bIsDebugEnabled) {
          logger.debug(
              "KohlsReturnRefund.callPSAGetOrderListAPI Output:" + XMLUtil.getXMLString(inDoc));
        }
      }
    } catch (Exception e) {
      logger.error(
          "Exception occurred while calling callRecordExternalPayments API:" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.callRecordExternalPayments - End");
    }
    logger.endTimer("KohlsReturnRefund.callRecordExternalPayments");
    return inDoc;
  }

  /**
   * This method updates the outDoc of formInputSklToRecordExternalCharges according to the payment
   * type obtained from gravity
   * 
   * @param elePaymentMethod
   * @param outDocformInputSklToRecordExternalCharges
   * @param strOrderHeaderKey
   * @param getPaymentListOutDoc
   * @param mapKMCValues
   * @return
   */

  private Document updatesklRecordExternalCharges(Element elePaymentMethod,
      Document docpinpadResponse, Document outDocformInputSklToRecordExternalCharges,
      String strOrderHeaderKey, Document getPaymentListOutDoc, Map<String, String> mapKMCValues,
      String sExtnPOCFeature, YFSEnvironment env) {
    logger.beginTimer("KohlsReturnRefund.updatesklRecordExternalCharges");
    try {
      String strPaymentType = null;
      String strCreditCardTypeNo = null;
      String strCreditCardType = null;
      String sCTRoutOutput = "";
      String sAuthCode = "000000";
      Element responseElement = null;
      Element ctroutdElement = null;
      Element eleAuthCode = null;

      if (bIsDebugEnabled) {
        logger.debug(
            "KohlsReturnRefund.updatesklRecordExternalCharges formInputSklToRecordExternalCharges outDoc="
                + XMLUtil.getXMLString(outDocformInputSklToRecordExternalCharges));
        logger.debug(
            "KohlsReturnRefund.updatesklRecordExternalCharges paymentMethod element from gravity="
                + XMLUtil.getElementXMLString(elePaymentMethod));
        logger.debug(
            "KohlsReturnRefund.updatesklRecordExternalCharges OrderHeaderKey=" + strOrderHeaderKey);
        logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges  PaymentList outDoc="
            + XMLUtil.getXMLString(getPaymentListOutDoc));
      }
      Element elePaymentMethodExtn =
          (Element) elePaymentMethod.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
      if (!YFCCommon.isVoid(docpinpadResponse)) {
        responseElement = docpinpadResponse.getDocumentElement();
        ctroutdElement = SCXmlUtil.getChildElement(responseElement, "CTROUTD");
        eleAuthCode = SCXmlUtil.getChildElement(responseElement, "AUTH_CODE");
        if (!YFCCommon.isVoid(ctroutdElement)) {
          sCTRoutOutput = ctroutdElement.getTextContent();
        }
        if (!YFCCommon.isVoid(eleAuthCode)) {
          sAuthCode = eleAuthCode.getTextContent();
        }
      }

      Element eleRecordExternalCharges =
          outDocformInputSklToRecordExternalCharges.getDocumentElement();

      strPaymentType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
      eleRecordExternalCharges.setAttribute("OrganizationCode",
          elePaymentMethod.getAttribute("StoreID"));
      eleRecordExternalCharges.setAttribute("StoreID", elePaymentMethod.getAttribute("StoreID"));
      eleRecordExternalCharges.setAttribute("TerminalID",
          elePaymentMethod.getAttribute("TerminalID"));

      // CAPE-968 -- Start
      Element elePaymentMeth =
          SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
      Element elePaymentMethExtn = XMLUtil.getChildElement(elePaymentMeth, KohlsPOCConstant.E_EXTN);

      if (!YFCCommon.isVoid(elePaymentMethExtn)) {
        elePaymentMeth.removeChild(elePaymentMethExtn);
      }

      // CAPE-968 -- End

      if (strPaymentType.equalsIgnoreCase("CASH")) {

        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);
        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);

        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        String strPayRef1 = getPayRef1();
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
        String strRequestedAmount =
            "-".concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

        elePaymentMethod1.setAttribute("ChangeDue",
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        elePaymentMethod1.setAttribute("TotalRefundedAmount",
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);

        if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
          eleExtn.setAttribute("ExtnPaymentDetails",
              elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
        }
        if (bIsDebugEnabled) {
          logger.debug("KohlsPoCReturnRefund.updatesklRecordExternalCharges Cash");
        }

      }

      if (strPaymentType.equalsIgnoreCase("CORPORATE_REFUND")) {
        if (bIsDebugEnabled) {
          logger.debug("KohlsPoCReturnRefund.updatesklRecordExternalCharges corporated refund");
        }
        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);
        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        String strPayRef1 = getPayRef1();
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
        String strRequestedAmount =
            "-".concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

        elePaymentMethod1.setAttribute("TotalRefundedAmount",
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        Element eleKohlsPaymentList =
            (Element) elePaymentMethod1.getElementsByTagName("KohlsPaymentList").item(0);
        Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
        if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
          eleExtn.setAttribute("ExtnPaymentDetails",
              elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
        }
        // Changes For Person Info Bill To
        outDocformInputSklToRecordExternalCharges = updateCapWithPersonInfo(docInXMLClone,
            outDocformInputSklToRecordExternalCharges, sExtnPOCFeature);

        Document docCommonCodeInput = formInputForCommonCode(docInXMLClone);
        // Call getCommonCodeList api
        Document docCommonCodeOutput = callGetCommonCodeList(env, docCommonCodeInput);
        // Prepare the input for changeOrder api
        Document docChangeOrderInput =
            inputToChangeOrderCorporateRefund(docInXMLClone, docCommonCodeOutput);
        // Call changeOrder api
        Document docChangeOrderOutput = callChangeOrder(env, docChangeOrderInput);
        if (!YFCCommon.isVoid(docChangeOrderOutput)) {
          if (bIsDebugEnabled) {
            logger.debug("KohlsReturnRefund.setFinalPSARefundTypes docChangeOrderOutput="
                + XMLUtil.getXMLString(docChangeOrderOutput));
          }
        }
        // Set the global variable to false for
        // future use
        bIsCorpRefund = false;

      }

      if (strPaymentType.equalsIgnoreCase("KOHLS_CASH")) {

        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);
        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        String strPayRef1 = getPayRef1();
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
      
       String strRequestedAmount =
                "-".concat("0.00");
            elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, "0.00");
            elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT,"0.00");

            elePaymentMethod1.setAttribute("TotalRefundedAmount",
                "0.00");



      
        Element eleKohlsPaymentList =
            (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

        Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
        if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
          eleExtn.setAttribute("ExtnPaymentDetails",
              elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
        }

        if (bIsDebugEnabled) {
          logger.debug("KohlsPoCReturnRefund.updatesklRecordExternalCharges Cash");
        }

      }

      if (strPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC)) {
        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);
        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
        String strPayRef1 = getPayRef1();
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
        if (!YFCCommon.isStringVoid(strKMCEntryMethod)) {
          logger.debug("KMCEntryMethod is " + strKMCEntryMethod);
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2, strKMCEntryMethod);
          elePaymentMethod1.setAttribute("EntryMethod", strKMCEntryMethod);

        }
        Element eleKohlsPaymentList =
            (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, "02");
        String strRequestedAmount =
            "-".concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_SVC_NO,
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_SVCNo));
        elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
            mapKMCValues.get(KohlsPOCConstant.ATTR_STORE_ID));
        Element elePaymentMethod1Extn =
            XMLUtil.createChild(elePaymentMethod1, KohlsXMLLiterals.E_EXTN);
        elePaymentMethod1Extn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE,
            mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE));
        elePaymentMethod1Extn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE,
            mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE));
        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
        String strAuthCode = mapKMCValues.get(KohlsXMLLiterals.A_AUTH_CODE);
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_CODE, strAuthCode);
        if (!KohlsPOCConstant.N_PG_SUCCESS.equals(strAuthCode)) {
          elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT,
              KohlsPOCConstant.ZERO);
          if (strAuthCode.equals(KohlsPOCConstant.OFFLINE)) {
            elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE,
                KohlsPOCConstant.OFFLINE);
          } else {
            elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE,
                KohlsXMLLiterals.ATTR_DECLINED);
          }
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_SUSPEND_ANY_MORE_CHARGES,
              KohlsXMLLiterals.CONST_Y);
          elePaymentMethod1.setAttribute("TotalRefundedAmount", KohlsPOCConstant.ZERO);
        } else {
          elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);
          elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE, "SUCCESS");
          elePaymentMethod1.setAttribute("TotalRefundedAmount",
              elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
          // Element eleExtn = XMLUtil.createChild(elePaymentMethod1,
          // KohlsPOCConstant.A_EXTN);
          if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
            elePaymentMethod1Extn.setAttribute("ExtnPaymentDetails",
                elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
          }
        }
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE,
            mapKMCValues.get(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE));
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_INTERNAL_RETURN_CODE,
            mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE));

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_TRAN_RETURN_MESSAGE,
            mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE));


        elePaymentMethod1Extn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

      }

      if (strPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD)) {
        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);
        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
        Element eleKohlsPaymentList =
            (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

        String strCreditCardNo = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
        String strCreditExpDate =
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, strCreditExpDate);
        int iSize = strCreditCardNo.length();
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges isize=" + iSize);
        }
        Element elePayment = null;
        String strTrimCreditCardNo = strCreditCardNo.substring(iSize - 4, iSize);

        Element elePaymentList = getPaymentListOutDoc.getDocumentElement();
        String strTotalNo = elePaymentList.getAttribute("TotalNumberOfRecords");
        if (!YFCCommon.isVoid(strTotalNo) && Integer.parseInt(strTotalNo) > 0) {
          elePayment = SCXmlUtil.getXpathElement(elePaymentList,
              "Payment[@DisplayCreditCardNo='" + strTrimCreditCardNo + "']");
        }
        strCreditCardType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
        strCreditCardTypeNo = changeCreditCardType(strCreditCardType);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, strCreditCardTypeNo);
        if (!YFCCommon.isVoid(elePayment)) {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
              elePayment.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO));
        } else {

          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
              strTrimCreditCardNo);

        }
        if (!YFCCommon.isVoid(elePayment)) {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
              elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
        } else {

          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, strCreditCardNo);
        }
        if (!YFCCommon.isVoid(elePayment)) {
          String sFirstName = elePayment.getAttribute(KohlsPOCConstant.ATTR_FIRST_NAME);
          if (!YFCCommon.isStringVoid(sFirstName)) {
            if (bIsDebugEnabled) {
              logger.debug(
                  "KohlsReturnRefund.updatesklRecordExternalCharges sFirstName" + sFirstName);
            }
            elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_FIRST_NAME, sFirstName);
          }
        }
        if (!YFCCommon.isVoid(elePayment)) {
          String sLastName = elePayment.getAttribute(KohlsPOCConstant.ATTR_LAST_NAME);
          if (!YFCCommon.isStringVoid(sLastName)) {
            if (bIsDebugEnabled) {
              logger
                  .debug("KohlsReturnRefund.updatesklRecordExternalCharges sLastName" + sLastName);
            }
            elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_LAST_NAME, sLastName);
          }
        }
        if (!YFCCommon.isVoid(elePayment)) {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
              elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));

        }
        if (!YFCCommon.isVoid(sCTRoutOutput)) {
          elePaymentMethod1.setAttribute("ExtraDetails10", sCTRoutOutput);
        }
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        String strRequestedAmount =
            KohlsPOCConstant.MINUS.concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);

        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);

        elePaymentMethod1.setAttribute("TotalRefundedAmount",
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));

        Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
        eleExtn.setAttribute("ExtnPSIPayment", "Y");
        eleExtn.setAttribute("ExtnApprovedAmount", strRequestedAmount);
        eleExtn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");
        if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
          eleExtn.setAttribute("ExtnPaymentDetails",
              elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
        }
        elePaymentDetails.setAttribute("AuthorizationID", sAuthCode);
        elePaymentDetails.setAttribute("InternalReturnCode", "00");
        elePaymentDetails.setAttribute("InPerson", "Y");
      //CAPE-4074 - start
        if(!YFCCommon.isVoid(elePaymentMethod.getAttribute("EntryMethod"))){
          elePaymentMethod1.setAttribute("EntryMethod", elePaymentMethod.getAttribute("EntryMethod"));
        } else {
          elePaymentMethod1.setAttribute("EntryMethod", "SWIPED");
        }
      //CAPE-4074 - end
        elePaymentMethod1.setAttribute("ExtraDetails7", "CREDIT");
        elePaymentMethod1.setAttribute("IsExternalPayment", "Y");

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

      }

      // CAPE-263 -- Start -- Murali K

      if (strPaymentType.equalsIgnoreCase("DEBIT_CARD")) {

        Element elePayment = null;
        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);

        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
        Element eleKohlsPaymentList =
            (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

        String strCreditCardNo = elePaymentMethod.getAttribute("DebitCardNo");
        String strCreditExpDate =
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);

        String strRequestedAmount =
            KohlsPOCConstant.MINUS.concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        int iSize = strCreditCardNo.length();

        String strTrimDebitCardNo = strCreditCardNo.substring(iSize - 4, iSize);

        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges isize=" + iSize);
        }

        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, strCreditExpDate);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, "19");
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        elePaymentMethod1.setAttribute("DebitCardNo", strCreditCardNo);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);
        elePaymentMethod1.setAttribute("TotalRefundedAmount",
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
      //CAPE-4074 - start
        if(!YFCCommon.isVoid(elePaymentMethod.getAttribute("EntryMethod"))){
          elePaymentMethod1.setAttribute("EntryMethod", elePaymentMethod.getAttribute("EntryMethod"));
        } else {
          elePaymentMethod1.setAttribute("EntryMethod", "SWIPED");
        }
      //CAPE-4074 - end
        elePaymentMethod1.setAttribute("ExtraDetails7", "DEBIT");
        elePaymentMethod1.setAttribute("IsExternalPayment", "Y");
        elePaymentMethod1.setAttribute("AccountType", "Terminal");

        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);
        elePaymentDetails.setAttribute("AuthorizationID", "000000");
        elePaymentDetails.setAttribute("InternalReturnCode", "00");
        elePaymentDetails.setAttribute("InPerson", "Y");
        elePaymentDetails.setAttribute("OfflineStatus", "N");
        elePaymentDetails.setAttribute("InternalReturnCode", "F0");
        elePaymentDetails.setAttribute("ChargeType", "CHARGE");

        Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
        eleExtn.setAttribute("ExtnPSIPayment", "Y");
        eleExtn.setAttribute("ExtnApprovedAmount", strRequestedAmount);
        eleExtn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");
        if (!YFCCommon.isVoid(eleKohlsPaymentList))

        {

          eleExtn.setAttribute("ExtnPaymentDetails",
              XMLUtil.getElementXMLString(eleKohlsPaymentList));
        }

        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
            strTrimDebitCardNo);

      }

      // CAPE -263 --End - Murali K
      if (strPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD)) {
        eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
            strOrderHeaderKey);
        Element elePaymentMethod1 =
            SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
        Element elePayment = null;
        String strCreditCardNo = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
        String strCreditExpDate =
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, strCreditExpDate);
        int iSize = strCreditCardNo.length();
        if (bIsDebugEnabled) {
          logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges isize=" + iSize);
        }
        Element eleKohlsPaymentList =
            (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

        String strTrimCreditCardNo = strCreditCardNo.substring(iSize - 4, iSize);
        if (getPaymentListOutDoc.getDocumentElement() != null) {
          Element elePaymentList = getPaymentListOutDoc.getDocumentElement();
          elePayment = SCXmlUtil.getXpathElement(elePaymentList,
              "Payment[@DisplayCreditCardNo='" + strTrimCreditCardNo + "']");
        }
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE,
            KohlsXMLLiterals.ATTR_ZERO_FOUR);

        if (!YFCCommon.isVoid(elePayment)) {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
              elePayment.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO));
        } else {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
              strTrimCreditCardNo);
        }

        if (!YFCCommon.isVoid(elePayment)) {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
              elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
        } else {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, strCreditCardNo);
        }
        if (!YFCCommon.isVoid(elePayment)) {
          elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
              elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
        }
        if (!YFCCommon.isVoid(elePayment)) {
          String sFirstName = elePayment.getAttribute(KohlsPOCConstant.ATTR_FIRST_NAME);
          if (!YFCCommon.isStringVoid(sFirstName)) {
            if (bIsDebugEnabled) {
              logger.debug(
                  "KohlsReturnRefund.updatesklRecordExternalCharges sFirstName" + sFirstName);
            }
            elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_FIRST_NAME, sFirstName);
          }
        }
        if (!YFCCommon.isVoid(elePayment)) {
          String sLastName = elePayment.getAttribute(KohlsPOCConstant.ATTR_LAST_NAME);
          if (!YFCCommon.isStringVoid(sLastName)) {
            if (bIsDebugEnabled) {
              logger
                  .debug("KohlsReturnRefund.updatesklRecordExternalCharges sLastName" + sLastName);
            }
            elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_LAST_NAME, sLastName);
          }
        }
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
        String strRequestedAmount =
            KohlsPOCConstant.MINUS.concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
        elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);

        Element elePaymentDetailsList =
            SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
        Element elePaymentDetails =
            SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);

        elePaymentMethod1.setAttribute("TotalRefundedAmount",
            elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));

        Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
        if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
          eleExtn.setAttribute("ExtnPaymentDetails",
              elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
        }
        eleExtn.setAttribute("ExtnPSIPayment", "Y");
        eleExtn.setAttribute("ExtnApprovedAmount", strRequestedAmount);
        eleExtn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");

        elePaymentDetails.setAttribute("AuthorizationID", sAuthCode);
        elePaymentDetails.setAttribute("InternalReturnCode", "00");
        elePaymentDetails.setAttribute("InPerson", "Y");

      //CAPE-4074 - start
        if(!YFCCommon.isVoid(elePaymentMethod.getAttribute("EntryMethod"))){
          elePaymentMethod1.setAttribute("EntryMethod", elePaymentMethod.getAttribute("EntryMethod"));
        } else {
          elePaymentMethod1.setAttribute("EntryMethod", "SWIPED");
        }
      //CAPE-4074 - end
        elePaymentMethod1.setAttribute("ExtraDetails7", "CREDIT");
        elePaymentMethod1.setAttribute("IsExternalPayment", "Y");
        if (!YFCCommon.isVoid(sCTRoutOutput)) {
          elePaymentMethod1.setAttribute("ExtraDetails10", sCTRoutOutput);
        }

        elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

      }
    } catch (Exception e) {
      logger.error("Exception in the updatesklRecordExternalCharges Method:" + e.getMessage());
    }
    if (bIsDebugEnabled) {
      logger.debug(
          "KohlsReturnRefund.updatesklRecordExternalCharges  updatesklRecordExternalCharges  outDoc="
              + XMLUtil.getXMLString(outDocformInputSklToRecordExternalCharges));
    }
    logger.endTimer("KohlsReturnRefund.updatesklRecordExternalCharges");
    return outDocformInputSklToRecordExternalCharges;
  }

  /**
   * This method changes the credit card type to 05,06,07,08 depending on the input
   * 
   * @param strCreditCardType
   * @return
   */

  private String changeCreditCardType(String strCreditCardType) {
    logger.beginTimer("KohlsReturnRefund.changeCreditCardType");
    if (bIsDebugEnabled) {
      logger.debug("KohlsReturnRefund.setCreditCardType --Start");
      logger.debug(
          "KohlsReturnRefund.setCreditCardType before strCreditCardType" + strCreditCardType);
    }
    if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_VISA)) {
      strCreditCardType = KohlsConstant.VISA_05;
    } else if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_MASTERCARD)) {
      strCreditCardType = KohlsConstant.MASTERCARD_06;
    } else if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_DISCOVER)) {
      strCreditCardType = KohlsConstant.DISCOVER_07;
    } else if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_AMEX)) {
      strCreditCardType = KohlsConstant.AMEX_08;
    }
    if (bIsDebugEnabled) {
      logger
          .debug("KohlsReturnRefund.setCreditCardType after strCreditCardType" + strCreditCardType);
    }
    logger.endTimer("KohlsReturnRefund.changeCreditCardType");
    return strCreditCardType;
  }

  private Document formInputForPSI(Element elePayment) throws Exception {
    logger.beginTimer("KohlsReturnRefund.formInputForPSI");
    Document docPSIStatus = XMLUtil.createDocument("PSIStatus");
    Element elePSIStatus = docPSIStatus.getDocumentElement();
    elePSIStatus.setAttribute("ClientID", elePayment.getAttribute("TerminalID"));
    elePSIStatus.setAttribute("OrganizationCode", elePayment.getAttribute("StoreID"));
    if (bIsDebugEnabled) {
      logger.debug("Input to getPSIStatusListForPOS" + XMLUtil.getXMLString(docPSIStatus));
    }
    logger.endTimer("KohlsReturnRefund.formInputForPSI");
    return docPSIStatus;
  }

  private Document callPinPad(YFSEnvironment env, Element elePayment) throws Exception {
    logger.beginTimer("KohlsReturnRefund.callPinPad");
    if (bIsDebugEnabled) {
      logger.debug("Inside callPinPad method. Payment element is: "
          + XMLUtil.getElementXMLString(elePayment));
    }
    Document docPinpadResponse = null;
    // Document docPSIInput = formInputForPSI(elePayment);
    elePayment.setAttribute("OrderNo", sOrderNo);
    // Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env,
    // "getPSIStatusListForPOS",
    // docPSIInput);
    // if (bIsDebugEnabled) {
    // logger.debug("Output from getPSIStatusListForPOS" +
    // XMLUtil.getXMLString(docPSIStatusOut));
    // }

    // Element elePsiStatus = (Element)
    // docPSIStatusOut.getElementsByTagName("PSIStatus").item(0);

    timeTaken = 0.01;

    // if (!YFCCommon.isVoid(elePsiStatus)) {
    // YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
    // NRSCCommercePSIStatusGenerator generator =
    // new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
    // PSIStatus psiStatus = generator.generatePSIStatus();
    KohlsPoCPinPadOperations object = new KohlsPoCPinPadOperations();
    long start = 0;
    try {
      start = System.currentTimeMillis();
      logger.debug("KohlsReturnRefund.callPinPad - start time is " + start);
      // docPinpadResponse = request.doCreditRequest(psiStatus, request,
      // elePayment);
      docPinpadResponse = object.doCreditRequest(env, XMLUtil.getDocumentForElement(elePayment));
      if (logger.isDebugEnabled()) {
        logger.debug("Response from Pinpad is: " + XMLUtil.getXMLString(docPinpadResponse));
      }

    } catch (Exception e) {
      logger.error(
          "KohlsReturnRefund.formAndCallInputToRecordExternalCharges Exception while calling pinpad: "
              + e.getMessage());
    } finally {
      long end = System.currentTimeMillis();
      logger.debug("KohlsReturnRefund.callPinPad - end time is " + end);
      timeTaken = (end - start);
    }
    /*
     * } else { logger.error("Pinpad is not paired for Store: " + elePayment.getAttribute("StoreID")
     * + " and" + " Terminal: " + elePayment.getAttribute("TerminalID") +
     * ". Hence PSI Credit request is Skipped."); }
     */
    logger.endTimer("KohlsReturnRefund.callPinPad");

    return docPinpadResponse;
  }

  /**
   * This method sorts the input payment method and puts KMC as first tender because, if KMC
   * activation fails we would not have processed other tenders. Create By mrjoshi *
   * 
   * @param docInXML
   */
  public static void sortPaymentMethod(Document docInXML) {
    logger.beginTimer("KohlsReturnRefund.sortPaymentMethod");
    HashMap<String, Element> mapTempPaymentMethod = new HashMap<String, Element>();
    NodeList nlPaymentMethod = docInXML.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
    Element elePaymentMethods =
        XMLUtil.getChildElement(docInXML.getDocumentElement(), KohlsPOCConstant.E_PAYMENT_METHODS);
    if (nlPaymentMethod.getLength() > 1) {
      for (int i = 0; i < nlPaymentMethod.getLength(); i++) {
        Element elePaymentMethod = (Element) nlPaymentMethod.item(i);
        String sPaymentType = elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
        if ("CREDIT_CARD".equalsIgnoreCase(sPaymentType)
            || "DEBIT_CARD".equalsIgnoreCase(sPaymentType) || "KOHLS_CHARGE_CARD".equalsIgnoreCase(sPaymentType)) {
          String sCreditCardNo = elePaymentMethod.getAttribute("CreditCardNo");
          sPaymentType = sPaymentType + "_" + sCreditCardNo;
        }
        mapTempPaymentMethod.put(sPaymentType, elePaymentMethod);
      }
      docInXML.getDocumentElement().removeChild(elePaymentMethods);
      elePaymentMethods =
          XMLUtil.createChild(docInXML.getDocumentElement(), KohlsPOCConstant.E_PAYMENT_METHODS);
      // First KMC, then CCs and then finally cash
      if (mapTempPaymentMethod.containsKey("KMC")) {
        elePaymentMethods.appendChild(mapTempPaymentMethod.get("KMC"));
        mapTempPaymentMethod.remove("KMC");
      }
      Element eleCASHPaymentMethod = null;
      if (mapTempPaymentMethod.containsKey("CASH")) {
        eleCASHPaymentMethod = mapTempPaymentMethod.get("CASH");
        mapTempPaymentMethod.remove("CASH");
      }
      for (String key : mapTempPaymentMethod.keySet()) {
        elePaymentMethods.appendChild(mapTempPaymentMethod.get(key));
      }
      if (!YFCCommon.isVoid(eleCASHPaymentMethod)) {
        elePaymentMethods.appendChild(eleCASHPaymentMethod);
      }
    }
    logger.endTimer("KohlsReturnRefund.sortPaymentMethod");
  }

  private Document getSplitupDetailsForKMCAndCorpRefund(Document docInputXML,
      HashMap mapOrderRefundAmount) throws ParserConfigurationException {

    logger.beginTimer("KohlsReturnRefund.getSplitupDetailsForKMCAndCorpRefund");

    Element elePaymentMethods =
        (Element) docInputXML.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHODS).item(0);
    if (logger.isDebugEnabled()) {
      logger.debug("elePaymentMethods---> " + XMLUtil.getElementXMLString(elePaymentMethods));
    }

    if (logger.isDebugEnabled()) {
      logger.debug("Input xml ---> " + XMLUtil.getXMLString(docInputXML));
    }
    NodeList ndlPaymentMethod = elePaymentMethods.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
    for (int i = 0; i < ndlPaymentMethod.getLength(); i++) {

      Element elePaymentMethod = (Element) ndlPaymentMethod.item(i);
      if (!YFCCommon.isVoid(elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE))) {
        if ((elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE).equalsIgnoreCase("KMC")
            && elePaymentMethod.getAttribute("ConvertAllToKMC").equalsIgnoreCase("Y"))
            || (elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE)
                .equalsIgnoreCase("CORPORATE_REFUND"))) {

          if (logger.isDebugEnabled()) {
            logger.debug("In the if block");
          }
          Document elekohlsElement = XMLUtil.createDocument("KohlsPaymentList");

          Iterator<Entry<String, String>> itrSplitPaymentTotal =
              mapOrderRefundAmount.entrySet().iterator();

          while (itrSplitPaymentTotal.hasNext()) {

            if (logger.isDebugEnabled()) {
              logger.debug("Looping the refund amount ");
            }
            Entry<String, String> mapiter = itrSplitPaymentTotal.next();
            Element eleKohlsPayment =
                XMLUtil.createChild(elekohlsElement.getDocumentElement(), "KohlsPayment");
            String sOrderDetails[] = String.valueOf(mapiter.getKey()).split("-");

            eleKohlsPayment.setAttribute("StoreID", sOrderDetails[0]);
            eleKohlsPayment.setAttribute("TranNo", sOrderDetails[2]);

            eleKohlsPayment.setAttribute("TerminalID", sOrderDetails[1]);
            eleKohlsPayment.setAttribute(KohlsPOCConstant.A_PAYMENT_TYPE,
                elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE));

            eleKohlsPayment.setAttribute("RefundAmount", String.valueOf(mapiter.getValue()));

          }
          Element elePaymentMethodExtn =
              (Element) elePaymentMethod.getElementsByTagName("Extn").item(0);
          elePaymentMethodExtn.setAttribute("ExtnPaymentDetails",
              XMLUtil.getElementXMLString(elekohlsElement.getDocumentElement()));

        }
      }
      if (logger.isDebugEnabled()) {
        logger.debug("Final out put xml fater convertion  " + XMLUtil.getXMLString(docInputXML));
      }
    }
    logger.endTimer("KohlsReturnRefund.getSplitupDetailsForKMCAndCorpRefund");

    return docInputXML;
  }
}
