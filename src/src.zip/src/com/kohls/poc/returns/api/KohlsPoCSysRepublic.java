package com.kohls.poc.returns.api;


import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlcPoCWriteToFileUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author
 *
 */

/**
 * @author mrjoshi
 *
 */
/**
 * @author mrjoshi
 *
 */
public class KohlsPoCSysRepublic extends KOHLSBaseApi {
  private static YFCLogCategory logger;
  String sExtnPOCFeature = "";
  private String sGiftFlag = "";
  String strResponse = "";
  private String strShippingItemID = "";
  private List<String> aShippingSkuArray = new ArrayList<String>();;
  private Properties props;
  boolean isSysRepOffLine = false;
  public HashMap<String, String> mapOrderRefundAmount = new HashMap<String, String>();
  private HashMap<String, String> mapOrderRefundAmountWithoutTax = new HashMap<String, String>();

  private String strMaskedDL = "";
  DecimalFormat df = new DecimalFormat("#0.00");

  static {
    logger = YFCLogCategory.instance(KohlsPoCSysRepublic.class.getName());
  }

  /**
   * Create By *
   * 
   * @param env
   * @param docInputXML
   * @param sFilePath
   * @param sLogToFile
   * @return
   * @throws Exception
   */
  public Document getInputTenderingDetails(YFSEnvironment env, Document docInputXML)
      throws Exception {

    logger.beginTimer("KohlsPoCSysRepublic.getInputTenderingDetails");
    boolean bIsErrorMashResp = false;
    if (!YFCCommon.isVoid(docInputXML)) {
      Element eleOrder = docInputXML.getDocumentElement();

      sGiftFlag = eleOrder.getAttribute("GiftFlag");
      if ("Y".equalsIgnoreCase(sGiftFlag)) {
        sGiftFlag = "true";
      }

      Element eleExtn = (Element) docInputXML.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
      sExtnPOCFeature = eleExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
      // sExtnPOCFeature = "NonReceiptedReturn";
    }

    strShippingItemID = this.getRuleValue(env, "SHIPPING_CHARGE_ITEMS");
    if (!YFCCommon.isVoid(strShippingItemID)) {
      String[] sTempShippingItemID = strShippingItemID.split(",");
      for (int j = 0; j < sTempShippingItemID.length; j++) {
        aShippingSkuArray.add(sTempShippingItemID[j]);
      }
    }

    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docInputXML)) {
        logger.debug("Input Xml to getInputTenderingDetails  " + SCXmlUtil.getString(docInputXML));
      }
    }
    Document docOutGetDorderDetails = this.getOrderDetails(env, docInputXML);
    HashMap<String, String> mapOTR = getOTRKey(docOutGetDorderDetails);
    Document docOutRefundAmount =
        getRefundAmount(mapOTR, docOutGetDorderDetails, docInputXML, env, "N", sExtnPOCFeature);

    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docOutRefundAmount)) {
        logger.debug(
            "Document after Refund Amount calculated " + SCXmlUtil.getString(docOutRefundAmount));
      }
    }

    String sMultiReceiptErrorPrompt =
        docOutRefundAmount.getDocumentElement().getAttribute("displaySysPrompt");
    if (!YFCCommon.isVoid(sMultiReceiptErrorPrompt)
        && "Y".equalsIgnoreCase(sMultiReceiptErrorPrompt)) {
      logger.debug("Error scenario for Multi Receipted Return.");
      logger.endTimer("KohlsPoCSysRepublic.getInputTenderingDetails");
      return docOutRefundAmount;
    }

    if (!YFCCommon.isVoid(docOutRefundAmount.getDocumentElement().getAttribute("DLRequired"))) {

      String strDLRequired = docOutRefundAmount.getDocumentElement().getAttribute("DLRequired");
      if (YFCCommon.isVoid(docInputXML.getDocumentElement().getAttribute("DriversLicense"))) {
        if (!YFCCommon.isVoid(docInputXML.getDocumentElement().getAttribute("CustomerIDSource"))) {
          if (docInputXML.getDocumentElement().getAttribute("CustomerIDSource")
              .equals("KeyEntered")) {
            docOutRefundAmount.getDocumentElement().setAttribute("DLRequired", "N");
            return docOutRefundAmount;
          }
        }
      }
      if (!YFCCommon.isVoid(docInputXML.getDocumentElement().getAttribute("NoId"))) {
        if (docInputXML.getDocumentElement().getAttribute("NoId").equals("Y")) {
          docOutRefundAmount.getDocumentElement().setAttribute("DLRequired", "N");
          return docOutRefundAmount;
        }


      }
      if (strDLRequired.equals("Y")) {
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(docOutRefundAmount)) {
            logger.debug(" DL is Required  " + SCXmlUtil.getString(docOutRefundAmount));
          }
        }
        logger.endTimer("KohlsPoCSysRepublic.getInputTenderingDetails");
        return docOutRefundAmount;
      }
    }

    Document docChangeOrderOutput = null;
    String sDriverseLicence =
        docOutRefundAmount.getDocumentElement().getAttribute(KohlsPOCConstant.A_DRIVERS_LICENSE);

    String sError = "";
    if (!YFCCommon.isVoid(sDriverseLicence)) {
      // strMaskedDL = convertDL(sDriverseLicence);
      // calling sysRepublic WS
      String sFilePath = "";
      String sFileName = "";
      String sContentToWrite = "";
      boolean bAppend = true;
      KohlcPoCWriteToFileUtil fileUtil = null;

      Document docGetOrderDetails = this.getOrderDetails(env, docInputXML);

      Document docInIntelliCheck =
          getInputIntelliCheck(docInputXML, docGetOrderDetails, docOutRefundAmount, env);

      // MJ 01/23: Changes for QA to check the KC
      // Request / response - begin

      Element eleIntelliCheck = docInIntelliCheck.getDocumentElement();
      String sLogToFile = null;
      try {
        sLogToFile = getPropertyValue(this.props.getProperty("LogIDScanCallToFile"));
        sFilePath = getPropertyValue(this.props.getProperty("LogIDDir"));
      } catch (Exception ex) {
        sLogToFile = KohlsPOCConstant.NO;
      }

      if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
        if (!sFilePath.endsWith("/")) {
          sFilePath = sFilePath + "/";
        }
        sFileName = eleIntelliCheck.getAttribute("StoreID") + "-"
            + eleIntelliCheck.getAttribute("RegisterID") + "-"
            + eleIntelliCheck.getAttribute("TransactionID") + ".log";
        logger.debug("########## Logging ID Scan  request to file: " + (sFilePath + sFileName));
        sContentToWrite = YFCDateUtils.getCurrentDate(true) + ": Request to ID  service is: \n"
            + XMLUtil.getXMLString(docInIntelliCheck) + "\n";
        try {
          fileUtil = new KohlcPoCWriteToFileUtil(sFilePath + sFileName, bAppend);
          if (!YFCCommon.isVoid(fileUtil)) {
            fileUtil.writeDataToFile(sContentToWrite);
          }
        } catch (Exception ex) {
          // problem logging to file
        }
      }
      Document docOutIntelliCheck = null;
      try {
        docOutIntelliCheck =
            KOHLSBaseApi.invokeService(env, "KohlsReturnDLScanRestAPI", docInIntelliCheck);
        if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
          logger.debug("Logging KC response to file");
          sContentToWrite =
              YFCDateUtils.getCurrentDate(true) + ": Response from ID Scan  service is: \n"
                  + XMLUtil.getXMLString(docOutIntelliCheck) + "\n";
          try {
            if (!YFCCommon.isVoid(fileUtil)) {
              fileUtil.writeDataToFile(sContentToWrite);
            }
          } catch (Exception ex) {
            // problem logging to file
          }
        }
      } catch (Exception e) {
        bIsErrorMashResp = true;
        try {
          if (!YFCCommon.isVoid(fileUtil)) {
            fileUtil.writeDataToFile(e.toString());
          }
        } catch (Exception ex) {
          // problem logging to file
        }
        sError = e.toString();
        docOutIntelliCheck = XMLUtil.getDocument(e.getMessage());
      } finally {
        // Document outDocSysRepWS = sysRepublicCall(env, docInputXML.getDocumentElement(),
        // strMaskedDL,
        // docOutGetDorderDetails);
        if (!YFCCommon.isVoid(fileUtil)) {
          fileUtil.closeFile();
        }
        docChangeOrderOutput =
            callChangeOrder(env, docInputXML, docOutIntelliCheck, docOutRefundAmount);
        docChangeOrderOutput.getDocumentElement().setAttribute("RefundAmount",
            docInputXML.getDocumentElement().getAttribute("RefundAmount"));
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(docChangeOrderOutput)) {
            logger.debug(
                "Final OutPut Xml after changeOrder" + SCXmlUtil.getString(docChangeOrderOutput));
          }
        }

        if (!bIsErrorMashResp) {

          Element eleMashResponse = docOutIntelliCheck.getDocumentElement();

          String sExtnResultCode = eleMashResponse.getAttribute("extendedResultCode");
          if (!YFCCommon.isVoid(sExtnResultCode)) {
            if ("LAWS".equalsIgnoreCase(sExtnResultCode) || "LAWP".equalsIgnoreCase(sExtnResultCode)
                || "LAWD".equalsIgnoreCase(sExtnResultCode)) {

              docChangeOrderOutput.getDocumentElement().setAttribute("RAWDLRequired",
                  KohlsPOCConstant.YES);

            }

          }
        }



        logger.endTimer("KohlsPoCSysRepublic.getInputTenderingDetails");
        return docChangeOrderOutput;
      }
    }
    return docInputXML;
  }

  private Document getOTRExceededOrder(Document docInputXml) {
    // TODO Auto-generated method stub

    Iterator<Map.Entry<String, String>> itrRefundAmountWithoutTax =
        mapOrderRefundAmountWithoutTax.entrySet().iterator();
    Element eleOrder = docInputXml.getDocumentElement();
    while (itrRefundAmountWithoutTax.hasNext()) {
      Map.Entry<String, String> itrRefundAmountEntry = itrRefundAmountWithoutTax.next();

      String sTempVal[] = String.valueOf(itrRefundAmountEntry.getValue()).split("-");

      String OrderInfo[] = String.valueOf(itrRefundAmountEntry.getKey()).split("-");

      Element eleReceipt = SCXmlUtil.createChild(eleOrder, "Receipt");
      eleReceipt.setAttribute("OrderNo", OrderInfo[0]);

      eleReceipt.setAttribute("TerminalID", OrderInfo[1]);

      eleReceipt.setAttribute("TranNo", OrderInfo[2]);
      eleReceipt.setAttribute("Amount", sTempVal[0]);
      Double dOTRAmount = Double.parseDouble(sTempVal[1]);
      Double Amount = Double.parseDouble(sTempVal[0]);
      if (Amount > dOTRAmount) {
        eleOrder.setAttribute("displaySysPrompt", "Y");
        break;

      }
      //

      // System.out.println("terminalID"+ OrderInfo[1]);
    }
    return docInputXml;
  }

  /**
   * Create By *
   * 
   * @param env
   * @param docInputXML
   * @return
   * @throws Exception
   */
  public Document getOrderDetails(YFSEnvironment env, Document docInputXML) throws Exception {
    logger.beginTimer("KohlsPoCSysRepublic.getOrderDetails");

    Document docOutGetDorderDetails = null;

    String strOrderHeaderKey = docInputXML.getDocumentElement().getAttribute("OrderHeaderKey");
    String strGetOrderDetails = "<Order OrderHeaderKey='" + strOrderHeaderKey + "'/>";

    Document docInGetOrderDetilsDoc = XMLUtil.getDocument(strGetOrderDetails);

    // CAPE - 2755 - ISS PA Happy Path - Start - Murali K
    if (ServerTypeHelper.amIOnEdgeServer()
        && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {

      Element eleYfcAdditionalInfo = XMLUtil.createChild(
          docInGetOrderDetilsDoc.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
      eleYfcAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);

    }
    // CAPE - 2755 - ISS PA Happy Path - End - Murali K

    if (!YFCCommon.isVoid(docInGetOrderDetilsDoc)) {
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docInGetOrderDetilsDoc)) {
          logger.debug(
              "Input XML to GetOrderDetails   " + SCXmlUtil.getString(docInGetOrderDetilsDoc));
        }
      }
      Document docGetOrderDetailsTemplate =
          XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_DETAILS_TEMPLATE_RETURNS);
      docOutGetDorderDetails = KOHLSBaseApi.invokeAPI(env, docGetOrderDetailsTemplate,
          KohlsPOCConstant.API_GET_ORDER_DETAILS, docInGetOrderDetilsDoc);
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docOutGetDorderDetails)) {
          logger.debug(
              "Output XML to GetOrderDetails   " + SCXmlUtil.getString(docOutGetDorderDetails));
        }
      }

    }
    logger.endTimer("KohlsPoCSysRepublic.getOrderDetails");

    return docOutGetDorderDetails;
  }

  /**
   * @param strStore
   * @param strTerminalId
   * @param strTransNo
   * @param strOtrAmountDefault
   * @param mapOTR
   * @return Double otr amount
   */
  private Double getHighestOTRAmount(String strStore, String strTerminalId, String strTransNo,
      String strOtrAmountDefault, HashMap mapOTR) {
    Double dReturnValue = Double.valueOf(strOtrAmountDefault);
    Iterator<Map.Entry<Integer, String>> iterator = mapOTR.entrySet().iterator();
    while (iterator.hasNext()) {
      Map.Entry<Integer, String> entry = iterator.next();
      String[] strKey = String.valueOf(entry.getKey()).split("-");
      String strCompareStore = strKey[2];
      String strCompareTerminalId = strKey[3];
      String strCompareTransNo = strKey[4];
      String[] strOTRResponseDetails = entry.getValue().split("-");
      String strCompareOtrAmount = strOTRResponseDetails[2];
      try {
        if (strStore.equalsIgnoreCase(strCompareStore)
            && strTerminalId.equalsIgnoreCase(strCompareTerminalId)
            && strTransNo.equalsIgnoreCase(strCompareTransNo)
            && Double.valueOf(strCompareOtrAmount).doubleValue() > dReturnValue.doubleValue()) {
          // found a higher return value, use this instead
          dReturnValue = Double.valueOf(strCompareOtrAmount);
        }
      } catch (NumberFormatException nfe) {
        // keep the default value
      }
    }
    return dReturnValue;
  }

  /**
   * Create By *
   * 
   * @param mapOTR
   * @param docOrderDetails
   * @param docInputXML
   * @param sExtnPOCFeature2
   * @return
   * @throws Exception
   */
  public Document getRefundAmount(HashMap mapOTR, Document docOrderDetails, Document docInputXML,
      YFSEnvironment env, String sMultiReceiptFlag, String sExtnPOCFeature2) throws Exception {
    logger.beginTimer("KohlsPoCSysRepublic.getRefundAmount");

    double dReceiptLineTotal = 0.0;
    double dReceiptLineTotalWithoutTax = 0.0;
    double dShippingSkuAmount = 0.0;
    double dTransactionLineTotal = 0.0;
    double dTransactionLineTotalWithoutTax = 0.0;
    double dTax = 0.0;
    Double dReceiptOTRAmount = 0.0;
    Double dCumulativeOTRAmount = 0.0;
    boolean bRefundCalciReqd = true;
    Element eleOrder = docInputXML.getDocumentElement();
    String sRefundAmount = eleOrder.getAttribute(KohlsPOCConstant.REFUND_AMT);



    Element eleProratedLines = (Element) XPathUtil.getNode(eleOrder, "//ProRatedLines");

    if (!YFCCommon.isVoid(eleProratedLines)) {
      if (!YFCCommon.isVoid(sRefundAmount)) {
        bRefundCalciReqd = false;
      }

    }
    if (YFCCommon.isVoid(sExtnPOCFeature)) {
      sExtnPOCFeature = sExtnPOCFeature2;
    }
    // sExtnPOCFeature="ReceiptedReturn";
    if (!YFCCommon.isVoid(docOrderDetails)) {
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docOrderDetails)) {
          logger.debug("InPut  XML to getRefundAmount   " + SCXmlUtil.getString(docOrderDetails));
        }
      }

      if ("NonReceiptedReturn".equals(sExtnPOCFeature)) {
        Element eleOverallTotals =
            XMLUtil.getChildElement(docOrderDetails.getDocumentElement(), "OverallTotals");
        dTransactionLineTotal = Double.parseDouble(eleOverallTotals.getAttribute("GrandTotal"));
        dTransactionLineTotalWithoutTax =
            Double.parseDouble(eleOverallTotals.getAttribute("LineSubTotal"));

      } else {
        Element eleOrderLines = XMLUtil.getChildElement(docOrderDetails.getDocumentElement(),
            KohlsPOCConstant.ELEM_ORDER_LINES);
        NodeList ndlOrdderLine = docOrderDetails.getElementsByTagName("OrderLine");
        Iterator<Map.Entry<Integer, String>> iterator = mapOTR.entrySet().iterator();
        while (iterator.hasNext()) {
          Map.Entry<Integer, String> entry = iterator.next();
          String[] strKey = String.valueOf(entry.getKey()).split("-");
          String strStore = strKey[2];
          String strTerminalId = strKey[3];
          String strTransNo = strKey[4];
          String[] strOTRResponseDetails = entry.getValue().split("-");
          strResponse = strOTRResponseDetails[0];
          String sOrderDetails = strStore + "-" + strTerminalId + "-" + strTransNo;
          // if (strOTRResponseDetails.length == 3) {
          try {
            dReceiptOTRAmount = getHighestOTRAmount(strStore, strTerminalId, strTransNo,
                strOTRResponseDetails[2], mapOTR);
          } catch (Exception e) {
            String sRuleValue = this.getRuleValue(env, "OTR_AMOUNT_LIMIT");
            if (YFCCommon.isVoid(sRuleValue)) {
              sRuleValue = "150.00";
            }
            dReceiptOTRAmount = dReceiptOTRAmount + Double.parseDouble(sRuleValue);
          }

          dCumulativeOTRAmount = dCumulativeOTRAmount + dReceiptOTRAmount;

          // Resetting the receipt totals
          dReceiptLineTotal = 0.00;
          dReceiptLineTotalWithoutTax = 0.00;

          if (YFCLogUtil.isDebugEnabled()) {
            logger.debug("Current transaction details:" + strKey.toString());
            logger.debug("Current OTR Details " + strOTRResponseDetails.toString());
            logger.debug("Receipt OTR Amount is " + dReceiptOTRAmount);
            logger.debug("Cumulative OTR Amount is " + dCumulativeOTRAmount);
          }

          Element elePromotionExtn = (Element) XPathUtil.getNode(eleOrder,
              "//Order/Promotions/Promotion/Extn[@ExtnCouponSourceCode='" + strStore + "-"
                  + strTerminalId + "-" + strTransNo + "']");
          String sExtnKCOptionSelected = "";
          if (!YFCCommon.isVoid(elePromotionExtn)) {
            sExtnKCOptionSelected =
                elePromotionExtn.getAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED);
          }

          // Looping through lines to identify which line belongs to
          // this OTR.
          for (int i = 0; i < ndlOrdderLine.getLength(); i++) {
            Element eleOrderLine = (Element) ndlOrdderLine.item(i);
            String strOrderedQty = XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);
            boolean bShippingSku = false;
            if (!YFCCommon.isVoid(eleOrderLine)) {
              Element eleCustomAttributes =
                  (Element) eleOrderLine.getElementsByTagName("CustomAttributes").item(0);

              Element eleExtn =
                  (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
              String sSkuStatus = eleExtn.getAttribute(KohlsPOCConstant.EXTN_SKU_STATUS_CODE);

              Element eleItem = (Element) eleOrderLine.getElementsByTagName("Item").item(0);
              Element eleLinePriceInfo =
                  (Element) eleOrderLine.getElementsByTagName("LinePriceInfo").item(0);
              Element eleLineOverallTotals =
                  (Element) eleOrderLine.getElementsByTagName("LineOverallTotals").item(0);

              if (YFCLogUtil.isDebugEnabled()) {
                if (!YFCCommon.isVoid(eleCustomAttributes)) {
                  logger.debug("Custom Attributes: " + SCXmlUtil.getString(eleCustomAttributes));
                }
              }
              // Checking is Sku is shipping sku or not.
              if (aShippingSkuArray.contains(eleItem.getAttribute("ItemID"))) {
                bShippingSku = true;

              }

              if ("ReceiptedReturn".equals(sExtnPOCFeature)) {
                String strPrimeLineno = eleOrderLine.getAttribute("PrimeLineNo");
                Element eleProratedOrderLine = null;
                if (!YFCCommon.isVoid(sExtnKCOptionSelected)) {
                  eleProratedOrderLine = (Element) XPathUtil.getNode(eleOrder,
                      "//Order/ProRatedLines/OrderLines[@OrderLinesForKCOption='"
                          + sExtnKCOptionSelected + "'][@OrderLinesForPromotion='" + sOrderDetails
                          + "']/OrderLine[@PrimeLineNo='" + strPrimeLineno + "']");
                }

                if (!YFCCommon.isVoid(eleCustomAttributes)) {
                  if (eleCustomAttributes.getAttribute("Text7").equals(strStore)
                      && eleCustomAttributes.getAttribute("Text8").equals(strTerminalId)
                      && eleCustomAttributes.getAttribute("Text9").equals(strTransNo)) {

                    // CAPE-3613 Removing order line when its been referenced once
                    eleOrderLines.removeChild(eleOrderLine);
                    i--;
                    // CAPE-3613 - end
                    if (YFCLogUtil.isDebugEnabled()) {
                      logger.debug("LinePriceInfo is: " + SCXmlUtil.getString(eleLinePriceInfo));
                    }
                    if (!YFCCommon.isVoid(eleLinePriceInfo)) {
                      if (bShippingSku) {
                        dShippingSkuAmount = dShippingSkuAmount
                            + Double.parseDouble(eleLinePriceInfo.getAttribute("LineTotal"));
                      } else {
                        if (YFCCommon.isVoid(eleProratedOrderLine) && !KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(strOrderedQty)) {
                          dReceiptLineTotal = dReceiptLineTotal
                              + Double.parseDouble(eleLinePriceInfo.getAttribute("LineTotal"));
                          dReceiptLineTotalWithoutTax =
                              dReceiptLineTotalWithoutTax + Double.parseDouble(
                            		  eleExtn.getAttribute("ExtnNetPrice"));

                         } else if (!YFCCommon.isVoid(eleProratedOrderLine)){

                          Element eleProratedOrderLineExtn = (Element) eleProratedOrderLine
                              .getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
                          Element eleProratedOrderLineTax = (Element) eleProratedOrderLine
                              .getElementsByTagName("LineTax").item(0);

                          dReceiptLineTotal = dReceiptLineTotal
                              + Double.parseDouble(
                                  eleProratedOrderLineExtn.getAttribute("ExtnNetPrice"))
                              + Double.parseDouble(eleProratedOrderLineTax.getAttribute("Tax"));
                          dReceiptLineTotalWithoutTax = dReceiptLineTotalWithoutTax + Double
                              .parseDouble(eleProratedOrderLineExtn.getAttribute("ExtnNetPrice"));

                        }
                        // If OTR Amount exceeds even
                        // for 1 receipt for MRR, throw
                        // exception
                        if (Double.compare(
                            Double.parseDouble(df.format(dReceiptLineTotalWithoutTax)),
                            dReceiptOTRAmount) > 0 && mapOTR.size() > 1) {
                          docInputXML.getDocumentElement().setAttribute("displaySysPrompt", "Y");
                          Element eleReceipt =
                              SCXmlUtil.createChild(docInputXML.getDocumentElement(), "Receipt");
                          eleReceipt.setAttribute("OrderNo", strStore);

                          eleReceipt.setAttribute("TerminalID", strTerminalId);

                          eleReceipt.setAttribute("TranNo", strTransNo);
                          eleReceipt.setAttribute("Amount", df.format(dReceiptOTRAmount));
                          return docInputXML;
                        }
                      }
                    }
                  }
                }
              } else if (sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)
                  && !sSkuStatus.equalsIgnoreCase("30")) {
                NodeList ndlLineTax = eleOrderLine.getElementsByTagName("LineTax");
                for (int k = 0; k < ndlLineTax.getLength(); k++) {
                  Element eleLineTax = (Element) ndlLineTax.item(k);
                  if (!YFCCommon.isVoid(eleLineTax)) {
                    if (eleLineTax.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY)
                        .equals("Price")) {
                      Element eleLineTaxExtn =
                          XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
                      if (!YFCCommon.isVoid(eleLineTaxExtn)) {
                        String sOrigTax = eleLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
                        if (!YFCCommon.isVoid(sOrigTax)) {
                          double dOrigTax = Double.parseDouble(sOrigTax);
                          dTax = dOrigTax - Double.parseDouble(eleLineTax.getAttribute("Tax"));
                        }
                      }
                    }
                  }
                }
                double dTotalFeeAdjValue = 0.00;
                NodeList nlFeeLineCharge = XPathUtil.getNodeList(eleOrderLine,
                        "LineCharges/LineCharge[@ChargeCategory='FEE']");
                if(nlFeeLineCharge.getLength()>0){
                  for(int fl =0; fl<nlFeeLineCharge.getLength(); fl++){
                  	Element eleFeeLineCharge = (Element) nlFeeLineCharge.item(fl);
                  	if(!YFCCommon.isVoid(eleFeeLineCharge)){
                  		String strChargePerLine = eleFeeLineCharge.getAttribute("ChargePerLine");
                  		if(!YFCCommon.isVoid(strChargePerLine)){
                  			double dChargePerLine = Double.valueOf(strChargePerLine);
                  			Element eleFeelLineChargeExtn = SCXmlUtil.getChildElement(eleFeeLineCharge, "Extn");
                  			if(!YFCCommon.isVoid(eleFeelLineChargeExtn)) {
                  			  String strExtnOrigChgPerLine = eleFeelLineChargeExtn.getAttribute("ExtnOrigChgPerLine");
                                if(!YFCCommon.isVoid(strExtnOrigChgPerLine)){
                                    double dExtnOrigChgPerLine = Double.valueOf(strExtnOrigChgPerLine);
                                    dTotalFeeAdjValue = dTotalFeeAdjValue + (dExtnOrigChgPerLine - dChargePerLine);
                                }
                  			}
                  		}
                  	}
                  }
                }
                double dTempTotal =
                    Double.parseDouble(eleCustomAttributes.getAttribute("Text12")) - Double
                        .parseDouble(eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
                if (dTempTotal > 0) {
                  dReceiptLineTotalWithoutTax = dReceiptLineTotalWithoutTax + dTempTotal;
                  dReceiptLineTotal = dReceiptLineTotal + dTempTotal + dTax + dTotalFeeAdjValue;
                }
              }
            }
          }
          dTransactionLineTotal = Math.abs(dTransactionLineTotal + dReceiptLineTotal);
          dTransactionLineTotalWithoutTax =
              Math.abs(dTransactionLineTotalWithoutTax + dReceiptLineTotalWithoutTax);

          // }
          // CAPE-3469 begin : Making sure we dont forget the Shipping sku in the Receipt total
          dReceiptLineTotal = dReceiptLineTotal + dShippingSkuAmount;
          // CAPE-3469 - end

          // MJ 06-22 CAPE-3613 - start
          if (!YFCCommon.isVoid(
              mapOrderRefundAmount.get(strStore + "-" + strTerminalId + "-" + strTransNo))) {
            Double dTempReceiptTotal = Double.parseDouble(
                mapOrderRefundAmount.get(strStore + "-" + strTerminalId + "-" + strTransNo));
            mapOrderRefundAmount.put(strStore + "-" + strTerminalId + "-" + strTransNo,
                df.format(dReceiptLineTotal + dTempReceiptTotal));
          } else {
            mapOrderRefundAmount.put(strStore + "-" + strTerminalId + "-" + strTransNo,
                df.format(dReceiptLineTotal));
          }
          // MJ 06-22 CAPE-3613 - end
        }
      }

      if (YFCCommon.isVoid(docInputXML.getDocumentElement().getAttribute("DriversLicense"))) {
        boolean bCheckDL =
            this.checkDLReq(dTransactionLineTotalWithoutTax, dCumulativeOTRAmount, strResponse);
        if (bCheckDL) {
          eleOrder = docInputXML.getDocumentElement();
          eleOrder.setAttribute("DLRequired", "Y");
          if (bRefundCalciReqd) {
            eleOrder.setAttribute("RefundAmount",
                df.format(dTransactionLineTotal + dShippingSkuAmount));
          }
          eleOrder.setAttribute("OTRAmount", String.valueOf(dCumulativeOTRAmount));
          if (YFCLogUtil.isDebugEnabled()) {
            if (!YFCCommon.isVoid(docInputXML)) {
              logger.debug("DL Required returning to gravity for DL Information "
                  + SCXmlUtil.getString(docInputXML));
            }
          }
          return docInputXML;
        } else {
          eleOrder = docInputXML.getDocumentElement();
          if (bRefundCalciReqd) {
            eleOrder.setAttribute("RefundAmount",
                df.format(dTransactionLineTotal + dShippingSkuAmount));
          } else {
            eleOrder.setAttribute("RefundAmount", sRefundAmount);

          }
          eleOrder.setAttribute("OTRAmount", String.valueOf(dCumulativeOTRAmount));
          // eleOrder.setAttribute("DLRequired", "N");
          if (YFCLogUtil.isDebugEnabled()) {
            if (!YFCCommon.isVoid(docInputXML)) {
              logger.debug("Refund Amount calculation ends: " + SCXmlUtil.getString(docInputXML));
            }
          }
          return docInputXML;
        }
      } else {
        eleOrder = docInputXML.getDocumentElement();
        eleOrder.setAttribute("OTRAmount", String.valueOf(dCumulativeOTRAmount));
        if (bRefundCalciReqd) {
          eleOrder.setAttribute("RefundAmount",
              df.format(dTransactionLineTotal + dShippingSkuAmount));
        } else {
          eleOrder.setAttribute("RefundAmount", sRefundAmount);

        }
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(docInputXML)) {
            logger.debug("Refund Amount calculation ends: " + SCXmlUtil.getString(docInputXML));
          }
        }
        return docInputXML;
      }
    }
    logger.endTimer("KohlsPoCSysRepublic.getRefundAmount");
    return docInputXML;
  }

  /**
   * Create By *
   * 
   * @param docInputXML
   * @return
   */
  public HashMap<String, String> getOTRKey(Document docInputXML) {
    logger.beginTimer("KohlsPoCSysRepublic.getOTRKey");

    HashMap<String, String> mapOTR = new HashMap<String, String>();
    if (!YFCCommon.isVoid(docInputXML)) {
      NodeList ndlReference = docInputXML.getElementsByTagName("Reference");
      for (int i = 0; i < ndlReference.getLength(); i++) {

        Element eleReference = (Element) ndlReference.item(i);
        if (!YFCCommon.isVoid(eleReference)) {
          if (eleReference.getAttribute("Name").startsWith("OTR")) {
            mapOTR.put(eleReference.getAttribute("Name"), eleReference.getAttribute("Value"));
            if (YFCCommon.isVoid(this.strResponse)) {
              this.strResponse = eleReference.getAttribute("Value").split("-")[0];
            }
          }
        }
      }
    }
    logger.endTimer("KohlsPoCSysRepublic.getOTRKey");

    return mapOTR;
  }

  /**
   * Create By *
   * 
   * @param dlineTotal
   * @param dOTRAmount
   * @param strResponse
   * @param sExtnPOCFeature
   * @return
   */
  private boolean checkDLReq(double dlineTotal, double dOTRAmount, String strResponse) {
    logger.beginTimer("KohlsPoCSysRepublic.checkDLReq");
    if (!YFCCommon.isVoid(strResponse)) {
      if ((strResponse.contains("F0") || strResponse.contains("F9"))
          && Double.parseDouble(df.format(dlineTotal)) <= dOTRAmount) {
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(strResponse)) {
            logger.debug("Drivers Licence Required: false");
          }
        }
        logger.endTimer("KohlsPoCSysRepublic.checkDLReq");
        return false;
      }
    }
    logger.debug("Drivers Licence Required: true");
    logger.endTimer("KohlsPoCSysRepublic.checkDLReq");
    return true;
  }

  /**
   * Create By *
   * 
   * @param env
   * @param mapOTR
   * @return
   * @throws Exception
   */
  private Document getOTRPaymentList(YFSEnvironment env, Map<String, String> mapOTR,
      String sSellerOrganizationCode) throws Exception {

    logger.beginTimer("KohlsPoCSysRepublic.getOTRPaymentList");

    Document docInOTRPymntInfo = SCXmlUtil.createDocument("KohlsOTROrder");
    Element elelOTRPymntInfo = docInOTRPymntInfo.getDocumentElement();
    Element eleComplexQuery = null;
    Element eleAnd = null;
    Element eleOR = null;
    Element eleExpStoreID = null;
    Element eleExpTerminalID = null;
    Element eleTranNo = null;
    Element eleOrderDate = null;
    StringBuffer strOrderDate = null;

    elelOTRPymntInfo.setAttribute("CurrentStoreID", sSellerOrganizationCode);

    if (mapOTR.size() > 1) {
      eleComplexQuery = SCXmlUtil.createChild(elelOTRPymntInfo, "ComplexQuery");
      eleComplexQuery.setAttribute("Operator", "And");
      eleOR = SCXmlUtil.createChild(eleComplexQuery, "Or");
    }

    for (String key : mapOTR.keySet()) {
      String[] sOTRValue = key.split("-");
      String sStoreID = sOTRValue[2];
      String sTerminalID = sOTRValue[3];
      String sTranNo = sOTRValue[4];
      if(sOTRValue.length > 7) {
    	  strOrderDate = new StringBuffer(sOTRValue[5]);
    	  strOrderDate.append("-").append(sOTRValue[6]).append("-").append(sOTRValue[7]);
      }

      if (mapOTR.size() > 1) {

        eleAnd = SCXmlUtil.createChild(eleOR, "And");

        eleExpStoreID = SCXmlUtil.createChild(eleAnd, "Exp");
        eleExpTerminalID = SCXmlUtil.createChild(eleAnd, "Exp");
        eleTranNo = SCXmlUtil.createChild(eleAnd, "Exp");
        eleExpStoreID.setAttribute("Name", "StoreID");
        eleExpStoreID.setAttribute("Value", sStoreID);

        eleExpTerminalID.setAttribute("Name", "TerminalID");
        eleExpTerminalID.setAttribute("Value", sTerminalID);
        eleTranNo.setAttribute("Name", "TranNo");
        eleTranNo.setAttribute("Value", sTranNo);
        if(strOrderDate !=null && strOrderDate.length() > 0) {
        	eleOrderDate = SCXmlUtil.createChild(eleAnd, "Exp");
        	eleOrderDate.setAttribute("Name", "OrderDate");
        	eleOrderDate.setAttribute("Value", strOrderDate.toString());
        }
        // eleExp.setAttribute("Name","OTRDetails"); 

      } else if (mapOTR.size() == 1) {
        elelOTRPymntInfo.setAttribute("StoreID", sStoreID);
        elelOTRPymntInfo.setAttribute("TerminalID", sTerminalID);
        elelOTRPymntInfo.setAttribute("TranNo", sTranNo);
        if(strOrderDate !=null && strOrderDate.length() > 0) {
        	elelOTRPymntInfo.setAttribute("OrderDate", strOrderDate.toString());
        }

      }
      if (YFCLogUtil.isDebugEnabled()) {
        if (!YFCCommon.isVoid(docInOTRPymntInfo)) {

          logger.debug("Input to getPaymentList" + SCXmlUtil.getString(docInOTRPymntInfo));
        }

      }
    }

    Document outDocOTRPymntInfo =
        KOHLSBaseApi.invokeService(env, "KohlsPoCGetKohlsOTROrderList", docInOTRPymntInfo);

    sortOTRPaymentBasedOnRefundSeqNo(outDocOTRPymntInfo);

    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(outDocOTRPymntInfo)) {

        logger.debug("Input to getPaymentList" + SCXmlUtil.getString(outDocOTRPymntInfo));
      }

    }
    logger.endTimer("KohlsPoCSysRepublic.getOTRPaymentList");

    return outDocOTRPymntInfo;

  }

  /**
   * Create By mrjoshi *
   * 
   * @param outDocOTRPymntInfo
   */
  private void sortOTRPaymentBasedOnRefundSeqNo(Document outDocOTRPymntInfo) {
    logger.beginTimer("KohlsPoCSysRepublic.sortOTRPaymentBasedOnRefundSeqNo");
    NodeList nlOTROrder = outDocOTRPymntInfo.getElementsByTagName("KohlsOTROrder");
    if (!YFCCommon.isVoid(nlOTROrder) && nlOTROrder.getLength() > 0) {
      for (int i = 0; i < nlOTROrder.getLength(); i++) {
        Element eleOTROrder = (Element) nlOTROrder.item(i);
        Element eleOTRPaymentList = XMLUtil.getChildElement(eleOTROrder, "KohlsOTRPaymentList");
        NodeList nlOTRPayment = eleOTROrder.getElementsByTagName("KohlsOTRPayment");
        HashMap<Integer, Element> tempPayment = new HashMap<Integer, Element>();
        if (!YFCCommon.isVoid(nlOTRPayment) && nlOTRPayment.getLength() > 1) {
          for (int j = 0; j < nlOTRPayment.getLength(); j++) {
            Element eleOTRPayment = (Element) nlOTRPayment.item(j);
            String sRefundSeqNo = eleOTRPayment.getAttribute("RefundSeqNo");
            tempPayment.put(Integer.parseInt(sRefundSeqNo), eleOTRPayment);
          }
          eleOTROrder.removeChild(eleOTRPaymentList);
          eleOTRPaymentList = XMLUtil.createChild(eleOTROrder, "KohlsOTRPaymentList");
          SortedSet<Integer> keys = new TreeSet<Integer>(tempPayment.keySet());
          for (Integer key : keys) {
            XMLUtil.appendChild(eleOTRPaymentList, tempPayment.get(key));
          }
        }
      }
    }
    logger.endTimer("KohlsPoCSysRepublic.sortOTRPaymentBasedOnRefundSeqNo");

  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docInputXML
   * @return
   * @throws Exception
   */
  public Document getTenderDetails(YFSEnvironment env, Document docInputXML) throws Exception {
    if (logger.isDebugEnabled()) {
      logger.beginTimer("KohlsPoCSysRepublic.getTenderDetails");
      logger.debug("Input to  getTenderDetails is ::" + XMLUtil.getXMLString(docInputXML));

    }
    Document docOutCreatePaymentMethod = null;
    Element eleOrder = docInputXML.getDocumentElement();
    Element eleExtn = SCXmlUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
    sExtnPOCFeature = eleExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
    Document docOutGetOrderDetails = this.getOrderDetails(env, docInputXML);

    String sSellerOrganizationCode = docOutGetOrderDetails.getDocumentElement()
        .getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);

    HashMap<String, String> mapOTR = getOTRKey(docOutGetOrderDetails);
    if (mapOTR.size() > 1) {
      strShippingItemID = this.getRuleValue(env, "SHIPPING_CHARGE_ITEMS");
      if (!YFCCommon.isVoid(strShippingItemID)) {
        String[] sTempShippingItemID = strShippingItemID.split(",");
        for (int j = 0; j < sTempShippingItemID.length; j++) {
          aShippingSkuArray.add(sTempShippingItemID[j]);
        }
      }
      Document outRefundAmountDoc =
          getRefundAmount(mapOTR, docOutGetOrderDetails, docInputXML, env, "Y", sExtnPOCFeature);
      // splitRefundAmount(inSplitDoc, dRefundAmount, inDoc)
    }
    // Element eleOrder = docInputXML.getDocumentElement();
    // Document docOutRefundAmount = getRefundAmount(mapOTR,
    // docOutGetOrderDetails, docInputXML);
    Element elePaymentMethods =
        XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PAYMENT_METHODS);
    if (!YFCCommon.isVoid(elePaymentMethods)) {
      XMLUtil.removeChild(eleOrder, elePaymentMethods);
    }
    elePaymentMethods = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PAYMENT_METHODS);
    sGiftFlag = eleOrder.getAttribute("GiftFlag");
    if ("Y".equalsIgnoreCase(sGiftFlag)) {
      sGiftFlag = "true";
    } else {
      sGiftFlag = "false";
    }

    // HashMap<String, String> mapOTR = getOTRKey(docOutGetOrderDetails);
    Document docGetOTRPaymentList = null;
    if (!YFCCommon.isVoid(sExtnPOCFeature)) {
      if ((sExtnPOCFeature.equals("ReceiptedReturn"))
          || (sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT))) {
        docGetOTRPaymentList = getOTRPaymentList(env, mapOTR, sSellerOrganizationCode);
      }
    }
    if (mapOTR.size() > 1) {

      docOutCreatePaymentMethod =
          createPaymentMethodForMultiReceipt(docGetOTRPaymentList, docInputXML);
    } else {
      docOutCreatePaymentMethod = createPaymentMethod(docInputXML, docGetOTRPaymentList,
          docOutGetOrderDetails, env, mapOTR);
    }
    if (logger.isDebugEnabled()) {
      logger.endTimer("KohlsPoCSysRepublic.getTenderDetails");
      logger
          .debug("Out Put of getTenderDetails " + XMLUtil.getXMLString(docOutCreatePaymentMethod));

    }

    return docOutCreatePaymentMethod;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param docInOrder
   * @param docInOTRPymntInfo
   * @param docOutGetOrderDetails
   * @param env
   * @return
   * @throws Exception
   */
  private Document createPaymentMethod(Document docInOrder, Document docInOTRPymntInfo,
      Document docOutGetOrderDetails, YFSEnvironment env, HashMap mapOTR) throws Exception {
    String sDriverseLicence = "";
    HashMap<String, String> mapsplitUpAmount = new HashMap<String, String>();
    Element eleExtnChangeOrder = null;
    String strStore = "";
    String strTerminalId = "";
    String strTransNo = "";

    logger.beginTimer("KohlsPoCSysRepublic.createPaymentMethod");
    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docInOrder)) {
        logger.debug("Order XML" + SCXmlUtil.getString(docInOrder));
      }
    }

    if (!YFCCommon.isVoid(mapOTR.keySet().toString().split("-")) && mapOTR.keySet().size() > 0) {
      String[] strKey = mapOTR.keySet().toString().split("-");
      strStore = strKey[2];
      strTerminalId = strKey[3];
      strTransNo = strKey[4];
    }

    if (!YFCCommon.isVoid(docInOrder)) {
      Element eleOrder = docInOrder.getDocumentElement();
      sDriverseLicence = eleOrder.getAttribute("DriversLicense");
      // docOutGetOrderDetails = this.getOrderDetails(env, docInOrder);
      String sOrderHeaderKey = eleOrder.getAttribute("OrderHeaderKey");
      String sChangeOrderInputXml = "<Order OrderHeaderKey='" + sOrderHeaderKey + "'/>";

      Document docChangeOrderIn = XMLUtil.getDocument(sChangeOrderInputXml);
      Element eleChangeOrderInRoot = docChangeOrderIn.getDocumentElement();
      eleChangeOrderInRoot.setAttribute("IgnoreRepricingUE", "Y");
      eleChangeOrderInRoot.setAttribute("Override", "Y");
      eleChangeOrderInRoot.setAttribute("Action", "MODIFY");

      Element eleExtn = null;
      Element elePersonInfoBillTo = (Element) docOutGetOrderDetails.getDocumentElement()
          .getElementsByTagName("PersonInfoBillTo").item(0);
      XMLUtil.importElement(docInOrder.getDocumentElement(), elePersonInfoBillTo);

      if (!YFCCommon.isVoid(docOutGetOrderDetails)
          && SCXmlUtil.getChildElement(docOutGetOrderDetails.getDocumentElement(),
              KohlsPOCConstant.E_EXTN) != null) {
        eleExtn = (Element) docOutGetOrderDetails.getDocumentElement()
            .getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
        // sDriverseLicence = eleExtn.getAttribute("ExtnDLForSys");
      }
      String sRefundAmount = eleOrder.getAttribute("RefundAmount");

      String sPaymentType = "";
      if (!YFCCommon.isVoid(docOutGetOrderDetails)) {
        sPaymentType = setPaymentMethod(docOutGetOrderDetails, sRefundAmount, env, docInOrder,
            docInOTRPymntInfo);
      }
      Element elePaymentMethods =
          (Element) docInOrder.getElementsByTagName("PaymentMethods").item(0);

      // if (!YFCCommon.isVoid(docInOTRPymntInfo)) {
      if (!YFCCommon.isVoid(sPaymentType)) {
        eleExtnChangeOrder = XMLUtil.createChild(eleChangeOrderInRoot, KohlsPOCConstant.E_EXTN);
        eleExtnChangeOrder.setAttribute(KohlsPOCConstant.EXTN_ORIGINAL_TENDER, "N");
        Element elePaymentMethod = SCXmlUtil.createChild(elePaymentMethods, "PaymentMethod");
        elePaymentMethod.setAttribute("PaymentType", sPaymentType);
        if (sPaymentType.equals("CORPORATE_REFUND")) {
          elePaymentMethod.setAttribute("PaymentType", sPaymentType);
          if (strResponse.equals(KohlsPOCConstant.A_OTR_RESPONSE_1F0)) {
            elePaymentMethod.setAttribute("ReasonCode",
                KohlsPOCConstant.CORPORATE_RESASON_CODE_1F0);

          } else if (strResponse.equals(KohlsPOCConstant.A_OTR_RESPONSE_F9)) {
            elePaymentMethod.setAttribute("ReasonCode", KohlsPOCConstant.CORPORATE_RESASON_CODE_F9);

          } else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde")))
              && eleExtn.getAttribute("ExtnSysResponseCde").equals("09")) {
            elePaymentMethod.setAttribute("ReasonCode", KohlsPOCConstant.CORPORATE_RESASON_CODE_09);

          } else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde")))
              && eleExtn.getAttribute("ExtnSysResponseCde").equals("11")) {
            elePaymentMethod.setAttribute("ReasonCode", "Offline to Intellicheck");

          } else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde")))
              && eleExtn.getAttribute("ExtnSysResponseCde").equals("12")) {
            elePaymentMethod.setAttribute("ReasonCode", "Offline to Mash");

          } else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde")))
              && eleExtn.getAttribute("ExtnSysResponseCde").equals("13")) {
            elePaymentMethod.setAttribute("ReasonCode", "Offline To SysRepublic");

          } else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnExpired")))
              && eleExtn.getAttribute("ExtnExpired").equalsIgnoreCase("Yes")) {
            elePaymentMethod.setAttribute("ReasonCode", "Expired");

          }


          else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde")))
              && eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE).equals("08")) {
            elePaymentMethod.setAttribute("ReasonCode", "Declined");

          } else if (!YFCCommon.isVoid(eleExtn)
              && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde")))
              && eleExtn.getAttribute("ExtnSysResponseCde").equals("10")) {
            elePaymentMethod.setAttribute("ReasonCode", "EditError");

          } else if (!YFCCommon.isVoid(eleOrder)
              && (!YFCCommon.isVoid(eleOrder.getAttribute("NoId")))
              && eleOrder.getAttribute("NoId").equals("Y")) {
            elePaymentMethod.setAttribute("ReasonCode", "No ID");

          } else if (!YFCCommon.isVoid(eleOrder)) {
            if ("S".equalsIgnoreCase(eleOrder.getAttribute("KeyedOrScanned"))
                && YFCCommon.isVoid(eleOrder.getAttribute("DriversLicense"))) {
              elePaymentMethod.setAttribute("ReasonCode", "Invalid Barcode");
            }
          } else if (!YFCCommon.isVoid(eleOrder)) {
            if ("KeyEntered".equalsIgnoreCase(eleOrder.getAttribute("CustomerIDSource"))
                && YFCCommon.isVoid(eleOrder.getAttribute("DriversLicense"))) {
              elePaymentMethod.setAttribute("ReasonCode", "Alternate ID");
            }
          } else {
            elePaymentMethod.setAttribute("ReasonCode", KohlsPOCConstant.CORPORATE_RESASON_CODE);
          }
          elePaymentMethod.setAttribute("DriversLicense", sDriverseLicence);

          Element eleKohlsPaymentList = SCXmlUtil.createChild(elePaymentMethod, "KohlsPaymentList");
          Element eleKohlsPayment = SCXmlUtil.createChild(eleKohlsPaymentList, "KohlsPayment");
          eleKohlsPayment.setAttribute("RefundAmount",
              docInOrder.getDocumentElement().getAttribute("RefundAmount"));
          eleKohlsPayment.setAttribute("StoreID", strStore);
          eleKohlsPayment.setAttribute("TerminalID", strTerminalId);

          eleKohlsPayment.setAttribute("TranNo", strTransNo);

        }
        elePaymentMethod.setAttribute("Amount",
            docInOrder.getDocumentElement().getAttribute("RefundAmount"));
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(docInOrder)) {

            logger.debug(
                "Returning order based on SyssRepublic Response" + SCXmlUtil.getString(docInOrder));
          }

        }

        eleExtnChangeOrder.setAttribute(KohlsPOCConstant.EXTN_ORIGINAL_TENDER, "N");
        // return docInOrder;
      } else {
        Element eleOTROrder = docInOTRPymntInfo.getDocumentElement();
        NodeList ndlOTRPaymentInfo = eleOTROrder.getElementsByTagName("KohlsOTRPayment");
        if (sGiftFlag.equals("true")) {
          /*
           * if (!YFCCommon.isVoid(eleExtn)) { eleExtnChangeOrder.setAttribute(KohlsPOCConstant.
           * EXTN_ORIGINAL_TENDER, "N"); }
           */
          Element elePaymentMethod = SCXmlUtil.createChild(elePaymentMethods, "PaymentMethod");
          Element eleKohlsPaymentList = SCXmlUtil.createChild(elePaymentMethod, "KohlsPaymentList");
          Element eleKohlsPayment = SCXmlUtil.createChild(eleKohlsPaymentList, "KohlsPayment");
          eleKohlsPayment.setAttribute("StoreID", strStore);
          eleKohlsPayment.setAttribute("TerminalID", strTerminalId);

          eleKohlsPayment.setAttribute("TranNo", strTransNo);
          elePaymentMethod.setAttribute("PaymentType", "KMC");
          elePaymentMethod.setAttribute("Amount",
              docInOrder.getDocumentElement().getAttribute("RefundAmount"));
          eleKohlsPayment.setAttribute("RefundAmount",
              docInOrder.getDocumentElement().getAttribute("RefundAmount"));

          return docInOrder;
        }
        if (ndlOTRPaymentInfo.getLength() > 0) {
          for (int i = 0; i < ndlOTRPaymentInfo.getLength(); i++) {
            Element elePaymentMethod = SCXmlUtil.createChild(elePaymentMethods, "PaymentMethod");
            if (!YFCCommon.isVoid(elePaymentMethod)) {
              Element eleOTRPayment = (Element) ndlOTRPaymentInfo.item(i);
              if (YFCLogUtil.isDebugEnabled()) {
                if (!YFCCommon.isVoid(eleOTRPayment)) {
                  logger.debug("In case if RS is online " + SCXmlUtil.getString(eleOTRPayment));
                }
              }
              elePaymentMethod.setAttribute("PaymentType",
                  eleOTRPayment.getAttribute("PaymentType"));
              String sPaymentTypeKey = eleOTRPayment.getAttribute("PaymentType");
              elePaymentMethod.setAttribute("CreditCardExpDate",
                  eleOTRPayment.getAttribute("ExpirationDate"));
              elePaymentMethod.setAttribute("Amount",
                  eleOTRPayment.getAttribute("AvailableAmount"));
              // CAPE - 263 changes
              if (eleOTRPayment.getAttribute("PaymentType").equals("CREDIT_CARD")
                  || eleOTRPayment.getAttribute("PaymentType").equals("DEBIT_CARD")) {
                elePaymentMethod.setAttribute("CreditCardNo",
                    eleOTRPayment.getAttribute("CreditCardNo"));

                if (eleOTRPayment.getAttribute("CreditCardType").equals("19")) {
                  elePaymentMethod.setAttribute("CreditCardType", "Debit");
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "DEBIT" + "-"
                      + eleOTRPayment.getAttribute("CreditCardNo");
                }

                if (eleOTRPayment.getAttribute("CreditCardType").equals("05")) {
                  elePaymentMethod.setAttribute("CreditCardType", "VISA");
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "VISA" + "-"
                      + eleOTRPayment.getAttribute("CreditCardNo");

                }

                if (eleOTRPayment.getAttribute("CreditCardType").equals("06")) {
                  elePaymentMethod.setAttribute("CreditCardType", "MASTERCARD");
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "MASTERCARD" + "-"
                      + eleOTRPayment.getAttribute("CreditCardNo");

                }

                if (eleOTRPayment.getAttribute("CreditCardType").equals("07")) {
                  elePaymentMethod.setAttribute("CreditCardType", "DISCOVER");
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "DISCOVER" + "-"
                      + eleOTRPayment.getAttribute("CreditCardNo");

                }

                if (eleOTRPayment.getAttribute("CreditCardType").equals("08")) {
                  elePaymentMethod.setAttribute("CreditCardType", "AMEX");
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "AMEX" + "-"
                      + eleOTRPayment.getAttribute("CreditCardNo");

                }
                sPaymentTypeKey =
                    sPaymentTypeKey + "-" + eleOTRPayment.getAttribute("CreditCardNo");
              } else if ("KOHLS_CHARGE_CARD"
                  .equalsIgnoreCase(eleOTRPayment.getAttribute("PaymentType"))) {
                elePaymentMethod.setAttribute("CreditCardType", "KOHLSCHARGE");
                elePaymentMethod.setAttribute("CreditCardNo",
                    eleOTRPayment.getAttribute("CreditCardNo"));
                sPaymentTypeKey = sPaymentTypeKey + "-" + "KOHLSCHARGE" + "-"
                    + eleOTRPayment.getAttribute("CreditCardNo");

              }
              sPaymentTypeKey = sPaymentTypeKey + "-" + eleOTRPayment.getAttribute("RefundSeqNo");
              mapsplitUpAmount.put(sPaymentTypeKey, eleOTRPayment.getAttribute("AvailableAmount"));
              // CAPE-4074 - start
              if (!YFCCommon.isVoid(eleOTRPayment.getAttribute("EntryMethod"))) {
                elePaymentMethod.setAttribute("EntryMethod",
                    eleOTRPayment.getAttribute("EntryMethod"));
              }
              // CAPE-4074 - end
            }
          }


          TreeMap<String, String> sortedMap = new TreeMap<String, String>(new Comparator<String>() {
            @Override
            public int compare(String s1, String s2) {
              String arrS1PaymentType[] = s1.split("-");
              String arrS2PaymentType[] = s2.split("-");
              String sRef1Seq = arrS1PaymentType[arrS1PaymentType.length - 1];
              String sRef2Seq = arrS2PaymentType[arrS2PaymentType.length - 1];
              Integer iRef1Seq = Integer.parseInt(sRef1Seq);
              Integer iRef2Seq = Integer.parseInt(sRef2Seq);
              return iRef1Seq.compareTo(iRef2Seq);
            }
          });

          sortedMap.putAll(mapsplitUpAmount);


          createSplitUpAmountForSingleReceipt(sortedMap,
              docInOrder.getDocumentElement().getAttribute("RefundAmount"), docInOrder, strStore,
              strTerminalId, strTransNo);
        } else {
          if (!YFCCommon.isVoid(eleExtnChangeOrder)) {
            eleExtnChangeOrder = XMLUtil.createChild(eleChangeOrderInRoot, KohlsPOCConstant.E_EXTN);
            eleExtnChangeOrder.setAttribute(KohlsPOCConstant.EXTN_ORIGINAL_TENDER, "N");
          }


          if (strResponse.contains(KohlsPOCConstant.A_OTR_RESPONSE_F0)
              && eleOrder.getAttribute("RefundAmount").equals("0.0")) {
            return docInOrder;

          } else {
            eleOrder.setAttribute("ProcessOfflineTendering", "Y");

          }
        }
      }
      // }

      if (!YFCCommon.isVoid(eleExtnChangeOrder)) {
        if (!YFCCommon.isVoid(eleExtnChangeOrder.getAttribute("ExtnOriginalTender"))) {
          if (eleExtnChangeOrder.getAttribute("ExtnOriginalTender").equals("N")) {
            Document docScanDetails = updteIDScanDetails(docInOrder);
            if (!YFCCommon.isVoid(docScanDetails)) {
              eleExtnChangeOrder.setAttribute("ExtnIDScanDetails",
                  XMLUtil.getXMLString(docScanDetails));
            }
            Document docChangeOrderTemplate =
                XMLUtil.getDocument(KohlsPOCConstant.CHANGE_ORDER_TEMPLATE);
            KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, "changeOrder", docChangeOrderIn);
          }
        }
      }
    }
    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(docInOrder)) {
        logger.debug("In case if RS is online " + SCXmlUtil.getString(docInOrder));
      }
    }
    logger.endTimer("KohlsPoCSysRepublic.createPaymentMethod");

    return docInOrder;
  }

  private void createSplitUpAmountForSingleReceipt(TreeMap mapsplitUpAmount, String sRefundAmount,
      Document docInOrder, String strStore, String strTerminalId, String strTransNo) {

    double dRefundAmount;
    try {
      dRefundAmount = Double.parseDouble(sRefundAmount);
    } catch (NumberFormatException nf) {
      dRefundAmount = 0;
    }
    String strRefundAmount = "";
    String strAmount = "";
    Iterator<Map.Entry<Integer, Integer>> itrPaymentTotal = mapsplitUpAmount.entrySet().iterator();
    Element elePaymentMethods = (Element) docInOrder.getElementsByTagName("PaymentMethods").item(0);
    while (itrPaymentTotal.hasNext()) {
      Map.Entry<Integer, Integer> itrPaymentTotalEntry = itrPaymentTotal.next();

      String arrPaymentType[] = String.valueOf(itrPaymentTotalEntry.getKey()).split("-");
      NodeList ndlPaymentMethod = elePaymentMethods.getElementsByTagName("PaymentMethod");

      for (int i = 0; i < ndlPaymentMethod.getLength(); i++) {

        Element elePaymentMethod = (Element) ndlPaymentMethod.item(i);

        if (!arrPaymentType[0].equals(elePaymentMethod.getAttribute("PaymentType"))) {

          continue;
        }

        Element eleKohlsPaymentList = XMLUtil.createChild(elePaymentMethod, "KohlsPaymentList");

        double dAmount = Double.parseDouble(String.valueOf(itrPaymentTotalEntry.getValue()));
        if (dRefundAmount <= dAmount) {

          strRefundAmount = String.format("%.2f", dRefundAmount);
          strAmount = String.format("%.2f", dAmount);
          dRefundAmount = Double.parseDouble(strRefundAmount);
          dAmount = Double.parseDouble(strAmount);

          logger.debug("KohlsPSATendering.distributeRefundAmount dRefundAmount=" + dRefundAmount
              + " dAmount=" + dAmount);

          dRefundAmount = 0;

          if (arrPaymentType[0].equals(elePaymentMethod.getAttribute("PaymentType"))) {
            if (arrPaymentType[0].equals("CREDIT_CARD") || arrPaymentType[0].equals("DEBIT_CARD")
                || arrPaymentType[0].equals("KOHLS_CHARGE_CARD")) {

              if (arrPaymentType[1].equals(elePaymentMethod.getAttribute("CreditCardType"))
                  && arrPaymentType[2].equals(elePaymentMethod.getAttribute("CreditCardNo"))) {
                Element elekohlsPayment = XMLUtil.createChild(eleKohlsPaymentList, "KohlsPayment");
                elekohlsPayment.setAttribute("RefundAmount", strRefundAmount);
                elekohlsPayment.setAttribute("PaymentType",
                    elePaymentMethod.getAttribute("PaymentType"));
                elekohlsPayment.setAttribute("StoreID", strStore);
                elekohlsPayment.setAttribute("TerminalID", strTerminalId);

                elekohlsPayment.setAttribute("TranNo", strTransNo);

              }
            } else {
              Element elekohlsPayment = XMLUtil.createChild(eleKohlsPaymentList, "KohlsPayment");
              elekohlsPayment.setAttribute("RefundAmount", strRefundAmount);
              elekohlsPayment.setAttribute("PaymentType",
                  elePaymentMethod.getAttribute("PaymentType"));
              elekohlsPayment.setAttribute("StoreID", strStore);
              elekohlsPayment.setAttribute("TerminalID", strTerminalId);

              elekohlsPayment.setAttribute("TranNo", strTransNo);

            }
          }

        } else {

          strRefundAmount = String.format("%.2f", dRefundAmount);
          strAmount = String.format("%.2f", dAmount);
          dRefundAmount = Double.parseDouble(strRefundAmount);
          dAmount = Double.parseDouble(strAmount);

          logger.debug("KohlsPSATendering.distributeRefundAmount dRefundAmount=" + dRefundAmount
              + " dAmount=" + dAmount);

          if (arrPaymentType[0].equals(elePaymentMethod.getAttribute("PaymentType"))) {
            if (arrPaymentType[0].equals("CREDIT_CARD") || arrPaymentType[0].equals("DEBIT_CARD")
                || arrPaymentType[0].equals("KOHLS_CHARGE_CARD")) {

              if (arrPaymentType[1].equals(elePaymentMethod.getAttribute("CreditCardType"))
                  && arrPaymentType[2].equals(elePaymentMethod.getAttribute("CreditCardNo"))) {
                Element elekohlsPayment = XMLUtil.createChild(eleKohlsPaymentList, "KohlsPayment");
                elekohlsPayment.setAttribute("RefundAmount", strAmount);
                elekohlsPayment.setAttribute("PaymentType",
                    elePaymentMethod.getAttribute("PaymentType"));
                elekohlsPayment.setAttribute("StoreID", strStore);
                elekohlsPayment.setAttribute("TerminalID", strTerminalId);

                elekohlsPayment.setAttribute("TranNo", strTransNo);

              }
            } else {
              Element elekohlsPayment = XMLUtil.createChild(eleKohlsPaymentList, "KohlsPayment");
              elekohlsPayment.setAttribute("RefundAmount", strAmount);
              elekohlsPayment.setAttribute("PaymentType",
                  elePaymentMethod.getAttribute("PaymentType"));
              elekohlsPayment.setAttribute("StoreID", strStore);
              elekohlsPayment.setAttribute("TerminalID", strTerminalId);

              elekohlsPayment.setAttribute("TranNo", strTransNo);

            }
          }

          dRefundAmount = dRefundAmount - dAmount;
        }

      }

    }

    // TODO Auto-generated method stub

  }

  /**
   * Create By *
   * 
   * @param strDrivingLic
   * @return
   */
  public String convertDL(String strDrivingLic) {
    logger.beginTimer("KohlsPoCSysRepublic.convertDL");
    logger.debug("input DL --:" + strDrivingLic);

    strDrivingLic = strDrivingLic.toUpperCase();

    String retDL = "";

    char[] dlArray = strDrivingLic.toCharArray();

    for (int i = 0; i < dlArray.length; i++) {
      char currentChar = dlArray[i];
      if (currentChar == '0' || currentChar == '1' || currentChar == '2' || currentChar == '3'
          || currentChar == '4' || currentChar == '5' || currentChar == '6' || currentChar == '7'
          || currentChar == '8' || currentChar == '9')
        retDL += currentChar;
      else {
        switch (currentChar) {
          case 'A': {
            retDL += "21";
            break;
          }
          case 'B': {
            retDL += "22";
            break;
          }
          case 'C': {
            retDL += "23";
            break;
          }
          case 'D': {
            retDL += "31";
            break;
          }
          case 'E': {
            retDL += "32";
            break;
          }
          case 'F': {
            retDL += "33";
            break;
          }
          case 'G': {
            retDL += "41";
            break;
          }
          case 'H': {
            retDL += "42";
            break;
          }
          case 'I': {
            retDL += "43";
            break;
          }
          case 'J': {
            retDL += "51";
            break;
          }
          case 'K': {
            retDL += "52";
            break;
          }
          case 'L': {
            retDL += "53";
            break;
          }
          case 'M': {
            retDL += "61";
            break;
          }
          case 'N': {
            retDL += "62";
            break;
          }
          case 'O': {
            retDL += "63";
            break;
          }
          case 'P': {
            retDL += "71";
            break;
          }
          case 'Q': {
            retDL += "11";
            break;
          }
          case 'R': {
            retDL += "72";
            break;
          }
          case 'S': {
            retDL += "73";
            break;
          }
          case 'T': {
            retDL += "81";
            break;
          }
          case 'U': {
            retDL += "82";
            break;
          }
          case 'V': {
            retDL += "83";
            break;
          }
          case 'W': {
            retDL += "91";
            break;
          }
          case 'X': {
            retDL += "92";
            break;
          }
          case 'Y': {
            retDL += "93";
            break;
          }
          case 'Z': {
            retDL += "12";
            break;
          }
          case '*': {
            retDL += "0";
            break;
          }
        }
      }
    }
    logger.debug("output  DL/Customer ID --:" + retDL);
    logger.endTimer("KohlsPoCSysRepublic.convertDL");
    return retDL;
  }

  /**
   * Create By *
   * 
   * @param env
   * @param eleOrder
   * @param strCustomerID
   * @param sFilePath
   * @param sLogToFile
   * @return
   * @throws ParserConfigurationException
   * @throws Exception
   */
  public Document sysRepublicCall(YFSEnvironment env, Element eleOrder, String strCustomerID,
      Document docOutGetDorderDetails) throws ParserConfigurationException {
    logger.beginTimer("KohlsPoCSysRepublic:sysRepublicCall");
    Document modifySysRepResponse = null;
    // Document docOutGetOrderList;
    try {
      /*
       * docOutGetOrderList = getOrderListCall(env,
       * eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY)); Element eleOrderGetOrderList =
       * XMLUtil .getChildElement(docOutGetOrderList.getDocumentElement(),
       * KohlsXMLLiterals.E_ORDER);
       */
      if (!YFCCommon.isVoid(docOutGetDorderDetails)) {
        Element eleGetOrderDetailsRoot = docOutGetDorderDetails.getDocumentElement();
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.INV_DATE_FORMAT);
        /*
         * Element eleOrderExtn = XMLUtil.getChildElement(eleOrderGetOrderList,
         * KohlsXMLLiterals.E_EXTN);
         */

        // preparing Sys republic WS Request
        Document docSysRepRequest = XMLUtil.createDocument("com:lpCashRefund");

        Element eleLpCashRefund = docSysRepRequest.getDocumentElement();
        eleLpCashRefund.setAttribute("xmlns:com", "http://com.kohls.lp.rm.cashrefund.service/");
        eleLpCashRefund.setAttribute("xmlns:cas",
            "http://www.kohls.com/ep/au/1.0/CashRefundRequest");

        Element eleArg = XMLUtil.createChild(eleLpCashRefund, "arg0");

        Element eleAssociateID = XMLUtil.createChild(eleArg, "cas:AssociateID");
        Element eleRegisterID = XMLUtil.createChild(eleArg, "cas:RegisterID");
        Element eleStoreID = XMLUtil.createChild(eleArg, "cas:StoreID");
        Element eleTransactionID = XMLUtil.createChild(eleArg, "cas:TransactionID");
        Element eleDateTime = XMLUtil.createChild(eleArg, "cas:Date_Time");
        Element eleCustomerID = XMLUtil.createChild(eleArg, "cas:CustomerID");
        Element eleCustomerIDSource = XMLUtil.createChild(eleArg, "cas:CustomerIDSource");
        Element eleTransactionAmount = XMLUtil.createChild(eleArg, "cas:TransactionAmount");

        eleAssociateID
            .setTextContent(eleGetOrderDetailsRoot.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
        eleRegisterID
            .setTextContent(eleGetOrderDetailsRoot.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
        eleTransactionID.setTextContent(
            eleGetOrderDetailsRoot.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));
        eleDateTime.setTextContent(sdf.format(date));

        eleStoreID.setTextContent(
            eleGetOrderDetailsRoot.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
        eleCustomerID.setTextContent(strCustomerID);

        eleTransactionAmount.setTextContent(eleOrder.getAttribute(KohlsPOCConstant.REFUND_AMT));
        eleCustomerIDSource.setTextContent("00");

        // invoking the SysRepblic WS and removing namespaces in the
        // response

        logger.debug("Input to sysRepublic WS" + XMLUtil.getXMLString(docSysRepRequest));

        String sFileName = "";
        String sContentToWrite = "";
        boolean bAppend = true;
        KohlcPoCWriteToFileUtil fileUtil = null;

        /*
         * logger.debug( "Input xml for Kohls Cash webservice is: " +
         * XMLUtil.getXMLString(docSysRepRequest)); logger.debug( "is Log to file  ::" +
         * sLogToFile); logger.debug( "Log to file Directory for Sys Republic  ::" + sFilePath);
         */

        Document responseDocSysRepublicWS =
            KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_SYS_REP_WS, docSysRepRequest);

        logger.debug(
            "Response from sys Republic ::: " + XMLUtil.getXMLString(responseDocSysRepublicWS));

        Document docOutNameSpaceRemoval = KOHLSBaseApi.invokeService(env,
            KohlsPOCConstant.KOHLS_NAME_SPACE_REMOVER, responseDocSysRepublicWS);

        modifySysRepResponse = modifyResponse(env, docOutNameSpaceRemoval, strCustomerID);
        logger.debug("Responce to XML format" + XMLUtil.getXMLString(modifySysRepResponse));

      }
      logger.endTimer("KohlsPoCSysRepublic:sysRepublicCall");
      return modifySysRepResponse;

    } catch (Exception e) {
      isSysRepOffLine = true;
      return modifyResponse(env, XMLUtil.createDocument("Errors"), strCustomerID);
    }
  }

  /**
   * Create By *
   * 
   * @param env
   * @param responseDocSysRepublicWS
   * @param strCustomerID
   * @return
   * @throws ParserConfigurationException
   */
  private Document modifyResponse(YFSEnvironment env, Document responseDocSysRepublicWS,
      String strCustomerID) throws ParserConfigurationException {
    logger.beginTimer("KohlsPoCSysRepublic:modifyResponse");

    // creating modified response doc
    Document docModifiedRes = XMLUtil.createDocument("CashRefundResponse");
    Element eleModifiedReturn =
        XMLUtil.createChild(docModifiedRes.getDocumentElement(), KohlsPOCConstant.RETURN);

    if (!isSysRepOffLine) {
      Element eleCashRefundResponse = responseDocSysRepublicWS.getDocumentElement();

      Element eleReturn = XMLUtil.getChildElement(eleCashRefundResponse, "return");

      if (!YFCCommon.isVoid(XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.REGISTER_ID)))
        eleModifiedReturn.setAttribute(KohlsPOCConstant.REGISTER_ID,
            XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.REGISTER_ID).getTextContent());

      if (!YFCCommon.isVoid(XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.STORE_ID)))
        eleModifiedReturn.setAttribute(KohlsPOCConstant.STORE_ID,
            XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.STORE_ID).getTextContent());

      if (!YFCCommon.isVoid(XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.TRANSACTION_ID)))
        eleModifiedReturn.setAttribute(KohlsPOCConstant.TRANSACTION_ID,
            XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.TRANSACTION_ID).getTextContent());

      if (!YFCCommon.isVoid(XMLUtil.getChildElement(eleReturn, "Date_Time")))
        eleModifiedReturn.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME,
            XMLUtil.getChildElement(eleReturn, "Date_Time").getTextContent());

      if (!YFCCommon
          .isVoid(XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.A_APPROVAL_NUMBER))) {
        eleModifiedReturn.setAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER, XMLUtil
            .getChildElement(eleReturn, KohlsPOCConstant.A_APPROVAL_NUMBER).getTextContent());

      }

      if (!YFCCommon
          .isVoid(XMLUtil.getChildElement(eleReturn, KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE))) {
        eleModifiedReturn.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE, XMLUtil
            .getChildElement(eleReturn, KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE).getTextContent());

      }

      eleModifiedReturn.setAttribute(KohlsPOCConstant.A_SYS_APPROVAL_SRC_CDE, "02");
    } else {
      eleModifiedReturn.setAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER, "999999");
      eleModifiedReturn.setAttribute(KohlsPOCConstant.A_SYS_APPROVAL_SRC_CDE, "00");
      eleModifiedReturn.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE, "Offline");
    }

    eleModifiedReturn.setAttribute(KohlsPOCConstant.ATTR_DRIVERS_LICENSE, strCustomerID);

    // taking WS call time and setting to Return Element.
    String timetakenForWSCall = (String) env.getTxnObject("Timetaken_WSCall");
    if (!YFCCommon.isVoid(timetakenForWSCall)) {
      Double dTimetakenForWSCall = Double.parseDouble(timetakenForWSCall);
      eleModifiedReturn.setAttribute(KohlsPOCConstant.A_EXTN_SYS_AUTH_TIME,
          df.format(dTimetakenForWSCall / 100));
    } else {
      eleModifiedReturn.setAttribute(KohlsPOCConstant.A_EXTN_SYS_AUTH_TIME, "0.00");
    }
    logger.endTimer("KohlsPoCSysRepublic:modifyResponse");
    logger.debug("modified responce " + XMLUtil.getXMLString(docModifiedRes));

    return docModifiedRes;
  }

  /**
   * Create By *
   * 
   * @param env
   * @param strOHK
   * @return
   * @throws Exception
   */
  private Document getOrderListCall(YFSEnvironment env, String strOHK) throws Exception {

    // Input Doc getOrderList
    Document docInGetOrderList = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    docInGetOrderList.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
        strOHK);

    // Template Doc getOrderList
    Document docTempGetOrderList = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDERLIST);
    Element eleOrder =
        XMLUtil.createChild(docTempGetOrderList.getDocumentElement(), KohlsXMLLiterals.E_ORDER);
    Element eleExtnOrder = XMLUtil.createChild(eleOrder, KohlsXMLLiterals.E_EXTN);

    // invoking getOrderList
    return KOHLSBaseApi.invokeAPI(env, docTempGetOrderList, KohlsPOCConstant.API_GET_ORDER_LIST,
        docInGetOrderList);

  }

  /**
   * Create By *
   * 
   * @param env
   * @param inDoc
   * @param repsonseSysRepublic
   * @return
   */
  private Document callChangeOrder(YFSEnvironment env, Document docInputXML,
      Document docInIntelliCheck, Document docOutRefundAmount) {
    logger.beginTimer("KohlsPoCSysRepublic.callChangeOrder");
    Document docChangeOrderOut = null;
    Element eleInDoc = docInputXML.getDocumentElement();
    String sResponseCode = "";
    String sApprovalNumber = "";
    Element eleResponseSysRepublic = null;
    String sOrderHeaderKey = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    String sCustomerIDSource = docInputXML.getDocumentElement().getAttribute("CustomerIDSource");

    SimpleDateFormat tempdf = new SimpleDateFormat("dd/MM/YYYY");
    if (!YFCCommon.isVoid(docInIntelliCheck)) {
      if (!YFCCommon.isVoid(docInIntelliCheck.getDocumentElement())) {
        eleResponseSysRepublic = docInIntelliCheck.getDocumentElement();
      }
    }
    if (!YFCCommon.isVoid(eleResponseSysRepublic)) {
      if (!YFCCommon
          .isVoid(eleResponseSysRepublic.getAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER_SYS))) {

        sApprovalNumber =
            XMLUtil.getAttribute(eleResponseSysRepublic, KohlsPOCConstant.A_APPROVAL_NUMBER_SYS);
      }
      if (!YFCCommon
          .isVoid(eleResponseSysRepublic.getAttribute(KohlsPOCConstant.A_RESPONSE_CODE))) {

        sResponseCode =
            XMLUtil.getAttribute(eleResponseSysRepublic, KohlsPOCConstant.A_RESPONSE_CODE);

      } /*
         * String sDLForSys = XMLUtil.getAttribute(eleReturn, KohlsPOCConstant.A_DRIVERS_LICENSE);
         */
    }
    if (YFCCommon.isVoid(eleResponseSysRepublic)) {
      sResponseCode = "Offline";

    } else {
      Element eleError = (Element) eleResponseSysRepublic.getElementsByTagName("Error").item(0);

      if (!YFCCommon.isVoid(eleError)) {
        if (sCustomerIDSource.equals("Scanned") 
        		&& (eleError.getAttribute("ErrorDescription").contains("500")
              || YFCCommon.isVoid(eleResponseSysRepublic)
              || eleError.getAttribute("ErrorDescription").contains("503"))) {
        	    sResponseCode = "Offline_To_IntelliCheck";          
        } else if (sCustomerIDSource.equals("KeyEntered") &&
              (eleError.getAttribute("ErrorDescription").contains("500")
              || YFCCommon.isVoid(eleResponseSysRepublic)
              || eleError.getAttribute("ErrorDescription").contains("503"))) {
            sResponseCode = "Offline_To_SysRepublic";
        } else {
          sResponseCode = "Offline_To_Mash";
        }

      }

    }
    Document docChangeOrderDoc = null;

    try {

      docChangeOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
      Element eleChangeOrder = docChangeOrderDoc.getDocumentElement();
      eleChangeOrder.setAttribute("IgnoreRepricingUE", "Y");
      eleChangeOrder.setAttribute("Override", "Y");
      eleChangeOrder.setAttribute("Action", "MODIFY");
      XMLUtil.setAttribute(eleChangeOrder, KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
      // Element eleChangeOrderPersonInfoBillto = XMLUtil.cre(eleChangeOrder,
      // KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
      Element eleChangeOrderPersonInfoBillto =
          docChangeOrderDoc.createElement(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
      eleChangeOrder.appendChild(eleChangeOrderPersonInfoBillto);

      Element eleChangeOrderExtn = XMLUtil.createChild(eleChangeOrder, KohlsXMLLiterals.E_EXTN);
      XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_NO,
          sApprovalNumber);

      // code change for CAPE-4359
      if (sCustomerIDSource.equals("KeyEntered") && !YFCCommon.isVoid(
          docInputXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_DRIVERS_LICENSE))) {
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_DL_FOR_SYS,
            docInputXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_DRIVERS_LICENSE));
      }

      if ("Approval".equalsIgnoreCase(sResponseCode)) {
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE, "00");
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_TYPE_CDE,
            "A");
      } else if ("CashRefundDenied".equalsIgnoreCase(sResponseCode)) {
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE, "03");
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_TYPE_CDE,
            "R");

        // End code change for CAPE-4359
      } else if ("customeridrequired".equalsIgnoreCase(sResponseCode)
          || "dollarlimitexceeded".equalsIgnoreCase(sResponseCode)
          || "storelimitexceeded".equalsIgnoreCase(sResponseCode)
          || "kohlsauthrequired".equalsIgnoreCase(sResponseCode)
          || "Declined".equals(sResponseCode)) {
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE, "08");
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_TYPE_CDE,
            "R");
      } else if (sResponseCode.contains("Offline") ||sResponseCode.equalsIgnoreCase( "EditError")
          || YFCCommon.isVoid(sResponseCode)) {
        String sRefundAmount = docOutRefundAmount.getDocumentElement().getAttribute("RefundAmount");
        double dRefundAmount = 0.00;
        if (!YFCCommon.isVoid(sRefundAmount)) {
          dRefundAmount = Double.parseDouble(sRefundAmount);
        }
        String sSysRepublicFloorLimit = this.getRuleValue(env, "REFUND_FLOOR_LIMIT");
        Double dSysRepublicFloorLimit = 0.00D;
        if (!YFCCommon.isVoid(sSysRepublicFloorLimit)) {
          dSysRepublicFloorLimit = Double.parseDouble(sSysRepublicFloorLimit);
        }
        if (dRefundAmount <= dSysRepublicFloorLimit) {
          XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_NO,
              "000000");
          XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE, "00");

        } else {
          XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_NO,
              "999999");
          if (sResponseCode.equalsIgnoreCase("EditError")) {
            XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE,
                "10");

          } else if (YFCCommon.isVoid(sResponseCode) || sResponseCode.equalsIgnoreCase("Offline_To_IntelliCheck")) {
            XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE,
                "11");

          } else if (sResponseCode.equalsIgnoreCase("Offline_To_Mash")) {
            XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE,
                "12");

          } else if (sResponseCode.equalsIgnoreCase("Offline_To_SysRepublic")) {
            XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE,
                "13");

          } else {
            XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_REPSONSE_CDE,
                "09");
          }
        }
        XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_SYS_APPROVAL_TYPE_CDE,
            "F");
      }


      if (!YFCCommon.isVoid(eleResponseSysRepublic)) {
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("dlidNumberRaw"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, KohlsPOCConstant.A_EXTN_DL_FOR_SYS,
              eleResponseSysRepublic.getAttribute("dlidNumberRaw"));
        }

        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("processResult"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnProcessResult",
              eleResponseSysRepublic.getAttribute("processResult"));
        }

        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("extendedResultCode"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnExtendedResultCode",
              eleResponseSysRepublic.getAttribute("extendedResultCode"));
        }

        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("mediaType"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnMediaType",
              eleResponseSysRepublic.getAttribute("mediaType"));

        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("issuingJurisdictionCvt"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnIssueJurisdicationCvt",
              eleResponseSysRepublic.getAttribute("issuingJurisdictionCvt"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("issuingJurisdictionAbbrv"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnIssueJurisdicationAbbr",
              eleResponseSysRepublic.getAttribute("issuingJurisdictionAbbrv"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("expired"))) {

          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnExpired",
              eleResponseSysRepublic.getAttribute("expired"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("expirationDate"))) {

          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnExpiryDate",
              eleResponseSysRepublic.getAttribute("expirationDate"));
        }

        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("issueDate"))) {

          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnIssueDate",
              eleResponseSysRepublic.getAttribute("issueDate"));
        }

        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("dlidNumberFormatted"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnDLNumberFormat",
              eleResponseSysRepublic.getAttribute("dlidNumberFormatted"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("uniqueId"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnUniqueID",
              eleResponseSysRepublic.getAttribute("uniqueId"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("testCard"))) {
          XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnTestCard",
              eleResponseSysRepublic.getAttribute("testCard"));

        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("address1"))) {
          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "AddressLine1",
              eleResponseSysRepublic.getAttribute("address1"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("address2"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "AddressLine2",
              eleResponseSysRepublic.getAttribute("address2"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("city"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "City",
              eleResponseSysRepublic.getAttribute("city"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("firstName"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "FirstName",
              eleResponseSysRepublic.getAttribute("firstName"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("lastName"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "LastName",
              eleResponseSysRepublic.getAttribute("lastName"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("middleName"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "MiddleName",
              eleResponseSysRepublic.getAttribute("middleName"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("postalCode"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "ZipCode",
              eleResponseSysRepublic.getAttribute("postalCode"));
        }
        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("state"))) {

          XMLUtil.setAttribute(eleChangeOrderPersonInfoBillto, "State",
              eleResponseSysRepublic.getAttribute("state"));
        }

        Element elePersonInfoBillToExtn =
            XMLUtil.createChild(eleChangeOrderPersonInfoBillto, KohlsPOCConstant.E_EXTN);

        if (!YFCCommon.isVoid(eleResponseSysRepublic.getAttribute("dateOfBirth"))) {
          XMLUtil.setAttribute(elePersonInfoBillToExtn, "ExtnDateOfBirth",
              eleResponseSysRepublic.getAttribute("dateOfBirth"));
        }
      }
      logger.debug("Input Xml to changeOrder call  " + SCXmlUtil.getString(docChangeOrderDoc));
      Document docOutIdscanDetails = updteIDScanDetails(docInputXML);
      if (!YFCCommon.isVoid(docOutIdscanDetails)) {
        XMLUtil.setAttribute(eleChangeOrderExtn, "ExtnIDScanDetails",
            SCXmlUtil.getString(docOutIdscanDetails));
      }

      if (!YFCCommon.isVoid(eleChangeOrderPersonInfoBillto)) {
        if (eleChangeOrderPersonInfoBillto.getAttributes().getLength() == 0) {

          eleChangeOrder.removeChild(eleChangeOrderPersonInfoBillto);
        }

      }
      Document docChangeOrderTemplate = XMLUtil.getDocument(KohlsPOCConstant.CHANGE_ORDER_TEMPLATE);

      docChangeOrderOut = invokeAPI(env, docChangeOrderTemplate, KohlsPOCConstant.API_CHANGE_ORDER,
          docChangeOrderDoc);
      logger.debug("changeOrder call Output " + SCXmlUtil.getString(docChangeOrderOut));

      // TODO Auto-generated catch block e.printStackTrace(); }
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    logger.endTimer("KohlsPoCSysRepublic.callChangeOrder");
    return docChangeOrderDoc;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param docInSysRepublicResponse
   * @param sRefundAmount
   * @param env
   * @param docInOrder
   * @return
   * @throws Exception
   */
  private String setPaymentMethod(Document docInGetOrderDetails, String sRefundAmount,
      YFSEnvironment env, Document docInOrder, Document docInOTRPymntInfo) throws Exception {
    logger.beginTimer("KohlsPoCSysRepublic.setPaymentMethod");
    double dRefundAmount = 0.0;
    if (!YFCCommon.isVoid(sRefundAmount)) {
      dRefundAmount = Double.parseDouble(sRefundAmount);
    }
    Element eleOrderDetails = docInGetOrderDetails.getDocumentElement();
    Element eleExtn =
        (Element) eleOrderDetails.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
    double dFloorLimit = 0.0;
    boolean bStateFilter = false;
    Element eleOrder = docInOrder.getDocumentElement();

    String sExtnExtendedResultCode = eleExtn.getAttribute("ExtnExtendedResultCode");
    if ((!YFCCommon.isVoid(sExtnExtendedResultCode)) && sExtnExtendedResultCode.contains("LAW")) {
      bStateFilter = true;
    }

    if (!YFCCommon.isVoid(eleOrder)) {

      if (!YFCCommon.isVoid(eleOrder.getAttribute("NoId"))
          && "Y".equalsIgnoreCase(eleOrder.getAttribute("NoId"))) {
        return "CORPORATE_REFUND";


      }
    }
    // String sFlag=getScanIDDetails(docInOrder, env, docInGetOrderDetails);
    if (eleOrder.getAttribute("CustomerIDSource").equalsIgnoreCase("KeyEntered")) {

      if (YFCCommon.isVoid(eleOrder.getAttribute("DriversLicense"))) {
        return "CORPORATE_REFUND";
      }
    }

    /*
     * if(eleOrder.getAttribute("CustomerIDSource").equalsIgnoreCase("KeyEntered")){
     * 
     * if(eleOrder.getAttribute("KeyedOrScanned").equalsIgnoreCase("S")) { return
     * "CORPORATE_REFUND"; } }
     */


    if (!YFCCommon.isVoid(eleExtn)) {

      // CAPE-1741 -- START
      if (!YFCCommon.isVoid(this.strResponse) && this.strResponse.contains("F8")) {
        logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
        return "CORPORATE_REFUND";
      }
      if (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnExpired"))
          && eleExtn.getAttribute("ExtnExpired").equalsIgnoreCase("yes")) {
        logger.debug("ExtnDLNumberFormat------> " + eleExtn.getAttribute("ExtnDLNumberFormat"));

        logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");

        return "CORPORATE_REFUND";
      }



      if (YFCCommon.isVoid(eleExtn.getAttribute("ExtnExtendedResultCode"))
          && (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnProcessResult")))) {
        if ((eleExtn.getAttribute("ExtnProcessResult")).equalsIgnoreCase("DocumentFinancial")
            || (eleExtn.getAttribute("ExtnProcessResult")).equalsIgnoreCase("DocumentUnknown")
            || (eleExtn.getAttribute("ExtnProcessResult")).equalsIgnoreCase("DocumentDecryptFail")
            || eleExtn.getAttribute("ExtnProcessResult").equalsIgnoreCase("DocumentBadRead")) {
          logger.debug("Extnded Result Code " + eleExtn.getAttribute("ExtnExtendedResultCode"));

          logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");

          return "CORPORATE_REFUND";
        }
        // CAPE-1741 -- END
      }



      String sSysRepublicResponseCode = eleExtn.getAttribute("ExtnSysResponseCde");

      if (sSysRepublicResponseCode.equals("00")) {
        if ((sExtnPOCFeature.equals("ReceiptedReturn"))
            || (sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT))) {

          if (sGiftFlag.equals("true")) {
            logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
            return KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT;
          } else {
            logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
            return "";
          }
        } else // CAPE-1743 :Non-Receipted & Level 1 Response Begin
        if ("NonReceiptedReturn".equalsIgnoreCase(this.sExtnPOCFeature)) {
          logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
          return "CASH";
        }
        // CAPE-1743 :Non-Receipted & Level 1 Response End
      } else if (sSysRepublicResponseCode.equals("09") || sSysRepublicResponseCode.equals("10")
          || sSysRepublicResponseCode.equals("11") || sSysRepublicResponseCode.equals("12")
          || sSysRepublicResponseCode.equals("13")) {

        String sFloorLimit = this.getRuleValue(env, "REFUND_FLOOR_LIMIT");
        dFloorLimit = Double.parseDouble(sFloorLimit);
        if (dRefundAmount > dFloorLimit) {
          logger.debug("First if Block of Offline");
          logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
          return "CORPORATE_REFUND";

        } else if (this.sExtnPOCFeature.equals("NonReceiptedReturn")) {
          if (dRefundAmount <= dFloorLimit) {

            logger.debug("Non Receipted Offline");
            logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
            return "CASH";
          }
        } else if (this.sExtnPOCFeature.equals("ReceiptedReturn")
            || this.sExtnPOCFeature.equals("PriceAdjustment")) {
          if (dRefundAmount <= dFloorLimit) {

            logger.debug("Non Receipted Offline");
            Element eleOTROrder = docInOTRPymntInfo.getDocumentElement();
            NodeList ndlOTRPaymentInfo = eleOTROrder.getElementsByTagName("KohlsOTRPayment");
            if (ndlOTRPaymentInfo.getLength() == 0) {
              logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
              return "CASH";
            }
          }
        }
        if (sGiftFlag.equals("true")) {
          if (dRefundAmount <= dFloorLimit) {
            logger.debug("Gift Flag floor limit");
            logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
            return "KMC";
          }
        }
      } else if (sSysRepublicResponseCode.equals("03")) {
        logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
        return "KMC";

      } else if (sSysRepublicResponseCode.equals("08")) {
        logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
        return "CORPORATE_REFUND";
      }

      if (YFCCommon.isVoid(eleExtn.getAttribute("ExtnDLNumberFormat"))
          && YFCCommon.isVoid(eleExtn.getAttribute("ExtnDLForSys"))
          && eleOrder.getAttribute("CustomerIDSource").equalsIgnoreCase("Scanned")
          && (!bStateFilter)) {
        logger.debug("Blank ExtnDLNumberFormat for Scanning------> "
            + eleExtn.getAttribute("ExtnDLNumberFormat"));
        logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
        return "CORPORATE_REFUND";
      }


    }
    logger.endTimer("KohlsPoCSysRepublic.setPaymentMethod");
    return "";
  }

  public String getRuleValue(YFSEnvironment env, String strRuleID) throws Exception {
    logger.beginTimer("KohlsPoCSysRepublic.getRuleValue");
    Document docInput = YFCDocument.createDocument("Rule").getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute("OrganizationCode", "KOHLS-RETAIL");
    eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, strRuleID);
    Document docOutRule =
        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docInput);
    if (!YFCCommon.isVoid(docOutRule)) {
      Element eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);

      if (!YFCCommon.isVoid(eleRule)) {
        logger.endTimer("KohlsPoCSysRepublic.getRuleValue");
        return eleRule.getAttribute("RuleValue");
      }
    }
    logger.endTimer("KohlsPoCSysRepublic.getRuleValue");
    return "";
  }

  @SuppressWarnings("unchecked")
  private Document createPaymentMethodForMultiReceipt(Document inSplitDoc, Document inDoc) {
    logger.beginTimer("KohlsPOCSysRepublic.createPaymentMethodForMultiReceipt");
    TreeMap mapPaymentTotal = new TreeMap();
    HashMap mapSplitPaymentTotal = new HashMap();
    HashMap<String, String> mapExpirationDate = new HashMap<String, String>();
    HashMap<String, String> mapEntryMethod = new HashMap<String, String>();
    double dTempTotalPayment = 0.0;
    double dRefundAmount = 0.0;
    NodeList ndlOTROrder = inSplitDoc.getDocumentElement().getElementsByTagName("KohlsOTROrder");
    if (!YFCCommon.isVoid(ndlOTROrder)) {
      for (int i = 0; i < ndlOTROrder.getLength(); i++) {
        String strRefundAmount = "";
        String sPaymentTypeKey = "";

        Element eleOTROrder = (Element) ndlOTROrder.item(i);
        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(eleOTROrder)) {
            logger.debug("OtrOrderDetails " + SCXmlUtil.getString(eleOTROrder));
          }
        }
        String sConactOrderPayment = eleOTROrder.getAttribute("StoreID") + "-"
            + eleOTROrder.getAttribute("TerminalID") + "-" + eleOTROrder.getAttribute("TranNo");

        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(sConactOrderPayment)) {
            logger.debug("sConactOrderPayment " + sConactOrderPayment);
          }
        }
        String sTempRefundAmount = mapOrderRefundAmount.get(sConactOrderPayment);
        if (!YFCCommon.isVoid(sTempRefundAmount)) {
          dRefundAmount = Double.parseDouble(sTempRefundAmount);
        }

        if (YFCLogUtil.isDebugEnabled()) {
          if (!YFCCommon.isVoid(dRefundAmount)) {
            logger.debug("RefundAmount " + dRefundAmount);
          }
        }

        if (!YFCCommon.isVoid(sTempRefundAmount)) {
          NodeList ndlKohlsOTRPayment =
              (NodeList) eleOTROrder.getElementsByTagName("KohlsOTRPayment");
          for (int j = 0; j < ndlKohlsOTRPayment.getLength(); j++) {

            sConactOrderPayment = eleOTROrder.getAttribute("StoreID") + "-"
                + eleOTROrder.getAttribute("TerminalID") + "-" + eleOTROrder.getAttribute("TranNo");

            Element eleKohlsOTRPaymentMethod = (Element) ndlKohlsOTRPayment.item(j);
            if (YFCLogUtil.isDebugEnabled()) {
              if (!YFCCommon.isVoid(eleOTROrder)) {
                logger.debug("eleKohlsOTRPaymentMethod-----> "
                    + SCXmlUtil.getString(eleKohlsOTRPaymentMethod));
              }
            }
            // System.out.println("the attribute is
            // "+elePaymentLt.getAttribute("AvailableAmount"));
            String strAmount = eleKohlsOTRPaymentMethod.getAttribute("AvailableAmount");
            if (!YFCCommon.isVoid(strAmount)) {
              double dAmount = Double.parseDouble(strAmount);
              if (YFCLogUtil.isDebugEnabled()) {
                if (!YFCCommon.isVoid(dAmount)) {
                  logger.debug("Amount-----> " + dAmount);
                }
              }

              String sCreditCardNo = eleKohlsOTRPaymentMethod.getAttribute("CreditCardNo");
              if (!YFCCommon.isVoid(sCreditCardNo)) {
                String sExpirationDate = eleKohlsOTRPaymentMethod.getAttribute("ExpirationDate");
                logger.debug("ExpirationDate is: " + sExpirationDate);
                if (mapExpirationDate.containsKey(sCreditCardNo)) {
                  String sExpDateTemp = mapExpirationDate.get(sCreditCardNo);
                  if (sExpDateTemp.compareTo(sExpirationDate) < 0) {
                    logger.debug("Old expiration date is found in Map - " + sExpDateTemp
                        + ", Replacing with new ExpirationDate: " + sExpirationDate);
                    mapExpirationDate.put(sCreditCardNo, sExpirationDate);
                  }
                } else {
                  mapExpirationDate.put(sCreditCardNo, sExpirationDate);
                }
                
                mapEntryMethod.put(sCreditCardNo,
                    eleKohlsOTRPaymentMethod.getAttribute("EntryMethod"));
                logger.debug(
                    "EntryMethod is: " + eleKohlsOTRPaymentMethod.getAttribute("EntryMethod"));
              }

              if (eleKohlsOTRPaymentMethod.getAttribute("PaymentType").equals("CREDIT_CARD")) {

                sPaymentTypeKey =
                    eleKohlsOTRPaymentMethod.getAttribute("PaymentType") + "-" + sCreditCardNo;

                if (eleKohlsOTRPaymentMethod.getAttribute("CreditCardType").equals("05")) {
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "VISA";
                }

                if (eleKohlsOTRPaymentMethod.getAttribute("CreditCardType").equals("06")) {
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "MASTERCARD";
                }

                if (eleKohlsOTRPaymentMethod.getAttribute("CreditCardType").equals("07")) {
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "DISCOVER";
                }

                if (eleKohlsOTRPaymentMethod.getAttribute("CreditCardType").equals("08")) {
                  sPaymentTypeKey = sPaymentTypeKey + "-" + "AMEX";
                }
              } else if ("KOHLS_CHARGE_CARD"
                  .equalsIgnoreCase(eleKohlsOTRPaymentMethod.getAttribute("PaymentType"))) {
                sPaymentTypeKey =
                    eleKohlsOTRPaymentMethod.getAttribute("PaymentType") + "-" + sCreditCardNo;
                sPaymentTypeKey = sPaymentTypeKey + "-" + "KOHLSCHARGE";
              } else if ("CASH"
                  .equalsIgnoreCase(eleKohlsOTRPaymentMethod.getAttribute("PaymentType"))) {
                sPaymentTypeKey = "CASH";
              } else if ("KMC"
                  .equalsIgnoreCase(eleKohlsOTRPaymentMethod.getAttribute("PaymentType"))) {
                sPaymentTypeKey = "KMC";
              } else if ("DEBIT_CARD"
                  .equalsIgnoreCase(eleKohlsOTRPaymentMethod.getAttribute("PaymentType"))) {
                sPaymentTypeKey =
                    eleKohlsOTRPaymentMethod.getAttribute("PaymentType") + "-" + sCreditCardNo;
                sPaymentTypeKey = sPaymentTypeKey + "-" + "DEBIT";
              }

              /*
               * // CAPE-4074 - start if
               * (!YFCCommon.isVoid(eleKohlsOTRPaymentMethod.getAttribute("EntryMethod"))) {
               * sPaymentTypeKey = sPaymentTypeKey + "-" +
               * eleKohlsOTRPaymentMethod.getAttribute("EntryMethod"); } // CAPE-4074 - end
               */

              sConactOrderPayment = sConactOrderPayment + "-" + sPaymentTypeKey;

              if (YFCLogUtil.isDebugEnabled()) {
                if (!YFCCommon.isVoid(sConactOrderPayment)) {
                  logger.debug("sConactOrderPayment-----> " + sConactOrderPayment);
                }
              }
              if (dRefundAmount != 0.0) {
                if (dRefundAmount <= dAmount) {

                  if (YFCLogUtil.isDebugEnabled()) {
                    if (!YFCCommon.isVoid(sConactOrderPayment)) {
                      logger.debug("In the First if block of refund condition -----> ");
                    }
                  }
                  strRefundAmount = df.format(dRefundAmount);
                  strAmount = df.format(dAmount);
                  dRefundAmount = Double.parseDouble(strRefundAmount);
                  dAmount = Double.parseDouble(strAmount);

                  if (mapPaymentTotal.containsKey(sPaymentTypeKey)) {

                    dTempTotalPayment =
                        dRefundAmount + (double) (mapPaymentTotal.get(sPaymentTypeKey));

                    mapPaymentTotal.put(sPaymentTypeKey, dTempTotalPayment);

                    if (YFCLogUtil.isDebugEnabled()) {
                      if (!YFCCommon.isVoid(sConactOrderPayment)) {
                        logger.debug("Summation of Payment -----> " + dTempTotalPayment
                            + "Payment Type-------->" + sPaymentTypeKey);
                      }
                    }
                  } else {
                    if (YFCLogUtil.isDebugEnabled()) {
                      if (!YFCCommon.isVoid(sConactOrderPayment)) {
                        logger.debug("in else Summation of Payment -----> " + dTempTotalPayment
                            + "Payment Type-------->" + sPaymentTypeKey);
                      }
                    }
                    mapPaymentTotal.put(sPaymentTypeKey, dRefundAmount);
                  }

                  if (!YFCCommon.isVoid(mapSplitPaymentTotal.get(sConactOrderPayment))) {
                    Double dTempSplitAmt = Double
                        .parseDouble(String.valueOf(mapSplitPaymentTotal.get(sConactOrderPayment)));
                    mapSplitPaymentTotal.put(sConactOrderPayment, dTempSplitAmt + dRefundAmount);
                  } else {
                    mapSplitPaymentTotal.put(sConactOrderPayment, dRefundAmount);
                  }

                  dRefundAmount = 0;

                } else {

                  if (YFCLogUtil.isDebugEnabled()) {
                    if (!YFCCommon.isVoid(sConactOrderPayment)) {
                      logger.debug(" else Block of Refund Calculation--->");
                    }
                  }
                  strRefundAmount = df.format(dRefundAmount);
                  strAmount = df.format(dAmount);
                  dRefundAmount = Double.parseDouble(strRefundAmount);
                  dAmount = Double.parseDouble(strAmount);

                  // System.out.println("the amount is " + dAmount);
                  if (!YFCCommon.isVoid(mapSplitPaymentTotal.get(sConactOrderPayment))) {
                    Double dTempSplitAmt = Double
                        .parseDouble(String.valueOf(mapSplitPaymentTotal.get(sConactOrderPayment)));
                    mapSplitPaymentTotal.put(sConactOrderPayment, dTempSplitAmt + dAmount);
                  } else {
                    mapSplitPaymentTotal.put(sConactOrderPayment, dAmount);
                  }

                  if (mapPaymentTotal.containsKey(sPaymentTypeKey)) {

                    dTempTotalPayment = dAmount + (double) (mapPaymentTotal.get(sPaymentTypeKey));

                    mapPaymentTotal.put(sPaymentTypeKey, dTempTotalPayment);
                    // System.out.println("the value is " + dTempTotalPayment);
                    if (YFCLogUtil.isDebugEnabled()) {
                      if (!YFCCommon.isVoid(sConactOrderPayment)) {
                        logger.debug(" Summation of Payment -----> " + dTempTotalPayment
                            + "Payment Type-------->" + sPaymentTypeKey);
                      }
                    }
                  } else {
                    mapPaymentTotal.put(sPaymentTypeKey, dAmount);
                    if (YFCLogUtil.isDebugEnabled()) {
                      if (!YFCCommon.isVoid(sConactOrderPayment)) {
                        logger.debug("in else Summation of Payment -----> " + dTempTotalPayment
                            + "Payment Type-------->" + sPaymentTypeKey);
                      }
                    }

                  }
                  dRefundAmount = dRefundAmount - dAmount;

                }
              }
            } else {
              dRefundAmount = 0.0;
            }

          }
        }

        if (dRefundAmount > 0) {
          if (!YFCCommon.isVoid(sPaymentTypeKey)) {
            String sRefundValue = String.valueOf(mapPaymentTotal.get(sPaymentTypeKey));

            double tempval = dRefundAmount + Double.parseDouble(sRefundValue);
            mapPaymentTotal.put(sPaymentTypeKey, tempval);
            if (!YFCCommon.isVoid(String.valueOf(mapSplitPaymentTotal.get(sConactOrderPayment)))) {
              double stempSplitAmount =
                  Double.parseDouble(String.valueOf(mapSplitPaymentTotal.get(sConactOrderPayment)))
                      + dRefundAmount;
              mapSplitPaymentTotal.put(sConactOrderPayment, stempSplitAmount);
            }
          }
        }

      }
    }

    Document outDocForPaymentMethods = createPaymentMethodSplitUpAmount(inDoc, mapPaymentTotal,
        mapSplitPaymentTotal, mapExpirationDate, mapEntryMethod);
    logger.endTimer("KohlsPOCSysRepublic.createPaymentMethodForMultiReceipt");
    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(outDocForPaymentMethods)) {
        logger.debug("Final Output ---> " + SCXmlUtil.getString(outDocForPaymentMethods));
      }
    }
    return outDocForPaymentMethods;

  }

  private Document createPaymentMethodSplitUpAmount(Document inDoc, TreeMap mapPaymentTotal,
      HashMap mapSplitPaymentTotal, HashMap<String, String> mapExpirationDate,
      HashMap<String, String> mapEntryMethod) {

    logger.beginTimer("KohlsPOCSysRepublic.createPaymentMethodSplitUpAmount");
    String sPaymentType = "";
    String sStoreID = "";
    String sTerminalID = "";
    String sTranNo = "";
    Element elePaymentMethods = (Element) inDoc.getElementsByTagName("PaymentMethods").item(0);
    Iterator<Map.Entry<Integer, Integer>> itrPaymentTotal = mapPaymentTotal.entrySet().iterator();
    while (itrPaymentTotal.hasNext()) {
      Map.Entry<Integer, Integer> itrPaymentTotalEntry = itrPaymentTotal.next();
      if (!YFCCommon.isVoid(itrPaymentTotalEntry)) {

        logger.debug(" Payment Total Key = " + itrPaymentTotalEntry.getKey() + ", Value = "
            + itrPaymentTotalEntry.getValue());
      }
      String sTempVal = String.valueOf(itrPaymentTotalEntry.getValue());

      String arrPaymentType[] = String.valueOf(itrPaymentTotalEntry.getKey()).split("-");
      if (!YFCCommon.isVoid(arrPaymentType)) {
        sPaymentType = arrPaymentType[0];

      } else {
        sPaymentType = String.valueOf(itrPaymentTotalEntry.getKey());

      }
      if (!YFCCommon.isVoid(sPaymentType)) {

        logger.debug("Payment type-->" + sPaymentType);
      }
      double dRefundAmount = Double.parseDouble(sTempVal);
      if (dRefundAmount != 0.0) {
        Element elePaymentMethod = SCXmlUtil.createChild(elePaymentMethods, "PaymentMethod");
        Element eleKohlsPaymentList = SCXmlUtil.createChild(elePaymentMethod, "KohlsPaymentList");

        elePaymentMethod.setAttribute("PaymentType", sPaymentType);
        elePaymentMethod.setAttribute("Amount", String.valueOf(itrPaymentTotalEntry.getValue()));
        if (sPaymentType.equals("CREDIT_CARD") || sPaymentType.equals("KOHLS_CHARGE_CARD")
            || sPaymentType.equals("DEBIT_CARD")) {
          elePaymentMethod.setAttribute("CreditCardType", arrPaymentType[2]);
          elePaymentMethod.setAttribute("CreditCardNo", arrPaymentType[1]);

          if (mapEntryMethod.containsKey(arrPaymentType[1])) {
            elePaymentMethod.setAttribute("EntryMethod", mapEntryMethod.get(arrPaymentType[1]));
          }

          if (mapExpirationDate.containsKey(arrPaymentType[1])) {
            elePaymentMethod.setAttribute("CreditCardExpDate",
                mapExpirationDate.get(arrPaymentType[1]));
          }
        }

        Iterator<Map.Entry<Integer, Integer>> itrSplitPaymentTotal =
            mapSplitPaymentTotal.entrySet().iterator();

        while (itrSplitPaymentTotal.hasNext()) {

          Map.Entry<Integer, Integer> itrSplitPaymentTotalEntry = itrSplitPaymentTotal.next();

          if (YFCLogUtil.isDebugEnabled()) {
            logger.debug("In Iteration of SecondMap");

          }
          String sOrderDetails[] = String.valueOf(itrSplitPaymentTotalEntry.getKey()).split("-");
          if (!YFCCommon.isVoid(sOrderDetails)) {
            sStoreID = sOrderDetails[0];
            sTerminalID = sOrderDetails[1];

            sTranNo = sOrderDetails[2];

          }
          String sCurrentStore =
              inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_STORE_NUMBER);
          String sSplitPaymentType = String.valueOf(itrSplitPaymentTotalEntry.getKey());
          if (sSplitPaymentType.contains(String.valueOf(itrPaymentTotalEntry.getKey()))) {

            if (YFCLogUtil.isDebugEnabled()) {
              if (!YFCCommon.isVoid(sSplitPaymentType)) {
                logger.debug("PaymentType=" + sPaymentType + "StoreID=" + sStoreID + "TerminalID="
                    + sTerminalID + "TranNo=" + sTranNo + "sCurrentStore" + sCurrentStore);
              }
            }
            Element eleKohlsPayment = SCXmlUtil.createChild(eleKohlsPaymentList, "KohlsPayment");

            eleKohlsPayment.setAttribute("PaymentType", sPaymentType);
            eleKohlsPayment.setAttribute("StoreID", sStoreID);
            eleKohlsPayment.setAttribute("TerminalID", sTerminalID);
            eleKohlsPayment.setAttribute("TranNo", sTranNo);
            eleKohlsPayment.setAttribute("CurretnStoreID", sCurrentStore);

            eleKohlsPayment.setAttribute("RefundAmount",
                df.format(itrSplitPaymentTotalEntry.getValue()));
          }

        }
      }

    }

    if (YFCLogUtil.isDebugEnabled()) {
      if (!YFCCommon.isVoid(inDoc)) {
        logger.debug("Return Document ---> " + SCXmlUtil.getString(inDoc));
      }
    }
    logger.endTimer("KohlsPOCSysRepublic.createPaymentMethodSplitUpAmount");

    return inDoc;

  }

  private Document getInputIntelliCheck(Document docInputXML, Document docOutGetOrderDetails,
      Document docOutRefundAmount, YFSEnvironment env) throws Exception {

    Document docReturnDLScan = SCXmlUtil.createDocument("ReturnDLScanInput");
    Element eleGetOrderDetails = docOutGetOrderDetails.getDocumentElement();
    Element eleOrderRefundAmount = docOutRefundAmount.getDocumentElement();
    Element eleOrder = docInputXML.getDocumentElement();
    Element eleReturnDLScan = docReturnDLScan.getDocumentElement();
    if (!YFCCommon.isVoid(eleGetOrderDetails.getAttribute("OperatorID")))

    {
      eleReturnDLScan.setAttribute("AssociateID", eleGetOrderDetails.getAttribute("OperatorID"));


    }

    if (!YFCCommon.isVoid(eleGetOrderDetails.getAttribute("TerminalID"))) {
      eleReturnDLScan.setAttribute("RegisterID", eleGetOrderDetails.getAttribute("TerminalID"));


    }

    if (!YFCCommon.isVoid(eleOrder.getAttribute("DriversLicense"))) {
      eleReturnDLScan.setAttribute("DriverLicense", eleOrder.getAttribute("DriversLicense"));


    }
    if (!YFCCommon
        .isVoid(eleGetOrderDetails.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE))) {
      eleReturnDLScan.setAttribute("StoreID",
          eleGetOrderDetails.getAttribute((KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)));

      String loctionID = getLocationID(
          eleGetOrderDetails.getAttribute((KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)), env);
      eleReturnDLScan.setAttribute("LocationID", loctionID);

    }
    if (!YFCCommon.isVoid(eleGetOrderDetails.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO))) {
      eleReturnDLScan.setAttribute("TransactionID",
          eleGetOrderDetails.getAttribute((KohlsPOCConstant.A_POS_SEQUENCE_NO)));


    }
    if (!YFCCommon.isVoid(eleOrder.getAttribute("CustomerIDSource"))) {
      eleReturnDLScan.setAttribute("CustomerIDSource", eleOrder.getAttribute("CustomerIDSource"));


    }
    if (!YFCCommon.isVoid(eleGetOrderDetails.getAttribute(KohlsPOCConstant.A_ORDER_DATE))) {
      eleReturnDLScan.setAttribute("DateTime",
          eleGetOrderDetails.getAttribute((KohlsPOCConstant.A_ORDER_DATE)));


    }

    if (!YFCCommon.isVoid(eleOrderRefundAmount.getAttribute("RefundAmount"))) {
      eleReturnDLScan.setAttribute("TransactionAmount",
          KohlsPOCConstant.MINUS + eleOrderRefundAmount.getAttribute(("RefundAmount")));


    }
    Element eleReturnItemList = SCXmlUtil.createChild(eleReturnDLScan, "ReturnItemList");
    Element eleOrderLines = (Element) eleGetOrderDetails.getElementsByTagName("OrderLines").item(0);
    NodeList ndlOrderLine = eleOrderLines.getElementsByTagName("OrderLine");
    for (int i = 0; i < ndlOrderLine.getLength(); i++) {
      Element eleOrderLine = (Element) ndlOrderLine.item(i);
      Element eleOrderLineExtn =
          (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
      Element eleItem = (Element) eleOrderLine.getElementsByTagName("Item").item(0);
      Element eleLinePriceInfo =
          (Element) eleOrderLine.getElementsByTagName("LinePriceInfo").item(0);

      Element eleReturnItem = SCXmlUtil.createChild(eleReturnItemList, "ReturnItem");
      eleReturnItem.setAttribute("itemPrice", eleLinePriceInfo.getAttribute("UnitPrice"));
      eleReturnItem.setAttribute("itemSkuUpc", eleItem.getAttribute("ItemID"));
      eleReturnItem.setAttribute("deptNumber", eleOrderLineExtn.getAttribute("ExtnItemDept"));
      eleReturnItem.setAttribute("itemSequenceNumber",eleOrderLine.getAttribute("PrimeLineNo"));

    }



    return docReturnDLScan;

  }

  private Document updteIDScanDetails(Document docInOrder) {
    Document docInputIDScan = SCXmlUtil.createDocument("IDScanDetails");
    Element eleIDScanDetails = docInputIDScan.getDocumentElement();

    Element eleOrder = docInOrder.getDocumentElement();
    if (!YFCCommon.isVoid(eleOrder)) {
      if (!YFCCommon.isVoid(eleOrder.getAttribute("ScanningEnabled"))) {
        eleIDScanDetails.setAttribute("ScanningEnabled", eleOrder.getAttribute("ScanningEnabled"));
      }
      if (!YFCCommon.isVoid(eleOrder.getAttribute("ConsentEnabled"))) {
        eleIDScanDetails.setAttribute("ConsentEnabled", eleOrder.getAttribute("ConsentEnabled"));
      }
      if (!YFCCommon.isVoid(eleOrder.getAttribute("IDType"))) {
        eleIDScanDetails.setAttribute("IDType", eleOrder.getAttribute("IDType"));
      }

      if (!YFCCommon.isVoid(eleOrder.getAttribute("CustomerIDSource"))) {
        String sCustomerIDSource = eleOrder.getAttribute("CustomerIDSource");
        if (sCustomerIDSource.equalsIgnoreCase("Scanned")) {

          eleIDScanDetails.setAttribute("IsScanned", KohlsPOCConstant.YES);
        } else {
          eleIDScanDetails.setAttribute("IsScanned", KohlsPOCConstant.NO);
        }

      }

      if (!YFCCommon.isVoid(eleOrder.getAttribute("ConsentResponse"))) {
        eleIDScanDetails.setAttribute("ConsentResponse", eleOrder.getAttribute("ConsentResponse"));
      }


    }

    return docInputIDScan;



  }

  private String getLocationID(String sStoreID, YFSEnvironment env) throws Exception {



    Document getOrganizationHierarchyInput = XMLUtil.getDocument("<Organization OrganizationCode='"
        + sStoreID + "' OrganizationKey='" + sStoreID + "' ></Organization>");

    Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
        "<Organization OrganizationName=''><Node><ShipNodePersonInfo State=''/></Node></Organization>");
    Document getOrganizationListOutput =
        KOHLSBaseApi.invokeAPI(env, getOrganizationHierarchyTemplate, "getOrganizationHierarchy",
            getOrganizationHierarchyInput);


    String sLocationID =
        XPathUtil.getString(getOrganizationListOutput, "//Node/ShipNodePersonInfo/@State");
    if (!YFCCommon.isVoid(sLocationID)) {

      return sLocationID;

    }

    return "";

  }

  public String getPropertyValue(String property) {
    logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
    String propValue;
    propValue = YFSSystem.getProperty(property);
    // Manoj 10/22: updated to use configured property if
    // customer_overrides.properties does not return any value
    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
    return propValue;

  }

  public void setProperties(Properties prop) throws Exception {
    logger.beginTimer("KohlsPOCSysRepublic.setProperties");
    this.props = prop;
    logger.debug("In the set properties method");
    logger.endTimer("KohlsPOCSysRepublic.setProperties");
  }


}
