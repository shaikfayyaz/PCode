package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.custom.util.StringUtil;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

@SuppressWarnings("deprecation")
public class KohlsPoCTVSReturnOrderReprice extends KOHLSBaseApi {

  private static YFCLogCategory logger;
  // private List<String> RS_BAD_DATA_CODE = Arrays.asList("000001F0",
  // "000102", "000000F9");
  boolean IsUnitPricezero = false;
  String sLINE_GETTING_ADDED = "";
  HashMap<Double, String> mapTaxDetails = new HashMap<Double, String>();
  String sTaxIndicatorRepo = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  DecimalFormat df = new DecimalFormat("#0.00");
  boolean bIsEcomStore = false;
  String strIsAutoReturn="";

  static {
    logger = YFCLogCategory.instance(KohlsPoCTVSReturnOrderReprice.class.getName());
  }

  /**
   * This method receives UE input document and after processing returns back the UE output
   * 
   * @return Document
   * @param YFSEnvironment yfsEnv
   * @param Document inDoc
   * @throws YFSUserExitException
   * @throws Exception
   */
  // Service is KohlsReturnTVSPricing
  public Document orderReprice(YFSEnvironment env, Document inputDoc)
      throws YFSException, YFSUserExitException {
    logger.beginTimer("KohlsPoCTVSReturnOrderReprice.orderReprice");
    String strItemId = null;
    double dTotalRKCAmt = KohlsPOCConstant.ZERO_DBL;
    double dQualifyingAmt = KohlsPOCConstant.ZERO_DBL;
    String sRuleValue = null;
    double dRuleValue = 0.00;
    String sTRANSACTION_GETTING_ADDED = "";

    String sOTResponse = null;
    boolean bOTROffline = false;

    Element returnOrderEle = inputDoc.getDocumentElement();
    Element returnOrderExtnEle = XMLUtil.getChildElement(returnOrderEle, KohlsPOCConstant.E_EXTN);

    String strExtnPOCFeature = returnOrderExtnEle.getAttribute("ExtnPOCFeature");

    if (!YFCCommon.isVoid(env.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE))) {
      String ignoreRepricingUE = (String) env.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE);

      if (KohlsPOCConstant.TRUE.equalsIgnoreCase(ignoreRepricingUE)) {
        env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
        Document docOut = null;
        try {
          docOut = XMLUtil.createDocument("Order");
        } catch (ParserConfigurationException e) {
          throw new YFSException(e.getMessage());
        }
        logger.endTimer("KohlsPoCTVSReturnOrderReprice.orderReprice");
        return docOut;
      }
    }
    
    // PST-4585 changes start
        String draftOrderFlag = XMLUtil.getAttribute(returnOrderEle,
                KohlsPOCConstant.A_DRAFT_ORDER_FLAG);
        if (KohlsPOCConstant.NO.equalsIgnoreCase(draftOrderFlag)) {

            logger.debug("Returning from RepriceUE..");
            try {
                return XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
            } catch (ParserConfigurationException e) {

                throw new YFSException(e.getMessage());
            }
        }
        // PST-4585 changes end
    // call separate class if it is non receipted return
    if (strExtnPOCFeature.equalsIgnoreCase("NonReceiptedReturn")) {
      // CAPE-108 Associate Non Receipt -- START
      String customerAssociateNo =
          XMLUtil.getChildElement(inputDoc.getDocumentElement(), KohlsPOCConstant.E_EXTN)
              .getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
      if (!YFCCommon.isVoid(customerAssociateNo)) {
        // CAPE 1677 - Start
        List<Element> orderLineEleList =
            XMLUtil.getElementsByTagName(inputDoc.getDocumentElement(), "OrderLine");
        for (Element eleOrderLine : orderLineEleList) {
          Element eleFirstItem = XMLUtil.getFirstElementByName(eleOrderLine, "Item");
          if (eleFirstItem.getAttribute("ItemID").equalsIgnoreCase("SKU_VOID_TRAN_ZERO_ITEM")) {
            logger.endTimer("KohlsPoCTVSReturnOrderReprice.orderReprice");
            return inputDoc;
          }
        }
        // CAPE 1677 - End
        // new KohlsPoCTVSOrderPromotionsCaller().createPromotionElemForAssDisc(yfsEnv,
        // inDoc.getDocumentElement());
      }
      // CAPE-108 Associate Non Receipt -- END
      inputDoc = new KohlsPoCProcessNonReceiptOrder().processNonReceiptedItems(env, inputDoc);
      logger.endTimer("KohlsPoCTVSReturnOrderReprice.orderReprice");
      return inputDoc;
    }


    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCTVSReturnOrderReprice.orderReprice : Input to getOrderPrice method \n"
          + XMLUtil.getXMLString(inputDoc));
    }

    try {

      Element eleOrder = inputDoc.getDocumentElement();      
      Element eleOrderLines = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);  
      
      //Only for Auto Returns - CPE-13146 Start
      strIsAutoReturn=(String) env.getTxnObject("IS_AUTO_RETURN");
	  if (!YFCCommon.isVoid(env.getTxnObject("IS_AUTO_RETURN")) && KohlsPOCConstant.YES.equalsIgnoreCase(env.getTxnObject("IS_AUTO_RETURN").toString())) { 
		  Document docTVSRequest = null ;
		  if (logger.isDebugEnabled()) {
		  logger.debug("Value of Omni Transaction Object:: IS_AUTO_RETURN:: "+env.getTxnObject("IS_AUTO_RETURN")); 
    	  logger.debug("Inside AUTO RETURN block to perform price updates for all lines in the Input");
		  }
		  logger.info(":: AUTO_RETURN block of ReturnOrderReprice :: ");
    	  NodeList nlLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    	  for(int iLines=0;iLines <nlLines.getLength();iLines++){
        	  Element eleCurrentLine = (Element) nlLines.item(iLines);
        	//PST-8672 - Added to add RKC details of each line START
			  Element eleLineCharges =
		              XMLUtil.getChildElement(eleCurrentLine, KohlsXMLLiterals.E_LINE_CHARGES);
		          if (!YFCCommon.isVoid(eleLineCharges)) {
		            NodeList nlLineCharge =
		                eleLineCharges.getElementsByTagName(KohlsXMLLiterals.E_LINE_CHARGE);
		            if (nlLineCharge.getLength() > 0) {
		              for (int l = 0; l < nlLineCharge.getLength(); l++) {
		                Element eleLineCharge = (Element) nlLineCharge.item(l);
		                String sChargeCategory =
		                    eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY);
		                if (KohlsPOCConstant.KOHLS_CASH_DISCOUNT.equals(sChargeCategory)) {
		                  String sChargePerLine =
		                      eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE);
		                  dTotalRKCAmt = dTotalRKCAmt + Double.parseDouble(sChargePerLine);
		                }               
		              }
		            }
		          }
		   //PST-8672 - END		
        	  Element eleExtn = XMLUtil.getChildElement(eleCurrentLine, KohlsXMLLiterals.E_EXTN, true);
              String strReturnPrice = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_RETURN_PRICE);
               if(!YFCCommon.isVoid(docTVSRequest)){
            	   Document docTVSRequestTemp= constructTVSRequest(env, eleCurrentLine, inputDoc, strReturnPrice);
            	   
            	   //Append Item
            	   Element eleItem=(Element)SCXmlUtil.getXpathElement(docTVSRequestTemp.getDocumentElement(), "//itemList/item");
            	   Element eleId=(Element)eleItem.getElementsByTagName("id").item(0);
            	   XMLUtil.setNodeValue(eleId,String.valueOf(iLines+1));
            	   Element eleOrigItem=(Element)SCXmlUtil.getXpathElement(docTVSRequest.getDocumentElement(), "//itemList");
            	   Element eleOrderLineItems = (Element)eleOrigItem.getOwnerDocument().importNode(eleItem, true);
            	   eleOrigItem.appendChild(eleOrderLineItems);
                          	  
             	  }
               else { //First Line of Auto Return
            	   docTVSRequest=constructTVSRequest(env, eleCurrentLine, inputDoc, strReturnPrice);
            	}
    	  	}

    	  if (logger.isDebugEnabled()) {
    		  logger.debug("KohlsPoCTVSReturnOrderReprice.orderReprice:\t Resquest to cartPrice is: AUTO_RETURN \n"+SCXmlUtil.getString(docTVSRequest));
    	  }
    	  Document docPriceTVSResponse = KOHLSBaseApi.invokeService(env,
    		      KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE, docTVSRequest);
    		if (logger.isDebugEnabled()) {
    		    logger.debug("KohlsPoCTVSReturnOrderReprice.orderReprice:\t Response from cartPrice is:\n"
    		            + XMLUtil.getXMLString(docPriceTVSResponse));
    		}
    		Element tvsPriceResponseEle = docPriceTVSResponse.getDocumentElement();    		 
    		// Checking for SOAP fault
    		if ((!YFCCommon.isVoid(tvsPriceResponseEle)
    		                && !tvsPriceResponseEle.getTagName().equalsIgnoreCase("Errors"))) {
    			//If no errors in TVS response set the below 
    			for(int iLines=0;iLines <nlLines.getLength();iLines++){
    	           	  Element eleCurrentLine = (Element) nlLines.item(iLines);
    	           	  Element eleExtn = XMLUtil.getChildElement(eleCurrentLine, KohlsXMLLiterals.E_EXTN, true);
    			NodeList nlItems=SCXmlUtil.getXpathNodes(tvsPriceResponseEle, "//itemList/item");
    		  //  for(int iItems=0;iItems <nlItems.getLength();iItems++){
    		    Element itemElement = (Element) nlItems.item(iLines);
    		    String pluPrice = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_PLU_PRICE);
    		    if(YFCCommon.isVoid(pluPrice)) {
    		        pluPrice = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SELLING_PRICE);
    		    }
    		    XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_SELLING_PRICE, pluPrice);
    		    XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, pluPrice);
    		    //CPE-9632 set Text11 with current SKU status code from TVS
    		    String skuStatusText = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SKU_STATUS);
    			String skuStatusCode = KohlsPoCPnPUtil.getStatusCodeFromTVS(skuStatusText);
    			XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE, skuStatusCode);
	    	    		
    		  updateTaxIndicators(eleCurrentLine);
    			if (logger.isDebugEnabled()) {
    				logger.debug("Updated Pick Lines Tax "+XMLUtil.getElementXMLString(eleCurrentLine));
    			}
    		 }  }
    	  //CPE-13146 End
	  		}
    	  else { 
    		  logger.info(":: NON AUTO_RETURN block of ReturnOrderReprice :: ");
			 
			  String sReturnStore = eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
			
			  // MJ 04/24 - added logic to avoid TVS call multiple times for same item
			  // Retrieving the txn object
			  if (!YFCCommon.isVoid(env.getTxnObject("LINE_GETTING_ADDED"))) {
			    sLINE_GETTING_ADDED = (String) env.getTxnObject("LINE_GETTING_ADDED");
			  }
			  
			  if (!YFCCommon.isVoid(env.getTxnObject("TRANSACTION_GETTING_ADDED"))) {
			    sTRANSACTION_GETTING_ADDED = (String) env.getTxnObject("TRANSACTION_GETTING_ADDED");
			  }
			
			  String strAssocID = XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_EXTN)
			      .getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
			  NodeList nlOrderLine = inputDoc.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
			  Element eleOrdetextn =
			      XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			
			  if (!YFCCommon.isVoid(eleOrdetextn)) {
			    sOTResponse = eleOrdetextn.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE);
			    // sOTResponseType = eleOrdetextn.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE);
			    if (KohlsPOCConstant.RS_BAD_DATA_CODE.contains(sOTResponse)) {
			      bOTROffline = true;
			    }

      }
      if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
        for (int i = 0; i < nlOrderLine.getLength(); i++) {
          String sText10 = "";
          Element eleOrderLine = (Element) nlOrderLine.item(i);
          String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
          Double dOrderedQty = 0.00;
          boolean isAssocDiscPresent = false;
          String sOrigStoreNo=null;
          

          if (!YFCCommon.isVoid(sOrderedQty)) {
            dOrderedQty = Double.parseDouble(sOrderedQty);
          }
          if (Double.compare(dOrderedQty, 0.00) == 0) {
            eleOrderLines.removeChild(eleOrderLine);
            i--;
            continue;
          }
          NodeList nlTaxLine = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);

          // MJ 0308: Commented for CAPE-2125 - begin
          // else {
          Element eleExtn = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_EXTN, true);
          String strExtnNetPrice = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_NET_PRICE);
          String strReturnPrice = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_RETURN_PRICE);
          if (!YFCCommon.isVoid(strExtnNetPrice)) {
            dQualifyingAmt = dQualifyingAmt + Double.parseDouble(strExtnNetPrice);
          }
          Element eleLineCharges =
              XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_LINE_CHARGES);

          if (!YFCCommon.isVoid(eleLineCharges)) {
            NodeList nlLineCharge =
                eleLineCharges.getElementsByTagName(KohlsXMLLiterals.E_LINE_CHARGE);
            if (nlLineCharge.getLength() > 0) {
              for (int l = 0; l < nlLineCharge.getLength(); l++) {
                Element eleLineCharge = (Element) nlLineCharge.item(l);
                String sChargeCategory =
                    eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY);

                if (KohlsPOCConstant.KOHLS_CASH_DISCOUNT.equals(sChargeCategory)) {
                  String sChargePerLine =
                      eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE);
                  dTotalRKCAmt = dTotalRKCAmt + Double.parseDouble(sChargePerLine);
                }
                // Added for CAPE - 2110 - Murali K
                else if (KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE.equals(sChargeCategory)) {
                  isAssocDiscPresent = true;
                }
              }
            }
          }
          // MJ 0308: Commented for CAPE-2125 - end

          // if(!isAssocDiscCall && )
          if (logger.isDebugEnabled()) {
          logger.debug("Length of the LineTax: "+ nlTaxLine.getLength());
          logger.debug("GiftFlag is: "+ eleOrderLine.getAttribute("GiftFlag"));
          }

          Element eleItem = (Element) (eleOrderLine.getElementsByTagName("Item").item(0));

          Element linePrcEle = XMLUtil.getChildElement(eleOrderLine,
              KohlsPOCConstant.E_LINE_PRICE_INFO, Boolean.TRUE);
          String sOrderLineAction = eleOrderLine.getAttribute(KohlsPOCConstant.A_ACTION);
          String orderLineUnitPrice =
              XMLUtil.getAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE);
          if(YFCCommon.isVoid(strExtnNetPrice)){
        	  XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_NET_PRICE,orderLineUnitPrice);
          }
          strItemId = XMLUtil.getAttribute(eleItem, KohlsPOCConstant.A_ITEM_ID);
          
          Element eleCustomAttributes =
              XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
          String sLineIdentifier="";
          //PST-8055 - identify sales order by custom attributes combination
          if (!YFCCommon.isVoid(eleCustomAttributes)) {
            sText10 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT10);
            String sTransIdentifier = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7)+"_" 
                +eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8)+"_"
                +eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
            sLineIdentifier =sTransIdentifier+"_"+sText10;
            						
            if ((!YFCCommon.isVoid(sText10) && !sLINE_GETTING_ADDED.equals(sLineIdentifier)
                || (!"Create".equalsIgnoreCase(sOrderLineAction) && bOTROffline))) {
              //If orderLine belongs to transaction for which new line is getting added then dont update 
              // Tax indicator here. It will be updated after TVS call. Otherwise if line belongs to different
              // transaction then update the tax indicator here.
              if(!sTRANSACTION_GETTING_ADDED.equalsIgnoreCase(sTransIdentifier)) {
                updateTaxIndicators(eleOrderLine);
              }
              //eleOrderLines.removeChild(eleOrderLine);
              //i--;
              continue;
            }
            sOrigStoreNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
            String sMultiOrderNumber = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT13);
           // sMultiOrderNumber = "12345";
            if(!YFCCommon.isVoid(sMultiOrderNumber)) {
              bIsEcomStore = true;
              logger.debug("Is Ecom Store: "+bIsEcomStore);
            }else {
            	bIsEcomStore = false;
            }
          }
		
          if (!YFCCommon.isVoid(strItemId)
                && !(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(strItemId))) {
              // Cape -82 go to TVS and calculate Line taxes
              if (bOTROffline && nlTaxLine.getLength() == 0) {
                // CAPE --2110 -- Murali K -- Start
                if (strAssocID.equals("000000") && !isAssocDiscPresent) {
                  boolean tvsResponse = new KohlsPoCRSOffline().processOTROffline(env, eleOrderLine,
                      inputDoc, orderLineUnitPrice, true);
                  if (tvsResponse) {
                    continue;
                  } else {
                    new KohlsPoCRSOffline().processOTROffline(env, eleOrderLine, inputDoc,
                        orderLineUnitPrice, false);
                    continue;
                  }
                } else if (nlTaxLine.getLength() == 0) {
                  new KohlsPoCRSOffline().processOTROffline(env, eleOrderLine, inputDoc,
                      orderLineUnitPrice, false);
		  updateTaxIndicators(eleOrderLine);
                  continue;
                }
                // CAPE --2110 -- Murali K -- END
              }
              // Dont call adjustmentPrice api for ECOM order.
              if(!bIsEcomStore && !YFCCommon.isVoid(strReturnPrice) && Double.parseDouble(strReturnPrice) > 0.00D) {
                try 
                {   //Get FeeTax with Original Store details 
                    Document docTVSFeeTaxRequest,docTVSFeeTaxResponse = null;
                    Element tvsFeeTaxResponseEle =null, tvsPriceResponseEle = null;
                    //PST-8055 - sending Sale Order Identifier , so to match the correct order in MRR scenario
                    docTVSFeeTaxRequest =
                            constructAdjustmentTVSRequest(env, eleOrderLine, inputDoc, strReturnPrice, false, sLineIdentifier);
      
                    docTVSFeeTaxResponse = KOHLSBaseApi.invokeService(env,
                            KohlsPOCConstant.KOHLS_POC_PSA_WEB_SERVICE, docTVSFeeTaxRequest);
      
                    tvsFeeTaxResponseEle = docTVSFeeTaxResponse.getDocumentElement();
                    // Checking for SOAP fault
                    if ((YFCCommon.isVoid(tvsFeeTaxResponseEle)
                                    || tvsFeeTaxResponseEle.getTagName().equalsIgnoreCase("Errors"))) {
                      //Error received from TVS. Using LineTax and fee from RS.
                        updateTaxIndicators(eleOrderLine);
                    } else {
                        Element itemElementlist = (Element) KohlsXPathUtil.getNode(tvsFeeTaxResponseEle, "//itemList");
                        //PST-8055. we need to update all lines coming back from TVS
                        //Loop through Items and updateOrderLines by matching PrimeLineNo.
                        NodeList nlItems = itemElementlist.getElementsByTagName("item");
                        NodeList nlLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
                        for(int iItems =0 ;iItems < nlItems.getLength();iItems++){
                        	Element itemElement = (Element)nlItems.item(iItems);
                        	KohlsPoCPnPUtil.consolidateLineTaxes(itemElement);
	                        for(int iLines=0;iLines <nlLines.getLength();iLines++){
	                        	Element eleCurrentLine = (Element) nlLines.item(iLines);
	                        	if(!(itemElement.getAttribute("id").equalsIgnoreCase(
	                        			eleCurrentLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO)))){
	                        		continue;
	                        	}
	                        	Element extnEle = XMLUtil.getChildElement(eleCurrentLine, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
	                        	//Set the PLUPrice only when both OrigStore and Return Store are same, Otherwise no.
	                        	if(!YFCCommon.isVoid(sOrigStoreNo) && Integer.parseInt(sOrigStoreNo) == Integer.parseInt((sReturnStore))) {
    		                        String pluPrice = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_PLU_PRICE);
    		                        if(YFCCommon.isVoid(pluPrice)) {
    		                            pluPrice = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SELLING_PRICE);
    		                        }
    		                        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE, pluPrice);
    		                        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, pluPrice);
	                        	}
		                        // to check and uncomment next line
		                        // eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT10,sText10);
		      
		                        //CPE -214 : start - this might be commented based on confirmation
		                        //If tax and fee is returned then updated LineTaxes , LineCharges, and Awards
		                        if(!bIsEcomStore ){
		                          Element eleTVSLineTaxes = (Element)itemElement.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
		                            if (!YFCCommon.isVoid(eleTVSLineTaxes)) {
		                                //LineTax received from TVS. Remove LineTax from RS
		                                Element eleRSLineTaxes = (Element)eleCurrentLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
		                                if(!YFCCommon.isVoid(eleRSLineTaxes)) {
		                                    XMLUtil.removeChild(eleCurrentLine, eleRSLineTaxes);
		                                }
		                                XMLUtil.importElement(eleCurrentLine, eleTVSLineTaxes);
		                            }
		                            //Import fees from TVS
		                            NodeList nlFee =null;
		                            nlFee = itemElement.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
		                            if (!YFCCommon.isVoid(nlFee) && nlFee.getLength() > 0) {
		                                updateReturnFee(eleCurrentLine,itemElement);
		                            }
		                            //Import Fee end;
			                    } else{
		                            logger.info("Tax and Fee details not updated since its ECom Store");
		                        }
		                        //CPE-214 changes end
		                        updateTaxIndicators(eleCurrentLine);
	                        }
                        }
                    }
                  } catch (Exception ex) {
                        logger.error("Error in calling adjustmentPrice api during returns "+ex.getMessage());
                        updateTaxIndicators(eleOrderLine);
                  }
              } 
              else if (bIsEcomStore){
            	  if (logger.isDebugEnabled()) {
            	  logger.debug("Inside else block for updating Pick Tax Details on Receipt");
            	  }
            	  logger.info("Process tax details for all lines in AUTO_RETURN");
            	  NodeList nlLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
            	  for(int iLines=0;iLines <nlLines.getLength();iLines++){
	            	  Element eleCurrentLine = (Element) nlLines.item(iLines);
	            	  updateTaxIndicators(eleCurrentLine);
	            	  if (logger.isDebugEnabled()) {
	            	  logger.debug("Updated Pick Lines Tax "+XMLUtil.getElementXMLString(eleCurrentLine));
	            	  }
            	  }
              }
            
            //CPE-11593 if original store is different than current store then call cartPrice api 
            // and get current pluPrice
            //CPE-9632 comment out IF statement because we always need to call cartPrice api to get
            // current SKU status code until TVS can make a change to return the current SKU status code
            // in the adjustPrice api.
            //if(!YFCCommon.isVoid(sOrigStoreNo) &&
            //    Integer.parseInt(sOrigStoreNo) != Integer.parseInt((sReturnStore))){
              try {
                    Document docTVSRequest = constructTVSRequest(env, eleOrderLine, inputDoc, strReturnPrice);

                    Document docPriceTVSResponse = KOHLSBaseApi.invokeService(env,
                          KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE, docTVSRequest);
                    if (logger.isDebugEnabled()) {
                        logger.debug("KohlsPoCTVSReturnOrderReprice.orderReprice:\t Response from cartPrice is:\n"
                                + XMLUtil.getXMLString(docPriceTVSResponse));
                    }
                    Element tvsPriceResponseEle = docPriceTVSResponse.getDocumentElement();
                    // Checking for SOAP fault
                    if ((YFCCommon.isVoid(tvsPriceResponseEle)
                                    || tvsPriceResponseEle.getTagName().equalsIgnoreCase("Errors"))) {
                      //Error received from TVS. set 0 price
                      logger.error("Error Received from cartPrice api, setting 0 price");
                      XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_SELLING_PRICE, "0.00");
                      XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, "0.00");
                    } else {
                        Element itemElement = (Element) KohlsXPathUtil.getNode(tvsPriceResponseEle, "//itemList/item");
                        String pluPrice = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_PLU_PRICE);
                        if(YFCCommon.isVoid(pluPrice)) {
                            pluPrice = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SELLING_PRICE);
                        }
                        XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_SELLING_PRICE, pluPrice);
                        XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, pluPrice);
                        //CPE-9632 set Text11 with current SKU status code from TVS
                        String skuStatusText = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SKU_STATUS);
						String skuStatusCode = KohlsPoCPnPUtil.getStatusCodeFromTVS(skuStatusText);
						XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE, skuStatusCode);
                    }
                } catch (Exception ex) {
                  logger.error("Exception in cartPrice api: "+ex.getMessage());
                  XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_SELLING_PRICE, "0.00");
                  XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, "0.00");
                }
            //CPE-9632 see comment above to comment out IF statemment.  
            //}
          }
        }
      }
     }
	//PST-8672 - START
	  //Moved from non Auto Return Block to outside and closed else block before this, to execute this block for all Returns
	  // Added for Tax Indicator - begin
	  Document docTaxDetailsList = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
	  Element eleTaxDetailsRoot = docTaxDetailsList.getDocumentElement();
	  Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
	  // Added for Tax Indicator - end
	//PST-8672 - END
      Element elePromotions = XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_PROMOTIONS);
      if (!YFCCommon.isVoid(elePromotions)) {
        NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsXMLLiterals.E_PROMOTION);
        if (nlPromotion.getLength() > 0) {
          for (int k = 0; k < nlPromotion.getLength(); k++) {
            Element elePromotion = (Element) nlPromotion.item(k);
            String promotionType =
                XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_TYPE);
            // String promotionApplied =
            // XMLUtil.getAttribute(elePromotion,
            // KohlsPOCConstant.A_PROMOTION_APPLIED);
            Element elePromotionExtn =
                XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
            if (KohlsPOCConstant.KOHLS_CASH_REISSUE.equals(promotionType)) {
              Document docRuleListForPOS = this.callGetRuleListForPOS(env);
              if (!YFCCommon.isVoid(docRuleListForPOS)) {
                NodeList nlRuleListFosOS = docRuleListForPOS.getElementsByTagName("Rule");
                Element eleRule = (Element) nlRuleListFosOS.item(0);
                if (!YFCCommon.isVoid(eleRule)) {
                  sRuleValue = eleRule.getAttribute("RuleValue");
                  if (!YFCCommon.isVoid(sRuleValue)) {
                    dRuleValue = Double.parseDouble(sRuleValue);
                  }
                }
              }
              if (dTotalRKCAmt > 0) {
                if (dTotalRKCAmt < dRuleValue) {
                  XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                      df.format(dRuleValue));
                } else {
                  XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                      df.format(dTotalRKCAmt));
                }
                XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, "Y");
              } else {
                XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, "N");
                XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                    "0.00");
              }
              // Cape 1718 - End
              // Debdoot 02/16: Changes for CAPE 1801 - End
              XMLUtil.setAttribute(elePromotionExtn, KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT,
                  df.format(dQualifyingAmt));
              XMLUtil.setAttribute(elePromotionExtn, KohlsPOCConstant.E_EXTN_COUPON_AMOUNT,
                  df.format(dTotalRKCAmt));
              // }
            }
          }
        }
      

      // Added for Taxindicators - begin
      if (mapTaxDetails.size() > 0) {
        for (Double dTaxPercent : mapTaxDetails.keySet()) {
          Element eleTaxDetail =
              XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE,
              String.valueOf(dTaxPercent));
          String sTemp[] = mapTaxDetails.get(dTaxPercent).split("_");
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
        }
      }
      eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
          XMLUtil.getElementXMLString(eleTaxDetailsRoot));
      // Added for Taxindicators - end

    } }catch (Exception e) {
      e.printStackTrace();
      throw new YFSException();
    } finally {
      logger.endTimer("KohlsPoCTVSReturnOrderReprice.orderReprice");
    }
    if (logger.isDebugEnabled()) {
      logger.debug(" Document before returning FROM KohlsPoCTVSReturnOrderReprice"
          + XMLUtil.getXMLString(inputDoc));
    }
    return inputDoc;
  }

  
  /**
   * @param eleOrderLine
   * @param tvsResponseEle 
   * Return Orderlines of a sales order are sent TBS calculates tax and price for the full order
   * this method Updates Line Charges and Line Awards from TVS response
   */
  public void updateReturnFee(Element eleOrderLine, Element eleItem) {
      logger.beginTimer("KohlsPoCTVSReturnOrderReprice.updateReturnFee");
      Element eleOrderLineCharges = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES, true);
      Element eleOrderLineAwards = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_AWARDS, true);
      //PS-8055 - Instead of updating just the scanned order line. change is to update all lines added
      //Loops through Fee from TVS output and update LineCharges and Awards
      NodeList nlFee = eleItem.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
      List<Element> nlCurretnFee = new ArrayList<Element>();
      if (!YFCCommon.isVoid(nlFee)) {
	      //Remove line charges and Awards
		  if(!YFCCommon.isVoid(eleOrderLineCharges)){
			  NodeList nlCharges  = eleOrderLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
			  if(!YFCCommon.isVoid(nlCharges) && nlCharges.getLength()>0){
				  for (int iCharge = 0; iCharge < nlCharges.getLength(); iCharge++) {
					  Element eleCharge = (Element) nlCharges.item(iCharge);
					  if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))){
						  eleOrderLineCharges.removeChild(eleCharge);
						  iCharge--;
					  }
				  }
			  }
		  }
		  if(!YFCCommon.isVoid(eleOrderLineAwards)){
			  NodeList nlAwards  = eleOrderLineAwards.getElementsByTagName(KohlsPOCConstant.E_AWARD);
			  if(!YFCCommon.isVoid(nlAwards) && nlAwards.getLength()>0){
				  for (int iAward = 0; iAward < nlAwards.getLength(); iAward++) {
					  Element eleAward = (Element) nlAwards.item(iAward);
					  if(eleAward.getAttribute(KohlsPOCConstant.A_PROMOTION_ID).contains(KohlsPOCConstant.CONST_FEE)){
						  eleAward.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.REMOVE);
					  }
				  }
			  }
		  }
	     
		  for (int index = 0; index < nlFee.getLength(); index++) {
			  Element eleFee = (Element) nlFee.item(index);
			  nlCurretnFee.add(eleFee);
		  }
		  //update Fee and Awards.
		  KohlsPoCPnPUtil.updateFeeDetails(nlCurretnFee, eleOrderLine,KohlsPOCConstant.MINUS,null, null);
		  
		  Element eleTVSTaxes = (Element)eleItem.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
		  Element eleTaxtoRemove = XMLUtil.getChildElement(eleOrderLine,KohlsPOCConstant.ELEM_LINE_TAXES);
		  eleOrderLine.removeChild(eleTaxtoRemove);
		  Element eleOrderLineTaxes = (Element)eleOrderLine.getOwnerDocument().importNode(eleTVSTaxes, true);
		  eleOrderLine.appendChild(eleOrderLineTaxes);
      }
      logger.endTimer("KohlsPoCTVSReturnOrderReprice.updateReturnFee");
  }

/**
   * This method constructs TVS request
   * 
   * @param yfsEnv
   * @param eleOrderLine
   * @param inXML
   * @param unitPrice
   * @return
   * @throws Exception
   */
  public Document constructTVSRequest(YFSEnvironment yfsEnv, Element eleOrderLine, Document inXML,
      String unitPrice) throws Exception {
    logger.beginTimer("KohlsPoCTVSReturnOrderReprice.constructTVSRequestDocument");
	  if (logger.isDebugEnabled()) {
    logger.debug("Method Name : constructTVSRequestDocument   and   Status : Start ");
	  }
    Element tempOrderEle = inXML.getDocumentElement();
    Document tvsRequestDoc = XMLUtil.createDocument("priceRequest");
    Element priceRequestEle = tvsRequestDoc.getDocumentElement();
    Element transactionEle = XMLUtil.createChild(priceRequestEle, "transaction");
    // Per Jeff, we should send Current store details to TVS
    // String strStoreNum = eleCustomeAttribiutes.getAttribute("Text7");
    String strStoreNum = tempOrderEle.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
    if (StringUtil.isEmpty(strStoreNum)) {
      throw new Exception(
          " ******************** Sales Order Store should not be Empty ********* in KohlsPoCTVSReturnOrderReprice.constructTVSRequest method");
    }

    // String strStoreNumReturn =
    // KohlsPoCPnPUtil.prepadStoreNoWithZeros(tempOrderEle.getAttribute("SellerOrganizationCode"));
    Element extnEle = XMLUtil.getChildElement(eleOrderLine, "Extn");

    String transId = XMLUtil.getAttribute(tempOrderEle, "ExtnOrigPosSequenceNo");
    // String transId = XMLUtil.getAttribute(tempOrderEle,
    // KohlsPOCConstant.A_POS_SEQUENCE_NO);
    Element eleTransactionId =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
    XMLUtil.setNodeValue(eleTransactionId, transId);
    Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
    XMLUtil.setNodeValue(eleStoreNum, strStoreNum);
    Element storeAddressEle =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
    if (logger.isDebugEnabled()) {
      logger.debug("Element tempOrderEle: " + XMLUtil.getElementXMLString(tempOrderEle));
    }
    Element eleShipNdPerInfo = null;
    if (!YFCCommon.isVoid(eleOrderLine)) {

      eleShipNdPerInfo = XMLUtil.getFirstElementByName(eleOrderLine, "Shipnode/ShipNodePersonInfo");
    } 
	  if (YFCCommon.isVoid(eleShipNdPerInfo)){

      Document getOrganizationHierarchyInput = XMLUtil.getDocument("<Organization OrganizationCode='"
          + strStoreNum + "' OrganizationKey='" + strStoreNum + "' ></Organization>");
  
      Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
          "<Organization OrganizationName=''><Node><ShipNodePersonInfo/></Node></Organization>");
      Document getOrganizationListOutput =
          KOHLSBaseApi.invokeAPI(yfsEnv, getOrganizationHierarchyTemplate, "getOrganizationHierarchy",
              getOrganizationHierarchyInput);
      eleShipNdPerInfo =
          ((Element) getOrganizationListOutput.getElementsByTagName("ShipNodePersonInfo").item(0));
    }
    Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
    XMLUtil.setNodeValue(eleCity,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
    Element eleCountry =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
    XMLUtil.setNodeValue(eleCountry,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
    Element elePostal =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
    XMLUtil.setNodeValue(elePostal,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
    Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
    XMLUtil.setNodeValue(eleState,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
    Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
    XMLUtil.setNodeValue(eleGeo,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
    // }

    Element eleItemList = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
    Element eleItem = XMLUtil.createChild(eleItemList, KohlsPOCConstant.ELEM_SMALL_ITEM);

    Element eleSku = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_SKU);
    Element EleItem = (Element) (eleOrderLine.getElementsByTagName("Item").item(0));
    String strItemId = XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID);

    String sTaxCode = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE);
    String sEmpDiscCode = "S";
    Element eleReference = (Element) XPathUtil.getNode(eleOrderLine,
        "/OrderLine/References/Reference[@Name='ExtnEmpDiscCode']");
    if (!YFCCommon.isVoid(eleReference)) {
      sEmpDiscCode = eleReference.getAttribute("Value");
    }
    if (YFCCommon.isVoid(sTaxCode)) {

      // call getItemList
      Document getItemListInput = XMLUtil.getDocument("<Item OrganizationCode='DEFAULT' ItemID='"
          + XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID) + "' />");
      Document getItemListTemplate = XMLUtil.getDocument(
          "<ItemList><Item ItemID='' ><ClassificationCodes TaxProductCode='' /> <Extn ExtnEmpDiscCode=''/></Item></ItemList>");
      Document getItemListOutput =
          KOHLSBaseApi.invokeAPI(yfsEnv, getItemListTemplate, "getItemList", getItemListInput);
      NodeList nItemList = getItemListOutput.getElementsByTagName("Item");
      if (!YFCCommon.isVoid(nItemList)) {
        Element eleItemOut = ((Element) nItemList.item(0));
        if (!YFCCommon.isVoid(eleItemOut)) {
          sTaxCode = ((Element) eleItemOut.getElementsByTagName("ClassificationCodes").item(0))
              .getAttribute(KohlsPOCConstant.A_TAX_PRODUCT_CODE);
          extnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE, sTaxCode);
          sEmpDiscCode = ((Element) eleItemOut.getElementsByTagName("Extn").item(0))
              .getAttribute("ExtnEmpDiscCode");
          if (logger.isDebugEnabled()) {
            logger.debug("Item list output " + XMLUtil.getElementXMLString(eleItemOut));
            logger.debug("sTaxCode is " + sTaxCode + " sEmpDiscCode is " + sEmpDiscCode);
          }
        } else {
          logger.error("Item " + XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID)
              + " is not present in OMS. This is the case of Item Not On File.");
          throw new YFSException("Item Not Found in OMS");
        }
      }
    }

    XMLUtil.setNodeValue(eleSku, strItemId);

    Element eleId = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_ID);
    XMLUtil.setNodeValue(eleId, KohlsPOCConstant.STRING_ONE);

    Element eleTaxCodeIndicator =
        XMLUtil.createChild(eleItem, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
    XMLUtil.setNodeValue(eleTaxCodeIndicator, sTaxCode);

    Element eleEmpDiscCode = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
    XMLUtil.setNodeValue(eleEmpDiscCode, sEmpDiscCode);
    YFCDate date = new YFCDate();
    String strDate = date.getString(null, true);

    Element eleScanTime = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_SCAN_TIME);
    XMLUtil.setNodeValue(eleScanTime, strDate);

    KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(yfsEnv, transactionEle);

    String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.TAX_EXEMPT_FLAG);
    String strTaxExemptCert =
        XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

    Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
    XMLUtil.setNodeValue(eleTaxExempt, strTaxExemptFlag);

    logger.endTimer("KohlsPoCTVSReturnOrderReprice.constructTVSRequestDocument");
	  if (logger.isDebugEnabled()) {
    logger.debug("Method Name : constructTVSRequestDocument   and   Status :End");
	  }

    return tvsRequestDoc;

  }
  
  /**
   * This method constructs Adj TVS request
   * 
   * @param yfsEnv
   * @param eleOrderLine
   * @param inXML
   * @param unitPrice
   * @param sOrderIdentifier - customAttrbutes - Text7_Text8_Text9_Text10 
   * to identify the corresponding sales order in case of MRR
   * @return
   * @throws Exception
   */
  public Document constructAdjustmentTVSRequest(YFSEnvironment yfsEnv, Element eleCurrentOrderLine, Document inXML,
          String returnPrice, boolean bIsEcomStore ,String sOrderIdentifier) throws Exception {
      logger.beginTimer("KohlsPoCTVSCaller.constructAdjustmentTVSRequest");
	  if (logger.isDebugEnabled()) {
      logger.debug("Method Name : constructAdjustmentTVSRequest   and   Status : Start ");
	  }
      Element tempOrderEle = inXML.getDocumentElement();
      Document tvsRequestDoc = XMLUtil.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
      Element priceRequestEle = tvsRequestDoc.getDocumentElement();
      priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
      priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");

      Element transactionEle = XMLUtil.createChild(priceRequestEle,KohlsPOCConstant.ORIGINAL_TRANSACTION);
      String sOrigPrimeLineNo = null;
      String sOrigTerminal = null;
      String sOriginalStore = null;
      String sOriginalDateTime = null;
      String sOriginalTranNo = null;
      Element eleCustomeAttributes = XMLUtil.getFirstElementByName(eleCurrentOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
      if (!YFCCommon.isVoid(eleCustomeAttributes)) {
        if(bIsEcomStore) {
          // if ECom store, then call TVS for current store. Tax and fees will be ignored from TVS.
          sOriginalStore = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
        } else {
          sOriginalStore = eleCustomeAttributes.getAttribute(KohlsPOCConstant.TEXT7);
        }
        sOriginalDateTime = eleCustomeAttributes.getAttribute(KohlsPOCConstant.DATE2);
        sOriginalTranNo = eleCustomeAttributes.getAttribute(KohlsPOCConstant.TEXT9);
        sOrigTerminal = eleCustomeAttributes.getAttribute(KohlsPOCConstant.TEXT8);
        sOrigPrimeLineNo = eleCustomeAttributes.getAttribute(KohlsPOCConstant.TEXT10);
        if(YFCCommon.isVoid(sOriginalStore) || YFCCommon.isVoid(sOriginalDateTime) || YFCCommon.isVoid(sOriginalTranNo)) {
          throw new YFSException ("Original transaction info cannot be null: "+sOriginalStore+", "+sOriginalTranNo+", "+sOriginalDateTime);
        }
      } else {
        throw new YFSException ("Original transaction info cannot be null: Empty or null CustomAttributes");
      }
     
      // String strStoreNumReturn =
      // KohlsPoCPnPUtil.prepadStoreNoWithZeros(tempOrderEle.getAttribute("SellerOrganizationCode"));
      Element extnEle = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN);

      Element eleTransactionId =
              XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
      XMLUtil.setNodeValue(eleTransactionId, sOriginalTranNo);

      Element transactionTime = XMLUtil.createChild(transactionEle, KohlsPOCConstant.TRANSACTION_TIME);
      XMLUtil.setNodeValue(transactionTime, sOriginalDateTime);

      Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
      XMLUtil.setNodeValue(eleStoreNum, sOriginalStore);
      Element storeAddressEle =
              XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
      if (logger.isDebugEnabled()) {
          logger.debug("Element tempOrderEle: " + XMLUtil.getElementXMLString(tempOrderEle));
      }
      Element eleShipNdPerInfo = null;
      if (!YFCCommon.isVoid(eleCurrentOrderLine)) {
          eleShipNdPerInfo = XMLUtil.getFirstElementByName(eleCurrentOrderLine, "Shipnode/ShipNodePersonInfo");
      }

      Document getOrganizationHierarchyInput = XMLUtil.getDocument("<Organization OrganizationCode='"
              + sOriginalStore +"' ></Organization>");

      Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
              "<Organization OrganizationName=''><Node><ShipNodePersonInfo/></Node></Organization>");
      Document getOrganizationListOutput =
              KOHLSBaseApi.invokeAPI(yfsEnv, getOrganizationHierarchyTemplate, KohlsPOCConstant.API_GET_ORGANIZAION_HIERARCHY,
                      getOrganizationHierarchyInput);
      eleShipNdPerInfo =
              ((Element) getOrganizationListOutput.getElementsByTagName(KohlsPOCConstant.SHP_NODE_PER_INFO).item(0));
      Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
      XMLUtil.setNodeValue(eleCity,
              XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
      Element eleCountry =
              XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
      XMLUtil.setNodeValue(eleCountry,
              XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
      Element elePostal =
              XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
      XMLUtil.setNodeValue(elePostal,
              XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
      Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
      XMLUtil.setNodeValue(eleState,
              XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
      Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
      XMLUtil.setNodeValue(eleGeo,
              XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
      // }

      Element lidOfferExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.LID_OFFER_EXEMPT);
      XMLUtil.setNodeValue(lidOfferExempt,KohlsPOCConstant.NO);
      Element eleItemList = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
      Element eleOrderLines = (Element) eleCurrentOrderLine.getParentNode();
      NodeList nlOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
      //PST-8055 - Loop all return order lines. Match OrderIdentifier and if it matches 
      // send all lines to TVS for tax calculations
      for(int iOrderLine=0; iOrderLine < nlOrderLines.getLength();iOrderLine++){
    	  
    	  Element eleOrderLine = (Element)nlOrderLines.item(iOrderLine);
    	  //Match Order info and send all related OrderLines to TVS
    	  String[] sOrderInfo = sOrderIdentifier.split("_");
    	  Element eleCustomAttrbs = XMLUtil.getFirstElementByName(eleOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
	      sOriginalDateTime = eleCustomAttrbs.getAttribute(KohlsPOCConstant.DATE2);
	      sOriginalStore = eleCustomeAttributes.getAttribute(KohlsPOCConstant.TEXT7);
	      sOriginalTranNo = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT9);
	      sOrigTerminal = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT8);
	      sOrigPrimeLineNo = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT10);
	      if(!(sOriginalStore.equalsIgnoreCase(sOrderInfo[0]) && 
    			  sOrigTerminal.equalsIgnoreCase(sOrderInfo[1]) &&
    			sOriginalTranNo.equalsIgnoreCase(sOrderInfo[2]))){
    		  continue;
    	  }
    	  
	      Element eleExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
	      returnPrice = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_RETURN_PRICE);
	      Element eleItem = XMLUtil.createChild(eleItemList, KohlsPOCConstant.ELEM_SMALL_ITEM);
	
	      Element eleSku = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_SKU);
	      Element EleItem = (Element) (eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0));
	      String strItemId = XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID);
	
	      // PST-8233 make sure you get the tax product code from current order line we are looping and not the order 
	      // line from where the item scan happened. 
	      String sTaxCode = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE);
	      String sEmpDiscCode = KohlsPOCConstant.CONST_S;
	      Element eleReference = (Element) XPathUtil.getNode(eleOrderLine,
	              "/OrderLine/References/Reference[@Name='ExtnEmpDiscCode']");
	      if (!YFCCommon.isVoid(eleReference)) {
	          sEmpDiscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
	      }
	      if (YFCCommon.isVoid(sTaxCode)) {
	    	  String sitem = XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID);
	    	  if (sitem.length() ==7){
	    		  sitem ="0"+sitem;
	    	  }
	          // call getItemList
	          Document getItemListInput = XMLUtil.getDocument("<Item OrganizationCode='DEFAULT' ItemID='"
	                  + sitem + "' />");
	          Document getItemListTemplate = XMLUtil.getDocument(
	                  "<ItemList><Item ItemID='' ><ClassificationCodes TaxProductCode='' /> <Extn ExtnEmpDiscCode=''/></Item></ItemList>");
	          Document getItemListOutput =
	                  KOHLSBaseApi.invokeAPI(yfsEnv, getItemListTemplate, KohlsPOCConstant.API_GET_ITEM_LIST, getItemListInput);
	          NodeList nItemList = getItemListOutput.getElementsByTagName(KohlsPOCConstant.E_ITEM);
	          if (!YFCCommon.isVoid(nItemList)) {
	              Element eleItemOut = ((Element) nItemList.item(0));
	              if (!YFCCommon.isVoid(eleItemOut)) {
	                  sTaxCode = ((Element) eleItemOut.getElementsByTagName(KohlsPOCConstant.ELE_CLASSIFICATION_CODES).item(0))
	                          .getAttribute(KohlsPOCConstant.A_TAX_PRODUCT_CODE);
	                  extnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE, sTaxCode);
	                  sEmpDiscCode = ((Element) eleItemOut.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0))
	                          .getAttribute(KohlsPOCConstant.EMP_DISC_CODE);
	                  if (logger.isDebugEnabled()) {
	                      logger.debug("Item list output " + XMLUtil.getElementXMLString(eleItemOut));
	                      logger.debug("sTaxCode is " + sTaxCode + " sEmpDiscCode is " + sEmpDiscCode);
	                  }
	              } else {
	                  logger.error("Item " + XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID)
	                          + " is not present in OMS. This is the case of Item Not On File.");
	                  throw new YFSException("Item Not Found in OMS");
	              }
	          }
	      }
	
	      XMLUtil.setNodeValue(eleSku, strItemId);
	
	      Element eleId = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_ID);
	      XMLUtil.setNodeValue(eleId, eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
	
	      Element EleMerchandise = XMLUtil.createChild(eleItem, KohlsPOCConstant.MERCHANDISE_HIRARCHY);
	
	      // PST-8233 make sure you get the tax product code from current order line we are looping and not the order 
	      // line from where the item scan happened. 
	      String department = XMLUtil.getAttribute(eleExtn,KohlsPOCConstant.EXTN_ITEM_DEPT);
	      String majorClass = XMLUtil.getAttribute(eleExtn,KohlsPOCConstant.EXTN_ITEM_CLASS);
	      String subClass = XMLUtil.getAttribute(eleExtn,KohlsPOCConstant.EXTN_ITEM_SUB_CLASS);
	      String vendorStyle = XMLUtil.getAttribute(eleExtn,KohlsPOCConstant.EXTN_VENDOR_STYLE_NO);
	
	
	      Element deptElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.DEPARTMENT);
	      XMLUtil.setNodeValue(deptElement, department);
	
	      Element majorClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.MAJOR_CLASS);
	      XMLUtil.setNodeValue(majorClassElement, majorClass);
	
	      Element subClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.SUB_CLASS);
	      XMLUtil.setNodeValue(subClassElement, subClass);
	
	      Element vendorStyleElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.VENDOR_STYLE);
	      if(YFCCommon.isVoid(vendorStyle)){
	          vendorStyle = KohlsPOCConstant.TEN;
	      }
	      XMLUtil.setNodeValue(vendorStyleElement, vendorStyle);
	
	      Element eleTaxCodeIndicator =
	              XMLUtil.createChild(eleItem, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
	      XMLUtil.setNodeValue(eleTaxCodeIndicator, sTaxCode);
	
	      Element eleLineTaxExempt = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_TAX_EXEMPT);
	      Element linePriceInfoEle = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
	      String strTaxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
	      if(!YFCCommon.isVoid(strTaxableFlag) && (strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.OVERRIDE_TAX_O) 
	    		  || strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.NO)))
	      {
	    	  XMLUtil.setNodeValue(eleLineTaxExempt, KohlsPOCConstant.YES);
	      }
	      else
	      {	
	    	  XMLUtil.setNodeValue(eleLineTaxExempt, KohlsPOCConstant.NO);
	      }
	      if (!(YFCCommon.isVoid(String.valueOf(returnPrice))
	              || KohlsPoCPnPUtil.getDouble(returnPrice).equals(KohlsPOCConstant.ZERO_STR))) {
	          IsUnitPricezero = true;
	          Element eleregularPrise = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_REGULAR_PRICE);
	          XMLUtil.setNodeValue(eleregularPrise, returnPrice);
	      }
	
	      // PST-8233 make sure you get the tax product code from current order line we are looping and not the order 
	      // line from where the item scan happened. 
	      String SKUStatusCode = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
	      Element regularPriceStatusElement = XMLUtil.createChild(eleItem, KohlsPOCConstant.REGULAR_PRICE_STATUS);
	      XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);
	
	      Element eleEmpDiscCode = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
	      XMLUtil.setNodeValue(eleEmpDiscCode, sEmpDiscCode);
			
			// START Date changes for PST-7492
	      //YFCDate date = new YFCDate();
	      //String strDate = date.getString(null, true);
	      Element eleScanTime = XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_SCAN_TIME);
	      XMLUtil.setNodeValue(eleScanTime, sOriginalDateTime);
		  // END Date changes for PST-7492
      }
      KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(yfsEnv, transactionEle);

      Element adjustments = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ADJUSTMENS);

      String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.TAX_EXEMPT_FLAG);
      String strTaxExemptCert =
              XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

      Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
      XMLUtil.setNodeValue(eleTaxExempt, strTaxExemptFlag);

      logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestDocument");
	  if (logger.isDebugEnabled()) {
      logger.debug("Method Name : constructTVSRequestDocument   and   Status :End");
	  }

      return tvsRequestDoc;

  }

  /**
   * Calling ruleList api to get rule List for RKC_ADJ_VALUE
   * 
   * @param env
   * @return
   * @throws DOMException
   * @throws Exception
   */
  private Document callGetRuleListForPOS(YFSEnvironment env) throws DOMException, Exception {
    // TODO Auto-generated method stub
    logger.beginTimer("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS");
    Document docRuleListForPOSOutput = null;

    Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
    Element eleRuleMetadata = docInput.createElement("RuleMetadata");
    eleRuleMetadata.setAttribute("GroupName", "RKC_ADJ_VALUE");
    eleInput.appendChild(eleRuleMetadata);
	  if (logger.isDebugEnabled()) {
    logger.debug("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS docInput="
        + XMLUtil.getXMLString(docInput));
	  }
    docRuleListForPOSOutput =
        KOHLSBaseApi.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
	  if (logger.isDebugEnabled()) {
    logger.debug("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS docRuleListForPOSOutput="
        + XMLUtil.getXMLString(docRuleListForPOSOutput));
	  }
    logger.endTimer("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS");
    return docRuleListForPOSOutput;
  }

  /**
   * Create By *
   * 
   * @param eleOrderLine
   */
  public void updateTaxIndicators(Element eleOrderLine) {
    logger.beginTimer("KohlsPoCTVSReturnOrderReprice.updateTaxIndicators");
    double dUnitPrice = 0.00D;
    double dOrderedQty = 0.00D;
    double dTaxPercent = 0.00D;
    double dTax = 0.00D;
    // Element eleOrderLine = (Element) nlOrderLine.item(i);
    String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
    if (!YFCCommon.isVoid(sOrderedQty)) {
      dOrderedQty = Double.parseDouble(sOrderedQty);
    }
    if (dOrderedQty > 0) {
      Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
      String sExtnTaxableAmt = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
      // Element eleLinePriceInfo =
      // XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
      // String sUnitPrice = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
      NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
      for (int j = 0; j < nlLineTax.getLength(); j++) {
        Element eleLineTax = (Element) nlLineTax.item(j);
        Element eleTaxExtn = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.A_EXTN,true);
        String sNewTaxableAmt= eleTaxExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
        if(bIsEcomStore) {
      	  dUnitPrice = Double.parseDouble(sExtnTaxableAmt);
        } // stamp sNewTaxableAmt for Omni Pick lines as the Fee/basis amount is zero for it - CPE-13007
        else if(!YFCCommon.isVoid(sNewTaxableAmt)){
            dUnitPrice = Double.parseDouble(sNewTaxableAmt);
        }else{
        	dUnitPrice = Double.parseDouble(sExtnTaxableAmt);
        	NodeList nlLineCharges = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
        	double totalFee=0;
        	 for (int k = 0; k < nlLineCharges.getLength(); k++) {
        	        Element eleLineCharge = (Element) nlLineCharges.item(k);
        	        if(eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY).contains(KohlsPOCConstant.SMALL_ATTR_FEE)){
        	        	totalFee = totalFee + Double.parseDouble(eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE));
        	        }
        	 }
        	 dUnitPrice = dUnitPrice +totalFee;
        }
        String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
        String sTaxPercent = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
        if (!YFCCommon.isVoid(sTax)) {
          dTax = dTax + Double.parseDouble(sTax);
        }
        if (!YFCCommon.isVoid(sTaxPercent)) {
          dTaxPercent = dTaxPercent + Double.parseDouble(sTaxPercent);
        }
      }
      //If taxable amt is non zero then set the TaxableAmt = Basis amt.
      if (!YFCCommon.isVoid(sExtnTaxableAmt) && Double.parseDouble(sExtnTaxableAmt) > 0) {
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, df.format(dUnitPrice));
      }
      if (logger.isDebugEnabled()) {
        logger.debug("Updating tax with tax %: " + String.valueOf(dTaxPercent)
            + " and Taxable Amount: " + String.valueOf(dUnitPrice));
      }

      if (mapTaxDetails.containsKey(dTaxPercent)) {
        String[] sTemp = mapTaxDetails.get(dTaxPercent).split("_");
        double dTax_Temp = Double.parseDouble(sTemp[0]);
        double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
        String sTaxIndicator = sTemp[2];
        mapTaxDetails.remove(dTaxPercent);
        mapTaxDetails.put(dTaxPercent, df.format(dTax_Temp + dTax) + "_"
            + df.format(dTaxableAmount_Temp + dUnitPrice) + "_" + sTaxIndicator);
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
      } else {
        String sTaxIndicator;
        if (dTaxPercent > 0) {
          sTaxIndicator = String.valueOf(sTaxIndicatorRepo.charAt(0));
          sTaxIndicatorRepo = sTaxIndicatorRepo.substring(1);
        } else {
          sTaxIndicator = "#";
        }
        mapTaxDetails.put(dTaxPercent,
            df.format(dTax) + "_" + df.format(dUnitPrice) + "_" + sTaxIndicator);
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
      }
    }
    logger.endTimer("KohlsPoCTVSReturnOrderReprice.updateTaxIndicators");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param reqDoc
   * @return
   * @throws Exception
   */
  private Document addTaxDetailsForReturns(YFSEnvironment env, Document reqDoc) throws Exception {

    logger.beginTimer("KohlsPoCTVSOrderRepriceUE.addTaxDetails");
	  if (logger.isDebugEnabled()) {
    logger.debug("Start of AddTaxDetails logiccc " + XMLUtil.getXMLString(reqDoc));
	  }

    Document docTaxDetailsList = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element eleTaxDetailsRoot = docTaxDetailsList.getDocumentElement();

    HashMap<Double, String> mapTaxDetails = new HashMap<Double, String>();

    DecimalFormat df = new DecimalFormat("#0.00");

    String sTaxIndicatorRepo = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    Element eleOrderExtn =
        XMLUtil.getChildElement(reqDoc.getDocumentElement(), KohlsPOCConstant.E_EXTN);

    NodeList nlOrderLine = reqDoc.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        double dUnitPrice = 0.00D;
        double dOrderedQty = 0.00D;
        double dTaxPercent = 0.00D;
        double dTax = 0.00D;
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
        if (!YFCCommon.isVoid(sOrderedQty)) {
          dOrderedQty = Double.parseDouble(sOrderedQty);
        }
        if (dOrderedQty == 0.00D) {
          continue;
        }
        Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
        Element eleLinePriceInfo =
            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
        String sUnitPrice = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
        if (!YFCCommon.isVoid(sUnitPrice)) {
          dUnitPrice = Double.parseDouble(sUnitPrice);
        }
        NodeList nlLineCharge =
            eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
        for (int k = 0; k < nlLineCharge.getLength(); k++) {
          Element eleLineCharge = (Element) nlLineCharge.item(k);
          String sChargePerLine = eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
          Double dChargePerLine = 0.00;
          if (!YFCCommon.isVoid(sChargePerLine)) {
            dChargePerLine = Double.parseDouble(sChargePerLine);
          }
          String sChargeCategory =
              eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);

          if ("PriceOverrideIncreaseAmount".equalsIgnoreCase(sChargeCategory)) {
            dUnitPrice = dUnitPrice + Math.abs(dChargePerLine);
          } else {
            dUnitPrice = dUnitPrice - Math.abs(dChargePerLine);
          }
        }
        NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
        for (int j = 0; j < nlLineTax.getLength(); j++) {
          Element eleLineTax = (Element) nlLineTax.item(j);
          String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
          String sTaxPercent = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
          if (!YFCCommon.isVoid(sTax)) {
            dTax = dTax + Double.parseDouble(sTax);
          }
          if (!YFCCommon.isVoid(sTaxPercent)) {
            dTaxPercent = dTaxPercent + Double.parseDouble(sTaxPercent);
          }
        }
        if (mapTaxDetails.containsKey(dTaxPercent)) {
          String[] sTemp = mapTaxDetails.get(dTaxPercent).split("_");
          double dTax_Temp = Double.parseDouble(sTemp[0]);
          double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
          String sTaxIndicator = sTemp[2];
          mapTaxDetails.remove(dTaxPercent);
          mapTaxDetails.put(dTaxPercent, df.format(dTax_Temp + dTax) + "_"
              + df.format(dTaxableAmount_Temp + dUnitPrice) + "_" + sTaxIndicator);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
        } else {
          String sTaxIndicator;
          if (dTaxPercent > 0) {
            sTaxIndicator = String.valueOf(sTaxIndicatorRepo.charAt(0));
            sTaxIndicatorRepo = sTaxIndicatorRepo.substring(1);
          } else {
            sTaxIndicator = "#";
          }
          mapTaxDetails.put(dTaxPercent,
              df.format(dTax) + "_" + df.format(dUnitPrice) + "_" + sTaxIndicator);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
        }
      }

      // Forming Tax details
      if (mapTaxDetails.size() > 0) {
        for (Double dTaxPercent : mapTaxDetails.keySet()) {
          Element eleTaxDetail =
              XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE,
              String.valueOf(dTaxPercent));
          String sTemp[] = mapTaxDetails.get(dTaxPercent).split("_");
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
        }
      }
    }
    eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
        XMLUtil.getElementXMLString(eleTaxDetailsRoot));
	  if (logger.isDebugEnabled()) {
    logger.debug("End of taxDetailsList logicccc" + XMLUtil.getXMLString(reqDoc));
	  }
    logger.endTimer("KohlsPoCTVSOrderRepriceUE.addTaxDetails");
    return reqDoc;
  }
}
