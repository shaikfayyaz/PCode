package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.sbc.orgRules.KohlsPoCOrgRuleUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author chidu This class is called from KohlsPoCTVSOrderRepriceUE class, orderReprice method for
 *         non receipt item. It checks for Items which has no price details. It calls TVS and
 *         appends the actual price and Tax details and returns the document
 *
 */
/**
 * @author chidu
 * 
 */

@SuppressWarnings("deprecation")
public class KohlsPoCProcessNonReceiptOrder {

  private static YFCLogCategory logger;
  HashMap<String, Element> itemPriceMap = new HashMap<String, Element>();
  boolean IsUnitPricezero = false;
  boolean isPriceOverrideForDummySku = false;
  String strOverrideAdjustmentValue = null;
  String sAssoc_S_Percent = "";
  String sAssoc_H_Percent = "";
  String strMarkDownPercentage="20";
  HashMap<Double, String> mapTaxDetail = new HashMap<Double, String>();
  Map<String, Element> orderPromotionsMap = new LinkedHashMap<String, Element>();
  Map<String, String> map_S_AssociateDisc = new HashMap<String, String>();
  Map<String, String> map_H_AssociateDisc = new HashMap<String, String>();
  DecimalFormat df = new DecimalFormat("#0.00");
  // Refactoring
  String sLINE_GETTING_ADDED = "";

  static {
    logger = YFCLogCategory.instance(KohlsPoCProcessNonReceiptOrder.class.getName());
  }

  public Document processNonReceiptedItems(YFSEnvironment yfsEnv, Document inXML)
      throws YFSException {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.processNonReceiptedItems");

    if (logger.isDebugEnabled()) {
      logger.debug(
          "KohlsPoCProcessNonReceiptOrder.processNonReceiptedItems : Input to processNonReceiptedItems method \n"
              + XMLUtil.getXMLString(inXML));
    }

    try {
    	Element eExtn = XMLUtil.getChildElement(inXML.getDocumentElement(), KohlsPOCConstant.E_EXTN);	
        String customerAssociateNo = eExtn.getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
     
      if (!YFCCommon.isVoid(customerAssociateNo)) {

        this.checkAndCreateAssocPromotions(yfsEnv, inXML.getDocumentElement());
      }
      // Refactoring
      NodeList nlOrderLine = inXML.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
      Element eleOrderLines =
          XMLUtil.getChildElement(inXML.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
      KohlsPoCTVSReturnOrderReprice obj = new KohlsPoCTVSReturnOrderReprice();

      if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
        for (int i = 0; i < nlOrderLine.getLength(); i++) {
          Element eleCurrentOrderLine = (Element) nlOrderLine.item(i);
          String sAction = eleCurrentOrderLine.getAttribute("Action");
          String sOrderedQty = eleCurrentOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
          if (!YFCCommon.isVoid(sOrderedQty)) {
            Double dOrderedQty = Double.parseDouble(sOrderedQty);
            if (Double.compare(dOrderedQty, 0.00D) == 0) {
              continue;
            }
          }

          Element eleItem = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_ITEM);
          String sItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
          if(!YFCCommon.isVoid(sItemID) && (KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(sItemID))){
        	  return inXML;
			}
          else{
          Element eleCurrentLinePriceInfo =
              XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
          String sUnitPrice = eleCurrentLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
          String sTaxableFlag =
              eleCurrentLinePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
          if (YFCCommon.isVoid(sTaxableFlag)) {
            sTaxableFlag = KohlsPOCConstant.NO;
          }
          if (KohlsPOCConstant.NO.equalsIgnoreCase(sTaxableFlag)) {
            checkAndAddLineTax(eleCurrentOrderLine);
          }
          if (YFCCommon.isVoid(sUnitPrice)) {
            sUnitPrice = "0.0";
          }
          Double dUnitPrice = Double.parseDouble(sUnitPrice);

          // Changes For for CAPE-92 -- Start
          logger.debug(
              "KohlsPoCProcessNonReceiptOrder.processNonReceiptedItems : Calling  processPromotions");
          strOverrideAdjustmentValue = "";
          strOverrideAdjustmentValue = processPromotions(eleCurrentOrderLine, true);

          // Changes For CAPE-92 -- End
          
          // CPE- 8863 : START 
          // If the Price is Overridden then ExtnIsPriceEntered = Y .
    
          Element eleOrderLineExtn = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN);
          String isPriceEnteredForSku = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);
          if( KohlsCorpReturnsConstants.FLAG_Y.equals(isPriceEnteredForSku)){
        	  isPriceOverrideForDummySku = true;
        	  if(!(dUnitPrice == 0) ) {
        	  strOverrideAdjustmentValue = sUnitPrice;
        	  }else{
        		  isPriceOverrideForDummySku = false; 
        	  }
          }
         // CPE- 8863 : END 

          // MJ 02/08 - moved from TVS call to here.
          String sExtnEmpDiscCode = "S";
          if (!YFCCommon.isVoid(eleCurrentOrderLine)) {
            Element eleReference = (Element) ((NodeList) XPathUtil
                .getNodeList(eleCurrentOrderLine, "References/Reference[@Name='ExtnEmpDiscCode']")
                .item(0));
            // logger.debug("eleOrderLine is: " +
            // XMLUtil.getElementXMLString(eleCurrentOrderLine));
            if (!YFCCommon.isVoid(eleReference)) {
              sExtnEmpDiscCode = eleReference.getAttribute("Value");
            }

          }

          if (logger.isDebugEnabled()) {
            logger.debug("Emp Disc Code is    :" + sExtnEmpDiscCode);
          }
         
          // checking if UnitPrice = 0
          if (dUnitPrice == 0 || isPriceOverrideForDummySku) {
            // If item is previously added and then copy the details
            // from it instead of going to TVS
            if (itemPriceMap.containsKey(sItemID) ) {// CPE- 8863 : If its a dummy Sku , it should always prompt for new price.

              Element elePreviousOrderLine = itemPriceMap.get(sItemID);

              // Double previousLineUnitPrice =
              // Double.parseDouble(elePreviousLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE));
              if (YFCCommon.isVoid(strOverrideAdjustmentValue)) {
                Element elePreviousLinePriceInfo = XMLUtil.getChildElement(elePreviousOrderLine,
                    KohlsPOCConstant.E_LINE_PRICE_INFO);
                Element elePreviousExtn =
                    XMLUtil.getChildElement(elePreviousOrderLine, KohlsPOCConstant.E_EXTN);
                Element elePreviousLineTaxes =
                    XMLUtil.getChildElement(elePreviousOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);
                Element elePreviousLineCharges = XMLUtil.getChildElement(elePreviousOrderLine,
                    KohlsPOCConstant.ELEM_LINE_CHARGES);
                Element elePreviousAwards =
                    XMLUtil.getChildElement(elePreviousOrderLine, KohlsPOCConstant.E_AWARDS);

                Element eleCurrentExtn =
                    XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN);
                Element eleCurrentLineTaxes =
                    XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);
                Element eleCurrentAwards =
                    XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_AWARDS);
                Element eleCurrentLineCharges = XMLUtil.getChildElement(eleCurrentOrderLine,
                    KohlsPOCConstant.ELEM_LINE_CHARGES);

                // Removing the Elements from Current Orderline
                if (!YFCCommon.isVoid(eleCurrentExtn)) {
                  eleCurrentOrderLine.removeChild(eleCurrentExtn);
                }
                if (!YFCCommon.isVoid(eleCurrentLineTaxes)) {
                  eleCurrentOrderLine.removeChild(eleCurrentLineTaxes);
                }
                if (!YFCCommon.isVoid(eleCurrentLinePriceInfo)) {
                  eleCurrentOrderLine.removeChild(eleCurrentLinePriceInfo);
                }
                if (!YFCCommon.isVoid(eleCurrentAwards)) {
                  eleCurrentOrderLine.removeChild(eleCurrentAwards);
                }
                if (!YFCCommon.isVoid(eleCurrentLineCharges)) {
                  eleCurrentOrderLine.removeChild(eleCurrentLineCharges);
                }
                // Copying the elements from previously added line
                if (!YFCCommon.isVoid(elePreviousLinePriceInfo)) {
                  XMLUtil.importElement(eleCurrentOrderLine, elePreviousLinePriceInfo);
                }
                if (!YFCCommon.isVoid(elePreviousLineTaxes)) {
                  elePreviousLineTaxes.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
                  XMLUtil.importElement(eleCurrentOrderLine, elePreviousLineTaxes);
                }
                if (!YFCCommon.isVoid(elePreviousLineCharges)) {
                  elePreviousLineCharges.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
                  XMLUtil.importElement(eleCurrentOrderLine, elePreviousLineCharges);
                }
                if (!YFCCommon.isVoid(elePreviousExtn)) {
                  XMLUtil.importElement(eleCurrentOrderLine, elePreviousExtn);
                }
                if (!YFCCommon.isVoid(elePreviousAwards)) {
                  elePreviousAwards.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
                  XMLUtil.importElement(eleCurrentOrderLine, elePreviousAwards);
                  /*
                   * if (!YFCCommon .isVoid(XMLUtil.getChildElement(elePreviousAwards,
                   * KohlsXMLLiterals.E_AWARD))) XMLUtil.importElement(eleCurrentAwards,
                   * XMLUtil.getChildElement(elePreviousAwards, KohlsXMLLiterals.E_AWARD));
                   */
                }
                obj.updateTaxIndicators(eleCurrentOrderLine);
                createTaxMapValues(eleCurrentOrderLine);
              } else {
                eleCurrentOrderLine =
                    constructAndCallTVS(yfsEnv, eleCurrentOrderLine, inXML, sExtnEmpDiscCode);
                processPromotions(eleCurrentOrderLine, false);
                obj.updateTaxIndicators(eleCurrentOrderLine);
                createTaxMapValues(eleCurrentOrderLine);
                if (YFCCommon.isVoid(strOverrideAdjustmentValue)) { 
                  itemPriceMap.put(sItemID, eleCurrentOrderLine);
                }
              }
            } else {
              eleCurrentOrderLine =
                  constructAndCallTVS(yfsEnv, eleCurrentOrderLine, inXML, sExtnEmpDiscCode);
              processPromotions(eleCurrentOrderLine, false);
              obj.updateTaxIndicators(eleCurrentOrderLine);
              createTaxMapValues(eleCurrentOrderLine);
              inXML.getDocumentElement().setAttribute("ValidatePromotionAward", "N");
            }
          } else {
            if (YFCCommon.isVoid(strOverrideAdjustmentValue) && !isPriceOverrideForDummySku) {
              itemPriceMap.put(sItemID, eleCurrentOrderLine);
              // MJ 05/15 added for optimization - begin
              if (YFCCommon.isVoid(sAction)) {
                obj.updateTaxIndicators(eleCurrentOrderLine);
                createTaxMapValues(eleCurrentOrderLine);
                eleOrderLines.removeChild(eleCurrentOrderLine);
                i--;
                if (logger.isDebugEnabled()) {
                  logger.debug("Inside Refactored else block to remove OL1"
                      + XMLUtil.getElementXMLString(eleCurrentOrderLine));
                }

                NodeList nlAward =
                    eleCurrentOrderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);
                if (!YFCCommon.isVoid(nlAward) && nlAward.getLength() > 0) {
                  for (int j = 0; j < nlAward.getLength(); j++) {
                    Element eleAward = (Element) nlAward.item(j);
                    String sAwardDesc = eleAward.getAttribute(KohlsPOCConstant.A_DESCRIPTION);
                    if (!YFCCommon.isVoid(sAwardDesc) && sAwardDesc.contains("Assoc Disc")) {
                      String sAwardAmt = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT);
                      if (YFCCommon.isVoid(sAwardAmt)) {
                        sAwardAmt = "0.00";
                      }
                      String sOrderLineKey =
                          eleCurrentOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
                      if ("H".equalsIgnoreCase(sExtnEmpDiscCode)) {
                        map_H_AssociateDisc.put(sOrderLineKey, sAwardAmt);
                      } else {
                        map_S_AssociateDisc.put(sOrderLineKey, sAwardAmt);
                      }
                    }
                  }
                }
                continue;
                // MJ 05/15 added for optimization -end
              }
            }
          }

          // MJ 02/08 Added for Associate Discount = begin
          NodeList nlAward = eleCurrentOrderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);
          if (!YFCCommon.isVoid(nlAward) && nlAward.getLength() > 0) {
            for (int j = 0; j < nlAward.getLength(); j++) {
              Element eleAward = (Element) nlAward.item(j);
              String sAwardDesc = eleAward.getAttribute(KohlsPOCConstant.A_DESCRIPTION);
              if (!YFCCommon.isVoid(sAwardDesc) && sAwardDesc.contains("Assoc Disc")) {
                String sAwardAmt = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT);
                if (YFCCommon.isVoid(sAwardAmt)) {
                  sAwardAmt = "0.00";
                }
                String sOrderLineKey =
                    eleCurrentOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
                if ("H".equalsIgnoreCase(sExtnEmpDiscCode)) {
                  map_H_AssociateDisc.put(sOrderLineKey, sAwardAmt);
                } else {
                  map_S_AssociateDisc.put(sOrderLineKey, sAwardAmt);
                }
              }
            }
          }
          // MJ 02/08 Added for Associate Discount = end
        }
      }
    }
      Element elePromotions =
          XMLUtil.getChildElement(inXML.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);
      if (!YFCCommon.isVoid(elePromotions)) {
        inXML.getDocumentElement().removeChild(elePromotions);
      }
      Element eleNewPromotions =
          XMLUtil.createChild(inXML.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);

      if (orderPromotionsMap.containsKey("ASSOC_DISC_MANUAL_SOFT_LINE") && !YFCCommon.isVoid(orderPromotionsMap.get("ASSOC_DISC_MANUAL_HARD_LINE"))) {
        // MJ 02/08 - CHanges for Associate discount begin
        Element elePromotion = orderPromotionsMap.get("ASSOC_DISC_MANUAL_SOFT_LINE");
        Double dOverrideAdjValue = 0.00D;
        for (String key : map_S_AssociateDisc.keySet()) {
          String sAwardAmt = map_S_AssociateDisc.get(key);
          Double dAwardAmt = Double.parseDouble(sAwardAmt);
          dOverrideAdjValue = dOverrideAdjValue + Math.abs(dAwardAmt);
        }
        if (Double.compare(Double.parseDouble(sAssoc_H_Percent),
            Double.parseDouble(sAssoc_S_Percent)) == 0) {
          for (String key : map_H_AssociateDisc.keySet()) {
            String sAwardAmt = map_H_AssociateDisc.get(key);
            Double dAwardAmt = Double.parseDouble(sAwardAmt);
            dOverrideAdjValue = dOverrideAdjValue + Math.abs(dAwardAmt);
          }
        }
        if (dOverrideAdjValue > 0 ) {
          elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
        }
        elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
            df.format(dOverrideAdjValue));
        XMLUtil.importElement(eleNewPromotions, elePromotion);
        // MJ 02/08 - CHanges for Associate discount End
      }
      if (orderPromotionsMap.containsKey("ASSOC_DISC_MANUAL_HARD_LINE") && !YFCCommon.isVoid(orderPromotionsMap.get("ASSOC_DISC_MANUAL_HARD_LINE"))) {
        // MJ 02/08 - CHanges for Associate discount begin
        Element elePromotion = orderPromotionsMap.get("ASSOC_DISC_MANUAL_HARD_LINE");
        Double dOverrideAdjValue = 0.00D;
        for (String key : map_H_AssociateDisc.keySet()) {
          String sAwardAmt = map_H_AssociateDisc.get(key);
          Double dAwardAmt = Double.parseDouble(sAwardAmt);
          dOverrideAdjValue = dOverrideAdjValue + Math.abs(dAwardAmt);
        }
        if (dOverrideAdjValue > 0 ) {
          elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
        }
        elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
            df.format(dOverrideAdjValue));
        XMLUtil.importElement(eleNewPromotions, elePromotion);
        // MJ 02/08 - CHanges for Associate discount End
      }
      
      // Added for Taxindicators - begin
      // Added for Tax Indicator - begin
      Document docTaxDetailsList = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
      Element eleTaxDetailsRoot = docTaxDetailsList.getDocumentElement();
      Element eleOrderExtn = XMLUtil.getChildElement(inXML.getDocumentElement(), KohlsPOCConstant.E_EXTN);
      // Added for Tax Indicator - end
      if (mapTaxDetail.size() > 0) {
        for (Double dTaxPercent : obj.mapTaxDetails.keySet()) {
          Element eleTaxDetail =
              XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE, String.valueOf(dTaxPercent));
          String sTemp[] = mapTaxDetail.get(dTaxPercent).split("_");
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
          eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
        }
      }
      eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
          XMLUtil.getElementXMLString(eleTaxDetailsRoot));
      
    } catch (Exception e) {
      logger.error(e);
      logger.debug(" Exception occurred KohlsPoCProcessNonReceiptOrder.processNonReceiptedItems"
          + e.getMessage());
      throw new YFSException(e.getMessage());
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Output of processNonReceiptedItems method is:\n" + XMLUtil.getXMLString(inXML));
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.processNonReceiptedItems");
    return inXML;
  }

  /**
   * @param eleCurrentOrderLine
   * @param bOverrideadjustmentValue
   * @return override adjustment value if bOverrideadjustmentValue true
   * @return current orderLine Element by setting promotion applied N if bOverrideadjustmentValue
   *         false
   */
  private String processPromotions(Element eleCurrentOrderLine, boolean bOverrideadjustmentValue) {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.processPromotions");
    NodeList nlPromotions = eleCurrentOrderLine.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    if (!YFCCommon.isVoid(nlPromotions) && nlPromotions.getLength() > 0) {
      for (int j = 0; j < nlPromotions.getLength(); j++) {
        Element elePromotion = (Element) nlPromotions.item(j);
        String sPromotionType = elePromotion.getAttribute("PromotionType");

        if (KohlsPOCConstant.PRICE_OVERRIDE.equalsIgnoreCase(sPromotionType)) {
          if (bOverrideadjustmentValue) {
            String sOverrideAdjustmentValue =
                elePromotion.getAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
            elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                KohlsPOCConstant.PAYMENT_RETURN_CODE_0);
            logger.endTimer("KohlsPoCProcessNonReceiptOrder.processPromotions");
            return sOverrideAdjustmentValue;
          } else {
            elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.V_N);
            logger.endTimer("KohlsPoCProcessNonReceiptOrder.processPromotions");
            return "";
          }
        }

      }
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.processPromotions");
    return "";
  }

  /**
   * Create By mrjoshi *
   * 
   * @param eleCurrentOrderLine
   */
  private void checkAndAddLineTax(Element eleCurrentOrderLine) {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.checkAndAddLineTax");
    Element eleLineTaxes =
        XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES, true);
    NodeList nlLineTax = eleLineTaxes.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
    if (nlLineTax.getLength() == 0) {
      Element eleLineTax = XMLUtil.createChild(eleLineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
      eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, "0");
      eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, "0");
      eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
      eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
      eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
      eleLineTax.setAttribute(KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, "0");
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.checkAndAddLineTax");
  }

  /**
   * @param yfsEnv
   * @param inXML
   * @return docTVSResponse
   * @throws Exception
   * 
   *         This Method Frames and call TVS web service to get tax details of Items
   */
  public Element constructAndCallTVS(YFSEnvironment yfsEnv, Element eleCurrentOrderLine,
      Document docInXML, String sExtnEmpDiscCode) throws Exception {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.constructAndCallTVS");
    Document docTVSResponse = null;

    Element tempOrderEle = docInXML.getDocumentElement();

    if (logger.isDebugEnabled()) {
      logger.debug(
          "Element eleCurrentOrderLine: " + XMLUtil.getElementXMLString(eleCurrentOrderLine));
    }
    Document tvsRequestDoc = XMLUtil.createDocument("returnPriceRequest");
    Element priceRequestEle = tvsRequestDoc.getDocumentElement();
    Element transactionEle = XMLUtil.createChild(priceRequestEle, "transaction");
    
    String sellerOrganizationCode = tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);

    // Transaction level Variables --Start
    String strStoreNumber = KohlsPoCPnPUtil.prepadStoreNoWithZeros(
    		sellerOrganizationCode);

    String strTransId = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
    createNodeAndSetValue(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID, strTransId);
    createNodeAndSetValue(transactionEle, KohlsPOCConstant.STORE_NUM, strStoreNumber);

    // Transaction level Variables --End

    Element storeAddressEle =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);

    // Call getOrganization Hierachy to get Store Info

    // Document getOrganizationListOutput = getOrganizationHierarchy(yfsEnv,
    // strStoreNumber);

    Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
    Element eleCountry =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
    Element elePostal =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
    Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
    Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);

    Element eleShipNode = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsConstant.SHIP_NODE);
    Element eleShipNdPerInfo =
        XMLUtil.getChildElement(eleShipNode, KohlsPOCConstant.SHP_NODE_PER_INFO);
    if (!YFCCommon.isVoid(eleShipNdPerInfo)) {
      XMLUtil.setNodeValue(eleCity,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
      XMLUtil.setNodeValue(eleCountry,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
      XMLUtil.setNodeValue(elePostal,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
      XMLUtil.setNodeValue(eleState,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));

      String sGeoCode = XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE);
      if (YFCCommon.isVoid(sGeoCode)) {
        YFSException yfsException = new YFSException();
        yfsException.setErrorCode(KohlsPOCConstant.INVALID_GEO_CODE);
        yfsException.setErrorDescription(
            KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_GEO_CODE));
        throw yfsException;
      } else {
        XMLUtil.setNodeValue(eleGeo, sGeoCode);
      }
    } else {
      Document getOrganizationHierarchyInput =
          XMLUtil.getDocument("<Organization OrganizationCode='"
              + sellerOrganizationCode
              + "' OrganizationKey='"
              + sellerOrganizationCode
              + "' ></Organization>");
      Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
          "<Organization OrganizationName=''><Node ShipNode=''><ShipNodePersonInfo City='' Country='' ZipCode='' State='' TaxGeoCode=''/></Node></Organization>");
      Document getOrganizationListOutput =
          KOHLSBaseApi.invokeAPI(yfsEnv, getOrganizationHierarchyTemplate,
              KohlsConstant.GET_ORGANIZATION_HIERARCHY_API, getOrganizationHierarchyInput);
      eleShipNdPerInfo = ((Element) getOrganizationListOutput
          .getElementsByTagName(KohlsXMLLiterals.E_SHIPNODE_PERSON_INFO).item(0));
      XMLUtil.setNodeValue(eleCity,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
      XMLUtil.setNodeValue(eleCountry,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
      XMLUtil.setNodeValue(elePostal,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
      XMLUtil.setNodeValue(eleState,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
      XMLUtil.setNodeValue(eleGeo,
          XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
    }

    Element eleItemList = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
    // MJ 02/08 - Moving this logic to parent for loop
    /*
     * String sExtnEmpDiscCode = "S"; if (!YFCCommon.isVoid(eleCurrentOrderLine)) { Element
     * eleReference = (Element) ((NodeList) XPathUtil.getNodeList( eleCurrentOrderLine,
     * "References/Reference[@Name='ExtnEmpDiscCode']").item(0)); // logger.debug(
     * "eleOrderLine is: " + // XMLUtil.getElementXMLString(eleCurrentOrderLine)); if
     * (!YFCCommon.isVoid(eleReference)) { sExtnEmpDiscCode = eleReference.getAttribute("Value"); }
     * 
     * }
     */

    //
    // logic Start

    Element eleItem = XMLUtil.createChild(eleItemList, KohlsPOCConstant.ELEM_SMALL_ITEM);

    Element eleOrderLineItem = (Element) (eleCurrentOrderLine.getElementsByTagName("Item").item(0));
    String strItemId = XMLUtil.getAttribute(eleOrderLineItem, KohlsPOCConstant.A_ITEM_ID);

    createNodeAndSetValue(eleItem, KohlsPOCConstant.ATTR_SKU, strItemId);
    createNodeAndSetValue(eleItem, KohlsPOCConstant.ATTR_ID, KohlsPOCConstant.STRING_ONE);
    createNodeAndSetValue(eleItem, "empDiscCode", sExtnEmpDiscCode);

    Element extnEle = XMLUtil.getChildElement(eleCurrentOrderLine, "Extn");

    String sTaxCode = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE);

    if (YFCCommon.isVoid(sTaxCode)) {
      sTaxCode = XMLUtil.getAttribute(eleOrderLineItem, KohlsPOCConstant.A_TAX_PRODUCT_CODE);
    }

    createNodeAndSetValue(eleItem, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR, sTaxCode);

    if (!YFCCommon.isVoid(strOverrideAdjustmentValue) ) {
     createNodeAndSetValue(eleItem, KohlsPOCConstant.ATTR_REGULAR_PRICE, strOverrideAdjustmentValue);
    }

    String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.TAX_EXEMPT_FLAG);
    String strTaxExemptCert =
        XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

    if (!YFCCommon.isVoid(strTaxExemptCert)
        || strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES)) {
      createNodeAndSetValue(eleItem, KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.YES);
    } else {
      createNodeAndSetValue(eleItem, KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.NO);
    }
    YFCDate date = new YFCDate();
    String strDate = date.getString(null, true);
    createNodeAndSetValue(eleItem, KohlsPOCConstant.ATTR_SCAN_TIME, strDate);
    // CAPE-108 -- Associate Non Receipted Returns -- Adding manualTLD

    Element offersEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELEM_OFFERS);

    if (!YFCCommon.isVoid(XMLUtil.getChildElement(tempOrderEle, KohlsXMLLiterals.E_EXTN)
        .getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO))) {
      Element eleManualTLD = XMLUtil.createChild(transactionEle, "manualTLD");
      Element eleID = XMLUtil.createChild(eleManualTLD, "id");
      Element elescanOrder = XMLUtil.createChild(eleManualTLD, "scanOrder");
      Element elemarkDownValue = XMLUtil.createChild(eleManualTLD, "markDownValue");
      Element elesecondaryMarkDownValue =
          XMLUtil.createChild(eleManualTLD, "secondaryMarkDownValue");
      Element elediscountType = XMLUtil.createChild(eleManualTLD, "discountType");

      if (YFCCommon.isVoid(sAssoc_S_Percent) || YFCCommon.isVoid(sAssoc_H_Percent)) {
        String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;
        String strDiscountValueFromUtil =
            getDiscountsPercentageForPOSBydate(yfsEnv, tempOrderEle, ruleId).trim();

        String[] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
        int length1 = delimitedComma[0].length() - 1;
        int length2 = delimitedComma[1].length() - 1;
        sAssoc_S_Percent = delimitedComma[0].substring(0, length1);
        sAssoc_H_Percent = delimitedComma[1].substring(0, length2);
      }
      eleID.setTextContent("1001");
      elescanOrder.setTextContent("1");
      elemarkDownValue.setTextContent(
          String.valueOf(Double.valueOf(sAssoc_S_Percent) / KohlsPOCConstant.HUNDRED_INT));
      elesecondaryMarkDownValue.setTextContent(
          String.valueOf(Double.valueOf(sAssoc_H_Percent) / KohlsPOCConstant.HUNDRED_INT));
      elediscountType.setTextContent("AssociateDiscount");
    }
    if(isNRRMardownEnabled(yfsEnv,sellerOrganizationCode)){
    	Element eleMarkdownManualTLD = XMLUtil.createChild(transactionEle, "manualTLD");
        Element eleMarkdownID = XMLUtil.createChild(eleMarkdownManualTLD, "id");
        Element eleMarkdownscanOrder = XMLUtil.createChild(eleMarkdownManualTLD, "scanOrder");
        Element eleMarkDownValue = XMLUtil.createChild(eleMarkdownManualTLD, "markDownValue");
        Element eleMarkDowndiscountType = XMLUtil.createChild(eleMarkdownManualTLD, "discountType");
        Element eleMarkDowngift = XMLUtil.createChild(eleMarkdownManualTLD, "gift");
        Element eleMarkDownIEIndicator = XMLUtil.createChild(eleMarkdownManualTLD, "IEIndicator");
        eleMarkdownID.setTextContent("1002");
        eleMarkdownscanOrder.setTextContent("2");
        eleMarkDownValue.setTextContent( String.valueOf(Double.valueOf(strMarkDownPercentage) / KohlsPOCConstant.HUNDRED_INT));
        eleMarkDowndiscountType.setTextContent("ManualPercentOff");
        eleMarkDowngift.setTextContent("N");
        eleMarkDownIEIndicator.setTextContent("None");
    }
    
    // CAPE-108 -- Associate Non Receipted Returns --change Adding
    // manualTLD to TVS request-- END
    KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(yfsEnv, transactionEle);
    Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
    XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);

    if (logger.isDebugEnabled()) {
      logger.debug("TVS Request is     : " + XMLUtil.getXMLString(tvsRequestDoc));
    }
    docTVSResponse =
        KOHLSBaseApi.invokeService(yfsEnv, "KohlsPoCTVSNonReceiptedReturn", tvsRequestDoc);
    /*
     * if (!YFCCommon.isVoid(XMLUtil.getChildElement(tempOrderEle,
     * KohlsXMLLiterals.E_EXTN).getAttribute( KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO))) {
     * this.updateTvsResponceForAssociateDisc(yfsEnv, docTVSResponse);
     * 
     * }
     */

    if (logger.isDebugEnabled()) {
      logger.debug("TVS Response is     : " + XMLUtil.getXMLString(docTVSResponse));
    }

    eleCurrentOrderLine = processTVSResponse(docTVSResponse, eleCurrentOrderLine, sExtnEmpDiscCode);

    if (logger.isDebugEnabled()) {
      logger.debug("Method Name : constructAndCallTVS   and   Status :End\n "
          + XMLUtil.getElementXMLString(eleCurrentOrderLine));
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.constructAndCallTVS");
    return eleCurrentOrderLine;
  }

  /**
   * Checks if Markdown Rule is enabled. If enabled ,retrieves the
   * value configured value
 * @return
 */
private boolean isNRRMardownEnabled(YFSEnvironment yfsEnv, String strStore) {
	// TODO Auto-generated method stub
	try {
		String strEnabled = KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID(yfsEnv, strStore, "NRR_RTNS_MARKDWN_OVRDE","N");
		if(strEnabled.equalsIgnoreCase("Y")){
			String strPercentage = KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID(yfsEnv, strStore, "NRR_MARKDOWN_PERCENT","20");
			strMarkDownPercentage = strPercentage;
			return true;
		} else {
			return false;
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		return false;
	}
}

/**
   * Create By mrjoshi *
   * 
   * @param transactionEle
   * @param smallAttrTransactionId
   * @param strTransId
   * @return
   */
  private Element createNodeAndSetValue(Element parentElement, String nodeName, String nodeValue) {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.createNodeAndSetValue");
    Element eleTemp = XMLUtil.createChild(parentElement, nodeName);
    XMLUtil.setNodeValue(eleTemp, nodeValue);
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.createNodeAndSetValue");
    return eleTemp;
  }

  /**
   * @param docTVSResponse
   * @param inXML
   * @return inputDocument This method process the response from TVS appends Extension, return price
   *         and Tax details to orderLine and Logs any response errors
   */
  private Element processTVSResponse(Document docTVSResponse, Element eleCurrentOrderLine,
      String sExtnEmpDiscCode) {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.processTVSResponse");
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCProcessNonReceiptOrder.processTVSResponse:\t Response from TVS:\n"
          + XMLUtil.getXMLString(docTVSResponse));
    }

    	// Changes made for CPE -- 8863 , The following code will handle both
 		// Error responses from TVS.One starting with <Errors> and the other one starting with
 		// <TVSResponseEl>" with a sub node of "error" and text element for code and message.
 		Element tvsResponseEle = docTVSResponse.getDocumentElement();
 		String errorCodeStr = null;
 		String errorMsgStr = null;
 		YFSException yfsException = null;
 		boolean errorResponse = false;
 		if (tvsResponseEle.getTagName().equalsIgnoreCase("Errors")) {
 			yfsException = new YFSException();
 			errorCodeStr = XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorCode");
 			errorResponse = true;
 		}
 		NodeList nListError = tvsResponseEle.getElementsByTagName("error");
 		if (nListError.getLength()>0) {
 			Element eError = (Element) nListError.item(0);
 			yfsException = new YFSException();
 			Node eCode = SCXmlUtil.getChildElement(eError, "code");
 			Node eMsg = SCXmlUtil.getChildElement(eError, "message");
 			errorResponse = true;
 			errorCodeStr = eCode.getTextContent();
 			errorMsgStr = eMsg.getTextContent();
 		}
 		if (errorResponse) {
 			if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr)) {
 				yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
 			} else {
 				yfsException.setErrorCode(errorCodeStr);
 			}
 			yfsException.setErrorDescription(errorMsgStr);
 			throw yfsException;
    } else {
      logger.debug("Processing Response from TVS");
      Element eleTVSItemOut =
          (Element) tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM).item(0);
      KohlsPoCPnPUtil.consolidateLineTaxes(eleTVSItemOut);
      // fetching PLU price instead of regular price. CPE-10772. 
      String sRegularPrice =
          XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_PLU_PRICE);
      String sNonReceiptReturnPrice = XMLUtil.getAttribute(eleTVSItemOut, "nonReceiptReturnPrice");
      logger.debug("NonReceiptReturnPrice from TVS is: " + sNonReceiptReturnPrice);
      String sSellingPrice =
          XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_SELLING_PRICE);
      Element linePrcEle = XMLUtil.getChildElement(eleCurrentOrderLine,
          KohlsPOCConstant.E_LINE_PRICE_INFO, Boolean.TRUE);
      XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE, sNonReceiptReturnPrice);
      XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_LIST_PRICE, sRegularPrice);
      Element extnOrderLineEle =
          XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

      // Set Extension Attributes
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_RETURN_PRICE,
          XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_RETURN_PRICE));
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT,
          XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_TAXABLE_PRICE));
      // MJ 05/15 Changes for CAPE-2543 - begin
      // XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE,
      // sSellingPrice);
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE, sRegularPrice);
      // MJ 05/15 Changes for CAPE-2543 - end
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_NET_PRICE,
          XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_NET_PRICE));
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_RECPTT_RTN_PRICE,
          XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_RECEIPT_RETURN_PRICE));
      //XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_NON_CLEARANCE_AMT,
        //  XMLUtil.getAttribute(eleTVSItemOut, KohlsPOCConstant.ATTR_LAST_NON_CLR_PRI));
      String skuStatusText = eleTVSItemOut.getAttribute(KohlsPOCConstant.ATTR_SKU_STATUS);
     String skuStatusCode = KohlsPoCPnPUtil.getStatusCodeFromTVS(skuStatusText);
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE,
          skuStatusCode);
      XMLUtil.setAttribute(extnOrderLineEle, KohlsPOCConstant.A_EXTN_IS_DISCOUNTABLE,
          KohlsPOCConstant.YES);

      // Add Line Taxess
      Element eleLineTaxes = (Element) eleCurrentOrderLine
          .getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
      if (!YFCCommon.isVoid(eleLineTaxes)) {
        eleCurrentOrderLine.removeChild(eleLineTaxes);
      }
      Element eleLineTaxesresponse =
          (Element) eleTVSItemOut.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
      // eleOrderLine.appendChild(eleLineTaxesresponse);
      linePrcEle.setAttribute(KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.NO);
      if (!YFCCommon.isVoid(eleLineTaxesresponse)) {
        Element eleLineTax = (Element) eleLineTaxesresponse
            .getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
        if (!YFCCommon.isVoid(eleLineTax)) {
          String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
          if (!YFCCommon.isVoid(sTax)) {
            Double dTax = Double.parseDouble(sTax);
            if (0.00 < dTax) {
              linePrcEle.setAttribute(KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.YES);
            }
          }
        }
        XMLUtil.importElement(eleCurrentOrderLine, eleLineTaxesresponse);
      }

      // Add Line Taxess

      // Removing LineCharges And Awards if any already exist
      Element eleLineCharges = (Element) eleCurrentOrderLine
          .getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGES).item(0);

      if (!YFCCommon.isVoid(eleLineCharges)) {
        eleCurrentOrderLine.removeChild(eleLineCharges);
      }

      Element eleAwards =
          (Element) eleCurrentOrderLine.getElementsByTagName(KohlsXMLLiterals.E_AWARDS).item(0);

      if (!YFCCommon.isVoid(eleAwards)) {
        Element eleAward = XMLUtil.getChildElement(eleAwards, KohlsXMLLiterals.E_AWARD);
        if (!YFCCommon.isVoid(eleAward)) {

          if (eleAward.getAttribute(KohlsXMLLiterals.A_PROMOTION_ID)
              .equals("ASSOC_DISC_MANUAL_SOFT_LINE")
              || eleAward.getAttribute(KohlsXMLLiterals.A_PROMOTION_ID)
                  .equals("ASSOC_DISC_MANUAL_HARD_LINE")) {
            eleAward.setAttribute("Action", "REMOVE");
          }

        }

      }

      NodeList nlModifier = docTVSResponse.getElementsByTagName("modifier");

      Element eleCurrentOrderLineCharges =
          XMLUtil.createChild(eleCurrentOrderLine, KohlsXMLLiterals.E_LINE_CHARGES);
      Element eleCurrentOrderLineAwards =
          XMLUtil.createChild(eleCurrentOrderLine, KohlsXMLLiterals.E_AWARDS);

      if (!YFCCommon.isVoid(nlModifier) && nlModifier.getLength() > 0) {
        for (int i = 0; i < nlModifier.getLength(); i++) {
          Element eleTempModifier = (Element) nlModifier.item(i);

          // Add LineCharges and Awards
          addLineCharges(eleTempModifier, eleCurrentOrderLineCharges,sNonReceiptReturnPrice);
          addAwards(eleTempModifier, eleTVSItemOut, eleAwards, sExtnEmpDiscCode);
        }

      }
      List<Element> ndFeeList = XMLUtil.getElementsByTagName(eleTVSItemOut, "fees");
      updateRateFeeDetails(ndFeeList,eleCurrentOrderLine);
      // Creating Re-ticket award
      // createReticketAward(eleCurrentOrderLine, sRegularPrice,
      // sSellingPrice);
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.processTVSResponse");
    return eleCurrentOrderLine;
  }


  /**
   * This Methods adds Linecharges For Associate LTD Create By TKMAHDR
 * @param sNonReceiptReturnPrice 
   * 
   * @param docTVSResponse
   * @param eleCurrentOrderLine
   */
  private void addLineCharges(Element eleModifier, Element eleCurrentOrderLineCharges, String sNonReceiptReturnPrice) {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.addLineCharges");
    String sParentDiscountID = eleModifier.getAttribute("parentDiscountId");
    if (sParentDiscountID.equals("1001")) {
      // Adding Associate Discount as lineCharge
      eleCurrentOrderLineCharges.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
      Element eleCurrentOrderLineCharge =
          XMLUtil.createChild(eleCurrentOrderLineCharges, KohlsXMLLiterals.E_LINE_CHARGE);

      eleCurrentOrderLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY,
          KohlsPOCConstant.ASSOCIATE_DISCOUNT_CHARGE);
      eleCurrentOrderLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_NAME,
          KohlsPOCConstant.ASSOCIATE_DISCOUNT_CHARGE);
      String strnetPriceDelta = eleModifier.getAttribute("netPriceDelta");
      Double douDeltaValue = Double.parseDouble(strnetPriceDelta);
      douDeltaValue = Math.abs(douDeltaValue);
      eleCurrentOrderLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE,
          douDeltaValue.toString());
      eleCurrentOrderLineCharge.setAttribute("IsDiscount", "Y");
      eleCurrentOrderLineCharge.setAttribute("IsManual", "Y");

    }
    if (sParentDiscountID.equals("1002")) {
        // Adding Associate Discount as lineCharge
        eleCurrentOrderLineCharges.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
        Element eleCurrentOrderLineCharge =
            XMLUtil.createChild(eleCurrentOrderLineCharges, KohlsXMLLiterals.E_LINE_CHARGE);
        Element eleCurrentOrderLineExtn = 
        	XMLUtil.createChild(eleCurrentOrderLineCharge, KohlsXMLLiterals.E_EXTN);
        eleCurrentOrderLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY,
            KohlsPOCConstant.MANUAL_LID);
        eleCurrentOrderLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_NAME,
            KohlsPOCConstant.LID_PERCENT_OFF_LINE_CHARGE);
        String strnetPriceDelta = eleModifier.getAttribute("netPriceDelta");
        Double douDeltaValue = Double.parseDouble(strnetPriceDelta);
        douDeltaValue = Math.abs(douDeltaValue);
        eleCurrentOrderLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE,
            douDeltaValue.toString());
        
        Element eleCurrentOrderLine = (Element)eleCurrentOrderLineCharges.getParentNode();
        //Element extnOrderLineEle =
                XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
       // Element extnOLAddnlDataList = XMLUtil.createChild(extnOrderLineEle, "OrderLineAddnlDataList");
        //Element extnOLAddnlData =  XMLUtil.createChild(extnOLAddnlDataList, "OrderLineAddnlData");
        
       // extnOLAddnlData.setAttribute("Name", "ExtnPriceWithManualPD");
       // extnOLAddnlData.setAttribute("Value", String.valueOf(new DecimalFormat("#.00").format(
        		//Double.valueOf(sNonReceiptReturnPrice) - douDeltaValue)));
        
        //extnOrderLineEle.setAttribute("ExtnPriceWithManualPD", String.valueOf(new DecimalFormat("#.00").format(
        	//	Double.valueOf(sNonReceiptReturnPrice) - douDeltaValue)));
        
        eleCurrentOrderLineExtn.setAttribute("ExtnPriceWithManualPD", String.valueOf(new DecimalFormat("#.00").format(
        		Double.valueOf(sNonReceiptReturnPrice) - douDeltaValue)));
        
        eleCurrentOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_TYPE_CODE, "P");
        eleCurrentOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_REASON_CODE,"710");
        if(!YFCCommon.isVoid(strMarkDownPercentage))
        {
        		eleCurrentOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, 
        				String.valueOf(Double.valueOf(strMarkDownPercentage) / KohlsPOCConstant.HUNDRED_INT));
        }
        
        eleCurrentOrderLineCharge.setAttribute("IsDiscount", "Y");
        eleCurrentOrderLineCharge.setAttribute("IsManual", "Y");

      }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.addLineCharges");
  }

  /**
   * This Methods adds Awards For Associate LTD Create By TKMAHDR
   * 
   * @param docTVSResponse
   * @param eleCurrentOrderLine
   */
  private void addAwards(Element eleModifier, Element eleTVSItem, Element eleCurrentOrderLineAwards,
      String sExtnEmpDiscCode) {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.addAwards");
    String sParentDiscountID = eleModifier.getAttribute("parentDiscountId");
    if (! sParentDiscountID.equals("1001")) {
    	return;
    }
    Element elePromotion = null;
    String strAssocDiscID = "";
    if (Double.compare(Double.parseDouble(sAssoc_H_Percent),
        Double.parseDouble(sAssoc_S_Percent)) == 0) {
      elePromotion = orderPromotionsMap.get("ASSOC_DISC_MANUAL_SOFT_LINE");
      strAssocDiscID = "ASSOC_DISC_MANUAL_SOFT_LINE";
    } else {
      if (sExtnEmpDiscCode.equals("S")) {
        elePromotion = orderPromotionsMap.get("ASSOC_DISC_MANUAL_SOFT_LINE");
        strAssocDiscID = "ASSOC_DISC_MANUAL_SOFT_LINE";
      } else {
        elePromotion = orderPromotionsMap.get("ASSOC_DISC_MANUAL_HARD_LINE");
        strAssocDiscID = "ASSOC_DISC_MANUAL_HARD_LINE";
      }
    }

    eleCurrentOrderLineAwards.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
    Element awardEle = XMLUtil.createChild(eleCurrentOrderLineAwards, KohlsPOCConstant.E_AWARD);

    XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());

    XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);

    String taxablePriceDelta =
        XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA);
    Double dTaxablePriceDelta = 0.00D;
    if (!YFCCommon.isVoid(taxablePriceDelta)) {
      dTaxablePriceDelta = Double.parseDouble(taxablePriceDelta);
    }
    XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT,
        df.format(Math.abs(dTaxablePriceDelta)));

    if (!YFCCommon.isVoid(elePromotion)) {
      XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_TYPE,
          elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE));
      XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID,
          elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_ID));
      XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION,
          elePromotion.getAttribute(KohlsPOCConstant.A_DESCRIPTION));
    }

    Element awardExtEle = XMLUtil.createChild(awardEle, KohlsXMLLiterals.E_EXTN);
    String sExtnTaxDelta =
        XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA);
    Double dExtnTaxDelta = 0.00;
    if (!YFCCommon.isVoid(sExtnTaxDelta)) {
      dExtnTaxDelta = Double.parseDouble(sExtnTaxDelta);
    }
    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TAX_DELTA,
        df.format(Math.abs(dExtnTaxDelta)));

    String sExtnNetDelta = XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_NET_PRICE_DELTA);
    Double dExtnNetDelta = 0.00;
    if (!YFCCommon.isVoid(sExtnNetDelta)) {
      dExtnNetDelta = Double.parseDouble(sExtnTaxDelta);
    }
    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_NET_DELTA,
        df.format(Math.abs(dExtnNetDelta)));
    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_ACT_DELTA,
        KohlsPoCPnPUtil.getDouble(
            XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED)));
    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_PER_DELTA,
        XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_TIER_PERCENT_ACHIEVED));
    String tierLevelAchieved =
        XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_TIER_LEVEL_ACHIEVED);
    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_LVL_ACHVD, tierLevelAchieved);

    String returnPriceDelta =
        XMLUtil.getAttribute(eleModifier, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA);

    if (!YFCCommon.isVoid(returnPriceDelta)) {
      XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_RETRN_DELTA,
          df.format(Math.abs(Double.valueOf(returnPriceDelta))));
    }

    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.ATTR_EXTN_SALE_PRICE,
        XMLUtil.getAttribute(eleTVSItem, KohlsPOCConstant.ATTR_SIMPLE_PROMO_PRICE));

    XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, "1");

    XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ITEM_ID,
        XMLUtil.getAttribute(eleTVSItem, KohlsPOCConstant.ATTR_SKU));
    /*
     * Double douOverrideAdjValue = 0.00; if (!YFCCommon.isVoid(elePromotion
     * .getAttribute("OverrideAdjustmentValue"))) { douOverrideAdjValue =
     * Double.parseDouble(elePromotion .getAttribute("OverrideAdjustmentValue")); }
     * 
     * douOverrideAdjValue = douOverrideAdjValue + Math.abs(Double.parseDouble(taxablePriceDelta));
     * elePromotion.setAttribute("OverrideAdjustmentValue", douOverrideAdjValue.toString());
     */
    orderPromotionsMap.remove(strAssocDiscID);
    orderPromotionsMap.put(strAssocDiscID, elePromotion);
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.addAwards");

  }

  public void checkAndCreateAssocPromotions(YFSEnvironment yfsEnv, Element tempOrderEle)
      throws Exception {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.checkAndCreateAssocPromotions");

    if (YFCCommon.isVoid(sAssoc_S_Percent) || YFCCommon.isVoid(sAssoc_H_Percent)) {
      String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;
      // call new method by sending the business date, rule
      // id, enterprise code and set the extnDiscountPercent
      // attribute
      String strDiscountValueFromUtil =
          getDiscountsPercentageForPOSBydate(yfsEnv, tempOrderEle, ruleId).trim();
      String[] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
      int length1 = delimitedComma[0].length() - 1;
      int length2 = delimitedComma[1].length() - 1;
      sAssoc_S_Percent = String.valueOf(delimitedComma[0].substring(0, length1));
      sAssoc_H_Percent = String.valueOf(delimitedComma[1].substring(0, length2));
    }

    Element eleOrderLines = XMLUtil.getChildElement(tempOrderEle, KohlsXMLLiterals.E_ORDER_LINES);
    Element elePromotions = XMLUtil.getChildElement(tempOrderEle, KohlsXMLLiterals.E_PROMOTIONS);
    NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsXMLLiterals.E_PROMOTION);

    if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > KohlsPOCConstant.ZERO_INT) {
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
        orderPromotionsMap.put(elePromotion.getAttribute(KohlsXMLLiterals.A_PROMOTION_ID),
            elePromotion);
      }
    }
    String strExtnEmpDiscCode = "S";
    NodeList nlOrderLine = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > KohlsPOCConstant.ZERO_INT) {
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        Element eleReference = (Element) ((NodeList) XPathUtil
            .getNodeList(eleOrderLine, "References/Reference[@Name='ExtnEmpDiscCode']").item(0));

        if (!YFCCommon.isVoid(eleReference)) {
          strExtnEmpDiscCode = eleReference.getAttribute("Value");
        }
        if (((strExtnEmpDiscCode.equals("S") || strExtnEmpDiscCode.equalsIgnoreCase("N")) 
            && !orderPromotionsMap.containsKey("ASSOC_DISC_MANUAL_SOFT_LINE"))
            || (strExtnEmpDiscCode.equals("H")
                && !orderPromotionsMap.containsKey("ASSOC_DISC_MANUAL_HARD_LINE"))) {

          Element promotonEle = XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
          XMLUtil.setAttribute(promotonEle, "IsInternal", KohlsPOCConstant.YES);
          XMLUtil.setAttribute(promotonEle, "PromotionGroup", "MANUAL");
          XMLUtil.setAttribute(promotonEle, "PromotionApplied", KohlsPOCConstant.YES);
          XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_TYPE,
              KohlsPOCConstant.ASSOCIATE_DISCOUNT);

          Element elePromotionExtn = XMLUtil.createChild(promotonEle, KohlsXMLLiterals.E_EXTN);
          elePromotionExtn.setAttribute("ExtnPromotionFlag", "Y");

          if (Double.compare(Double.parseDouble(sAssoc_H_Percent),
              Double.parseDouble(sAssoc_S_Percent)) == 0) {
            String[] args = {sAssoc_S_Percent};
            XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_DESCRIPTION, KOHLSResourceUtil
                .getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args));
            elePromotionExtn.setAttribute("ExtnDiscountPercent",
                String.valueOf(Double.parseDouble(sAssoc_S_Percent)));
            XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_ID,
                KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE);
            orderPromotionsMap.put("ASSOC_DISC_MANUAL_SOFT_LINE", promotonEle);
          } else {
            if (strExtnEmpDiscCode.equals("S") || strExtnEmpDiscCode.equals("N")) {
              String[] args = {sAssoc_S_Percent};
              XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_DESCRIPTION, KOHLSResourceUtil
                  .getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args));
              elePromotionExtn.setAttribute("ExtnDiscountPercent",
                  String.valueOf(Double.parseDouble(sAssoc_S_Percent)));
              XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_ID,
                  KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE);
              orderPromotionsMap.put("ASSOC_DISC_MANUAL_SOFT_LINE", promotonEle);
            }

            else if (strExtnEmpDiscCode.equals("H")) {
              String[] args = {sAssoc_H_Percent};
              XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_DESCRIPTION, KOHLSResourceUtil
                  .getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args));

              elePromotionExtn.setAttribute("ExtnPromotionFlag", "Y");
              elePromotionExtn.setAttribute("ExtnDiscountPercent",
                  String.valueOf(Double.parseDouble(sAssoc_H_Percent)));
              XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_ID,
                  KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE);
              orderPromotionsMap.put("ASSOC_DISC_MANUAL_HARD_LINE", promotonEle);

            }
          }
        }

      }
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.checkAndCreateAssocPromotions");
  }

  public String getDiscountsPercentageForPOSBydate(YFSEnvironment yfsEnv, Element orderElement,
      String strRuleID) throws Exception {
    logger.beginTimer("KohlsPoCProcessNonReceiptOrder.getDiscountsPercentageForPOSBydate");

    String strCodeShortDescription = null;
    Element eleCommonCode = null;
    Document docOutputForGetCommonCodeList = null;
    String sBusinessDay = "";
    String sOrganizationCode = "";
    String sDefaultDate = "";

    sBusinessDay = orderElement.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
    sOrganizationCode = orderElement.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);
    SimpleDateFormat simpleDateformat = new SimpleDateFormat(KohlsPOCConstant.HD_DATE_FORMAT);
    Date date = simpleDateformat.parse(sBusinessDay);
    SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YY);
    String sBusinessDay_converted = sdf.format(date);
    logger.debug("Business Day is :: " + sBusinessDay_converted);

    Document docInputForGetCommonCodeList = XMLUtil.createDocument(KohlsConstant.E_COMMON_CODE);
    Element eleInputForGetCommonCodeList = docInputForGetCommonCodeList.getDocumentElement();
    eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_CODE_TYPE, strRuleID);
    eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_ORGANIZATION_CODE, sOrganizationCode);
    Document docCommonCodeTemplate = XMLUtil.getDocument(
        "<CommonCodeList><CommonCode CodeShortDescription='' CodeValue=''/></CommonCodeList>");
    docOutputForGetCommonCodeList = KOHLSBaseApi.invokeAPI(yfsEnv, docCommonCodeTemplate,
        KohlsConstant.API_GET_COMMON_CODE_LIST, docInputForGetCommonCodeList);
    // Performance improvement changes - Start
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Output of Common Code API :: " + XMLUtil.getXMLString(docOutputForGetCommonCodeList));
    }
    // Performance improvement changes - End

    NodeList nlCommonCode =
        docOutputForGetCommonCodeList.getElementsByTagName(KohlsConstant.E_COMMON_CODE);
    if (!YFCCommon.isVoid(nlCommonCode) && nlCommonCode.getLength() > 0) {
      for (int i = 0; i < nlCommonCode.getLength(); i++) {
        eleCommonCode = (Element) nlCommonCode.item(i);
        String strCodeValue = eleCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);
        if (strCodeValue.equalsIgnoreCase(sBusinessDay_converted)) {
          strCodeShortDescription = eleCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
          logger.debug(
              "Code Short Description for given Business Date :: " + strCodeShortDescription);
          return strCodeShortDescription;
        } else if ("DEFAULT".equalsIgnoreCase(strCodeValue)) {
          sDefaultDate = eleCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
          logger.debug("DEFAULT Code Short Description is :: " + strCodeShortDescription);
        }
      }
    }
    logger.endTimer("KohlsPoCProcessNonReceiptOrder.getDiscountsPercentageForPOSBydate");
    return sDefaultDate;
  }
  
  
  private void createTaxMapValues(Element eleCurrentOrderLine){
	  String sTaxIndicatorRepo = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	  Element eleOrderLineExtn = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN);
	  Element eleCurrentLinePriceInfo =
              XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
          String sUnitPrice = eleCurrentLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
          double dUnitPrice = Double.parseDouble(sUnitPrice);
      double dTax=0,dTaxPercent=0;
      NodeList nlLineTax = eleCurrentOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
      for (int j = 0; j < nlLineTax.getLength(); j++) {
        Element eleLineTax = (Element) nlLineTax.item(j);
        String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
        String sTaxPercent = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
        
        // CPE-213 Using TaxBasis amt to show on Receipt
        Element eleTaxExtn = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
        if(!YFCCommon.isVoid(eleTaxExtn)) {
          String sTaxBasis = eleTaxExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
          if(!YFCCommon.isVoid(sTaxBasis)) {
            dUnitPrice = Double.parseDouble(sTaxBasis);
          }
        }
        if (!YFCCommon.isVoid(sTax)) {
          dTax = dTax + Double.parseDouble(sTax);
        }
        if (!YFCCommon.isVoid(sTaxPercent)) {
          dTaxPercent = dTaxPercent + Double.parseDouble(sTaxPercent);
        }
      }
      if (mapTaxDetail !=null && mapTaxDetail.containsKey(dTaxPercent)) {
          String[] sTemp = mapTaxDetail.get(dTaxPercent).split("_");
          double dTax_Temp = Double.parseDouble(sTemp[0]);
          double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
          String sTaxIndicator = sTemp[2];
         
          mapTaxDetail.remove(dTaxPercent);
          mapTaxDetail.put(dTaxPercent, df.format(dTax_Temp + dTax) + "_"
              + df.format(dTaxableAmount_Temp + dUnitPrice) + "_" + sTaxIndicator);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
        } else {
          String sTaxIndicator;
          if (dTaxPercent > 0) {
            sTaxIndicator = String.valueOf(sTaxIndicatorRepo.charAt(0));
            sTaxIndicatorRepo = sTaxIndicatorRepo.substring(1);
          } else {
            sTaxIndicator = "#";
          }
          mapTaxDetail.put(dTaxPercent,
              df.format(dTax) + "_" + df.format(dUnitPrice) + "_" + sTaxIndicator);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
        }
  }
  
  /**
 * @param ndFeeList
 * @param orderLineEle
 * updateRate based Fee as Awards and LineCharges
 */
 private void updateRateFeeDetails(List<Element> ndFeeList, Element orderLineEle) {
  	logger.beginTimer("KohlsPoCProcessNonReceiptOrder.updateFeeDetails");
  	Element eleLineCharges = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES, true);
  	Element eleAwards = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, true);
  	
  	if(YFCCommon.isVoid(eleLineCharges)){
  		eleLineCharges = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);
  	}
  	if(YFCCommon.isVoid(eleAwards)){
  		eleAwards = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.E_AWARDS);
  	}
  	double dFeeRate=0;
  	if (ndFeeList.size() > KohlsPOCConstant.ZERO_INT) {
  		for (Element eleFees : ndFeeList) {

  			String sRate = XMLUtil.getAttribute(eleFees,KohlsPOCConstant.SMALL_ATTR_RATE_FEE);
  			if(!YFCCommon.isVoid(sRate)){
  				dFeeRate = Double.parseDouble(sRate);
  			}
  			//do not include flat based fee.
  			if(dFeeRate >0){
	  			String sCalcAmount = eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
	  			if(sCalcAmount.isEmpty()){
	  				sCalcAmount =KohlsPOCConstant.ZERO;
	  			}
	  			double dChangeFee= Double.parseDouble(eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
	  			Element lineChargeEle = XMLUtil.createChild(eleLineCharges, KohlsPOCConstant.ELEM_LINE_CHARGE);
	  			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY,KohlsPOCConstant.CONST_FEE);
	  			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
	  			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_CHARGE_PER_LINE, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
	  			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_BILLABLE, KohlsPOCConstant.YES);
	  			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.NO);
	  			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.Reference, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
	
	  			Element lineChargeExtnEle = XMLUtil.getChildElement(lineChargeEle, KohlsPOCConstant.E_EXTN, true);
	  			XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_FEE_ID, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_FEE_ID));
	  			XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_BASIS_AMOUNT));
	  			XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_EXEMPT_AMOUNT, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_EXEMPT_AMOUNT));
	  			XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_RATE_FEE));
	  			XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_COMPLETION_CODE, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_COMPLETION_CODE));
	  			XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.Extn_Is_Fee_Taxable, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_IS_TAXABLE));
	
	  			Element awardEle = XMLUtil.createChild(eleAwards, KohlsPOCConstant.E_AWARD);
	  			Element awardExtEle = XMLUtil.createChild(awardEle, KohlsPOCConstant.E_EXTN);
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY,KohlsPOCConstant.CONST_FEE);
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.ATTR_CHARGE_NAME, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.PROMOTIONID, KohlsPOCConstant.CONST_FEE);
	  			DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
	  			
	  			XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, "-"+twoDForm.format(dChangeFee));
	  			XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.EXTN_AWARD_RECEIPT_DESC,eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
	  			XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE);
  			}
  		}

  	}
  	logger.endTimer("KohlsPoCProcessNonReceiptOrder.updateRateFeeDetails");
  }
}
