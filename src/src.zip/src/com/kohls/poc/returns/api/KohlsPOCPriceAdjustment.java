package com.kohls.poc.returns.api;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.pricing.ue.KohlsPoCTVSCaller;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPOCPriceAdjustment {

  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPOCPriceAdjustment.class.getName());
  }

  /*
   * This method will invoke by KohlsPoCRepriceUEWrapper class. This method invokes TVS to get tax
   * for eligible items
   */

  /**
   * @param yfsEnv
   * @param inputClone
   * @param dTVSCartPriceResponse
   * @return
   * @throws Exception
   */
  public Document processPriceAdjustedItems(YFSEnvironment yfsEnv, Document inputClone,
      Document dTVSCartPriceResponse, HashMap<String, Element> mapOLPromotionToBeReset)
      throws Exception {

    //Document docInputRequestToTVS = null;
    try {
      logger.beginTimer("KohlsPOCPriceAdjustment.processPriceAdjustedItems");
      // create header
      // docInputRequestToTVS = createHeaderTVS(yfsEnv, inputClone);
      inputClone =
          getItemTagList(yfsEnv, inputClone, dTVSCartPriceResponse, mapOLPromotionToBeReset);
    } catch (Exception e) {
      logger.error("Error occured in KohlsPOCPriceAdjustment.getTVSRequestInput " + e.getMessage());
      throw e;
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Output of 2nd TVS Call is: " + XMLUtil.getXMLString(inputClone));
    }
    logger.endTimer("KohlsPOCPriceAdjustment.processPriceAdjustedItems");
    return inputClone;
  }

  /*
   * This method compares the lines with prime line number and selects eligible lines
   */
  /**
   * @param yfsEnv
   * @param docItemListToTVS
   * @param inputClone
   * @param dTVSCartPriceResponse
   * @return
   */
  private Document getItemTagList(YFSEnvironment yfsEnv, Document inputClone,
      Document dTVSCartPriceResponse, HashMap<String, Element> mapOLPromotionToBeReset) {
    logger.beginTimer("KohlsPOCPriceAdjustment.getItemTagList");
    Document docResponseFromGetCartPrice = null;
    boolean PAItemFound = false;
    Document docItemListToTVS = null;
    Element eloriginalTransaction = null;
    try {

      Element eleOrderElement = inputClone.getDocumentElement();
      Element eleOrdeLines = (Element) eleOrderElement.getElementsByTagName("OrderLines").item(0);
      NodeList nlOrderLines = eleOrderElement.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);

      for (int i = 0; i < nlOrderLines.getLength(); i++) {
        Double dTVSReturnPrice = 99999.0;
        Double dRSReturnPrice = 0.0;

        Element eleCurrentOrderLine = (Element) nlOrderLines.item(i);

        Element eleCustomAttr =
            (Element) eleCurrentOrderLine.getElementsByTagName("CustomAttributes").item(0);

        String sPrimeLineNumber =
            eleCurrentOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
        Element extnEle =
            XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN, true);
        Element eleTVSCartPriceResponse =
            (Element) XPathUtil.getNode(dTVSCartPriceResponse.getDocumentElement(),
                "//OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNumber + "']");
        Element eleTVSCartPriceResponseExtn =
            XMLUtil.getChildElement(eleTVSCartPriceResponse, "Extn");
        if (logger.isDebugEnabled()) {
          logger.debug(
              "Element to be modified is " + XMLUtil.getElementXMLString(eleTVSCartPriceResponse));
        }
        if (YFCCommon.isVoid(eleTVSCartPriceResponseExtn)) {
          continue;
        }
        String sSkuStatus =
            eleTVSCartPriceResponseExtn.getAttribute(KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
        if (!YFCCommon.isVoid(sSkuStatus) && "30".equalsIgnoreCase(sSkuStatus)) {
          extnEle.setAttribute(KohlsPOCConstant.EXTN_SKU_STATUS_CODE, "30");
          continue;
        }
        if (eleTVSCartPriceResponseExtn.getAttribute("ExtnIsPriceEntered").equalsIgnoreCase("Y")) {
          extnEle.setAttribute("ExtnIsPriceEntered", "Y");
          continue;

        }

        String sRSReturnPrice = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);

        String sTVSReturnPrice =
            eleTVSCartPriceResponseExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);

        logger.debug("PrimeLineNo is: " + sPrimeLineNumber + ", RS ReturnPrice is: "
            + sRSReturnPrice + " TVS Return Price is: " + sTVSReturnPrice);

        if (!YFCCommon.isVoid(sTVSReturnPrice)) {
          dTVSReturnPrice = Double.parseDouble(sTVSReturnPrice);
        }

        if (!YFCCommon.isVoid(sRSReturnPrice)) {
          dRSReturnPrice = Double.parseDouble(sRSReturnPrice);
        }

        if (dRSReturnPrice > dTVSReturnPrice) {
          // Create TVS Request document
          if (YFCCommon.isVoid(docItemListToTVS)) {
            docItemListToTVS = createHeaderTVS(yfsEnv, inputClone);
          }

          eloriginalTransaction = XMLUtil.getChildElement(docItemListToTVS.getDocumentElement(),
              KohlsPOCConstant.ORIGINAL_TRANSACTION);
          if (logger.isDebugEnabled()) {
            logger
                .debug("KohlsPOCPriceAdjustment.getItemTagList -- Before returning  Request to TVS"
                    + XMLUtil.getElementXMLString(eloriginalTransaction));
          }

          NodeList nlItemList =
              eloriginalTransaction.getElementsByTagName(KohlsPOCConstant.ATTR_ITEM_LIST);
          Element itemListEle = null;
          if (!YFCCommon.isVoid(nlItemList) && nlItemList.getLength() > 0) {
            // dont create Itemlist
            itemListEle = (Element) nlItemList.item(0);
          } else {
            itemListEle =
                XMLUtil.createChild(eloriginalTransaction, KohlsPOCConstant.ATTR_ITEM_LIST);
          }

          PAItemFound = true;
          logger.debug("PrimeLineNo " + sPrimeLineNumber + " qualified for Price Adjustment");
          // Element replaceElementTemp = eleTVSCartPriceResponse

          Element eTVSPriceInfo =
              (Element) eleTVSCartPriceResponse.getElementsByTagName("LinePriceInfo").item(0);

          // MJ 03/21 - Adding ExtnOrigLineTax on Line tax element -
          // begin
          NodeList nlTVSLineTax =
              eleTVSCartPriceResponse.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
          Element eleCurrentLineTaxes =
              XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES, true);
          if (!YFCCommon.isVoid(nlTVSLineTax) && nlTVSLineTax.getLength() > 0) {
            for (int j = 0; j < nlTVSLineTax.getLength(); j++) {
              Element eleTVSLineTax = (Element) nlTVSLineTax.item(j);
              String sTaxName = eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_NAME);
              Element eleCurrentLineTax = (Element) XPathUtil.getNode(eleCurrentLineTaxes,
                  "LineTax[@TaxName='" + sTaxName + "']");
              if (!YFCCommon.isVoid(eleCurrentLineTax)) {
                String sCurrentTax = eleCurrentLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                Element eleTVSLineTaxExtn =
                    XMLUtil.getChildElement(eleTVSLineTax, KohlsPOCConstant.E_EXTN, true);
                eleTVSLineTaxExtn.setAttribute("ExtnOrigTaxAmt", sCurrentTax);
              }
            }
          }

          if (logger.isDebugEnabled()) {
            logger.debug(
                "Element to replace is " + XMLUtil.getElementXMLString(eleTVSCartPriceResponse));
          }
          // Add item to TVS Request
          createItem(yfsEnv, eleTVSCartPriceResponse, itemListEle, dTVSReturnPrice);

          Element replaceElement = (Element) inputClone.importNode(eleTVSCartPriceResponse, true);

          eleOrdeLines.replaceChild(replaceElement, eleCurrentOrderLine);

        } else if ((dRSReturnPrice < dTVSReturnPrice)
            && eleCustomAttr.getAttribute("Text11").equalsIgnoreCase("Eligible")) {
          Element replaceElement = (Element) inputClone.importNode(eleTVSCartPriceResponse, true);

          eleOrdeLines.replaceChild(replaceElement, eleCurrentOrderLine);

        } else {
          XMLUtil.removeChild(eleOrdeLines, eleCurrentOrderLine);
          i--;
        }
      }
      if (PAItemFound) {

        // MJ 06-19: No need to send the exclusions to TVS request as we dont need to
        // evaluate promotions again.
        // KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(yfsEnv, eloriginalTransaction);
        Element elAdjustment =
            XMLUtil.createChild(eloriginalTransaction, KohlsPOCConstant.ADJUSTMENS);
        Element elTaxExempt =
                XMLUtil.createChild(eloriginalTransaction, KohlsPOCConstant.ATTR_TAX_EXEMPT);
        
        if ((!YFCCommon.isVoid(eleOrderElement.getAttribute("TaxExemptFlag"))) 
        	&& KohlsPOCConstant.YES.equalsIgnoreCase(eleOrderElement.getAttribute("TaxExemptFlag"))) {
            
            XMLUtil.setNodeValue(elTaxExempt, KohlsPOCConstant.YES);
        } else {
        
        XMLUtil.setNodeValue(elTaxExempt, KohlsPOCConstant.NO);
        }

        if (logger.isDebugEnabled()) {
          logger.debug("KohlsPOCPriceAdjustment.getItemTagList Second  Request to TVS"
              + XMLUtil.getElementXMLString(eloriginalTransaction));
        }

        docResponseFromGetCartPrice = KOHLSBaseApi.invokeService(yfsEnv,
            KohlsPOCConstant.KOHLS_POC_PSA_WEB_SERVICE, eloriginalTransaction.getOwnerDocument());
        Element eleSecondTVSOut = docResponseFromGetCartPrice.getDocumentElement();
        for (int i = 0; i < nlOrderLines.getLength(); i++) {
          Element eleOrderLine = (Element) nlOrderLines.item(i);
          String sPrimeLineNumber = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
          Element eleTVSOrderLine = (Element) XPathUtil.getNode(eleSecondTVSOut,
                  "//itemList/item[@id='" + sPrimeLineNumber + "']");
          KohlsPoCPnPUtil.consolidateLineTaxes(eleTVSOrderLine);
          Element eleTVSLineTaxes = (Element) eleTVSOrderLine.getElementsByTagName("LineTaxes").item(0);
          if (!YFCCommon.isVoid(eleTVSLineTaxes)) {
            NodeList nlTVSLineTax =
                eleTVSLineTaxes.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);

            Element eleCurrentLineTaxes =
                XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES, true);
            if (!YFCCommon.isVoid(nlTVSLineTax) && nlTVSLineTax.getLength() > 0) {
              for (int j = 0; j < nlTVSLineTax.getLength(); j++) {
                Element eleTVSLineTax = (Element) nlTVSLineTax.item(j);
                String sTaxName = eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_NAME);
                Element eleCurrentLineTax = (Element) XPathUtil.getNode(eleCurrentLineTaxes,
                    "LineTax[@TaxName='" + sTaxName + "']");
                if (!YFCCommon.isVoid(eleCurrentLineTax)) {
                  eleCurrentLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX,
                      eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX));
                  eleCurrentLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT,
                      eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT));
                  eleCurrentLineTax.setAttribute("LineTotalTax",
                      eleTVSLineTax.getAttribute("LineTotalTax"));
                }
              }
            }
          }

          // MJ 03/21 setting reset attribute - begin

          Element elePromotions = mapOLPromotionToBeReset.get(sPrimeLineNumber);
          if (!YFCCommon.isVoid(elePromotions)) {
            NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
            if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
              for (int j = 0; j < nlPromotion.getLength(); j++) {
                Element elePromotion = (Element) nlPromotion.item(j);
                elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, "N");
              }
            }
            XMLUtil.importElement(eleOrderLine, elePromotions);
          }

          // MJ 03/21 setting reset attribute - end
        }
      }
    } catch (Exception e) {
      logger.error("Error occured in KohlsPOCPriceAdjustment.getItemTagList " + e.getMessage());
    }

    logger
        .debug("KohlsPOCPriceAdjustment.getItemTagList *********** Before returning  Request to TVS"
            + XMLUtil.getXMLString(inputClone));
    logger.endTimer("KohlsPOCPriceAdjustment.getItemTagList");

    return inputClone;
  }

  /**
   * @param yfsEnv
   * @param eleCurrentOrderLine
   * @param itemListEle
   * @param dDifference
   * @throws Exception
   */
  private void createItem(YFSEnvironment yfsEnv, Element eleCurrentOrderLine, Element itemListEle,
      double dDifference) throws Exception {
    logger.beginTimer("KohlsPOCPriceAdjustment.createItem");
    Element eleItem = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_ITEM);
    Element extnEle = XMLUtil.getChildElement(eleCurrentOrderLine, KohlsPOCConstant.E_EXTN);

    String sItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
    Element itemEle = XMLUtil.createChild(itemListEle, KohlsPOCConstant.ELEM_SMALL_ITEM);
    Element eleSku = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SKU);
    XMLUtil.setNodeValue(eleSku, sItemID);
    Element eleId = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_ID);
    XMLUtil.setNodeValue(eleId,
        eleCurrentOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
    Element EleMerchandise = XMLUtil.createChild(itemEle, KohlsPOCConstant.MERCHANDISE_HIRARCHY);
    String department = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_ITEM_DEPT);
    String majorClass = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_ITEM_CLASS);
    String subClass = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_ITEM_SUB_CLASS);
    String vendorStyle = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_VENDOR_STYLE_NO);
    Element deptElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.DEPARTMENT);
    XMLUtil.setNodeValue(deptElement, department);
    Element majorClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.MAJOR_CLASS);
    XMLUtil.setNodeValue(majorClassElement, majorClass);
    Element subClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.SUB_CLASS);
    XMLUtil.setNodeValue(subClassElement, subClass);
    Element vendorStyleElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.VENDOR_STYLE);
    if (YFCCommon.isVoid(vendorStyle)) {
      vendorStyle = "10";
    }
    XMLUtil.setNodeValue(vendorStyleElement, vendorStyle);
    Element eleTaxCodeIndicator =
        XMLUtil.createChild(itemEle, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
    XMLUtil.setNodeValue(eleTaxCodeIndicator,
        extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE));
    Element eleTaxExempt = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
    Element eleCurrentLinePriceInfo = XMLUtil.getChildElement(eleCurrentOrderLine, "LinePriceInfo");
    String strTaxableFlag = eleCurrentLinePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
    if (!YFCCommon.isVoid(strTaxableFlag) && (strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.NO)
        || strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.OVERRIDE_TAX_O))) {
      XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
    } else {
      XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);

    }
    Element eleRegPrice = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_REGULAR_PRICE);

    String sUnitPrice = eleCurrentLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
    Double dRegularPrice = 0.00;
    if (!YFCCommon.isVoid(sUnitPrice)) {
      dRegularPrice = Double.parseDouble(sUnitPrice);
    }
    NodeList nlLineCharge =
        eleCurrentOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
    for (int i = 0; i < nlLineCharge.getLength(); i++) {
      Element eleLineCharge = (Element) nlLineCharge.item(i);
      String sChargePerLine = eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
      String sChargeCategory = XMLUtil.getAttribute(eleLineCharge, KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
      if (!YFCCommon.isVoid(sChargePerLine) && !KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(sChargeCategory)) {
        dRegularPrice = dRegularPrice - Double.parseDouble(sChargePerLine);
      }
    }
    //PST-3701 - Start - Formatting Double value
    DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
    //XMLUtil.setNodeValue(eleRegPrice, Double.toString(dRegularPrice));
    XMLUtil.setNodeValue(eleRegPrice, twoDForm.format(dRegularPrice));
    //PST-3701 - End
    String SKUStatusCode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
    Element regularPriceStatusElement =
        XMLUtil.createChild(itemEle, KohlsPOCConstant.REGULAR_PRICE_STATUS);
    XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);
    String isDiscountable = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_IS_DISCOUNTABLE);
    if (KohlsPOCConstant.YES.equalsIgnoreCase(isDiscountable)) {
      isDiscountable = KohlsPOCConstant.NO;
    } else if (KohlsPOCConstant.NO.equalsIgnoreCase(isDiscountable)) {
      isDiscountable = KohlsPOCConstant.YES;
    }

    Element eleEmpDiscCode = null;
    String sDiscCode = KohlsPOCConstant.CONST_S;
    Element eleReference = (Element) KohlsXPathUtil.getNode(eleCurrentOrderLine,
        "./References/Reference[@Name='ExtnEmpDiscCode']");
    if (!YFCCommon.isVoid(eleReference)) {
      eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
      if (!YFCCommon.isVoid(eleReference.getAttribute(KohlsPOCConstant.A_VALUE))) {
        XMLUtil.setNodeValue(eleEmpDiscCode, eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
      } else {
        XMLUtil.setNodeValue(eleEmpDiscCode, KohlsPOCConstant.CONST_S);
      }
    } else {
      logger.debug("References is empty, calling GetItemList api");
      eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
      Document docGetItemListOutput = getItemList(yfsEnv, sItemID);

      Element eleItemOut = (Element) docGetItemListOutput.getElementsByTagName("Item").item(0);
      if (!(YFCCommon.isVoid(eleItemOut))) {
        Element eleItemExtn = XMLUtil.getChildElement(eleItemOut, "Extn");
        sDiscCode = eleItemExtn.getAttribute("ExtnEmpDiscCode");
        logger.debug("eleEmpDiscCode " + sDiscCode);
        XMLUtil.setNodeValue(eleEmpDiscCode, sDiscCode);
      }
    }

    Element eleScanTime = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SCAN_TIME);
    YFCDate date = new YFCDate();
    String sCreateTimeStamp = date.getString(null, true);
    XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
    logger.endTimer("KohlsPOCPriceAdjustment.createItem");
  }

  /**
   * @param yfsEnv
   * @param sItemID
   * @return
   */
  private Document getItemList(YFSEnvironment yfsEnv, String sItemID) {
    logger.beginTimer("KohlsPOCPriceAdjustment.getItemList");
    Document docGetItemListOutput = null;

    try {
      Document docGetItemListInput = XMLUtil.createDocument("Item");

      Element eleItemIn = docGetItemListInput.getDocumentElement();
      eleItemIn.setAttribute("ItemID", sItemID);
      String sGetItemListTemplate = "<ItemList><Item ItemID=''><Extn ExtnClass='' ExtnDept='' "
          + "ExtnEmpDiscCode='' ExtnMerchandiseTaxCode='' ExtnSubClass=''/>"
          + "<ClassificationCodes TaxProductCode=''/></Item></ItemList>";
      if (logger.isDebugEnabled()) {
        logger.debug("Invoking getItemList API with input as:\n"
            + XMLUtil.getXMLString(docGetItemListInput));
      }
      docGetItemListOutput =
          KOHLSBaseApi.invokeAPI(yfsEnv, XMLUtil.getDocument(sGetItemListTemplate),
              KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);

    } catch (ParserConfigurationException e) {
      logger.error(
          "Error occured while calling itemList KohlsPOCPriceAdjustment.getItemList ParserConfigurationException"
              + e.getMessage());
    } catch (SAXException e) {
      logger.error(
          "Error occured while calling itemList KohlsPOCPriceAdjustment.getItemList ParserConfigurationException"
              + e.getMessage());
    } catch (IOException e) {
      logger.error(
          "Error occured while calling itemList KohlsPOCPriceAdjustment.getItemList IOException"
              + e.getMessage());
    } catch (Exception e) {
      logger.error(
          "Error occured while calling itemList KohlsPOCPriceAdjustment.getItemList Exception"
              + e.getMessage());
    } finally {
      logger.endTimer("KohlsPOCPriceAdjustment.getItemList");
    }
    return docGetItemListOutput;
  }

  /**
   * @param yfsEnv
   * @param inDoc
   * @return
   * @throws ParserConfigurationException
   */
  private Document createHeaderTVS(YFSEnvironment yfsEnv, Document inDoc)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsPOCPriceAdjustment.createHeaderTVS");
    Element tempOrderEle = null;
    tempOrderEle = inDoc.getDocumentElement();

    Element eleCustomAttributes =
        (Element) tempOrderEle.getElementsByTagName("CustomAttributes").item(0);
    String strStoreNumber = eleCustomAttributes.getAttribute("Text7");
    String transId = eleCustomAttributes.getAttribute("Text9");
    String transTime = eleCustomAttributes.getAttribute("Date2");
    Document docInputRequestToTVS = XMLUtil.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
    Element priceRequestEle = docInputRequestToTVS.getDocumentElement();
    // changed for compile issue
    priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
    priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");
    Element transactionEle =
        XMLUtil.createChild(priceRequestEle, KohlsPOCConstant.ORIGINAL_TRANSACTION);
    /*
     * String transId = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
     */
    Element eleTransactionId =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
    XMLUtil.setNodeValue(eleTransactionId, transId);
    Element transactionTime =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.TRANSACTION_TIME);
    /*
     * String transTime = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORDER_DATE);
     */
    XMLUtil.setNodeValue(transactionTime, transTime);
    /*
     * String strStoreNumber = KohlsPoCPnPUtil.prepadStoreNoWithZeros( tempOrderEle
     * .getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
     */
    Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
    XMLUtil.setNodeValue(eleStoreNum, strStoreNumber);
    Element storeAddressEle =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
    Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
    Element eleCountry =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
    Element elePostal =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
    Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
    Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
    Element eleShipNode = XMLUtil.getChildElement(tempOrderEle, KohlsConstant.SHIP_NODE);
    Element eleShipNdPerInfo =
        XMLUtil.getChildElement(eleShipNode, KohlsPOCConstant.SHP_NODE_PER_INFO);

    Document getOrganizationListOutput = callOrganisationHierarchy(yfsEnv, strStoreNumber);
    eleShipNdPerInfo = ((Element) getOrganizationListOutput
        .getElementsByTagName(KohlsXMLLiterals.E_SHIPNODE_PERSON_INFO).item(0));
    XMLUtil.setNodeValue(eleCity,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
    XMLUtil.setNodeValue(eleCountry,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
    XMLUtil.setNodeValue(elePostal,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
    XMLUtil.setNodeValue(eleState,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
    XMLUtil.setNodeValue(eleGeo,
        XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
    // }
    Element lidOfferExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.LID_OFFER_EXEMPT);
    XMLUtil.setNodeValue(lidOfferExempt, "N");
    logger.endTimer("KohlsPOCPriceAdjustment.createHeaderTVS");
    return docInputRequestToTVS;
  }

  /**
   * @param yfsEnv
   * @param sStoreNumber
   * @return
   */
  private Document callOrganisationHierarchy(YFSEnvironment yfsEnv, String sStoreNumber) {
    Document getOrganizationListOutput = null;
    try {
      Document getOrganizationHierarchyInput =
          XMLUtil.getDocument("<Organization OrganizationCode='" + sStoreNumber
              + "' OrganizationKey='" + sStoreNumber + "' ></Organization>");
      Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
          "<Organization OrganizationName=''><Node ShipNode=''><ShipNodePersonInfo City='' Country='' ZipCode='' State='' TaxGeoCode=''/></Node></Organization>");
      getOrganizationListOutput = KOHLSBaseApi.invokeAPI(yfsEnv, getOrganizationHierarchyTemplate,
          KohlsConstant.GET_ORGANIZATION_HIERARCHY_API, getOrganizationHierarchyInput);
    } catch (Exception e) {
      logger.error(
          "Error occured in KohlsPOCPriceAdjustment.callOrganisationHierarchy " + e.getMessage());
    }
    return getOrganizationListOutput;
  }
}
