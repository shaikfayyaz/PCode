package com.kohls.poc.returns.api;

import java.text.DecimalFormat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.api.KohlsPoCPublishVoidInvoice;
import com.kohls.poc.api.KohlsPocInvoiceToSalesHubAPI;
import com.kohls.poc.api.KohlsPublishInvoiceForPA;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCResendInvoices extends KOHLSBaseApi {
	private static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCResendInvoices.class.getName());

	public Document resendInvoiceMessagesForReturnsAndPA(YFSEnvironment env,
			Document docInXML) throws Exception {
		logger.beginTimer("KohlsPoCResendInvoices.resendInvoiceMessagesForReturnsAndPA");
		Document docOutXML = null;
		String strOHkey = docInXML.getDocumentElement().getAttribute(
				KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		// call GetORderlist API
		Document inputDoc = KOHLSBaseApi.invokeAPI(env,
				"global/template/api/DataCollect_Get_Sales_Order_List.xml",
				KohlsPOCConstant.GET_ORDER_LIST, docInXML);
		Element eleChargeTran = (Element) XPathUtil
				.getNode(inputDoc,
						"//OrderList/Order/ChargeTransactionDetails/ChargeTransactionDetail[@OrderInvoiceKey !='']");
		String strOHInvoicekey = eleChargeTran
				.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);

		Element eleOrder = (Element) XPathUtil.getNode(inputDoc,
				"/OrderList/Order");
		String sPosSeqNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
		eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);

		
		if (YFCCommon.isVoid(eleOrder)) {
			// Nothing to retrieve.
			return docOutXML;
		}
		Element eleOrderExtn = (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.A_EXTN)
				.item(0);
		String sPOCFeature = "";
		sPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
		String sPAStatus = "";
		sPAStatus = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
		String sReturnStatus = "";
		sReturnStatus = eleOrder.getAttribute(KohlsPOCConstant.A_POST_VOIDED);

		logger.debug("Determining the status of order");
		
		// set @OrderInvoiceKey, VoidTransactionNo
		Element eleInRoot = docInXML.getDocumentElement();
		eleInRoot.setAttribute(
				KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY, strOHInvoicekey);
		eleInRoot.setAttribute("VoidTransactionNo",
				sPosSeqNo);
		eleInRoot.setAttribute(KohlsPOCConstant.EXTN_POC_FEATURE, sPOCFeature);
		eleInRoot.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, sPAStatus);
		eleInRoot.setAttribute(KohlsPOCConstant.A_POST_VOIDED, sReturnStatus);
		
		if (sPOCFeature.contains("PriceAdjustment")) {
			// PA transaction
			if (sPAStatus.equalsIgnoreCase("PA_VOID")) {
				docOutXML = KOHLSBaseApi.invokeService(env, "KohlsPAPostVoid",
						docInXML);
			} else if (sPAStatus.equalsIgnoreCase("PA_MIDVOID")) {
				docOutXML = KOHLSBaseApi.invokeService(env, "KohlsPAMidVoid",
						docInXML);
			} else {
				// Consolidating the Invoice Collection and updating
				// InvoiceHeader
				Document docOrderInvoiceDetailInput = YFCDocument
						.createDocument("InvoiceDetail").getDocument();
				Element eleOrderInvoiceInput = docOrderInvoiceDetailInput
						.getDocumentElement();

				Element elePAInvHeader = XMLUtil.createChild(
						eleOrderInvoiceInput, "InvoiceHeader");

				Element eleOrderRoot = (Element) docOrderInvoiceDetailInput
						.importNode(eleOrder, true);
				elePAInvHeader.appendChild(eleOrderRoot);
				eleOrderRoot.setAttribute("OrderHeaderKey", strOHkey);
				Document docPublishInvoiceDetail = new KohlsPocInvoiceToSalesHubAPI()
						.generateAndPublishPOSInvoiceToSalesHub(env,
								docOrderInvoiceDetailInput);
				KohlsPublishInvoiceForPA oPAInvoice = new KohlsPublishInvoiceForPA();
				oPAInvoice.consolidateInvoiceCollectionWithHeaderDetails(env,
						docPublishInvoiceDetail, strOHkey);
				docOutXML = docPublishInvoiceDetail;
				if(logger.isDebugEnabled()){
					logger.debug("XML used for posting to KohlsPoCPostMessageToSalesHubQ " +XMLUtil.getXMLString(docPublishInvoiceDetail));
				}
				KOHLSBaseApi.invokeService(env,
						"KohlsPoCPostMessageToSalesHubQ", docOutXML);
			}
		}
		if (sPOCFeature.contains("Return")) {

			// Follow returns invoice
			if (sReturnStatus.equalsIgnoreCase("Y")) {

				KohlsPoCPublishVoidInvoice opostVoid = new KohlsPoCPublishVoidInvoice();
				docOutXML = opostVoid.postVoid(env, docInXML);
				if(logger.isDebugEnabled()){
					logger.debug("XML used for posting to KohlsPoCPostVoidAfterMessageToSalesHubQ " +XMLUtil.getXMLString(docOutXML));
				}
				KOHLSBaseApi.invokeService(env,
						"KohlsPoCPostVoidAfterMessageToSalesHubQ", docOutXML);
			} else {
				Document inGetOrderInvoiceList = XMLUtil
						.getDocument("<OrderInvoice OrderHeaderKey='' ></OrderInvoice>");
				inGetOrderInvoiceList.getDocumentElement().setAttribute(
						"OrderHeaderKey", strOHkey);

				// Calling getOrderInvoiceList API to get all the Invoices
				// associated to the current PSA Order
				Document getOrderInvoiceListTemplate = XMLUtil
						.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_OUT_TEMP);
				Document outGetOrderInvoiceList = KOHLSBaseApi.invokeAPI(env,
						getOrderInvoiceListTemplate, "getOrderInvoiceList",
						inGetOrderInvoiceList);

				if (logger.isDebugEnabled())
					logger.debug("The outGetOrderInvoiceList Output : "
							+ XMLUtil.getXMLString(outGetOrderInvoiceList));

				docOutXML = resendReturnsInvoiceMessages(env,
						outGetOrderInvoiceList);
				if(logger.isDebugEnabled()){
					logger.debug("XML used for posting to KohlsPoCPostMessageToSalesHubQ " +XMLUtil.getXMLString(docOutXML));
				}
				KOHLSBaseApi.invokeService(env,
						"KohlsPoCPostMessageToSalesHubQ", docOutXML);

			}
		}
		logger.endTimer("KohlsPoCResendInvoices.resendInvoiceMessagesForReturnsAndPA");
		return docOutXML;
	}

	public Document resendReturnsInvoiceMessages(YFSEnvironment env,
			Document docInvoiceListOut) throws Exception {

		logger.beginTimer("KohlsPoCResendInvoices.resendReturnsInvoiceMessages");
		DecimalFormat df = new DecimalFormat("#0.00");
		Document docInvoiceOut = null;
		KohlsPoCPreateReturnInvoiceForSalesHub oSalesHub = new KohlsPoCPreateReturnInvoiceForSalesHub();
		NodeList nlOrderInvoice = docInvoiceListOut
				.getElementsByTagName(KohlsPOCConstant.E_ORDER_INVOICE);
		for (int i = 0; i < nlOrderInvoice.getLength(); i++) {
			Element eleOrderInvoice = (Element) nlOrderInvoice.item(i);
			String sOrderInvoiceKey = eleOrderInvoice
					.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);

			if (!YFCCommon.isVoid(sOrderInvoiceKey)) {
				Document docInvoiceDetailsOut = oSalesHub
						.getOrderInvoiceDetails(env, sOrderInvoiceKey);
				if (i == 0) {
					docInvoiceOut = (Document) docInvoiceDetailsOut
							.cloneNode(true);
					continue;
				}
				NodeList nlCollectionDetail = docInvoiceDetailsOut
						.getElementsByTagName(KohlsPOCConstant.ELE_COLLECTION_DETAIL);
				Element eleOutCollectionDetails = (Element) eleOrderInvoice
						.getElementsByTagName(
								KohlsPOCConstant.ELE_COLLECTION_DETAILS)
						.item(0);
				for (int j = 0; j < nlCollectionDetail.getLength(); j++) {
					Element eleCollectionDetail = (Element) nlCollectionDetail
							.item(j);
					Element eleTemp = (Element) eleOutCollectionDetails
							.getOwnerDocument().importNode(eleCollectionDetail,
									true);
					eleOutCollectionDetails.appendChild(eleTemp);
				}
				// Consolidating the amounts
				Element eleInvoiceHeaderFinal = (Element) eleOrderInvoice
						.getElementsByTagName(
								KohlsPOCConstant.ELE_INVOICE_HEADER).item(0);
				String sTotalAmount_Final = eleInvoiceHeaderFinal
						.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
				String sTotalTax_Final = eleInvoiceHeaderFinal
						.getAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX);
				String sLineSubTotal_Final = eleInvoiceHeaderFinal
						.getAttribute(KohlsPOCConstant.ATTR_LINE_SUB_TOTAL);
				String sAmountCollected_Final = eleInvoiceHeaderFinal
						.getAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED);

				Element eleInvoiceHeader = (Element) docInvoiceDetailsOut
						.getElementsByTagName(
								KohlsPOCConstant.ELE_INVOICE_HEADER).item(0);
				String sTotalAmount = eleInvoiceHeader
						.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
				String sTotalTax = eleInvoiceHeader
						.getAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX);
				String sLineSubTotal = eleInvoiceHeader
						.getAttribute(KohlsPOCConstant.ATTR_LINE_SUB_TOTAL);
				String sAmountCollected = eleInvoiceHeader
						.getAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED);

				if (!YFCCommon.isVoid(sTotalAmount_Final)
						&& !YFCCommon.isVoid(sTotalAmount)) {
					Double dTotalAmount_Final = Double
							.parseDouble(sTotalAmount_Final)
							+ Double.parseDouble(sTotalAmount);
					eleInvoiceHeaderFinal.setAttribute(
							KohlsPOCConstant.A_TOATL_AMOUNT,
							df.format(dTotalAmount_Final));
				}
				if (!YFCCommon.isVoid(sTotalTax_Final)
						&& !YFCCommon.isVoid(sTotalTax)) {
					Double dTotalTax_Final = Double
							.parseDouble(sTotalTax_Final)
							+ Double.parseDouble(sTotalTax);
					eleInvoiceHeaderFinal.setAttribute(
							KohlsPOCConstant.ATTR_TOTAL_TAX,
							df.format(dTotalTax_Final));
				}
				if (!YFCCommon.isVoid(sLineSubTotal_Final)
						&& !YFCCommon.isVoid(sLineSubTotal)) {
					Double dLineSubTotal_Final = Double
							.parseDouble(sLineSubTotal_Final)
							+ Double.parseDouble(sLineSubTotal);
					eleInvoiceHeaderFinal.setAttribute(
							KohlsPOCConstant.ATTR_LINE_SUB_TOTAL,
							df.format(dLineSubTotal_Final));
				}
				if (!YFCCommon.isVoid(sAmountCollected_Final)
						&& !YFCCommon.isVoid(sAmountCollected)) {
					Double dAmountCollected_Final = Double
							.parseDouble(sAmountCollected_Final)
							+ Double.parseDouble(sAmountCollected);
					eleInvoiceHeaderFinal.setAttribute(
							KohlsPOCConstant.ATTR_AMOUNT_COLLECTED,
							df.format(dAmountCollected_Final));
				}

			}
		}
		docInvoiceOut = new KohlsPocInvoiceToSalesHubAPI()
				.generateAndPublishPOSInvoiceToSalesHub(env, docInvoiceOut);
		if (nlOrderInvoice.getLength() > 0){
			oSalesHub.consolidateCollectionDetails(docInvoiceOut);
			oSalesHub.manupulateReturnOrderForDataCollect(docInvoiceOut);
		}
		logger.endTimer("KohlsPoCResendInvoices.resendReturnsInvoiceMessages");
		return docInvoiceOut;

	}

}
