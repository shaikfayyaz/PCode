/*
 * File: KohlsPoCManagePSIOrdersForReturns.java Created on Jan 21, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 *
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.api;

import java.text.DecimalFormat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCCommercePSIStatusGenerator;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIStatus;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.manager.OrderManager;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.manager.SessionManager;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author mrjoshi This class forms the input xml and calls managePSIOrderForPOS api for order
 * detail display on pinpad.
 */
public class KohlsPoCManagePSIOrdersForReturns extends KOHLSBaseApi {
    private static YFCLogCategory logger =
            YFCLogCategory.instance(KohlsPoCManagePSIOrdersForReturns.class.getName());

    public Document managePSIOrderForReturns(YFSEnvironment env, Document inDoc) throws Exception {
        logger.beginTimer("KohlsPoCManagePSIOrdersForReturns.managePSIOrderForReturns");
        // MJ 01/23: Added for CAPE 1568 - Begin
        String sExtnPOCFeature = "";
        String sExtnPsaStatus = "";
        boolean bSkipAPICall = false;
        Object SkipAPICall = env.getTxnObject("SkipManagePSIOrderCall");
        if (!YFCCommon.isVoid(SkipAPICall)) {
            bSkipAPICall = (Boolean) SkipAPICall;
        }
        if (!YFCCommon.isVoid(bSkipAPICall) && bSkipAPICall) {
            return inDoc;
        }

        Element eleRootElement = inDoc.getDocumentElement();
        String sTerminalID = eleRootElement.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        String sStoreID = eleRootElement.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        Element eleOrderExtn = XMLUtil.getChildElement(eleRootElement, KohlsPOCConstant.E_EXTN);
        if (!YFCCommon.isVoid(eleOrderExtn)) {
            sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE);
            sExtnPsaStatus = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_PSA_STATUS);
        }
        // PA MidVoid and Post Void - begin
        if (!YFCCommon.isVoid(sExtnPOCFeature)
                && KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)
                && !KohlsXMLLiterals.A_PA_STARTED.equals(sExtnPsaStatus)) {
     /* eleRootElement.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, sTerminalID);
      eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, sStoreID);
      eleRootElement.setAttribute(KohlsPOCConstant.OPERATION,
          KohlsXMLLiterals.OPERATION_FINISH_SESSION);
      eleRootElement.setAttribute(KohlsPOCConstant.A_ORDER_DETAILS_INCLUDED, "true");
      invokeAPI(env, KohlsPOCConstant.API_MANAGE_PSI_ORDER_FOR_POS, inDoc);*/
            Document docPSIInput = XMLUtil.createDocument("PSIStatus");
            Element elePSIStatus = docPSIInput.getDocumentElement();
            elePSIStatus.setAttribute(KohlsXMLLiterals.A_CLIENT_ID, sTerminalID);
            elePSIStatus.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, sStoreID);
            Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);
            Element elePsiStatus =
                    (Element) docPSIStatusOut.getElementsByTagName(KohlsXMLLiterals.E_PSI_STATUS).item(0);
            if (!YFCCommon.isVoid(elePsiStatus)) {
                YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
                NRSCCommercePSIStatusGenerator generator =
                        new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
                PSIStatus psiStatus = generator.generatePSIStatus();
                OrderManager manager = SessionManager.getOrderManager(psiStatus);
                manager.pushSessionEnd();
            }
            logger.endTimer("KohlsPoCManagePSIOrdersForReturns.managePSIOrderForReturns");
            return inDoc;
        }
        // PA MidVoid and Post Void - end

        if (KohlsXMLLiterals.A_PA_STARTED.equals(sExtnPsaStatus)
                && ServerTypeHelper.amIOnEdgeServer()) {
            Element eleAdditionalInfo =
                    SCXmlUtil.createChild(inDoc.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
            eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, "MOTHERSHIP");
        }

        Document docGetOrderDetailsOut =
                invokeAPI(env, "global/template/api/POC/managePSIOrder/managePSIOrderForPOS_POCReturns.xml",
                        KohlsPOCConstant.API_GET_ORDER_DETAILS, inDoc);
        Element eleOrderOutRoot = docGetOrderDetailsOut.getDocumentElement();
        if (!YFCCommon.isVoid(eleOrderOutRoot) && KohlsXMLLiterals.A_PA_STARTED.equals(sExtnPsaStatus)
                && ServerTypeHelper.amIOnEdgeServer()) {
            Element eleAdditionalInfo =
                    XMLUtil.getChildElement(eleOrderOutRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
            if (!YFCCommon.isVoid(eleAdditionalInfo)) {
                eleOrderOutRoot.removeChild(eleAdditionalInfo);
            }
        }

        // If no orderlines then dont send message to Pinpad.
        NodeList nlOrderLine = eleOrderOutRoot.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
        if (nlOrderLine.getLength() == 0) {
            return docGetOrderDetailsOut;
        }
        eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, sTerminalID);
        eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, sStoreID);
        eleOrderOutRoot.setAttribute(KohlsPOCConstant.OPERATION,
                KohlsPOCConstant.OPERATION_UPDATE_SESSION);
        eleOrderOutRoot.setAttribute(KohlsPOCConstant.A_ORDER_DETAILS_INCLUDED, KohlsPOCConstant.TRUE);
        // PA - begin
        if (!YFCCommon.isVoid(sExtnPOCFeature)
                && KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)
                && KohlsXMLLiterals.A_PA_STARTED.equals(sExtnPsaStatus)) {
            prepareOrderForPriceAdjustmentDisplay(docGetOrderDetailsOut);
            eleOrderOutRoot.setAttribute(KohlsPOCConstant.OPERATION, "startSession");
            if (nlOrderLine.getLength() == 0) {
                logger.debug("No eligible lines found to display so Skipping pinpad call");
                logger.endTimer("KohlsPoCManagePSIOrdersForReturns.managePSIOrderForReturns");
                return docGetOrderDetailsOut;
            }
        }
        // PA - end
        else if (!YFCCommon.isVoid(sExtnPOCFeature)
                && "NonReceiptedReturn".equalsIgnoreCase(sExtnPOCFeature)) {
            processAssoDiscForNonReceiptedReturn(docGetOrderDetailsOut);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Calling managePSIOrderForPOS with input xml: \n"
                    + XMLUtil.getXMLString(docGetOrderDetailsOut));
        }
        invokeAPI(env, KohlsPOCConstant.API_MANAGE_PSI_ORDER_FOR_POS, docGetOrderDetailsOut);
        logger.endTimer("KohlsPoCManagePSIOrdersForReturns.managePSIOrderForReturns");
        return docGetOrderDetailsOut;
    }

    /**
     * Create By mrjoshi * This method adds the line charge amt for Associate disc to the line total
     * for pinpad display
     *
     * @param docGetOrderDetailsOut
     */
    private void processAssoDiscForNonReceiptedReturn(Document docGetOrderDetailsOut) {
        logger.beginTimer("KohlsPoCManagePSIOrdersForReturns.processAssoDiscForNonReceiptedReturn");
        boolean bIsAssocDiscPresent = false;
        NodeList nlPromotion = docGetOrderDetailsOut.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
        if (nlPromotion.getLength() > 0) {
            for (int i = 0; i < nlPromotion.getLength(); i++) {
                Element elePromotion = (Element) nlPromotion.item(i);
                String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
                if (KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(sPromotionType)) {
                    bIsAssocDiscPresent = true;
                    break;
                }
            }
            if (bIsAssocDiscPresent) {
                NodeList nlOrderLine =
                        docGetOrderDetailsOut.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
                for (int i = 0; i < nlOrderLine.getLength(); i++) {
                    double dAssocDisc = 0.0;
                    DecimalFormat df = new DecimalFormat("#0.00");
                    Element eleOrderLine = (Element) nlOrderLine.item(i);
                    NodeList nlLineCharge =
                            eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
                    for (int j = 0; j < nlLineCharge.getLength(); j++) {
                        Element eleLineCharge = (Element) nlLineCharge.item(j);
                        String sChargeCategory = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
                        if (KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE.equals(sChargeCategory)) {
                            String sChargePerLine =
                                    eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
                            dAssocDisc = Double.parseDouble(sChargePerLine);
                            break;
                        }
                    }
                    Element eleComputedPrice = XMLUtil.getChildElement(eleOrderLine, "ComputedPrice");
                    if (!YFCCommon.isVoid(eleComputedPrice)) {
                        eleComputedPrice.setAttribute(KohlsPOCConstant.E_LINE_TOTAL, df.format(
                                dAssocDisc + Double.parseDouble(eleComputedPrice.getAttribute(KohlsPOCConstant.E_LINE_TOTAL))));
                        eleComputedPrice.setAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX, df.format(dAssocDisc
                                + Double.parseDouble(eleComputedPrice.getAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX))));
                    }

                    Element eleAwards = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_AWARDS);
                    if (!YFCCommon.isVoid(eleAwards)) {
                        eleOrderLine.removeChild(eleAwards);
                    }
                    Element elePromotions =
                            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_PROMOTIONS);
                    if (!YFCCommon.isVoid(elePromotions)) {
                        eleOrderLine.removeChild(elePromotions);
                    }
                    Element eleLineCharges =
                            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
                    if (!YFCCommon.isVoid(eleLineCharges)) {
                        eleOrderLine.removeChild(eleLineCharges);
                    }
                    Element eleLinePriceInfo =
                            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
                    if (!YFCCommon.isVoid(eleLinePriceInfo)) {
                        eleOrderLine.removeChild(eleLinePriceInfo);
                    }
                    Element eleLineOverallTotals =
                            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
                    if (!YFCCommon.isVoid(eleLineOverallTotals)) {
                        eleOrderLine.removeChild(eleLineOverallTotals);
                    }
                }
            }
        }
        logger.endTimer("KohlsPoCManagePSIOrdersForReturns.processAssoDiscForNonReceiptedReturn");
    }

    /**
     * Create By mrjoshi * This method prepares the order xml to be displayed on Pinpad
     *
     * @param docGetOrderDetailsOut
     */
    private void prepareOrderForPriceAdjustmentDisplay(Document docGetOrderDetailsOut) {
        logger.beginTimer("KohlsPoCManagePSIOrdersForReturns.prepareOrderForPriceAdjustmentDisplay");
        Element eleOrder = docGetOrderDetailsOut.getDocumentElement();
        eleOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.RO_DOCUMENT_TYPE);
        eleOrder.setAttribute(KohlsPOCConstant.TAX_EXEMPT_FLAG, KohlsPOCConstant.NO);
        String sOrderNo = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
        String sPosSeqNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
        eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sOrderNo.substring(0, sOrderNo.length() - 9) + sPosSeqNo);
        NodeList nlOrderLine =
                docGetOrderDetailsOut.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
        Element eleOrderLines = XMLUtil.getChildElement(docGetOrderDetailsOut.getDocumentElement(),
                KohlsPOCConstant.ELEM_ORDER_LINES);
        double dTotalTax = 0.0;
        double dLineTotalWithoutTax = 0.0;
        DecimalFormat df = new DecimalFormat("#0.00");
        if (nlOrderLine.getLength() > 0) {
            for (int i = 0; i < nlOrderLine.getLength(); i++) {
                double dOrigReturnPrice = 0.00;
                double dCurrentReturnPrice = 0.00;
                double dAdjustedPrice = 0.00;
                double dAdjustedTax = 0.00;
                Element eleOrderLine = (Element) nlOrderLine.item(i);

                Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
                String sSkuStatus = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE);
                if (!YFCCommon.isVoid(sSkuStatus) && sSkuStatus.equalsIgnoreCase("30")) {
                    eleOrderLines.removeChild(eleOrderLine);
                    i--;
                    continue;
                }
                String sExtnIsPriceEntered = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);
                if (!YFCCommon.isVoid(sExtnIsPriceEntered) && sExtnIsPriceEntered.equalsIgnoreCase(KohlsPOCConstant.YES)) {
                    eleOrderLines.removeChild(eleOrderLine);
                    i--;
                    continue;
                }
                Element eleCustomAttributes =
                        XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
                if (!YFCCommon.isVoid(eleCustomAttributes)) {
                    String sText11 = eleCustomAttributes.getAttribute("Text11");
                    if (!"Eligible".equals(sText11)) {
                        eleOrderLines.removeChild(eleOrderLine);
                        i--;
                        continue;
                    }
                    String sText12 = eleCustomAttributes.getAttribute("Text12");
                    if (!YFCCommon.isVoid(sText12)) {
                        dOrigReturnPrice = Double.parseDouble(sText12);
                    }
                }
                String sExtnReturnPrice =
                        eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
                if (!YFCCommon.isVoid(sExtnReturnPrice)) {
                    dCurrentReturnPrice = Double.parseDouble(sExtnReturnPrice);
                }
                dAdjustedPrice = dOrigReturnPrice - dCurrentReturnPrice;
                dLineTotalWithoutTax = dLineTotalWithoutTax + dAdjustedPrice;
                if (Double.compare(dAdjustedPrice, 0.00) <= 0) {
                    eleOrderLines.removeChild(eleOrderLine);
                    i--;
                    continue;
                }
                Element eleAwards = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_AWARDS);
                double dExtnTotalTaxDeltaPerLine = 0.0;
                if (!YFCCommon.isVoid(eleAwards)) {
                	NodeList nlAwards = eleAwards.getElementsByTagName(KohlsCorpReturnsConstants.AWARD);
                	for(int iAward=0; iAward< nlAwards.getLength(); iAward++){
                		Element AwardEle = (Element) nlAwards.item(iAward);
                		if("FEE".equalsIgnoreCase(AwardEle.getAttribute(KohlsCorpReturnsConstants.CHARGE_CATEGORY))){
                			String sAmt = AwardEle.getAttribute(KohlsCorpReturnsConstants.AWARDS_AMOUNT);
                			if ( !YFCCommon.isVoid(sAmt)){
                				Element eleAwardExtn = SCXmlUtil.getChildElement(AwardEle,KohlsCorpReturnsConstants.EXTN);
                				String strExtnTaxDelta = eleAwardExtn.getAttribute("ExtnTaxDelta");
                				if(YFCCommon.isVoid(strExtnTaxDelta)){
                					strExtnTaxDelta = KohlsCorpReturnsConstants.DEFAULT_ZEROVALUE;
                				}
                				double dExtnTaxDelta = Double.parseDouble(strExtnTaxDelta);
                				if(dExtnTaxDelta == 0){
                					eleAwards.removeChild(AwardEle);
                					iAward--;
                				}else{
                					AwardEle.setAttribute(KohlsCorpReturnsConstants.AWARDS_AMOUNT, strExtnTaxDelta);
                					dExtnTotalTaxDeltaPerLine = dExtnTotalTaxDeltaPerLine + dExtnTaxDelta;
                				}
                			}
                		} else{
                			eleAwards.removeChild(AwardEle);
                			iAward--;
                		}
                	}
                }
                //dAdjustedPrice = dAdjustedPrice + dExtnTotalTaxDeltaPerLine;
                dLineTotalWithoutTax = dLineTotalWithoutTax + dExtnTotalTaxDeltaPerLine;
                Element elePromotions =
                        XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_PROMOTIONS);
                if (!YFCCommon.isVoid(elePromotions)) {
                    eleOrderLine.removeChild(elePromotions);
                }
                Element eleLineCharges =
                        XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
                if (!YFCCommon.isVoid(eleLineCharges)) {
                    eleOrderLine.removeChild(eleLineCharges);
                }
                NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
                if (nlLineTax.getLength() > 0) {
                    for (int j = 0; j < nlLineTax.getLength(); j++) {
                        Element eleLineTax = (Element) nlLineTax.item(j);
                        String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                        Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
                        if (!YFCCommon.isVoid(eleLineTaxExtn)) {
                            String sExtnOrigTaxAmt = eleLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
                            if (!YFCCommon.isVoid(sExtnOrigTaxAmt)) {
                                dAdjustedTax = Double.parseDouble(sExtnOrigTaxAmt) - Double.parseDouble(sTax);
                                dTotalTax = dTotalTax + dAdjustedTax;
                                eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, df.format(dAdjustedTax));
                                eleLineTax.setAttribute(KohlsXMLLiterals.A_REMAINING_TAX, df.format(dAdjustedTax));
                            }
                        }
                    }
                }
                double dAdjustedLineTotal = dAdjustedPrice + dAdjustedTax;
                Element eleComputedPrice = XMLUtil.getChildElement(eleOrderLine, "ComputedPrice");
                if (!YFCCommon.isVoid(eleComputedPrice)) {
                    eleComputedPrice.setAttribute(KohlsPOCConstant.E_LINE_TOTAL, df.format(dAdjustedLineTotal));
                    eleComputedPrice.setAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX, df.format(dAdjustedPrice));
                    eleComputedPrice.setAttribute(KohlsPOCConstant.ATTR_TAX, df.format(dAdjustedTax));
                    eleComputedPrice.setAttribute(KohlsPOCConstant.A_UNIT_PRICE, df.format(dAdjustedPrice));
                }
                Element eleLinePriceInfo =
                        XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
                if (!YFCCommon.isVoid(eleLinePriceInfo)) {
                    eleOrderLine.removeChild(eleLinePriceInfo);
                    if(!YFCCommon.isVoid(dExtnTotalTaxDeltaPerLine) && dExtnTotalTaxDeltaPerLine>0 && !YFCCommon.isVoid(dAdjustedPrice)){
                    	Element eleNewFeeLinePriceInfo = XMLUtil.createChild(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
                    	XMLUtil.setAttribute(eleNewFeeLinePriceInfo, KohlsPOCConstant.A_UNIT_PRICE, String.valueOf(df.format(dAdjustedPrice-dExtnTotalTaxDeltaPerLine)));
                    }
                }
                Element eleLineOverallTotals =
                        XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
                if (!YFCCommon.isVoid(eleLineOverallTotals)) {
                    eleOrderLine.removeChild(eleLineOverallTotals);
                }
            }
        }
        if (nlOrderLine.getLength() > 0) {
            Element eleOverallTotals = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELE_OVERALLTOTALS);
            eleOverallTotals.setAttribute("GrandCharges", KohlsPOCConstant.ZERO_STR);
            eleOverallTotals.setAttribute(KohlsPOCConstant.ATTR_GRAND_DISCOUNT, KohlsPOCConstant.ZERO_STR);
            eleOverallTotals.setAttribute(KohlsPOCConstant.ATTR_GRAND_TAX, df.format(dTotalTax));
            eleOverallTotals.setAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL, df.format(dLineTotalWithoutTax + dTotalTax));
            eleOverallTotals.setAttribute(KohlsPOCConstant.ATTR_LINE_SUB_TOTAL, df.format(dLineTotalWithoutTax));

            Element elePaymentMethods =
                    XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PAYMENT_METHODS);
            if (!YFCCommon.isVoid(elePaymentMethods)) {
                eleOrder.removeChild(elePaymentMethods);
            }
            Element elePromotions = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
            if (!YFCCommon.isVoid(elePromotions)) {
                eleOrder.removeChild(elePromotions);
            }
        }
        logger.endTimer("KohlsPoCManagePSIOrdersForReturns.prepareOrderForPriceAdjustmentDisplay");
    }
}
