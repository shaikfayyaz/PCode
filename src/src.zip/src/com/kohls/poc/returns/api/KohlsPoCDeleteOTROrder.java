/*
 * File: KohlsPoCDeleteOTROrder.java Created on Feb 24, 2017 for POC_OMS_IBM_Returns by mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author mrjoshi
 *
 */
public class KohlsPoCDeleteOTROrder extends KOHLSBaseApi {
  private static YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCDeleteOTROrder.class.getName());
 private static String OTR_ORDER_KEY ="OTROrderKey";
  public void deleteOTROrder(YFSEnvironment env, Document docInXML) throws Exception {
    logger.beginTimer("KohlsPoCDeleteOTROrder.deleteOTROrder");
    Document docGetOrderDetailsOut = getOrderDetails(env, docInXML);
    
    Document docOTROrder = XMLUtil.createDocument("KohlsOTROrder");
    Element eleOrder = docGetOrderDetailsOut.getDocumentElement();
    Element eleReferences = KohlsXPathUtil.getElementByXpath(docGetOrderDetailsOut, "/Order/References");
    NodeList nlReference = eleReferences.getElementsByTagName("Reference");
    if (!YFCCommon.isVoid(nlReference) && nlReference.getLength() > 0) {
      for (int i = 0; i < nlReference.getLength(); i++) {
        Element eleReference = (Element) nlReference.item(i);
        String sName = eleReference.getAttribute("Name");
        if (!YFCCommon.isVoid(sName) && sName.contains("OTR")) {
          Element eleOTROrder = docOTROrder.getDocumentElement();
          String sTemp[] = sName.split("-");
          if (sTemp.length > 3) {
        	  eleOTROrder.setAttribute("CurrentStoreID", eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
	          eleOTROrder.setAttribute("StoreID", sTemp[2]);
	          eleOTROrder.setAttribute("TerminalID", sTemp[3]);
	          eleOTROrder.setAttribute("TranNo", sTemp[4]);
	          invokeService(env, "KohlsPoCDeleteKohlsOTROrder", docOTROrder);
          }
        } else {
          continue;
        }
      }
    }
    logger.endTimer("KohlsPoCDeleteOTROrder.deleteOTROrder");
  }
  
  public void deleteOTROrderforReturnPass(YFSEnvironment env, Document docInXML) throws Exception {
	    logger.beginTimer("KohlsPoCDeleteOTROrder.deleteOTROrderforReturnPass");
	    Document docGetOrderDetailsOut =  invokeService(env, KohlsPOCConstant.KOHLS_OTR_ORDER_LIST_FLOW, docInXML);
	    
	    Element eleOrder = docGetOrderDetailsOut.getDocumentElement();
	    NodeList nlOrderList = eleOrder.getElementsByTagName(KohlsPOCConstant.E_KOHLS_OTR_ORDER);
	    if (!YFCCommon.isVoid(nlOrderList) && nlOrderList.getLength() > 0) {
	    	for (int i = 0; i < nlOrderList.getLength(); i++) {
	    		Element eleOTROrder = (Element) nlOrderList.item(i);
	    		Document docOtr = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_OTR_ORDER);
	    		Element eleOtr = docOtr.getDocumentElement();
	    		eleOtr.setAttribute(OTR_ORDER_KEY, eleOTROrder.getAttribute(OTR_ORDER_KEY));
	    		invokeService(env, "KohlsPoCDeleteKohlsOTROrder", docOtr);
	    	}
	    } 
  
	    logger.endTimer("KohlsPoCDeleteOTROrder.deleteOTROrderforReturnPass");
	  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docInXML
   * @return
   * @throws Exception 
   */
  private Document getOrderDetails(YFSEnvironment env, Document docInXML) throws Exception {
    logger.beginTimer("KohlsPoCDeleteOTROrder.getOrderDetails");
    Document docGetOrderDetailsOut = null;
    String sOrderHeaderKey = docInXML.getDocumentElement().getAttribute("OrderHeaderKey");
    if(!YFCCommon.isVoid(sOrderHeaderKey)){
      Document docGetOrderDetailsInXML = XMLUtil.createDocument("Order");
      docGetOrderDetailsInXML.getDocumentElement().setAttribute("OrderHeaderKey", sOrderHeaderKey);
      Document docGetOrderDetailsTemplate = XMLUtil.getDocument("<Order OrderHeaderKey='' SellerOrganizationCode=''><References><Reference Name='' Value=''/></References></Order>");
      docGetOrderDetailsOut =invokeAPI(env, docGetOrderDetailsTemplate,  "getOrderDetails", docGetOrderDetailsInXML);
    } else {
      docGetOrderDetailsOut = XMLUtil.createDocument("Order");
    }
    logger.endTimer("KohlsPoCDeleteOTROrder.getOrderDetails");
    return docGetOrderDetailsOut;
  }
}
