/*
 * File: KohlsPoCValidateItemForReturn.java Created on Jan 24, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 *
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.api;

import com.kohls.common.util.*;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author mrjoshi
 */

public class KohlsPoCValidateItemForReturn extends KOHLSBaseApi {

    private static YFCLogCategory logger =
            YFCLogCategory.instance(KohlsPoCValidateItemForReturn.class.getName());

    SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
    public static HashMap<String, String> specialSkuMap = new HashMap<String, String>();

    String sOrderHeaderKey = "";
    String sOrgCode = "";
    String sSellerOrgCode = "";
    Element eleOrder = null;
    Document docItemListOut = null;

    String ERROR_ITEM_NOT_FOUND = "ITEM_NOT_FOUND";

    /**
     * Create By mrjoshi *
     *
     * @param args
     */
    public static void main(String[] args) {

    }

    /*
     * Input to this class:
     *
     * <Order OrderHeaderKey="<optional>" ExtnPOCFeature=""> <OrderLines> <OrderLine GiftFlagInd=""
     * BarcodeData="<Item ID / UPC to be validated>"> </OrderLine> </OrderLines> </Order>
     *
     * Output of this class:
     *
     * <Order OrderHeaderKey=""> <OrderLines> <OrderLine ItemFound="Y/N" IsCallBackItem="Y/N"
     * IsRFIDItem="Y/N" PricePrompt="Y/N" IsWebExclusiveItem="Y/N"> <Item ItemID="" UnitOfMeasure=""
     * UPCCode=""> <ClassificationCodes TaxProductCode=""/> <Extn ExtnCallBack="" ExtnDept=""
     * ExtnClass="" ExtnSubClass="" /> <AdditionalAttributeList> <AdditionalAttribute DoubleValue=""
     * IntegerValue="" IsInherited="" Name="" Value=""/> </AdditionalAttributeList> </Item>
     * </OrderLine> </OrderLines> </Order>
     */

    /**
     * Constructor to initialize the document
     *
     * @param docItemListOut
     */
    public KohlsPoCValidateItemForReturn(Document docItemListOut) {
        this.docItemListOut = docItemListOut;
    }

    /**
     * Constructor to initialize the document
     */
    public KohlsPoCValidateItemForReturn() {
        this.docItemListOut = null;
    }


    /**
     * @param env
     * @param docInXML
     * @return
     * @throws Exception
     */
    public Document validateItemForReturn(YFSEnvironment env, Document docInXML) throws Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.validateItemForReturn");
        if (logger.isDebugEnabled()) {
            logger.debug(
                    "Input xml to KohlsPoCValidateItemForReturn is: " + XMLUtil.getXMLString(docInXML));
        }
        if (!"Order".equals(docInXML.getDocumentElement().getNodeName())) {
            throw new YFSException("Invalid XML. XML must have Order as root element");
        }
        eleOrder = docInXML.getDocumentElement();
        sOrderHeaderKey = eleOrder.getAttribute("OrderHeaderKey");
        sOrgCode = eleOrder.getAttribute("EnterpriseCode");
        sSellerOrgCode = eleOrder.getAttribute("SellerOrganizationCode");

        NodeList nlOrderLine = docInXML.getElementsByTagName("OrderLine");

        if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
            for (int i = 0; i < nlOrderLine.getLength(); i++) {
                Element eleOrderLine = (Element) nlOrderLine.item(i);
                String sBarcodeData = eleOrderLine.getAttribute(KohlsPOCConstant.A_BAR_CODE_DATA_LOWER);
                String sBarcodeType = eleOrderLine.getAttribute(KohlsPOCConstant.A_BARCODE_TYPE);
                String sItemID = eleOrderLine.getAttribute(KohlsPOCConstant.A_ITEM_ID);

                if (YFCCommon.isVoid(sBarcodeData)) {
                    throw new YFSException("No Item found for validation");
                }
                // call getItemList api to get the details of item
                Element eleItemDetails = getItemDetails(env, sBarcodeData, eleOrderLine, sBarcodeType, sItemID);
                NodeList nlItem = eleItemDetails.getElementsByTagName("Item");
                if (nlItem.getLength() > 0) {
                    // Setting the basic attributes to orderline:
                    addBasicItemInfo((Element) nlItem.item(0), eleOrderLine, env);
                    // Doing item validations
                    checkIfItemReturnable((Element) nlItem.item(0), eleOrderLine);
                    callBackItemValidation((Element) nlItem.item(0), eleOrderLine);
                    checkForSpecialItems(env, eleOrderLine);
                    // checkItemValidations(eleOrderLine);
                    checkForDeptRestrictedReturn(env, (Element) nlItem.item(0));
                    checkForExclusionItem(env, (Element) nlItem.item(0), eleOrderLine);
                    checkForRFIDItem(env, (Element) nlItem.item(0), eleOrderLine);
                    checkForWebExclusiveItem(env, (Element) nlItem.item(0), eleOrderLine);
                    //CPE-10396
                    checkForMOSSalvageItem(env, (Element) nlItem.item(0), eleOrderLine);
                    checkIfReturnPassLine(env, (Element) nlItem.item(0), eleOrderLine);
                } else {
                    Element eleErrorList = XMLUtil.getChildElement(eleOrderLine, "ErrorList", true);
                    Element eleError = XMLUtil.createChild(eleErrorList, "Error");
                    eleError.setAttribute("ErrorCode", ERROR_ITEM_NOT_FOUND);
                    eleError.setAttribute("ErrorDescription", "Item Not Found in OMS");
                    //Added for CAPE-2429 - start
                    Element eleItem = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_ITEM, true);
                    eleItem.setAttribute(KohlsPOCConstant.A_ITEM_DESC, "Not on File");
                    //Added for CAPE-2429 - end
                }
            }
        } else {
            throw new YFSException("No Item found for validation");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Output of validateItemForReturn is: " + XMLUtil.getXMLString(docInXML));
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.validateItemForReturn");
        return docInXML;
    }


    /**
     * Create By mrjoshi *
     *
     * @param env
     * @param item
     * @param eleOrderLine    This method sets the IsWebExclusiveItem attribute at orderline
     * @param sExtnPOCFeature
     */
    private void checkForWebExclusiveItem(YFSEnvironment env, Element item, Element eleOrderLine) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForWebExclusiveItem");
        Element eleItemExtn = XMLUtil.getChildElement(item, KohlsPOCConstant.E_EXTN);
        String sExtnWebExclusiveIndicator = "N", sExtnDCReturnCode = "", sExtnDCReturnCodeDesc = "";
        if (!YFCCommon.isVoid(eleItemExtn)) {
            sExtnWebExclusiveIndicator = eleItemExtn.getAttribute(KohlsPOCConstant.A_EXTN_WEBEX_INDICATOR);
            sExtnDCReturnCode = eleItemExtn.getAttribute(KohlsPOCConstant.A_EXTN_DC_RETURN_CODE);
        }
        String sRuleValue = "";
        if ((!YFCCommon.isVoid(sExtnWebExclusiveIndicator) && sExtnWebExclusiveIndicator.equalsIgnoreCase(KohlsPOCConstant.YES) && (!YFCCommon.isVoid(env.getTxnObject(KohlsPOCConstant.OPERATION)) &&
                env.getTxnObject(KohlsPOCConstant.OPERATION).toString().equalsIgnoreCase(
                        KohlsPOCConstant.DAMAGE_RETICKET)))) {
            try {
                sRuleValue = getConfiguredRules(env, KohlsPOCConstant.ENABLE_PMDM_RULE);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                logger.error("error while fetching the rules " + e.getMessage());
            }

            //Calling PMDM if Switch is Enabled - START
            if (!YFCCommon.isVoid(sRuleValue) && sRuleValue.equalsIgnoreCase(KohlsPOCConstant.YES)) {
                Document apiInDoc = SCXmlUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);
                Element apiInputEle = apiInDoc.getDocumentElement();
                apiInputEle.setAttribute(KohlsPOCConstant.A_ITEM_ID, (String) item.getAttribute(KohlsPOCConstant.A_ITEM_ID));
                try {
                    Document apiOutputDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.PMDM_SERVICE_CALL, apiInDoc);
                    if (!YFCCommon.isVoid(apiOutputDoc)) {
                        Element eleOutput = apiOutputDoc.getDocumentElement();
                        if (!YFCCommon.isVoid(eleOutput)) {
                            sExtnDCReturnCode = eleOutput.getAttribute("ReturnDispositionCode");
                            sExtnDCReturnCodeDesc = eleOutput.getAttribute("ReturnDispositionDescription");
                        }
                    }
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    logger.error("error while making PMDM call" + e.getMessage());
                }

            }
            //Calling PMDM if Switch is Enabled - END
            //CPE-10413, 10412 - START
            if (!YFCCommon.isVoid(sExtnWebExclusiveIndicator) && sExtnWebExclusiveIndicator.equalsIgnoreCase(KohlsPOCConstant.YES)) {
                if (!YFCCommon.isVoid(sExtnDCReturnCode)) {
                    eleOrderLine.setAttribute("IsWebExclusiveItem", sExtnWebExclusiveIndicator);
                } else {
                    eleOrderLine.setAttribute("IsWebExclusiveItem", KohlsPOCConstant.NO);
                }
            } else {
                eleOrderLine.setAttribute("IsWebExclusiveItem", KohlsPOCConstant.NO);
            }
            // CPE-10413, 10412 - END
            Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
            if (!YFCCommon.isVoid(eleOrderLineExtn)) {
                eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_WEBEX_INDICATOR, sExtnWebExclusiveIndicator);
                //setting EXTN attributes fetched from PMDM call.
                eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_DC_RETURN_CODE, sExtnDCReturnCode);
                eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_DC_RETURN_CODE_DESC, sExtnDCReturnCodeDesc);
            }
            Element eleOrderLineItem = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_ITEM);
            if (!YFCCommon.isVoid(eleOrderLineItem)) {
                Element eleOrderLineItemExtn = XMLUtil.getChildElement(eleOrderLineItem, KohlsPOCConstant.E_EXTN);
                eleOrderLineItemExtn.setAttribute(KohlsPOCConstant.A_EXTN_DC_RETURN_CODE, sExtnDCReturnCode);
                eleOrderLineItemExtn.setAttribute(KohlsPOCConstant.A_EXTN_DC_RETURN_CODE_DESC, sExtnDCReturnCodeDesc);
            }
        }

        logger.endTimer("KohlsPoCValidateItemForReturn.checkForWebExclusiveItem");
    }

    /**
     * @param env
     * @param item
     * @param eleOrderLine
     */
    private void checkIfReturnPassLine(YFSEnvironment env, Element item,
                                       Element eleOrderLine) {
        Element eleCustAttribs = XMLUtil.getChildElement(eleOrderLine, "CustomAttributes", true);
        String sPassNo = eleCustAttribs.getAttribute("Text3");
        if (!YFCCommon.isVoid(sPassNo) && (sPassNo.startsWith("RO") || sPassNo.startsWith("RI"))) {
            eleOrderLine.setAttribute("IsReturnPassLine", "Y");
        } else {
            eleOrderLine.setAttribute("IsReturnPassLine", "N");
        }
    }

    /**
     * Create By IBMAdmin *
     *
     * @param env
     * @param item
     * @param eleOrderLine This method sets the IsMOSSalvageItem attribute at orderline
     */
    private void checkForMOSSalvageItem(YFSEnvironment env, Element item, Element eleOrderLine) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForMOSSalvageItem");
        Element eleItemExtn, mosDataList, mosData;
        String MosStartDate;
        String sDMRule = "", sRuleValue = "";
        try {
            sDMRule = getConfiguredRules(env, KohlsPOCConstant.DM_RULE);
            sRuleValue = getConfiguredRules(env, KohlsPOCConstant.ENABLE_MOS_SALVAGE_CHECK);
        } catch (Exception e) {
            logger.error("Error while making DM and MOS Salvage Rule Check call" + e.getMessage());
        }
        //Calling MOS Salvage if Switch is Enabled - START
        if (!YFCCommon.isVoid(sDMRule) && sDMRule.equalsIgnoreCase(KohlsPOCConstant.YES)) {
            if (!YFCCommon.isVoid(sRuleValue) && sRuleValue.equalsIgnoreCase(KohlsPOCConstant.YES)) {
                eleItemExtn = XMLUtil.getChildElement(item, KohlsPOCConstant.E_EXTN);
                if (!YFCCommon.isVoid(eleItemExtn)) {
                    mosDataList = XMLUtil.getChildElement(eleItemExtn, KohlsPOCConstant.KOHLS_MOS_DATA_LIST);
                    if (!YFCCommon.isVoid(mosDataList)) {
                        mosData = XMLUtil.getChildElement(mosDataList, KohlsPOCConstant.KOHLS_MOS_DATA);
                        if (!YFCCommon.isVoid(mosData)) {
                            MosStartDate = mosData.getAttribute(KohlsPOCConstant.MOS_START_DATE);
                            try {
                                if (!YFCCommon.isVoid(MosStartDate)) {
                                    SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MOS_DATE_FORMAT);
                                    Date mosDate = sdf.parse(MosStartDate);
                                    Date currDate = new Date();
                                    if (currDate.compareTo(mosDate) >= 0) {
                                        eleOrderLine.setAttribute(KohlsPOCConstant.IS_MOS_SALVAGE_ITEM, KohlsPOCConstant.YES);
                                    } else {
                                        eleOrderLine.setAttribute(KohlsPOCConstant.IS_MOS_SALVAGE_ITEM, KohlsPOCConstant.NO);
                                    }
                                }
                            } catch (Exception e) {
                            }
                            ;
                        }
                    }
                }
            } else {
                eleOrderLine.setAttribute(KohlsPOCConstant.IS_MOS_SALVAGE_ITEM, KohlsPOCConstant.NO);
            }
        } else {
            eleOrderLine.setAttribute(KohlsPOCConstant.IS_MOS_SALVAGE_ITEM, KohlsPOCConstant.NO);
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.checkForMOSSalvageItem");
    }

    /**
     * Create By mrjoshi *
     *
     * @param sItemID
     * @return
     * @throws Exception
     */
    private Element getItemDetails(YFSEnvironment env, String sBarcodeData, Element elemOrdLine, String sBarcodeType, String sItemID)
            throws Exception {
        // call getItemList api and return
        logger.beginTimer("KohlsPoCValidateItemForReturn.getItemDetails");
        Document docGetItemListInput = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);
        Element eleItemInput = docGetItemListInput.getDocumentElement();

        if (!YFCCommon.isVoid(sBarcodeType)) {
            //If sku is entered on UI
            if ("SKU".equalsIgnoreCase(sBarcodeType)) {
                eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, sBarcodeData);
            } else if ("UPC".equalsIgnoreCase(sBarcodeType)) {
                //If UPC is entered on UI, and SKU is also available from translate Barcode happend from UI
                if (!YFCCommon.isVoid(sItemID)) {
                    eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, sItemID);
                } else {
                    //control should rarely come here, but just in case
                    Document docTranslateBarcodeInXML = XMLUtil.getDocument("<BarCode BarCodeData=\"" + sBarcodeData + "\" BarCodeType=\"POSBarcodeScan\" DisplayLocalizedFieldInLocale=\"en_US\">\n" +
                            "    <ContextualInfo EnterpriseCode=\"KOHLS-RETAIL\" OrganizationCode=\"KOHLS-RETAIL\"/>\n" +
                            "</BarCode>");
                    Document docTranslateBarcodeOutXML = invokeAPI(env, "translateBarCode", docTranslateBarcodeInXML);
                    if (!YFCCommon.isVoid(docTranslateBarcodeOutXML)) {
                        Element eleItemContextualInfo = (Element) docTranslateBarcodeOutXML.getElementsByTagName("ItemContextualInfo").item(0);
                        if (!YFCCommon.isVoid(eleItemContextualInfo)) {
                            String itemIDFromTranslateBarcode = eleItemContextualInfo.getAttribute(KohlsPOCConstant.A_ITEM_ID);
                            if (!YFCCommon.isVoid(itemIDFromTranslateBarcode)) {
                                eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, itemIDFromTranslateBarcode);
                            } else {
                                throw new YFSException("Invalid Barcode data entered", "INVALID_DATA_ENTERED",
                                        "Please enter correct item id or UPC code");
                            }
                        } else {
                            throw new YFSException("Invalid Barcode data entered", "INVALID_DATA_ENTERED",
                                    "Please enter correct item id or UPC code");
                        }
                    } else {
                        throw new YFSException("Invalid Barcode data entered", "INVALID_DATA_ENTERED",
                                "Please enter correct item id or UPC code");
                    }
                }
            }
        } else {
            if (sBarcodeData.length() == 7) {
                sBarcodeData = '0' + sBarcodeData;
            }
            if (sBarcodeData.length() == 14) {
                sBarcodeData = sBarcodeData.substring(1);
            }
            if (sBarcodeData.length() == 8) {
                eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, sBarcodeData);
            } else if (sBarcodeData.length() == 11 || sBarcodeData.length() == 12 || sBarcodeData.length() == 13) {
                /*
                 * if(sBarcodeData.startsWith("0")) { sBarcodeData = sBarcodeData.substring(1); }
                 */
                // Replace all leading zeros from UPCs only
                //as of 07/28, none of the UPCs in OMSRMASTER have leading zeros
                sBarcodeData = sBarcodeData.replaceFirst("^0*", "");

                Element eleItemAliasList =
                        docGetItemListInput.createElement(KohlsPOCConstant.A_ITEM_ALIAS_LIST);
                eleItemInput.appendChild(eleItemAliasList);
                Element eleItemAlias = docGetItemListInput.createElement(KohlsPOCConstant.A_ITEM_ALIAS);
                eleItemAliasList.appendChild(eleItemAlias);
                eleItemAlias.setAttribute(KohlsPOCConstant.A_ALIAS_VALUE, sBarcodeData);
                //Commenting the LIKE query
      /*  if (sBarcodeData.length() == 11) {
          eleItemAlias.setAttribute("AliasValueQryType", "LIKE");
        }*/
            } else {
                throw new YFSException("Invalid Barcode data entered", "INVALID_DATA_ENTERED",
                        "Please enter correct item id or UPC code");
            }
        }


        // CPE-4844 check if its for damage / reticket, if so use a different template
        String template = KohlsPOCConstant.GET_ITEM_LIST_FOR_ITEM_VALIDATION;
        if (!YFCCommon.isVoid(env.getTxnObject(KohlsPOCConstant.OPERATION)) &&
                env.getTxnObject(KohlsPOCConstant.OPERATION).toString().equalsIgnoreCase(
                        KohlsPOCConstant.DAMAGE_RETICKET)) {
            template = KohlsPOCConstant.GET_ITEM_LIST_FOR_ITEM_VALIDATION_DAMAGE_RETICKET;
        }

        Document docGetItemListOut =
                KOHLSBaseApi.invokeAPI(env, template,
                        KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);


        logger.endTimer("KohlsPoCValidateItemForReturn.getItemDetails");
        return docGetItemListOut.getDocumentElement();

    }

    /**
     * Create By mrjoshi *
     *
     * @param item
     * @param elemOrdLine
     * @throws Exception
     */
    private void addBasicItemInfo(Element eleItem, Element elemOrdLine, YFSEnvironment env) throws Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.addBasicItemInfo");

        Element eleClassificationCodes =
                (Element) eleItem.getElementsByTagName("ClassificationCodes").item(0);
        String sTaxProductCode = eleClassificationCodes.getAttribute("TaxProductCode");

        Element eleItemExtn = (Element) eleItem.getElementsByTagName("Extn").item(0);
        String sDept = eleItemExtn.getAttribute("ExtnDept");
        String sClass = eleItemExtn.getAttribute("ExtnClass");
        String sSubClass = eleItemExtn.getAttribute("ExtnSubClass");
        String sExtnEmpDiscCode = eleItemExtn.getAttribute("ExtnEmpDiscCode");
        String sExtnDCReturnCode = eleItemExtn.getAttribute("ExtnDCReturnCode");

        Element eleOrderLineItem = XMLUtil.getChildElement(elemOrdLine, "Item", true);
        if (!YFCCommon.isVoid(env.getTxnObject(KohlsPOCConstant.OPERATION)) &&
                KohlsPOCConstant.DAMAGE_RETICKET.equalsIgnoreCase(
                        (String) env.getTxnObject(KohlsPOCConstant.OPERATION))) {
            Element eleOrderLineItemExtn = XMLUtil.getChildElement(eleOrderLineItem, "Extn", true);
            eleOrderLineItemExtn.setAttribute("ExtnDept", sDept);
            eleOrderLineItemExtn.setAttribute("ExtnClass", sClass);
            eleOrderLineItemExtn.setAttribute("ExtnSubClass", sSubClass);
            eleOrderLineItemExtn.setAttribute("ExtnTaxProductCode", sTaxProductCode);
            eleOrderLineItemExtn.setAttribute("ExtnStyle", eleItemExtn.getAttribute("ExtnStyle"));
            //DM-490
            eleOrderLineItemExtn.setAttribute("ExtnIsHazmat", eleItemExtn.getAttribute("ExtnIsHazmat"));
            //DM-308 - START
            eleOrderLineItemExtn.setAttribute("ExtnDCReturnCodeDesc", eleItemExtn.getAttribute("ExtnDCReturnCodeDesc"));
            eleOrderLineItemExtn.setAttribute("ExtnDCReturnCode", eleItemExtn.getAttribute("ExtnDCReturnCode"));
            //DM-308 - END

            Element eleOrderLineItemDetails = SCXmlUtil.createChild(elemOrdLine, KohlsPOCConstant.E_ITEM_DETAILS);
            eleOrderLineItemDetails.setAttribute(KohlsPOCConstant.A_ITEM_ID, eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID));
            Element eleOrderLineItemDetailsPrimaryInfo = SCXmlUtil.createChild(eleOrderLineItemDetails, KohlsXMLLiterals.E_PRIMARY_INFORMATION);
            Element eleItemPrimaryInformation = SCXmlUtil.getChildElement(eleItem, KohlsXMLLiterals.E_PRIMARY_INFORMATION);
            eleOrderLineItemDetailsPrimaryInfo.setAttribute(KohlsXMLLiterals.A_SHORT_DESCRIPTION,
                    eleItemPrimaryInformation.getAttribute(KohlsXMLLiterals.A_SHORT_DESCRIPTION));
            Element additionalAttributesList = SCXmlUtil.getChildElement(eleItem, KohlsXMLLiterals.E_ADDITIONAL_ATTRIBUTE_LIST);
            if (!YFCCommon.isVoid(additionalAttributesList)) {
                Element eleOrderLineItemDetailsAttributeList = SCXmlUtil.createChild(
                        eleOrderLineItemDetails, KohlsXMLLiterals.E_ADDITIONAL_ATTRIBUTE_LIST);
                ArrayList<Element> additionalAttributes = SCXmlUtil.getChildren(additionalAttributesList, KohlsXMLLiterals.E_ADDITIONAL_ATTRIBUTE);
                for (Element currentAdditionalAttribute : additionalAttributes) {
                    if (KohlsPOCConstant.POC_MERCHANDISE_DESCRIPTION.equalsIgnoreCase(
                            currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_NAME))) {
                        Element additionalAttribute = SCXmlUtil.createChild(
                                eleOrderLineItemDetailsAttributeList, KohlsXMLLiterals.E_ADDITIONAL_ATTRIBUTE);
                        additionalAttribute.setAttribute(KohlsXMLLiterals.A_ADDITIONAL_ATTRIBUTE_KEY,
                                currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_ADDITIONAL_ATTRIBUTE_KEY));
                        additionalAttribute.setAttribute(KohlsXMLLiterals.A_ATTRIBUTE_DOMAIN_ID,
                                currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_ATTRIBUTE_DOMAIN_ID));
                        additionalAttribute.setAttribute(KohlsXMLLiterals.A_ATTRIBUTE_GROUP_ID,
                                currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_ATTRIBUTE_GROUP_ID));
                        additionalAttribute.setAttribute(KohlsXMLLiterals.A_IS_INHERITED,
                                currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_IS_INHERITED));
                        additionalAttribute.setAttribute(KohlsXMLLiterals.A_NAME,
                                currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_NAME));
                        additionalAttribute.setAttribute(KohlsXMLLiterals.A_VALUE,
                                currentAdditionalAttribute.getAttribute(KohlsXMLLiterals.A_VALUE));
                    }
                }
            }

        }
        /*
         * Element eleOrderLineItemExtn = XMLUtil.getChildElement(eleOrderLineItem, "Extn", true);
         * eleOrderLineItemExtn.setAttribute("ExtnItemDept", sDept);
         * eleOrderLineItemExtn.setAttribute("ExtnItemClass", sClass);
         * eleOrderLineItemExtn.setAttribute("ExtnItemSubClass", sSubClass);
         * eleOrderLineItemExtn.setAttribute("ExtnTaxProductCode", sTaxProductCode);
         */

        Element eleOrderLineExtn = XMLUtil.getChildElement(elemOrdLine, "Extn", true);
        eleOrderLineExtn.setAttribute("ExtnItemDept", sDept);
        eleOrderLineExtn.setAttribute("ExtnItemClass", sClass);
        eleOrderLineExtn.setAttribute("ExtnItemSubClass", sSubClass);
        eleOrderLineExtn.setAttribute("ExtnTaxProductCode", sTaxProductCode);
        eleOrderLineExtn.setAttribute("ExtnDCReturnCode", sExtnDCReturnCode);

        Element eleReferences = XMLUtil.getChildElement(elemOrdLine, "References", true);
        Element eleReference = XMLUtil.createChild(eleReferences, "Reference");
        // eleReference.setAttribute("ExtnEmpDiscCode", sExtnEmpDiscCode);
        eleReference.setAttribute("Name", "ExtnEmpDiscCode");
        eleReference.setAttribute("Value", sExtnEmpDiscCode);

        Element eleAddAttribute = (Element) XPathUtil
                .getNodeList(eleItem,
                        "/Item/AdditionalAttributeList/AdditionalAttribute[@Name='POCMerchandiseDescription']")
                .item(0);
        if (!YFCCommon.isVoid(eleAddAttribute)) {
            elemOrdLine.setAttribute("Description", eleAddAttribute.getAttribute("Value"));
        }
        String strBarCode = elemOrdLine.getAttribute("BarcodeData");
        String strBarCodeType = elemOrdLine.getAttribute("BarcodeType");
        String sUPCCode = "";
        NodeList nlItemAlias = eleItem.getElementsByTagName(KohlsPOCConstant.E_ITEM_ALIAS);
        if (!YFCCommon.isVoid(nlItemAlias) && nlItemAlias.getLength() > 0) {
            for (int i = 0; i < nlItemAlias.getLength(); i++) {
                Element eleItemAlias = (Element) nlItemAlias.item(i);
                String sName = eleItemAlias.getAttribute(KohlsPOCConstant.A_ALIAS_NAME);
                if (sName.toLowerCase().contains("upc")) {
                    if (!YFCCommon.isVoid(eleItemAlias)) {
                        sUPCCode = eleItemAlias.getAttribute(KohlsPOCConstant.A_ALIAS_VALUE);
                        if (strBarCode.contains(sUPCCode)) {
                            break;
                        }
                    }
                }
            }
        }

        String sItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
        eleOrderLineItem.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, "EACH");

        if ("UPC".equalsIgnoreCase(strBarCodeType)) {
            eleOrderLineItem.setAttribute(KohlsPOCConstant.A_ITEM_ID, sItemID);
            eleOrderLineItem.setAttribute(KohlsPOCConstant.A_UPC_CODE, strBarCode);
        } else {
            if (strBarCode.length() == 7) {
                strBarCode = "0" + strBarCode;
            } else if (strBarCode.length() == 11) {
                strBarCode = sUPCCode;
            }
            if (strBarCode.length() == 8 || strBarCode.length() == 7) {
                eleOrderLineItem.setAttribute(KohlsPOCConstant.A_ITEM_ID, strBarCode);
                eleOrderLineItem.setAttribute(KohlsPOCConstant.A_UPC_CODE, sUPCCode);
            } else {
                eleOrderLineItem.setAttribute(KohlsPOCConstant.A_ITEM_ID, sItemID);

                eleOrderLineItem.setAttribute(KohlsPOCConstant.A_UPC_CODE, strBarCode);
            }
        }


        logger.endTimer("KohlsPoCValidateItemForReturn.addBasicItemInfo");
    }

    /**
     * Create By Sudina *
     *
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */
    private void checkIfItemReturnable(Element eleItem, Element elemOrdLine) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.CheckIfItemReturnable");

        Element elePrimaryInfo = (Element) eleItem.getElementsByTagName("PrimaryInformation").item(0);
        String strIsReturnable = elePrimaryInfo.getAttribute("IsReturnable");
        if (!YFCCommon.isVoid(strIsReturnable)
                && KohlsPOCConstant.YES.equalsIgnoreCase(strIsReturnable)) {
            elemOrdLine.setAttribute("IsReturnable", KohlsPOCConstant.YES);
        } else {
            elemOrdLine.setAttribute("IsReturnable", KohlsPOCConstant.NO);
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.CheckIfItemReturnable");
    }

    /**
     * Create By Sudina *
     *
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */
    private void callBackItemValidation(Element eleItem, Element elemOrdLine) throws ParseException {
        logger.beginTimer("KohlsPoCValidateItemForReturn.callBackItemValidation");
        String sCallbackInd = KohlsPOCConstant.NO;
        Element eleItemExtn = (Element) eleItem.getElementsByTagName("Extn").item(0);
        String strCallBackTypeCode = eleItemExtn.getAttribute("ExtnCallbackTypeCode");
        String strCallbackStartDate = eleItemExtn.getAttribute("ExtnCallbackStartDate");
        String strCallbackEndDate = eleItemExtn.getAttribute("ExtnCallbackEndDate");
        String strMerchandiseTaxCode = eleItemExtn.getAttribute("ExtnMerchandiseTaxCode");
        String strCallback = eleItemExtn.getAttribute("ExtnCallback");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String strCurrentDate = sdf.format(new Date());

        if (!YFCCommon.isVoid(strCallBackTypeCode) && !YFCCommon.isVoid(strCallbackStartDate)
                && !YFCCommon.isVoid(strCallbackEndDate)) {
            if (((sdf.parse(strCurrentDate)).compareTo(sdf.parse(strCallbackStartDate))) > 0
                    && ((sdf.parse(strCallbackEndDate)).compareTo(sdf.parse(strCurrentDate)) > 0)) {

                elemOrdLine.setAttribute("IsCallbackItem", KohlsPOCConstant.YES);
                Element eleOrderItem = XMLUtil.getChildElement(elemOrdLine, "Item", true);
                Element eleExtn = XMLUtil.getChildElement(eleOrderItem, "Extn", true);
                eleExtn.setAttribute("ExtnCallbackTypeCode", strCallBackTypeCode);
                eleExtn.setAttribute("ExtnCallbackStartDate", strCallbackStartDate);
                eleExtn.setAttribute("ExtnCallbackEndDate", strCallbackEndDate);
                eleExtn.setAttribute("ExtnMerchandiseTaxCode", strMerchandiseTaxCode);
                eleExtn.setAttribute("ExtnCallback", strCallback);
                sCallbackInd = KohlsPOCConstant.YES;
            }
        }
        elemOrdLine.setAttribute("IsCallbackItem", sCallbackInd);
        logger.endTimer("KohlsPoCValidateItemForReturn.callBackItemValidation");
    }

    /**
     * Create By Sudina *
     *
     * @param env
     * @param docInput
     * @param eleOrLn
     * @throws Exception
     */
    private void checkForSpecialItems(YFSEnvironment env, Element eleOrLn) throws Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForSpecialItems");

        // String strGiftFlag = eleOrLn.getAttribute("GiftFlagInd");
        String strItemID = eleOrLn.getAttribute("BarcodeData");

        if (specialSkuMap.isEmpty()) {
            try {
                buildSpecialSkuMap(env);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (specialSkuMap.containsKey(strItemID)) {
            eleOrLn.setAttribute("PricePrompt", KohlsPOCConstant.YES);
            eleOrLn.setAttribute("SpecialSkuType", specialSkuMap.get(strItemID));
        } else {
            eleOrLn.setAttribute("PricePrompt", KohlsPOCConstant.NO);
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.checkForSpecialItems");
    }

    /**
     * Create By Sudina *
     *
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */
    private String getConfiguredRules(YFSEnvironment env, String ruleID) throws Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.getConfiguredRules");
        String strRuleValue = "";
        Document docGetRuleListInput = XMLUtil.createDocument("Rules");
        Element eleRuleInput = docGetRuleListInput.getDocumentElement();
        eleRuleInput.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, sOrgCode);
        eleRuleInput.setAttribute(KohlsPOCConstant.A_RULE_ID, ruleID);
        if (!YFCCommon.isVoid(ruleID) && (ruleID.equalsIgnoreCase(KohlsPOCConstant.DM_RULE)
                || ruleID.equalsIgnoreCase(KohlsPOCConstant.ENABLE_MOS_SALVAGE_CHECK) || ruleID.equalsIgnoreCase(KohlsPOCConstant.ENABLE_PMDM_RULE))) {
            eleRuleInput.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, sSellerOrgCode);
        }
        Document docGetRuleListOut = KOHLSBaseApi.invokeAPI(env,
                KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docGetRuleListInput);
        if (docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).getLength() > 0) {
            Element eleRule =
                    (Element) docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).item(0);
            strRuleValue = eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.getConfiguredRules");
        return strRuleValue;
    }

    /**
     * Create By Sudina *
     *
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */
    private boolean checkForRule(String strToComapre, String strCompareWith, String strDelimiter) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForRule");
        boolean ruleFlag = false;
        /*
         * StringTokenizer st = new StringTokenizer(strInput, strDelimiter); ArrayList<String>
         * listRuleValues = new ArrayList<String>();
         *
         * while (st.hasMoreTokens()) { listRuleValues.add(st.nextToken()); }
         */
        if (!YFCCommon.isVoid(strCompareWith)) {
            String[] listRuleValues = strCompareWith.split(strDelimiter);
            Set<String> mySet = new HashSet<String>(Arrays.asList(listRuleValues));
            if (mySet.contains(strToComapre)) {
                ruleFlag = true;
            }
            /*
             * if (listRuleValues.length > 0) { for (int i = 0; i < listRuleValues.length; i++) { if
             * (listRuleValues[i].equalsIgnoreCase(strToComapre)) { ruleFlag = true; break; } } }
             */
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.checkForRule");
        return ruleFlag;
    }

    /**
     * Create By Sudina *
     *
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */
    private void checkItemValidations(Element eleOrderLine) {
        boolean isGiftItem = false;
        NodeList nlOrderLine = eleOrder.getElementsByTagName("OrderLine");

        if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
            for (int i = 0; i < nlOrderLine.getLength(); i++) {
                if (!isGiftItem) {
                    Element eleOrdLine = (Element) nlOrderLine.item(i);
                    String strGiftFlag = eleOrdLine.getAttribute("GiftFlag");

                    if (!YFCCommon.isVoid(strGiftFlag)
                            && KohlsPOCConstant.YES.equalsIgnoreCase(strGiftFlag)) {
                        isGiftItem = true;
                    }
                } else if (isGiftItem && i < nlOrderLine.getLength()) {
                    // What flag has to be set here?

                }
            }

        }

    }

    /**
     * Create By Sudina *
     *
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */

    private void checkForDeptRestrictedReturn(YFSEnvironment env, Element eleItem) throws Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForDeptRestrictedReturn");

        Element eleItemExtn = (Element) eleItem.getElementsByTagName("Extn").item(0);
        String strDept = eleItemExtn.getAttribute("ExtnDept");
        if (!YFCCommon.isVoid(strDept)) {

            Document docComCdLstInput = XMLUtil.createDocument(KohlsPOCConstant.ELEM_COMMON_CODE);
            Element eleCommonCode = docComCdLstInput.getDocumentElement();
            eleCommonCode.setAttribute(KohlsPOCConstant.ATTR_CODE_TYPE, "DEPT_RESTRCT_RTN_DAY");
            eleCommonCode.setAttribute("OrganizationCode", sOrgCode);
            eleCommonCode.setAttribute("CodeValue", strDept);
            Document docComCdLstOutput =
                    invokeAPI(env, KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docComCdLstInput);
            if (!YFCCommon.isVoid(docComCdLstOutput)) {
                Element eleCommonCodeOutput =
                        (Element) docComCdLstOutput.getElementsByTagName("OrderLine").item(0);
                if (!YFCCommon.isVoid(eleCommonCodeOutput)) {
                    String strDesc = eleCommonCodeOutput.getAttribute("CodeShortDescription");
                    if (strDesc.equalsIgnoreCase(KohlsPOCConstant.YES)) {
                        // Item cannot be returned... which flag to be set?
                    }
                }
            }

        }
        logger.endTimer("KohlsPoCValidateItemForReturn. ");
    }

    /**
     * Create By mrjoshi *
     *
     * @param env
     * @param eleItem
     * @param eleOrderLine input xml for getPOSExclusionDefinition api
     *
     *                     <ExclusionDefn ExclusionActive="Y" > <ComplexQuery Operator="And"> <Or> <And> <Exp Name=
     *                     "ExclusionDept" ExclusionDeptQryType="EQ" Value="444"/> </And>
     *                     <And> <Exp Name="ExclusionDept" ExclusionDeptQryType="EQ" Value="217"/> <Exp Name=
     *                     "ExclusionClass" ExclusionClassQryType="EQ" Value="30"/> </And>
     *                     <And> <Exp Name="ExclusionDept" ExclusionDeptQryType="EQ" Value="444"/> <Exp Name=
     *                     "ExclusionClass" ExclusionClassQryType="EQ" Value="90"/> <Exp Name="ExclusionSubClass"
     *                     ExclusionSubClassQryType="EQ" Value="97"/> </And> </Or> </ComplexQuery> </ExclusionDefn>
     */
    private void checkForExclusionItem(YFSEnvironment env, Element eleItem, Element eleOrderLine) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForExclusionItem");
        boolean bIsExcl = false;
        // Logic for checking if item returned is exclusion or not
        /*
         * boolean hasExclusionsBeenModified = false; Date activeDate = null; try {
         * hasExclusionsBeenModified = KohlsPoCCommonAPIUtil.hasExclusionsBeenModified(env); } catch
         * (Exception e1) { e1.printStackTrace(); } if (KohlsPoCCommonAPIUtil.exclusionsMap.isEmpty() ||
         * hasExclusionsBeenModified) { try { KohlsPoCCommonAPIUtil.buildExclusionsMap(env); } catch
         * (Exception e) { e.printStackTrace(); } }
         */

        Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_EXTN, true);
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM, KohlsPOCConstant.NO);
        Element eleItemExtn = XMLUtil.getChildElement(eleItem, KohlsXMLLiterals.E_EXTN);
        String extnClass = eleItemExtn.getAttribute("ExtnClass");
        String extnSubClass = eleItemExtn.getAttribute("ExtnSubClass");
        String extnDept = eleItemExtn.getAttribute("ExtnDept");
        try {
            Document docExclusionRulesIn = XMLUtil.createDocument(KohlsPOCConstant.E_EXCLUSION_DEFN);
            Element eleExclusionRulesIn = docExclusionRulesIn.getDocumentElement();
            XMLUtil.setAttribute(eleExclusionRulesIn, KohlsPOCConstant.E_EXCLUSION_ACTIVE,
                    KohlsPOCConstant.YES);
            Element eleComplexQuery = docExclusionRulesIn.createElement("ComplexQuery");

            eleExclusionRulesIn.appendChild(eleComplexQuery);
            eleComplexQuery.setAttribute("Operator", "And");

            Element eleOr1 = docExclusionRulesIn.createElement("Or");
            eleComplexQuery.appendChild(eleOr1);

            Element eleAnd1 = docExclusionRulesIn.createElement("And");
            eleOr1.appendChild(eleAnd1);
            Element eleExp1 = docExclusionRulesIn.createElement("Exp");
            eleAnd1.appendChild(eleExp1);
            eleExp1.setAttribute("Name", "ExclusionDept");
            eleExp1.setAttribute("ExclusionDeptQryType", "EQ");
            eleExp1.setAttribute("Value", extnDept);

            Element eleAnd2 = (Element) docExclusionRulesIn.importNode(eleAnd1, true);
            eleOr1.appendChild(eleAnd2);
            Element eleExp2_2 = docExclusionRulesIn.createElement("Exp");
            eleAnd2.appendChild(eleExp2_2);
            eleExp2_2.setAttribute("Name", "ExclusionClass");
            eleExp2_2.setAttribute("ExclusionClassQryType", "EQ");
            eleExp2_2.setAttribute("Value", extnClass);

            Element eleAnd3 = (Element) docExclusionRulesIn.importNode(eleAnd2, true);
            eleOr1.appendChild(eleAnd3);
            Element eleExp3_3 = docExclusionRulesIn.createElement("Exp");
            eleAnd3.appendChild(eleExp3_3);
            eleExp3_3.setAttribute("Name", "ExclusionSubClass");
            eleExp3_3.setAttribute("ExclusionSubClassQryType", "EQ");
            eleExp3_3.setAttribute("Value", extnSubClass);

            Document docExclusionTemplate = XMLUtil.getDocument(
                    "<ExclusionDefns><ExclusionDefn ExclusionActive='' ExclusionActiveDate='' ExclusionClass='' ExclusionDept='' ExclusionSubClass='' /></ExclusionDefns>");
            Document docGetExclusionRulesOut = KOHLSBaseApi.invokeAPI(env, docExclusionTemplate,
                    "getPOSExclusionDefinition", docExclusionRulesIn);

            if (!YFCCommon.isVoid(docGetExclusionRulesOut)) {
                NodeList nlExclusionDefn =
                        docGetExclusionRulesOut.getElementsByTagName(KohlsPOCConstant.E_EXCLUSION_DEFN);
                if (!YFCCommon.isVoid(nlExclusionDefn) && nlExclusionDefn.getLength() > 0) {
          /*eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM,
              KohlsPOCConstant.YES); */

                    bIsExcl = this.determineExclusionAttribute(extnDept, extnClass, extnSubClass, docGetExclusionRulesOut);
                    if (bIsExcl) {
                        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM,
                                KohlsPOCConstant.YES);
                    }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.checkForExclusionItem");
    }


    private boolean determineExclusionAttribute(String extnDept, String extnClass, String extnSubClass, Document docGetExclusionRulesOut) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
        NodeList nlAppliedFilter = null;
        Element eleAppliedFilter = null;
        String sExclusionClass = null;
        String sExclusionSubClass = null;
        String sIsActiveForAppliedFilter = null;

        try {
            nlAppliedFilter = KohlsXPathUtil.getNodeList(docGetExclusionRulesOut,
                    "/ExclusionDefns/ExclusionDefn[(@ExclusionDept='" + extnDept + "')]");

            if (!YFCCommon.isVoid(nlAppliedFilter)) {

                int nlAppliedFilterLen = nlAppliedFilter.getLength();
                for (int i = 0; i < nlAppliedFilterLen; i++) {
                    eleAppliedFilter = (Element) nlAppliedFilter.item(i);
                    sExclusionClass = eleAppliedFilter.getAttribute("ExclusionClass");
                    sExclusionSubClass = eleAppliedFilter.getAttribute("ExclusionSubClass");
                    if (YFCCommon.isVoid(sExclusionClass) && YFCCommon.isVoid(sExclusionSubClass)) {
                        logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
                        return true;

                    }
                }
            } else {
                logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
                return false;
            }

            nlAppliedFilter = KohlsXPathUtil.getNodeList(docGetExclusionRulesOut,
                    "/ExclusionDefns/ExclusionDefn[(@ExclusionDept='" + extnDept + "') and (@ExclusionClass='" + extnClass + "')]");

            if (!YFCCommon.isVoid(eleAppliedFilter)) {
                int nlAppliedFilterLen = nlAppliedFilter.getLength();
                for (int i = 0; i < nlAppliedFilterLen; i++) {
                    eleAppliedFilter = (Element) nlAppliedFilter.item(i);
                    sExclusionSubClass = eleAppliedFilter.getAttribute("ExclusionSubClass");
                    if (YFCCommon.isVoid(sExclusionSubClass)) {
                        logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
                        return true;
                    }
                }
            } else {
                logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
                return false;
            }

            sIsActiveForAppliedFilter = KohlsXPathUtil.getString(docGetExclusionRulesOut,
                    "/ExclusionDefns/ExclusionDefn[(@ExclusionDept='" + extnDept + "') and (@ExclusionClass='" + extnClass + "') and (@ExclusionSubClass='" + extnSubClass + "')]/@ExclusionActive");

            if (!YFCCommon.isVoid(sIsActiveForAppliedFilter)) {
                logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
                return true;
            }

        } catch (Exception e) {

            e.printStackTrace();
            logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
            return false;
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.determineExclusionAttribute");
        return false;
    }

    private void checkForRFIDItem(YFSEnvironment env, Element eleItem, Element eleOrderLine)
            throws Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.checkForRFIDItem");
        boolean isW2W = false;
        boolean isICC = false;
        String strDept = null;
        String sW2WStoreList = null;
        String sICCStoreList = null;
        String sW2WDeptList = null;
        String sICCDeptList = null;
        String strStoreNo = sSellerOrgCode;
        eleOrderLine.setAttribute("IsRFIDItem", "N");
        eleOrderLine.setAttribute("RFIDType", "");
        Element eleExtn = (Element) eleItem.getElementsByTagName("Extn").item(0);
        if (!YFCCommon.isVoid(eleExtn)) {
            strDept = eleExtn.getAttribute("ExtnDept");
        }
        if (!YFCCommon.isVoid(strStoreNo)) {
            sW2WStoreList = getConfiguredRules(env, "W2W_STORE_LIST");
            isW2W = checkForRule(strStoreNo, sW2WStoreList, ",");

            if (isW2W && !YFCCommon.isVoid(strDept)) {
                sW2WDeptList = getConfiguredRules(env, "W2W_DEPARTMENT_LIST");
                isW2W = checkForRule(strDept, sW2WDeptList, ",");
                if (isW2W) {
                    eleOrderLine.setAttribute("IsRFIDItem", "Y");
                    eleOrderLine.setAttribute("RFIDType", "W2W");
                }
            }
            sICCStoreList = getConfiguredRules(env, "ICC_STORE_LIST");
            isICC = checkForRule(strStoreNo, sICCStoreList, ",");
            if (isICC && !YFCCommon.isVoid(strDept)) {
                sICCDeptList = getConfiguredRules(env, "ICC_DEPARTMENT_LIST");
                isICC = checkForRule(strDept, sICCDeptList, ",");
                if (isICC) {
                    eleOrderLine.setAttribute("IsRFIDItem", "Y");
                    eleOrderLine.setAttribute("RFIDType", "ICC");
                }
            }
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.checkForRFIDItem");
    }

    public static void buildSpecialSkuMap(YFSEnvironment yfsEnv) throws ParseException, Exception {
        logger.beginTimer("KohlsPoCValidateItemForReturn.buildSpecialSkuMap");

        if (!specialSkuMap.isEmpty()) {
            specialSkuMap.clear();
        }
        Document docRuleList = getSpecialSkuList(yfsEnv);
        Element eleRuleList = docRuleList.getDocumentElement();
        NodeList nlRule = eleRuleList.getElementsByTagName("Rule");

        if (!YFCCommon.isVoid(nlRule) && nlRule.getLength() > 0) {
            for (int i = 0; i < nlRule.getLength(); i++) {
                Element eleRule = (Element) nlRule.item(i);

                StringTokenizer st = new StringTokenizer(eleRule.getAttribute("RuleValue"), ",");

                while (st.hasMoreTokens()) {
                    specialSkuMap.put(st.nextToken(), eleRule.getAttribute("RuleID"));
                }
            }
        }
        logger.endTimer("KohlsPoCValidateItemForReturn.buildSpecialSkuMap");
    }

    public static Document getSpecialSkuList(YFSEnvironment yfsEnv) throws Exception, ParseException {
        logger.beginTimer("KohlsPoCValidateItemForReturn.getSpecialSkuList");
        Document docRulesList = XMLUtil.createDocument("Rules");
        Element eleRules = docRulesList.getDocumentElement();
        Element eleMetaData = XMLUtil.createChild(eleRules, "RuleMetadata");
        eleMetaData.setAttribute("GroupName", "POC_RETURNS");
        Element eleComplexQry = XMLUtil.createChild(eleMetaData, "ComplexQuery");
        eleComplexQry.setAttribute("Operator", "OR");
        setRuleDetails(eleComplexQry, "SCANNING_PENALTY_ITEMS");
        setRuleDetails(eleComplexQry, "TAX_MANIFESTO_ITEMS");
        setRuleDetails(eleComplexQry, "SHIPPING_CHARGE_ITEMS");
        Document docSpecialSkuList =
                KOHLSBaseApi.invokeAPI(yfsEnv, KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docRulesList);
        logger.endTimer("KohlsPoCValidateItemForReturn.getSpecialSkuList");
        return docSpecialSkuList;
    }

    public static void setRuleDetails(Element eleCQry, String strRuleId) {
        logger.beginTimer("KohlsPoCValidateItemForReturn.setRuleDetails");
        Element eleExp = XMLUtil.createChild(eleCQry, "Exp");
        eleExp.setAttribute("Name", "RuleID");
        eleExp.setAttribute("QryType", "EQ");
        eleExp.setAttribute("Value", strRuleId);
        logger.endTimer("KohlsPoCValidateItemForReturn.setRuleDetails");
    }

}
