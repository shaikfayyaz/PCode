package com.kohls.poc.returns.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;



import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;


/**
 * This Class returns a true if RS system is active and false if 
 * it is inactive. This is determined by calling the 
 * getCommonCodeList with CodeType  as "IS_RS_ACTIVE" 
 * 
 * @param env
 * @param inputDoc
 * @return 
 * @exception Exception
 * 
 */
public class KohlsPoCCheckForRSSytem extends KOHLSBaseApi {
  private static final YFCLogCategory logger = YFCLogCategory
      .instance(KohlsPoCCheckForRSSytem.class.getName());

  /**
   * @param env
   * @param inDoc
   * @return
   * @throws Exception
   */
  public Document checkForReturnServices(YFSEnvironment env,
      Document inDoc) throws Exception {

    logger.beginTimer("KohlsPoCCheckForRSSytem.checkForReturnServices");
    Document docComCdLstOutput = null;

    try {
      //Create Input XML for getCommonCodeList API
      Document docComCdLstInput = YFCDocument.createDocument(KohlsConstant.E_COMMON_CODE).getDocument();
      Element eleComCode = docComCdLstInput.getDocumentElement();
      eleComCode.setAttribute(KohlsPOCConstant.ATTR_CODE_TYPE, KohlsPOCConstant.IS_RS_ACTIVE);

      //Calling getCommonCodeList API 
      docComCdLstOutput = invokeAPI(env, KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docComCdLstInput);


      Element eleOrder = inDoc.getDocumentElement();

      if(!YFCCommon.isVoid(docComCdLstOutput))
      {
        Element eleCommonCode=(Element)(XPathUtil.getNodeList(docComCdLstOutput.getDocumentElement(), "/CommonCodeList/CommonCode").item(0));
        if(logger.isDebugEnabled()){
          logger.debug("KohlsPoCCheckForRSSytem.checkForReturnServices: Get Common Code List output"+XMLUtil.getXMLString(docComCdLstOutput));
        }
        if(!YFCCommon.isVoid(eleCommonCode))
        {
          XMLUtil.setAttribute(eleOrder, KohlsPOCConstant.EXTN_IS_RS_ACTIVE,eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_VALUE));
        }
        else{
          XMLUtil.setAttribute(eleOrder, KohlsPOCConstant.EXTN_IS_RS_ACTIVE,"Y");
        }		
      }
      else
        XMLUtil.setAttribute(eleOrder, KohlsPOCConstant.EXTN_IS_RS_ACTIVE,"Y");

    }
    catch (Exception e){

      logger.error(e);
      e.printStackTrace();
      throw e;
    }
    return inDoc;
  }

}
