package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.psa.api.KohlsKCSCallForPSA;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author tkmaath
 *
 */
/**
 * @author mrjoshi
 *
 */
public class KohlsReturnsLCSDeactivation {
    private static YFCLogCategory logger;
    
    String sExtnPOCFeature = "";
    String sOrderHeaderKey = "";
    String sMorePromotionsToProcess = "N";
    String sErrorMessage = "Errors in LCS Response";
    HashMap mapPromotionGravity = new HashMap();
    HashMap mapPromotionOrder = new HashMap();
    String sTVSErrorMessage = "Errors in TVS Response";
    Document LCSResponseDoc = null;
    String sUnprocessedExtnCouponSourceCode = ""; // need to check
    String strEligibleAmt = "";
    String strAmtToBeUnearned = "";
    public double dRefundAmount_Temp = 0.00;
    public double dRefundAmount = 0.00;
    List lEcommStores =null;
    String sEligibleLine = "";
    String callingSource = "";
    public HashMap<String, Double> mapLinePrice = new HashMap<String, Double>();
    public HashMap<String, Double> mapOrigtaxRate = new HashMap<String, Double>();

    private Properties props;

    static {
        logger = YFCLogCategory.instance(KohlsReturnsLCSDeactivation.class.getName());

    }

    KohlsKCSCallForPSA LCSobj = new KohlsKCSCallForPSA();
    KohlsTVSCallForReturnKCEligibleItems firstTVSObj = new KohlsTVSCallForReturnKCEligibleItems();

    /**
     * 
     * @param env
     * @param orderInDoc
     * @return
     * @throws Exception
     */
    
    public Document getOrderListDetails(YFSEnvironment env, Document orderInDoc) throws ParserConfigurationException{
        logger.beginTimer("KohlsReturnsLCSDeactivation.getOrderListDetails");

        DecimalFormat df = new DecimalFormat("0.00");
        //logger.debug("Input to method getOrderListDetails ::" + XMLUtil.getXMLString(orderInDoc));

        Document docGetOrderListOuput = null;
    
        Element eleInOrder = orderInDoc.getDocumentElement();
        
        Element eleOrderExtn = XMLUtil.getChildElement(eleInOrder, KohlsPOCConstant.E_EXTN);
        if (!YFCCommon.isVoid(eleOrderExtn)) {
            sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
        }

        sOrderHeaderKey = eleInOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        // Forming the input document for getOrderList API Call.
        Document docGetOrderListInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
        Element eleOrderInput = docGetOrderListInput.getDocumentElement();
        if (!YFCCommon.isVoid(sOrderHeaderKey)) {
            eleOrderInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);

            try {

                String sTemplateName = "/global/template/api/POC/kohlscashunearning/POC_getOrderList.xml";
                env.setApiTemplate(KohlsPOCConstant.GET_ORDER_LIST, sTemplateName);

                // PA changes for ISS - start
                if (ServerTypeHelper.amIOnEdgeServer()) {
                    if (!YFCCommon.isVoid(sExtnPOCFeature)
                            && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                        Element eleAdditionalInfo = SCXmlUtil.createChild(
                                docGetOrderListInput.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
                        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
                                KohlsXMLLiterals.V_MOTHERSHIP);
                    } else {
                      // Check if endpoint is present in env then use it.
                      if(!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
                        String sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
                        Element eleAdditionalInfo = SCXmlUtil.createChild(
                            docGetOrderListInput.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
                        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
                      }
                    }
                }
                // PA changes for ISS - end
                if (logger.isDebugEnabled()) {
                    logger.debug(
                            "Inside KohlsReturnsLCSDeactivation.getOrderListDetails getOrderList api input is: "
                                    + XMLUtil.getXMLString(docGetOrderListInput));
                }
                docGetOrderListOuput =
                        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_LIST, docGetOrderListInput);
                env.clearApiTemplate(KohlsPOCConstant.GET_ORDER_LIST);
                if (logger.isDebugEnabled()) {
                    logger.debug(
                            "Inside KohlsReturnsLCSDeactivation.getOrderListDetails getOrderList api output is: "
                                    + XMLUtil.getXMLString(docGetOrderListOuput));
                }
            } catch (Exception e1) {

                logger.error("Exception when calling getOrderList service" + e1.getMessage());
            } finally {
              logger.endTimer("KohlsReturnsLCSDeactivation.getOrderListDetails");
            }
        }
        
        return docGetOrderListOuput;
    }
    /**
     * 
     * @param env
     * @param orderInDoc
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public Document deactivateKohlsCash(YFSEnvironment env, Document orderInDoc, Date currentBusinessDate , String source) throws Exception {
        logger.beginTimer("KohlsReturnsLCSDeactivation.deactivateKohlsCash");
        if(logger.isDebugEnabled()) {
          logger.debug("Input to deactivateKohlsCash is: "+XMLUtil.getXMLString(orderInDoc));
        }
        Element eleInOrder = orderInDoc.getDocumentElement();
        Element orderDtlsEle = null;
        // Getting RefundAmount if its blank in input
        String sExtnSourceCode ="";
        Element elePromotionMaxRefund =null;
        Element elePromotion = null;
        Element eleRfundDeduction = null;
        Double dRefundDeduction = 0.00;
        DecimalFormat df = new DecimalFormat("#0.00");
        if (!YFCCommon.isVoid(eleInOrder.getAttribute(KohlsXMLLiterals.A_LAST_RECEIPT_PROCESSED))) {

            sExtnSourceCode = eleInOrder.getAttribute(KohlsXMLLiterals.A_LAST_RECEIPT_PROCESSED);
            setMorePromotionAttribute(eleInOrder,sExtnSourceCode);
            NodeList eleProcessPromotions = SCXmlUtil.getXpathNodes(eleInOrder, 
                    "//Order/Promotions/Promotion[@PromotionType='"+ KohlsPOCConstant.LOYALTY_KC_UNEARNED + "']");
            for (int i=0; i < eleProcessPromotions.getLength(); i++) {
                Element currentPromotion = (Element) eleProcessPromotions.item(i);
                Element currentExtnNode = SCXmlUtil.getChildElement(currentPromotion, KohlsXMLLiterals.E_EXTN);
                if (sExtnSourceCode.equalsIgnoreCase(currentExtnNode.getAttribute(KohlsXMLLiterals.A_EXTN_COUPON_SOURCE_CODE))) {
                    elePromotion = currentPromotion;
                    break;
                }
            }
            logger.debug("element elePromotion" + XMLUtil.getElementXMLString(elePromotion));
            Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, "Extn");

            //String sExtnKCOptionSelected = elePromotionExtn.getAttribute("ExtnKCOptionSelected");
            elePromotionMaxRefund = XMLUtil.getChildElement(elePromotion, KohlsXMLLiterals.E_MAXIMIZE_REFUND);
            if(dRefundAmount == 0.0D) {
              dRefundAmount = Double.parseDouble(elePromotionMaxRefund.getAttribute("RefundAmount"));
              dRefundAmount_Temp = dRefundAmount;
            }else {
              elePromotionMaxRefund.setAttribute("RefundAmount", df.format(dRefundAmount));
            }
            eleRfundDeduction = XMLUtil.createChild(elePromotion, "RefundDeduction");
            String sRefundDeduction = eleInOrder.getAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION);
            if(!YFCCommon.isVoid(sRefundDeduction)) {
              dRefundDeduction = Double.parseDouble(sRefundDeduction);
            }
            //eleRfundDeduction.setNodeValue(df.format(dRefundDeduction));
            eleRfundDeduction.setTextContent(df.format(dRefundDeduction));
        }
        
        if (dRefundDeduction > 0 && YFCCommon.isVoid(source)) {
            lEcommStores = populateEcommStores(env);
            callTVSAndUpdateOrderDocument(env, eleInOrder, orderInDoc, eleRfundDeduction, elePromotion);
        } 
        
        updateOutputDocPromotion(env, elePromotion, "Y", dRefundAmount+"", "MaximizeRefund", currentBusinessDate);
        
        XMLUtil.removeChild(elePromotion, eleRfundDeduction);
        eleInOrder.setAttribute("MorePromotionsToProcess", sMorePromotionsToProcess);
        logger.endTimer("KohlsReturnsLCSDeactivation.deactivateKohlsCash");
        return orderInDoc;
    }

     public Element updateOutputDocPromotion(YFSEnvironment env, Element elePromo,
              String sPromotionApplied, String sAmt, String sKCOption, Date currentBusinessDate) {
       
            logger.beginTimer("KohlsReturnsLCSDeactivation.updateOutputDocPromotion");
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Element elePromoExtn = XMLUtil.getChildElement(elePromo, KohlsPOCConstant.E_EXTN);
            String sTranUnearnAmt = elePromoExtn.getAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE);
            if (!YFCCommon.isVoid(sKCOption)) {
              Element elePromotionMaxRefund = XMLUtil.getChildElement(elePromo, sKCOption, true);
              elePromotionMaxRefund.setAttribute(KohlsPOCConstant.UNEARNED_VALUE, sTranUnearnAmt);
              elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, new DecimalFormat("#0.00").format(Double.parseDouble(sAmt)));
            }

            if (!YFCCommon.isVoid(sPromotionApplied)) {
              elePromo.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, sPromotionApplied);
            }
            elePromo.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, sTranUnearnAmt);
            //elePromoExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, sKCOption);
            String sPromotionType = elePromo.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
            if(KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType)) {
              String startDate =  elePromoExtn.getAttribute(KohlsPOCConstant.E_EXTN_START_DATE);
              String endDate =  elePromoExtn.getAttribute(KohlsPOCConstant.E_EXTN_END_DATE);
              //Date currentDate = new Date();
              String sReasonCode = "";
              if(!YFCCommon.isVoid(startDate) && !YFCCommon.isVoid(endDate)) {
                try {
                      Date dtStartDate = sdf.parse(startDate);
                      Date dtEndDate = sdf.parse(endDate);
                      if(currentBusinessDate.before(dtStartDate)) {
                        sReasonCode = "PREREDEMPTION";
                      } else if (currentBusinessDate.after(dtEndDate)) {
                        sReasonCode = "POSTREDEMPTION";
                      } else {
                        sReasonCode = "ACTIVE";
                      }
                    } catch (ParseException e) {
                      // TODO Auto-generated catch block
                      e.printStackTrace();
                    }
              }
              elePromoExtn.setAttribute(KohlsPOCConstant.EXTN_REASON_CODE, sReasonCode);
            }
            logger.endTimer("KohlsReturnsLCSDeactivation.updateOutputDocPromotion");
            return elePromo;

          }

    /**
     * Create By mrjoshi *
     * 
     * @param env
     * @param LCSResponseDoc2
     * @param orderDtlsEle
     * @param eleMKCRefundDeduction
     * @param string
     * @throws Exception
     */
    void callTVSAndUpdateOrderDocument(YFSEnvironment env, Element orderDtlsEle, Document outDoc, Element eleRefundDeduction,
            Element elePromotion) throws Exception {
        logger.beginTimer("KohlsReturnsLCSDeactivation.callTVSAndUpdateOrderDocument");
        Element promoExtnEle = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN);
        String sReceiptSrc = promoExtnEle.getAttribute("ExtnCouponSourceCode");
        String[] sOrigDefn = sReceiptSrc.split("-");
        LCSResponseDoc = makeElgibleItems(outDoc,sReceiptSrc);
        Document firstTVSResponseForMKCDoc =
                firstTVSObj.prepareRequestForFirstTVSCall(env, LCSResponseDoc, orderDtlsEle,
                        eleRefundDeduction, sOrigDefn[0], sOrigDefn[1], sOrigDefn[2]);
        boolean bErrorsInTVS = checkForTVSResponseErrors(firstTVSResponseForMKCDoc);
        if (bErrorsInTVS) {
            logger.debug("Errors in TVS response, Please proceed with tendering!!");
            throw new YFSException(sTVSErrorMessage);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("TVS output is:  " + XMLUtil.getXMLString(firstTVSResponseForMKCDoc));
        }
        // Setting RefundAmount and LineCharge on the orderLine
        addRefundDeductionCharges(env, firstTVSResponseForMKCDoc, outDoc, elePromotion, "MaximizeRefund",
                orderDtlsEle, promoExtnEle.getAttribute("ExtnCouponSourceCode"));
        //updateOutputDocPromotion(env, elePromotion, "Y", dRefundAmount+"", "MaximizeRefund");
        logger.endTimer("KohlsReturnsLCSDeactivation.callTVSAndUpdateOrderDocument");
    }
    
    /*<ReturnableItemList><ReturnableItem>
      <LineNo>1</LineNo><Dept>26</Dept><NetPrice>26.0</NetPrice>
      <KohlsCashEligible>True</KohlsCashEligible>
      </ReturnableItem></ReturnableItemList>*/
    public Document makeElgibleItems(Document outDoc, String sReceiptSrc) throws ParserConfigurationException {
        logger.beginTimer("KohlsReturnsLCSDeactivation.makeElgibleItems");
        Document docReturnableList = XMLUtil.createDocument("KCSOutput");
        Element rootEle = XMLUtil.createChild(docReturnableList.getDocumentElement(), "Data") ;
        Element paretnEle = XMLUtil.createChild(rootEle, "ReturnableItemList") ;
        //paretnEle.setTextContent("True");
        Element eleOrderLines = XMLUtil.getChildElement(outDoc.getDocumentElement(), KohlsXMLLiterals.E_ORDER_LINES);
        Element eleOrderExtn = XMLUtil.getChildElement(outDoc.getDocumentElement(), KohlsXMLLiterals.E_EXTN);
        String sPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
        List<Element> OrderLineList =XMLUtil.getElementsByTagName(eleOrderLines, KohlsXMLLiterals.E_ORDER_LINE);
               
        String[] sReceipt = sReceiptSrc.split("-");   
        for (Element OrderLineEle : OrderLineList) {
                Element extnEle  = XMLUtil.getChildElement(OrderLineEle, KohlsPOCConstant.A_EXTN);
                String sOrderedQty = XMLUtil.getAttribute(OrderLineEle, KohlsPOCConstant.ATTR_ORDERED_QTY);
                Element CustAttribsEle = XMLUtil.getChildElement(OrderLineEle, KohlsPOCConstant.CUST_ATTRIBUTES);
                String SStore = XMLUtil.getAttribute(CustAttribsEle,KohlsPOCConstant.TEXT7);
                String sTerminal = XMLUtil.getAttribute(CustAttribsEle,KohlsPOCConstant.TEXT8);
                String sTranNo = XMLUtil.getAttribute(CustAttribsEle,KohlsPOCConstant.TEXT9);
                String sEligible = XMLUtil.getAttribute(CustAttribsEle,KohlsPOCConstant.TEXT11);
                String sText12 = XMLUtil.getAttribute(CustAttribsEle,"Text12");
                //if(extnEle.getAttribute("ExtnKohlsCashEligible").equalsIgnoreCase("Y")||extnEle.getAttribute("ExtnKohlsCashEligible").equalsIgnoreCase("true")){
                    if((sReceipt[0].equalsIgnoreCase(SStore) && sReceipt[1].equalsIgnoreCase(sTerminal)
                            && sReceipt[2].equalsIgnoreCase(sTranNo) ) || YFCCommon.isVoid(sPOCFeature)){
                        if( "PriceAdjustment".equalsIgnoreCase(sPOCFeature) && !"Eligible".equalsIgnoreCase(sEligible)){
                            continue;
                        }
                        String sKCEligible = extnEle.getAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE);
                        //sEligibleLine is set in KohlsCashRewardsDeactivation class as true - else it will be empty
                        if(!"true".equalsIgnoreCase(sKCEligible)) {
                          continue;
                        }
                        Element returnableItemEle = XMLUtil.createChild(paretnEle, "ReturnableItem");
                        Element lineNoEle = XMLUtil.createChild(returnableItemEle, "LineNo");
                        //lineNoEle.setNodeValue(OrderLineEle.getAttribute("PrimeLineNo"));
                        lineNoEle.setTextContent(OrderLineEle.getAttribute("PrimeLineNo"));
                        Element deptEle = XMLUtil.createChild(returnableItemEle, "Dept");
                        //deptEle.setNodeValue(extnEle.getAttribute("ExtnItemDept"));
                        deptEle.setTextContent(extnEle.getAttribute("ExtnItemDept"));
                        Element netPriceEle = XMLUtil.createChild(returnableItemEle, "NetPrice");
                        if (sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                          String sNetPrice = extnEle.getAttribute("ExtnNetPrice");
                            Double dText12 = 0.00D;
                            if (!YFCCommon.isVoid(sText12)) {
                              dText12 = Double.parseDouble(sText12);
                            }
                            double dTempTotal = dText12 - Double.parseDouble(sNetPrice); 
                            netPriceEle.setTextContent(new DecimalFormat("#0.00").format(dTempTotal));
                        } else {
                        //netPriceEle.setNodeValue(extnEle.getAttribute("ExtnNetPrice"));
                          netPriceEle.setTextContent(extnEle.getAttribute("ExtnNetPrice"));
                        }
                        Element KohlsCashEligibleEle = XMLUtil.createChild(returnableItemEle, "KohlsCashEligible");
                        if (!YFCCommon.isVoid(callingSource) && Double.parseDouble(sOrderedQty) == 0) {
                        	KohlsCashEligibleEle.setTextContent("false");
                        }else{
                        	//KohlsCashEligibleEle.setNodeValue("true");
                        	KohlsCashEligibleEle.setTextContent("true");
                        }
                    }
                //}
            }
        logger.endTimer("KohlsReturnsLCSDeactivation.makeElgibleItems");
        return docReturnableList;
    }

    /**
     * @param tvsResponseDoc
     * @throws YFSException
     */
    public boolean checkForTVSResponseErrors(Document tvsResponseDoc) throws YFSException {
        logger.beginTimer("KohlsReturnsLCSDeactivation.checkForTVSResponseErrors");
        logger
        .debug("Input to method checkForTVSResponseErrors" + XMLUtil.getXMLString(tvsResponseDoc));

        Boolean bIsError = false;
        Element tvsResponseEle = tvsResponseDoc.getDocumentElement();
        // Checking for SOAP fault
        if (tvsResponseEle.getTagName().equalsIgnoreCase(KohlsPOCConstant.E_ERRORS)) {
            bIsError = true;
            YFSException yfsException = new YFSException();
            String errorCodeStr = XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
                    .getAttribute(KohlsPOCConstant.E_ERRORCODE);
            String errorDesc = XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
                    .getAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION);

            if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr)) {
                yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
                yfsException.setErrorDescription(errorDesc);
            } else if (KohlsPOCConstant.OFFER_END_DATE_PASSED.equalsIgnoreCase(errorCodeStr)) {
                yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
                if (!YFCCommon
                        .isStringVoid(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID))) {
                    yfsException.setErrorDescription(
                            KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID));
                }
            } else {
                yfsException.setErrorCode(errorCodeStr);
                yfsException.setErrorDescription(errorDesc);
            }
            if (!"OFFER_END_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
                yfsException.setErrorDescription(errorDesc);
            }
            throw yfsException;
        }
        logger.endTimer("KohlsReturnsLCSDeactivation.checkForTVSResponseErrors");
        return bIsError;
    }


    /**
     * @param env
     * @param tvsResponse
     * @param outDoc
     * @throws Exception
     */
    private void addRefundDeductionCharges(YFSEnvironment env, Document tvsResponse, Document outDoc,
            Element elePromotion, String sKCOption, Element orderDtlsEle, String sExtnSourceCode)
                    throws Exception {
        logger.beginTimer("KohlsReturnsLCSDeactivation.addRefundDeductionCharges");
        DecimalFormat df = new DecimalFormat("0.00");
        for (String id : mapLinePrice.keySet()){
          dRefundAmount_Temp = dRefundAmount_Temp - mapLinePrice.get(id);
        }
        
        Double dLineTax = 0.00;
        Double dNetPrice = 0.00;
        Double dTempOrderTotal = 0.0;
        Double dTempOrderTotalWithoutTax = 0.0;
        Element orderEle = outDoc.getDocumentElement();
        Element eleProRatedLines = XMLUtil.getChildElement(orderEle, "ProRatedLines", true);
        Element eleOrderLines = XMLUtil.createChild(eleProRatedLines, KohlsXMLLiterals.E_ORDER_LINES);
        // Setting this attribute to retain the proration done for
        // MaximizeRefund when
        // refundDeduction > 0 i.e. partial KC redemption scenario.
        eleOrderLines.setAttribute("OrderLinesForKCOption", sKCOption);
        // Get the transaction for Which Promotion is being processed.
        Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
        String sExtnCouponSourceCode = "";
        if(!YFCCommon.isVoid(elePromotionExtn)) {
          sExtnCouponSourceCode = elePromotionExtn.getAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE);
        }
        String sLastReceiptPocessed = orderDtlsEle.getAttribute(KohlsXMLLiterals.A_LAST_RECEIPT_PROCESSED);
        if(!YFCCommon.isVoid(sExtnCouponSourceCode)) {
          eleOrderLines.setAttribute("OrderLinesForPromotion", sExtnCouponSourceCode);
        } else {
          eleOrderLines.setAttribute("OrderLinesForPromotion", sLastReceiptPocessed);
        }
        Element tvsResEle = tvsResponse.getDocumentElement();
        NodeList itemsNL = tvsResEle.getElementsByTagName("item");
        if (itemsNL.getLength() > 0) {
            for (int i = 0; i < itemsNL.getLength(); i++) {
                Element tempItemEle = (Element) itemsNL.item(i);
                String sID = tempItemEle.getAttribute("id");

                Element eleOrderLine = XMLUtil.createChild(eleOrderLines, KohlsXMLLiterals.E_ORDER_lINE);
                Element eleOrderLineExtn = XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_EXTN);
                eleOrderLine.setAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO, sID);
                eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO,
                        KohlsPOCConstant.A_SUB_LINE_NO);

                eleOrderLine.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.MODIFY);
                Element eleOriginalOrderLine = (Element) XPathUtil.getNode(orderDtlsEle,
                        "//OrderLines/OrderLine[@PrimeLineNo='" + sID + "']");
                Double totalAdjFee = KohlsPOCConstant.ZERO_DBL;
                NodeList nlFees = tempItemEle.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
                if (!YFCCommon.isVoid(nlFees) && nlFees.getLength()>0) {
                	for(int f=0; f<nlFees.getLength(); f++){
                		Element eleFees = ((Element) nlFees.item(f));
                		String strCalculatedAmount = XMLUtil.getAttribute(eleFees, KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
                		if(!YFCCommon.isVoid(strCalculatedAmount)){
                			totalAdjFee = totalAdjFee + Double.valueOf(strCalculatedAmount);
                		}
                	}
                }
                // KC unearning for price adjustment
                if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {

                    Element eleOriginalOrderLineCustomAttr =
                            XMLUtil.getChildElement(eleOriginalOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
                    Element eleOriginalOrderLineExtn =
                            XMLUtil.getChildElement(eleOriginalOrderLine, KohlsPOCConstant.E_EXTN);
                    String sNetPriceOriginal = eleOriginalOrderLineCustomAttr.getAttribute("Text12");
                    String sTaxablePriceOriginal = eleOriginalOrderLineCustomAttr.getAttribute("Text14");
                    String sOriginalStoreId = eleOriginalOrderLineCustomAttr.getAttribute(KohlsPOCConstant.TEXT7);
                    String sOriginalTerminalId = eleOriginalOrderLineCustomAttr.getAttribute(KohlsPOCConstant.TEXT8);
                    String sOriginalTranNo = eleOriginalOrderLineCustomAttr.getAttribute(KohlsPOCConstant.TEXT9);
                    String sOriginalLineId = eleOriginalOrderLineCustomAttr.getAttribute(KohlsPOCConstant.TEXT10);
                    String sNetPriceCurrent =
                            eleOriginalOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
                    String sTaxablePriceCurrent =
                            eleOriginalOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
                    Element eleOrderCustAttribs = XMLUtil.getChildElement(orderDtlsEle,KohlsPOCConstant.CUST_ATTRIBUTES);
                    String sMultChannelNmbr = eleOrderCustAttribs.getAttribute(KohlsPOCConstant.TEXT13);
                    if (!YFCCommon.isVoid(sNetPriceOriginal)) {
                        Double dNetPriceOriginal = Double.parseDouble(sNetPriceOriginal);
                        Double dNetPriceCurrent = Double.parseDouble(sNetPriceCurrent);
                        String sNetPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
                        String sReturnPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_RETURN_PRICE);
                        String sBasisAmt = "";
                        if(tempItemEle.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX).getLength()>0) {
                          Element eleTVSLineTaxExtn = XMLUtil.getChildElement((Element)tempItemEle.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX).item(0), KohlsPOCConstant.E_EXTN);
                          if(!YFCCommon.isVoid(eleTVSLineTaxExtn)) {
                            sBasisAmt = eleTVSLineTaxExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
                          }
                        }
                        String sTaxablePrice = "";
                        if(!YFCCommon.isVoid(sBasisAmt)) {
                          sTaxablePrice = sBasisAmt;
                        } else {
                          tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
                        }
                        if (!YFCCommon.isVoid(sNetPrice)) {
                          dNetPrice = Double.parseDouble(sNetPrice);
                          // Double dTVSNetPrice =
                          // Double.parseDouble(sNetPrice);
                          Double dKCProratedNetPrice = Double.parseDouble(sNetPriceOriginal) - (dNetPrice + dNetPriceCurrent);
                          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE,
                              df.format(dKCProratedNetPrice));
                        }
                        if (!YFCCommon.isVoid(sReturnPrice)) {
                          Double dTVSReturnPrice = Double.parseDouble(sReturnPrice);
                          Double dKCProratedReturnPrice = Double.parseDouble(sNetPriceOriginal) - (dTVSReturnPrice + dNetPriceCurrent);
                          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE,
                              df.format(dKCProratedReturnPrice));
                        }
                        if (!YFCCommon.isVoid(sTaxablePrice)) {
                          Double dTaxablePriceOriginal = Double.parseDouble(sTaxablePriceOriginal);
                          Double dTaxablePriceCurrent = Double.parseDouble(sTaxablePriceCurrent);
                          Double dTVSTaxablePrice = Double.parseDouble(sTaxablePrice);
                          Double dKCProratedTaxablePrice = dTaxablePriceOriginal - (dTVSTaxablePrice + dTaxablePriceCurrent);
                          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT,
                              df.format(dKCProratedTaxablePrice));
                        }
                      }

                    Element eleLineTaxes =
                            (Element) tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
                    NodeList lineTaxNL = tempItemEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
                    if (!YFCCommon.isVoid(lineTaxNL)) {
                        Element eleLineTaxTVS = ((Element) lineTaxNL.item(0));
                        String strlineTax = eleLineTaxTVS.getAttribute(KohlsXMLLiterals.A_TAX);
                        dLineTax = Double.parseDouble(strlineTax);
                        //CAPE-4251 - retaining Ecom tax rate changes
                        if(!YFCCommon.isVoid(sMultChannelNmbr)){
                            Double dTaxRate =  mapOrigtaxRate.get(sOriginalStoreId+"-"+sOriginalTerminalId+"-"+sOriginalTranNo+"-"+sOriginalLineId);
                            String sTaxablePriceFromTVS = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
                            dLineTax = Double.parseDouble(sTaxablePriceFromTVS) * dTaxRate/100;
                            Element eleLineTax = ((Element) lineTaxNL.item(0));
                            strlineTax = new DecimalFormat("#0.00").format(dLineTax);
                            eleLineTax.setAttribute(KohlsXMLLiterals.A_TAX, strlineTax);
                            eleLineTax.setAttribute("LineTotalTax", strlineTax);
                            eleLineTax.setAttribute("LineTotalTaxRate",  new DecimalFormat("#0.00").format(dTaxRate));
                            eleLineTax.setAttribute("TaxPercentage",  new DecimalFormat("#0.00").format(dTaxRate));
                        }
                        Element eleOriginalOrderLineTax = (Element) eleOriginalOrderLine
                                .getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX).item(0);
                        String sCurrentTax = eleOriginalOrderLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                        Element eleOriginalOrderLineTaxExtn =
                                XMLUtil.getChildElement(eleOriginalOrderLineTax, KohlsPOCConstant.E_EXTN);
                        String sExtnOrigTaxAmt = eleOriginalOrderLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
                        if (!YFCCommon.isVoid(sExtnOrigTaxAmt)) {
                          Double dDeltaTax = Double.parseDouble(sExtnOrigTaxAmt) - (dLineTax + Double.parseDouble(sCurrentTax));
                          eleLineTaxTVS.setAttribute(KohlsXMLLiterals.A_TAX, df.format(dDeltaTax));
                          Element eleLineTaxTVSExtn =
                              XMLUtil.getChildElement(eleLineTaxTVS, KohlsPOCConstant.E_EXTN, true);
                          eleLineTaxTVSExtn.setAttribute("ExtnOrigTaxAmt", sExtnOrigTaxAmt);
                        }
                        Element eleLineTaxes_Temp = (Element) outDoc.importNode(eleLineTaxes, true);
                        eleLineTaxes_Temp.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
                        eleOrderLine.appendChild(eleLineTaxes_Temp);
                    }
                    Element eleOrigLineCharges = XMLUtil.getChildElement(eleOriginalOrderLine, "LineCharges");
                    if (!YFCCommon.isVoid(eleOrigLineCharges)) {
                  	  eleOrderLine.appendChild(outDoc.importNode(eleOrigLineCharges, true));
                    }
                  //deduct the Orig Fee amt with the Fee after PA, so the remaing fee is corresponding to 
                    // refund amt.
                    NodeList nlFee = tempItemEle.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
                    if (!YFCCommon.isVoid(nlFee)) {
                      for (int index = 0; index < nlFee.getLength(); index++) {
                          Element eleFee = (Element) nlFee.item(index);
                          NodeList nlCharges  = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
                          if(!YFCCommon.isVoid(nlCharges) && nlCharges.getLength()>0){
                              for (int iCharge = 0; iCharge < nlCharges.getLength(); iCharge++) {
                                  Element eleCharge = (Element) nlCharges.item(iCharge);
                                  if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))
                                          && eleFee.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION).equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME))){
                                    Element eleChargeExtn = XMLUtil.getChildElement(eleCharge, KohlsPOCConstant.E_EXTN);
                                    String sOrigFeeAmt = eleChargeExtn.getAttribute("ExtnOrigChgPerLine");
                                      String sFeeAmt = eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
                                      Double deltaFee = Double.parseDouble(sOrigFeeAmt) - (Double.parseDouble(sFeeAmt) + Double.parseDouble(eleCharge.getAttribute("ChargePerLine")));
                                      //eleChargeExtn.setAttribute("ExtnOrigChgPerLine",  df.format(Double.parseDouble(sOrigFeeAmt) - Double.parseDouble(eleCharge.getAttribute("ChargePerLine"))));
                                      double dNewFeeBasisAmt = Double.parseDouble(eleChargeExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT)) 
                                          + Double.parseDouble(eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_BASIS_AMOUNT)); 
                                      eleChargeExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, df.format(dNewFeeBasisAmt));
                                      eleChargeExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_EXEMPT_AMOUNT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_EXEMPT_AMOUNT));
                                      eleChargeExtn.setAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_RATE_FEE));
                                      eleCharge.setAttribute( KohlsPOCConstant.A_CHARGE_PER_LINE, df.format(deltaFee));
                                      eleCharge.setAttribute( KohlsPOCConstant.ATTR_CHARGE_AMNT,  df.format(deltaFee));
                                      eleCharge.setAttribute( "InvoicedChargeAmount", sFeeAmt);
                                  }
                              }
                          }
                      }
                    }
                } else {
                    Element eleCustomAttributes = (Element) eleOriginalOrderLine
                            .getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
                    String sOriginalStoreId="";
                    String sOriginalTerminalId="";
                    String sOriginalTranNo="";
                    String sOriginalLineId="";
                    String sMultiChannelNbr = "";
                    if (!YFCCommon.isVoid(eleCustomAttributes)) {
                        sOriginalStoreId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
                        sOriginalTerminalId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
                        sOriginalTranNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
                        sOriginalLineId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT10);
                        sMultiChannelNbr = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT13);
                    }
                    String sNetPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
                    String sReturnPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_RETURN_PRICE);
                    String sProratedNetPrice = tempItemEle.getAttribute("proratedNetPriceDiscountAmt");
                    String sTaxablePrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
                    eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, sNetPrice);
                    eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE, sReturnPrice);
                    eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, sTaxablePrice);
                    dNetPrice = Double.parseDouble(sNetPrice);
                    //dNetPrice = Double.parseDouble(sProratedNetPrice);
                    Element eleLineTaxes =
                            (Element) tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
                    NodeList lineTaxNL = tempItemEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
                    if (!YFCCommon.isVoid(lineTaxNL)) {
                    	Element eleLineTax = ((Element) lineTaxNL.item(0));
                      	Element eleExtnLineTax = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
                      	String strExtnBasisAmount = XMLUtil.getAttribute(eleExtnLineTax, KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
                      	if(!YFCCommon.isVoid(strExtnBasisAmount)){
                      		eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, strExtnBasisAmount);
                      	}
                        String strlineTax="";
                        //CAPE-4251 - retaining Ecom tax rate changes
                        if(!YFCCommon.isVoid(sMultiChannelNbr)){
                            Double dTaxRate =  mapOrigtaxRate.get(sOriginalStoreId+"-"+sOriginalTerminalId+"-"+sOriginalTranNo+"-"+sOriginalLineId);
                            dLineTax = Double.parseDouble(sReturnPrice) * dTaxRate/100;
                            //Element eleLineTax = ((Element) lineTaxNL.item(0));
                            strlineTax = new DecimalFormat("#0.00").format(dLineTax);
                            eleLineTax.setAttribute(KohlsXMLLiterals.A_TAX, strlineTax);
                            eleLineTax.setAttribute("LineTotalTax", strlineTax);
                            eleLineTax.setAttribute("LineTotalTaxRate",  new DecimalFormat("#0.00").format(dTaxRate));
                            eleLineTax.setAttribute("TaxPercentage",  new DecimalFormat("#0.00").format(dTaxRate));
                        } else{
                            strlineTax = ((Element) lineTaxNL.item(0)).getAttribute(KohlsXMLLiterals.A_TAX);
                            dLineTax = Double.parseDouble(strlineTax);
                        }
                        Element eleLineTaxes_Temp = (Element) outDoc.importNode(eleLineTaxes, true);
                        eleLineTaxes_Temp.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
                        eleOrderLine.appendChild(eleLineTaxes_Temp);

                    }
                    KohlsPoCPnPUtil.updateKCDTaxFee(eleOrderLine,tempItemEle,"Returns",KohlsPOCConstant.MINUS);
                }
                // changes for cape 1575 - Begin
                // MJ 02/02 Changes for CAPE 1654 - Begin
                // dTempOrderTotal = dTempOrderTotal + (dNetPrice + dLineTax);
                Double finalNetPrice = Double.valueOf(df.format(dNetPrice + totalAdjFee));
                if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {

                    if (mapLinePrice.containsKey(sID)) {
                        mapLinePrice.remove(sID);
                        mapLinePrice.put(sID, (finalNetPrice + Double.parseDouble(new DecimalFormat("#0.00").format(dLineTax))));
                    } else {
                      mapLinePrice.put(sID, (finalNetPrice + Double.parseDouble(new DecimalFormat("#0.00").format(dLineTax))));
                    }
                } else {
                    if (mapLinePrice.containsKey(sID)) {
                        mapLinePrice.remove(sID);
                        mapLinePrice.put(sID, (finalNetPrice + Double.parseDouble(new DecimalFormat("#0.00").format(dLineTax))));
                    } else {
                        mapLinePrice.put(sID, (finalNetPrice + Double.parseDouble(new DecimalFormat("#0.00").format(dLineTax))));
                    }
                }
                // MJ 02/02 Changes for CAPE 1654 - Begin
                // MJ 02/02 changes for CAPE 1654 - End
                // changes for cape 1575 - end
                NodeList nlModifier = tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_MODIFIER);
                if (!YFCCommon.isVoid(nlModifier) && nlModifier.getLength() > 0) {
                    Element eleModifier = (Element) nlModifier.item(0);
                    Element eleLineCharges =
                            XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_LINE_CHARGES, true);
                    String sNetPriceDelta = eleModifier.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE_DELTA);
                    Double dNetPriceDelta = Math.abs(Double.parseDouble(sNetPriceDelta));
                    Element eleLineCharge =
                            XMLUtil.createChild(eleLineCharges, KohlsXMLLiterals.E_LINE_CHARGE);
                    eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY,
                            KohlsPOCConstant.KC_UNEARNED);
                    eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_NAME, KohlsPOCConstant.KC_UNEARNED);
                    eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE,
                            String.valueOf(dNetPriceDelta));
                    eleLineCharge.setAttribute(KohlsXMLLiterals.A_IS_DISCOUNT, KohlsPOCConstant.NO);
                }
            }
        }

        // MJ 02/02 Changes for CAPE 1654 - Begin
        // Calculating final refund amount
        //if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
        for (String id : mapLinePrice.keySet()) {
            dTempOrderTotal = dTempOrderTotal + mapLinePrice.get(id);
        }

        // MJ 02/02 Changes for CAPE 1654 - End
        if(!KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)){
            dTempOrderTotal = dRefundAmount_Temp + dTempOrderTotal;
        }
        
        dRefundAmount = dTempOrderTotal;
        dRefundAmount_Temp = dTempOrderTotal;
        //mapLinePrice.clear();

        elePromotion.setAttribute(KohlsPOCConstant.REFUND_AMT,
                new DecimalFormat("#0.00").format(dTempOrderTotal));
        // changes for cape 1575 - Begin
        elePromotion.setAttribute("RefundAmountWithoutTax",
                new DecimalFormat("#0.00").format(dTempOrderTotalWithoutTax));
        // changes for cape 1575 - end      
        orderDtlsEle.setAttribute(KohlsPOCConstant.REFUND_AMT, 
            new DecimalFormat("#0.00").format(dTempOrderTotal));
        
        Element eleMaxRefund = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.MAX_REFUND, true);
        
        eleMaxRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, 
            new DecimalFormat("#0.00").format(dTempOrderTotal));
        
        logger.endTimer("KohlsReturnsLCSDeactivation.addRefundDeductionCharges");

    }

    /**
     * Create By mrjoshi *
     * 
     * @param tagName
     * @param element
     * @param sValue
     */
    private static void setString(String tagName, Element parentElement, String sValue) {
        logger.beginTimer("KohlsReturnsLCSDeactivation.setString");
        Element temp = XMLUtil.createChild(parentElement, tagName);
        temp.setTextContent(sValue);
        logger.endTimer("KohlsReturnsLCSDeactivation.setString");
    }

    /**
     * Stamp Attributes using changeOrder when LCS is offline Created By tkmai3r
     * 
     * @param env
     * @param elePromotion
     * @param strOrderHeaderKey
     * @throws Exception
     */
    public void stampOfflineAttributesInChangeOrder(YFSEnvironment env, Element elePromotion,
            String strOrderHeaderKey) throws Exception {

        logger.beginTimer("KohlsReturnsLCSDeactivation.stampOfflineAttributesInChangeOrder");
        Document inputChangeOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleOrder = inputChangeOrderDoc.getDocumentElement();
        eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
        eleOrder.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsPOCConstant.YES);
        elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
        Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN);
        elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_OFFLINE_MODE, KohlsPOCConstant.YES);
        Element elePromotions = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
        elePromotions.appendChild(inputChangeOrderDoc.importNode(elePromotion, true));
        // setting env object to skip the Repricing UE call.
        env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
        KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API, inputChangeOrderDoc);

        logger.endTimer("KohlsReturnsLCSDeactivation.stampOfflineAttributesInChangeOrder");

    }

    /**
     * This function is used to get the value for a property
     * 
     * @param property name in string format
     * @return String propValue
     */
    public String getPropertyValue(String property) {
        logger.beginTimer("KohlsReturnsLCSDeactivation.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        // Manoj 10/22: updated to use configured property if
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        logger.endTimer("KohlsReturnsLCSDeactivation.getPropertyValue");
        return propValue;

    }

    /**
     * Sets the properties
     * 
     * @param prop Properties that need to be set
     * @throws Exception when unable to set the Property
     */

    public void setProperties(Properties prop) throws Exception {
        logger.beginTimer("KohlsReturnsLCSDeactivation.setProperties");
        this.props = prop;
        logger.debug("In the set properties method");
        logger.endTimer("KohlsReturnsLCSDeactivation.setProperties");
    }

    

    /** 
     * @param eleOrder
     * @param sExtnCouponSrcCode
     */
    public void setMorePromotionAttribute(Element eleOrder, String sExtnCouponSrcCode) {
      logger.beginTimer("KohlsReturnsLCSDeactivation.setMorePromotionAttribute");
        int mapsize = 0;

        Element elePromotions = (Element) eleOrder.getElementsByTagName("Promotions").item(0);
        if (!YFCCommon.isVoid(elePromotions)) {
            NodeList ndlPromotion = elePromotions.getElementsByTagName("Promotion");
            for (int i = 0; i < ndlPromotion.getLength(); i++) {

                Element elePromotion = (Element) ndlPromotion.item(i);
                Element elePromotionExtn = (Element) elePromotion.getElementsByTagName("Extn").item(0);

                if ((elePromotion.getAttribute("PromotionType").equalsIgnoreCase("LOYALTY_KC_UNEARNED") ||
                        elePromotion.getAttribute("PromotionType").equalsIgnoreCase("KOHLS_CASH_UNEARNED"))
                        && elePromotion.getAttribute("IsProcessed").equalsIgnoreCase("Y")) {

                    mapPromotionGravity.put(elePromotionExtn.getAttribute("ExtnCouponSourceCode"),
                            elePromotion.getAttribute("PromotionId"));
                }

                if (elePromotion.getAttribute("PromotionType").equalsIgnoreCase("LOYALTY_KC_UNEARNED") ||
                        elePromotion.getAttribute("PromotionType").equalsIgnoreCase("KOHLS_CASH_UNEARNED")) {

                    mapPromotionOrder.put(elePromotionExtn.getAttribute("ExtnCouponSourceCode"),
                            elePromotion.getAttribute("PromotionId"));
                }
            }
            if (!YFCCommon.isVoid(sExtnCouponSrcCode)) {
                if (mapPromotionOrder.containsKey(sExtnCouponSrcCode)) {

                    mapsize = mapPromotionOrder.size() - 1;

                }
            }
            if (mapsize == mapPromotionGravity.size()) {

                sMorePromotionsToProcess = "N";

            } else {

                sMorePromotionsToProcess = "Y";
            }
        }   
        logger.debug("Inside KohlsReturnsLCSDeactivation: sMorePromotionsToProcess is: "+sMorePromotionsToProcess);
        logger.endTimer("KohlsReturnsLCSDeactivation.setMorePromotionAttribute");
    }

    
    
    /** 
     * @param ecommStoreLists
     * @param storeId
     * @return
     */
   /* public boolean isEcommerceStore( List<String> ecommStoreLists, String storeId)
    {
      logger.beginTimer("KohlsReturnsLCSDeactivation.isEcommerceStore");
      if ( storeId.startsWith( "0" ) )
      {
        storeId = storeId.substring( 1, storeId.length() );
      }
      for ( String ecomStoreId : ecommStoreLists )
      {

        if ( ecomStoreId.equals( storeId ) )
        {
          logger.endTimer("KohlsReturnsLCSDeactivation.isEcommerceStore");
          return true;
        }
      }
      
      logger.endTimer("KohlsReturnsLCSDeactivation.isEcommerceStore");
      return false;
    }*/
    
    
    /**
     * @param env
     * @return
     * @throws Exception
     */
    public List<String> populateEcommStores( YFSEnvironment env ) throws Exception
    {
      logger.beginTimer("KohlsReturnsLCSDeactivation.populateEcommStores");
      List<String> ecommStoreLists = new ArrayList<String>();

      Document exDoc = KohlsPoCCommonAPIUtil.getCommonCodeList(env, "EComStores", "", "DEFAULT");

      if ( exDoc != null )
      {
        NodeList commonCodeNodes = XPathUtil.getNodeList(exDoc.getDocumentElement(), "//CommonCodeList/CommonCode" );
        if ( commonCodeNodes != null )
        {
          String codeValue = null;
          for(int index=0;index < commonCodeNodes.getLength();index++ )
          {
            Element commonCodeNode = (Element)commonCodeNodes.item( index );
            codeValue = commonCodeNode.getAttribute( KohlsConstant.A_CODE_VALUE );
            ecommStoreLists.add( codeValue );
          }
        }
      }
      logger.endTimer("KohlsReturnsLCSDeactivation.populateEcommStores");
      return ecommStoreLists;
    }

}
