/*
 * File: KohlsPoCPreateReturnInvoiceForSalesHub.java Created on May 22, 2017 for POC_OMS_IBM_Returns
 * by mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.util.HashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.api.KohlsPocInvoiceToSalesHubAPI;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

import org.apache.commons.lang3.StringUtils;

/**
 * @author mrjoshi
 *
 */
public class KohlsPoCPreateReturnInvoiceForSalesHub extends KOHLSBaseApi {

  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPOCPriceAdjustment.class.getName());
  }

  public Document preparReturnInvoice(YFSEnvironment env, Document docInXML) throws Exception {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.preparReturnInvoice");
    if (logger.isDebugEnabled()) {
      logger.debug("Input xml to KohlsPoCPreateReturnInvoiceForSalesHub.preparReturnInvoice is: "
          + XMLUtil.getXMLString(docInXML));
    }
    String sIsVoidDuring = "";
    DecimalFormat df = new DecimalFormat("#0.00");
    Element eleOrderExtn =
        XMLUtil.getChildElement(docInXML.getDocumentElement(), KohlsPOCConstant.A_EXTN);
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      sIsVoidDuring = eleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
    }

    // String sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

    Document docInvoiceListOut = createOrderInvoice(env, docInXML);

    callRequestCollection(env, docInXML);

    Document docInvoiceOut = null;

    NodeList nlOrderInvoice =
        docInvoiceListOut.getElementsByTagName(KohlsPOCConstant.E_ORDER_INVOICE);
    for (int i = 0; i < nlOrderInvoice.getLength(); i++) {
      Element eleOrderInvoice = (Element) nlOrderInvoice.item(i);
      String sOrderInvoiceKey =
          eleOrderInvoice.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
      if (!YFCCommon.isVoid(sOrderInvoiceKey)) {
        Document docInvoiceDetailsOut = getOrderInvoiceDetails(env, sOrderInvoiceKey);

        if (!YFCCommon.isVoid(sIsVoidDuring) && KohlsPOCConstant.YES.equals(sIsVoidDuring)) {
          voidInvoice(env, sOrderInvoiceKey);
        } else {
          updateInvoiceStatus(env, sOrderInvoiceKey);
        }
        if (i == 0) {
          docInvoiceOut = (Document) docInvoiceDetailsOut.cloneNode(true);
          continue;
        }
        NodeList nlCollectionDetail =
            docInvoiceDetailsOut.getElementsByTagName(KohlsPOCConstant.ELE_COLLECTION_DETAIL);
        Element eleOutCollectionDetails = (Element) docInvoiceOut
            .getElementsByTagName(KohlsPOCConstant.ELE_COLLECTION_DETAILS).item(0);
        for (int j = 0; j < nlCollectionDetail.getLength(); j++) {
          Element eleCollectionDetail = (Element) nlCollectionDetail.item(j);
          Element eleTemp = (Element) eleOutCollectionDetails.getOwnerDocument()
              .importNode(eleCollectionDetail, true);
          eleOutCollectionDetails.appendChild(eleTemp);
        }
        // Consolidating the amounts
        // CAPE-3197 - start
        Element eleInvoiceHeaderFinal = (Element) docInvoiceOut
            .getElementsByTagName(KohlsPOCConstant.ELE_INVOICE_HEADER).item(0);
        String sTotalAmount_Final =
            eleInvoiceHeaderFinal.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
        String sTotalTax_Final =
            eleInvoiceHeaderFinal.getAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX);
        String sLineSubTotal_Final =
            eleInvoiceHeaderFinal.getAttribute(KohlsPOCConstant.ATTR_LINE_SUB_TOTAL);
        String sAmountCollected_Final =
            eleInvoiceHeaderFinal.getAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED);

        Element eleInvoiceHeader = (Element) docInvoiceDetailsOut
            .getElementsByTagName(KohlsPOCConstant.ELE_INVOICE_HEADER).item(0);
        String sTotalAmount = eleInvoiceHeader.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
        String sTotalTax = eleInvoiceHeader.getAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX);
        String sLineSubTotal = eleInvoiceHeader.getAttribute(KohlsPOCConstant.ATTR_LINE_SUB_TOTAL);
        String sAmountCollected =
            eleInvoiceHeader.getAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED);

        if (!YFCCommon.isVoid(sTotalAmount_Final) && !YFCCommon.isVoid(sTotalAmount)) {
          Double dTotalAmount_Final =
              Double.parseDouble(sTotalAmount_Final) + Double.parseDouble(sTotalAmount);
          eleInvoiceHeaderFinal.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT,
              df.format(dTotalAmount_Final));
        }
        if (!YFCCommon.isVoid(sTotalTax_Final) && !YFCCommon.isVoid(sTotalTax)) {
          Double dTotalTax_Final =
              Double.parseDouble(sTotalTax_Final) + Double.parseDouble(sTotalTax);
          eleInvoiceHeaderFinal.setAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX,
              df.format(dTotalTax_Final));
        }
        if (!YFCCommon.isVoid(sLineSubTotal_Final) && !YFCCommon.isVoid(sLineSubTotal)) {
          Double dLineSubTotal_Final =
              Double.parseDouble(sLineSubTotal_Final) + Double.parseDouble(sLineSubTotal);
          eleInvoiceHeaderFinal.setAttribute(KohlsPOCConstant.ATTR_LINE_SUB_TOTAL,
              df.format(dLineSubTotal_Final));
        }
        if (!YFCCommon.isVoid(sAmountCollected_Final) && !YFCCommon.isVoid(sAmountCollected)) {
          Double dAmountCollected_Final =
              Double.parseDouble(sAmountCollected_Final) + Double.parseDouble(sAmountCollected);
          eleInvoiceHeaderFinal.setAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED,
              df.format(dAmountCollected_Final));
        }
        // CAPE-3197 - end
      }
    }

    consolidateCollectionDetails(docInvoiceOut);

    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.preparReturnInvoice");
    return docInvoiceOut;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param sOrderInvoiceKey
   * @throws Exception
   */
  private void voidInvoice(YFSEnvironment env, String sOrderInvoiceKey) throws Exception {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.voidInvoice");
    Document docChangeOrderInvoiceInXML = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_INVOICE);
    docChangeOrderInvoiceInXML.getDocumentElement()
        .setAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY, sOrderInvoiceKey);
    docChangeOrderInvoiceInXML.getDocumentElement().setAttribute(KohlsPOCConstant.A_TRANSACTION_ID,
        KohlsPOCConstant.VOID_INVOICE_TRAN_RETURN);
    docChangeOrderInvoiceInXML.getDocumentElement()
        .setAttribute(KohlsPOCConstant.ATTR_IGNORE_STATUS_CHECK, KohlsPOCConstant.YES);
    invokeAPI(env, KohlsPOCConstant.API_VOID_INVOICE, docChangeOrderInvoiceInXML);
    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.voidInvoice");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param sOrderInvoiceKey
   * @throws Exception
   */
  private void updateInvoiceStatus(YFSEnvironment env, String sOrderInvoiceKey) throws Exception {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.updateInvoiceStatus");
    Document docChangeOrderInvoiceInXML = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_INVOICE);
    docChangeOrderInvoiceInXML.getDocumentElement()
        .setAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY, sOrderInvoiceKey);
    docChangeOrderInvoiceInXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_STATUS,
        KohlsPOCConstant.INVOICE_PUBLISHED_STATUS);
    invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER_INVOICE, docChangeOrderInvoiceInXML);
    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.updateInvoiceStatus");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param docInvoiceOut
   */
  public void consolidateCollectionDetails(Document docInvoiceOut) {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.consolidateCollectionDetails");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Input xml to KohlsPoCPreateReturnInvoiceForSalesHub.consolidateCollectionDetails is: "
              + XMLUtil.getXMLString(docInvoiceOut));
    }
    HashMap<String, Element> mapPaymentMethodMap = new HashMap<String, Element>();
    Element eleCollectionDetails = (Element) docInvoiceOut
        .getElementsByTagName(KohlsPOCConstant.ELE_COLLECTION_DETAILS).item(0);
    NodeList nlCollectionDetail =
        docInvoiceOut.getElementsByTagName(KohlsPOCConstant.ELE_COLLECTION_DETAIL);
    for (int i = 0; i < nlCollectionDetail.getLength(); i++) {
      Element eleCollectionDetail = (Element) nlCollectionDetail.item(i);
      String sAmountCollected =
          eleCollectionDetail.getAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED);
      Element elePaymentMethod =
          XMLUtil.getChildElement(eleCollectionDetail, KohlsPOCConstant.E_PAYMENT_METHOD);
      String sTotalRefundedAmount =
          elePaymentMethod.getAttribute(KohlsPOCConstant.A_TOTAL_REFUNDED_AMOUNT);
      if (!YFCCommon.isVoid(sAmountCollected) && !YFCCommon.isVoid(sTotalRefundedAmount)) {
        if (Double.compare(Double.parseDouble(sAmountCollected),
            Double.parseDouble(sTotalRefundedAmount)) == 0) {
          continue;
        } else {
          eleCollectionDetails.removeChild(eleCollectionDetail);
          i--;
        }
      }
      String sPaymentType = elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
      if (KohlsPOCConstant.PAYMENT_CREDIT_CARD.equals(sPaymentType)
          || KohlsPOCConstant.KOHL_CHARGE_CARD.equals(sPaymentType)) {
        String sCreditCardNo = elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_CREDIT_CARD_NO);
        sPaymentType = sPaymentType + "_" + sCreditCardNo;
      } else if (KohlsPOCConstant.PAYMENT_DEBIT_CARD.equals(sPaymentType)) {
        String sDebitCardNo = elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_DEBIT_CARD_NO);
        sPaymentType = sPaymentType + "_" + sDebitCardNo;
      }
      if (!mapPaymentMethodMap.containsKey(sPaymentType)) {
        eleCollectionDetail.setAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED,
            sTotalRefundedAmount);
        mapPaymentMethodMap.put(sPaymentType, eleCollectionDetail);
      }
    

	    if(!sPaymentType.equals("KOHLS_CASH"))
	    {
		    if (!mapPaymentMethodMap.containsKey(sPaymentType)) {
			    eleCollectionDetail.setAttribute(KohlsPOCConstant.ATTR_AMOUNT_COLLECTED,
			    sTotalRefundedAmount);
			    mapPaymentMethodMap.put(sPaymentType, eleCollectionDetail);
		    }
	    }
    }
    
    if (mapPaymentMethodMap.size() > 0) {
      for (String key : mapPaymentMethodMap.keySet()) {
        eleCollectionDetails.appendChild(mapPaymentMethodMap.get(key));
      }
    }
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Outout of KohlsPoCPreateReturnInvoiceForSalesHub.consolidateCollectionDetails is: "
              + XMLUtil.getXMLString(docInvoiceOut));
    }
    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.consolidateCollectionDetails");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param sOrderInvoiceKey
   * @return
   * @throws Exception
   */
  public Document getOrderInvoiceDetails(YFSEnvironment env, String sOrderInvoiceKey)
      throws Exception {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.preparReturnInvoice");
    Document docGetOrderInvoiceDetailsIn =
        XMLUtil.createDocument(KohlsPOCConstant.E_GET_ORDER_INVOICE_DETAILS);
    docGetOrderInvoiceDetailsIn.getDocumentElement().setAttribute("InvoiceKey", sOrderInvoiceKey);
    if (logger.isDebugEnabled()) {
      logger.debug("Input to getOrderInvoiceDetails is: "
          + XMLUtil.getXMLString(docGetOrderInvoiceDetailsIn));
    }
    Document docGetORderInvoiceDetailsOut =
        invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT,
            KohlsPOCConstant.GET_INVOICE_ORDER_DET, docGetOrderInvoiceDetailsIn);
    if (logger.isDebugEnabled()) {
      logger.debug("Output of getOrderInvoiceDetails is: "
          + XMLUtil.getXMLString(docGetORderInvoiceDetailsOut));
    }
    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.preparReturnInvoice");
    return docGetORderInvoiceDetailsOut;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docInXML
   * @throws Exception
   */
  private void callRequestCollection(YFSEnvironment env, Document docInXML) throws Exception {
	  logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.callRequestCollection");
	  Document docRequestCollectionIn = XMLUtil.createDocument("Order");
	  docRequestCollectionIn.getDocumentElement().setAttribute("OrderHeaderKey", docInXML.getDocumentElement().getAttribute("OrderHeaderKey"));
	  invokeAPI(env, KohlsPOCConstant.API_REQUEST_COLLECTION, docRequestCollectionIn);
	  logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.callRequestCollection");
	  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docInXML
   * @return
   * @throws Exception
   */
  private Document createOrderInvoice(YFSEnvironment env, Document docInXML) throws Exception {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.createOrderInvoice");
    Document docCreateOrderInvoiceOut =
        invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_LIST_TEMPLATE,
            KohlsPOCConstant.API_CREATE_ORDER_INVOICE, docInXML);
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Output of createOrderInvoiceList is: " + XMLUtil.getXMLString(docCreateOrderInvoiceOut));
    }
    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.createOrderInvoice");
    return docCreateOrderInvoiceOut;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docInXML
   * @return
   */
  public Document manupulateReturnOrderForDataCollect(Document docInXML) throws Exception {
    logger.beginTimer("KohlsPoCPreateReturnInvoiceForSalesHub.manupulateReturnOrderForDataCollect");
    int iPrimeLineNo = 1;
    DecimalFormat df = new DecimalFormat("#0.00");
    Element eleOrder = (Element) docInXML.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);
 
    Element eleExtnOrder  = (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
    String sExtnPOCFeature = eleExtnOrder.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE); 
    if (KohlsPOCConstant.NON_RECEIPTED_RET.equalsIgnoreCase(sExtnPOCFeature)) {
       String strDLNumberFormat  = eleExtnOrder.getAttribute(KohlsPOCConstant.A_EXTN_NUMBER_FORMAT);   
       if(!YFCCommon.isVoid(strDLNumberFormat)){
    	   KohlsPocInvoiceToSalesHubAPI kohlsPocInvoiceToSalesHubAPI = new KohlsPocInvoiceToSalesHubAPI();
    	   eleExtnOrder.setAttribute(KohlsPOCConstant.A_EXTN_NUMBER_FORMAT, kohlsPocInvoiceToSalesHubAPI.convertDL(strDLNumberFormat));
       }     
    }
    Element eleOrderLines =
        (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES).item(0);
    NodeList nlOrderLine = eleOrderLines.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    eleOrder.removeChild(eleOrderLines);
    HashMap<String, Element> mapPromotionMap = new HashMap<String, Element>();
    Element elePromotions = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS, true);
    Element eleNewOrderLines = XMLUtil.createChild(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);
    for (int i = 0; i < nlOrderLine.getLength(); i++) {
      Element eleOrderLine = (Element) nlOrderLine.item(i);
      Double dOrderedQty = 0.00D;
      String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
      eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, String.valueOf(iPrimeLineNo));

      NodeList nlLineCharge = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
      // Changes for CAPE-4115 - start
      // this section of code will just the line charge on the order line. It is just for data
      // collect
      // purpose only. It has no impact on OMS pricing.
      Element eleLineCharges =
          XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
      for (int j = 0; j < nlLineCharge.getLength(); j++) {
        Element eleLineCharge = (Element) nlLineCharge.item(j);
        Element eleLineChargeExtn = XMLUtil.getChildElement(eleLineCharge, KohlsPOCConstant.E_EXTN);
        String sExtnDiscountTypeCode = "";
        String sExtnDiscountReasonCode = "";
        String sExtnDiscountPercent = "0.00";
        String sTLDDiscountTypeCode = "";
        String sTempChargeName="";
        String sChargeCategory="";
       if (!YFCCommon.isVoid(eleLineChargeExtn)) {
          sExtnDiscountTypeCode = eleLineChargeExtn.getAttribute("ExtnDiscountTypeCode");
          sExtnDiscountReasonCode = eleLineChargeExtn.getAttribute("ExtnDiscountReasonCode");
          sExtnDiscountPercent = eleLineChargeExtn.getAttribute("ExtnDiscountPercent");
        }
        // Changes for CAPE-4261, CAPE-4086 start
        String sChargePerLine = eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
        String sChargeName = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
         sChargeCategory = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);

        // Changes for CAPE-4261 - start
        if ("D".equalsIgnoreCase(sExtnDiscountTypeCode)             
            || "R".equalsIgnoreCase(sExtnDiscountTypeCode)) {
          sTLDDiscountTypeCode = "D";
        } //changes for PST-6398 - Starte
        else if("K".equalsIgnoreCase(sExtnDiscountTypeCode)){
        	 sTLDDiscountTypeCode = "K";
        }//changes for PST-6398 - End
        else if ("P".equalsIgnoreCase(sExtnDiscountTypeCode)
            || "Q".equalsIgnoreCase(sExtnDiscountTypeCode)) {
          sTLDDiscountTypeCode = "P";
        } else if ("S".equalsIgnoreCase(sExtnDiscountTypeCode)) {
          sTLDDiscountTypeCode = "S";
        } else {
          sTLDDiscountTypeCode = "T";
        }
        // Changes for CAPE-4261 - end

        if (Double.parseDouble(sChargePerLine) > 0.00D
            && !(("G".equalsIgnoreCase(sExtnDiscountTypeCode)
                && "764".equalsIgnoreCase(sExtnDiscountReasonCode))
                || ("E".equalsIgnoreCase(sExtnDiscountTypeCode)
                    && "776".equalsIgnoreCase(sExtnDiscountReasonCode)) ||("J".equalsIgnoreCase(sExtnDiscountTypeCode)
                    && "762".equalsIgnoreCase(sExtnDiscountReasonCode)))) {
          if (Double.parseDouble(sChargePerLine) > 0.00D) {
        	  // changes start for PST-7427
        	  
        	  sTempChargeName=sExtnDiscountReasonCode+"_"+sExtnDiscountTypeCode;
        	 
        	  // changes end for PST-7427
        	              if (mapPromotionMap.containsKey(sTempChargeName)) {
        	               Element elePromotion = mapPromotionMap.get(sTempChargeName);
        	               
              String sOverrideAdjValue =
                  elePromotion.getAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
              Double dOverrideAdjValue = Double.parseDouble(sOverrideAdjValue);
             
              elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                  df.format(dOverrideAdjValue + Double.parseDouble(sChargePerLine)));
             
            } else {
              Element elePromotion =
                  XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
              if((KohlsPOCConstant.V_EXTN_DISCOUNT_REASON_CODE_VALUE_761.equalsIgnoreCase(sExtnDiscountReasonCode)) ||(KohlsPOCConstant.V_EXTN_DISCOUNT_TYPE_CODE_VALUE_761.equalsIgnoreCase(sExtnDiscountTypeCode))){
            	  
            	  elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, sChargeCategory);
                    
              }
              else
              {
            	  elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, sChargeName);
                  
              }
              elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                  sChargePerLine);
              Element elePromotionExtn = XMLUtil.createChild(elePromotion, KohlsPOCConstant.E_EXTN);
              elePromotionExtn.setAttribute("ExtnDiscountTypeCode", sTLDDiscountTypeCode);
              elePromotionExtn.setAttribute("ExtnDiscountReasonCode", sExtnDiscountReasonCode);
              elePromotionExtn.setAttribute("ExtnDiscountPercent", sExtnDiscountPercent);
              mapPromotionMap.put(sTempChargeName, elePromotion);
            }
          }
        }
        // Changes for CAPE-4261, CAPE-4086 end
        
        if (!YFCCommon.isVoid(sExtnDiscountTypeCode) && !YFCCommon.isVoid(sExtnDiscountReasonCode)
            && (("H".equals(sExtnDiscountTypeCode) && "763".equals(sExtnDiscountReasonCode))
                || ("F".equals(sExtnDiscountTypeCode) && "775".equals(sExtnDiscountReasonCode)))) {
          Element eleLineCharge_Temp = (Element) eleLineCharge.cloneNode(true);
          Element eleLineChargeExtn_Temp =
              XMLUtil.getChildElement(eleLineCharge_Temp, KohlsPOCConstant.E_EXTN);
          if ("H".equals(sExtnDiscountTypeCode) && "763".equals(sExtnDiscountReasonCode)) {
            eleLineChargeExtn_Temp.setAttribute("ExtnDiscountTypeCode", "G");
            eleLineChargeExtn_Temp.setAttribute("ExtnDiscountReasonCode", "764");
          } else {
            eleLineChargeExtn_Temp.setAttribute("ExtnDiscountTypeCode", "E");
            eleLineChargeExtn_Temp.setAttribute("ExtnDiscountReasonCode", "776");
          }
          XMLUtil.appendChild(eleLineCharges, eleLineCharge_Temp);
        }
      }
      // Changes for CAPE-4115 - end

      //MJ 10/24 CAPE-4520 start
      Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
      String sExtnPLURetailAmt = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT);
      //MJ 10/24 CAPE-4520 End
      
      XMLUtil.appendChild(eleNewOrderLines, eleOrderLine);
      i--;

      if (!YFCCommon.isVoid(sOrderedQty)) {
        dOrderedQty = Double.parseDouble(sOrderedQty);
      }
      if (dOrderedQty == 0.00D) {
        eleOrderLine.setAttribute("Type", "ReturnedLine");     
        //PST-3299,PST-5508 - Defensive fix - Start        
        if(!YFCCommon.isVoid(eleOrderLineExtn)){
           String sExtnTaxableAmount = XMLUtil.getAttribute(eleOrderLineExtn, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
           if(YFCCommon.isVoid(sExtnTaxableAmount)){
              XMLUtil.setAttribute(eleOrderLineExtn, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, KohlsPOCConstant.OdotO);
             }
        }//end  if(!YFCCommon.isVoid(eleOrderLineExtn))  
        Element eleOrderLine_Temp = (Element) eleOrderLine.cloneNode(true);
        eleOrderLine_Temp.setAttribute("Type", "VoidedLine");
        iPrimeLineNo = iPrimeLineNo + 1;
        eleOrderLine_Temp.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO,
            String.valueOf(iPrimeLineNo));
        XMLUtil.appendChild(eleNewOrderLines, eleOrderLine_Temp);
        //PST-3299,PST-5508 - Defensive fix - End      
      }
      iPrimeLineNo = iPrimeLineNo + 1;
    }
    logger.endTimer("KohlsPoCPreateReturnInvoiceForSalesHub.manupulateReturnOrderForDataCollect");
    return docInXML;
  }
}
