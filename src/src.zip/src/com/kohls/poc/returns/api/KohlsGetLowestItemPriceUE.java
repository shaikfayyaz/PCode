package com.kohls.poc.returns.api;

import java.util.HashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.ypm.japi.ue.YPMGetLowestItemPriceUE;
/******************************************************************************************
 * File Name : KohlsGetLowestItemPriceUE.java
 * 
 * Description : This class calls the TVS webservice to get Lowest item Price for past 13 weeks
 *  
 * Modification Log :
 * --------------------------------------------------------------------------------------
 * Author :: IBM Sterling Initial Version--------------------------------------------0.01
 * Date   :: 15-Sep-2016 
 * --------------------------------------------------------------------------------------
 * --------------------------------------------------------------------------------------
 * --------------------------------------------------------------------------------------
 *****************************************************************************************/

public class KohlsGetLowestItemPriceUE implements YPMGetLowestItemPriceUE {

  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsGetLowestItemPriceUE.class.getName());
  }

  public Document getLowestItemPrice (YFSEnvironment env, Document inDoc) throws YFSUserExitException{

    logger.beginTimer("KohlsGetLowestItemPriceUE.getLowestItemPrice");
    this.logger.debug("Method Name : getLowestItemPrice   and   Status : Start ");

    try {

      if(logger.isDebugEnabled()){

        this.logger.debug("Input of KohlsGetLowestItemPriceUE class is:" +XMLUtil.getXMLString(inDoc));

      }

      Element inEle = inDoc.getDocumentElement();
      int j=1;
      HashMap<String, String> itemIdPrice = new HashMap<String, String>();

      //preparing Document for TVS webservice request

      Document inPutToTVS = XMLUtil.createDocument(KohlsPOCConstant.PRICE_REQUEST);
      Element priceRequestEle = inPutToTVS.getDocumentElement();
      Element transactionEle = XMLUtil.createChild(priceRequestEle, KohlsPOCConstant.ATTR_TRANSACTION);  

      Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
      XMLUtil.setNodeValue(eleStoreNum, inEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
      Element storeAddressEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);

      //preparing inDoc for getOrganizationHierarchy API call
      Document inPutGetOrganizationHierarchy = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORGANIZATION);
      Element inPutEleGetOrg = inPutGetOrganizationHierarchy.getDocumentElement();
      inPutEleGetOrg.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, inEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
      inPutEleGetOrg.setAttribute(KohlsPOCConstant.ATTR_ORGANIZATION_KEY, inEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));

      //preparing template for getOrganizationHierarchy API call            
      Document tempGetOrganizationHierarchy = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORGANIZATION);
      Element eleNode = XMLUtil.createChild(tempGetOrganizationHierarchy.getDocumentElement(), KohlsPOCConstant.A_NODE);
      Element eleShipNodePersonInfo = XMLUtil.createChild(eleNode, KohlsPOCConstant.SHP_NODE_PER_INFO);


      //calling  getOrganizationHierarchy API 
      Document getOrganizationListOutput = KOHLSBaseApi.invokeAPI(env,tempGetOrganizationHierarchy,KohlsPOCConstant.API_GET_ORGANIZAION_HIERARCHY,inPutGetOrganizationHierarchy);

      Element eleShipNdPerInfo=((Element)getOrganizationListOutput.getElementsByTagName(KohlsPOCConstant.SHP_NODE_PER_INFO).item(0));
      Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
      XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
      Element eleCountry = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
      XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
      Element elePostal = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
      XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
      Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
      XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
      Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
      XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));

      Element itemListEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);

      NodeList lineItemList = XPathUtil.getNodeList(inDoc, "ItemPrice/LineItems/LineItem");


      for(int i=0; i < lineItemList.getLength(); i++ )
      {
        Element tempEle = (Element) lineItemList.item(i);

        Element itemEle = XMLUtil.createChild(itemListEle, KohlsPOCConstant.ELEM_ITEM);        
        Element eleSku = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SKU);
        XMLUtil.setNodeValue(eleSku, tempEle.getAttribute(KohlsPOCConstant.A_ITEM_ID));
        Element eleId = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_ID);             
        XMLUtil.setNodeValue(eleId, Integer.toString(j));
        Element eleTaxCodeIndicator = XMLUtil.createChild(itemEle, KohlsPOCConstant.A_TAX_CODE_INDICATOR);
        XMLUtil.setNodeValue(eleTaxCodeIndicator, "76800");
        Element eleTaxExempt = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
        XMLUtil.setNodeValue(eleTaxExempt, "N");
        Element eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
        XMLUtil.setNodeValue(eleEmpDiscCode, "H");
        j++;

      }

      KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(env, transactionEle);

      if(logger.isDebugEnabled()){

        this.logger.debug("Input of KohlsPoCTVSWebService is:" +XMLUtil.getXMLString(inPutToTVS));

      }

      Document tvsOutPut = KohlsCommonUtil.invokeService(env, KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE, inPutToTVS);

      if(logger.isDebugEnabled()){

        this.logger.debug("Output of KohlsPoCTVSWebService is:" +XMLUtil.getXMLString(tvsOutPut));

      }


      NodeList itemList = XPathUtil.getNodeList(
          tvsOutPut, "priceResponse/transaction/itemList/item");


      for(int i=0; i < itemList.getLength(); i++ )
      {
        Element tempEle = (Element) itemList.item(i);
        String itemId = tempEle.getAttribute(KohlsPOCConstant.ATTR_SKU);
        if(!itemIdPrice.containsKey(itemId)){           		

          itemIdPrice.put(itemId, tempEle.getAttribute(KohlsPOCConstant.ATTR_SELLING_PRICE));            		
        }            	

      }

      for(int i=0; i < lineItemList.getLength(); i++ )
      {
        Element tempEle = (Element) lineItemList.item(i);
        tempEle.setAttribute(KohlsPOCConstant.A_UNIT_PRICE, itemIdPrice.get(tempEle.getAttribute(KohlsPOCConstant.A_ITEM_ID)));
      }

      if(logger.isDebugEnabled()){

        this.logger.debug("Output of getLowestItemPrice is:" +XMLUtil.getXMLString(inDoc));

      }


    }  catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      throw new YFSUserExitException();
    }
    return inDoc;
  }
}
