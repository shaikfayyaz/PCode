/*
 * File: KohlsPoCMatchItemFromOTRResponse.java Created on Jan 24, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 *
 * Reason Date Who Descriptions ------- -------- --- -----------
 */

package com.kohls.poc.returns.api;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.agent.process.ApiInvoker;
import com.kohls.poc.agent.process.DefaultApiInvoker;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.validation.constraints.NotNull;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author sudina
 */

public class KohlsPoCMatchItemFromOTRResponse {
    private static YFCLogCategory logger =
            YFCLogCategory.instance(KohlsPoCMatchItemFromOTRResponse.class.getName());

    private static final String ALTERNATE_SKU_ENTITY_NAME = "ExtnAlternateSkus";

    HashMap<String, String> OTRResponseMap = new HashMap<String, String>();
    // List<String> listItemAddedOnReturnOrder = new ArrayList<String>();
    String sItemToBeMatched = "";
    String sItemMatchCriteria = "";
    private static YFCDocument oTemplateDoc = null;
    String ERROR_ITEM_RETURNED_PREVIOUSLY = "ITEM_RETURNED_PREVIOUSLY";
    String ERROR_ITEM_ADDED_FOR_RETURN = "ERROR_ITEM_ADDED_FOR_RETURN";
    String ERROR_INVALID_DATA_ENTERED = "INVALID_DATA_ENTERED";
    String ERROR_ITEM_NOT_FOUND_ON_RECEIPT = "ITEM_NOT_FOUND_ON_RECEIPT";
    String ERROR_ITEM_ALREADY_ADDED_ON_TRANSACTION = "ITEM_ALREADY_ADDED_ON_TRANSACTION";
    List listItemAddedOnReturnOrder = null;
    boolean bItemPreviouslyReturned = false;
    boolean bItemAlreadyAddedOnTransaction = false;
    private ApiInvoker invoker = new DefaultApiInvoker();

    Document docItemListOut = null;
    public static final String MSG_FORMAT = "Duplicate UPC - Original sku %s Attempting to find alternate sku %s on receipt";


    public Document matchItemDetails(YFSEnvironment env, Document docInXML) throws Exception {
        return this.matchItemDetails(env, docInXML, true);
    }

    /**
     * @param env
     * @param docInXML
     * @return
     * @throws Exception
     */
    private Document matchItemDetails(YFSEnvironment env, Document docInXML, boolean allowRecurse) throws Exception {
        try {
            logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.matchItemDetails");
            if (logger.isDebugEnabled()) {
                logger.debug(
                        "Input xml to KohlsPoCMatchItemFromOTRResponse is: " + XMLUtil.getXMLString(docInXML));
            }

            Document originalDocument = this.cloneDocument(docInXML);

            String strBarCode = "";
            String strBarCodeType = "";

            // NodeList nlReference = docInXML.getElementsByTagName("Reference");
            Element eleOrder = (Element) docInXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
            Element eleOrderLines =
                    (Element) docInXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);
            // String strIsReturned = null;
            // Element eleOrderLineFromDB = null;
            Document docReturnOrderList = null;
            String sOHKey = eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
            String sCurrentStore = eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
            if (!YFCCommon.isVoid(sOHKey)) {
                docReturnOrderList = callGetOrderList(env, sOHKey);
                if (!YFCCommon.isVoid(docReturnOrderList)) {
                    if (YFCCommon.isVoid(OTRResponseMap) || OTRResponseMap.isEmpty()) {
                        loadOTRInfo(docReturnOrderList);
                    }
                    // after loading the references info in the map, checking if
                    // map is still empty
                    if (OTRResponseMap.isEmpty()) {
                        logger.error("No orders found for matching. Returning back");
                        return docInXML;
                    }
                }

                // Get Item id from input xml. If its UPC, then get corresponding
                // item id
                Element eleOLine = (Element) docInXML.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE).item(0);
                if (YFCCommon.isVoid(eleOLine)) {
                    sItemToBeMatched = "";
                } else {
                    strBarCode = eleOLine.getAttribute(KohlsPOCConstant.A_BAR_CODE_DATA_LOWER);
                    strBarCodeType = eleOLine.getAttribute(KohlsPOCConstant.A_BARCODE_TYPE);
                    try {
                        sItemToBeMatched = checkForBarCode(env, strBarCode, strBarCodeType);
                    } catch (Exception e) {
                        if (strBarCode.length() != 8) {
                            // Error element for item already added for return
                            Element eleErrorList = XMLUtil.getChildElement(docInXML.getDocumentElement(),
                                    KohlsPOCConstant.E_ERROR_LIST, true);
                            Element eleError = XMLUtil.createChild(eleErrorList, KohlsPOCConstant.E_ERROR);
                            eleError.setAttribute(KohlsPOCConstant.A_ERROR_CODE, ERROR_INVALID_DATA_ENTERED);
                            eleError.setAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION,
                                    "Invalid Barcode data entered");
                        }
                    }

                }

                if (YFCCommon.isVoid(sItemToBeMatched)) {
                    logger.debug("Item to be matched is not valid");
                    return docInXML;
                }

                // Update the map mapItemAddedOnReturnOrder
                listItemAddedOnReturnOrder = loadItemsAddedOnReturnOrder(env, docReturnOrderList);

                // Creating input for KohlsPoCGetKohlsOTROrderList

                Document docGetOTROrderInput = formGetOTROrderInput(sCurrentStore);
                if (logger.isDebugEnabled()) {
                    logger.debug("OTR Input xml is: " + XMLUtil.getXMLString(docGetOTROrderInput));
                }

                if (!YFCCommon.isVoid(docGetOTROrderInput)) {
                    // Calling KohlsPoCGetOTROrderLineInfoList API to fetch order
                    // line info from custom tables
                    Document docOut = KOHLSBaseApi.invokeService(env,
                            KohlsPOCConstant.KOHLS_OTR_ORDER_LIST_FLOW, docGetOTROrderInput);

                    if (YFCLogUtil.isDebugEnabled()) {
                        logger.debug("response from  KohlsPoCGetKohlsOTROrderList service call \n"
                                + XMLUtil.getXMLString(docOut));
                    }

                    Element eleMatchedOrderLine = null;
                    String sStoreNo = "";
                    String sTerminalID = "";
                    String sTranNo = "";
                    String sOrderDate = "";
                    String sSaleOrderNo = "";
                    String sOrderLineKey = "";
                    String sSalesOrderHeaderKey = "";

                    NodeList nlOTROrder = docOut.getElementsByTagName(KohlsPOCConstant.E_KOHLS_OTR_ORDER);
                    logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.itemMatchingLogic");
                    if (!YFCCommon.isVoid(nlOTROrder) && nlOTROrder.getLength() > 0) {
                        for (int i = 0; i < nlOTROrder.getLength(); i++) {
                            Element eleOTROrder = (Element) nlOTROrder.item(i);
                            sStoreNo = eleOTROrder.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
                            sTerminalID = eleOTROrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
                            sTranNo = eleOTROrder.getAttribute(KohlsPOCConstant.A_TRAN_NO);
                            sOrderDate = eleOTROrder.getAttribute(KohlsXMLLiterals.A_ORDER_DATE);
                            sSaleOrderNo = eleOTROrder.getAttribute(KohlsXMLLiterals.A_ORDER_NO);


                            HashMap<String, Double> mapRSPrimeineList = getRSPrimlineList(eleOTROrder, sItemToBeMatched);


                            if (logger.isDebugEnabled()) {
                                logger.debug("@@@@ mapRSPrimeineList : " + mapRSPrimeineList.size());
                            }
                            if (mapRSPrimeineList.size() > 0) {
                                Double dMaxTaxableAmt_WithoutGiftFlag = 0.00;
                                Double dMaxTaxableAmt_WithGiftFlag = 0.00;
                                String sRSPrimeLineWithHighestPrice_WithoutGiftFlag = "";
                                String sRSPrimeLineWithHighestPrice_WithGiftFlag = "";
                                boolean bGiftLineExists = false;
                                for (String key : mapRSPrimeineList.keySet()) {
                                    String[] tempString = key.split("-");
                                    String retPrimeLineNo = tempString[0];
                                    String sGiftFlag = tempString[1];
                                    Double dTaxableAmt = mapRSPrimeineList.get(key);
                                    if (!listItemAddedOnReturnOrder
                                            .contains(sStoreNo + "-" + sTerminalID + "-" + sTranNo + "-" + retPrimeLineNo)
                                            && Double.compare(dTaxableAmt, dMaxTaxableAmt_WithoutGiftFlag) >= 0
                                            && "N".equalsIgnoreCase(sGiftFlag)) {
                                        dMaxTaxableAmt_WithoutGiftFlag = dTaxableAmt;
                                        sRSPrimeLineWithHighestPrice_WithoutGiftFlag = retPrimeLineNo;
                                    } else if (!listItemAddedOnReturnOrder
                                            .contains(sStoreNo + "-" + sTerminalID + "-" + sTranNo + "-" + retPrimeLineNo)
                                            && Double.compare(dTaxableAmt, dMaxTaxableAmt_WithGiftFlag) >= 0
                                            && "Y".equalsIgnoreCase(sGiftFlag)) {
                                        dMaxTaxableAmt_WithGiftFlag = dTaxableAmt;
                                        sRSPrimeLineWithHighestPrice_WithGiftFlag = retPrimeLineNo;
                                        bGiftLineExists = true;
                                    }
                                }
                                if (logger.isDebugEnabled()) {
                                    logger.debug("@@@@ sRSPrimeLineWithHighestPrice_WithGiftFlag : "
                                            + sRSPrimeLineWithHighestPrice_WithGiftFlag);
                                    logger.debug("@@@@ sRSPrimeLineWithHighestPrice_WithoutGiftFlag : "
                                            + sRSPrimeLineWithHighestPrice_WithoutGiftFlag);
                                }
                                if (bGiftLineExists && Double.compare(dMaxTaxableAmt_WithoutGiftFlag, 0.00D) == 0) {
                                    Element eleMatchedOTROrderLine = (Element) XPathUtil.getNode(eleOTROrder,
                                            "KohlsOTROrderLineList/KohlsOTROrderLine[@PrimeLineNo='"
                                                    + sRSPrimeLineWithHighestPrice_WithGiftFlag + "']");
                                    eleMatchedOrderLine = XMLUtil
                                            .getDocument(
                                                    eleMatchedOTROrderLine.getAttribute(KohlsXMLLiterals.E_ORDER_LINE_INFO))
                                            .getDocumentElement();
                                    sOrderLineKey = eleMatchedOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY);
                                    sSalesOrderHeaderKey =
                                            eleMatchedOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
                                    break;
                                } else {
                                    Element eleMatchedOTROrderLine = (Element) XPathUtil.getNode(eleOTROrder,
                                            "KohlsOTROrderLineList/KohlsOTROrderLine[@PrimeLineNo='"
                                                    + sRSPrimeLineWithHighestPrice_WithoutGiftFlag + "']");
                                    eleMatchedOrderLine = XMLUtil
                                            .getDocument(
                                                    eleMatchedOTROrderLine.getAttribute(KohlsXMLLiterals.E_ORDER_LINE_INFO))
                                            .getDocumentElement();
                                    sOrderLineKey = eleMatchedOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY);
                                    sSalesOrderHeaderKey =
                                            eleMatchedOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
                                    break;
                                }
                            }
                        }
                    }
                    logger.endTimer("KohlsPoCMatchItemFromOTRResponse.itemMatchingLogic");
                    if (!YFCCommon.isVoid(eleMatchedOrderLine)) {
                        eleOrder.removeChild(eleOrderLines);
                        eleOrderLines = XMLUtil.createChild(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);
                        eleMatchedOrderLine.setAttribute(KohlsPOCConstant.A_IS_RETURNABLE, KohlsPOCConstant.YES);
                        eleMatchedOrderLine.setAttribute(KohlsPOCConstant.A_BAR_CODE_DATA_LOWER, strBarCode);
                        eleMatchedOrderLine.setAttribute(KohlsPOCConstant.A_BARCODE_TYPE, strBarCodeType);
                        Element eleCustAttributes =
                                XMLUtil.getChildElement(eleMatchedOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES, true);
                        eleCustAttributes.setAttribute(KohlsPOCConstant.TEXT6, sSaleOrderNo);
                        eleCustAttributes.setAttribute(KohlsPOCConstant.TEXT7, sStoreNo);
                        eleCustAttributes.setAttribute(KohlsPOCConstant.TEXT8, sTerminalID);
                        eleCustAttributes.setAttribute(KohlsPOCConstant.TEXT9, sTranNo);
                        eleCustAttributes.setAttribute(KohlsPOCConstant.TEXT10,
                                eleMatchedOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
                        eleCustAttributes.setAttribute(KohlsPOCConstant.DATE2, sOrderDate);
                        eleMatchedOrderLine.removeAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

                        if (!YFCCommon.isVoid(sOrderLineKey) && YFCCommon.isVoid(
                                eleMatchedOrderLine.getAttribute(KohlsPOCConstant.A_DERIVED_FROM_ORDER_LINE_KEY))) {
                            Element eleDerviedFrom =
                                    XMLUtil.createChild(eleMatchedOrderLine, KohlsXMLLiterals.E_DERIVED_FROM);
                            eleDerviedFrom.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, sOrderLineKey);
                            eleDerviedFrom.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sSalesOrderHeaderKey);
                        }

                        NodeList nlLinesTaxes =
                                eleMatchedOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
                        if (!YFCCommon.isVoid(nlLinesTaxes)) {
                            for (int i = 0; i < nlLinesTaxes.getLength(); i++) {
                                Element eleLineTax = (Element) nlLinesTaxes.item(i);
                                String strTaxPercent = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
                                strTaxPercent = String.valueOf(Double.parseDouble(strTaxPercent) * 100.0);
                                eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, strTaxPercent);
                            }

                        }

                        XMLUtil.importElement(eleOrderLines, eleMatchedOrderLine);
                        // Importing References from getOrderList api call.
                        Element eleRefefences_input =
                                XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.A_REFERENCES);
                        if (!YFCCommon.isVoid(eleRefefences_input)) {
                            eleOrder.removeChild(eleRefefences_input);
                        }
                        Element eleReferences_Out =
                                (Element) XPathUtil.getNode(docReturnOrderList, "/OrderList/Order/References");
                        NodeList nleleReference_out =
                                eleReferences_Out.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
                        for (int i = 0; i < nleleReference_out.getLength(); i++) {
                            Element eleReference_Out = (Element) nleleReference_out.item(i);
                            String sName = eleReference_Out.getAttribute(KohlsPOCConstant.Name);
                            CharSequence csOrder = sStoreNo + "-" + sTerminalID + "-" + sTranNo;
                            if (!sName.contains(csOrder)) {
                                eleReferences_Out.removeChild(eleReference_Out);
                                i--;
                            }
                        }
                        if (!YFCCommon.isVoid(eleReferences_Out)) {
                            XMLUtil.importElement(eleOrder, eleReferences_Out);
                        }
                        new KohlsPoCValidateItemForReturn(docItemListOut).validateItemForReturn(env, docInXML);


                    } else {


                        // defect 2818 check special sku before setting error
                        docInXML = new KohlsPoCValidateItemForReturn(docItemListOut).validateItemForReturn(env, docInXML);

                        Element eleOrderLine = (Element) docInXML.getDocumentElement()
                                .getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE).item(0);
                        if (eleOrderLine.getAttribute(KohlsPOCConstant.A_SPL_SKU_TYPE).equalsIgnoreCase("")) {
                            String sErrorCode = "";
                            String sErrorDescription = "";
                            if (bItemPreviouslyReturned) {
                                sErrorCode = ERROR_ITEM_RETURNED_PREVIOUSLY;
                                sErrorDescription = "Item Previously Returned on another transaction";
                            } else if (bItemAlreadyAddedOnTransaction) {
                                sErrorCode = ERROR_ITEM_ALREADY_ADDED_ON_TRANSACTION;
                                sErrorDescription = "Item Already added on current transaction";
                            } else {

                                // ITEM NOT FOUND .... Check for alternate SKUS  (Duplicate UPC for returns)
                                // check for escape condition... (no alternate skus exist, or all have been checked already)
                                if (allowRecurse) {
                                    try {
                                        String[] alternateSkus = this.getAlternateSkus(env, strBarCode);
                                        for (String alt : alternateSkus) {

                                            // log the original and alternate sku
                                            String msg = String.format(MSG_FORMAT, strBarCode, alt);
                                            logger.info(msg);

                                            // create clone to use as input for recursion call, update sku, attempt match
                                            Document altMatchDocument = this.cloneDocument(originalDocument);
                                            this.updateSku(altMatchDocument, alt);
                                            Document alternateResult = this.matchItemDetails(env, altMatchDocument, false);

                                            // examine alternate result to determine if we have matched or not.
                                            if (this.hasValidMatch(alternateResult))
                                                return alternateResult;
                                        }
                                    } catch (Exception ex) {
                                        logger.error("Duplicate UPC - Failed to match on alternate SKU", ex);
                                    }
                                }

                                // setup information on items already identified as not matching.
                                sErrorCode = ERROR_ITEM_NOT_FOUND_ON_RECEIPT;
                                sErrorDescription = "Item Not Found on Receipt";
                                Element eleExtn = XMLUtil.getChildElement(eleOrderLine, "Extn", true);
                                if (YFCCommon.isVoid(eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT))) {
                                    eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT, "000");
                                }
                                if (YFCCommon.isVoid(eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS))) {
                                    eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS, "00");
                                }
                                if (YFCCommon.isVoid(eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS))) {
                                    eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS, "00");
                                }
                            }


                            Element eleErrorList =
                                    XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_ERROR_LIST, true);
                            Element eleError = XMLUtil.createChild(eleErrorList, KohlsPOCConstant.E_ERROR);
                            eleError.setAttribute(KohlsPOCConstant.A_ERROR_CODE, sErrorCode);
                            eleError.setAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION, sErrorDescription);
                        }
                    }
                }
            } else {
                logger.debug("This is non receipted flow. Calling item Validation");
                docInXML = new KohlsPoCValidateItemForReturn().validateItemForReturn(env, docInXML);
            }
            if (logger.isDebugEnabled()) {
                logger.debug(
                        "Output of the KohlsPoCMatchItemFromOTRResponse is: " + XMLUtil.getXMLString(docInXML));
            }

            /*
             * YFCDocument oOutDoc = YFCDocument.getDocumentFor(docInXML); if
             * (YFCCommon.isVoid(oTemplateDoc)) { InputStream fileToReadFrom =
             * KohlsPoCMatchItemFromOTRResponse.class .getResourceAsStream(
             * "/global/template/api/POC/returns/POC_ItemMatchingOutput.xml"); Document docTemplate =
             * XMLUtil.getDocument(fileToReadFrom); oTemplateDoc = YFCDocument.getDocumentFor(docTemplate);
             * } YCPBCTemplateTrimmer oTempTrim = new YCPBCTemplateTrimmer(); oTempTrim
             * .trimTheOutputBasedOnTemplate(oOutDoc.getDocumentElement(),oTemplateDoc
             * .getDocumentElement(), false); if (logger.isDebugEnabled()) { logger.debug(
             * "OutputDoc after trimming is --->" + oOutDoc.getDocumentElement()); }
             */
        } finally {
            logger.endTimer("KohlsPoCMatchItemFromOTRResponse.matchItemDetails");
        }
        return docInXML;
    }

    /**
     * Replace the the barcode attribute in the document with the alternate.
     *
     * @param altMatchDocument
     * @param alt
     */
    private void updateSku(Document altMatchDocument, String alt) {
        NodeList lines = altMatchDocument.getElementsByTagName("OrderLine");
        Element orderLine = (Element) lines.item(0);
        orderLine.setAttribute("BarcodeData", alt);
        orderLine.setAttribute("BarcodeType", "SKU");
        orderLine.setAttribute("ItemID", alt);
        orderLine.setAttribute("UPCCode", "");
    }

    /**
     * Determine if result from recursive call found a match.
     *
     * @param alternateResult
     * @return
     */
    private boolean hasValidMatch(Document alternateResult) {

        NodeList errorList = alternateResult.getElementsByTagName(KohlsPOCConstant.E_ERROR);
        for (int i = 0; i < errorList.getLength(); i++) {

            Element error = (Element) errorList.item(i);
            if (ERROR_ITEM_NOT_FOUND_ON_RECEIPT.equals(error.getAttribute(KohlsPOCConstant.E_ERROR)))
                return false;
        }
        return true;
    }

    private Document cloneDocument(Document docInXML) throws Exception {
        Document clone = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Node node = clone.importNode(docInXML.getDocumentElement(), true);
        clone.appendChild(node);
        return clone;
    }

    /**
     * Gets a list of alternate skus for a particular sku.
     *
     * @return a new String[].  Will return array size zero if no alternate skus exist.
     */
    @NotNull
    private String[] getAlternateSkus(YFSEnvironment env, String sku) throws Exception {
        if (YFCCommon.isVoid(sku)) {
            logger.warn("lookup for alternate SKUs passed in empty SKU");
            return new String[0];
        }
        try {
            Document input = XMLUtil.createDocument("Item");
            Element item = input.getDocumentElement();
            item.setAttribute("ItemID", sku);
            item.setAttribute("OrganizationCode", "DEFAULT");
            item.setAttribute("UnitOfMeasure", "EACH");

            String template = KohlsPOCConstant.GET_ITEM_LIST_FOR_ITEM_VALIDATION;
            String apiName = KohlsPOCConstant.API_GET_ITEM_LIST;
            docItemListOut = invoker.invokeApi(env, template, apiName, input);

            NodeList extnList = docItemListOut.getElementsByTagName("Extn");
            Element extn = (Element) extnList.item(0);
            String skuList = extn.getAttribute(ALTERNATE_SKU_ENTITY_NAME);
            if (skuList.length() > 0) {
                return skuList.split(",");
            }
        } catch (Exception e) {
            logger.error("could not find alternate SKUs for SKU failed: " + sku, e);
        }
        return new String[0];
    }

    /**
     * Create By mrjoshi *
     *
     * @throws Exception
     */
    private List loadItemsAddedOnReturnOrder(YFSEnvironment env, Document docOrderInfo)
            throws Exception {
        List<String> listItemAddedOnReturnOrder = new ArrayList<>();
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.loadItemsAddedOnReturnOrder");
        NodeList nlOrderLine = docOrderInfo.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
        for (int i = 0; i < nlOrderLine.getLength(); i++) {
            Element eleOrderLine = (Element) nlOrderLine.item(i);
            Double dOrderedQty = 0.00;
            String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
            if (!YFCCommon.isVoid(sOrderedQty)) {
                dOrderedQty = Double.parseDouble(sOrderedQty);
            }
            if (dOrderedQty == 0.00) {
                continue;
            }
            Element eleItem = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_ITEM);
            String sItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
            String sUPCCode = eleItem.getAttribute(KohlsPOCConstant.A_UPC_CODE);
            try {
                if ((sItemMatchCriteria.equalsIgnoreCase("UPC") &&
                        (Long.parseLong(sItemToBeMatched) != Long.parseLong(sUPCCode)))
                        || (sItemMatchCriteria.equalsIgnoreCase("SKU") &&
                        (Long.parseLong(sItemToBeMatched) != Long.parseLong(sItemID)))
                ) {
                    continue;
                }
            } catch (NumberFormatException nfe) {
                logger.error("sItemID or sUPCCode is not valid. " + "sItemID: " + sItemID + " sUPCCode: " + sUPCCode + ". with " + nfe.getMessage(), nfe);
                continue;
            } catch (Exception e) {
                logger.error("Error comparing SKU/UPC with item. sItemID: " + sItemID + " sUPCCode: " + sUPCCode + " sItemToBeMatched: " + sItemToBeMatched, e);
                continue;
            }
            Element eleCustomAttributes =
                    XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
            // String sText6 =
            // eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT6);
            String sText7 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
            String sText8 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
            String sText9 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
            String sText10 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT10);
            listItemAddedOnReturnOrder.add(sText7 + "-" + sText8 + "-" + sText9 + "-" + sText10);
        }
        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.loadItemsAddedOnReturnOrder");
        return listItemAddedOnReturnOrder;
    }

    /**
     * @param eleCQry
     * @param strName
     * @param QryType
     * @param strValue
     * @return
     * @throws ParserConfigurationException
     */

    private static void setComplexQueryDetails(Element eleOr, String strKey) {
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.setComplexQueryDetails");

        String[] sOTRValue = strKey.split("-");
        String sStoreID = sOTRValue[2];
        String sTerminalID = sOTRValue[3];
        String sTranNo = sOTRValue[4];

        Element eleAnd = XMLUtil.createChild(eleOr, KohlsPOCConstant.E_AND);
        Element eleExpForStore = XMLUtil.createChild(eleAnd, KohlsPOCConstant.E_EXP);
        eleExpForStore.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_STORE_ID);
        eleExpForStore.setAttribute(KohlsPOCConstant.A_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
        eleExpForStore.setAttribute(KohlsPOCConstant.A_VALUE, sStoreID);

        Element eleExpForTerminal = XMLUtil.createChild(eleAnd, KohlsPOCConstant.E_EXP);
        eleExpForTerminal.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_TERMINAL_ID);
        eleExpForTerminal.setAttribute(KohlsPOCConstant.A_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
        eleExpForTerminal.setAttribute(KohlsPOCConstant.A_VALUE, sTerminalID);

        Element eleExpForTrans = XMLUtil.createChild(eleAnd, KohlsPOCConstant.E_EXP);
        eleExpForTrans.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.A_TRAN_NO);
        eleExpForTrans.setAttribute(KohlsPOCConstant.A_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
        eleExpForTrans.setAttribute(KohlsPOCConstant.A_VALUE, sTranNo);

        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.setComplexQueryDetails");
    }

    /**
     * @param env
     * @param sOHK
     * @return docGetOrderListOutput
     * @throws Exception
     */
    private Document callGetOrderList(YFSEnvironment env, String sOHK) throws Exception {
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.callGetOrderList");

        Document docOrderListInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
        Element eleOrder = docOrderListInput.getDocumentElement();
        eleOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOHK);
        Document docGetOrderListOutput =
                invoker.invokeApi(env, KohlsPOCConstant.GET_ORDER_LIST_FOR_ITEM_MATCHING_TEMPLATE,
                        KohlsPOCConstant.API_GET_ORDER_LIST, docOrderListInput);
        if (logger.isDebugEnabled()) {
            logger.debug("Input to getOrderList   :" + XMLUtil.getXMLString(docOrderListInput));
        }
        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.callGetOrderList");
        return docGetOrderListOutput;
    }

    /**
     * @param env
     * @param docInXML
     * @return sBarcodeData
     * @throws Exception
     */

    public String checkForBarCode(YFSEnvironment env, String sBarcodeData, String strBarCodeType) throws Exception {
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.checkForBarCode");

        if (!YFCCommon.isVoid(strBarCodeType)) {
            sItemMatchCriteria = strBarCodeType;
            return sBarcodeData;
        }

        // Initialize the criteria
        sItemMatchCriteria = "SKU";

        if (sBarcodeData.length() == 14) {
            sBarcodeData = sBarcodeData.substring(1);
            sItemMatchCriteria = "UPC";
        }
        if (sBarcodeData.length() == 7) {
            sBarcodeData = '0' + sBarcodeData;
            sItemMatchCriteria = "SKU";
        } else if (sBarcodeData.length() == 11 || sBarcodeData.length() == 12
                || sBarcodeData.length() == 13) {
            /*
             * if(sBarcodeData.startsWith("0")) { sBarcodeData = sBarcodeData.substring(1); }
             */
            // Replace all leading zeros from UPCs only
            // as of 07/28, none of the UPCs in OMSRMASTER have leading zeros
            sBarcodeData = sBarcodeData.replaceFirst("^0*", "");

            Document docGetItemListInput = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);
            Element eleItemInput = docGetItemListInput.getDocumentElement();
            Element eleItemAliasList =
                    docGetItemListInput.createElement(KohlsPOCConstant.A_ITEM_ALIAS_LIST);
            eleItemInput.appendChild(eleItemAliasList);
            Element eleItemAlias = docGetItemListInput.createElement(KohlsPOCConstant.A_ITEM_ALIAS);
            eleItemAliasList.appendChild(eleItemAlias);
            eleItemAlias.setAttribute(KohlsPOCConstant.A_ALIAS_VALUE, sBarcodeData);

            docItemListOut =
                    KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST_FOR_ITEM_VALIDATION,
                            KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);

            Element eleItem =
                    (Element) docItemListOut.getElementsByTagName(KohlsXMLLiterals.E_ITEM).item(0);
            if (!YFCCommon.isVoid(eleItem)) {
                sBarcodeData = eleItem.getAttribute(KohlsXMLLiterals.A_ITEM_ID);
                sItemMatchCriteria = "SKU";
            } else {
                if (sBarcodeData.length() == 12 && sBarcodeData.startsWith("400")) {
                    // its 12, trim the first 3 and the last
                    // for example 400914496003 will become 91449600
                    sBarcodeData = sBarcodeData.substring(3, 11);
                    sItemMatchCriteria = "SKU";
                } else {
                    sItemMatchCriteria = "UPC";
                }
            }
        } else if (sBarcodeData.length() != 8) {
            throw new Exception("Invalid SKU");
        }
        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.checkForBarCode");
        return sBarcodeData;
    }

    /**
     * @param sCurrentStore
     * @return
     * @throws ParserConfigurationException
     */
    private Document formGetOTROrderInput(String sCurrentStore) throws ParserConfigurationException {
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.formGetOTROrderInput");

        Document docOTROrder = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_OTR_ORDER);
        Element eleOTROrder = docOTROrder.getDocumentElement();

        eleOTROrder.setAttribute(KohlsPOCConstant.A_CURRENT_STORE_ID, sCurrentStore);

        Element eleOrderBy = XMLUtil.createChild(eleOTROrder, KohlsPOCConstant.E_ORDER_BY);
        Element eleAttribute = XMLUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
        eleAttribute.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.A_CREATE_TS);
        eleAttribute.setAttribute(KohlsPOCConstant.A_DESC, KohlsPOCConstant.YES);
        Element eleComplexQry = XMLUtil.createChild(eleOTROrder, KohlsPOCConstant.E_COMPLEX_QUERY);
        eleComplexQry.setAttribute(KohlsPOCConstant.A_OPERATOR, KohlsPOCConstant.AND);

        Element eleOR = XMLUtil.createChild(eleComplexQry, KohlsPOCConstant.E_OR);
        for (String key : OTRResponseMap.keySet()) {
            setComplexQueryDetails(eleOR, key);
        }

        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.formGetOTROrderInput");
        return docOTROrder;
    }

    /**
     * @param docInputXML
     * @throws Exception
     */
    private void loadOTRInfo(Document docInputXML) throws Exception {
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.loadOTRInfo");

        if (!YFCCommon.isVoid(docInputXML)) {
            Element eleReferences =
                    (Element) XPathUtil.getNode(docInputXML, "/OrderList/Order/References");
            NodeList ndlReference = eleReferences.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
            for (int i = 0; i < ndlReference.getLength(); i++) {

                Element eleReference = (Element) ndlReference.item(i);
                if (!YFCCommon.isVoid(eleReference)) {
                    if (eleReference.getAttribute(KohlsPOCConstant.Name).startsWith(KohlsPOCConstant.A_OTR)) {
                        OTRResponseMap.put(eleReference.getAttribute(KohlsPOCConstant.Name),
                                eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
                    }

                }
            }
        }
        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.loadOTRInfo");
    }

    /**
     * @param eleOTROrder
     * @param itemID
     * @return
     * @throws Exception
     */
    public HashMap<String, Double> getRSPrimlineList(Element eleOTROrder, String barcodeData)
            throws Exception {
        logger.beginTimer("KohlsPoCMatchItemFromOTRResponse.getRSPrimlineList");
        HashMap<String, Double> primeineList = new HashMap<String, Double>();

        if (logger.isDebugEnabled()) {
            logger.debug("@@@@ RS response : " + XMLUtil.getElementXMLString(eleOTROrder));
        }

        // NodeList nlOTROrderLine =
        // eleOTROrder.getElementsByTagName(KohlsPOCConstant.E_KOHLS_OTR_ORDER_LINE);
        NodeList nlOTROrderLine = null;
        if ("SKU".equals(sItemMatchCriteria)) {
            nlOTROrderLine = XPathUtil.getNodeList(eleOTROrder,
                    "KohlsOTROrderLineList/KohlsOTROrderLine[@ItemID='" + barcodeData + "']");
            // Sometimes item id starts with 0 and RS does give response without 0. So handling that case.
            if (barcodeData.startsWith("0") && nlOTROrderLine.getLength() == 0) {
                nlOTROrderLine =
                        XPathUtil.getNodeList(eleOTROrder, "KohlsOTROrderLineList/KohlsOTROrderLine[@ItemID='"
                                + barcodeData.replaceFirst("^0*", "") + "']");
            }
        } else {
            nlOTROrderLine = XPathUtil.getNodeList(eleOTROrder,
                    "KohlsOTROrderLineList/KohlsOTROrderLine[@UPCCode='" + barcodeData + "']");
            if (barcodeData.startsWith("0") && nlOTROrderLine.getLength() == 0) {
                nlOTROrderLine =
                        XPathUtil.getNodeList(eleOTROrder, "KohlsOTROrderLineList/KohlsOTROrderLine[@UPCCode='"
                                + barcodeData.replaceFirst("^0*", "") + "']");
            }
        }


        if (nlOTROrderLine != null && nlOTROrderLine.getLength() > 0) {
            for (int index = 0; index < nlOTROrderLine.getLength(); index++) {
                Double dReturnPrice = 0.00;
                Element orderLineNode = (Element) nlOTROrderLine.item(index);
                String sOrderLineInfo = orderLineNode.getAttribute(KohlsXMLLiterals.E_ORDER_LINE_INFO);
                Element eleOrderLineInfo = XMLUtil.getDocument(sOrderLineInfo).getDocumentElement();

                Element orderLineExtn =
                        XMLUtil.getChildElement(eleOrderLineInfo, KohlsPOCConstant.E_EXTN);
                String sReturnPrice = orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
                String sGiftFlag = eleOrderLineInfo.getAttribute(KohlsXMLLiterals.A_GIFT_FLAG);
                if (YFCCommon.isVoid(sGiftFlag)) {
                    sGiftFlag = KohlsPOCConstant.NO;
                }
                if (!YFCCommon.isVoid(sReturnPrice)) {
                    dReturnPrice = Double.parseDouble(sReturnPrice);
                }
                String sIsReturnedItem = eleOrderLineInfo.getAttribute(KohlsPOCConstant.IS_RETURNED_ITEM);
                if (!YFCCommon.isVoid(sIsReturnedItem)
                        && KohlsPOCConstant.YES.equalsIgnoreCase(sIsReturnedItem)) {
                    bItemPreviouslyReturned = true;
                    continue;
                }

                // Added for OMNI return - start
                String sDeliveryMethod = eleOrderLineInfo.getAttribute("DeliveryMethod");
                String sStatus = eleOrderLineInfo.getAttribute("Status");
                if (!YFCCommon.isVoid(sDeliveryMethod) && !YFCCommon.isVoid(sStatus)
                        && "PICK".equalsIgnoreCase(sDeliveryMethod) && !"3700.2".equalsIgnoreCase(sStatus)) {
                    continue;
                }
                // Added for OMNI return - end
                Element eleItem =
                        (Element) eleOrderLineInfo.getElementsByTagName(KohlsPOCConstant.E_ITEM).item(0);
                if (!YFCCommon.isVoid(eleItem)) {
                    String itemID1 = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
                    String upcCode = eleItem.getAttribute(KohlsPOCConstant.A_UPC_CODE);
                    if (logger.isDebugEnabled()) {
                        logger.debug("@@ itemID1 " + itemID1 + "  itemID : " + barcodeData);
                    }
                    try {
                        long lBarcodeData = Long.parseLong(barcodeData);
                        long lItemID1 = Long.parseLong(itemID1);
                        long lUpcCode = Long.parseLong(upcCode);
                        if (("SKU".equals(sItemMatchCriteria) && lBarcodeData == lItemID1)
                                || ("UPC".equals(sItemMatchCriteria) && lBarcodeData == lUpcCode)) {
                            String primeNo = eleOrderLineInfo.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                            String strTranNo = eleOTROrder.getAttribute(KohlsPOCConstant.A_TRAN_NO);
                            String strTerminalID = eleOTROrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
                            String strStoreNo = eleOTROrder.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);

                            if (!YFCCommon.isVoid(listItemAddedOnReturnOrder) && (listItemAddedOnReturnOrder
                                    .contains(strStoreNo + "-" + strTerminalID + "-" + strTranNo + "-" + primeNo))) {
                                bItemPreviouslyReturned = false;
                                bItemAlreadyAddedOnTransaction = true;
                                continue;
                            } else {
                                primeineList.put(primeNo + "-" + sGiftFlag, dReturnPrice);
                            }
                            if (logger.isDebugEnabled()) {
                                logger.debug("@@@@ primeNo " + primeNo);
                            }
                        }
                    } catch (Exception e) {
                        if (("SKU".equals(sItemMatchCriteria) && barcodeData == itemID1)
                                || ("UPC".equals(sItemMatchCriteria) && barcodeData == upcCode)) {
                            String primeNo = eleOrderLineInfo.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                            primeineList.put(primeNo + "_" + sGiftFlag, dReturnPrice);
                            if (logger.isDebugEnabled()) {
                                logger.debug("@@@@ primeNo " + primeNo);
                            }
                        }
                    }
                }
            }
        }
        logger.endTimer("KohlsPoCMatchItemFromOTRResponse.getRSPrimlineList");
        return primeineList;
    }
}