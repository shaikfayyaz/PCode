/*
 * File: KohlsPoCActivateRKCForReturns.java Created on Feb 15, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.api;

/**
 * @author mrjoshi
 *
 */
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


/**
 * @author mrjoshi
 *
 */
public class KohlsPoCActivateRKCForReturns extends KOHLSBaseApi {

  String sOrderHeaderKey = "";
  String sPromotionKey = "";
  String sSource = "";
  String sScanIndicator="";
  String sExtnActivationBarcode="";
  String sExtnCouponSrcCode="";

  private final static YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCActivateRKCForReturns.class);

  public Document activateRKCReturns(YFSEnvironment env, Document inXML)
      throws YFSException, RemoteException {
    logger.beginTimer("KohlsPoCActivateRKCForReturns.activateRKCReturns");
    logger.debug("KohlsPoCActivateRKCForReturns.activateRKCReturns"+com.custom.util.xml.XMLUtil.getXMLString(inXML));
    Document docDKCOut = null;
    env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
    try {
      Element eleOrder = inXML.getDocumentElement();
      sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      sSource = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DM_SOURCE);
      sScanIndicator=eleOrder.getAttribute(KohlsPOCConstant.ATTR_SCAN_INDICATOR);
      Element eleExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
      
      if(!YFCCommon.isVoid(sSource) && sSource.equalsIgnoreCase(KohlsPOCConstant.ATTR_RKC_ACTIVATION)){
      Element elePromotion = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTION);
      if(elePromotion != null){
      Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
      if(elePromotionExtn != null){
      sExtnActivationBarcode=elePromotionExtn.getAttribute(KohlsPOCConstant.A_EXTN_ACTIVATION_BARCODE);
      sExtnCouponSrcCode=elePromotionExtn.getAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE);
  	
	  logger.debug("sExtnActivationBarcode: "+sExtnActivationBarcode);
      }
      }
      }
      String sEmailID = eleExtn.getAttribute(KohlsPOCConstant.EXTN_ERECEIPT_EMAIL_ID);
      String sIsTraining = eleOrder.getAttribute("isTraining");
      if (YFCCommon.isVoid(sIsTraining)) {
        sIsTraining = KohlsPOCConstant.NO;
      }
      Element eleOrderDetailsOut = callGetOrderDetails(env);
      Document docDKCInput =null;
      
      if(!YFCCommon.isVoid(sSource) && sSource.equalsIgnoreCase(KohlsPOCConstant.ATTR_RKC_ACTIVATION)){
          docDKCInput = getDKCInputXML(eleOrderDetailsOut, sEmailID, sIsTraining,sSource);
          docDKCOut = invokeService(env, "KohlsRealtimeRKCWrapper", docDKCInput);
      }else{
       docDKCInput = getDKCInputXML(eleOrderDetailsOut, sEmailID, sIsTraining,sSource);
       docDKCOut = invokeService(env, "KohlsPoCActivateDigitalRKC", docDKCInput);
      }
      
      //KohlsPoCDKCService obj = new KohlsPoCDKCService();
      //docDKCOut = obj.invokeDKCService(env, docDKCInput);
      
      if (!YFCCommon.isVoid(docDKCOut)) {
        callChangeOrder(env, docDKCOut);
      }
    } catch (Exception e) {
      throw new YFSException(e.getMessage());
    } finally {
      env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
    }
    logger.endTimer("KohlsPoCActivateRKCForReturns.activateRKCReturns");
    return docDKCOut;
  }

  /**
   * Create By mrjoshi * 
   * @return
   * @throws Exception 
   */
  private Element callGetOrderDetails(YFSEnvironment env) throws Exception {
    logger.beginTimer("KohlsPoCActivateRKCForReturns.callGetOrderDetails");
    Document docGetOrderDetailsIn = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    Element eleGetOrderDetailsInRoot = docGetOrderDetailsIn.getDocumentElement();
    eleGetOrderDetailsInRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
    //Stamping ExtnCouponAmount and ExtnQualifyingAmount for RKC Activation for returns.
    String sGetOrderDetailsTemplate = "<Order OrderHeaderKey='' SellerOrganizationCode='' TerminalID='' "
        + "PosSequenceNo='' OrderNo=''><Extn ExtnReceiptID='' ExtnEReceiptEmailID='' ExtnPAReceiptID='' ExtnPOCFeature=''/>"
        + "<Promotions><Promotion PromotionKey='' PromotionType='' OverrideAdjustmentValue=''><Extn ExtnCouponAmount='' ExtnQualifyingAmount='' ExtnActivationBarCode='' /></Promotion>"
        + "</Promotions></Order>";
    Document docGetOrderDetailsTemplate = XMLUtil.getDocument(sGetOrderDetailsTemplate);
    Document docGetOrderDetailsOut = invokeAPI(env, docGetOrderDetailsTemplate, KohlsPOCConstant.API_GET_ORDER_DETAILS, docGetOrderDetailsIn);
    logger.debug("KohlsPoCActivateRKCForReturns.callGetOrderDetails- docGetOrderDetailsOut: "+com.custom.util.xml.XMLUtil.getXMLString(docGetOrderDetailsOut));
    logger.endTimer("KohlsPoCActivateRKCForReturns.callGetOrderDetails");
    return docGetOrderDetailsOut.getDocumentElement();
  }

  /**
   * Create By mrjoshi *
   * 
   * @param dkcOut
   * @throws Exception
   */
  private void callChangeOrder(YFSEnvironment env, Document docDKCOut) throws Exception {
    logger.beginTimer("KohlsPoCActivateRKCForReturns.callChangeOrder");
    Element eleDKCOutRoot = docDKCOut.getDocumentElement();
    String sCouponNo = eleDKCOutRoot.getAttribute(KohlsPOCConstant.ATTR_COUPON_NUMBER);
    Document docChangeOrderIn = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    Element eleChangeOrderRoot = docChangeOrderIn.getDocumentElement();
    eleChangeOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
    eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsPOCConstant.YES);
    eleChangeOrderRoot.setAttribute(KohlsPOCConstant.A_ACTION, "Modify");
    Element elePromotions = XMLUtil.createChild(eleChangeOrderRoot, KohlsPOCConstant.E_PROMOTIONS);
    Element elePromotion = XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_KEY, sPromotionKey);
    Element elePromotionExtn = XMLUtil.createChild(elePromotion, KohlsPOCConstant.E_EXTN);
    //CPE-9964 START. 
    if(sSource.equalsIgnoreCase(KohlsPOCConstant.ATTR_RKC_ACTIVATION)){
    //Fetch the response from the Document input and stamp the ExtnRkcActivationFlag.
    String sResponse=eleDKCOutRoot.getAttribute(KohlsPOCConstant.A_RESULT);
    Boolean bResponse=Boolean.parseBoolean(sResponse);
    logger.debug("bResponse: "+bResponse);
    if(bResponse){
    		elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_IS_RKC_ACTIVATED, "Y");
    }
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE, sExtnCouponSrcCode);
    
    }
    else{
    	elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_IS_RKC_ACTIVATED, "Y");
    	elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE, "03");        
    }
  //CPE-9964 END. 
    elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE, sCouponNo);
    elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED, "Y");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Calling changeOrder api with input xml:\n" + XMLUtil.getXMLString(docChangeOrderIn));
    }
    // Setting minimum template for changeOrder api output
    Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
    //Setting env object to ignore the order repricing ue
    // setting env object to skip the Repricing UE call.
    env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
    // Setting minimum template for changeOrder api output
    invokeAPI(env, docChangeOrderTemplate, KohlsPOCConstant.API_CHANGE_ORDER, docChangeOrderIn);    
    logger.endTimer("KohlsPoCActivateRKCForReturns.callChangeOrder");
  }

  @SuppressWarnings("deprecation")
  protected Document getDKCInputXML(Element eleOrder, String sEmailID, String sIsTraining, String sSource)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsPoCActivateRKCForReturns.getDKCInputXML");
    logger.debug("KohlsPoCActivateRKCForReturns.getDKCInputXML eleOrder xml: "+com.custom.util.xml.XMLUtil.getElementXMLString(eleOrder));
    String sCouponAmount = "";
    String sQualifyingAmount="";
    //String sExtnCouponEventID = "";
   // String sExtnQualifyingAmount = KohlsPOCConstant.ZERO_STR;
    Document docDKCInputXML = XMLUtil.createDocument("DigitalKohlsCashActivation");
    Element eleDKCInRoot = docDKCInputXML.getDocumentElement();
    Element eleExtn = SCXmlUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
    if (YFCCommon.isVoid(sEmailID)) {
      sEmailID = eleExtn.getAttribute(KohlsPOCConstant.EXTN_ERECEIPT_EMAIL_ID);
    }
   
    String sReceiptID="";
    sReceiptID = eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);
    if(!YFCCommon.isVoid(sSource) && sSource.equalsIgnoreCase(KohlsPOCConstant.ATTR_RKC_ACTIVATION)){
    		String sPOCFeature=eleExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
	    if(!YFCCommon.isVoid(sPOCFeature) && sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)){
	         sReceiptID = eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_PA_RECEIPT_ID);    
	    }
    }
    String sOrderNo = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
    sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    
    String sDateTime = eleOrder.getAttribute(KohlsPOCConstant.A_DATE_TIME);
    
    if (YFCCommon.isVoid(sDateTime)) {
      Date date = new Date();
      sDateTime = new SimpleDateFormat(KohlsPOCConstant.DATE_FORMAT_KOHLS_CASH).format(date);
    }
    String sStoreId = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
    String sTerminalID = eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
    String sTranNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
    NodeList nlPromotion = eleOrder.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);

    if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        if (!YFCCommon.isVoid(sPromotionType)
            && KohlsPOCConstant.KOHLS_CASH_REISSUE.equals(sPromotionType)) {
          sPromotionKey = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_KEY);
          //Stamping qualifying amount and coupon amount for RKC Activation for returns
          if(!YFCCommon.isVoid(sSource) && sSource.equalsIgnoreCase(KohlsPOCConstant.ATTR_RKC_ACTIVATION)){
              eleExtn=XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN);
              if(eleExtn != null){
            	  sCouponAmount = eleExtn.getAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT);  
            	  sQualifyingAmount= eleExtn.getAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT);
            	  //sActivationBarCode=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE);
            	  logger.debug("sCouponAmount: "+sCouponAmount+" :sQualifyingAmount: "+sQualifyingAmount);
              }
              }else{
          sCouponAmount = elePromotion.getAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);  
          }
        }
      }

    } else {
      throw new YFSException("No Promotion information found on order.");
    }

    // Setting required attributes to the input xml
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sOrderNo);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_COUPON_AMOUNT, sCouponAmount);
    //eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_COUPON_EVENT_ID, sExtnCouponEventID);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_EMAIL_ADDRESS, sEmailID);
   // eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_QUALIFYING_AMOUNT, sExtnQualifyingAmount);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_RECEIPT_ID, sReceiptID);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_SEQUENCE_NO, sTranNo);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_Store, sStoreId);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
    eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_IS_TRAINING, sIsTraining);
    eleDKCInRoot.setAttribute("EventType", "Stores");
    eleDKCInRoot.setAttribute("Source", sSource);
    //Stamping qualifying amount and order no for RKC Activation for returns.
    if(!YFCCommon.isVoid(sSource) && sSource.equalsIgnoreCase(KohlsPOCConstant.ATTR_RKC_ACTIVATION)){
    	eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_QUALIFYING_AMOUNT, sQualifyingAmount);
    	eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_ACTIVATION_BARCODE, sExtnActivationBarcode);
    	eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sOrderNo.substring(0, sOrderNo.length() - 9) + sTranNo);
        eleDKCInRoot.setAttribute(KohlsPOCConstant.A_TIME_STAMP, sDateTime);
    	if(!YFCCommon.isVoid(sScanIndicator) && sScanIndicator.equalsIgnoreCase("Y")){
    		  eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_SCAN_INDICATOR,"true");
    	}else{
		  eleDKCInRoot.setAttribute(KohlsPOCConstant.ATTR_SCAN_INDICATOR,"false");
    	}
    }else{
		  eleDKCInRoot.setAttribute(KohlsPOCConstant.A_DATE_TIME, sDateTime);
    }
    
    logger.endTimer("KohlsPoCActivateRKCForReturns.getDKCInputXML");
    return docDKCInputXML;
  }
}
