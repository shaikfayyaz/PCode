package com.kohls.poc.returns.api;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.psa.api.KohlsKCSCallForPSA;
import com.kohls.poc.util.KohlcPoCWriteToFileUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author tkmaath
 *
 */
public class KohlsReturnsKCDeactivation {
  private static YFCLogCategory logger;
  String strDocumentType = "";
  String strOrigStoreNo = "";
  String sOrigTerminalID = "";
  String sOrigTranNo = "";
  String strCurrentStoreNo = "";
  String sCurrentTerminalID = "";
  String sCurrentTranNo = "";
  String sBusinessDate = "";
  String sOperatorID = "";
  String sOrderDate = "";
  String sReceiptID = "";
  String sExtnPOCFeature = "";
  String sOrderHeaderKey = "";
  String sSysRepublicResponse = "";
  String sSysRepublicFloorLimit = "";
  String sMorePromotionsToProcess = "N";
  String sErrorMessage = "Errors in KCS Response";
  HashMap<String, String> mapPromotionGravity = new HashMap<String, String>();
  HashMap<String, String> mapPromotionOrder = new HashMap<String, String>();
  String sKCRedeemedMessage =
      "KC has been redeemed fully and unearn value is greater than or equal to Refund amount";
  String sKCUnearnedMessage = "No Kohls Cash unearned on the order";
  // CAPE 1296
  String sKCRMessage = "Kohls Cash Reissue on the order";
  Element elePromotionKCR = null;
  // CAPE 1296
  String sTVSErrorMessage = "Errors in TVS Response";
  String sPromoType = "";
  String sPromotionID = "";
  String sPromotionKey = "";
  String sUnprocessedPromotionID = "";
  String sUnprocessedPromotionKey = "";
  String sUnprocessedExtnCouponSourceCode = "";
  // MJ 01/24: Added for CAPE 1605 - begin
  String strRedemptionPeriod = "";
  // MJ 01/24: Added for CAPE 1605 - end
  Document docKohlsCashRequest = null;
  public Document kcsResponseDoc = null;
  // MJ 01/26: Added for CAPE 1615 - begin
  String strEligibleAmt = "";
  String strAmtToBeUnearned = "";
  String strKohlsCashBalance = "";
  String sExtnInitialOfferAmt = "";
  String callingSource = "";
  double dSysRepublicFloorLimit = 0.00D;
  double dRefundAmount_Temp = 0.00;
  double dRefundAmount = 0.00;
  Double dMRRefundDeduction=0.0;
  List lEcommStores = null;
  // MJ 01/26: Added for CAPE 1615 - End
  // MJ 02/02 : added for CAPE 1654 - begin
  HashMap<String, Double> mapLinePrice = new HashMap<String, Double>();
  HashMap<String, Double> mapOrigtaxRate = new HashMap<String, Double>();
  // MJ 02/02 Added for CAPE 1654 - End
  private Properties props;
  static {
    logger = YFCLogCategory.instance(KohlsReturnsKCDeactivation.class.getName());
  }
  KohlsKCSCallForPSA KCSobj = new KohlsKCSCallForPSA();
  KohlsTVSCallForReturnKCEligibleItems firstTVSObj = new KohlsTVSCallForReturnKCEligibleItems();
  Document docGetOrderListOuput = null;
  /**
   * 
   * @param env
   * @param orderInDoc
   * @return
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  public Document deactivateKohlsCash(YFSEnvironment env, Document orderInDoc) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.deactivateKohlsCash");
    boolean omsKCEnabled = false;
    DecimalFormat df = new DecimalFormat("0.00");
    logger.debug("Input to method deactivateKohlsCash ::" + XMLUtil.getXMLString(orderInDoc));
   
    // Document firstTVSResponseForMRDoc = null;
    // Document firstTVSResponseForMKCDoc = null;
    Element tempOrderEle = null;
    Element eleOrderPromo = null;
    // Element eleDeductibleOffers = null;
    Element eleOrderPromotionsExtn = null;
    Element eleKohlsCashBalance = null;
    // Element eleEligibleAmount = null;
    Double dAmtToBeUnearned = 0.0;
    Double dRefundAmountWithoutTax = 0.0;
    Double dKohlsCashBalance = 0.0;
    // Double dCouponAmt = 0.0;
    // Double dOfferBalanceAmt = 0.0;
    Double dEligibleAmt = 0.00;
    Double dTotalNetPrice = 0.00;
    Double dDeltaTaxForPA = 0.00;
    boolean bDisplayUIPrompt = true;
    // Double dNetPriceTotal = 0.0;
    // Double dMaxKohlsCashRefundReduction = 0.0;
    boolean bAnyKCProcessedOnOrder = false;
    String sExtnCouponBalance = null;
    // boolean bErrorsInTVS = false;
    Document docErrorsInKCS = null;
    String strKohlscashId = "";
    Element elePromotionGettingProcessed = null;
    // MJ 01/24: Commented for CAPE 1605 - begin
    // String strRedemptionPeriod = "";
    // MJ 01/24: Commented for CAPE 1605 - end
    Element eleInOrder = orderInDoc.getDocumentElement();
    Element eleOrderExtn = XMLUtil.getChildElement(eleInOrder, KohlsPOCConstant.E_EXTN);
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
    }
    // sOrderHeaderKey =
    // eleInOrder.getAttribute(KohlsPOCConstant.RETURN_HEADER_KEY);
    // if(YFCCommon.isVoid(sOrderHeaderKey)){
    sOrderHeaderKey = eleInOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    setMorePromotionAttribute(eleInOrder, "");
    // }
    String sRefundAmount = eleInOrder.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
    logger.debug(" Refund Amount ::" + sRefundAmount);
    if (!YFCCommon.isVoid(sRefundAmount)) {
      dRefundAmount = Double.parseDouble(sRefundAmount);
      dRefundAmount_Temp = dRefundAmount;
    }
    //Skip if calling from V2
    if(YFCCommon.isVoid(callingSource)){
    	docGetOrderListOuput = getOrderList(env,orderInDoc);
    }
    Document docCommonCodeListOuput = this.getCommonCodeListForSpecialSKU(env);
    List<String> specialSKUList = this.getSpecialSKU(docCommonCodeListOuput);
    // Preparing Output document.
    Document outputDoc = XMLUtil.createDocument(KohlsPOCConstant.REFUND_OPTIONS);
    Element eleRefundOptions = outputDoc.getDocumentElement();
    eleRefundOptions.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
    Element eleOrderList = docGetOrderListOuput.getDocumentElement();
    // Getting RefundAmount if its blank in input
    if (!YFCCommon.isVoid(eleInOrder.getAttribute("LastReceiptProcessed"))) {
      String sExtnSourceCode = eleInOrder.getAttribute("LastReceiptProcessed");
      Element elePromotion = (Element) XPathUtil.getNode(eleInOrder,
          "//Promotions/Promotion[Extn/@ExtnCouponSourceCode='" + sExtnSourceCode + "']");
      logger.debug("element elePromotion" + XMLUtil.getElementXMLString(elePromotion));
      Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, "Extn");
      String sExtnKCOptionSelected = elePromotionExtn.getAttribute("ExtnKCOptionSelected");
      // Fix null issue
      if (YFCCommon.isVoid(sExtnKCOptionSelected)) {
        sExtnKCOptionSelected = "MaximizeRefund";
      }
      Element eleTemp = XMLUtil.getChildElement(elePromotion, sExtnKCOptionSelected);
      dRefundAmount = Double.parseDouble(eleTemp.getAttribute("RefundAmount"));
      dRefundAmount_Temp = dRefundAmount;
    }
    // ifeleInOrder
    if (dRefundAmount == 0) {
      Element eleOverallTotals =
          (Element) eleOrderList.getElementsByTagName("OverallTotals").item(0);
      if (!YFCCommon.isVoid(eleOverallTotals)) {
        String sGrandTotal = eleOverallTotals.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);
        // Changes for CPAE 1589 - begin
        String sGrandTax = eleOverallTotals.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
        dRefundAmount = Double.parseDouble(sGrandTotal);
        dRefundAmountWithoutTax = dRefundAmount - Double.parseDouble(sGrandTax);
        dRefundAmount_Temp = Double.parseDouble(sGrandTotal);
        // Changes for CPAE 1589 - end
      }
    }
    if (!YFCCommon.isVoid(eleOrderList)) {
      tempOrderEle = XMLUtil.getChildElement(eleOrderList, KohlsPOCConstant.ELEM_ORDER);
      Element eleExtn = XMLUtil.getChildElement(tempOrderEle, KohlsXMLLiterals.E_EXTN);
      if (!YFCCommon.isVoid(eleExtn)) {
        if (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnSysResponseCde"))) {
          sSysRepublicResponse = eleExtn.getAttribute("ExtnSysResponseCde");
        }
      }
      // CAPE 1296
      elePromotionKCR = SCXmlUtil.getXpathElement(tempOrderEle,
          "//Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_REISSUE']");
      // MJ 01/26: Added for CAPE 1612 - begin
      strCurrentStoreNo = tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
      sCurrentTerminalID = tempOrderEle.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
      sCurrentTranNo = tempOrderEle.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
      // Get Original taxes
      //lEcommStores = populateEcommStores(env);
      // MJ 01/26: Added for CAPE 1612 - end
      // MJ 01/25: commented for CAPE 1612 - begin
      // docKohlsCashRequest =
      // prepareKCRequestWithHeaderData(tempOrderEle);
      // MJ 01/25: commented for CAPE 1612 - begin
      Element eleOrderPromotions =
          XMLUtil.getChildElement(tempOrderEle, KohlsXMLLiterals.E_PROMOTIONS);
      NodeList promoList = eleOrderPromotions.getElementsByTagName(KohlsXMLLiterals.E_PROMOTION);
      String sProcessed = eleOrderPromotions.getAttribute("IsProcessed");
      String sExtnCouponSourceCode = "";
      String scurrentPromoType = "";
      boolean bKCSuccessfulyInvoked = false;
      if (!YFCCommon.isVoid(promoList) && promoList.getLength() > 0) {
        for (int i = 0; i < promoList.getLength(); i++) {
          eleOrderPromo = (Element) promoList.item(i);
          elePromotionGettingProcessed = eleOrderPromo;
          // separating current promotion information with K C unearn
          scurrentPromoType = eleOrderPromo.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
          if (!KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(scurrentPromoType)) {
        	  continue;
          }
          if (scurrentPromoType.equalsIgnoreCase(KohlsPOCConstant.KOHLS_CASH_UNEARNED)) {
            // persisting only KC unearn values
            sPromoType = scurrentPromoType;
            sPromotionID = eleOrderPromo.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
            sPromotionKey = eleOrderPromo.getAttribute(KohlsPOCConstant.A_PROMOTION_KEY);
            eleOrderPromotionsExtn =
                XMLUtil.getChildElement(eleOrderPromo, KohlsXMLLiterals.E_EXTN);
            sExtnCouponSourceCode =
                eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE);
            // MJ 01/25: added for CAPE 1612 - begin
            if (!mapPromotionGravity.isEmpty()) {
              if (mapPromotionGravity.containsKey(sExtnCouponSourceCode)) {
                continue;
              }
            }
            
            //In case for V2 MRR, dont process any other promos, but process promotion which is in the loop from calling
            //Program
            if(!YFCCommon.isVoid(env.getTxnObject(KohlsPOCConstant.CURR_PROCESS_TRANSACTION))
                && !sExtnCouponSourceCode.equalsIgnoreCase((String)env.getTxnObject(KohlsPOCConstant.CURR_PROCESS_TRANSACTION))) {
              continue;
            }
            
            setMorePromotionAttribute(eleOrderList, sExtnCouponSourceCode);
            
            // MJ 01/26: Added for CAPE 1612 - Begin
            docKohlsCashRequest = prepareKCRequestWithHeaderData(tempOrderEle);
            // MJ 01/26: Added for CAPE 1612 - End
            // MJ 01/25: added for CAPE 1612 - begin
            String[] sTemp = sExtnCouponSourceCode.split("-");
            strOrigStoreNo = sTemp[0];
            sOrigTerminalID = sTemp[1];
            sOrigTranNo = sTemp[2];
            // MJ 01/26: Commented for CAPE 1612 - Begin
            // docKohlsCashRequest =
            // prepareKCRequestWithHeaderData(tempOrderEle);
            // MJ 01/26: Commented for CAPE 1612 - End
            Element eleKCRequestRoot = docKohlsCashRequest.getDocumentElement();
            Element eleData =
                (Element) eleKCRequestRoot.getElementsByTagName(KohlsPOCConstant.E_DATA).item(0);
            if (!YFCCommon.isVoid(eleData)) {
              eleKCRequestRoot.removeChild(eleData);
            }
            eleData = XMLUtil.createChild(eleKCRequestRoot, KohlsPOCConstant.E_DATA);
            sExtnCouponBalance =
                eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE);
            String sExtnQualifyingAmount =
                eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT);
            String sExtnCouponAmount =
                eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT);
            String sCouponNo = eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.A_EXTNCOUPONNO);
            sExtnInitialOfferAmt =
                eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.A_EXTN_INITIAL_OFFER_AMT);
            // setting coupon information to the KC Request
            setString(KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, eleData, sReceiptID);
            setString(KohlsConstant.KOHLS_CASH_ID, eleData, sCouponNo);
            // Setting KohlsCashStatus in the KC request
            Element eleKohlsCashStatus =
                XMLUtil.createChild(eleData, KohlsXMLLiterals.E_KOHLS_CASH_STATUS);
            setString(KohlsXMLLiterals.E_KOHLS_CASH_BALANCE, eleKohlsCashStatus,
                sExtnCouponBalance);
            setString(KohlsXMLLiterals.E_EARNED_AMOUNT, eleKohlsCashStatus, sExtnCouponAmount);
            setString(KohlsXMLLiterals.E_ELIGIBLE_AMOUNT, eleKohlsCashStatus,
                sExtnQualifyingAmount);
            // Setting ReturnableItemList in the KC request
            boolean bLinesExistsInKCRequest = false;
            Element eleReturnableItemList =
                XMLUtil.createChild(eleData, KohlsXMLLiterals.E_RETURNABLE_ITEMLIST);
            NodeList nlOrderLine = tempOrderEle.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
            if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
              for (int j = 0; j < nlOrderLine.getLength(); j++) {
                Element eleOrderLine = (Element) nlOrderLine.item(j);
                String sOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
                String sPrimeLineNo =
                    eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                if (Double.parseDouble(sOrderedQty) == 0) {
                  continue;
                }
                Element eleItem =
                    (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);
                String sItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
                // Check for VOID SKU , PENALTY SKU AND RETURN
                // SHIPPING FEE SKU
                if (sItemID.equals("SKU_VOID_TRAN_ZERO_ITEM")) {
                  // if
                  // (sItemID.equals("SKU_VOID_TRAN_ZERO_ITEM")
                  // || sItemID.equals("80011000") ||
                  // sItemID.equals("85010001")) {
                  continue;
                }
                Element eleCustomAttributes = (Element) eleOrderLine
                    .getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
                if (!YFCCommon.isVoid(eleCustomAttributes)) {
                  String sText7 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
                  String sText8 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
                  String sText9 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
                  String sText12 = eleCustomAttributes.getAttribute("Text12");
                  String sText11 = eleCustomAttributes.getAttribute("Text11");
                  String sText13 = eleCustomAttributes.getAttribute("Text13");
                  // If order line does not belong to same
                  // order as Kohls Cash coupon then dont
                  // add it in the Kohls Cash request (for
                  // Multi Receipt Scenario)
                  if (!sExtnCouponSourceCode.equals(sText7 + "-" + sText8 + "-" + sText9)) {
                    continue;
                  }
                  if (!YFCCommon.isVoid(sText13)) {
                    Element eleTax = (Element) eleOrderLine.getElementsByTagName("LineTax").item(0);
                    if(!YFCCommon.isVoid(eleTax))
                    {
                    	if(!YFCCommon.isVoid(eleTax.getAttribute("TaxPercentage")))
                    	{
                    		mapOrigtaxRate.put(sText7,
                    		Double.parseDouble(eleTax.getAttribute("TaxPercentage")));
                    	}
                    }
                  }
                  String sExtnPOCFeature = eleExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
                  // MJ 02/02: Added for CAPE 1654 - begin
                  Element eleLinePriceInfo = (Element) eleOrderLine
                      .getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
                  String sLineTotal = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_LINE_TOTAL);
                  if (!sExtnPOCFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                    mapLinePrice.put(sPrimeLineNo, Double.parseDouble(sLineTotal));
                    dRefundAmount_Temp = dRefundAmount_Temp - Double.parseDouble(sLineTotal);
                  }
                  if (!YFCCommon.isVoid(specialSKUList)) {
                    if (specialSKUList.contains(sItemID)) {
                      continue;
                    }
                  }
                  // MJ 02/02: Added for CAPE 1654 - end
                  Element eleOrderLineExtn =
                      (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
                  String sDept = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT);
                  Element eleLineOverallTotals =
                      XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
                  //String sNetPrice = eleLineOverallTotals.getAttribute("LineTotalWithoutTax");
                  String sNetPrice = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE);
                  if (sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                    Double dText12 = 0.00D;
                    if (!YFCCommon.isVoid(sText12)) {
                      dText12 = Double.parseDouble(sText12);
                    }
                    sNetPrice = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
                    double dTempTotal = dText12 - Double.parseDouble(sNetPrice);
                    sNetPrice = df.format(dTempTotal);
                    if (dTempTotal > 0 && sText11.equalsIgnoreCase("Eligible")) {
                      Element eleOrderLineTax = (Element) eleOrderLine
                          .getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
                      Element eleOrderLineTaxExtn =
                          XMLUtil.getChildElement(eleOrderLineTax, KohlsPOCConstant.E_EXTN);
                      String strCurrentTax =
                          eleOrderLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                      String strInitialTax = eleOrderLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
                      if ((!YFCCommon.isVoid(strCurrentTax))
                          && (!YFCCommon.isVoid(strInitialTax))) {
                        dDeltaTaxForPA =
                            Double.parseDouble(strInitialTax) - Double.parseDouble(strCurrentTax);
                      }
                      Double dAdjustedLineTotal = dTempTotal + dDeltaTaxForPA;
                      mapLinePrice.put(sPrimeLineNo, dAdjustedLineTotal);
                      dDeltaTaxForPA = 0.00;
                    } else {
                      continue;
                    }
                  }
                  dTotalNetPrice = dTotalNetPrice + Double.parseDouble(sNetPrice);
                  /*
                   * String sNetPrice = eleOrderLineExtn.getAttribute(
                   * KohlsPOCConstant.A_EXTN_NET_PRICE); if(YFCCommon.isVoid(sNetPrice)){ sNetPrice
                   * = eleOrderLineExtn.getAttribute( KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT); }
                   */
                  // Create ReturnableItem tag and add details
                  // to it
                  Element eleReturnableItem = XMLUtil.createChild(eleReturnableItemList,
                      KohlsXMLLiterals.E_RETURNABLE_ITEM);
                  setString(KohlsXMLLiterals.E_LINE_NO, eleReturnableItem, sPrimeLineNo);
                  setString(KohlsPOCConstant.A_DEPT, eleReturnableItem, sDept);
                  setString(KohlsPOCConstant.A_NET_PRICE, eleReturnableItem, sNetPrice);
                  setString(KohlsPOCConstant.RETURN, eleReturnableItem, KohlsPOCConstant.TRUE);
                  bLinesExistsInKCRequest = true;
                  bAnyKCProcessedOnOrder = true;
                }
              }
            }
            if (bLinesExistsInKCRequest) {
              String sFilePath = "";
              String sFileName = "";
              String sContentToWrite = "";
              boolean bAppend = true;
              KohlcPoCWriteToFileUtil fileUtil = null;
              try {
                // MJ 01/23: Changes for QA to check the KC
                // Request / response - begin
                logger.debug("Input xml for Kohls Cash webservice is: "
                    + XMLUtil.getXMLString(docKohlsCashRequest));
                String sLogToFile = "Y";
                try {
                  // sLogToFile =
                  // getPropertyValue(this.props.getProperty("LogKCCallToFile"));
                  // sFilePath =
                  // getPropertyValue(this.props.getProperty("LogKCLogDir"));
                  sFilePath = "/logs/apps/of/KCS";
                  // sLogToFile = "N";
                  if (!YFCCommon.isVoid(sLogToFile)
                      && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
                    if (!sFilePath.endsWith("/")) {
                      sFilePath = sFilePath + "/";
                    }
                    sFileName = strCurrentStoreNo + "-" + sCurrentTerminalID + "-" + sCurrentTranNo
                        + ".log";
                    logger
                        .debug("########## Logging KC request to file: " + (sFilePath + sFileName));
                    sContentToWrite =
                        YFCDateUtils.getCurrentDate(true) + ": Request to KC service is: \n"
                            + XMLUtil.getXMLString(docKohlsCashRequest) + "\n";
                    fileUtil = new KohlcPoCWriteToFileUtil(sFilePath + sFileName, bAppend);
                    fileUtil.writeDataToFile(sContentToWrite);
                  }
                } catch (Exception ex) {
                  sLogToFile = KohlsPOCConstant.NO;
                }
                logger.beginTimer("KohlsReturnsKCDeactivation.KohlsCashWebserviceCall");
                
                KohlsCashManager kcm = new KohlsCashManager(env);
                
                omsKCEnabled = kcm.isOMSKohlsCashEnabled(strCurrentStoreNo);
                
                if(logger.isDebugEnabled())
        			logger.debug("######Rule value for OMS KC in KohlsReturnsKCDeactivation.KohlsCashWebserviceCall: " + omsKCEnabled);
                
                if(omsKCEnabled) {
                	kcm.loadEvents(strCurrentStoreNo);
                	//Use KCM
                	kcsResponseDoc = kcm.determineKohlsCashDeactivation(docKohlsCashRequest);
                }
                else {
                	//Use KCS
                	kcsResponseDoc = KohlsCommonUtil.invokeService(env,
                		KohlsConstant.KOHLS_CASH_DEACTIVATION_WEB_SERVICE, docKohlsCashRequest);
                }
                
                logger.endTimer("KohlsReturnsKCDeactivation.KohlsCashWebserviceCall");
                
                if(kcsResponseDoc != null) {
	                logger.debug(
	                    "Output of KohlsCashWebservice call::" + SCXmlUtil.getString(kcsResponseDoc));
	                if (!YFCCommon.isVoid(sLogToFile)
	                    && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
	                  logger.debug("Logging KC response to file");
	                  sContentToWrite =
	                      YFCDateUtils.getCurrentDate(true) + ": Response from KC service is: \n"
	                          + XMLUtil.getXMLString(kcsResponseDoc) + "\n";
	                  fileUtil.writeDataToFile(sContentToWrite);
	                  fileUtil.closeFile();
	                }
                }
                
                docErrorsInKCS = validateKohlsCashResponseErrors(kcsResponseDoc, dRefundAmount, omsKCEnabled);
                
                if (!YFCCommon.isVoid(docErrorsInKCS)) {
                  logger.debug(
                      "Errors in KohlsCashDeactivation response, Please proceed with tendering!!");
                  // Calling changeOrder to Update promotion
                  callChangeOrderToUpdatePromotion(env, eleOrderPromo, "N", "0.00", "",
                      tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
                  logger.endTimer("KohlsReturnsKCDeactivation.deactivateKohlsCash");
                  // CAPE 1296
                  if (!YFCCommon.isVoid(elePromotionKCR)) {
                    if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                        && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                      docErrorsInKCS = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
                    }
                  }
                  return docErrorsInKCS;
                }
                // CAPE-3488 fix keep track of this promotion id
                // that we just requested for
                sUnprocessedPromotionID = sPromotionID;
                sUnprocessedPromotionKey = sPromotionKey;
                sUnprocessedExtnCouponSourceCode = sExtnCouponSourceCode;
                // MJ 01/23: Changes for QA to check the KC
                // Request / response - end
              } catch (Exception e) {
                if (!YFCCommon.isVoid(fileUtil)) {
                  fileUtil.closeFile();
                }
                e.printStackTrace();
                Document docErrorOut =
                    prepareOutputForError(sOrderHeaderKey, sErrorMessage, dRefundAmount);
                logger.debug(
                    "Errors in KohlsCashDeactivation response, Please proceed with tendering!!");
                docErrorOut.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ERR_DESC,
                    "Errors in KCS Response");
                this.stampOfflineAttributesInChangeOrder(env, eleOrderPromo, sOrderHeaderKey);
                logger.endTimer("KohlsReturnsKCDeactivation.deactivateKohlsCash");
                // CAPE 1296
                if (!YFCCommon.isVoid(elePromotionKCR)) {
                  if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                      && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                    docErrorOut = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
                  }
                }
                return docErrorOut;
              }
              bKCSuccessfulyInvoked = true;
            }
          }
          //if (bKCSuccessfulyInvoked) {
            break;
          //}
        }
      }
    }
    if (!bAnyKCProcessedOnOrder) {
     /* Document docErrorOut =
          prepareOutputForError(sOrderHeaderKey, sKCUnearnedMessage, dRefundAmount);*/
      if ("Y".equalsIgnoreCase(sMorePromotionsToProcess)) {
        callChangeOrderToUpdatePromotion(env, elePromotionGettingProcessed, "Y", "0.0", KohlsPOCConstant.MAX_REFUND,
            tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
        // Changes for PLYT-292 - end
        // PLYT-1420 start
      
        //Skip if calling from V2
        if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) && YFCCommon.isVoid(callingSource)) {
          logger.error(
              "KohlsReturnsKCDeactivation.deactivateKohlsCash : KC is not unearn on current Promotion"
                  + sUnprocessedExtnCouponSourceCode
                  + "but more Promotion is to be processed. Hence initiaing the call again");
          Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
              KohlsPOCConstant.E_PROMOTIONS, true);
          elePromotionGettingProcessed.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
          orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
              df.format(dRefundAmount));
          XMLUtil.importElement(eleInPromotions, elePromotionGettingProcessed);
          KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
          return obj.deactivateKohlsCash(env, orderInDoc);
        }
        // PLYT-1420 end
      }
      
      logger.debug("No Kohls Cash unearned on the order");
      orderInDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ERR_DESC,
          "No Kohls Cash unearned on the order.");
      logger.endTimer("KohlsReturnsKCDeactivation.deactivateKohlsCash");
      // CAPE 1296
      if (!YFCCommon.isVoid(elePromotionKCR)) {
        if (!YFCCommon.isVoid(sMorePromotionsToProcess)
            && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
          orderInDoc = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
        }
      }
      return orderInDoc;
    }
    logger.debug("No Errors in KohlsCashDeactivation response");
    Element eleUnearnedValue;
    Element eleDeactivationOptions;
    Element eleKohlscashId;
    Element eleRedemptionPeriod;
    Element eleEligibilityDeduction;
    
    if(omsKCEnabled) {
    	eleUnearnedValue = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    	        "DetermineKohlsCashDeactivationResponseMsg/Data/UnearnedValue");
    	    eleDeactivationOptions = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    	        "DetermineKohlsCashDeactivationResponseMsg/Data/DeactivationOptions");
    	    eleKohlscashId = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    	        "DetermineKohlsCashDeactivationResponseMsg/Data/KohlsCashID");
    	    eleRedemptionPeriod = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    	        "DetermineKohlsCashDeactivationResponseMsg/Data/RedemptionPeriod");
    	    eleEligibilityDeduction = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    	        "DetermineKohlsCashDeactivationResponseMsg/Data/EligibilityDeduction");
    }
    else {
    	eleUnearnedValue = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    	        "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/UnearnedValue");
	    eleDeactivationOptions = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
	        "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/DeactivationOptions");
	    eleKohlscashId = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
	        "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/KohlsCashID");
	    eleRedemptionPeriod = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
	        "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/RedemptionPeriod");
	    eleEligibilityDeduction = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
	        "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/EligibilityDeduction");
    }
    
    /*
     * dNetPriceTotal = calculateNetPrice(eleReturnableItemList, dNetPriceTotal);
     */
    try {
    	Element eleKCDData;
    	if(omsKCEnabled) {
    		eleKCDData = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
  		          "DetermineKohlsCashDeactivationResponseMsg/Data");
    	}
    	else {
    		eleKCDData = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
    		          "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data");
    	}
      
      if (!YFCCommon.isVoid(eleUnearnedValue)) {
        strAmtToBeUnearned = XMLUtil.getNodeValue(eleUnearnedValue);
        dAmtToBeUnearned = Double.parseDouble(strAmtToBeUnearned);
      }
      if (!YFCCommon.isVoid(eleKohlscashId)) {
        strKohlscashId = XMLUtil.getNodeValue(eleKohlscashId);
      }
      if (!YFCCommon.isVoid(eleRedemptionPeriod)) {
        strRedemptionPeriod = XMLUtil.getNodeValue(eleRedemptionPeriod);
      }
      eleKohlsCashBalance = XMLUtil.getChildElement(eleKCDData, KohlsPOCConstant.KC_BAL);
      if (!YFCCommon.isVoid(eleKohlsCashBalance)) {
        strKohlsCashBalance = XMLUtil.getNodeValue(eleKohlsCashBalance);
        dKohlsCashBalance = Double.parseDouble(strKohlsCashBalance);
      }
      if (!YFCCommon.isVoid(eleEligibilityDeduction)) {
        strEligibleAmt = XMLUtil.getNodeValue(eleEligibilityDeduction);
        dEligibleAmt = Double.parseDouble(strEligibleAmt);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    // Creating output document
    // Document promotionsDoc =
    // XMLUtil.createDocument(KohlsXMLLiterals.E_PROMOTIONS);
    /*
     * Document outDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
     * outDoc.getDocumentElement().setAttribute(KohlsXMLLiterals. A_ORDER_HEADER_KEY,
     * tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
     * 
     * // Element elePromotions = promotionsDoc.getDocumentElement(); Element elePromotions =
     * XMLUtil.createChild(outDoc.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);
     */
    //Document outDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
   Document outDoc = (Document) orderInDoc.cloneNode(true);
    // Element elePromotions = promotionsDoc.getDocumentElement();
    Element elePromotions =
        XMLUtil.getChildElement(outDoc.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);
    if (YFCCommon.isVoid(elePromotions)) {
      elePromotions =
          XMLUtil.createChild(outDoc.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);
    }
    /*
     * // Import Kohls Cash Reissue element as well in the output if
     * (!YFCCommon.isVoid(elePromotionKCR)) { Element elePromotionKCROut = (Element)
     * outDoc.importNode(elePromotionKCR, true); elePromotions.appendChild(elePromotionKCROut); }
     */
    // Element elePromotions = XMLUtil.createChild(eleInOrder,
    // "Promotions");
    Element elePromotion = XMLUtil.createChild(elePromotions, KohlsXMLLiterals.E_PROMOTION);
    elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.NO);
    elePromotion.setAttribute(KohlsXMLLiterals.A_PROMOTION_ID, sUnprocessedPromotionID);
    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, sPromoType);
    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_KEY, sUnprocessedPromotionKey);
    elePromotion.setAttribute(KohlsPOCConstant.REDEMPTION_PERIOD, strRedemptionPeriod);
    Element elePromotionExtn = XMLUtil.createChild(elePromotion, KohlsXMLLiterals.E_EXTN);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REASON_CODE, strRedemptionPeriod);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_OFFLINE_MODE, KohlsPOCConstant.NO);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE,
        sUnprocessedExtnCouponSourceCode);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, strEligibleAmt);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE, strAmtToBeUnearned);
    elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_INITIAL_OFFER_AMT, sExtnInitialOfferAmt);
    // Fetching additional response attributes -- end -- 14/5/16
    if (dAmtToBeUnearned > 0) {
      // Check if UI prompt needs to be displayed or not
      if ("ACTIVE".equalsIgnoreCase(strRedemptionPeriod)
          || "POSTREDEMPTION".equalsIgnoreCase(strRedemptionPeriod)) {
        if ((dAmtToBeUnearned - dKohlsCashBalance) >= dEligibleAmt) {
          bDisplayUIPrompt = false;
        }
      } /*
         * else if ("PREREDEMPTION".equalsIgnoreCase(strRedemptionPeriod) &&
         * (sSysRepublicResponse.equals("03") || sSysRepublicResponse.equals("08") ||
         * sSysRepublicResponse.equals("09"))) { bDisplayUIPrompt = false; }
         */
      if (!YFCCommon.isVoid(strKohlsCashBalance)) {
        elePromotion.setAttribute(KohlsPOCConstant.KC_BAL, strKohlsCashBalance);
        elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE, strKohlsCashBalance);
      }
      /*
       * if (!YFCCommon.isVoid(eleEligibleAmount)) {
       * elePromotion.setAttribute(KohlsPOCConstant.EARNED_AMT, eleEligibleAmount.getTextContent());
       * }
       */
      if (!YFCCommon.isVoid(eleUnearnedValue)) {
        elePromotion.setAttribute(KohlsPOCConstant.UNEARNED_VALUE,
            eleUnearnedValue.getTextContent());
      }
      elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, strAmtToBeUnearned);
      elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
      if (dTotalNetPrice > dAmtToBeUnearned) {
        Element eleMaximizeRefund =
            XMLUtil.getChildElement(eleDeactivationOptions, KohlsPOCConstant.MAX_REFUND);
        Element eleKohlsCashReduction =
            XMLUtil.getChildElement(eleMaximizeRefund, KohlsPOCConstant.KC_REDUCTION);
        String sKohlsCashReduction = XMLUtil.getNodeValue(eleKohlsCashReduction);
        if (!YFCCommon.isVoid(eleMaximizeRefund)) {
          // Changes for CAPE 137 and 1537
          if ("POSTREDEMPTION".equalsIgnoreCase(strRedemptionPeriod)) {
            if (Double.compare(dKohlsCashBalance, dAmtToBeUnearned) >= 0) {
             // elePromotion = this.updateOutputDocPromotion(env, elePromotion, "Y",
              //    sKohlsCashReduction, KohlsPOCConstant.MAX_REFUND);
              callChangeOrderToUpdatePromotion(env, elePromotion, "Y", sKohlsCashReduction, KohlsPOCConstant.MAX_REFUND,
                  tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
              // Changes for PLYT-292 - end
              // PLYT-1420 start
             //Skip calling for V2 - callingSource - V2Unearn
              if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) && YFCCommon.isVoid(callingSource)) {
                logger.error(
                    "KohlsReturnsKCDeactivation.deactivateKohlsCash : KC is not unearn on current Promotion"
                        + sUnprocessedExtnCouponSourceCode
                        + "but more Promotion is to be processed. Hence initiaing the call again");
                Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
                    KohlsPOCConstant.E_PROMOTIONS, true);
                elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
                orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
                    df.format(dRefundAmount));
                XMLUtil.importElement(eleInPromotions, elePromotion);
                KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
                return obj.deactivateKohlsCash(env, orderInDoc);
              }
              // PLYT-1420 end
              if (!YFCCommon.isVoid(elePromotionKCR)) {
                if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                    && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                  outDoc = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
                }
              }
              // If its V2 Call, then return outDoc = inDoc
              if(!YFCCommon.isVoid(callingSource)){
                logger.debug("Its Post redemption. So promotion is updated via changeOrder call");
                outDoc = (Document)orderInDoc.cloneNode(true);
              }
              // CAPE 1296
              outDoc.getDocumentElement().setAttribute("MorePromotionsToProcess",
                  sMorePromotionsToProcess);
              return outDoc;
            }
          }
          // 03/09 MJ- Changes for CAPE-865 - begin
          if (!bDisplayUIPrompt) {
            // KCOption has be KohlsPOCConstant.MAX_REFUND always.
            String kcOption = KohlsPOCConstant.MAX_REFUND;
            callChangeOrderToUpdatePromotion(env, elePromotion, "Y", sKohlsCashReduction, kcOption,
                tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
            // PLYT-1420 start
           //Skip calling for V2 - callingSource - V2Unearn
            if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) && YFCCommon.isVoid(callingSource)) {
              logger.error(
                  "KohlsReturnsKCDeactivation.deactivateKohlsCash : KC is not unearn on current Promotion "
                      + sUnprocessedExtnCouponSourceCode
                      + "but more Promotion is to be processed. Hence initiaing the call again");
              Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
                  KohlsPOCConstant.E_PROMOTIONS, true);
              elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
              orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
                  df.format(dRefundAmount));
              XMLUtil.importElement(eleInPromotions, elePromotion);
              KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
              return obj.deactivateKohlsCash(env, orderInDoc);
            }
            // PLYT-1420 end
            // CAPE 1296 for all scenario
            if (!YFCCommon.isVoid(elePromotionKCR)) {
              if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                  && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                outDoc = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
              }
            }
            
            // If its V2 Call, then return outDoc = inDoc
            if(!YFCCommon.isVoid(callingSource)){
              logger.debug("Its Post redemption. So promotion is updated via changeOrder call");
              outDoc = (Document)orderInDoc.cloneNode(true);
            }
            // CAPE 1296
            outDoc.getDocumentElement().setAttribute("MorePromotionsToProcess",
                sMorePromotionsToProcess);
            return outDoc;
          }
          // MJ 01/25 Changes for 1565 - end
          Element elePromotionMaxRefund =
              XMLUtil.createChild(elePromotion, KohlsPOCConstant.MAX_REFUND);
          elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dRefundAmount));
          elePromotionMaxRefund.setAttribute("RefundAmountWithoutTax",
              df.format(dRefundAmountWithoutTax));
          elePromotionMaxRefund.setAttribute(KohlsPOCConstant.UNEARNED_KC, sKohlsCashReduction);
          // call to tvs when RefundDeduction > 0 (partial KC
          // Redemption scenario)
          Element eleMRRefundDeduction =
              XMLUtil.getChildElement(eleMaximizeRefund, KohlsPOCConstant.REF_DEDUCTION);
          String strMRRefundDeduction = XMLUtil.getNodeValue(eleMRRefundDeduction);
          elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REF_DEDUCTION, strMRRefundDeduction);
          dMRRefundDeduction = Double.parseDouble(strMRRefundDeduction);
          //Skip calling for V2 - callingSource - V2Unearn
          if (dMRRefundDeduction > 0.0  && YFCCommon.isVoid(callingSource)) {
            try {
              callTVSAndUpdateOrderDocument(env, kcsResponseDoc, tempOrderEle, eleMRRefundDeduction,
                  "MaximizeRefund", outDoc, dRefundAmountWithoutTax, elePromotionMaxRefund,
                  eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE));
            } catch (Exception ex) {
            	  logger.error("Exception in KohlsReturnsKCDeactivation.callTVSAndUpdateOrderDocument -- > "+ex.getMessage());
              Document docErrorOut =
                  prepareOutputForError(sOrderHeaderKey, ex.getMessage(), dRefundAmount);
              // CAPE 1296
              if (!YFCCommon.isVoid(elePromotionKCR)) {
                if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                    && sMorePromotionsToProcess.equals("N")) {
                  docErrorOut = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
                }
              }
              docErrorOut.getDocumentElement().setAttribute("MorePromotionsToProcess",
                  sMorePromotionsToProcess);
              return docErrorOut;
            }
          }
        }
      } else {
        Element eleMaximizeRefund =
            XMLUtil.getChildElement(eleDeactivationOptions, KohlsPOCConstant.MAX_REFUND);
        if (!YFCCommon.isVoid(eleMaximizeRefund)) {
          // MJ 01/25 Changes for 1565 - begin
          Element eleKohlsCashReduction =
              XMLUtil.getChildElement(eleMaximizeRefund, KohlsPOCConstant.KC_REDUCTION);
          String sKohlsCashReduction = XMLUtil.getNodeValue(eleKohlsCashReduction);
          Element eleMRRefundDeduction =
              XMLUtil.getChildElement(eleMaximizeRefund, KohlsPOCConstant.REF_DEDUCTION);
          String strMRRefundDeduction = XMLUtil.getNodeValue(eleMRRefundDeduction);
          if (!YFCCommon.isVoid(sKohlsCashReduction) && !YFCCommon.isVoid(strMRRefundDeduction)) {
            Double dKohlsCashReduction = Double.parseDouble(sKohlsCashReduction);
            dMRRefundDeduction = Double.parseDouble(strMRRefundDeduction);
            if (dKohlsCashReduction == 0.00D && dMRRefundDeduction == 0.00D) {
              String kcOption = KohlsPOCConstant.MAX_REFUND;
              callChangeOrderToUpdatePromotion(env, elePromotion, "Y", sKohlsCashReduction,
                  kcOption, tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
              // PLYT-1420 start
              //Skip calling for V2 - callingSource - V2Unearn
              if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) && YFCCommon.isVoid(callingSource)) {
                logger.error(
                    "KohlsReturnsKCDeactivation.deactivateKohlsCash : KC is not unearn on current Promotion "
                        + sUnprocessedExtnCouponSourceCode
                        + "but more Promotion is to be processed. Hence initiaing the call again");
                Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
                    KohlsPOCConstant.E_PROMOTIONS, true);
                elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
                orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
                    df.format(dRefundAmount));
                XMLUtil.importElement(eleInPromotions, elePromotion);
                KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
                return obj.deactivateKohlsCash(env, orderInDoc);
              }
              if (!YFCCommon.isVoid(elePromotionKCR)) {
                if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                    && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                  orderInDoc = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
                }
              }
              
              // If its V2 Call, then return outDoc = inDoc
              if(!YFCCommon.isVoid(callingSource)){
                logger.debug("Its Post redemption. So promotion is updated via changeOrder call");
                outDoc = (Document)orderInDoc.cloneNode(true);
              }
              
              // PLYT-1420 end
              orderInDoc.getDocumentElement().setAttribute("MorePromotionsToProcess",
                  sMorePromotionsToProcess);
              return orderInDoc;
            }
          }
          // If No UI promot to be displayed then call changeOrder
          // MJ 02/07- Updated for CAPE 1681 - Begin
          Double dExtnInitialOfferAmt = Double.parseDouble(sExtnInitialOfferAmt);
          if (!bDisplayUIPrompt && !("ACTIVE".equalsIgnoreCase(strRedemptionPeriod)
              && dTotalNetPrice <= (dExtnInitialOfferAmt - dKohlsCashBalance))) {
            // KCOption has be KohlsPOCConstant.MAX_REFUND always.
            String kcOption = KohlsPOCConstant.MAX_REFUND;
            // PLYT-1015 set the KC option selected for tibco in
            // order to unearn coupon
            if ("POSTREDEMPTION".equalsIgnoreCase(strRedemptionPeriod) && dAmtToBeUnearned > 0) {
              if (bDisplayUIPrompt) {
                kcOption = KohlsPOCConstant.MAX_REFUND;
              }
              // more PLYT-1015 update
              elePromotionExtn =
                  XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, true);
              elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_TRAN_UNEARNED_VALUE,
                  sKohlsCashReduction);
              elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ELIGIBILITY_DEDUCTION,
                  sKohlsCashReduction);
            }
            callChangeOrderToUpdatePromotion(env, elePromotion, "Y", sKohlsCashReduction, kcOption,
                tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
            // PLYT-1420 start
            // Skip calling for V2 - callingSource - V2Unearn
            if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) && YFCCommon.isVoid(callingSource)) {
              logger.error(
                  "KohlsReturnsKCDeactivation.deactivateKohlsCash : KC is not unearn on current Promotion "
                      + sUnprocessedExtnCouponSourceCode
                      + "but more Promotion is to be processed. Hence initiaing the call again");
              Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
                  KohlsPOCConstant.E_PROMOTIONS, true);
              elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
              orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
                  df.format(dRefundAmount));
              XMLUtil.importElement(eleInPromotions, elePromotion);
              KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
              return obj.deactivateKohlsCash(env, orderInDoc);
            }
            // CAPE 1296 for all scenario
            if (!YFCCommon.isVoid(elePromotionKCR)) {
              if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                  && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                orderInDoc = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
              }
            }
            
            // If its V2 Call, then return outDoc = inDoc
            if(!YFCCommon.isVoid(callingSource)){
              logger.debug("Its Post redemption. So promotion is updated via changeOrder call");
              outDoc = (Document)orderInDoc.cloneNode(true);
            }
            
            // PLYT-1420 end
            // CAPE 1296
            orderInDoc.getDocumentElement().setAttribute("MorePromotionsToProcess",
                sMorePromotionsToProcess);
            return orderInDoc;
          }
          // MJ 02/07- Updated for CAPE 1681 - End
          // For post redemption if nothing is redeemed then dont show
          // UI.
          if ("POSTREDEMPTION".equalsIgnoreCase(strRedemptionPeriod)) {
            if (Double.compare(dKohlsCashBalance, dAmtToBeUnearned) >= 0) {
              
             /* elePromotion = this.updateOutputDocPromotion(env, elePromotion, "Y",
                  sKohlsCashReduction, KohlsPOCConstant.MAX_REFUND);*/
              
              callChangeOrderToUpdatePromotion(env, elePromotion, "N",sKohlsCashReduction, KohlsPOCConstant.MAX_REFUND,
                  tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
              
              // CAPE 1296 for all scenario
              // PLYT-1420 start
              //Skip calling for V2 - callingSource - V2Unearn
              if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) &&YFCCommon.isVoid(callingSource)) {
                logger.error(
                    "KohlsReturnsKCDeactivation.deactivateKohlsCash : KC is not unearn on current Promotion "
                        + sUnprocessedExtnCouponSourceCode
                        + "but more Promotion is to be processed. Hence initiaing the call again");
                Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
                    KohlsPOCConstant.E_PROMOTIONS, true);
                elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
                orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
                    df.format(dRefundAmount));
                XMLUtil.importElement(eleInPromotions, elePromotion);
                KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
                return obj.deactivateKohlsCash(env, orderInDoc);
              }
              // PLYT-1420 end
              if (!YFCCommon.isVoid(elePromotionKCR)) {
                if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                    && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                  outDoc = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
                }
              }
              
              // If its V2 Call, then return outDoc = inDoc
              if(!YFCCommon.isVoid(callingSource)){
                logger.debug("Its Post redemption. So promotion is updated via changeOrder call");
                outDoc = (Document)orderInDoc.cloneNode(true);
              }
              // CAPE 1296
              outDoc.getDocumentElement().setAttribute("MorePromotionsToProcess",
                  sMorePromotionsToProcess);
              return outDoc;
            }
          }
          // MJ 01/25 Changes for 1565 - end
          Element elePromotionMaxRefund =
              XMLUtil.createChild(elePromotion, KohlsPOCConstant.MAX_REFUND);
          elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dRefundAmount));
          elePromotionMaxRefund.setAttribute("RefundAmountWithoutTax",
              df.format(dRefundAmountWithoutTax));
          elePromotionMaxRefund.setAttribute(KohlsPOCConstant.UNEARNED_KC, sKohlsCashReduction);
          elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REF_DEDUCTION, strMRRefundDeduction);
          // call to tvs when RefundDeduction > 0 (partial KC
          // Redemption scenario)
          dMRRefundDeduction = Double.parseDouble(strMRRefundDeduction);
        //Skip calling for V2 - callingSource - V2Unearn
          if (dMRRefundDeduction > 0.0 && YFCCommon.isVoid(callingSource)) {
            try {
              callTVSAndUpdateOrderDocument(env, kcsResponseDoc, tempOrderEle, eleMRRefundDeduction,
                  "MaximizeRefund", outDoc, dRefundAmountWithoutTax, elePromotionMaxRefund,
                  eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE));
            } catch (Exception ex) {
              Document docErrorOut = (Document) orderInDoc.cloneNode(true);
              // CAPE 1296
              if (!YFCCommon.isVoid(elePromotionKCR)) {
                if (!YFCCommon.isVoid(sMorePromotionsToProcess)
                    && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
                  docErrorOut = updateOutputDocWithKCR(docErrorOut, elePromotionKCR);
                }
              }
              return docErrorOut;
            }
          }
        }
      }
      logger.debug("Output of method deactivateKohlsCash ::" + XMLUtil.getXMLString(outputDoc));
      logger.debug("Output of method deactivateKohlsCash ::" + XMLUtil.getXMLString(orderInDoc));
      logger.endTimer("KohlsReturnsKCDeactivation.deactivateKohlsCash");
      // CAPE 1296
      if (!YFCCommon.isVoid(elePromotionKCR)
          && !(KohlsPOCConstant.KOHLS_CASH_REISSUE).equalsIgnoreCase(sPromoType)) {
        if (!YFCCommon.isVoid(sMorePromotionsToProcess)
            && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
          outDoc = updateOutputDocWithKCR(outDoc, elePromotionKCR);
        }
      }
      outDoc.getDocumentElement().setAttribute("MorePromotionsToProcess", sMorePromotionsToProcess);
      return outDoc;
    } else {
      // Calling changeOrder to Update promotion
      callChangeOrderToUpdatePromotion(env, elePromotion, "N", "0.00", "",
          tempOrderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
      // CAPE 1296
      // PLYT-1420 start
      //Skip calling for V2 - callingSource - V2Unearn
      if (KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(sMorePromotionsToProcess) && YFCCommon.isVoid(callingSource)) {
        logger.error(
            "KohlsReturnsKCDeactivation.deactivateKohlsCash : Kohls Cash is not unearn on current Promotion "
                + sUnprocessedExtnCouponSourceCode
                + " but more Promotion is to be processed. Hence initiaing the call again");
        Element eleInPromotions = XMLUtil.getChildElement(orderInDoc.getDocumentElement(),
            KohlsPOCConstant.E_PROMOTIONS, true);
        elePromotion.setAttribute("IsProcessed", KohlsPOCConstant.FLAG_Y);
        orderInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.REFUND_AMT,
            df.format(dRefundAmount));
        XMLUtil.importElement(eleInPromotions, elePromotion);
        KohlsReturnsKCDeactivation obj = new KohlsReturnsKCDeactivation();
        return obj.deactivateKohlsCash(env, orderInDoc);
      }
      // PLYT-1420 end
      Document docErrorOut = null;
      if (!YFCCommon.isVoid(elePromotionKCR)) {
        if (!YFCCommon.isVoid(sMorePromotionsToProcess)
            && sMorePromotionsToProcess.equalsIgnoreCase("N")) {
          docErrorOut = updateOutputDocWithKCR(orderInDoc, elePromotionKCR);
        } else {
          docErrorOut = (Document) orderInDoc.cloneNode(true);
        }
      } else {
        docErrorOut = (Document) orderInDoc.cloneNode(true);
      }
      // CAPE 1296
      docErrorOut.getDocumentElement().setAttribute("MorePromotionsToProcess",
          sMorePromotionsToProcess);
      logger.debug("No Kohls Cash unearned on the order");
      logger.endTimer("KohlsReturnsKCDeactivation.deactivateKohlsCash");
      return docErrorOut;
    }
  }
  // CAPE 1297 start

  private Document getOrderList(YFSEnvironment env, Document orderInDoc) throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCDeactivation.getOrderList");
	  Document docGetOrderListOuput=null;
	  // Forming the input document for getOrderList API Call.
	    Document docGetOrderListInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
	    Element eleOrderInput = docGetOrderListInput.getDocumentElement();
	    if (!YFCCommon.isVoid(sOrderHeaderKey)) {
	      eleOrderInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
	      try {
	        String sTemplateName = "/global/template/api/POC/kohlscashunearning/POC_getOrderList.xml";
	        env.setApiTemplate(KohlsPOCConstant.GET_ORDER_LIST, sTemplateName);
	        // PA changes for ISS - start
	        if (ServerTypeHelper.amIOnEdgeServer()) {
	          if (!YFCCommon.isVoid(sExtnPOCFeature)
	              && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
	            Element eleAdditionalInfo = SCXmlUtil.createChild(
	                docGetOrderListInput.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
	            eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
	                KohlsXMLLiterals.V_MOTHERSHIP);
	          }
	        }
	        // PA changes for ISS - end
	        if (logger.isDebugEnabled()) {
	          logger.debug(
	              "Inside KohlsReturnsKCDeactivation.deactivateKohlsCash getOrderList api input is: "
	                  + XMLUtil.getXMLString(docGetOrderListInput));
	        }
	        docGetOrderListOuput =
	            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_LIST, docGetOrderListInput);
	        env.clearApiTemplate(KohlsPOCConstant.GET_ORDER_LIST);
	        if (logger.isDebugEnabled()) {
	          logger.debug(
	              "Inside KohlsReturnsKCDeactivation.deactivateKohlsCash getOrderList api output is: "
	                  + XMLUtil.getXMLString(docGetOrderListOuput));
	        }
	      } catch (Exception e1) {
	        logger.error("Exception when calling getOrderList service" + e1.getMessage());
	      }
	    } else {
	      logger.error("OrderHeaderKey is null in the input xml");
	      return orderInDoc;
	    }
	    
	    logger.endTimer("KohlsReturnsKCDeactivation.getOrderList");
	return docGetOrderListOuput;
}

/**
   * 
   * @param env
   * @param orderInDoc
   * @return
   * @throws Exception
   */
  public Document doPromotionOverride(YFSEnvironment env, Document orderInDoc) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.doPromotionOverride");
    logger.debug("KohlsReturnsKCDeactivation.doPromotionOverride orderInDoc="
        + XMLUtil.getXMLString(orderInDoc));
    String sRuleValue = "";
    double dRuleValue = 0;
    String sOverrideAdjustmentValue = "";
    double dOverrideAdjustmentValue = 0;
    // CAPE-1801 Defect fix
    boolean isChangeOrderReqd = false;
    // CAPE-1801 Defect fix end
    Document docRuleListForPOS = callGetRuleListForPOS(env);
    if (!YFCCommon.isVoid(docRuleListForPOS)) {
      NodeList nlRuleListFosOS = docRuleListForPOS.getElementsByTagName("Rule");
      Element eleRule = (Element) nlRuleListFosOS.item(0);
      if (!YFCCommon.isVoid(eleRule)) {
        sRuleValue = eleRule.getAttribute("RuleValue");
        dRuleValue = Double.parseDouble(sRuleValue);
      }
    }
    Element elePromotionKCR = SCXmlUtil.getXpathElement(orderInDoc.getDocumentElement(),
        "//Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_REISSUE']");
    if (!YFCCommon.isVoid(elePromotionKCR)) {
      String sPromotionApplied = elePromotionKCR.getAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED);
      if ("Y".equalsIgnoreCase(sPromotionApplied)) {
        sOverrideAdjustmentValue = elePromotionKCR.getAttribute("OverrideAdjustmentValue");
        dOverrideAdjustmentValue = Double.parseDouble(sOverrideAdjustmentValue);
        if (dOverrideAdjustmentValue < dRuleValue) {
          logger.debug("dOverrideAdjustmentValue is less than dRuleValue");
          // CAPE-1801 Defect fix
          isChangeOrderReqd = true;
          // CAPE-1801 Defect fix end
          elePromotionKCR.setAttribute("OverrideAdjustmentValue", sRuleValue);
        }
      }
    }
    logger.debug("KohlsReturnsKCDeactivation.doPromotionOverride orderOutDoc="
        + XMLUtil.getXMLString(orderInDoc));
    // CAPE-1801 Defect fix Calling changeOrder API to update
    // OverrideAdjustmentValue at Promotion
    // level
    /*
     * if (isChangeOrderReqd) { orderInDoc.getDocumentElement().setAttribute(
     * KohlsConstant.A_ACTION, KohlsPOCConstant.ACTION_MODIFY);
     * orderInDoc.getDocumentElement().setAttribute( KohlsConstant.ATTR_OVERRIDE,
     * KohlsConstant.YES); Document docChangeOrderTemplate = XMLUtil .getDocument(
     * "<Order OrderHeaderKey=''/>"); KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate,
     * KohlsConstant.CHANGE_ORDER_API, orderInDoc); }
     */
    // CAPE-1801 Defect fix end
    logger.endTimer("KohlsReturnsKCDeactivation.doPromotionOverride");
    return orderInDoc;
  }

  private Document callGetRuleListForPOS(YFSEnvironment env) throws DOMException, Exception {
    // TODO Auto-generated method stub
    logger.beginTimer("KohlsReturnsKCDeactivation.callGetRuleListForPOS");
    Document docRuleListForPOSOutput = null;
    Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
    Element eleRuleMetadata = docInput.createElement("RuleMetadata");
    eleRuleMetadata.setAttribute("GroupName", "RKC_ADJ_VALUE");
    eleInput.appendChild(eleRuleMetadata);
    logger.debug("KohlsReturnsKCDeactivation.callGetRuleListForPOS docInput="
        + XMLUtil.getXMLString(docInput));
    docRuleListForPOSOutput =
        KOHLSBaseApi.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
    logger.debug("KohlsReturnsKCDeactivation.callGetRuleListForPOS docRuleListForPOSOutput="
        + XMLUtil.getXMLString(docRuleListForPOSOutput));
    logger.endTimer("KohlsReturnsKCDeactivation.callGetRuleListForPOS");
    return docRuleListForPOSOutput;
  }

  // CAPE 1297 End
  /**
   * Create By mrjoshi *
   * 
   * @param elePromotion
   * @throws Exception
   */
  public Document callChangeOrderToUpdatePromotion(YFSEnvironment env, Element elePromo,
      String sPromotionApplied, String sAmt, String sKCOption, String sOrderHeaderKey)
      throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.callChangeOrderToUpdatePromotion");
    Document docChangeOrderInput = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    Element eleOrder = docChangeOrderInput.getDocumentElement();
    eleOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
    eleOrder.setAttribute(KohlsXMLLiterals.A_ACTION, "MODIFY");
    eleOrder.setAttribute(KohlsConstant.ATTR_OVERRIDE, KohlsConstant.YES);
    Element elePromotions = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
    elePromotions.setAttribute("IsProcessed", "Y");
    Element elePromotion = XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
    if (!YFCCommon.isVoid(sKCOption)) {
      Element elePromotionMaxRefund = XMLUtil.createChild(elePromotion, sKCOption);
      elePromotionMaxRefund.setAttribute(KohlsPOCConstant.UNEARNED_VALUE, strAmtToBeUnearned);
      elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, sAmt);
    }
    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_KEY,
        elePromo.getAttribute(KohlsPOCConstant.A_PROMOTION_KEY));
    if (!YFCCommon.isVoid(sPromotionApplied)) {
      elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, sPromotionApplied);
    }
    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE,
        KohlsPOCConstant.KOHLS_CASH_UNEARNED);
    elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, sAmt);
    Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, true);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_UNEARNED_VALUE, sAmt);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION,
        Double.toString(KohlsPOCConstant.ZERO_DBL));
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, sKCOption);
    // MJ 01/24: Added for CAPE 1605 - begin
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REASON_CODE, strRedemptionPeriod);
    // MJ 01/24: added for CAPE 1605 - end
    // MJ 01/26 Added for CAPE 1615 - begin
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, strEligibleAmt);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE, strAmtToBeUnearned);
    // PLYT-1360 changes start
    Element eleOrderPromotionsExtn = XMLUtil.getChildElement(elePromo, KohlsXMLLiterals.E_EXTN);
    String sExtnCouponSourceCode =
        eleOrderPromotionsExtn.getAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE);
    if (!YFCCommon.isVoid(sExtnCouponSourceCode)) {
      elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE,
          sExtnCouponSourceCode);
    }
    // PLYT-1360 changes end
    // MJ 01/26 Added for CAPE 1615 - end
    // Element elePromotion_Temp = (Element)
    // docChangeOrderInput.importNode(elePromotion, true);
    // elePromotions.appendChild(elePromotion_Temp);
    if (logger.isDebugEnabled()) {
      logger.debug("PostRedemption scenario encountered. Calling changeOrder with input xml: \n"
          + XMLUtil.getXMLString(docChangeOrderInput));
    }
    // setting env object to skip the Repricing UE call.
    env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
    // Setting minimum template for changeOrder api output
    // PA changes for ISS - start
    if (ServerTypeHelper.amIOnEdgeServer()) {
      if (!YFCCommon.isVoid(sExtnPOCFeature)
          && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
        Element eleAdditionalInfo = SCXmlUtil.createChild(
            docChangeOrderInput.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
            KohlsXMLLiterals.V_MOTHERSHIP);
      }
    }
    // PA changes for ISS - end
    
    Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
    KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API,
        docChangeOrderInput);
    logger.endTimer("KohlsReturnsKCDeactivation.callChangeOrderToUpdatePromotion");
    return docChangeOrderInput;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param kcsResponseDoc2
   * @param tempOrderEle
   * @param eleMKCRefundDeduction
   * @param string
   * @throws Exception
   */
  private void callTVSAndUpdateOrderDocument(YFSEnvironment env, Document kcsResponseDoc,
      Element tempOrderEle, Element eleRefundDeduction, String sKCOption, Document outDoc,
      double dRefundAmount, Element elePromotion, String sExtnSourceCode) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.callTVSAndUpdateOrderDocument");
    Document firstTVSResponseForMKCDoc =
        firstTVSObj.prepareRequestForFirstTVSCall(env, kcsResponseDoc, tempOrderEle,
            eleRefundDeduction, strOrigStoreNo, sOrigTerminalID, sOrigTranNo);
    boolean bErrorsInTVS = checkForTVSResponseErrors(firstTVSResponseForMKCDoc);
    if (bErrorsInTVS) {
      logger.debug("Errors in TVS response, Please proceed with tendering!!");
      throw new YFSException(sTVSErrorMessage);
    }
    if (logger.isDebugEnabled()) {
      logger.debug("TVS output is:  " + XMLUtil.getXMLString(firstTVSResponseForMKCDoc));
    }
    // Setting RefundAmount and LineCharge on the orderLine
    addRefundDeductionCharges(env, firstTVSResponseForMKCDoc, outDoc, elePromotion, sKCOption,
        tempOrderEle, sExtnSourceCode);
    logger.endTimer("KohlsReturnsKCDeactivation.callTVSAndUpdateOrderDocument");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param sOrderHeaderKey
   * @return
   * @throws ParserConfigurationException
   */
  private Document prepareOutputForError(String sOrderHeaderKey, String sErrorDesc,
      Double dRefundAmount) throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCDeactivation.prepareOutputForError");
    DecimalFormat df = new DecimalFormat("0.00");
    // Creating Document in case of errors
    Document docErrorOut = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    Element OrderElement = docErrorOut.getDocumentElement();
    OrderElement.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
    OrderElement.setAttribute(KohlsXMLLiterals.A_PROCEED_WITH_TENDERING, KohlsConstant.YES);
    OrderElement.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT, df.format(dRefundAmount));
    OrderElement.setAttribute(KohlsXMLLiterals.A_ERR_DESC, sErrorDesc);
    logger.endTimer("KohlsReturnsKCDeactivation.prepareOutputForError");
    return docErrorOut;
  }

  // CAPE 1296 begin
  private Document prepareKCROutputForError(String sOrderHeaderKey, String sErrorDesc,
      Double dRefundAmount, Element elePromotionIn) throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCDeactivation.prepareOutputForError");
    DecimalFormat df = new DecimalFormat("00.00");
    // Creating Document in case of errors
    Document docErrorOut = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    Element OrderElement = docErrorOut.getDocumentElement();
    OrderElement.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
    OrderElement.setAttribute(KohlsXMLLiterals.A_PROCEED_WITH_TENDERING, KohlsConstant.YES);
    OrderElement.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT, df.format(dRefundAmount));
    Element elePromotions = docErrorOut.createElement(KohlsPOCConstant.E_PROMOTIONS);
    OrderElement.appendChild(elePromotions);
    Element elePromotionOut = (Element) docErrorOut.importNode(elePromotionIn, true);
    elePromotions.appendChild(elePromotionOut);
    OrderElement.setAttribute(KohlsXMLLiterals.A_ERR_DESC, sErrorDesc);
    logger.endTimer("KohlsReturnsKCDeactivation.prepareOutputForError");
    return docErrorOut;
  }

  private Document updateOutputDocWithKCR(Document outDoc, Element elePromotionIn)
      throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCDeactivation.updateOutputDocWithKCR");
    outDoc.getDocumentElement().setAttribute("MorePromotionsToProcess", sMorePromotionsToProcess);
    NodeList nlPromotions = outDoc.getElementsByTagName(KohlsPOCConstant.E_PROMOTIONS);
    Element elePromotions = null;
    if (!YFCCommon.isVoid(nlPromotions) && nlPromotions.getLength() > 0) {
      elePromotions = (Element) nlPromotions.item(0);
    } else {
      elePromotions = outDoc.createElement(KohlsPOCConstant.E_PROMOTIONS);
      outDoc.getDocumentElement().appendChild(elePromotions);
    }
    Element elePromotionOut = (Element) outDoc.importNode(elePromotionIn, true);
    elePromotions.appendChild(elePromotionOut);
    outDoc.getDocumentElement().setAttribute("RefundAmount", new DecimalFormat("#0.00").format(dRefundAmount));
    logger.endTimer("KohlsReturnsKCDeactivation.updateOutputDocWithKCR");
    return outDoc;
  }

  // CAPE 1296 end
  /**
   * Create By mrjoshi *
   * 
   * @param tempOrderEle
   * @return
   * @throws ParserConfigurationException
   * @throws ParseException
   */
  public Document prepareKCRequestWithHeaderData(Element tempOrderEle)
      throws ParserConfigurationException, ParseException {
    logger.beginTimer("KohlsReturnsKCDeactivation.prepareKCRequestWithHeaderData");
    SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
    strDocumentType = tempOrderEle.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
    // strStoreNo =
    // tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
    // sTerminalID =
    // tempOrderEle.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
    // sTranNo =
    // tempOrderEle.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
    sBusinessDate = tempOrderEle.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
    sOperatorID = tempOrderEle.getAttribute(KohlsPOCConstant.A_OPERATOR_ID);
    sOrderDate = sdf.format(sdf.parse(tempOrderEle.getAttribute(KohlsPOCConstant.A_ORDER_DATE)));
    Element eleOrderExtn =
        (Element) tempOrderEle.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
    if (eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE)
        .equalsIgnoreCase("PriceAdjustment")) {
      sReceiptID = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_PA_RECEIPT_ID);
    } else {
      sReceiptID = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID);
    }
    // Creating the KCS request document.
    Document kcsRequestDoc =
        XMLUtil.createDocument(KohlsXMLLiterals.E_DETERMINE_KOHLS_CASH_DEACTIVATION_REQUEST_MSG);
    Element eleKCRequestRoot = kcsRequestDoc.getDocumentElement();
    // header element construction -starts
    Element eleHeader = XMLUtil.createChild(eleKCRequestRoot, KohlsConstant.HEADER);
    // MJ 01/26: Updated for CAPE 148 - begin
    setString(KohlsConstant.STORE, eleHeader, strCurrentStoreNo);
    setString(KohlsConstant.TERMINAL, eleHeader, sCurrentTerminalID);
    setString(KohlsConstant.TRANS_NUM, eleHeader, sCurrentTranNo);
    // MJ: 01/26: Updated for CAPE 148 - end
    setString(KohlsConstant.BUSINESS_DATE, eleHeader, sBusinessDate);
    setString(KohlsConstant.ASSO_ID, eleHeader, sOperatorID);
    setString(KohlsConstant.TRAN_START_DATE, eleHeader, sOrderDate);
    setString(KohlsConstant.TRAINING_MODE, eleHeader, KohlsPOCConstant.CONST_FALSE);
    // header element construction -ends
    logger.endTimer("KohlsReturnsKCDeactivation.prepareKCRequestWithHeaderData");
    return kcsRequestDoc;
  }

  /**
   * @param secondTVSResponseDoc
   * @throws NumberFormatException
   */
  public Double calculateTempOrderPrice(Document secondTVSResponseDoc)
      throws NumberFormatException {
    logger.beginTimer("KohlsReturnsKCDeactivation.calculateTempOrderPrice");
    logger.debug(
        "Input to method calculateTempOrderPrice ::" + XMLUtil.getXMLString(secondTVSResponseDoc));
    Double dTempOrderTotal = 0.0;
    Element eleAdjustmentResponse = secondTVSResponseDoc.getDocumentElement();
    List<Element> tvsItmList =
        XMLUtil.getElementsByTagName(eleAdjustmentResponse, KohlsPOCConstant.ELEM_SMALL_ITEM);
    if (tvsItmList.size() > KohlsPOCConstant.ZERO_INT) {
      for (Element item : tvsItmList) {
        String strNetPrice = item.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
        Element eleLineTaxes = XMLUtil.getChildElement(item, KohlsXMLLiterals.E_LINE_TAXES);
        NodeList nlItemTax = eleLineTaxes.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
        Double dTotalLineTax = 0.0;
        for (int i = 0; i < nlItemTax.getLength(); i++) {
          Element eleLineTax = (Element) nlItemTax.item(i);
          String strTax = eleLineTax.getAttribute("tax");
          // TVS is sending some stores tax and some stores Tax Begin
          if (YFCCommon.isStringVoid(strTax)) {
            strTax = eleLineTax.getAttribute("Tax");
          }
          // TVS is sending some stores tax and some stores Tax End
          if (!YFCCommon.isStringVoid(strTax)) {
            dTotalLineTax = dTotalLineTax + Double.parseDouble(strTax);
          }
        }
        dTempOrderTotal = dTempOrderTotal + Double.parseDouble(strNetPrice) + dTotalLineTax;
      }
    }
    logger.debug("TVS response,Temp OrderTotal is: " + dTempOrderTotal);
    logger.endTimer("KohlsReturnsKCDeactivation.calculateTempOrderPrice");
    return dTempOrderTotal;
  }

  /**
   * @param tvsResponseDoc
   * @throws YFSException
   */
  public boolean checkForTVSResponseErrors(Document tvsResponseDoc) throws YFSException {
    logger.beginTimer("KohlsReturnsKCDeactivation.checkForTVSResponseErrors");
    logger
        .debug("Input to method checkForTVSResponseErrors" + XMLUtil.getXMLString(tvsResponseDoc));
    Boolean bIsError = false;
    Element tvsResponseEle = tvsResponseDoc.getDocumentElement();
    // Checking for SOAP fault
    if (tvsResponseEle.getTagName().equalsIgnoreCase(KohlsPOCConstant.E_ERRORS)) {
      bIsError = true;
      YFSException yfsException = new YFSException();
      String errorCodeStr = XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
          .getAttribute(KohlsPOCConstant.E_ERRORCODE);
      String errorDesc = XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
          .getAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION);
      if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr)) {
        yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
        yfsException.setErrorDescription(errorDesc);
      } else if (KohlsPOCConstant.OFFER_END_DATE_PASSED.equalsIgnoreCase(errorCodeStr)) {
        yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
        if (!YFCCommon
            .isStringVoid(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID))) {
          yfsException.setErrorDescription(
              KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID));
        }
      } else {
        yfsException.setErrorCode(errorCodeStr);
        yfsException.setErrorDescription(errorDesc);
      }
      if (!"OFFER_END_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
        yfsException.setErrorDescription(errorDesc);
      }
      throw yfsException;
    }
    logger.endTimer("KohlsReturnsKCDeactivation.checkForTVSResponseErrors");
    return bIsError;
  }

  /**
   * 
   * @param outDocKohlsCashWebService
   * @param OrderElement
   * @return
   * @throws ParserConfigurationException
   */
  public Document validateKohlsCashResponseErrors(Document outDocKohlsCashWebService,
      Double dRefundAmount, boolean omsKcEnabled) throws ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCDeactivation.validateKohlsCashResponseErrors");
    // If there is any error in KCS Response, Set the boolean true
    Document docKCValidationOut = null;
    
    if(outDocKohlsCashWebService == null) {
		docKCValidationOut = prepareOutputForError(sOrderHeaderKey,
		          "Kohls Cash web service output doc was null ", dRefundAmount);
	    return docKCValidationOut;
    }
    
    Element eleKCSResponse = outDocKohlsCashWebService.getDocumentElement();
    if (KohlsConstant.E_ERRORS.equalsIgnoreCase(eleKCSResponse.getNodeName())) {
      docKCValidationOut = prepareOutputForError(sOrderHeaderKey, sErrorMessage, dRefundAmount);
      return docKCValidationOut;
    }
    Element dataElement;
    try {
    	if(omsKcEnabled) {
    		dataElement = XMLUtil.getChildElement(eleKCSResponse, "Data");
    	}
    	else {
    		dataElement = KohlsXPathUtil.getElementByXpath(outDocKohlsCashWebService,
    		          "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data");
    	}
      
      String unEarnedKCSValue = "";
      String authResponseCode = "";
      String redemptionPeriod = "";
      /*
       * Element unEarnedEle = XMLUtil.getChildElement(dataElement,
       * KohlsPOCConstant.UNEARNED_VALUE); if (!YFCCommon.isVoid(unEarnedEle)) { unEarnedKCSValue =
       * XMLUtil.getNodeValue(unEarnedEle); Double dEarnedKCSValue =
       * Double.parseDouble(unEarnedKCSValue); if (dEarnedKCSValue == 0) { docKCValidationOut =
       * prepareOutputForError(sOrderHeaderKey, sKCUnearnedMessage, dRefundAmount); return
       * docKCValidationOut; } }
       */
      Element authResponseCodeEle =
          XMLUtil.getChildElement(dataElement, KohlsPOCConstant.AUTH_RES_CODE);
      if (!YFCCommon.isVoid(authResponseCodeEle)) {
        authResponseCode = XMLUtil.getNodeValue(authResponseCodeEle);
      }
      Element redemptionPeriodEle =
          XMLUtil.getChildElement(dataElement, KohlsPOCConstant.REDEMPTION_PERIOD);
      if (!YFCCommon.isVoid(redemptionPeriodEle)) {
        redemptionPeriod = XMLUtil.getNodeValue(redemptionPeriodEle);
      }
      Element DeactivationOptEle =
          XMLUtil.getChildElement(dataElement, KohlsPOCConstant.DEACTIVATION_OPTIONS);
      // TBD Page 77 KCS Design doc - Non-approval inquiry response
      if (authResponseCode.equals("7") && YFCCommon.isVoid(DeactivationOptEle)) {
        docKCValidationOut =
            prepareOutputForError(sOrderHeaderKey, "Non-approval inquiry response", dRefundAmount);
        return docKCValidationOut;
      }
      // TBD Page 78 KCS Design doc - Non-approval inquiry response
      else if (redemptionPeriod.equals("NONE") && YFCCommon.isVoid(DeactivationOptEle)) {
        docKCValidationOut =
            prepareOutputForError(sOrderHeaderKey, "Event ID not found", dRefundAmount);
        return docKCValidationOut;
      }
      /*
       * else if (("ACTIVE".equals(redemptionPeriod) || "POSTREDEMPTION".equals(redemptionPeriod)))
       * { if ((sSysRepublicResponse.equals("03") || sSysRepublicResponse.equals("08")) ||
       * sSysRepublicResponse.equals("09")) { docKCValidationOut =
       * prepareOutputForError(sOrderHeaderKey, "Ignore Kohls cash rules", dRefundAmount); return
       * docKCValidationOut; } }
       */
    } catch (Exception e) {
      logger.error("Exception at KohlsReturnsKCDeactivation.validateKohlsCashResponseErrors"
          + e.getStackTrace());
      docKCValidationOut = prepareOutputForError(sOrderHeaderKey,
          "UnRecorgnized error. Please check the logs for more details ", dRefundAmount);
      return docKCValidationOut;
    }
    logger.endTimer("KohlsReturnsKCDeactivation.validateKohlsCashResponseErrors");
    return docKCValidationOut;
  }

  /**
   * This method is called to add Total Net Price for KohlsCashElegible Items
   * 
   * @param eleReturnableItemList
   * @param dNetPriceTotal
   * @return
   * @throws NumberFormatException
   * @throws TransformerException
   * @throws ParserConfigurationException
   */
  public Double calculateNetPrice(Element eleReturnableItemList, Double dNetPriceTotal)
      throws NumberFormatException, TransformerException, ParserConfigurationException {
    logger.beginTimer("KohlsReturnsKCDeactivation.calculateNetPrice");
    List<Element> returnableItemList =
        XMLUtil.getElementsByTagName(eleReturnableItemList, KohlsXMLLiterals.E_RETURNABLE_ITEM);
    if (returnableItemList.size() > KohlsPOCConstant.ZERO_INT) {
      for (Element returnableItem : returnableItemList) {
        Element eleNetPrice = XMLUtil.getChildElement(returnableItem, KohlsPOCConstant.A_NET_PRICE);
        Element eleKohlsCashEligible =
            XMLUtil.getChildElement(returnableItem, KohlsXMLLiterals.E_KOHLS_CASH_ELIGIBLE);
        String strNetPrice = XMLUtil.getNodeValue(eleNetPrice);
        String strKohlsCashEligible = XMLUtil.getNodeValue(eleKohlsCashEligible);
        if (!YFCCommon.isVoid(strNetPrice)) {
          if (strKohlsCashEligible.equals(KohlsXMLLiterals.CONST_TRUE)) {
            dNetPriceTotal = dNetPriceTotal + Double.parseDouble(strNetPrice);
          }
        }
      }
    }
    logger.debug("calculateNetPrice: TotalNetPrice:" + dNetPriceTotal);
    logger.endTimer("KohlsReturnsKCDeactivation.calculateNetPrice");
    return dNetPriceTotal;
  }

  /**
   * @param env
   * @param tvsResponse
   * @param outDoc
   * @throws Exception
   */
  /**
   * @param env
   * @param tvsResponse
   * @param outDoc
   * @throws Exception
   */
  private void addRefundDeductionCharges(YFSEnvironment env, Document tvsResponse, Document outDoc,
      Element elePromotion, String sKCOption, Element tempOrderEle, String sExtnSourceCode)
      throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.addRefundDeductionCharges");
    DecimalFormat df = new DecimalFormat("0.00");
    // dRefundAmount = this.dRefundAmount_Temp;
    Double dLineTax = 0.00;
    Double dNetPrice = 0.00;
    Double dTempOrderTotal = 0.0;
    Double dTempOrderTotalWithoutTax = 0.0;
    Element orderEle = outDoc.getDocumentElement();
    Element eleProRatedLines = XMLUtil.getChildElement(orderEle, "ProRatedLines", true);
    Element eleOrderLines = XMLUtil.createChild(eleProRatedLines, KohlsXMLLiterals.E_ORDER_LINES);
    // Setting this attribute to retain the proration done for
    // MaximizeRefund when
    // refundDeduction > 0 i.e. partial KC redemption scenario.
    eleOrderLines.setAttribute("OrderLinesForKCOption", sKCOption);
    eleOrderLines.setAttribute("OrderLinesForPromotion", sUnprocessedExtnCouponSourceCode);
    Element tvsResEle = tvsResponse.getDocumentElement();
    NodeList itemsNL = tvsResEle.getElementsByTagName("item");
    if (itemsNL.getLength() > 0) {
      for (int i = 0; i < itemsNL.getLength(); i++) {
        Element tempItemEle = (Element) itemsNL.item(i);
        String sID = tempItemEle.getAttribute("id");
        Element eleOrderLine = XMLUtil.createChild(eleOrderLines, KohlsXMLLiterals.E_ORDER_lINE);
        Element eleOrderLineExtn = XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_EXTN);
        eleOrderLine.setAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO, sID);
        eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO,
            KohlsPOCConstant.A_SUB_LINE_NO);
        eleOrderLine.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.MODIFY);
        Element eleOriginalOrderLine = (Element) XPathUtil.getNode(tempOrderEle,
            "//OrderLines/OrderLine[@PrimeLineNo='" + sID + "']");
        Double totalAdjFee = KohlsPOCConstant.ZERO_DBL;
        NodeList nlFees = tempItemEle.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
        if (!YFCCommon.isVoid(nlFees) && nlFees.getLength()>0) {
        	for(int f=0; f<nlFees.getLength(); f++){
        		Element eleFees = ((Element) nlFees.item(f));
        		String strCalculatedAmount = XMLUtil.getAttribute(eleFees, KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
        		if(!YFCCommon.isVoid(strCalculatedAmount)){
        			totalAdjFee = totalAdjFee + Double.valueOf(strCalculatedAmount);
        		}
        	}
        }
        
        // KC unearning for price adjustment
        if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
          Element eleOriginalOrderLineCustomAttr =
              XMLUtil.getChildElement(eleOriginalOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
          Element eleOriginalOrderLineExtn =
              XMLUtil.getChildElement(eleOriginalOrderLine, KohlsPOCConstant.E_EXTN);
          String sNetPriceOriginal = eleOriginalOrderLineCustomAttr.getAttribute("Text12");
          String sTaxablePriceOriginal = eleOriginalOrderLineCustomAttr.getAttribute("Text14");
          String sStoreOriginal = eleOriginalOrderLineCustomAttr.getAttribute("Text7");
          String sNetPriceCurrent =
              eleOriginalOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
          String sTaxablePriceCurrent =
              eleOriginalOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
          if (!YFCCommon.isVoid(sNetPriceOriginal)) {
            Double dNetPriceOriginal = Double.parseDouble(sNetPriceOriginal);
            Double dNetPriceCurrent = Double.parseDouble(sNetPriceCurrent);
            String sNetPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
            String sReturnPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_RETURN_PRICE);
            String sBasisAmt = "";
            if(tempItemEle.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX).getLength()>0) {
              Element eleTVSLineTaxExtn = XMLUtil.getChildElement((Element)tempItemEle.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX).item(0), KohlsPOCConstant.E_EXTN);
              if(!YFCCommon.isVoid(eleTVSLineTaxExtn)) {
                sBasisAmt = eleTVSLineTaxExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
              }
            }
            String sTaxablePrice = "";
            if(!YFCCommon.isVoid(sBasisAmt)) {
              sTaxablePrice = sBasisAmt;
            } else {
              tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
            }
            if (!YFCCommon.isVoid(sNetPrice)) {
              dNetPrice = Double.parseDouble(sNetPrice);
              // Double dTVSNetPrice =
              // Double.parseDouble(sNetPrice);
              Double dKCProratedNetPrice = Double.parseDouble(sNetPriceOriginal) - (dNetPrice + dNetPriceCurrent);
              eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE,
                  df.format(dKCProratedNetPrice));
            }
            if (!YFCCommon.isVoid(sReturnPrice)) {
              Double dTVSReturnPrice = Double.parseDouble(sReturnPrice);
              Double dKCProratedReturnPrice = Double.parseDouble(sNetPriceOriginal) - (dTVSReturnPrice + dNetPriceCurrent);
              eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE,
                  df.format(dKCProratedReturnPrice));
            }
            if (!YFCCommon.isVoid(sTaxablePrice)) {
              Double dTaxablePriceOriginal = Double.parseDouble(sTaxablePriceOriginal);
              Double dTaxablePriceCurrent = Double.parseDouble(sTaxablePriceCurrent);
              Double dTVSTaxablePrice = Double.parseDouble(sTaxablePrice);
              Double dKCProratedTaxablePrice = dTaxablePriceOriginal - (dTVSTaxablePrice + dTaxablePriceCurrent);
              eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT,
                  df.format(dKCProratedTaxablePrice));
            }
          }
          Element eleLineTaxes =
              (Element) tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
          NodeList lineTaxNL = tempItemEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
          if (!YFCCommon.isVoid(lineTaxNL)) {
            Element eleLineTaxTVS = ((Element) lineTaxNL.item(0));
            String strlineTax = eleLineTaxTVS.getAttribute(KohlsXMLLiterals.A_TAX);
            dLineTax = Double.parseDouble(strlineTax);
            // CAPE-4251 - retaining Ecom tax rate changes
            Element eleCustomAttributes = (Element) eleOriginalOrderLine
                    .getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
            String sEComOrderNo = "";
            if (!YFCCommon.isVoid(eleCustomAttributes)) {
               sEComOrderNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT13);
            }
            //CPE-12427 changes
            if (!YFCCommon.isVoid(sEComOrderNo)) {
              Double dTaxRate = mapOrigtaxRate.get(sStoreOriginal);
              String sTaxablePriceFromTVS =
                  tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
              dLineTax = Double.parseDouble(sTaxablePriceFromTVS) * dTaxRate / 100;
              Element eleLineTax = ((Element) lineTaxNL.item(0));
              strlineTax = new DecimalFormat("#0.00").format(dLineTax);
              eleLineTax.setAttribute(KohlsXMLLiterals.A_TAX, strlineTax);
              eleLineTax.setAttribute("LineTotalTax", strlineTax);
              eleLineTax.setAttribute("LineTotalTaxRate",
                  new DecimalFormat("#0.00").format(dTaxRate));
              eleLineTax.setAttribute("TaxPercentage", new DecimalFormat("#0.00").format(dTaxRate));
            }
            Element eleOriginalOrderLineTax = (Element) eleOriginalOrderLine
                .getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX).item(0);
            String sCurrentTax = eleOriginalOrderLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
            Element eleOriginalOrderLineTaxExtn =
                XMLUtil.getChildElement(eleOriginalOrderLineTax, KohlsPOCConstant.E_EXTN);
            String sExtnOrigTaxAmt = eleOriginalOrderLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
            if (!YFCCommon.isVoid(sExtnOrigTaxAmt)) {
              Double dDeltaTax = Double.parseDouble(sExtnOrigTaxAmt) - (dLineTax + Double.parseDouble(sCurrentTax));
              eleLineTaxTVS.setAttribute(KohlsXMLLiterals.A_TAX, df.format(dDeltaTax));
              Element eleLineTaxTVSExtn =
                  XMLUtil.getChildElement(eleLineTaxTVS, KohlsPOCConstant.E_EXTN, true);
              eleLineTaxTVSExtn.setAttribute("ExtnOrigTaxAmt", sExtnOrigTaxAmt);
            }
            Element eleLineTaxes_Temp = (Element) outDoc.importNode(eleLineTaxes, true);
            eleLineTaxes_Temp.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
            eleOrderLine.appendChild(eleLineTaxes_Temp);
          }
          Element eleOrigLineCharges = XMLUtil.getChildElement(eleOriginalOrderLine, "LineCharges");
          if (!YFCCommon.isVoid(eleOrigLineCharges)) {
            eleOrderLine.appendChild(outDoc.importNode(eleOrigLineCharges, true));
          }
        //deduct the Orig Fee amt with the Fee after PA, so the remaing fee is corresponding to 
          // refund amt.
          NodeList nlFee = tempItemEle.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
          if (!YFCCommon.isVoid(nlFee)) {
            for (int index = 0; index < nlFee.getLength(); index++) {
                Element eleFee = (Element) nlFee.item(index);
                NodeList nlCharges  = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
                if(!YFCCommon.isVoid(nlCharges) && nlCharges.getLength()>0){
                    for (int iCharge = 0; iCharge < nlCharges.getLength(); iCharge++) {
                        Element eleCharge = (Element) nlCharges.item(iCharge);
                        if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))
                                && eleFee.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION).equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME))){
                          Element eleChargeExtn = XMLUtil.getChildElement(eleCharge, KohlsPOCConstant.E_EXTN);
                          String sOrigFeeAmt = eleChargeExtn.getAttribute("ExtnOrigChgPerLine");
                            String sFeeAmt = eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
                            Double deltaFee = Double.parseDouble(sOrigFeeAmt) - (Double.parseDouble(sFeeAmt) + Double.parseDouble(eleCharge.getAttribute("ChargePerLine")));
                            //eleChargeExtn.setAttribute("ExtnOrigChgPerLine",  df.format(Double.parseDouble(sOrigFeeAmt) - Double.parseDouble(eleCharge.getAttribute("ChargePerLine"))));
                            double dNewFeeBasisAmt = Double.parseDouble(eleChargeExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT)) 
                                + Double.parseDouble(eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_BASIS_AMOUNT)); 
                            eleChargeExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, df.format(dNewFeeBasisAmt));
                            eleChargeExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_EXEMPT_AMOUNT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_EXEMPT_AMOUNT));
                            eleChargeExtn.setAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_RATE_FEE));
                            eleCharge.setAttribute( KohlsPOCConstant.A_CHARGE_PER_LINE, df.format(deltaFee));
                            eleCharge.setAttribute( KohlsPOCConstant.ATTR_CHARGE_AMNT,  df.format(deltaFee));
                            eleCharge.setAttribute( "InvoicedChargeAmount", sFeeAmt);
                        }
                    }
                }
            }
          }
              
         // KohlsPoCPnPUtil.updateKCDTaxFee(eleOrderLine,tempItemEle,"Returns",KohlsPOCConstant.BLANK);
        } else {
          Element eleCustomAttributes = (Element) eleOriginalOrderLine
              .getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
          String sOriginalStoreId = "";
          String sEComOrderNo = "";
          if (!YFCCommon.isVoid(eleCustomAttributes)) {
            sOriginalStoreId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
            sEComOrderNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT13);
          }
          String sNetPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
          String sReturnPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_RETURN_PRICE);
          String sProratedNetPrice = tempItemEle.getAttribute("proratedNetPriceDiscountAmt");
          String sTaxablePrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, sNetPrice);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE, sReturnPrice);
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, sTaxablePrice);
          dNetPrice = Double.parseDouble(sNetPrice);
          // dNetPrice = Double.parseDouble(sProratedNetPrice);
          Element eleLineTaxes =
              (Element) tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
          NodeList lineTaxNL = tempItemEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
          if (!YFCCommon.isVoid(lineTaxNL)) {
        	Element eleLineTax = ((Element) lineTaxNL.item(0));
          	Element eleExtnLineTax = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
          	String strExtnBasisAmount = XMLUtil.getAttribute(eleExtnLineTax, KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
          	if(!YFCCommon.isVoid(strExtnBasisAmount)){
          		eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, strExtnBasisAmount);
          	}
            String strlineTax = "";
            // CAPE-4251 - retaining Ecom tax rate changes
            if (!YFCCommon.isVoid(sEComOrderNo)) {
              Double dTaxRate = mapOrigtaxRate.get(sOriginalStoreId);
              dLineTax = Double.parseDouble(sReturnPrice) * dTaxRate / 100;
              //Element eleLineTax = ((Element) lineTaxNL.item(0));
              strlineTax = new DecimalFormat("#0.00").format(dLineTax);
              eleLineTax.setAttribute(KohlsXMLLiterals.A_TAX, strlineTax);
              eleLineTax.setAttribute("LineTotalTax", strlineTax);
              eleLineTax.setAttribute("LineTotalTaxRate",
                  new DecimalFormat("#0.00").format(dTaxRate));
              eleLineTax.setAttribute("TaxPercentage", new DecimalFormat("#0.00").format(dTaxRate));
            } else {
              strlineTax = ((Element) lineTaxNL.item(0)).getAttribute(KohlsXMLLiterals.A_TAX);
              dLineTax = Double.parseDouble(strlineTax);
            }
            Element eleLineTaxes_Temp = (Element) outDoc.importNode(eleLineTaxes, true);
            eleLineTaxes_Temp.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
            eleOrderLine.appendChild(eleLineTaxes_Temp);
          }
          KohlsPoCPnPUtil.updateKCDTaxFee(eleOrderLine,tempItemEle,"Returns",KohlsPOCConstant.BLANK);
        }
        // changes for cape 1575 - Begin
        // MJ 02/02 Changes for CAPE 1654 - Begin
        // dTempOrderTotal = dTempOrderTotal + (dNetPrice + dLineTax);
	Double finalNetPrice = Double.valueOf(df.format(dNetPrice + totalAdjFee));
        if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
          if (mapLinePrice.containsKey(sID)) {
            mapLinePrice.remove(sID);

          mapLinePrice.put(sID, (finalNetPrice + Double.parseDouble(new DecimalFormat("#0.00").format(dLineTax))));
          }
        } else {
          if (mapLinePrice.containsKey(sID)) {
            mapLinePrice.remove(sID);
          mapLinePrice.put(sID, (finalNetPrice + Double.parseDouble(new DecimalFormat("#0.00").format(dLineTax))));

        }
        }
        // MJ 02/02 Changes for CAPE 1654 - Begin
        // MJ 02/02 changes for CAPE 1654 - End
        // changes for cape 1575 - end
        NodeList nlModifier = tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_MODIFIER);
        if (!YFCCommon.isVoid(nlModifier) && nlModifier.getLength() > 0) {
          Element eleModifier = (Element) nlModifier.item(0);
          Element eleLineCharges =
              XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_LINE_CHARGES, true);
          String sNetPriceDelta = eleModifier.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE_DELTA);
          Double dNetPriceDelta = Math.abs(Double.parseDouble(sNetPriceDelta));
          Element eleLineCharge =
              XMLUtil.createChild(eleLineCharges, KohlsXMLLiterals.E_LINE_CHARGE);
          eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY,
              KohlsPOCConstant.KC_UNEARNED);
          eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_NAME, KohlsPOCConstant.KC_UNEARNED);
          eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE,
              String.valueOf(dNetPriceDelta));
          eleLineCharge.setAttribute(KohlsXMLLiterals.A_IS_DISCOUNT, KohlsPOCConstant.NO);
        }
      }
    }
    // MJ 02/02 Changes for CAPE 1654 - Begin
    // Calculating final refund amount
    // if
    // (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature))
    // {
    for (String id : mapLinePrice.keySet()) {
      dTempOrderTotal = dTempOrderTotal + mapLinePrice.get(id);
    }
    // MJ 02/02 Changes for CAPE 1654 - End
    if (!KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature)) {
      dTempOrderTotal = dRefundAmount_Temp + dTempOrderTotal;
    }
    elePromotion.setAttribute(KohlsPOCConstant.REFUND_AMT,
        new DecimalFormat("#0.00").format(dTempOrderTotal));
    // changes for cape 1575 - Begin
    elePromotion.setAttribute("RefundAmountWithoutTax",
        new DecimalFormat("#0.00").format(dTempOrderTotalWithoutTax));
    // changes for cape 1575 - end
    logger.endTimer("KohlsReturnsKCDeactivation.addRefundDeductionCharges");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param tagName
   * @param element
   * @param sValue
   */
  private static void setString(String tagName, Element parentElement, String sValue) {
    logger.beginTimer("KohlsReturnsKCDeactivation.setString");
    Element temp = XMLUtil.createChild(parentElement, tagName);
    temp.setTextContent(sValue);
    logger.endTimer("KohlsReturnsKCDeactivation.setString");
  }

  /**
   * Stamp Attributes using changeOrder when KCS is offline Created By tkmai3r
   * 
   * @param env
   * @param elePromotion
   * @param strOrderHeaderKey
   * @throws Exception
   */
  public void stampOfflineAttributesInChangeOrder(YFSEnvironment env, Element elePromotion,
      String strOrderHeaderKey) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.stampOfflineAttributesInChangeOrder");
    Document inputChangeOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    Element eleOrder = inputChangeOrderDoc.getDocumentElement();
    eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
    eleOrder.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsPOCConstant.YES);
    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
    Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_OFFLINE_MODE, KohlsPOCConstant.YES);
    Element elePromotions = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
    elePromotions.appendChild(inputChangeOrderDoc.importNode(elePromotion, true));
    // setting env object to skip the Repricing UE call.
    env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
    KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API, inputChangeOrderDoc);
    logger.endTimer("KohlsReturnsKCDeactivation.stampOfflineAttributesInChangeOrder");
  }

  /**
   * This function is used to get the value for a property
   * 
   * @param property name in string format
   * @return String propValue
   */
  public String getPropertyValue(String property) {
    logger.beginTimer("KohlsReturnsKCDeactivation.getPropertyValue");
    String propValue;
    propValue = YFSSystem.getProperty(property);
    // Manoj 10/22: updated to use configured property if
    // customer_overrides.properties does not return any value
    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    logger.endTimer("KohlsReturnsKCDeactivation.getPropertyValue");
    return propValue;
  }

  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */
  public void setProperties(Properties prop) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.setProperties");
    this.props = prop;
    logger.debug("In the set properties method");
    logger.endTimer("KohlsReturnsKCDeactivation.setProperties");
  }

  /**
   * Sterling OOB getCommonCodeList call to get list of special SKUs
   * 
   * @param env
   * @return
   * @throws Exception
   */
  protected Document getCommonCodeListForSpecialSKU(YFSEnvironment env) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.getCommonCodeListForSpecialSKU");
    Document docInputgetCommonCodeList = XMLUtil.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
    Element eleCommonCode = docInputgetCommonCodeList.getDocumentElement();
    eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
        KohlsPOCConstant.VAL_KOHLS_SPL_ITEMS_RET);
    Document docCommonCodeListOuput = KOHLSBaseApi.invokeAPI(env,
        KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docInputgetCommonCodeList);
    logger.endTimer("KohlsReturnsKCDeactivation.getCommonCodeListForSpecialSKU");
    return docCommonCodeListOuput;
  }

  /**
   * List object preparation which contains special SKUs
   * 
   * @param docCommonCodeListOuput
   * @return
   */
  @SuppressWarnings("rawtypes")
  protected List getSpecialSKU(Document docCommonCodeListOuput) {
    logger.beginTimer("KohlsReturnsKCDeactivation.getSpecialSKU");
    List<String> specialSKUlist = new ArrayList<String>();
    NodeList commonCodeNL =
        docCommonCodeListOuput.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
    int commonCodeNLlen = commonCodeNL.getLength();
    for (int i = 0; i < commonCodeNLlen; i++) {
      Element eleCommonCode = (Element) commonCodeNL.item(i);
      specialSKUlist.add(eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE));
    }
    logger.endTimer("KohlsReturnsKCDeactivation.getSpecialSKU");
    return specialSKUlist;
  }

  /** 
   * @param eleOrder
   * @param sExtnCouponSrcCode
   */
  void setMorePromotionAttribute(Element eleOrder, String sExtnCouponSrcCode) {
    logger.beginTimer("KohlsReturnsKCDeactivation.setMorePromotionAttribute");
    int mapsize = 0;
    Element elePromotions = (Element) eleOrder.getElementsByTagName("Promotions").item(0);
    if (!YFCCommon.isVoid(elePromotions)) {
      NodeList ndlPromotion = elePromotions.getElementsByTagName("Promotion");
      for (int i = 0; i < ndlPromotion.getLength(); i++) {
        Element elePromotion = (Element) ndlPromotion.item(i);
        Element elePromotionExtn = (Element) elePromotion.getElementsByTagName("Extn").item(0);
        if (elePromotion.getAttribute("PromotionType").equalsIgnoreCase("KOHLS_CASH_UNEARNED")
            && elePromotion.getAttribute("IsProcessed").equalsIgnoreCase("Y")) {
          mapPromotionGravity.put(elePromotionExtn.getAttribute("ExtnCouponSourceCode"),
              elePromotion.getAttribute("PromotionId"));
        }
        if (elePromotion.getAttribute("PromotionType").equalsIgnoreCase("KOHLS_CASH_UNEARNED")) {
          mapPromotionOrder.put(elePromotionExtn.getAttribute("ExtnCouponSourceCode"),
              elePromotion.getAttribute("PromotionId"));
        }
      }
      if (!YFCCommon.isVoid(sExtnCouponSrcCode)) {
        if (mapPromotionOrder.containsKey(sExtnCouponSrcCode)) {
          mapsize = mapPromotionOrder.size() - 1;
        }
      }
      if (mapsize == mapPromotionGravity.size()) {
        sMorePromotionsToProcess = "N";
      } else {
        sMorePromotionsToProcess = "Y";
      }
    }
    logger.endTimer("KohlsReturnsKCDeactivation.setMorePromotionAttribute");
  }

  /** 
   * @param env
   * @param elePromo
   * @param sPromotionApplied
   * @param sAmt
   * @param sKCOption
   * @return
   */
  private Element updateOutputDocPromotion(YFSEnvironment env, Element elePromo,
      String sPromotionApplied, String sAmt, String sKCOption) {
    logger.beginTimer("KohlsReturnsKCDeactivation.updateOutputDocPromotion");
    if (!YFCCommon.isVoid(sKCOption)) {
      Element elePromotionMaxRefund = XMLUtil.createChild(elePromo, sKCOption);
      elePromotionMaxRefund.setAttribute(KohlsPOCConstant.UNEARNED_VALUE, strAmtToBeUnearned);
      elePromotionMaxRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, sAmt);
    }
    if (!YFCCommon.isVoid(sPromotionApplied)) {
      elePromo.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, sPromotionApplied);
    }
    elePromo.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, sAmt);
    elePromo.setAttribute("IsProcessed", "Y");
    logger.debug("KC Prompt will not be shown,setting IsProcessed as Y ");
    Element elePromotionExtn = XMLUtil.getChildElement(elePromo, KohlsPOCConstant.E_EXTN, true);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_UNEARNED_VALUE, sAmt);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION,
        Double.toString(KohlsPOCConstant.ZERO_DBL));
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, sKCOption);
    // MJ 01/24: Added for CAPE 1605 - begin
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REASON_CODE, strRedemptionPeriod);
    // MJ 01/24: added for CAPE 1605 - end
    // MJ 01/26 Added for CAPE 1615 - begin
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, strEligibleAmt);
    elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE, strAmtToBeUnearned);
    // MJ 01/26 Added for CAPE 1615 - end
    // Element elePromotion_Temp = (Element)
    // docChangeOrderInput.importNode(elePromotion, true);
    // elePromotions.appendChild(elePromotion_Temp);
    // setting env object to skip the Repricing UE call.
    // env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
    // Setting minimum template for changeOrder api output
    // Document docChangeOrderTemplate = XMLUtil.getDocument("<Order
    // OrderHeaderKey=''/>");
    // KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate,
    // KohlsConstant.CHANGE_ORDER_API,
    // docChangeOrderInput);
    logger.endTimer("KohlsReturnsKCDeactivation.updateOutputDocPromotion");
    return elePromo;
  }

  /**
   * @param ecommStoreLists
   * @param storeId
   * @return
   */
/*  private static boolean isEcommerceStore(List<String> ecommStoreLists, String storeId) {
    logger.beginTimer("KohlsReturnsKCDeactivation.isEcommerceStore");
    
      if (storeId.startsWith("0")) {
      storeId = storeId.substring(1, storeId.length());
    	}
     for (String ecomStoreId : ecommStoreLists) {
      if (ecomStoreId.equals(storeId)) {
        logger.endTimer("KohlsReturnsKCDeactivation.isEcommerceStore");
        return true;
      }
    } 
    logger.endTimer("KohlsReturnsKCDeactivation.isEcommerceStore");
    return false;
  }*/

  /** 
   * @param env
   * @return
   * @throws Exception
   */
  /*private static List<String> populateEcommStores(YFSEnvironment env) throws Exception {
    logger.beginTimer("KohlsReturnsKCDeactivation.populateEcommStores");
    List<String> ecommStoreLists = new ArrayList<String>();
    Document exDoc = KohlsPoCCommonAPIUtil.getCommonCodeList(env, "EComStores", "", "DEFAULT");
    if (exDoc != null) {
      NodeList commonCodeNodes =
          XPathUtil.getNodeList(exDoc.getDocumentElement(), "//CommonCodeList/CommonCode");
      if (commonCodeNodes != null) {
        String codeValue = null;
        for (int index = 0; index < commonCodeNodes.getLength(); index++) {
          Element commonCodeNode = (Element) commonCodeNodes.item(index);
          codeValue = commonCodeNode.getAttribute(KohlsConstant.A_CODE_VALUE);
          ecommStoreLists.add(codeValue);
        }
      }
    }
    logger.endTimer("KohlsReturnsKCDeactivation.populateEcommStores");
    return ecommStoreLists;
  }*/
}
