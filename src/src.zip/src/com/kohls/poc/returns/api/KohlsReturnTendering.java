/**
 * @author SA345825
 * 
 *         This Java class will calculate the Refund amount and split the refund amount among 4
 *         return tender types based on the tender hierarchy 1.Cash 2.Credit Card 3.Kohl's Charge
 *         4.KMC- Kohl's Merchandise credit.
 * 
 *         Sample Input XML
 *         <Order OrderHeaderKey="2016030919240426551" StoreNumber="430" MaximizeRefund="Y"
 *         MaximizeKohlsCash="Y" RefundAmount="100" UnearnedKohlsCash="5.00" > <PaymentMethods>
 *         <PaymentMethod PaymentType="CASH" Amount="30"/>
 *         <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="VISA" CreditCardNo="1245260120"
 *         Amount="20"/>
 *         <PaymentMethod PaymentType= "CREDIT_CARD" CreditCardType="MASTERCARD" CreditCardNo=
 *         "8464196593" Amount="5"/>
 *         <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="DISCOVER" CreditCardNo=
 *         "7849216326" Amount="10"/>
 *         <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="AMEX" CreditCardNo="4145936225"
 *         Amount="5"/> <PaymentMethod PaymentType="KOHLS_CHARGE_CARD" Amount="15"/>
 *         <PaymentMethod PaymentType="KMC" Amount="15"/> </PaymentMethods> </Order>
 *
 */
/**************************************************************************
 * File : KohlsReturnTendering.java Author : : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 11/03/2016
 *****************************************************************************/

package com.kohls.poc.returns.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.text.DecimalFormat;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.returns.api.KohlsPoCSysRepublic;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsReturnTendering extends KOHLSBaseApi {

  private static YFCLogCategory logger;
  // Changes for sending Correct Organization to POS Rules - Start
  String strOrgCode = "KOHLS-RETAIL";
  private Properties props;
  // Changes for sending Correct Organization to POS Rules - End

  static {
    logger = YFCLogCategory.instance(KohlsReturnTendering.class.getName());
  }

  /**
   * This Method is used to distribute the Refund amount among the tender types based on tender
   * limit and tender hierarchy.
   * 
   * @param yfsEnv
   * @param inputXML
   * @throws Exception
   */
  public Document distributeRefundAmount(YFSEnvironment yfsEnv, Document inputXML)
      throws Exception {
    logger.beginTimer("KohlsReturnTendering.distributeRefundAmount");
    // logger.debug("KohlsReturnTendering.distributeRefundAmount -- Start");
    logger.debug(
        "KohlsReturnTendering.distributeRefundAmount Input to method distributeRefundAmount :"
            + XMLUtil.getXMLString(inputXML));

    Document docRuleListForPOSOutput = null;
    Document docRuleListForTenderRoll = null;
    String strRefundAmount = "";
    String strUnearnedKohlsCash = "";
    DecimalFormat df = new DecimalFormat("#0.00");
    String strMaximizeRefund = "";
    String strMaximizeKohlsCash = "";
    String strOrderHeaderkey = "";
    String strStoreNumber = "";
    String strGiftFlag = "";
    String KMCThreshold = "";
    // Changes for sending Correct Organization to POS Rules - Start
    String strOrgCode = "KOHLS-RETAIL";
    // Changes for sending Correct Organization to POS Rules - End
    Element elePaymentMethod = null;
    double dRefundAmount = 0.0;
    double dKMCTenderLimit = 0.0;
    Boolean bAddToCash = false;

    // creating Output document
    Document docOutput = null;

    // Sequence the tender display
    // inputXML = sequencePaymentMethods(yfsEnv, inputXML);

    // Commented the integration
    Element eleOrderRoot = inputXML.getDocumentElement();
    Element eleOrderExtn = XMLUtil.getFirstElementByName(eleOrderRoot, KohlsPOCConstant.A_EXTN);
    String strPOCFeature = "";
    Element eleOrder = null;
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      strPOCFeature = eleOrderExtn.getAttribute("ExtnPOCFeature");
    }
    eleOrderRoot
        .removeChild(XMLUtil.getChildElement(eleOrderRoot, KohlsPOCConstant.E_PAYMENT_METHODS));
    XMLUtil.createChild(eleOrderRoot, KohlsPOCConstant.E_PAYMENT_METHODS);


    KohlsPoCSysRepublic pocSysRepublic = new KohlsPoCSysRepublic();
    String sLogToFile = "";
    String sFilePath = "";

    /*
     * try { logger.debug("Inside try block ::"); sLogToFile =
     * getPropertyValue(this.props.getProperty("LogSysRepToFile")); sFilePath =
     * getPropertyValue(this.props.getProperty("LogSysRepLogDir")); logger.debug(
     * "Log file Directory path " + sFilePath); logger.debug("is log sys republic to file " +
     * sLogToFile); } catch (Exception ex) { logger.debug("Inside catch block ::"); sLogToFile =
     * KohlsPOCConstant.NO; }
     */

    Document docOutTender = pocSysRepublic.getTenderDetails(yfsEnv, inputXML);
    if (logger.isDebugEnabled()) {
      logger.debug("Output From SysRepublic   ::" + XMLUtil.getXMLString(docOutTender));
    }
    Element eleTender = docOutTender.getDocumentElement();
    elePaymentMethod = KohlsXPathUtil.getElementByXpath(docOutTender,
        "Order/PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
    String sDLRequired = eleTender.getAttribute("DLRequired");
    if (YFCCommon.isVoid(sDLRequired)) {
      sDLRequired = "N";
    }
    String sProcessOfflineTendering = eleTender.getAttribute("ProcessOfflineTendering");
    if (YFCCommon.isVoid(sProcessOfflineTendering)) {
      sProcessOfflineTendering = "N";
    }
    if ("Y".equalsIgnoreCase(sProcessOfflineTendering) || "Y".equalsIgnoreCase(sDLRequired)
        || !YFCCommon.isVoid(elePaymentMethod)) {
      return docOutTender;
    } else {
      eleOrder = docOutTender.getDocumentElement();
    }

    // Element eleOrder = inputXML.getDocumentElement();
    if (!YFCCommon.isVoid(eleOrder)) {
      strGiftFlag = eleOrder.getAttribute(KohlsXMLLiterals.A_GIFT_FLAG);
      strRefundAmount = eleOrder.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
      if (!YFCCommon.isVoid(strRefundAmount)) {
        dRefundAmount = Double.parseDouble(strRefundAmount);
        logger.debug("PSA Refund Amount::" + dRefundAmount);
      }
      strUnearnedKohlsCash = eleOrder.getAttribute(KohlsXMLLiterals.A_UNEARNED_KOHLSCASH);
      strMaximizeRefund = eleOrder.getAttribute(KohlsXMLLiterals.A_MAXIMIZE_REFUND);
      strMaximizeKohlsCash = eleOrder.getAttribute(KohlsXMLLiterals.A_MAXIMIZE_KOHLS_CASH);
      strOrderHeaderkey = eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
      strStoreNumber = eleOrder.getAttribute(KohlsXMLLiterals.A_STORE_NUMBER);
      logger.debug("KohlsReturnTendering.distributeRefundAmount strUnearnedKohlsCash="
          + strUnearnedKohlsCash + " strMaximizeRefund=" + strMaximizeRefund
          + " strMaximizeKohlsCash=" + strMaximizeKohlsCash + " strOrderHeaderKey="
          + strOrderHeaderkey + " strStoreNumber=" + strStoreNumber);
      if (!YFCCommon.isVoid(strOrderHeaderkey)) {
        callChangeOrder(yfsEnv, strUnearnedKohlsCash, strMaximizeRefund, strMaximizeKohlsCash,
            strOrderHeaderkey);
      }

    }
    docOutput = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER).getDocument();
    Element eleOutputOrder = docOutput.getDocumentElement();
    if (!YFCCommon.isVoid(strOrderHeaderkey)) {
      eleOutputOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
    }

    Element eleOutputPaymentMethods = docOutput.createElement(KohlsXMLLiterals.E_PAYMENT_METHODS);
    eleOutputOrder.appendChild(eleOutputPaymentMethods);
    Element elePaymentMethods =
        XMLUtil.getFirstElementByName(eleOrder, KohlsXMLLiterals.E_PAYMENT_METHODS);
    if (!YFCCommon.isVoid(elePaymentMethods)) {
      NodeList nlPaymentMethod =
          elePaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
      // Handling infinite loop if there no payment method coming from
      // Gravity
      /*
       * if (nlPaymentMethod.getLength() == 0) { throw new
       * YFSException("No Payment method coming from Gravity."); }
       */

      while (dRefundAmount != 0) {
        logger.debug("KohlsReturnTendering.distributeRefundAmount inside while dRefundAmount="
            + dRefundAmount);
        Double dOrigRefundAmt = dRefundAmount;
        Double dTotalAmountDistOnPmnt = 0.00D;
        Element eleOutputPaymentMethod = null;
        for (int i = 0; i < nlPaymentMethod.getLength(); i++) {
          elePaymentMethod = (Element) nlPaymentMethod.item(i);
          logger.debug("KohlsReturnTendering.distributeRefundAmount current elePaymentMethod="
              + XMLUtil.getElementXMLString(elePaymentMethod));
          if (!YFCCommon.isVoid(elePaymentMethod)) {
            String strPaymentType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
            String strAmount = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT);

            if (!YFCCommon.isVoid(strAmount)) {
              dTotalAmountDistOnPmnt = dTotalAmountDistOnPmnt + Double.parseDouble(strAmount);
            }
            // MJ 03/27 - If refund amt < Paymentmethod Amt,
            if (Double.parseDouble(df.format(dRefundAmount)) < Double.parseDouble(strAmount)) {

              strAmount = strRefundAmount;
            }
            // Creating PaymentMethod element in the output XML
            eleOutputPaymentMethod = docOutput.createElement(KohlsXMLLiterals.E_PAYMENT_METHOD);

            // CAPE-4074 - start
            if (!YFCCommon.isVoid(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_Entry_Method))) {
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_Entry_Method,
                  elePaymentMethod.getAttribute(KohlsXMLLiterals.A_Entry_Method));
            }
            // CAPE-4074 - end
            Element eleKohlsPaymentList =
                (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

            if (!YFCCommon.isVoid(eleKohlsPaymentList)) {
              XMLUtil.importElement(eleOutputPaymentMethod, eleKohlsPaymentList);

            }

            eleOutputPaymentMethods.appendChild(eleOutputPaymentMethod);
            eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
            if (KohlsConstant.PAYMENT_TYPE_CASH.equalsIgnoreCase(strPaymentType)) {
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                  KohlsConstant.PAYMENT_TYPE_CASH);
            } else if ("CORPORATE_REFUND".equalsIgnoreCase(strPaymentType)) {
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                  "CORPORATE_REFUND");
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE_GRP,
                  "CORPORATE_REFUND");

            } else if (KohlsConstant.PAYMENTTYPE_CREDIT_CARD.equalsIgnoreCase(strPaymentType)) {
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE_GRP,
                  KohlsConstant.PAYMENTTYPE_CREDIT_CARD);
              String strCreditCardType =
                  elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                  strCreditCardType);
              String strCreditCardNo =
                  elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
                  strCreditCardNo);
              if (elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE) != null) {
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
                    elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
              }
            }
            // CAPE - 263 --Start
            else if (KohlsConstant.PAYMENTTYPE_DEBIT_CARD.equalsIgnoreCase(strPaymentType)) {
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE_GRP,
                  KohlsConstant.PAYMENTTYPE_DEBIT_CARD);
              String strCreditCardType =
                  elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                  strCreditCardType);
              String strCreditCardNo =
                  elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
                  strCreditCardNo);
              if (elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE) != null) {
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
                    elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
              }
            }
            // CAPE - 263 --End
            else if (KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE.equalsIgnoreCase(strPaymentType)) {
              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                  KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE);

              eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE_GRP,
                  KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE);
              String strCreditCardNo =
                  elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
              if (!YFCCommon.isStringVoid(strCreditCardNo)) {
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
                    strCreditCardNo);
              }
              if (elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE) != null) {
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
                    elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
              }
            } else if (KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
                .equalsIgnoreCase(strPaymentType)) {

              // Call getRuleListForPOS to fetch the value of
              // KMC tender limit.

              // Changing the input to OrganizationCode from
              // StoreNo - Start
              /*
               * if (!YFCCommon.isVoid(strStoreNumber)) { docRuleListForPOSOutput =
               * callGetRuleListForPOS( yfsEnv, strStoreNumber);
               */

              if (!YFCCommon.isVoid(strOrgCode)) {
                // MJ 03/15- Changes for cape-2178 - begin
                // if (!"Y".equalsIgnoreCase(strGiftFlag)) {
                docRuleListForPOSOutput = callGetRuleListForPOS(yfsEnv, strOrgCode);
                logger.debug("KohlsReturnTendering.distributeRefundAmount docRuleListForPOSOutput="
                    + XMLUtil.getXMLString(docRuleListForPOSOutput));
                // }
                // MJ 03/15- Changes for cape-2178 - end
                // Changing the input to OrganizationCode
                // from StoreNo - End

                if (!YFCCommon.isVoid(docRuleListForPOSOutput)) {
                  // Checking if KMCRefundAmount is less
                  // than KMCTenderLimit
                  Element eleRuleList = docRuleListForPOSOutput.getDocumentElement();
                  if (!YFCCommon.isVoid(eleRuleList)) {
                    Element eleRule =
                        (Element) eleRuleList.getElementsByTagName(KohlsXMLLiterals.E_RULE).item(0);
                    if (!YFCCommon.isVoid(eleRule)) {
                      String strRuleValue = eleRule.getAttribute(KohlsXMLLiterals.A_RULE_VALUE);
                      if (!YFCCommon.isVoid(strRuleValue)) {
                        dKMCTenderLimit = Double.parseDouble(strRuleValue);

                        logger.debug("KohlsReturnTendering.distributeRefundAmount dRefundAmount="
                            + dRefundAmount + " dKMCTenderLimit=" + dKMCTenderLimit);
                        Double strAmountdouble = Double.parseDouble(strAmount);
                        if (strAmountdouble < dKMCTenderLimit) {

                          // Set the Flag true
                          bAddToCash = true;
                          KMCThreshold = "Y";
                          eleOutputPaymentMethods.removeChild(eleOutputPaymentMethod);
                          /**
                           * Adding KMC refund amount to Cash refund if KMC refund amount is less
                           * than KMCTenderLimit.
                           */
                          Element eleCashPaymentMethod = SCXmlUtil.getXpathElement(
                              eleOutputPaymentMethods, KohlsConstant.PAYMENT_METHOD_CASH);
                          if (!YFCCommon.isVoid(eleCashPaymentMethod)) {
                            String strCashRefundAmt =
                                eleCashPaymentMethod.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
                            if (!YFCCommon.isVoid(strCashRefundAmt)) {
                              rollupKMCIntoCASH(docOutput,Double.parseDouble(strCashRefundAmt),KohlsConstant.PAYMENT_METHOD_CASH);
                              Double dCashRefundAmt = Double.parseDouble(eleCashPaymentMethod.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT));
                              //Added KMC refund amount  with the cash amount to get total refund amount to return as cash
                              Double dFinalCashRefundAmt = dCashRefundAmt + dRefundAmount;
                              logger.debug(
                                  "KohlsReturnTendering.distributeRefundAmount dFinalCashRefundAmt="
                                      + dFinalCashRefundAmt + " dCashRefundAmt" + dCashRefundAmt
                                      + " dRefundAmount=" + dRefundAmount);
                              eleCashPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT,
                                  Double.toString(dFinalCashRefundAmt));
                            }
                            if (eleCashPaymentMethod != null) {
                              NodeList ndlKohlsPaymentCash =
                                  eleCashPaymentMethod.getElementsByTagName("KohlsPayment");
                              HashMap mapPaymentMethod = new HashMap();
                              for (int j = 0; j < ndlKohlsPaymentCash.getLength(); j++) {

                                Element eleKohlsPayment = (Element) ndlKohlsPaymentCash.item(j);
                                String sStore = eleKohlsPayment.getAttribute("StoreID");
                                String sTranNo = eleKohlsPayment.getAttribute("TranNo");
                                String sTerminalID = eleKohlsPayment.getAttribute("TerminalID");

                                String sCashRefundAmount =
                                    eleKohlsPayment.getAttribute("RefundAmount");
                                double dCashRefundmount = Double.parseDouble(sCashRefundAmount);
                                NodeList ndlKohlsPaymentKMC =
                                    eleKohlsPaymentList.getElementsByTagName("KohlsPayment");
                                for (int k = 0; k < ndlKohlsPaymentKMC.getLength(); k++) {

                                  Element eleKohlsPaymentkmc = (Element) ndlKohlsPaymentKMC.item(k);
                                  String sStoreKMC = eleKohlsPaymentkmc.getAttribute("StoreID");
                                  String sTranNoKMC = eleKohlsPaymentkmc.getAttribute("TranNo");
                                  String sTerminalIDKMC =
                                      eleKohlsPaymentkmc.getAttribute("TerminalID");
                                  // double dmount=0.0;
                                  /// =
                                  // Double.parseDouble(eleKohlsPaymentkmc.getAttribute("Amount"));
                                  String sKMCRefundmount =
                                      eleKohlsPaymentkmc.getAttribute("RefundAmount");
                                  double dKMCRefundmount = Double.parseDouble(sKMCRefundmount);

                                  if (sStoreKMC.equals(sStore) && sTranNoKMC.equals(sTranNo)
                                      && sTerminalID.equals(sTerminalIDKMC)) {
                                    String sPaymentConcat =
                                        sStoreKMC + "-" + sTerminalIDKMC + "-" + sTranNoKMC;
                                    mapPaymentMethod.put(sPaymentConcat, dKMCRefundmount);

                                    double tempAmount = dKMCRefundmount + dCashRefundmount;
                                    eleKohlsPayment.setAttribute("RefundAmount",
                                        String.valueOf(tempAmount));

                                  }



                                }

                              }
                              if (mapPaymentMethod.size() != eleKohlsPaymentList.getChildNodes()
                                  .getLength()) {
                                NodeList ndlKOhlsPaymentList =
                                    eleKohlsPaymentList.getElementsByTagName("KohlsPayment");

                                for (int k = 0; k < ndlKOhlsPaymentList.getLength(); k++) {
                                  Element eleKMCKohlsPayment =
                                      (Element) ndlKOhlsPaymentList.item(k);

                                  String sStoreKMC = eleKMCKohlsPayment.getAttribute("StoreID");
                                  String sTerminalIDKMC = eleKMCKohlsPayment.getAttribute("TranNo");
                                  String sTranNoKMC = eleKMCKohlsPayment.getAttribute("TerminalID");
                                  String sPaymentConcat =
                                      sStoreKMC + "-" + sTerminalIDKMC + "-" + sTranNoKMC;

                                  if (!mapPaymentMethod.containsKey(sPaymentConcat)) {
                                    Element eleCashKohlsPayment = (Element) eleCashPaymentMethod
                                        .getElementsByTagName("KohlsPaymentList").item(0);
                                    eleKMCKohlsPayment.setAttribute("PaymentType", "CASH");
                                    XMLUtil.importElement(eleCashKohlsPayment, eleKMCKohlsPayment);

                                  }

                                }

                              }


                            }

                          } else {

                            logger.debug("New changes for KMC in else block");

                            Element eleOutputPaymentMethodCash =
                                docOutput.createElement(KohlsXMLLiterals.E_PAYMENT_METHOD);
                            eleOutputPaymentMethods.appendChild(eleOutputPaymentMethodCash);
                            eleOutputPaymentMethodCash.setAttribute(
                                KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                                KohlsConstant.PAYMENT_TYPE_CASH);
                            eleOutputPaymentMethodCash
                                .setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT, strAmount);

                            if (!YFCCommon.isVoid(eleKohlsPaymentList)) {

                              NodeList ndlKOhlsPaymentList =
                                  eleKohlsPaymentList.getElementsByTagName("KohlsPayment");
                              for (int j = 0; j < ndlKOhlsPaymentList.getLength(); j++) {

                                Element eleKohlsPayment = (Element) ndlKOhlsPaymentList.item(j);
                                eleKohlsPayment.setAttribute("PaymentType",
                                    KohlsConstant.PAYMENT_TYPE_CASH);


                              }
                              XMLUtil.importElement(eleOutputPaymentMethodCash,
                                  eleKohlsPaymentList);

                            }

                          }
                        }
                      }
                    }
                  }
                }
              }
              if (!bAddToCash) {
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_TENDER_TYPE,
                    KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT);
              }
            }

            if (!YFCCommon.isVoid(strAmount)) {
              double dAmount = Double.parseDouble(strAmount);
              // Distributing refund amount among 4 return
              // tenders
              logger.debug("KohlsReturnTendering.distributeRefundAmount dRefundAmount="
                  + dRefundAmount + " dAmount=" + dAmount);
              if (dRefundAmount <= dAmount) {

                strRefundAmount = String.format("%.2f", dRefundAmount);
                strAmount = String.format("%.2f", dAmount);
                dRefundAmount = Double.parseDouble(strRefundAmount);
                dAmount = Double.parseDouble(strAmount);

                logger.debug("KohlsReturnTendering.distributeRefundAmount dRefundAmount="
                    + dRefundAmount + " dAmount=" + dAmount);
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT,
                    Double.toString(dRefundAmount));
                dRefundAmount = 0;
                break;
              } else {

                strRefundAmount = String.format("%.2f", dRefundAmount);
                strAmount = String.format("%.2f", dAmount);
                dRefundAmount = Double.parseDouble(strRefundAmount);
                dAmount = Double.parseDouble(strAmount);

                logger.debug("KohlsReturnTendering.distributeRefundAmount dRefundAmount="
                    + dRefundAmount + " dAmount=" + dAmount);
                eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT,
                    Double.toString(dAmount));
                dRefundAmount = dRefundAmount - dAmount;
              }
            } else {
              dRefundAmount = 0.0;
            }
          }
        }
        // Any deficit amount must go back on last tender. So adding
        // logic here (cape 1088)
        Double dDeficitAmt = dOrigRefundAmt - dTotalAmountDistOnPmnt;
        logger.debug("Deficit amount is: " + dDeficitAmt);
        if (dDeficitAmt > 0) {
          logger.debug(
              "Deficit amount is not zero. So refunding the deficit amount to last tender from RS");
          String sRefundAmt = eleOutputPaymentMethod.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
          eleOutputPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT,
              new DecimalFormat("#0.00").format(Double.parseDouble(sRefundAmt) + dDeficitAmt));
          dRefundAmount = 0.0;
        }
      }
    }

    NodeList paymentList = docOutput.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
    Element paymentMethodsElement =
        (Element) docOutput.getElementsByTagName("PaymentMethods").item(0);

    for (int i = 0; i < paymentList.getLength(); i++) {
      Element paymentElem = (Element) paymentList.item(i);
      if (Double.parseDouble(paymentElem.getAttribute("RefundAmount")) == 0) {
        paymentMethodsElement.removeChild(paymentElem);
        i--;
      }

    }
    // docOutput = sequencePaymentMethods(yfsEnv, docOutput);

    // To be uncommented with TenderRollUp Release -- Start
    docRuleListForTenderRoll = callGetRuleListForPOSTenderRoll(yfsEnv, strOrgCode);

    docOutput = tenderRollUp(yfsEnv, docOutput, docRuleListForTenderRoll);

    // To be uncommented with TenderRollUp Release -- End

    // Sequence the tender display
    // docOutput = sequencePaymentMethods(yfsEnv, docOutput);
    // Attribute to Enable and Disable Button
    docOutput.getDocumentElement().setAttribute("KmcThreshold", KMCThreshold);
    logger.debug(
        "KohlsReturnTendering.distributeRefundAmount docOutput=" + XMLUtil.getXMLString(docOutput));

    // logger.debug("KohlsReturnTendering.distributeRefundAmount -- Start");
    logger.endTimer("KohlsReturnTendering.distributeRefundAmount");
    return docOutput;
  }

  public Document tenderRollUp(YFSEnvironment yfsEnv, Document docOutput,
      Document docRuleListForTenderRoll) {
    logger.beginTimer("KohlsReturnTendering.tenderRollUp");
    String strRuleValue = KohlsPOCConstant.BLANK;
    String strUlRefundAmount = KohlsPOCConstant.BLANK;
    String strPenUlRefundAmount = KohlsPOCConstant.BLANK;
    Double dUlRefundAmount = 0.0;
    Double dPenUlRefundAmount = 0.0;
    Double dRuleValue = 0.0;
    int iTotalNo = 0;
    try {
      logger.debug("KohlsReturnTendering.tenderRollUp - Begin");
      logger.debug("KohlsReturnTendering.tenderRollUp docRuleListForTenderRoll ="
          + XMLUtil.getXMLString(docRuleListForTenderRoll));
      logger
          .debug("KohlsReturnTendering.tenderRollUp docOutput =" + XMLUtil.getXMLString(docOutput));
      if (!YFCCommon.isVoid(docRuleListForTenderRoll)) {
        Element eleRule = (Element) XPathUtil
            .getNodeList(docRuleListForTenderRoll.getDocumentElement(), "/RuleList/Rule").item(0);
        if (!YFCCommon.isVoid(eleRule)) {
          strRuleValue = eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE);

          if (!YFCCommon.isVoid(docOutput)) {
            NodeList ndlPaymentMethod = XPathUtil.getNodeList(docOutput.getDocumentElement(),
                "/Order/PaymentMethods/PaymentMethod");
            Element elePaymentMethods = (Element) XPathUtil
                .getNodeList(docOutput.getDocumentElement(), "/Order/PaymentMethods").item(0);
            if ((!YFCCommon.isVoid(ndlPaymentMethod)) && (!YFCCommon.isVoid(elePaymentMethods))) {
              iTotalNo = ndlPaymentMethod.getLength();
              logger.debug("KohlsReturnTendering.tenderRollUp TotalNo= " + iTotalNo);
              // CAPE-288: the rules will be called when the no.
              // of tenders is greater than 1.
              if (iTotalNo > 1) {
                Element eleUltimatePayment = (Element) ndlPaymentMethod.item(iTotalNo - 1);
                Element elePenUltimatePayment = (Element) ndlPaymentMethod.item(iTotalNo - 2);
                logger.debug("KohlsReturnTendering.tenderRollUp eleUltimatePayment= "
                    + XMLUtil.getElementXMLString(eleUltimatePayment));
                logger.debug("KohlsReturnTendering.tenderRollUp elePenUltimatePayment= "
                    + XMLUtil.getElementXMLString(elePenUltimatePayment));
                if ((!YFCCommon.isVoid(eleUltimatePayment))
                    && (!YFCCommon.isVoid(elePenUltimatePayment))) {
                  strUlRefundAmount =
                      eleUltimatePayment.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
                  strPenUlRefundAmount =
                      elePenUltimatePayment.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
                  logger.debug(
                      "KohlsReturnTendering.tenderRollUp strUlRefundAmount= " + strUlRefundAmount);
                  logger.debug("KohlsReturnTendering.tenderRollUp strPenUlRefundAmount= "
                      + strPenUlRefundAmount);

                  if ((!YFCCommon.isVoid(strPenUlRefundAmount))
                      && (!YFCCommon.isVoid(strUlRefundAmount))) {
                    dUlRefundAmount = Double.valueOf(strUlRefundAmount);
                    dPenUlRefundAmount = Double.valueOf(strPenUlRefundAmount);
                    dRuleValue = Double.valueOf(strRuleValue);

                    logger.debug("KohlsReturnTendering.tenderRollUp dUlRefundAmount= "
                        + dUlRefundAmount + " dPenUlRefundAmount= " + dPenUlRefundAmount
                        + " dRuleValue= " + dRuleValue);
                    if (dUlRefundAmount <= dRuleValue) {
                      updatePaymentMethodAndRefundAmt(docOutput, eleUltimatePayment,
                          elePenUltimatePayment);
                      dPenUlRefundAmount = dPenUlRefundAmount + dUlRefundAmount;
                      logger.debug("KohlsReturnTendering.tenderRollUp final dPenUlRefundAmount= "
                          + dPenUlRefundAmount);
                      elePenUltimatePayment.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT,
                          dPenUlRefundAmount.toString());
                      XMLUtil.removeChild(elePaymentMethods, eleUltimatePayment);
                    }
                  }
                }
              }
            }
          }

        }
      }
    } catch (Exception ex) {
      logger.debug(ex.getMessage());
    }
    logger.debug("KohlsReturnTendering.tenderRollUp docOutput= " + XMLUtil.getXMLString(docOutput));
    // logger.debug("KohlsReturnTendering.tenderRollUp - End");
    logger.endTimer("KohlsReturnTendering.tenderRollUp");
    return docOutput;
  }

  /**
   * This method is called to Update the value of KCD Coupon Code, UnearnedKohlsCash in the db.
   * 
   * @param yfsEnv
   * @param strUnearnedKohlsCash
   * @param strMaximizeRefund
   * @param strMaximizeKohlsCash
   * @param strOrderHeaderkey
   * @throws ParserConfigurationException
   * @throws DOMException
   */
  public void callChangeOrder(YFSEnvironment yfsEnv, String strUnearnedKohlsCash,
      String strMaximizeRefund, String strMaximizeKohlsCash, String strOrderHeaderkey)
      throws ParserConfigurationException, DOMException {
    logger.beginTimer("KohlsReturnTendering.callChangeOrder");
    // logger.debug("KohlsReturnTendering.callChangeOrder -- Start");
    // Call changeOrder API to update the unearned Kohls cash
    Document docChangeOrderInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    Element eleInputOrder = docChangeOrderInput.getDocumentElement();
    eleInputOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
    eleInputOrder.setAttribute(KohlsXMLLiterals.A_ACTION, KohlsConstant.MODIFY);
    Element eleExtn = docChangeOrderInput.createElement(KohlsXMLLiterals.E_EXTN);
    eleInputOrder.appendChild(eleExtn);

    // Added For PSA Data Collect- START
    if (KohlsConstant.YES.equalsIgnoreCase(strMaximizeRefund)) {
      eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE,
          KohlsXMLLiterals.CONST_MAXIMIZE_REFUND);
      eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_DEACTIVATED, strUnearnedKohlsCash);
    } else if (KohlsConstant.YES.equalsIgnoreCase(strMaximizeKohlsCash)) {
      eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE,
          KohlsXMLLiterals.CONST_MAXIMIZE_KOHLS_CASH);
    }
    if (eleExtn.hasAttributes()) {
      // Added For PSA Data Collect- END
      // Added For PSA Data Collect- END
      // MAD-287 Adding endpoint before calling change Order
      logger.debug("Before Adding edge ::" + ServerTypeHelper.amIOnEdgeServer());
      if (ServerTypeHelper.amIOnEdgeServer()) {
        Element eleAdditionalInfo =
            SCXmlUtil.createChild(eleInputOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_MOTHERSHIP);
      }
      logger.debug(" KohlsReturnTendering.callChangeOrder Input to callChangeOrder :"
          + XMLUtil.getXMLString(docChangeOrderInput));
      try {
        KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.CHANGE_ORDER_API, docChangeOrderInput);
      } catch (Exception e) {
        logger.error(
            " KohlsReturnTendering.callChangeOrder Exception in the Method callChangeOrder of KohlsReturnTendering"
                + e.getStackTrace());
      }
    } else {
      logger.debug(
          "There is no attributes for changeOrder api, so skipping the changeOrder api call.");
    }

    logger.endTimer("KohlsReturnTendering.callChangeOrder");
    // logger.debug("KohlsReturnTendering.callChangeOrder -- End");
  }

  /**
   * 
   * @param yfsEnv
   * @param strOrgCode
   * @return
   * @throws DOMException
   * @throws Exception
   */
  public Document callGetRuleListForPOS(YFSEnvironment yfsEnv, String strOrgCode)
      throws DOMException, Exception {
    logger.beginTimer("KohlsReturnTendering.callGetRuleListForPOS");
    // logger.debug("KohlsReturnTendering.callGetRuleListForPOS -- Start ");
    Document docRuleListForPOSOutput = null;

    // Prepare Input to call getCommomCodeList API
    Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, strOrgCode);
    eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, "KMC_TENDER_LIMIT");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "KohlsReturnTendering.callGetRuleListForPOS docInput=" + XMLUtil.getXMLString(docInput));
    }
    // calling getCommomCodeList API
    docRuleListForPOSOutput =
        KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsReturnTendering.callGetRuleListForPOS docRuleListForPOSOutput="
          + XMLUtil.getXMLString(docRuleListForPOSOutput));
    }
    logger.endTimer("KohlsReturnTendering.callGetRuleListForPOS");
    // logger.debug("KohlsReturnTendering.callGetRuleListForPOS -- End ");
    return docRuleListForPOSOutput;
  }

  // Added for Tender RollUp -Start
  public Document callGetRuleListForPOSTenderRoll(YFSEnvironment yfsEnv, String strOrgCode)
      throws ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsReturnTendering.callGetRuleListForPOSTenderRoll");
    Document docRuleListForPOSOutput = null;
    try {
      // logger.debug("KohlsReturnTendering.callGetRuleListForPOSTenderRoll -- Start");
      Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
      Element eleInput = docInput.getDocumentElement();
      eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, strOrgCode);


      if (logger.isDebugEnabled())
        logger.debug("KohlsReturnTendering.callGetRuleListForPOSTenderRoll docInput="
            + XMLUtil.getXMLString(docInput));

      // Rule name to be added
      eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, "ROLLUP_TENDER_LIMIT");
      docRuleListForPOSOutput =
          KohlsCommonUtil.invokeAPI(yfsEnv, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
      logger.debug("KohlsReturnTendering.callGetRuleListForPOSTenderRoll docRuleListForPOSOutput="
          + XMLUtil.getXMLString(docRuleListForPOSOutput));
    } catch (Exception ex) {
      logger.debug(ex.getMessage());
    }
    // logger.debug("KohlsReturnTendering.callGetRuleListForPOSTenderRoll -- End");
    logger.endTimer("KohlsReturnTendering.callGetRuleListForPOSTenderRoll");
    return docRuleListForPOSOutput;
  }

  // Added for Tender RollUp -Start

  // Added for Tender sequencing for display on "Proceed To Tender screen"
  public Document sequencePaymentMethods(YFSEnvironment env, Document docInXML) throws Exception {
    logger.beginTimer("KohlsReturnTendering.sequencePaymentMethods");

    NodeList nlPaymentMethod = docInXML.getElementsByTagName("PaymentMethod");
    logger.debug("Length of payment " + nlPaymentMethod.getLength());
    Element elePaymentMethods = (Element) docInXML.getElementsByTagName("PaymentMethods").item(0);
    HashMap<String, Element> map = new HashMap<String, Element>();

    int i = nlPaymentMethod.getLength() - 1;
    while (i >= 0) {
      Element elePaymentMethod = (Element) nlPaymentMethod.item(i);
      String sPaymentMethod = elePaymentMethod.getAttribute("PaymentType");
      if (sPaymentMethod.equalsIgnoreCase("CREDIT_CARD")) {
        sPaymentMethod = elePaymentMethod.getAttribute("CreditCardType");
      }
      if (map.containsKey(sPaymentMethod)) {

        int refundAmount = Integer.parseInt(map.get(sPaymentMethod).toString())
            + Integer.parseInt(elePaymentMethod.getAttribute("Amount"));
        elePaymentMethod.setAttribute("Amount", String.valueOf(refundAmount));
      }
      map.put(sPaymentMethod, elePaymentMethod);
      elePaymentMethods.removeChild(elePaymentMethod);
      i--;
    }
    Document docRulesListInput = XMLUtil.createDocument("Rule");
    Element eleRuleInputRoot = docRulesListInput.getDocumentElement();
    eleRuleInputRoot.setAttribute("RuleID", "DISPLAY_REFUND_PAYMENT_SEQUENCE");
    eleRuleInputRoot.setAttribute("OrganizationCode", strOrgCode);
    Document docRulesListOutput = invokeAPI(env, "getRuleListForPOS", docRulesListInput);
    if (!YFCCommon.isVoid(docRulesListOutput)) {
      Element eleRuleOut = (Element) docRulesListOutput.getElementsByTagName("Rule").item(0);
      if (!YFCCommon.isVoid(eleRuleOut)) {
        String sSequence = eleRuleOut.getAttribute("RuleValue");
        // to be replaced with getRulesListForPOS api to get the
        // sequence from SBC rule - end
        String[] delimitedString = sSequence.split(",");
        for (int j = 0; j < delimitedString.length; j++) {
          if (map.containsKey(delimitedString[j])) {
            elePaymentMethods.appendChild(map.get(delimitedString[j]));
          }
        }
      }
    }
    logger.endTimer("KohlsReturnTendering.sequencePaymentMethods");
    return docInXML;
  }

  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */

  public void setProperties(Properties prop) throws Exception {
    logger.beginTimer("KohlsReturnTendering.setProperties");
    this.props = prop;
    logger.debug("In the set properties method");
    logger.endTimer("KohlsReturnTendering.setProperties");
  }

  /**
   * This function is used to get the value for a property
   * 
   * @param property name in string format
   * @return String propValue
   */
  public String getPropertyValue(String property) {
    logger.beginTimer("KohlsReturnTendering.getPropertyValue");
    String propValue;
    propValue = YFSSystem.getProperty(property);

    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    logger.endTimer("KohlsReturnTendering.getPropertyValue");
    return propValue;

  }

  private void updatePaymentMethodAndRefundAmt(Document inDoC, Element eleUltimatePayment,
      Element elePenUltimatePayment) {
    logger.beginTimer("KohlsReturnTendering.updatePaymentMethodAndRefundAmt");

    String sRefundAmtToBeRolledUp =
        eleUltimatePayment.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
    Double dRefundAmtToBeRolledUp = Double.parseDouble(sRefundAmtToBeRolledUp);
    Element eleKohlsPaymentList =
        (Element) elePenUltimatePayment.getElementsByTagName("KohlsPaymentList").item(0);
    NodeList ndlKohlsPayment = eleKohlsPaymentList.getElementsByTagName("KohlsPayment");
    if (!YFCCommon.isVoid(ndlKohlsPayment)) {
      int totalRecords = ndlKohlsPayment.getLength();
      if (totalRecords > 0) {
        double tempRefundAmount = dRefundAmtToBeRolledUp / totalRecords;
        if (logger.isDebugEnabled()) {
          logger.debug("Refund amount for Split " + tempRefundAmount);
        }
        for (int j = 0; j < ndlKohlsPayment.getLength(); j++) {
          Element eleKohlsPayment = (Element) ndlKohlsPayment.item(j);
          if (logger.isDebugEnabled()) {
            if (!YFCCommon.isVoid(eleKohlsPayment)) {
              logger.debug("KohlsReturnTendering.callGetRuleListForPOS docRuleListForPOSOutput="
                  + XMLUtil.getElementXMLString(eleKohlsPayment));
            }
          }
          double dRefundval =
              Double.parseDouble(eleKohlsPayment.getAttribute("RefundAmount")) + tempRefundAmount;
          if (logger.isDebugEnabled()) {
            logger.debug("RefundValue---->" + dRefundval);
          }
          eleKohlsPayment.setAttribute("RefundAmount",
              new DecimalFormat("#0.00").format(dRefundval));
        }
      }

    }
    logger.beginTimer("KohlsReturnTendering.updatePaymentMethodAndRefundAmt");

  }

  private void rollupKMCIntoCASH(Document inDoC, double dRefundAmount, String sPaymentType) {
    logger.endTimer("KohlsReturnTendering.updatePaymentMethodAndRefundAmt");

    Element elePaymentMethods = XMLUtil.getFirstElementByName(inDoC.getDocumentElement(),
        KohlsXMLLiterals.E_PAYMENT_METHODS);
    if (!YFCCommon.isVoid(elePaymentMethods)) {
      NodeList nlPaymentMethod =
          elePaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
      for (int i = 0; i < nlPaymentMethod.getLength(); i++) {

        // double Ref = Double.parseDouble("Amount") + dRefundAmount;
        // changing for 3156
        double refAmt = dRefundAmount;
        Element elePaymentMethod = (Element) nlPaymentMethod.item(i);
        if (!YFCCommon.isVoid(elePaymentMethod)) {
          if (logger.isDebugEnabled()) {
            logger.debug("KohlsReturnTendering.callGetRuleListForPOS docRuleListForPOSOutput="
                + XMLUtil.getElementXMLString(elePaymentMethod));
          }
        }
        if (elePaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE).equals(sPaymentType)) {
          elePaymentMethod.setAttribute("Amount", String.valueOf(refAmt));
          Element eleKohlsPaymentList =
              (Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);
          if (!YFCCommon.isVoid(eleKohlsPaymentList)) {
            if (logger.isDebugEnabled()) {
              logger.debug("KohlsReturnTendering.callGetRuleListForPOS docRuleListForPOSOutput="
                  + XMLUtil.getElementXMLString(eleKohlsPaymentList));
            }
          }
          NodeList ndlKohlsPayment = eleKohlsPaymentList.getElementsByTagName("KohlsPayment");
          if (!YFCCommon.isVoid(ndlKohlsPayment)) {
            int totalRecords = ndlKohlsPayment.getLength();
            if (totalRecords > 0) {
              double tempRefundAmount = dRefundAmount / totalRecords;
              if (logger.isDebugEnabled()) {
                logger.debug("Refund amount for Split " + tempRefundAmount);
              }


              for (int j = 0; j < ndlKohlsPayment.getLength(); j++) {

                Element eleKohlsPayment = (Element) ndlKohlsPayment.item(j);
                if (logger.isDebugEnabled()) {
                  if (!YFCCommon.isVoid(eleKohlsPayment)) {
                    logger
                        .debug("KohlsReturnTendering.callGetRuleListForPOS docRuleListForPOSOutput="
                            + XMLUtil.getElementXMLString(eleKohlsPayment));
                  }
                }
                double dRefundval = Double.parseDouble(eleKohlsPayment.getAttribute("RefundAmount"))
                    + tempRefundAmount;
                if (logger.isDebugEnabled()) {
                  logger.debug("RefundValue---->" + dRefundval);
                }
                eleKohlsPayment.setAttribute("RefundAmount", String.valueOf(dRefundval));
              }
            }
          }
        }
      }

    }
    logger.endTimer("KohlsReturnTendering.updatePaymentMethodAndRefundAmt");

  }
}
