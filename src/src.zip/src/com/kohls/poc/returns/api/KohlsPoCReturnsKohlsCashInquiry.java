package com.kohls.poc.returns.api;

import java.io.IOException;
import java.text.DecimalFormat;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


/*<CouponInquiryRequestMsg>
	<Header AssociateID="1628246" BusinessDate="2017/03/17" Store="9953" OrderHeaderKey='2017142775557258478'
        Terminal="63" TrainingMode="false"
        TranStartDateTime="2017/03/17T00:00:00" TransactionNumber="0892"/>
	<Data CouponNumber="142775557258478" HandKeyedCoupon="true"
        InquiryTransaction="true" Pin="8928" ReceiptID="999958782965352004530950456"/>
</CouponInquiryRequestMsg>
 */

/**
 * @author tkmaath
 *
 */
public class KohlsPoCReturnsKohlsCashInquiry extends KOHLSBaseApi{
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCReturnsKohlsCashInquiry.class.getName());
	}
	/**
	 * @param yfsEnv
	 * @param inXML
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public Document callKohlsCashInquiry (YFSEnvironment yfsEnv, Document inXML) throws ParserConfigurationException, SAXException, IOException
	{
		logger.beginTimer("KohlsPoCReturnsKohlsCashInquiry.callKohlsCashInquiry");

		Element eleInData = (Element) inXML.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_DATA).item(0);
		Element eleInHeader = (Element) inXML.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_HEADER).item(0);
		Document dOrderInput = XMLUtil.getDocument("<Order Action='MODIFY' Override='Y' IgnoreRepricingUE='Y'><Promotions><Promotion PromotionType='KOHLS_CASH_UNEARNED' "
				+ "><Extn/></Promotion></Promotions></Order>");
		Element eleCouponInquiry = dOrderInput.createElement("KohlsCouponInquiryResponse");
		//call webservice -- KohlsPoCKohlsCashInquiryWebService
		try{
			String sOrderHeaderKey=eleInHeader.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			dOrderInput.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
			eleInHeader.removeAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			Element elePromotion = (Element)dOrderInput.getElementsByTagName(KohlsPOCConstant.E_PROMOTION).item(0);
			
			elePromotion.setAttribute(KohlsPOCConstant.PROMOTIONID, eleInData.getAttribute(KohlsPOCConstant.A_COUPON_NUMBER));
			long beginTime = System.currentTimeMillis();
			
			Document docCouponResp = invokeService(yfsEnv, "KohlsPoCKohlsCashInquiryWebService", inXML);
			long endTime = System.currentTimeMillis();

			Element eleheader = (Element) docCouponResp.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_HEADER).item(0);
			Element eleData = (Element) docCouponResp.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_DATA).item(0);
			if(!YFCCommon.isVoid(eleheader)){
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_ASSOCIATE_ID, eleheader.getAttribute(KohlsPOCConstant.A_ASSOCIATE_ID));
				//eleCouponInquiry.setAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE, eleheader.getAttribute(KohlsPOCConstant.ATTR_Store));
				//eleCouponInquiry.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO ,eleheader.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM));
				//eleCouponInquiry.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,eleheader.getAttribute(KohlsPOCConstant.A_TERMINAL));
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_ORDER_DATE, eleheader.getAttribute(KohlsPOCConstant.A_BUSINESS_DATE));
			}
			if(!YFCCommon.isVoid(eleData)){
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_AUTH_CODE, eleData.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM));
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F"+eleData.getAttribute(KohlsPOCConstant.AUTH_RES_CODE));
				//PST-3298 - Start
				if(!YFCCommon.isVoid(eleData.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE))){
					eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_BALANCE, eleData.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE));
				}else{
					eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_BALANCE, KohlsPOCConstant.OdotO);
				}
				//PST-3298 - End
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_HISTORY, eleData.getAttribute(KohlsPOCConstant.A_HISTORY_DATA));
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_STATUS, eleData.getAttribute(KohlsPOCConstant.A_COUPON_STATUS));
			}
			if(!YFCCommon.isVoid(eleInData)){
				eleCouponInquiry.setAttribute(KohlsPOCConstant.ATTR_COUPON_NUMBER, eleInData.getAttribute(KohlsPOCConstant.ATTR_COUPON_NUMBER));
				eleCouponInquiry.setAttribute(KohlsPOCConstant.A_COUPON_RECEIPT_ID, eleInData.getAttribute(KohlsPOCConstant.ATTR_RECEIPT_ID));
			}
			eleCouponInquiry.setAttribute(KohlsPOCConstant.A_AUTH_TIME, new DecimalFormat("#0.00").format((endTime - beginTime) / 100));



			//eleCouponInquiry.setAttribute(KohlsPOCConstant.A_IS_TRAINING,"");
			eleCouponInquiry.setAttribute("IsKohlsCashIdDetokenized","");

			//elePromotion.appendChild(eleCouponInquiry);
			Element elePromotionExtn = (Element)dOrderInput.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
			elePromotionExtn.setAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil.getElementXMLString(eleCouponInquiry));
			if(logger.isDebugEnabled()){
				logger.debug("Input to Change order is"+XMLUtil.getXMLString(dOrderInput));
			}
			//call change ORder
			invokeAPI(yfsEnv, dOrderInput, KohlsPOCConstant.API_CHANGE_ORDER, dOrderInput);

		}catch(YFSException e){
			throw e;
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new YFSException("SERVICE_ERROR");
		}

		
		logger.endTimer("KohlsPoCReturnsKohlsCashInquiry.callKohlsCashInquiry");
		return XMLUtil.createDocument(eleCouponInquiry);
	}
}
