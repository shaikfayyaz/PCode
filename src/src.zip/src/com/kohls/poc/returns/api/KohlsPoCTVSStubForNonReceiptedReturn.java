/*
 * File: TVSStubForNonReceipteReturns.java Created on Jan 9, 2017 for KohlsUtil by mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.api;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ibm.icu.text.DecimalFormat;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.util.KohlsPoCXMLTransformer;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author mrjoshi This class is the stub class for TVS interface for Non receipted price. This
 *         class will always return the price < $100 and Tax rate of 10%
 */
public class KohlsPoCTVSStubForNonReceiptedReturn {
  private static final YFCLogCategory log =
      YFCLogCategory.instance(KohlsPoCTVSStubForNonReceiptedReturn.class.getName());
  private static double dTaxRate = 10.00;
  private static double nonReceiptAmtConversionFactor = 80;

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docInXML
   * @return
   * @throws Exception
   */
  public Document processTVSRequest(YFSEnvironment env, Document docInXML) throws Exception {
    log.beginTimer("KohlsPoCTVSStubForNonReceiptedReturn.processTVSRequest");
    DecimalFormat df = new DecimalFormat("#0.00");
    String manualTLD_id = "";
    String markDownValue = "";
    String secondaryMarkDownValue = "";
    String discountType = "";
    double dMarkDownValue = 0.0;
    double dSecondaryMarkDownValue = 0.0;
    double dAssoDiscDelta = 0.0;
    double dTotalTLDImpactVal = 0.0;
    double dPrice = 0.0D;
    boolean bAddAssociateDiscModifier = false;

    if (log.isDebugEnabled()) {
      log.debug("Input to KohlsPoCTVSStubForNonReceiptedReturn.processTVSRequest is: "
          + XMLUtil.getXMLString(docInXML));
    }
    File file = new File("/tmp/NonReceiptedItemPrice.txt");
    HashMap<String, Double> ItemPrice = new HashMap<String, Double>();
    FileReader fileReader = null;
    BufferedReader bufferedReader = null;
    if (file != null) {
      try {
        fileReader = new FileReader(file);
        bufferedReader = new BufferedReader(fileReader);
        String line;
        while ((line = bufferedReader.readLine()) != null) {
          String temp[] = line.split(",");
          if (!YFCCommon.isVoid(temp)) {
            String sItemID = temp[0].trim();
            String sPrice = temp[1].trim();
            ItemPrice.put(sItemID, Double.parseDouble(sPrice));
          }
        }
      } catch (Exception ex) {
        ex.printStackTrace();
      } finally {
        if (!YFCCommon.isVoid(fileReader)) {
          fileReader.close();
        }
      }
    }

    Element eleInputRoot = docInXML.getDocumentElement();
    if (YFCCommon.isVoid(eleInputRoot)
        || !eleInputRoot.getNodeName().equalsIgnoreCase("returnPriceRequest")) {
      throw new YFSException("Invalid XML");
    }
    Element eleTransaction = (Element) eleInputRoot.getElementsByTagName("transaction").item(0);
    if (YFCCommon.isVoid(eleTransaction)) {
      throw new YFSException("Element transaction not found");
    }
    String transactionId = getString("transactionId", eleTransaction);
    String storeNum = getString("storeNum", eleTransaction);
    if (YFCCommon.isVoid(transactionId)) {
      throw new YFSException("transactionId is not present in the request");
    }
    if (YFCCommon.isVoid(storeNum)) {
      throw new YFSException("storeNum is not present in the request");
    }
    NodeList nlItemList = eleTransaction.getElementsByTagName("item");
    if (nlItemList.getLength() == 0) {
      throw new YFSException("No Items sent in the request");
    }
    Document docOutXML = XMLUtil.createDocument("priceResponse");
    Element eleOutTransaction = docOutXML.createElement("transaction");
    docOutXML.getDocumentElement().appendChild(eleOutTransaction);
    setString("transactionId", transactionId, eleOutTransaction, docOutXML);
    setString("storeNum", storeNum, eleOutTransaction, docOutXML);

    Element eleManualTLD = XMLUtil.getChildElement(eleTransaction, "manualTLD");
    if (!YFCCommon.isVoid(eleManualTLD)) {
      manualTLD_id = getString("id", eleManualTLD);
      markDownValue = getString("markDownValue", eleManualTLD);
      secondaryMarkDownValue = getString("secondaryMarkDownValue", eleManualTLD);
      discountType = getString("discountType", eleManualTLD);
      if ("AssociateDiscount".equalsIgnoreCase(discountType)) {
        dMarkDownValue = Double.parseDouble(markDownValue);
        dSecondaryMarkDownValue = Double.parseDouble(secondaryMarkDownValue);
      }
    }

    Element eleOutItemList = docOutXML.createElement("itemList");
    eleOutTransaction.appendChild(eleOutItemList);

    for (int i = 0; i < nlItemList.getLength(); i++) {
      Element eleItem = (Element) nlItemList.item(i);
      Element eleOutItem = docOutXML.createElement("item");
      eleOutItemList.appendChild(eleOutItem);
      String sku = getString("sku", eleItem);
      String id = getString("id", eleItem);
      String empDiscCode = getString("empDiscCode",eleItem);
      //Temp hardcoded
     /* if(YFCCommon.isVoid(empDiscCode)){
        empDiscCode = "S";
      }*/
      if (YFCCommon.isVoid(empDiscCode)) {
        throw new YFSException("empDiscCode is not present in the request");
      }
      String regularPrice = getString("regularPrice", eleItem);
      setString("id", id, eleOutItem, docOutXML);
      setString("sku", sku, eleOutItem, docOutXML);
      setString("skuStatus", "Active", eleOutItem, docOutXML);

      if (!YFCCommon.isVoid(regularPrice)) {
        dPrice = Double.parseDouble(regularPrice);
      } else if (!ItemPrice.isEmpty() && ItemPrice.containsKey(sku)) {
        if(dMarkDownValue > 0 || dSecondaryMarkDownValue > 0){
          dPrice = ItemPrice.get(sku);
          regularPrice = new DecimalFormat("#0.00").format(dPrice);
        } else {
          dPrice = ItemPrice.get(sku) * 1.25;
        }
        
      } else {
        dPrice = Double.valueOf((int) (Math.random()*10 +1)*10);
      }
      String sPrice = new DecimalFormat("#0.00").format(dPrice);
      setString("regularPrice", sPrice, eleOutItem, docOutXML);
      setString("lastNonClearancePrice", sPrice, eleOutItem, docOutXML);
      setString("sellingPrice", sPrice, eleOutItem, docOutXML);
      setString("netPrice", sPrice, eleOutItem, docOutXML);
      setString("receiptReturnPrice", sPrice, eleOutItem, docOutXML);
      setString("returnPrice", sPrice, eleOutItem, docOutXML);
      // NonReceipted price is 80% of price.
      Double dNonReceiptedPrice = 0.0D;
      if (!YFCCommon.isVoid(regularPrice)) {
        dNonReceiptedPrice = dPrice;
      } else {
        dNonReceiptedPrice = (dPrice * (nonReceiptAmtConversionFactor / 100));
      }
      if ("S".equalsIgnoreCase(empDiscCode) && dMarkDownValue > 0) {
        dAssoDiscDelta = dNonReceiptedPrice * dMarkDownValue;
        dTotalTLDImpactVal = dTotalTLDImpactVal + dAssoDiscDelta;
        // dNonReceiptedPrice = dNonReceiptedPrice - dAssoDiscDelta;
        bAddAssociateDiscModifier = true;
      } else if ("H".equalsIgnoreCase(empDiscCode) && dMarkDownValue > 0) {
        dAssoDiscDelta = dNonReceiptedPrice * dSecondaryMarkDownValue;
        dTotalTLDImpactVal = dTotalTLDImpactVal + dAssoDiscDelta;
        // dNonReceiptedPrice = dNonReceiptedPrice - dAssoDiscDelta;
        bAddAssociateDiscModifier = true;
      }
      String sNonReceiptedPrice = df.format(dNonReceiptedPrice);
      setString("taxablePrice", sNonReceiptedPrice, eleOutItem, docOutXML);
      setString("nonReceiptReturnPrice", sNonReceiptedPrice, eleOutItem, docOutXML);
      Element eleTax = docOutXML.createElement("LineTax");
      eleOutItem.appendChild(eleTax);
      // tax rate is 10%
      Double dTax = ((dNonReceiptedPrice - dAssoDiscDelta) * (dTaxRate / 100));
      String sTax = df.format(dTax);
      setString("taxName","State Tax",eleTax,docOutXML); 
      setString("tax",sTax,eleTax,docOutXML);
      setString("taxPercentage","10.00",eleTax,docOutXML);
      setString("chargeCategory","Price",eleTax,docOutXML);
      setString("taxType","Sales",eleTax,docOutXML);

      /*
       * setString("taxName","State Tax",eleTax,docOutXML); setString("tax",sTax,eleTax,docOutXML);
       * setString("taxPercentage","10.00",eleTax,docOutXML);
       * setString("chargeCategory","Price",eleTax,docOutXML);
       * setString("taxType","Sales",eleTax,docOutXML);
       */

      if (bAddAssociateDiscModifier) {
        Element modifierList = docOutXML.createElement("modifierList");
        eleOutItem.appendChild(modifierList);
        Element modifier = docOutXML.createElement("modifier");
        modifierList.appendChild(modifier);
        setString("parentDiscountId", manualTLD_id, modifier, docOutXML);
        setString("precedence", "73", modifier, docOutXML);
        setString("modifierActive", "Y", modifier, docOutXML);
        setString("itemId", id, modifier, docOutXML);
        setString("buyItem", "N", modifier, docOutXML);
        setString("sellingPriceDelta", "0", modifier, docOutXML);
        setString("taxablePriceDelta", "-" + df.format(dAssoDiscDelta), modifier, docOutXML);
        setString("netPriceDelta", "-" + df.format(dAssoDiscDelta), modifier, docOutXML);
        setString("returnPriceDelta", "-" + df.format(dAssoDiscDelta), modifier, docOutXML);
        setString("receiptedReturnPriceDelta", "0", modifier, docOutXML);
        setString("proratedSellingPriceDiscountAmountDelta", "0", modifier, docOutXML);
        setString("proratedTaxablePriceDiscountAmountDelta", "0", modifier, docOutXML);
        setString("proratedReturnPriceDelta", "0", modifier, docOutXML);
        setString("proratedReceiptedReturnPriceDelta", "0", modifier, docOutXML);
        setString("proratedNetPriceDiscountAmountDelta", "0", modifier, docOutXML);
        setString("tierActivationAchieved", "0", modifier, docOutXML);
      }
    }

    Element eleTLDList = docOutXML.createElement("TLDList");
    eleOutTransaction.appendChild(eleTLDList);
    if (bAddAssociateDiscModifier) {
      Element tld = docOutXML.createElement("tld");
      eleTLDList.appendChild(tld);
      setString("id", manualTLD_id, tld, docOutXML);
      setString("TLDImpact", "-" + df.format(dTotalTLDImpactVal), tld, docOutXML);
    }

    if (log.isDebugEnabled()) {
      log.debug("TVS XML before tranformation: " + XMLUtil.getXMLString(docOutXML));
    }
    KohlsPoCXMLTransformer transformer = new KohlsPoCXMLTransformer();
    docOutXML = transformer.translateTVSResponse(env,docOutXML);
    if (log.isDebugEnabled()) {
      log.debug("TVS XML after tranformation: " + XMLUtil.getXMLString(docOutXML));
    }
    log.endTimer("KohlsPoCTVSStubForNonReceiptedReturn.processTVSRequest");
    return docOutXML;
  }

  protected static String getString(String tagName, Element element) {
    log.beginTimer("KohlsPoCTVSStubForNonReceiptedReturn.getString");
    NodeList list = element.getElementsByTagName(tagName);
    if (list != null && list.getLength() > 0) {
      NodeList subList = list.item(0).getChildNodes();

      if (subList != null && subList.getLength() > 0) {
        log.endTimer("KohlsPoCTVSStubForNonReceiptedReturn.getString");
        return subList.item(0).getNodeValue();
      }
    }
    log.endTimer("KohlsPoCTVSStubForNonReceiptedReturn.getString");
    return null;
  }

  protected static void setString(String tagName, String value, Element parentElement,
      Document parentDoc) {
    log.beginTimer("KohlsPoCTVSStubForNonReceiptedReturn.setString");
    Element temp = parentDoc.createElement(tagName);
    temp.appendChild(parentDoc.createTextNode(value));
    parentElement.appendChild(temp);
    log.endTimer("KohlsPoCTVSStubForNonReceiptedReturn.setString");
  }
}
