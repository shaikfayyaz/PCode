package com.kohls.poc.returns;

import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.returns.ue.KohlsBeforeCreateReturnOrderUE;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.receipt.ReceiptUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.kohls.common.util.KOHLSBaseApi;

public class KohlsImportPOSOrderForPA implements YIFCustomApi {

  private static final YFCLogCategory log =
      YFCLogCategory.instance(KohlsImportPOSOrderForPA.class.getName());
  private YIFApi api;
  HashMap<String, String> recycleFeeSkuMap = new HashMap<String, String>();
  public static final Map<String, String> mapOTRResponses = new HashMap<String, String>();

  static {
    mapOTRResponses.put("Approval", "F0");
    mapOTRResponses.put("CorporateRefundRequired", "F8");
    mapOTRResponses.put("EditError", "F2");
    mapOTRResponses.put("HardDecline", "F7");
    mapOTRResponses.put("Offline", "F9");
    mapOTRResponses.put("RefundAuth", "F1");
    mapOTRResponses.put("Transaction not found", "1F0");
    mapOTRResponses.put("TransactionNotFound", "1F0");
    mapOTRResponses.put("Drivers license lookup error", "F0");
    mapOTRResponses.put("Gift Receipt Threshold lookup error", "F0");
    mapOTRResponses.put("Transaction lookup error", "F0");
    mapOTRResponses.put("Item lookup error gift receipt", "F0");
    mapOTRResponses.put("Line item discount lookup error", "F0");
    mapOTRResponses.put("Employee discount lookup error", "F0");
    mapOTRResponses.put("Tender record lookup error", "F0");
    mapOTRResponses.put("Check auto lookup error", "F0");
    mapOTRResponses.put("Cust ref lookup error for a check", "F0");
    mapOTRResponses.put("Check Tender \"D\" and NSF=N <=14 days <= $50, Good", "F0");
    mapOTRResponses.put("Suspect Transaction", "F0");
    mapOTRResponses.put("Receipt is older than 3 years", "F1");
    mapOTRResponses.put("Check Tender \"D\" or \"K\",  <= $25.00", "F1");
    mapOTRResponses.put("Gift Receipt was from a voided transaction", "F1");
    mapOTRResponses.put("Check Tender “D” and NSF=Y, <= $25.  Cash", "F1");
    mapOTRResponses.put("Check Tender - Check tender > $75", "F1");
    mapOTRResponses.put("Edit Error – Bad Data in the authorization", "F2");
    mapOTRResponses.put("Original Transaction was voided", "F7");
    mapOTRResponses.put("Invalid transaction type.  Nothing on this receipt to return", "F7");
    mapOTRResponses.put("Gift Receipt was previously returned", "F8");
    mapOTRResponses.put("OTR amount is 0.00", "F8");
    mapOTRResponses.put("Check Tender \"D\" or \"K\" – Over $25.00", "F8");
    mapOTRResponses.put("Check Tender \"G\" – Over $250.00 and under 5 days", "F8");
    mapOTRResponses.put("E-Commerce Return is occurring at theFulfillmentCenter", "F8");
    mapOTRResponses.put("Check Tender \"D\" and NSF = Y and > $25.  Corporate Refund", "F8");
  }

  public KohlsImportPOSOrderForPA() throws YIFClientCreationException {
    api = YIFClientFactory.getInstance().getApi();

  }

  public Document importPOSOrderForPA(YFSEnvironment env, Document inXML)
      throws IOException, Exception {
    log.beginTimer("KohlsImportPOSOrderForPA.importPOSOrderForPA");
    Document impDoc = null;
    Map<String, Element> mapItemList = new HashMap<String, Element>();
    boolean bIsGCOnlyOrder = true;
    try {
      Element ordEle = inXML.getDocumentElement();
      Document impOrderDoc = XMLUtil.newDocument();
      XMLUtil.importElement(impOrderDoc, ordEle);
      if (log.isDebugEnabled()) {
        log.debug("importPOSOrderForPA input doc: " + KohlsXMLUtil.getXMLString(impOrderDoc));
      }
      Element impOrdDocEle = impOrderDoc.getDocumentElement();

      // Remove tenders available and other details from input
      Element tenderEle = (Element) impOrdDocEle
          .getElementsByTagName(KohlsXMLLiterals.TENDERS_AVAILABLE_RETURN).item(0);
      XMLUtil.removeChild(impOrdDocEle, tenderEle);
      XMLUtil.removeChild(impOrdDocEle, (Element) impOrdDocEle
          .getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0));
      XMLUtil.removeChild(impOrdDocEle, (Element) impOrdDocEle
          .getElementsByTagName(KohlsXMLLiterals.E_REPONSE_REASON_DESC).item(0));
      XMLUtil.removeChild(impOrdDocEle,
          (Element) impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_POC_ORDER).item(0));
      // Add ExtnReceiptId
      Document gravityInXML = (Document) env.getTxnObject(KohlsConstant.GRAVITY_IN_REQ);
      String strOrigTerminalID = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
      String strOrigStoreNumber = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
      String strOrigOrderDate = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_ORDER_DATE);
      String strOrigOrderNo = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
      // CAE-78 Start
      String strOrigTransactionNbr = inXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
      String strBusinessDay = "";
      String strScanType = inXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_Entry_Method);
      String strExtnRecp =
          gravityInXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
      if (strExtnRecp.startsWith("0")) {
        strExtnRecp = strExtnRecp.substring(1);
      }
      NodeList orderLineList = impOrdDocEle.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
      Element orderLineEle = null;
      // recycle fee commoncode values Start
      if (recycleFeeSkuMap.isEmpty()) {
        loadRecycleFeeSkuHashMap(env);
      }
      // recycle fee commoncode values End
      int iCounterEligibleItem = 0;
      for (int i = 0; i < orderLineList.getLength(); i++) {
        orderLineEle = (Element) orderLineList.item(i);
        Element eleCustomAttributes = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES, true);

        // CAPE 2282 - Original Tax import to be used by UI calculation
        NodeList lineTaxList = orderLineEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
        for (int j = 0; j < lineTaxList.getLength(); j++) {
          Element eleLineTax = (Element) lineTaxList.item(j);
          Element eleLineTaxExtn =
              XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN, true);
          eleLineTaxExtn.setAttribute(KohlsPOCConstant.A_EXTN_ORG_TAX_AMT,
              eleLineTax.getAttribute(KohlsXMLLiterals.A_TAX));
        }
       
        Element eleOrderItem = null;
        try {
          eleOrderItem = (Element) (XPathUtil.getNode(orderLineEle, KohlsXMLLiterals.E_ITEM));
        } catch (Exception e) {
          log.error("Exception in getNode - importPOSOrderForPA of KohlsImportPOSOrderForPA:"
              + e.getMessage());
        }
        Element eleOrderLineExtn = XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_EXTN);
        Element eleLinePriceInfo =
            XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_LINE_PRICE_INFO);
        String strLineTotal = eleLinePriceInfo.getAttribute(KohlsConstant.LINE_TOT);
        DecimalFormat df = new DecimalFormat("#0.00");
        double dLineTotal = Double.parseDouble(strLineTotal);

        String strItemId = eleOrderItem.getAttribute(KohlsConstant.A_ITEM_ID);
        // HAndled 7 digit item ids.
        if (strItemId.length() == 7) {
          strItemId = "0" + strItemId;
        }
        // Enabling caching for duplicate items
        Element itemEle = null;
        if (YFCCommon.isVoid(mapItemList.get(strItemId))) {
          itemEle = getItemExtnAttribs(env, strItemId, strOrigStoreNumber);
          mapItemList.put(strItemId, itemEle);
        } else {
          itemEle = mapItemList.get(strItemId);
        }
        Element itemExtnEle = null;
        if (!YFCCommon.isVoid(itemEle)) {
          // Set item id incase prefixed with 0 to enable TVS itg
          eleOrderItem.setAttribute(KohlsConstant.A_ITEM_ID, strItemId);
          orderLineEle.setAttribute(KohlsConstant.A_ITEM_ID, strItemId);
          itemExtnEle = (Element) itemEle.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
          log.debug("item element from itemlist: " + KohlsXMLUtil.getElementXMLString(itemEle));
          eleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ITEM_CLASS, itemExtnEle.getAttribute(KohlsXMLLiterals.A_EXTN_CLASS));
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT, itemExtnEle.getAttribute(KohlsPOCConstant.E_EXTN_DEPT));
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS,
              itemExtnEle.getAttribute(KohlsPOCConstant.EXTNSUBCLASS));
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.EXTN_VENDOR_STYLE_NO,
              itemExtnEle.getAttribute(KohlsPOCConstant.EXTN_VENDOR_STYLE_NO));
          if(YFCCommon.isVoid(eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE))){
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE,
              KohlsXPathUtil.getString(itemEle, "ClassificationCodes/@TaxProductCode"));
          }
          eleOrderLineExtn.setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE,
              itemExtnEle.getAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE));
          eleOrderLineExtn.setAttribute("ExtnCallback", itemExtnEle.getAttribute("ExtnCallback"));
          eleOrderLineExtn.setAttribute("ExtnCallbackStartDate",
              itemExtnEle.getAttribute("ExtnCallbackStartDate"));
          eleOrderLineExtn.setAttribute("ExtnCallbackEndDate",
              itemExtnEle.getAttribute("ExtnCallbackEndDate"));

          // Added for POS Import TVS Error - Start
          String sEmpDiscCode = itemExtnEle.getAttribute(KohlsXMLLiterals.ATTR_EMP_DISC_CODE);
          Element eleReferences = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.A_REFERENCES);
          Element eleReference = XMLUtil.createChild(eleReferences, KohlsPOCConstant.A_REFERENCE);
          eleReference.setAttribute(KohlsXMLLiterals.A_NAME, KohlsXMLLiterals.ATTR_EMP_DISC_CODE);
          if (!YFCCommon.isStringVoid(sEmpDiscCode)) {
            eleReference.setAttribute(KohlsXMLLiterals.A_VALUE, sEmpDiscCode);
          } else {
            eleReference.setAttribute(KohlsXMLLiterals.A_VALUE, KohlsPOCConstant.BLANK);
          }
          // Added for POS Import TVS Error - End
        }

        eleCustomAttributes.setAttribute("Text6", strOrigOrderNo);
        eleCustomAttributes.setAttribute("Text7", strOrigStoreNumber);
        eleCustomAttributes.setAttribute("Text8", strOrigTerminalID);
        eleCustomAttributes.setAttribute("Text9", strOrigTransactionNbr);
        eleCustomAttributes.setAttribute("Text10", orderLineEle.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
        eleCustomAttributes.setAttribute("Text12",
            eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
        eleCustomAttributes.setAttribute("Text13", df.format(dLineTotal));
        eleCustomAttributes.setAttribute("Text14",
                eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT));
        eleCustomAttributes.setAttribute("Date2", strOrigOrderDate);
        
        //Added for CAPE-107 Scenario 7 - begin
        NodeList nlLineCharge = orderLineEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
        for(int j=0; j<nlLineCharge.getLength(); j++){
          Element eleLineCharge = (Element)nlLineCharge.item(j);
          String sChargePerLine = eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
          Element eleLineChargeExtn = XMLUtil.getChildElement(eleLineCharge, KohlsPOCConstant.E_EXTN, true);
          eleLineChargeExtn.setAttribute("ExtnOrigChgPerLine", sChargePerLine);
        }

        String strStatusCode = "";

        if (!YFCCommon.isVoid(eleOrderLineExtn))
          strStatusCode = eleOrderLineExtn.getAttribute("ExtnSkuStatusCode");

        if (!YFCCommon.isVoid(strItemId) && !YFCCommon.isVoid(itemEle)) {

          if (strItemId.endsWith("000")) {
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "DummySKU");
            eleOrderLineExtn.setAttribute("ExtnIsPriceEntered", "Y");
            bIsGCOnlyOrder = false;
          } else if (recycleFeeSkuMap.containsKey(strItemId)) {
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "RecycleFeeSKU");
            bIsGCOnlyOrder = false;
          } else if ((KohlsPOCConstant.YES).equals(orderLineEle.getAttribute("IsReturnedItem"))) {
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "ReturnedSKU");
            bIsGCOnlyOrder = false;
          } else if ((KohlsPOCConstant.TRUE).equals(orderLineEle.getAttribute("GiftCardInd"))) {
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "GiftCardSKU");
          } else if (strStatusCode.equals("30")) {
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "ClearanceSKU");
            bIsGCOnlyOrder = false;
          } else if (!YFCCommon.isVoid(eleOrderLineExtn.getAttribute("ExtnCallbackTypeCode"))
              && 2 == Integer.parseInt(eleOrderLineExtn.getAttribute("ExtnCallbackTypeCode"))) {
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "CallBackItem");
            bIsGCOnlyOrder = false;
          } else {
            iCounterEligibleItem++;
            eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "Eligible");
            bIsGCOnlyOrder = false;
          }

        } else {
          eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT11, "ItemNotFound");
          bIsGCOnlyOrder = false;
        }
        // Aj CAPE-1977
        // CAPE--1977 Item eligibility -- End
      }

      Element extnElement = XMLUtil.getChildElement(impOrdDocEle, KohlsXMLLiterals.E_EXTN);
          
      // MJ 03/24 Commented A_EXTN_RECEIPT_ID so that if return happens on this transaction,
      // this particular order should not show up in the getOrderList api call.
      /*
       * extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, strExtnRecp);
       */
      extnElement.setAttribute("ExtnPSAStatus", KohlsPOCConstant.A_PA_INITIATED);
      extnElement.setAttribute(KohlsPOCConstant.EXTN_POC_FEATURE,
          KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT);
      extnElement.setAttribute("ExtnRegisterBankNumber","1");
      // CAPE-79 Associate PA - Start
      if (strExtnRecp.substring(0, 3).equals("776")) {
        if(YFCCommon.isVoid(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO))) {
          extnElement.setAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO, "0000000");
        }
      }

      String sExtnOTRResponse = extnElement.getAttribute("ExtnOTRResponse");
      String sresponseReasonType = extnElement.getAttribute("ExtnOTRResponseType");
      String sOTRTotalAmount = impOrdDocEle.getAttribute("TransactionAvailableAmt");
      Element eleReferences = XMLUtil.createChild(impOrdDocEle, "References");
      Element eleReference = XMLUtil.createChild(eleReferences, "Reference");
      eleReference.setAttribute("Name",
          "OTR-R-" + strOrigStoreNumber + "-" + strOrigTerminalID + "-" + strOrigTransactionNbr);
      eleReference.setAttribute("Value", sExtnOTRResponse + mapOTRResponses.get(sresponseReasonType)
          + "-" + sresponseReasonType + "-" + sOTRTotalAmount+"-"+strExtnRecp+"_"+strScanType+"-"+"-");

      // Aj: as we are calling repriceOrder instead of changeOrder, we
      // need to pass OrderHoldTypes in impOrdDocEle
      Element eleOrderHoldTypes =
          XMLUtil.createChild(impOrdDocEle, KohlsXMLLiterals.E_ORDER_HOLD_TYPES);
      Element eleOrderHoldType =
          XMLUtil.createChild(eleOrderHoldTypes, KohlsXMLLiterals.E_ORDER_HOLD_TYPE);
      eleOrderHoldType.setAttribute(KohlsXMLLiterals.A_STATUS,
          KohlsPOCConstant.HOLD_CREATED_STATUS);
      eleOrderHoldType.setAttribute(KohlsXMLLiterals.A_HOLD_TYPE, KohlsPOCConstant.A_PA_HOLD_TYPE);
      eleOrderHoldType.setAttribute(KohlsXMLLiterals.A_REASON_TEXT,
          KohlsPOCConstant.A_PA_INITIATED);

      if (log.isDebugEnabled()) {
        log.debug("import readys doc: " + KohlsXMLUtil.getXMLString(impOrderDoc));
      }

      // Checking if valid response is received from RS.
      checkIfOrderNeedsToBeImported(impOrderDoc, mapOTRResponses.get(sresponseReasonType),
          bIsGCOnlyOrder);

      // RS response is valid. Now generating new transaction no for import order.
      String strTransactionNbr = "";
      String strTransactionTmst = gravityInXML.getDocumentElement().getAttribute("TransactionTmst");
      Document tillInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
      tillInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
          gravityInXML.getDocumentElement().getAttribute("CurrentStore"));
      tillInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
          gravityInXML.getDocumentElement().getAttribute("CurrentTerminal"));
      log.debug("INput to api is" + SCXmlUtil.getString(tillInput));
      Document docNextTranOut = api.getNextTransactionNumberForPOS(env, tillInput);
      Document docTillStatusOut = api.getCurrentTillStatusForPOS(env, tillInput);
      if (docTillStatusOut != null) {
        if (log.isDebugEnabled()) {
          log.debug("here is the business day:" + docTillStatusOut.getDocumentElement()
              .getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
          log.debug("here is the till id:"
              + docTillStatusOut.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
        }
        strTransactionNbr =
            docNextTranOut.getDocumentElement().getAttribute(KohlsPOCConstant.A_SEQUENCE_NUMBER);
        strTransactionNbr = KohlsPoCPnPUtil.prepadString(strTransactionNbr, 4, "0");
        strBusinessDay =
            docTillStatusOut.getDocumentElement().getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
      }
      // String strTransactionTmst = inXML.getDocumentElement().getAttribute("OrderDate");
      // String strTerminalID = inXML.getDocumentElement().getAttribute("TerminalID");
      String strCurrentTerminal = gravityInXML.getDocumentElement().getAttribute("CurrentTerminal");
      // String strStoreNumber = inXML.getDocumentElement().getAttribute("SellerOrganizationCode");
      String strCurrentStore = gravityInXML.getDocumentElement().getAttribute("CurrentStore");
      // strTransactionNbr="2868";
      String strReceiptId = ReceiptUtil.generateReceiptID(docNextTranOut.getDocumentElement().getAttribute("transactionNumber"), 
    		  KohlsPOCConstant.RETURN_RECEIPT_LINE_NUMBER_TYPE);
      impOrdDocEle.setAttribute("POSSequenceNumber", strTransactionNbr);
      impOrdDocEle.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NO,
          docNextTranOut.getDocumentElement().getAttribute("transactionNumber"));
      impOrdDocEle.setAttribute("BusinessDay", strBusinessDay);
      impOrdDocEle.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO, strTransactionNbr);
      impOrdDocEle.setAttribute("OrderDate", KohlsUtil.getCurrSysDate());
      impOrdDocEle.setAttribute("TerminalID", strCurrentTerminal);
      impOrdDocEle.setAttribute("SellerOrganizationCode", strCurrentStore);
      impOrdDocEle.setAttribute("OrderNo",
          impOrdDocEle.getAttribute("OrderNo") + "_" + strTransactionNbr);

      // Aj CAPE-1977
      Element eleOrderExtn=XMLUtil.getChildElement(impOrdDocEle, KohlsXMLLiterals.E_EXTN);
      eleOrderExtn.setAttribute("ExtnPAReceiptID", strReceiptId);
      if(!YFCCommon.isVoid(eleOrderExtn)){
     // CAPE-2254 Check for KC Unearn promotion for Returns - begin
        if ( (!YFCCommon.isVoid(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE)) 
      			&& eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE).equals(
      					KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT))) {
        	eleOrderExtn.setAttribute(KohlsPOCConstant.EXTN_IS_LATEST, KohlsPOCConstant.NO);
          String sExtnDeductibleOffer = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS);
          if (!YFCCommon.isVoid(sExtnDeductibleOffer)) {
            try {
              KohlsBeforeCreateReturnOrderUE obj = new KohlsBeforeCreateReturnOrderUE();
              obj.storeNo = strCurrentStore;
              obj.setPromotionsForRO(env, impOrderDoc);
            } catch (Exception e) {
              log.debug("Error in setting KC Unearn promotions");
              throw new YFSException(e.getMessage());
            }
          }
        }
      }
      // if (iCounterEligibleItem > 0) {
      
      //CAPe - 2755 - Start - Murali K
      if(ServerTypeHelper.amIOnEdgeServer()){        
        Element eleAdditionalInfo= SCXmlUtil.createChild(impOrdDocEle,KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
        eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
     }
      
      KohlsPoCCommonAPIUtil.setQueryTimeOut(env, impOrdDocEle, true);
      
      //CAPE - 2755 - End - Murali K
      impDoc = KohlsCommonUtil.invokeAPI(env,
          KohlsXMLLiterals.IMPORT_ORDER_PA, KohlsPOCConstant.IMPORT_ORDER_API, impOrderDoc);
       if (!YFCCommon.isVoid(impDoc)) {

        // updating to custome table
        updateOrginalSaleData(env, impDoc);
        Element outputDocEle = impDoc.getDocumentElement();

        Element isPOCOrderEle = XMLUtil.createChild(outputDocEle, KohlsXMLLiterals.E_POC_ORDER);
        XMLUtil.setNodeValue(isPOCOrderEle, KohlsConstant.FALSE);
        XMLUtil.importElement(outputDocEle,
            (Element) ordEle.getElementsByTagName(KohlsXMLLiterals.E_CLEAN_RECEIPT_IND).item(0));
        XMLUtil.importElement(outputDocEle,
            (Element) ordEle.getElementsByTagName(KohlsXMLLiterals.E_REPONSE_REASON_DESC).item(0));
        XMLUtil.importElement(outputDocEle, (Element) ordEle
            .getElementsByTagName(KohlsXMLLiterals.TENDERS_AVAILABLE_RETURN).item(0));
        if (log.isDebugEnabled()) {
          log.debug("gravity send doc: " + KohlsXMLUtil.getXMLString(impDoc));
        }
      }
    } catch (YFCException e) {
      // ex.printStackTrace();
      log.error("Exception in KohlsImportPOSOrderForPA of KohlsImportPOSOrderForPA. Details:"
          + e.getMessage());
      // throw new YFCException(KohlsConstant.EXTN_OTHER);
      log.error(e.getAttribute(YFCException.ERROR_CODE));
      throw e;
    }
    log.endTimer("KohlsImportPOSOrderForPA.importPOSOrderForPA");
    return impDoc;
  }

  /**
   * Create By mrjoshi * This method checks the RS response and decides whether or not the order
   * shoud be imported in the oms.
   * 
   * @param impOrderDoc
   * @param string
   * @param bIsGCOnlyOrder
   */
  private void checkIfOrderNeedsToBeImported(Document impOrderDoc, String sRSReasonType,
      boolean bIsGCOnlyOrder) {
    log.beginTimer("KohlsImportPOSOrderForPA.checkIfOrderNeedsToBeImported");
    log.debug("sRSReasonType is: " + sRSReasonType + " and bIsGCOnlyOrder is: " + bIsGCOnlyOrder);
    if (("F8".equalsIgnoreCase(sRSReasonType))
        || ("F0".equalsIgnoreCase(sRSReasonType))) {
      log.debug("Transaction is good to import");
    } else{
      log.endTimer("KohlsImportPOSOrderForPA.checkIfOrderNeedsToBeImported");
      throw new YFSException("Order Does not qualify for PA", "EXTN_OTHER",
          "RS Response code is: " + sRSReasonType + ", bIsGCOnlyOrder is: " + bIsGCOnlyOrder);
    }
    log.endTimer("KohlsImportPOSOrderForPA.checkIfOrderNeedsToBeImported");
  }

  private boolean isItemEligibleForPA(YFSEnvironment env, Element orderLineEle, String strItemId,
      int iCounterEligibleItem) {
    log.beginTimer("KohlsImportPOSOrderForPA.isItemEligibleForPA");
    log.debug("Current Line element :" + orderLineEle);
    log.debug("Current Item  element :" + strItemId);
    String strStatusCode = "";
    Element eleOrderLineExtn = XMLUtil.getChildElement(orderLineEle, KohlsXMLLiterals.E_EXTN);
    if (!YFCCommon.isVoid(eleOrderLineExtn))
      strStatusCode = eleOrderLineExtn.getAttribute("ExtnSkuStatusCode");

    if (!YFCCommon.isVoid(strItemId)) {
      if ("000".equals(strItemId.substring(4)) || recycleFeeSkuMap.containsKey(strItemId)
          || orderLineEle.getAttribute("IsReturnedItem").equals("Y")
          || orderLineEle.getAttribute("GiftFlag").equals("Y") || strStatusCode.equals("30")) {
        log.debug("Item is not eligible for Price Adjustment :" + strItemId);
        log.endTimer("KohlsImportPOSOrderForPA.isItemEligibleForPA");
        return false;

      } else {
        log.debug("Item is eligible for Price Adjustment :" + strItemId);
        log.endTimer("KohlsImportPOSOrderForPA.isItemEligibleForPA");
        return true;
      }
    } else {
      log.debug("ItemID is void, hencenot eligible for Price Adjustment");
      log.endTimer("KohlsImportPOSOrderForPA.isItemEligibleForPA");
      return false;
    }
  }

  private void updateOrginalSaleData(YFSEnvironment env, Document docInImportOrder)
      throws Exception {
    // Document docOutOrginalOrder =null;
    log.beginTimer("KohlsImportPOSOrderForPA.updateOrginalSaleData");

    if (!YFCCommon.isVoid(docInImportOrder)) {

      Element elePAOrder =
          (Element) XPathUtil.getNodeList(docInImportOrder, KohlsPOCConstant.ELE_ORDER).item(0);
      String strOHkey = elePAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      String OriginalSaleDataXML = XMLUtil.getXMLString(docInImportOrder);
      if (log.isDebugEnabled()) {
        log.debug("Input the method is  " + KohlsXMLUtil.getXMLString(docInImportOrder));
      }

      Document docInputForOrigSale =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
      Element eleInputForOrigSale = docInputForOrigSale.getDocumentElement();
      eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
      eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA, OriginalSaleDataXML);
      eleInputForOrigSale.setAttribute("PSAData", OriginalSaleDataXML);
      eleInputForOrigSale.setAttribute(KohlsPOCConstant.E_RECEIPT_ID, strOHkey);
      
      //CAPE - 2755 - Start - Murali K
     if(ServerTypeHelper.amIOnEdgeServer()){        
          Element eleAdditionalInfo= SCXmlUtil.createChild(docInputForOrigSale.getDocumentElement(),KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
          eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
       }

      //CAPe - 2755 - End - Murali K
      if (log.isDebugEnabled()) {
        log.debug("Input Document before service all  input doc: "
            + KohlsXMLUtil.getXMLString(docInputForOrigSale));
      }
      KOHLSBaseApi.invokeService(env, "KohlsPoCUpdateOrigSaleData", docInputForOrigSale);
    }
    log.beginTimer("KohlsImportPOSOrderForPA.updateOrginalSaleData");

  }

  private void loadRecycleFeeSkuHashMap(YFSEnvironment env) {
    log.beginTimer("KohlsImportPOSOrderForPA.loadRecycleFeeSkyHashMap");
    try {

      Document docCommonCodeIn = XMLUtil.createDocument("CommonCode");
      Element eleCommonCodeIn = docCommonCodeIn.getDocumentElement();
      eleCommonCodeIn.setAttribute("CodeType", "RECYCLE_FEE_SKUS");
      Document docCommonCodeTemplate = XMLUtil
          .getDocument("<CommonCodeList><CommonCode CodeName='' CodeValue=''/></CommonCodeList>");
      Document docCommonCodeOut =
          KOHLSBaseApi.invokeAPI(env, docCommonCodeTemplate, "getCommonCodeList", docCommonCodeIn);
      if (!YFCCommon.isVoid(docCommonCodeOut)) {
        NodeList nlCommonCode = docCommonCodeOut.getElementsByTagName("CommonCode");
        if (nlCommonCode.getLength() > 0) {
          for (int j = 0; j < nlCommonCode.getLength(); j++) {
            Element eleCommonCode = (Element) nlCommonCode.item(j);
            String sRecycleFeeSku = eleCommonCode.getAttribute("CodeName");
            String sCodeValue = eleCommonCode.getAttribute("CodeValue");
            recycleFeeSkuMap.put(sRecycleFeeSku, sCodeValue);
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new YFSException(e.getMessage());
    }
    log.endTimer("KohlsImportPOSOrderForPA.loadRecycleFeeSkyHashMap");

  }

  private Element getItemExtnAttribs(YFSEnvironment env, String sItemID, String strStoreNumber)
      throws Exception {
    log.beginTimer("KohlsImportPOSOrderForPA.getItemExtnAttribs");
    Element eleItemEle = null;

    try {
      Document docItemListInput = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);
      docItemListInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_ITEM_ID, sItemID);
      docItemListInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, strStoreNumber);
      docItemListInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, "EACH");

      // Output template for getItemList api
      Document docItemListOutputTemplate = XMLUtil.getDocument(
          "<ItemList><Item TaxableFlag=''><Extn ExtnDept='' ExtnClass='' ExtnSubClass='' ExtnVendorStyleNo='' ExtnEmpDiscCode='' "
              + "ExtnCallbackTypeCode=''  ExtnCallback='' ExtnCallbackStartDate='' ExtnCallbackEndDate='' /><ClassificationCodes TaxProductCode='' /></Item></ItemList>");
      
      KohlsPoCCommonAPIUtil.setQueryTimeOut(env, docItemListInput.getDocumentElement(), false);
      
      // Invoking getItemList api
      Document docItemListOutput = KohlsCommonUtil.invokeAPI(env, docItemListOutputTemplate,
          "getItemList", docItemListInput);

     eleItemEle = (Element) docItemListOutput.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);
      if (YFCCommon.isVoid(docItemListOutput)) {
        YFSException yfsException = new YFSException();
        yfsException.setErrorDescription("Value of getItemList is null");
        throw yfsException;

      }

    } catch (YFSException yfsException) {
      log.error(yfsException);
    }
    log.endTimer("KohlsImportPOSOrderForPA.getItemExtnAttribs");
    return eleItemEle;
  }

  @Override
  public void setProperties(Properties arg0) throws Exception {
    // TODO Auto-generated method stub

  }

}
