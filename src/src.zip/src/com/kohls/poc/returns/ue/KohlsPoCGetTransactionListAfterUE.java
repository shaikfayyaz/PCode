/*
 * File: KohlsPoCGetTransactionListAfterUE.java Created on Apr 11, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.returns.ue;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.pos.japi.ue.ejournal.POSGetTransactionListAfterUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;


/**
 * @author mrjoshi This class implements the POSGetTransactionListAfterUE to override the
 *         TransactionType attribute for Price adjustment when procedure id is 10103
 */
public class KohlsPoCGetTransactionListAfterUE implements POSGetTransactionListAfterUE {
  private static final YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCGetTransactionListAfterUE.class.getName());

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.tgcs.tcx.gravity.pos.japi.ue.ejournal.POSGetTransactionListAfterUE#GetTransactionList(com.
   * yantra.yfs.japi.YFSEnvironment, org.w3c.dom.Document)
   */
  public Document GetTransactionList(YFSEnvironment env, Document docInXML)
      throws YFSUserExitException {
   logger.beginTimer("KohlsPoCGetTransactionListAfterUE.GetTransactionList");
   if(logger.isDebugEnabled()){
     logger.debug("Input xml is: "+XMLUtil.getXMLString(docInXML));
   }
   NodeList nlTransaction = docInXML.getElementsByTagName(KohlsPOCConstant.E_TRANSACTION);
   if(nlTransaction.getLength()>0){
     for(int i=0; i<nlTransaction.getLength(); i++){
       Element eleTransaction = (Element) nlTransaction.item(i);
       String sProcedureID = eleTransaction.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID);
       if(!YFCCommon.isVoid(sProcedureID) && "10103".equals(sProcedureID)){
         eleTransaction.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "Price Adjustment");
       }
       else if(!YFCCommon.isVoid(sProcedureID) && "10104".equals(sProcedureID)){
         eleTransaction.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "PA Post Void");
       }
       else if(!YFCCommon.isVoid(sProcedureID) && "10105".equals(sProcedureID)){
         eleTransaction.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "PA MidVoid");
       }
     }
   }
   logger.endTimer("KohlsPoCGetTransactionListAfterUE.GetTransactionList");
    return docInXML;
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.tgcs.tcx.gravity.pos.japi.ue.ejournal.POSGetTransactionListAfterUE#GetTransactionList(com.
   * yantra.yfs.japi.YFSEnvironment, org.w3c.dom.Document)
   */
  public Document getTransactionList(YFSEnvironment env, Document docInXML)
      throws YFSUserExitException {
   logger.beginTimer("KohlsPoCGetTransactionListAfterUE.GetTransactionList");
   if(logger.isDebugEnabled()){
     logger.debug("Input xml is: "+XMLUtil.getXMLString(docInXML));
   }
   NodeList nlTransaction = docInXML.getElementsByTagName(KohlsPOCConstant.E_TRANSACTION);
   if(nlTransaction.getLength()>0){
     for(int i=0; i<nlTransaction.getLength(); i++){
       Element eleTransaction = (Element) nlTransaction.item(i);
       String sProcedureID = eleTransaction.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID);
       if(!YFCCommon.isVoid(sProcedureID) && "10103".equals(sProcedureID)){
         eleTransaction.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "Price Adjustment");
       }
       else if(!YFCCommon.isVoid(sProcedureID) && "10104".equals(sProcedureID)){
         eleTransaction.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "PA Post Void");
       }
       else if(!YFCCommon.isVoid(sProcedureID) && "10105".equals(sProcedureID)){
         eleTransaction.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "PA MidVoid");
       }
     }
   }
   logger.endTimer("KohlsPoCGetTransactionListAfterUE.GetTransactionList");
    return docInXML;
  }

}
