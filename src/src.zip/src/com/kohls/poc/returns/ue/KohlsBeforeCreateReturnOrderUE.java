/**
 * 
 */
package com.kohls.poc.returns.ue;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsPoCInvokeDataSecurityPlatform;
import com.protegrity.common.XCException;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.receipt.ReceiptUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSBeforeCreateOrderUE;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;

/**
 * @author ibmadmin
 *
 */
public class KohlsBeforeCreateReturnOrderUE implements YFSBeforeCreateOrderUE {
  private static final YFCLogCategory log =
      YFCLogCategory.instance(KohlsBeforeCreateReturnOrderUE.class.getName());
  SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
  public String storeNo ="";
  /*
   * (non-Javadoc)
   * 
   * @see com.yantra.yfs.japi.ue.YFSBeforeCreateOrderUE#beforeCreateOrder(com.yantra.yfs.japi.
   * YFSEnvironment, org.w3c.dom.Document)
   */
  @Override
  public Document beforeCreateOrder(YFSEnvironment env, Document input)
      throws YFSUserExitException {
    log.beginTimer("KohlsBeforeCreateReturnOrderUE.beforeCreateOrder");
    log.debug("Input XML from beforeCreateOrder - "+XMLUtil.getXMLString(input));
    // override with the latest till id / business day
    try {
    	//merge from R8
    	if (null != input) {
            Element inputElement = input.getDocumentElement();
            String draftOrderFlag = inputElement.getAttribute(KohlsPOCConstant.A_DRAFT_ORDER_FLAG);
            log.debug("KohlsBeforeCreateReturnOrderUE.beforeCreateOrder   draftOrderFlag :" + draftOrderFlag);
            if ("N".equalsIgnoreCase(draftOrderFlag)) {
                removeAttributewithBillToKey(inputElement);
            }
        }
    	// <TillStatus OrganizationCode="9955" TerminalID="75"/>
      Element orderElement = input.getDocumentElement();
      boolean mboolStoreOrder = false;
      String draftOrderFlag = orderElement.getAttribute("DraftOrderFlag");
      if(ServerTypeHelper.amIOnOfflineServer())
      {
    	  	orderElement.setAttribute("EntryType", "STORE-OFFLINE");
      }
      else if (ServerTypeHelper.amIOnEdgeServer())
      {
    	  	orderElement.setAttribute("EntryType", "STORE-EDGE");
      }
      String entryType = orderElement.getAttribute("EntryType");
      if("N".equalsIgnoreCase(draftOrderFlag) && "STORE-EDGE".equalsIgnoreCase(entryType))
      {
    	  	orderElement.setAttribute("ProcessPaymentOnReturnOrder", "Y");
    	  	orderElement.removeAttribute("ReturnByGiftRecipient");
    	  	mboolStoreOrder = true;
      }
      Element extnOrderExtn = XMLUtil.getChildElement(orderElement, KohlsPOCConstant.A_EXTN);
      if (extnOrderExtn == null) {
        extnOrderExtn =
            XMLUtil.getChildElement(orderElement, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
      } else {
          setPartnerRewardsID(input);
      }
      if (!YFCCommon.isVoid(orderElement.getAttribute(KohlsXMLLiterals.A_SESSION_START_TIME))) {
    	  orderElement.setAttribute(KohlsXMLLiterals.A_ORDER_DATE, orderElement.getAttribute(KohlsXMLLiterals.A_SESSION_START_TIME));
      }
      if (KohlsPOCConstant.RECEIPTED_RET.equalsIgnoreCase(extnOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE))
    		  || KohlsPOCConstant.NON_RECEIPTED_RET.equalsIgnoreCase(extnOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE))) { 
    	  
          storeNo = orderElement.getAttribute("SellerOrganizationCode");
          String terminal = orderElement.getAttribute("TerminalID");
          String extnPOCFeature = extnOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE);
          String businessDay = orderElement.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
    	  	
  		  if(YFCCommon.isVoid(orderElement.getAttribute(KohlsXMLLiterals.A_TRANSACTION_NO)))
  		  {
  			 log.debug("Transaction # blank in the input. Generating Txn #");
  			 addTransactionNumber(env, input);
  		  }	
    	  	   String posSeqNo =  orderElement.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO);
    	  	 log.info("Creating "+extnPOCFeature+" for "+storeNo+"/"+terminal+"/"+posSeqNo+" for the business day "+
 	  				businessDay);
		      extnOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ORIGINAL_POS_SEQ_NO,
		    		  posSeqNo);
		      if (orderElement.getAttribute(KohlsXMLLiterals.A_TRANSACTION_NO) != null
		          && !"".equalsIgnoreCase(orderElement.getAttribute(KohlsXMLLiterals.A_TRANSACTION_NO))) {
		        extnOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID,
		            ReceiptUtil.generateReceiptID(
		                orderElement.getAttribute(KohlsXMLLiterals.A_TRANSACTION_NO),
		                KohlsPOCConstant.RETURN_RECEIPT_LINE_NUMBER_TYPE));
		      }    	      
	      // Start CAPE- 1497 Sprint 6
	      setPromotionsForRO(env, input);
	      // End CAPE- 1497 Sprint 6
	      

      }
      
      // DM-880 check for exclusion flag
      Element orderLinesElement = SCXmlUtil.getChildElement(orderElement, KohlsXMLLiterals.E_ORDER_LINES);
	      if (!YFCCommon.isVoid(orderLinesElement)) {
	    	  ArrayList<Element> orderLines = SCXmlUtil.getChildren(orderLinesElement, KohlsXMLLiterals.E_ORDER_LINE);
	    	  if (!YFCCommon.isVoid(orderLines) && !orderLines.isEmpty()) {
	    		  for (Element currentOrderLine : orderLines) {
	    			  if (KohlsPOCConstant.RECEIPTED_RET.equalsIgnoreCase(extnOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE))
	    		    		  || KohlsPOCConstant.NON_RECEIPTED_RET.equalsIgnoreCase(extnOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE)))
	    			  {
	    				  checkForExclusionItem(env, currentOrderLine);
	    			  }
	    			  if(mboolStoreOrder) {
	    				  changeSaleDateoffset(currentOrderLine);
	    			  }
	    		  }
	    	  }
	   }
      
    }catch (Exception ex) {
      log.error("Problem in KohlsBeforeCreateReturnOrderUE "+ex.getMessage());
      throw new YFSException(ex.getMessage());
    }
    log.endTimer("KohlsBeforeCreateReturnOrderUE.beforeCreateOrder");
    return input;
  }

    /**
     * RMVP - 530 Add Sephora BI to the Text1 column of YFS_ORDER_HEADER_EXTENSION table
     *
     * @param input
     * @throws IOException
     * @throws SAXException
     * @throws ParserConfigurationException
     */
  public void setPartnerRewardsID (Document input) throws IOException, SAXException, ParserConfigurationException {

      Element eleOrder = input.getDocumentElement();
      Element extnOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.A_EXTN);
      String sExtnDeductibleOffer = extnOrderExtn.getAttribute(KohlsCorpReturnsConstants.EXTN_DEDUCTIBLE_OFFERS);
      if (!YFCCommon.isVoid(sExtnDeductibleOffer)) {
          Document docDeductibleOffers = XMLUtil.getDocument(sExtnDeductibleOffer);
          NodeList partnerRewardsIds = docDeductibleOffers.getElementsByTagName(KohlsXMLLiterals.A_PARTNER_REWARDS_ID);
          if (partnerRewardsIds.getLength() > 0){
              //Note: This code has to be changed when we get new PartnerRewardIds
              String partnerRewardId = partnerRewardsIds.item(0).getTextContent();
              if (YFCCommon.isVoid(partnerRewardId)) { // empty or null
                  return;
              }

              log.debug("Adding Sephora Rewards ID to Text1 - "+partnerRewardId);
              Element eleCustomAttributes = (Element) input.getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
              if (YFCCommon.isVoid(eleCustomAttributes)) {
                  Element customAttributes = input.createElement(KohlsPOCConstant.CUST_ATTRIBUTES);
                  customAttributes.setAttribute(KohlsPOCConstant.TEXT1, partnerRewardId);
                  eleOrder.appendChild(customAttributes);
              } else {
                  eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT1, partnerRewardId);
              }
          }
      }
  }
  
  public void changeSaleDateoffset(Element currentOrderLine) {

	  log.beginTimer("KohlsPoCBeforeChangeOrderUE.changeSaleDateoffset");
	  Element eleCustomAttributes = null;
	  String strDate2 = "";
	  String strDate1 = "";
	  NodeList ndCustomAttributes = currentOrderLine.getElementsByTagName(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
	  if(ndCustomAttributes.getLength()>0) {
		  //get Date2 - from /OrderLine/CustomAttributes[@Date2="2018-10-31T15:51:05-07:00"]
		  eleCustomAttributes = (Element)ndCustomAttributes.item(0);
		  strDate2 = eleCustomAttributes.getAttribute(KohlsXMLLiterals.A_DATE2);
		  if(!XMLUtil.isVoid(strDate2)) {
			  //set Date2 without offset 2018-10-31T15:51:05
			  strDate2 = strDate2.substring(0, strDate2.lastIndexOf("-"));
			  eleCustomAttributes.setAttribute(KohlsXMLLiterals.A_DATE2, strDate2);
		  }//end if(!XMLUtil.isVoid(strDate2))
		  //get Date1 - from /OrderLine/CustomAttributes[@Date1="2018-10-31T15:51:05-08:00"]
		  strDate1 = eleCustomAttributes.getAttribute(KohlsXMLLiterals.A_DATE1);
		  if(!XMLUtil.isVoid(strDate1)) {
			  //set Date1 without offset 2018-10-31T15:51:05
			  strDate1 = strDate1.substring(0, strDate1.lastIndexOf("-"));
			  eleCustomAttributes.setAttribute(KohlsXMLLiterals.A_DATE1, strDate1);
		  }//end if(!XMLUtil.isVoid(strDate1)) 
	  }//end  if(ndCustomAttributes.getLength()>0)
	  log.endTimer("KohlsPoCBeforeChangeOrderUE.changeSaleDateoffset");
  }
  
  public void addTransactionNumber(YFSEnvironment env , Document docIn) throws Exception {
	  log.beginTimer("KohlsBeforeCreateReturnOrderUE.addTransactionNumber");
	       String transactionNumber = "";
	         Document rootDoc = SCXmlUtil.createDocument("GetNextTransactionNumber");
	         Element rootElem = rootDoc.getDocumentElement();
	        Element inElem = docIn.getDocumentElement();
	 
	
	        if(YFCCommon.isVoid(inElem.getAttribute("SellerOrganizationCode"))) {
	 
	         rootElem.setAttribute("OrganizationCode", inElem.getAttribute("OrganizationCode"));
	  
	       } else {
	           rootElem.setAttribute("OrganizationCode", inElem.getAttribute("SellerOrganizationCode"));
	       }
	         rootElem.setAttribute("TerminalID", inElem.getAttribute("TerminalID"));
	        rootElem.setAttribute("OperatorID", inElem.getAttribute("OperatorID"));
	        rootElem.setAttribute("OrderHeaderKey", inElem.getAttribute("OrderHeaderKey"));
	       rootElem.setAttribute("ProcedureID", inElem.getAttribute("ProcedureID"));
	         rootElem.setAttribute("Date", inElem.getAttribute("Date"));
        	  Document outDoc =
        		        KOHLSBaseApi.invokeAPI(env, "getNextTransactionNumberForPOS", rootDoc);
           Element outputRoot = outDoc.getDocumentElement();

       transactionNumber = outputRoot.getAttribute("transactionNumber");
          if(!YFCCommon.isVoid(transactionNumber)) {
  
             inElem.setAttribute("TransactionNo", transactionNumber);
          }
 
          String posSequenceNo = outputRoot.getAttribute("SequenceNumber");
            if(!YFCCommon.isVoid(posSequenceNo)) {
 
            inElem.setAttribute("PosSequenceNo", posSequenceNo);
             inElem.setAttribute("POSSequenceNumber", posSequenceNo);
            }
          log.endTimer("KohlsBeforeCreateReturnOrderUE.addTransactionNumber");	
	  
	    }
  
  /**
   * This method checks if the item returned is Exlcusion item or not
   * 
   * @param env
   * @param eleOrderLine
   */
  private void checkForExclusionItem(YFSEnvironment env, Element eleOrderLine) {
	  log.beginTimer("KohlsPoCBeforeChangeOrderUE.checkForExclusionItem");
	  // Logic for checking if item returned is exclusion or not
	  boolean hasExclusionsBeenModified = false;
	  Date activeDate = null;
	  try {
		  hasExclusionsBeenModified = KohlsPoCCommonAPIUtil.hasExclusionsBeenModified(env);
	  } catch (Exception e1) {
		  e1.printStackTrace();
	  }
	  if (KohlsPoCCommonAPIUtil.exclusionsMap.isEmpty() || hasExclusionsBeenModified) {
		  try {
			  KohlsPoCCommonAPIUtil.buildExclusionsMap(env);
		  } catch (Exception e) {
			  log.error("Problem building exclusions"+e.getMessage());
		  }
	  }

	  Element orderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_EXTN);
	  String extnClass = orderLineExtn.getAttribute("ExtnItemClass");
	  String extnSubClass = orderLineExtn.getAttribute("ExtnItemSubClass");
	  String extnDept = orderLineExtn.getAttribute("ExtnItemDept");
	  try {
		  if (KohlsPoCCommonAPIUtil.exclusionsMap.containsKey(extnDept)) {
			  activeDate = sdf.parse(KohlsPoCCommonAPIUtil.exclusionsMap.get(extnDept));
		  } else if (KohlsPoCCommonAPIUtil.exclusionsMap.containsKey(extnDept + "-" + extnClass)) {
			  activeDate = sdf.parse(KohlsPoCCommonAPIUtil.exclusionsMap.get(extnDept + "-" + extnClass));
		  } else if (KohlsPoCCommonAPIUtil.exclusionsMap.containsKey(extnDept + "-" + extnClass + "-" + extnSubClass)) {
			  activeDate = sdf.parse(KohlsPoCCommonAPIUtil.exclusionsMap
					  .get(extnDept + "-" + extnClass + "-" + extnSubClass));
		  }
		  if (!YFCCommon.isVoid(activeDate) && YFCDateUtils.getCurrentDate(false).after(activeDate)) {
			  orderLineExtn.setAttribute("ExtnIsExclusionItem", "Y");
			  Element eleAwards = (Element) orderLineExtn.getElementsByTagName("Awards").item(0);
			  if (!YFCCommon.isVoid(eleAwards)) {
				  orderLineExtn.removeChild(eleAwards);
			  }
		  }
	  } catch (Exception e) {
		  e.printStackTrace();
	  }
	  log.endTimer("KohlsPoCBeforeChangeOrderUE.checkForExclusionItem");
  }

  // Start CAPE- 17 Sprint 6
  /*
   * <oag:DeductibleOffers> <oag:DeductibleOffer> <oag:OfferBalanceAmt>10.00</oag:OfferBalanceAmt>
   * <oag:EarnedAmt>10.00</oag:EarnedAmt> <oag:EligibleAmt>75.87</oag:EligibleAmt>
   * <oag:InitialOfferAmt>10.00</oag:InitialOfferAmt>
   * <oag:IndividualOfferId>123456232948857</oag:IndividualOfferId>
   * <oag:GlobalOfferId>12345</oag:GlobalOfferId> <oag:PostSaleInd>false</oag:PostSaleInd>
   * </oag:DeductibleOffer> </oag:DeductibleOffers>
   * 
   * <Order> <Promotions> <Promotion PromotionID="123456232948857"
   * PromotionType="KOHLS_CASH_UNEARNED"> <Extn ExtnCouponEventID="12345" ExtnCouponBalance=
   * "10.00 (OfferBalanceAmt)" ExtnCouponAmount="10.00 (EarnedAmt)" ExtnQualifyingAmount="75.87"
   * ExtnCouponSourceCode="9955-84-0091"/> </Promotion> </Promotions> </Order>
   */
  public void setPromotionsForRO(YFSEnvironment yfsEnv, Document input)
      throws DOMException, Exception {
    log.beginTimer("KohlsBeforeCreateReturnOrderUE.setPromotionsForRO");
    Element eleOrder = input.getDocumentElement();
    // Logic for RKC
    Element elePromotions = XMLUtil.getChildElement(eleOrder, "Promotions", true);
    NodeList nlPromotion = eleOrder.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        if (!YFCCommon.isVoid(sPromotionType) && "KOHLS_CASH_REISSUE".equals(sPromotionType)) {
          Element elePromotionExtn =
              (Element) elePromotion.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
          String sExtnCouponEventID =
              elePromotionExtn.getAttribute(KohlsPOCConstant.E_EXTN_COUPON_EVENT_ID);
          if (YFCCommon.isVoid(sExtnCouponEventID)) {
            sExtnCouponEventID = "99999";
          }
          elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, sExtnCouponEventID);
        }
      }
    }

    // Logic for KC Unearning
    // Assuming XPATH of DeductibleOffer is Order/Extn/ExtnDeductibleOffers
    Element eleOrderExtn = (Element) input.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      String sExtnDeductibleOffer = eleOrderExtn.getAttribute(KohlsCorpReturnsConstants.EXTN_DEDUCTIBLE_OFFERS);
      if (!YFCCommon.isVoid(sExtnDeductibleOffer)) {

          setPartnerRewardsID(input);
          if (!KohlsConstants.POC_FEATURE_PRICE_ADJUSTMENT.equalsIgnoreCase(
                  eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE))) {
              // for LCS, do not delete for PA
              eleOrderExtn.removeAttribute("ExtnDeductibleOffers");
          }

        // Get Loyalty Store Type for current store
        String sStoreCurrent = eleOrder.getAttribute("SellerOrganizationCode");
        String loyaltyStoreType = KohlsPoCCommonAPIUtil.getRuleValue(yfsEnv, "LY_STORE_TYPE",  sStoreCurrent, "Y2Y");
        
        Document docExtnDeductibleOffer = XMLUtil.getDocument(sExtnDeductibleOffer);
        Element eleExtnDeductibleOffer = docExtnDeductibleOffer.getDocumentElement();
        ArrayList<String> lAlreadyAddedPromotion = new ArrayList<String>();
        // For RP, there could be more than 1 DeductibleOffer. So looping.
        NodeList nlDeductibleOffer = eleExtnDeductibleOffer.getElementsByTagName("DeductibleOffer");
        if (nlDeductibleOffer.getLength() > 0) {
            for(int x=0; x<nlDeductibleOffer.getLength(); x++) {
              Element eleDeductibleOffer = (Element) nlDeductibleOffer.item(x);
           // check if we have loyalty, if so don't do below
              NodeList kcList = eleDeductibleOffer.getElementsByTagName("IndividualOfferId");
              if (kcList.getLength() > 0) {
                if (YFCCommon.isVoid(elePromotions)) {
                  elePromotions = input.createElement("Promotions");
                  eleOrder.appendChild(elePromotions);
                }
                String sTranNumner = "";
                String sExtnCouponSourceCode = "";
                NodeList nlReference = input.getElementsByTagName(KohlsPOCConstant.Reference);
                Document referencesDoc;
                //CPE-11497 - absence of Reference on Return Order , Get it from environment object
                if(0==nlReference.getLength())
                {     referencesDoc =(Document)yfsEnv.getTxnObject("referencesDoc");
                      nlReference=referencesDoc.getElementsByTagName(KohlsPOCConstant.Reference);
                }
                if (!YFCCommon.isVoid(nlReference) && nlReference.getLength() > 0) {
                  for (int i = 0; i < nlReference.getLength(); i++) {
                    Element eleReference = (Element) nlReference.item(i);
                    String sName = eleReference.getAttribute(KohlsPOCConstant.A_NAME);
                    if (!YFCCommon.isVoid(sName) && sName.contains("OTR")) {
                      String sTemp[] = sName.split("-");
                      sExtnCouponSourceCode = sTemp[2] + "-" + sTemp[3] + "-" + sTemp[4];
                      sTranNumner = sTemp[4];
                      if(!lAlreadyAddedPromotion.contains(sExtnCouponSourceCode)) {
                        lAlreadyAddedPromotion.add(sExtnCouponSourceCode);
                        break;
                      }
                    }
                  }
                }
                //for (int iOffers = 0; iOffers < nlDeductibleOffer.getLength(); iOffers++) {
                  //Element eleOffer = (Element) nlDeductibleOffer.item(iOffers);
      
                  NodeList nlIndividualOfferId = eleDeductibleOffer.getElementsByTagName("IndividualOfferId");
                  Element eleIndividualOfferId = (Element) nlIndividualOfferId.item(0);
                  String sIndividualOfferId = eleIndividualOfferId.getTextContent();
                  NodeList nlGlobalOfferID = eleDeductibleOffer.getElementsByTagName("GlobalOfferId");
                  Element eleGlobalOfferID = (Element) nlGlobalOfferID.item(0);
                  String sGlobalOfferID = eleGlobalOfferID.getTextContent();
      
                  NodeList nlOfferBalAmt = eleDeductibleOffer.getElementsByTagName("OfferBalanceAmt");
                  Element eleOfferBalAmt = (Element) nlOfferBalAmt.item(0);
                  String sOfferBalAmt = eleOfferBalAmt.getTextContent();
      
                  NodeList nlEarnedAmt = eleDeductibleOffer.getElementsByTagName("EarnedAmt");
                  Element eleEarnedAmt = (Element) nlEarnedAmt.item(0);
                  String sEarnedAmt = eleEarnedAmt.getTextContent();
      
                  NodeList nlEligibleAmt = eleDeductibleOffer.getElementsByTagName("EligibleAmt");
                  Element eleEligibleAmt = (Element) nlEligibleAmt.item(0);
                  String sEligibleAmt = eleEligibleAmt.getTextContent();
      
                  NodeList nlInitialOfferAmt = eleDeductibleOffer.getElementsByTagName("InitialOfferAmt");
                  Element eleInitialOfferAmt = (Element) nlInitialOfferAmt.item(0);
                  String sInitialOfferAmt = eleInitialOfferAmt.getTextContent();
                  Element eleCustomerDetail = XMLUtil.getChildElement(eleDeductibleOffer, KohlsXMLLiterals.E_LOYALTY_CUSTOMER_DETAILS);
                  
                  //Promotions are created if V2 or Promotion created in case of LoyaltyCustomer are not present
                  if(YFCCommon.isVoid(eleCustomerDetail) || loyaltyStoreType.contains("V2") ){

                      Element elePromotion = input.createElement("Promotion");
          
                      elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, sIndividualOfferId+"_"+sTranNumner);
                      elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, "KOHLS_CASH_UNEARNED");
                      Element eleExtnPromotion = input.createElement(KohlsPOCConstant.E_EXTN);
                      eleExtnPromotion.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_EVENT_ID, sGlobalOfferID);
                      eleExtnPromotion.setAttribute("ExtnCouponNo", sIndividualOfferId);
                      eleExtnPromotion.setAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE, sOfferBalAmt);
                      eleExtnPromotion.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT, sEarnedAmt);
                      eleExtnPromotion.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, sEligibleAmt);
                      eleExtnPromotion.setAttribute("ExtnCouponSourceCode", sExtnCouponSourceCode);
                      eleExtnPromotion.setAttribute(KohlsPOCConstant.A_EXTN_INITIAL_OFFER_AMT,
                          sInitialOfferAmt);
                      eleExtnPromotion.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED,
                          KohlsPOCConstant.YES);
                      
                      elePromotion.appendChild(eleExtnPromotion);
                      elePromotions.appendChild(elePromotion);
                  } 
                //}
                
              }
            }
        }
        //eleOrder.appendChild(elePromotions);
      }
    }
    log.endTimer("KohlsBeforeCreateReturnOrderUE.setPromotionsForRO");
  }

  // start CAPE- 1497 Sprint 6
  public boolean isEventIDInRange(YFSEnvironment yfsEnv, String sGlobalOfferID)
      throws DOMException, Exception {
    log.beginTimer("KohlsBeforeCreateReturnOrderUE.isEventIDInRange");
    boolean isEventIDInRange = false;
    int iFromRuleValue = 0;
    int iToRuleValue = 0;
    int iGlobalOfferID = 0;
    String sFromRuleValue = "0";
    String sToRuleValue = "0";
    Document docRuleListForPOS = callGetRuleListForPOS(yfsEnv, sGlobalOfferID);
    if (!YFCCommon.isVoid(docRuleListForPOS)) {
      Element eleRuleFrom = SCXmlUtil.getXpathElement(docRuleListForPOS.getDocumentElement(),
          "/RuleList/Rule[@RuleID='KC_TOKENIZATION_FROM']");
      Element eleRuleTo = SCXmlUtil.getXpathElement(docRuleListForPOS.getDocumentElement(),
          "/RuleList/Rule[@RuleID='KC_TOKENIZATION_TO']");
      if (!YFCCommon.isVoid(eleRuleFrom)) {
        sFromRuleValue = eleRuleFrom.getAttribute("RuleValue");
        iFromRuleValue = Integer.parseInt(sFromRuleValue);
      }
      if (!YFCCommon.isVoid(eleRuleTo)) {
        sToRuleValue = eleRuleTo.getAttribute("RuleValue");
        iToRuleValue = Integer.parseInt(sToRuleValue);
      }
      if (!YFCCommon.isVoid(sGlobalOfferID)) {
        iGlobalOfferID = Integer.parseInt(sGlobalOfferID);
      }
      if (iGlobalOfferID <= iToRuleValue && iGlobalOfferID >= iFromRuleValue) {
        isEventIDInRange = true;
      }
    }
    log.endTimer("KohlsBeforeCreateReturnOrderUE.isEventIDInRange");
    return isEventIDInRange;
  }
  // End CAPE- 1497 Sprint 6

  /**
   * 
   * @param yfsEnv
   * @param strCouponEventID
   * @return
   * @throws DOMException
   * @throws Exception
   */
  public Document callGetRuleListForPOS(YFSEnvironment yfsEnv, String strCouponEventID)
      throws DOMException, Exception {
    log.beginTimer("KohlsBeforeCreateReturnOrderUE.callGetRuleListForPOS");
    Document docRuleListForPOSOutput = null;

    // Prepare Input to call getCommomCodeList API
    Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
    Element eleRuleMetadata = docInput.createElement("RuleMetadata");
    eleRuleMetadata.setAttribute("GroupName", "KC_TOKENIZATION");
    eleInput.appendChild(eleRuleMetadata);

    log.debug("KohlsBeforeCreateReturnOrderUE.callGetRuleListForPOS docInput="
        + XMLUtil.getXMLString(docInput));
    // calling getCommomCodeList API
    docRuleListForPOSOutput =
        KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);

    log.debug("KohlsBeforeCreateReturnOrderUE.callGetRuleListForPOS docRuleListForPOSOutput="
        + XMLUtil.getXMLString(docRuleListForPOSOutput));
    log.endTimer("KohlsBeforeCreateReturnOrderUE.callGetRuleListForPOS");
    return docRuleListForPOSOutput;
  }

  public static String decryptCouponEventId(String sCouponNo)
      throws UnsupportedEncodingException, XCException {
    log.beginTimer("KohlsBeforeCreateReturnOrderUE.decryptCouponEventId");
    log.debug("Kohls Cash Coupon is encrypte. Initiating decryption....");
    KohlsPoCInvokeDataSecurityPlatform securityPlatfrom = new KohlsPoCInvokeDataSecurityPlatform();
    String sHostXC = YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
    String policyUser = YFSSystem.getProperty(KohlsPOCConstant.POLICY_USER);
    String dataElement = "TKN_KCASH";
    securityPlatfrom.run(sHostXC, policyUser);
    String sDecryptedCouponNo = securityPlatfrom.returnDecryptedValue(sCouponNo, dataElement);
    log.debug("Kohls Cash Coupon decryption completed successfully .....");
    log.endTimer("KohlsBeforeCreateReturnOrderUE.decryptCouponEventId");
    return sDecryptedCouponNo;
  }

  @Override
  public String beforeCreateOrder(YFSEnvironment env, String input) throws YFSUserExitException {
    return input;
  }
  /**
   * This method iterates through all the Attributes in audit level and
   * removes the attribute element with BillToKey in it.
   * 
   * @param inputElement
   */
  private void removeAttributewithBillToKey(Element inputElement) {
      stampBlankBillToKeyOnPaymentMethodElement(inputElement);

      NodeList orderAuditsList = inputElement.getElementsByTagName(KohlsPOCConstant.E_ORDER_AUDITS);
      if (orderAuditsList.getLength() > 0) {
          Element orderAuditsElement = (Element) orderAuditsList.item(0);

          List<Element> orderAudits = XMLUtil
                  .getElementsByTagName(orderAuditsElement, KohlsPOCConstant.E_ORDER_AUDIT);
          for (Element orderAudit : orderAudits) {

              NodeList orderAuditDetailsList = null;
              try {
                  orderAuditDetailsList = KohlsXPathUtil.getNodeList(orderAudit,
                          "OrderAuditLevels/OrderAuditLevel/OrderAuditDetails");
              } catch (Exception e) {

                  log.debug("KohlsBeforeCreateReturnOrderUE.removeAttributewithBillToKey   has error fetching OrderAuditDetails");
              }
              if (orderAuditDetailsList.getLength() > 0) {
                  Element orderAuditDetailsElement = (Element) orderAuditDetailsList.item(0);
                  List<Element> orderAuditDetails = XMLUtil.getElementsByTagName(orderAuditDetailsElement,
                          KohlsPOCConstant.E_ORDER_AUDIT_DETAIL);
                  for (Element orderAuditDetail : orderAuditDetails) {
                      NodeList attributesList = orderAuditDetail.getElementsByTagName(KohlsPOCConstant.E_ATTRIBUTES);
                      if (attributesList.getLength() > 0) {
                          Element attributesElement = (Element) attributesList.item(0);
                          List<Element> attributes = XMLUtil.getElementsByTagName(attributesElement,
                                  KohlsPOCConstant.E_ATTRIBUTE);
                          for (Element attribute : attributes) {
                              String attributeName = attribute.getAttribute(KohlsPOCConstant.Name);
                              log.debug("KohlsBeforeCreateReturnOrderUE.removeAttributewithBillToKey  attributeName: "
                                      + attributeName);
                              if (KohlsPOCConstant.A_BILL_TO_KEY.equalsIgnoreCase(attributeName)) {
                                  attributesElement.removeChild(attribute);
                              }
                          }
                      }

                  }
              }

          }
      }
  }

  /**
   * This Method stamps blank BillToKey in the PaymentMethod element.
   * 
   * @param inputElement
   */
  private void stampBlankBillToKeyOnPaymentMethodElement(Element inputElement) {
      NodeList paymentMethodsList = inputElement.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHODS);
      if (paymentMethodsList.getLength() > 0) {
          Element paymentMethodsElement = (Element) paymentMethodsList.item(0);

          List<Element> paymentMethods = XMLUtil.getElementsByTagName(paymentMethodsElement,
                  KohlsPOCConstant.E_PAYMENT_METHOD);
          for (Element paymentMethod : paymentMethods) {
              log.debug("KohlsBeforeCreateReturnOrderUE.stampBlankBillToKeyOnPaymentMethodElement stamping blank BillToKey");
              paymentMethod.setAttribute(KohlsPOCConstant.A_BILL_TO_KEY, "");
          }
      }
  }

}
