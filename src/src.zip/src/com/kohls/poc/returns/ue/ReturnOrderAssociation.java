package com.kohls.poc.returns.ue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.ue.OMPReturnOrderAssociationUE;

public class ReturnOrderAssociation implements OMPReturnOrderAssociationUE {

	private static final YFCLogCategory log = YFCLogCategory
			.instance(ReturnOrderAssociation.class.getName());

	/**
	 * This method will be called from the service being implemented as part of
	 * OMPReturnOrderAssociationUE only when the ExtnIsRSActive flag is "N" i.e.
	 * when RS in unavailable. Also this method will fetch either the highest
	 * priced item or latest priced item as per the items in the customer's
	 * previous orders
	 */
	public Document manageReturnOrderAssociation(YFSEnvironment env,
			Document docInXML) {
		if (YFCLogUtil.isDebugEnabled()) {
			try {
				log.debug("######### ReturnOrderAssociation.manageReturnOrderAssociation input XML #########"
						+ KohlsUtil.extractStringFromNode(docInXML));
			} catch (TransformerException e) {
				log.error("TransformerException in manageReturnOrderAssociation of ReturnOrderAssociation. Details:"
						+ e.getMessage());
			}
		}
		Element eleOrd = (Element) docInXML.getDocumentElement();
		String attrIsRSActive = eleOrd
				.getAttribute(KohlsPOCConstant.EXTN_IS_RS_ACTIVE);
		log.debug("Value of attribute ExtnIsRSActive: " + attrIsRSActive);
		if (attrIsRSActive != null && attrIsRSActive == "false") {
			log.debug("Inside the condition when ExtnIsRSActive is false");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			int iLoopCounter = 0;
			Element eleOrderLines = (Element) docInXML.getElementsByTagName(
					KohlsPOCConstant.ELEM_ORDER_LINES).item(0);
			NodeList nlOrderLine = eleOrderLines
					.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			int iNodeLength = nlOrderLine.getLength();
			log.debug("node length is: " + iNodeLength);
			for (int i = iLoopCounter; i < iNodeLength; i++) {
				Element eleOrderLine = (Element) nlOrderLine.item(i);
				String sPrimeLineNo = eleOrderLine
						.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

				if (YFCCommon.isVoid(sPrimeLineNo)) {
					continue;
				}
				log.debug("inside Order Line: " + sPrimeLineNo);

				String sDerivedFromOrderLineKey = eleOrderLine
						.getAttribute(KohlsPOCConstant.A_DERIVED_FROM_ORDER_LINE_KEY);
				if (!YFCCommon.isVoid(sDerivedFromOrderLineKey)) {
					log.debug("DerivedFromOrderLineKey is: "
							+ sDerivedFromOrderLineKey);
				}
				if (YFCCommon.isVoid(sDerivedFromOrderLineKey)) {
					Element eleAssociableOrderLines = (Element) eleOrderLine
							.getElementsByTagName(
									KohlsPOCConstant.E_ASSOCIABLE_ORD_LINES)
							.item(0);
					NodeList nlAssociableOrderLine = eleAssociableOrderLines
							.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
					double dPreviousLinePrice = 0.0D;
					Element elePreviousOrderLine = null;
					Date dPreviousOrderDate = null;
					log.debug("nlAssociableOrderLine.getLength() is: "
							+ nlAssociableOrderLine.getLength());
					int jLoopCounter = 0;
					int jNodeLength = nlAssociableOrderLine.getLength();
					if (jNodeLength > 1) {
						for (int j = jLoopCounter; j < nlAssociableOrderLine
								.getLength(); j++) {
							Element eleAssociableOrderLine = (Element) nlAssociableOrderLine
									.item(j);

							Element eleExtn = (Element) eleAssociableOrderLine
									.getElementsByTagName(
											KohlsPOCConstant.E_EXTN).item(0);
							Double dReturnPrice = Double
									.parseDouble(eleExtn
											.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE));
							Element eleOrder = (Element) eleAssociableOrderLine
									.getElementsByTagName(
											KohlsPOCConstant.ELEM_ORDER)
									.item(0);
							Date dOrderDate = null;
							try {
								dOrderDate = sdf
										.parse(eleOrder
												.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
							} catch (ParseException e) {
								e.printStackTrace();
							}
							log.debug(" J is: " + j);
							if (j == 0) {
								dPreviousLinePrice = dReturnPrice;
								elePreviousOrderLine = eleAssociableOrderLine;
								dPreviousOrderDate = dOrderDate;
								log.debug("Values are: " + dReturnPrice
										+ " and " + dOrderDate);
							} else {
								log.debug("Previous Values are: "
										+ dPreviousLinePrice + " and "
										+ dPreviousOrderDate);
								log.debug("Current Values are: " + dReturnPrice
										+ " and " + dOrderDate);
								if (dPreviousLinePrice < dReturnPrice) {
									log.debug("Current node price is greater than previous node price. So removing previous node");
									eleAssociableOrderLines
											.removeChild(elePreviousOrderLine);
									dPreviousLinePrice = dReturnPrice;
									jLoopCounter = j--;
									jNodeLength--;
									iNodeLength--;

								} else if (dPreviousLinePrice == dReturnPrice) {
									if (dPreviousOrderDate.before(dOrderDate)) {
										log.debug("Current node OrderDate is greater than previous node OrderDate. So removing previous node");
										eleAssociableOrderLines
												.removeChild(elePreviousOrderLine);
										dPreviousOrderDate = dOrderDate;
										jLoopCounter = j--;
										jNodeLength--;
										iNodeLength--;

									} else {
										log.debug("Previous node OrderDate is greater than current node OrderDate. So removing current node");
										eleAssociableOrderLines
												.removeChild(eleAssociableOrderLine);
									}
								} else {
									log.debug("Previous node price is greater than Current node price. So removing current node");
									eleAssociableOrderLines
											.removeChild(eleAssociableOrderLine);
									jLoopCounter = j--;
									jNodeLength--;
									iNodeLength--;
								}
							}

						}
					}

				} else {
					Element eleAssociableOrderLines = (Element) eleOrderLine
							.getElementsByTagName(
									KohlsPOCConstant.E_ASSOCIABLE_ORD_LINES)
							.item(0);
					NodeList nlAssociableOrderLine = eleAssociableOrderLines
							.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
					eleOrderLines.removeChild(eleOrderLine);
					iLoopCounter = i--;
					iNodeLength = iNodeLength
							- (nlAssociableOrderLine.getLength() + 1);
				}
			}
		}
		log.debug("Output of ReturnOrderAssociationUE: "
				+ XMLUtil.getXMLString(docInXML));
		return docInXML;

	}
}
