package com.kohls.poc.payments.ue;

//Java imports
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.ibm.icu.text.DecimalFormat;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsConstant;
import com.kohls.poc.api.KohlsPocInvoiceToSalesHubAPI;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionOutputStruct;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSCollectionStoredValueCardUE;

/**************************************************************************
 * File : KohlsPoc CollectionSVCcardUE.java Author : IBM Created : June 6 2013
 * Modified : June 6 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 14/06/2013 IBM First Cut.
 ***************************************************************************** 
 * 
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the gift card payment authorization using a synchronous web
 * service call to the Payment Service
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCCollectionSVCCardUE extends KOHLSBaseApi implements
		YFSCollectionStoredValueCardUE {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCCollectionSVCCardUE.class);
	
	String sStoreID = null;
	String sTerminalID = null;
	String sDriverLicense = "";
	String sTranNo = null;
	String sOperatorID = null;
	KohlsPoCCollectionUEHelper collUEHelper = new KohlsPoCCollectionUEHelper();
	YFSExtnPaymentCollectionOutputStruct outStruct = new YFSExtnPaymentCollectionOutputStruct();
	//PST-1428 - Start
	String sExtnSvcAuthTranNo = "";
	String delimiter = "_";
	String sPosSequenceNo = "";
	//PST-1428 - End

	/**
	 * This function invokes the Payment Webservice to get the Gift Card
	 * authorized from Payment Gateway
	 * 
	 * @param env
	 * @param inStruct
	 * @return outStruct
	 * @exception YFSUserExitException
	 */

	public YFSExtnPaymentCollectionOutputStruct collectionStoredValueCard(
			YFSEnvironment env, YFSExtnPaymentCollectionInputStruct inStruct)
			throws YFSUserExitException {
		logger.beginTimer("KohlsPoCCollectionSVCCardUE.collectionStoredValueCard");
		Document docGetOrderListTemplate = null;
		Document respPaymentDoc = null;
		Document reqPaymentDoc = null;
		String progId= env.getProgId();
		logger.debug("progId##############: "+
							progId);
		String sOrderHeaderKey = inStruct.orderHeaderKey;

		Document inDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
		Element eleInput = inDoc.getDocumentElement();
		eleInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
		String sDoc = KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE;
		
		try {
			String strPaymentRef6=inStruct.paymentReference6;
			if (!YFCCommon.isVoid(inStruct.callForAuthorizationStatus) && inStruct.callForAuthorizationStatus.equalsIgnoreCase(KohlsPOCConstant.AUTH_CODE_ACQUIRED)) {
				outStruct.authorizationAmount = inStruct.requestAmount;
				outStruct.tranAmount = inStruct.requestAmount;
				return outStruct;
			}
			//Changes for PSA tendering as Authorization of SVC is taken care from another class -- POC Returns Team -- Start
			
			else if((!YFCCommon.isVoid(strPaymentRef6)) && strPaymentRef6.equalsIgnoreCase("PSA")){
				
				if(logger.isDebugEnabled()){
					logger.debug("inStruct from KohlsPoCCollectionSVCCardUE.collectionStoredValueCard is: \n"+inStruct.toString());
					logger.debug("outStruct from KohlsPoCCollectionSVCCardUE.collectionStoredValueCard is: \n"+outStruct.toString());
				}
				outStruct.authorizationAmount = inStruct.requestAmount;
				outStruct.tranAmount = inStruct.requestAmount;
			//	outStruct.PaymentReference6 = inStruct.paymentReference6;
				return outStruct;
			}
			//Changes for PSA tendering as Authorization of SVC is taken care from another class -- POC Returns Team -- End
			docGetOrderListTemplate = XMLUtil.getDocument(sDoc);

			/* invoke getOrderList API to to get StoreID, TerminalID and ExtnOrigPosSequenceNo */
			Document orderListDocOutput = invokeAPI(env, docGetOrderListTemplate, "getOrderList", inDoc);
			NodeList nlElements = orderListDocOutput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
			Element eleOrder = (Element) nlElements.item(0);
			String storeNo = eleOrder.getAttribute("SellerOrganizationCode");
			sStoreID = KohlsPoCPnPUtil.prepadStoreNoWithZeros(storeNo);
			sTerminalID =  eleOrder.getAttribute("TerminalID");
			sOperatorID = eleOrder.getAttribute("OperatorID");
			// Changes for defect 2289
			//Replacing the PosSequenceNo with Order/Extn/@ExtnOrigPosSequenceNo
			Element eleExtn = (Element) ((NodeList) XPathUtil.getNodeList(eleOrder, "/OrderList/Order/Extn")).item(0);
			//PST-1428 - Start - Replacing the Order/Extn/@ExtnOrigPosSequenceNo with PosSequenceNo. 
			//If PosSequenceNo is null, then ExtnOrigPosSequenceNo is used.
			String sExtnOrigPosSequenceNo = eleExtn.getAttribute("ExtnOrigPosSequenceNo");
			String sExtnDLForSys = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_DL_FOR_SYS);
			if (!YFCCommon.isStringVoid(sExtnDLForSys)) {
				KohlsPocInvoiceToSalesHubAPI kohlsPocInvoiceToSalesHubAPI = new KohlsPocInvoiceToSalesHubAPI();
				sDriverLicense=kohlsPocInvoiceToSalesHubAPI.convertDL(sExtnDLForSys);
			}
			sPosSequenceNo = eleOrder.getAttribute("PosSequenceNo");
			String sPostVoided = XMLUtil.getAttribute(eleOrder, "PostVoided");
			String sExtnSuspendSeqNum = "";
			if(eleExtn.hasAttribute("ExtnSuspendSeqNum")){  
				sExtnSuspendSeqNum = XMLUtil.getAttribute(eleExtn, "ExtnSuspendSeqNum");
			}
			if(!("Y".equalsIgnoreCase(sPostVoided))){
				if (!YFCCommon.isVoid(sPosSequenceNo)) {
					sTranNo = collUEHelper.getPOSSeqNo(sPosSequenceNo);
					logger.debug("sPosSequenceNo has been sent in request ");
				}else{
					sTranNo = collUEHelper.getPOSSeqNo(sExtnOrigPosSequenceNo);
					logger.debug("sExtnOrigPosSequenceNo has been sent in request ");
				}
			}else{
				if(logger.isDebugEnabled()){
					logger.debug("inStruct from KohlsPoCCollectionSVCCardUE.collectionStoredValueCard is: \n"+inStruct.toString());
					//logger.debug("outStruct from KohlsPoCCollectionSVCCardUE.collectionStoredValueCard is: \n"+outStruct.toString());
				}
				Document docInStructPaymentMethodExtn = inStruct.eleExtendedFields;
				
				if(YFCCommon.isVoid(docInStructPaymentMethodExtn)){
					docInStructPaymentMethodExtn = YFCDocument.createDocument("eleExtendedFields").getDocument();
				}
				
				Element eleInStructPaymentMethod = docInStructPaymentMethodExtn.getDocumentElement();
				Element eleInStructPaymentMethodExtn = XMLUtil.getChildElement(eleInStructPaymentMethod, "Extn");
				String sInStructExtnSvcAuthTranNo = XMLUtil.getAttribute(eleInStructPaymentMethodExtn, "ExtnSvcAuthTranNo");
				logger.debug("sInStructExtnSvcAuthTranNo value is : " +sInStructExtnSvcAuthTranNo);
				if (!YFCCommon.isVoid(sInStructExtnSvcAuthTranNo)){
					sTranNo = getTranNoFromExtnSvcAuthTranNo(sInStructExtnSvcAuthTranNo , inStruct);
				}else{
					sTranNo = collUEHelper.getPOSSeqNo(sExtnOrigPosSequenceNo);
				}
			}
			//PST-1428 - End
			// Changes for defect 2289 - End
			
			if ("CHARGE".equals(inStruct.chargeType))
			{
				//Create input for SVC webservice
				reqPaymentDoc = getInputForServicesEnablement(env, inStruct);
				
				//Invoke SVC webservice
				respPaymentDoc = invokeService(env, "KohlsPoCSVCPaymentWebService", reqPaymentDoc);
				
				//Set attributes to outstruct
				createResponseDocumentfromWS(env, respPaymentDoc, inStruct);
				
				if (inStruct.bVoidTransaction) {
					if (!("0".equals(outStruct.authCode)) || !("1".equals(outStruct.authCode))) {
						outStruct.internalReturnCode = "Force Voided";
					}
					// Manoj 02/03: Fix for defect 3487
					outStruct.authorizationAmount = inStruct.requestAmount;					
					/*if(outStruct.authorizationAmount > 0.00){
						outStruct.authorizationAmount = 0.00 - outStruct.authorizationAmount;
					}*/
					return outStruct;
				} else {					
					if (KohlsPOCConstant.N_PG_SUCCESS.equals(outStruct.authCode)
							|| KohlsPOCConstant.N_PG_SOFT_REFFERAL.equals(outStruct.authCode)) {
						if(progId.contains("POS_Payment") || progId.contains("POS_TenderPayment")){
			            	 logger.debug("Inside Agent Pick #####");
			            	 outStruct.authorizationAmount = inStruct.requestAmount;
			            	 if (KohlsPOCConstant.N_PG_SOFT_REFFERAL.equals(outStruct.authCode)) {
			            		 logger.debug("Inside Agent Soft Referral #####");
			            		 outStruct.authorizationAmount = inStruct.requestAmount;
				            	 outStruct.internalReturnMessage = "REFERRAL";
			            	 }
						}
						outStruct.authReturnCode = "SUCCESS";
					} else if (KohlsPOCConstant.N_PG_DECLINE.equals(outStruct.authCode)
							|| KohlsPOCConstant.N_PG_EDIT_ERROR.equals(outStruct.authCode)) {
						if(progId.contains("POS_Payment") || progId.contains("POS_TenderPayment")){
			            	 logger.debug("Inside Agent Pick #####");
			            	 outStruct.authorizationAmount = inStruct.requestAmount;
		            		outStruct.retryFlag = "N";
		            		outStruct.suspendPayment = "N";
			            	if (KohlsPOCConstant.N_PG_DECLINE.equals(outStruct.internalReturnCode)) {
			            		logger.debug("Inside Agent Decline #####");
			            		outStruct.internalReturnMessage = "DECLINE";
			            	}else if (KohlsPOCConstant.N_PG_EDIT_ERROR.equals(outStruct.internalReturnCode)) {
			            		logger.debug("Inside Agent Decline #####");
			            		outStruct.internalReturnMessage = "Edit Error";
			            	}
			            }else{
						
						// Start: The below code is uncommented for defect fix 3531 
						// outStruct.authorizationAmount = 0D;
						outStruct.authorizationAmount = 0D;
						//End : defect fix 3531
						
						outStruct.retryFlag = "N";
						outStruct.holdOrderAndRaiseEvent = true;
						outStruct.suspendPayment = "Y";
						
						if (KohlsPOCConstant.N_PG_EDIT_ERROR
								.equals(outStruct.authCode)) {
							outStruct = collUEHelper.logPaymentTransactionError(
									outStruct, KohlsPOCConstant.N_TCX_CANCELED,
									"CANCELLED");
						} else {
							outStruct = collUEHelper.logPaymentTransactionError(
									outStruct, KohlsPOCConstant.N_TCX_DECLINED,
									"DECLINED");
						}
			            }
					} else if (KohlsPOCConstant.N_PG_INVALID_PIN.equals(outStruct.authCode)) {
						if(progId.contains("POS_Payment") || progId.contains("POS_TenderPayment")){
			            	logger.debug("Inside Agent Pick #####");
		            		logger.debug("Inside Agent Invalid Pin #####");
		            		outStruct.authorizationAmount = inStruct.requestAmount;
		            		outStruct.authReturnMessage = "Invald Pin";
		            		outStruct.retryFlag = "N";
		            		outStruct.suspendPayment = "N";
			            }else{
						outStruct.authorizationAmount = 0D;
						outStruct.retryFlag = "N";
						outStruct.holdOrderAndRaiseEvent = true;
						outStruct.authReturnMessage = "Invald Pin";
						outStruct.suspendPayment = "Y";
						outStruct = collUEHelper.logPaymentTransactionError(
								outStruct,
								KohlsPOCConstant.N_TCX_REQUEST_FOR_VALID_PIN,
								"Invalid Pin");
			            }
					} else if (KohlsPOCConstant.N_PG_REFERRAL.equals(outStruct.authCode)
							|| KohlsPOCConstant.N_PG_OFFLINE
									.equals(outStruct.authCode)) {
						if(progId.contains("POS_Payment") || progId.contains("POS_TenderPayment")){
				            	logger.debug("Inside Agent Pick #####");
				            	if (KohlsPOCConstant.N_PG_REFERRAL.equals(outStruct.authCode)){
				            		logger.debug("Inside NPG Referral #####");
				            		outStruct.authorizationAmount = inStruct.requestAmount;
				            		outStruct.internalReturnMessage = "REFERRAL";
				            		outStruct.retryFlag = "N";
				            	}else{
				            		outStruct.retryFlag = "Y";
				            		logger.debug("Inside Agent Offline #####");
				            		outStruct.OfflineStatus=true; 
									outStruct.ConditionalCallForAuthorization = "Y";
				            	}
				            }else{
						outStruct.retryFlag = "Y";
						if(KohlsPOCConstant.N_PG_REFERRAL.equals(outStruct.authCode)){
							outStruct.RequiresCallForAuthorization = true;
							// start: defect 3531
							outStruct.authorizationAmount = 0D;
							// end : defect 3531
							
						} else{
							outStruct.OfflineStatus=true; 
							outStruct.ConditionalCallForAuthorization = "Y";
						}
						
						//Manoj 09/30: Commenting offline status as per discussion with Toshiba
						/*if(KohlsPOCConstant.N_PG_OFFLINE.equals(outStruct.authCode)){
							outStruct.OfflineStatus=true;
						}*/
						// 7/30 changes
						/*Manoj 10/15: uncommenting the line as Gravity needs the MessageType=1
						for CallForAuthorization*/
						outStruct =	collUEHelper.logPaymentTransactionError(outStruct,
						KohlsPOCConstant.N_TCX_CAL_FOR_AUTHORIZATION,"CallForAuthRequested");
						// Code added for Defect 2407
						new KohlsPoCCollectionUEHelper().invokeServiceForKohlsPaymentExtension(env, inStruct, respPaymentDoc, outStruct);
				            }
					}					
				}				
			}

		} catch (Exception ex) {
			//YFSException es = (YFSException) ex;
			if (inStruct.bVoidTransaction) {
				outStruct.authorizationAmount = inStruct.requestAmount;
				outStruct.tranAmount = inStruct.requestAmount;
				outStruct.internalReturnCode = "Force Voided";
				//outStruct.OfflineStatus=true;
				return outStruct;
			} // Defect 2494 changes - begin
			else {				
				outStruct.ConditionalCallForAuthorization = "Y";
				outStruct.OfflineStatus=true; 
				outStruct.retryFlag = "Y";
				outStruct = collUEHelper.logPaymentTransactionError(outStruct,
						KohlsPOCConstant.N_TCX_CAL_FOR_AUTHORIZATION,
						"CallForAuthRequested");	
			} 
			ex.printStackTrace();
		}
		return outStruct;
	}

	/**
	 * This function prepares the request for SVC
	 * webservice call
	 * @param env
	 * @param inputStruct
	 * @return reqDoc
	 * @exception ParseException
	 */

	private Document getInputForServicesEnablement(YFSEnvironment env,
			YFSExtnPaymentCollectionInputStruct inputStruct)
			throws ParseException {

		DecimalFormat dcf = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		
		Document yDoc = YFCDocument.createDocument("PaymentRequest").getDocument();

		Element elePmntReq = yDoc.getDocumentElement();
		Element eleTran = yDoc.createElement("Transaction");
		
		// Setting absolute value of request amount (amount should be +ve even during reversal)
		Double dAmount = new Double(inputStruct.requestAmount);
		eleTran.setAttribute("TenderAmount", dcf.format(Math.abs(dAmount.doubleValue())));
		eleTran.setAttribute("StoreNumber",	sStoreID);
		eleTran.setAttribute("RegisterNumber", sTerminalID);
		eleTran.setAttribute("SVCno", inputStruct.svcNo);
		if(!YFCCommon.isStringVoid(sOperatorID)) {
			String numericOperatorID = sOperatorID.replaceAll("[A-Za-z]", "9");
			eleTran.setAttribute("OperatorID", numericOperatorID);
			logger.debug("From KohlsPoCCollectionSVCCardUE.getInputForServicesEnablement numericOperatorID is  :" + numericOperatorID + " and sOperatorID is " + sOperatorID);
		}
		eleTran.setAttribute("TransactionNumber", sTranNo);
		//PST-1428 - Start
		sExtnSvcAuthTranNo = inputStruct.svcNo.concat(delimiter).concat(sPosSequenceNo);
		logger.debug("SVCNo , posSeqNo ,sExtnSvcAuthTranNo values are :" + sExtnSvcAuthTranNo);
		//PST-1428 - End
		if (!inputStruct.bVoidTransaction) {
			eleTran.setAttribute("RequestType", "Tender");
		} else {
         		if ( KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase( inputStruct.documentType ) ) {
            			eleTran.setAttribute( KohlsPOCConstant.A_REQUEST_TYPE, KohlsXMLLiterals.ATTR_ACTIVATION_REVERSAL );
            			if (!YFCCommon.isStringVoid(sDriverLicense)) {
            		    	eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE, sDriverLicense);
            		    }
            		    else {
            		    	eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE, KohlsConstant.PSA_DRIVERS_LICENSE_NUM);	
            		    }
         		} else {
            			eleTran.setAttribute( KohlsPOCConstant.A_REQUEST_TYPE, KohlsXMLLiterals.ATTR_TENDER_REVERSAL );
         		}
		}

		// 7/30 changed logic to accept null card types as default Giftcards
		if (!YFCCommon.isVoid(inputStruct.creditCardType) && inputStruct.creditCardType.equals("02")) {
			eleTran.setAttribute("PaymentType", "MerchandiseReturnCredit");			
		} else {
			eleTran.setAttribute("PaymentType", "Giftcard");
		} 
		
		// Changes for defect 2289 - Begin
		// Hardcoding the Entry Method as "BARCODE" for all Tender Reversals
		if ((("KEYED").equalsIgnoreCase(inputStruct.entryType) 
				|| "KEYED".equalsIgnoreCase(inputStruct.paymentReference2))
				&& !(inputStruct.bVoidTransaction)) {
			eleTran.setAttribute("EntryMethod", "KEYED");
		} else {
			eleTran.setAttribute("EntryMethod", "BARCODE");
		}
		// Changes for defect 2289 - End
		
		if (!YFCCommon.isVoid(inputStruct.secureAuthenticationCode)){
			eleTran.setAttribute("SVPinNo", inputStruct.secureAuthenticationCode);
		}
		
		XMLUtil.appendChild(elePmntReq, eleTran);
		logger.debug("ydoc(Input for SVG) from KohlsPoCCollectionSVCCardUE.getInputForServicesEnablement is  :" + YFCDocument.getDocumentFor(yDoc).getDocumentElement().toString());
		return yDoc;
	}

	/**
	 * This function sets the attibutes to the UE outstruct based on 
	 * the SOAP response from the SVC system 
	 * @param env
	 * @param respDoc
	 * @param inStruct
	 * @return outputStruct
	 * @exception SQLException
	 * 
	 */
	public void createResponseDocumentfromWS(
			YFSEnvironment env, Document respDoc, YFSExtnPaymentCollectionInputStruct inStruct) {
		DateFormat df = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss"); 
		
		Element paymentResponse = respDoc.getDocumentElement();

		outStruct.internalReturnCode = paymentResponse.getAttribute("AuthResponse");
		outStruct.tranReturnMessage = paymentResponse.getAttribute("RemainingBalance");
		outStruct.internalReturnMessage = paymentResponse.getAttribute("AuthSource");
		outStruct.authCode = paymentResponse.getAttribute("ApprovalNumber");
		outStruct.authorizationId = paymentResponse.getAttribute("AuthResponse");
		outStruct.tranAmount = inStruct.requestAmount;
		// Added attribute AuthTime on 09/30 for sales hub
		outStruct.authTime = df.format(Calendar.getInstance().getTime());
		
		if (!YFCCommon.isVoid(paymentResponse.getAttribute("ApprovedAmount"))) {
			double dAppAmount = Double.parseDouble(paymentResponse.getAttribute("ApprovedAmount"));
			outStruct.authorizationAmount = dAppAmount;
		} else {
			outStruct.authorizationAmount = inStruct.requestAmount;
		}
		
		//Sudina : Offline Gift Card Changes - Start
		
   		String sExtnAuthSourceNode = paymentResponse.getAttribute("NodeId");
   	
		Document docPaymentMethodExtn = outStruct.eleExtendedFields;
	
		if(YFCCommon.isVoid(docPaymentMethodExtn)){
			docPaymentMethodExtn = YFCDocument.createDocument("eleExtendedFields").getDocument();
		}
		
		Element elePaymentMethod = docPaymentMethodExtn.getDocumentElement();
		Element elePaymentMethodExtn = XMLUtil.getChildElement(elePaymentMethod, "Extn");
		if(YFCCommon.isVoid(elePaymentMethodExtn)){
			elePaymentMethodExtn=XMLUtil.createChild(elePaymentMethod, "Extn");
		}
		    
		if(sExtnAuthSourceNode.startsWith("ISP")){
			elePaymentMethodExtn.setAttribute("ExtnAuthSourceNode", "STORE");
		} else {
			elePaymentMethodExtn.setAttribute("ExtnAuthSourceNode","CORP");
		}
		//PST-1428 - Start
		elePaymentMethodExtn.setAttribute("ExtnSvcAuthTranNo", sExtnSvcAuthTranNo);
		//PST-1428 - End
		
		if(logger.isDebugEnabled())
			logger.debug("---- docPaymentMethodExtn after check ------ "+XMLUtil.getXMLString(docPaymentMethodExtn));
		
		outStruct.eleExtendedFields = docPaymentMethodExtn;
		//Sudina : Offline Gift Card Changes - End
	}
	
	//PST-1428 - Start
	private String getTranNoFromExtnSvcAuthTranNo(
			String sInStructExtnSvcAuthTranNo, YFSExtnPaymentCollectionInputStruct inputStruct) {

		logger.beginTimer("KohlsPoCCollectionSVCCardUE.getTranNoFromExtnSvcAuthTranNo");
		String sSVCAuthNo = "";
		String sSVCAuthTranNo = "";
		String[] delimitedString = null;
		String sInstructSVCNo = inputStruct.svcNo;

		if (!YFCCommon.isVoid(sInStructExtnSvcAuthTranNo)){

			delimitedString = sInStructExtnSvcAuthTranNo.split(delimiter);
			sSVCAuthNo = delimitedString[0];
			if(sInstructSVCNo.equalsIgnoreCase(sSVCAuthNo)){
				sSVCAuthTranNo = delimitedString[1];
			}
		}
		logger.debug("sInstructSVCNo, sSVCAuthNo, sSVCAuthTranNo being retuened ;" +sInstructSVCNo + "  "+sSVCAuthNo + "  " +sSVCAuthTranNo);
		logger.endTimer("KohlsPoCCollectionSVCCardUE.getTranNoFromExtnSvcAuthTranNo");
		return sSVCAuthTranNo;
	}
	//PST-1428 - End
}
