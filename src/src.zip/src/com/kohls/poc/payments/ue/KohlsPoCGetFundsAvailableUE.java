package com.kohls.poc.payments.ue;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.util.webserviceUtil.WebServiceCaller;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSGetFundsAvailableUE;

/**************************************************************************
 * File : KohlsPoCGetFundsAvailableUE.java 
 * Author : IBM 
 * Created : January 20 2015 
 * Modified : Feb 4 2015 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 21/01/2015 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This class is invoked when request for GiftCard/KMC Balance Inquiry .
 * This class prepares request ,invokes SVC Payment Gateway and prepares response 
 *  
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCGetFundsAvailableUE extends KOHLSBaseApi implements
		YFSGetFundsAvailableUE {
	
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCGetFundsAvailableUE.class);

	
	private Properties props;


	Map<String, String> responseHM = new HashMap<String, String>();

	public Document getFundsAvailable(YFSEnvironment env, Document docInXML)
			throws YFSUserExitException {
		
		logger.beginTimer("KohlsPoCGetFundsAvailableUE.getFundsAvailable");
		

		Document requestDoc = null;
		Document responseDoc = null;
		Document outDoc = null;

		try {
			
			
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Input to getFundsAvailable--KohlsPoCGetFundsAvailableUE ::: " + XMLUtil.getXMLString( docInXML ) );
         }
			// requestDoc
			requestDoc = this.getInputForGCKMCInquiry(docInXML);
			
			
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Request to KohlsPoCSVCPaymentWebService--KohlsPoCGetFundsAvailableUE ::: " + XMLUtil.getXMLString( requestDoc ) );
         }	
			// Invoke SVC Payment WebService
			responseDoc = invokeService(env, "KohlsPoCSVCPaymentWebService",requestDoc);
			
			
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Response to KohlsPoCSVCPaymentWebService--KohlsPoCGetFundsAvailableUE ::: " + XMLUtil.getXMLString( responseDoc ) );
         }
			logger.verbose("webServiceCaller.timeTakenLong--getFundsAvailable()::::"+WebServiceCaller.timeTakenLong);
			
			// outputDoc
			outDoc = createDocumentFromResponse(env, responseDoc);

		} catch (Exception ex) {
			ex.printStackTrace();
			YFSException es = (YFSException) ex;
			if (ex.getClass().getName()
					.equalsIgnoreCase("com.yantra.yfs.japi.YFSException")
					&& (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")
							|| es.getErrorCode().equalsIgnoreCase("EXTN_IO")|| es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")
							|| es.getErrorCode().equalsIgnoreCase(
									"javax.xml.soap.SOAPException") || es
							.getErrorCode().equalsIgnoreCase(
									"javax.xml.ws.soap.SOAPFaultException"))) {

				outDoc = YFCDocument.createDocument("PaymentMethod")
						.getDocument();
				Element pmntMethEle = outDoc.getDocumentElement();
				
				pmntMethEle.setAttribute("FundsAvailable", "00.00");
				pmntMethEle.setAttribute("SVDataSource", responseHM.get(KohlsPOCConstant.SV_DATA_SOURCE));			
				pmntMethEle.setAttribute("SVCardType", responseHM.get(KohlsPOCConstant.SV_CARD_TYPE));
				pmntMethEle.setAttribute("SVAuthSource", KohlsPOCConstant.SV_AUTH_SOURCE_OFFLINE);
				pmntMethEle.setAttribute("SVAuthCodeResponse", "F9");
				pmntMethEle.setAttribute("SVCardTime", "0000");
				pmntMethEle.setAttribute("SVAuthCode", "000000");				
				
		
				responseHM.put(KohlsPOCConstant.SV_CARD_BALANCE,"00.00");
				responseHM.put(KohlsPOCConstant.SV_AUTH_SOURCE,KohlsPOCConstant.SV_AUTH_SOURCE_OFFLINE);
				responseHM.put(KohlsPOCConstant.SV_AUTH_CODE_RESPONSE, "F9");
				responseHM.put(KohlsPOCConstant.SV_AUTH_CODE, "000000");
				responseHM.put(KohlsPOCConstant.SV_CARD_AUTH_TIME, "0000");
			}
			
			else
			{
				throw new YFSUserExitException(ex.getMessage());
			}
		}

		finally {
			
			env.setTxnObject("ADMIN_AUDIT_EXTN", responseHM);

		}
		
		
      if ( logger.isDebugEnabled() )
      {
         logger.debug( "Output of getFundsAvailable--KohlsPoCGetFundsAvailableUE ::: " + XMLUtil.getXMLString( outDoc ) );
      }
		logger.endTimer("KohlsPoCGetFundsAvailableUE.getFundsAvailable");
		
		return outDoc;
	}

	
	
	

	/*
	 * This method frames the request xml for SVC Payment WebService Call
	 * 
	 * @param docInXML 
	 * @return reqDoc 
	 * @exception ParseException
	 * 
	 */
	private Document getInputForGCKMCInquiry(Document docInXML)
			throws ParseException, YFSException {

		try
		{
			
		
		logger.beginTimer("KohlsPoCGetFundsAvailableUE.getInputForGCKMCInquiry");
		Element eleInXML = docInXML.getDocumentElement();
		Document reqDoc = YFCDocument.createDocument("PaymentRequest")
				.getDocument();
		Element elePmntReq = reqDoc.getDocumentElement();
		Element eleTran = reqDoc.createElement("Transaction");
		String entryMethodStr = eleInXML.getAttribute("EntryMethod");

		if ("KEYED".equalsIgnoreCase(entryMethodStr)) {
			eleTran.setAttribute("EntryMethod", "KEYED");
		} else {
			eleTran.setAttribute("EntryMethod", "BARCODE");
		}
		
      String sOperatorID = eleInXML.getAttribute("OperatorID");
      if(!YFCCommon.isStringVoid(sOperatorID)) {
         String numericOperatorID = sOperatorID.replaceAll("[A-Za-z]", "9");
         eleTran.setAttribute("OperatorID", numericOperatorID);
         logger.debug("From KohlsPoCGetFundsAvailableUE.getInputForGCKMCInquiry numericOperatorID is  :" + numericOperatorID + " and sOperatorID is " + sOperatorID);
      }		
		String creditCardTypeStr = eleInXML.getAttribute("CreditCardType");

		if (!YFCCommon.isVoid(creditCardTypeStr)
				&& creditCardTypeStr.equals("02")) {
			eleTran.setAttribute("PaymentType", "MerchandiseReturnCredit");
			// set Card_Type in hashmap 
			responseHM.put(KohlsPOCConstant.SV_CARD_TYPE, "KMC");

		} else {
			eleTran.setAttribute("PaymentType", "Giftcard");
			// set Card_Type in hashmap
			responseHM.put(KohlsPOCConstant.SV_CARD_TYPE, "KGC");

		}

		//eleTran.setAttribute("Protected", props.getProperty("Protected"));		
		eleTran.setAttribute("RegisterNumber", eleInXML.getAttribute("TerminalID"));		
		eleTran.setAttribute("RequestType", "Inquiry");			
		String svcNoStr = eleInXML.getAttribute("PrimaryAccountNo");
		eleTran.setAttribute("SVCno", svcNoStr);		
		eleTran.setAttribute("StoreNumber", eleInXML.getAttribute("OrganizationCode"));		
		eleTran.setAttribute("TenderAmount", "00.00");		
		eleTran.setAttribute("TransactionNumber", eleInXML.getAttribute("POSSequenceNumber"));
		responseHM.put(KohlsPOCConstant.SV_ACCOUNT_NUMBER, svcNoStr);
		responseHM.put(KohlsPOCConstant.SV_DATA_SOURCE, entryMethodStr);
		String saleWithGCInq = eleInXML.getAttribute(KohlsPOCConstant.ExtraDetails5);
		if(KohlsPOCConstant.SALE_WITH_GCINQ.equalsIgnoreCase(saleWithGCInq)) {
				responseHM.put(KohlsPOCConstant.SALE_WITH_GCINQ, KohlsPOCConstant.YES);
		}
		XMLUtil.appendChild(elePmntReq, eleTran);
		logger.endTimer("KohlsPoCGetFundsAvailableUE.getInputForGCKMCInquiry");
		return reqDoc;

	}	
	catch (Exception ex){
        ex.printStackTrace();
        throw new YFSException(ex.getMessage());
}
	
}
	/* 
	 * This method processes the Payment Gateway Response and prepares OutDoc for UE and sets the hashmap to set as value in txnObj
	 * 
	 * @param env 
	 * @param resDoc 
	 * @param webServiceCaller 
	 * @return outputDoc 
	 * @throws ParseException
	 * 
	 */
	private Document createDocumentFromResponse(YFSEnvironment env,
			Document resDoc)
			throws ParseException, YFSException {

		try
		{
			
		logger.beginTimer("KohlsPoCGetFundsAvailableUE.createDocumentFromResponse");
		
		String authRes = "";
		Document outputDoc = YFCDocument.createDocument("PaymentMethod")
				.getDocument();
		Element resEle = resDoc.getDocumentElement();
		Element pmntMethEle = outputDoc.getDocumentElement();
		String approvalNo = resEle.getAttribute("ApprovalNumber");		
		
		if (KohlsPOCConstant.N_PG_SUCCESS.equals(approvalNo) 
				|| KohlsPOCConstant.N_PG_DECLINE.equals(approvalNo) 
				|| KohlsPOCConstant.N_PG_EDIT_ERROR.equals(approvalNo)
				|| KohlsPOCConstant.N_PG_REFERRAL.equals(approvalNo)
				|| KohlsPOCConstant.N_PG_OFFLINE.equals(approvalNo)) {
			
			pmntMethEle.setAttribute("SVDataSource", responseHM.get(KohlsPOCConstant.SV_DATA_SOURCE));			
			pmntMethEle.setAttribute("SVCardType", responseHM.get(KohlsPOCConstant.SV_CARD_TYPE));
			
					
			if( KohlsPOCConstant.N_PG_OFFLINE.equals(approvalNo))
			{
			pmntMethEle.setAttribute("FundsAvailable","00.00");			
			responseHM.put(KohlsPOCConstant.SV_CARD_BALANCE,"00.00");
			
			pmntMethEle.setAttribute("SVAuthCodeResponse", "F9");			
			responseHM.put(KohlsPOCConstant.SV_AUTH_CODE_RESPONSE, "F9");
			
			
			pmntMethEle.setAttribute("SVAuthSource", KohlsPOCConstant.SV_AUTH_SOURCE_OFFLINE);			
			responseHM.put(KohlsPOCConstant.SV_AUTH_SOURCE,	KohlsPOCConstant.SV_AUTH_SOURCE_OFFLINE);
			
			pmntMethEle.setAttribute("SVAuthCode", "000000");
			responseHM.put(KohlsPOCConstant.SV_AUTH_CODE,"000000");
			
			pmntMethEle.setAttribute("SVCardTime", "0000");
			responseHM.put(KohlsPOCConstant.SV_CARD_AUTH_TIME,"0000");
			
			}
			else
			{
				if( KohlsPOCConstant.N_PG_EDIT_ERROR.equals(approvalNo))
			{
				pmntMethEle.setAttribute("FundsAvailable","00.00");
				responseHM.put(KohlsPOCConstant.SV_CARD_BALANCE,"00.00");
			}
			else
			{
			pmntMethEle.setAttribute("FundsAvailable",
					resEle.getAttribute("RemainingBalance"));
			responseHM.put(KohlsPOCConstant.SV_CARD_BALANCE,
					resEle.getAttribute("RemainingBalance"));
			}
				
				pmntMethEle.setAttribute("SVAuthSource", KohlsPOCConstant.SV_AUTH_SOURCE_VALUE);
				
				responseHM.put(KohlsPOCConstant.SV_AUTH_SOURCE,
						KohlsPOCConstant.SV_AUTH_SOURCE_VALUE);
				
				authRes = resEle.getAttribute("AuthResponse");
				String authCodeRes = authRes.substring((authRes.length()) - 2);
				
				pmntMethEle.setAttribute("SVAuthCodeResponse", authCodeRes);
				
				responseHM.put(KohlsPOCConstant.SV_AUTH_CODE_RESPONSE,
						authCodeRes);
				
				String authCodeStr = authRes.substring(0,6);
				pmntMethEle.setAttribute("SVAuthCode", authCodeStr);
				
				responseHM.put(KohlsPOCConstant.SV_AUTH_CODE,
						authCodeStr);
				
				long timetaken = WebServiceCaller.timeTakenLong;
				logger.verbose("long timetaken = webServiceCaller.getTimeTaken();--createDocumentFromResponse::::"+timetaken);
				String strTimeTaken = Long.toString(timetaken);
								
				String strAuthTime = KohlsPoCPnPUtil.prepadAuthTimeWithZeros(strTimeTaken);		
				
				pmntMethEle.setAttribute("SVCardTime", strAuthTime);
				responseHM.put(KohlsPOCConstant.SV_CARD_AUTH_TIME,strAuthTime);
			}
		}
		logger.endTimer("KohlsPoCGetFundsAvailableUE.createDocumentFromResponse");
		return outputDoc;
		}
		catch (Exception ex){
	        ex.printStackTrace();
	        throw new YFSException(ex.getMessage());
	}

	}
	


	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}


}
