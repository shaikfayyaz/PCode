package com.kohls.poc.payments.ue;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.ws.soap.SOAPFaultException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.date.YDate;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionOutputStruct;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSCollectionDebitCardUE;

/**************************************************************************
 * File : KohlsPoc KohlsPoCCollectionDebitCardUE.java Author : IBM Created :
 * July 22 2013 Modified : july 22 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 22/07/2013 IBM Second Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the Debit card payment authorization using a synchronous
 * web service call to the Payment Service
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCCollectionDebitCardUE extends KOHLSBaseApi implements
		YFSCollectionDebitCardUE {
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCCollectionDebitCardUE.class);
	private HashMap<String, String> inAdditionalAttributes = new HashMap<String, String>();
	KohlsPoCCollectionUEHelper kohlsUEHelper = new KohlsPoCCollectionUEHelper();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.yantra.yfs.japi.ue.YFSCollectionDebitCardUE#collectionDebitCard
	 * (com.yantra.yfs.japi.YFSEnvironment,
	 * com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct)
	 */
	/**
	 * This function invokes the Payment Webservice to get the Debit Card
	 * authorization from Payment Gateway
	 * 
	 * @param env
	 * @param inStruct
	 * @return outStruct
	 * @exception YFSUserExitException
	 */
	public YFSExtnPaymentCollectionOutputStruct collectionDebitCard(
			YFSEnvironment env, YFSExtnPaymentCollectionInputStruct inStruct)
			throws YFSUserExitException {
		logger.beginTimer("KohlsPoCCollectionDebitCardUE.collectionDebitCard");
		YFSExtnPaymentCollectionOutputStruct outStruct = new YFSExtnPaymentCollectionOutputStruct();
//		 Start changes for SAF :Sprint 8.2
		Document docPaymentMethod = inStruct.eleExtendedFields;
		if(!YFCCommon.isVoid(docPaymentMethod)){
			Element elePaymentMethod = docPaymentMethod.getDocumentElement();
			Element elePaymentMethodExtn = XMLUtil.getChildElement(elePaymentMethod, "Extn");
			if (!(YFCCommon.isVoid(elePaymentMethodExtn)) && elePaymentMethodExtn.getAttribute("ExtnPSIPayment").equalsIgnoreCase("Y")){
				if(inStruct.bVoidTransaction) {
					outStruct.authorizationAmount = inStruct.requestAmount;
					outStruct.authorizationId = inStruct.authorizationId;
					
					
					if(logger.isDebugEnabled())
						logger.debug("outStruct from KohlsPoCCollectionDebitCardUE.collectionDebitCard is: \n"+outStruct.toString());
					logger.endTimer("KohlsPoCCollectionDebitCardUE.collectionDebitCard");
					return outStruct;
				} else {
					//Manoj 09/02: Added after discussion with Toshiba team for tender void scenario. 
					//They do not want to apply the hold if its Tender Void (ExtnSAFNum wont be present for it)
					String sExtnSAFNum = elePaymentMethodExtn.getAttribute("ExtnSAFNum");
					if(!YFCCommon.isVoid(sExtnSAFNum)) {
						logger.debug("ExtnSAFNum is not null, so this is SAF transaction. Applying the hold");
						outStruct.holdOrderAndRaiseEvent=true;
						outStruct.holdReason="SAF_Hold";
					}
					
					
					if(logger.isDebugEnabled())
						logger.debug("outStruct from KohlsPoCCollectionCreditCardUE.collectionDebitCard is: \n"+outStruct.toString());
					
					logger.endTimer("KohlsPoCCollectionDebitCardUE.collectionDebitCard");
					return outStruct;
				}
				
			}
		}
		
		// End changes for SAF :Sprint 8.2
		
		String sOrderHeaderKey = inStruct.orderHeaderKey;
		Document inputDoc = YFCDocument
				.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
		Element eleInput = inputDoc.getDocumentElement();
		eleInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
		try {

			Document templateDoc = XMLUtil
					.getDocument(KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE);
			Document respPaymentDoc = null;
			Document reqPaymentDoc;
			env.setApiTemplate(KohlsPOCConstant.API_GET_ORDER_LIST, templateDoc);
			Document orderListDocOutput = invokeAPI(env,
					KohlsPOCConstant.API_GET_ORDER_LIST, inputDoc);
			
			if(logger.isDebugEnabled())
				logger.debug("OutPut Doc for getOrderLineList:"+ XMLUtil.getXMLString(orderListDocOutput));
			
			env.clearApiTemplate(KohlsPOCConstant.API_GET_ORDER_LIST);
			NodeList nlElements = orderListDocOutput
					.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
			Element elePayment = (Element) nlElements.item(0);
			Element eleExtn = (Element) ((NodeList) XPathUtil.getNodeList(orderListDocOutput.getDocumentElement(), "/OrderList/Order/Extn")).item(0);
			logger.debug("Assign Store ID  attributes Start:");
			String storeNo = elePayment
					.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
			// code added 07/10/2013
			String prepadStroNo = KohlsPoCPnPUtil
					.prepadStoreNoWithZeros(storeNo);
			inAdditionalAttributes.put(KohlsPOCConstant.A_STORE_ID, prepadStroNo);
			inAdditionalAttributes.put(KohlsPOCConstant.A_TERMINAL_ID,
					elePayment.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
			// Changes for defect 2393: Replaces POSSeqNo with ExtnOrigPosSequenceNo.
			inAdditionalAttributes.put("ExtnOrigPosSequenceNo",
					kohlsUEHelper.getPOSSeqNo(eleExtn.getAttribute("ExtnOrigPosSequenceNo")));
			if (inStruct.chargeType.equals(KohlsPOCConstant.CHARGE)
					&& inStruct.bVoidTransaction == false) {
				logger.debug("Processing an CHARGE transaction");
				reqPaymentDoc = createInputForWebService(env, inStruct);
				respPaymentDoc = invokeService(env,
						KohlsPOCConstant.KOHLS_POC_CC_PAYMENT_WEBSERVICE,
						reqPaymentDoc);
				
				if(logger.isDebugEnabled())
					logger.debug("OutPut document From WebService:"
						+ XMLUtil.getXMLString(respPaymentDoc));

				outStruct = this.createResponse(env, respPaymentDoc, inStruct);
				
				if (KohlsPOCConstant.N_PG_SUCCESS
						.equals(outStruct.internalReturnCode)) {
					outStruct.tranAmount = inStruct.requestAmount;

				} else if (KohlsPOCConstant.N_PG_EDIT_ERROR
						.equals(outStruct.internalReturnCode)
						|| KohlsPOCConstant.N_PG_DECLINE
								.equals(outStruct.internalReturnCode)
						|| KohlsPOCConstant.N_PG_OFFLINE
								.equals(outStruct.internalReturnCode)
						|| KohlsPOCConstant.N_PG_INVALID_PIN
								.equals(outStruct.internalReturnCode)) {
					outStruct.authorizationAmount = 0D;
					outStruct.holdOrderAndRaiseEvent = true;
					outStruct.tranAmount = inStruct.requestAmount;
					outStruct.retryFlag = "N";
					outStruct.suspendPayment = "Y";
					if (!"6".equals(outStruct.internalReturnCode)) {
						outStruct = kohlsUEHelper.logPaymentTransactionError(
								outStruct, KohlsPOCConstant.N_TCX_DECLINED,
								KohlsPOCConstant.KOHLS_PAY_DECLINED);
					} else {
						outStruct = kohlsUEHelper.logPaymentTransactionError(
								outStruct,
								KohlsPOCConstant.N_TCX_REQUEST_FOR_VALID_PIN,
								"Invalid Pin");
					}
					if (KohlsPOCConstant.N_PG_OFFLINE
							.equals(outStruct.internalReturnCode)) {
						// Defect 2703 - Begin
						//outStruct.ConditionalCallForAuthorization = "Y";
						// Defect 2703 - End
						outStruct.OfflineStatus=true; 
						outStruct.retryFlag = "Y";
					}
				}
			} else if (inStruct.chargeType.equals(KohlsPOCConstant.CHARGE)
					&& inStruct.bVoidTransaction == true) {
				logger.debug("Process Void Transaction");
				reqPaymentDoc = this.createInputForWebService(env, inStruct);
				respPaymentDoc = invokeService(env,
						KohlsPOCConstant.KOHLS_POC_CC_PAYMENT_WEBSERVICE,
						reqPaymentDoc);
				outStruct = this.createResponse(env, respPaymentDoc, inStruct);
				outStruct = this.processVoidTransaction(env, outStruct,
						inStruct);
			}
		} catch (Exception ex) {
			YFSException es = (YFSException) ex;
			if (inStruct.bVoidTransaction) {
				outStruct.authorizationAmount = inStruct.requestAmount;
				outStruct.tranAmount = inStruct.requestAmount;
				outStruct.internalReturnCode = "Force Voided";
				return outStruct;
			} 
			//Manoj 12/15: Fix for defect 3371 - Begin
			/*else if (ex.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")
					&& (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT") 
							|| es.getErrorCode().equalsIgnoreCase("EXTN_IO"))){				
					// Defect 2703 - Begin
					//outStruct.ConditionalCallForAuthorization = "Y";
					// Defect 2703 - End
					outStruct.OfflineStatus=true; 
					outStruct.retryFlag = "Y";
			} else {
				outStruct.authorizationAmount = 0D;
				outStruct.suspendPayment = "Y";
				outStruct.retryFlag = "N";
				outStruct.holdOrderAndRaiseEvent = true;
				outStruct.tranAmount = inStruct.requestAmount;
				outStruct = kohlsUEHelper.logPaymentTransactionError(outStruct,
						KohlsPOCConstant.N_TCX_DECLINED, "DECLINED");
			}*/			
			else{
				outStruct.OfflineStatus=true; 
				outStruct.retryFlag = "Y";
			}
			//Manoj 12/15: Fix for defect 3371 - End
			ex.printStackTrace();
		}
		logger.endTimer("KohlsPoCCollectionDebitCardUE.collectionDebitCard");
		return outStruct;
	}

	/**
	 * This method process void transactions.
	 * 
	 * @param env
	 * @param outStruct
	 * @param inStruct
	 * @return outStruct
	 */
	private YFSExtnPaymentCollectionOutputStruct processVoidTransaction(
			YFSEnvironment env, YFSExtnPaymentCollectionOutputStruct outStruct,
			YFSExtnPaymentCollectionInputStruct inStruct) {
		outStruct.tranAmount = inStruct.requestAmount;
		if (!"0".equals(outStruct.internalReturnCode)) {
			outStruct.internalReturnCode = "Force Voided";
		}	
		return outStruct;
	}

	/**
	 * This function processes the Payment Gateway response
	 * 
	 * @param env
	 * @param respDoc
	 * @param inStruct
	 * @return
	 * @throws ParseException
	 * @throws YFSUserExitException
	 */

	private YFSExtnPaymentCollectionOutputStruct createResponse(
			YFSEnvironment env, Document respDoc,
			final YFSExtnPaymentCollectionInputStruct inStruct)
			throws ParseException {
		YFSExtnPaymentCollectionOutputStruct outputStruct = new YFSExtnPaymentCollectionOutputStruct();
		Element transactionResponse = respDoc.getDocumentElement();
		Element responseElement = XMLUtil.getFirstElementByName(
				transactionResponse, KohlsPOCConstant.E_RESPONSE);
		outputStruct.internalReturnCode = responseElement.getAttribute(
				KohlsPOCConstant.E_ACTION_CODE).trim();
		Element transactionEle = XMLUtil.getFirstElementByName(
				transactionResponse, KohlsPOCConstant.E_TRANSACTION);
		outputStruct = getTransactionAttributes(outputStruct, transactionEle);
		// mod.
		outputStruct.authorizationAmount = inStruct.requestAmount;
		if (!YFCCommon.isVoid(transactionEle.getAttribute("Amount"))) {
			// Changes as per AJB response amount
			double dbAmount = KohlsPoCCollectionUEHelper
					.convertAmtToOMSFormat(transactionEle
							.getAttribute("Amount"));
			if (dbAmount < Math.abs(inStruct.requestAmount)
					&& inStruct.requestAmount > 0) {
				outputStruct.authorizationAmount = dbAmount;
			} else if (dbAmount < Math.abs(inStruct.requestAmount)
					&& inStruct.requestAmount < 0) {
				outputStruct.authorizationAmount = 0 - dbAmount;
			}
		}

		/*
		 * if(outputStruct.authorizationAmount>=0.0){
		 * outputStruct.PaymentReference2
		 * =transactionEle.getAttribute("Reversal"); }
		 */
		//Manoj : Change for defect 2815 - Begin
		if(!(YFCCommon.isVoid(inStruct.bVoidTransaction)) && inStruct.bVoidTransaction){
			return outputStruct;
		}
		//Manoj : Change for defect 2815 - End
		String strAckMessage = transactionEle
				.getAttribute(KohlsPOCConstant.A_DEBIT_ACK_RESP_MESSAGE);
		if ((!"".equals(strAckMessage) || strAckMessage != null)
				&& "0".equals(outputStruct.internalReturnCode)) {
			try {
				// Added Logic to parse Ack request
				if (strAckMessage.substring(0, 3).equals("101")) {
					strAckMessage = "901" + strAckMessage.substring(3);
				}
				sendDebitAckReqMessage(env, strAckMessage);
			} catch (SOAPFaultException sfe) {
				return outputStruct;
			} catch (ParserConfigurationException pe) {
				pe.printStackTrace();
				return outputStruct;
			} catch (Exception e) {
				e.printStackTrace();
				return outputStruct;
			}
		}

		return outputStruct;
	}

	/**
	 * This function get the attributes from TransactionElement
	 * 
	 * @param outputStruct
	 * @param transactionEle
	 * @return outputStruct
	 * @throws ParseException
	 */
	public YFSExtnPaymentCollectionOutputStruct getTransactionAttributes(
			YFSExtnPaymentCollectionOutputStruct outputStruct,
			Element transactionEle) throws ParseException {
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'");
		DateFormat df2 = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss");
		String strPS2000data = transactionEle
				.getAttribute(KohlsPOCConstant.A_PS2000DATA);
		String strSequenceNumber = transactionEle
				.getAttribute(KohlsPOCConstant.A_SEQUENCE_NUMBER);
		String strBankResponseCode = transactionEle
				.getAttribute(KohlsPOCConstant.A_BANK_RESPONSE_CODE);
		String strPostingDate = transactionEle
				.getAttribute(KohlsPOCConstant.A_POSTING_DATE);
		String strRetrievalRefNumber = transactionEle
				.getAttribute(KohlsPOCConstant.A_RETRIEVAL_REF_NUMBER);
		String strNetworkId = transactionEle
				.getAttribute(KohlsPOCConstant.A_NETWORK_ID);
		String strTraceAuditNumber = transactionEle
				.getAttribute(KohlsPOCConstant.A_TRACE_AUDIT_NUMBER);
		// String strDepositData=transactionEle.getAttribute("DepositData");
		// String strCustomerName=transactionEle.getAttribute("CustomerName");
		outputStruct.authReturnMessage = "ps2000Data='" + strPS2000data
				+ "' sequenceNumber='" + strSequenceNumber
				+ "' bankResponseCode='" + strBankResponseCode
				+ "' postingData='" + strPostingDate + "'";
		outputStruct.internalReturnMessage = "retrievalRefNumber='"
				+ strRetrievalRefNumber + "' networkId='" + strNetworkId
				+ "' traceAuditNumber='" + strTraceAuditNumber + "'";

		// StringBuffer strBuffTranRetMessTemplate=new
		// StringBuffer("<depositData="+strDepositData+" customerName="+strCustomerName+" />");
		outputStruct.tranReturnMessage = transactionEle
				.getAttribute(KohlsPOCConstant.A_DEPOSIT_DATA);
		// Manoj 10/11 changes
		/*
		 * outputStruct.authorizationId = transactionEle
		 * .getAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER);
		 */
		String sAuthID = "";
		String sReversal = "";
		if (!YFCCommon.isVoid(transactionEle
				.getAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER))) {
			sAuthID = transactionEle
					.getAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER);
		}
		if (!YFCCommon.isVoid(transactionEle.getAttribute("Reversal"))) {
			sReversal = transactionEle.getAttribute("Reversal");
			if (!YFCCommon.isVoid(sAuthID)) {
				outputStruct.authorizationId = sAuthID + "=" + sReversal;
			} else {
				outputStruct.authorizationId = " " + "=" + sReversal;
			}
		} else {
			outputStruct.authorizationId = sAuthID;
		}
		outputStruct.authAVS = transactionEle
				.getAttribute(KohlsPOCConstant.A_AVS_RESP);
		// Added attribute AuthTime on 09/30 for sales hub
		String sAuthTime = transactionEle.getAttribute("DateTime");
		Date dtAuthTimeRaw = df1.parse(sAuthTime);
		String sAuthTimeFormatted = df2.format(dtAuthTimeRaw);
		outputStruct.authTime = sAuthTimeFormatted;

		return outputStruct;

	}

	/**
	 * This method send Acknowledgment message to PG for Auth(0) -Success.
	 * 
	 * @param env
	 * @param strAckMessage
	 * @return
	 * @throws Exception
	 */

	private void sendDebitAckReqMessage(YFSEnvironment env, String strAckMessage)
			throws Exception {
		Document ackReqMessDoc = XMLUtil.newDocument();
		Element eleProcessTransReq = ackReqMessDoc
				.createElement(KohlsPOCConstant.E_PROCESS_TRANS_REQ);
		// added
		eleProcessTransReq.setAttribute("IsDebitACKRequest", "Y");
		ackReqMessDoc.appendChild(eleProcessTransReq);
		Element eleTransaction = ackReqMessDoc
				.createElement(KohlsPOCConstant.A_DEBIT_ACK);
		eleProcessTransReq.appendChild(eleTransaction);
		eleTransaction.setAttribute(KohlsPOCConstant.A_DEBIT_ACK_REQ_MESSAGE,
				strAckMessage);
		
		if(logger.isDebugEnabled())
			logger.debug("AckReqMessDoc:" + XMLUtil.getXMLString(ackReqMessDoc));
		invokeService(env, KohlsPOCConstant.KOHLS_POC_CC_PAYMENT_WEBSERVICE,
				ackReqMessDoc);

	}

	/**
	 * This function creates Request for Authorization to PG (payment gateway).
	 * 
	 * @param env
	 * @param inputStruct
	 * @return
	 * @throws ParseException
	 * @throws ParserConfigurationException
	 */
	private Document createInputForWebService(YFSEnvironment env,
			YFSExtnPaymentCollectionInputStruct inputStruct)
			throws ParseException, ParserConfigurationException {

		Document inputDoc = XMLUtil.newDocument();
		Element eleProcessTransReq = inputDoc
				.createElement(KohlsPOCConstant.E_PROCESS_TRANS_REQ);
		Element eleReq = inputDoc.createElement(KohlsPOCConstant.E_REQUEST);
		inputDoc.appendChild(eleProcessTransReq);
		eleReq.setAttribute(KohlsPOCConstant.A_CHANNEL, KohlsPOCConstant.POC);
		eleProcessTransReq.appendChild(eleReq);
		Element eleToken = inputDoc.createElement(KohlsPOCConstant.E_TOKEN);
		eleToken.setAttribute(KohlsPOCConstant.A_CARD_NUMBER,
				inputStruct.debitCardNo);
		eleToken.setAttribute(KohlsPOCConstant.A_TYPE, KohlsPOCConstant.INTERNAL);
		eleToken.setAttribute(KohlsPOCConstant.A_PROVIDER,
				KohlsPOCConstant.PROTEGRITY);
		eleProcessTransReq.appendChild(eleToken);
		Element eleTran = inputDoc.createElement(KohlsPOCConstant.E_TRANSACTION);
		Double dAmount = new Double(inputStruct.requestAmount);
		if (dAmount.doubleValue() > 0) {
			eleTran.setAttribute(KohlsPOCConstant.A_TRANSACTION_REQUEST_TYPE,
					KohlsPOCConstant.SALE);
		} else {
			eleTran.setAttribute(KohlsPOCConstant.A_TRANSACTION_REQUEST_TYPE,
					KohlsPOCConstant.VOID_SALE);
			// Manoj : 10/11 changes
			if (!YFCCommon.isVoid(inputStruct.authorizationId)) {
				String[] tempTran = inputStruct.authorizationId.split("=");
				if (tempTran.length == 2)
					eleTran.setAttribute(KohlsPOCConstant.A_REVERSAL, tempTran[1]);
				else
					eleTran.setAttribute(KohlsPOCConstant.A_REVERSAL, "");
			}
		}
		// Fixed for defect 1268
		eleTran.setAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER,
				this.inAdditionalAttributes.get("ExtnOrigPosSequenceNo"));
		eleTran.setAttribute(KohlsPOCConstant.A_REQUEST_TYPE, KohlsPOCConstant.N_100);
		eleTran.setAttribute(KohlsPOCConstant.A_AMOUNT, KohlsPoCCollectionUEHelper
				.convertAmtToAJBFormat(Math.abs(dAmount.doubleValue())));
		//Manoj : Change forr defect 2815 - Begin 
		if(!YFCCommon.isVoid(inputStruct.bVoidTransaction) && inputStruct.bVoidTransaction){
			eleTran.setAttribute(KohlsPOCConstant.A_IS_SWIPED, KohlsPOCConstant.FALSE);
		}else {
			eleTran.setAttribute(KohlsPOCConstant.A_IS_SWIPED, KohlsPOCConstant.TRUE);
		}
		//Manoj : Change forr defect 2815 - End
		eleTran.setAttribute(KohlsPOCConstant.A_CARD_EXPIRATION_DATE, inputStruct.creditCardExpirationDate);
		eleTran.setAttribute(KohlsPOCConstant.A_CVVCODE, "");
		// String strSecAuthCode=inputStruct.secureAuthenticationCode;
		/* String[] temp= strSecAuthCode.trim().split("="); */
		// Added Swiped Data Code
		if (!YFCCommon.isVoid(inputStruct.secureAuthenticationCode)) {
			String strSecAuthCode = inputStruct.secureAuthenticationCode;
			String[] temp = strSecAuthCode.trim().split(" ");
			if (temp.length == 2) {
				eleTran.setAttribute(KohlsPOCConstant.A_SWIPEDATA, "swipe="
						+ temp[1] + " " + "pin=" + temp[0]);
			} else if (temp.length == 1)
				eleTran.setAttribute(KohlsPOCConstant.A_SWIPEDATA, "swipe="
						+ temp[0]);
		}
		eleTran.setAttribute(KohlsPOCConstant.A_PAYMENT_TYPE,
				KohlsPOCConstant.DEBIT_CARD);
		// Corrected the Tranaction Type
		eleTran.setAttribute(KohlsPOCConstant.A_TRANSACTION_TYPE, "Debit");
		// Commented pinblock
		// eleTran.setAttribute(KohlsPOCConstant.A_PIN_BLOCK, "");
		String posEcho = this.inAdditionalAttributes
				.get(KohlsPOCConstant.A_TERMINAL_ID) + inputStruct.orderNo;
		eleTran.setAttribute(KohlsPOCConstant.A_POS_ECHO, posEcho);
		eleTran.setAttribute(KohlsPOCConstant.A_ZIP_CODE,
				inputStruct.billToZipCode);
		Date dbDate = new Date();
		DateFormat sdfDateFormat = new SimpleDateFormat(
				YDate.ISO_DATETIME_FORMAT);
		eleTran.setAttribute(KohlsPOCConstant.A_DATE_TIME,
				sdfDateFormat.format(dbDate));
		Element eleStore = inputDoc.createElement("Store");
		eleStore.setAttribute(KohlsPOCConstant.A_STORE_NUMBER,
				this.inAdditionalAttributes.get(KohlsPOCConstant.A_STORE_ID));
		eleStore.setAttribute(KohlsPOCConstant.A_TERMINAL_NUMBER,
				this.inAdditionalAttributes.get(KohlsPOCConstant.A_TERMINAL_ID));
		eleStore.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO,
				this.inAdditionalAttributes.get("ExtnOrigPosSequenceNo"));
		eleProcessTransReq.appendChild(eleTran);
		eleProcessTransReq.appendChild(eleStore);
		
		
		if(logger.isDebugEnabled())
			logger.debug("Input document to WebService:"
				+ XMLUtil.getXMLString(inputDoc));
		return inputDoc;
	}

}
