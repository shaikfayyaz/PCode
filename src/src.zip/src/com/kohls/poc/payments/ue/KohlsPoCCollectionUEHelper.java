package com.kohls.poc.payments.ue;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.util.YFCUtils;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCCallingProgLogRegistry;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionOutputStruct;

public class KohlsPoCCollectionUEHelper extends KOHLSBaseApi {
	public static final String AGENTS = "AGENT";
	public static final String APIS = "API";
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCCollectionUEHelper.class.getName());

	/**
	 * This function logs the Payment Transaction Errors
	 * 
	 * @param outStruct
	 * @param sMessageType
	 * @param sMessage
	 * @return outStruct
	 */
	public YFSExtnPaymentCollectionOutputStruct logPaymentTransactionError(
			YFSExtnPaymentCollectionOutputStruct outStruct,
			String sMessageType, String sMessage) {
		logger.beginTimer("KohlsPoCCollectionUEHelper.KohlsPoCCollectionUEHelper");
		Element paymentTransactionError = null;
		if (sMessage.length() >= 100) {
			sMessage = sMessage.substring(sMessage.length() - 99,
					sMessage.length());
		}
		Document paymentTransactionErrorList = outStruct.PaymentTransactionError;
		if (YFCCommon.isVoid(paymentTransactionErrorList)) {
			paymentTransactionErrorList = YFCDocument.createDocument(
					"PaymentTransactionErrorList").getDocument();
		}
		paymentTransactionError = paymentTransactionErrorList
				.createElement("PaymentTransactionError");
		paymentTransactionError.setAttribute("MessageType", sMessageType);
		paymentTransactionError.setAttribute("Message", sMessage);
		paymentTransactionErrorList.getDocumentElement().appendChild(
				paymentTransactionError);
		outStruct.PaymentTransactionError = paymentTransactionErrorList;
		logger.endTimer("KohlsPoCCollectionUEHelper.KohlsPoCCollectionUEHelper");
		return outStruct;
	}

	/**
	 * This function change the DateFormat from MMYY YYMM
	 * 
	 * @param String
	 * @return String
	 */
	public String changeDateFormat(String sExpDate) throws YFSException {
		logger.beginTimer("KohlsPoCCollectionUEHelper.changeDateFormat");
		int count = sExpDate.length();
		String modExpDate = "";
		if (count == 4) {

			modExpDate = sExpDate.substring(count / 2)
					+ sExpDate.substring(0, (count / 2));
		} else
			throw new YFSException("InvalidCardExpirationDate", "YFS10243",
					"YFS: Invalid Date");
		logger.endTimer("KohlsPoCCollectionUEHelper.changeDateFormat");
		return modExpDate;
	}

	/**
	 * This function retrieves POSSeqNo last 4 digits
	 * 
	 * @param String
	 * @return String
	 */
	public String getPOSSeqNo(String sPosSeqNo) {
		logger.beginTimer("KohlsPoCCollectionUEHelper.getPOSSeqNo");
		String sSubSeqNo = null;

		if (sPosSeqNo.length() == 5) {
			sSubSeqNo = sPosSeqNo.substring(1);

		} else {
			sSubSeqNo = sPosSeqNo;
		}
		logger.endTimer("KohlsPoCCollectionUEHelper.getPOSSeqNo");
		return sSubSeqNo;
	}

	/**
	 * This function identifies caller Agent or API
	 * 
	 * @param sTransactionName
	 * @return boolean
	 */
	@SuppressWarnings("unchecked")
	public boolean identifyCallingProgram(String sTransactionName) {
		logger.beginTimer("KohlsPoCCollectionUEHelper.identifyCallingProgram");
		ArrayList<String> alstAgents = (ArrayList<String>) YFCCallingProgLogRegistry
				.getLogRegistryListForType(AGENTS);
		if ((alstAgents != null) && alstAgents.contains(sTransactionName)) {

			return true;
		}
		ArrayList<String> alstAPIs = (ArrayList<String>) YFCCallingProgLogRegistry
				.getLogRegistryListForType(APIS);
		if ((alstAPIs != null) && alstAPIs.contains(sTransactionName)) {
			return true;
		}
		logger.endTimer("KohlsPoCCollectionUEHelper.identifyCallingProgram");
		return false;

	}

	public HashMap<String, String> getCustData(String CustData) {
		logger.beginTimer("KohlsPoCCollectionUEHelper.getCustData");
		Map<String, String> map = new HashMap<String, String>();
		String marker = "CustData";
		String splitKey = "`";

		if ((YFCCommon.isVoid(CustData))
				|| (YFCUtils.find(CustData, marker) == -1)
				|| (YFCUtils.find(CustData, splitKey) == -1))
			return (HashMap<String, String>) map;

		int key = YFCUtils.find(CustData, marker) + marker.length() + 1;

		String[] sStringTokens = CustData.substring(key).split("`");

		String sCustName = "";

		if (!(sStringTokens.length < 3)) {
			if ((!YFCCommon.isVoid(sStringTokens[1]))
					&& (!YFCCommon.isVoid(sStringTokens[2]))) {
				sCustName = sStringTokens[0].trim() + " "
						+ sStringTokens[1].trim() + " "
						+ sStringTokens[2].trim();
			} else
				sCustName = sStringTokens[0].trim() + " "
						+ sStringTokens[2].trim();

		} else
			return (HashMap<String, String>) map;

		if (!YFCCommon.isVoid(CustData.trim())) {
			map.put("CustomerName", sCustName);
		} else {
			map.put("CustomerName", null);
		}

		String sZipCode = "";

		if (!(sStringTokens.length < 5)) {
			sZipCode = sStringTokens[4].trim();
		} else
			return (HashMap<String, String>) map;

		map.put("ZipCode", sZipCode.trim());

		String softReferralInd = "";

		if (!(sStringTokens.length < 8)) {
			softReferralInd = sStringTokens[7].trim();
		} else
			return (HashMap<String, String>) map;

		map.put("SoftReferralIndicator", softReferralInd.trim());
		logger.endTimer("KohlsPoCCollectionUEHelper.getCustData");
		return (HashMap<String, String>) map;
	}

	public static String convertAmtToAJBFormat(Double dReqAmount) {
		logger.beginTimer("KohlsPoCCollectionUEHelper.convertAmtToAJBFormat");
		DecimalFormat dcf = new DecimalFormat("0.00");
		BigDecimal ajbAmt = new BigDecimal(dcf.format(dReqAmount));
		int iNewAJBAmt = ajbAmt.multiply(new BigDecimal(100)).intValue();
		String sAJBAmt = Integer.toString(iNewAJBAmt);
		if (iNewAJBAmt < 10) {
			sAJBAmt = String.format("%02d", iNewAJBAmt);
		}
		logger.endTimer("KohlsPoCCollectionUEHelper.convertAmtToAJBFormat");
		return sAJBAmt;
	}

	public static Double convertAmtToOMSFormat(String sReqAmount) {
		BigDecimal omsAmt = new BigDecimal(Integer.parseInt(sReqAmount));
		return (omsAmt.divide(new BigDecimal(100)).doubleValue());
	}
	
	/**
	 * This method is used to Persist the data in the KOHLS_PAYMENT_EXTENSION table.
	 * 
	 * @param env
	 * @param inStruct
	 * @param respPaymentDoc
	 * @throws Exception 
	 */
	public void invokeServiceForKohlsPaymentExtension(YFSEnvironment env, YFSExtnPaymentCollectionInputStruct inStruct, Document respPaymentDoc, YFSExtnPaymentCollectionOutputStruct outStruct) throws Exception {
			logger.beginTimer("KohlsPoCCollectionUEHelper.invokeServiceForKohlsPaymentExtension");
			Element transactionResponse = respPaymentDoc.getDocumentElement();
			Document docCreateKohlsPaymentExtnIn = YFCDocument.createDocument("KohlsPaymentExtension").getDocument();
			if(!YFCCommon.isVoid(inStruct.svcNo) && KohlsPOCConstant.N_PG_REFERRAL.equals(outStruct.authCode)){
				Element eleKohlsPaymentExtnRoot = docCreateKohlsPaymentExtnIn.getDocumentElement();
				eleKohlsPaymentExtnRoot.setAttribute("PaymentKey", inStruct.paymentKey);
				eleKohlsPaymentExtnRoot.setAttribute("OrderHeaderKey", inStruct.orderHeaderKey);
				eleKohlsPaymentExtnRoot.setAttribute("OrderNo", inStruct.orderNo);
				eleKohlsPaymentExtnRoot.setAttribute("PaymentType", inStruct.paymentType);
								
				Document docExtnPaymentDataDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTION).getDocument();
				Element extnPaymentDataEle = docExtnPaymentDataDoc.getDocumentElement();
				
				extnPaymentDataEle.setAttribute("AuthAmount", String.valueOf(inStruct.requestAmount));
				extnPaymentDataEle.setAttribute("AuthAvs", outStruct.authAVS);
				extnPaymentDataEle.setAttribute("AuthCode", outStruct.authCode);
				extnPaymentDataEle.setAttribute("AuthReturnCode", outStruct.authReturnCode);
				
				extnPaymentDataEle.setAttribute("AuthReturnFlag", outStruct.authReturnFlag);
				extnPaymentDataEle.setAttribute("AuthReturnMessage", outStruct.authReturnMessage);
				extnPaymentDataEle.setAttribute("AuthTime", new YFCDate().getString(null, true));
				extnPaymentDataEle.setAttribute("CVVAuthCode", outStruct.sCVVAuthCode);
				
				extnPaymentDataEle.setAttribute("InternalReturnCode", outStruct.internalReturnCode);
				extnPaymentDataEle.setAttribute("InternalReturnFlag", outStruct.internalReturnFlag);
				
				extnPaymentDataEle.setAttribute("InternalReturnMessage", outStruct.internalReturnMessage);
				extnPaymentDataEle.setAttribute("RequestId", outStruct.requestID);
				
				extnPaymentDataEle.setAttribute("TranAmount", String.valueOf(inStruct.requestAmount));
				extnPaymentDataEle.setAttribute("TranRequestTime", new YFCDate().getString(null, true));
				extnPaymentDataEle.setAttribute("TranReturnCode", outStruct.tranReturnCode);
				extnPaymentDataEle.setAttribute("TranReturnFlag", outStruct.tranReturnFlag);

				extnPaymentDataEle.setAttribute("TranReturnMessage", outStruct.tranReturnMessage);
				extnPaymentDataEle.setAttribute("TranType", outStruct.tranType);

				eleKohlsPaymentExtnRoot.setAttribute("ExtnPaymentData", XMLUtil.getXMLString(docExtnPaymentDataDoc));
			}
			if(YFCCommon.isVoid(inStruct.svcNo)) {
				Element responseElement = XMLUtil.getFirstElementByName(transactionResponse, "Response");
				String internalReturnCode = responseElement.getAttribute("ActionCode").trim();
				if (KohlsPOCConstant.N_PG_REFERRAL.equals(internalReturnCode)){
					Element transactionElement = XMLUtil.getFirstElementByName(transactionResponse, "Transaction");
					String sAuthID = XMLUtil.getAttribute(transactionElement, "ApprovalNumber");						
					Element eleKohlsPaymentExtnRoot = docCreateKohlsPaymentExtnIn.getDocumentElement();
					eleKohlsPaymentExtnRoot.setAttribute("PaymentKey", inStruct.paymentKey);
					eleKohlsPaymentExtnRoot.setAttribute("OrderHeaderKey", inStruct.orderHeaderKey);
					eleKohlsPaymentExtnRoot.setAttribute("OrderNo", inStruct.orderNo);
					eleKohlsPaymentExtnRoot.setAttribute("PaymentType", inStruct.paymentType);
					eleKohlsPaymentExtnRoot.setAttribute("Reference1", sAuthID);
					
					Document docExtnPaymentDataDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTION).getDocument();
					Element extnPaymentDataEle = docExtnPaymentDataDoc.getDocumentElement();
					
					extnPaymentDataEle.setAttribute("AuthAmount", String.valueOf(inStruct.requestAmount));
					extnPaymentDataEle.setAttribute("AuthAvs", outStruct.authAVS);
					extnPaymentDataEle.setAttribute("AuthCode", outStruct.authCode);
					extnPaymentDataEle.setAttribute("AuthReturnCode", outStruct.authReturnCode);
					
					extnPaymentDataEle.setAttribute("AuthReturnFlag", outStruct.authReturnFlag);
					extnPaymentDataEle.setAttribute("AuthReturnMessage", outStruct.authReturnMessage);
					extnPaymentDataEle.setAttribute("AuthTime", new YFCDate().getString(null, true));
					extnPaymentDataEle.setAttribute("CVVAuthCode", outStruct.sCVVAuthCode);
					
					extnPaymentDataEle.setAttribute("InternalReturnCode", outStruct.internalReturnCode);
					extnPaymentDataEle.setAttribute("InternalReturnFlag", outStruct.internalReturnFlag);
					
					extnPaymentDataEle.setAttribute("InternalReturnMessage", outStruct.internalReturnMessage);
					extnPaymentDataEle.setAttribute("RequestId", outStruct.requestID);
					
					extnPaymentDataEle.setAttribute("TranAmount", String.valueOf(inStruct.requestAmount));
					extnPaymentDataEle.setAttribute("TranRequestTime", new YFCDate().getString(null, true));
					extnPaymentDataEle.setAttribute("TranReturnCode", outStruct.tranReturnCode);
					extnPaymentDataEle.setAttribute("TranReturnFlag", outStruct.tranReturnFlag);

					extnPaymentDataEle.setAttribute("TranReturnMessage", outStruct.tranReturnMessage);
					extnPaymentDataEle.setAttribute("TranType", outStruct.tranType);

					eleKohlsPaymentExtnRoot.setAttribute("ExtnPaymentData", XMLUtil.getXMLString(docExtnPaymentDataDoc));
				}
			}
			if(!YFCCommon.isVoid(docCreateKohlsPaymentExtnIn)){
				invokeService(env,"KohlsPoCCreateQNo", docCreateKohlsPaymentExtnIn);
			}
			logger.endTimer("KohlsPoCCollectionUEHelper.invokeServiceForKohlsPaymentExtension");			
		}
}