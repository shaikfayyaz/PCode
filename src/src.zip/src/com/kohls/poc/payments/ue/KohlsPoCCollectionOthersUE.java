package com.kohls.poc.payments.ue;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.comergent.base64.Base64;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.poc.payments.ue.pinpad.CheckCaptureResponse;
import com.protegrity.xcclient.XCAPI;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCCommercePSIStatusGenerator;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIStatus;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.VerifonePointIntegrationClient;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.CapturePSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.NRSCPSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.ShowItemsRequest;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.ycp.YFSContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionOutputStruct;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSCollectionOthersUE;

/**************************************************************************
 * File : KohlsPoCCollectionOthersUE.java 
 * Author : IBM 
 * Created : January 27 2015 
 * Modified : January 27 2015 
 * Version : 0.1
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 27/01/2015 IBM First Cut.
 *****************************************************************************
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 * This class is invoked when check tender is used as a payment type. This class invokes
 * Payment gateway to get the response code and prepares outstruct 
 *
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCCollectionOthersUE implements YFSCollectionOthersUE {
    //    private final static YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCCollectionOthersUE.class);

    private final static String OFFLINE_STATUS = "OfflineStatus";
    private YFCLogCategory logger = null;
    private YIFApi api = null;

    private YFCLogCategory getLogger() {
        if (this.logger == null)
            logger = YFCLogCategory.instance(KohlsPoCCollectionOthersUE.class);
        return logger;
    }

    /**
     * Get the api object
     *
     * @return YIFApi instance
     * @throws Exception
     */
    private YIFApi getApi() throws Exception {
        if (api == null)
            api = YIFClientFactory.getInstance().getApi();
        return api;
    }


    /**
     * Collect the authorization data for a tender by check.
     *
     * @param env      The environment
     * @param inStruct The input struct
     * @return The output struct
     * @throws YFSUserExitException
     */
    @Override
    public final YFSExtnPaymentCollectionOutputStruct collectionOthers(YFSEnvironment env, YFSExtnPaymentCollectionInputStruct inStruct) throws YFSUserExitException {

        YFSExtnPaymentCollectionOutputStruct outstruct = new YFSExtnPaymentCollectionOutputStruct();

        try {

            // validate to see if this request should be sent to the pinpad for processing
            if (!this.validate(inStruct, outstruct))
                return outstruct;

            // send this request to the pinpad for processing
            Document response = this.sendToPinpad(env, inStruct);

            // parse the response and set the properties of the outstruct
            this.parseResponse(response, inStruct, outstruct);

        } catch (Exception ex) {

            // any kind of problem with this user exit results in the offline response
            this.getLogger().error("Problem with Check Authorization: Failed over to offline logic: "
                    + ex.getMessage() + getStackTrace(ex));

            outstruct.retryFlag = "Y";
            outstruct.ConditionalCallForAuthorization = "Y";
            outstruct.PaymentReference6 = OFFLINE_STATUS;
            outstruct.OfflineStatus = true;
            outstruct.internalReturnMessage = "CallForAuthRequested";
        }
        return outstruct;
    }


    /**
     * Validate whether to perform the authorization or not.
     * examine parts of the input structure to determine.  set appropriate values on output struct
     *
     * @param inStruct  input parameter structure
     * @param outstruct output parameter structure
     * @return
     */
    private boolean validate(YFSExtnPaymentCollectionInputStruct inStruct, YFSExtnPaymentCollectionOutputStruct outstruct) {
        if ("VENDOR_CHECK".equalsIgnoreCase(inStruct.paymentType)
                || "TRAVELERS_CHECK".equalsIgnoreCase(inStruct.paymentType)
                || "PO_VOUCHER".equalsIgnoreCase(inStruct.paymentType)) {
            outstruct.authorizationAmount = inStruct.requestAmount;
            outstruct.authorizationId = inStruct.authorizationId;
            return false;
        }

        if (!"CHARGE".equals(inStruct.chargeType))
            return false;

        if (inStruct.bVoidTransaction) {
            // Generate output struct for auths during void transaction
            if ("CASH".equals(inStruct.paymentType) || "CHECK".equals(inStruct.paymentType)) {
                outstruct.authorizationAmount = inStruct.requestAmount;
                outstruct.suspendPayment = "Y";
                outstruct.retryFlag = "N";
                outstruct.holdOrderAndRaiseEvent = false;
                outstruct.tranAmount = inStruct.requestAmount;
                return false;
            }

            // force void condition on second call during offline
            else {
                outstruct.internalReturnCode = "Force Voided";
                outstruct.internalReturnMessage = "REFERRAL - DEC";
                outstruct.authorizationAmount = 0D;
                outstruct.suspendPayment = "Y";
                outstruct.retryFlag = "N";
                outstruct.holdOrderAndRaiseEvent = true;
                outstruct.tranAmount = inStruct.requestAmount;
                return false;
            }

        } else {
            // Don't authorize check auth for payment transaction
            if (inStruct.documentType.equalsIgnoreCase("9090.ex")) {
                outstruct.authorizationAmount = inStruct.requestAmount;
                outstruct.tranAmount = inStruct.requestAmount;
                outstruct.authorizationId = "000000";
                outstruct.internalReturnMessage = "APPROVED";
                outstruct.internalReturnCode = "0";
                return false;
            }

            // Second Call made by PaymentProcessAgent, or by OMS API processOrderPayments
            // to reconcile offline payments.
            // Its okay to just approve this because the check got either (auto approved as under floor limit or
            // apprved because of auth number given back after called in)
            if (OFFLINE_STATUS.equals(inStruct.paymentReference6)) {
                outstruct.authorizationAmount = inStruct.requestAmount;
                outstruct.tranAmount = inStruct.requestAmount;
                outstruct.internalReturnMessage = "APPROVED OFFLINE";
                return false;
            }
        }
        return true;
    }


    /**
     * Set the fields on the output struct from the response document retrieved from the pinpad.
     *
     * @param response     The response document from the pinpad
     * @param inStruct     The input struct used for some more data to add to the output struct
     * @param outputStruct the output struct to populate
     */
    private void parseResponse(Document response, YFSExtnPaymentCollectionInputStruct inStruct, YFSExtnPaymentCollectionOutputStruct outputStruct) throws Exception {

        KohlsPoCCollectionUEHelper helper = new KohlsPoCCollectionUEHelper();

        CheckCaptureResponse capture = new CheckCaptureResponse();
        capture.parseDocument(response);

        outputStruct.authTime = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss").format(Calendar.getInstance().getTime());

        if (capture.AUTH_CODE != null)
            outputStruct.authorizationId = capture.AUTH_CODE;
        else
            outputStruct.authorizationId = "";

        // Approved
        if (capture.isApproved()) {
            outputStruct.tranAmount = inStruct.requestAmount;
            outputStruct.internalReturnMessage = "APPROVED";
            outputStruct.authorizationAmount = inStruct.requestAmount;
        }

        // DL Required
        else if (capture.isDlRequired()) {
            helper.logPaymentTransactionError(outputStruct, KohlsPOCConstant.N_TCX_SECOND_ID_NEEDED, "DRIVER LICENSE");

            outputStruct.internalReturnCode = "4";
            outputStruct.internalReturnMessage = "DRIVER LICENCE";
        }

        // Decline
        else if (capture.isDecline()) {
            helper.logPaymentTransactionError(outputStruct, KohlsPOCConstant.N_TCX_DECLINED, "DECLINE");

            outputStruct.internalReturnCode = "8";
            outputStruct.internalReturnMessage = "DECLINE";

            outputStruct.authorizationAmount = 0;
            outputStruct.retryFlag = "N";
            outputStruct.tranAmount = inStruct.requestAmount;
            outputStruct.suspendPayment = "N";
            outputStruct.authReturnMessage = "DECLINED";
            outputStruct.holdOrderAndRaiseEvent = true;
        }

        // Offline
        else {
            helper.logPaymentTransactionError(outputStruct, KohlsPOCConstant.N_TCX_CAL_FOR_AUTHORIZATION, "CallForAuthRequested");

            outputStruct.internalReturnCode = "9";

            outputStruct.retryFlag = "Y";
            outputStruct.ConditionalCallForAuthorization = "Y";
            outputStruct.OfflineStatus = true;
            outputStruct.PaymentReference6 = OFFLINE_STATUS;
            outputStruct.internalReturnMessage = "CallForAuthRequested";
        }
    }

    /**
     * Get the psi status object which represents the connection to the pinpad
     *
     * @param env            The sterling environment
     * @param orderHeaderKey the order header key
     * @return
     * @throws Exception
     */
    private PSIStatus getStatusObject(YFSEnvironment env, String orderHeaderKey) throws Exception {
        Document inDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
        Element eleInput = inDoc.getDocumentElement();
        eleInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        String sDoc = KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE;
        Document docGetOrderListTemplate;

        // Invoke getOrderList API to to get Storeid and Terminalid
        docGetOrderListTemplate = XMLUtil.getDocument(sDoc);
        String apiName = "getOrderList";
        env.setApiTemplate(apiName, docGetOrderListTemplate);
        Document orderListDocOutput = this.getApi().invoke(env, apiName, inDoc);
        env.clearApiTemplate(apiName);

        NodeList nlElements = orderListDocOutput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
        Element eleOrder = (Element) nlElements.item(0);
        String storeNo = eleOrder.getAttribute("SellerOrganizationCode");
        String terminalId = eleOrder.getAttribute("TerminalID");
        Document docPSIInput = XMLUtil.createDocument("PSIStatus");
        Element elePSIStatus = docPSIInput.getDocumentElement();
        elePSIStatus.setAttribute(KohlsXMLLiterals.A_CLIENT_ID, terminalId);
        elePSIStatus.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, storeNo);
        Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);
        Element elePsiStatus = (Element) docPSIStatusOut.getElementsByTagName(KohlsXMLLiterals.E_PSI_STATUS).item(0);

        YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
        NRSCCommercePSIStatusGenerator generator = new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
        PSIStatus psiStatus = generator.generatePSIStatus();
        return psiStatus;
    }


    /**
     * Send for authorization to the pinpad
     *
     * @param env      Environment
     * @param inStruct authorization input information
     * @return the pinpad response document
     * @throws Exception
     */
    private Document sendToPinpad(YFSEnvironment env, YFSExtnPaymentCollectionInputStruct inStruct) throws Exception {
        try {
            PSIStatus psiStatus = this.getStatusObject(env, inStruct.orderHeaderKey);
            if (psiStatus == null)
            {
                throw new Exception("PSI Status could not be found");
            }

            NRSCPSIRequest capture = new CapturePSIRequest(psiStatus);

            capture.add("TRANS_AMOUNT", new DecimalFormat("0.00").format(inStruct.requestAmount));
            capture.add("PAYMENT_TYPE", "CHECK_SALE");
            capture.add("MICR", getDecryptedField(inStruct.chequeReference, "MICR"));
            capture.add("CHECK_TYPE", "0");

            if (!YFCCommon.isVoid(inStruct.paymentReference9))
                capture.add("DL_NUMBER", getDecryptedField(inStruct.paymentReference9, "IDNBR"));

            if (!YFCCommon.isVoid(inStruct.paymentReference8))
                capture.add("DL_STATE", inStruct.paymentReference8);

            Document response = VerifonePointIntegrationClient.send(psiStatus, capture);

            ShowItemsRequest showItems = new ShowItemsRequest(psiStatus);

            VerifonePointIntegrationClient.send(psiStatus, showItems);

            return response;

        } catch (Exception ex) {
            getLogger().error("Check tender Failover to offline:  Request to pinpad failed:" + ex.getMessage() + getStackTrace((ex)));
            return null;
        }
    }

    private String getStackTrace(Throwable throwable){
        if (throwable != null) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            throwable.printStackTrace(pw);
            return sw.toString();
        }
        return "";
    }

    /**
     * Decrypts and strips non-digit characters for the check account number
     *
     * @param encryptedValue the encrypted account number read from the micr
     * @return the decrypted and formatted account number
     * @throws Exception
     */

    private String getDecryptedField(String encryptedValue, String fieldName) throws Exception {
        XCAPI xcapi = new XCAPI();
        try {
            String user = YFSSystem.getProperty(KohlsPOCConstant.POLICY_USER);
            String host = YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);

            xcapi.openSession(user, fieldName, host);
            byte[] userBytes = user.getBytes();
            byte[] elementBytes = fieldName.getBytes();
            byte[] dataBytes = Base64.decode(encryptedValue);
            byte[] resultBytes = xcapi.decrypt(1, userBytes, elementBytes, dataBytes);

            StringBuilder sb = new StringBuilder();
            return new String(resultBytes, "UTF-8");
        } finally {
            xcapi.closeSession();
        }
    }
}
