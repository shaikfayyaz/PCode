package com.kohls.poc.payments.ue;

import java.text.ParseException;
import java.util.Properties;

import javax.xml.soap.SOAPException;
import javax.xml.ws.soap.SOAPFaultException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.tgcs.tcx.gravity.pos.japi.ue.storedvalue.POSProcessStoredValueUE;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

public class KohlsPoCGiftCardActivationUE extends KOHLSBaseApi implements POSProcessStoredValueUE{
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCGiftCardActivationUE.class);
	KohlsPoCCollectionUEHelper kohlsUEHelper=new KohlsPoCCollectionUEHelper();

	boolean bIncorrectRequest = false;
	private Properties props;

	public Document processStoredValue(YFSEnvironment env, Document docInXML)
			throws YFSUserExitException  {

		//System.out.println("InputXMLS is" + XMLUtil.getXMLString(docInXML));
		Element eleStoredValueRequest = docInXML.getDocumentElement();

		Document docGCActRequestInput = null;
		Document docGCActRequestOutput = null;
		try {
			docGCActRequestInput = getInputForGCActivation(eleStoredValueRequest, docInXML);
			if(bIncorrectRequest){
				return docGCActRequestInput;
			}

			if("PreAuthVoid".equalsIgnoreCase(eleStoredValueRequest.getAttribute("Request"))){
				Element eleStoredValueRequestResult = docInXML.createElement("StoredValueRequestResult");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "Success");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "DeAuthorize");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, "-1");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, "Internal");
				XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
				return  docInXML;
			}

			docGCActRequestOutput = invokeService(env,"KohlsPoCSVCPaymentWebService", docGCActRequestInput);
			//System.out.println("OutPut Response from SVC System :"+XmlUtils.getString(docGCActRequestOutput));
			
			if(logger.isDebugEnabled())
				logger.debug("OutPut Response from SVC System :"+XmlUtils.getString(docGCActRequestOutput));
			docInXML = createResponseDocumentfromWS(docGCActRequestOutput, docInXML);
			
			if(logger.isDebugEnabled())
				logger.debug("OutPut XML :"+XmlUtils.getString(docInXML));

		} catch (Exception ex) {
			YFSException es = (YFSException) ex;
			if (ex.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")
					&& (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT") 
							|| es.getErrorCode().equalsIgnoreCase("EXTN_IO")
							|| es.getErrorCode().equalsIgnoreCase("javax.xml.soap.SOAPException") 
							|| es.getErrorCode().equalsIgnoreCase("javax.xml.ws.soap.SOAPFaultException"))){
				Element eleStoredValueRequestResult = docInXML.createElement("StoredValueRequestResult");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "Declined");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "System Error");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, "-1");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, "Internal");
				XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
				return docInXML;
				//throw new YFCException("SOAPFaultException");
			}
		}
		return docInXML;


	}

	private Document getInputForGCActivation(Element eleStoredValueRequest, Document docInXML)
			throws ParseException {

		String sRequest = eleStoredValueRequest.getAttribute("Request");
		Document yDoc = YFCDocument.createDocument("PaymentRequest")
				.getDocument();
		Element elePmntReq = yDoc.getDocumentElement();
		Element eleTran = yDoc.createElement("Transaction");
		Double dAmount = new Double(eleStoredValueRequest.getAttribute("Amount"));
		if ("PreAuth".equalsIgnoreCase(sRequest)) {
			eleTran.setAttribute("RequestType", "Inquiry");
		} else if (("PreAuthComplete".equalsIgnoreCase(sRequest)))
		{
			eleTran.setAttribute("RequestType", "Activation");
		}else if(("Deactivate".equalsIgnoreCase(sRequest))){
			eleTran.setAttribute("RequestType", "ActivationReversal");
		}else if("PreAuthVoid".equalsIgnoreCase(sRequest)){
			eleTran.setAttribute("RequestType", "Inquiry");
		}
		else {
			bIncorrectRequest = true;
			Element eleStoredValueRequestResult = docInXML.createElement("StoredValueRequestResult");
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "ErrorPermanent");
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "Incorrect Request");
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, "-1");
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, "Internal");
			XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
			return docInXML;
		}
		eleTran.setAttribute("TenderAmount",
				Double.toString(Math.abs(dAmount.doubleValue())));
		eleTran.setAttribute("PaymentType", eleStoredValueRequest.getAttribute("Issuer"));
		String sEntryMethod = eleStoredValueRequest.getAttribute("EntryMethod");
		eleTran.setAttribute("Protected", props.getProperty("Protected"));
		if ("KEYED".equalsIgnoreCase(sEntryMethod)){
			eleTran.setAttribute("EntryMethod", "KEYED");
		}else{
			eleTran.setAttribute("EntryMethod", "BARCODE");
		}
		//code added on 07/10/13

		String storeNo=eleStoredValueRequest.getAttribute("StoreId");
		String prepadStroNo=KohlsPoCPnPUtil.prepadStoreNoWithZeros(storeNo);
		eleTran.setAttribute("StoreNumber",prepadStroNo);
		eleTran.setAttribute("RegisterNumber",
				eleStoredValueRequest.getAttribute("TerminalId"));
		eleTran.setAttribute("SVCno", eleStoredValueRequest.getAttribute("Account"));
		eleTran.setAttribute("OperatorID",
				eleStoredValueRequest.getAttribute("OperatorId"));
		// add transaction number
		eleTran.setAttribute("TransactionNumber",
				eleStoredValueRequest.getAttribute("PosSequenceNo"));



		XMLUtil.appendChild(elePmntReq, eleTran);

		return yDoc;

	}

	public Document createResponseDocumentfromWS(Document docGCActRequestOutput, Document docInXML)throws YFCException {

		Element eleStoredValueRequest = docInXML.getDocumentElement();
		Element eleStoredValueRequestResult = docInXML.createElement("StoredValueRequestResult");
		Element paymentResponse = docGCActRequestOutput.getDocumentElement();

		String sResultCode = paymentResponse.getAttribute("ApprovalNumber");
		//String sActionCode = paymentResponse.getAttribute("AuthResponse");
		//String sMessage = paymentResponse.getAttribute("AuthCodeDescription");
		String sAuthSource=paymentResponse.getAttribute("AuthSource");
		
		//Radha : Offline Gift Card Changes - Start
		
		String sExtnAuthSourceNode = paymentResponse.getAttribute("NodeId");
		Element sExtn = docInXML.createElement("Extn");

		if(sExtnAuthSourceNode.startsWith("ISP"))
		{	
		sExtn.setAttribute("ExtnAuthSourceNode","STORE");
		}
		else
		{
		sExtn.setAttribute("ExtnAuthSourceNode","CORP");
		}
		//Radha : Offline Gift Card Changes - End
		
		if("PreAuth".equalsIgnoreCase(eleStoredValueRequest.getAttribute("Request"))){

			//System.out.println("ResultCode:"+sResultCode);
			if(KohlsPOCConstant.N_PG_REFERRAL.equals(sResultCode)){
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "Success");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "Authorized");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, sResultCode);
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, sAuthSource);
			}
			//Manoj 11/07: changes for defct 1420 - Begin
			/*else if(KohlsPOCConstant.N_PG_OFFLINE.equals(sResultCode)){

				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "ErrorPermanent");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "Denied");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, sResultCode);
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, sAuthSource);
			}*/
			//Changes for Defect 1420 - End
			else {
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "ErrorDeclined");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "Declined");
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, sResultCode);
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, sAuthSource);
			}

		}else if("PreAuthComplete".equalsIgnoreCase(eleStoredValueRequest.getAttribute("Request"))){
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "Success");
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, sResultCode);
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, sAuthSource);
			if((KohlsPOCConstant.N_PG_SUCCESS.equals(sResultCode))){
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "Activated");
			}else{
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "OfflineActivation");
			}
		}else if("Deactivate".equals(eleStoredValueRequest.getAttribute("Request"))){
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESULT_CODE, "Success");
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_NETWORK_ID, sAuthSource);
			eleStoredValueRequestResult.setAttribute(ATTRIBUTE_RESPONSE_CODE, sResultCode);
			if((KohlsPOCConstant.N_PG_SUCCESS.equals(sResultCode))){
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "Deactivated");

			}else{
				eleStoredValueRequestResult.setAttribute(ATTRIBUTE_ACTION_CODE, "OfflineDeactivation");
			}
		}
		/*		eleStoredValueRequestResult.setAttribute(ATTRIBUTE_APPROVAL_CODE_OUTPUT, "00005");
		eleStoredValueRequestResult.setAttribute(ATTRIBUTE_MESSAGE, "");
		eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PIN, "839376");
	    eleStoredValueRequestResult.setAttribute(ATTRIBUTE_PROCESSOR_VERSION_NUMBER, "0.0");*/
	    
	    	//Radha : Offline Gift Card Changes - Start
	    	
	    	XMLUtil.appendChild(eleStoredValueRequestResult, sExtn);
	    	
	    	//Radha : Offline Gift Card Changes - End
	    	
		XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
		//System.out.println("Create OutPut XML:"+ XmlUtils.getString(docInXML));
		
		if(logger.isDebugEnabled())
			logger.debug("Create OutPut XML:"+ XmlUtils.getString(docInXML));
		return docInXML;
	}
	
	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}
}
