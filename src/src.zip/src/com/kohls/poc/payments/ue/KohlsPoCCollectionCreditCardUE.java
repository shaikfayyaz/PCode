package com.kohls.poc.payments.ue;

//Java imports
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.util.YFCUtils;
import com.yantra.yfc.date.YDate;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionOutputStruct;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSCollectionCreditCardUE;

/**************************************************************************
 * File : KohlsPoc CollectionCreditcardUE.java Author : IBM Created : June 6
 * 2013 Modified : June 6 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 14/06/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : Revisit tranamount field after testing with Payment Gateway stub
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the credit card payment authorization using a synchronous
 * web service call to the Payment Service
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCCollectionCreditCardUE extends KOHLSBaseApi implements
		YFSCollectionCreditCardUE {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCCollectionCreditCardUE.class);

	private HashMap<String, String> inAdditionalAttributes = new HashMap<String, String>();
	private HashMap<String, String> outAdditionalAttributes = new HashMap<String, String>();
	KohlsPoCCollectionUEHelper collUEHelper = new KohlsPoCCollectionUEHelper();
	public final static String FORCE_VOID = "Force Voided";

	/**
	 * This function invokes the Payment Webservice to get the Credit Card
	 * authorized from Payment Gateway
	 * 
	 * @param env
	 * @param inStruct
	 * @return outStruct
	 * @exception YFSUserExitException
	 */
	public final YFSExtnPaymentCollectionOutputStruct collectionCreditCard(
			final YFSEnvironment env,
			final YFSExtnPaymentCollectionInputStruct inStruct)
			throws YFSUserExitException {
		
		logger.beginTimer("KohlsPoCCollectionCreditCardUE.collectionCreditCard");
		YFSExtnPaymentCollectionOutputStruct outStruct = new YFSExtnPaymentCollectionOutputStruct();
		String voidCharge= (String)env.getTxnObject("ProcessVoidCharge");
		
		//dummy closing the voided charge created for OMNI
		if("Y".equalsIgnoreCase(voidCharge))
		{ 
			try
			{
			Date currentDate = new Date();
		      String strOrderDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(currentDate);
		      SimpleDateFormat formatter = new SimpleDateFormat(
		              "yyyy-MM-dd'T'HH:mm:ss");
		          Date dtOrderDate = formatter.parse(strOrderDate);
		          Calendar calOrderDate = Calendar.getInstance();
		          calOrderDate.setTime(dtOrderDate);
		          calOrderDate.add(Calendar.DATE,
		              Integer.parseInt("7"));
		          SimpleDateFormat dateFormat = new SimpleDateFormat(
		                  "yyyyMMddHHmmss");
		        String strAuthExpDate = dateFormat.format(calOrderDate.getTime());
			    outStruct.tranAmount = inStruct.requestAmount;
			    outStruct.authorizationId = "999999";
			    outStruct.authorizationAmount = inStruct.requestAmount;
			    outStruct.holdOrderAndRaiseEvent = false;
			    outStruct.holdReason = "";
			    outStruct.retryFlag = "N";
			    outStruct.authorizationExpirationDate = strAuthExpDate;
			}
			catch(Exception ex)
			{
				logger.error("Exception while parsing date" + ex);
			}
			 return outStruct;
		}
		DateFormat df = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss");
//		 Start changes for SAF :Sprint 8.2
		Document docPaymentMethod = inStruct.eleExtendedFields;
		if(!YFCCommon.isVoid(docPaymentMethod)){
			Element elePaymentMethod = docPaymentMethod.getDocumentElement();
			Element elePaymentMethodExtn = XMLUtil.getChildElement(elePaymentMethod, "Extn");
			if (!(YFCCommon.isVoid(elePaymentMethodExtn)) && elePaymentMethodExtn.getAttribute("ExtnPSIPayment").equalsIgnoreCase("Y")){
				String strPaymentRef6=inStruct.paymentReference6;
				if(inStruct.bVoidTransaction) {
					outStruct.authorizationAmount = inStruct.requestAmount;
					outStruct.authorizationId = inStruct.authorizationId;
					
					logger.debug("outStruct from KohlsPoCCollectionCreditCardUE.collectionCreditCard is: \n"+
							outStruct.toString());
					logger.endTimer("KohlsPoCCollectionCreditCardUE.collectionCreditCard");
					return outStruct;
				} 
	            //Condition Added for PSA Tendering as not required to Re authorize the Card in case of Refund-- POC Returns Team -- Start
				
				else if((!YFCCommon.isVoid(strPaymentRef6)) && (strPaymentRef6.equalsIgnoreCase("PSA") || "PA".equalsIgnoreCase(strPaymentRef6))){
					logger.debug("inStruct from KohlsPoCCollectionCreditCardUE.collectionCreditCard is: \n"+inStruct.toString());
					logger.debug("outStruct from KohlsPoCCollectionCreditCardUE.collectionCreditCard is: \n"+outStruct.toString());
					outStruct.authorizationAmount = inStruct.requestAmount;
					outStruct.authorizationId = inStruct.authorizationId;
				//	outStruct.PaymentReference6 = inStruct.paymentReference6;
					return outStruct;
				}
				//Condition Added for PSA Tendering as not required to Re authorize the Card in case of Refund-- POC Returns Team -- End
                else {
					//Manoj 09/02: Added after discussion with Toshiba team for tender void scenario. 
					//They do not want to apply the hold if its Tender Void (ExtnSAFNum wont be present for it)
					String sExtnSAFNum = elePaymentMethodExtn.getAttribute("ExtnSAFNum");
					if(!YFCCommon.isVoid(sExtnSAFNum)) {
						logger.debug("ExtnSAFNum is not null, so this is SAF transaction. Applying the hold");
						outStruct.holdOrderAndRaiseEvent=true;
						outStruct.holdReason="SAF_Hold";
					}
					logger.debug("outStruct from KohlsPoCCollectionCreditCardUE.collectionCreditCard is: \n"+
							outStruct.toString());
					logger.endTimer("KohlsPoCCollectionCreditCardUE.collectionCreditCard");
					return outStruct;
				}
				
			}
		}
		
		// End changes for SAF :Sprint 8.2
		String sOrderHeaderKey = inStruct.orderHeaderKey;
		// changed logic
		Document inDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER)
				.getDocument();
		Element eleInput = inDoc.getDocumentElement();
		eleInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);

		String sDoc = KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE;
		String sGetChargeTransactionListTemplate = KohlsPOCConstant.GET_CHARGE_TRANSACTION_LIST_TEMPLATE;
		Document docGetOrderListTemplate;

		try {
			Document respPaymentDoc = null;
			Document reqPaymentDoc;

			docGetOrderListTemplate = XMLUtil.getDocument(sDoc);

			/* invoke API to to get Storeid and Terminalid */

			Document orderListDocOutput = invokeAPI(env,
					docGetOrderListTemplate, "getOrderList", inDoc);
			NodeList nlElements = orderListDocOutput
					.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
			Element eleOrder = (Element) nlElements.item(0);

			logger.verbose("Assign Store ID  attributes Start:");
			// code added 07/10/13
			String storeNo = eleOrder.getAttribute("SellerOrganizationCode");
			String prepadStroNo = KohlsPoCPnPUtil
					.prepadStoreNoWithZeros(storeNo);
			inAdditionalAttributes.put("StoreID", prepadStroNo);
			inAdditionalAttributes.put("TerminalID",
					eleOrder.getAttribute("TerminalID"));
			logger.verbose("Assign Store ID  attributes completed :");

			Element eleExtn = (Element) ((NodeList) XPathUtil.getNodeList(eleOrder, "/OrderList/Order/Extn")).item(0);

			if (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnOrigPosSequenceNo"))) {
				inAdditionalAttributes.put("ExtnOrigPosSequenceNo", collUEHelper
						.getPOSSeqNo(eleExtn.getAttribute("ExtnOrigPosSequenceNo")));
			}

			if ("CHARGE".equals(inStruct.chargeType)) {
				if (inStruct.bVoidTransaction) {
					//reqPaymentDoc = getInputForServicesEnablement(env, inStruct);
					// Blocking the call to external Payment Gateway as for OMS-R orders all Authorizations, Reversals should always happen through PinPad. This call is causing some bad data issues at the payment gateway,
//					respPaymentDoc = invokeService(env,
//							"KohlsPoCCCPaymentWebService", reqPaymentDoc);
					outStruct.authorizationAmount = inStruct.requestAmount;
					outStruct.tranAmount = inStruct.requestAmount;
					outStruct.internalReturnMessage = KohlsConstant.AUTH_ID_DUMMY;
					outStruct.authorizationId = KohlsConstant.AUTH_ID_DUMMY;
					outStruct.authReturnMessage = KohlsConstant.DUMMY_SETTLEMENT_MSG;
					outStruct.authAVS = KohlsConstant.DUMMY_SETTLEMENT_MSG;
					outStruct.authTime =df.format(Calendar.getInstance().getTime());
					//outStruct = createResponseDocumentfromWS(env, respPaymentDoc,inStruct);
					if (!"0".equals(outStruct.internalReturnCode)) {
						outStruct.internalReturnCode = FORCE_VOID;
					}

					return outStruct;
				}
				/*
				 * Document inPmntDoc = YFCDocument.createDocument("Payment")
				 * .getDocument(); Element elePmntInput =
				 * inDoc.getDocumentElement();
				 * elePmntInput.setAttribute("PaymentKey", inStruct.paymentKey);
				 * 
				 * Document pmntListDocOutput = invokeAPI(env, tempDoc,
				 * "getPaymentList", inPmntDoc); NodeList nlPmntElements =
				 * pmntListDocOutput .getElementsByTagName("Payment");
				 */
				/*Document docChargeTransDtlsInput = YFCDocument.createDocument(
						"ChargeTransactionDetail").getDocument();
				Element eleChargeTransInputRoot = docChargeTransDtlsInput
						.getDocumentElement();
				eleChargeTransInputRoot.setAttribute("ChargeTransactionKey",
						inStruct.chargeTransactionKey);
				Document docsGetChargeTransactionListTemplate = XMLUtil
						.getDocument(sGetChargeTransactionListTemplate);
				Document docChargeTransDtlsOut = invokeAPI(env,
						docsGetChargeTransactionListTemplate,
						KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST,
						docChargeTransDtlsInput);
				NodeList nlChargeTransactionDetailsRoot = docChargeTransDtlsOut
						.getElementsByTagName("ChargeTransactionDetail");
				Element eleChargeTransactionDetail = (Element) nlChargeTransactionDetailsRoot
						.item(0);*/				
			}

			if ("CHARGE".equals(inStruct.chargeType)
					&& !inStruct.bVoidTransaction) {
				logger.debug("Processing an CHARGE transaction");
				
				if (!YFCCommon.isVoid(inStruct.callForAuthorizationStatus) && inStruct.callForAuthorizationStatus.equalsIgnoreCase(KohlsPOCConstant.AUTH_CODE_ACQUIRED)) {
					outStruct.authorizationAmount = inStruct.requestAmount;
					outStruct.tranAmount = inStruct.requestAmount;
					return outStruct;
				}
				else {
					outStruct.authorizationAmount = inStruct.requestAmount;
					outStruct.tranAmount = inStruct.requestAmount;
					outStruct.internalReturnMessage = KohlsConstant.AUTH_ID_DUMMY;
					outStruct.authorizationId = KohlsConstant.AUTH_ID_DUMMY;
					outStruct.authReturnMessage = KohlsConstant.DUMMY_SETTLEMENT_MSG;
					outStruct.authAVS = KohlsConstant.DUMMY_SETTLEMENT_MSG;
					outStruct.authTime =df.format(Calendar.getInstance().getTime());
				}
				

				//reqPaymentDoc = getInputForServicesEnablement(env, inStruct);
// Blocking the call to external Payment System .
//				respPaymentDoc = invokeService(env,
//						"KohlsPoCCCPaymentWebService", reqPaymentDoc);
//				
//				if (respPaymentDoc.getDocumentElement().getAttribute("code").equals("AJB_ERROR")){
//					outStruct.retryFlag = "Y";
//					outStruct.RequiresCallForAuthorization = true;
//					outStruct = collUEHelper.logPaymentTransactionError(outStruct,
//							KohlsPOCConstant.N_TCX_CAL_FOR_AUTHORIZATION,
//							"CallForAuthRequested");
//					return outStruct;
//				}
//					
//				outStruct = createResponseDocumentfromWS(env, respPaymentDoc,
//						inStruct);
//				logger.verbose("Entered to the Charge Logic:");
//
//				if (KohlsPOCConstant.N_PG_SUCCESS
//						.equals(outStruct.internalReturnCode)
//						|| KohlsPOCConstant.N_PG_SOFT_REFFERAL
//								.equals(outStruct.internalReturnCode)) {
//
//					outStruct.tranAmount = inStruct.requestAmount;
//
//				}

//				if (KohlsPOCConstant.N_PG_DECLINE
//						.equals(outStruct.internalReturnCode)
//						|| KohlsPOCConstant.N_PG_INVALID_FUNDS
//								.equals(outStruct.internalReturnCode)
//						|| KohlsPOCConstant.N_PG_INVALID
//								.equals(outStruct.internalReturnCode)
//						|| KohlsPOCConstant.N_PG_EDIT_ERROR
//								.equals(outStruct.internalReturnCode)) {
//
//					outStruct.authorizationAmount = 0D;
//					outStruct.retryFlag = "N";
//
//					outStruct.holdOrderAndRaiseEvent = true;
//					// Added Below two attributes for 6/26 release
//					outStruct.authReturnMessage = "DECLINED";
//					outStruct.suspendPayment = "Y";
//					outStruct.tranAmount = inStruct.requestAmount;
//					// Qucik Credit for Kohls Charge
//					if ("Kohls Charge".equals(inStruct.creditCardType)) {
//						outStruct.tranReturnCode = "999999";
//
//					}
//					if ("2".equals(outStruct.internalReturnCode)) {
//						outStruct = collUEHelper.logPaymentTransactionError(
//								outStruct, KohlsPOCConstant.N_TCX_CANCELED,
//								"CANCELLED");
//
//					} else {
//						outStruct = collUEHelper.logPaymentTransactionError(
//								outStruct, KohlsPOCConstant.N_TCX_DECLINED,
//								"DECLINED");
//					}
//				}

//				if (KohlsPOCConstant.N_PG_REFERRAL
//						.equals(outStruct.internalReturnCode)
//						|| KohlsPOCConstant.N_PG_OFFLINE
//								.equals(outStruct.internalReturnCode)) {
//
//					outStruct.retryFlag = "Y";
					
					/* Manoj 09/30: Commenting offline status as per discussion
					 with Toshiba
					 */
					// Manoj 01/20: Uncommenting the offline Status for defect 855
					//defect 855 changes - Begin
//					if(KohlsPOCConstant.N_PG_OFFLINE.equals(outStruct.internalReturnCode)){ 
//						outStruct.ConditionalCallForAuthorization="Y"; 
//						outStruct.OfflineStatus=true; 
//					} else{
//						outStruct.RequiresCallForAuthorization = true;
//						// Code added for Defect 2407
//						collUEHelper.invokeServiceForKohlsPaymentExtension(env, inStruct, respPaymentDoc, outStruct);
//					}
					//defect 855 changes - End
					// 7/30 changes commented below line
					/*Manoj 10/15: uncommenting the line as Gravity needs the MessageType=1
					for CallForAuthorization*/
//					outStruct =
//					collUEHelper.logPaymentTransactionError(outStruct,
//					KohlsPOCConstant.N_TCX_CAL_FOR_AUTHORIZATION,"CallForAuthRequested");
//				}
//
			}
		} catch (Exception ex) {
			YFSException es = (YFSException) ex;
			if (inStruct.bVoidTransaction) {
				outStruct.authorizationAmount = inStruct.requestAmount;
				outStruct.tranAmount = inStruct.requestAmount;
				outStruct.internalReturnCode = "Force Voided";	
				return outStruct;
			} 
			// Defect 2494 changes - begin
			//else {				
//				outStruct.ConditionalCallForAuthorization = "Y";
//				outStruct.OfflineStatus=true; 
//				outStruct.retryFlag = "Y";
				
			//}
			//Manoj 12/15: Fix for defect 3371 - Begin
			/*else if (ex.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")
					&& es.getErrorCode().equalsIgnoreCase("javax.xml.soap.SOAPException") 
						|| es.getErrorCode().equalsIgnoreCase("javax.xml.ws.soap.SOAPFaultException")){				
					outStruct.retryFlag = "Y";
					outStruct.RequiresCallForAuthorization = true;
					outStruct = collUEHelper.logPaymentTransactionError(outStruct,
							KohlsPOCConstant.N_TCX_CAL_FOR_AUTHORIZATION,
							"CallForAuthRequested");				
			}
			// Defect 2494 changes - end
			else {					
				outStruct.authorizationAmount = 0D;
				outStruct.suspendPayment = "Y";
				outStruct.retryFlag = "N";
				outStruct.holdOrderAndRaiseEvent = true;
				outStruct.tranAmount = inStruct.requestAmount;
				outStruct = collUEHelper
						.logPaymentTransactionError(outStruct,
								KohlsPOCConstant.N_TCX_DECLINED, "DECLINED");						
			}*/
			//Manoj 12/15: Fix for defect 3371 - End
			ex.printStackTrace();
		}		
		logger.endTimer("KohlsPoCCollectionCreditCardUE.collectionCreditCard");
		return outStruct;
	}

	/**
	 * This function prepares the request
	 * 
	 * @param env
	 * @param inputStruct
	 * @return reqDoc
	 * @exception ParseException
	 */
	private Document getInputForServicesEnablement(final YFSEnvironment env,
			final YFSExtnPaymentCollectionInputStruct inputStruct)
			throws ParseException, YFSException {

		Document reqDoc = YFCDocument.createDocument(
				"ProcessTransactionRequest").getDocument();
		Element eleReqDoc = reqDoc.getDocumentElement();
		Element eleReq = reqDoc.createElement("Request");

		eleReq.setAttribute("Channel", "PoC");

		XMLUtil.appendChild(eleReqDoc, eleReq);

		Element eleToken = reqDoc.createElement("Token");
		eleToken.setAttribute("CardNumber", inputStruct.creditCardNo);
		eleToken.setAttribute("Type", "internal");
		eleToken.setAttribute("Provider", "Protegrity");
		XMLUtil.appendChild(eleReqDoc, eleToken);

		Element eleTran = reqDoc.createElement("Transaction");
		Double dAmount = new Double(inputStruct.requestAmount);

		if (dAmount.doubleValue() > 0) {
			eleTran.setAttribute("TransactionRequestType", "Sale");
		} else {
			eleTran.setAttribute("TransactionRequestType", "VoidSale");
		}

		eleTran.setAttribute("Amount", KohlsPoCCollectionUEHelper.convertAmtToAJBFormat(Math
				.abs(dAmount.doubleValue())));
		eleTran.setAttribute("TransactionNumber",
				inAdditionalAttributes.get("ExtnOrigPosSequenceNo"));
		eleTran.setAttribute("RequestType", "100");

		// Added for 6/26 build because instruct.entryType is null. It was
		// expected to be "swiped" or "keyed"
		// Void request included as part of 7/26		
		//Manoj 0330: modified the logic to set the IsSwiped=false if secureAuthenticationCode
		// is not present in the input
		if (!inputStruct.bVoidTransaction) {
			// Swaping the conditions for SWIPED as it was not working
			if (("SWIPED".equalsIgnoreCase(inputStruct.paymentReference2))
					|| ("SWIPED".equalsIgnoreCase(inputStruct.paymentReference1))) {
				eleTran.setAttribute("CVVCode", "");
				// PG is expecting the swipe data in swipe=<> pin=<> format
				/*
				 * eleTran.setAttribute("SwipeData",
				 * inputStruct.secureAuthenticationCode);
				 */
				if (!YFCCommon.isVoid(inputStruct.secureAuthenticationCode)) {
					eleTran.setAttribute("IsSwiped", "true");
					eleTran.setAttribute("CardExpirationDate", "");
					String strSecAuthCode = inputStruct.secureAuthenticationCode;
					String[] temp = strSecAuthCode.trim().split(" ");
					if (temp.length == 2) {
						eleTran.setAttribute(KohlsPOCConstant.A_SWIPEDATA,
								"swipe=" + temp[1] + " " + "pin=" + temp[0]);
					} else if (temp.length == 1)
						eleTran.setAttribute(KohlsPOCConstant.A_SWIPEDATA,
								"swipe=" + temp[0]);
				}
				// mrjoshi 08/24: Workaround for Gravity issue when
				// secureAuthenticationCode
				// is sent as blank
				else {
					eleTran.setAttribute(KohlsPOCConstant.A_SWIPEDATA, "swipe="
							+ inputStruct.creditCardNo);
					eleTran.setAttribute("IsSwiped", "false");
					eleTran.setAttribute("CardExpirationDate",
							inputStruct.creditCardExpirationDate);
				}
				// Need to be checked
				eleTran.setAttribute("ZipCode", "");
			} else {
				if (!YFCUtils.isVoid(inputStruct.creditCardExpirationDate)) {

					eleTran.setAttribute("CardExpirationDate",
							inputStruct.creditCardExpirationDate);
				}
				eleTran.setAttribute("CVVCode",
						inputStruct.secureAuthenticationCode);
				eleTran.setAttribute("IsSwiped", "false");
				if (!"KOHLS_CHARGE_CARD".equals(inputStruct.paymentType)) {
					eleTran.setAttribute("ZipCode", inputStruct.billToZipCode);
				}
			}

		} else {
			// ** Start 8/31 changes
			//eleTran.setAttribute("IsSwiped", inputStruct.paymentReference2);
			// Manoj : Change for defect 2842 - Begin
			eleTran.setAttribute("IsSwiped", KohlsPOCConstant.FALSE);
			//Manoj : Change for defect 2842 - End
			// ** End 8/31 changes
			eleTran.setAttribute("CardExpirationDate",
					inputStruct.creditCardExpirationDate);

			// ** Start 8/31 changes
			if (!YFCCommon.isVoid(inputStruct.authorizationId)) {
				String[] tempTran = inputStruct.authorizationId.split("=");
				if (tempTran.length == 2)
					eleTran.setAttribute("Reversal", tempTran[1]);
				else
					eleTran.setAttribute("Reversal", "");
			}
			// ** End 8/31 changes
			eleTran.setAttribute("CVVCode", "");
			eleTran.setAttribute("SwipeData", "");
			eleTran.setAttribute("ZipCode", "");

		}

		if ("Kohls Charge".equals(inputStruct.paymentType)) {
			eleTran.setAttribute("ZipCode", "9901");
		}
		// added
		eleTran.setAttribute("PaymentType", "credit");
		eleTran.setAttribute("TransactionType", "Credit");

		Date dbDate = new Date();
		DateFormat sdfDateFormat = new SimpleDateFormat(
				YDate.ISO_DATETIME_FORMAT);
		eleTran.setAttribute("DateTime", sdfDateFormat.format(dbDate));
		Element eleStore = reqDoc.createElement("Store");
		eleStore.setAttribute("StoreNumber",
				inAdditionalAttributes.get("StoreID"));
		eleStore.setAttribute("TerminalNumber",
				inAdditionalAttributes.get("TerminalID"));
		XMLUtil.appendChild(eleReqDoc, eleStore);
		XMLUtil.appendChild(eleReqDoc, eleTran);
		return reqDoc;
	}

	/**
	 * This function processes the Payment Gateway response
	 * 
	 * @param env
	 * @param respDoc
	 * @param inStruct
	 * @return outputStruct
	 * @throws ParseException
	 * 
	 */
	public final YFSExtnPaymentCollectionOutputStruct createResponseDocumentfromWS(
			final YFSEnvironment env, final Document respDoc,
			final YFSExtnPaymentCollectionInputStruct inStruct)
			throws ParseException {
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'");
		DateFormat df2 = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss");
		YFSExtnPaymentCollectionOutputStruct outputStruct = new YFSExtnPaymentCollectionOutputStruct();
		Element transactionResponse = respDoc.getDocumentElement();
		Element responseElement = XMLUtil.getFirstElementByName(
				transactionResponse, "Response");
		outputStruct.internalReturnCode = responseElement.getAttribute(
				"ActionCode").trim();

		Element transactionElement = XMLUtil.getFirstElementByName(
				transactionResponse, "Transaction");
		// Added logic for 8/31 release
		// ****Started logic to append reversal to AuthorizationID
		String sAuthID = "";
		String sReversal = "";
		if (!YFCCommon
				.isVoid(transactionElement.getAttribute("ApprovalNumber"))) {
			sAuthID = transactionElement.getAttribute("ApprovalNumber");
		}

		if (!YFCCommon.isVoid(transactionElement.getAttribute("Reversal"))) {
			sReversal = transactionElement.getAttribute("Reversal");
			if (!YFCCommon.isVoid(sAuthID))
				outputStruct.authorizationId = sAuthID + "=" + sReversal;
		} else {

			outputStruct.authorizationId = sAuthID;
		}

		// ****End logic to append reversal to AuthorizationID

		outputStruct.authReturnMessage = transactionElement
				.getAttribute("AuthReturnMessage");
		outputStruct.sCVVAuthCode = transactionElement.getAttribute("CvvResp");
		outputStruct.authAVS = transactionElement.getAttribute("AVSResp");
		outputStruct.tranReturnCode = transactionElement
				.getAttribute("CardLevel");
		// Added attribute AuthTime on 09/30 for sales hub
		String sAuthTime = transactionElement.getAttribute("DateTime");
		Date dtAuthTimeRaw = df1.parse(sAuthTime);
		String sAuthTimeFormatted = df2.format(dtAuthTimeRaw);
		outputStruct.authTime = sAuthTimeFormatted;

		// 7/30 changes Changed Logic to authorization amount
		// Added as part of 8/31 release
		// **Start To handle KohlsCharge Card
		if (!YFCCommon.isVoid(transactionElement.getAttribute("UserData"))
				&& "KOHLS_CHARGE_CARD".equals(inStruct.paymentType)) {
			HashMap<String, String> map = collUEHelper.getCustData(transactionElement.getAttribute("UserData"));
			if (KohlsPOCConstant.N_PG_SOFT_REFFERAL
					.equals(outputStruct.internalReturnCode)) {
				String sSoftReferralIndicator = null;
				if (!YFCCommon.isVoid(map.get("SoftReferralIndicator"))) {
					if ("01".equals(map.get("SoftReferralIndicator"))) {
						sSoftReferralIndicator = "Z" + map.get("ZipCode");
					} else if ("00".equals(map.get("SoftReferralIndicator"))) {
						sSoftReferralIndicator = "DL";
					}
				}
				// setContextObject(env, "SoftReferralIndicator",
				// sSoftReferralIndicator);
				outputStruct.internalReturnMessage = "SoftReferralIndicator="
						+ sSoftReferralIndicator;
				logger.verbose("************** SoftReferralIndicator is "
						+ sSoftReferralIndicator);
			}
			if (!YFCCommon.isVoid(map.get("CustomerName"))) {
				// setContextObject(env, "CustomerName",
				// map.get("CustomerName"));
				outputStruct.internalReturnMessage = outputStruct.internalReturnMessage
						+ "`" + "CustomerName=" + map.get("CustomerName");
				logger.verbose("************** CustomerName is "
						+ map.get("CustomerName"));
			}

		}

		// Added on 09/30 for defect 1021
		/*if (KohlsPOCConstant.N_PG_REFERRAL.equals(outputStruct.internalReturnCode)
				&& "KOHLS_CHARGE_CARD".equals(inStruct.paymentType)) {
			// Manoj 10/14: Changes for defect 1021
			Document docCreateKohlsPaymentExtnIn = YFCDocument.createDocument("KohlsPaymentExtension").getDocument();
			Element eleKohlsPaymentExtnRoot = docCreateKohlsPaymentExtnIn.getDocumentElement();
			eleKohlsPaymentExtnRoot.setAttribute("PaymentKey", inStruct.paymentKey);
			eleKohlsPaymentExtnRoot.setAttribute("OrderHeaderKey", inStruct.orderHeaderKey);
			eleKohlsPaymentExtnRoot.setAttribute("OrderNo", inStruct.orderNo);
			eleKohlsPaymentExtnRoot.setAttribute("PaymentType", inStruct.paymentType);
			eleKohlsPaymentExtnRoot.setAttribute("Reference1", sAuthID);
			try {
				invokeService(env,
						"KohlsPoCCreateQNo", docCreateKohlsPaymentExtnIn);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//outputStruct.internalReturnMessage = sAuthID;
		} else */
		if (KohlsPOCConstant.N_PG_OFFLINE
				.equals(outputStruct.internalReturnCode)
				&& "KOHLS_CHARGE_CARD".equals(inStruct.paymentType)) {
			outputStruct.internalReturnMessage = "000000";
		}

		// **End To handle KohlsCharge Card
		if (KohlsPOCConstant.N_PG_SUCCESS.equals(outputStruct.internalReturnCode)
				|| KohlsPOCConstant.N_PG_SOFT_REFFERAL
						.equals(outputStruct.internalReturnCode)) {
			// Void check
			outputStruct.authorizationAmount = inStruct.requestAmount;
			if (!YFCCommon.isVoid(transactionElement.getAttribute("Amount"))) {
				//Changes as per AJB response amount
				double dbAmount = KohlsPoCCollectionUEHelper
						.convertAmtToOMSFormat(transactionElement
								.getAttribute("Amount"));
				if (dbAmount < Math.abs(inStruct.requestAmount) && inStruct.requestAmount > 0) {
					outputStruct.authorizationAmount = dbAmount;
				} else if (dbAmount < Math.abs(inStruct.requestAmount) && inStruct.requestAmount < 0){
					outputStruct.authorizationAmount = 0 - dbAmount;
				} 
			}

		}

		String strPS2000data = transactionElement.getAttribute("PS2000Data");
		String strSequenceNumber = transactionElement
				.getAttribute("SequenceNumber");
		String strBankResponseCode = transactionElement
				.getAttribute("BankResponseCode");
		String strPostingDate = transactionElement.getAttribute("PostingDate");
		// Added attribute Options on 09/30 for sales hub
		String strOption = transactionElement.getAttribute("Options");

		outputStruct.authReturnMessage = "ps2000Data='" + strPS2000data
				+ "' sequenceNumber='" + strSequenceNumber
				+ "' bankResponseCode='" + strBankResponseCode
				+ "' postingDate='" + strPostingDate + "'" + "' options='"
				+ strOption + "'";
		outputStruct.tranReturnMessage = transactionElement
				.getAttribute("DepositData");

		return outputStruct;
	}

}
