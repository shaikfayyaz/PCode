package com.kohls.poc.voids.ue;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.payments.ue.KohlsPoCCollectionSVCCardUE;
import com.tgcs.tcx.gravity.pos.japi.ue.order.POSVoidTransactionUE;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoc KohlsPocVoidInvoiceUE.java Author : IBM Created : Oct 8 2013
 * Modified : Oct 8 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 8/10/2013
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the credit card payment authorization using a synchronous
 * web service call to the Payment Service
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPocVoidInvoiceUE extends KOHLSBaseApi implements
		POSVoidTransactionUE {
	String strOrderHeaderKey;
	String strOrderNo;
	String strEnterpriseCode;
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPocVoidInvoiceUE.class);

	public void checkIfOkToVoid(YFSEnvironment env, YFCDocument inputDoc)
			throws YFSUserExitException {
		//Document inDoc = inputDoc.getDocument();
		logger.beginTimer("KohlsPocVoidInvoiceUE.checkIfOkToVoid");
		YFCElement eleOrder = inputDoc.getDocumentElement();
		strOrderHeaderKey = eleOrder
				.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		strOrderNo = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
		strEnterpriseCode = eleOrder
				.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
		String strPostVoidConfirmFlag = eleOrder
				.getAttribute(KohlsPOCConstant.ATTR_POST_VOID_CONFIRMED_FLAG);
		String strProcedureID = eleOrder
				.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID);
		//Start fix for PR-141
		String strSecondaryOrderHeaderKey = eleOrder
						.getAttribute(KohlsPOCConstant.ATTR_SEC_ORD_HDR_KEY);
		//End fix for for PR-141

		try {

			if (strProcedureID != null && strPostVoidConfirmFlag != null) {
				if (strPostVoidConfirmFlag.equalsIgnoreCase(KohlsPOCConstant.YES)
						&& strProcedureID
								.equalsIgnoreCase(KohlsPOCConstant.STRING_POST_VOID)) {
					// Create input XML for getOrderInvoiceList API
					logger.debug("##### It is a Post Void Transaction. Check and Void the invoice.");
					Document docInputForGetOrderInvList = YFCDocument
							.createDocument(KohlsPOCConstant.E_ORDER_INVOICE)
							.getDocument();
					Element eleOrderInvoiceInput = docInputForGetOrderInvList
							.getDocumentElement();
					Element eleInvoiceOrder = docInputForGetOrderInvList.createElement("Order");
					eleOrderInvoiceInput.appendChild(eleInvoiceOrder);
					eleInvoiceOrder.setAttribute(
							KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
					eleInvoiceOrder.setAttribute(
							KohlsPOCConstant.ATTR_ORDER_NO, strOrderNo);
					eleInvoiceOrder.setAttribute(
							KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
							strEnterpriseCode);
					Document docOrderInvListOutput = invokeAPI(env,
							KohlsPOCConstant.GET_ORDER_INVOICE_LIST_OUTPUT,
							KohlsPOCConstant.API_GET_ORDER_INVOICE_LIST,
							docInputForGetOrderInvList);
					
					if (!YFCCommon.isVoid(docOrderInvListOutput)) {
						NodeList ndListOrderInvoiceList = XPathUtil
								.getNodeList(docOrderInvListOutput
										.getDocumentElement(),
										"/OrderInvoiceList/OrderInvoice");
						Element eleOrderInvoice = (Element) ndListOrderInvoiceList
								.item(0);
						String strStatus = eleOrderInvoice
								.getAttribute(KohlsPOCConstant.A_STATUS);
						String strInvoiceKey = eleOrderInvoice
								.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
						
						if (strStatus
								.equals(KohlsPOCConstant.INVOICE_PUBLISHED_STATUS)) {							
							
							// Create Input for changeOrderInvoice API
							Document docInputForChangeOrderInv = YFCDocument
									.createDocument(
											KohlsPOCConstant.E_ORDER_INVOICE)
									.getDocument();
							Element eleChangeOrderInvoiceInput = docInputForChangeOrderInv
									.getDocumentElement();
							eleChangeOrderInvoiceInput.setAttribute(
									KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY,
									strInvoiceKey);
							eleChangeOrderInvoiceInput.setAttribute(
									KohlsPOCConstant.ATTR_STATUS,
									KohlsPOCConstant.INVOICE_CREATED_STATUS);

							Document docChangeOrderInvOutput = invokeAPI(env,
									KohlsPOCConstant.API_CHANGE_ORDER_INVOICE,
									docInputForChangeOrderInv);
						} else {
							// Defect #4873 - Start
							sendSalesDetailsToSalesHub(env,strInvoiceKey);
							// Defect #4873 - End
						}
					}
				}
			}
		} catch (Exception exception) {
			if (exception instanceof YFSUserExitException) {
				logger.endTimer("KohlsPocVoidInvoiceUE.checkIfOkToVoid");
				YFSUserExitException yfsUEException = (YFSUserExitException) exception;
				yfsUEException.setErrorCode("POST VOID FAILURE");
				yfsUEException
						.setErrorDescription("Post Void Failure - Could not set the status code back to 00");
				throw yfsUEException;
			}
		}

		if ("voidTransaction".equalsIgnoreCase(strProcedureID)) {
			logger.debug("##### It is a void during Transaction. Set ExtnIsVoidDuring='Y' by calling changeOrder API.");
			Document changeOrderInputDoc = null;
			try {
				changeOrderInputDoc = XMLUtil.newDocument();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Element eleOrd = changeOrderInputDoc
					.createElement(KohlsPOCConstant.ELEM_ORDER);
			Element eleExtn = changeOrderInputDoc
					.createElement(KohlsPOCConstant.A_EXTN);
			eleOrd.setAttribute("Override", KohlsPOCConstant.FLAG_Y);
			eleOrd.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOrderHeaderKey);
			eleOrd.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOrderNo);
			eleOrd.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
					strEnterpriseCode);
			eleExtn.setAttribute("ExtnIsVoidDuring", KohlsPOCConstant.FLAG_Y);
			changeOrderInputDoc.appendChild(eleOrd);
			eleOrd.appendChild(eleExtn);
			
			
			if(logger.isDebugEnabled())
				logger.debug("InputDocument For ChangeOrder:"+ XMLUtil.getXMLString(changeOrderInputDoc));

			try {
				invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER,
						changeOrderInputDoc);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				if (e instanceof YFSUserExitException) {
					logger.endTimer("KohlsPocVoidInvoiceUE.checkIfOkToVoid");
					YFSUserExitException yfsUEException = (YFSUserExitException) e;
					yfsUEException.setErrorCode("void During Failure");
					yfsUEException
							.setErrorDescription("Could not set ExtnIsVoidDuring attribute");
					throw yfsUEException;
				}
			}
		}
		//Start fix for PR-141
		if ("voidTransaction".equalsIgnoreCase(strProcedureID) && strSecondaryOrderHeaderKey!= null && !strSecondaryOrderHeaderKey.equalsIgnoreCase("")) {
			logger.debug("##### It is a void during Transaction. Set ExtnIsVoidDuring='Y' by calling changeOrder API for the EE Return Order");
			Document changeReturnOrderInputDoc = null;
			try {
				changeReturnOrderInputDoc = XMLUtil.newDocument();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Element eleOrd = changeReturnOrderInputDoc
					.createElement(KohlsPOCConstant.ELEM_ORDER);
			Element eleExtn = changeReturnOrderInputDoc
					.createElement(KohlsPOCConstant.A_EXTN);
			eleOrd.setAttribute("Override", KohlsPOCConstant.FLAG_Y);
			eleOrd.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strSecondaryOrderHeaderKey);
			eleOrd.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
					strEnterpriseCode);
			eleExtn.setAttribute("ExtnIsVoidDuring", KohlsPOCConstant.FLAG_Y);
			eleExtn.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.RO_DOCUMENT_TYPE);
			changeReturnOrderInputDoc.appendChild(eleOrd);
			eleOrd.appendChild(eleExtn);
			
			
			if(logger.isDebugEnabled())
				logger.debug("InputDocument For ChangeOrder: Return Order"+ XMLUtil.getXMLString(changeReturnOrderInputDoc));

			try {
				invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER,
						changeReturnOrderInputDoc);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				if (e instanceof YFSUserExitException) {
					logger.endTimer("KohlsPocVoidInvoiceUE.checkIfOkToVoid");
					YFSUserExitException yfsUEException = (YFSUserExitException) e;
					yfsUEException.setErrorCode("void During Failure");
					yfsUEException
							.setErrorDescription("Could not set ExtnIsVoidDuring attribute for Return Order");
					throw yfsUEException;
				}
			}
	}
		//End fix for PR-141
		logger.endTimer("KohlsPocVoidInvoiceUE.checkIfOkToVoid");
	}
	
	// Defect #4873 - Start
	public void sendSalesDetailsToSalesHub(YFSEnvironment env,
			String strInvoiceKey)  throws YFSUserExitException {
		logger.debug("##### Inside sendSalesDetailsToSalesHub.");
		// Call to getOrderList api for fetching the payment methods for the
		// order
		try {
			Document docOrderDetailOutput = null;
			Document docInputForGetOrderDetail = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderInput = docInputForGetOrderDetail
					.getDocumentElement();
			eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOrderHeaderKey);
			eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
					strEnterpriseCode);
			docOrderDetailOutput = invokeAPI(env,
					KohlsPOCConstant.GET_ORDER_DETAILS_OUTPUT,
					KohlsPOCConstant.API_GET_ORDER_DETAILS,
					docInputForGetOrderDetail);
			
			
			if(logger.isDebugEnabled())
				logger.debug("#####docOrderDetailOutput :" + XMLUtil.getXMLString(docOrderDetailOutput));

			// Iterate through the payment methods and fetch the attributes
			// 'ExtnPSIPayment and ExtnSAFStatus' from the
			// payment methods
			NodeList paymentMethodsList = (NodeList) XPathUtil.getNodeList(
					docOrderDetailOutput.getDocumentElement(),
					"/Order/PaymentMethods/PaymentMethod");

			if (paymentMethodsList != null
					&& paymentMethodsList.getLength() > 0) {
				for (int i = 0; i < paymentMethodsList.getLength(); i++) {
					Element elePaymentMethod = (Element) (paymentMethodsList
							.item(i));
					Element elePaymentMethodExtn = XMLUtil.getChildElement(
							elePaymentMethod, "Extn");
					if (!(YFCCommon.isVoid(elePaymentMethodExtn))
							&& elePaymentMethodExtn.getAttribute(
									"ExtnPSIPayment").equalsIgnoreCase("Y")
							&& elePaymentMethodExtn.getAttribute(
									"ExtnSAFStatus").equalsIgnoreCase(
									"ELIGIBLE")
							&& elePaymentMethod.getAttribute(
									"SuspendAnyMoreCharges").equalsIgnoreCase(
									"N")) {
						logger.debug("Atleast one payment exists on the order that has SAF payment in Eligible status");
						// Call the getOrderInvoiceDetails api for the order
						Document docInputToGetInvoiceDetails = XMLUtil.createDocument(KohlsPOCConstant.E_GET_ORDER_INVOICE_DETAILS);
								
						Element eleInputToGetInvoiceDetails = docInputToGetInvoiceDetails.getDocumentElement();
						eleInputToGetInvoiceDetails.setAttribute(KohlsPOCConstant.E_INVOICE_KEY, strInvoiceKey);
						
						
						if(logger.isDebugEnabled())
							logger.debug("Input XML for getOrderInvoiceDetails is: "+XMLUtil.getXMLString(docInputToGetInvoiceDetails));
						
						Document docInvoiceDetail = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT,
								"getOrderInvoiceDetails", docInputToGetInvoiceDetails);
						
						
						if(logger.isDebugEnabled())
							logger.debug("Invoke KohlsPoCPublishOrderInvoicetoSalesHub Service :"+ XMLUtil.getXMLString(docInvoiceDetail));
						
						// Publish the invoice to Saleshub
						Document docOutXML = KOHLSBaseApi.invokeService(env,"KohlsPoCPublishOrderInvoicetoSalesHub",docInvoiceDetail);
						
						
						if(logger.isDebugEnabled())
							logger.debug("OutXML is: "+XMLUtil.getXMLString(docOutXML));
						
						break;
					}
				}
			}
		} catch (Exception exception) {
			if (exception instanceof YFSUserExitException) {
				logger.endTimer("KohlsPocVoidInvoiceUE.sendSalesDetailsToSalesHub");
				YFSUserExitException yfsUEException = (YFSUserExitException) exception;
				yfsUEException.setErrorCode("POST VOID FAILURE");
				yfsUEException
						.setErrorDescription("Post Void Failure - inside sendSalesDetailsToSalesHub");
				throw yfsUEException;
			}
		}

	}
	// Defect #4873 - End
}
