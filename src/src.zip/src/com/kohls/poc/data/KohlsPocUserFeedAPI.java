package com.kohls.poc.data;

//Java Imports
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : KohlsPocUserFeedAPI.java 
 * Author : IBM Created : August 14 2013
 * Modified : August 14 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 14/08/2013 IBM First Cut.
 ***************************************************************************** 
 * 
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the various attributes with respect to Payment Tender, Void
 * transactions,suspended transactions, sign in authentication details. It creates 
 * a document with these attibutes and post the message to Sales Hub.
 * @author IBM
 * @version 0.1
 *****************************************************************************/


public  class KohlsPocUserFeedAPI extends KOHLSBaseApi {

	private static final YFCLogCategory 
	loggerForUserFeed = YFCLogCategory
	.instance(KohlsPocUserFeedAPI.class.getName());

	private Document docCommonCodeList = null;
	private Document docUserList = null;
	private Document docOrgHierOutput = null;
	private ArrayList arrListTempRoles = new ArrayList();
	private String strUserLoginId = null;
	private String strOrgKey = null;
//	Start - Fix for setting Locale Code
	private Properties props;
	private String strLocCode = null;
	
//	End - Fix for setting Locale Code


	
	/**
 	 * This function creates a new user, modifies or 
 	 * deletes an existing user 
 	 * 
 	 * @param env
 	 * @param inputUserFeed
 	 * @return none
 	 * @exception Exception
 	 *           
 	 */	

	public void userFeedMain(YFSEnvironment env, Document inputUserFeed) throws Exception 
	{
		Element eleUser = inputUserFeed.getDocumentElement();
		String strAction = eleUser.getAttribute(KohlsPOCConstant.A_ACTION);
		try {
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.userFeedMain -- BEGIN");
			
			
			strUserLoginId = eleUser.getAttribute(KohlsPOCConstant.ATTR_LOGIN_ID);
			strOrgKey = eleUser.getAttribute(KohlsPOCConstant.ATTR_ORGANIZATION_KEY);
			strOrgKey = strOrgKey.replaceFirst ("^0*", "");
			if (!YFCCommon.isVoid(strOrgKey))
			{
				//MAD-572 change start
				eleUser.setAttribute(KohlsPOCConstant.CTX_ORG_CODE, strOrgKey);
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("Setting the ContextOrganizationCode as --- "+strOrgKey);
				//MAD-572 change end
				strLocCode = fetchLocaleCode(env, strOrgKey);
			}
			
			if (!(strAction.equalsIgnoreCase(KohlsPOCConstant.ACTION_CREATE) || strAction.equalsIgnoreCase(KohlsPOCConstant.ACTION_MODIFY) || strAction.equalsIgnoreCase(KohlsPOCConstant.ACTION_DELETE)))
			{
				KohlsPocUserFeedAPI.loggerForUserFeed.verbose(strUserLoginId+" User not created - Unknown Action");
				YFSException exception = new YFSException();
				exception.setErrorCode("EXTN_UNKNOWN_ACTION");
				exception.setErrorDescription("Unknown Action Code in Input Message");
				throw exception;
			}
			else if (strAction.equalsIgnoreCase(KohlsPOCConstant.ACTION_DELETE))
			{
				deleteExistingUser(env);
			}
			else
			{
				docUserList = getUserList(env);	
				NodeList ndLstUserList = XPathUtil.getNodeList(docUserList.getDocumentElement(), "/UserList/User");
				if(ndLstUserList!=null)
				{
					Element eleUserList = (Element)ndLstUserList.item(0);
					if (ndLstUserList.getLength() == 0)
					{
						createNewUser(env,inputUserFeed);
					}
					else if(ndLstUserList.getLength() == 1)
					{
						eleUserList.setAttribute(KohlsPOCConstant.A_ACTION,KohlsPOCConstant.ACTION_MODIFY);
						modifyExistingUser(env,inputUserFeed);
					}
					else
					{
						YFSException exception = new YFSException();
						exception.setErrorCode("EXTN_2MANY_OMS_USER");
						exception.setErrorDescription("Too Many OMS User Matches");
						throw exception;
					}
				}
			}
		
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.userFeedMain -- END");
		}
		catch(Exception exception)
		{
			if (YFCCommon.isVoid(docOrgHierOutput) && (strAction.equalsIgnoreCase(KohlsPOCConstant.ACTION_CREATE) || strAction.equalsIgnoreCase(KohlsPOCConstant.ACTION_MODIFY)) )
			{
				YFSException ex = new YFSException();
				ex.setErrorCode("EXTN_UNKNOWN_ORGANIZATION");
				ex.setErrorDescription(strUserLoginId+" user will not be given OMS access as the organizationKey "+strOrgKey+ " does not exist in OMS");
				throw ex;
			}
			if(exception instanceof YFSException ){
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
				}
			
		}
	}
	

//	Start - Fix for setting Locale Code
	
	/**
	* Sets the properties
	* @param prop Properties that need to be set
	* @throws Exception when unable to set the Property
	*/


	public void setProperties(Properties prop) throws Exception {
	this.props = prop;
	KohlsPocUserFeedAPI.loggerForUserFeed.debug("In the set properties method");
	}
//	End - Fix for setting Locale Code
	
	
	/**
 	 * This function creates a new user document and 
 	 * sets the User from the input XML
 	 * 
 	 * @param loginID
 	 * @return docUserInput
 	 *           
 	 */	
	private Document createUserDocument(String loginID)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.createUserDocument -- BEGIN");
		Document docUserInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_USER).getDocument();
		Element elemUser = docUserInput.getDocumentElement();
		elemUser.setAttribute(KohlsPOCConstant.ATTR_LOGIN_ID, loginID);
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.createUserDocument -- END");
		return docUserInput;
	}
	
	/**
 	 * This function deletes an existing user 
 	 * for the user from the input XML
 	 * 
 	 * @param loginID
 	 * @return none
 	 *           
 	 */	
	private void deleteExistingUser(YFSEnvironment env)
	{
		try {
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.deleteExistingUser -- BEGIN");
				Document docDelUserInput = createUserDocument(strUserLoginId);
				KohlsPocUserFeedAPI.invokeAPI(env, KohlsPOCConstant.API_DELETE_USER_HIERARCHY, docDelUserInput);
				KohlsPocUserFeedAPI.loggerForUserFeed.verbose(strUserLoginId+" User deleted");
		}
		catch(Exception exc)
		{
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.deleteExistingUser ------------- User is already Deleted");
			YFSException exception = new YFSException();
			exception.setErrorCode("EXTN_USER_ALREADY_DELETED");
			exception.setErrorDescription(strUserLoginId+" is already deleted in OMS");
			throw exception;
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.deleteExistingUser -- END");
	}
	
	/**
 	 * This function retrieves the user list  
 	 * for the User from the input XML
 	 * 
 	 * @param env
 	 * @return docGetUserListOutput
 	 *           
 	 */	
	private Document getUserList(YFSEnvironment env)
	{	
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.getUserList -- BEGIN");
		Document docGetUserListOutput = null;
		try {
			//Create Input XML for getUserList
			Document docGetUserListInput = createUserDocument(strUserLoginId);
			//Call getUserList API
			docGetUserListOutput = KohlsPocUserFeedAPI.invokeAPI(env,KohlsPOCConstant.TEMPLATE_GET_USER_HIERARCHY, KohlsPOCConstant.API_GET_USER_LIST, docGetUserListInput);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
			 }			
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.getUserList -- END");
		return docGetUserListOutput;
	}
	
	/**
 	 * This function create user details   
 	 * for the User from the input XML
 	 * 
 	 * @param env
 	 * @param userInputDoc
 	 * @return docGetUserListOutput
 	 *           
 	 */	
	private void createNewUser(YFSEnvironment env, Document userInputDoc)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.createNewUser -- BEGIN");
		try {
			userInputDoc = conditionCheckBeforeAction(env, userInputDoc, KohlsPOCConstant.ACTION_CREATE);
			
			NodeList ndComCodList = XPathUtil.getNodeList(docCommonCodeList.getDocumentElement(), "/CommonCodeList/CommonCode");
			if(ndComCodList!=null)
			{
				Document docUserHierarchy = modifyInputDoc(env, userInputDoc);
				docUserHierarchy.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_GEN_PASSWORD, KohlsPOCConstant.YES);
				//Call createUserHierarchy API
				KohlsPocUserFeedAPI.invokeAPI(env,KohlsPOCConstant.API_CREATE_USER_HIERARCHY, docUserHierarchy);
				KohlsPocUserFeedAPI.loggerForUserFeed.verbose(strUserLoginId+" User created successfully");
			}
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.createNewUser -- END");
		}
		catch(Exception e)
		{
			if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
				
			 }	
		}
	}
	
	/**
 	 * This function sets attributes for the input Doc required
 	 * for createUserHierarchy and modifyUSerHierarchy   
 	 *  
 	 * @param userInput
 	 * @param env
 	 * @return userInput
 	 *           
 	 */	
	
	private Document modifyInputDoc(YFSEnvironment env, Document userInput)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.modifyInputDoc new -- BEGIN");
		try {	
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("In Try -- BEGIN");
	
			Element eleUser = userInput.getDocumentElement();
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("After element.modifyInputDoc new -- BEGIN");
	
			String strActivateFlag = eleUser.getAttribute(KohlsPOCConstant.ATTR_ACTIVATE_FLAG);
			//eleUser.setAttribute(KohlsPOCConstant.ATTR_DATA_SECURITY_GROUP_ID, "SALES");
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.activeflag new -- BEGIN");
	
			eleUser.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY);
			if(YFCCommon.isVoid(strActivateFlag))
				eleUser.setAttribute(KohlsPOCConstant.ATTR_ACTIVATE_FLAG, KohlsPOCConstant.YES);
			
			String strOrganizationKey = null;
			if(YFCCommon.isVoid(strOrgKey))
			{
					KohlsPocUserFeedAPI.loggerForUserFeed.debug("OrgKey.modifyInputDoc new -- BEGIN");
	
				eleUser.setAttribute(KohlsPOCConstant.ATTR_ORGANIZATION_KEY,KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY);
				//	Start - Fix for setting Locale Code
				strLocCode=props.getProperty(KohlsPOCConstant.ATTR_LOCALE_CODE);
				//End - Fix for setting Locale Code
			}
			else
			{
					KohlsPocUserFeedAPI.loggerForUserFeed.debug("else OrgKey.modifyInputDoc new -- BEGIN");
	
				//	Start - Fix for better performance
				strOrganizationKey = strOrgKey.replaceFirst ("^0*", "");
				eleUser.setAttribute(KohlsPOCConstant.ATTR_ORGANIZATION_KEY, strOrganizationKey);
				//	End - Fix for better performance
				//Start - Fix for setting Locale Code
				if (YFCCommon.isVoid(strLocCode))
				{
					strLocCode = fetchLocaleCode(env, strOrganizationKey);
				}
			}	
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("After Else .modifyInputDoc new -- BEGIN");
			//CPE-3121 changes start
			/*Document inTeamDoc;
			if(strOrganizationKey!=null){
				 inTeamDoc=XMLUtil.getDocument("<Team OrganizationCode='"+strOrganizationKey+"' TeamId='SALES'/>");

			}
			else
			{
					KohlsPocUserFeedAPI.loggerForUserFeed.debug("In Else.modifyInputDoc new -- BEGIN");
	
				 inTeamDoc=XMLUtil.getDocument("<Team OrganizationCode='"+KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY +"' TeamId='SALES'/>");

			}*/
			
				
			//Default Organization call with SALES as TeamId
			String sDefaultTeamKey = "";
			String sParentKey ="";
			String sTeamId ="";
			boolean isExistingTeam = false;
			Document inDefaultTeamDoc=XMLUtil.getDocument("<Team OrganizationCode='"+KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY +"' TeamId='SALES'/>");
			Document templateDefaultDoc = XMLUtil.getDocument("<TeamList><Team TeamKey='' TeamId='' /></TeamList>");
			Document outpuDefaulttDoc=KohlsPocUserFeedAPI.invokeAPI(env, templateDefaultDoc, KohlsPOCConstant.API_GET_TEAM_LIST, inDefaultTeamDoc);
			if(!YFCCommon.isVoid(outpuDefaulttDoc)){
				Element eleDefaultTeam=(Element) outpuDefaulttDoc.getDocumentElement().getElementsByTagName("Team").item(0);
				if(!YFCCommon.isVoid(eleDefaultTeam)){
					sDefaultTeamKey = eleDefaultTeam.getAttribute(KohlsPOCConstant.ATTR_TEAM_KEY);				
					KohlsPocUserFeedAPI.loggerForUserFeed.debug(" sDefaultTeamKey :: "+sDefaultTeamKey);
				}
			}
			
			Document outputTeamDoc = null;
			if(strOrganizationKey!=null){
				 String sTeamIDAppendedTeam = strOrganizationKey+"Team";
				 Document inTeamDoc=XMLUtil.getDocument("<Team OrganizationCode='"+strOrganizationKey+"' TeamId='"+sTeamIDAppendedTeam+"' />");
				 KohlsPocUserFeedAPI.loggerForUserFeed.debug("The Team Doc"+XMLUtil.getXMLString(inTeamDoc));				 
				 Document templateDoc = XMLUtil.getDocument("<TeamList><Team /></TeamList>");
				 outputTeamDoc=KohlsPocUserFeedAPI.invokeAPI(env, templateDoc, KohlsPOCConstant.API_GET_TEAM_LIST, inTeamDoc);
				 if(!YFCCommon.isVoid(outputTeamDoc)) {
					 Element eleTeam=(Element) outputTeamDoc.getDocumentElement().getElementsByTagName("Team").item(0);
					 if(!YFCCommon.isVoid(eleTeam)){
						 	sParentKey = eleTeam.getAttribute(KohlsPOCConstant.ATTR_PARENT_TEAM_KEY);
							sTeamId = eleTeam.getAttribute(KohlsPOCConstant.ATTR_TeamId);
							if(!YFCCommon.isVoid(sTeamId)){
								isExistingTeam = true;
							}
							KohlsPocUserFeedAPI.loggerForUserFeed.debug(" sParentKey :: "+sParentKey);
							KohlsPocUserFeedAPI.loggerForUserFeed.debug(" sTeamId :: "+sTeamId);
					}
				}
			}
			
			
			
			
			//Document outputDoc=KohlsPocUserFeedAPI.invokeAPI(env,KohlsPOCConstant.API_GET_TEAM_LIST,inTeamDoc);

			/*KohlsPocUserFeedAPI.loggerForUserFeed.debug("The outputDoc Doc"+XMLUtil.getXMLString(outputDoc));
			
			String strDaTaSecuprityGroup=XPathUtil.getString(outputDoc, "/TeamList/Team/SubTeamList/Team/@TeamId");
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("The strDaTaSecuprityGroup Doc"+strDaTaSecuprityGroup);*/
			
			//checking if store parent team key is  equal to sales team id 
			if(!YFCCommon.isVoid(sParentKey) && !YFCCommon.isVoid(sDefaultTeamKey) && sParentKey.equals(sDefaultTeamKey) ){

				KohlsPocUserFeedAPI.loggerForUserFeed.debug(" if block :: ");
	
				eleUser.setAttribute(KohlsPOCConstant.ATTR_DATA_SECURITY_GROUP_ID, sTeamId);
			}
			else if (isExistingTeam && !sParentKey.equals(sDefaultTeamKey)){
				
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("Else if block  as key's are not equal sDefaultTeamKey ::"+sDefaultTeamKey);
				String strTeamId=manageTeam(strOrganizationKey,sDefaultTeamKey,env,isExistingTeam);
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("strTeamId"+strTeamId);
				
				eleUser.setAttribute(KohlsPOCConstant.ATTR_DATA_SECURITY_GROUP_ID, strTeamId);
			}
			else{
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("sDefaultTeamKey ::"+sDefaultTeamKey);
				String strTeamId=manageTeam(strOrganizationKey,sDefaultTeamKey,env,isExistingTeam);
				KohlsPocUserFeedAPI.loggerForUserFeed.debug("strTeamId"+strTeamId);
				
				eleUser.setAttribute(KohlsPOCConstant.ATTR_DATA_SECURITY_GROUP_ID, strTeamId);
			}
			//CPE-3121 changes end
			if(!YFCCommon.isVoid(strLocCode))
			{
				eleUser.setAttribute("Localecode", strLocCode);
			}
	//		End - Fix for setting Locale Code
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("end of try.modifyInputDoc new -- BEGIN");
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
			 }		
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.modifyInputDoc -- END");
		return userInput;
	}
		
	
	
private String manageTeam(String strOrganizationKey,String strParentTeamKey,YFSEnvironment env,boolean isExistingTeam) throws Exception {
		// TODO Auto-generated method stub
	String strTeamId=strOrganizationKey+KohlsPOCConstant.ATTR_Team;
	String strTeamDesc=KohlsPOCConstant.ATTR_Store+" "+strOrganizationKey+" "+KohlsPOCConstant.ATTR_TeamId;
	Document inDoc;
	if(isExistingTeam){
		inDoc=XMLUtil.getDocument(KohlsPOCConstant.TEMPLATE_MANAGE_EXISTING_TEAM);
	}
	else {
	 inDoc=XMLUtil.getDocument(KohlsPOCConstant.TEMPLATE_MANAGE_TEAM);
	}
	Element eleTeam=inDoc.getDocumentElement();
	
	eleTeam.setAttribute(KohlsPOCConstant.ATTR_TeamId, strTeamId);
	eleTeam.setAttribute(KohlsPOCConstant.ATTR_DESCRIPTION, strTeamDesc);
	eleTeam.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, strOrganizationKey);
	eleTeam.setAttribute(KohlsPOCConstant.ATTR_PARENT_TEAM_KEY, strParentTeamKey);
	KohlsPocUserFeedAPI.loggerForUserFeed.debug("the manage Team input is "+XMLUtil.getXMLString(inDoc));
	Document outDoc=KohlsPocUserFeedAPI.invokeAPI(env, KohlsPOCConstant.API_MANAGE_TEAM, inDoc);
	
	KohlsPocUserFeedAPI.loggerForUserFeed.debug("The outDoc Doc"+XMLUtil.getXMLString(outDoc));
	
	if(outDoc!=null)
	{
		
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("The strTeamId Doc"+strTeamId);
		
		return strTeamId;
	}
	else{
		return null;
	}
		
	}


//	Start - Fix for setting Locale Code	
	/**
 	 * This function fetches the localeCode for a given organizationKey
 	 * 
 	 * @param env
 	 * @param strOrKey
 	 * @return strLocaleCode
 	 *           
 	 */	
	private String fetchLocaleCode(YFSEnvironment env, String strOrKey)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.fetchLocaleCode -- BEGIN");
		String strLocaleCode = null;
		try
		{
		//Create Input for getOrganizationHierarchy
		Document docOrgHierInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORGANIZATION).getDocument();
		Element elemOrg = docOrgHierInput.getDocumentElement();
		elemOrg.setAttribute(KohlsPOCConstant.ATTR_ORGANIZATION_KEY, strOrKey);
		
		//Call getOrganizationHierarchy API
		docOrgHierOutput = KohlsPocUserFeedAPI.invokeAPI(env,KohlsPOCConstant.TEMPLATE_GET_ORGANIZATION_HIERARCHY, KohlsPOCConstant.API_GET_ORGANIZAION_HIERARCHY, docOrgHierInput);
		strLocaleCode = ((Element)((XPathUtil.getNodeList(docOrgHierOutput.getDocumentElement(), "/Organization")).item(0))).getAttribute(KohlsPOCConstant.ATTR_LOCALE_CODE);
		}
		catch(Exception e)
		{
			if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
			 }	
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.fetchLocaleCode -- END");
		return strLocaleCode;
	}
//	End - Fix for setting Locale Code
	/**
 	 * This function updates the existing user details   
 	 * for the User from the input XML
 	 * 
 	 * @param env
 	 * @param userInputDoc
 	 * @return none
 	 *           
 	 */	
	private void modifyExistingUser(YFSEnvironment env, Document userInputDoc)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.modifyExistingUser -- BEGIN");
		try {

			userInputDoc = conditionCheckBeforeAction(env, userInputDoc, KohlsPOCConstant.ACTION_MODIFY);
			checkForTempRoles(env);
					
			//Create input for modifyUserHierarchy
			Document docUserHierarchy = null;
			Element eleUserGroupLists = (Element)((NodeList)XPathUtil.getNodeList(userInputDoc.getDocumentElement(), "/User/UserGroupLists")).item(0);
			if (arrListTempRoles.size()>0)
			{
				for(int i=0; i< arrListTempRoles.size();i++)
				{
					Element eleUserGroupList = XMLUtil.createElement(userInputDoc, "UserGroupList", 'Y');
					//Element eleUserGroupList = docUserHierarchy.createElement("UserGroupList");
					eleUserGroupList.setAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID, arrListTempRoles.get(i).toString());
					eleUserGroupLists.appendChild(eleUserGroupList);
				}
			}
			docUserHierarchy = modifyInputDoc(env,userInputDoc);
			Element eleUsrGroupLists = (Element)((NodeList)XPathUtil.getNodeList(docUserHierarchy.getDocumentElement(), "/User/UserGroupLists")).item(0);
			eleUsrGroupLists.setAttribute(KohlsPOCConstant.ATTR_RESET, KohlsPOCConstant.YES);

			KohlsPocUserFeedAPI.invokeAPI(env,KohlsPOCConstant.API_MODIFY_USER_HIERARCHY, docUserHierarchy);
			KohlsPocUserFeedAPI.loggerForUserFeed.verbose(strUserLoginId+" User modified successfully");
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.modifyExistingUser -- END");
		}
		catch(Exception e)
		{
			if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
			 }	
		}
	}

	/**
 	 * This function check if user has any temp roles that are not
 	 * in ITIM message and accordingly update the user access roles. 
 	 * 
 	 * @param env
 	 * @return none
 	 *           
 	 */	
	
	private void checkForTempRoles(YFSEnvironment env)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.checkForTempRoles -- BEGIN");
		try {
			
			//Document docGetUserLst = getUserList(env);
			NodeList ndLstUserLst = XPathUtil.getNodeList(docUserList.getDocumentElement(), "/UserList/User/UserGroupLists/UserGroupList");
			
			Document docTempRoles = getCommonCodeList(env, KohlsPOCConstant.STRING_TEMP_CODE_TYPE);
			NodeList ndListTempRoles = XPathUtil.getNodeList(docTempRoles.getDocumentElement(), "/CommonCodeList/CommonCode");
			
			if (ndLstUserLst!=null && ndListTempRoles!=null && ndListTempRoles.getLength()> 0)
			{
				for(int i=0;i<ndLstUserLst.getLength();i++)
				{
					Element eleUserLst = (Element)(ndLstUserLst.item(i));
					String strCodeValue = eleUserLst.getAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID);
					
					for (int j=0; j<ndListTempRoles.getLength(); j++)
					{
						String strTempRole = ((Element)ndListTempRoles.item(j)).getAttribute(KohlsPOCConstant.ATTR_CODE_NAME);
						if (strCodeValue.equals(strTempRole))
						{
							arrListTempRoles.add(strTempRole);
							break;
						}
					}
				}
			}
			KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.checkForTempRoles -- END");
		}
		catch(Exception e)
		{ 
			e.printStackTrace();
			 if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
			 }	
		}
	}
	

		/**
 	 * This function performs all the required condition
 	 * checks before creating/updating/modifying a user.
 	 * 
 	 * @param env
 	 * @param docUserInput
 	 * @return validateFlag - boolean
 	 *           
 	 */	
	
	private Document conditionCheckBeforeAction (YFSEnvironment env, Document docUserInput, String strAction)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.conditionCheckBeforeAction -- BEGIN");
		//boolean validateFlag = false;
		try
		{
			NodeList ndLstUserGpList = XPathUtil.getNodeList(docUserInput.getDocumentElement(), "/User/UserGroupLists/UserGroupList");
			if(ndLstUserGpList!=null)
			{
				Document docUserGrpList = YFCDocument.createDocument(KohlsPOCConstant.ELEM_USER_GROUP_LISTS).getDocument();
				Element eleUserGroupLists = docUserGrpList.getDocumentElement();
				for(int i=0;i<ndLstUserGpList.getLength();i++)
				{
					Element eleUsrGpLst = (Element)(ndLstUserGpList.item(i));
					eleUsrGpLst = fetchOMSCommonCode(env, eleUsrGpLst);
					docCommonCodeList = getCommonCodeList(env, eleUsrGpLst.getAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID)); 
					NodeList ndLstCommonCodeList = XPathUtil.getNodeList(docCommonCodeList.getDocumentElement(), "/CommonCodeList/CommonCode");
					if(ndLstCommonCodeList!=null)
					{
						for(int k=0;k<ndLstCommonCodeList.getLength();k++)
						{
							Element eleComCode = (Element)ndLstCommonCodeList.item(k);
							String eleCodeName = eleComCode.getAttribute(KohlsPOCConstant.ATTR_CODE_NAME);
							Element eleUserGroupList = XMLUtil.createElement(docUserGrpList, "UserGroupList", 'Y');
							eleUserGroupList.setAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID, eleCodeName);
							eleUserGroupLists.appendChild(eleUserGroupList);
						}
					}
				}
				
				Element eleUser = (Element)(XPathUtil.getNodeList(docUserInput.getDocumentElement(), "/User")).item(0);
				eleUser.removeChild((Element)(XPathUtil.getNodeList(docUserInput.getDocumentElement(), "/User/UserGroupLists")).item(0));
				XMLUtil.importElement(eleUser,eleUserGroupLists);
			}
			docUserInput = removeDuplicateRoles(env, docUserInput);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			 if (ex instanceof YFSException) {
				YFSException yfsException = (YFSException) ex;
				throw yfsException;
			 }	
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.conditionCheckBeforeAction -- END");
		return  docUserInput;
	}

	
		/**
 	 * This function finds the corresponding oms role
	 * for the ITIM role.
 	 * 
 	 * @param env
 	 * @param eleUsrGpLst
 	 * @return eleUsrGpLst - Element
 	 *           
 	 */	
	private Element fetchOMSCommonCode(YFSEnvironment env, Element eleUsrGpLst) {
		Map<String,String> omsGpIds = new HashMap<String, String>();
		omsGpIds.put("StoreAdministrativeAssistant", "StoreAdminAssistant");
		omsGpIds.put("TerritoryOperationsManager","TerritoryOpMgr");
		omsGpIds.put("AssistantStoreManager","AssistantStoreMgr");
		omsGpIds.put("BeautyJewelryAssociates","BeautyJewelryAssoc");
		omsGpIds.put("AdSetPriceChangeAssociates","AdSetPriceChngAssoc");
		omsGpIds.put("FreightReplenishmentAssociates","FreightRepAssoc");
		
		String itimUserGpId = eleUsrGpLst.getAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID);
		
		Iterator it = omsGpIds.entrySet().iterator();
		while(it.hasNext())
		{
			Map.Entry m = (Map.Entry)it.next();
			String strUserGrpKey = (String)m.getKey();
			if(itimUserGpId.equalsIgnoreCase(strUserGrpKey))
			{
				eleUsrGpLst.setAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID, (String)m.getValue());
				return eleUsrGpLst;
			}
		}
			return eleUsrGpLst;
		}


	/**
 	 * This function checks to see if roles in the user is more than 1.
 	 * 
 	 * @param env
 	 * @param inputDoc
 	 * @return checkDupRoles - boolean
 	 *           
 	 */	
	
private Document removeDuplicateRoles(YFSEnvironment env, Document inputDoc)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.removeDuplicateRoles -- BEGIN");
		try {
			NodeList ndListUserGroup = ((NodeList)(XPathUtil.getNodeList(inputDoc.getDocumentElement(), "/User/UserGroupLists/UserGroupList")));
			if(!YFCCommon.isVoid(ndListUserGroup) && ndListUserGroup.getLength() > 0)
			{
				ArrayList arListUserGroups = new ArrayList();
				for (int i=0;i<ndListUserGroup.getLength();i++)
				{
					Element eleUserGpList = (Element)ndListUserGroup.item(i);
					String strUserGpId = eleUserGpList.getAttribute(KohlsPOCConstant.ATTR_USERGROUP_ID);
					if(YFCCommon.isVoid(arListUserGroups))
					{
						arListUserGroups.add(strUserGpId);
					}
					else
					{
						if(!arListUserGroups.contains(strUserGpId))
						{
							arListUserGroups.add(strUserGpId);
						}
						else
						{
							Element eleUserGroupLists = (Element)(XPathUtil.getNodeList(inputDoc.getDocumentElement(),"/User/UserGroupLists")).item(0);
							XMLUtil.removeChild(eleUserGroupLists, eleUserGpList);
						}
					}
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			 if (ex instanceof YFSException) {
				YFSException yfsException = (YFSException) ex;
				throw yfsException;
			 }	
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.removeDuplicateRoles -- END");
		return inputDoc;
	}
		/**
 	 * This function retrieves common code for 
 	 * ITIM roles
 	 * 
 	 * @param environment
 	 * @param strCodeType
 	 * @return docComCdLstOutput
 	 *           
 	 */	

	private Document getCommonCodeList(YFSEnvironment environment, String strCodeType)
	{
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.getCommonCodeList -- BEGIN");
		Document docComCdLstOutput = null;
		try {
			//Create Input XML for getCommonCodeList API
			Document docComCdLstInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_COMMON_CODE).getDocument();
			Element eleCommonCode = docComCdLstInput.getDocumentElement();
			eleCommonCode.setAttribute(KohlsPOCConstant.ATTR_CODE_TYPE, strCodeType);
			// Start - Fix for better performance
			if(strCodeType.equalsIgnoreCase(KohlsPOCConstant.STRING_KOHLS_CORP_LOC_CODE_TYPE)|| strCodeType.equalsIgnoreCase(KohlsPOCConstant.STRING_STORE_LOC_FILTER_CODE_TYPE))
			{
				eleCommonCode.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrgKey);
			}
			// End - Fix for better performance
			docComCdLstOutput = invokeAPI(environment, KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docComCdLstInput);
			NodeList ndListComCodes = XPathUtil.getNodeList(docComCdLstOutput.getDocumentElement(), "/CommonCodeList/CommonCode");
			KohlsPocUserFeedAPI.loggerForUserFeed.verbose("CommonCode list length for code type "+strCodeType+" is : "+ndListComCodes.getLength());
			if(ndListComCodes.getLength()==0 && !(strCodeType.equalsIgnoreCase(KohlsPOCConstant.STRING_KOHLS_CORP_LOC_CODE_TYPE)|| strCodeType.equalsIgnoreCase(KohlsPOCConstant.STRING_STORE_LOC_FILTER_CODE_TYPE)))
			{
				throw new Exception();
			}
		}
		catch(Exception ex)
		{
			if(!(strCodeType.equalsIgnoreCase(KohlsPOCConstant.STRING_KOHLS_CORP_LOC_CODE_TYPE)|| (strCodeType.equalsIgnoreCase(KohlsPOCConstant.STRING_STORE_LOC_FILTER_CODE_TYPE))))
			{
				YFSException exception = new YFSException();
				exception.setErrorCode("EXTN_MISSING_TIM_ROLE");
				exception.setErrorDescription("ITIM Role Mapping Missing from Common Codes");
				throw exception;
			}
		}
		KohlsPocUserFeedAPI.loggerForUserFeed.debug("KohlsPocUserFeedAPI.getCommonCodeList -- END");
		return docComCdLstOutput;
	}
}
