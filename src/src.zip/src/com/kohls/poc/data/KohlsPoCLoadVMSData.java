package com.kohls.poc.data;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.KohlsUtil;
import com.kohls.poc.constant.KohlsPOCConstant;

import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfs.japi.YFSEnvironment;

/*import com.kohls.common.util.XPathUtil;
import com.kohls.common.util.KOHLSBaseApi;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.util.YFCCommon;*/

public class KohlsPoCLoadVMSData {
	
	private static final YFCLogCategory log = YFCLogCategory.instance(
			KohlsPoCLoadVMSData.class.getName());
	
	/**
	 * This method prepares an xml input document for multiApi to integrate VMS Data setup in OMS 
	 * by processing the input XML message from Tibco 
	 * @param env
	 * @param docInXML
	 * @return docOutXML
	 * @exception Exception
	 */
	
	public static Document loadVMSData(YFSEnvironment env, Document docInXML)
			throws ParserConfigurationException, TransformerException {
		Document docOutXML = null;
		
		try {
		log.beginTimer("KohlsPoCLoadVMSData.loadVMSData");
		if(YFCLogUtil.isDebugEnabled()){
					log.debug("######### loadVMSData input XML #########"+ KohlsUtil.extractStringFromNode(docInXML));
			}
		docOutXML = XMLUtil.createDocument(KohlsPOCConstant.E_MULTI_API);
		Element eleMultiApi = docOutXML.getDocumentElement();

	   NodeList nlVndDispList = docInXML.getElementsByTagName(KohlsPOCConstant.E_VNDDISPOCODE);
	 
	   for (int i = 0; i < nlVndDispList.getLength(); i++) {
	       Node nNode = nlVndDispList.item(i);
	       Element eleVndDispoCode = (Element) nNode;
	       
	       Element eleAPI = docOutXML.createElement(KohlsPOCConstant.E_API);
	       eleMultiApi.appendChild(eleAPI);
	               
	       String sSection = eleVndDispoCode.getAttribute(KohlsPOCConstant.A_SECTION);
	       String sAction = eleVndDispoCode.getAttribute(KohlsPOCConstant.A_ACTION);
	       
	       //Process VS section 
	       if (sSection.equalsIgnoreCase("VS")){
	       if (sAction.equalsIgnoreCase(KohlsPOCConstant.A_CREATE)) {
				
				if(YFCLogUtil.isDebugEnabled()){
							log.debug("######### In the Create Action Block #########"+ sAction);
					}
				eleAPI.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.API_CREATEVNDDISPOCODE);
				Element eleInput = docOutXML.createElement(KohlsPOCConstant.E_INPUT);
			    eleAPI.appendChild(eleInput);
			    eleInput.appendChild(docOutXML.importNode(eleVndDispoCode, true));
			}
	       else if (sAction.equalsIgnoreCase(KohlsPOCConstant.DELETE)) {
				
				if(YFCLogUtil.isDebugEnabled()){
							log.debug("######### In the Delete Action Block #########"+ sAction);
					}
				eleAPI.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.API_DELETEVNDDISPOCODE);
				Element eleInput = docOutXML.createElement(KohlsPOCConstant.E_INPUT);
			    eleAPI.appendChild(eleInput);
			    eleInput.appendChild(docOutXML.importNode(eleVndDispoCode, true));
			}
	        //Comment below section as OMS lookup is not required for DELETE action of a VS section
	        //Tibco will be providing the OMS Key to process the delete record
			/*else if (sAction.equalsIgnoreCase(KohlsPOCConstant.DELETE)){
					String sStyleId = eleVndDispoCode.getAttribute(KohlsPOCConstant.A_STYLEID);
					String sDeptNbr = eleVndDispoCode.getAttribute(KohlsPOCConstant.A_DEPTNBR);
					String sENTId = eleVndDispoCode.getAttribute(KohlsPOCConstant.A_ENTID);
					
					Document docInput = YFCDocument.createDocument(KohlsPOCConstant.E_VNDDISPOCODE).getDocument();
					Element eledocInputRoot = docInput.getDocumentElement();
					
					eledocInputRoot.setAttribute(KohlsPOCConstant.A_STYLEID, sStyleId);
					if(!YFCCommon.isVoid(sDeptNbr)){
					eledocInputRoot.setAttribute(KohlsPOCConstant.A_DEPTNBR, sDeptNbr);
					}
					if(!YFCCommon.isVoid(sENTId)){
					eledocInputRoot.setAttribute(KohlsPOCConstant.A_ENTID, sENTId);
					}		
					if(YFCLogUtil.isDebugEnabled()){
						log.debug("API Input is ::"+XMLUtil.getXMLString(docInput));
					}
					Document docGetVndDispoCodeList = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.API_GETVNDDISPOCODELIST,docInput);
								
					if(YFCLogUtil.isDebugEnabled()){
						log.debug("Invoking GetVndDispoCodeList");
					}
				 
					if(!YFCObject.isVoid(docGetVndDispoCodeList)){
						Element eleRootElement = docGetVndDispoCodeList.getDocumentElement();
						
						NodeList ndlVndDispoCodes = XPathUtil.getNodeList(eleRootElement,KohlsPOCConstant.E_VNDDISPOCODE);
						if(!YFCObject.isVoid(ndlVndDispoCodes)){
							//Delete all matching records
							for (int j=0;  j < ndlVndDispoCodes.getLength(); j++){
							Element elementVndDispoCode = (Element) ndlVndDispoCodes.item(j);
							//Element elementVndDispoCode = (Element) ndlVndDispoCodes.item(0);
							String sVendorStyleDispKey = elementVndDispoCode.getAttribute(KohlsPOCConstant.A_VENDORSTYLEDISPKEY);
							//Prepare input for deleting a record from VndDispCode
							if(!YFCCommon.isVoid(sVendorStyleDispKey)){
								
									if(YFCLogUtil.isDebugEnabled()){
										log.debug("######### In the Delete Action Block #########"+ sAction);
										}				
									eleAPI.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.API_DELETEVNDDISPOCODE);
									Element eleInput = docOutXML.createElement(KohlsPOCConstant.E_INPUT);
									eleAPI.appendChild(eleInput);
									eleVndDispoCode.setAttribute(KohlsPOCConstant.A_VENDORSTYLEDISPKEY, sVendorStyleDispKey);
									eleInput.appendChild(docOutXML.importNode(eleVndDispoCode, true));
								}							
							  }	
							}
						}
					}*/
	       else if(sAction.equalsIgnoreCase(KohlsPOCConstant.MODIFY)) {
	    	   if(YFCLogUtil.isDebugEnabled()){
	    		   log.debug("######### In the Modify Action Block #########"+ sAction);
	    	   }
	    	   eleAPI.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.API_CHANGEVNDDISPOCODE);
	    	   Element eleInput = docOutXML.createElement(KohlsPOCConstant.E_INPUT);
	    	   eleAPI.appendChild(eleInput);
	    	   eleVndDispoCode.setAttribute(KohlsPOCConstant.A_Select_Method, KohlsPOCConstant.SELECT_METHOD_WAIT);
	    	   eleInput.appendChild(docOutXML.importNode(eleVndDispoCode, true));
	       }
	      }
	     //Process VD section 
	       if (sSection.equalsIgnoreCase("VD")){
	    	   if(sAction.equalsIgnoreCase(KohlsPOCConstant.MODIFY)) {
					if(YFCLogUtil.isDebugEnabled()){
						log.debug("######### In the Modify Action Block #########"+ sAction);
						}
				eleAPI.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.API_CHANGEVNDDISPOCODE);
				Element eleInput = docOutXML.createElement(KohlsPOCConstant.E_INPUT);
				eleAPI.appendChild(eleInput);
				eleInput.appendChild(docOutXML.importNode(eleVndDispoCode, true));
			        eleVndDispoCode.setAttribute(KohlsPOCConstant.A_Select_Method, KohlsPOCConstant.SELECT_METHOD_WAIT);
		 }
		 else if (sAction.equalsIgnoreCase(KohlsPOCConstant.DELETE) || sAction.equalsIgnoreCase(KohlsPOCConstant.A_CREATE)){
			//Do not process, print a log
	    	 log.debug("Not processing the record of Vendor Disposition section for action:"+ sAction);
	    	//Remove child element "API" as record is not required to be processed
	    	 eleMultiApi.removeChild(eleAPI);
		   }
	    }
	  }       
	   if(YFCLogUtil.isDebugEnabled()){
			log.debug("######### loadVMSData output XML #########"+ KohlsUtil.extractStringFromNode(docOutXML));
		}
		log.endTimer("KohlsPoCLoadVMSData.loadVMSData");
			
	} catch (Exception e) {
			   e.printStackTrace();
			   }
	return docOutXML;
	}
}
