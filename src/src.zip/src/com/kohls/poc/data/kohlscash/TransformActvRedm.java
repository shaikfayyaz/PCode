package com.kohls.poc.data.kohlscash;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;

public class TransformActvRedm {
	
	final static String MISSING_INCOMING_DIR = "INCOMING DIRECTORY NOT FOUND OR IS NOT A DIRECTORY";
	final static String MISSING_MOUNTED_DIR = "MOUNTED DIRECTORY NOT FOUND OR IS NOT A DIRECTORY";
	final static String MISSING_REDEEM_FILE = "REDEEM FILE NOT FOUND IN MOUNTED DIRECTORY";
	final static String MISSING_ACTIVATE_FILE = "ACTIVATE FILE NOT FOUND IN MOUNTED DIRECTORY";
	
	final static String INCOMING_DIRECTORY_PATH = "/kohls/apps/file/offlinekc/incoming";
	final static String MOUNTED_DIRECTORY_PATH = "/etl/ep/kc";
	
	final static String REDEEM_FILENAME = "RWDREDM.DAT";
	final static String OFF_REDEEM_FILENAME = "OFFLRWDREDM.DAT";
	final static String ACTIVATE_FILENAME = "RWDACTV.DAT";
	final static String OFF_ACTIVATE_FILENAME = "OFFLRWDACTV.DAT";
	
	final static String OFFLINE_ACTIVATION_HEADER = "KCHEADER@offlineactivationrecords\n";
	final static String OFFLINE_REDEEM_HEADER = "KCHEADER@offlineredemptionrecords\n";
	final static String KCA_PRE = "KCA@";
	final static String KCR_PRE = "KCR@";
	
	final static String API_SUCCESS = "SUCCESS";
	final static String API_FAILURE = "FAILURE";
	final static String REDM_SUCCESS = "REDM FILE TRANSFORMED";
	final static String REDM_FAILURE = "REDM FILE FAILURE";
	final static String ACTV_SUCCESS = "ACTV FILE TRANSFORMED";
	final static String ACTV_FAILURE = "ACTV FILE FAILURE";
	
	public static void main(String args[]) {
		transformActvRedm();
	}
	
	public static void transformActvRedm() {
		try {
			// Make sure the incoming directory exists
			File incomingDir = new File(INCOMING_DIRECTORY_PATH);
			if (!incomingDir.exists() || !incomingDir.isDirectory()) {
				throw new IOException(MISSING_INCOMING_DIR);
			}

			// Check if the mounted path exists
			File mountedDir = new File(MOUNTED_DIRECTORY_PATH);
			if (!mountedDir.exists() || !mountedDir.isDirectory()) {
				throw new IOException(MISSING_MOUNTED_DIR);
			}

			// Set mounted and local file paths
			String mountedRedeemFilepath = MOUNTED_DIRECTORY_PATH + "/" + REDEEM_FILENAME;
			String mountedActivateFilepath = MOUNTED_DIRECTORY_PATH + "/" + ACTIVATE_FILENAME;

			String localRedeemFilepath = INCOMING_DIRECTORY_PATH + "/" + OFF_REDEEM_FILENAME;
			String localActivateFilepath = INCOMING_DIRECTORY_PATH + "/" + OFF_ACTIVATE_FILENAME;

			// Check if the files exist in the mounted directory
			File mountedRedeemFile = new File(mountedRedeemFilepath);
			if (!mountedRedeemFile.exists()) {
				throw new IOException(MISSING_REDEEM_FILE);
			}
			File mountedActivateFile = new File(mountedActivateFilepath);
			if (!mountedActivateFile.exists()) {
				throw new IOException(MISSING_ACTIVATE_FILE);
			}

			// Transform the redeem file
			transformRedm(mountedRedeemFilepath, localRedeemFilepath);
			// Transform the activate file
			transformActv(mountedActivateFilepath, localActivateFilepath);
			
			System.out.println(API_SUCCESS);
		} catch (Exception ex) {
			System.out.print(ex);
			System.out.println(API_FAILURE);
		}
	}

	public static void transformActv(String mount, String local) throws Exception {
		FileInputStream fstream = null;
		BufferedReader br = null;
		FileWriter writer = null;

		try {
			fstream = new FileInputStream(mount);
			br = new BufferedReader(new InputStreamReader(fstream));

			ArrayList<String> lines = new ArrayList<String>();

			lines.add(OFFLINE_ACTIVATION_HEADER);

			String strLine;

			while ((strLine = br.readLine()) != null) {
				if(!strLine.isEmpty()) {
					strLine = KCA_PRE + strLine + '\n';
					lines.add(strLine);
				}
			}

			writer = new FileWriter(local);
			for (String line : lines) {
				writer.write(line);
			}
			
			System.out.println(ACTV_SUCCESS);
		} catch (Exception ex) {
			System.out.println(ACTV_FAILURE);
			throw ex;
		} finally {
			br.close();
			fstream.close();
			writer.close();
		}
	}

	public static void transformRedm(String mount, String local) throws Exception {
		FileInputStream fstream = null;
		BufferedReader br = null;
		FileWriter writer = null;

		try {
			fstream = new FileInputStream(mount);
			br = new BufferedReader(new InputStreamReader(fstream));

			ArrayList<String> lines = new ArrayList<String>();
			
			lines.add(OFFLINE_REDEEM_HEADER);

			String strLine;

			while ((strLine = br.readLine()) != null) {
				if(!strLine.isEmpty()) {
					strLine = KCR_PRE + strLine + '\n';
					lines.add(strLine);
				}
			}

			writer = new FileWriter(local);
			for (String line : lines) {
				writer.write(line);
			}
			
			System.out.println(REDM_SUCCESS);
		} catch (Exception ex) {
			System.out.println(REDM_FAILURE);
			throw ex;
		} finally {
			br.close();
			fstream.close();
			writer.close();
		}

	}

}
