package com.kohls.poc.data.kohlscash;

public enum KohlsCouponType {
	KOHLSCASHAUTH, 
    KOHLSCASHNOAUTH, 
    LEGACY,
    NONE
}
