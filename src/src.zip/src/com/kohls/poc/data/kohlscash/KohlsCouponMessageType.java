package com.kohls.poc.data.kohlscash;

public enum KohlsCouponMessageType {
	INQUIRY,
	TENDER,
	VOIDTENDER,
}
