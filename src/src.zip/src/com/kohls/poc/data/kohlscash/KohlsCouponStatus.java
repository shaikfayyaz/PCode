package com.kohls.poc.data.kohlscash;

public enum KohlsCouponStatus {
	NONE,
    ACTIVE,
    PREREDEMPTION, 
    POSTREDEMPTION
}
