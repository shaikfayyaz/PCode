package com.kohls.poc.data.kohlscash;

public enum KohlsCashResponseCode {
	Approved("0"),
    EditError("2"),
    HardDecline("7"),
    Referral("8"),
    Offline("9");
	
	private final String value;
	
	KohlsCashResponseCode(String value) {
		this.value = value;
	}
	
	public String getValue() {
        return value;
    }
}
