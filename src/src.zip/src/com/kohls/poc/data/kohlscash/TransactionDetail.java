package com.kohls.poc.data.kohlscash;

import java.util.HashMap;
import java.util.Map;

public class TransactionDetail {

	private String transactionType;
	private String storeName;
	private String storeNumber;
	private String transactionAmount;
	private String transactionTimestamp;
	
	public String getTransactionType() {
		return transactionTypes.containsKey(transactionType) ? transactionTypes.get(transactionType) : transactionType;
	}
	
	public String getStoreName() {
		return this.storeName;
	}
	
	public String getStoreNumber() {
		return this.storeNumber;
	}
	
	public String getTransactionAmount() {
		return this.transactionAmount;
	}
	
	public String getTransactionTimestamp() {
		return this.transactionTimestamp;
	}
	
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}
	
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	
	public void setTransactionTimestamp(String transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
	}
	
	Map<String, String> transactionTypes = new HashMap<String, String>() {{
		put("ISSUE", "ISSUED");
        put("TENDER", "REDEEMED");
        put("VOIDTENDER", "VOIDED");
        put("VOIDISSUE", "VOIDED");
        put("OFFLINETENDER", "REDEEMED");
        put("INQUIRY", "INQUIRY");
        put("VOIDDEDUCT", "VOIDED");
        put("DEDUCTRFN", "RETURNED");
        put("DEDUCTAFN", "RETURNED");
        put("DEDUCTRPO", "RETURNED");
        put("DEDUCTRUO", "RETURNED");
        put("DEDUCTRUK", "RETURNED");
        put("DEDUCTRPK", "RETURNED");
        put("DEDUCTRFK", "RETURNED");
        put("DEDUCTOFN", "RETURNED");
        put("DEDUCTOPK", "RETURNED");
        put("DEDUCTOUK", "RETURNED");
        put("DEDUCTOUO", "RETURNED");
        put("DEDUCTOPO", "RETURNED");
        put("DEDUCTOPN", "RETURNED");
        put("DEDUCTRPN", "RETURNED");
        put("DEDUCTRUN", "RETURNED");
        put("DEDUCTOUN", "RETURNED");
        put("DEDUCTRFO", "RETURNED");
        put("VOIDOFFLINE", "VOIDED");
	}};
}
