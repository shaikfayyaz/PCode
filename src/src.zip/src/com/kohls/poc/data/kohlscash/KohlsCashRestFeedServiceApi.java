package com.kohls.poc.data.kohlscash;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;

import com.google.gson.Gson;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.rest.KohlsRestAPIUtilBuilder;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Element;

public class KohlsCashRestFeedServiceApi extends KOHLSBaseApi {

    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsCashRestFeedServiceApi.class.getName());
    public static final String KC_FEED_HOST = "KC_FEED_HOST";
    public static final String KC_FEED_ACTIVATION_URI = "KC_FEED_ACTIVATION_URI";
    public static final String KC_FEED_REDEMPTION_URI = "KC_FEED_REDEMPTION_URI";
    public static final String KC_FEED_TIMEOUT = "KC_FEED_TIMEOUT";
    public static final String KC_FEED_EXPAND_CORP_EVENTS = "KC_FEED_EXPAND_CORP_EVENTS";

    private List<String> storeList;

    public void callRestApi(YFSEnvironment env, Document inputKohlsCashFeed) {
        KohlsPocKohlsCashFeedAPI legacyApi = new KohlsPocKohlsCashFeedAPI();
        try {
            this.storeList = getStoreListFromOmsr(env);
        } catch(Exception ex) {
            logger.error("Failed to load store list from getOrganizationList API.", ex);
        }

        try {
            loadActivationEvents(env, legacyApi);
        } catch(Exception ex) {
            logger.error("Failed to load REST Kohls Cash Activation event feed.", ex);
        }

        try {
            loadRedemptionEvents(env, legacyApi);
        } catch(Exception ex) {
            logger.error("Failed to load REST Kohls Cash Redemption event feed.", ex);
        }

    }

    private void loadRedemptionEvents(YFSEnvironment env, KohlsPocKohlsCashFeedAPI legacyApi) throws Exception {
        //REDEMPTION EVENTS
        String redemptionEventsByAPI = fetchKohlsCashFeed(KC_FEED_REDEMPTION_URI);

        Map<String, List<KohlsCashRedeemEvent>> kohlsCashRedeemMap = new HashMap<>();

        KohlsCashRedeemEvent[] kohlsCashRedeemEvents = new Gson().fromJson(redemptionEventsByAPI, KohlsCashRedeemEvent[].class);
        for (KohlsCashRedeemEvent kcEvent : kohlsCashRedeemEvents) {
            if (kcEvent.isCorpEvent) {
                processCorpEvent(kcEvent, kohlsCashRedeemMap);
            } else {
                for (String storeNumber : kcEvent.stores) {
                    populateKCEventMap(kcEvent, storeNumber, kohlsCashRedeemMap);
                }
            }
        }
        //All events have been added by store number.
        long beginTime = System.currentTimeMillis();
        legacyApi.kohlsCashRedemptionMain(env, kohlsCashRedeemMap);
        long endTime = System.currentTimeMillis();
        long redmLoadTime = endTime - beginTime;

        logger.info(String.format("Redeem event load time was %d ms", redmLoadTime));
    }

    private void loadActivationEvents(YFSEnvironment env, KohlsPocKohlsCashFeedAPI legacyApi) throws Exception {
        //ACTIVATION EVENTS
        String activationEventsByAPI = fetchKohlsCashFeed(KC_FEED_ACTIVATION_URI);

        Map<String, List<KohlsCashActvEvent>> kohlsCashActvMap = new HashMap<>();

        KohlsCashActvEvent[] kohlsCashActvEvents = new Gson().fromJson(activationEventsByAPI, KohlsCashActvEvent[].class);
        for (KohlsCashActvEvent kcEvent : kohlsCashActvEvents) {
            if (kcEvent.isCorpEvent) {
                processCorpEvent(kcEvent, kohlsCashActvMap);
            } else {
                for (String storeNumber : kcEvent.stores) {
                    populateKCEventMap(kcEvent, storeNumber, kohlsCashActvMap);
                }
            }
        }
        //All events have been added by store number.
        long beginTime = System.currentTimeMillis();
        legacyApi.kohlsCashActivationMain(env, kohlsCashActvMap);
        long endTime = System.currentTimeMillis();
        long actvLoadTime = endTime - beginTime;

        logger.info(String.format("Activate event load time was %d ms", actvLoadTime));
    }

    private <E> void processCorpEvent(E kcEvent, Map<String, List<E>> kohlsCashMap) {
        String expandCorpEvents = YFSSystem.getProperty(KC_FEED_EXPAND_CORP_EVENTS);

        if(logger.isDebugEnabled())
            logger.debug(String.format("Value of KC_FEED_EXPAND_CORP_EVENTS is: %s", expandCorpEvents));

        if(KohlsConstant.TRUE.equalsIgnoreCase(expandCorpEvents)) {
            //Create an entry for each store
            for(String storeId : storeList) {
                //Reading the events will read store ID with a length of 4, so we want to left-pad with 0 up to 4 digits
                populateKCEventMap(kcEvent, padLeftZeros(storeId), kohlsCashMap);
            }
        } else {
            //Insert a single event for "ALL" stores
            populateKCEventMap(kcEvent, KohlsConstant.ALL_ITEM_ID, kohlsCashMap);
        }
    }

    private <E> void populateKCEventMap(E kcEvent, String storeNumber, Map<String, List<E>> kohlsCashMap) {
        List<E> kcEventList = kohlsCashMap.get(storeNumber);
        if (kcEventList == null) {
            kcEventList = new ArrayList<>();
            kcEventList.add(kcEvent);
            kohlsCashMap.put(storeNumber, kcEventList);
        } else {
            kcEventList.add(kcEvent);
        }
    }

    private String fetchKohlsCashFeed(String kcEventFeedUri) throws Exception {
        Map<String, String> depHeaderMap = new TreeMap<>();
        Map<String, String> headerMap = new TreeMap<>();

        String restDKCHost = YFSSystem.getProperty(KC_FEED_HOST);
        String kcFeedUri = YFSSystem.getProperty(kcEventFeedUri);
        String readTimeOut = YFSSystem.getProperty(KC_FEED_TIMEOUT);
        String kcFeedUrl = restDKCHost + kcFeedUri;

        ResponseEntity response = null;
        String responseBody = null;
        long beginTime = System.currentTimeMillis();
        response = new KohlsRestAPIUtilBuilder().setHttpMethod("GET").setMapHeader((TreeMap)headerMap)
                .setDepHeaderMap((TreeMap)depHeaderMap).setStrDomain(kcFeedUrl)
                .setStrReadTimeOut(readTimeOut).invokeCreateConnection();
        long endTime = System.currentTimeMillis();
        long kcReqTime = endTime - beginTime;

        if(logger.isDebugEnabled())
            logger.debug(String.format("Get events from %s took %d ms", kcEventFeedUri, kcReqTime));

        if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
            responseBody = (String)response.getBody();
        }
        return responseBody;
    }

    private List<String> getStoreListFromOmsr(YFSEnvironment env) throws Exception {
        List<String> storeList = new ArrayList<>();

        Document orgDoc = YFCDocument.createDocument(KohlsPOCConstant.ATTR_ORGANIZATION).getDocument();
        Element orgEle = orgDoc.getDocumentElement();
        orgEle.setAttribute("CatalogOrganizationCode", KohlsPOCConstant.DEFAULT);
        orgEle.setAttribute("ParentOrganizationCode", KohlsPOCConstant.KOHLS_RETAIL);
        orgEle.setAttribute("PrimaryEnterpriseKey", KohlsPOCConstant.KOHLS_RETAIL);
        Element corpPersonInfoEle = XMLUtil.createChild(orgEle, "CorporatePersonInfo");
        corpPersonInfoEle.setAttribute(KohlsPOCConstant.ATTR_COUNTRY, "US");
        Element billingPersonInfoEle = XMLUtil.createChild(orgEle, "BillingPersonInfo");
        Element shipNodePersonInfoEle = XMLUtil.createChild(orgEle, "ShipNodePersonInfo");
        Document getOrganizationListTemplate = XMLUtil.getDocument(
                "<OrganizationList>\n" +
                        "<Organization OrganizationCode=\"\">\n" +
                        "</Organization>\n" +
                        "</OrganizationList>");
        long beginTime = System.currentTimeMillis();
        Document getOrganizationListOutput =
                KOHLSBaseApi.invokeAPI(env, getOrganizationListTemplate,
                        KohlsConstant.API_GET_ORGANIZATION_LIST, orgDoc);
        long endTime = System.currentTimeMillis();
        long getOrganizationListTime = endTime - beginTime;

        if(logger.isDebugEnabled())
            logger.debug(String.format("getOrganizationList for KC feed took %d ms", getOrganizationListTime));

        ArrayList<Element> storeEleList = SCXmlUtil.getChildren(getOrganizationListOutput.getDocumentElement(),
                KohlsPOCConstant.ATTR_ORGANIZATION);

        for(Element storeEle : storeEleList) {
            String storeId = storeEle.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
            storeList.add(storeId);
        }

        return storeList;
    }

    private String padLeftZeros(String inputString) {
        if (inputString.length() >= 4) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        while (sb.length() < 4 - inputString.length()) {
            sb.append('0');
        }
        sb.append(inputString);

        return sb.toString();
    }
}
