package com.kohls.poc.data.kohlscash;

import java.util.List;

public class KohlsCashRedeemEvent {
    public String eventId;
    public String startDate;
    public String endDate;
    public String includeExcludeDepartment;
    public String toleranceEndDays;
    public List<String> departments;
    public List<String> stores;
    public boolean isCorpEvent;

    public String authorizationIndicator;
    public String discountType;
    public double discountAmount;
}
