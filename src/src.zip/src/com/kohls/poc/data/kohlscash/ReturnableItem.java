package com.kohls.poc.data.kohlscash;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

public class ReturnableItem {

	@XmlElement(name = "LineNo")
	private String lineNoStr;
	
	@XmlElement(name = "Dept")
	private String deptStr;
	
	@XmlElement(name = "NetPrice")
	private String netPriceStr;
	
	@XmlElement(name = "Return")
	private String isReturnStr;
	
	@XmlElement(name = "KohlsCashEligible")
	private String kohlsCashEligibleStr;
	
	public ReturnableItem() {
		
	}
	
	public ReturnableItem(long lineNo, long dept, double netPrice, boolean isReturn) {
		this.lineNoStr = KohlsCashFeedUtil.getInstance().convertLongToString(lineNo);
		this.deptStr = KohlsCashFeedUtil.getInstance().convertLongToString(dept);
		this.netPriceStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(netPrice);
		this.isReturnStr = KohlsCashFeedUtil.getInstance().convertBoolToString(isReturn);
		this.kohlsCashEligibleStr = "False";
	}
	
	public ReturnableItem(String lineNo, String dept, String netPrice, String isReturn) {
		this.lineNoStr = lineNo;
		this.deptStr = dept;
		this.netPriceStr = netPrice;
		this.isReturnStr = isReturn;
		this.kohlsCashEligibleStr = "False";
	}

	public long getLineNo() {
		return KohlsCashFeedUtil.getInstance().convertStringToLong(this.lineNoStr);
	}
	
	public String getLineNoStr() {
		return this.lineNoStr;
	}

	public long getDept() {
		return KohlsCashFeedUtil.getInstance().convertStringToLong(this.deptStr);
	}
	
	public String getDeptStr() {
		return this.deptStr;
	}

	public double getNetPrice() {
		return KohlsCashFeedUtil.getInstance().convertStringToDouble(this.netPriceStr);
	}
	
	public String getNetPriceStr() {
		return this.netPriceStr;
	}

	public boolean isReturn() {
		if(this.isReturnStr == null || this.isReturnStr.isEmpty()) {
			return false;
		}
		else {
			return this.isReturnStr.toLowerCase().equals("true") ? true : false;
		}
	}
	
	public void setIsReturn(boolean isReturn) {
		this.isReturnStr = KohlsCashFeedUtil.getInstance().convertBoolToString(isReturn);
	}
	
	public String getIsReturnStr() {
		return this.isReturnStr;
	}

	@XmlTransient
	public boolean isKohlsCashEligible() {
		if(this.kohlsCashEligibleStr == null || this.kohlsCashEligibleStr.isEmpty()) {
			return false;
		}
		else {
			return this.kohlsCashEligibleStr.toLowerCase().equals("true") ? true : false;
		}
	}
	
	@XmlTransient
	public String getIsKohlsCashEligibleStr() {
		return this.kohlsCashEligibleStr;
	}

	public void setKohlsCashEligible(boolean kohlsCashEligible) {
		this.kohlsCashEligibleStr = KohlsCashFeedUtil.getInstance().convertBoolToString(kohlsCashEligible);
	}
	
}
