package com.kohls.poc.data.kohlscash;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashActivationRequestMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashActivationRequestMsg.Item;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashActivationResponseMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationRequestMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg.DeactivationOptions;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg.MaximizeKohlsCash;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg.MaximizeRefund;
import com.kohls.poc.data.kohlscash.messages.GetActiveRKCEventsRequestMsg;
import com.kohls.poc.data.kohlscash.messages.GetActiveRKCEventsResponseMsg;
import com.kohls.poc.data.kohlscash.messages.KohlsCashActivationTransactionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.KohlsCashActivationTransactionResponseMsg;
import com.kohls.sbc.orgRules.KohlsPoCOrgRuleUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

// Responsible for making sure the proper files are loaded and Determining the amount of Kohl's Cash to activate

public class KohlsCashManager {

    // logger
    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsCashManager.class.getName());
    public static final String STORE_ID_QRY_TYPE = "StoreIdQryType";

    CouponManager couponManager;
    KohlsCashRewardsSystemMessenger messenger;
    YFSEnvironment env;
    
    public KohlsCashManager(YFSEnvironment env){
    	this.env = env;
    }
    
    public void loadEvents(String storeId) {
    	long beginTime = System.currentTimeMillis();
    	//Events in database have 4 digit store numbers
    	//Left pad storeId with 0's or events will not be fetched correctly
    	storeId = StringUtils.leftPad(storeId, 4, "0");
    	
    	Document docActivationEvents = null;
    	Document docRedemptionEvents = null;
		try{
			docActivationEvents = getActivationEventsFromDatabase(storeId);
		}
		catch(Exception getAllException){
			logger.error("Error invoking service for GetKohlsCashActivateEventList");
			throw new YFCException(getAllException);
		}
		
		try{
			docRedemptionEvents = getRedemptionEventsFromDatabase(storeId);
		}
		catch(Exception getAllException){
			logger.error("Error invoking service for GetKohlsCashRedemptionEventList");
			throw new YFCException(getAllException);
		}
		
		ArrayList<ActivateEventItem> activationEventItems = processDatabaseActivationEvents(docActivationEvents);
		ArrayList<RedeemEventItem> redemptionEventItems = processDatabaseRedemptionEvents(docRedemptionEvents);
    	
        this.couponManager = new CouponManager(activationEventItems, redemptionEventItems);
        long endTime = System.currentTimeMillis();
        long loadEventsTime = endTime - beginTime;
        logger.info("OMS KC load events took " + loadEventsTime + "ms");
    }
    
    protected Document getActivationEventsFromDatabase(String storeId) throws Exception {
    	Document docActivationEvents = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_ACTIVATION_EVENTS).getDocument();
    	Element docEle = docActivationEvents.getDocumentElement();
        Element eleComplexQuery = XMLUtil.createChild(docEle, KohlsPOCConstant.E_COMPLEX_QUERY);
        Element eleOr = XMLUtil.createChild(eleComplexQuery, KohlsXMLLiterals.E_OR);
        Element eleExpAll = XMLUtil.createChild(eleOr, KohlsXMLLiterals.E_EXP);
        eleExpAll.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.STOREID);
        eleExpAll.setAttribute(KohlsPOCConstant.A_VALUE, KohlsPOCConstant.ALL_ITEM_ID);
        eleExpAll.setAttribute(STORE_ID_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
        Element eleExpIndividual = XMLUtil.createChild(eleOr, KohlsXMLLiterals.E_EXP);
        eleExpIndividual.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.STOREID);
        eleExpIndividual.setAttribute(KohlsPOCConstant.A_VALUE, storeId);
        eleExpIndividual.setAttribute(STORE_ID_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
    	return KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_GET_KOHLS_CASH_ACTIVATION_LIST, docActivationEvents);
    }
    
    protected Document getRedemptionEventsFromDatabase(String storeId) throws Exception {
    	Document docRedemptionEvents = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENTS).getDocument();
    	Element docEle = docRedemptionEvents.getDocumentElement();
        Element eleComplexQuery = XMLUtil.createChild(docEle, KohlsPOCConstant.E_COMPLEX_QUERY);
        Element eleOr = XMLUtil.createChild(eleComplexQuery, KohlsXMLLiterals.E_OR);
        Element eleExpAll = XMLUtil.createChild(eleOr, KohlsXMLLiterals.E_EXP);
        eleExpAll.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.STOREID);
        eleExpAll.setAttribute(KohlsPOCConstant.A_VALUE, KohlsPOCConstant.ALL_ITEM_ID);
        eleExpAll.setAttribute(STORE_ID_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
        Element eleExpIndividual = XMLUtil.createChild(eleOr, KohlsXMLLiterals.E_EXP);
        eleExpIndividual.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.STOREID);
        eleExpIndividual.setAttribute(KohlsPOCConstant.A_VALUE, storeId);
        eleExpIndividual.setAttribute(STORE_ID_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
    	return KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_GET_KOHLS_CASH_REDEMPTION_LIST, docRedemptionEvents);
    }
    
    protected ArrayList<ActivateEventItem> processDatabaseActivationEvents(Document activationEvents){
    	ArrayList<ActivateEventItem> activationEventItems = new ArrayList<ActivateEventItem>();
    	
    	ArrayList<Element> existingEvents = SCXmlUtil.getChildren(activationEvents.getDocumentElement(),
				"KCActivationEvent");
    	
    	for(Element event : existingEvents){
			ActivateEventItem actvEvent = new ActivateEventItem();
			actvEvent.createItem(event);
			activationEventItems.add(actvEvent);
		}
    	
    	return activationEventItems;
    }
    
    protected ArrayList<RedeemEventItem> processDatabaseRedemptionEvents(Document redemptionEvents){
    	ArrayList<RedeemEventItem> redemptionEventItems = new ArrayList<RedeemEventItem>();
    	
    	ArrayList<Element> existingEvents = SCXmlUtil.getChildren(redemptionEvents.getDocumentElement(),
				"KCRedemptionEvent");
    	
    	for(Element event : existingEvents){
			RedeemEventItem redmEvent = new RedeemEventItem();
			redmEvent.createItem(event);
			redemptionEventItems.add(redmEvent);
		}
    	
    	return redemptionEventItems;
    }


    /// <summary>
    /// Originally part of the KohlsCashServiceApplication code and ported to this class
    /// Determines the kohls cash activation.
    /// </summary>
    /// <param name="inputXML">The input XML.</param>
    /// <param name="StoreActivationEvents">The store activation events.</param>
    /// <returns></returns>
    public Document determineKohlsCashActivation(Document kohlsCashRequestDoc)
    {
    	long beginTime = System.currentTimeMillis();
    	
    	try {
    		
	    	if (couponManager == null){
	            logger.error("Unable to determine Kohl's cash.  Coupon manager is null");
	            return null;
	        }
	
	    	JAXBContext requestContext = KohlsCashContextProvider.getInstance().getContext(DetermineKohlsCashActivationRequestMsg.class);
	        Unmarshaller reqUM = requestContext.createUnmarshaller();
	        DetermineKohlsCashActivationRequestMsg request = (DetermineKohlsCashActivationRequestMsg) reqUM.unmarshal(kohlsCashRequestDoc);
	        ArrayList<DetermineKohlsCashActivationResponseMsg> responses = new ArrayList<DetermineKohlsCashActivationResponseMsg>();
	
	        //Find out how much kohl's cash earned (if any) and set up the values in the out bound responses
	        calculateEarnedKohlsCashAmount(request.getBusinessDate(),
	                request.isApprovedKohlsChargeTendered(),
	                request.getItems(),
	                request.getStore(),
	                request.getReceiptID(),
	                request.isThresholdRequired(),
	                request,
	                responses);
        
            int count = responses.size();
            if(count > 0) {
                // Intentionally only take the data from the last Activation event found.
                // There is only supposed to be one Activation event available at a time, but
                // just in case there was more than one event just get the last one...
                DetermineKohlsCashActivationResponseMsg response = responses.get(count - 1);
                long endTime = System.currentTimeMillis();
                long actvTime = endTime - beginTime;
                logger.info("OMS KC determine activation took " + actvTime + "ms Activated:yes");
                return response.generateResponseXml();
            }
        } 
    	catch (JAXBException jaxe) {
    		logger.error("Unable to unmarshal DetermineKohlsCashActivationRequestMsg ", jaxe);
        }
    	catch(Exception e) {
    		logger.error("Unable to determine Kohls Cash activation ", e);
    	}

    	long endTime = System.currentTimeMillis();
        long actvTime = endTime - beginTime;
        logger.info("OMS KC determine activation took " + actvTime + "ms Activated:no");
    	
        return null;
    }

    private void calculateEarnedKohlsCashAmount(Date busDate,
                                                boolean kohlsChargeTendered,
                                                ArrayList<Item> itemList,
                                                String storeNum,
                                                String receiptID,
                                                boolean thresholdCheck,
                                                DetermineKohlsCashActivationRequestMsg request,
                                                ArrayList<DetermineKohlsCashActivationResponseMsg> responses)
    {

        int storeNumInt = KohlsCashFeedUtil.getInstance().convertStringToInt(storeNum);
        
        // Find any active events.
        ArrayList<ActivateEventItem> events = couponManager.getActiveActivateEvents(busDate, kohlsChargeTendered, storeNumInt);
        double kohlsCashEarned = 0;

        if (events == null || events.isEmpty()){
            DetermineKohlsCashActivationResponseMsg response = new DetermineKohlsCashActivationResponseMsg(request);
            response.setEventID("0");
            response.setEventName("NONE");
            responses.add(response);
            return;
        }

        final BigDecimal zero = BigDecimal.valueOf(0);
        for(ActivateEventItem event : events){

            if(KohlsCashFeedUtil.getInstance().convertStringToInt(event.getQualifyingAmount()) == 0){
                // Invalid amount.  Avoid divide by 0...
                continue;
            }
            BigDecimal qualifyingTotal = BigDecimal.valueOf(0);

            DetermineKohlsCashActivationResponseMsg response = new DetermineKohlsCashActivationResponseMsg(request);

            //Calculate Qualifying Total
            for(Item item : itemList){
                // Department 833 and 834 do not qualify for Kohl's Cash.
                if (item.getDept() == 833 || item.getDept() == 834)
                    continue;

                // Do any of the Departments from the incoming message match any
                // of the Event Departments.
                boolean deptNumberMatch = event.hasDept(item.getDept());
                boolean useItem;

                if (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getIncludeExcludeFlag()) == 0)
                    useItem = !deptNumberMatch;
                else
                    useItem = deptNumberMatch;

                if (useItem){
                    qualifyingTotal = qualifyingTotal.add(item.getNetPrice());
                }
            }// Qualifying total has been calculated

            // Determine the total Kohl's Cash.
            BigDecimal toleranceTotal = qualifyingTotal.add(new BigDecimal(KohlsCashFeedUtil.getInstance().convertStringToInt(event.getTolerance()) / 100) );
            BigDecimal floorTotal = BigDecimal.valueOf(Math.floor(toleranceTotal.doubleValue() / (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getQualifyingAmount()) / 100)));
            BigDecimal remainingTotal = BigDecimal.valueOf(toleranceTotal.doubleValue() % (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getQualifyingAmount()) / 100));

            if ( (floorTotal.compareTo(zero) > 0 && qualifyingTotal.compareTo(zero) > 0) || (thresholdCheck) ) {
                if (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getLimit()) >= 1){
                    kohlsCashEarned = Math.min( floorTotal.doubleValue(), KohlsCashFeedUtil.getInstance().convertStringToInt(event.getLimit()) ) * (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getCashValue()) / 100);
                }
                else {
                    kohlsCashEarned = floorTotal.doubleValue() * (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getCashValue()) / 100);
                }

                if ( (kohlsCashEarned > 0) || (thresholdCheck) )
                {
                    //Set up response message data
                    response.setEventName(event.getEventName());
                    response.setEventID(event.getEventID());
                    
                    String qualifyingTotalStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(qualifyingTotal.doubleValue());
                    response.setQualifyingPurchaseAmount(qualifyingTotalStr);
                    
                    String kohlsCashEarnedStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(kohlsCashEarned);
                    response.setKohlsCashAmount(kohlsCashEarnedStr);
                    //Set receipt line 1
                    if (!event.getReceiptMsgLines().isEmpty())
                    {
                        if (!event.getReceiptMsgLines().get(0).isEmpty())
                            response.setReceiptMessageLine1(event.getReceiptMsgLines().get(0));
                        else
                            response.setReceiptMessageLine1("");
                    }

                    //Set receipt line 2
                    if (!event.getReceiptMsgLines().isEmpty())
                    {
                        if (!event.getReceiptMsgLines().get(1).isEmpty())
                            response.setReceiptMessageLine2(event.getReceiptMsgLines().get(1));
                        else
                            response.setReceiptMessageLine2("");
                    }

                    if (kohlsCashEarned > 0)
                        response.setValidationCode(generateKohlsCashValidationCode(kohlsCashEarned, receiptID));

                    //Determine Threshold to earn another KC $$$
                    BigDecimal limit = BigDecimal.valueOf(KohlsCashFeedUtil.getInstance().convertStringToInt(event.getLimit()));
                    if ( thresholdCheck && (floorTotal.compareTo(limit) < 0 ) )
                    {
                        //Amount of eligible sale $$ needed to earn next Kohl's Cash amount
                    	double threshold = (KohlsCashFeedUtil.getInstance().convertStringToInt(event.getQualifyingAmount()) / 100) - remainingTotal.doubleValue();
                    	String thresholdStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(threshold);
                    	response.setThreshold(thresholdStr);

                        //Next Kohl's Cash $$ amount to be earned
                    	double nextKohlsCashEarned = KohlsCashFeedUtil.getInstance().convertStringToInt(event.getCashValue()) / 100;
                    	String nextKohlsCashEarnedStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(nextKohlsCashEarned);
                        response.setNextKohlsCashEarned(nextKohlsCashEarnedStr);
                    }
                }
                else
                {
                    // didn't earn any kohl's cash, return no event qualified for
                    response.setEventID("0");
                    response.setEventName(KohlsPOCConstant.EVENT_NAME_NONE);
                }
            }
            else{
                // didn't earn any kohl's cash, return no event qualified for
                response.setEventID("0");
                response.setEventName(KohlsPOCConstant.EVENT_NAME_NONE);
            }
            responses.add(response);
        }
    }

    private String generateKohlsCashValidationCode(double kohlsChargeAmount, String receiptID)
    {
        int dollarValue = (int)Math.ceil(kohlsChargeAmount);

        String lastFour = "0000";
        if (receiptID.length() >= 4)
            lastFour = receiptID.substring(receiptID.length() - 4, receiptID.length());

        String validationCode = Integer.toString(dollarValue) + lastFour;
        int checkDigit = KohlsCashFeedUtil.getInstance().CheckDigitCreate(validationCode);
        validationCode += KohlsCashFeedUtil.getInstance().convertIntToString(checkDigit);

        return validationCode;
    }
    
    public Document kohlsCashInquiry(Document kohlsCashRequestDoc) {
    	try {
    		
    		long beginTime = System.currentTimeMillis();
    		int rkcExpirationGracePeriod = 10;
    		long endTime;
    		long inquiryTime;
    		
    		//Parse out request, create basic response
			JAXBContext requestContext = KohlsCashContextProvider.getInstance().getContext(CouponInquiryRequestMsg.class);
	        Unmarshaller reqUM = requestContext.createUnmarshaller();
	        CouponInquiryRequestMsg request = (CouponInquiryRequestMsg) reqUM.unmarshal(kohlsCashRequestDoc);
    		CouponInquiryResponseMsg response = new CouponInquiryResponseMsg(request);
    		
    		//Check if the event exists in the redemption table
    		RedeemEventItem foundEvent = findRedemptionEvent(request.getCouponNumber(), request.getStore());
    		
    		if(foundEvent == null) {
    			response.setCouponType(KohlsCouponType.NONE);
    		    endTime = System.currentTimeMillis();
				inquiryTime = endTime - beginTime;
				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
    			return response.generateResponseXml();
    		}
    		
    		//Check the event start date
    		if(request.getBusinessDate().before(foundEvent.getDBStartDate())) {
    			if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("P")) {
    				//Legacy % discount - Event not started yet
    				response.setCouponType(KohlsCouponType.LEGACY);
    				response.setCouponStatus(KohlsCouponStatus.PREREDEMPTION);
    				response.setErrorMessage(KohlsPOCConstant.PRE_REDEMP_ERROR);
    				response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
    				response.setLegacyPercent(foundEvent.getDiscountAmountString());
    				response.setDepartments(foundEvent.getDepartments());
    				
    			    endTime = System.currentTimeMillis();
    				inquiryTime = endTime - beginTime;
    				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
    				return response.generateResponseXml();
    			}
    			
    			if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("D") &&
    					foundEvent.getDiscountAmount() > 0) {
    				//Legacy $ discount - Event Not Started
    				response.setCouponType(KohlsCouponType.LEGACY);
    				response.setCouponStatus(KohlsCouponStatus.PREREDEMPTION);
    				response.setErrorMessage(KohlsPOCConstant.PRE_REDEMP_ERROR);
    				response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
    				String legacyDollarString = KohlsCashFeedUtil.getInstance().convertDoubleToWholeDollar(foundEvent.getDiscountAmount() / 100);
    				response.setLegacyDollar(legacyDollarString);
    				response.setDepartments(foundEvent.getDepartments());
    				
    				endTime = System.currentTimeMillis();
    				inquiryTime = endTime - beginTime;
    				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
    				return response.generateResponseXml();
    			}
    		}
    		
    		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			Date max = sdf.parse("09099999");
    		
    		//Check the event end date
    		if(request.getBusinessDate().after(foundEvent.getDBEndDate())) {
    			if(foundEvent.getDBEndDate().compareTo(max) != 0 && request.getBusinessDate().after(foundEvent.getDBEndDate())) {
                    if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("P")) {
                        //Legacy % discount - Event Expired
                    	response.setCouponType(KohlsCouponType.LEGACY);
                    	response.setCouponStatus(KohlsCouponStatus.POSTREDEMPTION);
                    	response.setErrorMessage(KohlsPOCConstant.POST_REDEMP_ERROR);
                    	response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
                    	response.setLegacyPercent(foundEvent.getDiscountAmountString());
                    	response.setDepartments(foundEvent.getDepartments());

                    	endTime = System.currentTimeMillis();
        				inquiryTime = endTime - beginTime;
        				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                        return response.generateResponseXml();
                    }
                    
                    if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("D") && foundEvent.getDiscountAmount() > 0) {
                        //Legacy $ discount - Event Expired
                    	response.setCouponType(KohlsCouponType.LEGACY);
                    	response.setCouponStatus(KohlsCouponStatus.POSTREDEMPTION);
                    	response.setErrorMessage(KohlsPOCConstant.POST_REDEMP_ERROR);
                    	response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
                    	String legacyDollarString = KohlsCashFeedUtil.getInstance().convertDoubleToWholeDollar(foundEvent.getDiscountAmount() / 100);
                    	response.setLegacyDollar(legacyDollarString);
                    	response.setDepartments(foundEvent.getDepartments());

                    	endTime = System.currentTimeMillis();
        				inquiryTime = endTime - beginTime;
        				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                    	return response.generateResponseXml();
                    }
                }
    		}
    		
    		//Check Legacy Percent Coupon
            if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("P")) {
                response.setCouponType(KohlsCouponType.LEGACY);
                response.setCouponStatus(KohlsCouponStatus.ACTIVE);
                response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
                response.setLegacyPercent(foundEvent.getDiscountAmountString());
                response.setDepartments(foundEvent.getDepartments());

                endTime = System.currentTimeMillis();
				inquiryTime = endTime - beginTime;
				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                return response.generateResponseXml();   
            }
            
            //Check Legacy Dollar Coupon
            if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("D") && foundEvent.getDiscountAmount() > 0) {
            	response.setCouponType(KohlsCouponType.LEGACY);
            	response.setCouponStatus(KohlsCouponStatus.ACTIVE);
            	response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
            	String legacyDollarString = KohlsCashFeedUtil.getInstance().convertDoubleToWholeDollar(foundEvent.getDiscountAmount() / 100);
            	response.setLegacyDollar(legacyDollarString);
            	response.setDepartments(foundEvent.getDepartments());

            	endTime = System.currentTimeMillis();
				inquiryTime = endTime - beginTime;
				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
            	return response.generateResponseXml();
            }
            
            //Check Kohls Cash (No Authoriation)
            if(foundEvent.getAuthorizationIndicator().equals("0") && foundEvent.getDiscountType().equals("D") && foundEvent.getDiscountAmount() == 0) {
            	response.setCouponType(KohlsCouponType.KOHLSCASHNOAUTH);
            	response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
                
                //NOTE: These should be zero as set up in redeem.txt (forcing them to use validation code to obtain amount)
            	String dollarString = KohlsCashFeedUtil.getInstance().convertDoubleToWholeDollar(foundEvent.getDiscountAmount() / 100);
            	response.setCouponValue(dollarString);
            	response.setCouponBalance(dollarString);
                
            	response.setDepartments(foundEvent.getDepartments());

                if(request.getBusinessDate().before(foundEvent.getDBStartDate())) {
                	response.setCouponStatus(KohlsCouponStatus.PREREDEMPTION);
                	response.setErrorMessage(KohlsPOCConstant.PRE_REDEMP_ERROR);
                }
                else if(foundEvent.getDBEndDate().compareTo(max) != 0 && request.getBusinessDate().after(foundEvent.getDBEndDate())) {
                	response.setCouponStatus(KohlsCouponStatus.POSTREDEMPTION);
                	response.setErrorMessage(KohlsPOCConstant.POST_REDEMP_ERROR);
                }
                else {
                	response.setCouponStatus(KohlsCouponStatus.ACTIVE); 
                }

                endTime = System.currentTimeMillis();
				inquiryTime = endTime - beginTime;
				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                return response.generateResponseXml();
            }
            
            //Check Kohls Cash (Authorization)
            if(foundEvent.getAuthorizationIndicator().equals("1")) {
            	response.setCouponType(KohlsCouponType.KOHLSCASHAUTH);
                response.setIncludeExcludeFlag(foundEvent.getIncludeExcludeFlag());
                response.setDepartments(foundEvent.getDepartments());

                //Pre-redemption, don't do inquiry if not an inquiry transaction
                if(request.getBusinessDate().before(foundEvent.getDBStartDate())) {
                    response.setCouponStatus(KohlsCouponStatus.PREREDEMPTION);

                    if(!request.getInquiryTransaction()) {
                        response.setErrorMessage(KohlsPOCConstant.PRE_REDEMP_ERROR);
                        endTime = System.currentTimeMillis();
        				inquiryTime = endTime - beginTime;
        				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                        return response.generateResponseXml();
                    }
                }
                // for active AND post-redemption we will still do the inquiry, for post-redemption to give the associate the option to apply manual tld
                else if(foundEvent.getDBEndDate().compareTo(max) != 0 && request.getBusinessDate().after(foundEvent.getDBEndDate())) {
                    response.setCouponStatus(KohlsCouponStatus.POSTREDEMPTION);
                    
                    if(!request.getInquiryTransaction()) {
                        response.setErrorMessage(KohlsPOCConstant.POST_REDEMP_ERROR);
                    }
                }
                else {
                    response.setCouponStatus(KohlsCouponStatus.ACTIVE);
                }

                //DKC - 2016 Tokenization project, if OMS/Gravity could not detokenize and we are going to send KC System Inquiry, DON'T! and default to offline response
                if(!YFCObject.isNull(request.getTokenizedCoupon()) && request.getTokenizedCoupon()) {
                    if(response.getCouponStatus() == KohlsCouponStatus.ACTIVE || request.getInquiryTransaction())
                        response.setErrorMessage(KohlsPOCConstant.F9_OFFLINE_ERROR);
                    
                    response.setAuthResponseCode(KohlsCashResponseCode.Offline.getValue());
                    response.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
                    endTime = System.currentTimeMillis();
    				inquiryTime = endTime - beginTime;
    				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                    return response.generateResponseXml();
                }

                //Send Message to Rewards System
                if(messenger == null) {
                	messenger = new KohlsCashRewardsSystemMessengerImpl();
                }
                messenger.sendKohlsCashInquiryAJBMessage(request, response);

                //Set Error Message Based on Rewards System Response if required -> NOTE: setting only if redemption status is ACTIVE
                if((response.getCouponStatus() == KohlsCouponStatus.ACTIVE) || (request.getInquiryTransaction())) {
                    // RKC - dynamic expiration - Fix for PST-1710
                    // We need to validate the RKC expiration date before
                    // hitting other if conditions.
                    if(!YFCObject.isNull(response.getExpirationDateString())) {
                        // OMSr doesn't know anything about grace period so adding the grace period
                        // to expiration date came from DKC
                    	String dt = response.getExpirationDateString();  // Start date
                    	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                    	Calendar c = Calendar.getInstance();
                    	c.setTime(df.parse(dt));
                    	c.add(Calendar.DATE, rkcExpirationGracePeriod);  // number of days to add
                    	dt = df.format(c.getTime());  // dt is now the new date
                        response.setExpirationDate(dt);

                        if(request.getBusinessDate().after(response.getExpirationDate())) {
                            response.setCouponStatus(KohlsCouponStatus.POSTREDEMPTION);

                            if(!request.getInquiryTransaction()) {
                                response.setErrorMessage(KohlsPOCConstant.POST_REDEMP_ERROR);
                            }
                        }
                    }
                    //F0NoBalanceError
                    else if(response.getAuthResponseCode().equals(KohlsCashResponseCode.Approved.getValue())) {
                        if(!request.getInquiryTransaction()) {
                            if(response.getCouponBalance() <= 0) {
                                response.setErrorMessage(KohlsPOCConstant.F0_NO_BALANCE_ERROR);
                            }
                        }
                    }
                    //F8DuplicateError
                    else if(response.getAuthResponseCode().equals(KohlsCashResponseCode.Referral.getValue())) {
                        response.setErrorMessage(KohlsPOCConstant.F8_DUPLICATE_ERROR);
                    }
                    //F7700002DeclineError
                    //F7700003DeclineError
                    //F7700004DeclineError
                    else if(response.getAuthResponseCode().equals(KohlsCashResponseCode.HardDecline.getValue())) {
                        if(response.getAuthApprovalNum().equals(KohlsPOCConstant.HARD_DECLINE_700002)) {
                            if(request.getInquiryTransaction()) {
                                response.setErrorMessage(KohlsPOCConstant.F7_700002_INQ_TRANS_DECLINE_ERROR);
                            }
                            else {
                                response.setErrorMessage(KohlsPOCConstant.F7_700002_DECLINE_ERROR);
                            }
                        }
                        else if(response.getAuthApprovalNum().equals(KohlsPOCConstant.HARD_DECLINE_700003)) {
                            if(request.getInquiryTransaction()) {
                                response.setErrorMessage(KohlsPOCConstant.F7_700003_INQ_TRANS_DECLINE_ERROR);
                            }
                            else {
                                response.setErrorMessage(KohlsPOCConstant.F7_700003_DECLINE_ERROR);
                            }
                        }
                        else if(response.getAuthApprovalNum().equals(KohlsPOCConstant.HARD_DECLINE_700004))
                        {
                            if(request.getInquiryTransaction()) {
                                response.setErrorMessage(KohlsPOCConstant.F7_700004_INQ_TRANS_DECLINE_ERROR);
                            }
                            else {
                                response.setErrorMessage(KohlsPOCConstant.F7_700004_DECLINE_ERROR);
                            }
                        }
                    }                        
                    else {
                    	//edit error and offline and anything else if possible
                        response.setErrorMessage(KohlsPOCConstant.F9_OFFLINE_ERROR);
                    }
                }
                 
                endTime = System.currentTimeMillis();
				inquiryTime = endTime - beginTime;
				logger.info("OMS KC inquiry took " + inquiryTime + "ms");
                return response.generateResponseXml();
            }
    	}
    	catch(JAXBException jaxe) {
    		logger.error("Unable to unmarshal CouponInquiryRequestMsg ", jaxe);
    	}
    	catch(Exception ex) {
    		logger.error("Unable to perform Kohls Cash inquiry ", ex);
    	}
    	
    	return null;
    }
    
    private RedeemEventItem findRedemptionEvent(String couponNumber, String store) {
    	ArrayList<RedeemEventItem> storeRedeemEvents = this.couponManager.getStoreRedeemEvents(store);
    	
    	if(!YFCObject.isVoid(couponNumber) && couponNumber.length() >= 5) {
    		String eventId = couponNumber.substring(0, 5);
    		
    		for(RedeemEventItem evt : storeRedeemEvents) {
    			if(evt.getEventID().equals(eventId)){
    				return evt;
    			}
    		}
    	}
    	
    	return null;
    }
    
    public Document kohlsCashRedemption(Document kohlsCashRequestDoc) {
    	
    	long beginTime = System.currentTimeMillis();
    	try {
    		JAXBContext requestContext = KohlsCashContextProvider.getInstance().getContext(CouponRedemptionRequestMsg.class);
	        Unmarshaller reqUM = requestContext.createUnmarshaller();
	        CouponRedemptionRequestMsg inMsg = (CouponRedemptionRequestMsg) reqUM.unmarshal(kohlsCashRequestDoc);
    		CouponRedemptionResponseMsg outMsg = new CouponRedemptionResponseMsg(inMsg);
    		
    		if(messenger == null) {
            	messenger = new KohlsCashRewardsSystemMessengerImpl();
            }
    		if(inMsg.getMessageType() == KohlsCouponMessageType.VOIDTENDER) {
    			outMsg = messenger.sendKohlsCashVoidTransactionAJBMessage(inMsg, outMsg);
    		}
    		else {
    			outMsg = messenger.sendKohlsCashRedemptionAJBMessage(inMsg, outMsg);
    		}
    		
    		long endTime = System.currentTimeMillis();
    		long redmTime = endTime - beginTime;
    		logger.info("OMS KC redemption took " + redmTime + "ms Redeemed:yes");
    		
    		return outMsg.generateResponseXml();
    	}
    	catch(JAXBException jaxe) {
    		logger.error("Unable to unmarshal CouponRedemptionResponseMsg ", jaxe);
    	}
    	catch(Exception e) {
    		logger.error("Unable to perform Kohls Cash redemption ", e);
    	}
    	
    	long endTime = System.currentTimeMillis();
		long redmTime = endTime - beginTime;
		logger.info("OMS KC redemption took " + redmTime + "ms Redeemed:no");
    	
    	return null;
    }

	public Document kohlsCashActivationTransaction(Document reqDoc) {

        long beginTime = System.currentTimeMillis();
        long endTime, activationTranTime;
        try {

			String eventNotInRedeemFileError = "Kohl's Cash cannot be activated. Event does not exist.";
			String notKohlsCashError = "Kohl's Cash cannot be activated. Invalid Kohl's Cash event.";
			String eventNotInActivateFileError = "Kohl's Cash cannot be activated. Event does not exist.";
			String eventNotInActivationPeriod = "Kohl's Cash cannot be activated. Event is outside of activation period.";
			
			JAXBContext requestContext = KohlsCashContextProvider.getInstance().getContext(KohlsCashActivationTransactionRequestMsg.class);
	        Unmarshaller reqUM = requestContext.createUnmarshaller();
	        KohlsCashActivationTransactionRequestMsg inMsg = (KohlsCashActivationTransactionRequestMsg) reqUM.unmarshal(reqDoc);
			KohlsCashActivationTransactionResponseMsg outMsg = new KohlsCashActivationTransactionResponseMsg(inMsg);
			
			//Make sure the event is in redeem database
			RedeemEventItem foundEvent = findRedemptionEvent(inMsg.getKohlsCashId(), inMsg.getStore());
			
			if(foundEvent == null) {
				outMsg.setErrorMessageToDisplay(eventNotInRedeemFileError);
				outMsg.setCouponType(KohlsCouponType.NONE);
				
				endTime = System.currentTimeMillis();
				activationTranTime = endTime - beginTime;
				logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:no");
				return outMsg.generateResponseXml();
			}
			
			//Check that coupon is Kohl's Cash (not a legacy coupon)
			if(!isThisKohlsCash(foundEvent)) {
				outMsg.setCouponType(KohlsCouponType.LEGACY);
				outMsg.setErrorMessageToDisplay(notKohlsCashError);
				
				endTime = System.currentTimeMillis();
				activationTranTime = endTime - beginTime;
				logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:no");
				return outMsg.generateResponseXml();
			}
			
			//Make sure event is in activate database
			ActivateEventItem foundActivationEvent = findActivationEvent(inMsg.getKohlsCashId(), inMsg.getStore());
			
			if(foundActivationEvent == null) {
				outMsg.setErrorMessageToDisplay(eventNotInActivateFileError);
				outMsg.setCouponType(KohlsCouponType.NONE);
				
				endTime = System.currentTimeMillis();
				activationTranTime = endTime - beginTime;
				logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:no");
				return outMsg.generateResponseXml();
			}
			
			//DKC 2016 - if this is an RKC event, return NONE since we are not allowing RKC's to be activated in POST-SALE
			int qualifyingTenderInt = KohlsCashFeedUtil.getInstance().convertStringToInt(foundActivationEvent.getQualifyingTender());
			if(qualifyingTenderInt >= 2) {
				outMsg.setCouponType(KohlsCouponType.NONE);
				outMsg.setErrorMessageToDisplay(eventNotInActivateFileError);
				
				endTime = System.currentTimeMillis();
				activationTranTime = endTime - beginTime;
				logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:no");
				return outMsg.generateResponseXml();
			}
			
			double cashValue = KohlsCashFeedUtil.getInstance().convertStringToInt(foundActivationEvent.getCashValue()) / 100;
			String cashValueStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(cashValue);
			
			outMsg.setEventId(foundActivationEvent.getEventID());
			outMsg.setCashValue(cashValueStr);
			outMsg.setEventName(foundActivationEvent.getEventName());
			
			//Set receipt line 1
			if(foundActivationEvent.getReceiptMsgLines().size() > 0) {
				if(foundActivationEvent.getReceiptMsgLines().get(0).length() > 0) {
					outMsg.setReceiptMessageLine1(foundActivationEvent.getReceiptMsgLines().get(0));
				}
				else {
					outMsg.setReceiptMessageLine1(null);
				}
			}
			
			//Set receipt line 2
			if(foundActivationEvent.getReceiptMsgLines().size() > 1) {
				if(foundActivationEvent.getReceiptMsgLines().get(1).length() > 0) {
					outMsg.setReceiptMessageLine2(foundActivationEvent.getReceiptMsgLines().get(1));
				}
				else {
					outMsg.setReceiptMessageLine2(null);
				}
			}
			
			outMsg.setActivationStartDate(foundActivationEvent.getStartDateString());
			outMsg.setActivationEndDate(foundActivationEvent.getEndDateString());
			
			//If not in activation period, set error message and return the response
			if(inMsg.getBusinessDate().before(foundActivationEvent.getDBStartDate()) || inMsg.getBusinessDate().after(foundActivationEvent.getDBEndDate())) {
				outMsg.setErrorMessageToDisplay(eventNotInActivationPeriod);
				
				endTime = System.currentTimeMillis();
				activationTranTime = endTime - beginTime;
				logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:no");
				return outMsg.generateResponseXml();
			}
			
			double cashValueDouble = KohlsCashFeedUtil.getInstance().convertStringToDouble(outMsg.getCashValue());
			outMsg.setValidationCode(generateKohlsCashValidationCode(cashValueDouble, inMsg.getReceiptId()));
			
			endTime = System.currentTimeMillis();
			activationTranTime = endTime - beginTime;
			logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:yes");
			return outMsg.generateResponseXml();
		}
		catch(JAXBException jaxe) {
			logger.error("Unable to unmarshal KohlsCashActivationTransactionRequestMsg ", jaxe);
		}
		catch(Exception e) {
			logger.error("Unable to determine Kohls Cash activation transaction ", e);
		}

        endTime = System.currentTimeMillis();
        activationTranTime = endTime - beginTime;
        logger.info("OMS KC activation transaction took " + activationTranTime + "ms Activated:no");
		
		return null;
	}

	private boolean isThisKohlsCash(RedeemEventItem redeemEvent)
    {
        return (redeemEvent.getAuthorizationIndicator().equals("0") && redeemEvent.getDiscountType().equals("D") && 
        		redeemEvent.getDiscountAmount() == 0) || (redeemEvent.getAuthorizationIndicator().equals("1"));
    }
	
	private ActivateEventItem findActivationEvent(String couponNumber, String store) {
    	ArrayList<ActivateEventItem> storeActivateEvents = this.couponManager.getStoreActivateEvents(store);
    	
    	if(!YFCObject.isVoid(couponNumber) && couponNumber.length() >= 5) {
    		String eventId = couponNumber.substring(0, 5);
    		
    		for(ActivateEventItem evt : storeActivateEvents) {
    			if(evt.getEventID().equals(eventId)){
    				return evt;
    			}
    		}
    	}
    	
    	return null;
    }
	
	public Document determineKohlsCashDeactivation(Document deactivationDocument) {
		
		long beginTime = System.currentTimeMillis();
		try {
			
			JAXBContext requestContext = KohlsCashContextProvider.getInstance().getContext(DetermineKohlsCashDeactivationRequestMsg.class);
	        Unmarshaller reqUM = requestContext.createUnmarshaller();
	        DetermineKohlsCashDeactivationRequestMsg inMsg = (DetermineKohlsCashDeactivationRequestMsg) reqUM.unmarshal(deactivationDocument);
			DetermineKohlsCashDeactivationResponseMsg outMsg = new DetermineKohlsCashDeactivationResponseMsg(inMsg);
			
			outMsg = calculateUnearnedKohlsCashAmount(inMsg, outMsg);
			
			long endTime = System.currentTimeMillis();
			long deactTime = endTime - beginTime;
			logger.info("OMS KC deactivation took " + deactTime + "ms Deactivated:yes");
			return outMsg.generateResponseXml();
		}
		catch(JAXBException jaxe) {
			//SCXmlUtil.getString(deactivationDocument);
			logger.error("Unable to unmarshal DetermineKohlsCashDeactivationResponseMsg ", jaxe);
		}
		catch(Exception e) {
			logger.error("Unable to determine Kohls Cash deactivation ", e);
		}
		
		long endTime = System.currentTimeMillis();
		long deactTime = endTime - beginTime;
		logger.info("OMS KC deactivation took " + deactTime + "ms Deactivated:no");
		
		return null;
	}

	private DetermineKohlsCashDeactivationResponseMsg calculateUnearnedKohlsCashAmount(
			DetermineKohlsCashDeactivationRequestMsg inMsg, DetermineKohlsCashDeactivationResponseMsg outMsg) {
		try {
			ActivateEventItem activateEvent = findActivationEvent(inMsg.getKohlsCashId(), inMsg.getStore());
			RedeemEventItem redeemEvent = findRedemptionEvent(inMsg.getKohlsCashId(), inMsg.getStore());
			
			//If can't find the events, we are done, return NONE for redeem status to indicate event not found to caller
            //DKC 2016 - If the Event ID of the KC # passed in the request is actually an RKC, we are going to block this Event as a safe guard (RKC should never be deactivated)
            if(activateEvent == null || redeemEvent == null || KohlsCashFeedUtil.getInstance().convertStringToInt(activateEvent.getQualifyingTender()) >= 2) {
            	outMsg.setCouponStatus(KohlsCouponStatus.NONE);
            }
            else {
            	//Make sure we are dealing with Kohl's Cash
            	if(isThisKohlsCash(redeemEvent)) {
            		
            		//Populate the response object
            		outMsg.setEligibilityDeduction(calculateEligibleAmount(inMsg.getReturnableItemList(), activateEvent, true));
            		
            		//Set the coupon status
            		outMsg.setCouponStatus(determineCouponStatus(redeemEvent, inMsg.getBusinessDate()));
            		
            		//Set the Balance to return (will be echo of request Balance if passed in, or the result of an Inquiry if not)
            		outMsg.setKohlsCashBalance(inMsg.getKcStatus().getKohlsCashBalance());
            		
            		//Determine if anything was unearned
            		double qualifyingTotal = inMsg.getKcStatus().getEligibleAmt() - outMsg.getEligibilityDeduction();
            		
            		//Safety check in case more than the original amount is returned
            		if(qualifyingTotal < 0) {
            			qualifyingTotal = 0.0;
            		}
            		
            		//Calculate new earned amount, subtract from original earned amount to see if we unearned anything
            		double unearnedValue = inMsg.getKcStatus().getEarnedAmt() - calculateEarnedAmount(activateEvent, qualifyingTotal);
            		outMsg.setUnearnedValue(unearnedValue);
            		
            		//Check for an unearned amount
            		if(outMsg.getUnearnedValue() > 0) {
            			outMsg.setDeactivationOptions(setDeactivationOptions(outMsg, inMsg.getKcStatus()));
            		}
            	}
            	else {
            		outMsg.setCouponStatus(KohlsCouponStatus.NONE);
            	}
            }
            
            return outMsg;
		}
		catch(Exception e) {
			logger.error("Unable to calculate unearned Kohls Cash amount ", e);
		}
		
		return null;
	}

	private DeactivationOptions setDeactivationOptions(DetermineKohlsCashDeactivationResponseMsg outMsg,
			KohlsCashStatus kcStatus) {
		try{
			//Figure out buckets for Maximize Refund and Maximize Kohl's Cash options
			double kohlsCashDeduction;
			double refundDeduction;
			
			if(outMsg.getUnearnedValue() > kcStatus.getKohlsCashBalance()) {
				kohlsCashDeduction = kcStatus.getKohlsCashBalance();
				refundDeduction = outMsg.getUnearnedValue() - kohlsCashDeduction;
				
				if(outMsg.getEligibilityDeduction() <= refundDeduction) {
					//We can't take return to 0 or negative
					refundDeduction = 0.0;
				}
			}
			else {
				//Deactivation of everything
				kohlsCashDeduction = outMsg.getUnearnedValue();
				refundDeduction = 0.0;
			}
			
			DeactivationOptions deactOpts = new DeactivationOptions();
			MaximizeRefund mr = new MaximizeRefund(kohlsCashDeduction, refundDeduction);
			deactOpts.setMaxRefund(mr);
			
			//Maximize Kohl's Cash only active during redemption period
			if(outMsg.getCouponStatus() == KohlsCouponStatus.ACTIVE) {
				if(outMsg.getEligibilityDeduction() > outMsg.getUnearnedValue() && kohlsCashDeduction > 0) {
					//Maximize Kohl's Cash, don't deactivate
					kohlsCashDeduction = 0.0;
					refundDeduction = outMsg.getUnearnedValue();
					
					MaximizeKohlsCash mkc = new MaximizeKohlsCash(kohlsCashDeduction, refundDeduction);
					deactOpts.setMaxKohlsCash(mkc);
				}
			}
			
			return deactOpts;
		}
		catch(Exception e) {
			logger.error("Unable to set deactivation options for Kohls Cash ", e);
		}
		
		return null;
	}

	private double calculateEarnedAmount(ActivateEventItem activateEvent, double qualifyingTotal) {
		//add in tolerance
		double toleranceTotal = qualifyingTotal + (activateEvent.getToleranceInt() / 100);
		
		double floorTotal = Math.floor(toleranceTotal / (activateEvent.getQualifyingAmountInt() / 100));
		double newActivatedValue = 0.0;
		
		if(floorTotal > 0 && qualifyingTotal > 0) {
			if(activateEvent.getLimitInt() >= 1) {
				newActivatedValue = Math.min(floorTotal, activateEvent.getLimitInt()) * (activateEvent.getCashValueInt() / 100);
			}
			else {
				newActivatedValue = floorTotal * (activateEvent.getCashValueInt() / 100);
			}
		}
		
		return newActivatedValue;
	}

	private KohlsCouponStatus determineCouponStatus(RedeemEventItem redeemEvent, Date businessDate) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			Date max = sdf.parse("09099999");
			
			if(businessDate.before(redeemEvent.getDBStartDate())) {
				return KohlsCouponStatus.PREREDEMPTION;
			}
			else if(redeemEvent.getDBEndDate() != max && businessDate.after(redeemEvent.getDBEndDate())) {
				return KohlsCouponStatus.POSTREDEMPTION;
			}
			else {
				return KohlsCouponStatus.ACTIVE;
			}
		}
		catch(ParseException pe) {
			logger.error("Unable to parse business date for coupon status ", pe);
		}
		catch(Exception e) {
			logger.error("Unable to determine coupon status ", e);
		}
		
		return KohlsCouponStatus.NONE;
	}

	private double calculateEligibleAmount(ArrayList<ReturnableItem> returnableItemList,
			ActivateEventItem activateEvent, boolean eligibilityDeduction) {
		//go through each return item to determine if is kohl's cash eligible, and add up the total return amount (will be eligibility deduction)
        double eligibleAmount = 0.0;

        for(ReturnableItem item : returnableItemList) {
            // Department 833 and 834 do not qualify for Kohl's Cash.
            if(item.getDept() == 833 || item.getDept() == 834) {
                continue;
            }

            boolean deptNumberFound = false;

            for(String dept : activateEvent.getDepartments()) {
                if(dept != null && !dept.isEmpty()) {
                	dept = dept.trim();
                    // Department Check
                    if(item.getDept() == KohlsCashFeedUtil.getInstance().convertStringToLong(dept)) {
                        deptNumberFound = true;
                        break;
                    }
                }
            }

            boolean useItem;

            if(activateEvent.getIncludeExcludeFlag().equals("0")) {
                useItem = !deptNumberFound;
            }
            else {
                useItem = deptNumberFound;
            }
            
            if(useItem) {
                if(eligibilityDeduction) {
                    if(item.isReturn()) {
                        eligibleAmount += item.getNetPrice();
                    }
                }
                else {
                    eligibleAmount += item.getNetPrice();
                }

                item.setKohlsCashEligible(true);
            }
        }
        return eligibleAmount;
	}
	
	public Document getActiveRKCEvents(Document requestDocument) {
		
		try {
			long beginTime = System.currentTimeMillis();
			JAXBContext requestContext = KohlsCashContextProvider.getInstance().getContext(GetActiveRKCEventsRequestMsg.class);
	        Unmarshaller reqUM = requestContext.createUnmarshaller();
	        GetActiveRKCEventsRequestMsg inMsg = (GetActiveRKCEventsRequestMsg) reqUM.unmarshal(requestDocument);
	        GetActiveRKCEventsResponseMsg outMsg = new GetActiveRKCEventsResponseMsg(inMsg);
			
	        ArrayList<ActivateEventItem> activeEvents = null;
	        
			if(inMsg.getKohlsCashId() != null && !inMsg.getKohlsCashId().isEmpty()) {
				ActivateEventItem activateEvent = findActivationEvent(inMsg.getKohlsCashId(), inMsg.getStore());
				
				if(activateEvent != null) {
					if(activateEvent.getQualifyingTenderInt() >= 2) {
						activeEvents = new ArrayList<ActivateEventItem>();
						activeEvents.add(activateEvent);
					}
				}
			}
			else {
				activeEvents = couponManager.getActiveRKCEvents(inMsg.getStore(), inMsg.getBusinessDate());
			}
			
			outMsg.setActiveRKCEventsList(activeEvents);
			
			long endTime = System.currentTimeMillis();
			long rkcTime = endTime - beginTime;
			logger.info("OMS KC getActiveRKC took " + rkcTime + "ms");
			return outMsg.generateResponseXml();
		}
		catch(JAXBException jaxe) {
			logger.error("Unable to unmarshal GetActiveRKCEventsRequestMsg ", jaxe);
		}
		catch(Exception e) {
			logger.error("Unable to get active RKC events ", e);
		}
		
		return null;
		
	}
	
	public boolean isOMSKohlsCashEnabled(String organizationCode) {
		try {
			organizationCode = fixStoreId(organizationCode);
			
			String omsKCEnabled = getOMSKohlsCashEnabledRule(organizationCode);
		
			return omsKCEnabled.equals("Y") ? true : false;
		}
		catch(Exception ex) {
			logger.error(ex);
		}
		
		return false;
	}
	
	protected String getOMSKohlsCashEnabledRule(String organizationCode) throws Exception {
		return KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID(env, organizationCode, "OMS_KOHLS_CASH_STORE", "N");
	}
	
	protected String fixStoreId(String storeId) {
		if(storeId == null || storeId.isEmpty()) {
			//No organization code passed, we won't be able to get the rule for it
			return "";
		}
		
		storeId = StringUtils.stripStart(storeId,"0");
		
		return storeId;
	}
}
