package com.kohls.poc.data.kohlscash;

public interface EventItem {
    void createItem(String itemInfo);
    String getEventItemID();
    String getOriginalData();
}
