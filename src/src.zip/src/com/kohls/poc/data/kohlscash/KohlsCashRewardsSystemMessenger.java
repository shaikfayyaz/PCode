package com.kohls.poc.data.kohlscash;

import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;

public interface KohlsCashRewardsSystemMessenger {
	
	public CouponInquiryResponseMsg sendKohlsCashInquiryAJBMessage(CouponInquiryRequestMsg inquiryRequestMsg, CouponInquiryResponseMsg inquiryResponseMsg);
	
	public CouponRedemptionResponseMsg sendKohlsCashVoidTransactionAJBMessage(CouponRedemptionRequestMsg inMsg, CouponRedemptionResponseMsg outMsg);
	
	public CouponRedemptionResponseMsg sendKohlsCashRedemptionAJBMessage(CouponRedemptionRequestMsg inMsg, CouponRedemptionResponseMsg outMsg);
	
	

}
