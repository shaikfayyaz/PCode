package com.kohls.poc.data.kohlscash;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

import org.w3c.dom.Element;

import com.ibm.icu.text.SimpleDateFormat;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;

//@XmlType(propOrder={"receiptMessageLine1", "receiptMessageLine2"})
public class ActivateEventItem implements EventItem {
	
	private static final YFCLogCategory 
	loggerForActivateEventItem = YFCLogCategory
	.instance(ActivateEventItem.class.getName());

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    @XmlTransient
    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    @XmlTransient
    public String getStartDateString() {
        return startDate;
    }

    @XmlTransient
    public Date getStartDate() {
        return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getStartDateString(), "MMddyyyy"));
    }
    
    @XmlTransient
    public Date getDBStartDate() {
    	return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getStartDateString(), "yyyy-MM-dd"));
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @XmlTransient
    public String getEndDateString() {
        return endDate;
    }

    @XmlTransient
    public Date getEndDate() {
        return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getEndDateString(), "MMddyyyy"));
    }
    
    @XmlTransient
    public Date getDBEndDate() {
    	return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getEndDateString(), "yyyy-MM-dd"));
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @XmlTransient
    public String getQualifyingTender() {
        return qualifyingTender;
    }
    
    @XmlTransient
    public int getQualifyingTenderInt() {
    	return KohlsCashFeedUtil.getInstance().convertStringToInt(this.qualifyingTender);
    }

    public void setQualifyingTender(String qualifyingTender) {
        this.qualifyingTender = qualifyingTender;
    }

    @XmlTransient
    public String getQualifyingAmount() {
        return qualifyingAmount;
    }
    
    @XmlTransient
    public int getQualifyingAmountInt() {
    	return KohlsCashFeedUtil.getInstance().convertStringToInt(this.qualifyingAmount);
    }

    public void setQualifyingAmount(String qualifyingAmount) {
        this.qualifyingAmount = qualifyingAmount;
    }

    @XmlTransient
    public String getTolerance() {
        return tolerance;
    }
    
    @XmlTransient
    public int getToleranceInt() {
    	return KohlsCashFeedUtil.getInstance().convertStringToInt(this.tolerance);
    }

    public void setTolerance(String tolerance) {
        this.tolerance = tolerance;
    }

    @XmlTransient
    public String getLimit() {
        return limit;
    }
    
    @XmlTransient
    public int getLimitInt() {
    	return KohlsCashFeedUtil.getInstance().convertStringToInt(this.limit);
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    @XmlTransient
    public String getCashValue() {
        return cashValue;
    }
    
    @XmlTransient
    public int getCashValueInt() {
    	return KohlsCashFeedUtil.getInstance().convertStringToInt(this.cashValue);
    }

    public void setCashValue(String cashValue) {
        this.cashValue = cashValue;
    }

    @XmlTransient
    public String getIncludeExcludeFlag() {
        return includeExcludeFlag;
    }

    public void setIncludeExcludeFlag(String includeExcludeFlag) {
        this.includeExcludeFlag = includeExcludeFlag;
    }

    @XmlTransient
    public ArrayList<String> getDepartments() {
        return departments;
    }

    public void setDepartments(ArrayList<String> departments) {
        this.departments = departments;
    }

    @XmlTransient
    public ArrayList<String> getReceiptMsgLines() {
        return receiptMsgLines;
    }
    
    @XmlElement(name = "ReceiptMessageLine1")
    public String getReceiptMessageLine1() {
    	if(receiptMsgLines.size() > 0) {
    		return receiptMsgLines.get(0);
    	}
    	
    	return null;
    }
    
    public void setReceiptMessageLine1(String line1) {
    	if(receiptMsgLines.size() == 0) {
    		receiptMsgLines.add(line1);
    	}
    	else {
    		receiptMsgLines.add(0, line1);
    	}
    }
    
    @XmlElement(name = "ReceiptMessageLine2")
    public String getReceiptMessageLine2() {
    	if(receiptMsgLines.size() > 1) {
    		return receiptMsgLines.get(1);
    	}
    	
    	return null;
    }
    
    public void setReceiptMessageLine2(String line2) {
    	if(receiptMsgLines.size() > 1) {
    		receiptMsgLines.add(1, line2);
    	}
    	else {
    		receiptMsgLines.add(line2);
    	}
    }

    public void setDepartmentNumbersString(String deptNums){
        departmentNumbersString = deptNums;
    }

    @XmlTransient
    public String getDepartmentNumbersString() {
        return departmentNumbersString;
    }

    public void setReceiptMsgLines(ArrayList<String> receiptMsgLines) {
        this.receiptMsgLines = receiptMsgLines;
    }

    public void setReceiptMsg(String msg){
        receiptMsg = msg.replace(";", "");
    }

    @XmlTransient
    public String getReceiptMsg(){
        return receiptMsg;
    }

    @XmlTransient
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    @XmlTransient
    public String getOriginalData() {
        return originalData;
    }

    public void setOriginalData(String originalData) {
        this.originalData = originalData;
    }
    
    @XmlTransient
    public String getStoreNum() {
    	return storeNum;
    }
    
    public void setStoreNum(String num) {
    	storeNum = num;
    }
    
    @XmlTransient
    public String getFileDateString(){
    	return fileDate;
    }
    
    @XmlTransient
    public Date getFileDate() {
    	if(this.getFileDateString().contains("-")) {
    		return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getFileDateString(), "yyyy-MM-dd'T'HH:mm:ss"));
    	}
    	else {
    		return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getFileDateString(), "yyyyMMddHHmmss"));
    	}
    }
    
    public void setFileDate(String date) {
    	fileDate = date;
    }
    
    @XmlTransient
    public String getFormattedFileDate(){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return sdf.format(getFileDate());
    }
    
    @XmlTransient
    public String getFormattedStartDate(){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(getStartDate());
    }
    
    @XmlTransient
    public String getFormattedEndDate(){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(getEndDate());
    }
    
    @XmlTransient
    public boolean isProcessed() {
    	return this.processed;
    }
    
    public void setProcessed(boolean processed) {
    	this.processed = processed;
    }
    
    @XmlTransient
    public String getEventKey() {
    	return this.eventKey;
    }
    
    public void setEventKey(String eventKey) {
    	this.eventKey = eventKey;
    }

    /// <summary>The original string that was used to fill in the data fields</summary>
    String originalData;

    /// <summary>First Five Digits of the Kohls Cash Number</summary>
    @XmlElement(name = "EventID")
    String eventID;

    /// <summary>Event Start Date MMddyyyy</summary>
    @XmlElement(name = "ActivationStartDate")
    String startDate;

    /// <summary>Event End Date MMddyyyy</summary>
    @XmlElement(name = "ActivationEndDate")
    String endDate;

    /// <summary>Required Amount to qualify</summary>
    @XmlElement(name = "ExpirationDays")
    String qualifyingTender;

    /// <summary>DDDCC (Amount to qualify for discount)</summary>
    String qualifyingAmount;

    /// <summary>(DDCC) Dollars and cents +/- range to qualify</summary>
    String tolerance;

    /// <summary>Limit setting; 0=no limit, 1=one per trans, 2=two per trans</summary>
    String limit;

    /// <summary>DDDCC (Value of Kohls cash)</summary>
    String cashValue;

    /// <summary>Areas to Include; 0=store wide, 1=department specific</summary>
    String includeExcludeFlag;

    /// <summary>Department numbers; 5 Departments each defined by 4 digits, comma separated</summary>
    ArrayList<String> departments = new ArrayList<String>();

    String departmentNumbersString;

    ArrayList<String> receiptMsgLines = new ArrayList<String>();

    String receiptMsg;

    /// <summary>Name of promotion, used in activation prompt</summary>
    @XmlElement(name = "EventName")
    String eventName;
    
    String storeNum;
    
    String fileDate;
    
    boolean processed;
    
    String eventKey;


    public ActivateEventItem(){
        setEventID("");
        this.processed = false;
    }

    public void createItem(Element eventElement){
    	setEventID(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_ID));
        setStartDate(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_START_DATE));
        setEndDate(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_END_DATE));
        setQualifyingTender(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_TENDER_TYPE_ALLOWED));
        setQualifyingAmount(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_QUALIFICATION_THRESHOLD));
        setTolerance(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_QUALIFICATION_TOLERANCE));
        setLimit(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_LIMIT));
        setCashValue(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_VALUE));
        setIncludeExcludeFlag(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_DEPT_EXCL_INCL_FLAG));
        setDepartmentNumbersString(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_DEPARTMENT_NUMBERS));
        setEventName(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_NAME));
        setStoreNum(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID));
        setFileDate(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_ACTV_FILE_DATE));
        setEventKey(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_KEY));
        
        String receiptMessage = eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_RCPT_MESSAGE_LINES);
        setReceiptMsg(receiptMessage);
        		
		if(!receiptMessage.isEmpty()) {
            String[] ReceiptMsgLinesStrs = receiptMessage.split("[|]");
            for (String msg : ReceiptMsgLinesStrs) {
                receiptMsgLines.add(msg.trim());
            }
        }
		
		String[] depts = departmentNumbersString.split("[,]");
		
		for(String dept : depts) {
			if(dept != null && !dept.isEmpty()) {
				departments.add(dept);
			}
		}
    }

    // Pass in one line from the activate file for eventData
    // Example: "10011,04052015,04012055,000,05000,0200,150,00500,0,0070,0833,0834,0983,,Loyalty Rewards-QA, | ;"
    public void createItem(String eventData) {
        receiptMsgLines.clear();
        departments.clear();

        // Save the original entry
        setOriginalData(eventData);

        String delims = "[,]";
        String[] tokens = eventData.split(delims);

        // Make sure eventData properly defines an event
        int minRequiredTokenCount = 16;
        if (tokens.length < minRequiredTokenCount) {
            return;
        }

        setEventID(tokens[0]);
        setStartDate(tokens[1]);
        setEndDate(tokens[2]);
        setQualifyingTender(tokens[3]);
        setQualifyingAmount(tokens[4]);
        setTolerance(tokens[5]);
        setLimit(tokens[6]);
        setCashValue(tokens[7]);
        setIncludeExcludeFlag(tokens[8]);
        // Capture the departments
        String dept;
        int maxDeptCount = 5;
        for (int ii = 0; ii < maxDeptCount; ii++) {
            //When the token delimiter meets the event delimiter there is a special case with the string split
            dept = tokens[9 + ii];
            if (dept.equals(";"))
                dept = "";
            departments.add(dept);
        }

        String deptNumStr = "";
        for(int i = 0; i < departments.size(); i++){
            if(i == departments.size() - 1){
                deptNumStr += departments.get(i);
            }
            else{
                deptNumStr += departments.get(i) + ",";
            }
        }

        setDepartmentNumbersString(deptNumStr);

        setEventName(tokens[14]);

        String receiptMsg = tokens[15];
        setReceiptMsg(receiptMsg);
        if(!receiptMsg.isEmpty()) {
            //Remove the trailing ';"
            receiptMsg = receiptMsg.substring(0, receiptMsg.length() - 1);
            String[] ReceiptMsgLinesStrs = receiptMsg.split("[|]");
            for (String msg : ReceiptMsgLinesStrs) {
                receiptMsgLines.add(msg.trim());
            }
        }
    }

    public void createItem(KohlsCashActvEvent kcEvent, String storeNum){
        setEventID(kcEvent.eventId);
        setStartDate(kcEvent.startDate);
        setEndDate(kcEvent.endDate);
        setQualifyingTender(kcEvent.tenderType);
        setQualifyingAmount(Integer.valueOf((int) (kcEvent.qualificationAmount*100)).toString());
        setTolerance(Integer.valueOf((int)(kcEvent.tolerance*100)).toString());
        setLimit(kcEvent.limit);
        setCashValue(Integer.valueOf((int)(kcEvent.value*100)).toString());
        setIncludeExcludeFlag(kcEvent.includeExcludeDepartment);
        setEventName(kcEvent.eventName);
        setStoreNum(storeNum);
        setFileDate(sdf.format(new Date()));

// if Departments are not provided, default to ,,,, to avoid unnecessary update/delta sync records. ,,,, is default listed in Kohls_POC_DB_Extensions.xml
        String kcDepartments = ",,,,";
        if (kcEvent.departments != null) {
            StringBuilder builder = new StringBuilder();
            for (String dept : kcEvent.departments) {
                if (!dept.isEmpty()) {
                    departments.add(dept);
                    builder.append(dept).append(',');
                }
            }
            kcDepartments = builder.toString();
        }
        setDepartmentNumbersString(kcDepartments);

        String receiptMessage = kcEvent.receiptMessageLine;
        setReceiptMsg(receiptMessage);

        if(receiptMessage!=null && !receiptMessage.isEmpty()) {
            for (String msg : receiptMessage.split("[|]")) {
                if (!msg.equalsIgnoreCase("null"))
                    receiptMsgLines.add(msg.trim());
            }
        }
    }

    // Determine if this entry includes a specific department
    public boolean hasDept(int dept){
        boolean ret = false;
        for(String strDept : departments)
        {
            if(strDept.isEmpty())
                continue;
            if(dept == KohlsCashFeedUtil.getInstance().convertStringToInt(strDept)) {
                ret = true;
                break;
            }
        }
        return ret;
    }

    @Override
    public String getEventItemID() {
        return getEventID();
    }
    
    @Override
    public boolean equals(Object o) {
    	if(o == this) {
    		return true;
    	}
    	
    	if(!(o instanceof ActivateEventItem)) {
    		return false;
    	}
    	
    	ActivateEventItem actv = (ActivateEventItem) o;
    	
    	return actv.getEventID().equals(this.eventID) && actv.getStoreNum().equals(this.storeNum);
    }
    
    public boolean checkForUpdates(ActivateEventItem actv) {
    	return actv.getCashValueInt() != this.getCashValueInt() ||
    			!actv.departmentNumbersString.equals(this.departmentNumbersString) ||
    			actv.getDBEndDate().compareTo(this.getDBEndDate()) != 0 ||
    			!actv.eventName.equals(this.eventName) ||
    			!actv.includeExcludeFlag.equals(this.includeExcludeFlag) ||
    			actv.getLimitInt() != this.getLimitInt() ||
    			actv.getQualifyingAmountInt() != this.getQualifyingAmountInt() ||
    			actv.getQualifyingTenderInt() != this.getQualifyingTenderInt() ||
    			!actv.receiptMsg.trim().equals(this.receiptMsg.trim()) ||
    			actv.getDBStartDate().compareTo(this.getDBStartDate()) != 0 ||
    			actv.getToleranceInt() != this.getToleranceInt();
    }

    // Used for debugging/testing
    /*@Override
    public String toString() {
        String ret = "";

        ret += "OriginalData: ";
        ret += getOriginalData();
        ret += "\n";
        ret += "EventID: ";
        ret += getEventID();
        ret += "\n";
        ret += "StartDate: ";
        ret += getStartDate();
        ret += "\n";
        ret += "EndDate: ";
        ret += getEndDate();
        ret += "\n";
        ret += "QualifyingTender: ";
        ret += getQualifyingTender();
        ret += "\n";
        ret += "QualifyingAmount: ";
        ret += getQualifyingAmount();
        ret += "\n";
        ret += "Tolerance: ";
        ret += getTolerance();
        ret += "\n";
        ret += "Limit: ";
        ret += getLimit();
        ret += "\n";
        ret += "CashValue: ";
        ret += getCashValue();
        ret += "\n";
        ret += "IncludeExcludeFlag: ";
        ret += getIncludeExcludeFlag();
        ret += "\n";
        // The departments
        ret += "Departments: ";
        for(String s : departments){
            ret += s;
            ret += "\n";
        }
        ret += "EventName: ";
        ret += getEventName();
        ret += "\n";
        ret += "Store number: ";
        ret += getStoreNum();
        ret += "\n";
        ret += "File date: ";
        ret += getFileDate();
        ret += "\n";
        return ret;
    }*/
    
    /*public boolean isEventValid(){
    	boolean validEvent = false;
    	
    	int qualifiyingTenderInt = KohlsCashFeedUtil.getInstance().convertStringToInt(getQualifyingTender());
    	
    	if(qualifiyingTenderInt <= 1){
    		validEvent = isEventWithinThreshold();
    	}
    	
    	return validEvent;
    }*/
    
    /*private boolean isEventWithinThreshold(){
    	Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 7);
        Date startThresholdDate;
        Date today;
        startThresholdDate = cal.getTime();
        today = Calendar.getInstance().getTime();
    	
        boolean eventIsValid = false;

        //Check if today is within the event range
        if(today.after(getStartDate()) && today.before(getEndDate())){
            eventIsValid = true;
        }

        //Check if the threshold date (today + 7 days) is within the event range
        if(startThresholdDate.after(getStartDate()) && startThresholdDate.before(getEndDate())){
            eventIsValid = true;
        }

        return eventIsValid;
    }*/
}
