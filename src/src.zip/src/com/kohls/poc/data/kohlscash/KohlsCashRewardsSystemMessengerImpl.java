package com.kohls.poc.data.kohlscash;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.http.ResponseEntity;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.dkc.DKCErrorException;
import com.kohls.poc.data.kohlscash.dkc.DKCInquiryRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCInquiryResponseMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCMessageFactory;
import com.kohls.poc.data.kohlscash.dkc.DKCMessageFactoryImpl;
import com.kohls.poc.data.kohlscash.dkc.DKCResponseHelper;
import com.kohls.poc.data.kohlscash.dkc.DKCTenderRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCTenderResponseMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCVoidTransactionRequestMessage;
import com.kohls.poc.data.kohlscash.dkc.DKCVoidTransactionResponseMessage;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;
import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;

public class KohlsCashRewardsSystemMessengerImpl implements KohlsCashRewardsSystemMessenger {
	
	// logger
    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsCashRewardsSystemMessengerImpl.class.getName());
	
	KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
	
	DKCMessageFactory messageFactory;
	
	public KohlsCashRewardsSystemMessengerImpl() {
		
	}
	
	public ResponseEntity<String> SendInquiryRequestMessage(DKCInquiryRequestMessage dkcMessage) {
	
		ResponseEntity<String> response = dkcMessage.sendRequest();
		return response;
	}
	
	public ResponseEntity<String> CreateAndSendInquiryRequestMessage(CouponInquiryRequestMsg msg) {
		
		if(messageFactory == null) {
    		messageFactory = new DKCMessageFactoryImpl();
    	}
		
		DKCInquiryRequestMessage dkcMessage = messageFactory.createDKCInquiryRequestMessage(msg);
		return SendInquiryRequestMessage(dkcMessage);
	}
	
	public ResponseEntity<String> SendVoidRedemptionRequestMessage(DKCVoidTransactionRequestMessage dkcMessage) {
		
		ResponseEntity<String> response = dkcMessage.sendRequest();
	    return response;
	}
	
	public ResponseEntity<String> CreateAndSendVoidRedemptionRequestMessage(CouponRedemptionRequestMsg msg) {
		
		Calendar cal = Calendar.getInstance();
        Date now = cal.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String voidTimestamp = sdf.format(now);
		
		if(messageFactory == null) {
	    	messageFactory = new DKCMessageFactoryImpl();
	    }
	
	    DKCVoidTransactionRequestMessage dkcMessage = messageFactory.createDKCVoidTransactionRequestMessage(msg, voidTimestamp);
	    return SendVoidRedemptionRequestMessage(dkcMessage);
	}
	
	public ResponseEntity<String> SendRedemptionRequestMessage(DKCTenderRequestMessage dkcMessage) {
		
		ResponseEntity<String> response = dkcMessage.sendRequest();
	    return response;
	}
	
	public ResponseEntity<String> CreateAndSendRedemptionRequestMessage(CouponRedemptionRequestMsg msg) {
		
		if(messageFactory == null) {
			messageFactory = new DKCMessageFactoryImpl();
		}
		
	    DKCTenderRequestMessage dkcMessage = messageFactory.createDKCTenderRequestMessage(msg);
	    return SendRedemptionRequestMessage(dkcMessage);
	}
	
	public CouponInquiryResponseMsg sendKohlsCashInquiryAJBMessage(CouponInquiryRequestMsg inquiryRequestMsg, CouponInquiryResponseMsg inquiryResponseMsg) { 
        try {
            
            ResponseEntity<String> response = CreateAndSendInquiryRequestMessage(inquiryRequestMsg); 
            
            if(response == null) {
            	logger.error("KohlsCashRewardsSystemMessenger.sendKohlsCashInquiryAJBMessage: NULL response from DKC");
            	//Process as offline
            	inquiryResponseMsg = createInquiryOfflineResponseMsgObject(inquiryResponseMsg);
            }
            else {
            	final String responseBody = response.getBody();
            	
    			// HTTP Code of 4XX or 5XX
    			if (restApiUtil.isError(response.getStatusCode())) {
    				logger.error("KohlsCashRewardsSystemMessenger.sendKohlsCashInquiryAJBMessage: error response from DKC: " + response.getStatusCode());
    				//Process as offline
                	inquiryResponseMsg = createInquiryOfflineResponseMsgObject(inquiryResponseMsg);
    			} 
    			else {
    				String responseStr =  responseBody.toString();
    				
    				if(logger.isDebugEnabled())
    					logger.debug("######Response from DKC--sendKohlsCashInquiryAJBMessage###### " + responseStr);
    				
    				inquiryResponseMsg = createInquiryResponseMsgObject(inquiryResponseMsg, inquiryRequestMsg, responseStr);
    			}
            }
        }
        catch (Exception e)
        {
        	logger.error(e);
        	inquiryResponseMsg = createInquiryOfflineResponseMsgObject(inquiryResponseMsg);
        }
        
        return inquiryResponseMsg;
    }
	
	private CouponInquiryResponseMsg createInquiryOfflineResponseMsgObject(CouponInquiryResponseMsg inquiryResponseMsg) {
		inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.Offline.getValue());
		inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
		
		return inquiryResponseMsg;
	}

	public CouponInquiryResponseMsg createInquiryResponseMsgObject(CouponInquiryResponseMsg inquiryResponseMsg, CouponInquiryRequestMsg inquiryRequestMsg, String responseStr) {
		try {
			DKCInquiryResponseMessage dkcInquiryResp = new DKCInquiryResponseMessage(responseStr);
			inquiryResponseMsg.setCouponBalance(dkcInquiryResp.getBalance());
			inquiryResponseMsg.setHistoryData(DKCResponseHelper.asHistoryData(dkcInquiryResp.getTransactionDetails()));
			inquiryResponseMsg.setExpirationDate(dkcInquiryResp.getExpirationDate());
			inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.Approved.getValue());
			inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
		}
		catch(DKCErrorException dkce) {
			inquiryResponseMsg.setCouponBalance("0");
			
			switch(dkce.getDkcErrorCode()) {
				case ActivationNotFound:
				case ValidationFailure:
					inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.HardDecline.getValue());
					if(!YFCObject.isNull(inquiryRequestMsg.getReceiptId()) && inquiryRequestMsg.getReceiptId().length() > 0) {
						inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700003);
					}
					else {
						inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700002);
					}
					break;
				case ActivationVoided:
					inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.HardDecline.getValue());
					inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700004);
					break;
				case Referral:
					inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.Referral.getValue());
					inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.REFERRAL_800001);
					break;
				default:
					inquiryResponseMsg.setAuthResponseCode(KohlsCashResponseCode.Offline.getValue());
					inquiryResponseMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
					break;
			}
		}
		
		return inquiryResponseMsg;
	}

	public CouponRedemptionResponseMsg sendKohlsCashVoidTransactionAJBMessage(CouponRedemptionRequestMsg inMsg, CouponRedemptionResponseMsg outMsg) {
		try
        {
            ResponseEntity<String> response = CreateAndSendVoidRedemptionRequestMessage(inMsg);
            
            if(response == null) {
            	logger.error("KohlsCashRewardsSystemMessenger.sendKohlsCashVoidTransactionAJBMessage: NULL response from DKC");
            	//Process as offline
            	outMsg = createRedemptionOfflineResponseMsgObject(outMsg, inMsg.getDiscountAmount());
            }
            else {
            	final String responseBody = response.getBody();
            	
    			// HTTP Code of 4XX or 5XX
    			if (restApiUtil.isError(response.getStatusCode())) {
    				logger.error("KohlsCashRewardsSystemMessenger.sendKohlsCashVoidTransactionAJBMessage: error response from DKC: " + response.getStatusCode());
    				//Process as offline
    				outMsg = createRedemptionOfflineResponseMsgObject(outMsg, inMsg.getDiscountAmount());
    			} 
    			else {
    				String responseStr =  responseBody.toString();
    				
    				if(logger.isDebugEnabled())
    					logger.debug("######Response from DKC--sendKohlsCashVoidTransactionAJBMessage###### " + responseStr);
    				
    				outMsg = createVoidTransactionResponseMsgObject(outMsg, inMsg, responseStr);
    			}
            }
        }
        catch (Exception e)
        {
        	logger.error(e);
        	outMsg = createRedemptionOfflineResponseMsgObject(outMsg, inMsg.getDiscountAmount());
        }
        
        return outMsg;
	}

	private CouponRedemptionResponseMsg createVoidTransactionResponseMsgObject(CouponRedemptionResponseMsg outMsg, CouponRedemptionRequestMsg inMsg, String responseStr) {
		try {
			DKCVoidTransactionResponseMessage dkcVoidTransactionResp = new DKCVoidTransactionResponseMessage(responseStr);
			outMsg.setLineToPrint("0");
			outMsg.setCouponBalance("0");
			outMsg.setCouponValue("0");
			
			if(!YFCObject.isNull(dkcVoidTransactionResp.getTransactionStatus()) && dkcVoidTransactionResp.getTransactionStatus().length() > 0) {
				outMsg.setAuthResponseCode(KohlsCashResponseCode.Approved.getValue());
				outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
			}
			else {
				outMsg.setAuthResponseCode(KohlsCashResponseCode.HardDecline.getValue());
				outMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700002);
			}
		}
		catch(DKCErrorException dkce) {
			outMsg.setLineToPrint("0");
			outMsg.setCouponBalance("0");
			outMsg.setCouponValue("0");
			
			switch(dkce.getDkcErrorCode()) {
				case VoidError:
					outMsg.setAuthResponseCode(KohlsCashResponseCode.HardDecline.getValue());
					outMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700002);
					break;
				default:
					outMsg.setAuthResponseCode(KohlsCashResponseCode.Offline.getValue());
					outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
					break;
			}
		}
		
		return outMsg;
	}

	public CouponRedemptionResponseMsg sendKohlsCashRedemptionAJBMessage(CouponRedemptionRequestMsg inMsg, CouponRedemptionResponseMsg outMsg) {
		try {
			
			ResponseEntity<String> response = CreateAndSendRedemptionRequestMessage(inMsg);
            
            if(response == null) {
            	logger.error("KohlsCashRewardsSystemMessenger.sendKohlsCashRedemptionAJBMessage: NULL response from DKC");
            	//Process as offline
            	outMsg = createRedemptionOfflineResponseMsgObject(outMsg, inMsg.getDiscountAmount());
            }
            else {
            	final String responseBody = response.getBody();
            	
    			// HTTP Code of 4XX or 5XX
    			if (restApiUtil.isError(response.getStatusCode())) {
    				logger.error("KohlsCashRewardsSystemMessenger.sendKohlsCashRedemptionAJBMessage: error response from DKC: " + response.getStatusCode());
    				//Process as offline
    				outMsg = createRedemptionOfflineResponseMsgObject(outMsg, inMsg.getDiscountAmount());
    			} 
    			else {
    				String responseStr =  responseBody.toString();
    				
    				if(logger.isDebugEnabled())
    					logger.debug("######Response from DKC--sendKohlsCashRedemptionAJBMessage###### " + responseStr);
    				
    				outMsg = createRedemptionResponseMsgObject(outMsg, inMsg, responseStr);
    			}
            }
        }
        catch (Exception e)
        {
        	logger.error(e);
        	outMsg = createRedemptionOfflineResponseMsgObject(outMsg, inMsg.getDiscountAmount());
        }
        
        return outMsg;
	}

	private CouponRedemptionResponseMsg createRedemptionOfflineResponseMsgObject(CouponRedemptionResponseMsg outMsg, String discountAmount) {
		outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
		outMsg.setAuthResponseCode(KohlsCashResponseCode.Offline.getValue());
		outMsg.setCouponValue(discountAmount);
		outMsg.setCouponBalance("0");
		
		return outMsg;
	}

	private CouponRedemptionResponseMsg createRedemptionResponseMsgObject(CouponRedemptionResponseMsg outMsg, CouponRedemptionRequestMsg inMsg, String responseStr) {
		try {
			DKCTenderResponseMessage dkcResp = new DKCTenderResponseMessage(responseStr);
			outMsg.setLineToPrint(dkcResp.getLineToPrint());
			outMsg.setCouponBalance(dkcResp.getRemainingBalance());
			outMsg.setCouponValue(inMsg.getDiscountAmount());
			outMsg.setAuthResponseCode(KohlsCashResponseCode.Approved.getValue());
			outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
		} 
		catch(DKCErrorException dkce) {
			outMsg.setLineToPrint("0");
			outMsg.setCouponBalance("0");
			outMsg.setCouponValue("0");
			
			switch(dkce.getDkcErrorCode()) {
			case ActivationNotFound:
			case ValidationFailure:
				outMsg.setAuthResponseCode(KohlsCashResponseCode.HardDecline.getValue());
				
				if(dkce.getDkcErrorDescription().contains("Transaction amount must be greater")) {
					outMsg.setAuthResponseCode(KohlsCashResponseCode.EditError.getValue());
					outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
				}
				else if(!YFCObject.isVoid(inMsg.getReceiptId()) && inMsg.getReceiptId().length() > 0) {
					outMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700003);
				}
				else {
					outMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700002);
				}
				break;
			case ActivationVoided:
				outMsg.setAuthResponseCode(KohlsCashResponseCode.HardDecline.getValue());
				outMsg.setAuthApprovalNum(KohlsPOCConstant.HARD_DECLINE_700004);
				break;
			case Referral:
				outMsg.setAuthResponseCode(KohlsCashResponseCode.Referral.getValue());
				outMsg.setAuthApprovalNum(KohlsPOCConstant.REFERRAL_800001);
				break;
			default:
				outMsg.setAuthResponseCode(KohlsCashResponseCode.Offline.getValue());
				outMsg.setAuthApprovalNum(KohlsPOCConstant.AUTH_ID_DUMMY);
				break;
			}
		}
		
		return outMsg;
	}
}
