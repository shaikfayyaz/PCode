package com.kohls.poc.data.kohlscash;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPocKohlsCashFeedAPI extends KOHLSBaseApi {
	
	private static final YFCLogCategory 
	loggerForKohlsCashFeed = YFCLogCategory
	.instance(KohlsPocKohlsCashFeedAPI.class.getName());
	
	ArrayList<Element> existingActivationEvents = null;
	ArrayList<Element> existingRedemptionEvents = null;
	ArrayList<ActivateEventItem> existingActvEvents = new ArrayList<ActivateEventItem>();
	ArrayList<RedeemEventItem> existingRedmEvents = new ArrayList<RedeemEventItem>();
	int activationEventsAdded;
	int activationEventsRemoved;
	int activationEventsUpdated;
	int redemptionEventsAdded;
	int redemptionEventsRemoved;
	int redemptionEventsUpdated;
	
	YFSEnvironment environment;
	
	public void transformActvRedm(YFSEnvironment env, Document input) {
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.info("KohlsPocKohlsCashFeedAPI.transformActvRedm -- BEGIN");
		try {
			//Get local incoming folder location
			String incomingDirLocation = getPropertyValue("OFFLINE_KC_INCOMING_DIR", "");
			
			//If the incoming directory location is not set, throw an error
			if(incomingDirLocation.isEmpty()) {
				Exception ex = new Exception("INCOMING DIRECTORY PATH NOT FOUND IN COP FILE");
				throw new YFCException(ex);
			}
			
			//Make sure the incoming directory exists
			File incomingDir = new File(incomingDirLocation);
			if(!incomingDir.exists() || !incomingDir.isDirectory()) {
				Exception ex = new Exception("INCOMING DIRECTORY NOT FOUND OR IS NOT A DIRECTORY");
				throw new YFCException(ex);
			}
			
			//Set mounted folder path
			String mountedPath = "/etl/ep/kc";
			
			//Check if the mounted path exists
			File mountedDir = new File(mountedPath);
			if(!mountedDir.exists() || !mountedDir.isDirectory()) {
				Exception ex = new Exception("MOUNTED DIRECTORY NOT FOUND OR IS NOT A DIRECTORY");
				throw new YFCException(ex);
			}
			
			//Set original filenames
			String redeemFilename = "RWDREDM.DAT";
			String activateFilename = "RWDACTV.DAT";
			
			//Set local filenames
			String localRedeemFilename = "OFFLRWDREDM.DAT";
			String localActivateFilename = "OFFLRWDACTV.DAT";
			
			//Set mounted and local file paths
			String mountedRedeemFilepath = mountedPath + "/" + redeemFilename;
			String mountedActivateFilepath = mountedPath + "/" + activateFilename;
			
			String localRedeemFilepath = incomingDirLocation + "/" + localRedeemFilename;
			String localActivateFilepath = incomingDirLocation + "/" + localActivateFilename;
			
			//Check if the files exist in the mounted directory
			File mountedRedeemFile = new File(mountedRedeemFilepath);
			if(!mountedRedeemFile.exists()) {
				Exception ex = new Exception("REDEEM FILE NOT FOUND IN MOUNTED DIRECTORY");
				throw new YFCException(ex);
			}
			File mountedActivateFile = new File(mountedActivateFilepath);
			if(!mountedActivateFile.exists()) {
				Exception ex = new Exception("ACTIVATE FILE NOT FOUND IN MOUNTED DIRECTORY");
				throw new YFCException(ex);
			}
			
			//Transform the redeem file
			transformRedm(mountedRedeemFilepath, localRedeemFilepath);
			//Transform the activate file
			transformActv(mountedActivateFilepath, localActivateFilepath);
		}
		catch(Exception ex) {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("ERROR WHILE TRANSFORMING ACTV REDM FILES");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error(ex);
			throw new YFCException(ex);
		}
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.info("KohlsPocKohlsCashFeedAPI.transformActvRedm -- END");
	}
	
	public void transformActv(String mount, String local) throws Exception {
		FileInputStream fstream = null;
		BufferedReader br = null;
		FileWriter writer = null;
		
		try {
			fstream = new FileInputStream(mount);
	        br = new BufferedReader(new InputStreamReader(fstream));
	
	        ArrayList<String> lines = new ArrayList<String>();
	
	        lines.add("KCHEADER@offlineactivationrecords\n");
	
	        String strLine;
	
	        while ((strLine = br.readLine()) != null)   {
	            strLine = "KCA@" + strLine + '\n';
	            lines.add(strLine);
	        }
	
	        writer = new FileWriter(local);
	        for(String line : lines) {
	            writer.write(line);
	        }
		}
		catch(Exception ex) {
			throw new YFCException(ex);
		}
		finally {
			br.close();
	        fstream.close();
	        writer.close();
		}
	}
	
	public void transformRedm(String mount, String local) throws Exception {
		FileInputStream fstream = null;
		BufferedReader br = null;
		FileWriter writer = null;
		
		try {
			fstream = new FileInputStream(mount);
	        br = new BufferedReader(new InputStreamReader(fstream));

	        ArrayList<String> lines = new ArrayList<String>();

	        lines.add("KCHEADER@offlineredemptionrecords\n");

	        String strLine;

	        while ((strLine = br.readLine()) != null)   {
	            strLine = "KCR@" + strLine + '\n';
	            lines.add(strLine);
	        }

	        writer = new FileWriter(local);
	        for(String line : lines) {
	            writer.write(line);
	        }
		}
		catch(Exception ex) {
			throw new YFCException(ex);
		}
		finally {
			br.close();
			fstream.close();
			writer.close();
		}
		
	}
	
	public static String getPropertyValue(String property, String defaultValue)
	{
		loggerForKohlsCashFeed.beginTimer("KohlsPocKohlsCashFeedAPI.getPropertyValue");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		// customer_overrides.properties does not return any value
		if(YFCCommon.isVoid(propValue)){
			loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI getProperty: " + property + " has no value.");
			propValue = "";
		}
		loggerForKohlsCashFeed.endTimer("KohlsPocKohlsCashFeedAPI.getPropertyValue");
		
		if(propValue.isEmpty()) {
			return defaultValue;
		}
		
		return propValue;
	}
	
	public void kohlsCashFeedMain(YFSEnvironment env, Document inputKohlsCashFeed) throws Exception 
	{
		try {
			this.environment = env;
			
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashFeedMain -- BEGIN");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.beginTimer("KohlsPocKohlsCashFeedAPI.kohlsCashFeedMain");
			
			if(KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.isDebugEnabled()){
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Input xml to KohlsPocKohlsCashFeedAPI.kohlsCashFeedMain is: "
				          + XMLUtil.getXMLString(inputKohlsCashFeed));
			}
			
			//Get list of elements from the input document
			ArrayList<Element> activationList = SCXmlUtil.getChildren(inputKohlsCashFeed.getDocumentElement(),
					KohlsPOCConstant.ELEM_ACTIVATION_EVENT);
			
			String storeNum = "";
			String fileDate = "";
			activationEventsAdded = 0;
			activationEventsRemoved = 0;
			activationEventsUpdated = 0;
			
			for(Element activation : activationList){
				String actv = activation.getAttribute(KohlsPOCConstant.ATTR_KC_ACTIVATION_DATA);
				
				if(actv.contains("HDR")){
					//Clear existing xml events
					existingActivationEvents = null;
					
					//Remove unprocessed events for previous store from database
					removeUnprocessedActivateEvents(env);
					
					//Clear existing event objects from memory
					existingActvEvents = null;
					existingActvEvents = new ArrayList<ActivateEventItem>();
					
					//HDR line, save store and file date information from it
					storeNum = KohlsCashFeedUtil.getInstance().getStoreNumberFromHeader(actv);
					String[] headerParts = actv.split("_");
	                fileDate = headerParts[4];
	                
	                //Get list of store activation events from the database
	    			Document docActivationEvents = getActivationsFromDatabase(env, storeNum);
	    			
	    			existingActivationEvents = SCXmlUtil.getChildren(docActivationEvents.getDocumentElement(),
	    					"KCActivationEvent");
	    			
	    			//Populate the object list
	    			populateActvObjects();
	    			
	    			//KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Removed activate events: " + eventsRemoved);
	    			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Existing store activate events for store " + storeNum + ": " + existingActivationEvents.size());
				}
				else{
					//Activation event record, add store number and file date to it
					ActivateEventItem itm = new ActivateEventItem();
					itm.createItem(actv);
					itm.setStoreNum(storeNum);
					itm.setFileDate(fileDate);
					
					//Create activation event document
					Document actvDoc = createActivationDocument(itm);
					
					if(!doesActivationEventExist(itm)){
						if(addActivationEventToDatabase(env, actvDoc)) {
							activationEventsAdded++;
							//Add the event to our temp list also
							itm.setProcessed(true);
							existingActvEvents.add(itm);
						}
					}
				}
			}
			
			//Remove unprocessed events for the last store
			removeUnprocessedActivateEvents(env);
			
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Activate events added: " + activationEventsAdded);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Activate events removed: " + activationEventsRemoved);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Activate events updated: " + activationEventsUpdated);
			
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.endTimer("KohlsPocKohlsCashFeedAPI.kohlsCashFeedMain");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashFeedMain -- END");
		}
		catch(Exception exception)
		{
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error(exception);
			throw new YFCException(exception);
		}
	}

	public void kohlsCashActivationMain(YFSEnvironment env, Map<String, List<KohlsCashActvEvent>> kohlsCashMap) {
		try {
			//Set environment for other methods to use
			this.environment = env;

			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashActivationMain -- BEGIN");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.beginTimer("KohlsPocKohlsCashFeedAPI.kohlsCashActivationMain");

			String storeNum = "";
			activationEventsAdded = 0;
			activationEventsRemoved = 0;
			activationEventsUpdated = 0;

			//Iterate through each store ID (key) in the map
			for(Map.Entry<String, List<KohlsCashActvEvent>> kcEvents : kohlsCashMap.entrySet()) {

				//Clear existing xml events
				existingActivationEvents = null;

				//Remove unprocessed events for previous store from database
				removeUnprocessedActivateEvents(env);

				//Clear existing event objects from memory
				existingActvEvents = null;
				existingActvEvents = new ArrayList<ActivateEventItem>();

				// Store num is the key of the map
				storeNum = kcEvents.getKey();

				//Get list of store activation events from the database
				Document docActivationEvents = getActivationsFromDatabase(env, storeNum);

				existingActivationEvents = SCXmlUtil.getChildren(docActivationEvents.getDocumentElement(),
						"KCActivationEvent");

				//Populate the object list
				populateActvObjects();

				//KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Removed activate events: " + eventsRemoved);
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Existing store activate events for store " + storeNum + ": " + existingActivationEvents.size());

				//For each event in the event list for this store, create a database event object and add it if required
				for(KohlsCashActvEvent actv : kcEvents.getValue()) {
					//Activation event record, add store number and file date to it
					ActivateEventItem itm = new ActivateEventItem();
					itm.createItem(actv, storeNum);

					//Create activation event document
					Document actvDoc = createActivationDocument(itm);

					if(!doesActivationEventExist(itm)){
						if(addActivationEventToDatabase(env, actvDoc)) {
							activationEventsAdded++;
							//Add the event to our temp list also
							itm.setProcessed(true);
							existingActvEvents.add(itm);
						}
					}
				}
			}

			//Remove unprocessed events for the last store
			removeUnprocessedActivateEvents(env);

			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Activate events added: " + activationEventsAdded);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Activate events removed: " + activationEventsRemoved);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Activate events updated: " + activationEventsUpdated);

			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.endTimer("KohlsPocKohlsCashFeedAPI.kohlsCashActivationMain");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashActivationMain -- END");
		}
		catch(Exception exception)
		{
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error(exception);
			throw new YFCException(exception);
		}
	}
	
	public void removeUnprocessedActivateEvents(YFSEnvironment env) {
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.removeUnprocessedEvents -- BEGIN");
		
		for(ActivateEventItem actv : existingActvEvents) {
			if(!actv.isProcessed()) {
				Document docActivationEvent = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_ACTIVATION_EVENT).getDocument();
				Element actvEle = docActivationEvent.getDocumentElement();
				actvEle.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_KEY, actv.getEventKey());
				
				try {
					KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.removeUnprocessedEvents -- XML input: " + com.custom.util.xml.XMLUtil.getXMLString(docActivationEvent));
					KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_DELETE_KOHLS_CASH_ACTIVATION, docActivationEvent);
					activationEventsRemoved++;
				}
				catch(Exception ex) {
					KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for DeleteKohlsCashActivation");
					throw new YFCException(ex);
				}
			}
		}
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.removeUnprocessedEvents -- END");
	}
	
	public void populateActvObjects() {
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.populateActvObjects -- BEGIN");
		for(Element actvEle : existingActivationEvents) {
			ActivateEventItem actv = new ActivateEventItem();
			actv.createItem(actvEle);
			existingActvEvents.add(actv);
		}
		
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.populateActvObjects -- END");
	}
	
	public Document getActivationsFromDatabase(YFSEnvironment env, String storeNum) {
		Document docActivationEvents = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_ACTIVATION_EVENT).getDocument();
		Element actvEle = docActivationEvents.getDocumentElement();
		actvEle.setAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID, storeNum);
		
		try{
			if(KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.isDebugEnabled()){
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Input xml to KohlsPocKohlsCashFeedAPI.getActivationsFromDatabase is: "
				          + XMLUtil.getXMLString(docActivationEvents));
			}
			
			docActivationEvents = KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_GET_KOHLS_CASH_ACTIVATION_LIST, docActivationEvents);
			
			if(KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.isDebugEnabled()){
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Output xml from KohlsPocKohlsCashFeedAPI.getActivationsFromDatabase is: "
				          + XMLUtil.getXMLString(docActivationEvents));
			}
		}
		catch(Exception getAllException){
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for GetKohlsCashActivateEventList");
			throw new YFCException(getAllException);
		}
		
		return docActivationEvents;
	}
	
	public boolean addActivationEventToDatabase(YFSEnvironment env, Document actvDoc) {
		try{
			KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_CREATE_KOHLS_CASH_ACTIVATION, actvDoc);
			return true;
		}
		catch(Exception createException){
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for CreateKohlsCashActivateEvent");
			throw new YFCException(createException);
		}
	}
	
	public void kohlsCashRedemptionFeedMain(YFSEnvironment env, Document inputKohlsCashFeed) throws Exception 
	{
		try {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain -- BEGIN");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.beginTimer("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain");
			
			if(KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.isDebugEnabled()){
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Input xml to KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain is: "
				          + XMLUtil.getXMLString(inputKohlsCashFeed));
			}
			
			this.environment = env;
			
			//Get list of elements from the input document
			ArrayList<Element> redemptionList = SCXmlUtil.getChildren(inputKohlsCashFeed.getDocumentElement(),
					KohlsPOCConstant.ELEM_REDEMPTION_EVENT);
			
			String storeNum = "";
			String fileDate = "";
			redemptionEventsAdded = 0;
			redemptionEventsRemoved = 0;
			redemptionEventsUpdated = 0;
			
			for(Element redemption : redemptionList){
				String redm = redemption.getAttribute(KohlsPOCConstant.ATTR_KC_REDEMPTION_DATA);
				
				if(redm.contains("HDR")){
					//Clear existing xml events
					existingRedemptionEvents = null;
					
					//Remove unprocessed events for previous store from database
					removeUnprocessedRedeemEvents(env);
					
					//Clear existing event objects from memory
					existingRedmEvents = null;
					existingRedmEvents = new ArrayList<RedeemEventItem>();
					
					//HDR line, save store and file date information from it
					storeNum = KohlsCashFeedUtil.getInstance().getStoreNumberFromHeader(redm);
					String[] headerParts = redm.split("_");
	                fileDate = headerParts[4];
	                
	                //Get list of redemption events from the database
	    			Document docRedemptionEvents = getRedemptionEventsFromDatabase(env, storeNum);
	    			existingRedemptionEvents = SCXmlUtil.getChildren(docRedemptionEvents.getDocumentElement(), KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENT);
	    			
	    			//Populate the object list
	    			populateRedmObjects();
	    			
	    			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Existing store activate events for store " + storeNum + ": " + existingRedemptionEvents.size());
				}
				else{
					//Activation event record, add store number and file date to it
					RedeemEventItem itm = new RedeemEventItem();
					itm.createItem(redm);
					itm.setStoreNum(storeNum);
					itm.setFileDate(fileDate);
					
					//Create redemption event document
					Document redmDoc = createRedemptionDocument(itm);
					
					if(!doesRedemptionEventExist(itm)){
						if(addRedemptionEventToDatabase(env, redmDoc)) {
							redemptionEventsAdded++;
							itm.setProcessed(true);
						}
					}
				}
			}
			
			//Remove the unprocessed events for the last store
			removeUnprocessedRedeemEvents(env);
			
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Redeem events added: " + redemptionEventsAdded);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Redeem events removed: " + redemptionEventsRemoved);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Redeem events updated: " + redemptionEventsUpdated);
			
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.endTimer("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain -- END");
		}
		catch(Exception exception)
		{
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error(exception);
			throw new YFCException(exception);
		}
	}

	public void kohlsCashRedemptionMain(YFSEnvironment env, Map<String, List<KohlsCashRedeemEvent>> kohlsCashMap) {
		try {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain -- BEGIN");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.beginTimer("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain");

			this.environment = env;

			String storeNum = "";
			String fileDate = "";
			redemptionEventsAdded = 0;
			redemptionEventsRemoved = 0;
			redemptionEventsUpdated = 0;

			for(Map.Entry<String, List<KohlsCashRedeemEvent>> kcEvents : kohlsCashMap.entrySet()){

				//Clear existing xml events
				existingRedemptionEvents = null;

				//Remove unprocessed events for previous store from database
				removeUnprocessedRedeemEvents(env);

				//Clear existing event objects from memory
				existingRedmEvents = null;
				existingRedmEvents = new ArrayList<RedeemEventItem>();

				//HDR line, save store and file date information from it
				storeNum = kcEvents.getKey();

				//Get list of redemption events from the database
				Document docRedemptionEvents = getRedemptionEventsFromDatabase(env, storeNum);
				existingRedemptionEvents = SCXmlUtil.getChildren(docRedemptionEvents.getDocumentElement(), KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENT);

				//Populate the object list
				populateRedmObjects();

				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Existing store activate events for store " + storeNum + ": " + existingRedemptionEvents.size());

				for(KohlsCashRedeemEvent event : kcEvents.getValue()) {
					//Redemption event record
					RedeemEventItem itm = new RedeemEventItem();
					itm.createItem(event, storeNum);

					//Create redemption event document
					Document redmDoc = createRedemptionDocument(itm);

					if(!doesRedemptionEventExist(itm)){
						if(addRedemptionEventToDatabase(env, redmDoc)) {
							redemptionEventsAdded++;
							itm.setProcessed(true);
						}
					}
				}
			}

			//Remove the unprocessed events for the last store
			removeUnprocessedRedeemEvents(env);

			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Redeem events added: " + redemptionEventsAdded);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Redeem events removed: " + redemptionEventsRemoved);
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Redeem events updated: " + redemptionEventsUpdated);

			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.endTimer("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain");
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.kohlsCashRedemptionFeedMain -- END");
		}
		catch(Exception exception)
		{
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error(exception);
			throw new YFCException(exception);
		}
	}
	
	public void removeUnprocessedRedeemEvents(YFSEnvironment env) {
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.removeUnprocessedRedeemEvents -- BEGIN");
		
		for(RedeemEventItem redm : existingRedmEvents) {
			if(!redm.isProcessed()) {
				Document docRedeemEvent = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENT).getDocument();
				Element redmEle = docRedeemEvent.getDocumentElement();
				redmEle.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_KEY, redm.getEventKey());
				
				try {
					KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.removeUnprocessedRedeemEvents -- XML input: " + com.custom.util.xml.XMLUtil.getXMLString(docRedeemEvent));
					KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_DELETE_KOHLS_CASH_REDEMPTION, docRedeemEvent);
					redemptionEventsRemoved++;
				}
				catch(Exception ex) {
					KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for DeleteKohlsCashActivation");
					throw new YFCException(ex);
				}
			}
		}
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.removeUnprocessedRedeemEvents -- END");
	}
	
	public void populateRedmObjects() {
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.populateRedmObjects -- BEGIN");
		for(Element redmEle : existingRedemptionEvents) {
			RedeemEventItem redm = new RedeemEventItem();
			redm.createItem(redmEle);
			existingRedmEvents.add(redm);
		}
		
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.populateRedmObjects -- END");
	}
	
	public Document getRedemptionEventsFromDatabase(YFSEnvironment env, String storeNum) {
		Document docRedemptionEvent = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENT).getDocument();
		Element actvEle = docRedemptionEvent.getDocumentElement();
		actvEle.setAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID, storeNum);
		
		try{
			if(KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.isDebugEnabled()){
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Input xml to KohlsPocKohlsCashFeedAPI.getRedemptionEventsFromDatabase is: "
				          + XMLUtil.getXMLString(docRedemptionEvent));
			}
			
			docRedemptionEvent = KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_GET_KOHLS_CASH_REDEMPTION_LIST, docRedemptionEvent);
			
			if(KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.isDebugEnabled()){
				KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Output xml from KohlsPocKohlsCashFeedAPI.getRedemptionEventsFromDatabase is: "
				          + XMLUtil.getXMLString(docRedemptionEvent));
			}
		}
		catch(Exception getAllException){
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for GetKohlsCashRedemptionEventList");
			throw new YFCException(getAllException);
		}
		
		return docRedemptionEvent;
	}
	
	public boolean addRedemptionEventToDatabase(YFSEnvironment env, Document redmDoc) {
		try{
			KohlsPocKohlsCashFeedAPI.invokeService(env, KohlsPOCConstant.API_SVC_CREATE_KOHLS_CASH_REDEMPTION, redmDoc);
			return true;
		}
		catch(Exception createException){
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for CreateKohlsCashRedeemEvent");
			throw new YFCException(createException);
		}
	}
	
	public Document createActivationDocument(ActivateEventItem aevt)
	{
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.createActivationDocument -- BEGIN");
		Document docActivationEventInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_ACTIVATION_EVENT).getDocument();
		Element elemKC = docActivationEventInput.getDocumentElement();
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID, aevt.getStoreNum());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_ID, aevt.getEventID());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_ACTV_FILE_DATE, aevt.getFileDateString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_START_DATE, aevt.getStartDateString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_END_DATE, aevt.getEndDateString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_TENDER_TYPE_ALLOWED, aevt.getQualifyingTender());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_QUALIFICATION_THRESHOLD, aevt.getQualifyingAmount());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_QUALIFICATION_TOLERANCE, aevt.getTolerance());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_VALUE, aevt.getCashValue());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_DEPT_EXCL_INCL_FLAG, aevt.getIncludeExcludeFlag());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_DEPARTMENT_NUMBERS, aevt.getDepartmentNumbersString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_NAME, aevt.getEventName());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_RCPT_MESSAGE_LINES, aevt.getReceiptMsg());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_LIMIT, aevt.getLimit());
        
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.createActivationDocument -- END");
		return docActivationEventInput;
	}
	
	public Document createRedemptionDocument(RedeemEventItem revt)
	{
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.createRedemptionDocument -- BEGIN");
		Document docRedemptionEventInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KC_REDEMPTION_EVENT).getDocument();
		Element elemKC = docRedemptionEventInput.getDocumentElement();
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID, revt.getStoreNum());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_ID, revt.getEventID());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_ACTV_FILE_DATE, revt.getFileDateString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_START_DATE, revt.getStartDateString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_END_DATE, revt.getEndDateString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_AUTHORIZATION_INDICATOR, revt.getAuthorizationIndicator());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_DISCOUNT_TYPE, revt.getDiscountType());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_DISCOUNT_AMOUNT, revt.getDiscountAmountString());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_DEPT_EXCL_INCL_FLAG, revt.getIncludeExcludeFlag());
		elemKC.setAttribute(KohlsPOCConstant.ATTR_KC_DEPARTMENT_NUMBERS, revt.getDepartmentNumbersString());
        
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.createRedemptionDocument -- END");
		return docRedemptionEventInput;
	}
	
	public boolean doesActivationEventExist(ActivateEventItem pendingEvent){
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.doesActivationEventExist -- BEGIN");
		
		boolean eventExists = false;
		for(ActivateEventItem evt : existingActvEvents) {
			if(pendingEvent.equals(evt)) {
				eventExists = true;
				evt.setProcessed(true);
				//Check if event needs to be updated
				if(evt.checkForUpdates(pendingEvent)) {
					//Only update the event if it has an event key
					//If the event has not been committed yet it will not have an event key
					//This could happen if there is a duplicate event ID in a store in the flat file
					if(evt.getEventKey() != null && !evt.getEventKey().isEmpty()) {
						KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Updating activate event: " + evt.getEventKey());
						updateActivationEvent(pendingEvent, evt.getEventKey());
					}
				}
			}
		}
		
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.doesActivationEventExist -- END");
		return eventExists;
	}
	
	public void updateActivationEvent(ActivateEventItem pendingEvent, String existingEventKey) {
		Document docUpdateActivation = createActivationDocument(pendingEvent);
		Element updateEle = docUpdateActivation.getDocumentElement();
		updateEle.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_KEY, existingEventKey);
		
		try {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Input xml to KohlsPocKohlsCashFeedAPI.updateActivationEvent is: "
			          + XMLUtil.getXMLString(docUpdateActivation));
			KohlsPocKohlsCashFeedAPI.invokeService(this.environment, KohlsPOCConstant.API_SVC_UPDATE_KOHLS_CASH_ACTIVATION, docUpdateActivation);
			activationEventsUpdated++;
		}
		catch(Exception ex) {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for UpdateKohlsCashActivation");
			throw new YFCException(ex);
		}
	}
	
	public boolean doesRedemptionEventExist(RedeemEventItem pendingEvent){
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.doesRedemptionEventExist -- BEGIN");
		
		boolean eventExists = false;
		for(RedeemEventItem evt : existingRedmEvents) {
			if(pendingEvent.equals(evt)) {
				eventExists = true;
				evt.setProcessed(true);
				//Check if event needs to be updated
				if(evt.checkForUpdates(pendingEvent)) {
					//Only update the event if it has an event key
					//If the event has not been committed yet it will not have an event key
					//This could happen if there is a duplicate event ID in a store in the flat file
					if(evt.getEventKey() != null && !evt.getEventKey().isEmpty()) {
						KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Updating redeem event: " + evt.getEventKey());
						updateRedemptionEvent(pendingEvent, evt.getEventKey());
					}
				}
			}
		}
		
		KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("KohlsPocKohlsCashFeedAPI.doesRedemptionEventExist -- END");
		return eventExists;
	}
	
	public void updateRedemptionEvent(RedeemEventItem pendingEvent, String existingEventKey) {
		Document docUpdateRedemption = createRedemptionDocument(pendingEvent);
		Element updateEle = docUpdateRedemption.getDocumentElement();
		updateEle.setAttribute(KohlsPOCConstant.ATTR_KC_EVENT_KEY, existingEventKey);
		
		try {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.debug("Input xml to KohlsPocKohlsCashFeedAPI.updateRedemptionEvent is: "
			          + XMLUtil.getXMLString(docUpdateRedemption));
			KohlsPocKohlsCashFeedAPI.invokeService(this.environment, KohlsPOCConstant.API_SVC_UPDATE_KOHLS_CASH_REDEMPTION, docUpdateRedemption);
			redemptionEventsUpdated++;
		}
		catch(Exception ex) {
			KohlsPocKohlsCashFeedAPI.loggerForKohlsCashFeed.error("Error invoking service for UpdateKohlsCashActivation");
			throw new YFCException(ex);
		}
	}
}
