package com.kohls.poc.data.kohlscash;

import javax.xml.bind.JAXBContext;

import com.kohls.poc.data.kohlscash.messages.CouponInquiryRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponInquiryResponseMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.CouponRedemptionResponseMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashActivationRequestMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashActivationResponseMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationRequestMsg;
import com.kohls.poc.data.kohlscash.messages.DetermineKohlsCashDeactivationResponseMsg;
import com.kohls.poc.data.kohlscash.messages.GetActiveRKCEventsRequestMsg;
import com.kohls.poc.data.kohlscash.messages.GetActiveRKCEventsResponseMsg;
import com.kohls.poc.data.kohlscash.messages.KohlsCashActivationTransactionRequestMsg;
import com.kohls.poc.data.kohlscash.messages.KohlsCashActivationTransactionResponseMsg;
import com.yantra.yfc.log.YFCLogCategory;

public class KohlsCashContextProvider {
	
	private static final YFCLogCategory 
	logger = YFCLogCategory
	.instance(KohlsCashContextProvider.class.getName());
	
	private JAXBContext determineKohlsCashActivationRequestMsgContext;
	private JAXBContext determineKohlsCashActivationResponseMsgContext;
	private JAXBContext determineKohlsCashDeactivationRequestMsgContext;
	private JAXBContext determineKohlsCashDeactivationResponseMsgContext;
	private JAXBContext getActiveRKCEventsRequestMsgContext;
	private JAXBContext getActiveRKCEventsResponseMsgContext;
	private JAXBContext kohlsCashActivationTransactionRequestMsgContext;
	private JAXBContext kohlsCashActivationTransactionResponseMsgContext;
	private JAXBContext couponInquiryRequestMsgContext;
	private JAXBContext couponInquiryResponseMsgContext;
	private JAXBContext couponRedemptionRequestMsgContext;
	private JAXBContext couponRedemptionResponseMsgContext;
	
	private static KohlsCashContextProvider instance;
	
	protected KohlsCashContextProvider() {
		
	}
	
	public synchronized static KohlsCashContextProvider getInstance() {
		if(instance == null) {
			instance = new KohlsCashContextProvider();
		}
		return instance;
	}
	
	public synchronized JAXBContext getContext(Class c) {
		try {
			if(c == DetermineKohlsCashActivationRequestMsg.class) {
				if(determineKohlsCashActivationRequestMsgContext == null) {
					determineKohlsCashActivationRequestMsgContext = 
							JAXBContext.newInstance(DetermineKohlsCashActivationRequestMsg.class);
				}
				return determineKohlsCashActivationRequestMsgContext;
			}
			else if(c == DetermineKohlsCashActivationResponseMsg.class) {
				if(determineKohlsCashActivationResponseMsgContext == null) {
					determineKohlsCashActivationResponseMsgContext = 
							JAXBContext.newInstance(DetermineKohlsCashActivationResponseMsg.class);
				}
				return determineKohlsCashActivationResponseMsgContext;
			}
			else if(c == CouponInquiryRequestMsg.class) {
				if(couponInquiryRequestMsgContext == null) {
					couponInquiryRequestMsgContext = 
							JAXBContext.newInstance(CouponInquiryRequestMsg.class);
				}
				return couponInquiryRequestMsgContext;
			}
			else if(c == CouponInquiryResponseMsg.class) {
				if(couponInquiryResponseMsgContext == null) {
					couponInquiryResponseMsgContext = 
							JAXBContext.newInstance(CouponInquiryResponseMsg.class);
				}
				return couponInquiryResponseMsgContext;
			}
			else if(c == CouponRedemptionRequestMsg.class) {
				if(couponRedemptionRequestMsgContext == null) {
					couponRedemptionRequestMsgContext = 
							JAXBContext.newInstance(CouponRedemptionRequestMsg.class);
				}
				return couponRedemptionRequestMsgContext;
			}
			else if(c == CouponRedemptionResponseMsg.class) {
				if(couponRedemptionResponseMsgContext == null) {
					couponRedemptionResponseMsgContext = 
							JAXBContext.newInstance(CouponRedemptionResponseMsg.class);
				}
				return couponRedemptionResponseMsgContext;
			}
			else if(c == DetermineKohlsCashDeactivationRequestMsg.class) {
				if(determineKohlsCashDeactivationRequestMsgContext == null) {
					determineKohlsCashDeactivationRequestMsgContext = 
							JAXBContext.newInstance(DetermineKohlsCashDeactivationRequestMsg.class);
				}
				return determineKohlsCashDeactivationRequestMsgContext;
			}
			else if(c == DetermineKohlsCashDeactivationResponseMsg.class) {
				if(determineKohlsCashDeactivationResponseMsgContext == null) {
					determineKohlsCashDeactivationResponseMsgContext = 
							JAXBContext.newInstance(DetermineKohlsCashDeactivationResponseMsg.class);
				}
				return determineKohlsCashDeactivationResponseMsgContext;
			}
			else if(c == GetActiveRKCEventsRequestMsg.class) {
				if(getActiveRKCEventsRequestMsgContext == null) {
					getActiveRKCEventsRequestMsgContext = 
							JAXBContext.newInstance(GetActiveRKCEventsRequestMsg.class);
				}
				return getActiveRKCEventsRequestMsgContext;
			}
			else if(c == GetActiveRKCEventsResponseMsg.class) {
				if(getActiveRKCEventsResponseMsgContext == null) {
					getActiveRKCEventsResponseMsgContext = 
							JAXBContext.newInstance(GetActiveRKCEventsResponseMsg.class);
				}
				return getActiveRKCEventsResponseMsgContext;
			}
			else if(c == KohlsCashActivationTransactionRequestMsg.class) {
				if(kohlsCashActivationTransactionRequestMsgContext == null) {
					kohlsCashActivationTransactionRequestMsgContext = 
							JAXBContext.newInstance(KohlsCashActivationTransactionRequestMsg.class);
				}
				return kohlsCashActivationTransactionRequestMsgContext;
			}
			else if(c == KohlsCashActivationTransactionResponseMsg.class) {
				if(kohlsCashActivationTransactionResponseMsgContext == null) {
					kohlsCashActivationTransactionResponseMsgContext = 
							JAXBContext.newInstance(KohlsCashActivationTransactionResponseMsg.class);
				}
				return kohlsCashActivationTransactionResponseMsgContext;
			}
		}
		catch(Exception ex) {
			logger.error(ex);
		}
		
		return null;
	}

}
