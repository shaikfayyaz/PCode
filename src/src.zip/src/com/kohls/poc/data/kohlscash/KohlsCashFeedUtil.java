package com.kohls.poc.data.kohlscash;

import com.yantra.yfc.log.YFCLogCategory;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class KohlsCashFeedUtil {
	
	private static final YFCLogCategory 
	loggerForKohlsCashFeedUtil = YFCLogCategory
	.instance(KohlsCashFeedUtil.class.getName());
	
    private static KohlsCashFeedUtil INSTANCE = new KohlsCashFeedUtil();

    private static final int STORE_NUM_INDEX = 14;
    private static final int STORE_NUM_LENGTH = 4;

    private KohlsCashFeedUtil(){
    }

    public static KohlsCashFeedUtil getInstance(){
        return KohlsCashFeedUtil.INSTANCE;
    }

    public int convertCharToInt(Character c){
        return Character.getNumericValue(c);
    }

    public String convertIntToString(int n){
        return Integer.toString(n);
    }
    
    public String convertLongToString(long l) {
    	return Long.toString(l);
    }
    
    public String convertBoolToString(Boolean b){
        if (b)
            return "True";
        return "False";
    }

    public int convertStringToInt(String s){
        int ret = 0;
        if (s == null || s.isEmpty())
            return ret;

        try {
            ret = Integer.parseInt(s);
        } catch (NumberFormatException e) {
        	loggerForKohlsCashFeedUtil.error(e);
        }
        return ret;
    }
    
    public long convertStringToLong(String s) {
    	long ret = 0;
    	if (s == null || s.isEmpty()) {
    		return ret;
    	}
    	
    	try {
    		ret = Long.parseLong(s);
    	}
    	catch(NumberFormatException e) {
    		loggerForKohlsCashFeedUtil.error(e);
    	}
    	
    	return ret;
    }

    public double convertStringToDouble(String s){
        double ret = 0;
        if (s == null || s.isEmpty())
            return ret;

        try {
            ret = Double.parseDouble(s);
        } catch (NumberFormatException e) {
        	loggerForKohlsCashFeedUtil.error(e);
        }
        return ret;
    }
    
    public boolean convertStringToBool(String s){
        String ret = s.toLowerCase();
        return ret.equals("true");
    }

    // Return a string that contains two decimal places.  Ex. 101.98
    public String convertDoubleToDollarString(double d){
        String ret = "";
        
        if(d == 0) {
        	return "0.00";
        }
        
        DecimalFormat dFormat = new DecimalFormat("#.00");
        ret = dFormat.format(d);
        return ret;
    }

    // For Kohl's Cash values where the response is, for example, 10 and not 10.00
    public String convertDoubleToWholeDollar(double d){
        String ret = "";
        
        if(d == 0) {
        	return "0";
        }
        
        DecimalFormat dFormat = new DecimalFormat("#");
        ret = dFormat.format(d);
        return ret;
    }

    public Date getDateFromString(String strDate, String pattern){

        DateFormat dateFormat = new SimpleDateFormat(pattern, Locale.ENGLISH);
        Date date = new Date();
        try {
            date = dateFormat.parse(strDate);
        } catch (ParseException e) {
        	loggerForKohlsCashFeedUtil.error(e);
        }
        return date;
    }

    // <Original Code from the KohlsCashServiceApplication>
    public int CheckDigitCreate(String s){
        String Suspect = s;
        String weight = "121212121212121";
        int modulus = 10;

        int error = -1;
        try
        {
            if (Suspect == null || Suspect.isEmpty())
            {
            	loggerForKohlsCashFeedUtil.error("CheckDigitCreate - Check digit input cannot be blank");
                return error;
            }
            if (Suspect.length() > weight.length() - 1)
            {
            	loggerForKohlsCashFeedUtil.error("Check digit input is a longer length than the maximum 'Weight' of " + weight.length() + " defined");
                return error;
            }

            final String validChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVYWXZ_";
            Suspect = Suspect.trim().toUpperCase();
            int sum = 0;

            // loop right to left
            for (int i = 0; i < Suspect.length(); i++)
            {
                char ch = Suspect.charAt(Suspect.length() - i - 1);
                if (validChars.indexOf(ch) == -1)
                {
                	loggerForKohlsCashFeedUtil.error("CheckDigitCreate - Invalid character encountered while determining the check digit");
                    return error;
                }

                int digit = ch - 48;
                char weightChar = weight.charAt(weight.length()- i - 2);
                int weighting = ( Character.valueOf(weightChar) - 48 ) * digit;

                String strTemp = Integer.toString(weighting);
                for (int j = 0; j < strTemp.length(); j++)
                    sum += ( Character.valueOf(strTemp.charAt(j)) - 48);
            }
            sum = Math.abs(sum) + modulus;
            return (modulus - (sum%modulus))%modulus;
        }
        catch (Exception e)
        {
        	loggerForKohlsCashFeedUtil.error(e);
        }
        return error;
    }

    // Find the value for a given tag from within an XML doc
    /*public String getTagValue(Document doc, String tag) {

        XPathFactory xpf = XPathFactory.newInstance();
        XPath xp = xpf.newXPath();
        XPathExpression expr     = null;

        if (doc == null){
        	loggerForKohlsCashFeedUtil.error("Invalid Document. Unable to evaluate tag value.");
            return "";
        }

        if (tag == null || tag.isEmpty()){
        	loggerForKohlsCashFeedUtil.error("Error: Invalid tag");
            return "";
        }

        try {
            expr = xp.compile(tag);
        } catch (XPathExpressionException e) {
        	loggerForKohlsCashFeedUtil.error(e);
            return "";
        }

        //evaluate expression result on XML document
        NodeList node;
        try {
            node = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        } catch (XPathExpressionException e) {
        	loggerForKohlsCashFeedUtil.error(e);
            return "";
        }

        if(node == null || node.getLength() < 1){
        	loggerForKohlsCashFeedUtil.error("The document does not contain a value for the tag: " + tag);
            return "";
        }

        String ret = "";
        ret =  node.item(0).getTextContent();
        return ret;
    }*/

    /*public int getTagValueAsInt(Document doc, String tag) {
        String ret = getTagValue(doc, tag);
        return convertStringToInt(ret);
    }*/

    /*public boolean getTagValueAsBool(Document doc, String tag) {
        String ret = getTagValue(doc, tag);
        ret = ret.toLowerCase();
        return ret.equals("true");
    }*/

    // Given a Header entry from an Activate or Redeem file, find the Store Number
    public String getStoreNumberFromHeader(String header){
        String storeNum = "";
        if(header == null || header.isEmpty()){
        	loggerForKohlsCashFeedUtil.error("Header data not supplied");
            return "";
        }
        storeNum = header.substring(STORE_NUM_INDEX, STORE_NUM_INDEX + STORE_NUM_LENGTH);
        return storeNum;
    }

    // Creates an easy to read string from XML
    /*public String formatDisplayXML(String s){
        if(s == null || s.isEmpty()){
        	loggerForKohlsCashFeedUtil.error("Error: There is nothing to display.");
            return "";
        }

        String ret = "";
        try {
            Source xmlInput = new StreamSource(new StringReader(s));
            StringWriter stringWriter = new StringWriter();
            StreamResult xmlOutput = new StreamResult(stringWriter);
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            transformerFactory.setAttribute("indent-number", 2);
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            transformer.transform(xmlInput, xmlOutput);
            ret = xmlOutput.getWriter().toString();
        } catch (Exception e) {
        	loggerForKohlsCashFeedUtil.error(e);
        }
        return ret;
    }

    public String readFile(String filePathAndName){
        String ret = "";
        FileInputStream inputStream = null;
        Scanner sc = null;
        try {
            inputStream = new FileInputStream(filePathAndName);
            sc = new Scanner(inputStream, "UTF-8");

            while (sc.hasNextLine()){
                String line = sc.nextLine();
                line = line.trim();
                ret += line;
            }

            // note that Scanner suppresses exceptions
            if (sc.ioException() != null) {
                throw sc.ioException();
            }
        } catch (FileNotFoundException e) {
        	loggerForKohlsCashFeedUtil.error(e);
        } catch (IOException e) {
        	loggerForKohlsCashFeedUtil.error(e);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                	loggerForKohlsCashFeedUtil.error(e);
                }
            }
            if (sc != null) {
                sc.close();
            }
        }
        return ret;
    }

    public double doubleRounding(double d){
        BigDecimal bd = new BigDecimal(d).setScale(2, RoundingMode.HALF_EVEN);
        return bd.doubleValue();
    }*/
}
