package com.kohls.poc.data.kohlscash;

import javax.xml.bind.annotation.XmlElement;

public class KohlsCashStatus {
	
	@XmlElement(name = "KohlsCashBalance")
	private String kohlsCashBalanceStr;
	
	@XmlElement(name = "EarnedAmt")
	private String earnedAmtStr;
	
	@XmlElement(name = "EligibleAmt")
	private String eligibleAmtStr;
	
	public KohlsCashStatus() {
		
	}
	
	public KohlsCashStatus(double kcBalance, double earnedAmount, double eligAmount) {
		this.kohlsCashBalanceStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(kcBalance);
		this.earnedAmtStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(earnedAmount);
		this.eligibleAmtStr = KohlsCashFeedUtil.getInstance().convertDoubleToDollarString(eligAmount);
	}
	
	public KohlsCashStatus(String kcBalance, String earnedAmount, String eligAmount) {
		this.kohlsCashBalanceStr = kcBalance;
		this.earnedAmtStr = earnedAmount;
		this.eligibleAmtStr = eligAmount;
	}

	public double getKohlsCashBalance() {
		return KohlsCashFeedUtil.getInstance().convertStringToDouble(kohlsCashBalanceStr);
	}
	
	public String getKohlsCashBalanceStr() {
		return this.kohlsCashBalanceStr;
	}
	
	public double getEarnedAmt() {
		return KohlsCashFeedUtil.getInstance().convertStringToDouble(earnedAmtStr);
	}
	
	public String getEarnedAmtStr() {
		return this.earnedAmtStr;
	}

	public double getEligibleAmt() {
		return KohlsCashFeedUtil.getInstance().convertStringToDouble(eligibleAmtStr);
	}
	
	public String getEligibleAmtStr() {
		return this.eligibleAmtStr;
	}

}
