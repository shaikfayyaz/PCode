package com.kohls.poc.data.kohlscash;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.kohls.common.util.KohlsConstant;
import org.apache.commons.lang3.StringUtils;

import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;

public class CouponManager {
	
	private static final YFCLogCategory logger = YFCLogCategory.instance(CouponManager.class.getName());
    
    ArrayList<ActivateEventItem> activateEventList;
    ArrayList<RedeemEventItem> redeemEventList;
    
    public CouponManager(ArrayList<ActivateEventItem> activateEventItems, ArrayList<RedeemEventItem> redeemEventItems){
    	activateEventList = activateEventItems;
    	redeemEventList = redeemEventItems;
    }

    // Find all the active Activate events for a specific store by comparing each events' begin and end dates to the
    // passed in business date.
    public ArrayList<ActivateEventItem> getActiveActivateEvents(Date businessDate, boolean hasKohlsCharge, int storeNum){

        ArrayList<ActivateEventItem> allStoresEventList = new ArrayList<ActivateEventItem>();
        ArrayList<ActivateEventItem> storeSpecificEventList = new ArrayList<ActivateEventItem>();
        boolean storeSpecificEvent = false;
        String storeNumStr = KohlsCashFeedUtil.getInstance().convertIntToString(storeNum);
        storeNumStr = StringUtils.leftPad(storeNumStr, 4, "0");

        if(activateEventList.size() == 0){
        	logger.warn("Unable to find activate events for Store number: " + storeNum);
            return allStoresEventList;
        }

        if(businessDate == null){
        	logger.error("Invalid business date. Business date cannot be null.");
            return allStoresEventList;
        }

        for (ActivateEventItem event : activateEventList) {
            Date startDate = new Date();
            Date endDate = new Date();
            //Get the start and end dates for this event
            startDate = event.getDBStartDate();
            endDate = event.getDBEndDate();

            if (businessDate.before(startDate)  || //if the business date is prior to the Start date
                    businessDate.after(endDate)    ) { //if the business date is after the End date
                continue;
            }
            Date tempDate = KohlsCashFeedUtil.getInstance().getDateFromString("09099999", "MMddyyyy");
            if(event.getEndDate().equals(tempDate))
            {
                continue;
            }
            
            if(!YFCObject.isVoid(event.getStoreNum())) {
            	if(!event.getStoreNum().equals(storeNumStr) &&
						!event.getStoreNum().equalsIgnoreCase(KohlsConstant.ALL_ITEM_ID)){
                	continue;
                } else {
            		if(!KohlsConstant.ALL_ITEM_ID.equalsIgnoreCase(event.getStoreNum())) {
						storeSpecificEvent = true;
					}
				}
            }
            
            if(event.getQualifyingTenderInt() == 1 && !hasKohlsCharge) {
            	continue;
            }
            
            if(event.getQualifyingTenderInt() > 1) {
            	continue;
            }

            //If an event is store-specific, we want to favor it over the ALL stores events
			//Save the specific stores in their own list and add on to the end of all stores once
			//all stores have been added.
            if(storeSpecificEvent) {
				storeSpecificEventList.add(event);
			} else {
				allStoresEventList.add(event);
			}

        }

        allStoresEventList.addAll(storeSpecificEventList);

        return allStoresEventList;
    }
    
    public ArrayList<RedeemEventItem> getStoreRedeemEvents(String storeNum) {
    	ArrayList<RedeemEventItem> allStoreRedeemEvents = new ArrayList<RedeemEventItem>();
    	ArrayList<RedeemEventItem> storeSpecificRedeemEvents = new ArrayList<RedeemEventItem>();

    	storeNum = StringUtils.leftPad(storeNum, 4, "0");
    	
    	if(redeemEventList.size() == 0){
        	logger.warn("Unable to find redeem events for Store number: " + storeNum);
            return allStoreRedeemEvents;
        }
    	
    	for(RedeemEventItem redm : redeemEventList) {
    		if(!YFCObject.isVoid(redm.getStoreNum())) {
				//If an event is store-specific, we want to favor it over the ALL stores events
				//Save the specific stores in their own list and add on to the end of all stores once
				//all stores have been added.
            	if(redm.getStoreNum().equals(storeNum)) {
                	storeSpecificRedeemEvents.add(redm);
                } else if(redm.getStoreNum().equalsIgnoreCase(KohlsConstant.ALL_ITEM_ID)) {
					allStoreRedeemEvents.add(redm);
				}
            }
    	}

		allStoreRedeemEvents.addAll(storeSpecificRedeemEvents);
    	return allStoreRedeemEvents;
    }
    
    public ArrayList<ActivateEventItem> getStoreActivateEvents(String storeNum) {
    	ArrayList<ActivateEventItem> storeSpecificActivateEvents = new ArrayList<ActivateEventItem>();
    	ArrayList<ActivateEventItem> allStoreActivateEvents = new ArrayList<ActivateEventItem>();

    	storeNum = StringUtils.leftPad(storeNum, 4, "0");
    	
    	if(activateEventList.size() == 0){
        	logger.warn("Unable to find activate events for Store number: " + storeNum);
            return storeSpecificActivateEvents;
        }
    	
    	for(ActivateEventItem actv : activateEventList) {
    		if(!YFCObject.isVoid(actv.getStoreNum())) {
				//If an event is store-specific, we want to favor it over the ALL stores events
				//Save the specific stores in their own list and add on to the end of all stores once
				//all stores have been added.
            	if(actv.getStoreNum().equals(storeNum)) {
            		storeSpecificActivateEvents.add(actv);
                } else if(actv.getStoreNum().equalsIgnoreCase(KohlsConstant.ALL_ITEM_ID)) {
            		allStoreActivateEvents.add(actv);
				}
            }
    	}

    	allStoreActivateEvents.addAll(storeSpecificActivateEvents);
    	return allStoreActivateEvents;
    }

	public ArrayList<ActivateEventItem> getActiveRKCEvents(String store, Date businessDate) {
		
		ArrayList<ActivateEventItem> allStoreActivateEvents = getStoreActivateEvents(store);
		ArrayList<ActivateEventItem> activeRKCEvents = new ArrayList<ActivateEventItem>();
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			Date max = sdf.parse("09099999");
			
			for(ActivateEventItem itm : allStoreActivateEvents) {
				if(businessDate.before(itm.getDBStartDate()) || (businessDate.after(itm.getDBEndDate()) && itm.getDBEndDate().compareTo(max) != 0)) {
					continue;
				}
				
				if(itm.getQualifyingTenderInt() >= 2) {
					activeRKCEvents.add(itm);
				}
			}
			
			if(activeRKCEvents.size() == 0) {
				activeRKCEvents = null;
			}
			
			return activeRKCEvents;
		}
		catch(Exception ex) {
			logger.error(ex);
		}
		
		return null;
	}
}
