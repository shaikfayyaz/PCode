package com.kohls.poc.data.kohlscash;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.w3c.dom.Element;

import com.ibm.icu.text.SimpleDateFormat;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;

public class RedeemEventItem implements EventItem {

	private static final YFCLogCategory 
	loggerForRedeemEventItem = YFCLogCategory
	.instance(RedeemEventItem.class.getName());

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    public String getEventID() {
        return eventID;
    }

    public void setEventID(String eventID) {
        this.eventID = eventID;
    }

    public String getStartDateString() {
        return startDate;
    }

    public Date getStartDate() {
        return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getStartDateString(), "MMddyyyy"));
    }
    
    public Date getDBStartDate() {
    	return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getStartDateString(), "yyyy-MM-dd"));
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDateString() {
        return endDate;
    }

    public Date getEndDate() {
        return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getEndDateString(), "MMddyyyy"));
    }
    
    public Date getDBEndDate() {
    	return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getEndDateString(), "yyyy-MM-dd"));
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getIncludeExcludeFlag() {
        return includeExcludeFlag;
    }

    public void setIncludeExcludeFlag(String includeExcludeFlag) {
        this.includeExcludeFlag = includeExcludeFlag;
    }

    public ArrayList<String> getDepartments() {
        return departments;
    }

    public void setDepartments(ArrayList<String> departments) {
        this.departments = departments;
    }

    public void setDepartmentNumbersString(String deptNums){
        departmentNumbersString = deptNums;
    }

    public String getDepartmentNumbersString() {
        return departmentNumbersString;
    }

    public String getOriginalData() {
        return originalData;
    }

    public void setOriginalData(String originalData) {
        this.originalData = originalData;
    }
    
    public String getStoreNum() {
    	return storeNum;
    }
    
    public void setStoreNum(String num) {
    	storeNum = num;
    }
    
    public String getFileDateString(){
    	return fileDate;
    }
    
    public Date getFileDate() {
    	if(this.getFileDateString().contains("-")) {
    		return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getFileDateString(), "yyyy-MM-dd'T'HH:mm:ss"));
    	}
    	else {
    		return(KohlsCashFeedUtil.getInstance().getDateFromString(this.getFileDateString(), "yyyyMMddHHmmss"));
    	}
    }
    
    public void setFileDate(String date) {
    	fileDate = date;
    }
    
    public String getFormattedFileDate(){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		return sdf.format(getFileDate());
    }
    
    public String getFormattedStartDate(){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(getStartDate());
    }
    
    public String getFormattedEndDate(){
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(getEndDate());
    }
    
    public void setAuthorizationIndicator(String authInd){
    	this.authorizationIndicator = authInd;
    }
    
    public String getAuthorizationIndicator(){
    	return this.authorizationIndicator;
    }
    
    public void setDiscountType(String discountType){
    	this.discountType = discountType;
    }
    
    public String getDiscountType(){
    	return this.discountType;
    }
    
    public void setDiscountAmount(String discountAmount){
    	this.discountAmount = discountAmount;
    }
    
    public double getDiscountAmount(){
    	return KohlsCashFeedUtil.getInstance().convertStringToDouble(this.discountAmount);
    }
    
    public String getDiscountAmountString() {
    	return this.discountAmount;
    }
    
    public void setProcessed(boolean processed) {
    	this.processed = processed;
    }
    
    public boolean isProcessed() {
    	return this.processed;
    }
    
    public String getEventKey() {
    	return this.eventKey;
    }
    
    public void setEventKey(String eventKey) {
    	this.eventKey = eventKey;
    }

    /// <summary>The original string that was used to fill in the data fields</summary>
    String originalData;

    /// <summary>First Five Digits of the Kohls Cash Number</summary>
    String eventID;

    /// <summary>Event Start Date MMddyyyy</summary>
    String startDate;

    /// <summary>Event End Date MMddyyyy</summary>
    String endDate;

    /// <summary>Areas to Include; 0=store wide, 1=department specific</summary>
    String includeExcludeFlag;

    /// <summary>Department numbers; 5 Departments each defined by 4 digits, comma separated</summary>
    ArrayList<String> departments = new ArrayList<String>();

    String departmentNumbersString;
    
    String storeNum;
    
    String fileDate;
    
    String authorizationIndicator;
    
    String discountType;
    
    String discountAmount;
    
    boolean processed;
    
    String eventKey;


    public RedeemEventItem(){
        setEventID("");
        this.processed = false;
    }
    
    public void createItem(Element eventElement){
    	setEventID(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_ID));
        setStartDate(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_START_DATE));
        setEndDate(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_END_DATE));
        setIncludeExcludeFlag(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_DEPT_EXCL_INCL_FLAG));
        setDepartmentNumbersString(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_DEPARTMENT_NUMBERS));
        setStoreNum(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_STORE_ID));
        setAuthorizationIndicator(eventElement.getAttribute(KohlsPOCConstant.ATTR_AUTHORIZATION_INDICATOR));
        setDiscountType(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_DISCOUNT_TYPE));
        setDiscountAmount(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_DISCOUNT_AMOUNT));
        setFileDate(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_REDM_FILE_DATE));
        setEventKey(eventElement.getAttribute(KohlsPOCConstant.ATTR_KC_EVENT_KEY));
        
        if(departmentNumbersString != null) {
	    	String[] depts = departmentNumbersString.split("[,]");
			
			for(String dept : depts) {
				if(dept != null && !dept.isEmpty()) {
					departments.add(dept);
				}
			}
        }
    }

    // Pass in one line from the activate file for eventData
    // Example: "10011,04052015,04012055,000,05000,0200,150,00500,0,0070,0833,0834,0983,,Loyalty Rewards-QA, | ;"
    public void createItem(String eventData) {
        departments.clear();

        // Save the original entry
        setOriginalData(eventData);

        String delims = "[,]";
        String[] tokens = eventData.split(delims);

        // Make sure eventData properly defines an event
        /*int minRequiredTokenCount = 13;
        if (tokens.length < minRequiredTokenCount) {
            return;
        }*/

        setEventID(tokens[0]);
        setStartDate(tokens[1]);
        setEndDate(tokens[2]);
        setIncludeExcludeFlag(tokens[6]);
        // Capture the departments
        String dept;
        int maxDeptCount = 5;
        for (int ii = 0; ii < maxDeptCount; ii++) {
            //When the token delimiter meets the event delimiter there is a special case with the string split
            dept = tokens[7 + ii];
            if (dept.equals(";"))
                dept = "";
            departments.add(dept);
        }

        String deptNumStr = "";
        for(int i = 0; i < departments.size(); i++){
            if(i == departments.size() - 1){
                deptNumStr += departments.get(i).replace(";", "");
            }
            else{
                deptNumStr += departments.get(i) + ",";
            }
        }

        setDepartmentNumbersString(deptNumStr);
        setAuthorizationIndicator(tokens[3]);
        setDiscountType(tokens[4]);
        setDiscountAmount(tokens[5]);
    }

    public void createItem(KohlsCashRedeemEvent kcEvent, String storeNum) {
        departments.clear();

        setEventID(kcEvent.eventId);
        setStoreNum(storeNum);
        setStartDate(kcEvent.startDate);
        setEndDate(kcEvent.endDate);
        setIncludeExcludeFlag(kcEvent.includeExcludeDepartment);
        setFileDate(sdf.format(new Date()));

// if Departments are not provided, default to ,,,, to avoid unnecessary update/delta sync records. ,,,, is default listed in Kohls_POC_DB_Extensions.xml
        String kcDepartments = ",,,,";
        if (kcEvent.departments != null) {
            StringBuilder builder = new StringBuilder();
            for (String dept : kcEvent.departments) {
                if (!dept.isEmpty()) {
                    departments.add(dept);
                    builder.append(dept).append(',');
                }
            }
            kcDepartments = builder.toString();
        }
        setDepartmentNumbersString(kcDepartments);

        setAuthorizationIndicator(kcEvent.authorizationIndicator);
        setDiscountType(kcEvent.discountType);
        setDiscountAmount(Integer.valueOf((int)(kcEvent.discountAmount*100)).toString());
    }
    
    @Override
    public boolean equals(Object o) {
    	if(o == this) {
    		return true;
    	}
    	
    	if(!(o instanceof RedeemEventItem)) {
    		return false;
    	}
    	
    	RedeemEventItem redm = (RedeemEventItem) o;
    	
    	return redm.getEventID().equals(this.eventID) && redm.getStoreNum().equals(this.storeNum);
    }
    
    public boolean checkForUpdates(RedeemEventItem redm) {
    	return redm.getDBEndDate().compareTo(this.getDBEndDate()) != 0 ||
    			redm.getDBStartDate().compareTo(this.getDBStartDate()) != 0 ||
    			!redm.getDepartmentNumbersString().equals(this.getDepartmentNumbersString()) ||
    			redm.getDiscountAmount() != this.getDiscountAmount() ||
    			!redm.getDiscountType().equals(this.getDiscountType()) ||
    			!redm.getStoreNum().equals(this.getStoreNum()) ||
    			!redm.getAuthorizationIndicator().equals(this.getAuthorizationIndicator()) ||
    			!redm.getIncludeExcludeFlag().equals(this.getIncludeExcludeFlag());
    }

    // Determine if this entry includes a specific department
    /*public boolean hasDept(int dept){
        boolean ret = false;
        for(String strDept : departments)
        {
            if(strDept.isEmpty())
                continue;
            if(dept == KohlsCashFeedUtil.getInstance().convertStringToInt(strDept)) {
                ret = true;
                break;
            }
        }
        return ret;
    }*/

    @Override
    public String getEventItemID() {
        return getEventID();
    }

    // Used for debugging/testing
    /*@Override
    public String toString() {
        String ret = "";

        ret += "OriginalData: ";
        ret += getOriginalData();
        ret += "\n";
        ret += "EventID: ";
        ret += getEventID();
        ret += "\n";
        ret += "StartDate: ";
        ret += getStartDate();
        ret += "\n";
        ret += "EndDate: ";
        ret += getEndDate();
        ret += "\n";
        ret += "IncludeExcludeFlag: ";
        ret += getIncludeExcludeFlag();
        ret += "\n";
        // The departments
        ret += "Departments: ";
        for(String s : departments){
            ret += s;
            ret += "\n";
        }
        ret += "Store number: ";
        ret += getStoreNum();
        ret += "\n";
        ret += "File date: ";
        ret += getFileDate();
        ret += "\n";
        ret += "Authorization Indicator: ";
        ret += getAuthorizationIndicator();
        ret += "\n";
        ret += "Discount Type: ";
        ret += getDiscountType();
        ret += "\n";
        ret += "Discount Amount: ";
        ret += getDiscountAmount();
        ret += "\n";
        return ret;
    }*/
    
    /*public boolean isEventValid(){
    	//Keeping this method here just in case we need it
    	
    	return true;
    }*/
    
    /*private boolean isEventWithinThreshold(){
    	Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 7);
        Date startThresholdDate;
        Date today;
        startThresholdDate = cal.getTime();
        today = Calendar.getInstance().getTime();
    	
        boolean eventIsValid = false;

        //Check if today is within the event range
        if(today.after(getStartDate()) && today.before(getEndDate())){
            eventIsValid = true;
        }

        //Check if the threshold date (today + 7 days) is within the event range
        if(startThresholdDate.after(getStartDate()) && startThresholdDate.before(getEndDate())){
            eventIsValid = true;
        }

        return eventIsValid;
    }*/
}
