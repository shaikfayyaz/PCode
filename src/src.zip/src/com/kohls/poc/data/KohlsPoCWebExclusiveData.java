package com.kohls.poc.data;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCWebExclusiveData extends KOHLSBaseApi {

	private static final YFCLogCategory loggerWEData = YFCLogCategory
	.instance(KohlsPoCWebExclusiveData.class.getName());
	

	public Document getWebExclusiveData(YFSEnvironment env, Document inputDoc) throws Exception 
	{
		loggerWEData.beginTimer("----KohlsPoCWebExclusiveData.getWebExclusiveData---");
		Document resultDoc = null;
		try{
			if(!YFCCommon.isVoid(inputDoc))
			{
				Element eleItem = inputDoc.getDocumentElement();
				
				Document inputToWS = createInputForWS(eleItem);
				if(!YFCCommon.isVoid(inputToWS))
				{
					resultDoc = KOHLSBaseApi.invokeService(env,
							KohlsPOCConstant.GET_SKU_SERVICE_CALL, inputToWS);
					if(!YFCCommon.isVoid(resultDoc))
					{
						Element eleSKUAttributes = (Element)resultDoc.getElementsByTagName(KohlsPOCConstant.SKU_ATTRIBUTES).item(0);
						Element eleReturnDisposition = (Element)resultDoc.getElementsByTagName("ReturnDisposition").item(0);
						if(!YFCCommon.isVoid(eleSKUAttributes) && !YFCCommon.isVoid(eleReturnDisposition)){
							eleItem.setAttribute("ReturnDispositionDescription", eleReturnDisposition.getAttribute("ReferenceValueDescription"));
							eleItem.setAttribute(KohlsPOCConstant.RETURN_DISPOSITION_CODE, eleSKUAttributes.getAttribute(KohlsPOCConstant.RETURN_DISPOSITION_CODE));
						}
					}

				}
			}
		}
		catch(Exception e)
		{
			loggerWEData.debug("----KohlsPoCWebExclusiveData.getWebExclusiveData-- There is exception , so returning input document-");
		}
		loggerWEData.endTimer("----KohlsPoCWebExclusiveData.getWebExclusiveData---");
		return inputDoc;
	}
	
	
	private Document createInputForWS(Element eleInputItem) throws Exception
	{
		loggerWEData.beginTimer("----KohlsPoCWebExclusiveData.createInputForWS---");
		Document finalInputForWS = null;
		
			finalInputForWS= XMLUtil.createDocument("v1:"+KohlsPOCConstant.GET_SKU_INPUT);
			Element eleSKUInput = finalInputForWS.getDocumentElement();
			eleSKUInput.setAttribute("xmlns:v1", "http://www.kohls.com/schemas/cdm/BSInputOutputTypes/V1");
			eleSKUInput.setAttribute("xmlns:v11", "http://www.kohls.com/schemas/cdm/ProductTypesCDM/V1");
			Element eleSKUList = XMLUtil.createChild(eleSKUInput, "v11:"+KohlsPOCConstant.SKU_LIST);
			Element eleSKU = XMLUtil.createChild(eleSKUList, "v11:"+KohlsPOCConstant.SKU);
			Element eleSkuAttr = XMLUtil.createChild(eleSKU, "v11:"+KohlsPOCConstant.SKU_ATTRIBUTES);
			eleSkuAttr.setAttribute(KohlsPOCConstant.SKU_NUMBER, eleInputItem.getAttribute(KohlsPOCConstant.A_ITEM_ID));
			Element eleAdvanceFilter = XMLUtil.createChild(eleSKUInput, "v11:"+KohlsPOCConstant.ADVANCE_FILTER);
			eleAdvanceFilter.setAttribute(KohlsPOCConstant.WANT_CHILDREN, KohlsPOCConstant.TRUE);
			eleAdvanceFilter.setAttribute(KohlsPOCConstant.WANT_RLTNSHIP, KohlsPOCConstant.TRUE);
		loggerWEData.endTimer("----KohlsPoCWebExclusiveData.createInputForWS---");
		return finalInputForWS;
	}
}
