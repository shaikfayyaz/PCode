package com.kohls.poc.data.item;


import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : KohlsPoc ItemFeedCategoryHierarchyAPI.java Author : IBM Created :
 * August 27 2013 Modified : August 27 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This will manage CategoryHierarchy and ItemCategoryHierarchy
 * 
 * @author Naveen Yalamanchili
 * @version 0.1
 *****************************************************************************/

public class ItemFeedCategoryHierarchyAPI extends KOHLSBaseApi implements
        YIFCustomApi {

    private static final YFCLogCategory LOG_CAT = YFCLogCategory
            .instance(ItemFeedCategoryHierarchyAPI.class.getName());

    /**
     * This method invokes getCategoryDetails and getItemdDetails by fetching
     * prifix path
     * 
     * @return Document which will be the requestDoc
     * @param env
     *            YFSEnvironment variable from sterling
     * @param requestDoc
     *            read from the queue
     * @exception Exception
     *                throws when there is any mandatory fields are missing and
     *                others
     */
    public Document itemCategoryHierarchy(YFSEnvironment env,
            Document requestDoc) throws Exception {

        LOG_CAT.debug("itemCategoryHierarchy Start...");
        Element eleRoot = requestDoc.getDocumentElement();
        String sDept = XMLUtil.getAttribute(eleRoot, "Dept");
        String sClass = XMLUtil.getAttribute(eleRoot, "Class");
        String sSubclass = XMLUtil.getAttribute(eleRoot, "SubClass");
        String sOrganizationCode = XMLUtil.getAttribute(eleRoot,
                "OrganizationCode");
        String sUom = XMLUtil.getAttribute(eleRoot, "UnitOfMeasure");
        String sItemId = XMLUtil.getAttribute(eleRoot, "ItemID");

        String sAttr = null;
        if (YFCCommon.isVoid(sOrganizationCode)) {
            sAttr = "OrganizationCode";
        } else if (YFCCommon.isVoid(sItemId)) {
            sAttr = "ItemID";
        } else if (YFCCommon.isVoid(sDept)) {
            sAttr = "Dept";
        } else if (YFCCommon.isVoid(sClass)) {
            sAttr = "Class";
        } else if (YFCCommon.isVoid(sSubclass)) {
            sAttr = "Subclass";
        } else if (YFCCommon.isVoid(sUom)) {
            sAttr = "UnitOfMeasure";
        }

        // Bala: 10/14 - Commented because this is not a
        // mandatory attribute for category creation.
        /*
         * else if (YFCCommon.isVoid(sDesc)) { sAttr =
         * "POCMerchandiseDescription"; }
         */

        if (!YFCCommon.isVoid(sAttr)) {
            YFSException ex = new YFSException();
            ex.setErrorCode(KohlsPOCConstant.E_MANDATORY_FIELDS_MISSING);
            ex.setAttribute(sAttr, "");
            throw ex;
        }
        
       
		        String category_Domain = "KohlsCatalog";
		
		        // String sOcatpath = sDept + "-" + sClass + "-" + sSubclass;
		        String sPrefixpath = this.getprefixpath(env, sDept);
		        this.getCategoryDetails(env, sPrefixpath, sDept, sClass, sSubclass,
		                sOrganizationCode, category_Domain);
		        this.getItemdDetails(env, sItemId, sPrefixpath, sDept, sClass,
		                sSubclass, sOrganizationCode, sUom, category_Domain);
      
        return requestDoc;
    }

    /**
     * This method checks the ItemCategoryPath and calls modcatitem method based
     * on certain conditions
     * 
     * @param env
     *            YFSEnvironment variable
     * @param itemid
     *            ItemID from requestDoc
     * @param prifixpath
     *            CategoryPrefixPath
     * @param dept
     *            Department of item
     * @param clas
     *            Class of item
     * @param subclas
     *            SubClass of item
     * @param orgcode
     *            OrganizationCode of item
     * @param uom
     *            UnitOfMeasure of item
     * @exception Exception
     *                can be thrown while creating indoc to API or other
     *                scenarios
     */
    public void getItemdDetails(YFSEnvironment env, String sItemId,
            String sPrefixpath, String sDept, String sClass, String sSubclass,
            String sOrgcode, String sUom, String category_Domain)
            throws Exception {

        LOG_CAT.debug("call to getItemDetails  START... ");
        String sDettemp = "<Item><CategoryList><Category/></CategoryList></Item>";
        Document docItemdetail = XMLUtil.newDocument();
        Element eleItem = docItemdetail.createElement("Item");
        docItemdetail.appendChild(eleItem);
        eleItem.setAttribute("ItemID", sItemId);
        eleItem.setAttribute("OrganizationCode", sOrgcode);
        eleItem.setAttribute("UnitOfMeasure", sUom);
        Document docOutdetail = null;
        docOutdetail = KOHLSBaseApi.invokeAPI(env,
                XMLUtil.getDocument(sDettemp), "getItemDetails", docItemdetail);
        String sItemcatpath = null;
        if (!YFCCommon.isVoid(docOutdetail)) {
            Element eleCatlist = XMLUtil.getChildElement(
                    docOutdetail.getDocumentElement(), "CategoryList");
            if (!YFCCommon.isVoid(eleCatlist) && eleCatlist.hasChildNodes()) {
                if (eleCatlist.hasChildNodes()) {
                    sItemcatpath = XMLUtil.getAttribute((Element) docOutdetail
                            .getElementsByTagName("Category").item(0),
                            "CategoryPath");
                }
            }
        }
        if (YFCCommon.isVoid(sItemcatpath)) {
            if (YFCCommon.isVoid(sPrefixpath)) {
                sItemcatpath = "/" + category_Domain + "/" + sDept + "/"
                        + sDept + "-" + sClass + "/" + sDept + "-" + sClass
                        + "-" + sSubclass;
            } else {
                sItemcatpath = "/" + category_Domain + "/" + sPrefixpath + "/"
                        + sDept + "/" + sDept + "-" + sClass + "/" + sDept
                        + "-" + sClass + "-" + sSubclass;
            }
            LOG_CAT.debug("create categoryItem");
            this.modifycategoryitem(env, "Create", sItemId, sItemcatpath,
                    sOrgcode, sUom);
        } else {
            String sCatpath = null;
            if (YFCCommon.isVoid(sPrefixpath)) {
                sCatpath = "/" + category_Domain + "/" + sDept + "/" + sDept
                        + "-" + sClass + "/" + sDept + "-" + sClass + "-"
                        + sSubclass;
            } else {
                sCatpath = "/" + category_Domain + "/" + sPrefixpath + "/"
                        + sDept + "/" + sDept + "-" + sClass + "/" + sDept
                        + "-" + sClass + "-" + sSubclass;
            }
            if (!sCatpath.equalsIgnoreCase(sItemcatpath)) {
                LOG_CAT.debug("delete categoryItem...");
                this.modifycategoryitem(env, "Delete", sItemId, sItemcatpath,
                        sOrgcode, sUom);
                LOG_CAT.debug("create categoryItem...");
                this.modifycategoryitem(env, "Create", sItemId, sCatpath,
                        sOrgcode, sUom);
            }
        }
    }

    /**
     * This method will modify the categorypath of item based on action passed
     * 
     * @param env
     *            YFSEnvironment
     * @param action
     *            can be Create or Modify
     * @param itemid
     *            ItemID of Item
     * @param catpath
     *            catgorypath of item
     * @param orgcode
     *            OrganizationCode of item
     * @param uom
     *            UnitOfMeasure of item
     * @throws Exception
     *             throws when creating indoc and calling for API
     */
    public void modifycategoryitem(YFSEnvironment env, String sAction,
            String sItemId, String sCatpath, String sOrgcode, String sUom)
            throws Exception {

        LOG_CAT.debug("call to modifyCategoryItem START...");
        Document docInmodifycategoryitem = XMLUtil.newDocument();
        Element eleModifycategoryItem = docInmodifycategoryitem
                .createElement("ModifyCategoryItems");
        docInmodifycategoryitem.appendChild(eleModifycategoryItem);
        Element eleCateogry = docInmodifycategoryitem.createElement("Category");
        eleModifycategoryItem.appendChild(eleCateogry);
        eleCateogry.setAttribute("CategoryPath", sCatpath);
        eleCateogry.setAttribute("OrganizationCode", sOrgcode);
        Element eleCategoryItemList = docInmodifycategoryitem
                .createElement("CategoryItemList");
        eleCateogry.appendChild(eleCategoryItemList);
        Element eleCategoryItem = docInmodifycategoryitem
                .createElement("CategoryItem");
        eleCategoryItemList.appendChild(eleCategoryItem);
        eleCategoryItem.setAttribute("Action", sAction);
        eleCategoryItem.setAttribute("ItemID", sItemId);
        eleCategoryItem.setAttribute("OrganizationCode", sOrgcode);
        eleCategoryItem.setAttribute("UnitOfMeasure", sUom);
        this.invokeAPI(env, "modifyCategoryItem", docInmodifycategoryitem);
        LOG_CAT.debug("call to modifyCategoryItem END...");

    }

    /**
     * This methods get the prefixpath of based on CodeName
     * 
     * @param env
     *            YFSEnvironment
     * @param dept
     *            Department of Item
     * @return prifixpath prifixpath based on Department
     * @throws Exception
     *             throws while creating inDoc of API
     */
    public String getprefixpath(YFSEnvironment env, String sDept)
            throws Exception {

        LOG_CAT.debug("call to getPrefixpath Info");
        String sPrefixpath = null;
        String sCodetemp = "<CommonCodeList><CommonCode CodeName=\"\" CodeType=\"POC_CAT_HIER_PREFIX\" CodeValue=\"\" OrganizationCode=\"\"/></CommonCodeList>";
        Document docCommonCodeindoc = XMLUtil.newDocument();
        Element eleCc = docCommonCodeindoc.createElement("CommonCode");
        docCommonCodeindoc.appendChild(eleCc);
        eleCc.setAttribute("CodeType",
                KohlsPOCConstant.STRING_CATEGORY_CODE_TYPE);
        eleCc.setAttribute("CodeValue", sDept);
        LOG_CAT.debug("Start of getCommonCodeList info");
        Document docCommonCodeoutdoc = this.invokeAPI(env,
                XMLUtil.getDocument(sCodetemp), "getCommonCodeList",
                docCommonCodeindoc);
        sPrefixpath = XMLUtil.getAttribute((Element) docCommonCodeoutdoc
                .getElementsByTagName("CommonCode").item(0), "CodeName");
        LOG_CAT.debug("get Prefixpath Info END...");
        return sPrefixpath;

    }

    /**
     * This method will getCategoryDetails and calls createCategoryHierarchy
     * method if needed
     * 
     * @param env
     *            YFSEnvironment
     * @param prifixpath
     *            prifixpath based on department
     * @param dept
     *            Department
     * @param clas
     *            Class
     * @param subclas
     *            SubClass
     * @param organizationCode
     *            OrganizationCode
     * @throws Exception
     *             thows on API call and creating indoc of API
     */
    public void getCategoryDetails(YFSEnvironment env, String sPrefixpath,
            String sDept, String sClass, String sSubclass,
            String sOrganizationCode, String category_Domain) throws Exception {

        LOG_CAT.debug("call to getCategory Details");
        String sCategoryPath = null;
        if (YFCCommon.isVoid(sPrefixpath)) {
            sCategoryPath = "/" + category_Domain + "/" + sDept + "/" + sDept
                    + "-" + sClass + "/" + sDept + "-" + sClass + "-"
                    + sSubclass;
        } else {
            sCategoryPath = "/" + category_Domain + "/" + sPrefixpath + "/"
                    + sDept + "/" + sDept + "-" + sClass + "/" + sDept + "-"
                    + sClass + "-" + sSubclass;
        }
        Document docIndocCategoryDetails = XMLUtil.newDocument();
        Element eleCategory = docIndocCategoryDetails.createElement("Category");
        docIndocCategoryDetails.appendChild(eleCategory);
        eleCategory.setAttribute("CategoryPath", sCategoryPath);
        eleCategory.setAttribute("OrganizationCode", sOrganizationCode);

        try {
            KOHLSBaseApi.invokeAPI(env, "getCategoryDetails",
                    docIndocCategoryDetails);
        } catch (Exception e) {
            YFSException es = (YFSException) e;
            if (es.getErrorDescription().equalsIgnoreCase("Category Not Found")) {
                LOG_CAT.debug("create CategoryHierarchy");
                this.createCategoryHierarchy(env, sPrefixpath, sDept, sClass,
                        sSubclass, sOrganizationCode, category_Domain);
            }
        }
    }

    /**
     * This method creates CategoryHierarchy
     * 
     * @param env
     *            YFSEnvironment
     * @param prefixpath
     *            based on department
     * @param dept
     *            Department
     * @param clas
     *            Class
     * @param subclas
     *            SubClass
     * @param orgcode
     *            OrganizationCode
     * @throws Exception
     *             throws when creating inDoc to API
     */
    public void createCategoryHierarchy(YFSEnvironment env, String sPrefixpath,
            String sDept, String sClass, String sSubclass, String sOrgcode,
            String category_Domain) throws Exception {

        LOG_CAT.debug("call to createCategoryHierarchy info");
        String sCatpath = null;
        if (YFCCommon.isVoid(sPrefixpath)) {
            sCatpath = "/" + category_Domain + "/" + sDept;
        } else {
            sCatpath = "/" + category_Domain + "/" + sPrefixpath + "/" + sDept;
        }
        Document docIndocCategory = XMLUtil.newDocument();
        Element eleCategoryList = docIndocCategory
                .createElement("CategoryList");
        docIndocCategory.appendChild(eleCategoryList);
        
        Element eleCategory = docIndocCategory.createElement("Category");
        eleCategoryList.appendChild(eleCategory);
        eleCategory.setAttribute("Action", "Manage");
        eleCategory.setAttribute("CategoryID", sDept);
        // eleCategory.setAttribute("ShortDescription", "Dept"+sDept);
        eleCategory.setAttribute("CategoryPath", sCatpath);
        eleCategory.setAttribute("CategoryDomain", category_Domain);
        eleCategory.setAttribute("IsClassification",
                KohlsPOCConstant.IS_CLASSIFICATION);
        eleCategory.setAttribute("OrganizationCode", sOrgcode);
        eleCategory.setAttribute("Status", KohlsPOCConstant.STATUS);
        
        Element eleClasscategory = docIndocCategory.createElement("Category");
        eleCategoryList.appendChild(eleClasscategory);
        eleClasscategory.setAttribute("Action", "Manage");
        eleClasscategory.setAttribute("CategoryID", sDept + "-" + sClass);
        // eleClasscategory.setAttribute("ShortDescription", "Class" + sClass);
        eleClasscategory.setAttribute("CategoryPath", sCatpath + "/" + sDept
                + "-" + sClass);
        eleClasscategory.setAttribute("CategoryDomain", category_Domain);
        eleClasscategory.setAttribute("IsClassification",
                KohlsPOCConstant.IS_CLASSIFICATION);
        eleClasscategory.setAttribute("OrganizationCode", sOrgcode);
        eleClasscategory.setAttribute("Status", KohlsPOCConstant.STATUS);
        
        Element eleSubclasscategory = docIndocCategory
                .createElement("Category");
        eleCategoryList.appendChild(eleSubclasscategory);
        eleSubclasscategory.setAttribute("Action", "Manage");
        eleSubclasscategory.setAttribute("CategoryID", sDept + "-" + sClass
                + "-" + sSubclass);
        eleSubclasscategory.setAttribute("ShortDescription", sDept + "-"
                + sClass + "-" + sSubclass);
        eleSubclasscategory.setAttribute("CategoryPath", sCatpath + "/" + sDept
                + "-" + sClass + "/" + sDept + "-" + sClass + "-" + sSubclass);
        eleSubclasscategory.setAttribute("CategoryDomain", category_Domain);
        eleSubclasscategory.setAttribute("IsClassification",
                KohlsPOCConstant.IS_CLASSIFICATION);
        eleSubclasscategory.setAttribute("OrganizationCode", sOrgcode);
        eleSubclasscategory.setAttribute("Status", KohlsPOCConstant.STATUS);
        
        LOG_CAT.debug("create Category info...");
        KOHLSBaseApi.invokeAPI(env, "manageCategory", docIndocCategory);

    }
    
    /** PST-3116 start
     * This method will delete ItemAlias when ItemID and UPC is provided
     * 
     * @param env
     * @param inXML
     */
    public void deleteItemAlias(YFSEnvironment env,Document inXML){
    	
    	LOG_CAT.debug("itemCategoryHierarchy Start..."+XMLUtil.getXMLString(inXML));	
    	Element eleRoot = inXML.getDocumentElement();
    	 String sAction = XMLUtil.getAttribute(eleRoot, KohlsPOCConstant.A_ACTION);
    	 String sItemId = XMLUtil.getAttribute(eleRoot, KohlsPOCConstant.ATTR_ITEMID);
    	try {
    		
    		if (!YFCCommon.isVoid(inXML)) {
    			Element eleItemAliasList =  (Element) inXML.getElementsByTagName(KohlsPOCConstant.A_ITEM_ALIAS).item(0);
         		if(!YFCCommon.isVoid(eleItemAliasList)){
         			String isUPCExists = eleItemAliasList.getAttribute(KohlsPOCConstant.A_ALIAS_VALUE);
         			if(!YFCCommon.isVoid(sAction) && !YFCCommon.isVoid(isUPCExists)
         					&& KohlsPOCConstant.ACTION_DELETE.equalsIgnoreCase(sAction)){
    		
		    			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ITEMID, sItemId);
		    			eleRoot.setAttribute(KohlsPOCConstant.A_ORG_CODE, KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY);
		    			eleRoot.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, KohlsPOCConstant.UNIT_OF_MEASURE);
		    			LOG_CAT.debug("Input to getItemList ::"+XMLUtil.getXMLString(inXML));
		    			Document docOutdetail = this.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.ITEM_LIST_TEMP)
		    			,KohlsPOCConstant.API_GET_ITEM_LIST, inXML);
		    		
		    			if (!YFCCommon.isVoid(docOutdetail)) {
		    				Element eleItemAliasLst =  (Element) docOutdetail.getElementsByTagName(KohlsPOCConstant.A_ITEM_ALIAS_LIST).item(0);
		    				if (!YFCCommon.isVoid(eleItemAliasLst) && eleItemAliasLst.hasChildNodes()) {
		    					List<Element> aliasEleList = XMLUtil.getElementsByTagName(
		    							eleItemAliasLst, KohlsPOCConstant.A_ITEM_ALIAS);
		    					if (aliasEleList.size() > KohlsPOCConstant.ZERO_INT) {
		    		
		    						for (Element aliasEle : aliasEleList) {
		    							aliasEle.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.DELETE);
		    							LOG_CAT.debug("ouput..."+XMLUtil.getXMLString(docOutdetail));
		    						}
		    					}
		    						this.invokeAPI(env, "manageItem", docOutdetail);
		    				}
		    				
		    			}
         			}
         		}
    		}
    			
    	} catch (Exception e) {
    		LOG_CAT.debug("Error in deleteItemAlias");
    	}
    	
    	
    	//PST-3116 changes end
    }
    /**
     * Sets the properties
     * 
     * @param prop
     *            Properties that need to be set
     * @throws Exception
     *             when unable to set the Property
     */
    public void setProperties(Properties prop) throws Exception {

    }

    public String getPropertyValue(String property) {
        return YFSSystem.getProperty(property);

    }

}
