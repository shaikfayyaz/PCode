package com.kohls.poc.data.item;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : KohlsPoc ItemFeedDummySKUAPI.java Author : IBM Created : August 27
 * 2013 Modified : August 27 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This will create DummySKU Item when it is not there in the DataBase
 * 
 * @author Naveen Yalamanchili
 * @version 0.1
 *****************************************************************************/
public class ItemFeedDummySKUAPI extends KOHLSBaseApi implements YIFCustomApi {

    private static final YFCLogCategory LOG_CAT = YFCLogCategory
            .instance(ItemFeedDummySKUAPI.class.getName());

    /**
     * This method calls calmanItem method
     * 
     * @param YFSEnvironment
     *            env
     * @param Document
     *            reqDoc Read from the queue
     * @return Document reqDoc
     * @throws Exception
     *             throws while calling API and other scenarios
     */
    public Document itemFeedDummySKU(YFSEnvironment env, Document reqDoc)
            throws Exception {

        LOG_CAT.debug("start of itemFeedDummySKU info");
        Element eleRootEle = reqDoc.getDocumentElement();
        String sDept = XMLUtil.getAttribute(eleRootEle, "Dept");
        String sClass = XMLUtil.getAttribute(eleRootEle, "Class");
        String sSubclass = XMLUtil.getAttribute(eleRootEle, "SubClass");
        String sItemid = XMLUtil.getAttribute(eleRootEle, "ItemID");
        String sOrgcode = XMLUtil.getAttribute(eleRootEle, "OrganizationCode");
        String sUom = XMLUtil.getAttribute(eleRootEle, "UnitOfMeasure");
        String sDesc = XMLUtil.getAttribute(eleRootEle,
                "POCMerchandiseDescription");

        String sAttr = null;
        if (YFCCommon.isVoid(sOrgcode)) {
            sAttr = "OrganizationCode";
        } else if (YFCCommon.isVoid(sItemid)) {
            sAttr = "ItemID";
        } else if (YFCCommon.isVoid(sDept)) {
            sAttr = "Dept";
        } else if (YFCCommon.isVoid(sClass)) {
            sAttr = "Class";
        } else if (YFCCommon.isVoid(sSubclass)) {
            sAttr = "Subclass";
        } else if (YFCCommon.isVoid(sUom)) {
            sAttr = "UnitOfMeasure";
        }
		//Manoj 0415: Commented for the defect 3560
		/*else if (YFCCommon.isVoid(sDesc)) {
            sAttr = "POCMerchandiseDescription";
        }*/

        if (!YFCCommon.isVoid(sAttr)) {
            YFSException ex = new YFSException();
            ex.setErrorCode(KohlsPOCConstant.E_MANDATORY_FIELDS_MISSING);
            ex.setAttribute(sAttr, "");
            throw ex;
        }

        // 2014-05-16 : Modified for Defect 2618 : Start
        String sDeptForUpc = sDept;
        
        if (sDept.trim().length() < 3) {
            sDeptForUpc = StringUtils.leftPad(sDept, 3, '0');
        }

        // Item ID is supposed to be of format DDDSS000
        String sItemIDForDummySKU = sDeptForUpc + sSubclass + "000";
        // UPC is supposed to be of format 400DDDSS000C
        String sUPCForDummySKU = "400" + sItemIDForDummySKU;
        
        int checkDigit = KohlsUtil.checkDigitCreate(sUPCForDummySKU,
                KohlsPOCConstant.UPC_WEIGHT, KohlsPOCConstant.UPC_MOD,
                KohlsPOCConstant.PRODUCT_ADD);
        
       // Adding check-digit to create 12-digit UPC
        sUPCForDummySKU = sUPCForDummySKU + checkDigit;
        
        // 2014-05-16 : Modified for Defect 2618 : End
        
        Document docItemIndoc = XMLUtil.newDocument();
        Element eleItemRoot = docItemIndoc.createElement("Item");
        docItemIndoc.appendChild(eleItemRoot);
        eleItemRoot.setAttribute("ItemID", sItemIDForDummySKU);
        eleItemRoot.setAttribute("OrganizationCode", sOrgcode);
        eleItemRoot.setAttribute("UnitOfMeasure", sUom);

        try {
            LOG_CAT.debug("call getItemDetails info");
            KOHLSBaseApi.invokeAPI(env, "getItemDetails", docItemIndoc);
        } catch (Exception e) {
            YFSException es = (YFSException) e;
            if (es.getErrorDescription().equalsIgnoreCase("Item Not Found")) {
                LOG_CAT.debug("call manageItem info");
                calmanageItem(env, sItemIDForDummySKU, sDept, sClass, sSubclass,
                        sOrgcode, sUom, sDesc, sUPCForDummySKU);
            }
        }
        return reqDoc;

    }

    /**
     * This method will create manageItem inDoc with default values and calls
     * API
     * 
     * @param env
     *            YFSEnvironment
     * @param itemid
     *            ItemID
     * @param dept
     *            Department
     * @param clas
     *            Class
     * @param subclas
     *            SubClass
     * @param orgcode
     *            OrganizationCode
     * @param uom
     *            UnitOfMeasure
     * @param desc
     *            Description or AdditionalAttribute Value
     * @throws Exception
     *             throws when creating inDoc of manageItem API
     */
    public void calmanageItem(YFSEnvironment env, String sItemId, String sDept,
            String sClas, String sSubclas, String sOrgcode, String sUom,
            String sDesc, String sUPCForDummySKU) throws Exception {

        LOG_CAT.debug("start of manageItemAPI info");
        Document docIndocmanageItem = XMLUtil.newDocument();
        Element eleItemlist = docIndocmanageItem.createElement("ItemList");
        docIndocmanageItem.appendChild(eleItemlist);
        Element eleItem = docIndocmanageItem.createElement("Item");
        eleItemlist.appendChild(eleItem);
        eleItem.setAttribute("Action", "Manage");
        eleItem.setAttribute("ItemGroupCode", "PROD");
        eleItem.setAttribute("ItemID", sItemId);
        eleItem.setAttribute("OrganizationCode", sOrgcode);
        eleItem.setAttribute("UnitOfMeasure", sUom);
        Element elePinfo = docIndocmanageItem
                .createElement("PrimaryInformation");
        eleItem.appendChild(elePinfo);
        elePinfo.setAttribute("CostCurrency", KohlsPOCConstant.COST_CURRENCY);
        elePinfo.setAttribute("CreditWOReceipt",
                KohlsPOCConstant.CREDIT_WO_RECEIPT);
        elePinfo.setAttribute("IsReturnable", KohlsPOCConstant.IS_RETURNABLE);
        elePinfo.setAttribute("ReturnWindow", KohlsPOCConstant.RETURN_WINDOW);
        elePinfo.setAttribute("Status", KohlsPOCConstant.STATUS);
        elePinfo.setAttribute("TaxableFlag", KohlsPOCConstant.TAXABLE_FLAG);
        elePinfo.setAttribute("AllowGiftWrap", KohlsPOCConstant.ALLOW_GIFT_WRAP);
        elePinfo.setAttribute("isHazmat", KohlsPOCConstant.IS_HAZMAT);
        elePinfo.setAttribute("SerialReqdAtOrderCapture",
                KohlsPOCConstant.SERIAL_REQD_AT_ORDER_CAPTURE);
        elePinfo.setAttribute("QuantityReqdAtOrderCapture",
                KohlsPOCConstant.QUANTITY_REQD_AT_ORDER_CAPTURE);
        elePinfo.setAttribute("PriceReqdAtOrderCapture",
                KohlsPOCConstant.PRICE_REQD_AT_ORDER_CAPTURE);
        elePinfo.setAttribute("NotForSaleAtOrderCapture",
                KohlsPOCConstant.NOT_FOR_SALE_AT_ORDER_CAPTURE);
        elePinfo.setAttribute("IsTemplateItem",
                KohlsPOCConstant.IS_TEMPLATE_ITEM);
        elePinfo.setAttribute("UnitCost", KohlsPOCConstant.UNIT_COST);
        elePinfo.setAttribute("MinimumAgeReqdToBuy",
                KohlsPOCConstant.MINIMUM_AGE_REQD_TO_BUY);
        elePinfo.setAttribute("SalespersonIdReqdAtOrderCapture",
                KohlsPOCConstant.SALES_PERSON_ID_REQD_AT_ORDER_CAPTURE);
        elePinfo.setAttribute("PriceOverrideAllowed",
                KohlsPOCConstant.PRICE_OVERRIDE_ALLOWED);
        Element eleClascod = docIndocmanageItem
                .createElement("ClassificationCodes");
        eleItem.appendChild(eleClascod);
        eleClascod.setAttribute("TaxProductCode",
                KohlsPOCConstant.TAX_PRODUCT_CODE);
        Element eleExt = docIndocmanageItem.createElement("Extn");
        eleItem.appendChild(eleExt);
        eleExt.setAttribute("ExtnBreakable", KohlsPOCConstant.EXTN_BREAKABLE);
        eleExt.setAttribute("ExtnCageItem", KohlsPOCConstant.EXTN_CAGE_ITEM);
        eleExt.setAttribute("ExtnClass", sClas);
        eleExt.setAttribute("ExtnDept", sDept);
        eleExt.setAttribute("ExtnDirectShipItem",
                KohlsPOCConstant.EXTN_DIRECT_SHIP_ITEM);
        eleExt.setAttribute("ExtnIsPlasticGiftCard",
                KohlsPOCConstant.EXTN_IS_PLASTIC_GIFT_CARD);
        eleExt.setAttribute("ExtnIsVirtualGiftCard",
                KohlsPOCConstant.EXTN_IS_VIRTUAL_GIFT_CARD);
        eleExt.setAttribute("ExtnShipAlone", KohlsPOCConstant.EXTN_SHIP_ALONE);
        eleExt.setAttribute("ExtnSubClass", sSubclas);
        eleExt.setAttribute("ExtnBaggable", KohlsPOCConstant.EXTN_BAGGABLE);
        eleExt.setAttribute("ExtnDeptClassSubClass", sDept + "|" + sClas + "|"
                + sSubclas);
        eleExt.setAttribute("ExtnMerchandiseTaxCode",
                KohlsPOCConstant.EXTN_MERCHANDISE_TAX_CODE);
                
        //Defect 1701 : Added PMDM gap attributes to extn element - Start
        LOG_CAT.debug("Setting PMDM gap attributes");
        eleExt.setAttribute("ExtnWebItem",KohlsPOCConstant.NO);
        eleExt.setAttribute("ExtnEmpDiscCode",KohlsPOCConstant.NO);
        
       // Defect 1701 : Added PMDM gap attributes to extn element - End
        Element eleItemAlist = docIndocmanageItem
                .createElement("ItemAliasList");
        eleItem.appendChild(eleItemAlist);
        Element eleItemAlias = docIndocmanageItem.createElement("ItemAlias");
        eleItemAlist.appendChild(eleItemAlias);
        eleItemAlias.setAttribute("Action", "Modify");
        eleItemAlias.setAttribute("AliasName", KohlsPOCConstant.ALIAS_NAME);
        eleItemAlias.setAttribute("AliasValue", sUPCForDummySKU);
        Element eleAttList = docIndocmanageItem
                .createElement("AdditionalAttributeList");
        eleItem.appendChild(eleAttList);
        Element eleAatt = docIndocmanageItem
                .createElement("AdditionalAttribute");
        eleAttList.appendChild(eleAatt);
        eleAatt.setAttribute("AttributeDomainID", "ItemAttribute");
        eleAatt.setAttribute("AttributeGroupID", "POCAttributes");
        eleAatt.setAttribute("Operation", "Manage");
        eleAatt.setAttribute("Name", "POCMerchandiseDescription");
        eleAatt.setAttribute("Value", sDesc);
        eleAatt.setAttribute("ParentTable", "YFS_ITEM");
        LOG_CAT.debug("call to manageItem info");
//        System.out.println(XMLUtil.getXMLString(docIndocmanageItem));
	LOG_CAT.debug(XMLUtil.getXMLString(docIndocmanageItem));
        KOHLSBaseApi.invokeAPI(env, "manageItem", docIndocmanageItem);

    }
}
