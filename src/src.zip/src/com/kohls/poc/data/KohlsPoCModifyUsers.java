package com.kohls.poc.data;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.custom.util.xml.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCModifyUsers  extends KOHLSBaseApi {

	private static final YFCLogCategory 
	loggerForModifyUser = YFCLogCategory
	.instance(KohlsPoCModifyUsers.class.getName());
	
	/**
 	 * This function retrieves the user list  
 	 * for the User from the input XML and modifies the same user list with the new user group.
 	 * 
 	 * @param env
 	 * @param InputUserGroupID
 	 * @return returnDoc
 	 *           
 	 */	
	
	public Document ModifyUserGroup(YFSEnvironment env, Document InputUserGroupID)
	{	
		//<UserGroup GroupID="POS_TEMP_MANAGERS" />
		Element eleUser = InputUserGroupID.getDocumentElement();
		String strGroupID = eleUser.getAttribute("GroupID");
		int n = 0;
		Document docModifyUserListInput = null;
		Document returnDoc = null;
		loggerForModifyUser.debug("KohlsPoCModifyUsers.getUserList -- BEGIN");
		Document docGetUserListOutput = null;
		try {
			//Create Input XML for getUserList
			Document docGetUserListInput = XMLUtil.createDocument("User"); 
			Element EleGetUserListInput = docGetUserListInput.getDocumentElement();
			Element eleUserGroupLists = docGetUserListInput.createElement("UserGroupLists");
			EleGetUserListInput.appendChild(eleUserGroupLists);
			Element eleUserGroupList = docGetUserListInput.createElement("UserGroupList");
			eleUserGroupLists.appendChild(eleUserGroupList);
			eleUserGroupList.setAttribute("UsergroupKey", "POS_MANAGERS");
			//<User><UserGroupLists><UserGroupList UsergroupKey='POS_MANAGERS' /></UserGroupLists></User>
			//Create template XML for getUserList
			//<UserList TotalNumberOfRecords=""><User UserKey='' OrganizationKey'' /></UserList>
			Document docGetUserListTemp = XMLUtil.createDocument("UserList"); 
			Element EleGetUserListTemp = docGetUserListTemp.getDocumentElement();
			EleGetUserListTemp.setAttribute("TotalNumberOfRecords", "");
			Element eleUserTemp = docGetUserListTemp.createElement("User");
			EleGetUserListTemp.appendChild(eleUserTemp);
			eleUserTemp.setAttribute("UserKey", "");
			eleUserTemp.setAttribute("OrganizationKey", "");
			
			//Call getUserList API
			docGetUserListOutput = KohlsPoCModifyUsers.invokeAPI(env,docGetUserListTemp, KohlsPOCConstant.API_GET_USER_LIST, docGetUserListInput);
			
			loggerForModifyUser.debug("KohlsPoCModifyUsers.getUserList -- END");
			
			loggerForModifyUser.debug("KohlsPoCModifyUsers.ModifyUserHierarchy -- BEGIN");
			/*<User UserKey="" DataSecurityGroupId="SALES"> 
			<UserGroupLists>
			<UserGroupList UsergroupId="POS_TEMP_MANAGER"/>
			</UserGroupLists>
			</User>*/
			
			/*<User DataSecurityGroupId="SALES" OrganizationKey="9954" UserKey="1114120501480958238081">
    			<UserGroupLists>
    			<UserGroupList UsergroupId="POS_TEMP_MANAGERS" UsergroupKey="2016040105481272573002" />
				</UserGroupLists>
			 </User>*/
			NodeList nl = docGetUserListOutput.getElementsByTagName("User");
			for(int i =0;i<nl.getLength();i++){
				Element ele = (Element) nl.item(i);
				if(!YFCCommon.isVoid(ele.getAttribute("OrganizationKey")) && !ele.getAttribute("OrganizationKey").equalsIgnoreCase("STORE-US-00001")){
				docModifyUserListInput = XMLUtil.createDocument("User");
				Element EleModifyUserListInput = docModifyUserListInput.getDocumentElement();
				EleModifyUserListInput.setAttribute("UserKey", ele.getAttribute("UserKey"));
				EleModifyUserListInput.setAttribute("OrganizationKey", ele.getAttribute("OrganizationKey"));
				EleModifyUserListInput.setAttribute("DataSecurityGroupId", "SALES");
				Element eleUserGroupLists1 = docModifyUserListInput.createElement("UserGroupLists");
				EleModifyUserListInput.appendChild(eleUserGroupLists1);
				Element eleUserGroupLists2 = docModifyUserListInput.createElement("UserGroupList");
				eleUserGroupLists1.appendChild(eleUserGroupLists2);
				eleUserGroupLists2.setAttribute("UsergroupId", strGroupID);
				KohlsPoCModifyUsers.invokeAPI(env, KohlsPOCConstant.API_MODIFY_USER_HIERARCHY, docModifyUserListInput);
				n++;
				}
			}
			 returnDoc = XMLUtil.createDocument("Users");
			 Element returnEle = returnDoc.getDocumentElement();
			 returnEle.setAttribute("TotalNoOfRecordsUpdated", String.valueOf(n));
			 
			 
			 if(loggerForModifyUser.isDebugEnabled())
				 loggerForModifyUser.debug("The return doc value is :" +XMLUtil.getXMLString(returnDoc));
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			 if (e instanceof YFSException) {
				YFSException yfsException = (YFSException) e;
				throw yfsException;
			 }			
		}	
		
		loggerForModifyUser.debug("KohlsPoCModifyUsers.ModifyUserHierarchy -- END");
		return returnDoc;
		
	}
		
}
