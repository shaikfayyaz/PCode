package com.kohls.poc.inventory.ue;

import com.kohls.common.util.*;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


import javax.xml.parsers.ParserConfigurationException;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.HashMap;

/**
 * This class contains methods which modify the request to GetInventoryAvailabilitySyncService and response from
 * GetInventoryAvailabilitySyncService. The getExternalAvailabilityUE Input will be modified to request for
 * GetInventoryAvailabilitySyncService. The response from GetInventoryAvailabilitySyncService will be modified to output
 * from getExternalAvailabilityUE.
 */
public class KohlsPoCInventoryAvailabilityHandler {

    private static YFCLogCategory logger;
    static {
        logger = YFCLogCategory.instance(KohlsPoCInventoryAvailabilityHandler.class.getName());
    }

    /**
     * This method gets input to GetInventoryAvailabilityUE Input and modifies the input to form expected by
     * GetInventoryAvailabilitySyncService
     * @param env
     * @param inDoc
     * @return
     * @throws YFSException
     */

    public Document prepareRequestToGIV(YFSEnvironment env, Document inDoc) throws YFSException{

        //Initializing the variables
        Document docInGetInvAvailability = null;
        Element eleRoot = null;
        Element elePromise = null;
        Element elePromiseLine = null;
        String strDistanceToConsiderUOM = null;

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to prepareRequestToGIV : \n" + XMLUtil.getXMLString(inDoc));
        }

        try {
            //Get the element Promise
            elePromise = inDoc.getDocumentElement();
            docInGetInvAvailability = KohlsXMLUtil.createDocument(KohlsPOCConstant.A_GET_AVAILABILITY);
            eleRoot = docInGetInvAvailability.getDocumentElement();
            //Set attributes at GetAvailability
            eleRoot.setAttribute(KohlsConstants.DISTANCE_TO_CONSIDER, elePromise.getAttribute(
                    KohlsConstants.DISTANCE_TO_CONSIDER));
            strDistanceToConsiderUOM = elePromise.getAttribute(KohlsConstants.DISTANCE_TO_CONSIDER_UOM);
            if(!YFCCommon.isVoid(strDistanceToConsiderUOM)) {
                eleRoot.setAttribute(KohlsConstants.DISTANCE_TO_CONSIDER_UOM, strDistanceToConsiderUOM);
            } else {
                eleRoot.setAttribute(KohlsConstants.DISTANCE_TO_CONSIDER_UOM, KohlsConstants.MILE);
            }

            eleRoot.setAttribute(KohlsPOCConstant.A_EXTN_IS_ATG_REQ, KohlsPOCConstant.YES);
            eleRoot.setAttribute(KohlsPOCConstant.A_IS_STORE_PICKUP, KohlsPOCConstant.YES);
            eleRoot.setAttribute(KohlsPOCConstant.A_ONLY_ATS_REQ, KohlsPOCConstant.YES);
            eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, elePromise.getAttribute(
                    KohlsPOCConstant.A_ENTERPRISE_CODE));
            eleRoot.setAttribute(KohlsPOCConstant.A_REAL_TIME,KohlsPOCConstant.YES);

            /* OIC Integration - Stamp InventorySourceSystem as OIC if OIC integration is enabled else SIS */
            String strIsOICEnabled = checkIfOICIsEnabled(env);
            if(KohlsPOCConstant.YES.equalsIgnoreCase(strIsOICEnabled)) {
                eleRoot.setAttribute(KohlsPOCConstant.INVENTORY_SOURCE_SYSTEM, KohlsPOCConstant.A_OIC);
            } else {
                eleRoot.setAttribute(KohlsPOCConstant.INVENTORY_SOURCE_SYSTEM, KohlsPOCConstant.A_SIS);
            }

            setMonitorAvailabilityElement(env, docInGetInvAvailability, eleRoot, elePromise);

            if (logger.isDebugEnabled()) {
                logger.debug("The output XML from prepareRequestToGIV : \n" + XMLUtil.getXMLString(docInGetInvAvailability));
            }

            return docInGetInvAvailability;

        } catch(ParserConfigurationException exception) {
            throw new YFSException(exception.getMessage());
        } catch (RemoteException e) {
            throw  new YFSException(e.getMessage());
        } catch (YIFClientCreationException e) {
            throw  new YFSException(e.getMessage());
        }
    }

    /**
     * This method stamps the GetAvailability/MonitorItemAvailabilityList element
     * @param docInGetInvAvailability
     * @param eleRoot
     * @param elePromise
     */
    private void setMonitorAvailabilityElement(YFSEnvironment env, Document docInGetInvAvailability, Element eleRoot, Element elePromise) {
        /* Initialize Variable*/
        Element eleMonitorItemAvailabilityList = null;
        Element eleMonitorItemAvailability = null;
        Element eleShipToAddress = null;
        Element elePersonInfoShipTo = null;
        Element elePromiseLine = null;

         /* Get element Promise/PromiseLines/PromiseLine */
        elePromiseLine = KohlsXMLUtil.getChildElement(KohlsXMLUtil.getChildElement(elePromise,
                KohlsConstants.PROMISE_LINES), KohlsConstants.PROMISE_LINE);
        String  strTxnObj = elePromiseLine.getAttribute(KohlsConstants.LINE_ID) + KohlsPOCConstant.E_PIPE_SYMBOL +
                elePromise.getAttribute(KohlsConstants.DISTANCE_TO_CONSIDER) + KohlsPOCConstant.E_PIPE_SYMBOL +
                elePromise.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);

        env.setTxnObject(KohlsPOCConstant.GIV_LINEID, strTxnObj);

         /* Append GetAvailability/MonitorItemAvailabilityList */
        eleMonitorItemAvailabilityList = KohlsXMLUtil.createElement(docInGetInvAvailability,
                KohlsPOCConstant.A_MONITOR_ITEM_AVAILABILITY_LIST,KohlsPOCConstant.BLANK);
        KohlsXMLUtil.appendChild(eleRoot, eleMonitorItemAvailabilityList);

            /* Append GetAvailability/MonitorItemAvailabilityList/MonitorItemAvailability */
        eleMonitorItemAvailability = KohlsXMLUtil.createElement(docInGetInvAvailability,
                KohlsPOCConstant.A_MONITOR_ITEM_AVAILABILITY,KohlsPOCConstant.BLANK);
        eleMonitorItemAvailability.setAttribute(KohlsPOCConstant.A_ITEM_ID,
                elePromiseLine.getAttribute(KohlsPOCConstant.A_ITEM_ID));
        eleMonitorItemAvailability.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
                KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY);
        eleMonitorItemAvailability.setAttribute(KohlsPOCConstant.A_PRODUCT_CLASS, KohlsPOCConstant.PRODUCT_CLASS_GOOD);
        eleMonitorItemAvailability.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE,
                elePromiseLine.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE));
        KohlsXMLUtil.appendChild(eleMonitorItemAvailabilityList, eleMonitorItemAvailability);

            /* Get element Promise/PromiseLines/PromiseLine/ShipToAddress */
        elePersonInfoShipTo = KohlsXMLUtil.getChildElement(elePromiseLine, KohlsConstants.SHIP_TO_ADDRESS);

            /* Append GetAvailability/ShipToAddress */
        eleShipToAddress = KohlsXMLUtil.createElement(docInGetInvAvailability,
                KohlsConstants.SHIP_TO_ADDRESS,KohlsPOCConstant.BLANK);
        eleShipToAddress.setAttribute(KohlsPOCConstant.ATTR_COUNTRY, elePersonInfoShipTo.getAttribute(
                KohlsPOCConstant.ATTR_COUNTRY));
        eleShipToAddress.setAttribute(KohlsPOCConstant.A_ZIP_CODE, elePersonInfoShipTo.getAttribute(
                KohlsPOCConstant.A_ZIP_CODE));
        KohlsXMLUtil.appendChild(eleRoot, eleShipToAddress);

    }

    /**
     * This method get the response from GetInventoryAvailabilitySyncService as input and
     * modifies the input to GetInventoryAvailabilityUE Output.
     * @param env
     * @param inDoc
     * @return
     * @throws YFSException
     */

    public Document prepareResponseFromGIV(YFSEnvironment env, Document inDoc) throws YFSException{

        /* Initialize the variable */
        Document docExtAvailabilityOut = null;
        Element eleInRoot = null;
        Element eleOutPromise = null;
        Element eleOutSuggestedOption = null;
        Element eleShipNodeList = null;
        NodeList nlShipNode = null;
        String strDateTime = null;
        String strLineId = null;

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to prepareResponseFromGIV : \n" + XMLUtil.getXMLString(inDoc));
        }

        try {

            /* Get the ShipNodes from input document */
            eleInRoot = inDoc.getDocumentElement();

            /* If GIV returns an error throw the error object */
            if(KohlsPOCConstant.E_ERRORS.equalsIgnoreCase(eleInRoot.getNodeName())) {
                Element eleError = KohlsXMLUtil.getChildElement(eleInRoot, KohlsPOCConstant.E_ERROR);
                YFSException yfsException = new YFSException();
                yfsException.setErrorCode(eleError.getAttribute(KohlsPOCConstant.A_ERROR_CODE));
                yfsException.setErrorDescription(eleError.getAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION));
                throw yfsException;
            }
            eleShipNodeList = KohlsXMLUtil.getChildElement(eleInRoot, KohlsConstant.SHIP_NODE_LIST);

            /* Prepare output document */
            docExtAvailabilityOut = KohlsXMLUtil.createDocument(KohlsConstant.PROMISE_ELEMENT);
            eleOutPromise = docExtAvailabilityOut.getDocumentElement();

            String strTxnObj = (String) env.getTxnObject(KohlsPOCConstant.GIV_LINEID);
            strLineId = strTxnObj.split(KohlsPOCConstant.DelimitedSlash)[0];
            String strDistance = strTxnObj.split(KohlsPOCConstant.DelimitedSlash)[1];
            String strOrgCode = strTxnObj.split(KohlsPOCConstant.DelimitedSlash)[2];

            /* Set Attributes to Promise */
            eleOutPromise.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
            eleOutPromise.setAttribute(KohlsPOCConstant.A_ALLOCATION_RULE_ID, KohlsPOCConstant.A_SYSTEM);
            eleOutPromise.setAttribute(KohlsPOCConstant.A_CHECK_INVENTORY, KohlsPOCConstant.YES);
            eleOutPromise.setAttribute(KohlsConstants.DISTANCE_TO_CONSIDER, strDistance);
            eleOutPromise.setAttribute(KohlsConstants.DISTANCE_TO_CONSIDER_UOM, KohlsConstants.MILE);
            eleOutPromise.setAttribute(KohlsPOCConstant.A_OPTIMIZATION_TYPE, KohlsPOCConstant.A_OPTIMIZATION_TYPE_01);


            /* Set element SuggestedOption at Promise in output document */
            eleOutSuggestedOption = KohlsXMLUtil.createElement(docExtAvailabilityOut,
                    KohlsPOCConstant.ELE_SUGGESTED_OPTION, KohlsPOCConstant.BLANK);
            KohlsXMLUtil.appendChild(eleOutPromise, eleOutSuggestedOption);

            /* get Current Date */
            strDateTime = KohlsDateUtil.getCurrentDateTime(KohlsConstants.STERLING_TS_FORMAT);

            if(!YFCCommon.isVoid(eleShipNodeList)) {
                nlShipNode = eleShipNodeList.getElementsByTagName(KohlsPOCConstant.A_SHIP_NODE);
            }

            if(!YFCCommon.isVoid(nlShipNode)) {

                stampShipNodeDetails(env,docExtAvailabilityOut, strOrgCode, nlShipNode, strLineId, strDateTime,
                        eleOutSuggestedOption, eleOutPromise);
            }

        } catch (ParserConfigurationException exception) {
            throw new YFSException(exception.getMessage());
        } catch (YFSException exception) {
            throw new YFSException(exception.getMessage());
        } catch (Exception exception) {
            throw new YFSException(exception.getMessage());
        }

        if (logger.isDebugEnabled()) {
            logger.debug("The output XML from prepareResponseFromGIV : \n" + XMLUtil.getXMLString(docExtAvailabilityOut));
        }

        return docExtAvailabilityOut;
    }

    private void stampShipNodeDetails(YFSEnvironment env,Document docExtAvailabilityOut, String strOrgCode,
                                      NodeList nlShipNode,String strLineId,String strDateTime, Element eleOutSuggestedOption,
                                      Element eleOutPromise) throws Exception {
        {
            /* Initialize variables */
            Element eleOutOption = null;
            Element eleOutPromiseLines = null;
            Element eleOutPromiseLine = null;
            Element eleOutAssignments = null;

            /* Set element Option at Promise/SuggestedOption in output document */
            eleOutOption = KohlsXMLUtil.createElement(docExtAvailabilityOut, KohlsPOCConstant.ELE_OPTION,
                    KohlsPOCConstant.BLANK);
            eleOutOption.setAttribute(KohlsPOCConstant.A_HAS_ANY_UNAVAILABLEQTY, KohlsPOCConstant.YES);
            eleOutOption.setAttribute(KohlsConstants.OPTION_NO, KohlsPOCConstant.STRING_ONE);

                /* Set element PromiseLines at Promise/SuggestedOption/Option in output document */
            eleOutPromiseLines = KohlsXMLUtil.createElement(docExtAvailabilityOut, KohlsConstants.PROMISE_LINES,
                    KohlsPOCConstant.BLANK);

                /* Set element PromiseLine at Promise/SuggestedOption/PromiseLines/Option/PromiseLines in output document */
            eleOutPromiseLine = KohlsXMLUtil.createElement(docExtAvailabilityOut, KohlsConstants.PROMISE_LINE,
                    KohlsPOCConstant.BLANK);
            eleOutPromiseLine.setAttribute(KohlsPOCConstant.ATTR_FULFILLMENT_TYPE, KohlsConstants.PRODUCTSOURCING);
            eleOutPromiseLine.setAttribute(KohlsPOCConstant.A_REQUIRED_QTY, KohlsPOCConstant.NINE_DOUBLE);
            eleOutPromiseLine.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, KohlsConstants.EACH);
            eleOutPromiseLine.setAttribute(KohlsConstants.LINE_ID, strLineId);

                /* Set element Assignments at Promise/SuggestedOption/PromiseLines/Option
                /PromiseLines/PromiseLine in output document */
            eleOutAssignments = KohlsXMLUtil.createElement(docExtAvailabilityOut, KohlsPOCConstant.ELE_ASSIGNMENTS,
                    KohlsPOCConstant.BLANK);

            String strTemp = stampAssignments(env, nlShipNode, eleOutAssignments, docExtAvailabilityOut, strDateTime,
                    strOrgCode);
            String strItemID = strTemp.split(KohlsPOCConstant.DelimitedSlash) [0];
            String strIsUnAvailable = strTemp.split(KohlsPOCConstant.DelimitedSlash) [1];
            eleOutPromiseLine.setAttribute(KohlsPOCConstant.ATTR_ITEMID, strItemID);
            eleOutOption.setAttribute(KohlsPOCConstant.A_HAS_ANY_UNAVAILABLEQTY, strIsUnAvailable);

            if(KohlsPOCConstant.YES.equalsIgnoreCase(strIsUnAvailable)) {
                Element eleUnavailableLines = KohlsXMLUtil.createElement(docExtAvailabilityOut,
                        KohlsPOCConstant.ELE_UNAVAILABLE_LINES, KohlsPOCConstant.BLANK);
                Element eleUnavailableLine = KohlsXMLUtil.createElement(docExtAvailabilityOut,
                        KohlsPOCConstant.ELE_UNAVAILABLE_LINE, KohlsPOCConstant.BLANK);
                eleUnavailableLine.setAttribute(KohlsPOCConstant.A_ITEM_GROUP_CODE, KohlsPOCConstant.V_PROD);
                eleUnavailableLine.setAttribute(KohlsPOCConstant.ATTR_ITEMID, strItemID);
                eleUnavailableLine.setAttribute(KohlsPOCConstant.A_UNAVAILABLE_REASON,
                        KohlsPOCConstant.NOT_ENOUGH_PRODUCT_CHOICES);
                eleUnavailableLine.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, KohlsConstants.EACH);
                eleUnavailableLine.setAttribute(KohlsConstants.LINE_ID, strLineId);
                KohlsXMLUtil.appendChild(eleUnavailableLines,eleUnavailableLine);
                KohlsXMLUtil.appendChild(eleOutSuggestedOption, eleUnavailableLines);
            }
            KohlsXMLUtil.appendChild(eleOutPromiseLine, eleOutAssignments);
            KohlsXMLUtil.appendChild(eleOutPromiseLines, eleOutPromiseLine);
            KohlsXMLUtil.appendChild(eleOutOption, eleOutPromiseLines);
            KohlsXMLUtil.appendChild(eleOutSuggestedOption, eleOutOption);
            KohlsXMLUtil.appendChild(eleOutPromise, eleOutSuggestedOption);
        }
    }

    /**
     * This method stamps the inventory assignments in getExternalAvailability UE output document.
     * @param env
     * @param nlShipNode
     * @param eleAssignments
     * @param inDoc
     * @param strDateTime
     * @return
     * @throws ParserConfigurationException
     * @throws RemoteException
     */

    private String stampAssignments(YFSEnvironment env, NodeList nlShipNode, Element eleAssignments, Document inDoc,
                                    String strDateTime, String strOrgCode) throws Exception {
        String strItemID = null;
        String strShipNode = null;
        String strOnClearance = KohlsPOCConstant.NO;
        String strIsOmniPick = KohlsPOCConstant.NO;
        String strIsSellingStore = KohlsPOCConstant.NO;
        HashMap<String, String> hmOmniBipaasRule = new HashMap<>();
        int iCount = nlShipNode.getLength();
        String bUnavailabeQty = KohlsPOCConstant.NO;
        boolean bIsFirstCall = true;
        boolean bIsGCorVGC = false;

        String strDate = KohlsDateUtil.getCurrentDateTime(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);

        /* Get the OMNI_BIPAAS rule list for all stores */
        hmOmniBipaasRule = checkIfOmniPickIsEnabled(env);

        //Removing the left padded zeros
        String formattedStrOrgCode = StringUtils.stripStart(strOrgCode, KohlsConstant.ZERO_INT);

        /* Check if KOHLS-RETAIL is enabled or Store is present in the Rule List*/

        if(!YFCCommon.isVoid(hmOmniBipaasRule) &&  (hmOmniBipaasRule.containsKey(formattedStrOrgCode) && KohlsPOCConstant.YES.equals(hmOmniBipaasRule.get(formattedStrOrgCode)))) {
            strIsSellingStore = KohlsPOCConstant.YES;
        }
        else if ( !YFCCommon.isVoid( hmOmniBipaasRule ) && ( !hmOmniBipaasRule.containsKey( formattedStrOrgCode ) ) )
        {
           // Retrieve the value from retail, in case the store value is revoked.
           strIsSellingStore = hmOmniBipaasRule.get( KohlsPOCConstant.KOHLS_RETAIL );
        }
        /* Loop through each ShipNode in the ShipNodeList */
        for(int i=0; i < iCount; i++) {
            strIsOmniPick = KohlsPOCConstant.NO;
            Element eleInShipNode = (Element) nlShipNode.item(i);
            Element eleInventoryAlerts = KohlsXMLUtil.getChildElement(eleInShipNode, KohlsPOCConstant.A_INVENTORY_ALERTS);
            Element eleInventoryAlert = KohlsXMLUtil.getChildElement(eleInventoryAlerts, KohlsPOCConstant.A_INVENTORY_ALERT);
            String strQty = eleInventoryAlert.getAttribute(KohlsPOCConstant.A_ONHAND_AVAILABLE_QTY);

            strShipNode = eleInventoryAlert.getAttribute(KohlsPOCConstant.A_NODE);

            Element eleAssignment = KohlsXMLUtil.createElement(inDoc, KohlsPOCConstant.ELE_ASSIGNMENT,
                    KohlsPOCConstant.BLANK);
            eleAssignment.setAttribute(KohlsPOCConstant.A_QUANTITY, strQty);
            eleAssignment.setAttribute(KohlsConstant.ATTR_SHIP_NODE, strShipNode);

            if (0 == Double.parseDouble(strQty)) {
                bUnavailabeQty = KohlsPOCConstant.YES;
                eleAssignment.setAttribute(KohlsPOCConstant.A_EMPTY_ASSIGNMENT_REASON, KohlsPOCConstant.NOT_ENOUGH_PRODUCT_CHOICES);
            } else {
                eleAssignment.setAttribute(KohlsConstants.DISTANCE, eleInShipNode.getAttribute(
                        KohlsPOCConstant.A_DISTANCE_FROM_SHIP_TO_ADDR));
                eleAssignment.setAttribute(KohlsPOCConstant.A_EXTERNAL_NODE, KohlsPOCConstant.YES);
                eleAssignment.setAttribute(KohlsPOCConstant.A_PROD_AVAIL_DATE, strDate);
                eleAssignment.setAttribute(KohlsPOCConstant.A_DELIVERY_DATE, strDateTime);
            }
            strItemID = eleInventoryAlert.getAttribute(KohlsPOCConstant.ATTR_ITEMID);

            //Invoke checkifItemIsVGCorGC to check if the item is a GC or VGC item
            if(bIsFirstCall) {
                bIsGCorVGC = checkifItemIsGCorVGC(env, strItemID);
                bIsFirstCall = false;
            }

            // Check if OnClearance Flag is set
            strOnClearance = eleInventoryAlert.getAttribute(KohlsPOCConstant.A_ON_CLEARANCE);

            if(KohlsPOCConstant.YES.equals(strOnClearance) || bIsGCorVGC || strOrgCode.equalsIgnoreCase(strShipNode)) {
                eleAssignment.setAttribute(KohlsPOCConstant.A_AVAIL_FROM_UNPLANNED_INV, KohlsPOCConstant.YES);
            } else {
                // Check if OMNI PICK is enabled for the store
                if ( !YFCCommon.isVoid( hmOmniBipaasRule ) && hmOmniBipaasRule.containsKey( strShipNode ) && KohlsPOCConstant.YES.equals( hmOmniBipaasRule.get( strShipNode ) ) )
                {
                    strIsOmniPick = KohlsPOCConstant.YES;
                }
                else if ( !YFCCommon.isVoid( hmOmniBipaasRule ) && !hmOmniBipaasRule.containsKey( strShipNode ) && !formattedStrOrgCode.equals(strShipNode))
                {
                   // Retrieve the value from retail, in case the store value is revoked.
                   strIsOmniPick = hmOmniBipaasRule.get( KohlsPOCConstant.KOHLS_RETAIL );
                }
                if(KohlsPOCConstant.NO.equals(strIsOmniPick) || KohlsPOCConstant.NO.equals(strIsSellingStore)) {
                    eleAssignment.setAttribute(KohlsPOCConstant.A_AVAIL_FROM_UNPLANNED_INV, KohlsPOCConstant.YES);
                } else {
                    eleAssignment.setAttribute(KohlsPOCConstant.A_AVAIL_FROM_UNPLANNED_INV, KohlsPOCConstant.NO);
                }
            }

            KohlsXMLUtil.appendChild(eleAssignments, eleAssignment);
        }

        return strItemID + KohlsPOCConstant.E_PIPE_SYMBOL + bUnavailabeQty;
    }

    /**
     * This method invokes getRuleListForPOS API to check if OMNIBag PICK is enabled
     * for a particular Store.
     * @param env
     * @return
     * @throws ParserConfigurationException
     * @throws RemoteException
     */

    private HashMap<String, String> checkIfOmniPickIsEnabled(YFSEnvironment env)
            throws Exception {
        Document docInGetRuleList = null;
        Document docOutGetRuleList = null;
        int iCount = 0;
        Element eleRule = null;
        //String strRuleValue = KohlsPOCConstant.NO;
        HashMap<String, String> hmOmniBipaasMap = new HashMap<>();

        /* Prepare input to getRuleListForPOS API */
        docInGetRuleList = KohlsXMLUtil.createDocument(KohlsPOCConstant.E_RULE);
        eleRule = docInGetRuleList.getDocumentElement();
        //eleRule.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strShipNode);
        eleRule.setAttribute(KohlsPOCConstant.A_RULE_ID, KohlsPOCConstant.OMNI_BIPAAS);

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to getRuleListForPOS : \n" + XMLUtil.getXMLString(docInGetRuleList));
        }

        /* Invoke getRuleListForPOS API */
        docOutGetRuleList = KOHLSBaseApi.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInGetRuleList);

        if (logger.isDebugEnabled()) {
            logger.debug("The output XML from getRuleListForPOS : \n" + XMLUtil.getXMLString(docOutGetRuleList));
        }

        /* Get the RuleValue from getRuleListForPOS API */
        NodeList nlRule = docOutGetRuleList.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_RULE);

        if(!YFCCommon.isVoid(nlRule)) {
            iCount = nlRule.getLength();
        }

        for(int i=0; i<iCount; i++) {
            Element eleRuleOut = (Element) nlRule.item(i);
            hmOmniBipaasMap.put(eleRuleOut.getAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE_ATTRIBUTE), eleRuleOut.getAttribute(KohlsXMLLiterals.A_RULE_VALUE));

        }

        return hmOmniBipaasMap;
    }

    /**
     * This method invokes getItemList API and verifies if the CategoryPath has StoredValue present in it. If Stored
     * Value is present then the item is gift card or virtual gift card.
     * @param env
     * @param strItemID
     * @return
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     */

    private boolean checkifItemIsGCorVGC(YFSEnvironment env, String strItemID) throws Exception {

        /* Initialize the variable */
        Document docIn = null;
        Document docOutGetItemList = null;
        Element eleInRoot = null;
        Element eleCategory = null;
        String strCategoryPath = null;

        /* Prepare the input document for getItemList */
        docIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.E_ITEM);
        eleInRoot = docIn.getDocumentElement();
        eleInRoot.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemID);
        eleInRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY);
        eleInRoot.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, KohlsConstants.EACH);


        /* Invoke getItemList API */
        if (logger.isDebugEnabled()) {
            logger.debug("The input XML To getItemList : \n" + XMLUtil.getXMLString(docIn));
        }
        
        docOutGetItemList = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GetItemListAPITemplateForGC), KohlsConstant.API_GET_ITEM_LIST, docIn);

        if (logger.isDebugEnabled()) {
            logger.debug("The output XML from getItemList : \n" + XMLUtil.getXMLString(docOutGetItemList));
        }

        /* Get Category Path from getItemList Output */
        Element eleItem = KohlsXMLUtil.getChildElement(docOutGetItemList.getDocumentElement(), KohlsPOCConstant.E_ITEM);

        if(!YFCCommon.isVoid(eleItem)) {
            eleCategory = KohlsXMLUtil.getChildElement(KohlsXMLUtil.getChildElement(eleItem,
                    KohlsPOCConstant.ELE_CATEGORY_LIST), KohlsPOCConstant.A_CATEGORY);
        }
        if(!YFCCommon.isVoid(eleCategory)) {
            strCategoryPath = eleCategory.getAttribute(KohlsPOCConstant.A_CATEGORY_PATH);
        }

        if(!YFCCommon.isVoid(strCategoryPath) && strCategoryPath.contains(KohlsPOCConstant.STORED_VALUE)) {
            return true;
        }

        return false;
    }

    /**
     * This method will getCommonCodeList call and verify if OMS has to be integrated with OIC or with GIV.
     * @param env
     * @return
     * @throws ParserConfigurationException
     * @throws RemoteException
     */
    private String checkIfOICIsEnabled(YFSEnvironment env) throws ParserConfigurationException, RemoteException, YIFClientCreationException {

        /* Initialize  Variables*/
        String strCodeValue = KohlsPOCConstant.NO;


        /* Invoke getCommonCodeList API */
        strCodeValue = KohlsUtil.getCommonCodeValue(env, KohlsPOCConstant.A_IS_OIC_ENABLED);
        return strCodeValue;

    }
}