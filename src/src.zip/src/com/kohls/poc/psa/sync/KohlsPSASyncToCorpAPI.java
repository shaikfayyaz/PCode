package com.kohls.poc.psa.sync;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.psa.api.KohlsPSARefund;
import com.tgcs.tcx.gravity.pos.util.YFCLoggerAdapter;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * Class to invoke multiApi on Corp to sync the PSA performed on InStore.
 * 
 */
public class KohlsPSASyncToCorpAPI extends KOHLSBaseApi {
    private static final YFCLoggerAdapter logger = new YFCLoggerAdapter(KohlsPSASyncToCorpAPI.class.getName());

    /**
     * Method to replay changeOrder calls on Corp.
     * 
     * @param env
     * @param inputDoc
     * @return
     * @throws Exception
     */
    public Document customChangeOrder(YFSEnvironment env, Document inputDoc) throws Exception {
        logger.debug("KohlsPSASyncToCorpAPI.customChangeOrder--Begin");
        // get the psa status
        Element inputElement = inputDoc.getDocumentElement();
        inputElement.setAttribute("ValidatePromotionAward", "N");
        Element extnElement = (Element) inputElement.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
        String status = extnElement.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
        if (KohlsPOCConstant.EXTN_PSA_STARTED.equals(status) || KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(status)) {
            logger.debug("get and set the corp order header and line keys   :");
            setCorpOrderKeysInTxn(env, inputDoc);
        }
        if (KohlsPOCConstant.EXTN_PSA_STARTED.equals(status) || KohlsPOCConstant.PSA_COMPLETED_STATUS.equals(status)) {
            String orderHeaderKey = (String) env.getTxnObject(KohlsPOCConstant.TXN_CORP_ORDER_HEADER_KEY);
            logger.debug("Stamp the corp order header key retrieved from txn :" + orderHeaderKey);
            inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        } else if (KohlsPOCConstant.EXTN_PSA_IN_PROGRESS.equals(status)
                || KohlsPOCConstant.PSA_VOIDED_STATUS.equals(status)
                || KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(status)) {
            logger.debug("Process PSA for In_Progress,Voided and PostVoid  :");
            formSyncInputForPSA(env, inputDoc);
            if(KohlsPOCConstant.EXTN_PSA_IN_PROGRESS.equalsIgnoreCase(status)){
            	inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.IsPSASyncToCorp, KohlsPOCConstant.YES);
            }
        }
        inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
        logger.debug("invoking change order for PSA,MIDVOID and POSTVOID    :");
        // change order call to apply or remove the discounts
        invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, inputDoc);

        if (KohlsPOCConstant.PSA_COMPLETED_STATUS.equals(status)
                || KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(status)
                || KohlsPOCConstant.PSA_VOIDED_STATUS.equals(status)) {
            // form changeOrder xml
            logger.debug("change the status to Synched in InStore   :");
            invokeManageOfflineTransactionQForPOSAPI(env, inputElement);
        }
        if (KohlsPOCConstant.PSA_COMPLETED_STATUS.equals(status) || KohlsPOCConstant.PSA_VOIDED_STATUS.equals(status)) {
            // form updateSynchedOrderStatus xml
            logger.debug("change the status to Synched in InStore   :");
            updateSaleStatus(env, inputElement);
        }
        logger.debug("KohlsPSASyncToCorpAPI.customChangeOrder--End");

        return inputDoc;

    }

    /**
     * Method to drop a offlineTrxQ message to change the ExtnPsaStatus to
     * "Synched" at InStore.
     * 
     * @param env
     * @param inputElement
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private void invokeManageOfflineTransactionQForPOSAPI(YFSEnvironment env, Element inputElement)
            throws ParserConfigurationException, Exception {
        logger.debug("KohlsPSASyncToCorpAPI.invokeManageOfflineTransactionQForPOSAPI--Begin");
        Document changeOrderDoc = formChangeOrderInput(inputElement);
        Document offlineTrxQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
        Element offlineTrxQElement = offlineTrxQDoc.getDocumentElement();
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.YES);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.API_CHANGE_ORDER);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_TS,
                inputElement.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
        offlineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
                inputElement.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.STRING_ONE);
        String transactionNo = (String) env.getTxnObject(KohlsPOCConstant.TXN_TRANSACTION_NO);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, transactionNo);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_DATA_XML, XMLUtil.getXMLString(changeOrderDoc));
        logger.debug("Invoking manageOfflineTransactionQForPOS    :");
        invokeAPI(env, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, offlineTrxQDoc);
        logger.debug("KohlsPSASyncToCorpAPI.invokeManageOfflineTransactionQForPOSAPI--End");
    }

    /**
     * Method to form the change order input to change status to Syched.
     * 
     * @param inputElement
     * @throws ParserConfigurationException
     */
    private Document formChangeOrderInput(Element inputElement) throws ParserConfigurationException {
        logger.debug("KohlsPSASyncToCorpAPI.formChangeOrderInput--Begin");
        Document changeOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element changeOrderElement = changeOrderDoc.getDocumentElement();
        changeOrderElement.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
                inputElement.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
        changeOrderElement.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
                inputElement.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
        changeOrderElement.setAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE,
                inputElement.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
        changeOrderElement.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
                inputElement.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
        changeOrderElement
                .setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
        changeOrderElement.setAttribute(KohlsPOCConstant.A_Select_Method,
                KohlsPOCConstant.SELECT_METHOD_WAIT);
        Element extnOrderElement = changeOrderDoc.createElement(KohlsPOCConstant.E_EXTN);
        extnOrderElement.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, KohlsPOCConstant.A_SYNCHED);
        changeOrderElement.appendChild(extnOrderElement);
        logger.debug("KohlsPSASyncToCorpAPI.formChangeOrderInput--End");
        return changeOrderDoc;
    }

    /**
     * Method to add the DeltaTax calculated in InStore.
     * 
     * @param env
     * @param inputDoc
     * @throws Exception
     */
    private void formSyncInputForPSA(YFSEnvironment env, Document inputDoc) throws Exception {
        logger.debug("KohlsPSASyncToCorpAPI.formSyncInputForPSA ---Begin");
        String corpOrderLineKey;
        String orderHeaderKey = (String) env.getTxnObject(KohlsPOCConstant.TXN_CORP_ORDER_HEADER_KEY);
        logger.debug("Stamp the corp order header key  :" + orderHeaderKey);
        inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.TRUE);
        env.setTxnObject(KohlsPOCConstant.IS_PSA_CHANGE_ORDER, KohlsPOCConstant.FLAG_Y);
        logger.debug("IgnoreRepricingUE ans ispsachangeOrder txn are set");
        Map<String, List<Element>> lineTax = new HashMap<String, List<Element>>();
        Map<String, String> lineKeyMap = (Map<String, String>) env.getTxnObject(KohlsPOCConstant.TXN_CORP_LINE_KEY_MAP);
        if (null != lineKeyMap && lineKeyMap.size() > 0) {
            logger.debug("After getting the line map from Txn  :");
            List<Element> orderLineList = XMLUtil.getElementsByTagName(inputDoc.getDocumentElement(),
                    KohlsPOCConstant.ELEM_ORDER_LINE);
            for (Element orderLine : orderLineList) {
                corpOrderLineKey = lineKeyMap.get(orderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
                orderLine.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY, corpOrderLineKey);
                List<Element> lineTaxesList = new ArrayList<Element>();
                Element deltaTaxesElement = (Element) XPathUtil.getNode(orderLine, KohlsPOCConstant.XPATH_DELTATAX);
                Element lineTaxesElement = (Element) XPathUtil.getNode(orderLine, KohlsPOCConstant.XPATH_DELTALINETAX);
                if (!YFCCommon.isVoid(lineTaxesElement)) {
                    lineTaxesList.add(lineTaxesElement);
                    lineTax.put(corpOrderLineKey, lineTaxesList);
                }
                if(!YFCCommon.isVoid(deltaTaxesElement)) {
                	orderLine.removeChild(deltaTaxesElement);
                }
               
            }
        }
        logger.debug("Set the delta tax txn for recalculatelinetaxUE  :");
        env.setTxnObject(KohlsPOCConstant.TXN_DELTATAX, lineTax);
        logger.debug("KohlsPSASyncToCorpAPI.formSyncInputForPSA ---End");
    }

    /**
     * Method to set the OrderHeaderKey and OrderLineKey at Corp.
     * 
     * @param env
     * @param inputDoc
     * @param corpOrderHeaderKey
     * @return
     * @throws ParserConfigurationException
     * @throws Exception
     * @throws SAXException
     * @throws IOException
     */
    private void setCorpOrderKeysInTxn(YFSEnvironment env, Document inputDoc) throws ParserConfigurationException,
            Exception, SAXException, IOException {
        logger.debug("KohlsPSASyncToCorpAPI.setCorpOrderKeysInTxn--Begin");
        String corpOrderHeaderKey = "";
        String corpOrderLineKey = "";
        String transactionNo = "";
        Map<String, String> lineKeyMap = new HashMap<String, String>();
        Document inputOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
                inputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
        Document orderListDoc = invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_CORP_ORDER_LIST_TEMPLATE),
                KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
        if (!YFCCommon.isVoid(orderListDoc)) {
            Element orderElement = (Element) orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);
            corpOrderHeaderKey = orderElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
            logger.debug("CorpOrderHeaderKey is   :" + corpOrderHeaderKey);
            transactionNo = orderElement.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
            logger.debug("The transaction no is  :" + transactionNo);
            List<Element> corpOrderLineList = XMLUtil.getElementsByTagName(orderElement,
                    KohlsPOCConstant.ELEM_ORDER_LINE);
            for (Element corporderLine : corpOrderLineList) {
                String primeLineNo = corporderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                corpOrderLineKey = corporderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
                logger.debug("CorpOrderLineKey is    :" + corpOrderLineKey);
                lineKeyMap.put(primeLineNo, corpOrderLineKey);
            }

        }
        env.setTxnObject(KohlsPOCConstant.TXN_CORP_ORDER_HEADER_KEY, corpOrderHeaderKey);
        env.setTxnObject(KohlsPOCConstant.TXN_CORP_LINE_KEY_MAP, lineKeyMap);
        env.setTxnObject(KohlsPOCConstant.TXN_TRANSACTION_NO, transactionNo);
        logger.debug("KohlsPSASyncToCorpAPI.setCorpOrderKeysInTxn--End");

    }

    /**
     * Method to replay payment capture on Corp.
     * 
     * @param env
     * @param inputDoc
     * @return
     * @throws Exception
     */
    public Document customPSARefund(YFSEnvironment env, Document inputDoc) throws Exception {
        logger.debug("KohlsPSASyncToCorpAPI.customPSARefund---Begin");
        KohlsPSARefund refundObj = new KohlsPSARefund();
        String orderHeaderKey = (String) env.getTxnObject(KohlsPOCConstant.TXN_CORP_ORDER_HEADER_KEY);
        logger.debug("Stamp the corp order header key retrieved from txn :" + orderHeaderKey);
        if (!YFCCommon.isVoid(orderHeaderKey)) {
            String isrequestCollectionCalled = (String) env
                    .getTxnObject(KohlsPOCConstant.TXN_REQUEST_COLLECTION_CALLED);
            if (YFCCommon.isVoid(isrequestCollectionCalled)
                    || !KohlsPOCConstant.FLAG_Y.equals(isrequestCollectionCalled)) {
                logger.debug("This is the first payment call for PSA:");
                Document docReqCollInput = refundObj.inputToRequestCollection(orderHeaderKey);
                // requestCollection api is called
                Document docReqCollOut = refundObj.callRequestCollectionAPI(env, docReqCollInput);
                // Whether requestCollection is a success or not is checked
                if ((!YFCCommon.isVoid(docReqCollOut))
                        && (docReqCollOut.getDocumentElement().getNodeName()
                                .equalsIgnoreCase(KohlsPOCConstant.ELEM_ORDER))) {
                    env.setTxnObject(KohlsPOCConstant.TXN_REQUEST_COLLECTION_CALLED, KohlsPOCConstant.FLAG_Y);
                    // Input to call getChargeTransactionList api is
                    // prepared
                    Document docCharTransInput = refundObj.inputToGetChargeTransactionList(orderHeaderKey);
                    // getChargeTransactionList api is called
                    Document docCharTransOutput = refundObj.callGetChargeTransactionListAPI(env, docCharTransInput);
                    // A list of ChargeTransactionKey(s) is prepared from
                    // the output of getChargeTransactionList api
                    List<String> chargeTrnsactionKeys = refundObj.getChargeTransactionKeys(docCharTransOutput);
                    // Input to voidChargeTransaction api is prepared
                    Document docVoidChargTransInput = refundObj.voidChargeTransactioninDoc(chargeTrnsactionKeys);
                    // voidChargeTransaction api is called
                    Document docVoidChargTransOutput = refundObj.callvoidChargeTransaction(env, docVoidChargTransInput);
                    if (!YFCCommon.isVoid(docVoidChargTransOutput)) {

                        logger.debug("KohlsPSASyncToCorpAPI.customPSARefund docVoidChargTransOutput="
                                + XMLUtil.getXMLString(docVoidChargTransOutput));

                    }
                }
            }
            Element inputElement = inputDoc.getDocumentElement();
            inputElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
            String nodeName = inputElement.getNodeName();
            if (KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES.equals(nodeName)) {
                logger.debug("Invoking recordExternalCharges API   :");
                invokeAPI(env, KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES, inputDoc);

            } else if (KohlsXMLLiterals.E_CAPTURE_PAYMENT.equals(nodeName)) {
                logger.debug("Invoking capturePayment API   :");
                invokeAPI(env, KohlsXMLLiterals.API_CAPTURE_PAYMENT, inputDoc);

            }
        }
        logger.debug("KohlsPSASyncToCorpAPI.customPSARefund---End");
        return inputDoc;

    }
    
    /**
     * Method to drop a offlineTrxQ message to change the Sale to "Synched" at
     * InStore.
     * 
     * @param env
     * @param inputElement
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private void updateSaleStatus(YFSEnvironment env, Element inputElement) throws ParserConfigurationException,
            Exception {
        logger.debug("KohlsPSASyncToCorpAPI.invokeManageOfflineTransactionQForPOSAPI--Begin");
        Document updateOrderStatusDoc = formUpdateSynchedOrderStatusInput(env, inputElement);
        Document offlineTrxQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
        Element offlineTrxQElement = offlineTrxQDoc.getDocumentElement();
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.YES);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID,
                KohlsPOCConstant.API_UPDATE_SYNCHED_ORDER_STATUS);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_TS,
                inputElement.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
        offlineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
                inputElement.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.STRING_ONE);
        String transactionNo = (String) env.getTxnObject(KohlsPOCConstant.TXN_TRANSACTION_NO);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, transactionNo);
        offlineTrxQElement.setAttribute(KohlsPOCConstant.A_DATA_XML, XMLUtil.getXMLString(updateOrderStatusDoc));
        logger.debug("Invoking manageOfflineTransactionQForPOS    :");
        invokeAPI(env, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, offlineTrxQDoc);
        logger.debug("KohlsPSASyncToCorpAPI.invokeManageOfflineTransactionQForPOSAPI--End");
    }

    private Document formUpdateSynchedOrderStatusInput(YFSEnvironment env, Element inputElement) throws Exception {
        String transactionNo = (String) env.getTxnObject(KohlsPOCConstant.TXN_TRANSACTION_NO);
        String sellerOrg = inputElement.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
        Document updateOrderStatusDoc = XMLUtil.createDocument(KohlsPOCConstant.E_UPDATE_SYNCHED_ORDER_STATUS);
        Element updateOrderStatusElement = updateOrderStatusDoc.getDocumentElement();
        updateOrderStatusElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sellerOrg);
        Element synchedOrdersElement = updateOrderStatusDoc.createElement(KohlsPOCConstant.E_SYNCHED_ORDERS);
        updateOrderStatusElement.appendChild(synchedOrdersElement);
        Element synchedOrderElement = updateOrderStatusDoc.createElement(KohlsPOCConstant.E_SYNCHED_ORDER);
        synchedOrderElement.setAttribute(KohlsPOCConstant.A_TRANSACTION_NO,
                inputElement.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO));
        synchedOrdersElement.appendChild(synchedOrderElement);
        return updateOrderStatusDoc;

    }

}
