package com.kohls.poc.psa.sync;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.pos.util.YFCLoggerAdapter;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCPSAReplayRecordOrderPaymentsForPOS extends KOHLSBaseApi {
    private static final YFCLoggerAdapter logger = new YFCLoggerAdapter(
            KohlsPoCPSAReplayRecordOrderPaymentsForPOS.class.getName());
    private static final Long MAX_SYNC_ID = Long.valueOf(99999L);
    String transactionNo = "";

    public Document init(YFSEnvironment env, Document inputXML) throws Exception {
        logger.beginTimer("KohlsPSAReplayRecordOrderPaymentsForPOS : init()");
        if (!ServerTypeHelper.amIOnEdgeServer()) {

            Element inputElement = inputXML.getDocumentElement();
            // get transaction number
            transactionNo = getTransactionNo(env, inputElement);

            Document operationInputXML = formOperationInputXML(env, inputElement, transactionNo);
            // form poss offline trx input
            formAndInvokeManageOfflineTrxQInputXML(env, inputElement, operationInputXML);

        }
        logger.endTimer("KohlsPSAReplayRecordOrderPaymentsForPOS : init()");
        return inputXML;

    }

    /**
     * This method is used to create the input xml for offlineTransactionQ.
     * 
     * @param inputElement
     * @param operationInputXML
     * @throws Exception
     */
    private void formAndInvokeManageOfflineTrxQInputXML(YFSEnvironment env, Element inputElement,
            Document operationInputXML) throws Exception {
        if (!YFCCommon.isVoid(operationInputXML)) {
            Document offlineTrxQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
            Element offlineTrxQElement = offlineTrxQDoc.getDocumentElement();
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.YES);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID,
                    KohlsPOCConstant.API_REPLAY_RECORD_ORDER_PAYMENT_FOR_POS);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_TS,
                    inputElement.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
            offlineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
                    inputElement.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.STRING_ONE);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, transactionNo);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_DATA_XML, XMLUtil.getXMLString(operationInputXML));
            invokeAPI(env, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, offlineTrxQDoc);
        }

    }

    /**
     * Method to form the input for ReplayRecordOrderForPayments.
     * 
     * @param inputElement
     * @param transactionNo
     * @throws Exception
     */
    private Document formOperationInputXML(YFSEnvironment env, Element inputElement, String transactionNo)
            throws Exception {
        Document inputROPDoc = null;
        NodeList paymentMethodsList = inputElement.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHODS);
        if (paymentMethodsList.getLength() > 0) {
            Element paymentMethodsElement = (Element) paymentMethodsList.item(0);

            List<Element> paymentMethods = XMLUtil.getElementsByTagName(paymentMethodsElement,
                    KohlsPOCConstant.E_PAYMENT_METHOD);
            for (Element paymentMethod : paymentMethods) {
                String totalRefundAmount = paymentMethod.getAttribute(KohlsPOCConstant.A_TOTAL_REFUNDED_AMOUNT);
                Double refundAmount = Double.parseDouble(totalRefundAmount);
                String syncID = "";
                if (refundAmount > 0.0) {
                    logger.debug("KohlsPoCPSAReplayRecordOrderPaymentsForPOS : formOperationInputXML() PSA flow ");
                    inputROPDoc = XMLUtil.createDocument(KohlsPOCConstant.E_REPLAY_RECORD_ORDER_PAYMENT_FOR_POS);
                    Element inputROPElement = inputROPDoc.getDocumentElement();
                    inputROPElement.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY,
                            paymentMethod.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
                    inputROPElement.setAttribute(KohlsPOCConstant.A_ORG_CODE,
                            paymentMethod.getAttribute(KohlsPOCConstant.ATTR_STORE_ID));
                    inputROPElement.setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
                            paymentMethod.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
                    inputROPElement.setAttribute(KohlsPOCConstant.ATTR_TILL_ID,
                            paymentMethod.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
                    inputROPElement.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, KohlsPOCConstant.STRING_ONE);
                    inputROPElement.setAttribute(KohlsPOCConstant.A_REPLAY, KohlsPOCConstant.YES);
                    inputROPElement.setAttribute(KohlsPOCConstant.A_UPDATE_TILL, KohlsPOCConstant.YES);
                    inputROPElement.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, transactionNo);
                    syncID = getSyncID(env, paymentMethod);
                    inputROPElement.setAttribute(KohlsPOCConstant.A_SYNC_ID, syncID);
                    Element accountTotalElement = inputROPDoc.createElement(KohlsPOCConstant.ATTR_ACCOUNT_TOTAL);
                    accountTotalElement.setAttribute(KohlsPOCConstant.A_ACCOUNT_TYPE, KohlsPOCConstant.A_TERMINAL);
                    accountTotalElement.setAttribute(KohlsPOCConstant.A_CATEGORY, KohlsPOCConstant.A_PAYMENT);
                    accountTotalElement.setAttribute(KohlsConstant.STR_COUNT, KohlsPOCConstant.STRING_ONE);
                    accountTotalElement.setAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE, KohlsPOCConstant.A_EXPECTED);
                    accountTotalElement.setAttribute(KohlsPOCConstant.A_INFO, KohlsPOCConstant.COST_CURRENCY);
                    accountTotalElement.setAttribute(KohlsPOCConstant.A_PAYMENT_TYPE,
                            paymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE));
					accountTotalElement.setAttribute(KohlsPOCConstant.ATTR_AMOUNT, KohlsPOCConstant.MINUS
                            + totalRefundAmount);
                    inputROPElement.appendChild(accountTotalElement);

                }
            }
        }
        return inputROPDoc;
    }

    /**
     * Method to get the next SyncID.
     * 
     * @param env
     * @param paymentMethod
     * @return
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private String getSyncID(YFSEnvironment env, Element paymentMethod) throws ParserConfigurationException, Exception {
        Document docTillStatus = XMLUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
        docTillStatus.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,
                paymentMethod.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
        docTillStatus.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORG_CODE,
                paymentMethod.getAttribute(KohlsPOCConstant.ATTR_STORE_ID));
        docTillStatus.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, KohlsPOCConstant.STRING_ONE);
        Document tillStatusDocument = invokeAPI(env, KohlsPOCConstant.API_GET_CURRENT_TILL_STATUS_FOR_POS,
                docTillStatus);
        String syncID = "";
        if (!(YFCCommon.isVoid(tillStatusDocument))) {
            YFCDocument tillStatusDoc = YFCDocument.getDocumentFor(tillStatusDocument);
            YFCElement tillStatusElement = tillStatusDoc.getDocumentElement();
            Long syncId = Long.valueOf(tillStatusElement.getLongAttribute(KohlsPOCConstant.A_SYNC_ID));
            if (syncId.longValue() >= MAX_SYNC_ID.longValue()) {
                syncId = Long.valueOf(1L);
            } else {
                syncId = Long.valueOf(syncId.longValue() + 1L);
            }
            syncID = syncId.toString();
        }
        logger.debug("KohlsPoCPSAReplayRecordOrderPaymentsForPOS : getSyncID()  " + syncID);
        return syncID;
    }

    /**
     * Method to get the Transaction Number.
     * 
     * @param env
     * @param inputElement
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws Exception
     */
    private String getTransactionNo(YFSEnvironment env, Element inputElement) throws ParserConfigurationException,
            SAXException, IOException, Exception {
        String transactionNo = "";
        String orderHeaderKey = inputElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        Document inputOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        Document orderListTemplateDoc = XMLUtil.getDocument("<OrderList><Order TransactionNo='' /></OrderList>");

        Document orderListDoc = invokeAPI(env, orderListTemplateDoc, KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
        if (null != orderListDoc) {
            NodeList orderList = orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
            if (orderList.getLength() > 0) {
                Element orderElement = (Element) orderList.item(0);
                transactionNo = orderElement.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
            }
        }
        logger.debug("KohlsPoCPSAReplayRecordOrderPaymentsForPOS : getTransactionNo()  " + transactionNo);
        return transactionNo;
    }
}
