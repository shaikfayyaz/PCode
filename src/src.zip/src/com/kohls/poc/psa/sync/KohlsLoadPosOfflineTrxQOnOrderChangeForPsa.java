package com.kohls.poc.psa.sync;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.pos.util.YFCLoggerAdapter;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * Class to populate POS_OFFLINE_TRX_Q table for PSA sync.
 * 
 */
public class KohlsLoadPosOfflineTrxQOnOrderChangeForPsa extends KOHLSBaseApi {
    private static final YFCLoggerAdapter logger = new YFCLoggerAdapter(
            KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.class.getName());
    String transactionNo = "";
    String operationTs = "";

    /**
     * Method to populate POS_OFFLINE_TRX_Q table.
     * 
     * @param env
     * @param inputDoc
     * @return
     * @throws Exception
     */
    public Document populatePosOfflineTrxQForPSA(YFSEnvironment env, Document inputDoc) throws Exception {
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.populatePSAOfflineQ---Begin");
        Element orderElement = inputDoc.getDocumentElement();
        String orderHeaderKey = orderElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        Element extnElement = (Element) orderElement.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);

        Document multiApiDoc = XMLUtil.createDocument(KohlsPOCConstant.E_MULTI_API);
        Document multiApiProcessDoc = XMLUtil.createDocument(KohlsPOCConstant.E_MULTI_API);

        // get the current transactions from psa offlineq table
        Document psaOfflineQListDoc = getPsaOfflineQList(env, orderHeaderKey);

        if (!YFCCommon.isVoid(psaOfflineQListDoc)) {

            List<Element> psaOfflineQList = XMLUtil.getElementsByTagName(psaOfflineQListDoc.getDocumentElement(),
                    KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
            for (Element psaOfflineQ : psaOfflineQList) {
                logger.debug("Processing the psa offline Q entries  :");
                formMultiApiXMLForPsa(multiApiDoc, psaOfflineQ);
                logger.debug("Marking the psa offline Q entries as processed  :");
                String psaOfflineQKey = psaOfflineQ.getAttribute(KohlsPOCConstant.A_PSA_OFFLINE_Q_KEY);
                String status = psaOfflineQ.getAttribute(KohlsPOCConstant.A_PSA_STATUS);
                logger.debug("The status of the psaofflineq record is   :" + status);
                if (KohlsPOCConstant.PSA_COMPLETED_STATUS.equals(status)
                		|| KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(status)
                		|| KohlsPOCConstant.PSA_VOIDED_STATUS.equals(status) ) {
                    logger.debug("Get the modifyts from psaofflineq  :");
                    operationTs = psaOfflineQ.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS);
                    logger.debug("operationTs is    :" + operationTs);
                }
                formMultiApiToChangePsaOfflineQStatus(psaOfflineQKey, multiApiProcessDoc);

            }

            addOfflineTrxQInputToMultiApi(env, orderElement, multiApiDoc, multiApiProcessDoc);
            invokeAPI(env, KohlsPOCConstant.API_MULTIAPI, multiApiProcessDoc);
        }
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.populatePSAOfflineQ---End");

        return inputDoc;

    }

    /**
     * Method to add the replay multiApi Doc.
     * 
     * @param env
     * @param orderElement
     * @param multiApiDoc
     * @param multiApiProcessDoc
     * @param multiApiProcessElement
     * @throws Exception
     */
    private void addOfflineTrxQInputToMultiApi(YFSEnvironment env, Element orderElement, Document operationXML,
            Document multiApiProcessDoc) throws Exception {
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.addOfflineTrxQInputToMultiApi---Begin");
        Element multiApiProcessElement = multiApiProcessDoc.getDocumentElement();
        Document posOfflineTrxQDoc = formManageOfflineTrxQInputXML(env, orderElement, operationXML);
        if (!YFCCommon.isVoid(posOfflineTrxQDoc)) {
            Element posOfflineTrxElement = posOfflineTrxQDoc.getDocumentElement();
            Element apiProcessElement = multiApiProcessDoc.createElement(KohlsPOCConstant.E_API);
            apiProcessElement.setAttribute(KohlsPOCConstant.A_NAME,
                    KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS);
            multiApiProcessElement.appendChild(apiProcessElement);
            Element inputProcessElement = multiApiProcessDoc.createElement(KohlsPOCConstant.E_INPUT);
            apiProcessElement.appendChild(inputProcessElement);
            Element processedElement = (Element) multiApiProcessDoc.importNode(posOfflineTrxElement, true);
            inputProcessElement.appendChild(processedElement);
        }
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.addOfflineTrxQInputToMultiApi---Begin");
    }

    /**
     * Method to form input xml for poofflinetrxQ.
     * 
     * @param env
     * @param inputElement
     * @param operationInputXML
     * @return
     * @throws Exception
     */
    private Document formManageOfflineTrxQInputXML(YFSEnvironment env, Element inputElement, Document operationInputXML)
            throws Exception {
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.formAndInvokeManageOfflineTrxQInputXML---Begin");
        Document offlineTrxQDoc = null;
        if (!YFCCommon.isVoid(operationInputXML)) {
            offlineTrxQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
            Element offlineTrxQElement = offlineTrxQDoc.getDocumentElement();
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.YES);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.UNIQUE_ID_MULTI_API);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_TS, operationTs);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
                    inputElement.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.STRING_ONE);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, transactionNo);
            offlineTrxQElement.setAttribute(KohlsPOCConstant.A_DATA_XML, XMLUtil.getXMLString(operationInputXML));

        }
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.formAndInvokeManageOfflineTrxQInputXML---End");
        return offlineTrxQDoc;

    }

    /**
     * Method to change the psaofflineq records to processed.
     * 
     * @param orderHeaderKey
     * @param multiApiProcessDoc
     * @param multiApiProcessElement
     * @throws ParserConfigurationException
     */
    public void formMultiApiToChangePsaOfflineQStatus(String PsaOfflineQKey, Document multiApiProcessDoc)
            throws ParserConfigurationException {
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.formMultiApiToChangePsaOfflineQStatus---Begin");
        Element multiApiProcessElement = multiApiProcessDoc.getDocumentElement();
        Document operationProcessDoc = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
        Element operationProcessElement = operationProcessDoc.getDocumentElement();
        operationProcessElement.setAttribute(KohlsPOCConstant.A_PSA_OFFLINE_Q_KEY, PsaOfflineQKey);
        // operationProcessElement.setAttribute(KohlsPOCConstant.A_IS_PROCESSED,
        // KohlsPOCConstant.FLAG_Y);
        Element apiProcessElement = multiApiProcessDoc.createElement(KohlsPOCConstant.E_API);
        apiProcessElement.setAttribute(KohlsPOCConstant.A_IS_EXTENDED_DB_API, KohlsPOCConstant.FLAG_Y);
        apiProcessElement.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.API_DELETE_PSA_OFFLINE_Q);
        multiApiProcessElement.appendChild(apiProcessElement);
        Element inputProcessElement = multiApiProcessDoc.createElement(KohlsPOCConstant.E_INPUT);
        apiProcessElement.appendChild(inputProcessElement);
        Element processedElement = (Element) multiApiProcessDoc.importNode(operationProcessDoc.getDocumentElement(),
                true);
        inputProcessElement.appendChild(processedElement);
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.formMultiApiToChangePsaOfflineQStatus---End");
    }

    /**
     * Method to form the multiApi xml.
     * 
     * @param multiApiDoc
     * @param multiApiElement
     * @param psaOfflineQ
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    private void formMultiApiXMLForPsa(Document multiApiDoc, Element psaOfflineQ) throws ParserConfigurationException,
            SAXException, IOException {
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.formMultiApiXMLForPsa---Begin");
        Element multiApiElement = multiApiDoc.getDocumentElement();
        String operationID = psaOfflineQ.getAttribute(KohlsPOCConstant.A_OPERATION_ID);
        String status = psaOfflineQ.getAttribute(KohlsPOCConstant.A_PSA_STATUS);
        String operationXML = psaOfflineQ.getAttribute(KohlsPOCConstant.A_PSA_OPERATION_XML);
        Document operationDoc = XMLUtil.getDocument(operationXML);
        if (KohlsPOCConstant.EXTN_PSA_STARTED.equals(status)) {
            logger.debug("get the transaction no for started :");
            transactionNo = operationDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
            logger.debug("The transaction no retrieved is  :" + transactionNo);
        }
        if (KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(status)) {
            logger.debug("get the transaction no for postvoid status  :");
            transactionNo = KohlsPOCConstant.V_POSTVOID_P
                    + operationDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
            logger.debug("The transaction no retrieved is  :" + transactionNo);
        }
        Element apiElement = multiApiDoc.createElement(KohlsPOCConstant.E_API);
        if (KohlsPOCConstant.API_CHANGE_ORDER.equals(operationID)) {

            apiElement.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.SRVC_KOHLS_PSA_ORDER_SYNC_SERVICE);

        } else if (KohlsXMLLiterals.API_CAPTURE_PAYMENT.equals(operationID)
                || KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES.equals(operationID)) {
            apiElement.setAttribute(KohlsPOCConstant.API_FLOWNAME, KohlsPOCConstant.PSA_PAYMENT_SYNC_FLOW);
        }
        multiApiElement.appendChild(apiElement);
        Element inputElement = multiApiDoc.createElement(KohlsPOCConstant.E_INPUT);
        apiElement.appendChild(inputElement);
        Element operationElement = (Element) multiApiDoc.importNode(operationDoc.getDocumentElement(), true);
        inputElement.appendChild(operationElement);
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.formMultiApiXMLForPsa---End");
    }

    /**
     * Method to get psaofflineqlist.
     * 
     * @param env
     * @param orderHeaderKey
     * @return
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private Document getPsaOfflineQList(YFSEnvironment env, String orderHeaderKey) throws ParserConfigurationException,
            Exception {
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.getPsaOfflineQList---Begin");
        Document inputKohlsPsaOfflineQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
        Element inputKohlsPsaOfflineQElement = inputKohlsPsaOfflineQDoc.getDocumentElement();
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_IS_PROCESSED, KohlsPOCConstant.V_N);
        Element orderByElement = inputKohlsPsaOfflineQDoc.createElement(KohlsPOCConstant.E_ORDER_BY);
        inputKohlsPsaOfflineQElement.appendChild(orderByElement);
        Element attributeElement = inputKohlsPsaOfflineQDoc.createElement(KohlsPOCConstant.A_ATTRIBUTE);
        attributeElement.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_PSA_REPLICATION_SEQ);
        orderByElement.appendChild(attributeElement);
        Document psaOfflineQListDoc = invokeService(env, KohlsPOCConstant.SRVC_GET_PSA_OFFLINE_Q_LIST,
                inputKohlsPsaOfflineQDoc);
        logger.debug("KohlsLoadPosOfflineTrxQOnOrderChangeForPsa.getPsaOfflineQList---End");
        return psaOfflineQListDoc;
    }

}
