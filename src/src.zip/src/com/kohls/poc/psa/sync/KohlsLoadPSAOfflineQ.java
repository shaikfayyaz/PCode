package com.kohls.poc.psa.sync;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.pos.util.YFCLoggerAdapter;
import com.yantra.ycp.core.YCPContext;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * Class to populate PSA_OFFLINE_Q table for PSA sync.
 * 
 */
public class KohlsLoadPSAOfflineQ extends KOHLSBaseApi {
    private static final YFCLoggerAdapter logger = new YFCLoggerAdapter(KohlsLoadPSAOfflineQ.class.getName());

    /**
     * Method to populate PSAOfflineQ.
     * 
     * @param env
     * @param inputDoc
     * @return
     * @throws Exception
     */
    public Document populatePSAOfflineQ(YFSEnvironment env, Document inputDoc) throws Exception {

        String extnPsaStatus = "";

        logger.debug("KohlsLoadPSAOfflineQ.populatePSAOfflineQ---Begin");
		String isReceiptScan = (String) env.getTxnObject(KohlsPOCConstant.TXN_IS_CHANGEORDER_FOR_RECEIPT_SCAN);
        if (YFCCommon.isVoid(isReceiptScan) || !KohlsPOCConstant.FLAG_Y.equals(isReceiptScan)) {
            logger.debug("changeOrder not from receipt scan");
        if (!YFCCommon.isVoid(inputDoc)) {

            Element orderElement = inputDoc.getDocumentElement();
            NodeList extnList = orderElement.getElementsByTagName(KohlsPOCConstant.A_EXTN);
            if (extnList.getLength() > 0) {
                Element extnElement = (Element) orderElement.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
                extnPsaStatus = extnElement.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
            }
            logger.debug("Psa status for non synced order  :" + extnPsaStatus);
            if (!YFCCommon.isVoid(extnPsaStatus)) {
                String orderHeaderKey = orderElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
                if (KohlsPOCConstant.EXTN_PSA_STARTED.equals(extnPsaStatus)) {
                    logger.debug("Load for PSA started status   :");
                    changeOrderForPsaStartedStatus(env, orderElement);

                }
                if (KohlsPOCConstant.EXTN_PSA_IN_PROGRESS.equals(extnPsaStatus)) {
                    logger.debug("Load for PSA in progress status   :");
                    changeOrderForPsaInprogressStatus(env, orderHeaderKey);

                }
                if (KohlsPOCConstant.PSA_COMPLETED_STATUS.equals(extnPsaStatus)) {
                    logger.debug("Load for PSA completed status   :");
                    changeOrderForPsaCompletedStatus(env, orderElement);

                }
                if (KohlsPOCConstant.PSA_VOIDED_STATUS.equals(extnPsaStatus)
                        || KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(extnPsaStatus)) {
                    logger.debug("Load for PSA mid void order post void status   :");
                    changeOrderForPsaVoidedStatus(env, orderHeaderKey, extnPsaStatus);

                }
            }

        } 
		} else {
            env.setTxnObject(KohlsPOCConstant.TXN_IS_CHANGEORDER_FOR_RECEIPT_SCAN, KohlsPOCConstant.NO);
        }

        logger.debug("KohlsLoadPSAOfflineQ.populatePSAOfflineQ---End");
        return inputDoc;

    }

    /**
     * Method to form changeOrder input for IN_PROGRESS status.
     * 
     * @param env
     * @param orderHeaderKey
     * @throws ParserConfigurationException
     * @throws Exception
     * @throws SAXException
     * @throws IOException
     */
    private void changeOrderForPsaInprogressStatus(YFSEnvironment env, String orderHeaderKey)
            throws ParserConfigurationException, Exception, SAXException, IOException {
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaInprogressStatus---Begin");
        // get the orderList with the specified template

        Document inputOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        // this template needs to be changed
        Document orderListDoc = invokeAPI(env, KohlsPOCConstant.GET_ORDER_LIST_FOR_PSA_TEMPLATE,
                KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
        if (!YFCCommon.isVoid(orderListDoc)) {
            Element inprogressOrderElement = (Element) orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER)
                    .item(0);
            logger.debug("Setting the IgnoreRepricingUE flag to Y for sync  :");
            inprogressOrderElement.setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FLAG_Y);
            inprogressOrderElement.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
            // check if this is the first discount applied on order
            String isFirstChangeOrder = isFirstChangeOrder(env, orderHeaderKey);
            logger.debug("The isFirstChangeOrder lfag is    :" + isFirstChangeOrder);
            Integer discounts = 0;
            if (KohlsPOCConstant.V_N.equals(isFirstChangeOrder)) {
                discounts = (Integer) env.getTxnObject(KohlsPOCConstant.TXN_NO_OF_DISCOUNT);

            }
            logger.debug("No of discounts   :" + discounts.toString());
            // get the Promotions element from order level
            NodeList promotionsList = XPathUtil.getNodeList(inprogressOrderElement, KohlsPOCConstant.XPATH_PROMOTION);
            int promotionsLength = promotionsList.getLength();
            if (KohlsPOCConstant.FLAG_Y.equals(isFirstChangeOrder) || (promotionsLength != discounts)) {
                if (promotionsList.getLength() > 0) {
                    Element promotionsElement = (Element) promotionsList.item(0);
                    logger.debug("Stamping the firstchangeorder and psachangeorder attributes");
                    promotionsElement.setAttribute(KohlsPOCConstant.A_IS_FIRST_CHANGE_ORDER, isFirstChangeOrder);
                    promotionsElement.setAttribute(KohlsPOCConstant.IS_PSA_CHANGE_ORDER, KohlsPOCConstant.FLAG_Y);
                }
                // append the delta line tax calculation to the change order
                // input
                getDeltaTaxElementForPsa(env, orderListDoc, inprogressOrderElement);
                // populate the PSA offline q table.
                populatePsaOfflineForPsaStatus(env, orderHeaderKey, inprogressOrderElement,
                        KohlsPOCConstant.EXTN_PSA_IN_PROGRESS);
            }
        }
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaInprogressStatus---End");
    }

    /**
     * Method used for all statuses to populate PSAOfflineQ.
     * 
     * @param env
     * @param orderHeaderKey
     * @param inprogressOrderElement
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private void populatePsaOfflineForPsaStatus(YFSEnvironment env, String orderHeaderKey, Element OrderElement,
            String status) throws ParserConfigurationException, Exception {
        logger.debug("KohlsLoadPSAOfflineQ.populatePsaOfflineForPsaStatus---Begin");
        OrderElement.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
        Document inputKohlsPsaOfflineQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
        Element inputKohlsPsaOfflineQElement = inputKohlsPsaOfflineQDoc.getDocumentElement();
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.API_CHANGE_ORDER);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_STATUS, status);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_OPERATION_XML,
                XMLUtil.getElementXMLString(OrderElement));
        String getPSAReplicationSequence = getPSAReplicationSequence(env);
        logger.debug("Replication sequence for this operation is   :" + getPSAReplicationSequence);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_REPLICATION_SEQ, getPSAReplicationSequence);
        invokeService(env, KohlsPOCConstant.SRVC_CREATE_PSA_OFFLINE_Q, inputKohlsPsaOfflineQDoc);
        logger.debug("KohlsLoadPSAOfflineQ.populatePsaOfflineForPsaStatus---End");
    }

    /**
     * Method to get the Delta tax element calculated at InStore.
     * 
     * @param env
     * @param orderListDoc
     * @param inprogressOrderElement
     */
    private void getDeltaTaxElementForPsa(YFSEnvironment env, Document orderListDoc, Element inprogressOrderElement) {
        logger.debug("KohlsLoadPSAOfflineQ.getDeltaTaxElementForPsa---Begin");
        Map<String, List> lineTax = (Map) env.getTxnObject(KohlsPOCConstant.TXN_DELTATAX);
        if (null != lineTax && lineTax.size() > 0) {
            logger.debug("Delta line taxes are set   :");
            List<Element> orderLineList = XMLUtil.getElementsByTagName(inprogressOrderElement,
                    KohlsPOCConstant.ELEM_ORDER_LINE);
            for (Element orderLine : orderLineList) {
                String orderLineKey = orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
                logger.debug("Order line key is   :" + orderLineKey);
                if (lineTax.containsKey(orderLineKey)) {
                    List<Element> liTax = lineTax.get(orderLineKey);
                    if (liTax.size() > 0) {
                        Element eleLineTaxes = liTax.get(0);
                        Element deltaTaxElement = orderListDoc.createElement(KohlsPOCConstant.XPATH_DELTATAX);
                        orderLine.appendChild(deltaTaxElement);
                        Node deltaLineTaxNode = orderListDoc.importNode(eleLineTaxes, true);
                        deltaTaxElement.appendChild(deltaLineTaxNode);

                    }
                }

            }
        }
        logger.debug("KohlsLoadPSAOfflineQ.getDeltaTaxElementForPsa---End");
    }

    /**
     * Method to check if this is the first change order.
     * 
     * @param env
     * @param orderHeaderKey
     * @throws ParserConfigurationException
     * @throws Exception
     */
    public String isFirstChangeOrder(YFSEnvironment env, String orderHeaderKey) throws ParserConfigurationException,
            Exception {
        logger.debug("KohlsLoadPSAOfflineQ.isFirstChangeOrder--Begin");
        String isFirstChangeOrder = "N";
        Document inputKohlsPsaOfflineQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
        Element inputKohlsPsaOfflineQElement = inputKohlsPsaOfflineQDoc.getDocumentElement();
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.API_CHANGE_ORDER);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_STATUS, KohlsPOCConstant.EXTN_PSA_IN_PROGRESS);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_IS_PROCESSED, KohlsPOCConstant.V_N);
        Element orderByElement = inputKohlsPsaOfflineQDoc.createElement(KohlsPOCConstant.E_ORDER_BY);
        inputKohlsPsaOfflineQElement.appendChild(orderByElement);
        Element attributeElement = inputKohlsPsaOfflineQDoc.createElement(KohlsPOCConstant.A_ATTRIBUTE);
        attributeElement.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_PSA_REPLICATION_SEQ);
        attributeElement.setAttribute(KohlsPOCConstant.A_DESC, KohlsPOCConstant.FLAG_Y);
        orderByElement.appendChild(attributeElement);
        Document psaOfflineQListDoc = invokeService(env, KohlsPOCConstant.SRVC_GET_PSA_OFFLINE_Q_LIST,
                inputKohlsPsaOfflineQDoc);
        if (!YFCCommon.isVoid(psaOfflineQListDoc)) {
            NodeList psaOfflineQList = psaOfflineQListDoc.getElementsByTagName(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
            if (psaOfflineQList.getLength() == 0) {
                logger.debug("This is the first PSA discount change order call");
                isFirstChangeOrder = KohlsPOCConstant.FLAG_Y;
            } else {
                logger.debug("This is not the first IN_PROGRESS call  :");
                Element psaOfflineQelement = (Element) psaOfflineQList.item(0);
                String orderString = psaOfflineQelement.getAttribute(KohlsPOCConstant.A_PSA_OPERATION_XML);
                Document orderDoc = XMLUtil.getDocument(orderString);
                NodeList promotionsList = XPathUtil.getNodeList(orderDoc.getDocumentElement(),
                        KohlsPOCConstant.XPATH_PROMOTION);
                Integer noOfDiscounts = promotionsList.getLength();
                logger.debug("the number of existing promotions on order    :" + noOfDiscounts.toString());
                env.setTxnObject(KohlsPOCConstant.TXN_NO_OF_DISCOUNT, noOfDiscounts);
            }

        }
        logger.debug("KohlsLoadPSAOfflineQ.isFirstChangeOrder--End");
        return isFirstChangeOrder;
    }

    /**
     * Method to form changeOrder input for Completed status.
     * 
     * @param env
     * @param orderElement
     * @throws ParserConfigurationException
     * @throws Exception
     * @throws SAXException
     * @throws IOException
     */
    private void changeOrderForPsaCompletedStatus(YFSEnvironment env, Element orderElement)
            throws ParserConfigurationException, Exception, SAXException, IOException {
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaStartedStatus--Begin");
        String orderHeaderKey = orderElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        Document inputOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        // this template needs to be changed
        Document orderListDoc = invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_LIST_COMPLETED_TEMPLATE),
                KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
        if (!YFCCommon.isVoid(orderListDoc)) {
            NodeList orderList = orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
            if (orderList.getLength() > 0) {
                Element orderRsElement = (Element) orderList.item(0);
                orderRsElement.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
                // form input to custom table
                populatePsaOfflineForPsaStatus(env, orderHeaderKey, orderRsElement,
                        KohlsPOCConstant.PSA_COMPLETED_STATUS);

            }
        }

        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaStartedStatus--End");
    }

    /**
     * Method to create the changeOrder input for psa started status and
     * populate the xml in psa offline q table.
     * 
     * @param env
     * @param inputDoc
     * @param orderElement
     * @param extnElement
     * @param extnPsaStatus
     * @param orderHeaderKey
     * @throws ParserConfigurationException
     * @throws Exception
     * @throws SAXException
     * @throws IOException
     */
    private void changeOrderForPsaStartedStatus(YFSEnvironment env, Element orderElement)
            throws ParserConfigurationException, Exception, SAXException, IOException {
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaStartedStatus--Begin");
        String orderHeaderKey = orderElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        // call get orderlist to stamp the rs response extn attributes
        Document inputOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        // this template needs to be changed
        Document orderListDoc = invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_LIST_STARTED_TEMPLATE),
                KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
        if (!YFCCommon.isVoid(orderListDoc)) {
            NodeList orderList = orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
            if (orderList.getLength() > 0) {
                Element orderRsElement = (Element) orderList.item(0);
                orderRsElement.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
                // form input to custom table
                populatePsaOfflineForPsaStatus(env, orderHeaderKey, orderRsElement, KohlsPOCConstant.EXTN_PSA_STARTED);

            }
        }

        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaStartedStatus--End");
    }

    /**
     * Method to generate the psa sequence number for psa offline q table.
     * 
     * @param env
     * @return
     * @throws Exception
     */
    private String getPSAReplicationSequence(YFSEnvironment env) throws Exception {
        logger.debug("KohlsLoadPSAOfflineQ.getPSAReplicationSequence--Begin");
        Statement statement = null;
        ResultSet resultSet = null;
        YCPContext context = (YCPContext) env;
        Connection connection = context.getDBConnection();
        String strPSASeq = "";

        try {
            statement = connection.createStatement();
            resultSet = statement
                    .executeQuery("select SEQ_PSA_REPLICATION_SEQUENCE.nextval as PSAReplicationSeq from dual");
            resultSet.next();
            strPSASeq = resultSet.getString(KohlsPOCConstant.SEQ_PSA_REPLICATION_SEQ);
            logger.debug("PSA non sync sequence number is  :" + strPSASeq);
        } catch (SQLException sqle) {
            sqle.printStackTrace();

        } finally {
            try {

                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        logger.debug("KohlsLoadPSAOfflineQ.getPSAReplicationSequence--End");
        return strPSASeq;
    }

    /**
     * Method to form changeOrder input for VOIDED status.
     * 
     * @param env
     * @param orderHeaderKey
     * @param status
     * @throws Exception
     */
    private void changeOrderForPsaVoidedStatus(YFSEnvironment env, String orderHeaderKey, String status)
            throws Exception {
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaVoidedStatus---Begin");
        Document inputOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        boolean isVoidedWithoutDiscounts = false;
        if (KohlsPOCConstant.PSA_VOIDED_STATUS.equals(status)) {
            logger.debug("Check if the void is without discounts  :");
            isVoidedWithoutDiscounts = changeOrderStatusForVoidedWithoutDiscounts(env, orderHeaderKey, inputOrderDoc,
                    isVoidedWithoutDiscounts);
            logger.debug("Is void without discount   :" + isVoidedWithoutDiscounts);

        }

        if (!isVoidedWithoutDiscounts) {

            // this template needs to be changed
            Document orderListDoc = invokeAPI(env, KohlsPOCConstant.GET_ORDER_LIST_FOR_PSA_TEMPLATE,
                    KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
            if (!YFCCommon.isVoid(orderListDoc)) {
                Element inprogressOrderElement = (Element) orderListDoc.getElementsByTagName(
                        KohlsPOCConstant.ELEM_ORDER).item(0);
                logger.debug("Setting IgnoreRepricingUE flag to Y for sync  :");
                inprogressOrderElement.setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FLAG_Y);
                inprogressOrderElement.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
                // get the Promotions element from order level
                NodeList promotionsList = XPathUtil.getNodeList(inprogressOrderElement, KohlsPOCConstant.E_PROMOTIONS);
                if (promotionsList.getLength() > 0) {
                    logger.debug("Setting the Rest flag on order promotions for void scenarios  :");
                    Element promotionsElement = (Element) promotionsList.item(0);
                    logger.debug("Stamping the ispsachangeorder attributes");
                    promotionsElement.setAttribute(KohlsPOCConstant.IS_PSA_CHANGE_ORDER, KohlsPOCConstant.FLAG_Y);
                    promotionsElement.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.FLAG_Y);
                }
                // Line level promotions will not be reset
                List<Element> orderLineList = XMLUtil.getElementsByTagName(inprogressOrderElement,
                        KohlsPOCConstant.ELEM_ORDER_LINE);
                for (Element orderLine : orderLineList) {
                    NodeList orderlinePromotionsList = orderLine.getElementsByTagName(KohlsPOCConstant.E_PROMOTIONS);
                    if (orderlinePromotionsList.getLength() > 0) {
                        Element orderlinepromotionsElement = (Element) orderlinePromotionsList.item(0);
                        logger.debug("Setting the line level promotion Reset flag to N  :");
                        orderlinepromotionsElement.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.V_N);
                    }
                    NodeList lineChargesList = orderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGES);
                    if (lineChargesList.getLength() > 0) {
                        Element lineChargesElement = (Element) lineChargesList.item(0);
                        logger.debug("Setting the line chanrges reset flag to Y");
                        lineChargesElement.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.FLAG_Y);
                    }
                }

                // append the delta line tax calculation to the change order
                // input
                getDeltaTaxElementForPsa(env, orderListDoc, inprogressOrderElement);

                populatePsaOfflineForPsaStatus(env, orderHeaderKey, inprogressOrderElement, status);
            }
        }
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderForPsaVoidedStatus---End");

    }

    /**
     * Method to form changeOrder input for Voided Status without discounts.
     * 
     * @param env
     * @param orderHeaderKey
     * @param inputOrderDoc
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private boolean changeOrderStatusForVoidedWithoutDiscounts(YFSEnvironment env, String orderHeaderKey,
            Document inputOrderDoc, boolean isVoidedWithoutDiscounts) throws ParserConfigurationException, Exception {
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderStatusForVoidedWithoutDiscounts ---Begin");
        // for voided without discounts
        Document inputKohlsPsaOfflineQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
        Element inputKohlsPsaOfflineQElement = inputKohlsPsaOfflineQDoc.getDocumentElement();
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.API_CHANGE_ORDER);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_STATUS, KohlsPOCConstant.EXTN_PSA_IN_PROGRESS);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_IS_PROCESSED, KohlsPOCConstant.V_N);
        Document psaOfflineQListDoc = invokeService(env, KohlsPOCConstant.SRVC_GET_PSA_OFFLINE_Q_LIST,
                inputKohlsPsaOfflineQDoc);
        if (!YFCCommon.isVoid(psaOfflineQListDoc)) {
            logger.debug("Retrieved the PsaOfflineQList  :");
            NodeList psaOfflineQList = psaOfflineQListDoc.getElementsByTagName(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
            logger.debug("No of records in progress for voided status  :" + psaOfflineQList.getLength());
            if (psaOfflineQList.getLength() == 0) {
                isVoidedWithoutDiscounts = true;
                Document orderListDoc = invokeAPI(env,
                        XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_LIST_VOIDED_TEMPLATE),
                        KohlsPOCConstant.API_GET_ORDER_LIST, inputOrderDoc);
                if (!YFCCommon.isVoid(orderListDoc)) {
                    NodeList orderList = orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
                    if (orderList.getLength() > 0) {
                        Element orderElement = (Element) orderList.item(0);
                        orderElement.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
                        // form input to custom table
                        populatePsaOfflineForPsaStatus(env, orderHeaderKey, orderElement,
                                KohlsPOCConstant.PSA_VOIDED_STATUS);

                    }
                }
            }

        }
        logger.debug("KohlsLoadPSAOfflineQ.changeOrderStatusForVoidedWithoutDiscounts ---End");
        return isVoidedWithoutDiscounts;
    }
}
