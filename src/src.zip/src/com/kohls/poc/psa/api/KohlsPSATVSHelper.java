package com.kohls.poc.psa.api;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPSATVSHelper {

  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPSATVSHelper.class.getName());
  }

  /**
   * 
   * @param promotionsEle
   * @param lidOfferExempt
   * @param tempOrderEle
   */
  @SuppressWarnings("unchecked")
  public void constructLidOfferExemptPSA(Element promotionsEle, Element lidOfferExempt,
      Element tempOrderEle) {
    logger.beginTimer("KohlsPoCTVSCaller.constructLidOfferExemptPSA");
    List<Element> orderPromotionList =
        XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
    XMLUtil.setNodeValue(lidOfferExempt, KohlsPOCConstant.NO);

    String promotionType = KohlsPOCConstant.BLANK;

    for (Element promotion : orderPromotionList) {
      promotionType = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_PROMOTION_TYPE);

      String promotionId = XMLUtil.getAttribute(promotion, KohlsPOCConstant.PROMOTIONID);

      Element extnEle = XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

      String extnPromotionFlag =
          XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
      String isPsaPromotion = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION);

      boolean lidValidationPrecedence = validatePrecedencelid(promotionId, tempOrderEle);

      if ((KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType))
          || (KohlsPOCConstant.KOHLSCASH.equalsIgnoreCase(promotionType))
          || (lidValidationPrecedence == true) && (!YFCCommon.isStringVoid(extnPromotionFlag)
              && YFCCommon.isStringVoid(isPsaPromotion))) {
        XMLUtil.setNodeValue(lidOfferExempt, KohlsPOCConstant.YES);
        break;
      }
    }
    logger.endTimer("KohlsPoCTVSCaller.constructLidOfferExemptPSA");
  }

  /**
   * 
   * @param promotionId
   * @param tempOrderEle
   * @return
   */
  @SuppressWarnings("unchecked")
  private boolean validatePrecedencelid(String promotionId, Element tempOrderEle) {
    logger.beginTimer("KohlsPoCTVSCaller.validatePrecedencelid");
    List<Element> orderLineList =
        XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
    String precedence = KohlsPOCConstant.BLANK;

    for (Element orderLine : orderLineList) {
      NodeList awardList = orderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);

      for (int iterator = 0; iterator < awardList.getLength(); iterator++) {

        Element awardElement = (Element) awardList.item(iterator);
        String awardPromotionId =
            XMLUtil.getAttribute(awardElement, KohlsPOCConstant.A_PROMOTION_ID);

        if (awardPromotionId.equalsIgnoreCase(promotionId)) {
          Element awardExtn = XMLUtil.getChildElement(awardElement, KohlsPOCConstant.A_EXTN);
          String salesHubClob =
              XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);

          if (!YFCCommon.isVoid(salesHubClob)) {
            Element salesHubDataEle = null;
            try {
              salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
            } catch (ParserConfigurationException e) {
              logger
                  .error("ParserConfigurationException at KohlsPoCTVSCaller.validatePrecedencelid");
            } catch (SAXException e) {
              logger.error("SAXException at KohlsPoCTVSCaller.validatePrecedencelid");
            } catch (IOException e) {
              logger.error("IOException at KohlsPoCTVSCaller.validatePrecedencelid");
            }

            if (!YFCCommon.isVoid(salesHubDataEle)) {
              precedence = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_PRECEDENCE);
            }
            if (precedence.equalsIgnoreCase(KohlsPOCConstant.THIRTY_SIX)
                || precedence.equalsIgnoreCase("37")) {
              return true;
            }
          }
        }
      }
    }
    logger.endTimer("KohlsPoCTVSCaller.validatePrecedencelid");
    return false;
  }

  /**
   * This methods calculates the NetPrice of the Item.
   * 
   * @param orderLine
   * @param promotions
   * @return
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  public double calculateItemNetPrice(YFSEnvironment env, Element orderLine, Element promotions) throws Exception {
    logger.beginTimer("KohlsPoCTVSCaller.calculateItemNetPrice");
    double totalItemPrice = 0.00;
    double totalAwards = 0.00;
    
    Element eleOrigOrderLines = (Element) env.getTxnObject("OriginalOrderLinesForPSA");
    Element eleOrigOrderLine = (Element) SCXmlUtil.getXpathNodes(eleOrigOrderLines, 
        "//OrderLines/OrderLine[@OrderLineKey='"+orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY)+"']").item(0);
    List <Element> origAwardList = XMLUtil.getElementsByTagName(eleOrigOrderLine,KohlsXMLLiterals.E_AWARD);

    Element orderLineExtn = XMLUtil.getChildElement(orderLine, KohlsXMLLiterals.E_EXTN);
    String orderLineNetPrice =
        XMLUtil.getAttribute(orderLineExtn, KohlsPOCConstant.A_EXTN_NET_PRICE);

    List<Element> promotionList =
        XMLUtil.getElementsByTagName(promotions, KohlsPOCConstant.E_PROMOTION);
    List<Element> awardList = XMLUtil.getElementsByTagName(orderLine, KohlsXMLLiterals.E_AWARD);

    for (Element award : awardList) {
      String awardPromoId = XMLUtil.getAttribute(award, KohlsXMLLiterals.E_PROMOTION_ID);
      Element eleAwardExtn = XMLUtil.getChildElement(award, KohlsXMLLiterals.E_EXTN, true);
      String isPSAPromotion = "";
      
      // Calculating changes to the Promotions from orig sale.
      for(Element origAward : origAwardList) {
          String origAwardPromoId = XMLUtil.getAttribute(origAward,KohlsXMLLiterals.E_PROMOTION_ID);
          String currentAwardPromoId = XMLUtil.getAttribute(award, KohlsXMLLiterals.E_PROMOTION_ID);
          if("ASSOC_DISC_MANUAL_SOFT_LINE".equalsIgnoreCase(currentAwardPromoId) || "ASSOC_DISC_MANUAL_HARD_LINE".equalsIgnoreCase(currentAwardPromoId)) {
            currentAwardPromoId = "790";
          }
          if("ASSOC_DISC_MANUAL_SOFT_LINE".equalsIgnoreCase(origAwardPromoId) || "ASSOC_DISC_MANUAL_HARD_LINE".equalsIgnoreCase(origAwardPromoId)) {
            origAwardPromoId = "790";
          }
          if(!YFCCommon.isVoid(currentAwardPromoId) && !YFCCommon.isVoid(origAwardPromoId) && origAwardPromoId.contains( currentAwardPromoId)
              && !currentAwardPromoId.contains("FEE_")){
              //adjusted AwardAmt calculated
            totalAwards = totalAwards - (Math.abs(Math.abs(Double.parseDouble(origAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT)) - 
                Double.parseDouble(award.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT)))));
            break;
           }
        }
      
      for (Element promotion : promotionList) {
        String promoId = XMLUtil.getAttribute(promotion, KohlsXMLLiterals.E_PROMOTION_ID);

        if (awardPromoId.equalsIgnoreCase(promoId)) {
          Element promoExtn = XMLUtil.getChildElement(promotion, KohlsXMLLiterals.E_EXTN);
          isPSAPromotion = XMLUtil.getAttribute(promoExtn, KohlsPOCConstant.ISPSAPROMOTION);
          break;
        }
      }

      if (KohlsPOCConstant.YES.equalsIgnoreCase(isPSAPromotion)) {
        //String awardAmount = XMLUtil.getAttribute(award, KohlsPOCConstant.A_AWARD_AMOUNT);
        String awardAmount = XMLUtil.getAttribute(eleAwardExtn, KohlsPOCConstant.A_EXTN_NET_DELTA);
        if(YFCCommon.isVoid(awardAmount)) {
          awardAmount = "0.00";
        }
        totalAwards += Math.abs(Double.parseDouble(awardAmount));
      }
    }
    totalItemPrice = Double.parseDouble(orderLineNetPrice) + totalAwards;
    DecimalFormat df = new DecimalFormat("0.00");
    String tempNetPrice = df.format(totalItemPrice);

    double itemNetPrice = Double.valueOf(tempNetPrice);
    logger.debug("NetPrice of Item:" + itemNetPrice);
    logger.endTimer("KohlsPoCTVSCaller.calculateItemNetPrice");
    return itemNetPrice;
  }

  /**
   * This Method creates transactionId,transactionTime,storeNum and storeAddress elements in the
   * request to call TVS web service
   * 
   * @param env
   * @param tempOrderEle
   * @param transactionEle
   * @throws Exception
   * @throws YFSException
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   */
  public void createConstantEleForTVSReq(YFSEnvironment env, Element tempOrderEle,
      Element transactionEle)
      throws Exception, YFSException, ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsPoCTVSCaller.createConstantEleForTVSReq");
	logger.debug("Input to KohlsPoCTVSCaller - tempOrderEle ::" + XMLUtil.getElementXMLString(tempOrderEle));
    // Adding transactionId as POSSeqNo to the input request
    String transId = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
    Element eleTransactionId =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
    XMLUtil.setNodeValue(eleTransactionId, transId);

    String transTime = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORDER_DATE);
    Element eletransactionTime =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.TRANSACTION_TIME);
    XMLUtil.setNodeValue(eletransactionTime, transTime);
	logger.debug(" *** date ***" + transTime);

    // Adding store number to the input request
    String shipNode =
        XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
    // Appending zero when store number length is less than 4
    shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
    Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
    XMLUtil.setNodeValue(eleStoreNum, shipNode);

    // Adding storeAddress details to TVS request
    Element storeAddressEle =
        XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
    Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
    Element eleCountry =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
    Element elePostal =
        XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
    Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
    Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);

    NodeList nlOrderLine =
        (NodeList) XPathUtil.getNodeList(tempOrderEle, KohlsXMLLiterals.XPATH_ORDER_LINE);
    if (!YFCCommon.isVoid(nlOrderLine)) {
      Element eleShipNdPerInfo = (Element) ((NodeList) XPathUtil.getNodeList(tempOrderEle,
          KohlsXMLLiterals.XPATH_SHIPNOD_EPERSON_INFO)).item(0);
      if (!YFCCommon.isVoid(eleShipNdPerInfo)) {
        XMLUtil.setNodeValue(eleCity,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
        XMLUtil.setNodeValue(eleCountry,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
        XMLUtil.setNodeValue(elePostal,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
        XMLUtil.setNodeValue(eleState,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));

        String sGeoCode =
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE);
        if (YFCCommon.isVoid(sGeoCode)) {
          YFSException yfsException = new YFSException();
          yfsException.setErrorCode(KohlsPOCConstant.INVALID_GEO_CODE);
          yfsException.setErrorDescription(
              KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_GEO_CODE));
          throw yfsException;

        } else {
          XMLUtil.setNodeValue(eleGeo, sGeoCode);
        }
      } else {
        Document getOrganizationHierarchyInput =
            XMLUtil.getDocument("<Organization OrganizationCode='"
                + tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)
                + "' OrganizationKey='"
                + tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)
                + "' ></Organization>");
        Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
            "<Organization OrganizationName=''><Node><ShipNodePersonInfo/></Node></Organization>");
        Document getOrganizationListOutput =
            KOHLSBaseApi.invokeAPI(env, getOrganizationHierarchyTemplate,
                KohlsConstant.GET_ORGANIZATION_HIERARCHY_API, getOrganizationHierarchyInput);
        eleShipNdPerInfo = ((Element) getOrganizationListOutput
            .getElementsByTagName(KohlsXMLLiterals.E_SHIPNODE_PERSON_INFO).item(0));
        XMLUtil.setNodeValue(eleCity,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
        XMLUtil.setNodeValue(eleCountry,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
        XMLUtil.setNodeValue(elePostal,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
        XMLUtil.setNodeValue(eleState,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
        XMLUtil.setNodeValue(eleGeo,
            XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
      }
    }
    logger.endTimer("KohlsPoCTVSCaller.createConstantEleForTVSReq");
  }

  /**
   * @param itemEle
   * @param extnEle
   */
  public void createMerchandiseHierarchy(Element itemEle, Element extnEle) {
    logger.beginTimer("KohlsPoCTVSCaller.createMerchandiseHierarchy");
    // creating merchandise element
    Element EleMerchandise = XMLUtil.createChild(itemEle, KohlsPOCConstant.MERCHANDISE_HIRARCHY);

    String department = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_ITEM_DEPT);
    Element deptElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.DEPARTMENT);
    XMLUtil.setNodeValue(deptElement, department);

    String majorClass = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_ITEM_CLASS);
    Element majorClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.MAJOR_CLASS);
    XMLUtil.setNodeValue(majorClassElement, majorClass);

    String subClass = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_ITEM_SUB_CLASS);
    Element subClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.SUB_CLASS);
    XMLUtil.setNodeValue(subClassElement, subClass);

    String vendorStyle = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_VENDOR_STYLE_NO);
    Element vendorStyleElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.VENDOR_STYLE);
    if (YFCCommon.isVoid(vendorStyle)) {
      vendorStyle = "10";
    }
    XMLUtil.setNodeValue(vendorStyleElement, vendorStyle);
    logger.endTimer("KohlsPoCTVSCaller.createMerchandiseHierarchy");
  }

  /**
   * @param env
   * @param tvsResponseDoc
   * @param firstTVSRequestDoc
   * @return
   */
  public Document callPSATVSWebService(YFSEnvironment env, Document tvsResponseDoc,
      Document firstTVSRequestDoc) {
    logger.beginTimer("KohlsPoCTVSCaller.callPSATVSWebService");
    try {
      logger.debug("Input to TVS call for PSA ::" + XMLUtil.getXMLString(firstTVSRequestDoc));
      tvsResponseDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_POC_PSA_WEB_SERVICE,
          firstTVSRequestDoc);
      logger.debug("Output of TVS call for PSA ::" + XMLUtil.getXMLString(tvsResponseDoc));
    } catch (Exception e) {
      logger.error("Error While Calling TVS web service for PSA" + e.getStackTrace());
    }
    logger.endTimer("KohlsPoCTVSCaller.callPSATVSWebService");
    return tvsResponseDoc;
  }

  /**
   * @param secondTVSResponseDoc
   * @return
   * @throws ParserConfigurationException
   * @throws DOMException
   */
  public Document validateTVSResponse(Document secondTVSResponseDoc)
      throws ParserConfigurationException, DOMException {
    logger.beginTimer("KohlsPoCTVSCaller.validateTVSResponse");
    if (YFCCommon.isVoid(secondTVSResponseDoc)) {
      Document docError = XMLUtil.createDocument("Errors");
      Element eleErrors = docError.getDocumentElement();
      Element eleError = XMLUtil.createChild(eleErrors, "Error");
      eleError.setAttribute("ErrorDescription", "Exception while Invoking TVS Web Service!!");
      return docError;
    }
    logger.endTimer("KohlsPoCTVSCaller.validateTVSResponse");
    return secondTVSResponseDoc;
  }

  /**
   * @param eleOrderLine
   * @param orderLineExtnEle
   * @param eleOutputItem
   * @throws YFSException
   */
  public void createTaxAttributes(Element eleOrderLine, Element orderLineExtnEle,
      Element eleOutputItem) throws YFSException {
    logger.beginTimer("KohlsPoCTVSCaller.createTaxAttributes");
    // contruction of taxCodeIndicator Element
    String sTaxCode = orderLineExtnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE);
    if (!YFCCommon.isVoid(sTaxCode) && sTaxCode.matches(".*\\d.*")) {
      // logger.debug("sTaxCode value ::"+sTaxCode);
      Element eleTaxCodeIndicator =
          XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
      XMLUtil.setNodeValue(eleTaxCodeIndicator, sTaxCode);
    } else {
      // logger.debug("else TaxcodeIndicator ::::"+sTaxCode);
      YFSException yfsException = new YFSException();
      yfsException.setErrorCode(KohlsPOCConstant.TAXCODE_INDICATOR_ERR);
      yfsException.setErrorDescription(
          KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TAXCODE_INDICATOR_ERR));
      throw yfsException;
    }

    // contruction of taxExempt Element
    Element linePriceInfoEle =
        XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_LINE_PRICE_INFO);
    Element eleTaxExempt = XMLUtil.createChild(eleOutputItem, KohlsPOCConstant.ATTR_TAX_EXEMPT);
    String strTaxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
    if (!YFCCommon.isVoid(strTaxableFlag) && (strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.NO)
        || strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.OVERRIDE_TAX_O))) {
      XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
    } else {
      XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);
    }
    logger.endTimer("KohlsPoCTVSCaller.createTaxAttributes");
  }

  
}
