package com.kohls.poc.psa.api;


import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCPinPadOperations;
import com.kohls.poc.util.KohlsPoCPinPadPostVoidOperations;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author POC Returns Team
 *
 **************************************************************************
 * File : KohlsPSAChargeForPV.java Author : POC Returns Team 
 ***************************************************************************** 
 * This Class is handles All Tender Charges with respect to Post Sale 
 * Adjustment Post Void scenarios
 ***************************************************************************** 
 * 
 * Sample Input :
 * 
 * <Order OperatorID="9600007" OrderHeaderKey="111608010240344729533" PosSequenceNo="0151" TerminalID="45"/>
 * 
 * Dependencies:
 * 
 * \Foundation\extensions\global\template\xsl\poc\KohlsPocPVGetOrderListInput.xsl
 * \Foundation\extensions\global\template\api\POC\PSAPostVoid\POC_getOrderListPSAPostVoid.xml
 * 
 *****************************************************************************/
public class KohlsPSAChargeForPV {

	private static YFCLogCategory logger;
	private String strOHKey=KohlsPOCConstant.BLANK;
	private Document docChanUEClone=null;
	private boolean bIsDebugEnabled=YFCLogUtil.isDebugEnabled();
	//Create a object of KohlsPSARefund to access the generic methods
	KohlsPSARefund kohlsPSARefund = new KohlsPSARefund();
	private double timeTaken = 0.00;
	//PR-992 - Start
	// private String strCurrentPSATranNo = null;
			//PR-992 - End
	static {
		logger = YFCLogCategory.instance(KohlsPSARefund.class.getName());
	}

	/**
	 * 
	 * This method acts as a controller for
	 * Charging customer back in case of 
	 * Post Sale Adjustment Post Void Scenarios
	 * 
	 * @param yfsEnv
	 * @param docInputPV
	 */
	@SuppressWarnings("unused")
	public Document setPSAChargeForPostVoid(YFSEnvironment yfsEnv,Document docInputPV) {
		long lStartTime=System.nanoTime();
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid -- Start");
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid lStartTime="+lStartTime);
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docInputPV="+XMLUtil.getXMLString(docInputPV));
			}
			String strIsFirstPSAPV=(String) yfsEnv.getTxnObject(KohlsXMLLiterals.ATTR_IS_FIRST_PSA_POST_VOID);
			if(!YFCCommon.isStringVoid(strIsFirstPSAPV)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid strIsFirstPSAPV="+strIsFirstPSAPV);
			}
			}
			else if(YFCCommon.isStringVoid(strIsFirstPSAPV)){ 
			setFirstPSAPVTxnObj(yfsEnv);
			//Gets the Order element from OrderList
			docInputPV=getOrderFromList(docInputPV);
			//Save the Order details to a clone to retrieve the Order details later
			docChanUEClone=docInputPV;
			//Get the OrderHeaderKey from the input document and save it
			strOHKey=kohlsPSARefund.getOHKey(docInputPV);
			//PR-922 - Start
			// Element elePSAOrder = docChanUEClone.getDocumentElement();
			// strCurrentPSATranNo = XMLUtil.getAttribute(elePSAOrder, "TransactionNo");
			//PR-992 - End
			if(bIsDebugEnabled && !YFCCommon.isStringVoid(strOHKey)){
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid strOHKey="+strOHKey);
			}
			//Prepare the input for requestCollection api
			Document docRequestCollInp=kohlsPSARefund.inputToRequestCollection(strOHKey);
			if(bIsDebugEnabled && !YFCCommon.isVoid(docRequestCollInp)){
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docrequestCollInp="+XMLUtil.getXMLString(docRequestCollInp));
			}
			//Call the requestCollection api
			Document docReqCollOut=kohlsPSARefund.callRequestCollectionAPI(yfsEnv, docRequestCollInp);
			if(bIsDebugEnabled && !YFCCommon.isVoid(docReqCollOut)){
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docReqCollOut="+XMLUtil.getXMLString(docReqCollOut));
			}
			//Compare the Output of requestCollection api for success
			if((!YFCCommon.isVoid(docReqCollOut)) && (docReqCollOut.getDocumentElement().getNodeName().equalsIgnoreCase(KohlsPOCConstant.ELEM_ORDER))){
				//Input to call getChargeTransactionList api is prepared
				Document docCharTransInput=kohlsPSARefund.inputToGetChargeTransactionList(strOHKey);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docCharTransInput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docCharTransInput="+XMLUtil.getXMLString(docCharTransInput));
				}	
				//getChargeTransactionList api is called
				Document docCharTransOutput=kohlsPSARefund.callGetChargeTransactionListAPI(yfsEnv,docCharTransInput);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docCharTransOutput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docCharTransOutput="+XMLUtil.getXMLString(docCharTransOutput));
				}
				//A list of ChargeTransactionKey(s) is prepared from the output of getChargeTransactionList api
				List<String> chargeTrnsactionKeys=kohlsPSARefund.getChargeTransactionKeys(docCharTransOutput);
				if(!chargeTrnsactionKeys.isEmpty()){
				//Input to voidChargeTransaction api is prepared
				Document docVoidChargTransInput=kohlsPSARefund.voidChargeTransactioninDoc(chargeTrnsactionKeys);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docVoidChargTransInput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docVoidChargTransInput="+XMLUtil.getXMLString(docVoidChargTransInput));
				}
				//voidChargeTransaction api is called
				Document docVoidChargTransOutput=kohlsPSARefund.callvoidChargeTransaction(yfsEnv,docVoidChargTransInput);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docVoidChargTransOutput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docVoidChargTransOutput="+XMLUtil.getXMLString(docVoidChargTransOutput));
				}
				}
				//Input to getPaymentList is prepared
				Document docGetPayListInput=inputToGetPaymentListPV(strOHKey);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docGetPayListInput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docGetPayListInput="+XMLUtil.getXMLString(docGetPayListInput));
				}
				//getPaymentList api is called
				Document docGetPayListOutput=kohlsPSARefund.callgetPaymentList(yfsEnv,docGetPayListInput);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docGetPayListOutput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docGetPayListOutput="+XMLUtil.getXMLString(docGetPayListOutput));
				}
				//A skeleton input for input of recordExternalCharges api is prepared
				Document docFormInputForRecord=formInputSklToRecordExternalChargesPV();
				if(bIsDebugEnabled && !YFCCommon.isVoid(docFormInputForRecord)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docFormInputForRecord="+XMLUtil.getXMLString(docFormInputForRecord));
				}
				//The input for recordExternalCharges api is updated and api is called
				Document docUpdateInputForRecord=formAndCallInputToRecordExternalChargesPV(yfsEnv,docGetPayListOutput,docFormInputForRecord,docInputPV);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docUpdateInputForRecord)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docUpdateInputForRecord="+XMLUtil.getXMLString(docUpdateInputForRecord));
				}
				//Input to capturePayment api is prepared
				Document docCapturePayInp=formInputToCapturePay(docGetPayListOutput);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docCapturePayInp)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docCapturePayInp="+XMLUtil.getXMLString(docCapturePayInp));
				}
				//capturePayment api is called
				Document docCapturePayOut=kohlsPSARefund.callCapturePaymentAPI(yfsEnv, docCapturePayInp);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docCapturePayOut)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docCapturePayOut="+XMLUtil.getXMLString(docCapturePayOut));
				}
				//Prepare Input for executeCollection api
				Document docExcCollInput=kohlsPSARefund.inputToExecuteCollection(strOHKey);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docExcCollInput)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docExcCollInput="+XMLUtil.getXMLString(docExcCollInput));
				}
				//Call executeCollection api
				Document docExcCollOutput= kohlsPSARefund.callExecuteCollectionAPI(yfsEnv,docExcCollInput);
				//Commented because not sure whether to remove PaymentReference6 or not -- Start
				/*
				//Input to remove PaymentReference6 using capturePayment is formed
				Document docInputToRemovePayRef6=formAndCallCapPayRemovePayRef6(docGetPayListOutput);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docInputToRemovePayRef6)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docInputToRemovePayRef6="+XMLUtil.getXMLString(docInputToRemovePayRef6));
				}
				//capturePayment api is called
				Document docCapPayOut=kohlsPSARefund.callCapturePaymentAPI(yfsEnv, docInputToRemovePayRef6);
				if(bIsDebugEnabled && !YFCCommon.isVoid(docCapPayOut)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docCapPayOut="+XMLUtil.getXMLString(docCapPayOut));
				}
				//Commented because not sure whether to remove PaymentReference6 or not -- End
				 */
				//Call requestCollection api
				docReqCollOut=kohlsPSARefund.callRequestCollectionAPI(yfsEnv,docRequestCollInp);	
				if(bIsDebugEnabled && !YFCCommon.isVoid(docReqCollOut)){
					logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid docReqCollOut="+XMLUtil.getXMLString(docReqCollOut));
				}
			}
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.setPSAChargeForPostVoid Exception"+e.getMessage());
		}
		long lEndTime=System.nanoTime();
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid lEndTime"+lEndTime);
	        logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid Time Elapsed Approx"+(lEndTime-lStartTime));
			logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid -- End");
		}
		return docChanUEClone;
	}

	/**
	 * 
	 * Set a Transaction Object to differentiate 
	 * between First PSA Post Void Transaction and 
	 * subsequent calls  
	 * 
	 * @param yfsEnv
	 */
	private void setFirstPSAPVTxnObj(YFSEnvironment yfsEnv) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.setFirstPSAPVTxnObj -- Start");
		}
		try{
			yfsEnv.setTxnObject(KohlsXMLLiterals.ATTR_IS_FIRST_PSA_POST_VOID, KohlsPOCConstant.YES);
			if(bIsDebugEnabled){
				String strIsFirstPSAPV=(String) yfsEnv.getTxnObject(KohlsXMLLiterals.ATTR_IS_FIRST_PSA_POST_VOID);
				if(!YFCCommon.isStringVoid(strIsFirstPSAPV)){
				logger.debug("KohlsPSAChargeForPV.setPSAChargeForPostVoid strIsFirstPSAPV"+strIsFirstPSAPV);
				}
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.setPSAChargeForPostVoid Exception"+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.setFirstPSAPVTxnObj -- End");
		}
	}

	/**
	 * 
	 * This method returns the Order document from 
	 * OrderList
	 * 
	 * @param docInputPV
	 * @return
	 */
	private Document getOrderFromList(Document docInputPV) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.getOrderFromList -- Start");
		}
		try{
			Element eleOrderList=docInputPV.getDocumentElement();
			Element eleOrder=XMLUtil.getChildElement(eleOrderList, KohlsPOCConstant.ELEM_ORDER);
			if(bIsDebugEnabled && !YFCCommon.isVoid(eleOrder)){
				logger.debug("KohlsPSAChargeForPV.getOrderFromList eleOrder="+XMLUtil.getElementXMLString(eleOrder));
			}	
			if(!YFCCommon.isVoid(eleOrder)){
				docInputPV=XMLUtil.getDocumentForElement(eleOrder);
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.getOrderFromList Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.getOrderFromList docOrder="+XMLUtil.getXMLString(docInputPV));
			logger.debug("KohlsPSAChargeForPV.getOrderFromList -- End");
		}
		return docInputPV;
	}

	/**
	 * 
	 * This method prepares the input to remove
	 * the PaymentReference6 from the Order
	 * 
	 * @param docGetPayListOutput
	 * @return
	 */
	@SuppressWarnings("unused")
	private Document formAndCallCapPayRemovePayRef6(Document docGetPayListOutput) {

		Document docCapPayInp=null;
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 -- Start");
		}
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 docGetPaylistOutput="+XMLUtil.getXMLString(docGetPayListOutput));
			}
			//Create a new Document for the input
			docCapPayInp=XMLUtil.createDocument(KohlsXMLLiterals.E_CAPTURE_PAYMENT);
			Element eleCapPayInp=docCapPayInp.getDocumentElement();
			//Set the OrderHeaderKey
			eleCapPayInp.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
			Element elePayMeths = XMLUtil.createChild(eleCapPayInp, KohlsXMLLiterals.E_PAYMENT_METHODS);
			//Traverse through the nodeList of getPaymentList api Output
			NodeList ndlPayList = XPathUtil.getNodeList(docGetPayListOutput, KohlsXMLLiterals.XPATH_PAY_METH_LIST);
			int iSize=ndlPayList.getLength();
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 iSize="+iSize);
			}
			for (int i = 0; i < iSize; i++) {
				Element eleCurrPayMeth = (Element)ndlPayList.item(i);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 eleCurrPayMeth="+XMLUtil.getElementXMLString(eleCurrPayMeth));
				}
				Element elePayMeth=XMLUtil.createChild(elePayMeths, KohlsPOCConstant.E_PAYMENT_METHOD);
				String sPayKey=eleCurrPayMeth.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 sPayKey="+sPayKey);
				}
				//Set the Parameters for the input
				elePayMeth.setAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY, sPayKey);
				//Commented because ExecuteCollection will require this attribute to have value.
				//elePayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6, "");
				elePayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6, "PSA_POSTVOID");
				elePayMeth.setAttribute(KohlsXMLLiterals.A_OPERATION, KohlsXMLLiterals.CONST_MANAGE);
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 docCappayInp after="+XMLUtil.getXMLString(docCapPayInp));
			logger.debug("KohlsPSAChargeForPV.formAndCallCapPayRemovePayRef6 -- End");
		}
		return docCapPayInp;
	}

	/**
	 * 
	 * This method forms input for 
	 * capturePayment api
	 * 
	 * @param docGetPayListOutput
	 * @return
	 */
	private Document formInputToCapturePay(Document docGetPayListOutput) {
		Document docCapPayInp=null;
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formInputToCapturePay -- Start");
		}
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.formInputToCapturePay docGetPayListOutput="+XMLUtil.getXMLString(docGetPayListOutput));
			}
			//Create a new document as required for the api
			docCapPayInp=XMLUtil.createDocument(KohlsXMLLiterals.E_CAPTURE_PAYMENT);
			Element eleCapPayInp=docCapPayInp.getDocumentElement();
			eleCapPayInp.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
			Element elePayMeths = XMLUtil.createChild(eleCapPayInp, KohlsXMLLiterals.E_PAYMENT_METHODS);
			//Traverse through the nodeList of getPaymentList api Output
			NodeList ndlPayList = XPathUtil.getNodeList(docGetPayListOutput, KohlsXMLLiterals.XPATH_PAY_METH_LIST);
			int iSize=ndlPayList.getLength();
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.formInputToCapturePay iSize="+iSize);
			}
			for (int i = 0; i < iSize; i++) {
				Element eleCurrPayMeth = (Element)ndlPayList.item(i);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSAChargeForPV.formInputToCapturePay eleCurrPayMeth="+XMLUtil.getElementXMLString(eleCurrPayMeth));
				}
				String sPaymentType=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				if(!YFCCommon.isStringVoid(sPaymentType)){
					if(bIsDebugEnabled){
						logger.debug("KohlsPSAChargeForPV.formInputToCapturePay sPaymentType="+sPaymentType);
					}
					//Check if the PaymentMethod Element is a Credit Card or KMC Or Not
					boolean bIsNotCard=checkIfNotCard(sPaymentType);
					if(bIsDebugEnabled){
						logger.debug("KohlsPSAChargeForPV.formInputToCapturePay bIsNotCard="+bIsNotCard);
					}
					//If it is not a Card Proceed
					if(bIsNotCard){
						Element elePayMeth=XMLUtil.createChild(elePayMeths, KohlsXMLLiterals.E_PAYMENT_METHOD);
						String sPayKey=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
						String sTotalRefAmt=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_TOTAL_REFUNDED_AMT);
						elePayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_KEY, sPayKey);
						elePayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, sPaymentType);
						elePayMeth.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION, KohlsXMLLiterals.CONST_Y);
						elePayMeth.setAttribute(KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS, KohlsXMLLiterals.CONST_Y);
						elePayMeth.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, sTotalRefAmt);
						elePayMeth.setAttribute(KohlsXMLLiterals.A_OPERATION, KohlsXMLLiterals.CONST_MANAGE);
						//PR-992 - Start
						// elePayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_7, strCurrentPSATranNo);
						//PR-992 - End
					}
				}
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.formInputToCapturePay Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formInputToCapturePay docCapPayInp after ="+XMLUtil.getXMLString(docCapPayInp));
			logger.debug("KohlsPSAChargeForPV.formInputToCapturePay -- End");
		}
		return docCapPayInp;
	}

	/**
	 * 
	 * This method checks if the PaymentType is 
	 * Not a Card 
	 * 
	 * @param sPaymentType
	 * @return
	 */
	private boolean checkIfNotCard(String sPaymentType) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.checkIfNotCard -- Start");
		}
		List <String> listArrayCard = Arrays.asList(KohlsPOCConstant.CASH, KohlsPOCConstant.ATTR_CORPORATE_REFUND, KohlsPOCConstant.KOHLS_CASH); 
		boolean bIsNotCard=false;
		bIsNotCard= listArrayCard.contains(sPaymentType);
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.checkIfNotCard bIsNotCard="+bIsNotCard);
			logger.debug("KohlsPSAChargeForPV.checkIfNotCard -- End");
		}
		return bIsNotCard;
	}

	/**
	 * 
	 * This method forms and calls
	 * recordExternalCharges api
	 * 
	 * @param yfsEnv
	 * @param docGetPayListOutput
	 * @param docFormInputForRecord
	 * @return
	 */
	private Document formAndCallInputToRecordExternalChargesPV(
			YFSEnvironment yfsEnv, Document docGetPayListOutput,
			Document docFormInputForRecord, Document docInputPV) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV -- Start");	
		}
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV docGetPayListOutput="
						+ XMLUtil.getXMLString(docGetPayListOutput)
						+ " docFormInputForRecord="
						+ XMLUtil.getXMLString(docFormInputForRecord));	
			}
			Document docFormInputForRecordClone=docFormInputForRecord;
			NodeList ndlPayList = XPathUtil.getNodeList(docGetPayListOutput, KohlsXMLLiterals.XPATH_PAY_METH_LIST);
			int iSize=ndlPayList.getLength();
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV iSize="+iSize);
			}

			for (int i = 0; i < iSize; i++) {
				Element eleCurrPayMeth = (Element)ndlPayList.item(i);
				//Since the document is getting overwritten reassign the document
				docFormInputForRecord=docFormInputForRecordClone;
				if(bIsDebugEnabled){
					logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV eleCurrPayMeth="+XMLUtil.getElementXMLString(eleCurrPayMeth));
				}
				String sPaymentType=eleCurrPayMeth.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
				if(!YFCCommon.isStringVoid(sPaymentType)){
					if(bIsDebugEnabled){
						logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV sPaymentType="+sPaymentType);
					}
					//Check if the PaymentMethod Element is a Credit Card or KMC Or Not
					boolean bIsCard=kohlsPSARefund.checkIfCard(sPaymentType);
					//Check if the PaymentMethod Element is a KMC
					boolean bIsKMC=((sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC))?true:false); 
					if(bIsDebugEnabled){
						logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV bIsCard="+bIsCard+" bIsKMC="+bIsKMC);
					}
					//If it is a card
					if(bIsCard){
						//Update the input for recordExternalCharges api
						Document docUpdateInputForRecord = null;
						Document docpinpadResponse = null;
						if(bIsKMC){
						docUpdateInputForRecord = updateInputForRecordPV(yfsEnv,docFormInputForRecord,eleCurrPayMeth,docpinpadResponse);
						}else{  
							updatePinpadSession(yfsEnv, eleCurrPayMeth,docInputPV);
							docpinpadResponse = callPinPad(yfsEnv, eleCurrPayMeth);
							docUpdateInputForRecord = updateInputForRecordPV(yfsEnv,docFormInputForRecord,eleCurrPayMeth,docpinpadResponse);
						}
						if(bIsDebugEnabled && (!YFCCommon.isVoid(docUpdateInputForRecord))){
							logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV docupdateInputForRecord="+docUpdateInputForRecord);
						}
						//Call recordExternalCharges api
						Document docOutputRecord=kohlsPSARefund.callRecordExternalPayments(yfsEnv, docUpdateInputForRecord);
						if(bIsDebugEnabled && (!YFCCommon.isVoid(docOutputRecord))){
							logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV docOutputRecord="+docOutputRecord);
						}
					}
				}
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV Exception"+e.getMessage());
		}
		if(bIsDebugEnabled && (!YFCCommon.isVoid(docFormInputForRecord))){
			logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV docFormInputForRecord End="+XMLUtil.getXMLString(docFormInputForRecord));
			logger.debug("KohlsPSAChargeForPV.formAndCallInputToRecordExternalChargesPV -- End");
		}
		return docFormInputForRecord;
	}



	/**
	 * 
	 * This method updates the input for
	 * recordExternalCharges api with tender
	 * specific attributes
	 * 
	 * @param yfsEnv
	 * @param docFormInputForRecord
	 * @param eleCurrPayMeth
	 * @param docpinpadResponse 
	 * @return
	 */
	private Document updateInputForRecordPV(YFSEnvironment yfsEnv, Document docFormInputForRecord,
			Element eleCurrPayMeth, Document docpinpadResponse) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV -- Start");
		}
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV docFormInputForRecord="+XMLUtil.getXMLString(docFormInputForRecord)+" eleCurrPayMeth="+XMLUtil.getElementXMLString(eleCurrPayMeth));
			}
			boolean bIsUsed=false;
			boolean isPinpadResponseAvailable = false;
			String sCTRoutOutput = "";
    		String sAuthCode = "000000";
			Element ctroutdElement = null;
    		Element eleAuthCode = null;
			Element responseElement = docpinpadResponse.getDocumentElement();
			if(!YFCCommon.isVoid(responseElement)){
				isPinpadResponseAvailable = true;
			}
			Element eleRecordExtChar=docFormInputForRecord.getDocumentElement();
			eleRecordExtChar.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
			Element eleRecordPayMeth = SCXmlUtil.getXpathElement(eleRecordExtChar,KohlsXMLLiterals.E_PAYMENT_METHOD);
			if(bIsDebugEnabled && (!YFCCommon.isVoid(eleRecordPayMeth))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV eleRecordPayMeth="+XMLUtil.getElementXMLString(eleRecordPayMeth));
			}
			//Get attributes from the output of Current PaymentMethod
			String sCreditCardNo=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sCreditCardNo))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sCreditCardNo="+sCreditCardNo);
			}
			String sCreditCardType=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sCreditCardType))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sCreditCardType="+sCreditCardType);
			}
			String sCreditCardExpDate=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sCreditCardExpDate))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sCreditCardExpDate="+sCreditCardExpDate);
			}
			String sPaymentKey=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sPaymentKey))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sPaymentKey="+sPaymentKey);
			}
			String sPaymentType=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sPaymentType))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sPaymentType="+sPaymentType);
			}
			String sTotalRefundedAmount=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_TOTAL_REFUNDED_AMT);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sTotalRefundedAmount))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sTotalRefundedAmount="+sTotalRefundedAmount);
			}
			String sDisplayCreditCardNo=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sDisplayCreditCardNo))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sDisplayCreditCardNo="+sDisplayCreditCardNo);
			}
			String sSvcNo=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_SVC_NO);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sSvcNo))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sSvcNo="+sSvcNo);
			}
			String sStoreID=eleCurrPayMeth.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sStoreID))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sStoreID="+sStoreID);
			}
			String sEntryMethod=eleCurrPayMeth.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sEntryMethod))){
				logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV sEntryMethod="+sEntryMethod);
			}
			//Check if its credit card and set the attributes
			if((!YFCCommon.isStringVoid(sCreditCardNo)) && (!YFCCommon.isStringVoid(sPaymentType)) && (sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD) || sPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD))){
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, sCreditCardExpDate);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, sCreditCardNo);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, sCreditCardType);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO, sDisplayCreditCardNo);
				bIsUsed=true;
				if(isPinpadResponseAvailable){
					ctroutdElement = SCXmlUtil.getChildElement(responseElement, "CTROUTD");
	    			eleAuthCode = SCXmlUtil.getChildElement(responseElement, "AUTH_CODE");
	    			if (!YFCCommon.isVoid(ctroutdElement)) {
	    				sCTRoutOutput = ctroutdElement.getTextContent();
	    			}
	    			if (!YFCCommon.isVoid(eleAuthCode)) {
	    				sAuthCode = eleAuthCode.getTextContent();
	    			}
					eleRecordPayMeth.setAttribute("ExtraDetails10", sCTRoutOutput);
					eleRecordPayMeth.setAttribute("AuthorizationID", sAuthCode);
					eleRecordPayMeth.setAttribute("ExtraDetails7", "CREDIT");
					eleRecordPayMeth.setAttribute("IsExternalPayment", "Y");
					Element eleExtn = XMLUtil.createChild(eleRecordPayMeth, KohlsPOCConstant.A_EXTN);
	    			eleExtn.setAttribute("ExtnPSIPayment", "Y");
				}
				if(bIsDebugEnabled && (!YFCCommon.isVoid(eleRecordPayMeth))){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV CC eleRecordPayMeth="+XMLUtil.getElementXMLString(eleRecordPayMeth)+" bIsUsed="+bIsUsed);
				}
			}
			//Check if its KMC and set the attributes
			if((!YFCCommon.isStringVoid(sSvcNo)) && (!YFCCommon.isStringVoid(sStoreID)) && (!YFCCommon.isStringVoid(sPaymentType)) && (sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC))){
				//Get the values required for PSA Gift Card Authorization reversal request
				Map<String,String> mKMCValues=getValuesForKMCPV(docChanUEClone);
				//Print the current values in the map
				kohlsPSARefund.printMapValues(mKMCValues);
				//Add remaining attributes to the map
				mKMCValues.put(KohlsXMLLiterals.A_TOTAL_REFUNDED_AMT, sTotalRefundedAmount);
				mKMCValues.put(KohlsXMLLiterals.A_Entry_Method, sEntryMethod);
				mKMCValues.put(KohlsPOCConstant.ATTR_STORE_ID, sStoreID);
				mKMCValues.put(KohlsXMLLiterals.A_SVC_NO, sSvcNo);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV KMC");
				}
				//Print the current values in the map
				kohlsPSARefund.printMapValues(mKMCValues);
				//Create a request for PSA Gift Card Authorization reversal 
				Document docPSAGCRevInp=createInputForPSAGCRev(mKMCValues);
				if(bIsDebugEnabled && (!YFCCommon.isVoid(docPSAGCRevInp))){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV docPSAGCRevInp="+XMLUtil.getXMLString(docPSAGCRevInp));
				}
				//Call PSA Gift Card Authorization reversal Service
				Document docPSAGCRevOut=callPSAGCService(yfsEnv,docPSAGCRevInp);
				if(bIsDebugEnabled && (!YFCCommon.isVoid(docPSAGCRevOut))){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV docPSAGCRevOut="+XMLUtil.getXMLString(docPSAGCRevOut));
				}
				Element eleRecordPayMethExtn=XMLUtil.createChild(eleRecordPayMeth, KohlsXMLLiterals.E_EXTN);
				eleRecordPayMethExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE, "");
				eleRecordPayMethExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE, "");
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_SVC_NO, sSvcNo);
				bIsUsed=true;
				if(bIsDebugEnabled && (!YFCCommon.isVoid(eleRecordPayMeth))){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV KMC eleRecordPayMeth="+XMLUtil.getElementXMLString(eleRecordPayMeth)+" bIsUsed="+bIsUsed);
				}
			}
			//If this PaymentMethod was used, set the generic attributes
			if(bIsUsed){
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, sPaymentType);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_PAYMENT_KEY, sPaymentKey);
				eleRecordPayMeth.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, sTotalRefundedAmount);
				if(bIsDebugEnabled && (!YFCCommon.isVoid(eleRecordPayMeth))){
					logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV Generic eleRecordPayMeth="+XMLUtil.getElementXMLString(eleRecordPayMeth));
				}
				Element elePaymentDetailsList = SCXmlUtil.getXpathElement(eleRecordPayMeth,KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
				Element elePaymentDetails = SCXmlUtil.getXpathElement(elePaymentDetailsList,KohlsXMLLiterals.E_PAYMENT_DETAILS);
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, sTotalRefundedAmount);
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, sTotalRefundedAmount);
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.updateInputForRecordPV Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV docFormInputForRecord="+XMLUtil.getXMLString(docFormInputForRecord));
			logger.debug("KohlsPSAChargeForPV.updateInputForRecordPV -- End");
		}
		return docFormInputForRecord;
	}



	/**
	 * 
	 * This Method calls Gift Card Activation
	 * Web Service 
	 * 
	 * @param yfsEnv
	 * @param docPSAGCRevInp
	 * @return
	 */
	private Document callPSAGCService(YFSEnvironment yfsEnv, Document docPSAGCRevInp) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.callPSAGCService -- Start");
		}
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.callPSAGCService docPSAGCRevInp="+XMLUtil.getXMLString(docPSAGCRevInp));
			}
			docPSAGCRevInp = KohlsCommonUtil.invokeService(yfsEnv,KohlsXMLLiterals.SER_KOHLS_POC_SVC, docPSAGCRevInp);
			if(bIsDebugEnabled && (!YFCCommon.isVoid(docPSAGCRevInp))){
				logger.debug("KohlsPSAChargeForPV.callPSAGCService docPSAGCRevInp="+XMLUtil.getXMLString(docPSAGCRevInp));
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.callPSAGCService Exception"+e.getMessage());
		}
		if(bIsDebugEnabled && (!YFCCommon.isVoid(docPSAGCRevInp))){
			logger.debug("KohlsPSAChargeForPV.callPSAGCService docPSAGCRevInp="+XMLUtil.getXMLString(docPSAGCRevInp));
			logger.debug("KohlsPSAChargeForPV.callPSAGCService -- End");
		}
		return docPSAGCRevInp;
	}

	/**
	 * 
	 * This Method creates the input to be 
	 * called for PSA Gift Card Activation Gateway
	 * 
	 * @param mKMCValues
	 * @return
	 */
	private Document createInputForPSAGCRev(Map<String, String> mKMCValues) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.createInputForPSAGCRev -- Start");
		}
		Document docPSAGCRevInp=null;
		try{
			kohlsPSARefund.printMapValues(mKMCValues);
			//Create a new Document for Request
			docPSAGCRevInp=XMLUtil.createDocument(KohlsConstant.PAYMENT_REQUEST);
			Element elePayReqRev=docPSAGCRevInp.getDocumentElement();
			Element eleTran=XMLUtil.createChild(elePayReqRev, KohlsXMLLiterals.E_TRANSACTION);
			Double dAmount = new Double(mKMCValues.get(KohlsXMLLiterals.A_TOTAL_REFUNDED_AMT));
			eleTran.setAttribute(KohlsXMLLiterals.A_TENDER_AMOUNT, Double.toString(Math.abs(dAmount.doubleValue())));
			eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE,KohlsConstant.PSA_DRIVERS_LICENSE_NUM);
			eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,KohlsXMLLiterals.ATTR_ACTIVATION_REVERSAL);
			eleTran.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,KohlsXMLLiterals.ATTR_MERC_RETURN_CREDIT);
			eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,mKMCValues.get(KohlsXMLLiterals.A_Entry_Method));
			eleTran.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER, mKMCValues.get(KohlsPOCConstant.A_STORE_ID));
			eleTran.setAttribute(KohlsXMLLiterals.A_REGISTER_NUMBER,mKMCValues.get(KohlsPOCConstant.ATTR_TERMINAL_ID));
			eleTran.setAttribute(KohlsXMLLiterals.A_SVCNO,mKMCValues.get(KohlsXMLLiterals.A_SVC_NO));
			eleTran.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,mKMCValues.get(KohlsPOCConstant.ATTR_OPERATOR_ID));
			eleTran.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,mKMCValues.get(KohlsPOCConstant.A_POS_SEQUENCE_NO));
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.createInputForPSAGCRev Exception"+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.createInputForPSAGCRev docPSAGCRevInp="+XMLUtil.getXMLString(docPSAGCRevInp));
			logger.debug("KohlsPSAChargeForPV.createInputForPSAGCRev -- End");
		}
		return docPSAGCRevInp;
	}

	/**
	 * 
	 * This method returns required values  
	 * for the PSA Gift Card Activation reversal 
	 * Request
	 * 
	 * @param docChanUEClone2
	 * @return
	 */
	private Map<String, String> getValuesForKMCPV(Document docChanUEClone2) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.getValuesForKMCPV -- Start");
		}
		Map<String, String> mKMCValues = new HashMap<String, String>();
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSAChargeForPV.getValuesForKMCPV docChanUEClone2"+XMLUtil.getXMLString(docChanUEClone2));
			}	
			Element eleOrder=docChanUEClone2.getDocumentElement();
			String sPosSeqNo=eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sPosSeqNo))){
				logger.debug("KohlsPSAChargeForPV.getValuesForKMCPV sPosSeqNo="+sPosSeqNo);
			}
			String sOperatorID=eleOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sOperatorID))){
				logger.debug("KohlsPSAChargeForPV.getValuesForKMCPV sOperatorID="+sOperatorID);
			}
			String sTerminalID=eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
			if(bIsDebugEnabled && (!YFCCommon.isStringVoid(sTerminalID))){
				logger.debug("KohlsPSAChargeForPV.getValuesForKMCPV sTerminalID="+sTerminalID);
			}
			if((!YFCCommon.isStringVoid(sOperatorID)) && (!YFCCommon.isStringVoid(sPosSeqNo)) && (!YFCCommon.isStringVoid(sTerminalID))){
				mKMCValues.put(KohlsPOCConstant.A_POS_SEQUENCE_NO, sPosSeqNo);	
				mKMCValues.put(KohlsPOCConstant.A_OPERATOR_ID, sOperatorID);	
				mKMCValues.put(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);	
			}
		}catch(Exception e){
			logger.error("KohlsPSAChargeForPV.getValuesForKMCPV Exception="+e.getMessage());
		}
		kohlsPSARefund.printMapValues(mKMCValues);
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.getValuesForKMCPV -- End");
		}
		return mKMCValues;
	}

	/**
	 * 
	 * This Method form a Skeleton input for
	 * recordExternalCharges api  
	 * 
	 * @return
	 * @throws ParserConfigurationException
	 */
	private Document formInputSklToRecordExternalChargesPV()
			throws ParserConfigurationException {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formInputSklToRecordExternalChargesPV - Begin");
		}
		Document docSklToRecordExternalCharges = XMLUtil
				.createDocument(KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES);
		Element eleRecordExternalCharges = docSklToRecordExternalCharges
				.getDocumentElement();
		Element elePaymentMethod = XMLUtil.createChild(
				eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
		elePaymentMethod.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION,
				KohlsXMLLiterals.CONST_Y);
		elePaymentMethod.setAttribute(KohlsXMLLiterals.A_OPERATION,
				KohlsXMLLiterals.CONST_MANAGE);
		elePaymentMethod.setAttribute(
				KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS,
				KohlsXMLLiterals.CONST_Y);
		//PR-992 - Start
		// elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_7, strCurrentPSATranNo);
		//PR-992 - End
		Element elePaymentDetailsList = XMLUtil.createChild(elePaymentMethod,
				KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
		Element elePaymentDetails = XMLUtil.createChild(elePaymentDetailsList,
				KohlsXMLLiterals.E_PAYMENT_DETAILS);
		elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE,
				KohlsXMLLiterals.CONST_CHARGE);
		elePaymentDetails.setAttribute(KohlsXMLLiterals.A_IN_PERSON,
				KohlsXMLLiterals.CONST_Y);
		elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_PROCESSED,
				KohlsXMLLiterals.CONST_Y);
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.formInputSklToRecordExternalChargesPV Output:"
					+ XMLUtil.getXMLString(docSklToRecordExternalCharges));
			logger.debug("KohlsPSAChargeForPV.formInputSklToRecordExternalChargesPV - End");
		}
		return docSklToRecordExternalCharges;

	}

	/**
	 * This method prepares an input to getPaymentList API
	 * @param env
	 * @param strOrderHeaderkey
	 * @return
	 * @throws ParserConfigurationException
	 */
	private Document inputToGetPaymentListPV(String strOrderHeaderkey) throws ParserConfigurationException  {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.inputToGetPaymentListPV - Begin");
		}
		Document docGetPaymentListInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_PAYMENT);
		Element eleGetPaymentListInput = docGetPaymentListInput
				.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)) {
			eleGetPaymentListInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
			eleGetPaymentListInput.setAttribute(
					KohlsXMLLiterals.A_PAYMENT_REF_6, KohlsXMLLiterals.CONST_PSA);
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSAChargeForPV.inputToGetPaymentListPV Output:"
					+ XMLUtil.getXMLString(docGetPaymentListInput));
			logger.debug("KohlsPSAChargeForPV.inputToGetPaymentListPV - End");
		}
		return docGetPaymentListInput;
	}
	
	//CPE-5903 - Start  
    private Document callPinPad(YFSEnvironment env, Element elePayment) throws Exception {
    	logger.beginTimer("KohlsPSARefund.callPinPad");  
    	if (bIsDebugEnabled) {
    		logger.debug("Inside callPinPad method. Payment element is: "
    				+ XMLUtil.getElementXMLString(elePayment));
    	}
    	Document docPinpadResponse = null;
    	elePayment.setAttribute("OrderNo", strOHKey);
    	timeTaken = 0.01;

    	KohlsPoCPinPadPostVoidOperations object = new KohlsPoCPinPadPostVoidOperations();
    	long start = 0;
    	try {
    		start = System.currentTimeMillis();
    		logger.debug("KohlsPSARefund.callPinPad - start time is " + start);
    		docPinpadResponse = object.doVoidRequest(env, XMLUtil.getDocumentForElement(elePayment));
    		if (logger.isDebugEnabled()) {
    			logger.debug("Response from Pinpad is: " + XMLUtil.getXMLString(docPinpadResponse));
    		}

    	} catch (Exception e) {
    		logger.error(
    				"KohlsPSARefund.formAndCallInputToRecordExternalCharges Exception while calling pinpad: "
    						+ e.getMessage());
    	} finally {
    		long end = System.currentTimeMillis();
    		logger.debug("KohlsPSARefund.callPinPad - end time is " + end);
    		timeTaken = (end - start);
    	}
    	logger.endTimer("KohlsPSARefund.callPinPad");

    	return docPinpadResponse;
    }
    
    	private String changeCreditCardType(String strCreditCardType) {
    		if(bIsDebugEnabled){
    		logger.debug("KohlsPSARefund.setCreditCardType --Start");
    		logger.debug("KohlsPSARefund.setCreditCardType before strCreditCardType"
    				+ strCreditCardType);
    		}
    		if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_VISA)) {
    			strCreditCardType = KohlsConstant.VISA_05;
    		} else if (strCreditCardType
    				.equalsIgnoreCase(KohlsConstant.PSA_MASTERCARD)) {
    			strCreditCardType = KohlsConstant.MASTERCARD_06;
    		} else if (strCreditCardType
    				.equalsIgnoreCase(KohlsConstant.PSA_DISCOVER)) {
    			strCreditCardType = KohlsConstant.DISCOVER_07;
    		} else if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_AMEX)) {
    			strCreditCardType = KohlsConstant.AMEX_08;
    		}
    		if(bIsDebugEnabled){
    		logger.debug("KohlsPSARefund.setCreditCardType after strCreditCardType"
    				+ strCreditCardType);
    		logger.debug("KohlsPSARefund.setCreditCardType --End");
    		}
    		return strCreditCardType;
    	}
    	
    	private void updatePinpadSession(YFSEnvironment yfsEnv, Element eleCurrPayMeth, Document inDoc){
    		logger.beginTimer("KohlsPSAChargeForPV.updatePinpadSession --Start");
    		
    		try {
    			Element eleOrderOutRoot = inDoc.getDocumentElement();
		        eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, eleCurrPayMeth.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
		        eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, eleCurrPayMeth.getAttribute(KohlsPOCConstant.A_STORE_ID));
		        eleOrderOutRoot.setAttribute(KohlsPOCConstant.OPERATION,
		                "updateSession");  
		        eleOrderOutRoot.setAttribute(KohlsPOCConstant.A_ORDER_DETAILS_INCLUDED, KohlsPOCConstant.TRUE);
				KOHLSBaseApi.invokeAPI(yfsEnv, KohlsPOCConstant.API_MANAGE_PSI_ORDER_FOR_POS, inDoc);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
    		logger.beginTimer("KohlsPSAChargeForPV.updatePinpadSession --Start");
    		
    	}

}
