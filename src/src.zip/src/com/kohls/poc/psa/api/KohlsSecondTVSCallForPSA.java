/**
 * 
 */
package com.kohls.poc.psa.api;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author SA345825
 *
 */
@SuppressWarnings("deprecation")
public class KohlsSecondTVSCallForPSA {

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsSecondTVSCallForPSA.class
				.getName());
	}

	KohlsPSATVSHelper objTVSHelper = new KohlsPSATVSHelper();

	Map<String, String> mapKCEligibleItems = new HashMap<String, String>();

	public Document prepareRequestForSecondTVSCall(YFSEnvironment env,
			Document firstTVSResponseDoc, Element tempOrderEle)
			throws Exception {

		Document secondTVSResponseDoc = null;

		Element eleOrderLevelPromotions = null;
		if (!YFCCommon.isVoid(tempOrderEle)) {
			eleOrderLevelPromotions = XMLUtil.getChildElement(tempOrderEle,
					KohlsXMLLiterals.E_PROMOTIONS);
		}

		// Prepare TVS request document for Second TVS call.

		Document secondTVSRequestDoc = XMLUtil
				.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
		Element priceRequestEle = secondTVSRequestDoc.getDocumentElement();
		priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
		priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");
		Element transactionEle = XMLUtil.createChild(priceRequestEle,
				KohlsPOCConstant.ORIGINAL_TRANSACTION);

		objTVSHelper.createConstantEleForTVSReq(env, tempOrderEle,
				transactionEle);

		// Adding lidOfferExempt to Second TVS request
		Element promotionsEle = XMLUtil.getChildElement(tempOrderEle,
				KohlsPOCConstant.E_PROMOTIONS);
		Element lidOfferExempt = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.LID_OFFER_EXEMPT);
		objTVSHelper.constructLidOfferExemptPSA(promotionsEle, lidOfferExempt,
				tempOrderEle);

		// Adding itemList to the Second TVS Request
		Element itemListEle = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ATTR_ITEM_LIST);

		// Save the first TVS call response in a map.
		Element eleItemList = KohlsXPathUtil.getElementByXpath(
				firstTVSResponseDoc,
				KohlsPOCConstant.ADJUSTMENT_RESPONSE_ITEMLIST);
		if (!YFCCommon.isVoid(eleItemList)) {
			NodeList nlItem = eleItemList
					.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM);
			for (int i = 0; i < nlItem.getLength(); i++) {
				Element eleItem = (Element) nlItem.item(i);
				String strid = eleItem.getAttribute(KohlsPOCConstant.ATTR_ID);
				String strnetPrice = eleItem
						.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
				mapKCEligibleItems.put(strid, strnetPrice);
			}
		}
		Element eleOrderLines = XMLUtil.getChildElement(tempOrderEle,
				KohlsXMLLiterals.E_ORDER_LINES);
		if (!YFCCommon.isVoid(eleOrderLines)) {
			NodeList nlOrderLine = eleOrderLines
					.getElementsByTagName(KohlsXMLLiterals.E_ORDER_lINE);
			for (int j = 0; j < nlOrderLine.getLength(); j++) {
				Element eleOrderLine = (Element) nlOrderLine.item(j);
				Element eleOrderLineExtn = XMLUtil.getChildElement(
						eleOrderLine, KohlsXMLLiterals.E_EXTN);
				Element eleOrderLineItem = XMLUtil.getChildElement(
						eleOrderLine, KohlsXMLLiterals.E_ITEM);

				Element eleOutputItem = XMLUtil.createChild(itemListEle,
						KohlsPOCConstant.ELEM_SMALL_ITEM);

				// construction of SKU Element
				String strItemId = eleOrderLineItem
						.getAttribute(KohlsPOCConstant.A_ITEM_ID);
				Element eleSku = XMLUtil.createChild(eleOutputItem,
						KohlsPOCConstant.ATTR_SKU);
				XMLUtil.setNodeValue(eleSku, strItemId);

				// contruction of id Element
				String strPrimeLineNo = eleOrderLine
						.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
				if (!YFCCommon.isVoid(strPrimeLineNo)) {
					Element eleId = XMLUtil.createChild(eleOutputItem,
							KohlsPOCConstant.ATTR_ID);
					XMLUtil.setNodeValue(eleId, strPrimeLineNo);
				}

				objTVSHelper.createMerchandiseHierarchy(eleOutputItem,
						eleOrderLineExtn);

				objTVSHelper.createTaxAttributes(eleOrderLine,
						eleOrderLineExtn, eleOutputItem);

				// construction of Regular Price Element
				Boolean bIsMapNull = false;
				Element eleRegPrice = XMLUtil.createChild(eleOutputItem,
						KohlsPOCConstant.ATTR_REGULAR_PRICE);
				if (!YFCCommon.isVoid(strPrimeLineNo)) {
					if (mapKCEligibleItems != null) {
						for (Entry<String, String> entry : mapKCEligibleItems
								.entrySet()) {
							if (strPrimeLineNo.equals(entry.getKey())) {
								XMLUtil.setNodeValue(eleRegPrice,
										entry.getValue());
								bIsMapNull = true;
							}
						}
					}
					if (!bIsMapNull) {
						Double dFinalPrice = objTVSHelper
								.calculateItemNetPrice(env, eleOrderLine,
										eleOrderLevelPromotions);
						XMLUtil.setNodeValue(eleRegPrice,
								Double.toString(dFinalPrice));
					}
				}

				// contruction of regularPriceStatus Element
				String SKUStatusCode = XMLUtil.getAttribute(eleOrderLineExtn,
						KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
				Element regularPriceStatusElement = XMLUtil.createChild(
						eleOutputItem, KohlsPOCConstant.REGULAR_PRICE_STATUS);
				XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);

				// contruction of empDiscCode Element
				Boolean bEmpDiscCode = false;
				Element eleEmpDiscCode = XMLUtil.createChild(eleOutputItem,
						KohlsPOCConstant.ATTR_EMP_DISC_CODE);
				Element eleReference = (Element) KohlsXPathUtil.getNode(
						eleOrderLine,
						"./References/Reference[@Name='ExtnEmpDiscCode']");
				if (!YFCCommon.isVoid(eleReference)) {
					if (!YFCCommon.isVoid(eleReference
							.getAttribute(KohlsPOCConstant.A_VALUE))) {
						XMLUtil.setNodeValue(eleEmpDiscCode, eleReference
								.getAttribute(KohlsPOCConstant.A_VALUE));
						bEmpDiscCode = true;
					}
				}
				if (!bEmpDiscCode) {
					XMLUtil.setNodeValue(eleEmpDiscCode,
							KohlsPOCConstant.CONST_S);
				}

				// contruction of scanTime Element
				Element eleScanTime = XMLUtil.createChild(eleOutputItem,
						KohlsPOCConstant.ATTR_SCAN_TIME);
				String createTS = eleOrderLineItem
						.getAttribute(KohlsPOCConstant.A_CREATE_TS);
				if (!YFCCommon.isStringVoid(createTS)) {
					XMLUtil.setNodeValue(eleScanTime, createTS);
				} else {
					YFCDate date = new YFCDate();
					String sCreateTimeStamp = date.getString(null, true);
					XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
				}
			}
		}

		// Adding offers in TVS request
		Element offersEle = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ELEM_OFFERS);
				
		//Adding exclusions in TVS request
		KohlsPoCPnPUtil.constructExclusionsForRefundDeduction(env,
				transactionEle);
				
		// Adding adjustments in TVS request
		Element adjustments = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ADJUSTMENS);

		// Adding taxExempt in TVS request
		Element eleTaxExempt = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ATTR_TAX_EXEMPT);
		String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle,
				KohlsPOCConstant.TAX_EXEMPT_FLAG);
		String strTaxExemptCert = XMLUtil.getAttribute(tempOrderEle,
				KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

		if (!YFCCommon.isVoid(strTaxExemptCert)
				|| strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES)) {
			XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
		} else {
			XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);
		}

		logger.debug("Input to Second TVS call for PSA ::"
				+ XMLUtil.getXMLString(secondTVSRequestDoc));
		secondTVSResponseDoc = objTVSHelper.callPSATVSWebService(env,
				secondTVSResponseDoc, secondTVSRequestDoc);
		return objTVSHelper.validateTVSResponse(secondTVSResponseDoc);
	}
}
