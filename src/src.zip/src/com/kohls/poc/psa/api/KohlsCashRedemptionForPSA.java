package com.kohls.poc.psa.api;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.pricing.ue.KohlsPoCTVSOrderRepriceUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCashRedemptionForPSA {
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsCashRedemptionForPSA.class.getName());
	}
	// dateformat in datetime
	DateFormat dateFormatDateTime = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);

	// dateformat in date
	DateFormat dateFormatDate = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);
	/**
	 * Method Name : KohlsCashRedemptionForPSA Description : This method
	 * constructs Kohls Cash Redemption request xml from the indoc supplied and
	 * returns an xml document with response from the Kohls Cash Redemption
	 * service for PSA
	 * @param env
	 * @param inDoc
	 * @return Document, an xml document with coupon details
	 * @throws ParserConfigurationException
	 */
	public Document KohlsCashRedemptionForPSA(YFSEnvironment env,Document inDoc) {
		logger.beginTimer("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA");
		Element eleInDocOrder = inDoc.getDocumentElement();
		Element extnEle = null;
		Element eleOPOrder = null;
		Document orderListInDoc = null;
		Document tempOrderOutDoc = null;
		Document orderListOutDoc = inDoc;

		// Retrieve OrderHeaderKey, which would be used while forming input
		// request to GetOrderList API
		String orderHeaderKey = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: Input to the KohlsCashRedemptionForPSA :: "+XMLUtil.getXMLString(inDoc));

		try {
			orderListInDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
			if(!YFCCommon.isVoid(orderHeaderKey)){
				orderListInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
				
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: Input to the getOrderList API :: " + XMLUtil.getXMLString(orderListInDoc));

				orderListOutDoc = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.KOHLS_CASH_REDEMPTION_GET_ORDER_LIST_OUTPUT,
						KohlsPOCConstant.API_GET_ORDER_LIST, orderListInDoc);
				
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: getOrderList Output:: " + XMLUtil.getXMLString(orderListOutDoc));
			}
			else{
				logger.error("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: OrderHeaderKey is null in the input xml ::");
				return inDoc;
			}

			// Retrieving Root Element from the response doc of GetOrderListAPI
			Element olOrderElement = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);

			// Retrieve Promotions and Promotions from the OrderElement
			List <Element> promotionList = XMLUtil.getElementsByTagName(olOrderElement, KohlsPOCConstant.E_PROMOTION);
			if(promotionList.size() > KohlsPOCConstant.ZERO_INT) {
				for (Element promotionElement : promotionList) {
					String promotionApplied = XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_PROMOTION_APPLIED);
					String promotionType = XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_PROMOTION_TYPE);
					//checking if promotionType is KOHLS_CASH and if the promotion is applied
					if ( KohlsPOCConstant.YES.equalsIgnoreCase(promotionApplied) &&  KohlsPOCConstant.KOHLSCASH.equalsIgnoreCase(promotionType) ) {
						extnEle = XMLUtil.getChildElement(promotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
						String eleExtnIsPsaPromotion=XMLUtil.getAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION);

						//checking if PSA promotion is applied
						if(KohlsPOCConstant.YES.equalsIgnoreCase(eleExtnIsPsaPromotion)){
							String extnOfflineMode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);	
							if(YFCCommon.isStringVoid(extnOfflineMode)) {

								Document serviceInDoc = XMLUtil.createDocument(KohlsPOCConstant.E_COUPON_REDEMPTION_REQ_MSG);

								Element serviceInDocElement = serviceInDoc.getDocumentElement();

								// Creating Header Element in the Request Message
								Element serviceHeaderElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_HEADER);

								// Creating Data Element in the Request Message
								Element dataElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_DATA);

								// Preparing Header Information in the Request Message
								prepareRequestHeaderDetails(env, olOrderElement, serviceHeaderElement);
								prepareRequestDataDetails(olOrderElement, promotionElement, dataElement);
								
								KohlsCashManager kcm = new KohlsCashManager(env);
								Document serviceOutDocFormatted = null;
								
								String sellerOrganizationCode = olOrderElement.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
								
								boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(sellerOrganizationCode);
								
								if(logger.isDebugEnabled())
									logger.debug("######Rule value for OMS KC in KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: " + omsKCEnabled);
								
							    try {
							    	if(omsKCEnabled) {
							    		if(logger.isDebugEnabled())
											logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA OMS KC input: " + XMLUtil.getXMLString(serviceInDoc));
							    		
										kcm.loadEvents(sellerOrganizationCode);
										//Do redemption via KCM
										serviceOutDocFormatted = kcm.kohlsCashRedemption(serviceInDoc);
										
										if(logger.isDebugEnabled())
											logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA OMS KC ouput: " + XMLUtil.getXMLString(serviceOutDocFormatted));
									}
									else {
										if(logger.isDebugEnabled())
											logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA KCS input: " + XMLUtil.getXMLString(serviceInDoc));
										
										//Do redemption via KCS
										serviceOutDocFormatted = KOHLSBaseApi.invokeService(env,
												KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_REDEMPTION_WEB_SERVICE, serviceInDoc);
										
										if(logger.isDebugEnabled())
											logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA KCS output" + XMLUtil.getXMLString(serviceOutDocFormatted));
									}
								} catch (Exception e1) {

									//  ExtnRedemResponseCode to 9 ONLY for the promotions with promotionType as KOHLS_CASH and if webservice call failed
										Element extnElement = XMLUtil.getChildElement(promotionElement, KohlsPOCConstant.E_EXTN);
										XMLUtil.setAttribute(extnElement, KohlsPOCConstant.A_REDEMPTION_RESPONSE_CODE, "9");
								
									logger.error( "KCM or KCS webservice call failure in KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: ", e1 );
									if(logger.isDebugEnabled())
										logger.debug("###### KCM or KCS webservice call failure in KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: " );
								} 
								
								Element serviceOutDocElement = serviceOutDocFormatted.getDocumentElement();

								// Retrieving Data Element from the Service Response
								List eleDataList = XMLUtil.getElementsByTagName(serviceOutDocElement, KohlsPOCConstant.E_DATA);
								if (!(XMLUtil.isVoid(eleDataList)) && (eleDataList.size() > KohlsPOCConstant.ZERO_INT)) {
									Element eleData = (Element) eleDataList.get(0);
									// Retrieving authResponseCode attribute
									String authResponseCode = eleData.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
									String authApprovalNum = eleData.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);
									String couponBalance = eleData.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
									if (!XMLUtil.isVoid(authResponseCode)) {
										if("0".equalsIgnoreCase(authResponseCode)){
											XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_REDEMPTION_AUTH_APPROVAL_NUM, authApprovalNum);
										}
										XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_REDEMPTION_RESPONSE_CODE, authResponseCode);
										XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE, couponBalance);
									}
								}
							}
						}
					} 
				}
			}

			eleOPOrder = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(),  KohlsPOCConstant.ELEM_ORDER);
			tempOrderOutDoc = XMLUtil.getDocumentForElement(eleOPOrder); 		
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: Final Output Document ::" + XMLUtil.getXMLString(tempOrderOutDoc));
		} catch (Exception e) {
			logger.error( "Failure in KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA: ", e );
			eleOPOrder = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);
			// Retrieve Promotions and Promotions from the OrderElement	
			if(logger.isDebugEnabled())
				logger.debug("OutDoc in exception block:" + XMLUtil.getXMLString(orderListOutDoc));
		    try {
				 tempOrderOutDoc = XMLUtil.getDocumentForElement(eleOPOrder);
			} catch (Exception e1) {
				e1.printStackTrace();
			}		
		}
		logger.debug("Exiting KohlsCashRedemptionForPSA ......");		
		logger.endTimer("KohlsCashRedemptionForPSA.KohlsCashRedemptionForPSA");

		return tempOrderOutDoc;

	}
	/*** Method Name : prepareRequestDataDetails Description : This method
	 * constructs Data Element which is a part of the KohlsCashRedemptionService
	 * request
	 * 
	 * @param eleInDocOrder
	 * @param elePromotion
	 * @param dataElement
	 */
	private void prepareRequestDataDetails(Element eleInDocOrder, Element elePromotion, Element dataElement) {
		logger.beginTimer("KohlsCashRedemptionForPSA.prepareRequestDataDetails");

		logger.debug("Entering prepareRequestDataDetails......");
		if (!XMLUtil.isVoid(elePromotion)) {

			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_COUPON_NUMBER, XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_ID));
			String overrideAdjValue = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_DISCOUNT_AMOUNT, String.valueOf(Math.abs(Double.valueOf(overrideAdjValue))));
			Element eleExtnPromotion = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
			String extnCouponScanned = XMLUtil.getAttribute(eleExtnPromotion, KohlsPOCConstant.A_EXTN_COUPON_SCANNED);
			if (!YFCCommon.isStringVoid(extnCouponScanned)) {
				if (KohlsPOCConstant.NO.equalsIgnoreCase(extnCouponScanned)) {
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON, KohlsPOCConstant.TRUE);
				} else {
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON, KohlsPOCConstant.FALSE);
				}
			}
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_PIN, XMLUtil.getAttribute(eleExtnPromotion, KohlsPOCConstant.A_EXTN_COUPON_PIN));

			String voidOrigTranNumber = "";
			String eleAction = XMLUtil.getAttribute(eleInDocOrder, KohlsPOCConstant.ATTR_ACTION);
			if (!XMLUtil.isVoid(eleAction) && KohlsPOCConstant.ACTION_CANCEL.equalsIgnoreCase(eleAction)) {
				voidOrigTranNumber = XMLUtil.getAttribute(eleInDocOrder, KohlsPOCConstant.A_POS_SEQUENCE_NO);
			}

			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_VOID_ORIG_TRAN_NUMBER, "");
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, XMLUtil.getAttribute(eleExtnPromotion,
					KohlsPOCConstant.A_EXTN_ORIGINAL_RECEIPT_ID));

		}
		logger.debug("Exiting prepareRequestDataDetails......");
		logger.endTimer("KohlsCashRedemptionForPSA.prepareRequestDataDetails");

	}

	/**
	 *  Method Name : prepareRequestHeaderDetails Description : This method
	 * constructs Header Element which is a part of the
	 * KohlsCashRedemptionService request
	 * @param env
	 * @param eleInDocOrder
	 * @param headerElement
	 * @throws Exception
	 */
	private void prepareRequestHeaderDetails(YFSEnvironment env, Element eleInDocOrder, Element headerElement) throws Exception {
		logger.beginTimer("KohlsCashRedemptionForPSA.prepareRequestHeaderDetails");

		logger.debug("Entering prepareRequestHeaderDetails......");
		String sellerOrganizationCode = eleInDocOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		sellerOrganizationCode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(sellerOrganizationCode);
		String terminalID = eleInDocOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);

		Document businessDateDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(env, eleInDocOrder);

		Element getTillStatusListForPOSOutEle = businessDateDoc.getDocumentElement();
		List<Element> tillStatusList = XMLUtil.getElementsByTagName(getTillStatusListForPOSOutEle, KohlsPOCConstant.E_TILL_STATUS);
		String businessDay = KohlsPOCConstant.EMPTY;
		if (tillStatusList.size() > KohlsPOCConstant.ZERO_INT) {
			Element tillStatusElement = tillStatusList.get(KohlsPOCConstant.ZERO_INT);
			businessDay = XMLUtil.getAttribute(tillStatusElement, KohlsPOCConstant.A_BUSINESS_DAY);
		}
		String operatorID = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID);

		String extnRequestDateTime = "";

		Element eleInDocOrderExtn = XMLUtil.getChildElement(eleInDocOrder, KohlsPOCConstant.E_EXTN);
		if (!XMLUtil.isVoid(eleInDocOrderExtn)) {
			extnRequestDateTime = eleInDocOrderExtn.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
			// Defect 3076 Start: Updated isVoid condition for extnRequestDateTime : Suresh			
			if (!XMLUtil.isVoid(extnRequestDateTime)) {
				// Defect 3076 End: Updated isVoid condition for extnRequestDateTime : Suresh

				Date dt = dateFormatDateTime.parse(extnRequestDateTime);
				extnRequestDateTime = (String) dateFormatDateTime.format(dt);
			}

		}
		logger.debug(extnRequestDateTime);

		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_STORE_APE, sellerOrganizationCode);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TERMINAL, terminalID);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_BUSINESS_DATE, businessDay);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_ASSOCIATE_ID, operatorID);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAINING_MODE, KohlsPOCConstant.CONST_FALSE);

		// get current date time with Calendar()
		Calendar cal = Calendar.getInstance();

		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAN_START_DATE_TIME, !XMLUtil.isVoid(extnRequestDateTime) ? extnRequestDateTime
				: dateFormatDateTime.format(cal.getTime()));

		// Retrieve and set PosSequenceNo
		String posSequenceNo = eleInDocOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
		String strOrignSeqNo = eleInDocOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
		//Fix for PR-688 - Start
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRANSACTION_NUMBER, posSequenceNo);
		logger.debug("Exiting prepareRequestHeaderDetails......With TransactionNumber: " +posSequenceNo);
		//Fix for PR-688 - End
		logger.endTimer("KohlsCashRedemptionForPSA.prepareRequestHeaderDetails");

	}


}
