package com.kohls.poc.psa.api;


import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * This class calls the KohlsCash deactivation web service to get KohlsCash amount 
 * to be unearned and KohlsCash eligible items.
 * @author SA345825
 *
 */
public class KohlsKCSCallForPSA
{
	private static YFCLogCategory logger;
	
	static {
		logger = YFCLogCategory.instance(KohlsKCSCallForPSA.class.getName());
	}
	/**
	 * This method prepares the request document for KohlsCash web service call.
	 * @param env
	 * @param inOrderEle
	 * @return
	 * @throws Exception
	 */
  public Document prepareKCSRequestDoc(YFSEnvironment env,Element inOrderEle) throws Exception {

		Element extDeductibleEle = null;
		Element offerIdEle = null;
		Element offerBalanceEle = null;
		Element earnedAmt = null;
		Element eligibleAmt = null;
		Element eleOrderPromo = null;

		String strExtnActiviationBarCode = null;
		String strExtnCouponAmount = null;
		String strExtnQualifyingAmount = null;
		String storeId = null;

		// Creating the KCS request document.
		Document kcsRequestDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_DETERMINE_KOHLS_CASH_DEACTIVATION_REQUEST_MSG); 
		Element reqEle = kcsRequestDoc.getDocumentElement();

		//header element construction -starts
		Element eleHeader = XMLUtil.createChild(reqEle, KohlsConstant.HEADER);

		Element storeEle = XMLUtil.createChild( eleHeader, KohlsConstant.STORE);
		//PR-37 needs to pass PSA store id for deactivation
		String transactionNumber = XMLUtil.getAttribute( inOrderEle, KohlsXMLLiterals.A_TRANSACTION_NO );
		if (!YFCCommon.isVoid(inOrderEle.getAttribute(KohlsXMLLiterals.A_STORE_ID))) {
			storeId = inOrderEle.getAttribute(KohlsXMLLiterals.A_STORE_ID);
		} else if( YFCCommon.isStringVoid( transactionNumber ) ) {
			storeId = XMLUtil.getAttribute( inOrderEle, KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE);
			logger.error("transactionNumber is coming as null");
		} else {
			storeId = transactionNumber.substring(12,  16);
		}
		// PR-37 End
		XMLUtil.setNodeValue( storeEle, storeId);

		Element teriminalEle = XMLUtil.createChild( eleHeader, KohlsConstant.TERMINAL);
		String terminalId = XMLUtil.getAttribute( inOrderEle,KohlsXMLLiterals.A_TERMINAL_ID);
		XMLUtil.setNodeValue( teriminalEle, terminalId);

		Element transactionEle = XMLUtil.createChild( eleHeader, KohlsConstant.TRANS_NUM);
		String transNumber = XMLUtil.getAttribute( inOrderEle,KohlsPOCConstant.A_POS_SEQUENCE_NO);
		XMLUtil.setNodeValue( transactionEle, transNumber);

		Element businessDateEle = XMLUtil.createChild( eleHeader, KohlsConstant.BUSINESS_DATE);
		String strOrderDate = XMLUtil.getAttribute( inOrderEle,KohlsXMLLiterals.A_ORDER_DATE);
		Date dateOrderDate=KohlsDateUtil.convertDate(strOrderDate);
		strOrderDate=KohlsDateUtil.formatDate(dateOrderDate,KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);
		XMLUtil.setNodeValue( businessDateEle,strOrderDate);

		Element assoIdElement = XMLUtil.createChild( eleHeader, KohlsConstant.ASSO_ID);
		String assoId = XMLUtil.getAttribute( inOrderEle,KohlsPOCConstant.A_OPERATOR_ID);
		XMLUtil.setNodeValue( assoIdElement, assoId);

		Element transTimeElement = XMLUtil.createChild( eleHeader, KohlsConstant.TRAN_START_DATE);
		String strOrderDateTime=KohlsDateUtil.formatDate(dateOrderDate,KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		XMLUtil.setNodeValue( transTimeElement,strOrderDateTime);

		Element trainMdeElement = XMLUtil.createChild( eleHeader, KohlsConstant.TRAINING_MODE);
		XMLUtil.setNodeValue( trainMdeElement, KohlsConstant.FALSE);
		//header element construction -ends

		//Data element construction -starts
		Element eleData = XMLUtil.createChild(reqEle, KohlsConstant.DATA);

		Element eleOrderExtn = XMLUtil.getChildElement(inOrderEle,KohlsXMLLiterals.E_EXTN);
		String receiptId = XMLUtil.getAttribute( eleOrderExtn, KohlsXMLLiterals.A_EXTN_RECEIPT_ID);

		Element receiptIdEle = XMLUtil.createChild(eleData, KohlsConstant.RECEIPT_ID);
		XMLUtil.setNodeValue( receiptIdEle, receiptId);	

		String extDeductibleOffersData = XMLUtil.getAttribute( eleOrderExtn,KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS);
		if(!YFCCommon.isVoid(extDeductibleOffersData)){
			try {
				extDeductibleEle = KohlsPoCPnPUtil.createElementFromXMLString(extDeductibleOffersData);
			} catch (ParserConfigurationException e) {
				logger.error("ParserConfigurationException at KohlsBeforePSAOrderCreateUE.prepareRequestDocument");
				return null;
			} catch (SAXException e) {
				logger.error("SAXException at KohlsBeforePSAOrderCreateUE.prepareRequestDocument");
				return null;
			} catch (IOException e) {
				logger.error("IOException at KohlsBeforePSAOrderCreateUE.prepareRequestDocument");
				return null;
			} 
		}

		Element deductibleOfferEle = XMLUtil.getChildElement( extDeductibleEle,KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);

		if(!YFCCommon.isVoid(deductibleOfferEle)){
			offerIdEle = XMLUtil.getChildElement(deductibleOfferEle,KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID);
			offerBalanceEle = XMLUtil.getChildElement(deductibleOfferEle,KohlsXMLLiterals.E_OFFER_BALANCE_AMOUNT);
			earnedAmt = XMLUtil.getChildElement(deductibleOfferEle,KohlsXMLLiterals.E_EARNED_AMOUNT);
			eligibleAmt = XMLUtil.getChildElement(deductibleOfferEle,KohlsXMLLiterals.E_ELIGIBLE_AMOUNT);
		}

		Element kohlsCashIdEle = XMLUtil.createChild(eleData, KohlsConstant.KOHLS_CASH_ID);
		if(!YFCCommon.isVoid(offerIdEle)){
			XMLUtil.setNodeValue( kohlsCashIdEle, XMLUtil.getNodeValue(offerIdEle));
		} else {
		  logger.error("Kohls Cash ID is not present in deductible Offer. Hence Returning back."+extDeductibleOffersData);
		  return null;
		}

		Element kohlsCashStatusEle = XMLUtil.createChild(eleData, KohlsXMLLiterals.E_KOHLS_CASH_STATUS);
		Element kohlsCashBalEle = XMLUtil.createChild( kohlsCashStatusEle, KohlsXMLLiterals.E_KOHLS_CASH_BALANCE);
		if(!YFCCommon.isVoid(offerBalanceEle)){
			XMLUtil.setNodeValue( kohlsCashBalEle, XMLUtil.getNodeValue(offerBalanceEle));
		}

		Element earnedAmtEle = XMLUtil.createChild( kohlsCashStatusEle, KohlsXMLLiterals.E_EARNED_AMOUNT);
		if(!YFCCommon.isVoid(earnedAmt)){
			XMLUtil.setNodeValue( earnedAmtEle, XMLUtil.getNodeValue(earnedAmt));
		}

		Element eligibleAmtEle = XMLUtil.createChild( kohlsCashStatusEle,KohlsXMLLiterals.E_ELIGIBLE_AMOUNT);
		if(!YFCCommon.isVoid(eligibleAmt)){
			XMLUtil.setNodeValue( eligibleAmtEle, XMLUtil.getNodeValue(eligibleAmt));
		}

		if ((YFCCommon.isVoid(XMLUtil.getNodeValue(kohlsCashIdEle)))
				|| (YFCCommon.isVoid(XMLUtil.getNodeValue(kohlsCashBalEle)))) {

			Document docInquiryRequest = XMLUtil
					.getDocument("<CouponInquiryRequestMsg></CouponInquiryRequestMsg>");
			Element eleInquiryRequest = docInquiryRequest.getDocumentElement();

			Element eleHead = (Element) eleHeader.cloneNode(true);
			docInquiryRequest.adoptNode(eleHead);

			XMLUtil.appendChild(eleInquiryRequest, eleHead);

			Element eleInquiryData = XMLUtil.createChild(eleInquiryRequest,
					"Data");
			Element eleHandKeyedCoupon = XMLUtil.createChild(eleInquiryData,
					"HandKeyedCoupon");
			XMLUtil.setNodeValue(eleHandKeyedCoupon, KohlsConstant.FALSE);

			Element eleCouponNumber = XMLUtil.createChild(eleInquiryData,
					"CouponNumber");

			Element ndOrderPromotions = (Element) XPathUtil.getNode(
					(Node) inOrderEle, "/OrderList/Order/Promotions");

			if (!YFCCommon.isVoid(ndOrderPromotions)) {
				List<Element> promotionList = XMLUtil.getElementsByTagName(
						ndOrderPromotions, KohlsPOCConstant.E_PROMOTION);

				for (Element promotion : promotionList) {

					if ((promotion.getAttribute("PromotionType")
							.equals("KOHLS_CASH_EARNED"))) {

						Element eleExtnPromo = XMLUtil.getChildElement(
								promotion, "Extn");

						if (!YFCCommon.isVoid(eleExtnPromo)) {
							strExtnActiviationBarCode = eleExtnPromo
									.getAttribute("ExtnActivationBarCode");
							strExtnCouponAmount = eleExtnPromo
									.getAttribute("ExtnCouponAmount");
							strExtnQualifyingAmount = eleExtnPromo
									.getAttribute("ExtnQualifyingAmount");
						}
					}

				}
			}
			XMLUtil.setNodeValue(eleCouponNumber, strExtnActiviationBarCode);

			Element elePin = XMLUtil.createChild(eleInquiryData, "Pin");
			Element eleReceiptID = XMLUtil.createChild(eleInquiryData,
					"ReceiptID");
			XMLUtil.setNodeValue(eleReceiptID, receiptId);

			KohlsCashManager kcm = new KohlsCashManager(env);
			Document docInquiryResponse = null;
			
			boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(storeId);
			
			if(logger.isDebugEnabled())
				logger.debug("######Rule value for OMS KC in KohlsBeforePSAOrderCreateUE.prepareRequestDocument: " + omsKCEnabled);
			
			if(omsKCEnabled) {
				if(logger.isDebugEnabled())
					 logger.debug("KohlsBeforePSAOrderCreateUE OMS KC input: " + XMLUtil.getXMLString(docInquiryRequest));
				
				kcm.loadEvents(storeId);
				//Use KCM
				docInquiryResponse = kcm.kohlsCashInquiry(docInquiryRequest);
				
				if(logger.isDebugEnabled())
					 logger.debug("KohlsBeforePSAOrderCreateUE OMS KC output: " + XMLUtil.getXMLString(docInquiryResponse));
			}
			else {
				if(logger.isDebugEnabled())
					 logger.debug("KohlsBeforePSAOrderCreateUE KCS input: " + XMLUtil.getXMLString(docInquiryRequest));
				
				//Use KCS
				docInquiryResponse = KohlsCommonUtil.invokeService(env,
							KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_INQUIRY_WEB_SERVICE,
							docInquiryRequest);
				
				if(logger.isDebugEnabled())
					 logger.debug("KohlsBeforePSAOrderCreateUE KCS output: " + XMLUtil.getXMLString(docInquiryResponse));
			}
			
			Element eleKohlsCashInquiryResponse = docInquiryResponse
					.getDocumentElement();

			Element dataEle = (Element) XMLUtil.getElementsByTagName(
					eleKohlsCashInquiryResponse, KohlsPOCConstant.E_DATA).get(
					KohlsPOCConstant.ZERO_INT);
			String strCouponBalance = XMLUtil.getAttribute(dataEle,
					"CouponBalance");

			if (((!YFCCommon.isVoid(strExtnActiviationBarCode))
					&& (!YFCCommon.isVoid(strCouponBalance))
					&& (!YFCCommon.isVoid(strExtnQualifyingAmount)) && (!YFCCommon
						.isVoid(strExtnCouponAmount)))) {
				XMLUtil.setNodeValue(kohlsCashIdEle, strExtnActiviationBarCode);
				XMLUtil.setNodeValue(kohlsCashBalEle, strCouponBalance);
				XMLUtil.setNodeValue(earnedAmtEle, strExtnCouponAmount);
				XMLUtil.setNodeValue(eligibleAmtEle, strExtnQualifyingAmount);
			}

		}


		Element returnItemListEle = XMLUtil.createChild(eleData,KohlsXMLLiterals.E_RETURNABLE_ITEMLIST);
		Element promotions = XMLUtil.getChildElement(inOrderEle,KohlsXMLLiterals.E_PROMOTIONS);
		
		Document docKohlsSaleForPSAIn = XMLUtil.createDocument("KOHLSSalesForPsa");
		Element eleKohlsSaleForPSAInRoot = docKohlsSaleForPSAIn.getDocumentElement();
		eleKohlsSaleForPSAInRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, inOrderEle.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
		Document docKohlsSaleForPSAOut = KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docKohlsSaleForPSAIn);
		String sOriginalSaleData = docKohlsSaleForPSAOut.getDocumentElement().getAttribute("OriginalSaleData");
		Element eleOrigOrderLines = null;
		if(!YFCCommon.isVoid(sOriginalSaleData)) {
		  Document docOrigSaleData = XMLUtil.getDocument(sOriginalSaleData);
		  eleOrigOrderLines = XMLUtil.getChildElement(docOrigSaleData.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
		}
		env.setTxnObject("OriginalOrderLinesForPSA", eleOrigOrderLines);
		List <Element> orderLineList = XMLUtil.getElementsByTagName(inOrderEle, KohlsPOCConstant.E_ORDER_LINE);
		for(Element orderLine: orderLineList){

			String orderLineNo = XMLUtil.getAttribute( orderLine,KohlsXMLLiterals.A_PRIME_LINE_NO);

			Element orderLineExtn = XMLUtil.getChildElement( orderLine,KohlsXMLLiterals.E_EXTN);
			String dept = XMLUtil.getAttribute( orderLineExtn,KohlsPOCConstant.A_EXTN_ITEM_DEPT);
			String returnVal = KohlsPOCConstant.TRUE;

			Double itemNetPrice = calculateItemDeltaPrice(orderLine, promotions, eleOrigOrderLines);

			Element returnItem = XMLUtil.createChild( returnItemListEle,KohlsXMLLiterals.E_RETURNABLE_ITEM);

			Element lineNoEle = XMLUtil.createChild( returnItem,KohlsXMLLiterals.E_LINE_NO );
			XMLUtil.setNodeValue(lineNoEle, orderLineNo);

			Element departmentEle = XMLUtil.createChild( returnItem,KohlsPOCConstant.A_DEPT );
			XMLUtil.setNodeValue( departmentEle, dept );

			Element netPriceEle = XMLUtil.createChild( returnItem,KohlsPOCConstant.A_NET_PRICE );
			XMLUtil.setNodeValue( netPriceEle, itemNetPrice.toString());

			Element returnEle = XMLUtil.createChild( returnItem,KohlsXMLLiterals.A_RETURN );
			XMLUtil.setNodeValue( returnEle, returnVal );
		}
		//Data element construction -ends
		logger.debug("Input to KohlsCashDeactivation webservice call::" +SCXmlUtil.getString(kcsRequestDoc));
		return kcsRequestDoc;		
	}

	/**
	 * This methods calculates the NetPrice of the Item.
	 * @param orderLine
	 * @param promotions
	 * @return
	 * @throws Exception
	 */
	public double calculateItemDeltaPrice(Element orderLine, Element promotions, Element eleOrigOrderLines) throws Exception{

		double totalAwards = 0.00;
		String sOrderLineKey = orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
		List<Element> promotionList = XMLUtil.getElementsByTagName(promotions,KohlsPOCConstant.E_PROMOTION);
	    Element eleOrigOrderLine = (Element) SCXmlUtil.getXpathNodes(eleOrigOrderLines, 
	        "//OrderLines/OrderLine[@OrderLineKey='"+orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY)+"']").item(0);
	    List <Element> origAwardList = XMLUtil.getElementsByTagName(eleOrigOrderLine,KohlsXMLLiterals.E_AWARD);
	    
	    List <Element> awardList = XMLUtil.getElementsByTagName(orderLine,KohlsXMLLiterals.E_AWARD);

		for(Element award : awardList){
			String awardPromoId = XMLUtil.getAttribute( award,KohlsXMLLiterals.E_PROMOTION_ID);
			Element eleAwardExtn = XMLUtil.getChildElement(award, KohlsXMLLiterals.E_EXTN, true);
			String isPSAPromotion = "";
			
			// Calculating changes to the Promotions from orig sale.
  			for(Element origAward : origAwardList) {
  			  String origAwardPromoId = XMLUtil.getAttribute(origAward,KohlsXMLLiterals.E_PROMOTION_ID);
  			  String currentAwardPromoId = XMLUtil.getAttribute( award,KohlsXMLLiterals.E_PROMOTION_ID);
  			  if("ASSOC_DISC_MANUAL_SOFT_LINE".equalsIgnoreCase(currentAwardPromoId) || "ASSOC_DISC_MANUAL_HARD_LINE".equalsIgnoreCase(currentAwardPromoId)) {
  			    currentAwardPromoId = "790";
  			  }
  			  if("ASSOC_DISC_MANUAL_SOFT_LINE".equalsIgnoreCase(origAwardPromoId) || "ASSOC_DISC_MANUAL_HARD_LINE".equalsIgnoreCase(origAwardPromoId)) {
  			    origAwardPromoId = "790";
              }
  			  if(!YFCCommon.isVoid(currentAwardPromoId) && !YFCCommon.isVoid(origAwardPromoId) && currentAwardPromoId.contains( origAwardPromoId) 
  					  && !currentAwardPromoId.contains("FEE_")){
  			      //adjusted AwardAmt calculated
  			    totalAwards = totalAwards + (Math.abs(Double.parseDouble(award.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT))) 
  			        - Math.abs(Double.parseDouble(origAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT))));
  			    break;
  			   }
  			  }
			
			for(Element promotion : promotionList){
				String promoId = XMLUtil.getAttribute(promotion,KohlsXMLLiterals.E_PROMOTION_ID);
				if(awardPromoId.equalsIgnoreCase( promoId) && !awardPromoId.contains("FEE_")){
					Element promoExtn = XMLUtil.getChildElement( promotion,KohlsXMLLiterals.E_EXTN);
					isPSAPromotion = XMLUtil.getAttribute( promoExtn,KohlsPOCConstant.ISPSAPROMOTION);
					break;
				}
			}

			if(KohlsPOCConstant.YES.equalsIgnoreCase(isPSAPromotion)){
			  //String awardAmount = XMLUtil.getAttribute(award, KohlsPOCConstant.A_AWARD_AMOUNT);
		        String awardAmount = XMLUtil.getAttribute(eleAwardExtn, KohlsPOCConstant.A_EXTN_NET_DELTA);
		        if(YFCCommon.isVoid(awardAmount)) {
		          awardAmount = "0.00";
		        }
				totalAwards += Math.abs(Double.parseDouble(awardAmount));   
			}
		}
		
		
		// Changes for LoyaltyV2 to add Tax
		String sCallingSource = orderLine.getAttribute("CallingSource");
		if(!YFCCommon.isVoid(sCallingSource) && totalAwards > 0.00D) {
		  Element eleOriginalLineTax = (Element) SCXmlUtil.getXpathNodes(eleOrigOrderLines, 
	            "//OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/LineTaxes/LineTax").item(0);
		  Element eleCurrentLineTax = (Element) SCXmlUtil.getXpathNodes(orderLine, 
		      "//OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/LineTaxes/LineTax").item(0);
		  if(!YFCCommon.isVoid(eleOriginalLineTax) && !YFCCommon.isVoid(eleCurrentLineTax)){
		    String sOriginalTax = eleOriginalLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
		    String sCurrentTax = eleCurrentLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
		    if(!YFCCommon.isVoid(sOriginalTax) && !YFCCommon.isVoid(sCurrentTax)) {
		      double dNetTax = Double.parseDouble(sOriginalTax) - Double.parseDouble(sCurrentTax);
		      totalAwards = totalAwards + dNetTax;
		    }
		  }
		  
		  NodeList nlOrigFeeCharge = (NodeList) SCXmlUtil.getXpathNodes(eleOrigOrderLines, 
              "//OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/LineCharges/LineCharge[@ChargeCategory='FEE']");
          NodeList nlCurrentFeeCharge = (NodeList) SCXmlUtil.getXpathNodes(orderLine, 
            "//OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/LineCharges/LineCharge[@ChargeCategory='FEE']");
          if(nlOrigFeeCharge.getLength()>0 && nlCurrentFeeCharge.getLength()>0) {
            for(int i=0; i<nlOrigFeeCharge.getLength(); i++) {
              Element eleOrigLineCharge = (Element)nlOrigFeeCharge.item(i);
              String sChargeName = eleOrigLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
              Element eleCurrentLineCharge = (Element) SCXmlUtil.getXpathNodes(orderLine, 
                  "//OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/LineCharges/LineCharge[@ChargeCategory='FEE'][@ChargeName='"+sChargeName+"']").item(0);
              if(!YFCCommon.isVoid(eleCurrentLineCharge)) {
                String sOrigChargePerLine = eleOrigLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
                String sCurrentChargePerLine = eleCurrentLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
                Double dNetFee = Double.parseDouble(sOrigChargePerLine) - Double.parseDouble(sCurrentChargePerLine);
                totalAwards = totalAwards + dNetFee;
              }
            }
          }
        
		}
		
		DecimalFormat df = new DecimalFormat("0.00");
        String tempNetPrice = df.format(totalAwards);

        double itemNetPrice = Double.valueOf(tempNetPrice);

		logger.debug("NetPrice of Item:"+itemNetPrice);
		return itemNetPrice;
	}
	
}
