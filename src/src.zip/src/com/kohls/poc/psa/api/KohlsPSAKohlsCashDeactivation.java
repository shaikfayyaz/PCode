package com.kohls.poc.psa.api;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.util.KohlcPoCWriteToFileUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author SA345825 
 * Sample Input XML 
 * <Order RefundAmount="30" OrderHeaderKey="">
 * 
 */
/**************************************************************************
 * File : KohlsPSAKohlsCashDeactivation.java Author : Sadhana KB , Mar 11 2016
 * Modified : Mar 11 2016 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 11/03/2016
 *****************************************************************************/

public class KohlsPSAKohlsCashDeactivation {
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPSAKohlsCashDeactivation.class
				.getName());
	}
	KohlsKCSCallForPSA KCSobj = new KohlsKCSCallForPSA();
	KohlsTVSCallForKohlsCashEligibleItems firstTVSObj = new KohlsTVSCallForKohlsCashEligibleItems();
	KohlsSecondTVSCallForPSA secondTVSObj = new KohlsSecondTVSCallForPSA();
	//CPE-3766 changes 
	HashMap<String, Double> mapLinePrice = new HashMap<String, Double>();
	String sEligibleAmount= "";
	String strAmtToBeUnearned = "";
	String strMRKohlsCashReduction ="";
	String sNetPriceDelta = "";
	public String callingSource ="";
	double dLineTax=0.0;
	double dDeltaTax=0.0;
	public double dMRRefundDeduction =0.0;
	public Document kcsResponseDoc = null;
	//MAD-646 changes start
	String endpoint = "";
	//MAD-646 changes end

	/**
	 * 
	 * @param env
	 * @param orderInDoc
	 * @return
	 * @throws Exception
	 */
	public Document deactivateKohlsCash(YFSEnvironment env, Document orderInDoc)
			throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		logger.debug("Input to method deactivateKohlsCash ::"
				+ XMLUtil.getXMLString(orderInDoc));
		Document docGetOrderListOuput = null;
		Document firstTVSResponseForMRDoc = null;
		Document firstTVSResponseForMKCDoc = null;
		Document secondTVSResponseForMRDoc = null;
		Document secondTVSResponseForMKCDoc = null;
		Element tempOrderEle = null;
		Double dAmtToBeUnearned = 0.0;
		Double dRefundAmount = 0.0;
		Double dNetPriceTotal = 0.0;
		Double dMaxRefRefundReduction = 0.0;
		Double dMaxKohlsCashRefundReduction = 0.0;
		String strOriginalTotalAmount = "";
		boolean bErrorsInTVS = false;
		boolean bErrorsInKCS = false;
	    boolean bDisplayUIPrompt = true;
		// Added For PSA Data Collect- START
		String strKohlscashId = "";
		String strRedemptionPeriod = "";
		// Added For PSA Data Collect- END
		String strSellerOrganizationCode, strTerminalID, strPosSequenceNo = "";
		Element eleInOrder = orderInDoc.getDocumentElement();
		if(!YFCCommon.isVoid(eleInOrder.getAttribute("CallingSource"))) {
		  callingSource = eleInOrder.getAttribute("CallingSource");
		}
		
		String sOrderHeaderKey = eleInOrder
				.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
		String sRefundAmount = eleInOrder
				.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
		logger.debug(" Refund Amount ::" + sRefundAmount);
		if (!YFCCommon.isVoid(sRefundAmount)) {
			dRefundAmount = Double.parseDouble(sRefundAmount);
		}
		String callingStoreNumber = eleInOrder
				.getAttribute(KohlsXMLLiterals.A_STORE_ID);

		// Forming the input document for getOrderList API Call.
		Document docGetOrderListInput = XMLUtil.createDocument("Order");
		Element eleOrderInput = docGetOrderListInput.getDocumentElement();
		if (!YFCCommon.isVoid(sOrderHeaderKey)) {
			eleOrderInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
					sOrderHeaderKey);
			try {
				//MAD-646 changes Start
				//CPE-2494 changes Start
				/*logger.debug("Checking if it is edge Deployemnt DEactivationKohlsCash::"+ServerTypeHelper.amIOnEdgeServer());
				if(ServerTypeHelper.amIOnEdgeServer()){
					Element eleAdditionalInfo= SCXmlUtil.createChild(eleOrderInput,KohlsXMLLiterals.E_YFCADDITIONALINFO);
					eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_LOCALANDMOTHERSHIP);
				 }*/
				//CPE-2494 changes end
				//MAD-646 changes end
				docGetOrderListOuput = KOHLSBaseApi.invokeService(env,
						KohlsConstant.PSA_GET_ORDER_LIST, docGetOrderListInput);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				logger.error("Exception in KohlsBeforePSAOrderCreateUE.beforeCreateOrder, when calling PSAgetOrderList service"
						+ e1.getMessage());
			}
		} else {
			logger.error("OrderHeaderKey is null in the input xml");
			return orderInDoc;
		}

		// Preparing Output document.
		Document outputDoc = XMLUtil.createDocument("RefundOptions");
		Element eleRefundOptions = outputDoc.getDocumentElement();
		eleRefundOptions.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
				sOrderHeaderKey);

		Element eleOrderList = docGetOrderListOuput.getDocumentElement();
		if (!YFCCommon.isVoid(eleOrderList)) {
			tempOrderEle = (Element) eleOrderList.getElementsByTagName("Order")
					.item(0);
			if (!YFCCommon.isVoid(tempOrderEle)) {
				strOriginalTotalAmount = tempOrderEle
						.getAttribute("OriginalTotalAmount");
				/*MAD-646 changes start
				logger.debug("before getting endpoint ::"+ServerTypeHelper.amIOnEdgeServer());
				if(ServerTypeHelper.amIOnEdgeServer()){
					Element eleyfcAdditional  = (Element)(XPathUtil.getNode(tempOrderEle, KohlsXMLLiterals.E_YFCADDITIONALINFO));
					if(!YFCCommon.isVoid(eleyfcAdditional)){
						endpoint = eleyfcAdditional.getAttribute(KohlsXMLLiterals.A_ENDPOINT);
					}
				}
				//MAD-646 changes End*/
			}
		}
		//Loyalty V2 changes - Start
		strSellerOrganizationCode = tempOrderEle
				.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE);
		strTerminalID = tempOrderEle
				.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID);
		strPosSequenceNo = tempOrderEle
				.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO);
		//Loyalty V2 changes - End
		if (!YFCCommon.isVoid(callingStoreNumber)) {
			tempOrderEle.setAttribute(KohlsXMLLiterals.A_STORE_ID, callingStoreNumber);
		}

		Document kcsReqDoc = KCSobj.prepareKCSRequestDoc(env, tempOrderEle);
		
		if(YFCCommon.isVoid(kcsReqDoc)) {
		  logger.error("Event KC is not present. Hence returning.");
		  return XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
		}
		
		//CPE-3766 changes
		Document outDoc = null;
		
		KohlsCashManager kcm = new KohlsCashManager(env);
		
		boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(callingStoreNumber);
		
		if(logger.isDebugEnabled())
			logger.debug("######Rule value for OMS KC in .deactivateKohlsCash: " + omsKCEnabled);
		
		if(omsKCEnabled) {
			if(logger.isDebugEnabled())
				logger.debug("KohlsPSAKohlsCashDeactivation OMS KC input: " + SCXmlUtil.getString(kcsReqDoc));
			
			kcm.loadEvents(callingStoreNumber);
			//Use KCM
			kcsResponseDoc = kcm.determineKohlsCashDeactivation(kcsReqDoc);
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsPSAKohlsCashDeactivation KCS output: " + SCXmlUtil.getString(kcsResponseDoc));
		}
		else {
			if(logger.isDebugEnabled())
				logger.debug("KohlsPSAKohlsCashDeactivation KCS input: " + SCXmlUtil.getString(kcsReqDoc));
			
			//Use KCS
			kcsResponseDoc = KohlsCommonUtil.invokeService(env,
					KohlsConstant.KOHLS_CASH_DEACTIVATION_WEB_SERVICE, kcsReqDoc);
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsPSAKohlsCashDeactivation KCS output: " + SCXmlUtil.getString(kcsResponseDoc));
		}
		
		// Creating Document in case of errors
		Document kcsOutputDoc = XMLUtil
				.createDocument(KohlsXMLLiterals.E_ORDER);
		Element OrderElement = kcsOutputDoc.getDocumentElement();
		OrderElement.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
				sOrderHeaderKey);
		OrderElement.setAttribute(KohlsXMLLiterals.A_PROCEED_WITH_TENDERING,
				KohlsConstant.YES);
		
		if(kcsResponseDoc != null) {
			String request = "KC Request:" + SCXmlUtil.getString(kcsReqDoc) + "\n";
	  	  	String response = "KC Response:" + SCXmlUtil.getString(kcsResponseDoc) + "\n";
			try {
	          KohlcPoCWriteToFileUtil fileUtil = new KohlcPoCWriteToFileUtil("/logs/apps/of/KCS/" + "KC_"+System.currentTimeMillis()+".txt", true);
	          if (!YFCCommon.isVoid(fileUtil)) {
	            fileUtil.writeDataToFile(request+response);
	            fileUtil.closeFile();
	          }
	        } catch (Exception ex) {
	          // problem logging to file
	        	//ex.printStackTrace(); 
	        	logger.debug("########## Exception to write file :" +request + response);
	        }
			
			if(logger.isDebugEnabled())
				logger.debug("Output of KohlsCashWebservice call::"
					+ SCXmlUtil.getString(kcsResponseDoc));
			
			bErrorsInKCS = validateKohlsCashResponseErrors(kcsResponseDoc, omsKCEnabled);
		}
		else {
			//If response was null, indicate that there was an error in the response
			bErrorsInKCS = true;
		}
		
		if (bErrorsInKCS) {
			logger.debug("Errors in KohlsCashDeactivation response, Please proceed with tendering!!");
			OrderElement.setAttribute(KohlsXMLLiterals.A_ERR_DESC,
					"Errors in KCS Response");
			return kcsOutputDoc;
		} else {
			logger.debug("No Errors in KohlsCashDeactivation response");
			Element eleUnearnedValue = null;
			Element eleDeactivationOptions = null;
			Element eleKohlscashId = null;
			Element eleRedemptionPeriod = null;
			Element eleReturnableItemList = null;
			
			if(omsKCEnabled) {
				eleUnearnedValue = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponseMsg/Data/UnearnedValue");
				eleDeactivationOptions = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponseMsg/Data/DeactivationOptions");
				// Added For PSA Data Collect- START
				eleKohlscashId = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponseMsg/Data/KohlsCashID");
				eleRedemptionPeriod = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponseMsg/Data/RedemptionPeriod");
				eleReturnableItemList = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponseMsg/Data/ReturnableItemList");
			}
			else {
				eleUnearnedValue = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/UnearnedValue");
				eleDeactivationOptions = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/DeactivationOptions");
				// Added For PSA Data Collect- START
				eleKohlscashId = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/KohlsCashID");
				eleRedemptionPeriod = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/RedemptionPeriod");
				eleReturnableItemList = KohlsXPathUtil
						.getElementByXpath(
								kcsResponseDoc,
								"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/ReturnableItemList");
			}
  			dNetPriceTotal = calculateNetPrice(eleReturnableItemList,
  					dNetPriceTotal);
  			
  			if(!YFCCommon.isVoid(callingSource)) {
              // If its Loyalty V2 call then append the Returnable Item List from KCS call to O/P doc 
              XMLUtil.importElement(outputDoc.getDocumentElement(), eleReturnableItemList);
            }

			// Added For PSA Data Collect- END
			// Fetching additional response attributes -- begin -- 14/5/16
			try {
				Element eleKCDData = null;
				Element eleEligibilityDeduction = null;
				
				if(omsKCEnabled) {
					eleKCDData = KohlsXPathUtil
							.getElementByXpath(
									kcsResponseDoc,
									"DetermineKohlsCashDeactivationResponseMsg/Data");
					eleEligibilityDeduction = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
		                    "DetermineKohlsCashDeactivationResponseMsg/Data/EligibilityDeduction");
				}
				else {
					eleKCDData = KohlsXPathUtil
							.getElementByXpath(
									kcsResponseDoc,
									"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data");
					eleEligibilityDeduction = KohlsXPathUtil.getElementByXpath(kcsResponseDoc,
		                    "DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data/EligibilityDeduction");
				}
				
				if (!YFCCommon.isVoid(eleUnearnedValue)) {
					strAmtToBeUnearned = XMLUtil
							.getNodeValue(eleUnearnedValue);
					dAmtToBeUnearned = Double.parseDouble(strAmtToBeUnearned);
				}
				// Added For PSA Data Collect- START
				if (!YFCCommon.isVoid(eleKohlscashId)) {
					strKohlscashId = XMLUtil.getNodeValue(eleKohlscashId);

				}
				if (!YFCCommon.isVoid(eleRedemptionPeriod)) {
					strRedemptionPeriod = XMLUtil
							.getNodeValue(eleRedemptionPeriod);
				}
				double dEligibleAmt = 0.0d;
				String strEligibleAmt = "";
				
				if (!YFCCommon.isVoid(eleEligibilityDeduction)) {
                  strEligibleAmt = XMLUtil.getNodeValue(eleEligibilityDeduction);
                  dEligibleAmt = Double.parseDouble(strEligibleAmt);
                  eleRefundOptions.setAttribute(KohlsXMLLiterals.E_ELIGIBLE_AMOUNT, strEligibleAmt);
				}
				
				if (KohlsConstants.KC_REDEMPTION_PERIOD_ACTIVATION.equalsIgnoreCase(strRedemptionPeriod)
						|| KohlsConstants.KC_REDEMPTION_PERIOD_POSTREDEMPTION.equalsIgnoreCase(strRedemptionPeriod)) {
					double dKohlsCashBalance = 0.0d;
					
					try {
	                    Element eleKohlsCashBalance = XMLUtil.getChildElement(eleKCDData, KohlsPOCConstant.KC_BAL);
	                    
	                    if (!YFCCommon.isVoid(eleKohlsCashBalance)) {
	                        String strKohlsCashBalance = XMLUtil.getNodeValue(eleKohlsCashBalance);
	                        if (!YFCCommon.isVoid(strKohlsCashBalance)) {
	                            dKohlsCashBalance = Double.parseDouble(strKohlsCashBalance);
	                        }
	                    }
	                    if ((dAmtToBeUnearned - dKohlsCashBalance) >=  dEligibleAmt) {
	                        bDisplayUIPrompt = false;
	                    }
	                } catch (Exception e) {
	                    logger.error("errors determining kohls cash amount.", e);
	                }
				} 
				
				if (!YFCCommon.isVoid(sOrderHeaderKey) && YFCCommon.isVoid(callingSource)) {
					callChangeOrder(env, strKohlscashId, dAmtToBeUnearned,
							strRedemptionPeriod, dNetPriceTotal,
							sOrderHeaderKey,eleDeactivationOptions, bDisplayUIPrompt, strEligibleAmt);

				}
				// Added For PSA Data Collect- END

				// Element
				// eleRedemptionPeriod=XMLUtil.getChildElement(eleKCDData,
				// "RedemptionPeriod");

				// System.out.println("eleKCDData ::"+XMLUtil.getElementXMLString(eleRedemptionPeriod));

				Element eleKohlsCashBalance = XMLUtil.getChildElement(
						eleKCDData, "KohlsCashBalance");

				// System.out.println("eleKCDData ::"+XMLUtil.getElementXMLString(eleKohlsCashBalance));

				// Element eleHeaderElement = kcsReqDoc.getDocumentElement();

				Element eleEligibleAmount = KohlsXPathUtil
						.getElementByXpath(kcsReqDoc,
								"DetermineKohlsCashDeactivationRequestMsg/Data/KohlsCashStatus/EarnedAmt");

				outputDoc.adoptNode(eleRedemptionPeriod);
				eleRefundOptions.appendChild(eleRedemptionPeriod);
				outputDoc.adoptNode(eleUnearnedValue);
				eleRefundOptions.appendChild(eleUnearnedValue);
				outputDoc.adoptNode(eleKohlsCashBalance);
				eleRefundOptions.appendChild(eleKohlsCashBalance);
				outputDoc.adoptNode(eleEligibleAmount);
				eleRefundOptions.appendChild(eleEligibleAmount);
				outputDoc.adoptNode(eleKohlscashId);
				eleRefundOptions.appendChild(eleKohlscashId);
				sEligibleAmount = XMLUtil.getNodeValue(eleEligibleAmount);
				eleRefundOptions.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_CPN_RETURN_AMOUNT,String.valueOf(dNetPriceTotal));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			//Creating promotion attribute CPE-3766
			 
			outDoc = (Document) orderInDoc.cloneNode(true);
			Element elePromotions =
			        XMLUtil.getChildElement(outDoc.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);
			    if (YFCCommon.isVoid(elePromotions)) {
			      elePromotions =  XMLUtil.createChild(outDoc.getDocumentElement(), KohlsXMLLiterals.E_PROMOTIONS);
			    }
			Element elePromotion = XMLUtil.createChild(elePromotions, KohlsXMLLiterals.E_PROMOTION);
			
						// Fetching additional response attributes -- end -- 14/5/16

			if (dRefundAmount > dAmtToBeUnearned) {
				Element eleMaximizeRefund = XMLUtil.getChildElement(
						eleDeactivationOptions, "MaximizeRefund");
				if (!YFCCommon.isVoid(eleMaximizeRefund)) {
					Element eleMaxRefund = outputDoc
							.createElement("MaximizeRefund");
					
					//CPE-3766 changes
					Element eleMaxRefundPro = XMLUtil.createChild(elePromotion,
							"MaximizeRefund");

					// setting the value of UnearnedKohlsCash for maximize
					// refund in the output.
					Element eleMRKohlsCashReduction = XMLUtil.getChildElement(
							eleMaximizeRefund, "KohlsCashReduction");
					if (!YFCCommon.isVoid(eleMRKohlsCashReduction)) {
						strMRKohlsCashReduction = XMLUtil
								.getNodeValue(eleMRKohlsCashReduction);
						eleMaxRefund.setAttribute("UnearnedKohlsCash",
								strMRKohlsCashReduction);
						
						//CPE-3766 changes
						eleMaxRefundPro.setAttribute("UnearnedKohlsCash",
								strMRKohlsCashReduction);
					}
					// setting the value of RefundAmount for maximize refund in
					// the output.
					Element eleMRRefundDeduction = XMLUtil.getChildElement(
							eleMaximizeRefund, "RefundDeduction");
					if (!YFCCommon.isVoid(eleMRRefundDeduction)) {
					    String strMRRefundDeduction = XMLUtil
								.getNodeValue(eleMRRefundDeduction);
							dMRRefundDeduction = Double
								.parseDouble(strMRRefundDeduction);
						//Skip calling TVS for V2 - callingSource - V2Unearn
						if (dMRRefundDeduction > 0.0  && YFCCommon.isVoid(callingSource)) {
							firstTVSResponseForMRDoc = firstTVSObj
									.prepareRequestForFirstTVSCall(env,
											kcsResponseDoc, tempOrderEle,
											eleMRRefundDeduction);
							bErrorsInTVS = checkForTVSResponseErrors(firstTVSResponseForMRDoc);
							if (bErrorsInTVS) {
								logger.debug("Errors in First TVS response, Please proceed with tendering!!");
								OrderElement.setAttribute(
										KohlsXMLLiterals.A_ERR_DESC,
										"Errors in First TVS Response");
								return kcsOutputDoc;
							}
							secondTVSResponseForMRDoc = secondTVSObj
									.prepareRequestForSecondTVSCall(env,
											firstTVSResponseForMRDoc,
											tempOrderEle);
							bErrorsInTVS = checkForTVSResponseErrors(secondTVSResponseForMRDoc);
							addRefundDeductionCharges(env,
									firstTVSResponseForMRDoc, outDoc,elePromotion ,"MaximizeRefund",
							        tempOrderEle);
							if (bErrorsInTVS) {
								logger.debug("Errors in Second TVS response, Please proceed with tendering!!");
								OrderElement.setAttribute(
										KohlsXMLLiterals.A_ERR_DESC,
										"Errors in Second TVS Response");
								return kcsOutputDoc;
							}
							dMaxRefRefundReduction = Double
									.parseDouble(strOriginalTotalAmount)
									- calculateTempOrderPrice(secondTVSResponseForMRDoc);
							Double finalRefundForMaxRefund = dRefundAmount
									- dMaxRefRefundReduction;
							finalRefundForMaxRefund = Double.valueOf(df
									.format(finalRefundForMaxRefund));
							eleMaxRefund.setAttribute("RefundAmount",
									df.format(finalRefundForMaxRefund));
							eleRefundOptions.appendChild(eleMaxRefund);
							//CPE-3766 changes
							eleMaxRefundPro.setAttribute("RefundAmount",
									df.format(finalRefundForMaxRefund));
						} else {
							dRefundAmount = Double.valueOf(df
									.format(dRefundAmount));
							eleMaxRefund.setAttribute("RefundAmount",
									df.format(dRefundAmount));
							eleRefundOptions.appendChild(eleMaxRefund);
							//CPE-3766 changes
							eleMaxRefundPro.setAttribute("RefundAmount",
									df.format(dRefundAmount));
						}
						eleMaxRefund.setAttribute("RefundDeduction", df.format(dMRRefundDeduction));
					}
				}
				Element eleMaximizeKohlsCash = XMLUtil.getChildElement(
						eleDeactivationOptions, "MaximizeKohlsCash");
				/*if (!YFCCommon.isVoid(eleMaximizeKohlsCash)) {
					//CPE-3766 changes
					 Element elePromotionMaxKohlsCash =
				              XMLUtil.createChild(elePromotion, KohlsPOCConstant.MAX_KC);
					Element eleMaxKohlsCash = outputDoc
							.createElement("MaximizeKohlsCash");

					// setting the value of UnearnedKohlsCash for Maximize
					// kohlsCash in the output.
					Element eleMKCKohlsCashReduction = XMLUtil.getChildElement(
							eleMaximizeKohlsCash, "KohlsCashReduction");
					if (!YFCCommon.isVoid(eleMKCKohlsCashReduction)) {
						String strMKCKohlsCashReduction = XMLUtil
								.getNodeValue(eleMKCKohlsCashReduction);
						eleMaxKohlsCash.setAttribute("UnearnedKohlsCash",
								strMKCKohlsCashReduction);
						//CPE-3766 changes 
						 elePromotionMaxKohlsCash.setAttribute("UnearnedKohlsCash",
									strMKCKohlsCashReduction);
					}

					// setting the value of RefundAmount for Maximize kohlsCash
					// in the output.
					Element eleMKCRefundDeduction = XMLUtil.getChildElement(
							eleMaximizeKohlsCash, "RefundDeduction");
					if (!YFCCommon.isVoid(eleMKCRefundDeduction)) {
						String strMKCRefundDeduction = XMLUtil
								.getNodeValue(eleMKCRefundDeduction);
						Double dMKCRefundDeduction = Double
								.parseDouble(strMKCRefundDeduction);
						logger.debug("amount :: dMKCRefundDeduction ::"+dMKCRefundDeduction);
						if (dMKCRefundDeduction > 0.0) {
							firstTVSResponseForMKCDoc = firstTVSObj
									.prepareRequestForFirstTVSCall(env,
											kcsResponseDoc, tempOrderEle,
											eleMKCRefundDeduction);
							bErrorsInTVS = checkForTVSResponseErrors(firstTVSResponseForMKCDoc);
							addRefundDeductionCharges(env,
									firstTVSResponseForMKCDoc, outDoc,elePromotion ,"MaximizeKohlsCash",
							        tempOrderEle);
							
							if (bErrorsInTVS) {
								logger.debug("Errors in First TVS response, Please proceed with tendering!!");
								OrderElement.setAttribute(
										KohlsXMLLiterals.A_ERR_DESC,
										"Errors in First TVS Response");
								return kcsOutputDoc;
							}
							secondTVSResponseForMKCDoc = secondTVSObj
									.prepareRequestForSecondTVSCall(env,
											firstTVSResponseForMKCDoc,
											tempOrderEle);
							bErrorsInTVS = checkForTVSResponseErrors(secondTVSResponseForMKCDoc);
							if (bErrorsInTVS) {
								logger.debug("Errors in Second TVS response, Please proceed with tendering!!");
								OrderElement.setAttribute(
										KohlsXMLLiterals.A_ERR_DESC,
										"Errors in Second TVS Response");
								return kcsOutputDoc;
							}
							Element eleOverAllTotal = (Element)tempOrderEle.getElementsByTagName("OverallTotals").item(0);
							
							
							dMaxKohlsCashRefundReduction = Double
									.parseDouble(strOriginalTotalAmount)
									- calculateTempOrderPrice(secondTVSResponseForMKCDoc);
							if(!YFCCommon.isVoid(eleOverAllTotal))
							{
								this.dDeltaTax=this.dLineTax - Double.parseDouble(eleOverAllTotal.getAttribute("GrandTax"));
								
							}
							double dAssociateDiscount=getAssociateDiscount(tempOrderEle);
							Double finalRefundForMaxKohlsCash = dRefundAmount
									- dMaxKohlsCashRefundReduction;
							if(!YFCCommon.isVoid(dAssociateDiscount)){
								finalRefundForMaxKohlsCash=finalRefundForMaxKohlsCash-dAssociateDiscount;
								finalRefundForMaxKohlsCash=finalRefundForMaxKohlsCash+this.dDeltaTax;
							}
							finalRefundForMaxKohlsCash = Double.valueOf(df
									.format(finalRefundForMaxKohlsCash));
							eleMaxKohlsCash.setAttribute(
											"RefundAmount",df.format(finalRefundForMaxKohlsCash));
							eleRefundOptions.appendChild(eleMaxKohlsCash);
							elePromotionMaxKohlsCash.setAttribute("RefundAmount",
									df.format(finalRefundForMaxKohlsCash));
							
						} else {
							dRefundAmount = Double.valueOf(df
									.format(dRefundAmount));
							
							double dAssociateDiscount=getAssociateDiscount(tempOrderEle);
							if(!YFCCommon.isVoid(dAssociateDiscount)){
								dRefundAmount=dRefundAmount-dAssociateDiscount;
								dRefundAmount =dRefundAmount+this.dDeltaTax;
							}
							eleMaxKohlsCash.setAttribute("RefundAmount",
									df.format(dRefundAmount));
							eleRefundOptions.appendChild(eleMaxKohlsCash);
							//CPE-3766 changes
							elePromotionMaxKohlsCash.setAttribute("RefundAmount",
									df.format(dRefundAmount));
						}
					}
				}*/
			} else {
				Element eleMaximizeRefund = outputDoc
						.createElement("MaximizeRefund");
				eleMaximizeRefund.setAttribute("RefundAmount",
						df.format(dRefundAmount));
				
				//Fix for #3598 - POC Returns Team - Start
				if(YFCLogUtil.isDebugEnabled()){
				logger.debug("KohlsPSAKohlsCashDeactivation.deactivateKohlsCash dRefundAmount="+dRefundAmount);
				}
				Element eleMaximizeRefundRes = XMLUtil.getChildElement(eleDeactivationOptions, "MaximizeRefund");
				if (!YFCCommon.isVoid(eleMaximizeRefundRes)) {
					if(YFCLogUtil.isDebugEnabled()){
					logger.debug("KohlsPSAKohlsCashDeactivation.deactivateKohlsCash eleMaximizeRefundRes="+XMLUtil.getElementXMLString(eleMaximizeRefundRes));
					}
					Element eleMRKohlsCashReduction = XMLUtil.getChildElement(eleMaximizeRefundRes, "KohlsCashReduction");
					if (!YFCCommon.isVoid(eleMRKohlsCashReduction)) {
						String strMRKohlsCashReduction = XMLUtil.getNodeValue(eleMRKohlsCashReduction);
						if(YFCLogUtil.isDebugEnabled()){
						logger.debug("KohlsPSAKohlsCashDeactivation.deactivateKohlsCash strMRKohlsCashReduction="+strMRKohlsCashReduction);
						}
						eleMaximizeRefund.setAttribute("UnearnedKohlsCash",strMRKohlsCashReduction);
					}
				}
				Element eleMRRefundDeduction = XMLUtil.getChildElement(
				    eleMaximizeRefundRes, "RefundDeduction");
            if (!YFCCommon.isVoid(eleMRRefundDeduction)) {
                String strMRRefundDeduction = XMLUtil
                        .getNodeValue(eleMRRefundDeduction);
                dMRRefundDeduction = Double
                        .parseDouble(strMRRefundDeduction);
                Element eleMaxRefundPro = XMLUtil.createChild(elePromotion,
                    "MaximizeRefund");
                //Skip calling TVS for V2 - callingSource - V2Unearn
                if (dMRRefundDeduction > 0.0 && YFCCommon.isVoid(callingSource)) {
                    firstTVSResponseForMRDoc = firstTVSObj
                            .prepareRequestForFirstTVSCall(env,
                                    kcsResponseDoc, tempOrderEle,
                                    eleMRRefundDeduction);
                    bErrorsInTVS = checkForTVSResponseErrors(firstTVSResponseForMRDoc);
                    if (bErrorsInTVS) {
                        logger.debug("Errors in First TVS response, Please proceed with tendering!!");
                        OrderElement.setAttribute(
                                KohlsXMLLiterals.A_ERR_DESC,
                                "Errors in First TVS Response");
                        return kcsOutputDoc;
                    }
                    secondTVSResponseForMRDoc = secondTVSObj
                            .prepareRequestForSecondTVSCall(env,
                                    firstTVSResponseForMRDoc,
                                    tempOrderEle);
                    bErrorsInTVS = checkForTVSResponseErrors(secondTVSResponseForMRDoc);
                    addRefundDeductionCharges(env,
                            firstTVSResponseForMRDoc, outDoc,elePromotion ,"MaximizeRefund",
                            tempOrderEle);
                    if (bErrorsInTVS) {
                        logger.debug("Errors in Second TVS response, Please proceed with tendering!!");
                        OrderElement.setAttribute(
                                KohlsXMLLiterals.A_ERR_DESC,
                                "Errors in Second TVS Response");
                        return kcsOutputDoc;
                    }
                    dMaxRefRefundReduction = Double
                            .parseDouble(strOriginalTotalAmount)
                            - calculateTempOrderPrice(secondTVSResponseForMRDoc);
                    Double finalRefundForMaxRefund = dRefundAmount
                            - dMaxRefRefundReduction;
                    finalRefundForMaxRefund = Double.valueOf(df
                            .format(finalRefundForMaxRefund));
                    eleMaximizeRefund.setAttribute("RefundAmount",
                            df.format(finalRefundForMaxRefund));
                    eleRefundOptions.appendChild(eleMaximizeRefund);
                    //CPE-3766 changes
                    eleMaxRefundPro.setAttribute("RefundAmount",
                            df.format(finalRefundForMaxRefund));
                } else {
                    dRefundAmount = Double.valueOf(df
                            .format(dRefundAmount));
                    eleMaximizeRefund.setAttribute("RefundAmount",
                            df.format(dRefundAmount));
                    eleRefundOptions.appendChild(eleMaximizeRefund);
                    //CPE-3766 changes
                    eleMaxRefundPro.setAttribute("RefundAmount",
                            df.format(dRefundAmount));
                }
                eleMaximizeRefund.setAttribute("RefundDeduction", df.format(dMRRefundDeduction)); 
            }
				//Fix for #3598 - POC Returns Team - End
				
				eleRefundOptions.appendChild(eleMaximizeRefund);
			}
			
			//CPE-3766
			eleRefundOptions.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, strSellerOrganizationCode);
			eleRefundOptions.setAttribute(KohlsXMLLiterals.A_TERMINAL_ID, strTerminalID);
			eleRefundOptions.setAttribute(KohlsXMLLiterals.A_POS_SEQ_NO, strPosSequenceNo);
			
			logger.debug("Prorated document here #######"+XMLUtil.getXMLString(outDoc));
			
			logger.debug("Output of method deactivateKohlsCash :$:"
					+ XMLUtil.getXMLString(outputDoc));
			
			if (!bDisplayUIPrompt) {
				//Changes for PLYT-1406 
				// call change changes needed for coupon source code
				
				// changes for PLYT-1401
				outputDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_DISPLAY_PSA_KC_PROMPT, KohlsConstants.NO);
			}
			return outputDoc;
		}

	}

	/**
	 * @param secondTVSResponseDoc
	 * @throws NumberFormatException
	 */
	public Double calculateTempOrderPrice(Document secondTVSResponseDoc)
			throws NumberFormatException {

		logger.debug("Input to method calculateTempOrderPrice ::"
				+ XMLUtil.getXMLString(secondTVSResponseDoc));
		Double dTempOrderTotal = 0.0;
		Element eleAdjustmentResponse = secondTVSResponseDoc
				.getDocumentElement();

		List<Element> tvsItmList = XMLUtil.getElementsByTagName(
				eleAdjustmentResponse, KohlsPOCConstant.ELEM_SMALL_ITEM);

		if (tvsItmList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element item : tvsItmList) {
				String strNetPrice = item
						.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
				Element eleLineTaxes = XMLUtil.getChildElement(item,
						"LineTaxes");
				NodeList nlItemTax = eleLineTaxes
						.getElementsByTagName("LineTax");
				Double dTotalLineTax = 0.0;
				for (int i = 0; i < nlItemTax.getLength(); i++) {
					Element eleLineTax = (Element) nlItemTax.item(i);
					String strTax = eleLineTax.getAttribute("tax");
					// TVS is sending some stores tax and some stores Tax Begin
 					if(YFCCommon.isStringVoid(strTax)){
 						strTax = eleLineTax.getAttribute("Tax");
 					}
 					//TVS is sending some stores tax and some stores Tax End
					if(! YFCCommon.isStringVoid(strTax)){
						dTotalLineTax = dTotalLineTax + Double.parseDouble(strTax);
					}
					
				}
				List<Element> feeList = XMLUtil.getElementsByTagName(item, KohlsPOCConstant.SMALL_ATTR_FEES);
                double dTotalFee = 0.00;
                for (Element fees : feeList) {
                  String calculatedAmount = fees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
                  String rateFee = fees.getAttribute(KohlsPOCConstant.SMALL_ATTR_RATE_FEE);
                  if(!YFCCommon.isVoid(calculatedAmount) && !YFCCommon.isVoid(rateFee) 
                      && Double.parseDouble(rateFee) > 0) {
                    dTotalFee = dTotalFee + Double.parseDouble(calculatedAmount);
                  }
                }
				dTempOrderTotal = dTempOrderTotal
						+ Double.parseDouble(strNetPrice) + dTotalLineTax + dTotalFee;
				this.dLineTax=dTotalLineTax;
			}
		}
		logger.debug("Second TVS response,Temp OrderTotal" + dTempOrderTotal);
		return dTempOrderTotal;
	}

	/**
	 * @param secondTVSResponseDoc
	 * @throws NumberFormatException
	 */
	public Double calculateSalesOrderTotal(Element tempOrderEle,
			Double dRefundAmount) throws NumberFormatException {

		Double dTotalAmount = 0.0;

		Element elePriceInfo = XMLUtil.getChildElement(tempOrderEle,
				KohlsXMLLiterals.E_PRICE_INFO);
		if (!YFCCommon.isVoid(elePriceInfo)) {
			String strTotalAmount = elePriceInfo
					.getAttribute(KohlsXMLLiterals.A_TOTAL_AMOUNT);
			if (!YFCCommon.isVoid(strTotalAmount)) {
				dTotalAmount = Double.parseDouble(strTotalAmount);
			}
		}
		Double dSalesOrderTotal = dRefundAmount + dTotalAmount;
		logger.debug("PSA Sales OrderTotal ::" + dSalesOrderTotal);
		return dSalesOrderTotal;
	}

	/**
	 * @param tvsResponseDoc
	 * @throws YFSException
	 */
	public boolean checkForTVSResponseErrors(Document tvsResponseDoc)
			throws YFSException {

		logger.debug("Input to method checkForTVSResponseErrors"
				+ XMLUtil.getXMLString(tvsResponseDoc));

		Boolean bIsError = false;
		Element tvsResponseEle = tvsResponseDoc.getDocumentElement();
		// Checking for SOAP fault
		if (tvsResponseEle.getTagName().equalsIgnoreCase("Errors")) {
			bIsError = true;
			YFSException yfsException = new YFSException();
			String errorCodeStr = XMLUtil.getChildElement(tvsResponseEle,
					"Error").getAttribute("ErrorCode");
			String errorDesc = XMLUtil.getChildElement(tvsResponseEle, "Error")
					.getAttribute("ErrorDescription");

			if (KohlsPOCConstant.PROMPT_FOR_PRICE
					.equalsIgnoreCase(errorCodeStr)) {
				yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
				yfsException.setErrorDescription(errorDesc);
			} else if (KohlsPOCConstant.OFFER_END_DATE_PASSED
					.equalsIgnoreCase(errorCodeStr)) {
				yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
				if (!YFCCommon.isStringVoid(KOHLSResourceUtil
						.getPropertyValue(KohlsPOCConstant.PLUMGROVRID))) {
					yfsException.setErrorDescription(KOHLSResourceUtil
							.getPropertyValue(KohlsPOCConstant.PLUMGROVRID));
				}
			} else {
				yfsException.setErrorCode(errorCodeStr);
				yfsException.setErrorDescription(errorDesc);
			}
			if (!"OFFER_END_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
				yfsException.setErrorDescription(errorDesc);
			}
			throw yfsException;
		}
		return bIsError;
	}

	/**
	 * 
	 * @param outDocKohlsCashWebService
	 * @param OrderElement
	 * @return
	 * @throws ParserConfigurationException
	 */
	public boolean validateKohlsCashResponseErrors(
			Document outDocKohlsCashWebService, boolean omsKCEnabled)
			throws ParserConfigurationException {

		// If there is any error in KCS Response, Set the boolean true
		Element eleKCSResponse = outDocKohlsCashWebService.getDocumentElement();
		if (KohlsConstant.E_ERRORS.equalsIgnoreCase(eleKCSResponse
				.getNodeName())) {
			logger.debug("validateKohlsCashResponseErrors : Error " + eleKCSResponse.getNodeName());
			return true;
		}

		Document kcsOutputDoc = XMLUtil.createDocument("Errors");
		Element errorsElement = kcsOutputDoc.getDocumentElement();

		Element dataElement;
		try {
			if(omsKCEnabled) {
				dataElement = KohlsXPathUtil
						.getElementByXpath(
								outDocKohlsCashWebService,
								"DetermineKohlsCashDeactivationResponseMsg/Data");
			}
			else {
				dataElement = KohlsXPathUtil
						.getElementByXpath(
								outDocKohlsCashWebService,
								"DetermineKohlsCashDeactivationResponse/DetermineKohlsCashDeactivationResult/DetermineKohlsCashDeactivationResponseMsg/Data");
			}
			
			String unEarnedKCSValue = "";
			String authResponseCode = "";
			String redemptionPeriod = "";
			Element unEarnedEle = XMLUtil.getChildElement(dataElement,
					"UnearnedValue");
			if (!YFCCommon.isVoid(unEarnedEle)) {
				unEarnedKCSValue = XMLUtil.getNodeValue(unEarnedEle);
			}

			Element authResponseCodeEle = XMLUtil.getChildElement(dataElement,
					"AuthResponseCode");
			if (!YFCCommon.isVoid(authResponseCodeEle)) {
				authResponseCode = XMLUtil.getNodeValue(authResponseCodeEle);
			}

			Element redemptionPeriodEle = XMLUtil.getChildElement(dataElement,
					"RedemptionPeriod");
			if (!YFCCommon.isVoid(redemptionPeriodEle)) {
				redemptionPeriod = XMLUtil.getNodeValue(redemptionPeriodEle);
			}

			Element DeactivationOptEle = XMLUtil.getChildElement(dataElement,
					"DeactivationOptions");

			// TBD Page 76 KCS Design doc - Nothing Unearned
			if (YFCCommon.isVoid(callingSource) && (YFCCommon.isVoid(unEarnedKCSValue)
					|| (Double.parseDouble(unEarnedKCSValue) == 0 && YFCCommon
							.isVoid(DeactivationOptEle)))) {
				Element errorEle = XMLUtil.createChild(errorsElement, "Error");
				XMLUtil.setAttribute(errorEle, "Description",
						"Nothing Unearned");
				logger.debug("validateKohlsCashResponseErrors : Nothing Unearned ");
			}

			// TBD Page 77 KCS Design doc - Non-approval inquiry response
			else if (authResponseCode.equals("7")
					&& YFCCommon.isVoid(DeactivationOptEle)) {
				Element errorEle = XMLUtil.createChild(errorsElement, "Error");
				XMLUtil.setAttribute(errorEle, "Description",
						"Non-approval inquiry response");
				logger.debug("validateKohlsCashResponseErrors : Non-approval inquiry response ");
			}

			// TBD Page 78 KCS Design doc - Non-approval inquiry response
			else if (redemptionPeriod.equals("NONE")
					&& YFCCommon.isVoid(DeactivationOptEle)) {
				Element errorEle = XMLUtil.createChild(errorsElement, "Error");
				XMLUtil.setAttribute(errorEle, "Description",
						"Event ID not found");
				logger.debug("validateKohlsCashResponseErrors : Error Event ID not found  ");
			}

			List errorList = XMLUtil.getElementsByTagName(errorsElement,
					"Error");
			if (errorList.size() > 0) {
				logger.debug("validateKohlsCashResponseErrors : Error list size : " + errorList.size());
				logger.debug("validateKohlsCashResponseErrors : Error Document : " + XMLUtil.getXMLString(kcsOutputDoc));
				return true;
			}

		} catch (Exception e) {
			logger.error("Exception at KohlsBeforePSAOrderCreateUE.validateKohlsCashResponseErrors"
					+ e.getStackTrace());
		}

		return false;

	}

	/**
	 * This method is called to Update the value of UnearnedKohlsCash,KCD Coupon
	 * Number,KCD Coupon Code, KCD Coupon Event Code, KCDCPNReturn Amount in the
	 * db.
	 * 
	 * @param yfsEnv
	 * @param strUnearnedKohlsCash
	 * @param strOrderHeaderkey
	 * @throws ParserConfigurationException
	 * @throws DOMException
	 */
	public void callChangeOrder(YFSEnvironment yfsEnv, String strKohlscashId,
			Double dAmtToBeUnearned, String strRedemptionPeriod,
			Double dNetPriceTotal, String strOrderHeaderkey,Element eleOptions, boolean displayUIPrompt, String strEligibleAmt)
			throws ParserConfigurationException, DOMException {
		// Call changeOrder API to update the unearned Kohls cash
		logger.debug("callChangeOrder method");
		Document docChangeOrderInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleInputOrder = docChangeOrderInput.getDocumentElement();
		eleInputOrder.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);

		if (!YFCCommon.isVoid(strOrderHeaderkey)) {
			eleInputOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
					strOrderHeaderkey);
			eleInputOrder.setAttribute(KohlsXMLLiterals.A_ACTION,
					KohlsConstant.MODIFY);
			Element eleExtn = docChangeOrderInput
					.createElement(KohlsXMLLiterals.E_EXTN);
			Element eleMaximizeRefund = XMLUtil.getChildElement(
					eleOptions, "MaximizeRefund");
			if (!YFCCommon.isVoid(eleMaximizeRefund)){
				Element eleMRKohlsCashReduction = XMLUtil.getChildElement(
						eleMaximizeRefund, "KohlsCashReduction");
				Element eleMRRefundDeduction = XMLUtil.getChildElement(
                    eleMaximizeRefund, "RefundDeduction");
				if (!YFCCommon.isVoid(eleMRKohlsCashReduction)) {
					strMRKohlsCashReduction = XMLUtil
							.getNodeValue(eleMRKohlsCashReduction);
					eleExtn.setAttribute("ExtnKohlsCashDeactivated",
							strMRKohlsCashReduction);
					eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_REFUND_AMOUNT, XMLUtil.getNodeValue(eleMRRefundDeduction));
					}
				}	
			eleInputOrder.appendChild(eleExtn);
			// Added For PSA Data Collect- START
			eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_NUMBER,
					strKohlscashId);
			if (dAmtToBeUnearned == 0.0 || !displayUIPrompt) {
				eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE,
						KohlsXMLLiterals.CONST_NO_DEACTIVATION);
			} else {
				// moving forward, only max Refund
				eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE,
						KohlsXMLLiterals.CONST_MAXIMIZE_REFUND);
			}
			if (!YFCCommon.isVoid(strRedemptionPeriod)) {
				if (strRedemptionPeriod.equals(KohlsPOCConstant.ACTIVE_CAPS)) {
					eleExtn.setAttribute(
							KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE,
							KohlsXMLLiterals.CONST_ACTIVE);
				} else if (strRedemptionPeriod
						.equals(KohlsPOCConstant.CONST_PRE_REDEMPTION)) {
					eleExtn.setAttribute(
							KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE,
							KohlsXMLLiterals.CONST_PREREDEMPTION);
				} else if (strRedemptionPeriod
						.equals(KohlsPOCConstant.CONST_POST_REDEMPTION)) {
					eleExtn.setAttribute(
							KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE,
							KohlsXMLLiterals.CONST_POSTREDEMPTION);
				}
			}

			eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_CPN_RETURN_AMOUNT,
					String.valueOf(dNetPriceTotal));
			eleExtn.setAttribute("ExtnEligibilityDeduction", strEligibleAmt);
			//Fix for PR-655-Start
			eleExtn.setAttribute("ExtnKCDReturnTenderAmount", String.valueOf(dAmtToBeUnearned));
			//Fix for PR-655-End
			// Added For PSA Data Collect- END
			
			/*MAD-646 changes start
			logger.debug("before getting endpoint ::"+ServerTypeHelper.amIOnEdgeServer());
			if(ServerTypeHelper.amIOnEdgeServer()){
				Element eleAdditionalInfo= SCXmlUtil.createChild(eleInputOrder,KohlsXMLLiterals.E_YFCADDITIONALINFO);
				if(!YFCCommon.isVoid(endpoint)){
					 eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endpoint);
				}
				
			}
			//MAD-646 changes End*/
			logger.debug("Input to callchangeOrder:"
					+ XMLUtil.getXMLString(docChangeOrderInput));
			try {
				KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.CHANGE_ORDER_API,
						docChangeOrderInput);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error("Exception in the Method distributeRefundAmount of KohlsPSATendering"
						+ e.getMessage());
			}
		}
	}

	/**
	 * This method is called to add Total Net Price for KohlsCashElegible Items
	 * 
	 * @param eleReturnableItemList
	 * @param dNetPriceTotal
	 * @return
	 * @throws NumberFormatException
	 * @throws TransformerException
	 * @throws ParserConfigurationException
	 */
	public Double calculateNetPrice(Element eleReturnableItemList,
			Double dNetPriceTotal) throws NumberFormatException,
			TransformerException, ParserConfigurationException {
		List<Element> returnableItemList = XMLUtil.getElementsByTagName(
				eleReturnableItemList, KohlsXMLLiterals.E_RETURNABLE_ITEM);
		if (returnableItemList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element returnableItem : returnableItemList) {

				Element eleNetPrice = XMLUtil.getChildElement(returnableItem,
						KohlsPOCConstant.A_NET_PRICE);
				Element eleKohlsCashEligible = XMLUtil.getChildElement(
						returnableItem, KohlsXMLLiterals.E_KOHLS_CASH_ELIGIBLE);
				String strNetPrice = XMLUtil.getNodeValue(eleNetPrice);
				String strKohlsCashEligible = XMLUtil
						.getNodeValue(eleKohlsCashEligible);
				if (!YFCCommon.isVoid(strNetPrice)) {
					if (strKohlsCashEligible
							.equals(KohlsXMLLiterals.CONST_TRUE)) {
						dNetPriceTotal = dNetPriceTotal
								+ Double.parseDouble(strNetPrice);
					}
				}

			}
		}
		logger.debug("calculateNetPrice: TotalNetPrice:" + dNetPriceTotal);
		return dNetPriceTotal;

	}
	
	/*public Document callTVSAndUpdateDoc(YFSEnvironment env,Element eleMKCRefundDeduction,
			Document firstTVSResponseForMKCDoc,Document secondTVSResponseForMKCDoc,
			boolean bErrorsInTVS,Element OrderElement,Document kcsOutputDoc,
			Document kcsResponseDoc,Element tempOrderEle){
		try{
			firstTVSResponseForMKCDoc = firstTVSObj
					.prepareRequestForFirstTVSCall(env,
							kcsResponseDoc, tempOrderEle,
							eleMKCRefundDeduction);
			bErrorsInTVS = checkForTVSResponseErrors(firstTVSResponseForMKCDoc);
			if (bErrorsInTVS) {
				logger.debug("Errors in First TVS response, Please proceed with tendering!!");
				OrderElement.setAttribute(
						KohlsXMLLiterals.A_ERR_DESC,
						"Errors in First TVS Response");
				return kcsOutputDoc;
			}
			secondTVSResponseForMKCDoc = secondTVSObj
					.prepareRequestForSecondTVSCall(env,
							firstTVSResponseForMKCDoc,
							tempOrderEle);
			bErrorsInTVS = checkForTVSResponseErrors(secondTVSResponseForMKCDoc);
			if (bErrorsInTVS) {
				logger.debug("Errors in Second TVS response, Please proceed with tendering!!");
				OrderElement.setAttribute(
						KohlsXMLLiterals.A_ERR_DESC,
						"Errors in Second TVS Response");
				return kcsOutputDoc;
			}
			}catch(Exception e) {
				// TODO Auto-generated catch block
				logger.error("Exception in the Method callTVSAndUpdateDoc of KohlsPSAKohlsCashDeactivation"
						+ e.getMessage());
			}
			return secondTVSResponseForMKCDoc;
			
		}*/
	
	/**
	 * @param eleProRatedOrderLines
	 * @param sEligibleAmount
	 */
	public void createAwardElement(Element eleProRatedOrderLines,String sEligibleAmount){

	  Element eleAwards =
	      XMLUtil.getChildElement(eleProRatedOrderLines, KohlsXMLLiterals.E_AWARDS);
	  if (YFCCommon.isVoid(eleAwards)) {
	    eleAwards =  XMLUtil.createChild(eleProRatedOrderLines, KohlsXMLLiterals.E_AWARDS);
	  }
	  Element eleAward = XMLUtil.createChild(eleAwards, KohlsXMLLiterals.E_AWARD);
	  Element eleAwardExtn = XMLUtil.createChild(eleAward, KohlsXMLLiterals.E_EXTN);
	  Document docSalesHubData = null;
	  Element eleData = null;

	  try {
	    docSalesHubData = XMLUtil.createDocument("Data");
	    eleData = docSalesHubData.getDocumentElement();
	    eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MAX_REFUND);
	    eleData.setAttribute(KohlsPOCConstant.A_PRECEDENCE, KohlsPOCConstant.THIRTY_SIX);
	    eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT,sEligibleAmount);

	    eleAwardExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_DELTA,sEligibleAmount);


	    eleAward.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, KohlsPOCConstant.MAX_REFUND);
	    eleAward.setAttribute(KohlsPOCConstant.ATTR_DESCRIPTION, KohlsPOCConstant.MAX_REFUND);
	    eleAward.setAttribute(KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
	    eleAward.setAttribute(KohlsPOCConstant.A_AWARD_AMOUNT, sEligibleAmount);

	    eleAwardExtn.setAttribute("ExtnSalesHubData",
	        XMLUtil.getXMLString(docSalesHubData));

	  } catch (Exception e) {
	    // TODO Auto-generated catch block
	    logger.error("Exception in the Method createAwardElement of KohlsPSAKohlsCashDeactivation"
	        + e.getMessage());
	  }


	}
	
	/**
	 * @param env
	 * @param tvsResponse
	 * @param outDoc
	 * @param elePromotion
	 * @param sKCOption
	 * @param tempOrderEle
	 * @throws Exception
	 */
	public void addRefundDeductionCharges(YFSEnvironment env,Document tvsResponse, Document outDoc,
		      Element elePromotion, String sKCOption, Element tempOrderEle)
		          throws Exception {
	  logger.debug("KohlsPSAKohlsCashDeactivation.addRefundDeductionCharges");

	  logger.debug("tempOrderEle :: "+XMLUtil.getElementXMLString(tempOrderEle));
	  DecimalFormat df = new DecimalFormat("0.00");
	  // dRefundAmount = this.dRefundAmount_Temp;

	  Double dLineTax = 0.00;
	  Double dNetPrice = 0.00;
	  Double dTempOrderTotal = 0.0;
	  Double dTempOrderTotalWithoutTax = 0.0;
	  Element orderEle = outDoc.getDocumentElement();

	  Element eleOrderExtn = XMLUtil.getChildElement(orderEle, KohlsXMLLiterals.E_EXTN, true);

	  eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_DEACTIVATED, strAmtToBeUnearned); 

	  Element eleProRatedLines = XMLUtil.getChildElement(orderEle, "ProRatedLines", true);
	  Element eleOrderLines = XMLUtil.createChild(eleProRatedLines, KohlsXMLLiterals.E_ORDER_LINES);

	  NodeList nlOrigLine = tempOrderEle.getElementsByTagName("OrderLine");
	  eleOrderLines.setAttribute("OrderLinesForKCOption", sKCOption);
	  // eleOrderLines.setAttribute("OrderLinesForPromotion", sUnprocessedExtnCouponSourceCode);
	  Element tvsResEle = tvsResponse.getDocumentElement();
	  NodeList itemsNL = tvsResEle.getElementsByTagName("item");

	  if (itemsNL.getLength() > 0) {
	    for (int i = 0; i < itemsNL.getLength(); i++) {
	      Element tempItemEle = (Element) itemsNL.item(i);
	      String sID = tempItemEle.getAttribute("id");


	      Element eleOrderLine = XMLUtil.createChild(eleOrderLines, KohlsXMLLiterals.E_ORDER_lINE);


	      logger.debug("Printing the amount KC balance ::::"+sEligibleAmount);

	      Element eleOrderLineExtn = XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_EXTN);
	      eleOrderLine.setAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO, sID);
	      eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO,
	          KohlsPOCConstant.A_SUB_LINE_NO);

	      eleOrderLine.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.MODIFY);


	      String sNetPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE);
	      String sReturnPrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_RETURN_PRICE);
	      String sProratedNetPrice = tempItemEle.getAttribute("proratedNetPriceDiscountAmt");
	      String sTaxablePrice = tempItemEle.getAttribute(KohlsPOCConstant.ATTR_TAXABLE_PRICE);
	      eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, sNetPrice);
	      eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE, sReturnPrice);
	      eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, sTaxablePrice);
	      dNetPrice = Double.parseDouble(sNetPrice);
	      //dNetPrice = Double.parseDouble(sProratedNetPrice);
	      Element eleLineTaxes =
	          (Element) tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAXES).item(0);
	      NodeList lineTaxNL = tempItemEle.getElementsByTagName(KohlsXMLLiterals.E_LINE_TAX);
	      if (!YFCCommon.isVoid(lineTaxNL)) {
	        String strlineTax = ((Element) lineTaxNL.item(0)).getAttribute(KohlsXMLLiterals.A_TAX);
	        dLineTax = Double.parseDouble(strlineTax);
	        Element eleLineTaxes_Temp = (Element) outDoc.importNode(eleLineTaxes, true);
	        eleLineTaxes_Temp.setAttribute(KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
	        eleOrderLine.appendChild(eleLineTaxes_Temp);
	        NodeList nlLineTax = eleLineTaxes_Temp.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
	        if(nlLineTax.getLength()>0) {
	          Element eleLineTax = (Element) nlLineTax.item(0);
	          Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
	          if (!YFCCommon.isVoid(eleLineTaxExtn)) {
	            String strBasisAmt = eleLineTaxExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
	            if(!YFCCommon.isVoid(strBasisAmt)) {
	              eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, strBasisAmt);
	            }
	          }
	        }
	      }
	      if (mapLinePrice.containsKey(sID)) {
	        mapLinePrice.remove(sID);
	        mapLinePrice.put(sID, (dNetPrice + dLineTax));
	      }

	      NodeList nlModifier = tempItemEle.getElementsByTagName(KohlsPOCConstant.ELEM_MODIFIER);

	      if (!YFCCommon.isVoid(nlModifier) && nlModifier.getLength() > 0) {
	        logger.debug("Modifires list from TVS response ##");
	        Element eleModifier = (Element) nlModifier.item(0);
	        Element eleLineCharges =
	            XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_LINE_CHARGES);
	        sNetPriceDelta = eleModifier.getAttribute(KohlsPOCConstant.ATTR_NET_PRICE_DELTA);
	        Double dNetPriceDelta = Math.abs(Double.parseDouble(sNetPriceDelta));
	        Element eleLineCharge =
	            XMLUtil.createChild(eleLineCharges, KohlsXMLLiterals.E_LINE_CHARGE);
	        eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY,
	            KohlsPOCConstant.KC_UNEARNED);
	        eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_NAME, KohlsPOCConstant.KC_UNEARNED);
	        eleLineCharge.setAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE,
	            String.valueOf(dNetPriceDelta));
	        eleLineCharge.setAttribute(KohlsXMLLiterals.A_IS_DISCOUNT, KohlsPOCConstant.NO);

	        createAwardElement(eleOrderLine, sNetPriceDelta);
	      }
	      //Loop through original Orderlines and import Line change ( Fee to prorateLines element)
	      for(int line =0; line < nlOrigLine.getLength();line++){
	    	  Element eleOrigLine = (Element)nlOrigLine.item(line);
	    	  //Match Line 
	    	  if(sID.equalsIgnoreCase(eleOrigLine.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO))){

	    		  NodeList nlLineCharge = eleOrigLine.getElementsByTagName(KohlsXMLLiterals.E_LINE_CHARGE);
	    		  for(int linechrg =0; linechrg < nlLineCharge.getLength();linechrg++){
	    			  Element eleLineCharge = (Element)nlLineCharge.item(linechrg);
	    			  //Match Fee to import and update later
	    			  if(eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY).contains(KohlsPOCConstant.SMALL_ATTR_FEE)){
	    				  Element eleImpLineCharge = (Element)eleOrderLine.getOwnerDocument().importNode(eleLineCharge, true);
	    				  Element eleLineCharges = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_LINE_CHARGES);
	    				  eleLineCharges.appendChild(eleImpLineCharge);
	    			  }
	    		  }
	    	  }
	      }
	      KohlsPoCPnPUtil.updateKCDTaxFee(eleOrderLine,tempItemEle,KohlsPOCConstant.ATTR_PSA,KohlsPOCConstant.BLANK);
	    }
	  }

	  elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE,
	      KohlsPOCConstant.KOHLS_CASH);
	  elePromotion.setAttribute(KohlsPOCConstant.PROMOTIONID,
	      KohlsPOCConstant.KC_MAXIMIZE);
	  elePromotion.setAttribute(KohlsPOCConstant.PROMO_APPLIED,
	      KohlsPOCConstant.YES); 
	  elePromotion.setAttribute(KohlsPOCConstant.A_TYPE_REQUEST,
	      KohlsPOCConstant.SALE);
	  elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
	      sEligibleAmount);
	  elePromotion.setAttribute("PromotionGroup",
	      KohlsPOCConstant.COUPON);
	  elePromotion.setAttribute(KohlsPOCConstant.REFUND_AMT,
	      new DecimalFormat("#0.00").format(dTempOrderTotal));
	  elePromotion.setAttribute("RefundAmountWithoutTax",
	      new DecimalFormat("#0.00").format(dTempOrderTotalWithoutTax));

	  logger.debug("KohlsPSAKohlsCashDeactivation.addRefundDeductionCharges ::"+XMLUtil.getXMLString(outDoc));

	  UpdatePSAKCDataForKohlsSalesForPSA(env,outDoc);
	  logger.endTimer("KohlsPSAKohlsCashDeactivation.addRefundDeductionCharges");
	}
	
	/**
	 * @param env
	 * @param PSAKCDataDoc
	 */
	public void UpdatePSAKCDataForKohlsSalesForPSA(YFSEnvironment env, Document PSAKCDataDoc) {
	  logger.beginTimer("KohlsPSAKohlsCashDeactivation.UpdatePSAKCDataForKohlsSalesForPSA");
	  try {

	    Element elePSAOrder = (Element) XPathUtil.getNode(PSAKCDataDoc,"/Order");
	    String strOHkey = elePSAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
	    String PSAKCDataXML = XMLUtil.getXMLString(PSAKCDataDoc);
	    Document docInputForPSAData = YFCDocument.createDocument(
	        KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
	    Element eleInputForPSAData = docInputForPSAData
	        .getDocumentElement();
	    eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
	    eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_PSA_KC_DATA, PSAKCDataXML);

	    //ISS change - start
	    if (ServerTypeHelper.amIOnEdgeServer()) {
	      String sEndpoint = "";
	      if (!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
	        sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
	      }
	      if (!YFCCommon.isVoid(sEndpoint)) {
	        Element eleAdditionalInfo =
	            SCXmlUtil.createChild(eleInputForPSAData, KohlsXMLLiterals.E_YFCADDITIONALINFO);
	        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
	      }
	    }
	    //ISS change - end

	    if(logger.isDebugEnabled()) {
	      logger.debug("Input to KohlsManageSaleForPSA is: "+XMLUtil.getXMLString(docInputForPSAData) );
	    }
	    KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docInputForPSAData);

	  } catch (Exception e) {

	    logger.error("Exception in the Method UpdatePSAKCDataForKohlsSalesForPSA of KohlsPSAKohlsCashDeactivation"
	        + e.getMessage());

	  }
	  logger.endTimer("KohlsPSAKohlsCashDeactivation.UpdatePSAKCDataForKohlsSalesForPSA");
	}
	
	
	/**
	 * @param eleOrder
	 * @return
	 */
	public double getAssociateDiscount (Element eleOrder){
	  logger.beginTimer("KohlsPSAKohlsCashDeactivation.getAssociateDiscount");
	  Element elePromotions = (Element) eleOrder.getElementsByTagName("Promotions").item(0) ;
	  NodeList ndlPromotions = elePromotions.getElementsByTagName("Promotion");
	  double total=0.0;
	  String sAssocDisPercentage ="";
	  double dAssocDiscount=0.0;
	  for(int i=0;i<ndlPromotions.getLength();i++){

	    Element elePromotion =(Element)ndlPromotions.item(i);
	    Element eleExtn = (Element)elePromotion.getElementsByTagName("Extn").item(0);
	    if(!YFCCommon.isVoid(eleExtn))
	    {
	      if(eleExtn.getAttribute("ExtnIsPsaPromotion").equalsIgnoreCase("Y")){

	        total=total+Math.abs(Double.parseDouble(elePromotion.getAttribute("OverrideAdjustmentValue")));
	      }
	    }
	    if(!YFCCommon.isVoid(elePromotion))
	    {
	      if(elePromotion.getAttribute("PromotionType").equals("ASSOCIATE_DISCOUNT")){
	        sAssocDisPercentage = eleExtn.getAttribute("ExtnDiscountPercent");
	        logger.debug("getAssociateDiscount: sAssocDisPercentage:" + sAssocDisPercentage);

	      }
	    }
	  }

	  if(!YFCCommon.isVoid(sAssocDisPercentage))
	  {
	    dAssocDiscount=(total*Double.parseDouble(sAssocDisPercentage))/100;

	  }
	  logger.debug("getAssociateDiscount: dAssocDiscount:" + dAssocDiscount);
	  logger.endTimer("KohlsPSAKohlsCashDeactivation.getAssociateDiscount");
	  return dAssocDiscount;
	}

	

}
