package com.kohls.poc.psa.api;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.returns.api.KohlsReturnRefund;
import com.kohls.poc.util.KohlsPoCPinPadOperations;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.ycp.core.YCPContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

/**
 * @author POC Returns Team
 * 
 * Sample Input XML
 * <Order OrderHeaderKey="2016030919240426551" BusinessDay="2016-06-29" OperatorID="2104795" TerminalID="41" TillID="1">
 * <PaymentMethods>
 * <PaymentMethod PaymentType="KOHLS_CASH" Amount="20" />
 * <PaymentMethod PaymentType="CASH" Amount="30"/>
 * <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="VISA" CreditCardNo="1245260120" Amount="20"/>
 * <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="MASTERCARD" CreditCardNo="8464196593" Amount="5"/>
 * <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="DISCOVER" CreditCardNo="7849216326" Amount="10"/>
 * <PaymentMethod PaymentType="CREDIT_CARD" CreditCardType="AMEX" CreditCardNo="4145936225" Amount="5"/>
 * <PaymentMethod PaymentType="KOHLS_CHARGE_CARD" Amount="15"/>
 * <PaymentMethod PaymentType="KMC" Amount="10" ConvertedFromCash="N" ConvertedFromCC="Y" 
 * ConvertedFromKohlsCharge="N" CreditCardType="VISA" SVCNo="" entryMethod="" storeNumber=""/>
 * <PaymentMethod Amount="10" PaymentType="CORPORATE_REFUND" FirstName="" LastName="" StreetAddress="" City="" 
 * State="" ZipCode="" DriversLicense="" PhoneNo="" Reason="" EMailID="" LoyalityCardNo=""/>
 * </PaymentMethods>
 * </Order>
 *
 */
/**************************************************************************
 * File : KohlsPSARefund.java Author : POC Returns Team 
 ***************************************************************************** 
 * This Class is handles All Tender Refunds with respect to Post Sale 
 * Adjustment scenarios
 ***************************************************************************** 
 * 
 *****************************************************************************/

public class KohlsPSARefund {

		private static YFCLogCategory logger;
		private String strOrdHeadKey=KohlsPOCConstant.BLANK;
		private String strKMCEntryMethod=KohlsPOCConstant.BLANK;
		private Document docGetPayOutClone=null;
		private Document docInXMLClone=null;
		private Document docOutputClone=null;
		private List<String> liPayKey= new ArrayList<String>();
		private boolean bIsCorpRefund=false;
		private boolean bIsKMCError=false;
		//CPE-5903 - Start
		private String sOrderNo = "";
		private double timeTaken = 0.00;
		KohlsReturnRefund objKRR = new KohlsReturnRefund();
		//CPE-5903 - End
		private boolean bIsDebugEnabled=YFCLogUtil.isDebugEnabled();
		//MAD-287 Start
		private String endpoint = null;
		//MAD-287 End
		//PR-992 - Start
		String strCurrentPSATranNo = null;
		//PR-992 - End
		private Map<String,String> mPSAId=new HashMap<String, String>();
		static {
			logger = YFCLogCategory.instance(KohlsPSARefund.class.getName());
		}

		
	/**
	 * This Method is called by Gravity as a parameter to 
	 * the OMS Service KohlsPSARefund.
	 * 
	 * Acts as a major and sole Driver for PSA Tender Refund Scenarios
	 * 
	 * inXML: Input From Gravity 
	 * UI Trigger Point: On Confirmation of Tender Prompt Screen
	 * 
	 * @param env
	 * @param inXML 
	 * @throws Exception 
	 */
	public Document setFinalPSARefundTypes(YFSEnvironment env, Document inXML) throws Exception
		{
		long lStartTime=System.nanoTime();
		
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setFinalPSARefundTypes -- Start");
			logger.debug("KohlsPSARefund.setFinalPSARefundTypes lStartTime="+lStartTime);
			logger.debug("KohlsPSARefund.setFinalPSARefundTypes InputDocument:" + XMLUtil.getXMLString(inXML));
		}
		Document docOutput = null;
		try{
		  // Sort Payment method to process KMC first and then Credit/KCC and then Cash tenders
		 KohlsReturnRefund.sortPaymentMethod(inXML);
		//Save the Document Object received from Gravity as a global DOM document object for further use
		docInXMLClone=inXML;
		//Save the OrderHeaderkey as a global variable to be used as a parameter for rest of the functions
		strOrdHeadKey=getOHKey(inXML);
		if(!YFCCommon.isStringVoid(strOrdHeadKey)){
			if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.setFinalPSARefundTypes strOrdHeadKey="+strOrdHeadKey);
			}
		//Input to call PSAGetOrderList OMS Service is prepared 
		Document docPSAGetOrderInput=inputToPSAGetOrderList(strOrdHeadKey, inXML);
		//PSAGetOrderList OMS Service is called
		docOutput=callPSAGetOrderListAPI(env,docPSAGetOrderInput);
		if(!YFCCommon.isVoid(docOutput)){
			//MAD-287 changes Start
			Element eleOrder = docOutput.getDocumentElement();
			Element eleAddtionalInfo = SCXmlUtil.getXpathElement(eleOrder, "/OrderList/Order/yfcAdditionalInfo");
			if(!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()){
				 endpoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
			}
			//MAD-287 changes End
			//Save the Document Object received as output from Service as a global DOM document object for further use
			docOutputClone=docOutput;
			//CPE-5903 - Start
			sOrderNo = ((Element) docOutputClone.getElementsByTagName("Order").item(0))
		              .getAttribute("OrderNo");
			//CPE-5903 - End
			//PR-922 - Start
			Element elePSAOrderList = docOutputClone.getDocumentElement();
			Element elePSAOrder=XMLUtil.getChildElement(elePSAOrderList, KohlsPOCConstant.ELEM_ORDER);
			strCurrentPSATranNo = XMLUtil.getAttribute(elePSAOrder, "TransactionNo");
			//PR-992 - End
			//Input to call requestCollection api is prepared
			//Can be removed as it is same as that of inputToPSAGetOrderList().
		Document docReqCollInput=inputToRequestCollection(strOrdHeadKey);
		//requestCollection api is called
		Document docReqCollOut=callRequestCollectionAPI(env,docReqCollInput);
		//Whether requestCollection is a success or not is checked
		if((!YFCCommon.isVoid(docReqCollOut)) && (docReqCollOut.getDocumentElement().getNodeName().equalsIgnoreCase(KohlsPOCConstant.ELEM_ORDER))){
			//Input to call getChargeTransactionList api is prepared
			Document docCharTransInput=inputToGetChargeTransactionList(strOrdHeadKey);
			//getChargeTransactionList api is called
			Document docCharTransOutput=callGetChargeTransactionListAPI(env,docCharTransInput);
			//A list of ChargeTransactionKey(s) is prepared from the output of getChargeTransactionList api
			List<String> chargeTrnsactionKeys= getChargeTransactionKeys(docCharTransOutput);
			//Input to voidChargeTransaction api is prepared
			Document docVoidChargTransInput=voidChargeTransactioninDoc(chargeTrnsactionKeys);
			//voidChargeTransaction api is called
			Document docVoidChargTransOutput=callvoidChargeTransaction(env,docVoidChargTransInput);
			if(!YFCCommon.isVoid(docVoidChargTransOutput)){
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setFinalPSARefundTypes docVoidChargTransOutput="+XMLUtil.getXMLString(docVoidChargTransOutput));
				}
			}
			//Input to getPaymentList is prepared
			Document docGetPayListInput=inputToGetPaymentList(strOrdHeadKey);
			//getPaymentList api is called
			Document docGetPayListOutput=callgetPaymentList(env,docGetPayListInput);
			//Save the getPaymentList api output as a global DOM document object for further use
			docGetPayOutClone=docGetPayListOutput;
			//Set PSA Ids to Map
			setPSAIdsToMap();
			//Print the Map Values
			printMapValues(mPSAId);
			//Form the generic skeleton for recordExternalCharges api  
			Document docSklRecordExternalCharges=formInputSklToRecordExternalCharges();
			//Update the tender specific attributes and call recordExternalCharges api
			Document docUpdatedInXml=formAndCallInputToRecordExternalCharges(env,docSklRecordExternalCharges,inXML);
			//Check if the output received from formAndCallInputToRecordExternalCharges contains Error xml or not
			if((!YFCCommon.isVoid(docUpdatedInXml)) && (docUpdatedInXml.getDocumentElement().getNodeName().equalsIgnoreCase(KohlsXMLLiterals.A_ERRORS))){
				//Set a global flag as true and return the Error Document to Gravity
				bIsKMCError=true;
				return docUpdatedInXml;
			}
			
			if(!YFCCommon.isVoid(docUpdatedInXml)){
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setFinalPSARefundTypes docUpdatedInXMl= "+XMLUtil.getXMLString(docUpdatedInXml)+" inXML="+XMLUtil.getXMLString(inXML));
				}
			}
			//Form the generic skeleton from capturePayment api
			Document docsklCapPayInput=skeletonInputToCapturePayment(docUpdatedInXml);
			//Update the Tender specific attributes to the skeleton
			Document docUpdateCapPayInput=updateInputToCapturePayment(docUpdatedInXml,docsklCapPayInput);
			//Update the remaining Tender specific attributes
			Document docFinalCapPayInput=updateCapWithPersonInfo(docInXMLClone,docUpdateCapPayInput);
			//Call capturePayment api
			Document docCapPayOutput=callCapturePaymentAPI(env, docFinalCapPayInput);
			
			// MAD-341 changes Start
            if (ServerTypeHelper.amIOnEdgeServer()) {
                logger.debug("capture payment invoked from InStore server   :");
                NodeList paymentMethodList = docFinalCapPayInput.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
                if (paymentMethodList.getLength() > 0) {
                    logger.debug("The orderheaderkey is  :" + strOrdHeadKey);
                    populatePsaOfflineForPsaStatus(env, strOrdHeadKey, docFinalCapPayInput.getDocumentElement(), KohlsXMLLiterals.API_CAPTURE_PAYMENT);

                }
            }
            // MAD-341 changes End
			
			//Check if the api call was a success or not by comparing the root node name
			if((!YFCCommon.isVoid(docCapPayOutput)) && (docCapPayOutput.getDocumentElement().getNodeName().equalsIgnoreCase(KohlsPOCConstant.ELEM_ORDER))){
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setFinalPSARefundTypes bIsCorpRefund="+bIsCorpRefund);
				}
				//Check if the Transaction has Corporate Refund as the Payment Type 
				if(bIsCorpRefund){
					//Prepare Input to call getCommonCodeList api
					Document docCommonCodeInput= formInputForCommonCode(docInXMLClone);
					//Call getCommonCodeList api
					Document docCommonCodeOutput=callGetCommonCodeList(env, docCommonCodeInput);
					//Prepare the input for changeOrder api 
					Document docChangeOrderInput=inputToChangeOrderCorporateRefund(docInXMLClone, docCommonCodeOutput);
					//Call changeOrder api
					Document docChangeOrderOutput=callChangeOrder(env, docChangeOrderInput);
					if(!YFCCommon.isVoid(docChangeOrderOutput)){
						if(bIsDebugEnabled){
							logger.debug("KohlsPSARefund.setFinalPSARefundTypes docChangeOrderOutput="+XMLUtil.getXMLString(docChangeOrderOutput));
						}
					}
					//Set the global variable to false for future use
					bIsCorpRefund=false;
				}

				//To be completed with Implementation Phase 7
				//Prepare Input for executeCollection api
				/* Document docExcCollInput=inputToExecuteCollection(strOrdHeadKey);
				 //Call executeCollection api
				Document docExcCollOutput= callExecuteCollectionAPI(env,docExcCollInput);
				//Call requestCollection api
				docReqCollOut=callRequestCollectionAPI(env,docReqCollInput);	*/		
			}
			else{
				//capturePayment api failure 
				if(bIsDebugEnabled){
					logger.debug("Contact System Admin (Capture Fail)");
				}
			}
		}else{
			//requestCollection api failure
			if(bIsDebugEnabled){
			logger.debug("Contact System Admin (Req Fail)");
			}
		}
		}
		}
		}catch(Exception e){
			logger.error("KohlsPSARefund.setFinalPSARefundTypes Exception="+e.getMessage());
				}
		finally{
			//Check if the KMC has error or not
			if(!bIsKMCError){
			//Prepare input for PSAGetOrderList OMS Service
			Document docPSAGetOrderInput=inputToPSAGetOrderList(strOrdHeadKey, inXML);
			//Call PSAGetOrderList OMS Service
			docOutput=callPSAGetOrderListAPI(env,docPSAGetOrderInput);
			if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.setFinalPSARefundTypes docGetOrderListOutput="+XMLUtil.getXMLString(docOutput));
			}
			//Extract Order Element from OrderList
            Element eleGetOrderOutputElement = XMLUtil.getChildElement(docOutput.getDocumentElement(),KohlsPOCConstant.ELEM_ORDER);
            //Get Document object from the Element
            docOutput=XMLUtil.getDocumentForElement(eleGetOrderOutputElement);
            long lEndTime=System.nanoTime();
            if(bIsDebugEnabled){
            	logger.debug("KohlsPSARefund.setFinalPSARefundTypes docOrderOutput="+XMLUtil.getXMLString(docOutput));
            	logger.debug("KohlsPSARefund.setFinalPSARefundTypes lEndTime"+lEndTime);
            	logger.debug("KohlsPSARefund.setFinalPSARefundTypes Time Elapsed Approx"+(lEndTime-lStartTime));
            	logger.debug("KohlsPSARefund.setFinalPSARefundTypes -- End");
            }
			return docOutput;
			}
		}
		return docOutput;
		}

	
	/**
	 * 
	 * Prints the Key and Value for 
	 * an Object of Map<String,String>
	 * 
	 * @param mKMCValues
	 */
	protected void printMapValues(Map<String, String> mKMCValues) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.printMapValues -- Start");
		}
		try{
			//If the Map is not empty proceed
			if(!mKMCValues.isEmpty()){
				//Create a set of Entries
				Set<Entry<String,String>> hashSet=mKMCValues.entrySet();
				//Iterate over the Set
				for(Entry<String,String> entry:hashSet ) {
					if(bIsDebugEnabled){
						logger.debug("KohlsPSARefund.printMapValues KMC Map Key="+entry.getKey()+" Value="+entry.getValue());
					}
				}
			}
		}catch(Exception e){
			logger.error("KohlsPSARefund.updateInputForRecordPV Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.printMapValues -- End");
		}
	}
	
	
	/**
	 * 
	 * This method 
	 * adds OperatorID, TerminalID, TillID, StoreID, 
	 * DrawerID and BusinessDay to a map to be 
	 * retrieved later
	 * 
	 */
	private void setPSAIdsToMap() {
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.setPSAIdsToMap -- Start");
			}
			Element eleOrder = docInXMLClone.getDocumentElement();
			String sBusinessDay=eleOrder.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY);
			if (!YFCCommon.isStringVoid(sBusinessDay)){
				mPSAId.put(KohlsPOCConstant.ATTR_BUSINESS_DAY, sBusinessDay);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setPSAIdsToMap sBusinessDay="+sBusinessDay);
				}
			}
			String sOperatorID=eleOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID);
			if (!YFCCommon.isStringVoid(sOperatorID)){
				mPSAId.put(KohlsPOCConstant.A_OPERATOR_ID, sOperatorID);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setPSAIdsToMap sOperatorID="+sOperatorID);
				}
			}
			String sTerminalID=eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
			if (!YFCCommon.isStringVoid(sTerminalID)){
				mPSAId.put(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setPSAIdsToMap sTerminalID="+sTerminalID);
				}
			}
			String sTillID=eleOrder.getAttribute(KohlsPOCConstant.ATTR_TILL_ID);
			if(!YFCCommon.isStringVoid(sTillID)){
				mPSAId.put(KohlsPOCConstant.ATTR_TILL_ID, sTillID);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setPSAIdsToMap sTillID="+sTillID);
				}
			}
			String sStoreID=eleOrder.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
			if(!YFCCommon.isStringVoid(sStoreID)){
				mPSAId.put(KohlsPOCConstant.ATTR_STORE_ID, sStoreID);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setPSAIdsToMap sStoreID="+sStoreID);
				}
			}
			String sDrawerID=eleOrder.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID);
			if(!YFCCommon.isStringVoid(sDrawerID)){
				mPSAId.put(KohlsPOCConstant.ATTR_DRAWER_ID, sDrawerID);
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.setPSAIdsToMap sDrawerID="+sDrawerID);
				}
			}
		}catch(Exception e){
			logger.error("KohlsPSARefund.setPSAId Exception"+e.getMessage());
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setPSAIdsToMap -- End");
		}
	}

	/**
	 * This is a major controller function for 
	 * preparing input for recordExternalCharges api 
	 * 
	 * @param env
	 * @param docSklRecordExternalCharges
	 * @param inXML
	 * @return
	 */
	private Document formAndCallInputToRecordExternalCharges(
			YFSEnvironment env, Document docSklRecordExternalCharges, Document inXML) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges -- Start");
		}
		try{
			if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docSklRecord="+XMLUtil.getXMLString(docSklRecordExternalCharges)+" inXML="+XMLUtil.getXMLString(inXML));
			}
		//Get the PaymentMethod(s) from the Gravity Input
		//CPE-5903 - Start
		Document docCloneSklRecordExternalCharges = null;
		Document docpinpadResponse = null;
		//CPE-5903 - End
		Element eleInXML= inXML.getDocumentElement();
		Element elePaymentMethods=SCXmlUtil.getXpathElement(eleInXML,KohlsXMLLiterals.E_PAYMENT_METHODS);
		if(!YFCCommon.isVoid(elePaymentMethods)){
		NodeList ndlPayMeth = XPathUtil.getNodeList(inXML,KohlsXMLLiterals.XPATH_PAY_METH);
		//Initialize a map to contain extn values for KMC
		Map <String,String> mapKMCValues = new HashMap<String, String>();
		int iPayMethSize=ndlPayMeth.getLength();
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges iPayMethSize="+iPayMethSize);
		}
		//Iterate over the NodeList of PaymentMethod(s) 
		for(int i=0;i<iPayMethSize;i++){
			//Get the Current Element
			Element eleCurrElement= (Element) ndlPayMeth.item(i);
			if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges eleCurrElement="+XMLUtil.getElementXMLString(eleCurrElement));
			}
			String sPaymentType=eleCurrElement.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
			if(!YFCCommon.isStringVoid(sPaymentType)){
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges sPaymentType="+sPaymentType);
				}
			//Check if the PaymentMethod Element is a Credit Card or KMC Or Not
			//Debit card is ignored since gravity calls RecordExternalCharges API
			boolean bIsCard=checkIfCard(sPaymentType);
			//Check if the PaymentMethod Element is a KMC
			boolean bIsKMC=((sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC))?true:false); 
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges bIsCard="+bIsCard+" bIsKMC="+bIsKMC);
			}
			//CPE-5903 - Start
			// Check if the PaymentMethod Element is a KCC
            boolean bIsKCC =
                ((sPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD)) ? true : false);
            // Check if the PaymentMethod Element is a CREDIT CARD
            boolean bIsCC =
                ((sPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD)) ? true : false);
            boolean bIsDebit = ((sPaymentType.equalsIgnoreCase("DEBIT_CARD")) ? true : false);

            if (bIsDebugEnabled) {
              logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges bIsCard="
                  + bIsCard + " bIsKMC=" + bIsKMC);
            }
			//CPE-5903 - End
			if(bIsCard){
				if(bIsKMC){
					Element eleOrderList = docOutputClone.getDocumentElement();
					Element eleOrder=XMLUtil.getChildElement(eleOrderList, KohlsPOCConstant.ELEM_ORDER);
					//Create a request for KMC to call Gift Card Gateway
					Document docKMCResponse = createPSAGCActivationRequest(env,eleCurrElement,eleOrder);
					if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docKMCResposne after request="+XMLUtil.getXMLString(docKMCResponse));
					}
					//Get a formatted response from the response of Gift Card Gateway 
					docKMCResponse = createResponseDocumentfromWS(docKMCResponse);
					if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docKMCResposne after response format="+XMLUtil.getXMLString(docKMCResponse));
					}
					//Check if the gateway had returned Error or success response 
					boolean bIfKMCError=checkForKMCError(docKMCResponse);
					boolean bIfKMCSuccess=checkForKMCSuccess(docKMCResponse);
					if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges bIfKMCError="+bIfKMCError+" bIfKMCSuccess="+bIfKMCSuccess);
					}
					//If it is an error form a error document as per Gravity requirements and return that document
					if(bIfKMCError){
					Document docError=setErrorKMCDoc(docKMCResponse);
					if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docError="+XMLUtil.getXMLString(docError));
					}
						return docError;
					}
					else if(bIfKMCSuccess){
						if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docKMCResposne before success doc set="+XMLUtil.getXMLString(docKMCResponse));
						}
					//Get the Extn attributes of KMC and set it in a map
					mapKMCValues=setSuccessKMC(docKMCResponse);
					}
					else{
						if(bIsDebugEnabled){
						//This is an IllegalState for the application
						logger.debug("KMC Response is wrong");
						}
						throw new IllegalStateException("KMC Response is wrong");
					}
				}
				//CPE-5903 - Start
				// Call to pinpad for payment type credit card and Kohls Charge Card

	              if ((bIsKCC || bIsCC || bIsDebit)) {
	                if (bIsDebugEnabled) {
	                  logger.debug("Reaching out to Pinpad");
	                }

	                docpinpadResponse = callPinPad(env, eleCurrElement);

	              }
	              docCloneSklRecordExternalCharges =
	                      (Document) docSklRecordExternalCharges.cloneNode(true);
	              
				//Update the skeleton of recordExternalCharges api input
			Document docFinalRecordExtCharInput=updatesklRecordExternalChargesWithPinpadResponse(eleCurrElement, docpinpadResponse,
					docSklRecordExternalCharges, strOrdHeadKey, docGetPayOutClone, mapKMCValues, null, env);
			//CPE-5903 - End
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docFinalRecordInput="+XMLUtil.getXMLString(docFinalRecordExtCharInput));
			}
			//Call recordExternalCharges api
			Document docFinalRecordExtCharOutput=callRecordExternalPayments(env,docFinalRecordExtCharInput);
			
			// MAD-341 changes Start
            if (ServerTypeHelper.amIOnEdgeServer()) {
				logger.debug("recordExternalCharges invoked from InStore server   :");
                NodeList paymentMethodList = docFinalRecordExtCharInput.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_DETAILS);
                if (paymentMethodList.getLength() > 0) {
                    logger.debug("The orderheaderkey is  :" + strOrdHeadKey);
                    populatePsaOfflineForPsaStatus(env, strOrdHeadKey,docFinalRecordExtCharInput.getDocumentElement(), KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES);

                }
            }
            // MAD-341 changes End
			
			if(!YFCCommon.isVoid(docFinalRecordExtCharOutput)){
				if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges docFinalRecordOut="+XMLUtil.getXMLString(docFinalRecordExtCharOutput));
			}
			}
			//Set used Elements as Y to remove Element later
			eleCurrElement.setAttribute(KohlsXMLLiterals.A_USED, KohlsXMLLiterals.CONST_Y);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges eleCurrElement end of loop="+XMLUtil.getElementXMLString(eleCurrElement));
			}
			}
		}
		}
		//Iterate over the Gravity input and remove the used elements
		for(int i=(iPayMethSize-1);i>=0;i--){
			Element eleCurrElement=(Element) ndlPayMeth.item(i);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges eleCurrElement 2nd loop="+XMLUtil.getElementXMLString(eleCurrElement));
			}
			String strIsUsed= eleCurrElement.getAttribute(KohlsXMLLiterals.A_USED);
			if((!YFCCommon.isStringVoid(strIsUsed)) && strIsUsed.equalsIgnoreCase(KohlsXMLLiterals.CONST_Y)){
				XMLUtil.removeChild(elePaymentMethods, eleCurrElement);
			}
		}
		if(bIsDebugEnabled){
			for (Iterator<String> iterator = liPayKey.iterator(); iterator
					.hasNext();) {
				String strPayKey = iterator.next();
				logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges liPayKey="+strPayKey);
			}
		logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges elePaymentMethods="+XMLUtil.getElementXMLString(elePaymentMethods));
		}
		}
	}catch(Exception e){
		logger.error("KohlsPSARefund.formAndCallInputToRecordExternalCharges Exception="+e.getMessage());
	}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges inXml="+XMLUtil.getXMLString(inXML));
		logger.debug("KohlsPSARefund.formAndCallInputToRecordExternalCharges -- End");
		}
		return inXML;
	}
	
	


	/**
	 * 
	 * This method prepares a formatted input from response received 
	 * from Gift Card Gateway
	 * 
	 * @param docGCActRequestOutput
	 * @return
	 * @throws YFCException
	 * @throws ParserConfigurationException
	 */
	private Document createResponseDocumentfromWS(Document docGCActRequestOutput)
			throws YFCException, ParserConfigurationException {

		Document docStoredValueRequest=null;
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.createResponseDocumentfromWS -- Start");
		}
		try{
			if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.createResponseDocumentfromWS docGCActRequestOutput="+XMLUtil.getXMLString(docGCActRequestOutput));
			}
		docStoredValueRequest = XMLUtil
				.createDocument(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST);
		Element eleStoredValueRequest = docStoredValueRequest
				.getDocumentElement();
		Element eleStoredValueRequestResult = docStoredValueRequest
				.createElement(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT);
		//Get attributes from the resposne and map to the new document
		XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
		Element sExtn = docStoredValueRequest.createElement(KohlsPOCConstant.A_EXTN);
		XMLUtil.appendChild(eleStoredValueRequestResult, sExtn);

		Element paymentResponse = docGCActRequestOutput.getDocumentElement();
		String sResultCode = paymentResponse.getAttribute(KohlsPOCConstant.A_APPROVAL_NUMBER);
		if (!YFCCommon.isVoid(sResultCode)) {
			if(bIsDebugEnabled){
			logger.debug("AuthCode from KMC Response::" + sResultCode);
		}
		}
		String sAuthSource = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_AUTH_SOURCE);
		String sExtnAuthSourceNode = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_NODEID);
		String sAuthResponse = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE);
		String sRemainingBalance = paymentResponse.getAttribute(KohlsXMLLiterals.ATTR_REMAINING_BALANCE);
		String sStoreId=paymentResponse.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
		if (sExtnAuthSourceNode.startsWith(KohlsXMLLiterals.ATTR_ISP)) {
			sExtn.setAttribute(KohlsXMLLiterals.ATTR_EXTN_AUTH_SOURCE_NODE, KohlsPOCConstant.ATTR_STORE);
		} else {
			sExtn.setAttribute(KohlsXMLLiterals.ATTR_EXTN_AUTH_SOURCE_NODE, KohlsXMLLiterals.ATTR_CORP);
		}
		//If the response has success codes, then map the following
		if (KohlsPOCConstant.N_PG_SUCCESS.equals(sResultCode)) {
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE, KohlsXMLLiterals.ATTR_SUCCESS);
			eleStoredValueRequestResult
					.setAttribute(KohlsPOCConstant.E_ACTION_CODE, KohlsXMLLiterals.ATTR_AUTHORIZED);
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE,sResultCode);
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID,sAuthSource);
			eleStoredValueRequestResult.setAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE,sAuthResponse);
			eleStoredValueRequestResult.setAttribute(KohlsXMLLiterals.ATTR_REMAINING_BALANCE,sRemainingBalance);
			if(!YFCCommon.isStringVoid(sStoreId)){
				logger.debug("Store Id is "+sStoreId);
				eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sStoreId);
			}
		} 
		//If the response has Error codes, then map the following
		else {
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE,KohlsXMLLiterals.ATTR_ERROR_DECLINED);
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.E_ACTION_CODE, KohlsXMLLiterals.ATTR_DECLINED);
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE,sResultCode);
			eleStoredValueRequestResult.setAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID,sAuthSource);
		}
		}
		catch(Exception e){
			logger.error("KohlsPSARefund.createResponseDocumentfromWS Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("OutPut XML of method createResponseDocumentfromWS :"
				+ XMLUtil.getXMLString(docStoredValueRequest));
		logger.debug("KohlsPSARefund.createResponseDocumentfromWS -- End");
		}
		return docStoredValueRequest;
	}
	
	
	/**
	 * 
	 * This method return the extn attributes of KMC authorization
	 * response
	 * 
	 * @param docKMCOut
	 * @return
	 */
	private Map <String,String> setSuccessKMC(Document docKMCOut) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.setSuccessKMCDoc -- Start");
		}
		Map <String,String> mapKMCValues= new HashMap<String,String>();
		try{
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setSuccessKMCDoc docKMCOut="+XMLUtil.getXMLString(docKMCOut));
			}
			Element eleStoredValueRequestResult = (Element) docKMCOut.getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
			if(!YFCCommon.isVoid(eleStoredValueRequestResult)){
			//Extract extn attributes of KMC authorization response and set it in a map
			String strAuthResponse = eleStoredValueRequestResult.getAttribute(KohlsXMLLiterals.ATTR_AUTH_RESPONSE);
			String strRemainingBalance = eleStoredValueRequestResult.getAttribute(KohlsXMLLiterals.ATTR_REMAINING_BALANCE);
			String strStoreId=eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
			String strInternalReturnMessage = eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID);
			String strAuthCode = eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setSuccessKMCDoc strAuthResponse"+strAuthResponse+" strRemainingBalance="+strRemainingBalance);
			}
			mapKMCValues.put(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE, strAuthResponse);
			mapKMCValues.put(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE, strRemainingBalance);
			if(!YFCCommon.isStringVoid(strStoreId)){
				mapKMCValues.put(KohlsPOCConstant.A_STORE_ID, strStoreId);
			}
			if(!YFCCommon.isStringVoid(strInternalReturnMessage)) {
				mapKMCValues.put(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE, strInternalReturnMessage);
			}
			if(!YFCCommon.isStringVoid(strAuthCode)) {
				mapKMCValues.put(KohlsXMLLiterals.A_AUTH_CODE, strAuthCode);
			}		
			}
		}catch(Exception e){
			logger.error("KohlsPSARefund.setSuccessKMCDoc Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.setSuccessKMCDoc -- End");
		}
		return mapKMCValues;
	}


	/**
	 * 
	 * This method shall return whether KMC authorization was a 
	 * success or not
	 * 
	 * @param docKMCOut
	 * @return
	 */
	private boolean checkForKMCSuccess(Document docKMCOut) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.checkForKMCSuccess -- Start");
		}
		Element eleStoredValueRequestResult = (Element) docKMCOut.getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
		if (!YFCCommon.isVoid(eleStoredValueRequestResult) && (eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE).equalsIgnoreCase(KohlsXMLLiterals.ATTR_SUCCESS))) {
			if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.checkForKMCSuccess Inside the if check i.e. Success");
			}
			return true;
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.checkForKMCSuccess -- End");
		}
		return false;
	}

	
	/**
	 * 
	 * This method shall form the KMC Error 
	 * document
	 * 
	 * @param docKMCOut
	 * @return
	 */
	private Document setErrorKMCDoc(Document docKMCOut) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.setErrorKMCDoc -- Start");
		}
		Document docError =null;
		try{
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setErrorKMCDoc docKMCOut="+XMLUtil.getXMLString(docKMCOut));
			}
		Element eleStoredValueRequestResult = (Element) docKMCOut.getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
		if(!YFCCommon.isVoid(eleStoredValueRequestResult)){
			//Create a new Error Document and send it back
			docError = XMLUtil.createDocument(KohlsXMLLiterals.A_ERRORS);
			Element eleErrors = docError.getDocumentElement();
			Element eleError = XMLUtil.createChild(eleErrors, KohlsPOCConstant.E_ERROR);
			eleError.setAttribute(KohlsPOCConstant.A_ERROR_CODE,eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE));
			eleError.setAttribute(KohlsXMLLiterals.ATTR_ERROR_ACTION_CODE,eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_ACTION_CODE));
			eleError.setAttribute(KohlsXMLLiterals.ATTR_ERROR_RESPONSE_CODE,eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESPONSE_CODE));
			eleError.setAttribute(KohlsXMLLiterals.ATTR_ERROR_PROCESSOR_NETWORK_ID,eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_PROCESSOR_NETWORK_ID));
			eleError.setAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION,"Card is Declined or Connect Timed Out");
		}
		if(bIsDebugEnabled){
			logger.debug("Error Document for KMC:"+ XMLUtil.getXMLString(docError));
		}
		}catch(Exception e){
			logger.error("KohlsPSARefund.setErrorKMCDoc Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.setErrorKMCDoc docError="+XMLUtil.getXMLString(docError));
		logger.debug("KohlsPSARefund.setErrorKMCDoc -- End");
		}
			return docError;
	}

	
	/**
	 * 
	 * This method checks if KMC authorization was 
	 * a failure or not
	 * 
	 * @param docKMCOut
	 * @return
	 */
	private boolean checkForKMCError(Document docKMCOut) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.checkForKMCError -- Start");
		}
		Element eleStoredValueRequestResult = (Element) docKMCOut.getElementsByTagName(KohlsXMLLiterals.ATTR_STORED_VALUE_REQUEST_RESULT).item(0);
			if ((!(YFCCommon.isVoid(eleStoredValueRequestResult)) && (eleStoredValueRequestResult.getAttribute(KohlsPOCConstant.ATTRIBUTE_RESULT_CODE).equalsIgnoreCase(KohlsXMLLiterals.ATTR_ERROR_DECLINED)))) {
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.checkForKMCError Error is the result");
				}
				return true;
			}
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.checkForKMCError -- End");
			}
			return false;
	}

	/**
	 * 
	 * This method shall check if PaymentType is
	 * a Card or not
	 * 
	 * @param sPaymentType
	 * @return
	 */
	public boolean checkIfCard(String sPaymentType) {
		if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.checkIfCard -- Start");
		}
		List <String> listArrayCard = Arrays.asList(KohlsXMLLiterals.ATTR_KMC, KohlsXMLLiterals.ATTR_CREDIT_CARD, KohlsPOCConstant.KOHL_CHARGE_CARD); 
		boolean bIsCard=false;
		bIsCard= listArrayCard.contains(sPaymentType);
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.checkIfCard bIsCard="+bIsCard);
		logger.debug("KohlsPSARefund.checkIfCard -- End");
		}
		return bIsCard;
	}


	/**
	 * 
	 * This method makes a changeOrder API call
	 * 
	 * @param env
	 * @param docChangeOrderInput
	 */
	private Document callChangeOrder(YFSEnvironment env,
			Document docChangeOrderInput) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callChangeOrder - Begin");
		}
		try {
			docChangeOrderInput=KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API,
					docChangeOrderInput);
		} catch (Exception e) {
			logger.error("Exception in the Method callChangeOrder of KohlsPSARefund"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callChangeOrder Output:"
				+ XMLUtil.getXMLString(docChangeOrderInput));
		logger.debug("KohlsPSARefund.callChangeOrder - End");
		}
		return docChangeOrderInput;
	}
	
	
	
	
	/**
	 * This method forms input for Common Code API
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	private Document formInputForCommonCode(Document inDoc) {

		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputForCommonCode - Start");
		}
		Document docInputForCommonCode = null;
		try {
			//Create an input for getCommonCodeList api from the Gravity input
			Element inDocOrder = inDoc.getDocumentElement();
			Element inDocPaymentMethod = SCXmlUtil
					.getXpathElement(inDocOrder,
							"PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
			docInputForCommonCode = XMLUtil
					.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
			Element eleCommonCode = docInputForCommonCode.getDocumentElement();
			eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
					KohlsXMLLiterals.ATTR_CORP_REASON_CODE);
			eleCommonCode.setAttribute(
					KohlsXMLLiterals.A_CODE_SHORT_DESCRIPTION,
					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_REASON));
		}

		catch (Exception e) {
			logger.error("Exception occurred in formInputForCommonCode  method:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputForCommonCode docOutput="
				+ XMLUtil.getXMLString(docInputForCommonCode));
		logger.debug("KohlsPSARefund.formInputForCommonCode -- End");
		}
		return docInputForCommonCode;

	}

	/**
	 * This method returns CodeValue with respect to 
	 * CodeDescription
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	private String getUpdatedCommonCode(Document inDoc) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getUpdatedCommonCode - Begin");
		}
		String strReasonCode = null;
		try {
			Element eleCommonCodeList = inDoc.getDocumentElement();
			Element eleCommonCode = (Element) eleCommonCodeList
					.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE).item(0);
			strReasonCode = eleCommonCode
					.getAttribute(KohlsXMLLiterals.A_CODE_VALUE);
		}
		catch (Exception e) {
			logger.error("Exception in the getUpdatedCommonCode Method:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getUpdatedCommonCode String="
				+ strReasonCode);
		}
		return strReasonCode;
	}
	
	/**
	 * This method makes a getCommonCodeList call
	 * @param env
	 * @param inDoc
	 * @return
	 */
	private Document callGetCommonCodeList (YFSEnvironment env,Document inDoc ){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callGetCommonCodeList - Begin");
		}
		try {
			//Call getCommonCodeList api
			inDoc = KOHLSBaseApi.invokeAPI(env,
					KohlsXMLLiterals.API_GET_COMMON_CODE_LIST, inDoc);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callGetCommonCodeList Output:"
					+ XMLUtil.getXMLString(inDoc));
			}
		} catch (Exception e) {
			logger.error("Exception occurred while calling getCommonCodeList API:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callGetCommonCodeList - End");
		}
		return inDoc;
		
	}
	
	
	
	/**
	 * This method forms input for the change Order for Corporate Refund
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	private Document inputToChangeOrderCorporateRefund(Document inDoc,Document docGetCommonCodeListOutput) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToChangeOrderCorporateRefund - Begin");
		logger.debug("KohlsPSARefund.inputToChangeOrderCorporateRefund inDoc="+XMLUtil.getXMLString(inDoc)+"  docGetCommonCodeListOutput="+XMLUtil.getXMLString(docGetCommonCodeListOutput));
		}
		Document docChangeOrderCorparateRefundInput = null;
		String strReasonCode=null;
		try {
			//Get CodeValue w.r.t CodeDescription
			strReasonCode=getUpdatedCommonCode(docGetCommonCodeListOutput);
			Element inDocOrder = inDoc.getDocumentElement();
			//MAD-287 -CPE 2471 Start
			//addEndpointToElement(inDocOrder);
			//MAD-287 -CPE2471 End
			Element inDocPaymentMethod = SCXmlUtil
					.getXpathElement(inDocOrder,
							"PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
			docChangeOrderCorparateRefundInput = XMLUtil
					.createDocument(KohlsXMLLiterals.E_ORDER);
			Element eleOrderChangeOrderCorparateRefundInput = docChangeOrderCorparateRefundInput
					.getDocumentElement();
			eleOrderChangeOrderCorparateRefundInput.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
			eleOrderChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, inDocOrder
							.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
			Element eleOrderExtnChangeOrderCorparateRefundInput = XMLUtil
					.createChild(eleOrderChangeOrderCorparateRefundInput,
							KohlsXMLLiterals.E_EXTN);
			String strExtnEmailAddress = inDocPaymentMethod
					.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
			if (!YFCCommon.isStringVoid(strExtnEmailAddress)){   
				eleOrderExtnChangeOrderCorparateRefundInput.setAttribute(
						KohlsXMLLiterals.A_EXTN_EMAIL_ADDRESS,
						strExtnEmailAddress);
			}
			String strLoyaltyCardNo = inDocPaymentMethod
					.getAttribute(KohlsXMLLiterals.A_LOYALITY_CARD_NO);
			if ((!YFCCommon.isStringVoid(strLoyaltyCardNo))) {  
				eleOrderExtnChangeOrderCorparateRefundInput.setAttribute(
						KohlsXMLLiterals.A_EXTN_CUSTOMER_LOYALCARD,
						strLoyaltyCardNo);
			}
			if (!YFCCommon.isStringVoid(strReasonCode)) { 
				eleOrderExtnChangeOrderCorparateRefundInput.setAttribute(
						KohlsXMLLiterals.A_EXTN_REASON_CODE, strReasonCode);
			}
			Element eleOrderPerChangeOrderCorparateRefundInput = XMLUtil
					.createChild(eleOrderChangeOrderCorparateRefundInput,
							KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_ADD_LINE_1, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS));
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_ADD_LINE_2, KohlsPOCConstant.BLANK);
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_ADD_LINE_3, KohlsPOCConstant.BLANK);
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_ADD_LINE_4, KohlsPOCConstant.BLANK);
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_CITY,
					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_CITY));
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_COUNTRY, KohlsPOCConstant.BLANK);
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_DAY_PHONE, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
			if (!YFCCommon.isStringVoid(strExtnEmailAddress)) { 
				eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
						KohlsXMLLiterals.A_EMAIL_ID, strExtnEmailAddress);
			}
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_FIRST_NAME, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_FIRST_NAME));
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_LAST_NAME, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_LAST_NAME));
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_MOBILE_PHONE, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_STATE,
					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STATE));
			eleOrderPerChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_ZIP_CODE, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
			Element eleOrderPerExtnChangeOrderCorparateRefundInput = XMLUtil
					.createChild(eleOrderPerChangeOrderCorparateRefundInput,
							KohlsXMLLiterals.E_EXTN);
			eleOrderPerExtnChangeOrderCorparateRefundInput.setAttribute(
					KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE, inDocPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
		}
		catch (Exception e) {
			logger.error("Exception occurred in inputToChangeOrderCorporateRefund method:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToChangeOrderCorporateRefund docOutput="
				+ XMLUtil.getXMLString(docChangeOrderCorparateRefundInput));
		}
		return docChangeOrderCorparateRefundInput;
	}

	
	
	/**
	 * 
	 * Updates the capturePayment api Input with Information 
	 * to be populated at PersonInfoBillTo Element 
	 * 
	 * @param inDocGravity
	 * @param outUpdateInputToCapturePayment
	 * @return
	 */
	private Document updateCapWithPersonInfo(Document inDocGravity,
			Document outUpdateInputToCapturePayment) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.updateCapWithPersonInfo -- Start");
		logger.debug("KohlsPSARefund.updateCapWithPersonInfo inDocGravity="+XMLUtil.getXMLString(inDocGravity)+" outUpdateInputToCapturePayment="+XMLUtil.getXMLString(outUpdateInputToCapturePayment));
		}
		try {
			Element inDocOrder = inDocGravity.getDocumentElement();
			Element inDocPaymentMethod = SCXmlUtil
					.getXpathElement(inDocOrder,
							"PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
			Element inDocCapturePayment = outUpdateInputToCapturePayment
					.getDocumentElement();
			Element inDocCapturePaymentMethod = SCXmlUtil
					.getXpathElement(inDocCapturePayment,
							"PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
			if ((!YFCCommon.isVoid(inDocCapturePaymentMethod))
					&& (!YFCCommon.isVoid(inDocPaymentMethod))) {
				Element eleInDocCapturePersonInfoBillTo = XMLUtil.createChild(
						inDocCapturePaymentMethod,
						KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
				String strExtnEmailAddress = inDocPaymentMethod
						.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
				eleInDocCapturePersonInfoBillTo
						.setAttribute(
								KohlsXMLLiterals.A_ADD_LINE_1,
								inDocPaymentMethod
										.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS));
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_ADD_LINE_2, KohlsPOCConstant.BLANK);
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_ADD_LINE_3, KohlsPOCConstant.BLANK);
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_ADD_LINE_4, KohlsPOCConstant.BLANK);
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_CITY, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_CITY));
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_COUNTRY, KohlsPOCConstant.BLANK);
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_DAY_PHONE, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
				if (!YFCCommon.isStringVoid(strExtnEmailAddress)) {
					eleInDocCapturePersonInfoBillTo.setAttribute(
							KohlsXMLLiterals.A_EMAIL_ID, strExtnEmailAddress);
				}
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_FIRST_NAME, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_FIRST_NAME));
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_LAST_NAME, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_LAST_NAME));
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_MOBILE_PHONE, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_STATE, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_STATE));
				eleInDocCapturePersonInfoBillTo.setAttribute(
						KohlsXMLLiterals.A_ZIP_CODE, inDocPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
				Element eleInDocCapturePersonInfoBillToExtn = XMLUtil
						.createChild(eleInDocCapturePersonInfoBillTo,
								KohlsXMLLiterals.E_EXTN);
				eleInDocCapturePersonInfoBillToExtn
						.setAttribute(
								KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE,
								inDocPaymentMethod
										.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
				bIsCorpRefund=true;
			}
		}
		catch (Exception e) {
			logger.error("Exception in the updateCapWithPersonInfo Method:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.updateCapWithPersonInfo outDoc="
				+ XMLUtil.getXMLString(outUpdateInputToCapturePayment));
		logger.debug("KohlsPSARefund.updateCapWithPersonInfo -- End");
		}
		return outUpdateInputToCapturePayment;
	}

	/**
	 * This method prepares input to executeCollection API
	 * 
	 * @param env
	 * @param strOrderHeaderkey
	 * @return
	 * @throws ParserConfigurationException
	 */
	protected Document inputToExecuteCollection(String strOrderHeaderkey) throws ParserConfigurationException  {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToExecuteCollection - Begin");
		}
		Document docExecuteCollectionInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_EXECUTECOLLECTION);
		Element eleExecuteCollectionInput = docExecuteCollectionInput
				.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)) {
			eleExecuteCollectionInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToExecuteCollection Output:"
				+ XMLUtil.getXMLString(docExecuteCollectionInput));
		logger.debug("KohlsPSARefund.inputToExecuteCollection - End");
		}
		return docExecuteCollectionInput;
	}
		
	/**
	 * This method calls executeCollectionService
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	@SuppressWarnings("unused")
	protected Document callExecuteCollectionAPI(YFSEnvironment env, Document inDoc) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callExecuteCollectionAPI - Begin");
		logger.debug("KohlsPSARefund.callExecuteCollectionAPI InputDocument:" + XMLUtil.getXMLString(inDoc));
		}
			try {
				 Document outDoc = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_EXECUTE_COLLECTION_PSA, inDoc);
			} catch (Exception e) {
			logger.error("Exception occurred while calling ExecuteCollection API:");
			}
		return inDoc;
			}
			
		
	
	/**
	 * This method invokes capturePaymentAPI
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	protected Document callCapturePaymentAPI(YFSEnvironment env, Document inDoc)
	{
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callCapturePaymentAPI - Begin");
		logger.debug("KohlsPSARefund.callCapturePaymentAPI InputDocument:" + XMLUtil.getXMLString(inDoc));
		}
		try {
			inDoc = KOHLSBaseApi.invokeAPI(env,
					KohlsXMLLiterals.API_CAPTURE_PAYMENT, inDoc);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callCapturePaymentAPI docOutput="
					+ XMLUtil.getXMLString(inDoc));
				}
		}
		catch (Exception e) {
			logger.error("Exception occurred while calling capturePayment API:"
					+ e.getMessage());
			}
		
		if(!YFCCommon.isVoid(inDoc)){
			if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callCapturePaymentAPI Output:"
				+ XMLUtil.getXMLString(inDoc));
		}
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callCapturePaymentAPI - End");
		}
		return inDoc;
			}

	/**
	 * This method prepares the input skeleton input to capturePayment API
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws ParserConfigurationException
	 */
	@SuppressWarnings("unchecked")
	private Document skeletonInputToCapturePayment(Document inDoc) throws ParserConfigurationException  
	{
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.skeletonInputToCapturePayment - Begin");
		logger.debug("KohlsPSARefund.skeletonInputToCapturePayment InputDocument:" + XMLUtil.getXMLString(inDoc));
		}
		Element eleInDoc=inDoc.getDocumentElement();
		String strOrderHeaderKey=eleInDoc.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
		Element elePaymentMethods=SCXmlUtil.getXpathElement(eleInDoc,KohlsXMLLiterals.E_PAYMENT_METHODS);
		List<Element> paymentMethodList= XMLUtil.getElementsByTagName(
				elePaymentMethods, KohlsXMLLiterals.E_PAYMENT_METHOD);
		int intPaymentMethodSize=paymentMethodList.size();
		//Creating Input
		Document docCapturePaymentInput=XMLUtil.createDocument(KohlsXMLLiterals.E_CAPTURE_PAYMENT);
		Element eleCapturePayment=docCapturePaymentInput.getDocumentElement();
		eleCapturePayment.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
		//MAD-287 CPE2471 Start
		//addEndpointToElement(eleCapturePayment);
		//MAD-287 CPE2471 End
		
		Element eleCapPaymentMethods=XMLUtil.createChild(eleCapturePayment, KohlsXMLLiterals.E_PAYMENT_METHODS);
		for(int i=0; i<intPaymentMethodSize; i++){
			Element elePaymentMethod = (Element)paymentMethodList.get(i);
			//skipping debit card for capture payment
			if(elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE).equalsIgnoreCase(KohlsPOCConstant.DEBIT_CARD)){
				continue;
			}
			Element eleCapPaymentMethod=XMLUtil.createChild(eleCapPaymentMethods, KohlsXMLLiterals.E_PAYMENT_METHOD);
			eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION,KohlsXMLLiterals.CONST_Y);
			eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_OPERATION, KohlsXMLLiterals.CONST_MANAGE);
			eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6, KohlsXMLLiterals.CONST_PSA);
			//PR-992 - Start
			eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_7, strCurrentPSATranNo);
			//PR-992 - End
			eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS, KohlsXMLLiterals.CONST_Y);	
			String strPayRef1=getPayRef1();
			if(!YFCCommon.isStringVoid(strPayRef1)){
				if(bIsDebugEnabled){
					logger.debug("KohlsPSARefund.skeletonInputToCapturePayment strPayRef1="+strPayRef1);
				}
				eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
			}
			eleCapPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2, KohlsPOCConstant.NO);
			String sBusinessDay=mPSAId.get(KohlsPOCConstant.ATTR_BUSINESS_DAY);
			if(!YFCCommon.isStringVoid(sBusinessDay)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.skeletonInputToCapturePayment sBusinessDay="+sBusinessDay);
				}
				eleCapPaymentMethod.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, sBusinessDay);
			}
			String sOperatorID=mPSAId.get(KohlsPOCConstant.A_OPERATOR_ID);
			if (!YFCCommon.isStringVoid(sOperatorID)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.skeletonInputToCapturePayment sOperatorID="+sOperatorID);
				}
				eleCapPaymentMethod.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, sOperatorID);
			}
			String sTerminalID=mPSAId.get(KohlsPOCConstant.ATTR_TERMINAL_ID);
			if (!YFCCommon.isStringVoid(sTerminalID)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.skeletonInputToCapturePayment sTerminalID="+sTerminalID);
				}
				eleCapPaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
			}
			String sTillID=mPSAId.get(KohlsPOCConstant.ATTR_TILL_ID);
			if (!YFCCommon.isStringVoid(sTillID)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.skeletonInputToCapturePayment sTillID="+sTillID);
				}
				eleCapPaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, sTillID);
			}
			String sStoreID=mPSAId.get(KohlsPOCConstant.ATTR_STORE_ID);
			if (!YFCCommon.isStringVoid(sStoreID)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.skeletonInputToCapturePayment sStoreID="+sStoreID);
				}
				eleCapPaymentMethod.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sStoreID);
			}
			String sDrawerID=mPSAId.get(KohlsPOCConstant.ATTR_DRAWER_ID);
			if (!YFCCommon.isStringVoid(sDrawerID)){
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.skeletonInputToCapturePayment sDrawerID="+sDrawerID);
				}
				eleCapPaymentMethod.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, sDrawerID);
			}
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.skeletonInputToCapturePayment Output:"
				+ XMLUtil.getXMLString(docCapturePaymentInput));
		logger.debug("KohlsPSARefund.skeletonInputToCapturePayment - End");
		}
		return docCapturePaymentInput;
	}
	
	/**
	 * This method updates the capturePayment Input
	 * @param env
	 * @param inDoc
	 * @param docCapturePaymentInput
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private Document updateInputToCapturePayment(Document inDoc, Document docCapturePaymentInput){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.updateInputToCapturePayment - Begin");
		logger.debug("KohlsPSARefund.updateInputToCapturePayment InputDocument:" + XMLUtil.getXMLString(inDoc));
		logger.debug("KohlsPSARefund.updateInputToCapturePayment capturePaymentInput:" + XMLUtil.getXMLString(docCapturePaymentInput));
		}
		Element eleInDoc=inDoc.getDocumentElement();
		Element elePaymentMethods=SCXmlUtil.getXpathElement(eleInDoc,KohlsXMLLiterals.E_PAYMENT_METHODS);
		List<Element> paymentMethodList= XMLUtil.getElementsByTagName(
				elePaymentMethods, KohlsXMLLiterals.E_PAYMENT_METHOD);
		Element eleCapInDoc=docCapturePaymentInput.getDocumentElement();
		Element eleCapPaymentMethods=SCXmlUtil.getXpathElement(eleCapInDoc,KohlsXMLLiterals.E_PAYMENT_METHODS);
		List<Element> capPaymentMethodList= XMLUtil.getElementsByTagName(
				eleCapPaymentMethods, KohlsXMLLiterals.E_PAYMENT_METHOD);
		for(int i=0; i<capPaymentMethodList.size();i++){
			String strPaymentType=paymentMethodList.get(i).getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
			capPaymentMethodList.get(i).setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,strPaymentType);
			String strRequestedAmount= "-".concat(paymentMethodList.get(i).getAttribute(KohlsXMLLiterals.A_AMOUNT));
			capPaymentMethodList.get(i).setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT,strRequestedAmount);
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.updateInputToCapturePayment Output:"
				+ XMLUtil.getXMLString(docCapturePaymentInput));
		logger.debug("KohlsPSARefund.updateInputToCapturePayment - End");
		}
		return docCapturePaymentInput;
	}
	
	/**
	 * This method prepares an input to getPaymentList API
	 * @param env
	 * @param strOrderHeaderkey
	 * @return
	 * @throws ParserConfigurationException
	 */
	private Document inputToGetPaymentList(String strOrderHeaderkey) throws ParserConfigurationException  {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToGetPaymentList - Begin");
		}
		Document docGetPaymentListInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_PAYMENT);
		Element eleGetPaymentListInput = docGetPaymentListInput
				.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)) {
			eleGetPaymentListInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
			//MAD-287 CPE 2471Start
			//addEndpointToElement(eleGetPaymentListInput);
			//MAD-287 CPE2471End
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToGetPaymentList Output:"
				+ XMLUtil.getXMLString(docGetPaymentListInput));
		logger.debug("KohlsPSARefund.inputToGetPaymentList - End");
		}
		return docGetPaymentListInput;
	}
	
	/**
	 * This method makes a getPaymentList API call 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	protected Document callgetPaymentList(YFSEnvironment env, Document inDoc) {
		if(bIsDebugEnabled){  
		logger.debug("KohlsPSARefund.callgetPaymentList - Begin");
		logger.debug("KohlsPSARefund.callgetPaymentList InputDocument:" + XMLUtil.getXMLString(inDoc));
		}
		try {
			Document docGetPaymentListOutTemp=XMLUtil.getDocument(KohlsXMLLiterals.TEMP_GET_PAY_LIST);
			if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.callgetPaymentList docGetPaymentListOutTemp="+XMLUtil.getXMLString(docGetPaymentListOutTemp));
				}
			inDoc = KOHLSBaseApi.invokeAPI(env, docGetPaymentListOutTemp, KohlsXMLLiterals.API_GET_PAYMENT_LIST, inDoc);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callgetPaymentList Output:"
					+ XMLUtil.getXMLString(inDoc));
			}
		} catch (Exception e) {
			logger.error("Exception occurred while calling getPaymentList API:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callgetPaymentList - End");
		}
		return inDoc;
	}
	
	
	/**
	 * This method makes a voidChargeTransaction API call
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	public Document callvoidChargeTransaction(YFSEnvironment env, Document inDoc) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callvoidChargeTransaction - Begin");
		logger.debug("KohlsPSARefund.callvoidChargeTransaction InputDocument:" + XMLUtil.getXMLString(inDoc));	
		}
		try {
			inDoc = KOHLSBaseApi.invokeAPI(env,
					KohlsXMLLiterals.API_VOID_CHARGE_TRANSACTION, inDoc);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callvoidChargeTransaction Output:"
					+ XMLUtil.getXMLString(inDoc));
			}
		} catch (Exception e) {
			logger.error("Exception occurred while calling voidChargeTransaction API:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callvoidChargeTransaction Output:"
				+ XMLUtil.getXMLString(inDoc));
		logger.debug("KohlsPSARefund.callvoidChargeTransaction - End");
		}
		return inDoc;
	}
	
	/**
	 * This methods forms the input for voidTransactionAPI
	 * 
	 * @param env
	 * @param inList
	 * @param docCallGetChargeTransactionListOutput
	 * @return
	 * @throws ParserConfigurationException
	 */
	public Document voidChargeTransactioninDoc(List<String> inList) throws ParserConfigurationException
			
	{
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.voidChargeTransactioninDoc - Begin");
		}
		Document inDocvoidChargeTransactionAPI = XMLUtil
				.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAILS);
		Element eleChargeTrasactionDetails = inDocvoidChargeTransactionAPI
				.getDocumentElement();
		for (int j = 0; j < inList.size(); j++) {
			Element eleChargeTrasactionDetail = XMLUtil.createChild(
					eleChargeTrasactionDetails,
					KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
			eleChargeTrasactionDetail.setAttribute(
					KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY, inList.get(j));
		}
		//MAD-287 CPE2471- Start
		 //addEndpointToElement(eleChargeTrasactionDetails);
		//MAD-287 CPE2471 - End 
		 
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.voidChargeTransactioninDoc inDoc="
				+ XMLUtil.getXMLString(inDocvoidChargeTransactionAPI));
		}
		return inDocvoidChargeTransactionAPI;
	}
	
	//MAD-287 - Start
	/**
	 * check isEdge deployment and setting the document with endpoint
	 */
	/*public void addEndpointToElement(Element finalEle) throws ParserConfigurationException
	
	{
		logger.debug("Before Adding edge ::"+ServerTypeHelper.amIOnEdgeServer());
		if(ServerTypeHelper.amIOnEdgeServer()){
			Element eleAdditionalInfo= SCXmlUtil.createChild(finalEle,KohlsXMLLiterals.E_YFCADDITIONALINFO);
			if (!YFCCommon.isVoid(endpoint)){
				eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endpoint);
			} else{
				eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_MOTHERSHIP);
			}
		 }			
		logger.debug("Before Adding edge ::"+XMLUtil.getElementXMLString(finalEle));
	
	}*/
	//MAD-287 - End
	/**
	 * This method saves the chargeTransactionKeys to an arrayList
	 * 
	 * @param env
	 * @param docChargeTransactionDetailsOut
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> getChargeTransactionKeys(Document docChargeTransactionDetailsOut) {	
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getChargeTransactionkeys - Begin");
		logger.debug("KohlsPSARefund.getChargeTransactionKeys InputDocument:" + XMLUtil.getXMLString(docChargeTransactionDetailsOut));
		}
		List<String> chargeTrnsactionKeys = new ArrayList<String>();
		try{
		Element eleChargeTransactionDetails = docChargeTransactionDetailsOut
				.getDocumentElement();
		List<Element> eleChargeTransactionDetailList = XMLUtil
				.getElementsByTagName(eleChargeTransactionDetails,
						KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
		if (eleChargeTransactionDetailList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element eleChargeTransactionDetail : eleChargeTransactionDetailList) {
				String strChargeTransactionKey = eleChargeTransactionDetail
						.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY);
				if (!YFCCommon.isVoid(strChargeTransactionKey))	{
					chargeTrnsactionKeys.add(strChargeTransactionKey);
					if(bIsDebugEnabled){
					logger.debug("ChargeTransactionKey:"+strChargeTransactionKey);
					}
				}
			}
		}
		}catch(Exception e){
			logger.error("KohlsPSARefund.getChargeTransactionkeys Exception"+e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getChargeTransactionkeys - End");
		}
		return chargeTrnsactionKeys;
	}
	
	/**
	 * This method invokes getChargeTransactionList API
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	public Document callGetChargeTransactionListAPI(YFSEnvironment env,
			Document inDoc){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callGetChargeTransactionListAPI -- Start");
		}
		try {
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callGetChargeTransactionListAPI inDoc="+XMLUtil.getXMLString(inDoc));
			}
			inDoc = KOHLSBaseApi.invokeAPI(env,
					KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, inDoc);
			if(!YFCCommon.isVoid(inDoc)){
				if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callGetChargeTransactionListAPI docOutput="
					+ XMLUtil
							.getXMLString(inDoc));
				}
			}
			}catch (Exception e) {
			logger.error("Exception occurred while calling getChargeTrasactionList API:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callGetChargeTransactionListAPI Output:"
				+ XMLUtil.getXMLString(inDoc));
		logger.debug("KohlsPSARefund.callGetChargeTransactionListAPI -- End");
		}
		return inDoc;
	}

	/**
	 * This method prepares input for getChargeTransactionList API
	 * 
	 * @param strOrderHeaderKey
	 * @return
	 * @throws ParserConfigurationException
	 */
	public Document inputToGetChargeTransactionList(String strOrderHeaderKey) throws ParserConfigurationException  {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToGetChargeTransactionList - Begin");
		}
		Document docGetChargeTransactionListInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
		Element eleChargeTransactionListInput = docGetChargeTransactionListInput
				.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderKey)) {
			eleChargeTransactionListInput.setAttribute(
					KohlsXMLLiterals.A_CHARGE_TYPE, KohlsXMLLiterals.CONST_CHARGE);
			eleChargeTransactionListInput.setAttribute(
					KohlsXMLLiterals.A_STATUS, KohlsXMLLiterals.ATTR_OPEN);
			eleChargeTransactionListInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
			//MAD-287 CPE2471- Start
			 //addEndpointToElement(eleChargeTransactionListInput);
			//MAD-287 CPE2471- End 
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToGetChargeTransactionList Output:"
				+ XMLUtil.getXMLString(docGetChargeTransactionListInput));
		logger.debug("KohlsPSARefund.inputToGetChargeTransactionList - End");
		}
		return docGetChargeTransactionListInput;
	}
	
	
	/**
	 * This method calls request collection Service
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	public Document callRequestCollectionAPI(YFSEnvironment env, Document inDoc) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callRequestCollectionAPI --Start");
		logger.debug("KohlsPSARefund.callRequestCollectionAPI InputDocument:" + XMLUtil.getXMLString(inDoc));
		}
		try {
			inDoc = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_REQUEST_COLLECTION_PSA, inDoc);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callRequestCollectionAPI docOutput="
					+ XMLUtil.getXMLString(inDoc));
			}
		} catch (Exception e) {
			logger.error("Exception occurred while calling requestCollection API:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callRequestCollectionAPI --End");
		}
		return inDoc;
	}
	
	
	/**
	 * This method prepares input to PSAGetOrderList service
	 * @param env
	 * @param strOrderHeaderkey
	 * @return
	 * @throws ParserConfigurationException
	 */
	private Document inputToPSAGetOrderList(String strOrderHeaderkey, Document inXML) throws ParserConfigurationException  {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToPSAGetOrderList - Begin");
		}
		Document docPSAGetOrderListInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_ORDER);
		Element elePSAGetOrderListInput = docPSAGetOrderListInput
				.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)) {
			elePSAGetOrderListInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
			//MAD-287 Start-CPE2361
			if (ServerTypeHelper.amIOnEdgeServer()) {
                		Element inElement = inXML.getDocumentElement();
                		Element eleAddtionalInfo = SCXmlUtil.getXpathElement(inElement, "/Order/yfcAdditionalInfo");
                		Element eleAdditionalInfo = SCXmlUtil.createChild(elePSAGetOrderListInput,
                        	KohlsXMLLiterals.E_YFCADDITIONALINFO);
                		eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,eleAddtionalInfo.getAttribute(KohlsXMLLiterals.A_ENDPOINT));
            		}
			//MAD-287 CPE2361 End
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToPSAGetOrderList Output:"
				+ XMLUtil.getXMLString(docPSAGetOrderListInput));
		logger.debug("KohlsPSARefund.inputToPSAGetOrderList - End");
		}
		return docPSAGetOrderListInput;

	}
	
	/**
	 * This method calls PSAGetOrderListAPI
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */

	private Document callPSAGetOrderListAPI(YFSEnvironment env, Document inDoc) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callPSAGetOrderListAPI -- Start");
		logger.debug("KohlsPSARefund.callPSAGetOrderListAPI InputDocument:" + XMLUtil.getXMLString(inDoc));
		}
		try {
			inDoc = KOHLSBaseApi.invokeService(env,
					KohlsConstant.PSA_GET_ORDER_LIST, inDoc);
			if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.callPSAGetOrderListAPI docOutput="
					+ XMLUtil.getXMLString(inDoc));
			}
		} catch (Exception e) {
			logger.error("Exception occurred while calling PSAGetOrderList API:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callPSAGetOrderListAPI -- End");
		}
		return inDoc;
	}
	
	/**
	 * This method prepares the input to requestCollection API
	 * 
	 * @param strOrderHeaderkey
	 * @return
	 * @throws ParserConfigurationException
	 */
	public Document inputToRequestCollection(String strOrderHeaderkey) throws ParserConfigurationException  {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToRequestCollection - Begin");
		}
		Document docRequestCollectionInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleRequestCollectionInput = docRequestCollectionInput
				.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)) {
			eleRequestCollectionInput.setAttribute(
					KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderkey);
		}
		//MAD-287 CPE2471 - Start
		//addEndpointToElement(eleRequestCollectionInput);
		//MAD-287 CPE2471- End 
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.inputToRequestCollection Input:"
				+ XMLUtil.getXMLString(docRequestCollectionInput));
		logger.debug("KohlsPSARefund.inputToRequestCollection - End");
		}
		return docRequestCollectionInput;
	}
	
	/**
	 * 
	 * This method returns the OrderHeaderKey from the 
	 * Gravity input
	 * 
	 * @param docInput
	 * @return
	 */
	protected String getOHKey(Document docInput){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getOHKey -- Start");
		logger.debug("KohlsPSARefund.getOHKey docInput="+XMLUtil.getXMLString(docInput));
		}
		String strOHKey=null;
		try{
			Element eleOrder = docInput.getDocumentElement();
			strOHKey=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		}catch(Exception e){
			logger.error("KohlsPSARefund.getOHKey Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getOHKey strOHKey="+strOHKey);
		logger.debug("KohlsPSARefund.getOHKey -- End");
		}
		return strOHKey;
	}
	

	/**
	 * 
	 * This method creates a new String based on Current
	 * TimeStamp
	 * 
	 * @return
	 */
	private String getPayRef1() {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getPayRef1 -- Start");
		}
		String strPayRef1=null;
		try{
		strPayRef1=new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()).trim();
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getPayRef1 strPayRef1="+strPayRef1);
		}
		}catch(Exception e){
			logger.error("KohlsPSARefund.getPayRef1 Exception="+e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.getPayRef1 -- End");
		}
		return strPayRef1;
	}


/**
 * 
 * @param env
 * @param eleTxnPaymentMethod
 * @param elemOrder
 * @return Document
 * @throws YFSUserExitException
 */
private Document createPSAGCActivationRequest(YFSEnvironment env,Element eleTxnPaymentMethod, Element elemOrder)
		throws YFSUserExitException {

	if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.createPSAGCActivationRequest -- Start");
	logger.debug("KohlsPSARefund.createPSAGCActivationRequest eleTxnPaymentMethod="+XMLUtil.getElementXMLString(eleTxnPaymentMethod)+" elemOrder="+XMLUtil.getElementXMLString(elemOrder));
	}
	Document docGCActivationOutput = null;
	// forming input to web service KohlsPoCSVCPaymentWebService
	Document docInputToWebService = YFCDocument.createDocument(
			KohlsConstant.PAYMENT_REQUEST).getDocument();
	Element elePmntReq = docInputToWebService.getDocumentElement();
	Element eleTran = docInputToWebService
			.createElement(KohlsXMLLiterals.E_TRANSACTION);
	XMLUtil.appendChild(elePmntReq, eleTran);

	// Setting the attributes in the input xml.
	Double dAmount = new Double(
			eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
	eleTran.setAttribute(KohlsXMLLiterals.A_TENDER_AMOUNT,
			Double.toString(Math.abs(dAmount.doubleValue())));
	eleTran.setAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE,
			KohlsConstant.PSA_DRIVERS_LICENSE_NUM);
	eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,
			KohlsConstant.ACTIVATION);

	eleTran.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,
			KohlsXMLLiterals.ATTR_MERC_RETURN_CREDIT);
	String sEntryMethod = eleTxnPaymentMethod
			.getAttribute(KohlsXMLLiterals.ATTR_ENTRY_METHOD);
	
	if(!YFCCommon.isStringVoid(sEntryMethod)){
		logger.debug("KMC Entry from Gravity"+sEntryMethod);
		strKMCEntryMethod=sEntryMethod;
		if(KohlsConstant.KEYED.equalsIgnoreCase(sEntryMethod)){
		eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,
				KohlsConstant.KEYED);
	}else if(KohlsConstant.BARCODE.equalsIgnoreCase(sEntryMethod)){
			eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,
					KohlsConstant.BARCODE);	
		}
	}
	//Has to be removed once Gravity implements Sending Entry method for all scenarios -- Start
	else {
		eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,
				KohlsConstant.BARCODE);
	}
	//Has to be removed once Gravity implements Sending Entry method for all scenarios -- End
	// eleTran.setAttribute("Protected", props.getProperty("Protected"));
	String storeNo = eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.ATTR_STORE_NUM);
	// String prepadStroNo=KohlsPoCPnPUtil.prepadStoreNoWithZeros(storeNo);
	eleTran.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER, storeNo);
	eleTran.setAttribute(KohlsXMLLiterals.A_REGISTER_NUMBER,
			elemOrder.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
	eleTran.setAttribute(KohlsXMLLiterals.A_SVCNO,
			eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_SVCNo));
	eleTran.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
			elemOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
	eleTran.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,
			elemOrder.getAttribute(KohlsConstant.POS_SEQUENCE_NO));

	if(bIsDebugEnabled){
	logger.debug("Input to call KohlsPoCSVCPaymentWebService::"
			+ XMLUtil.getXMLString(docInputToWebService));
	}
	try {
		docGCActivationOutput = KOHLSBaseApi.invokeService(env,
				KohlsXMLLiterals.SER_KOHLS_POC_SVC, docInputToWebService);
	} catch (Exception e) {
		logger.error("Exception while calling PSA KohlsPoCSVCPaymentWebService"
				+ e.getMessage());
	}
	if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.createPSAGCActivationRequest docGCActivationOutput="+XMLUtil.getXMLString(docGCActivationOutput));
	logger.debug("KohlsPSARefund.createPSAGCActivationRequest -- End");
	}
	return docGCActivationOutput;

}


/**
 * This method forms a skeleton input to recordExternalCharges with generic
 * items
 * @param docInXMLClone2 
 * 
 * @return
 * @throws ParserConfigurationException
 */
private Document formInputSklToRecordExternalCharges()
		throws ParserConfigurationException {
	if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges - Begin");
	}
	Document docSklToRecordExternalCharges =null; 
			try{
	docSklToRecordExternalCharges=XMLUtil
			.createDocument(KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES);
	Element eleRecordExternalCharges = docSklToRecordExternalCharges
			.getDocumentElement();
	Element elePaymentMethod = XMLUtil.createChild(
			eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
	elePaymentMethod.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION,
			KohlsXMLLiterals.CONST_Y);
	elePaymentMethod.setAttribute(KohlsXMLLiterals.A_OPERATION,
			KohlsXMLLiterals.CONST_MANAGE);
	elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6,
			KohlsXMLLiterals.CONST_PSA);
	//PR-992 - Start
	elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_7, strCurrentPSATranNo);
	//PR-992 - End
	elePaymentMethod.setAttribute(
			KohlsXMLLiterals.A_RESET_SUSPENSION_STATUS,
			KohlsXMLLiterals.CONST_Y);
	//MAD-287 CPE2471Start
	//addEndpointToElement(eleRecordExternalCharges);
	//MAD-287 CPE2471End
	String sPayRef1=getPayRef1();
	elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, sPayRef1);
	elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2, KohlsPOCConstant.NO);
	String sBusinessDay=mPSAId.get(KohlsPOCConstant.ATTR_BUSINESS_DAY);
	if (!YFCCommon.isStringVoid(sBusinessDay)){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges sBusinessDay="+sBusinessDay);
		}
		elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, sBusinessDay);
	}
	String sOperatorID=mPSAId.get(KohlsPOCConstant.A_OPERATOR_ID);
	if (!YFCCommon.isStringVoid(sOperatorID)){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges sOperatorID="+sOperatorID);
		}
		elePaymentMethod.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, sOperatorID);
	}
	String sTerminalID=mPSAId.get(KohlsPOCConstant.ATTR_TERMINAL_ID);
	if (!YFCCommon.isStringVoid(sTerminalID)){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges sTerminalID="+sTerminalID);
		}
		elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
	}
	String sTillID=mPSAId.get(KohlsPOCConstant.ATTR_TILL_ID);
	if (!YFCCommon.isStringVoid(sTillID)){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges sTillID="+sTillID);
		}
		elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, sTillID);
	}
	String sStoreID=mPSAId.get(KohlsPOCConstant.ATTR_STORE_ID);
	if (!YFCCommon.isStringVoid(sStoreID)){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges sStoreID="+sStoreID);
		}
		elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sStoreID);
	}
	String sDrawerID=mPSAId.get(KohlsPOCConstant.ATTR_DRAWER_ID);
	if (!YFCCommon.isStringVoid(sDrawerID)){
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges sDrawerID="+sDrawerID);
		}
		elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, sDrawerID);
	}
	Element elePaymentDetailsList = XMLUtil.createChild(elePaymentMethod,
			KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
	Element elePaymentDetails = XMLUtil.createChild(elePaymentDetailsList,
			KohlsXMLLiterals.E_PAYMENT_DETAILS);
	elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE,
			KohlsXMLLiterals.CONST_CHARGE);
	elePaymentDetails.setAttribute(KohlsXMLLiterals.A_IN_PERSON,
			KohlsXMLLiterals.CONST_Y);
	elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_PROCESSED,
			KohlsXMLLiterals.CONST_Y);
	if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges Output:"
			+ XMLUtil.getXMLString(docSklToRecordExternalCharges));
	logger.debug("KohlsPSARefund.formInputSklToRecordExternalCharges - End");
	}
			}catch(Exception e){
				logger.error("KohlsPSARefund.formInputSklToRecordExternalCharges Exception "+e.getMessage());
			}
	return docSklToRecordExternalCharges;

}


/**
 * This method makes a recordExternalCharges API call
 * 
 * @param env
 * @param inDoc
 * @return
 */
protected Document callRecordExternalPayments(YFSEnvironment env,
		Document inDoc) {
	if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.callRecordExternalPayments - Begin");
	logger.debug("KohlsPSARefund.callRecordExternalPayments InputDocument:"
			+ XMLUtil.getXMLString(inDoc));
	}
	try {
		inDoc = KOHLSBaseApi.invokeAPI(env,
				KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES, inDoc);
		if(!YFCCommon.isVoid(inDoc)){
			if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.callPSAGetOrderListAPI Output:"
				+ XMLUtil.getXMLString(inDoc));
		}
		}
	} catch (Exception e) {
		logger.error("Exception occurred while calling callRecordExternalPayments API:"
				+ e.getMessage());
	}
	if(bIsDebugEnabled){
	logger.debug("KohlsPSARefund.callRecordExternalPayments - End");
	}
	return inDoc;
}

  
/**
 * This method updates the outDoc of formInputSklToRecordExternalCharges according to the payment type obtained from gravity	
 * @param elePaymentMethod
 * @param outDocformInputSklToRecordExternalCharges
 * @param strOrderHeaderKey
 * @param getPaymentListOutDoc
 * @param mapKMCValues
 * @return
 */
	
private Document updatesklRecordExternalCharges(Element elePaymentMethod,
		Document outDocformInputSklToRecordExternalCharges,
		String strOrderHeaderKey, Document getPaymentListOutDoc,
		Map<String, String> mapKMCValues) {
	try {
		String strPaymentType = null;
		String strCreditCardTypeNo = null;
		String strCreditCardType = null;
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.updatesklRecordExternalCharges formInputSklToRecordExternalCharges outDoc="
					+ XMLUtil
							.getXMLString(outDocformInputSklToRecordExternalCharges));
			logger.debug("KohlsPSARefund.updatesklRecordExternalCharges paymentMethod element from gravity="
					+ XMLUtil
							.getElementXMLString(elePaymentMethod));
			logger.debug("KohlsPSARefund.updatesklRecordExternalCharges OrderHeaderKey="
					+ strOrderHeaderKey);
			logger.debug("KohlsPSARefund.updatesklRecordExternalCharges  PaymentList outDoc="
					+ XMLUtil
							.getXMLString(getPaymentListOutDoc));
			}
			Element eleRecordExternalCharges = outDocformInputSklToRecordExternalCharges
					.getDocumentElement();
			strPaymentType = elePaymentMethod
					.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
			if (strPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC)) {
				eleRecordExternalCharges.setAttribute(
						KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
				Element elePaymentMethod1 = SCXmlUtil.getXpathElement(
						eleRecordExternalCharges,
						KohlsXMLLiterals.E_PAYMENT_METHOD);
				String strPayRef1 = getPayRef1();
				elePaymentMethod1.setAttribute(
						KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
				if(!YFCCommon.isStringVoid(strKMCEntryMethod)){
					logger.debug("KMCEntryMethod is "+strKMCEntryMethod);
				elePaymentMethod1.setAttribute(
						KohlsXMLLiterals.A_PAYMENT_REF_2, strKMCEntryMethod);
				}
				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,
						strPaymentType);
				String strRequestedAmount = "-".concat(elePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_AMOUNT));
				elePaymentMethod1
						.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT,
								strRequestedAmount);
				elePaymentMethod1
						.setAttribute(KohlsXMLLiterals.A_SVC_NO,
								elePaymentMethod
										.getAttribute(KohlsXMLLiterals.A_SVCNo));
				elePaymentMethod1
				.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
						mapKMCValues.get(KohlsPOCConstant.ATTR_STORE_ID));  
				Element elePaymentMethod1Extn = XMLUtil.createChild(
						elePaymentMethod1, KohlsXMLLiterals.E_EXTN);
				elePaymentMethod1Extn
						.setAttribute(
								KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE,
								mapKMCValues
										.get(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE));
				elePaymentMethod1Extn
						.setAttribute(
								KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE,
								mapKMCValues
										.get(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE));
				Element elePaymentDetailsList = SCXmlUtil.getXpathElement(
						elePaymentMethod1,
						KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
				Element elePaymentDetails = SCXmlUtil.getXpathElement(
						elePaymentDetailsList,
						KohlsXMLLiterals.E_PAYMENT_DETAILS);
				elePaymentDetails
						.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT,
								strRequestedAmount);
				elePaymentDetails.setAttribute(
						KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);
			}
			if (strPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD))
			{
				eleRecordExternalCharges.setAttribute(
						KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
				Element elePaymentMethod1 = SCXmlUtil.getXpathElement(
						eleRecordExternalCharges,
						KohlsXMLLiterals.E_PAYMENT_METHOD);
				String strCreditCardNo = elePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
				int iSize=strCreditCardNo.length();
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.updatesklRecordExternalCharges isize="+iSize);
				}
				String strTrimCreditCardNo= strCreditCardNo.substring(iSize-4,iSize);
				Element elePaymentList = getPaymentListOutDoc
						.getDocumentElement();
				Element elePayment = SCXmlUtil.getXpathElement(elePaymentList,
						"Payment[@DisplayCreditCardNo='" + strTrimCreditCardNo + "']");
				strCreditCardType = elePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
				strCreditCardTypeNo = changeCreditCardType(strCreditCardType);
				elePaymentMethod1.setAttribute(
						KohlsXMLLiterals.A_CREDIT_CARD_TYPE,
						strCreditCardTypeNo);
				elePaymentMethod1
						.setAttribute(
								KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
								elePayment
										.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO));
				elePaymentMethod1.setAttribute(
						KohlsXMLLiterals.A_CREDIT_CARD_NO, elePayment
											.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
				String sFirstName=elePayment
						.getAttribute(KohlsPOCConstant.ATTR_FIRST_NAME);
				if(!YFCCommon.isStringVoid(sFirstName)){
					if(bIsDebugEnabled){
						logger.debug("KohlsPSARefund.updatesklRecordExternalCharges sFirstName"+sFirstName);
					}
				elePaymentMethod1.setAttribute(
						KohlsPOCConstant.ATTR_FIRST_NAME, sFirstName);
				}
				String sLastName=elePayment
						.getAttribute(KohlsPOCConstant.ATTR_LAST_NAME);
				if(!YFCCommon.isStringVoid(sLastName)){
					if(bIsDebugEnabled){
						logger.debug("KohlsPSARefund.updatesklRecordExternalCharges sLastName"+sLastName);
					}
				elePaymentMethod1.setAttribute(
						KohlsPOCConstant.ATTR_LAST_NAME, sLastName);
				}
				elePaymentMethod1
						.setAttribute(
								KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
								elePayment
										.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
				
				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,
						strPaymentType);
				String strRequestedAmount = KohlsPOCConstant.MINUS.concat(elePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_AMOUNT));
				elePaymentMethod1
						.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT,
								strRequestedAmount);
				Element elePaymentDetailsList = SCXmlUtil.getXpathElement(
						elePaymentMethod1,
						KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
				Element elePaymentDetails = SCXmlUtil.getXpathElement(
						elePaymentDetailsList,
						KohlsXMLLiterals.E_PAYMENT_DETAILS);
				elePaymentDetails
						.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT,
								strRequestedAmount);
				elePaymentDetails.setAttribute(
						KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);
				//PST-1906 - Start - Setting ExtnPSIPayment flag as Y
				 Element elePaymentMethod1Extn = XMLUtil.createChild(elePaymentMethod1, KohlsXMLLiterals.E_EXTN);
				 elePaymentMethod1Extn.setAttribute("ExtnPSIPayment","Y");
				 //PST-1906 - End
			}
			if (strPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD))
			{
				eleRecordExternalCharges.setAttribute(
						KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
				Element elePaymentMethod1 = SCXmlUtil.getXpathElement(
						eleRecordExternalCharges,
						KohlsXMLLiterals.E_PAYMENT_METHOD);
				String strCreditCardNo = elePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
				int iSize=strCreditCardNo.length();
				if(bIsDebugEnabled){
				logger.debug("KohlsPSARefund.updatesklRecordExternalCharges isize="+iSize);
				}
				String strTrimCreditCardNo= strCreditCardNo.substring(iSize-4,iSize);
				Element elePaymentList = getPaymentListOutDoc
						.getDocumentElement();
				Element elePayment = SCXmlUtil.getXpathElement(elePaymentList,
						"Payment[@DisplayCreditCardNo='" + strTrimCreditCardNo + "']");
				elePaymentMethod1.setAttribute(
						KohlsXMLLiterals.A_CREDIT_CARD_TYPE, KohlsXMLLiterals.ATTR_ZERO_FOUR);
				elePaymentMethod1
						.setAttribute(
								KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
								elePayment
										.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO));
				elePaymentMethod1.setAttribute(
						KohlsXMLLiterals.A_CREDIT_CARD_NO, elePayment
											.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
				elePaymentMethod1
						.setAttribute(
								KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
								elePayment
										.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
				String sFirstName=elePayment
						.getAttribute(KohlsPOCConstant.ATTR_FIRST_NAME);
				if(!YFCCommon.isStringVoid(sFirstName)){
					if(bIsDebugEnabled){
						logger.debug("KohlsPSARefund.updatesklRecordExternalCharges sFirstName"+sFirstName);
					}
				elePaymentMethod1.setAttribute(
						KohlsPOCConstant.ATTR_FIRST_NAME, sFirstName);
				}
				String sLastName=elePayment
						.getAttribute(KohlsPOCConstant.ATTR_LAST_NAME);
				if(!YFCCommon.isStringVoid(sLastName)){
					if(bIsDebugEnabled){
						logger.debug("KohlsPSARefund.updatesklRecordExternalCharges sLastName"+sLastName);
					}
				elePaymentMethod1.setAttribute(
						KohlsPOCConstant.ATTR_LAST_NAME, sLastName);
				}
				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,
						strPaymentType);
				String strRequestedAmount = KohlsPOCConstant.MINUS.concat(elePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_AMOUNT));
				elePaymentMethod1
						.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT,
								strRequestedAmount);
				Element elePaymentDetailsList = SCXmlUtil.getXpathElement(
						elePaymentMethod1,
						KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
				Element elePaymentDetails = SCXmlUtil.getXpathElement(
						elePaymentDetailsList,
						KohlsXMLLiterals.E_PAYMENT_DETAILS);
				elePaymentDetails
						.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT,
								strRequestedAmount);
				elePaymentDetails.setAttribute(
						KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);
				//PST-1906 - Start - Setting ExtnPSIPayment flag as Y
				 Element elePaymentMethod1Extn = XMLUtil.createChild(elePaymentMethod1, KohlsXMLLiterals.E_EXTN);
				 elePaymentMethod1Extn.setAttribute("ExtnPSIPayment","Y");
				 //PST-1906 - End
			}
		}
		catch (Exception e) {
			logger.error("Exception in the updatesklRecordExternalCharges Method:"
					+ e.getMessage());
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.updatesklRecordExternalCharges  updatesklRecordExternalCharges  outDoc="
				+ XMLUtil
						.getXMLString(outDocformInputSklToRecordExternalCharges));
		}
		return outDocformInputSklToRecordExternalCharges;
	}

/**
* This method changes the credit card type to 05,06,07,08 depending on the input
* @param strCreditCardType
* @return
*/

	private String changeCreditCardType(String strCreditCardType) {
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.setCreditCardType --Start");
		logger.debug("KohlsPSARefund.setCreditCardType before strCreditCardType"
				+ strCreditCardType);
		}
		if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_VISA)) {
			strCreditCardType = KohlsConstant.VISA_05;
		} else if (strCreditCardType
				.equalsIgnoreCase(KohlsConstant.PSA_MASTERCARD)) {
			strCreditCardType = KohlsConstant.MASTERCARD_06;
		} else if (strCreditCardType
				.equalsIgnoreCase(KohlsConstant.PSA_DISCOVER)) {
			strCreditCardType = KohlsConstant.DISCOVER_07;
		} else if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_AMEX)) {
			strCreditCardType = KohlsConstant.AMEX_08;
		}
		if(bIsDebugEnabled){
		logger.debug("KohlsPSARefund.setCreditCardType after strCreditCardType"
				+ strCreditCardType);
		logger.debug("KohlsPSARefund.setCreditCardType --End");
		}
		return strCreditCardType;
	}
	
	/**
	 * Added method to getKohlsSalesDetails from GetKohlsSalesDetails Service
	 * @param env
	 * @param inXML
	 * @return
	 * @throws Exception
	 */
	public Document getKohlsSalesDetails(YFSEnvironment env, Document inXML) throws Exception
	{
		logger.debug("KohlsPSARefund.getKohlsSalesDetails ");
		logger.debug("getKohlsSalesDetails -start");
		Document outDoc = null;
		Element eleOrder = inXML.getDocumentElement();
		//CPE2471
		//addEndpointToElement(eleOrder);
		//CPE2471
		logger.debug("getKohlsSalesDetails -input to api ::"+XMLUtil.getXMLString(inXML));
		outDoc=KOHLSBaseApi.invokeService(env, "GetKOHLSSalesDetailsForPSA",inXML);
		return outDoc;
		
	}
	
	/**
     * MAD-341 changes.
     * 
     * @param env
     * @param orderHeaderKey
     * @param inputElement
     * @param apiName
     * @throws ParserConfigurationException
     * @throws Exception
     */
    private void populatePsaOfflineForPsaStatus(YFSEnvironment env, String orderHeaderKey, Element inputElement,
            String apiName) throws ParserConfigurationException, Exception {
        logger.debug("KohlsPSARefund.populatePsaOfflineForPsaStatus---Begin");
        Document inputKohlsPsaOfflineQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_KOHLS_PSA_OFFLINE_Q);
        Element inputKohlsPsaOfflineQElement = inputKohlsPsaOfflineQDoc.getDocumentElement();
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, apiName);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_STATUS, "");
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_OPERATION_XML,
                XMLUtil.getElementXMLString(inputElement));
        String getPSAReplicationSequence = getPSAReplicationSequence(env);
        logger.debug("Replication sequence for this operation is   :" + getPSAReplicationSequence);
        inputKohlsPsaOfflineQElement.setAttribute(KohlsPOCConstant.A_PSA_REPLICATION_SEQ, getPSAReplicationSequence);
        KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SRVC_CREATE_PSA_OFFLINE_Q, inputKohlsPsaOfflineQDoc);
        logger.debug("KohlsPSARefund.populatePsaOfflineForPsaStatus---End");
    }

    /**
     * MAD-341 changes.
     * 
     * @param env
     * @return
     * @throws Exception
     */
    private String getPSAReplicationSequence(YFSEnvironment env) throws Exception {
        logger.debug("KohlsPSARefund.getPSAReplicationSequence--Begin");
        Statement statement = null;
        ResultSet resultSet = null;
        YCPContext context = (YCPContext) env;
        Connection connection = context.getDBConnection();
        String strPSASeq = "";

        try {
            statement = connection.createStatement();
            resultSet = statement
                    .executeQuery("select SEQ_PSA_REPLICATION_SEQUENCE.nextval as PSAReplicationSeq from dual");
            resultSet.next();
            strPSASeq = resultSet.getString(KohlsPOCConstant.SEQ_PSA_REPLICATION_SEQ);
            logger.debug("PSA non sync sequence number is  :" + strPSASeq);
        } catch (SQLException sqle) {
            sqle.printStackTrace();

        } finally {
            try {

                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        logger.debug("KohlsPSARefund.getPSAReplicationSequence--End");
        return strPSASeq;
    }

    //CPE-5903 - Start
    private Document callPinPad(YFSEnvironment env, Element elePayment) throws Exception {
    	logger.beginTimer("KohlsPSARefund.callPinPad");
    	if (bIsDebugEnabled) {
    		logger.debug("Inside callPinPad method. Payment element is: "
    				+ XMLUtil.getElementXMLString(elePayment));
    	}
    	Document docPinpadResponse = null;
    	// Document docPSIInput = formInputForPSI(elePayment);
    	elePayment.setAttribute("OrderNo", sOrderNo);
    	// Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env,
    	// "getPSIStatusListForPOS",
    	// docPSIInput);
    	// if (bIsDebugEnabled) {
    	// logger.debug("Output from getPSIStatusListForPOS" +
    	// XMLUtil.getXMLString(docPSIStatusOut));
    	// }

    	// Element elePsiStatus = (Element)
    	// docPSIStatusOut.getElementsByTagName("PSIStatus").item(0);

    	timeTaken = 0.01;

    	// if (!YFCCommon.isVoid(elePsiStatus)) {
    	// YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
    	// NRSCCommercePSIStatusGenerator generator =
    	// new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
    	// PSIStatus psiStatus = generator.generatePSIStatus();
    	KohlsPoCPinPadOperations object = new KohlsPoCPinPadOperations();
    	long start = 0;
    	try {
    		start = System.currentTimeMillis();
    		logger.debug("KohlsPSARefund.callPinPad - start time is " + start);
    		// docPinpadResponse = request.doCreditRequest(psiStatus, request,
    		// elePayment);
    		docPinpadResponse = object.doCreditRequest(env, XMLUtil.getDocumentForElement(elePayment));
    		if (logger.isDebugEnabled()) {
    			logger.debug("Response from Pinpad is: " + XMLUtil.getXMLString(docPinpadResponse));
    		}

    	} catch (Exception e) {
    		logger.error(
    				"KohlsPSARefund.formAndCallInputToRecordExternalCharges Exception while calling pinpad: "
    						+ e.getMessage());
    	} finally {
    		long end = System.currentTimeMillis();
    		logger.debug("KohlsPSARefund.callPinPad - end time is " + end);
    		timeTaken = (end - start);
    	}
    	/*
    	 * } else { logger.error("Pinpad is not paired for Store: " + elePayment.getAttribute("StoreID")
    	 * + " and" + " Terminal: " + elePayment.getAttribute("TerminalID") +
    	 * ". Hence PSI Credit request is Skipped."); }
    	 */
    	logger.endTimer("KohlsPSARefund.callPinPad");

    	return docPinpadResponse;
    }

    private Document updatesklRecordExternalChargesWithPinpadResponse(Element elePaymentMethod,
    		Document docpinpadResponse, Document outDocformInputSklToRecordExternalCharges,
    		String strOrderHeaderKey, Document getPaymentListOutDoc, Map<String, String> mapKMCValues,
    		String sExtnPOCFeature, YFSEnvironment env) {
    	logger.beginTimer("KohlsReturnRefund.updatesklRecordExternalCharges");
    	try {
    		String strPaymentType = null;
    		String strCreditCardTypeNo = null;
    		String strCreditCardType = null;
    		String sCTRoutOutput = "";
    		String sAuthCode = "000000";
    		Element responseElement = null;
    		Element ctroutdElement = null;
    		Element eleAuthCode = null;

    		if (bIsDebugEnabled) {
    			logger.debug(
    					"KohlsReturnRefund.updatesklRecordExternalCharges formInputSklToRecordExternalCharges outDoc="
    							+ XMLUtil.getXMLString(outDocformInputSklToRecordExternalCharges));
    			logger.debug(
    					"KohlsReturnRefund.updatesklRecordExternalCharges paymentMethod element from gravity="
    							+ XMLUtil.getElementXMLString(elePaymentMethod));
    			logger.debug(
    					"KohlsReturnRefund.updatesklRecordExternalCharges OrderHeaderKey=" + strOrderHeaderKey);
    			logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges  PaymentList outDoc="
    					+ XMLUtil.getXMLString(getPaymentListOutDoc));
    		}
    		Element elePaymentMethodExtn =
    				(Element) elePaymentMethod.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
    		if (!YFCCommon.isVoid(docpinpadResponse)) {
    			responseElement = docpinpadResponse.getDocumentElement();
    			ctroutdElement = SCXmlUtil.getChildElement(responseElement, "CTROUTD");
    			eleAuthCode = SCXmlUtil.getChildElement(responseElement, "AUTH_CODE");
    			if (!YFCCommon.isVoid(ctroutdElement)) {
    				sCTRoutOutput = ctroutdElement.getTextContent();
    			}
    			if (!YFCCommon.isVoid(eleAuthCode)) {
    				sAuthCode = eleAuthCode.getTextContent();
    			}
    		}

    		Element eleRecordExternalCharges =
    				outDocformInputSklToRecordExternalCharges.getDocumentElement();

    		strPaymentType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
    		eleRecordExternalCharges.setAttribute("OrganizationCode",
    				elePaymentMethod.getAttribute("StoreID"));
    		eleRecordExternalCharges.setAttribute("StoreID", elePaymentMethod.getAttribute("StoreID"));
    		eleRecordExternalCharges.setAttribute("TerminalID",
    				elePaymentMethod.getAttribute("TerminalID"));

    		// CAPE-968 -- Start
    		Element elePaymentMeth =
    				SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    		Element elePaymentMethExtn = XMLUtil.getChildElement(elePaymentMeth, KohlsPOCConstant.E_EXTN);

    		if (!YFCCommon.isVoid(elePaymentMethExtn)) {
    			elePaymentMeth.removeChild(elePaymentMethExtn);
    		}

    		// CAPE-968 -- End

    		if (strPaymentType.equalsIgnoreCase("CASH")) {

    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);
    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);

    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			String strPayRef1 = getPayRef1();
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
    			String strRequestedAmount =
    					"-".concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

    			elePaymentMethod1.setAttribute("ChangeDue",
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			elePaymentMethod1.setAttribute("TotalRefundedAmount",
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);

    			if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
    				eleExtn.setAttribute("ExtnPaymentDetails",
    						elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
    			}
    			if (bIsDebugEnabled) {
    				logger.debug("KohlsPoCReturnRefund.updatesklRecordExternalCharges Cash");
    			}

    		}

    		if (strPaymentType.equalsIgnoreCase("CORPORATE_REFUND")) {
    			if (bIsDebugEnabled) {
    				logger.debug("KohlsPoCReturnRefund.updatesklRecordExternalCharges corporated refund");
    			}
    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);
    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			String strPayRef1 = getPayRef1();
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
    			String strRequestedAmount =
    					"-".concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

    			elePaymentMethod1.setAttribute("TotalRefundedAmount",
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			Element eleKohlsPaymentList =
    					(Element) elePaymentMethod1.getElementsByTagName("KohlsPaymentList").item(0);
    			Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
    			if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
    				eleExtn.setAttribute("ExtnPaymentDetails",
    						elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
    			}
    			// Changes For Person Info Bill To
    			outDocformInputSklToRecordExternalCharges = updateCapWithPersonInfo(docInXMLClone,
    					outDocformInputSklToRecordExternalCharges, sExtnPOCFeature);

    			Document docCommonCodeInput = formInputForCommonCode(docInXMLClone);
    			// Call getCommonCodeList api
    			Document docCommonCodeOutput = callGetCommonCodeList(env, docCommonCodeInput);
    			// Prepare the input for changeOrder api
    			Document docChangeOrderInput =
    					inputToChangeOrderCorporateRefund(docInXMLClone, docCommonCodeOutput);
    			// Call changeOrder api
    			Document docChangeOrderOutput = callChangeOrder(env, docChangeOrderInput);
    			if (!YFCCommon.isVoid(docChangeOrderOutput)) {
    				if (bIsDebugEnabled) {
    					logger.debug("KohlsReturnRefund.setFinalPSARefundTypes docChangeOrderOutput="
    							+ XMLUtil.getXMLString(docChangeOrderOutput));
    				}
    			}
    			// Set the global variable to false for
    			// future use
    			bIsCorpRefund = false;

    		}

    		if (strPaymentType.equalsIgnoreCase("KOHLS_CASH")) {

    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);
    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			String strPayRef1 = getPayRef1();
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);

    			String strRequestedAmount =
    					"-".concat("0.00");
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, "0.00");
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT,"0.00");

    			elePaymentMethod1.setAttribute("TotalRefundedAmount",
    					"0.00");




    			Element eleKohlsPaymentList =
    					(Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

    			Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
    			if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
    				eleExtn.setAttribute("ExtnPaymentDetails",
    						elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
    			}

    			if (bIsDebugEnabled) {
    				logger.debug("KohlsPoCReturnRefund.updatesklRecordExternalCharges Cash");
    			}

    		}

    		if (strPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_KMC)) {
    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);
    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    			String strPayRef1 = getPayRef1();
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1, strPayRef1);
    			if (!YFCCommon.isStringVoid(strKMCEntryMethod)) {
    				logger.debug("KMCEntryMethod is " + strKMCEntryMethod);
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2, strKMCEntryMethod);
    				elePaymentMethod1.setAttribute("EntryMethod", strKMCEntryMethod);

    			}
    			Element eleKohlsPaymentList =
    					(Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, "02");
    			String strRequestedAmount =
    					"-".concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_SVC_NO,
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_SVCNo));
    			elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
    					mapKMCValues.get(KohlsPOCConstant.ATTR_STORE_ID));
    			Element elePaymentMethod1Extn =
    					XMLUtil.createChild(elePaymentMethod1, KohlsXMLLiterals.E_EXTN);
    			elePaymentMethod1Extn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE,
    					mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE));
    			elePaymentMethod1Extn.setAttribute(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE,
    					mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE));
    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
    			String strAuthCode = mapKMCValues.get(KohlsXMLLiterals.A_AUTH_CODE);
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_CODE, strAuthCode);
    			if (!KohlsPOCConstant.N_PG_SUCCESS.equals(strAuthCode)) {
    				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT,
    						KohlsPOCConstant.ZERO);
    				if (strAuthCode.equals(KohlsPOCConstant.OFFLINE)) {
    					elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE,
    							KohlsPOCConstant.OFFLINE);
    				} else {
    					elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE,
    							KohlsXMLLiterals.ATTR_DECLINED);
    				}
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_SUSPEND_ANY_MORE_CHARGES,
    						KohlsXMLLiterals.CONST_Y);
    				elePaymentMethod1.setAttribute("TotalRefundedAmount", KohlsPOCConstant.ZERO);
    			} else {
    				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);
    				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE, "SUCCESS");
    				elePaymentMethod1.setAttribute("TotalRefundedAmount",
    						elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    				// Element eleExtn = XMLUtil.createChild(elePaymentMethod1,
    				// KohlsPOCConstant.A_EXTN);
    				if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
    					elePaymentMethod1Extn.setAttribute("ExtnPaymentDetails",
    							elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
    				}
    			}
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE,
    					mapKMCValues.get(KohlsXMLLiterals.A_INTERNAL_RETURN_MESSAGE));
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_INTERNAL_RETURN_CODE,
    					mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_AUTH_RESPONSE_CODE));

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_TRAN_RETURN_MESSAGE,
    					mapKMCValues.get(KohlsXMLLiterals.A_EXTN_KMC_REMAINING_BALANCE));


    			elePaymentMethod1Extn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

    		}

    		if (strPaymentType.equalsIgnoreCase(KohlsXMLLiterals.ATTR_CREDIT_CARD)) {
    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);
    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    			Element eleKohlsPaymentList =
    					(Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

    			String strCreditCardNo = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
    			String strCreditExpDate =
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, strCreditExpDate);
    			int iSize = strCreditCardNo.length();
    			if (bIsDebugEnabled) {
    				logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges isize=" + iSize);
    			}
    			Element elePayment = null;
    			String strTrimCreditCardNo = strCreditCardNo.substring(iSize - 4, iSize);

    			Element elePaymentList = getPaymentListOutDoc.getDocumentElement();
    			String strTotalNo = elePaymentList.getAttribute("TotalNumberOfRecords");
    			if (!YFCCommon.isVoid(strTotalNo) && Integer.parseInt(strTotalNo) > 0) {
    				elePayment = SCXmlUtil.getXpathElement(elePaymentList,
    						"Payment[@DisplayCreditCardNo='" + strTrimCreditCardNo + "']");
    			}
    			strCreditCardType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
    			strCreditCardTypeNo = changeCreditCardType(strCreditCardType);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, strCreditCardTypeNo);
    			if (!YFCCommon.isVoid(elePayment)) {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
    						elePayment.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO));
    			} else {

    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
    						strTrimCreditCardNo);

    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
    						elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
    			} else {

    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, strCreditCardNo);
    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				String sFirstName = elePayment.getAttribute(KohlsPOCConstant.ATTR_FIRST_NAME);
    				if (!YFCCommon.isStringVoid(sFirstName)) {
    					if (bIsDebugEnabled) {
    						logger.debug(
    								"KohlsReturnRefund.updatesklRecordExternalCharges sFirstName" + sFirstName);
    					}
    					elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_FIRST_NAME, sFirstName);
    				}
    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				String sLastName = elePayment.getAttribute(KohlsPOCConstant.ATTR_LAST_NAME);
    				if (!YFCCommon.isStringVoid(sLastName)) {
    					if (bIsDebugEnabled) {
    						logger
    						.debug("KohlsReturnRefund.updatesklRecordExternalCharges sLastName" + sLastName);
    					}
    					elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_LAST_NAME, sLastName);
    				}
    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
    						elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));

    			}
    			if (!YFCCommon.isVoid(sCTRoutOutput)) {
    				elePaymentMethod1.setAttribute("ExtraDetails10", sCTRoutOutput);
    			}
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			String strRequestedAmount =
    					KohlsPOCConstant.MINUS.concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);

    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);

    			elePaymentMethod1.setAttribute("TotalRefundedAmount",
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));

    			Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
    			eleExtn.setAttribute("ExtnPSIPayment", "Y");
    			eleExtn.setAttribute("ExtnApprovedAmount", strRequestedAmount);
    			eleExtn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");
    			if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
    				eleExtn.setAttribute("ExtnPaymentDetails",
    						elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
    			}
    			elePaymentDetails.setAttribute("AuthorizationID", sAuthCode);
    			elePaymentDetails.setAttribute("InternalReturnCode", "00");
    			elePaymentDetails.setAttribute("InPerson", "Y");
    			//CAPE-4074 - start
    			if(!YFCCommon.isVoid(elePaymentMethod.getAttribute("EntryMethod"))){
    				elePaymentMethod1.setAttribute("EntryMethod", elePaymentMethod.getAttribute("EntryMethod"));
    			} else {
    				elePaymentMethod1.setAttribute("EntryMethod", "SWIPED");
    			}
    			//CAPE-4074 - end
    			elePaymentMethod1.setAttribute("ExtraDetails7", "CREDIT");
    			elePaymentMethod1.setAttribute("IsExternalPayment", "Y");

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

    		}

    		// CAPE-263 -- Start -- Murali K

    		if (strPaymentType.equalsIgnoreCase("DEBIT_CARD")) {

    			Element elePayment = null;
    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);

    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    			Element eleKohlsPaymentList =
    					(Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

    			String strCreditCardNo = elePaymentMethod.getAttribute("DebitCardNo");
    			String strCreditExpDate =
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);

    			String strRequestedAmount =
    					KohlsPOCConstant.MINUS.concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			int iSize = strCreditCardNo.length();

    			String strTrimDebitCardNo = strCreditCardNo.substring(iSize - 4, iSize);

    			if (bIsDebugEnabled) {
    				logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges isize=" + iSize);
    			}

    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, strCreditExpDate);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE, "19");
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			elePaymentMethod1.setAttribute("DebitCardNo", strCreditCardNo);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);
    			elePaymentMethod1.setAttribute("TotalRefundedAmount",
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			//CAPE-4074 - start
    			if(!YFCCommon.isVoid(elePaymentMethod.getAttribute("EntryMethod"))){
    				elePaymentMethod1.setAttribute("EntryMethod", elePaymentMethod.getAttribute("EntryMethod"));
    			} else {
    				elePaymentMethod1.setAttribute("EntryMethod", "SWIPED");
    			}
    			//CAPE-4074 - end
    			elePaymentMethod1.setAttribute("ExtraDetails7", "DEBIT");
    			elePaymentMethod1.setAttribute("IsExternalPayment", "Y");
    			elePaymentMethod1.setAttribute("AccountType", "Terminal");

    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);
    			elePaymentDetails.setAttribute("AuthorizationID", "000000");
    			elePaymentDetails.setAttribute("InternalReturnCode", "00");
    			elePaymentDetails.setAttribute("InPerson", "Y");
    			elePaymentDetails.setAttribute("OfflineStatus", "N");
    			elePaymentDetails.setAttribute("InternalReturnCode", "F0");
    			elePaymentDetails.setAttribute("ChargeType", "CHARGE");

    			Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
    			eleExtn.setAttribute("ExtnPSIPayment", "Y");
    			eleExtn.setAttribute("ExtnApprovedAmount", strRequestedAmount);
    			eleExtn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");
    			if (!YFCCommon.isVoid(eleKohlsPaymentList))

    			{

    				eleExtn.setAttribute("ExtnPaymentDetails",
    						XMLUtil.getElementXMLString(eleKohlsPaymentList));
    			}

    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
    					strTrimDebitCardNo);

    		}

    		// CAPE -263 --End - Murali K
    		if (strPaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD)) {
    			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
    					strOrderHeaderKey);
    			Element elePaymentMethod1 =
    					SCXmlUtil.getXpathElement(eleRecordExternalCharges, KohlsXMLLiterals.E_PAYMENT_METHOD);
    			Element elePayment = null;
    			String strCreditCardNo = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
    			String strCreditExpDate =
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE, strCreditExpDate);
    			int iSize = strCreditCardNo.length();
    			if (bIsDebugEnabled) {
    				logger.debug("KohlsReturnRefund.updatesklRecordExternalCharges isize=" + iSize);
    			}
    			Element eleKohlsPaymentList =
    					(Element) elePaymentMethod.getElementsByTagName("KohlsPaymentList").item(0);

    			String strTrimCreditCardNo = strCreditCardNo.substring(iSize - 4, iSize);
    			if (getPaymentListOutDoc.getDocumentElement() != null) {
    				Element elePaymentList = getPaymentListOutDoc.getDocumentElement();
    				elePayment = SCXmlUtil.getXpathElement(elePaymentList,
    						"Payment[@DisplayCreditCardNo='" + strTrimCreditCardNo + "']");
    			}
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE,
    					KohlsXMLLiterals.ATTR_ZERO_FOUR);

    			if (!YFCCommon.isVoid(elePayment)) {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
    						elePayment.getAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO));
    			} else {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_DISPLAY_CREDIT_CARD_NO,
    						strTrimCreditCardNo);
    			}

    			if (!YFCCommon.isVoid(elePayment)) {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
    						elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
    			} else {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO, strCreditCardNo);
    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
    						elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				String sFirstName = elePayment.getAttribute(KohlsPOCConstant.ATTR_FIRST_NAME);
    				if (!YFCCommon.isStringVoid(sFirstName)) {
    					if (bIsDebugEnabled) {
    						logger.debug(
    								"KohlsReturnRefund.updatesklRecordExternalCharges sFirstName" + sFirstName);
    					}
    					elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_FIRST_NAME, sFirstName);
    				}
    			}
    			if (!YFCCommon.isVoid(elePayment)) {
    				String sLastName = elePayment.getAttribute(KohlsPOCConstant.ATTR_LAST_NAME);
    				if (!YFCCommon.isStringVoid(sLastName)) {
    					if (bIsDebugEnabled) {
    						logger
    						.debug("KohlsReturnRefund.updatesklRecordExternalCharges sLastName" + sLastName);
    					}
    					elePaymentMethod1.setAttribute(KohlsPOCConstant.ATTR_LAST_NAME, sLastName);
    				}
    			}
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, strPaymentType);
    			String strRequestedAmount =
    					KohlsPOCConstant.MINUS.concat(elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
    			elePaymentMethod1.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, strRequestedAmount);

    			Element elePaymentDetailsList =
    					SCXmlUtil.getXpathElement(elePaymentMethod1, KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
    			Element elePaymentDetails =
    					SCXmlUtil.getXpathElement(elePaymentDetailsList, KohlsXMLLiterals.E_PAYMENT_DETAILS);
    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, strRequestedAmount);

    			elePaymentMethod1.setAttribute("TotalRefundedAmount",
    					elePaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));

    			Element eleExtn = XMLUtil.createChild(elePaymentMethod1, KohlsPOCConstant.A_EXTN);
    			if (!YFCCommon.isVoid(elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"))) {
    				eleExtn.setAttribute("ExtnPaymentDetails",
    						elePaymentMethodExtn.getAttribute("ExtnPaymentDetails"));
    			}
    			eleExtn.setAttribute("ExtnPSIPayment", "Y");
    			eleExtn.setAttribute("ExtnApprovedAmount", strRequestedAmount);
    			eleExtn.setAttribute("ExtnAuthTimeTaken", timeTaken + "");

    			elePaymentDetails.setAttribute("AuthorizationID", sAuthCode);
    			elePaymentDetails.setAttribute("InternalReturnCode", "00");
    			elePaymentDetails.setAttribute("InPerson", "Y");

    			//CAPE-4074 - start
    			if(!YFCCommon.isVoid(elePaymentMethod.getAttribute("EntryMethod"))){
    				elePaymentMethod1.setAttribute("EntryMethod", elePaymentMethod.getAttribute("EntryMethod"));
    			} else {
    				elePaymentMethod1.setAttribute("EntryMethod", "SWIPED");
    			}
    			//CAPE-4074 - end
    			elePaymentMethod1.setAttribute("ExtraDetails7", "CREDIT");
    			elePaymentMethod1.setAttribute("IsExternalPayment", "Y");
    			if (!YFCCommon.isVoid(sCTRoutOutput)) {
    				elePaymentMethod1.setAttribute("ExtraDetails10", sCTRoutOutput);
    			}

    			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, strRequestedAmount);

    		}
    	} catch (Exception e) {
    		logger.error("Exception in the updatesklRecordExternalCharges Method:" + e.getMessage());
    	}
    	if (bIsDebugEnabled) {
    		logger.debug(
    				"KohlsReturnRefund.updatesklRecordExternalCharges  updatesklRecordExternalCharges  outDoc="
    						+ XMLUtil.getXMLString(outDocformInputSklToRecordExternalCharges));
    	}
    	logger.endTimer("KohlsReturnRefund.updatesklRecordExternalCharges");
    	return outDocformInputSklToRecordExternalCharges;
    }

    private Document updateCapWithPersonInfo(Document inDocGravity,
    		Document outUpdateInputToCapturePayment, String sExtnPOCFeature) {
    	logger.beginTimer("KohlsReturnRefund.updateCapWithPersonInfo");
    	if (bIsDebugEnabled) {
    		logger.debug("KohlsReturnRefund.updateCapWithPersonInfo -- Start");
    		logger.debug("KohlsReturnRefund.updateCapWithPersonInfo inDocGravity="
    				+ XMLUtil.getXMLString(inDocGravity) + " outUpdateInputToCapturePayment="
    				+ XMLUtil.getXMLString(outUpdateInputToCapturePayment));
    	}
    	try {
    		Element inDocOrder = inDocGravity.getDocumentElement();
    		Element inDocCapturePaymentMethod = null;
    		Element inDocPaymentMethod = SCXmlUtil.getXpathElement(inDocOrder,
    				"PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
    		Element inDocCapturePayment = outUpdateInputToCapturePayment.getDocumentElement();

    		inDocCapturePaymentMethod = SCXmlUtil.getXpathElement(inDocCapturePayment,
    				"PaymentMethod[@PaymentType='CORPORATE_REFUND']");

    		if ((!YFCCommon.isVoid(inDocCapturePaymentMethod))
    				&& (!YFCCommon.isVoid(inDocPaymentMethod))) {
    			Element eleInDocCapturePersonInfoBillTo =
    					XMLUtil.createChild(inDocCapturePaymentMethod, KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
    			String strExtnEmailAddress = inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_1,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS).toUpperCase());
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_2,
    					KohlsPOCConstant.BLANK);
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_3,
    					KohlsPOCConstant.BLANK);
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_4,
    					KohlsPOCConstant.BLANK);
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_CITY,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_CITY).toUpperCase());
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_COUNTRY,
    					KohlsPOCConstant.BLANK);
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_DAY_PHONE,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
    			if (!YFCCommon.isStringVoid(strExtnEmailAddress)) {
    				eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_EMAIL_ID,
    						strExtnEmailAddress);
    			}
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_FIRST_NAME,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_FIRST_NAME).toUpperCase());
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_LAST_NAME,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_LAST_NAME).toUpperCase());
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_MOBILE_PHONE,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO));
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_STATE,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_STATE).toUpperCase());
    			eleInDocCapturePersonInfoBillTo.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
    			Element eleInDocCapturePersonInfoBillToExtn =
    					XMLUtil.createChild(eleInDocCapturePersonInfoBillTo, KohlsXMLLiterals.E_EXTN);
    			eleInDocCapturePersonInfoBillToExtn.setAttribute(KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE,
    					inDocPaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE));
    			bIsCorpRefund = true;
    		}
    	} catch (Exception e) {
    		logger.error("Exception in the updateCapWithPersonInfo Method:" + e.getMessage());
    		logger.endTimer("KohlsReturnRefund.updateCapWithPersonInfo");
    	}
    	if (bIsDebugEnabled) {
    		logger.debug("KohlsReturnRefund.updateCapWithPersonInfo outDoc="
    				+ XMLUtil.getXMLString(outUpdateInputToCapturePayment));
    		logger.debug("KohlsReturnRefund.updateCapWithPersonInfo -- End");
    	}
    	logger.endTimer("KohlsReturnRefund.updateCapWithPersonInfo");
    	return outUpdateInputToCapturePayment;
    }


    //CPE-5903 - End
	
}
