package com.kohls.poc.psa.api;

import java.text.ParseException;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
//import com.kohls.poc.test.testTVS.KohlsPSATVSHelper;
import com.kohls.poc.psa.api.KohlsPSATVSHelper;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * This Class prepares the request for TVS call (for only kohlsCash Eligible
 * Items).
 * 
 * @author SA345825
 *
 */
@SuppressWarnings("deprecation")
public class KohlsTVSCallForKohlsCashEligibleItems {

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory
				.instance(KohlsTVSCallForKohlsCashEligibleItems.class.getName());
	}

	KohlsPSATVSHelper objTVSHelper = new KohlsPSATVSHelper();

	/**
	 * This Method prepares the request to call TVS web service for KohlsCash
	 * eligible items.
	 * 
	 * @param env
	 * @param outDocKohlsCashWebService
	 * @param tempOrderEle
	 * @param refundReduction
	 * @return tvsResponseDoc
	 * @throws Exception
	 */
	public Document prepareRequestForFirstTVSCall(YFSEnvironment env,
			Document outDocKohlsCashWebService, Element tempOrderEle,
			Element refundReduction) throws Exception {

		Document tvsResponseDoc = null;

		// Prepare TVS request document.
		Document firstTVSRequestDoc = XMLUtil
				.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
		Element priceRequestEle = firstTVSRequestDoc.getDocumentElement();
		priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
		priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");
		Element transactionEle = XMLUtil.createChild(priceRequestEle,
				KohlsPOCConstant.ORIGINAL_TRANSACTION);

		// Adding transactionId , store number and store address to TVS request
		objTVSHelper.createConstantEleForTVSReq(env, tempOrderEle,
				transactionEle);

		// Adding lidOfferExempt to TVS request
		Element promotionsEle = XMLUtil.getChildElement(tempOrderEle,
				KohlsPOCConstant.E_PROMOTIONS);
		Element lidOfferExempt = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.LID_OFFER_EXEMPT);
		objTVSHelper.constructLidOfferExemptPSA(promotionsEle, lidOfferExempt,
				tempOrderEle);

		// Adding itemList Element to TVS request.
		Element itemListEle = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ATTR_ITEM_LIST);

		// Adding Kohls cash eligible items to the TVS request.
		Element eleKCSOutput = outDocKohlsCashWebService.getDocumentElement();
		if (!YFCCommon.isVoid(eleKCSOutput)) {

			checkForKCEligibleItems(env, eleKCSOutput, tempOrderEle, itemListEle);
			Element offersEle = XMLUtil.createChild(transactionEle,
					KohlsPOCConstant.ELEM_OFFERS);
			createManualTLD(transactionEle, refundReduction);

		}

		// Adding exclusions in TVS request
		KohlsPoCPnPUtil.constructExclusionsForRefundDeduction(env,
				transactionEle);

		// Adding adjustments in TVS request
		Element adjustments = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ADJUSTMENS);

		// Adding taxExempt in TVS request
		String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle,
				KohlsPOCConstant.TAX_EXEMPT_FLAG);
		String strTaxExemptCert = XMLUtil.getAttribute(tempOrderEle,
				KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

		if (!YFCCommon.isVoid(strTaxExemptCert)
				|| strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES)) {
			Element eleTaxExempt = XMLUtil.createChild(transactionEle,
					KohlsPOCConstant.ATTR_TAX_EXEMPT);
			XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
		} else {
			Element eleTaxExempt = XMLUtil.createChild(transactionEle,
					KohlsPOCConstant.ATTR_TAX_EXEMPT);
			XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);
		}
		logger.debug("Input to first TVS call for PSA ::"
				+ XMLUtil.getXMLString(firstTVSRequestDoc));
		tvsResponseDoc = objTVSHelper.callPSATVSWebService(env, tvsResponseDoc,
				firstTVSRequestDoc);

		return objTVSHelper.validateTVSResponse(tvsResponseDoc);
	}

	/**
	 * 
	 * @param transactionEle
	 * @param eleRefundDeduction
	 * @throws ParseException
	 * @throws Exception
	 */
	private void createManualTLD(Element transactionEle,
			Element eleRefundDeduction) throws ParseException, Exception {
		Element manualTLDEle = XMLUtil.createChild(transactionEle,
				KohlsPOCConstant.ELE_MANUAL_TLD);
		Element elePromoId = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.ATTR_ID);
		int i = KohlsPOCConstant.TLD_ID;
		int j = KohlsPOCConstant.ONE_INT;
		String strRefundDeduction = XMLUtil.getNodeValue(eleRefundDeduction);
		String ordPromotionID = (String) (Integer.toString(i + j));
		XMLUtil.setNodeValue(elePromoId, ordPromotionID);
		Element eleScanOrder = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.ATTR_SCAN_ORDER);
		XMLUtil.setNodeValue(eleScanOrder, KohlsConstant.STRING_ONE);

		Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
		XMLUtil.setNodeValue(eleMarkDownValue, strRefundDeduction);
		Element eleDiscountType = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
		XMLUtil.setNodeValue(eleDiscountType,
				KohlsPOCConstant.MANUAL_DOLLAR_OFF);
		Element eleGift = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.ATT_GIFT);
		XMLUtil.setNodeValue(eleGift, KohlsPOCConstant.YES);
		Element eleLegacyFlag = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.ATTR_LEGACY_FLAG);
		XMLUtil.setNodeValue(eleLegacyFlag, KohlsPOCConstant.YES);
		Element eleIEIndicator = XMLUtil.createChild(manualTLDEle,
				KohlsPOCConstant.A_IE_INDICATOR);
		XMLUtil.setNodeValue(eleIEIndicator, "None");
	}

	/**
	 * This Method checks for Kohls cash eligible items from the KCS response.
	 * 
	 * @param eleKCSOutput
	 * @param tempOrderEle
	 * @param itemListEle
	 * @throws YFSException
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private void checkForKCEligibleItems(YFSEnvironment env, Element eleKCSOutput,
			Element tempOrderEle, Element itemListEle) throws YFSException,
			Exception {

		Element eleData = (Element) eleKCSOutput.getElementsByTagName("Data")
				.item(0);
		if (!YFCCommon.isVoid(eleData)) {
			Element eleReturnableItemList = XMLUtil.getChildElement(eleData,
					KohlsXMLLiterals.E_RETURNABLE_ITEMLIST);
			if (!YFCCommon.isVoid(eleReturnableItemList)) {
				List<Element> returnableItemList = XMLUtil
						.getElementsByTagName(eleReturnableItemList,
								KohlsXMLLiterals.E_RETURNABLE_ITEM);
				for (Element returnableItem : returnableItemList) {
					Element eleKohlsCashEligible = XMLUtil.getChildElement(
							returnableItem,
							KohlsXMLLiterals.E_KOHLS_CASH_ELIGIBLE);
					String strKohlsCashEligible = XMLUtil
							.getNodeValue(eleKohlsCashEligible);
					if ((KohlsPOCConstant.TRUE)
							.equalsIgnoreCase(strKohlsCashEligible)) {
						// If the Item is kohls cash eligible , add it to the
						// TVS request.
						createReqForKCEligibleItems(env, tempOrderEle, itemListEle,
								returnableItem);
					}
				}
			}
		}
	}

	/**
	 * 
	 * @param tempOrderEle
	 * @param itemListEle
	 * @param returnableItem
	 * @throws YFSException
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	private void createReqForKCEligibleItems(YFSEnvironment env, Element tempOrderEle,
			Element itemListEle, Element returnableItem) throws YFSException,
			Exception {
		Element eleOutputItem = XMLUtil.createChild(itemListEle,
				KohlsPOCConstant.ELEM_SMALL_ITEM);
		Element eleLineNo = XMLUtil.getChildElement(returnableItem,
				KohlsXMLLiterals.E_LINE_NO);
		String strLineNo = XMLUtil.getNodeValue(eleLineNo);

		// Fetching only those orderLines from the getOrderList output which are
		// KholsCash eligible.
		Element eleKCEligibleOrderLine = SCXmlUtil.getXpathElement(
				tempOrderEle, "OrderLines/OrderLine[@PrimeLineNo=" + strLineNo
						+ "]");
		Element eleKCOrderLineExtn = XMLUtil.getChildElement(
				eleKCEligibleOrderLine, KohlsXMLLiterals.E_EXTN);

		// contruction of sku Element
		Element ordLineItemEle = XMLUtil.getChildElement(
				eleKCEligibleOrderLine, KohlsXMLLiterals.E_ITEM);
		String strItemId = ordLineItemEle
				.getAttribute(KohlsPOCConstant.A_ITEM_ID);
		String createTS = ordLineItemEle
				.getAttribute(KohlsPOCConstant.A_CREATE_TS);
		Element eleSku = XMLUtil.createChild(eleOutputItem,
				KohlsPOCConstant.ATTR_SKU);
		XMLUtil.setNodeValue(eleSku, strItemId);

		// contruction of id Element
		Element eleId = XMLUtil.createChild(eleOutputItem,
				KohlsPOCConstant.ATTR_ID);
		if (!YFCCommon.isVoid(eleKCEligibleOrderLine)) {
			String strPrimeLineNo = eleKCEligibleOrderLine
					.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO);
			XMLUtil.setNodeValue(eleId, strPrimeLineNo);
		}

		objTVSHelper.createMerchandiseHierarchy(eleOutputItem,
				eleKCOrderLineExtn);
		objTVSHelper.createTaxAttributes(eleKCEligibleOrderLine,
				eleKCOrderLineExtn, eleOutputItem);

		// contruction of regularPrice Element
		Element eleOrderLevelPromotions = null;
		if (!YFCCommon.isVoid(tempOrderEle)) {
			eleOrderLevelPromotions = XMLUtil.getChildElement(tempOrderEle,
					KohlsXMLLiterals.E_PROMOTIONS);
		}
		Double dFinalPrice = objTVSHelper.calculateItemNetPrice(env,
				eleKCEligibleOrderLine, eleOrderLevelPromotions);
		Element eleRegPrice = XMLUtil.createChild(eleOutputItem,
				KohlsPOCConstant.ATTR_REGULAR_PRICE);
		XMLUtil.setNodeValue(eleRegPrice, Double.toString(dFinalPrice));

		// contruction of regularPriceStatus Element
		String SKUStatusCode = XMLUtil.getAttribute(eleKCOrderLineExtn,
				KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
		Element regularPriceStatusElement = XMLUtil.createChild(eleOutputItem,
				KohlsPOCConstant.REGULAR_PRICE_STATUS);
		XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);

		// contruction of empDiscCode Element
		Boolean bEmpDiscCode = false;
		Element eleEmpDiscCode = XMLUtil.createChild(eleOutputItem,
				KohlsPOCConstant.ATTR_EMP_DISC_CODE);
		Element eleReference = (Element) KohlsXPathUtil.getNode(
				eleKCEligibleOrderLine,
				"./References/Reference[@Name='ExtnEmpDiscCode']");
		if (!YFCCommon.isVoid(eleReference)) {
			if (!YFCCommon.isVoid(eleReference
					.getAttribute(KohlsPOCConstant.A_VALUE))) {
				XMLUtil.setNodeValue(eleEmpDiscCode,
						eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
				bEmpDiscCode = true;
			}
		}
		if (!bEmpDiscCode) {
			XMLUtil.setNodeValue(eleEmpDiscCode, KohlsPOCConstant.CONST_S);
		}
		// contruction of scanTime Element
		Element eleScanTime = XMLUtil.createChild(eleOutputItem,
				KohlsPOCConstant.ATTR_SCAN_TIME);

		if (!YFCCommon.isStringVoid(createTS)) {
			XMLUtil.setNodeValue(eleScanTime, createTS);
		} else {
			YFCDate date = new YFCDate();
			String sCreateTimeStamp = date.getString(null, true);
			XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
		}
	}
}
