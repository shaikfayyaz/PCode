package com.kohls.poc.psa.ue;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.OMPConfirmRefundDistributionUE;

/**
 * @author SA345825
 *
 */
public class KohlsPSAOMPConfirmRefundDistributionUE implements
		OMPConfirmRefundDistributionUE {

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory
				.instance(KohlsPSAOMPConfirmRefundDistributionUE.class
						.getName());
	}

	@Override
	public Document confirmRefundDistribution(YFSEnvironment env, Document inXML)
			throws YFSUserExitException {
		
		
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.confirmRefundDistribution -- Start");
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.confirmRefundDistribution inXML="+XMLUtil.getXMLString(inXML));
		}
		
		Document docPSAOutput = inXML;
		Document docTxnOrder = (Document) env.getTxnObject("PSARefund");
		if (!YFCCommon.isVoid(docTxnOrder)) {
			
			
			if(logger.isDebugEnabled())
				logger.debug(" Txn Object 'PSARefund' document::"+ XMLUtil.getXMLString(docTxnOrder));
			
			Element eleTxnOrder = docTxnOrder.getDocumentElement();
			if (!YFCCommon.isVoid(eleTxnOrder)) {
				try {
					docPSAOutput = finalPSARefund(env, inXML, eleTxnOrder);
					
					
					if(logger.isDebugEnabled())
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.confirmRefundDistribution -- docPSAOutput="+XMLUtil.getXMLString(docPSAOutput));
				} catch (Exception e) {
					logger.error("Exception in KohlsPSAOMPConfirmRefundDistributionUE.confirmRefundDistribution, when calling PSARefund method:"
							+ e.getMessage());
				}
			}
		} else {
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.confirmRefundDistribution eleTxnOrder is null");
			return inXML;
		}
		return docPSAOutput;
	}

	/**
	 * @param env
	 * @param inXML
	 * @param eleTxnOrder
	 * @return Document
	 * @throws YFSUserExitException
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 */
	private Document finalPSARefund(YFSEnvironment env, Document inXML,
			Element eleTxnOrder) throws YFSUserExitException,
			ParserConfigurationException, TransformerException {
		
		
		if(logger.isDebugEnabled())
			logger.debug("Input to Method finalPSARefund ::"+ XMLUtil.getXMLString(inXML));
		Document docOutputXML = null;
		Document docGetOrderListOutput = null;

		Element eleOrder = (Element) inXML.getElementsByTagName(
				KohlsXMLLiterals.E_ORDER).item(0);
		String strOrderNo = eleOrder.getAttribute(KohlsXMLLiterals.A_ORDERNO);
		Element elePaymentMethods = (Element) eleOrder.getElementsByTagName(
				KohlsXMLLiterals.E_PAYMENT_METHODS).item(0);
		NodeList nlPaymentMethod = elePaymentMethods
				.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);

		// Prepare the Output document.
		docOutputXML = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER)
				.getDocument();
		Element eleOutputXMl = docOutputXML.getDocumentElement();
		eleOutputXMl.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE,
				KohlsConstant.SO_DOCUMENT_TYPE);
		eleOutputXMl.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE,
				KohlsConstant.KOHLS_RETAIL);
		eleOutputXMl.setAttribute(KohlsXMLLiterals.A_ORDERNO, strOrderNo);
		Element eleRefundPaymentMethods = docOutputXML
				.createElement(KohlsXMLLiterals.E_REFUND_PAYMENT_METHODS);
		eleOutputXMl.appendChild(eleRefundPaymentMethods);
		
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund "+XMLUtil.getXMLString(docOutputXML));
try{
		if (!YFCCommon.isVoid(eleTxnOrder)) {
			
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund eleTxnOrder="+XMLUtil.getElementXMLString(eleTxnOrder));
			
			String strTxnOrderHeaderKey = eleTxnOrder
					.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
			Element eleTxnPaymentMethods = (Element) eleTxnOrder
					.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS)
					.item(0);
			if (!YFCCommon.isVoid(eleTxnPaymentMethods)) {

				docGetOrderListOutput = callPSAgetOrderList(env,
						docGetOrderListOutput, strTxnOrderHeaderKey);
				
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Output of callPSAgetOrderList ="+XMLUtil.getXMLString(docGetOrderListOutput));
				
				NodeList nlTxnPaymentMethod = eleTxnPaymentMethods
						.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
				for (int iTxn = 0; iTxn < nlTxnPaymentMethod.getLength(); iTxn++) {
					Element eleTxnPaymentMethod = (Element) nlTxnPaymentMethod
							.item(iTxn);
					
					
					if(logger.isDebugEnabled())
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.confirmRefundDistribution  Current txnPaymentMethod="+XMLUtil.getElementXMLString(eleTxnPaymentMethod));

					// Setting RefundPaymentMethod element in the Output XML
					Element eleRefundPaymentMethod = docOutputXML
							.createElement(KohlsXMLLiterals.E_REFUND_PAYMENT_METHOD);
					eleRefundPaymentMethods.appendChild(eleRefundPaymentMethod);

					// Setting PaymentType in the Output XML
					String strTxnPaymentType = eleTxnPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
					if (!YFCCommon.isVoid(strTxnPaymentType)) {
						eleRefundPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_PAYMENT_TYPE,
								strTxnPaymentType);
					}

					// Setting RefundAmount in the Output XML
					String strRefundAmount = eleTxnPaymentMethod
							.getAttribute(KohlsXMLLiterals.A_AMOUNT);
					eleRefundPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_REFUND_AMOUNT, strRefundAmount);

					// Setting RefundForPaymentMethods element in the Output XML
					Element eleRefundForPaymentMethods = docOutputXML
							.createElement(KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHODS);
					eleRefundPaymentMethod
							.appendChild(eleRefundForPaymentMethods);

					// Setting RefundForPaymentMethod element in the Output XML
					NodeList nlSalePaymentMethodList = getSalePaymentMethodList(docGetOrderListOutput);
					logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund PaymentType="+strTxnPaymentType);
					if (KohlsConstant.PAYMENT_TYPE_CASH
							.equals(strTxnPaymentType)) {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund In Cash");
						createRefundForCash(eleRefundForPaymentMethods,
								strRefundAmount, nlSalePaymentMethodList);
					} else if (KohlsConstant.PAYMENTTYPE_CREDIT_CARD
							.equals(strTxnPaymentType)) {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund In CreditCard");
						String strCreditCardType = setCreditCardType(eleTxnPaymentMethod);
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund strCreditCardType"+strCreditCardType);
						String strCreditCardNo = eleTxnPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
						createRefundForCC(eleRefundForPaymentMethods,
								strCreditCardType, strCreditCardNo,
								strRefundAmount, nlSalePaymentMethodList);
					} else if (KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE
							.equals(strTxnPaymentType)) {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund In KohlsCharge");
						createRefundForKohlsCharge(eleRefundForPaymentMethods,
								strTxnPaymentType, strRefundAmount,
								nlSalePaymentMethodList);
					} else if (KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
							.equals(strTxnPaymentType)) {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund In KMC");
						String strConvertedFromCash = eleTxnPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_CONVERTED_FROM_CASH);
						String strConvertedFromCC = eleTxnPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_CONVERTED_FROM_CC);
						String strCreditCardType = setCreditCardType(eleTxnPaymentMethod);
						String ConvertedFromKohlsCharge = eleTxnPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_CONVERTED_FROM_KOHLS_CHARGE);
						String strConvertAllToKMC = eleTxnPaymentMethod
								.getAttribute(KohlsXMLLiterals.A_CONVERT_ALL_TO_KMC);
						
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund strConvertedFromCash="+strConvertedFromCash+
								     " strConvertedFromCC="+strConvertedFromCC+" strCreditCardType"+strCreditCardType+
								     " ConvertedFromKohlsCharge"+ConvertedFromKohlsCharge+" strConvertAllToKMC"+strConvertAllToKMC);
						
						if (YFCCommon.isVoid(strConvertedFromCash)
								&& YFCCommon.isVoid(strConvertedFromCC)
								&& YFCCommon.isVoid(ConvertedFromKohlsCharge)
								&& YFCCommon.isVoid(strConvertAllToKMC)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForKMC");
							createRefundForKMC(eleRefundForPaymentMethods,
									strRefundAmount, nlSalePaymentMethodList);
						} else if (KohlsConstant.YES
								.equalsIgnoreCase(strConvertAllToKMC)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForPaymentmethod");
							createRefundForPaymentmethod(
									eleRefundForPaymentMethods,
									strRefundAmount, nlSalePaymentMethodList);
						} else if (KohlsConstant.YES
								.equalsIgnoreCase(strConvertedFromCash)
								&& YFCCommon.isVoid(strConvertedFromCC)
								&& YFCCommon.isVoid(ConvertedFromKohlsCharge)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForCashKMC");
							createRefundForCashKMC(eleRefundForPaymentMethods,
									strRefundAmount, nlSalePaymentMethodList);
						} else if (KohlsConstant.YES
								.equalsIgnoreCase(strConvertedFromCC)
								&& YFCCommon.isVoid(strConvertedFromCash)
								&& YFCCommon.isVoid(ConvertedFromKohlsCharge)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForCCKMC");
							createRefundForCCKMC(eleRefundForPaymentMethods,
									strCreditCardType, strRefundAmount,
									nlSalePaymentMethodList);
						} else if (KohlsConstant.YES
								.equalsIgnoreCase(ConvertedFromKohlsCharge)
								&& YFCCommon.isVoid(strConvertedFromCash)
								&& YFCCommon.isVoid(strConvertedFromCC)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForKohlsChargeKMC");
							createRefundForKohlsChargeKMC(
									eleRefundForPaymentMethods,
									strRefundAmount, nlSalePaymentMethodList);
						} else if (KohlsConstant.YES
								.equalsIgnoreCase(strConvertedFromCash)
								&& KohlsConstant.YES
										.equalsIgnoreCase(strConvertedFromCC)
								&& YFCCommon.isVoid(ConvertedFromKohlsCharge)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForCashCCKMC");
							createRefundForCashCCKMC(
									eleRefundForPaymentMethods,
									strCreditCardType, strRefundAmount,
									nlSalePaymentMethodList);
						} else if (YFCCommon.isVoid(strConvertedFromCash)
								&& KohlsConstant.YES
										.equalsIgnoreCase(strConvertedFromCC)
								&& KohlsConstant.YES
										.equalsIgnoreCase(ConvertedFromKohlsCharge)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForCCKohlsChargeKMC");
							createRefundForCCKohlsChargeKMC(
									eleRefundForPaymentMethods,
									strCreditCardType, strRefundAmount,
									nlSalePaymentMethodList);
						} else if (KohlsConstant.YES
								.equalsIgnoreCase(strConvertedFromCash)
								&& YFCCommon.isVoid(strConvertedFromCC)
								&& KohlsConstant.YES
										.equalsIgnoreCase(ConvertedFromKohlsCharge)) {
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForCashKohlsChargeKMC");
							createRefundForCashKohlsChargeKMC(
									eleRefundForPaymentMethods,
									strRefundAmount, nlSalePaymentMethodList);
						}
					} else if (KohlsConstant.PAYMENT_TYPE_CORPORATE_REFUND
							.equals(strTxnPaymentType)) {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Calling createRefundForPaymentmethod");
						createRefundForPaymentmethod(
								eleRefundForPaymentMethods, strRefundAmount,
								nlSalePaymentMethodList);
					}
					for (int i = 0; i < nlPaymentMethod.getLength(); i++) {
						Element elemPaymentMethod = (Element) nlPaymentMethod
								.item(i);
						
						if(logger.isDebugEnabled())
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund Current elemPaymentMethod"+XMLUtil.getElementXMLString(elemPaymentMethod));
						if (!YFCCommon.isVoid(elemPaymentMethod)) {
							String strPaymenttye = elemPaymentMethod
									.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
							if (!YFCCommon.isVoid(strPaymenttye)
									&& strPaymenttye.equals(strTxnPaymentType)) {
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CHECK_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CHECK_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CHECK_REF,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CHECK_REF));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CREDIT_CARD_EXP_NAME,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_NAME));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CREDIT_CARD_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CREDIT_CARD_TYPE,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CUSTOMER_ACC_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CUSTOMER_ACC_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_CUSTOMER_PO_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_CUSTOMER_PO_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_DISP_CREDIT_CARD_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_DISP_CREDIT_CARD_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_DISPLAY_CUSTOMER_ACC_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_DISPLAY_CUSTOMER_ACC_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_DISP_PAYMENT_REF_1,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_DISP_PAYMENT_REF_1));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_DISPLAY_SVC_NO,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_DISPLAY_SVC_NO));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_FUNDS_AVAILABLE,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_FUNDS_AVAILABLE));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_GET_FUNDS_AVAILABLE_UE_INVOKED,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_GET_FUNDS_AVAILABLE_UE_INVOKED));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_PAYMENT_KEY,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_PAYMENT_REF_1,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_PAYMENT_REF_2,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2));
								eleRefundPaymentMethod
										.setAttribute(
												KohlsXMLLiterals.A_PAYMENT_REF_3,
												elemPaymentMethod
														.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_3));
								eleRefundPaymentMethod.setAttribute(
										KohlsXMLLiterals.A_PAYMENT_REF_6,
										KohlsConstant.PSA);
								
								if(logger.isDebugEnabled())
									logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund eleRefundPaymentMethod"+XMLUtil.getElementXMLString(eleRefundPaymentMethod));
							}
						}
					}

				}
			}
		}
}catch(Exception e){
	logger.error(e);
}
	
	if(logger.isDebugEnabled())
		logger.debug("Output of Method finalPSARefund ::"+ XMLUtil.getXMLString(docOutputXML));
	
		return docOutputXML;
	}

	/**
	 * @param eleTxnPaymentMethod
	 * @return
	 */
	public String setCreditCardType(Element eleTxnPaymentMethod) {
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.setCreditCardType --Start");
		String strCreditCardType = eleTxnPaymentMethod
				.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
		if (KohlsConstant.PSA_VISA.equalsIgnoreCase(strCreditCardType)) {
			strCreditCardType = KohlsConstant.VISA_05;
		} else if (KohlsConstant.PSA_MASTERCARD
				.equalsIgnoreCase(strCreditCardType)) {
			strCreditCardType = KohlsConstant.MASTERCARD_06;
		} else if (KohlsConstant.PSA_DISCOVER
				.equalsIgnoreCase(strCreditCardType)) {
			strCreditCardType = KohlsConstant.DISCOVER_07;
		} else if (KohlsConstant.PSA_AMEX.equalsIgnoreCase(strCreditCardType)) {
			strCreditCardType = KohlsConstant.AMEX_08;
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.setCreditCardType strCreditCardType"+strCreditCardType);
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.setCreditCardType --End");
		return strCreditCardType;
	}

	/**
	 * @param docGetOrderListOutput
	 */
	public NodeList getSalePaymentMethodList(Document docGetOrderListOutput) {
		
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.getSalePaymentMethodList -- Start");
		NodeList nlSalePaymentMethodList = null;
		
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.getSalePaymentMethodList docGetOrderListOutput="+XMLUtil.getXMLString(docGetOrderListOutput));
		
		try{
		if (!YFCCommon.isVoid(docGetOrderListOutput)) {
			Element eleGetOrderListOutput = docGetOrderListOutput
					.getDocumentElement();
			if (!YFCCommon.isVoid(eleGetOrderListOutput)) {
				nlSalePaymentMethodList = SCXmlUtil.getXpathNodes(
						eleGetOrderListOutput,
						"Order/PaymentMethods/PaymentMethod");
			}
		}
		}catch(Exception e){
			logger.error(e.getMessage());
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.getSalePaymentMethodList -- End");
		return nlSalePaymentMethodList;
	}

	/**
	 * @param env
	 * @param docGetOrderListOutput
	 * @param strTxnOrderHeaderKey
	 * @return
	 * @throws ParserConfigurationException
	 * @throws DOMException
	 */
	public Document callPSAgetOrderList(YFSEnvironment env,
			Document docGetOrderListOutput, String strTxnOrderHeaderKey)
			throws ParserConfigurationException, DOMException {
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.callPSAgetOrderList -- Start");
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.callPSAgetOrderList strTXNOrderHeader"+strTxnOrderHeaderKey);
		// Call getOrderList to get the sales payment methods
		Document docGetOrderListInput = XMLUtil
				.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleOrderInput = docGetOrderListInput.getDocumentElement();
		if (!YFCCommon.isVoid(strTxnOrderHeaderKey)) {
			eleOrderInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
					strTxnOrderHeaderKey);
			try {
				docGetOrderListOutput = KOHLSBaseApi.invokeService(env,
						KohlsConstant.PSA_GET_ORDER_LIST, docGetOrderListInput);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				logger.error("Exception in KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund, when calling PSAgetOrderList service"
						+ e1.getMessage());
			}
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.callPSAgetOrderList -- End");
		return docGetOrderListOutput;
	}

	/**
	 * This Method creates the RefundForPaymentMethods Element.
	 * 
	 * @param eleRefundPaymentMethods
	 * @param strRefundAmount
	 * @param nlSalePaymentMethods
	 */
	private void createRefundForKohlsCharge(Element eleRefundForPaymentMethods,
			String strTxnPaymentType, String strRefundAmount,
			NodeList nlSalePaymentMethods) {
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKohlsCharge -- Start");
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKohlsCharge eleRefundForPaymentMethods="+eleRefundForPaymentMethods+" strTxnPaymentType="+strTxnPaymentType+" strRefundAmount="+strRefundAmount);

		String strSalePaymentType = null;

		try {
		Element eleRefundForPaymentMethod = XMLUtil.createChild(
				eleRefundForPaymentMethods,
				KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
		eleRefundForPaymentMethods.appendChild(eleRefundForPaymentMethod);
		for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
			Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
					.item(i);
			strSalePaymentType = eleSalePaymentMethod
					.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
			if (!YFCCommon.isVoid(strSalePaymentType)) {
				if (strTxnPaymentType.equalsIgnoreCase(strSalePaymentType)) {
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);
					eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								strRefundAmount);
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKohlsCharge -- End");
		
	}

	private void createRefundForCash(Element eleRefundForPaymentMethods,
			String strRefundAmount, NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		
		
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash -- Start");
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash eleRefundForPaymentMethods="+XMLUtil.getElementXMLString(eleRefundForPaymentMethods)+" strRefundAmount="+strRefundAmount);
		}
		try {
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
				logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash dRefundAmount="+dRefundAmount);
		}
		while (dRefundAmount != 0) {
				logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash inside While dRefundAmount="+dRefundAmount);
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash current eleSalePaymentMethod"+XMLUtil.getElementXMLString(eleSalePaymentMethod));
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				if (KohlsConstant.PAYMENT_TYPE_CASH.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_TRAVELERS_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENTTYPE_DEBIT_CARD
								.equals(strPaymentType)) {

						Element eleRefundForPaymentMethod = XMLUtil
								.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
							
							strRefundAmount=String.format("%.2f", dRefundAmount);
							strTotalCharged=String.format("%.2f", dTotalCharged);
							dRefundAmount=Double.parseDouble(strRefundAmount);
							dTotalCharged=Double.parseDouble(strTotalCharged);	
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash dRefundAmount="+dRefundAmount+" dTotalCharged="+dTotalCharged);
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
							strRefundAmount=String.format("%.2f", dRefundAmount);
							strTotalCharged=String.format("%.2f", dTotalCharged);
							dRefundAmount=Double.parseDouble(strRefundAmount);
							dTotalCharged=Double.parseDouble(strTotalCharged);	
							logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash dRefundAmount="+dRefundAmount+" dTotalCharged="+dTotalCharged);
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCash -- Start");
	}

	private void createRefundForCC(Element eleRefundForPaymentMethods,
			String strCreditCardType, String strCreditCardNo,
			String strRefundAmount, NodeList nlSalePaymentMethods) {
logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC -- Start");

logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC eleRefundForPaymentMethods="+eleRefundForPaymentMethods+" strCreditCardType="+strCreditCardType+" strCreditCardNo="+strCreditCardNo+" strRefundAmount="+strRefundAmount);
		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC dRefundAmount="+dRefundAmount);
		}
	
	while (dRefundAmount != 0.0) {

			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC Inside While dRefundAmount="+dRefundAmount);
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC eleSalePaymentMethod"+XMLUtil.getElementXMLString(eleSalePaymentMethod));
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				String strSaleCreditCardType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
				String strSaleCreditCardNo = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
				if (KohlsConstant.PAYMENTTYPE_CREDIT_CARD
						.equals(strPaymentType)
						&& strCreditCardType.equals(strSaleCreditCardType)
						&& strCreditCardNo.equals(strSaleCreditCardNo)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					
					if(logger.isDebugEnabled())
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC elePaymentCredit"+XMLUtil.getElementXMLString(eleSalePaymentMethod));
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC Refund<Charged");
                        strRefundAmount=String.format("%.2f", dRefundAmount);
						strTotalCharged=String.format("%.2f", dTotalCharged);
						dRefundAmount=Double.parseDouble(strRefundAmount);
						dTotalCharged=Double.parseDouble(strTotalCharged);						
                                           eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForCC dRefund="+dRefundAmount+" dTotalCharged"+dTotalCharged);
                        strRefundAmount=String.format("%.2f", dRefundAmount);
						strTotalCharged=String.format("%.2f", dTotalCharged);
						dRefundAmount=Double.parseDouble(strRefundAmount);
						dTotalCharged=Double.parseDouble(strTotalCharged);												
                                                eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			
			}
		}
	}

	private void createRefundForCCKMC(Element eleRefundForPaymentMethods,
			String strCreditCardType, String strRefundAmount,
			NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				String strSaleCreditCardType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
				if ((KohlsConstant.PAYMENTTYPE_CREDIT_CARD
						.equals(strPaymentType) && strSaleCreditCardType
						.equals(strCreditCardType))
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_PREPAID_CREDIT_CARD
								.equals(strPaymentType)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
	}

	private void createRefundForCashCCKMC(Element eleRefundForPaymentMethods,
			String strCreditCardType, String strRefundAmount,
			NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				String strSaleCreditCardType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
				if ((KohlsConstant.PAYMENT_TYPE_CASH.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_TRAVELERS_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENTTYPE_DEBIT_CARD
								.equals(strPaymentType)
						|| (KohlsConstant.PAYMENTTYPE_CREDIT_CARD
								.equals(strPaymentType) && strSaleCreditCardType
								.equals(strCreditCardType))
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType) || KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
							.equals(strPaymentType))
						|| KohlsConstant.PAYMENT_TYPE_PREPAID_CREDIT_CARD
								.equals(strPaymentType)) {

					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
	}

	private void createRefundForCCKohlsChargeKMC(
			Element eleRefundForPaymentMethods, String strCreditCardType,
			String strRefundAmount, NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				String strSaleCreditCardType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
				if ((KohlsConstant.PAYMENTTYPE_CREDIT_CARD
						.equals(strPaymentType) && strSaleCreditCardType
						.equals(strCreditCardType))
						|| KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_PREPAID_CREDIT_CARD
								.equals(strPaymentType)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
	}

	private void createRefundForKMC(Element eleRefundForPaymentMethods,
			String strRefundAmount, NodeList nlSalePaymentMethods) {
		
		
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC -- Start");
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC eleRefundForPaymentMethods"+XMLUtil.getElementXMLString(eleRefundForPaymentMethods)+" strRefundAmount"+strRefundAmount );
		}
		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC dRefundAmount="+dRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC Current eleSalePaymentMethod="+XMLUtil.getElementXMLString(eleSalePaymentMethod));
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC strPaymentType="+strPaymentType);
				if (KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
						.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
								.equals(strPaymentType)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						strRefundAmount=String.format("%.2f", dRefundAmount);
						strTotalCharged=String.format("%.2f", dTotalCharged);
						dRefundAmount=Double.parseDouble(strRefundAmount);
						dTotalCharged=Double.parseDouble(strTotalCharged);
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						
						strRefundAmount=String.format("%.2f", dRefundAmount);
						strTotalCharged=String.format("%.2f", dTotalCharged);
						dRefundAmount=Double.parseDouble(strRefundAmount);
						dTotalCharged=Double.parseDouble(strTotalCharged);
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC dRefundAmount="+dRefundAmount+" dTotalCharged"+dTotalCharged);
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForKMC -- End");
	}

	private void createRefundForPaymentmethod(
			Element eleRefundForPaymentMethods, String strRefundAmount,
			NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod -- Start");
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod eleRefundForPaymentMethods"+XMLUtil.getElementXMLString(eleRefundForPaymentMethods)+" strRefundAmount="+strRefundAmount);
		}
		
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod dRefundAmount="+dRefundAmount);
		}
		while (dRefundAmount != 0) {
			logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod Inside While dRefundAmount="+dRefundAmount);
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				
				if(logger.isDebugEnabled())
					logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod current eleSalePaymentMethod="+XMLUtil.getElementXMLString(eleSalePaymentMethod));
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				if (!YFCCommon.isVoid(strPaymentType)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						strRefundAmount=String.format("%.2f", dRefundAmount);
						strTotalCharged=String.format("%.2f", dTotalCharged);
						dRefundAmount=Double.parseDouble(strRefundAmount);
						dTotalCharged=Double.parseDouble(strTotalCharged);	
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod dRefundAmount="+dRefundAmount+" dTotalCharged"+dTotalCharged);
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						strRefundAmount=String.format("%.2f", dRefundAmount);
						strTotalCharged=String.format("%.2f", dTotalCharged);
						dRefundAmount=Double.parseDouble(strRefundAmount);
						dTotalCharged=Double.parseDouble(strTotalCharged);	
						logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod dRefundAmount="+dRefundAmount+" dTotalCharged"+dTotalCharged);
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
		logger.debug("KohlsPSAOMPConfirmRefundDistributionUE.createRefundForPaymentmethod -- End");
	}

	private void createRefundForCashKMC(Element eleRefundForPaymentMethods,
			String strRefundAmount, NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				if (KohlsConstant.PAYMENT_TYPE_CASH.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_TRAVELERS_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENTTYPE_DEBIT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_PREPAID_CREDIT_CARD
								.equals(strPaymentType)) {

					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
	}

	private void createRefundForKohlsChargeKMC(
			Element eleRefundForPaymentMethods, String strRefundAmount,
			NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				if (KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE
						.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_PREPAID_CREDIT_CARD
								.equals(strPaymentType)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
	}

	private void createRefundForCashKohlsChargeKMC(
			Element eleRefundForPaymentMethods, String strRefundAmount,
			NodeList nlSalePaymentMethods) {

		Double dRefundAmount = 0.0;
		Double dTotalCharged = 0.0;
		if (!YFCCommon.isVoid(strRefundAmount)) {
			dRefundAmount = Double.parseDouble(strRefundAmount);
		}
		while (dRefundAmount != 0) {
			for (int i = 0; i < nlSalePaymentMethods.getLength(); i++) {
				Element eleSalePaymentMethod = (Element) nlSalePaymentMethods
						.item(i);
				String strPaymentType = eleSalePaymentMethod
						.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
				if (KohlsConstant.PAYMENT_TYPE_CASH.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_TRAVELERS_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENTTYPE_DEBIT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_KOHLS_CHARGE
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT
								.equals(strPaymentType)
						|| KohlsConstant.KOHLS_PAYMENT_TYPE_GIFT_CARD
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_VENDOR_CHECK
								.equals(strPaymentType)
						|| KohlsConstant.PAYMENT_TYPE_PREPAID_CREDIT_CARD
								.equals(strPaymentType)) {
					Element eleRefundForPaymentMethod = XMLUtil.createChild(
							eleRefundForPaymentMethods,
							KohlsXMLLiterals.E_REFUND_FOR_PAYMENT_METHOD);
					String strPaymentKey = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
					eleRefundForPaymentMethod.setAttribute(
							KohlsXMLLiterals.A_PAYMENT_KEY, strPaymentKey);

					String strTotalCharged = eleSalePaymentMethod
							.getAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED);
					if (!YFCCommon.isVoid(strTotalCharged)) {
						dTotalCharged = Double.parseDouble(strTotalCharged);
					}
					if (dRefundAmount <= dTotalCharged) {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dRefundAmount));
						dRefundAmount = 0.0;
						break;
					} else {
						eleRefundForPaymentMethod.setAttribute(
								KohlsXMLLiterals.A_REFUND_AMOUNT,
								Double.toString(dTotalCharged));
						dRefundAmount = dRefundAmount - dTotalCharged;
					}
				}
			}
		}
	}

}
