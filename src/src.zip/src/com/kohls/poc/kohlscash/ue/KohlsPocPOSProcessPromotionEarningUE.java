package com.kohls.poc.kohlscash.ue;

// java imports
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.data.kohlscash.KohlsPocKohlsCashFeedAPI;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.util.KohlsPoCSecurityUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.pos.japi.ue.order.POSProcessPromotionEarningUE;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

import com.kohls.poc.util.KohlsPoCCommonAPIUtil;

/**************************************************************************
 * File : KohlsPocPOSProcessPromotionEarningUE.java 
 * Author : IBM 
 * Created : August 12 2013 
 * Modified : August 27 2013 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 12/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * 
 * This class is
 * used to construct Kohls Cash Activation input xml and invokes Kohls Cash
 * service to retrieve the coupon related in an XML document
 * 
 * @author IBM India Pvt 
 * @version 0.1 
 * @version 0.1 changes : Updated Comments section
 * @version 0.2 changes : Updated ApprovedKohlsChargeTendered when Kohls Charge Card is used as payment type(Earlier creditCardType was used for checking)
 */



public class KohlsPocPOSProcessPromotionEarningUE extends KOHLSBaseApi implements POSProcessPromotionEarningUE {

    // logger
    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPocPOSProcessPromotionEarningUE.class.getName());

    // dateformat in datetime
    DateFormat dateFormatDateTime = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);

    // dateformat in date
    DateFormat dateFormatDate = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);



    /**
     * 
     * Method Name : processPromotionEarningUE Description : This method
     * constructs Kohls Cash activation request xml from the indoc supplied and
     * returns an xml document with coupons as a response from the Kohls Cash
     * Activation service
     * 
     * @param env
     *            environment
     * @param docInXML
     *            APE response from KohlsPocOrderRepriceUserExitImpl
     * @return Document, an xml document with coupon details
     */
    @Override
    public Document processPromotionEarningUE(YFSEnvironment env, Document inDoc) {
        logger.beginTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningUE: Start");
        
        
        if(logger.isDebugEnabled()){
            logger.debug("Method  processPromotionEarningUE : start");
            logger.debug("Input xml to processPromotionEarningUE:" + XMLUtil.getXMLString(inDoc));
        }

        Document tempOrderDoc = null;
        Document orderListInDoc = null;
        String sLoyaltyStoreCustomer = "N";
        Document orderListOutDoc = null;
        Element serviceHeaderElement = null;
        Element dataElement = null;
        Element tempOrderEl = null;
        try {

            // Read the inputDoc from the Gravity
            Element eleInDocOrder = inDoc.getDocumentElement();

            // Retrieve OrderHeaderKey, which would be used while forming input
            // request to GetOrderList API
            String orderHeaderKey = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
           

            // Forming Input Request to GetOrderList to retrieve further order
            // details from the response
            orderListInDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
            orderListInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
            
            
            if(logger.isDebugEnabled())
                logger.debug("orderListInDoc:" + XMLUtil.getXMLString(orderListInDoc));

            // Creating the outputOrderElement for UE Response
            tempOrderEl = this.createElementFromXMLString(XMLUtil.getXMLString(orderListInDoc));

            // Building Kohls Cash Activation Request Message
            Document serviceInDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DETERMINE_KOHLS_CASH_ACTIVATION_REQUEST_MSG);
            Element serviceInDocElement = serviceInDoc.getDocumentElement();

            // Creating Header Element in the Request Message
            serviceHeaderElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_HEADER);

            // Preparing Header Information in the Request Message
            prepareRequestHeaderDetails(env,eleInDocOrder, serviceHeaderElement);

            // Invoking GetOrderList API passing OrderHeaderKey, supplying
            // output template as a parameter
            orderListOutDoc = KOHLSBaseApi.invokeAPI(env,
                    KohlsPOCConstant.KOHLS_CASH_ACTIVATION_GET_ORDER_LIST_OUTPUT, KohlsPOCConstant.API_GET_ORDER_LIST,
                    orderListInDoc);
            
            if(logger.isDebugEnabled())
                logger.debug("orderListOutDoc:" + XMLUtil.getXMLString(orderListOutDoc));

            // Retrieving Root Element from the response doc of GetOrderListAPI
            Element olOrderElement = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(),
                    KohlsPOCConstant.ELEM_ORDER);
            
            //Boolean4 - PilotStore
            //Boolean5 - PilotCustomer
            Element olOrderCustAttributes = XMLUtil.getChildElement(olOrderElement,KohlsPOCConstant.CUST_ATTRIBUTES);
            // get pilot customer 
            if (!YFCCommon.isVoid(olOrderCustAttributes) &&
                !YFCCommon.isVoid(olOrderCustAttributes.getAttribute("Boolean5")) &&
                KohlsPOCConstant.YES.equalsIgnoreCase(olOrderCustAttributes.getAttribute("Boolean5"))) {
                sLoyaltyStoreCustomer = "Y";
            }

            // get loyalty store from oms cache 
            String sSellerOrgCode = olOrderElement.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
            String sLoyaltyStore = getOMSLoyaltyKohlsCashStoreTypeRule(env, sSellerOrgCode);

            if (logger.isDebugEnabled()) {
                logger.debug("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningUE: Loyalty Store: " + sLoyaltyStore +
                ". Pilot Customer: " + sLoyaltyStoreCustomer);
            }

            //If non pilot store - go for Event KCS
            if (KohlsPOCConstant.LOYALTY_STORE_Y2Y.equals(sLoyaltyStore)) {
                // determine event kohls cash
                processPromotionEarningKCS(env, inDoc, orderListOutDoc, tempOrderEl);
            }
            else if (KohlsPOCConstant.LOYALTY_STORE_V1_PILOT.equals(sLoyaltyStore)) {
                // determine rewards kohls cash
                processPromotionEarningLCS(env, inDoc, sSellerOrgCode, tempOrderEl);
            }
            else if (KohlsPOCConstant.LOYALTY_STORE_V2_PILOT.equals(sLoyaltyStore) ||
                KohlsPOCConstant.LOYALTY_STORE_V2_NON_PILOT.equals(sLoyaltyStore)) {
                // determine rewards kohls cash
                if (KohlsPOCConstant.YES.equalsIgnoreCase(sLoyaltyStoreCustomer)) {
                    processPromotionEarningLCS(env, inDoc, sSellerOrgCode, tempOrderEl);
                }
                // pack event kohls cash
                processPromotionEarningKCS(env, inDoc, orderListOutDoc, tempOrderEl);
            }

            // assigning the result doc to tempOrderDoc, which should be returned
            tempOrderDoc = XMLUtil.getDocumentForElement(tempOrderEl);

        } catch (Exception e) {
            logger.error(e);
            
            //Execute the below logic if LCS is offline
            Document docOut = null;
            try {
                docOut = XMLUtil.createDocument(orderListOutDoc.getDocumentElement().getFirstChild());
            } catch (ParserConfigurationException e1) {
                // TODO Auto-generated catch block
                logger.error(e1);
            }
            Element promotions = XMLUtil.getChildElement(docOut.getDocumentElement(),
                    KohlsPOCConstant.E_PROMOTIONS, Boolean.TRUE);
            Element promotion = XMLUtil.createChild(promotions, KohlsPOCConstant.E_PROMOTION);
            promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, KohlsPOCConstant.ZERO);
            Element promotionExtn = XMLUtil.createChild(promotion, KohlsPOCConstant.E_EXTN);
            promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_AWARD);
            if(KohlsPOCConstant.YES.equalsIgnoreCase(sLoyaltyStoreCustomer) ){
                promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_1, "LCS_OFFLINE");
            } else{
                promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_1, "");
            }
            
            setBlankPromotionAttributes(promotion, promotionExtn);
            
            // Added KCS offline or times out indicator
            promotionExtn.setAttribute("KOHLS_CASH_ERROR", "TRUE");
            
            
            if(logger.isDebugEnabled())
                logger.debug("outDoc on exception:" + XMLUtil.getXMLString(docOut));

            // orderListInDoc currently holds the response doc , on the
            // occurrence of any exception
            return docOut;
        } 
        
        if(logger.isDebugEnabled()){
            logger.debug("outDoc:" + XMLUtil.getXMLString(tempOrderDoc));
            logger.debug("Method  processPromotionEarningUE : end");
        }

        logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningUE: End");

        return tempOrderDoc;
    }
    
    protected String getOMSLoyaltyKohlsCashStoreTypeRule(YFSEnvironment env, String organizationCode) throws Exception {
        return KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, organizationCode,
            KohlsPOCConstant.LOYALTY_STORE_Y2Y);
    }

    /**
     * 
     * Method Name : processPromotionEarningLCS Description : This method
     * constructs Kohls Cash activation request xml from the indoc supplied and
     * returns an xml document with coupons as a response from the LCS Kohls Cash
     * Activation service
     * 
     * @param env
     *            environment
     * @param docInXML
     *            APE response from KohlsPocOrderRepriceUserExitImpl
     * @return tempOrderEl, an xml document with coupon details
     */
    private void processPromotionEarningLCS(YFSEnvironment env, Document inDoc, String sSellerOrgCode, Element tempOrderEl) {
        logger.beginTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningLCS: Start");

        if(logger.isDebugEnabled()){
            logger.debug("Method KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningLCS : start");
        }

        // Creating Promotions, Extn Elements in the UEResponse Document
        Element promotions = XMLUtil.getChildElement(tempOrderEl, KohlsPOCConstant.E_PROMOTIONS, Boolean.TRUE);
        Element promotion = XMLUtil.createChild(promotions, KohlsPOCConstant.E_PROMOTION);
        Element promotionExtn = XMLUtil.createChild(promotion, KohlsPOCConstant.E_EXTN);
        try {
            Document tempOrderDoc = null;   
            Document serviceOutDocFormatted=null;
            // Read the inputDoc from the Gravity
            Element eleInDocOrder = inDoc.getDocumentElement();

            // Retrieve OrderHeaderKey, which would be used while forming input request 
            String orderHeaderKey = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
            String orderDate = eleInDocOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
            String pendingBarcode = eleInDocOrder.getAttribute("pendingBarcode");
            String existingEarnTrackerBal = eleInDocOrder.getAttribute("existingEarnTrackerBal");;
            String existingPendingBal = eleInDocOrder.getAttribute("existingPendingBal");;
            String pin = eleInDocOrder.getAttribute("PIN");

            Document orderDocumentForLoyalty = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
            orderDocumentForLoyalty.getDocumentElement().setAttribute("Source", "postTender");
            orderDocumentForLoyalty.getDocumentElement().setAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE, sSellerOrgCode);
            orderDocumentForLoyalty.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
            orderDocumentForLoyalty.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORDER_DATE, orderDate);
            orderDocumentForLoyalty.getDocumentElement().setAttribute(KohlsPOCConstant.A_BUSINESS_DATE, businessDay);              
            orderDocumentForLoyalty.getDocumentElement().setAttribute("pendingBarcode", pendingBarcode);
            orderDocumentForLoyalty.getDocumentElement().setAttribute("existingEarnTrackerBal", existingEarnTrackerBal);;
            orderDocumentForLoyalty.getDocumentElement().setAttribute("existingPendingBal", existingPendingBal);;
            orderDocumentForLoyalty.getDocumentElement().setAttribute("PIN", pin);

            serviceOutDocFormatted = KOHLSBaseApi.invokeService(env,"KohlsPoCCallToLCSWrapper", orderDocumentForLoyalty);
            if (logger.isDebugEnabled()) {
                logger.debug("serviceOuptutDoc:" + XMLUtil.getXMLString(serviceOutDocFormatted));  
            }
            Element eleOutPostCartDoc = serviceOutDocFormatted.getDocumentElement();
            String eventID = eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_EVENT_NAME);
            String qualifyingPurchaseAmount =eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_QUALIFYING_PURCHASE_AMOUNT);
            String receiptMessageLine1 ="";
            String receiptMessageLine2 ="";
            String validationCode = eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_PIN);
            String transKcAmountToActivateTol = eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_TRANS_KC_AMOUNT_TO_ACTIVATE_TOL);
            String updatedPendingBalTol = eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_UPDATED_PENDING_BAL_TOL);
            String barcode = eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_BARCODE);
            String sIsDetokenized = "";
            if (!YFCCommon.isVoid(barcode) && !barcode.equalsIgnoreCase("")) {
                // Detoken the Coupon no
                KohlsPoCSecurityUtil obj = new KohlsPoCSecurityUtil();
                
                HashMap <String, String> resultSet = obj.encryptDecryptUsingProtegrity(env, sSellerOrgCode, KohlsPOCConstant.PROTEGRITY_DESECURE, 
                    barcode, KohlsPOCConstant.PROTEGRITY_TKN_KCASH);
                
                if (resultSet != null && ("SUCCESS".equalsIgnoreCase(resultSet.get("Status")) || "NA".equalsIgnoreCase(resultSet.get("Status")))) {
                  barcode = resultSet.get("Value");
                  sIsDetokenized = "Y";
                } else {
                  sIsDetokenized = "N";
                }
            }
            promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, eventID);

            // Set PromotionType as "LOYALTY_KOHLS_CASH"
            promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE,KohlsPOCConstant.KOHLS_CASH_AWARD);

            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_EVENT_ID, "");
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_ALGORITHM, "");
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, qualifyingPurchaseAmount);
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT, transKcAmountToActivateTol);
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_1, receiptMessageLine1);
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_2, receiptMessageLine2);
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_VALIDATION_CODE, validationCode);
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_START_DATE, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_REDEMPTION_START_DATE));
            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_END_DATE, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_REDEMPTION_END_DATE));
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_SPENDAWAY_EVENT, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_SPENDAWAY_EVENT));
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_SPENDAWAY_EVERYDAY_NON_KCC, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_SPENDAWAY_EVERYDAY_NON_KCC));
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_SPENDAWAY_EVERYDAY_KCC, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_SPENDAWAY_EVERYDAY_KCC));
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_TRAN_KC_AMT_TO_ACTIVATE_TOL, transKcAmountToActivateTol);
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_EVERYDAY_EARN_KCC, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_EVERYDAY_EARN_KCC));
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_EVERYDAY_NON_EARN_KCC, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_EVERYDAY_EARN_NON_KCC));
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_EVENT_KOHLS_CASH_EARN_TOL, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_EVENT_KOHLS_CASH_EARN_TOL));
            promotionExtn.setAttribute(KohlsPOCConstant.E_UPDATED_EARN_TRACKER_BAL, eleOutPostCartDoc.getAttribute(KohlsXMLLiterals.A_UPDATED_EARN_TRACKER_BAL));
            promotionExtn.setAttribute(KohlsPOCConstant.UPDATE_PENDING_BALANCE, updatedPendingBalTol);
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_COUPON_NO, barcode);
            //promotionExtn.setAttribute(KohlsPOCConstant.TRAN_KC_AMNT_TO_ACTIVATE, transKcAmountToActivateTol);
            promotionExtn.setAttribute(KohlsPOCConstant.A_COUPON_NUMBER, barcode);
            promotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED, sIsDetokenized);

        } 
        catch (Exception e) {
            logger.error("Error while calling LCS: " + e.getMessage());
            // Setting Extn Attributes as blank
            promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_AWARD);
            setBlankPromotionAttributes(promotion, promotionExtn);          
            promotionExtn.setAttribute("KOHLS_CASH_LCS_ERROR", "TRUE");
        } 

        if(logger.isDebugEnabled()){
            logger.debug("Method KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningLCS : end");
        }

        logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningLCS: End");

    }


    /**
     * 
     * Method Name : processPromotionEarningKCS Description : This method
     * constructs Kohls Cash activation request xml from the indoc supplied and
     * returns an xml document with coupons as a response from the Kohls Cash
     * Activation service
     * 
     * @param env
     *            environment
     * @param docInXML
     *            APE response from KohlsPocOrderRepriceUserExitImpl
     * @return tempOrderEl, an xml document with coupon details
     */
    private void processPromotionEarningKCS(YFSEnvironment env, Document inDoc, Document orderListOutDoc, Element tempOrderEl) throws Exception {
        logger.beginTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningKCS: Start");

        if(logger.isDebugEnabled()){
            logger.debug("Method KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningKCS : start");
        }

        Document tempOrderDoc = null;
        Document orderListInDoc = null;
        Element serviceHeaderElement = null;
        Element dataElement = null;

        // Read the inputDoc from the Gravity
        Element eleInDocOrder = inDoc.getDocumentElement();

        // Building Kohls Cash Activation Request Message
        Document serviceInDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DETERMINE_KOHLS_CASH_ACTIVATION_REQUEST_MSG);
        Element serviceInDocElement = serviceInDoc.getDocumentElement();

        // Creating Header Element in the Request Message
        serviceHeaderElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_HEADER);

        // Preparing Header Information in the Request Message
        prepareRequestHeaderDetails(env,eleInDocOrder, serviceHeaderElement);

        // Retrieving Root Element from the response doc of GetOrderListAPI
        Element olOrderElement = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(),
                KohlsPOCConstant.ELEM_ORDER);
        
        // Creating Data Element in the Request Message
        dataElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_DATA);
        
        if (!(XMLUtil.isVoid(olOrderElement))){
            // Preparing Data Information in the Request Details
            prepareRequestDataDetails(olOrderElement, dataElement, serviceHeaderElement);
        }
        
        if (logger.isDebugEnabled()) {
            logger.debug("serviceInDoc:" + XMLUtil.getXMLString(serviceInDoc));
        }

        Element serviceOutDocElement = null;
        
        //Use KohlsCashManager to determine activation events
        KohlsCashManager kcm = new KohlsCashManager(env);
        
        String sellerOrganizationCode = eleInDocOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        
        boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(sellerOrganizationCode);
        
        if(logger.isDebugEnabled()) {
            logger.debug("######Rule value for OMS KC in KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningUE: " + omsKCEnabled);
        }
        
        if (omsKCEnabled) {
        	
        	if (logger.isDebugEnabled()) {
                logger.debug("KohlsCashActivation Input to OMS KC " + XMLUtil.getXMLString(serviceInDoc));
            }
        	
            kcm.loadEvents(sellerOrganizationCode);
            //Do activation via KCM
            Document serviceOutDoc = kcm.determineKohlsCashActivation(serviceInDoc);
            
            if (serviceOutDoc != null) {
                if(logger.isDebugEnabled())
                    logger.debug("OMS KC KohlsCashActivation Result: " + XMLUtil.getXMLString(serviceOutDoc));
                
                serviceOutDocElement = serviceOutDoc.getDocumentElement();
                processKohlsCashResponse(tempOrderEl, serviceOutDocElement);
                
                // assigning the result doc to tempOrderDoc, which should be returned
                tempOrderDoc = XMLUtil.getDocumentForElement(tempOrderEl);
                if (tempOrderDoc != null){
                    if(logger.isDebugEnabled())
                        logger.debug("Returning orderDoc:" + XMLUtil.getXMLString(tempOrderDoc));
                    logger.debug("Method  processPromotionEarningUE : end");
                    logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningUE: End");
                    return;
                }
            }
            else {
                //Set blank attributes on the promotion extn
                Element promotions = XMLUtil.getChildElement(tempOrderEl, KohlsPOCConstant.E_PROMOTIONS, Boolean.TRUE);
                Element promotion = XMLUtil.getChildElement(promotions, KohlsPOCConstant.E_PROMOTION, Boolean.TRUE);
                Element promotionExtn = XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
                setBlankPromotionAttributes(promotion, promotionExtn);
            }
        }
        else {
        	if (logger.isDebugEnabled()) {
                logger.debug("KohlsCashActivation Input to KCS " + XMLUtil.getXMLString(serviceInDoc));
            }
            
            //Do activation via KCS
            Document serviceOutDocFormatted = KOHLSBaseApi.invokeService(env,
                     KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_ACTIVATION_WEB_SERVICE, serviceInDoc);
            
            if (logger.isDebugEnabled()) { 
                logger.debug("KCS serviceOuptutDoc:" + XMLUtil.getXMLString(serviceOutDocFormatted));   
            }        

            serviceOutDocElement = serviceOutDocFormatted.getDocumentElement();

            // Retrieving Data Element from the Service Response
            List eleDataList = XMLUtil.getElementsByTagName(serviceOutDocElement, KohlsPOCConstant.E_DATA);
            if (!(XMLUtil.isVoid(eleDataList))&& (eleDataList.size() > KohlsPOCConstant.ZERO_INT)) {

                // Retrieving the first occurrence of the Data from the output doc
                Element eleData = (Element) eleDataList.get(0);

                // Retrieving EVENTID attribute
                String eventID = eleData.getAttribute("EventID");

                // Creating Promotions, Extn Elements in the UEResponse Document
                Element promotions = XMLUtil.getChildElement(tempOrderEl, KohlsPOCConstant.E_PROMOTIONS, Boolean.TRUE);
                Element promotion = XMLUtil.getChildElement(promotions, KohlsPOCConstant.E_PROMOTION, Boolean.TRUE);
                Element promotionExtn = XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

                // If EventID is not blank and is non Zero, Consider stamping
                // coupon related details into the Extn Fields of the promotion
                if (!XMLUtil.isVoid(eventID)) {
                    if (!(KohlsPOCConstant.ZERO.equals(eventID))) {

                        String eventName = eleData.getAttribute(KohlsPOCConstant.E_EVENT_NAME);
                        String qualifyingPurchaseAmount = eleData
                                 .getAttribute(KohlsPOCConstant.E_QUALIFYING_PURCHASE_AMOUNT);
                        String kohlsCashAmount = eleData.getAttribute(KohlsPOCConstant.E_KOHLS_CASH_AMOUNT);
                        String receiptMessageLine1 = eleData.getAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_1);
                        String receiptMessageLine2 = eleData.getAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_2);
                        String validationCode = eleData.getAttribute(KohlsPOCConstant.E_VALIDATION_CODE);

                        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, eventID);

                        // Set PromotionType as "KOHLS_CASH_AWARD"
                        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_AWARD);

                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_EVENT_ID, eventID);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_ALGORITHM, eventName);
                        String qualifiedPurchaseAmount = promotionExtn.getAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT);
                        if (YFCCommon.isVoid(qualifiedPurchaseAmount) || qualifiedPurchaseAmount.equalsIgnoreCase("")) {
                            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, qualifyingPurchaseAmount);
                        }
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT, kohlsCashAmount);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_1, receiptMessageLine1);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_2, receiptMessageLine2);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_VALIDATION_CODE, validationCode);

                    } else {
                        // Setting Extn Attributes as blank
                        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_AWARD);
                        setBlankPromotionAttributes(promotion, promotionExtn);
                    }
                }
            }
        }     
        
        if(logger.isDebugEnabled()){
            logger.debug("Method KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningKCS : end");
        }

        logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.processPromotionEarningKCS: End");
    }

    private void processKohlsCashResponse(Element tempOrderEl, Element serviceOutDocElement) {
        try {
            List eleDataList = XMLUtil.getElementsByTagName(serviceOutDocElement, KohlsPOCConstant.E_DATA);
            if (!(XMLUtil.isVoid(eleDataList))&& (eleDataList.size() > KohlsPOCConstant.ZERO_INT)) {
    
                // Retrieving the first occurrence of the Data from the output
                // doc
                Element eleData = (Element) eleDataList.get(0);
    
                // Retrieving EVENTID attribute
                String eventID = eleData.getAttribute("EventID");
    
                // Creating Promotions, Extn Elements in the UEResponse Document
                Element promotions = XMLUtil.getChildElement(tempOrderEl, KohlsPOCConstant.E_PROMOTIONS, Boolean.TRUE);
                Element promotion = XMLUtil.getChildElement(promotions, KohlsPOCConstant.E_PROMOTION, Boolean.TRUE);
                Element promotionExtn = XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
    
                // If EventID is not blank and is non Zero, Consider stamping
                // coupon related details into the Extn Fields of the promotion
                if (!XMLUtil.isVoid(eventID)) {
                    if (!(KohlsPOCConstant.ZERO.equals(eventID))) {
    
                        String eventName = "Offline " + eleData.getAttribute(KohlsPOCConstant.E_EVENT_NAME);
                        String qualifyingPurchaseAmount = eleData
                                .getAttribute(KohlsPOCConstant.E_QUALIFYING_PURCHASE_AMOUNT);
                        String kohlsCashAmount = eleData.getAttribute(KohlsPOCConstant.E_KOHLS_CASH_AMOUNT);
                        String receiptMessageLine1 = eleData.getAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_1);
                        String receiptMessageLine2 = eleData.getAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_2);
                        String validationCode = eleData.getAttribute(KohlsPOCConstant.E_VALIDATION_CODE);
    
                        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, eventID);
    
                        // Set PromotionType as "KOHLS_CASH_AWARD"
                        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_AWARD);
    
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_EVENT_ID, eventID);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_ALGORITHM, eventName);
                        String qualifiedPurchaseAmount = promotionExtn.getAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT);
                        if (YFCCommon.isVoid(qualifiedPurchaseAmount) || qualifiedPurchaseAmount.equalsIgnoreCase("")) {
                            promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, qualifyingPurchaseAmount);
                        }                       
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT, kohlsCashAmount);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_1, receiptMessageLine1);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_2, receiptMessageLine2);
                        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_VALIDATION_CODE, validationCode);
    
                    } else {
                        // Setting Extn Attributes as blank
                        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH_AWARD);
                        setBlankPromotionAttributes(promotion, promotionExtn);
                    }
                }
            }
        }catch (Exception e) {
                logger.error(e);
        }
    }
    
    private void setBlankPromotionAttributes(Element promotion, Element promotionExtn) {
        // Setting Extn Attributes as blank
        promotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, KohlsPOCConstant.ZERO);

        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_EVENT_ID, "");
        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_ALGORITHM, "");
        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, "");
        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_COUPON_AMOUNT, "");
        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_1, "");
        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_RECEIPT_MESSAGE_2, "");
        promotionExtn.setAttribute(KohlsPOCConstant.E_EXTN_VALIDATION_CODE, "");
    }

    /**
     * 
     * Method Name : prepareRequestDataDetails Description : This method
     * constructs Data Element which is a part of the KohlsCashActivationService
     * request
     * 
     * @param orderElement
     *            - Order Element from GetOrderList response
     * @param dataElement
     *            - Data Element in the KohlsCashActivationService Request
     * @param headerElement
     *            - Header Element in the KohlsCashActivationService Request
     * @return void
     */
    private void prepareRequestDataDetails(Element orderElement, Element dataElement, Element headerElement) {

        logger.beginTimer("KohlsPocPOSProcessPromotionEarningUE.prepareRequestDataDetails: Start");


        // Retrieve and set PosSequenceNo
        String posSequenceNo = orderElement.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRANSACTION_NUMBER, posSequenceNo);

        // Retrieve and set TransactionNo
        String extnOriginalReceiptId = "";
        Element eleInDocOrderExtn = XMLUtil.getChildElement(orderElement, KohlsPOCConstant.E_EXTN);

        if (!XMLUtil.isVoid(eleInDocOrderExtn)) {
            extnOriginalReceiptId = eleInDocOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_ORIGINAL_RECEIPT_ID);
        } else {
            extnOriginalReceiptId = orderElement.getAttribute(KohlsPOCConstant.E_TRANSACTION_NO);
        }

        XMLUtil.setAttribute(dataElement, KohlsPOCConstant.E_RECEIPT_ID, extnOriginalReceiptId);

        // Retrieve PaymentMethods and PaymentMethod from the OrderElement

        Element elePaymentMethods = XMLUtil.getChildElement(orderElement, KohlsPOCConstant.E_PAYMENT_METHODS);

        if(!(XMLUtil.isVoid(elePaymentMethods))){
            List nodeListElePaymentMethod = XMLUtil.getElementsByTagName(elePaymentMethods, KohlsPOCConstant.E_PAYMENT_METHOD);

            // isKohlsChargeCard stores if KohlsChargeCard has been used as
            // PaymentType during the tendering process
            boolean isKohlsChargeCard = false;

            if(!(XMLUtil.isVoid(nodeListElePaymentMethod))){
                // Iterate through the list of PaymentMethod
                for (Iterator itr = nodeListElePaymentMethod.iterator(); itr.hasNext();) {

                    Node nodeElePaymentMethod = (Node) itr.next();

                    if (!(YFCCommon.isVoid(nodeElePaymentMethod))) {

                        Element elePaymentMethod = (Element) nodeElePaymentMethod;

                        // Retrieve PaymentType attribute from the paymentMethod
                        // element
                        String elePaymentType = elePaymentMethod
                                .getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);

                        if (!XMLUtil.isVoid(elePaymentType)) {

                            // Check if creditCardType is "KOHLS_CHARGE_CARD"
                            if (elePaymentType.equalsIgnoreCase(KohlsPOCConstant.KOHL_CHARGE_CARD)) {

                                // if true, set isKohlsChargeCard as true
                                isKohlsChargeCard = true;
                                break;
                            }
                        }
                    }
                }

            }


            // Set ApprovedKohlsChargeTendered
            XMLUtil.setAttribute(dataElement, KohlsPOCConstant.E_APPROVED_KOHLS_CHARGE_TENDERED,
                    String.valueOf(isKohlsChargeCard));
        }


        // Create ItemList Element in the KohlsCashActivationRequest
        Element eleItemList = XMLUtil.createChild(dataElement, KohlsPOCConstant.E_ITEM_LIST);

        // Order/OrderLines/OrderLine
        List nodeListOrderLine = XMLUtil.getElementsByTagName(orderElement, "OrderLine");

        // iterating the orderline
        for (Iterator itr = nodeListOrderLine.iterator(); itr.hasNext();) {

            Node nodeOrderLine = (Node) itr.next();

            if (!(YFCCommon.isVoid(nodeOrderLine))) {

                Element eleOrderLine = (Element) nodeOrderLine;

                Element elementItem = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_ITEM_DETAILS);

                Element eleOutItem = null;

                // Retrieve ExtnDept from the ItemDetails
                if (!XMLUtil.isVoid(elementItem)) {
                    Element eleExtnItem = XMLUtil.getChildElement(elementItem, KohlsPOCConstant.E_EXTN);
                    eleOutItem = XMLUtil.createChild(eleItemList, KohlsPOCConstant.E_ITEM);
                    String eleExtnDept = "";
                    if (!XMLUtil.isVoid(eleExtnItem)) {
                        eleExtnDept = eleExtnItem.getAttribute(KohlsPOCConstant.E_EXTN_DEPT);
                    }

                    // Set Dept Attribute
                    XMLUtil.setAttribute(eleOutItem, KohlsPOCConstant.E_DEPT, eleExtnDept);

                }

                /*// Retrieve LinePriceInfo Element
                Element elementLinePriceInfo = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);

                if (!XMLUtil.isVoid(elementLinePriceInfo)) {
                    // Retrieve LineTotal and Set NetPrice Attribute in the
                    // KohlsCashActivationRequest
                    String eleLineTotal = elementLinePriceInfo.getAttribute(KohlsPOCConstant.E_LINE_TOTAL);
                    XMLUtil.setAttribute(eleOutItem, KohlsPOCConstant.E_NETPRICE, eleLineTotal);

                }*/

                // Retrieve LineOverallTotals Element
                Element elementLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);

                if (!XMLUtil.isVoid(elementLineExtn) && !YFCCommon.isVoid( eleOutItem ) )
                {
                    // Retrieve LineTotalWithoutTax and Set NetPrice Attribute in the KohlsCashActivationRequest
                    String eleLineTotalWithoutTax = elementLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE);
                    if( !YFCCommon.isVoid( eleLineTotalWithoutTax ) )
                    {
                       XMLUtil.setAttribute(eleOutItem, KohlsPOCConstant.E_NETPRICE, eleLineTotalWithoutTax);
                    }

                }


            }
        }
        logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.prepareRequestDataDetails: End");


    }
    private String businessDay = KohlsPOCConstant.EMPTY;
    /**
     * Method Name : prepareRequestHeaderDetails Description : This method
     * constructs Header Element which is a part of the
     * KohlsCashActivationService request
     * 
     * @param eleInDocOrder
     * @param headerElement
     * @throws Exception 
     */
    private void prepareRequestHeaderDetails(YFSEnvironment yfsEnv,Element eleInDocOrder, Element headerElement) throws Exception {

        logger.beginTimer("KohlsPocPOSProcessPromotionEarningUE.prepareRequestHeaderDetails: Start");


        String sellerOrganizationCode = eleInDocOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        //Appending zero when store number length is less than 4
        sellerOrganizationCode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(sellerOrganizationCode);

        String terminalID = eleInDocOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        //String orderDate = eleInDocOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
        //String businessDay = KohlsPOCConstant.EMPTY;
        Document businessDateDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, eleInDocOrder);

        Element getTillStatusListForPOSOutEle = businessDateDoc.getDocumentElement();
        List<Element> tillStatusList = XMLUtil.getElementsByTagName(getTillStatusListForPOSOutEle, KohlsPOCConstant.E_TILL_STATUS);

        if(tillStatusList.size() > KohlsPOCConstant.ZERO_INT){
            Element tillStatusElement =  tillStatusList.get(KohlsPOCConstant.ZERO_INT);
            businessDay = XMLUtil.getAttribute(tillStatusElement, KohlsPOCConstant.A_BUSINESS_DAY);
        }

        /*if (!XMLUtil.isVoid(orderDate)) {

            Date orderDateObj = dateFormatDate.parse(orderDate);

            if (!XMLUtil.isVoid(orderDateObj)) {
                orderDate = dateFormatDate.format(orderDateObj);
            }

        }*/
        String operatorID = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID);

        String extnRequestDateTime = "";

        Element eleInDocOrderExtn = XMLUtil.getChildElement(eleInDocOrder, KohlsPOCConstant.E_EXTN);
        if (!XMLUtil.isVoid(eleInDocOrderExtn)) {
            extnRequestDateTime = eleInDocOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_REQUEST_DATE_TIME);

        }

        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_STORE_APE, sellerOrganizationCode);
        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TERMINAL, terminalID);
        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_BUSINESS_DATE, businessDay);
        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_ASSOCIATE_ID, operatorID);
        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAINING_MODE, KohlsPOCConstant.CONST_FALSE);

        // get current date time with Calendar()
        Calendar cal = Calendar.getInstance();

        // hardcoded with current date time
        XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAN_START_DATE_TIME,
                !XMLUtil.isVoid(extnRequestDateTime) ? extnRequestDateTime : dateFormatDateTime.format(cal.getTime()));

        logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.prepareRequestHeaderDetails: End");


    }

    private Element createElementFromXMLString(String xmlString) throws ParserConfigurationException, SAXException,
    IOException {

        logger.beginTimer("KohlsPocPOSProcessPromotionEarningUE.createElementFromXMLString: End");

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        InputSource is = new InputSource(new ByteArrayInputStream(xmlString.getBytes()));
        is.setEncoding(KohlsPOCConstant.ENCODING_VALUE);
        Document doc = db.parse(is);
        Element elem = doc.getDocumentElement();
        logger.endTimer("KohlsPocPOSProcessPromotionEarningUE.createElementFromXMLString: End");

        return elem;

    }

}
