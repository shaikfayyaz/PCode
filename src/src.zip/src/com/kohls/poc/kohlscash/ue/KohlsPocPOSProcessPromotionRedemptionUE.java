package com.kohls.poc.kohlscash.ue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.psa.api.KohlsCashRedemptionForPSA;
import com.tgcs.tcx.gravity.nrsc.kohls.pos.japi.ue.order.POSProcessPromotionRedemptionUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**************************************************************************
 * File : KohlsPocPOSProcessPromotionRedemptionUE.java Author : IBM 
 * Created : August 28 2013
 * Modified :
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 28/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file creates kohls cash redemption request and gets the response from
 * Kohls Cash redemption service.Based on the response forms UE response and 
 * returns back.
 * 
 * @author 
 * @version 0.1
 *****************************************************************************/

public class KohlsPocPOSProcessPromotionRedemptionUE extends KOHLSBaseApi implements POSProcessPromotionRedemptionUE {

	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPocPOSProcessPromotionRedemptionUE.class.getName());
	}

	// dateformat in datetime
	DateFormat dateFormatDateTime = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);

	// dateformat in date
	DateFormat dateFormatDate = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);

	/**
	 * 
	 * Method Name : processPromotionRedemptionUE Description : This method
	 * constructs Kohls Cash Redemption request xml from the indoc supplied and
	 * returns an xml document with response from the Kohls Cash Redemption
	 * service
	 * 
	 * @param env
	 *            environment
	 * @param inDoc
	 *            APE response from KohlsPocOrderRepriceUserExitImpl
	 * @return Document, an xml document with coupon details
	 * @throws Exception 
	 */

	public Document POSProcessPromotionRedemptionUE(YFSEnvironment env, Document inDoc) {

		logger.beginTimer("KohlsPocPOSProcessPromotionRedemptionUE.POSProcessPromotionRedemptionUE");
		Document tempOrderDoc = null;
		Element extnEle = null;
		Element eleOPOrder = null;
		Document orderListInDoc = null;
		Document orderListOutDoc = null;
		Document tempOrderOutDoc = null;
		
		//Added for Kohls cash redemption POC Returns-Start 
		Document docOutput=null;
		KohlsCashRedemptionForPSA objRedemtion=new KohlsCashRedemptionForPSA();
		//Added for Kohls cash redemption POC Returns-End
		
		logger.debug("Entering POSProcessPromotionRedemptionUE ......");

		// Read the inputDoc from the Gravity
		Element eleInDocOrder = inDoc.getDocumentElement();

		//Added for Kohls cash redemption POC Returns-Start
		String isPSAOrder= eleInDocOrder.getAttribute(KohlsPOCConstant.IS_PSA_ORDER);
		if( KohlsPOCConstant.YES.equalsIgnoreCase(isPSAOrder)){ 
			docOutput = objRedemtion.KohlsCashRedemptionForPSA(env,inDoc);
			//System.out.println("Result:" +XMLUtil.getXMLString(doc));
			return docOutput;
		}
		//Added for Kohls cash redemption POC Returns-End
		
		// Retrieve OrderHeaderKey, which would be used while forming input
		// request to GetOrderList API
		String orderHeaderKey = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		
		
		if(logger.isDebugEnabled())
			logger.debug(XMLUtil.getXMLString(inDoc));

		// Forming Input Request to GetOrderList to retrieve further order
		// details from the response
		try {
			
			orderListInDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
			
			orderListInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
			logger.debug("POSProcessPromotionRedemptionUE : is edge server: "+ServerTypeHelper.amIOnEdgeServer());
			if(ServerTypeHelper.amIOnEdgeServer()){
				stampEndpoint(orderListInDoc);
			}
			
			if(logger.isDebugEnabled())
				logger.debug("orderListInDoc:" + XMLUtil.getXMLString(orderListInDoc));
			
			orderListOutDoc = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.KOHLS_CASH_REDEMPTION_GET_ORDER_LIST_OUTPUT,
					KohlsPOCConstant.API_GET_ORDER_LIST, orderListInDoc);
			
			if(logger.isDebugEnabled())
				logger.debug("orderListOutDoc:" + XMLUtil.getXMLString(orderListOutDoc));

			// Retrieving Root Element from the response doc of GetOrderListAPI
			Element olOrderElement = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);

			// Retrieve Promotions and Promotions from the OrderElement

			List<Element> elePromotionsList = XMLUtil.getElementsByTagName(olOrderElement, KohlsPOCConstant.E_PROMOTIONS);

			if (!XMLUtil.isVoid(elePromotionsList) && elePromotionsList.size() > KohlsPOCConstant.ZERO_INT) {

				List nodeListElePromotion = XMLUtil.getElementsByTagName(elePromotionsList.get(KohlsPOCConstant.ZERO_INT),
						KohlsPOCConstant.E_PROMOTION);

				// Iterate through the list of Promotion
				for (Iterator itr = nodeListElePromotion.iterator(); itr.hasNext();) {

					Node nodeElePromotion = (Node) itr.next();

					if (!(YFCCommon.isVoid(nodeElePromotion))) {

						Element elePromotion = (Element) nodeElePromotion;

						String elePromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
						String promotionApplied = elePromotion.getAttribute(KohlsPOCConstant.PROMO_APPLIED);

						if (!XMLUtil.isVoid(elePromotionType)) {
							// Check if promotionType is "KOHLS_CASH"
							if (elePromotionType.equalsIgnoreCase(KohlsPOCConstant.KOHLS_CASH) && promotionApplied.equalsIgnoreCase(KohlsPOCConstant.YES)) {

								extnEle = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
								String extnOfflineMode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);

								if (YFCCommon.isStringVoid(extnOfflineMode)) {
									Document serviceInDoc = XMLUtil.createDocument(KohlsPOCConstant.E_COUPON_REDEMPTION_REQ_MSG);

									Element serviceInDocElement = serviceInDoc.getDocumentElement();

									// Creating Header Element in the Request
									// Message
									Element serviceHeaderElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_HEADER);

									// Creating Data Element in the Request Message
									Element dataElement = XMLUtil.createChild(serviceInDocElement, KohlsPOCConstant.E_DATA);

									// Preparing Header Information in the Request
									// Message
									prepareRequestHeaderDetails(env, olOrderElement, serviceHeaderElement);
									prepareRequestDataDetails(olOrderElement, elePromotion, dataElement);
									
									KohlsCashManager kcm = new KohlsCashManager(env);
									Document serviceOutDocFormatted = null;
									
									String sellerOrganizationCode = olOrderElement.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
									
									boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(sellerOrganizationCode);
									
									if(logger.isDebugEnabled())
										logger.debug("######Rule value for OMS KC in KohlsPocPOSProcessPromotionRedemptionUE.POSProcessPromotionRedemptionUE: " + omsKCEnabled);
								    try {
								    	if(omsKCEnabled) {
								    		if(logger.isDebugEnabled())
												logger.debug("OMS KC indoc:" + XMLUtil.getXMLString(serviceInDoc));
								    		
											kcm.loadEvents(sellerOrganizationCode);
											//Do redemption via KCM
											serviceOutDocFormatted = kcm.kohlsCashRedemption(serviceInDoc);
											
											if(logger.isDebugEnabled())
												logger.debug("OMS KC Outdoc:" + XMLUtil.getXMLString(serviceOutDocFormatted));
										}
										else {
											if(logger.isDebugEnabled())
												logger.debug("KCS indoc:" + XMLUtil.getXMLString(serviceInDoc));
											
											//Do redemption via KCS
											serviceOutDocFormatted = KOHLSBaseApi.invokeService(env,
													KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_REDEMPTION_WEB_SERVICE, serviceInDoc);
											
											if(logger.isDebugEnabled())
												logger.debug("KCS Outdoc:" + XMLUtil.getXMLString(serviceOutDocFormatted));
										}
									} catch (Exception e1) {

										//  ExtnRedemResponseCode to 9 ONLY for the promotions with promotionType as KOHLS_CASH and if webservice call failed
											Element extnElement = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
											XMLUtil.setAttribute(extnElement, KohlsPOCConstant.A_REDEMPTION_RESPONSE_CODE, "9");
									
										logger.error( "KCM or KCS webservice call failure in KohlsPocPOSProcessPromotionRedemptionUE.POSProcessPromotionRedemptionUE: ", e1 );
										if(logger.isDebugEnabled())
											logger.debug("###### KCM or KCS webservice call failure in KohlsPocPOSProcessPromotionRedemptionUE.POSProcessPromotionRedemptionUE: " );
									} 
									
									//for testing
									Element serviceOutDocElement = serviceOutDocFormatted.getDocumentElement();

									// Retrieving Data Element from the Service
									// Response

									List eleDataList = XMLUtil.getElementsByTagName(serviceOutDocElement, KohlsPOCConstant.E_DATA);
									if (!(XMLUtil.isVoid(eleDataList)) && (eleDataList.size() > KohlsPOCConstant.ZERO_INT)) {
										Element eleData = (Element) eleDataList.get(0);
										// Retrieving authResponseCode attribute
										String authResponseCode = eleData.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
										logger.debug("authresponsecode:" + authResponseCode);
										
										// Start: Retrieving authApprovalNum during Sprint 7 : Suresh
										String authApprovalNum = eleData.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);
										logger.debug("authApprovalNum:"+authApprovalNum);
										// End: Retrieving authApprovalNum during Sprint 7 : Suresh

										String couponBalance = eleData.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
										if (!XMLUtil.isVoid(authResponseCode)) {
										
										// Start: Retrieving authApprovalNum during Sprint 7 : Suresh
											// setting ExtnRedemAuthApprovalNum only in the case of authorized
											if("0".equalsIgnoreCase(authResponseCode)){
												XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_REDEMPTION_AUTH_APPROVAL_NUM, authApprovalNum);
											}
											// End: Retrieving authApprovalNum during Sprint 7 : Suresh
											
											XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_REDEMPTION_RESPONSE_CODE, authResponseCode);

											XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE, couponBalance);
										}

									}

								}

							}
						}

					}

				}
			}

			 eleOPOrder = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(),  KohlsPOCConstant.ELEM_ORDER);
		     tempOrderOutDoc = XMLUtil.getDocumentForElement(eleOPOrder); 		
		     
		   
			if(logger.isDebugEnabled())
				logger.debug("final out doc is:" + XMLUtil.getXMLString(tempOrderOutDoc));

		} catch (Exception e) {
			logger.error( "Failure in KohlsPocPOSProcessPromotionRedemptionUE.POSProcessPromotionRedemptionUE: ", e );
			eleOPOrder = XMLUtil.getChildElement(orderListOutDoc.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);
			// Retrieve Promotions and Promotions from the OrderElement	
			if(logger.isDebugEnabled())
				logger.debug("OutDoc in exception block:" + XMLUtil.getXMLString(orderListOutDoc));
		    try {
				 tempOrderOutDoc = XMLUtil.getDocumentForElement(eleOPOrder);
			} catch (Exception e1) {
				e1.printStackTrace();
			} 
		}

		logger.debug("Exiting POSProcessPromotionRedemptionUE ......");		
        logger.endTimer("KohlsPocPOSProcessPromotionRedemptionUE.POSProcessPromotionRedemptionUE");

		return tempOrderOutDoc;

	}

	
	
	private void stampEndpoint(Document orderListInDoc){
		
		String orderHeaderKey = orderListInDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		logger.debug("stampEndpoint:: Order header key value::  "+orderHeaderKey);
		if(!orderHeaderKey.startsWith(KohlsXMLLiterals.INSTORE_ORDER_NO_SEQUENCE_20)){
			Element eleAdditionalInfo= SCXmlUtil.createChild(orderListInDoc.getDocumentElement(),KohlsXMLLiterals.E_YFCADDITIONALINFO);
				 eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_MOTHERSHIP);
				 logger.debug("--stampEndpoint::  Added endpoint value as Mothership --");
			
		}
		
		
	}
	/*** Method Name : prepareRequestDataDetails Description : This method
	 * constructs Data Element which is a part of the KohlsCashRedemptionService
	 * request
	 * 
	 * @param eleInDocOrder
	 * @param elePromotion
	 * @param dataElement
	 */
	private void prepareRequestDataDetails(Element eleInDocOrder, Element elePromotion, Element dataElement) {
		logger.beginTimer("KohlsPocPOSProcessPromotionRedemptionUE.prepareRequestDataDetails");

		logger.debug("Entering prepareRequestDataDetails......");
		if (!XMLUtil.isVoid(elePromotion)) {

			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_COUPON_NUMBER, XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_ID));
			String overrideAdjValue = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
			overrideAdjValue = (YFCCommon.isStringVoid(overrideAdjValue)) ? KohlsPOCConstant.ZERO : overrideAdjValue;
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_DISCOUNT_AMOUNT, String.valueOf(Math.abs(Double.valueOf(overrideAdjValue))));
			logger.debug(XMLUtil.getAttribute(dataElement, KohlsPOCConstant.A_DISCOUNT_AMOUNT));

			Element eleExtnPromotion = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
			String extnCouponScanned = XMLUtil.getAttribute(eleExtnPromotion, KohlsPOCConstant.A_EXTN_COUPON_SCANNED);
			//Fix for defects 3843, 3845 and 3922 - Start
			String extnInputMethod = XMLUtil.getAttribute(eleExtnPromotion, "ExtnInputMethod");
			//logger.debug("The extnCouponScanned and  extnInputMethod value are :" + extnCouponScanned +"  " +extnInputMethod);
			if(!YFCCommon.isStringVoid(extnInputMethod)){
				if(extnInputMethod.equalsIgnoreCase("K")){
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.TRUE); 
				}else{
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.FALSE); 
				}
				//logger.debug("The HAND_KEYED_COUPON value inside If block is : " + XMLUtil.getAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON));
			}else{
				if(!YFCCommon.isStringVoid(extnCouponScanned) && extnCouponScanned.equalsIgnoreCase(KohlsPOCConstant.NO)){
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.TRUE); 
				}else{
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.FALSE);
				}
				//logger.debug("The HAND_KEYED_COUPON value inside Else block is : " + XMLUtil.getAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON));
			}
			//Start Commenting
			/*if (!YFCCommon.isStringVoid(extnCouponScanned)) {
				if (KohlsPOCConstant.NO.equalsIgnoreCase(extnCouponScanned)) {
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON, KohlsPOCConstant.TRUE);
				} else {
					XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON, KohlsPOCConstant.FALSE);
				}
			}*/
			//End Commenting
			//Fix for defects 3843, 3845 and 3922 - End
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_PIN, XMLUtil.getAttribute(eleExtnPromotion, KohlsPOCConstant.A_EXTN_COUPON_PIN));

			String voidOrigTranNumber = "";
			String eleAction = XMLUtil.getAttribute(eleInDocOrder, KohlsPOCConstant.ATTR_ACTION);
			if (!XMLUtil.isVoid(eleAction) && KohlsPOCConstant.ACTION_CANCEL.equalsIgnoreCase(eleAction)) {
				voidOrigTranNumber = XMLUtil.getAttribute(eleInDocOrder, KohlsPOCConstant.A_POS_SEQUENCE_NO);
			}

			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_VOID_ORIG_TRAN_NUMBER, "");
			//XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH,"");
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, XMLUtil.getAttribute(eleExtnPromotion,
					KohlsPOCConstant.A_EXTN_ORIGINAL_RECEIPT_ID));

		}
		logger.debug("Exiting prepareRequestDataDetails......");
		logger.endTimer("KohlsPocPOSProcessPromotionRedemptionUE.prepareRequestDataDetails");

	}

	/*** Method Name : prepareRequestHeaderDetails Description : This method
	 * constructs Header Element which is a part of the
	 * KohlsCashRedemptionService request
	 * 
	 * @param eleInDocOrder
	 * @param headerElement
	 * @throws Exception 
	 */
	private void prepareRequestHeaderDetails(YFSEnvironment env, Element eleInDocOrder, Element headerElement) throws Exception {
		logger.beginTimer("KohlsPocPOSProcessPromotionRedemptionUE.prepareRequestHeaderDetails");

		logger.debug("Entering prepareRequestHeaderDetails......");
		String sellerOrganizationCode = eleInDocOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		sellerOrganizationCode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(sellerOrganizationCode);
		String terminalID = eleInDocOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);

		Document businessDateDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(env, eleInDocOrder);

		Element getTillStatusListForPOSOutEle = businessDateDoc.getDocumentElement();
		List<Element> tillStatusList = XMLUtil.getElementsByTagName(getTillStatusListForPOSOutEle, KohlsPOCConstant.E_TILL_STATUS);
		String businessDay = KohlsPOCConstant.EMPTY;
		if (tillStatusList.size() > KohlsPOCConstant.ZERO_INT) {
			Element tillStatusElement = tillStatusList.get(KohlsPOCConstant.ZERO_INT);
			businessDay = XMLUtil.getAttribute(tillStatusElement, KohlsPOCConstant.A_BUSINESS_DAY);
		}
		String operatorID = eleInDocOrder.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID);

		String extnRequestDateTime = "";

		Element eleInDocOrderExtn = XMLUtil.getChildElement(eleInDocOrder, KohlsPOCConstant.E_EXTN);
		if (!XMLUtil.isVoid(eleInDocOrderExtn)) {
			extnRequestDateTime = eleInDocOrderExtn.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
			// Defect 3076 Start: Updated isVoid condition for extnRequestDateTime : Suresh			
			if (!XMLUtil.isVoid(extnRequestDateTime)) {
			// Defect 3076 End: Updated isVoid condition for extnRequestDateTime : Suresh
				
				Date dt = dateFormatDateTime.parse(extnRequestDateTime);
				extnRequestDateTime = (String) dateFormatDateTime.format(dt);
			}

		}
		logger.debug(extnRequestDateTime);

		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_STORE_APE, sellerOrganizationCode);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TERMINAL, terminalID);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_BUSINESS_DATE, businessDay);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_ASSOCIATE_ID, operatorID);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAINING_MODE, KohlsPOCConstant.CONST_FALSE);

		// get current date time with Calendar()
		Calendar cal = Calendar.getInstance();

		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAN_START_DATE_TIME, !XMLUtil.isVoid(extnRequestDateTime) ? extnRequestDateTime
				: dateFormatDateTime.format(cal.getTime()));

		// Retrieve and set PosSequenceNo
		String posSequenceNo = eleInDocOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
		String strOrignSeqNo = eleInDocOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
		//PR-688 - Start
		String strExtnPsaStatus = XMLUtil.getAttribute(eleInDocOrderExtn, "ExtnPsaStatus");
		if(!YFCCommon.isVoid(strExtnPsaStatus) && !YFCCommon.isVoid(posSequenceNo)){
			XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRANSACTION_NUMBER, posSequenceNo);
			logger.debug("TranxNumber set in request : " +posSequenceNo + "And" +strOrignSeqNo);
		}else{
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRANSACTION_NUMBER, strOrignSeqNo);
		}
		logger.debug("Exiting prepareRequestHeaderDetails......");
		//PR-688 - End
		logger.endTimer("KohlsPocPOSProcessPromotionRedemptionUE.prepareRequestHeaderDetails");

	}

}
