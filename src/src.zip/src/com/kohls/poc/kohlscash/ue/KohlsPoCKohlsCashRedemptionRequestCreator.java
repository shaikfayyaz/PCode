package com.kohls.poc.kohlscash.ue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**************************************************************************
 * File : KohlsPoCKohlsCashRedemptionRequestCreator.java Author : IBM 
 * Created : August 28 2013
 * Modified :
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 28/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file creates the request for KohlsCashRedemption in case of post void
 * 
 * @author Baijayanta
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCKohlsCashRedemptionRequestCreator {
	
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCKohlsCashRedemptionRequestCreator.class.getName());
	}
	DateFormat dateFormatDateTime = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
	
	/**
	 * 
	 * This method constructs input for KohlsCashRedemption service during post void
	 * @return Document
	 * @param Element tempOrderEle
	 * @throws Exception 
	 */
	public Document createKohlsCashRedeemInput (Element tempOrderEle,YFSEnvironment yfsEnv,Element promotionElement) throws Exception {
		
		logger.debug("Entering createKohlsCashRedeemInput method..");
		DateFormat dateFormat = new SimpleDateFormat(KohlsPOCConstant.DATE_FORMAT_KOHLS_CASH);
		DateFormat dateFormatDate = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);
		
		/* get current date time with Calendar() */
		Calendar cal = Calendar.getInstance();
		final Document kohlsCashRedemptionInputDoc = XMLUtil.createDocument(KohlsPOCConstant.E_COUPON_REDEMPTION_REQ_MSG);
		Element kohlsCashRedemptionInputEle = kohlsCashRedemptionInputDoc.getDocumentElement();
		Element orderExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
		Element header = XMLUtil.createChild(kohlsCashRedemptionInputEle,KohlsPOCConstant.E_HEADER);
		
		Element promotion = promotionElement;
		
		Element extn = XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN);
		
		String sellerOrganizationCode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		sellerOrganizationCode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(sellerOrganizationCode);
		
		XMLUtil.setAttribute(header, KohlsPOCConstant.A_STORE_APE,sellerOrganizationCode );
		XMLUtil.setAttribute(header, KohlsPOCConstant.A_TERMINAL, XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_TERMINAL_ID));
		//XMLUtil.setAttribute(header, KohlsPOCConstant.ATTR_TRANS_NUM, XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO));
		XMLUtil.setAttribute(header, KohlsPOCConstant.ATTR_TRANS_NUM, XMLUtil.getAttribute(orderExtn, KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO));

		Document businessDateDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle);

		Element getTillStatusListForPOSOutEle = businessDateDoc.getDocumentElement();
		List<Element> tillStatusList = XMLUtil.getElementsByTagName(getTillStatusListForPOSOutEle, KohlsPOCConstant.E_TILL_STATUS);
		String businessDay = KohlsPOCConstant.EMPTY;
		if(tillStatusList.size() > KohlsPOCConstant.ZERO_INT){
			Element tillStatusElement =  tillStatusList.get(KohlsPOCConstant.ZERO_INT);
			businessDay = XMLUtil.getAttribute(tillStatusElement, KohlsPOCConstant.A_BUSINESS_DAY);
		}
		XMLUtil.setAttribute(header, KohlsPOCConstant.A_BUSINESS_DATE, businessDay);
		//
		XMLUtil.setAttribute(header, KohlsPOCConstant.A_ASSOCIATE_ID, XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_OPERATOR_ID));
		String extnRequestDateTime = XMLUtil.getAttribute(orderExtn, KohlsPOCConstant.A_EXTN_REQUEST_DATE_TIME);
		// Start: Updated isVoid condition for extnRequestDateTime : Suresh	
		if(!XMLUtil.isVoid(extnRequestDateTime)) {
		// End: Updated isVoid condition for extnRequestDateTime : Suresh			
			
			SimpleDateFormat reqDateFormat = new SimpleDateFormat (KohlsPOCConstant.DATE); //("MM/dd/yy HH:mm:ss");
			Date dt = reqDateFormat.parse(extnRequestDateTime);
			extnRequestDateTime = (String)dateFormatDateTime.format(dt);
		}
		XMLUtil.setAttribute(header, KohlsPOCConstant.A_TRAN_START_DATE_TIME, XMLUtil.isVoid(extnRequestDateTime) ? dateFormat.format(cal.getTime()) : extnRequestDateTime);
		
		XMLUtil.setAttribute(header, KohlsPOCConstant.A_TRAINING_MODE, KohlsPOCConstant.FALSE);
		
		Element data = XMLUtil.createChild(kohlsCashRedemptionInputEle,KohlsPOCConstant.E_DATA);
		
		String extnCouponScanned = XMLUtil.getAttribute(extn, KohlsPOCConstant.A_EXTN_COUPON_SCANNED);
		/* If extnCouponScanned is 'N' set  HandKeyedCoupon to true
		 * else set HandKeyedCoupon to false */
		//Fix for defects 3843, 3845 and 3922 - Start
		String extnInputMethod = XMLUtil.getAttribute(extn, "ExtnInputMethod");
		//logger.debug("The extnCouponScanned and  extnInputMethod value are :" + extnCouponScanned +"  " +extnInputMethod);
		if(!YFCCommon.isStringVoid(extnInputMethod)){
			if(extnInputMethod.equalsIgnoreCase("K")){
				XMLUtil.setAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.TRUE); 
			}else{
				XMLUtil.setAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.FALSE); 
			}
			//logger.debug("The HAND_KEYED_COUPON value inside If block is : " + XMLUtil.getAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON));
		}else{
			if(!YFCCommon.isStringVoid(extnCouponScanned) && extnCouponScanned.equalsIgnoreCase(KohlsPOCConstant.NO)){
				XMLUtil.setAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.TRUE); 
			}else{
				XMLUtil.setAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.FALSE);
			}
			//logger.debug("The HAND_KEYED_COUPON value inside Else block is : " + XMLUtil.getAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON));
		}
		//Start Commenting
		/*if(!YFCCommon.isStringVoid(extnCouponScanned)) {
			if(KohlsPOCConstant.NO.equalsIgnoreCase(extnCouponScanned)) {
				XMLUtil.setAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.TRUE); 
			} else {
				XMLUtil.setAttribute(data, KohlsPOCConstant.A_HAND_KEYED_COUPON , KohlsPOCConstant.FALSE); 	
			}
		}*/
		//End Commenting
		//Fix for defects 3843, 3845 and 3922 - End
		XMLUtil.setAttribute(data, KohlsPOCConstant.A_COUPON_NUMBER, XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_PROMOTION_ID));
		String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
		
		String overrideMaxAdjustment = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
		
		if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
			overrideAdjustmentValue = overrideMaxAdjustment;
		} else {
			overrideAdjustmentValue = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
		}
		
		XMLUtil.setAttribute(data, KohlsPOCConstant.A_DISCOUNT_AMOUNT, String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue))));
		XMLUtil.setAttribute(data, KohlsPOCConstant.A_PIN, XMLUtil.getAttribute(extn, KohlsPOCConstant.A_EXTN_COUPON_PIN));
		//XMLUtil.setAttribute(data, KohlsPOCConstant.A_VOID_ORIG_TRAN_NUMBER, XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO));
		XMLUtil.setAttribute(data, KohlsPOCConstant.A_VOID_ORIG_TRAN_NUMBER, XMLUtil.getAttribute(orderExtn, KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO));
		XMLUtil.setAttribute(data, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, "");
		
		if(logger.isDebugEnabled()){
			logger.debug(XMLUtil.getXMLString(kohlsCashRedemptionInputDoc));
			logger.debug("Exiting createKohlsCashRedeemInput method.....");
		}
		return kohlsCashRedemptionInputDoc;
		
	}


}
