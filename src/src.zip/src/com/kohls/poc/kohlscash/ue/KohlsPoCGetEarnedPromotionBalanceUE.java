package com.kohls.poc.kohlscash.ue;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.util.webserviceUtil.WebServiceCaller;
import com.tgcs.tcx.gravity.nrsc.kohls.pos.japi.ue.order.getEarnedPromotionBalanceUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoCGetEarnedPromotionBalanceUE.java 
 * Author : IBM 
 * Created : January 21 2015 
 * Modified : January 21 2015 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 21/01/2015 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This class is invoked when getEarnedPromotionBalanceUE is invoked from Gravity
 * This class is responsible for preparing a request to the Kohls cash inquiry service
 * and returning a response doc with history data, balance
 *  
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCGetEarnedPromotionBalanceUE extends KOHLSBaseApi implements getEarnedPromotionBalanceUE {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCGetEarnedPromotionBalanceUE.class);


	
	Calendar cal = Calendar.getInstance();

	
	

	/**
	 * Description : This method accepts the Kohls cash inquiry input doc and returns the response from the Kohls Cash inquiry Service
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws YFSUserExitException
	 */
	public Document getEarnedPromotionBalanceUE(YFSEnvironment env, Document inDoc) throws YFSUserExitException  {
		
		logger.beginTimer("KohlsPoCGetEarnedPromotionBalanceUE.getEarnedPromotionBalanceUE");
		
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetEarnedPromotionBalanceUE inDoc:" + XMLUtil.getXMLString(inDoc));

		Document outDoc = null;

		Element promotionInquiryEle = inDoc.getDocumentElement();

		
		try {
			Document kohlsCashRequestDoc = prepareKohlsCashStandaloneInquiryRequest(env, promotionInquiryEle);
			
			Document kohlsCashResponseDoc = null;
			
			String kcsEndpoint;
			
			KohlsCashManager kcm = new KohlsCashManager(env);
			
			String organizationCode = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
			
			boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(organizationCode);
			
			if(logger.isDebugEnabled())
				logger.debug("######Rule value for OMS KC in KohlsPoCGetEarnedPromotionBalanceUE.getEarnedPromotionBalanceUE: " + omsKCEnabled);
			
			if(omsKCEnabled) {
				kcsEndpoint = "OMS KC";
				
				kcm.loadEvents(organizationCode);
				//Use KCM instead of service call to KCS
				kohlsCashResponseDoc = kcm.kohlsCashInquiry(kohlsCashRequestDoc);
			}
			else {
				kcsEndpoint = "KohlsPoCKohlsCashInquiryWebService";
				
				kohlsCashResponseDoc = KOHLSBaseApi.invokeService(env,
						KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_INQUIRY_WEB_SERVICE, kohlsCashRequestDoc);
			}
			
			if(logger.isDebugEnabled()) {
				logger.debug("######Request to " + kcsEndpoint + "--KohlsPoCGetEarnedPromotionBalanceUE######" + XMLUtil.getXMLString(kohlsCashRequestDoc));
				logger.debug("######Response to " + kcsEndpoint + "--KohlsPoCGetEarnedPromotionBalanceUE######"+XMLUtil.getXMLString(kohlsCashResponseDoc));
			}	
				
			String respStr = XMLUtil.getXMLString(kohlsCashResponseDoc);
			
			outDoc = prepareKohlsCashStandaloneInquiryResponse(env, kohlsCashResponseDoc,inDoc);
			
			String outDocString = XMLUtil.getXMLString(outDoc);
			
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsPoCGetEarnedPromotionBalanceUE outDoc:" + XMLUtil.getXMLString(outDoc));
			
		}  catch (Exception e) {
			logger.error(e);
			
			logger.debug(e.getClass().getName());
			
			
			
			
				YFSException es = (YFSException) e;
				logger.debug(es.getClass().getName());
				if (e.getClass().getName()
						.equalsIgnoreCase("com.yantra.yfs.japi.YFSException")
						&& (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")
								|| es.getErrorCode().equalsIgnoreCase("EXTN_IO")
								|| es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")
								|| es.getErrorCode().equalsIgnoreCase(
										"javax.xml.soap.SOAPException") || es
								.getErrorCode().equalsIgnoreCase(
										"javax.xml.ws.soap.SOAPFaultException"))) {
					
					logger.debug("EXTN_CONNECT OR EXTN_IO OR EXTN_OTHER EXCEPTION OCCURRED");
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_BALANCE, "0.00");
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F9");
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_AUTH_TIME, "0000");
					
					outDoc = inDoc;
					
					if(logger.isDebugEnabled())
						logger.debug("KohlsPoCGetEarnedPromotionBalanceUE outDoc DURING EXCEPTION :" + XMLUtil.getXMLString(outDoc));
				
			}else{
				throw new YFSUserExitException(e.getMessage());
			}
			
		}
		
		
		logger.endTimer("KohlsPoCGetEarnedPromotionBalanceUE.getEarnedPromotionBalanceUE");
		
		if(!YFCCommon.isVoid(outDoc)){
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsPoCGetEarnedPromotionBalanceUE outDoc:" + XMLUtil.getXMLString(outDoc));
	    }
		
		return outDoc;

	}
	
	/*
	<PromotionInquiry TerminalID="" SellerOrganizationCode="" IsTraining="" OrderDate="" 
		SequenceNo="" CouponNumber="" CouponReceiptID="" CouponPIN="" 
		
		CouponAuthResponse="" CouponAuthCodeReason="" CouponBalance="" 
		AuthTime="" CouponHistory=""/>
	*/
	

	/**Method : prepareKohlsCashStandaloneInquiryResponse
	 * Description : This method returns the response from the Kohls Cash inquiry Service
	 * @param env
	 * @param kohlsCashResponseDoc
	 * @param ueOutDoc
	 * @return
	 */
	private Document prepareKohlsCashStandaloneInquiryResponse(YFSEnvironment env, Document kohlsCashResponseDoc, Document ueOutDoc) {
		
		logger.beginTimer("KohlsPoCGetEarnedPromotionBalanceUE.prepareKohlsCashStandaloneInquiryResponse");

		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);

		
		Element promotionInquiryEle = ueOutDoc.getDocumentElement();
		Element kohlsCashResElement = kohlsCashResponseDoc.getDocumentElement();
		
		// Reading the Data element from the KC response
		List eleDataList = XMLUtil.getElementsByTagName(kohlsCashResElement, KohlsPOCConstant.E_DATA);
		if (!(XMLUtil.isVoid(eleDataList)) && (eleDataList.size() > KohlsPOCConstant.ZERO_INT)) {
			Element eleData = (Element) eleDataList.get(0);
			// Retrieving authResponseCode attribute which will hold, {0,2,7.9}
			String authResponseCode = eleData.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
			
			// authApprovalNum stores 6 digit response from KC Service
			String couponAuthCode = eleData.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);
			
			String couponBalance = eleData.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
			
			String couponType = eleData.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
			
			String couponStatus = eleData.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
			
			//Release 3 Sprint 3 changes
			String expiryDate = eleData.getAttribute(KohlsPOCConstant.A_EXPIRATION_DATE);
			
			
			// checking for void of couponBalance 
			String couponBalanceDouble = (!YFCCommon.isVoid(couponBalance))?(twoDForm.format(Math.abs(Double.valueOf(couponBalance)))):"0.00";
			
			// calculating the time taken from a static variable for the webservice call
			long timetaken = WebServiceCaller.timeTakenLong;
			
			
			
			if(!YFCCommon.isVoid(timetaken)){
				String formattedAuthTime = KohlsPoCPnPUtil.prepadAuthTimeWithZeros(String.valueOf(timetaken));
				XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_AUTH_TIME, String.valueOf(formattedAuthTime));
			}
			
			
			if (!XMLUtil.isVoid(authResponseCode)) {		
				
				

				// Success Response Code, history data and coupon balance
				if (KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode)) {
					
					String historyData = XMLUtil.getAttribute(eleData, KohlsPOCConstant.A_HISTORY_DATA);
			

					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_HISTORY, historyData);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_BALANCE, couponBalanceDouble);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F"+authResponseCode);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_CODE,couponAuthCode);
					

				// 2 - Soft Refferal, 9- Offline scenario
				} else if ((KohlsPOCConstant.TWO.equalsIgnoreCase(authResponseCode) || (KohlsPOCConstant.NINE
						.equalsIgnoreCase(authResponseCode)))) {

					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F"+authResponseCode);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_CODE,couponAuthCode);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_BALANCE, couponBalanceDouble);

					// 7 Response code is for Hard Decline.
				} else if (KohlsPOCConstant.SEVEN.equalsIgnoreCase(authResponseCode)) {
					
					String authApprovalNum = eleData.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);					

					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F"+authResponseCode);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_REASON, authApprovalNum);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_BALANCE, couponBalanceDouble);

					// 8 Response code is for duplicate req, and validation
					// code has be entered in this case from gravity
				} else if (null != authResponseCode && KohlsPOCConstant.EIGHT.equalsIgnoreCase(authResponseCode)) {

					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F"+authResponseCode);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_CODE,couponAuthCode);
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_BALANCE, couponBalanceDouble);
				}

				// Added else condition to handle couponType=KOHLSCASHNOAUTH and couponStatus=ACTIVE, EVEN THIS SHOULD BE CONSIDERED AS F9 FROM FDS
			}else{
				if(( (!YFCCommon.isVoid(couponType)) && KohlsPOCConstant.CONST_KOHLS_CASH_NO_AUTH.equalsIgnoreCase(couponType)) 
						&& (( (!YFCCommon.isVoid(couponStatus)) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)))){
					
					
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_AUTH_RESPONSE, "F9");
					XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_BALANCE, couponBalanceDouble);
				}
			}
			
			// BR 914 changes for including expiration date for RKC inquiry
			//Release 3 Sprint 3 changes
			setKohlsCashExpiryDate(promotionInquiryEle, expiryDate);
			
			// Start:  Sprint 7 CR 3563 : Suresh
			
			// setting UE CouponStatus attribute  to POSTREDEMPTION , if the couponStatus from KC response is POSTREDEMPTION
			if((!YFCCommon.isVoid(couponStatus) )&& (KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus))){
				XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_STATUS, KohlsPOCConstant.CONST_POST_REDEMPTION);
			}else{
				XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_STATUS, "");
			}
			
			// End: Sprint 7 CR 3563 : Suresh
			
				
			

		}
		
		logger.endTimer("KohlsPoCGetEarnedPromotionBalanceUE.prepareKohlsCashStandaloneInquiryResponse");

		return ueOutDoc;

	}

	/*
	 * 
	 * <PromotionInquiry AssociateID ="" TerminalID="" SellerOrganizationCode="" isTraining="" 
	 * OrderDate="" SequenceNo="" CouponNumber="" CouponReceiptID="" CouponPIN="" />
	 */

	/**
	 * Method : prepareKohlsCashStandaloneInquiryRequest
	 * Description : This method prepares InquiryRequest to the Kohls Cash Inquiry Service
	 * @param env
	 * @param promotionInquiryEle
	 * @return Document 
	 * @throws ParserConfigurationException
	 * @throws ParseException
	 */
	private Document prepareKohlsCashStandaloneInquiryRequest(YFSEnvironment env, Element promotionInquiryEle)
			throws ParserConfigurationException, ParseException {

		logger.beginTimer("KohlsPoCGetEarnedPromotionBalanceUE.prepareKohlsCashStandaloneInquiryRequest");
		
		String terminal = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_TERMINAL_ID);

		String shipNode = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		// Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);

		// workaround to work with Gravity UI timebeing
		//String isTraining = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_IS_TRAINING);
		String isTraining = XMLUtil.getAttribute(promotionInquiryEle, "isTraining");
		String orderDate = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_ORDER_DATE);
		String sequenceNo = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_SEQUENCE_NO);
		String couponNumber = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_NUMBER);
		String couponTransactionNumber = XMLUtil.getAttribute(promotionInquiryEle,
				KohlsPOCConstant.A_COUPON_RECEIPT_ID);
		String couponPIN = XMLUtil.getAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_PIN);
		
		String handKeyedCoupon=KohlsPOCConstant.FALSE;
		
		if(!YFCCommon.isVoid(couponPIN)){
			handKeyedCoupon = KohlsPOCConstant.TRUE;
		}

		String businessDay = KohlsPOCConstant.EMPTY;
		//Defect 5140 fix - Start
		DateFormat dateFormatDate = new SimpleDateFormat("yyyy-MM-dd");
		//Defect 5140 fix - End
		DateFormat businessDayDateFormat = new SimpleDateFormat("yyyy/MM/dd");
		DateFormat dateFormatDateTime = new SimpleDateFormat("yyyy/MM/dd'T'HH:mm:ss");

		Date businessDayObj = dateFormatDate.parse(orderDate);
		if (!YFCCommon.isVoid(businessDayObj)) {
			businessDay = businessDayDateFormat.format(businessDayObj);
		}

		String tranStartDateTime = KohlsPOCConstant.EMPTY;
		if (!YFCCommon.isStringVoid(orderDate)) {
			// commented the below line,to make it work with Gravity timebeing
			//SimpleDateFormat reqDateFormat = new SimpleDateFormat("MM/dd/yyyy'T'HH:mm:ss");
			//Defect 5140 fix - Start
			SimpleDateFormat reqDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			//Defect 5140 fix - End
			Date dt = reqDateFormat.parse(orderDate);
			tranStartDateTime = (String) dateFormatDateTime.format(dt);
		}
		
		// retrieving AssociateID
		String associateID = XMLUtil.getAttribute(promotionInquiryEle,KohlsPOCConstant.A_ASSOCIATE_ID);
		
		

		// KohlsCashInquiryDocument formation
		Document kohlsCashinputDoc = XMLUtil.createDocument(KohlsPOCConstant.E_COUPON_INQUIRY_REQUEST_MSG);
		Element KohlsCashinputElement = kohlsCashinputDoc.getDocumentElement();

		Element headerElement = XMLUtil.createChild(KohlsCashinputElement, KohlsPOCConstant.E_HEADER);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_STORE_APE, shipNode);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TERMINAL, terminal);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRANSACTION_NUMBER, sequenceNo);

		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_BUSINESS_DATE, businessDay);
		
		// setting AssociateID
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_ASSOCIATE_ID, associateID);
		XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAN_START_DATE_TIME,
				XMLUtil.isVoid(tranStartDateTime) ? dateFormatDateTime.format(cal.getTime()) : tranStartDateTime);
		
		if(!YFCCommon.isVoid(isTraining)){
			XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAINING_MODE, isTraining.equalsIgnoreCase("Y")?"true":"false");
		}
		

		Element dataElement = XMLUtil.createChild(KohlsCashinputElement, KohlsPOCConstant.E_DATA);
		
		XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON, handKeyedCoupon);
		XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_COUPON_NUMBER, couponNumber);
		XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_PIN, couponPIN);

		XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_INQUIRY_TRANSACTION, KohlsPOCConstant.TRUE);
		

		if (null != couponTransactionNumber && !YFCCommon.isStringVoid(couponTransactionNumber)) {
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, couponTransactionNumber);
		} else {
			XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, KohlsPOCConstant.EMPTY);
		}

		logger.endTimer("KohlsPoCGetEarnedPromotionBalanceUE.prepareKohlsCashStandaloneInquiryRequest");
		
		return kohlsCashinputDoc;

	}
	
	/**
 	 * @param promotionInquiryEle
 	 * @param expiryDate
 	 * This is change for BR 914. RKC Inquiry will have expirationdate from KCS.
 	 * Expiration date needs to be sent to Toshiba as CouponExpDate
	 * Release 3 Sprint 3 changes
 	 */
 	private void setKohlsCashExpiryDate(Element promotionInquiryEle,
 			String expiryDate) {
 		if(!YFCCommon.isVoid(expiryDate)){
 			XMLUtil.setAttribute(promotionInquiryEle, KohlsPOCConstant.A_COUPON_EXP_DATE,expiryDate);
 			
 		}
 	}

}
