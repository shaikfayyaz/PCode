package com.kohls.poc.kohlscash.ue;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;

import org.w3c.dom.NodeList;

import com.kohls.common.util.XPathUtil;

import com.tgcs.tcx.gravity.nrsc.kohls.pos.japi.ue.order.POSGetKohlsCashActivationDetailsUE;

/**************************************************************************
 * File : KohlsPocPostSaleKohlsCashActivation.java Author : IBM Created : March 11
 * 2015 Modified : March 11 2015 Version : 0.1
 ***************************************************************************** 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the activation request using a synchronous
 * web service call to the kohlsCashActivation Service
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPocPostSaleKohlsCashActivation extends KOHLSBaseApi implements POSGetKohlsCashActivationDetailsUE{

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPocPostSaleKohlsCashActivation.class);

	String strCouponNumber= null;
	String strReceiptID = null;

	/* Sample input to user exit : 
	 * <KohlsCashActivation SequenceNo="32" AssociateID="1234567" TerminalID="95" Store="9978" BusinessDate="2015-02-18" CouponNumber="123456923653873" 
	 * ReceiptID="12345677897800808" isTraining="N" TranStartDateTime="2014-12-5T09:00:00" /> */

	public Document getKohlsCashActivationDetailsUE(final YFSEnvironment env,Document inputDoc ) throws YFSException{

		logger.info("Inside the method constructKohlsCashActivationDocument.");

		Element eleKohlsCashActivation = (Element)inputDoc.getDocumentElement();

		//String strSequenceNo = eleKohlsCashActivation.getAttribute("SequenceNo");
		String strAssociateID = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.A_ASSOCIATE_ID);
		String strTerminalID = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
		String strStore = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.A_STORE_APE);
		String strBusinessDate = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.A_BUSINESS_DATE);
		strCouponNumber = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.A_COUPON_NUMBER);
		strReceiptID = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH);
		String strisTraining = eleKohlsCashActivation.getAttribute("isTraining");
		String strTranStartDateTime = eleKohlsCashActivation.getAttribute(KohlsPOCConstant.A_TRAN_START_DATE_TIME);
		String strSequenceNo = eleKohlsCashActivation.getAttribute("SequenceNo");

		// creating the request document 

		Document reqDoc = YFCDocument.createDocument("KohlsCashActivationTransactionRequestMsg")
				.getDocument();
		Element eleRoot = reqDoc.getDocumentElement();

		Element eleHeader = (Element)XMLUtil.createChild(eleRoot, KohlsPOCConstant.E_HEADER); 

		Element eleStore = XMLUtil.createChild(eleHeader, KohlsPOCConstant.A_STORE_APE);
		eleStore.setTextContent(strStore);				
		eleHeader.appendChild(eleStore);

		Element eleTerminal = XMLUtil.createChild(eleHeader, KohlsPOCConstant.A_TERMINAL);
		eleTerminal.setTextContent(strTerminalID);
		eleHeader.appendChild(eleTerminal);

		Element eleBusinessDate = XMLUtil.createChild(eleHeader, KohlsPOCConstant.A_BUSINESS_DATE);
		eleBusinessDate.setTextContent(strBusinessDate);
		eleHeader.appendChild(eleBusinessDate);

		Element eleTransactionNumber = XMLUtil.createChild(eleHeader,KohlsPOCConstant.ATTR_TRANS_NUM);
		eleTransactionNumber.setTextContent(strSequenceNo);
		eleHeader.appendChild(eleTransactionNumber);

		Element eleAssociateID = XMLUtil.createChild(eleHeader,KohlsPOCConstant.A_ASSOCIATE_ID);
		eleAssociateID.setTextContent(strAssociateID);
		eleHeader.appendChild(eleAssociateID);

		Element eleTranStartDateTime = XMLUtil.createChild(eleHeader, KohlsPOCConstant.A_TRAN_START_DATE_TIME);
		eleTranStartDateTime.setTextContent(strTranStartDateTime);
		eleHeader.appendChild(eleTranStartDateTime);

		Element eleTrainingMode = XMLUtil.createChild(eleHeader, KohlsPOCConstant.A_TRAINING_MODE);
		if ("Y".equalsIgnoreCase(strisTraining)||"True".equalsIgnoreCase(strisTraining)){
			eleTrainingMode.setTextContent("True");
		} else {
			eleTrainingMode.setTextContent("False");
		}
		eleHeader.appendChild(eleTrainingMode);
		Element eleData = (Element)XMLUtil.createChild(eleRoot, KohlsPOCConstant.E_DATA); 
		eleRoot.appendChild(eleData);

		Element eleReceiptID = XMLUtil.createChild(eleData, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH);
		eleReceiptID.setTextContent(strReceiptID);
		eleData.appendChild(eleReceiptID);

		Element eleKohlsCashID = XMLUtil.createChild(eleData, "KohlsCashID");
		eleKohlsCashID.setTextContent(strCouponNumber);
		eleData.appendChild(eleKohlsCashID);
		Document outputdoc = null;

		try{
			KohlsCashManager kcm = new KohlsCashManager(env);
			Document respKohlsCashDoc = null;
			
			boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(strStore);
			
			if(logger.isDebugEnabled())
				logger.debug("######Rule value for OMS KC in KohlsPocPostSaleKohlsCashActivation.getKohlsCashActivationDetailsUE: " + omsKCEnabled);
			
			
						
			if(omsKCEnabled) {
				if(logger.isDebugEnabled())
					logger.debug("OMS KC input: "+XMLUtil.getXMLString(reqDoc));
				
				kcm.loadEvents(strStore);
				//Use KCM
				respKohlsCashDoc = kcm.kohlsCashActivationTransaction(reqDoc);
				
				if(logger.isDebugEnabled())
					logger.debug("OMS KC output: "+XMLUtil.getXMLString(respKohlsCashDoc));
			}
			else {
				if(logger.isDebugEnabled())
					logger.debug("KCS input: "+XMLUtil.getXMLString(reqDoc));
				
				//Use KCS
				respKohlsCashDoc = invokeService(env, "KohlsPOCPostSaleKohlsCashActivationWebService",reqDoc);
				
				if(logger.isDebugEnabled())
					logger.debug("KCS output: "+XMLUtil.getXMLString(respKohlsCashDoc));
			}
			
			outputdoc = createResponseDocumentfromWS(env, respKohlsCashDoc, omsKCEnabled);
		}
		catch(YFSException es){
			
			logger.debug("Catching the exception and preparing the offline response");
			Document outDoc = YFCDocument.createDocument("KohlsCashActivation")
					.getDocument();
			Element eleRootOutDoc = outDoc.getDocumentElement();

			eleRootOutDoc.setAttribute("SequenceNo",strSequenceNo);
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_ASSOCIATE_ID,strAssociateID);
			eleRootOutDoc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,strTerminalID);
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_STORE_APE,strStore);
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_BUSINESS_DATE,strBusinessDate);
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_COUPON_NUMBER,strCouponNumber);
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_RECEIPT_ID,strReceiptID);
			eleRootOutDoc.setAttribute("isTraining",strisTraining);

			// TranStartDateTime
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_TRAN_START_DATE_TIME,strTranStartDateTime);

			/*if(es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT") || es.getErrorCode().equalsIgnoreCase(
					"EXTN_IO") || es.getErrorCode().equalsIgnoreCase("EXTN_OTHER") || es.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")
					&& es.getErrorCode().equalsIgnoreCase("javax.xml.soap.SOAPException")
					|| es.getErrorCode().equalsIgnoreCase("javax.xml.ws.soap.SOAPFaultException")){
*/
				//logger.debug("Catching the exception offline and SOAP exceptions");

				eleRootOutDoc.setAttribute("ErrorMessage", "Kohl’s Cash cannot be activated.  System is unavailable");
				eleRootOutDoc.setAttribute(KohlsPOCConstant.A_COUPON_TYPE, "NONE");

				return outDoc;
			//}
		}

		catch(Exception e){
			e.printStackTrace();
		}	

		return outputdoc;
	}
	
	/*
	 * This function preapres the response 
	 * @param env
	 * @param respKohlsCashDoc
	 * @return outDoc
	 * And also modifies the output fetched from KohlsPocKohlsCashActivationWebService service in the format : 
	 * 
	 * <KohlsCashActivation CouponType="KOHLSCASHAUTH" EventID="12345" TerminalID="95" EventName="" ReceiptMessageLine1="" ReceiptMessageLine2="" CouponAmount="10.00" 
	 * StartDate="2015-02-18" EndDate="2015-03-18" CouponNumber="123456923653873" ValidationCode="151515" ErrorMessage="" ReceiptID="12345677897800808" />
	 */

	private Document createResponseDocumentfromWS(YFSEnvironment env,
			Document respKohlsCashDoc, boolean omsKcEnabled) throws Exception {
		// TODO Auto-generated method stub
		
		
		if(logger.isDebugEnabled())
			logger.debug("Printing the respdoc"+ XMLUtil.getXMLString(respKohlsCashDoc));

		Document outDoc = YFCDocument.createDocument("KohlsCashActivation")
				.getDocument();
		Element eleRootOutDoc = outDoc.getDocumentElement();
		Element eleTransactionResponseMsg = null;
		
		if(omsKcEnabled) {
			eleTransactionResponseMsg = respKohlsCashDoc.getDocumentElement();
		}
		else {
			eleTransactionResponseMsg = (Element)((NodeList)XPathUtil.getNodeList(respKohlsCashDoc.getDocumentElement(),"/KohlsCashActivationTransactionResponse/KohlsCashActivationTransactionResult/KohlsCashActivationTransactionResponseMsg")).item(0);
		}
		
		Element elerespHeader = XMLUtil.getChildElement(eleTransactionResponseMsg, KohlsPOCConstant.E_HEADER);
		Element elerespData = XMLUtil.getChildElement(eleTransactionResponseMsg, KohlsPOCConstant.E_DATA);
		String strTerminal = elerespHeader.getAttribute(KohlsPOCConstant.A_TERMINAL);
		String strActivationStartDate = elerespData.getAttribute("ActivationStartDate");
		String strActivationEndDate = elerespData.getAttribute("ActivationEndDate");
		String strCashValue = elerespData.getAttribute("CashValue");
		String strCouponType = elerespData.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
		String strErrorMessageToDisplay = elerespData.getAttribute(KohlsPOCConstant.A_ERROR_MESSAGE_TO_DISPLAY);
		String strEventID = elerespData.getAttribute(KohlsPOCConstant.E_EVENT_ID);
		String strReceiptMessageLine1 = elerespData.getAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_1);
		String strReceiptMessageLine2 = elerespData.getAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_2);
		String strValidationCode = elerespData.getAttribute(KohlsPOCConstant.E_VALIDATION_CODE);

		eleRootOutDoc.setAttribute(KohlsPOCConstant.A_COUPON_TYPE, strCouponType);
		eleRootOutDoc.setAttribute("ErrorMessage", strErrorMessageToDisplay);
		if(!("KOHLSCASHAUTH".equalsIgnoreCase(strCouponType))){
			eleRootOutDoc.setAttribute(KohlsPOCConstant.A_COUPON_TYPE, "NONE");
		}		
		eleRootOutDoc.setAttribute(KohlsPOCConstant.E_EVENT_ID, strEventID);
		eleRootOutDoc.setAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_1, strReceiptMessageLine1);
		eleRootOutDoc.setAttribute(KohlsPOCConstant.E_RECEIPT_MESSAGE_LINE_2, strReceiptMessageLine2);
		eleRootOutDoc.setAttribute("CouponAmount", strCashValue);
		eleRootOutDoc.setAttribute("StartDate", strActivationStartDate);
		eleRootOutDoc.setAttribute("EndDate", strActivationEndDate);
		eleRootOutDoc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminal);
		eleRootOutDoc.setAttribute(KohlsPOCConstant.A_COUPON_NUMBER, strCouponNumber);
		eleRootOutDoc.setAttribute(KohlsPOCConstant.E_VALIDATION_CODE, strValidationCode);
		//eleRootOutDoc.setAttribute("ErrorMessage", strErrorMessage);
		eleRootOutDoc.setAttribute(KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, strReceiptID);

		return outDoc;
	}

}
