package com.kohls.poc.kohlscash.ue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**************************************************************************
 * File : KohlsPoCKohlsCashInquiryRequestCreator.java Author : IBM 
 * Created : August 12 2013
 * Modified :
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 28/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file creates the request for KohlsCashInquiry in case of KohlsCash Call
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCKohlsCashInquiryRequestCreator {
	
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPocPOSProcessPromotionRedemptionUE.class.getName());
	}
	public Document constructKohlsCashInquiryDocument(YFSEnvironment yfsEnv, Element tempOrderEle, Element newPromotionEle,String shipNode) throws Exception {
	logger.beginTimer("KohlsPoCKohlsCashInquiryRequestCreator.constructKohlsCashInquiryDocument");
	DateFormat dateFormat = new SimpleDateFormat(KohlsPOCConstant.DATE_FORMAT_KOHLS_CASH);
	DateFormat dateFormatDate = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);
	DateFormat dateFormatDateTime = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
	// get current date time with Calendar()
	Calendar cal = Calendar.getInstance();
	String businessDay = KohlsPOCConstant.EMPTY;
	
   String isPSAChangeOrder = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_PSA_CHANGE_ORDER);
   logger.debug("KohlsPoCKohlsCashInquiryRequestCreator.constructKohlsCashInquiryDocument : isPSAChangeOrder value :" + isPSAChangeOrder);
	Element extnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
	String terminal = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_TERMINAL_ID);
	String posSequenceNo = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
	String orderDate = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORDER_DATE);
	Document businessDateDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle);
	
	Element getTillStatusListForPOSOutEle = businessDateDoc.getDocumentElement();
	List<Element> tillStatusList = XMLUtil.getElementsByTagName(getTillStatusListForPOSOutEle, KohlsPOCConstant.E_TILL_STATUS);

	if(tillStatusList.size() > KohlsPOCConstant.ZERO_INT){
		Element tillStatusElement =  tillStatusList.get(KohlsPOCConstant.ZERO_INT);
		businessDay = XMLUtil.getAttribute(tillStatusElement, KohlsPOCConstant.A_BUSINESS_DAY);
	}
if (!XMLUtil.isVoid(orderDate)) {
      Date orderDateObj = dateFormatDate.parse(orderDate);
      if (!XMLUtil.isVoid(orderDateObj)) {
         orderDate = dateFormatDate.format(orderDateObj);
      }
   }
	// Update sale businessDay to tillstatus/@businessDay during PSA.
	if (KohlsPOCConstant.YES.equalsIgnoreCase(isPSAChangeOrder)) {
		String saleBusinessDay = getSaleBusineday( yfsEnv, tempOrderEle );
		businessDay = !YFCCommon.isStringVoid(saleBusinessDay)?saleBusinessDay:orderDate;
	}
	String operatorID = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_OPERATOR_ID);
	String extnRequestDateTime = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_REQUEST_DATE_TIME);
	if(!YFCCommon.isStringVoid(extnRequestDateTime)){
		SimpleDateFormat reqDateFormat = new SimpleDateFormat (KohlsPOCConstant.DATE);
		Date dt = reqDateFormat.parse(extnRequestDateTime);
		extnRequestDateTime = (String)dateFormatDateTime.format(dt);
	}
	
	String transactionNo = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_TRANSACTION_NO);

	Element extnPromotionEle = XMLUtil.getChildElement(newPromotionEle, KohlsPOCConstant.E_EXTN);
	String extnCouponScanned = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_SCANNED);
	//Fix for defects 3843, 3845 and 3922 - Start
	String extnInputMethod = XMLUtil.getAttribute(extnPromotionEle, "ExtnInputMethod");
	if(!YFCCommon.isVoid(extnInputMethod)){
		if(extnInputMethod.equalsIgnoreCase("K")){
			extnCouponScanned = KohlsPOCConstant.TRUE;
		}else{
			extnCouponScanned = KohlsPOCConstant.FALSE;
		}
	}else{
		if(!YFCCommon.isVoid(extnCouponScanned) && extnCouponScanned.equalsIgnoreCase(KohlsPOCConstant.NO)){
			extnCouponScanned = KohlsPOCConstant.TRUE;
		}else{
			extnCouponScanned = KohlsPOCConstant.FALSE;
			logger.debug("Logger came in Coupon - True block");
		}
	}
	//Start Commenting
	/*if(!YFCCommon.isStringVoid(extnCouponScanned)){
		if(KohlsPOCConstant.YES.equalsIgnoreCase(extnCouponScanned)){
			extnCouponScanned = KohlsPOCConstant.FALSE;

		}
		else{
			extnCouponScanned = KohlsPOCConstant.TRUE;
		}
	}*/
	//End Commenting
	//Fix for defects 3843, 3845 and 3922 - End
	String promotionId = XMLUtil.getAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_ID);
	String extnCouponPin = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_PIN);
	String extnOriginalReceiptID = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_ORIGINAL_RECEIPT_ID);
	//KohlsCashInquiryDocument formation
	Document kohlsCashinputDoc = XMLUtil.createDocument(KohlsPOCConstant.E_COUPON_INQUIRY_REQUEST_MSG);
	Element KohlsCashinputElement = kohlsCashinputDoc.getDocumentElement();
	Element headerElement = XMLUtil.createChild(KohlsCashinputElement, KohlsPOCConstant.E_HEADER);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_STORE_APE, shipNode);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TERMINAL, terminal);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRANSACTION_NUMBER, posSequenceNo);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_BUSINESS_DATE, businessDay);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_ASSOCIATE_ID, operatorID);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAN_START_DATE_TIME, 
			XMLUtil.isVoid(extnRequestDateTime) ? dateFormat.format(cal.getTime()) : extnRequestDateTime);
	XMLUtil.setAttribute(headerElement, KohlsPOCConstant.A_TRAINING_MODE, KohlsPOCConstant.CONST_FALSE);

	Element dataElement = XMLUtil.createChild(KohlsCashinputElement, KohlsPOCConstant.E_DATA);
	XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_HAND_KEYED_COUPON, extnCouponScanned);
	XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_COUPON_NUMBER, promotionId);
	XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_PIN, extnCouponPin);
	if(null != extnOriginalReceiptID && !YFCCommon.isStringVoid(extnOriginalReceiptID)){
	XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, extnOriginalReceiptID);
	}
	//Modifying the else loop to set blank ReceiptID instead of Txn no - fix for CPE-1037(PR-348)
	else
	{
		XMLUtil.setAttribute(dataElement, KohlsPOCConstant.A_RECEIPT_ID_KOHLS_CASH, "");
	}
	XMLUtil.getXMLString(kohlsCashinputDoc);
	logger.beginTimer("KohlsPoCKohlsCashInquiryRequestCreator.constructKohlsCashInquiryDocument");
	return kohlsCashinputDoc;
	}
	
   /**
    * This method gets saleBusinessday during PSA.
    * First will try to get saleBusinessday from RS response if not available,
    * get saleBusinessday from transaction audit logic, if both are not available,
    * use the order/@orderdate as ultimate fallback
    * Created By Bharath Nagaraju *
    * 
    * @param env
    * @param tempOrderEle
    */
   public String getSaleBusineday( YFSEnvironment env, Element tempOrderEle )
   {
      // Fetch saleBusinessDay from RS response for sale order.
      String saleBusinessDay = getSaleBusinessDayfromReturnService( env, tempOrderEle );
      // If result of getSaleBusinessDayfromReturnService is also null fetch saleBusinessday from getSaleBusinessDayfromTransactionAudit
      if ( YFCCommon.isVoid( saleBusinessDay ) )
      {
         saleBusinessDay = getSaleBusinessDayfromTransactionAudit( env, tempOrderEle );
      }
      return saleBusinessDay;
   }

   /**
    * To get saleBusinessday from RS during PSA.
    * 
    * @param env
    * @param tempOrderEle
    */
   public String getSaleBusinessDayfromReturnService( YFSEnvironment env, Element tempOrderEle )
   {
      DateFormat businessDayFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);
      String saleBusinessday = null;
      try
      {
         Element orderCustAttsElement = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.CUST_ATTRIBUTES);
         if ( !YFCCommon.isVoid( orderCustAttsElement ) ) {
             String businessDayValue = orderCustAttsElement.getAttribute( KohlsPOCConstant.ATTR_DATE_9 );
             if ( !YFCCommon.isVoid( businessDayValue ) ) {
                  Date businessDateObj = businessDayFormat.parse(businessDayValue);
                 if (!XMLUtil.isVoid(businessDateObj)) {
                     saleBusinessday = businessDayFormat.format(businessDateObj);
                  }
             }
         }
      }
      catch ( Exception e )
      {
         return null;
      }
      return saleBusinessday;

   }

   /**
    * To get saleBusinessday from transaction audit logic during PSA.
    * 
    * @param env
    * @param tempOrderEle
    */
   public String getSaleBusinessDayfromTransactionAudit( YFSEnvironment env, Element tempOrderEle )
   {
      String saleBusinessDay = null;
      try
      {
         String strOrderNo = tempOrderEle.getAttribute( KohlsPOCConstant.ATTR_ORDER_NO );
         String strSellerOrgCode = tempOrderEle.getAttribute( KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE );

         Document inTranDoc = YFCDocument.createDocument( KohlsPOCConstant.ATTR_TRANSACTION_AUDIT ).getDocument();
         Element eleInput = inTranDoc.getDocumentElement();
         eleInput.setAttribute( KohlsPOCConstant.ATTR_ORDER_NUMBER, strOrderNo );
         eleInput.setAttribute( KohlsPOCConstant.A_ORGANIZATION_CODE, strSellerOrgCode );
         eleInput.setAttribute( KohlsPOCConstant.ATTR_PROCEDURE_ID, KohlsPOCConstant.STATIC_CONSTANT_CREATE_TRANSACTION_PROCEDURE_ID );
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "getSaleBusinessDayfromTransactionAudit.getTransactionAuditListForPOS input doc : " + XMLUtil.getXMLString( inTranDoc ) );
         }

         Document getTraxAuditListOutput = KOHLSBaseApi.invokeAPI( env, XMLUtil.getDocument( KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE ), KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS, inTranDoc );
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "getSaleBusinessDayfromTransactionAudit.getTransactionAuditListForPOS output doc : " + XMLUtil.getXMLString( getTraxAuditListOutput ) );
         }
         NodeList nlElements = getTraxAuditListOutput.getElementsByTagName( KohlsPOCConstant.ATTR_TRANSACTION_AUDIT );

         // Check if Audit entry for procedure - 201

         if ( nlElements.getLength() > 0 )
         {
            Element eleGetTranAudit = (Element) nlElements.item( 0 );
            saleBusinessDay = eleGetTranAudit.getAttribute( KohlsPOCConstant.ATTR_BUSINESS_DAY );
         }
      }
      catch ( Exception e )
      {
         return null;
      }
      return saleBusinessDay;
   }
}
