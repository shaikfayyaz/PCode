package com.kohls.poc.condition;

import java.util.Map;

import org.w3c.dom.Document;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsMPOCCheckIfSPSTxn implements YCPDynamicConditionEx {

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCCheckIfDisableHardTotals.class.getName());
	}

	/**
	 * This method will be verify if the txn obj SourceSystem is SPS if SPS then
	 * return true else return false
	 *
	 * @param env
	 * @param name
	 * @param mapData
	 * @param inDoc
	 */
	@Override
	public boolean evaluateCondition(YFSEnvironment env, String name, Map mapData, Document inDoc) {

		logger.beginTimer("KohlsMPOCCheckIfSPSTxn::evaluateCondition");
		/* Initialize variables */

		String strPurpose = (String) env.getTxnObject(KohlsPOCConstant.SOURCE_SYSTEM);
		if ("SPS".equalsIgnoreCase(strPurpose))
			return true;
		else
			return false;
	}

	@Override
	public void setProperties(Map arg0) {
		// TODO Auto-generated method stub

	}

}
