package com.kohls.poc.condition;

import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfc.util.YFCCommon;

public class KohlsPOCIsCARRYInvoice implements YCPDynamicConditionEx {

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPOCIsCARRYInvoice.class.getName());

	/* 
	 * This condition class actually checks if the invoice xml has any CARRY lines or not. If CARRY lines are present, 
	 * it would be either normal POC order or OMNI1 order and hence it has to be routed to SalesHub only. If CARRY lines are not present,
	 * it is PICK invoice of OMNI2 order and hence has to be routed to SalesHub and OMSe kafka topic.
	 */
	@Override
	public boolean evaluateCondition(YFSEnvironment env, String arg1, Map arg2, Document inDocument) {
		boolean isCarryInvoice = false;
		try {
			Element eleInvoiceDetail = inDocument.getDocumentElement();
			Element eleInvoiceHeader = (Element) eleInvoiceDetail.getElementsByTagName(KohlsPOCConstant.ATTR_INVOICE_HEADER).item(0);
			Element eleOrder = (Element) eleInvoiceHeader.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);

			NodeList orderLineNodeList = eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			if(orderLineNodeList.getLength()>0) {
				for(int i=0; i<orderLineNodeList.getLength();i++) {
					Element orderLine = (Element) orderLineNodeList.item(i);
					String deliveryMethod = orderLine.getAttribute(KohlsPOCConstant.ATTR_DELIVERY_METHOD);
					if(KohlsPOCConstant.ATTR_DELIVERY_TYPE_CARRY.equalsIgnoreCase(deliveryMethod) || YFCCommon.isVoid(deliveryMethod)) {
						isCarryInvoice = true;
						break;
					}
				}
			}
			logger.debug("####### Inside  KohlsPOCIsCARRYInvoice class ####### isCarryInvoice: "+isCarryInvoice);
		} catch (Exception e) {
			throw new YFSException(e.getMessage());
		}
		return isCarryInvoice;
	}

	@Override
	public void setProperties(Map arg0) {
	}

}
