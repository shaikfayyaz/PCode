package com.kohls.poc.condition;

import java.util.Map;

import org.w3c.dom.Document;

import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPOCCheckIfOrderContainCarry implements YCPDynamicConditionEx {

	/**
	 * This condition will check if order contains at least one carry line and return true or false.
	 */
	@Override
	public boolean evaluateCondition(YFSEnvironment env, String name, Map mapData, Document inDoc) {
		boolean isCarry=false;
		String isCarryLine = (String)env.getTxnObject("IsCarryLine");
		if("Y".equals(isCarryLine))
		{
			isCarry=true;
		}
		return isCarry;
	}

	@Override
	public void setProperties(Map arg0) {
		// TODO Auto-generated method stub
		
	}

}
