package com.kohls.poc.condition;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * The Class KohlsPOCIsCompleteOrderCancelled is a dynamic condition class which is
 * used to check if the complete order is cancelled or not.
 */
public class KohlsPOCIsCompleteOrderCancelled implements YCPDynamicConditionEx {

	/** Logger for the class. */
	private static final YFCLogCategory LOG = YFCLogCategory
			.instance(KohlsPOCIsCompleteOrderCancelled.class.getName());

	/** The arguments. */
	private Map arguments = new HashMap();;


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.yantra.ycp.japi.YCPDynamicConditionEx#evaluateCondition(com.yantra
	 * .yfs.japi.YFSEnvironment, java.lang.String, java.util.Map,
	 * org.w3c.dom.Document)
	 */
	@Override
	public boolean evaluateCondition(YFSEnvironment envYFSEnvironment, String nameString,
			Map dataMap, Document inDocument) {
		
		String strOrderStatus = "";
		String strMinOrderStatus = "";
		String strMaxOrderStatus = "";
		
		/**
		 * Get the /Order/@Status, /Order@MinOrderStatus, /Order/@MaxOrderStatus
		 */
		Element eleOrder = inDocument.getDocumentElement();
		strOrderStatus = XMLUtil.getAttribute(eleOrder, KohlsPOCConstant.ATTR_STATUS);
		strMinOrderStatus = XMLUtil.getAttribute(eleOrder, KohlsPOCConstant.ATTR_MIN_ORD_STATUS);
		strMaxOrderStatus = XMLUtil.getAttribute(eleOrder, KohlsPOCConstant.MAX_ORDER_STATUS);
		
		if(LOG.isDebugEnabled()){
			
			LOG.debug("OrderStatus: " + strOrderStatus);
			LOG.debug("MinOrderStatus: " + strMinOrderStatus);
			LOG.debug("MaxOrderStatus: " + strMaxOrderStatus);
		}
		
		/**
		 * If @Status exists OR both @MinOrderStatus & @MaxOrderStatus exist
		 */
		if(!XMLUtil.isVoid(strOrderStatus) || (!XMLUtil.isVoid(strMinOrderStatus) && 
				!XMLUtil.isVoid(strMaxOrderStatus))){
			
			/**
			 * If @Status is 'Cancelled' OR both @MinOrderStatus and @MaxOrderStatus are '9000', 
			 * return true
			 */
			if(strOrderStatus.equals(KohlsPOCConstant.CANCELLED) || 
					((strMinOrderStatus.equals(KohlsPOCConstant.CONST_CANCEL)) && 
							(strMaxOrderStatus.equals(KohlsPOCConstant.CONST_CANCEL)))){
				
				if(LOG.isDebugEnabled()){
					LOG.debug("The complete order is cancelled");
				}
				return true;
			}
		}
		
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.yantra.ycp.japi.YCPDynamicConditionEx#setProperties(java.util.Map)
	 */
	@Override
	public void setProperties(Map map) {
		if (map != null) {
			this.arguments = map;
		}
	}

}
