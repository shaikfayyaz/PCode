
package com.kohls.poc.condition;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCorpSVCOfflinePaymentMethodUpdateCondition extends KOHLSBaseApi {
    private static final YFCLogCategory logger =
        YFCLogCategory.instance(KohlsCorpSVCOfflinePaymentMethodUpdateCondition.class.getName());

    public Document updatePaymentMethodForISSSvcOffline(YFSEnvironment env, Document inDoc) throws Exception {
        logger.beginTimer("KohlsCorpSVCOfflinePaymentMethodUpdateCondition.updatePaymentMethodForISSSvcOffline");

        try {
            if (logger.isDebugEnabled()) {
                logger.debug("Input of the updatePaymentMethodForISSSvcOffline" + XMLUtil.getXMLString(inDoc));
            }
            Element orderEle = inDoc.getDocumentElement();
            if (!YFCCommon.isVoid(orderEle)) {

                NodeList ndlPaymentMethod = orderEle.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
                if (!YFCCommon.isVoid(ndlPaymentMethod)) {
                    for (int i = 0; i < ndlPaymentMethod.getLength(); i++) {

                        Element elePaymentMethod = (Element) ndlPaymentMethod.item(i);

                        if ((!YFCCommon.isVoid(elePaymentMethod))
                            && elePaymentMethod.hasAttribute(KohlsPOCConstant.AWAITING_CHARGE_INTERFACE_AMOUNT)) {

                            String awaitingChargeInterfaceAmount =
                                elePaymentMethod.getAttribute(KohlsPOCConstant.AWAITING_CHARGE_INTERFACE_AMOUNT);

                            if (elePaymentMethod.hasAttribute(KohlsPOCConstant.PAYMENT_TYPE_GROUP)
                                && KohlsPOCConstant.STORED_VALUE_CARD
                                    .equals(elePaymentMethod.getAttribute(KohlsPOCConstant.PAYMENT_TYPE_GROUP))
                                && (!YFCCommon.isVoid(awaitingChargeInterfaceAmount))
                                && Double.parseDouble(awaitingChargeInterfaceAmount) > 0.00d) {

                                NodeList ndlPaymentDetails =
                                    elePaymentMethod.getElementsByTagName(KohlsPOCConstant.ATTR_PAYMENT_DETAILS);

                                if (!YFCCommon.isVoid(ndlPaymentDetails)) {
                                    for (int j = 0; j < ndlPaymentDetails.getLength(); j++) {

                                        Element elePaymentDetails = (Element) ndlPaymentDetails.item(j);
                                        if (!YFCCommon.isVoid(elePaymentDetails)) {
                                            elePaymentDetails.setAttribute(KohlsPOCConstant.ATTR_REQ_PROCESSED, KohlsPOCConstant.YES);
                                            elePaymentDetails.setAttribute(KohlsPOCConstant.PROCESSED_AMOUNT,
                                                awaitingChargeInterfaceAmount);

                                            if (logger.isDebugEnabled()) {
                                                logger.debug(
                                                    "Setting the parameters RequestProcessed : Y and ProcessedAmount : "
                                                        + awaitingChargeInterfaceAmount);
                                                logger.debug("Output of the updatePaymentMethodForISSSvcOffline"
                                                    + XMLUtil.getXMLString(inDoc));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error while setting the TotalCharged for SVC Reference Approval Payment Method", e);
        }
        logger.endTimer("KohlsCorpSVCOfflinePaymentMethodUpdateCondition.updatePaymentMethodForISSSvcOffline");
        return inDoc;
    }

}
