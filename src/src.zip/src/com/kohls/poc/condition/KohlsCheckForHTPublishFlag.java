package com.kohls.poc.condition;

import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCheckForHTPublishFlag extends KOHLSBaseApi implements YCPDynamicConditionEx {

	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsCheckForHTPublishFlag.class.getName());

	  private String strStoreID = null;
	  private String strBusinessDay = null;
	  private String strTerminalID = null;
	  private String strTillNumber = null;
	  private String strProcedureID = null;
	  
	
	public boolean evaluateCondition(YFSEnvironment paramYFSEnvironment,
			String paramString, Map paramMap, Document inDoc) {
		boolean publishHT = true;
		log.debug("Inside KohlsCheckForHTPublishFlag");
		try {

			Element eleAcct = inDoc.getDocumentElement();
			strProcedureID = eleAcct.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID);
			strBusinessDay = eleAcct.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY);
			strTillNumber = eleAcct.getAttribute(KohlsPOCConstant.ATTR_TILL_ID);
			strTerminalID = eleAcct.getAttribute(KohlsPOCConstant.ATTR_ACCOUNTABLE_TERMINAL_ID);
			strStoreID = eleAcct.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
			if(KohlsPOCConstant.FIVE.equals(strProcedureID))
			{				 
				if(isHTAlreadyPublished(paramYFSEnvironment))
				{
					log.info("Hard Totals already published, No need to publish again");
					publishHT = false;
				}
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug("Inside KohlsCheckForHTPublishFlag..EXCEPTION... returning true and proceeding further");
		}
		return publishHT;
	}
	
	private boolean isHTAlreadyPublished(YFSEnvironment env) {
		log.beginTimer("KohlsCheckForHTPublishFlag.getStorePdtAcc");
	    boolean htPublished = false;
	    try {
	      // Create input xml for getStoreProductAccListForPOS API

	      Document docInputForStorePdtAcc =
	          YFCDocument.createDocument(KohlsPOCConstant.ATTR_STORE_PRODUCT_ACC).getDocument();
	      Element eleStorePdtAccInput = docInputForStorePdtAcc.getDocumentElement();
	      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
	      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, strTillNumber);
	      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
	      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, strStoreID);

	      // Call getStoreProductAccListForPOS API
	      Document docOutput = invokeAPI(env, KohlsPOCConstant.API_HT_STORE_PROD_ACC_LIST_TEMPLATE,
	          KohlsPOCConstant.API_GET_STORE_PRODUCT_ACC_LIST_FOR_POS, docInputForStorePdtAcc);
	      if(!YFCCommon.isVoid(docOutput) && docOutput.getDocumentElement().hasChildNodes())
	      {
	    	  	 Element storeProdAccEle = SCXmlUtil.getChildElement(docOutput.getDocumentElement(), KohlsPOCConstant.ATTR_STORE_PRODUCT_ACC);
	    	  	 Element extnEle = SCXmlUtil.getChildElement(storeProdAccEle, KohlsPOCConstant.E_EXTN);
	    	  	 if(!YFCCommon.isVoid(extnEle))
	    	  	 {
	    	  		 String extnHTPublishedFlag = extnEle.getAttribute(KohlsPOCConstant.EXTN_IS_HT_PUBLISHED);
	    	  		 if(KohlsPOCConstant.YES.equals(extnHTPublishedFlag))
	    	  		 {
	    	  			htPublished = true;
	    	  		 }	    	  		
	    	  	 }
	      }
	    } catch (Exception exception) {
	    	log.endTimer("KohlsCheckForHTPublishFlag.getStorePdtAcc");
	      exception.printStackTrace();
	      if (exception instanceof YFSException) {
	        YFSException yfsException = (YFSException) exception;
	        throw yfsException;
	      }
	    }
	    log.endTimer("KohlsCheckForHTPublishFlag.getStorePdtAcc");
	    return htPublished;
	  }
	
	

	@Override
	public void setProperties(Map arg0) {
		// TODO Auto-generated method stub

	}

}
