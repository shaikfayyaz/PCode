package com.kohls.poc.condition;

import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPOCVerifyOmniOrder implements YCPDynamicConditionEx {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPOCVerifyOmniOrder.class.getName());

	/* This method is responsible for identifying POC invoice, OMNI1 invoice or  OMNI2 invoice.
	 * 
	 */
	@Override
	public boolean evaluateCondition(YFSEnvironment env, String arg1, Map arg2, Document inDocument) {
		boolean isOmni2Order = false;
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("inDocument: " + XMLUtil.getXMLString(inDocument));
			}
			Document docOrderListOutput = null;
			Element extnOrderEle = null;
			String extnIsOmni = "";
			Element eleInvoiceDetail = inDocument.getDocumentElement();
			Element invHeaderEle = (Element) eleInvoiceDetail.getElementsByTagName(KohlsPOCConstant.ELE_INVOICE_HEADER)
					.item(0);
			Element orderEle = (Element) invHeaderEle.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);

			if (!YFCCommon.isVoid(orderEle)) {
				extnOrderEle = (Element) orderEle.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
				if (!YFCCommon.isVoid(extnOrderEle)) {
					extnIsOmni = extnOrderEle.getAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI);
				} else {
					String orderHeaderKey = orderEle.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
					logger.debug("orderHeaderKey: " + orderHeaderKey);

					if (!YFCCommon.isVoid(orderHeaderKey)) {
						YFCDocument docInputForGetOrderList = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER);
						docInputForGetOrderList.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
								orderHeaderKey);
						if (logger.isDebugEnabled()) {
							logger.debug("Input of getOrderList: "
									+ XMLUtil.getXMLString(docInputForGetOrderList.getDocument()));
						}

						Document template = XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE_OMNI2_CHK);
						docOrderListOutput = KOHLSBaseApi.invokeAPI(env, template, KohlsPOCConstant.API_GET_ORDER_LIST,
								docInputForGetOrderList.getDocument());
						if (logger.isDebugEnabled()) {
							logger.debug("Output of getOrderList: " + XMLUtil.getXMLString(docOrderListOutput));
						}
						if (!YFCCommon.isVoid(docOrderListOutput)) {
							Element outOrderEle = docOrderListOutput.getDocumentElement();
							extnOrderEle = (Element) outOrderEle.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
							if (!YFCCommon.isVoid(extnOrderEle)) {
								extnIsOmni = extnOrderEle.getAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI);
							}
						}
					}
				}
				
				if (!YFCCommon.isVoid(extnIsOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(extnIsOmni)) {
					// It is an OMNI order. Now need to check if OMNI2 is enabled or not.
					logger.debug("It is an OMNI order.");
					Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env,
							KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
					String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);

					if (KohlsPOCConstant.YES.equals(omni2Enabled)) {
						// It is OMNI2 order. Need to check if the invoice published is CARRY invoice or 
						// PICK invoice.
						logger.debug("OMNI2 enabled true");
						String invoiceType = invHeaderEle.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE);
						if (!YFCCommon.isVoid(invoiceType)
								&& KohlsPOCConstant.CONSTANT_ORDER.equalsIgnoreCase(invoiceType)) { 
							// It is an OMNI2 PICK invoice.
						
							String strMessageType=inDocument.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE);
							//Verify if its an Omni2 Void During, if so continue with Tibco process
							if((!YFCCommon.isVoid(strMessageType) && !strMessageType.equalsIgnoreCase(KohlsPOCConstant.A_VOID_DURING_INVOICE)) || YFCCommon.isVoid(strMessageType))		
								logger.debug("It is an OMNI2 PICK invoice.");
								isOmni2Order = true;
						}
					} 
				}
			}
		} catch (Exception ex) {
			YFSException yfsEx = new YFSException();
			yfsEx.setErrorDescription("Exception while identifying OMNI order. "+ex);
			throw yfsEx;
		}
		return isOmni2Order;
	}

	@Override
	public void setProperties(Map arg0) {
	}

}
