/*
 * File: KohlsPoCCheckEnvironmentVariable.java  Created on Apr 14, 2017 for OMSR3 by TKMACJT\
 * This class acts as utility  * to check any property if exists in COP or any property 
 * file within YFSSystem.You can pass n number property name and value.This class checks
 * all the property then returns true if all property name-value matched with COP
 * COPYRIGHT:
 * LICENSED MATERIALS - PROPERTY OF Kohls Stores
 * "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason  		Date     		Who Descriptions
 * ------- 		-------- 		--- -----------
 */
package com.kohls.poc.condition;

/**
 * @author TKMACJT
 *
 */
/**
 * 
 */


import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author TKMACJT
 *
 */
public class KohlsPoCCheckEnvironmentVariable implements YCPDynamicConditionEx {
    
    private Map propMap;
    private static YFCLogCategory logger;
    
    static {
        logger = YFCLogCategory.instance(KohlsPoCCheckEnvironmentVariable.class.getName());
    }

    /* (non-Javadoc)
     * @see com.yantra.ycp.japi.YCPDynamicConditionEx#evaluateCondition(com.yantra.yfs.japi.YFSEnvironment, java.lang.String, java.util.Map, org.w3c.dom.Document)
     */
    @Override
    public boolean evaluateCondition(YFSEnvironment env, String name,
            Map mapData, Document inDoc) {
        logger.beginTimer("KohlsPoCCheckEnvironmentVariable");
        logger.verbose("In KohlsPoCCheckEnvironmentVariable condition");

        boolean retVal = false;
        try{
          if (null == inDoc) {
              logger.verbose("Input Document to KohlsPoCCheckEnvironmentVariable condition is null");
              return retVal;
          }
          else {
              logger.verbose("Input Document to KohlsPoCCheckEnvironmentVariable condition is:\n\n"+propMap.keySet()+"Checking properties "+" with the document"+XMLUtil.getXMLString(inDoc));
          }
          retVal = checkProp(propMap,env);
        } catch (Exception e) {
            logger.error("KohlsPoCCheckEnvironmentVariable", e);
        }
        finally {
            logger.verbose("KohlsPoCCheckEnvironmentVariable condition return value is: "+retVal);
            logger.endTimer("KohlsPoCCheckEnvironmentVariable");
        }
        return retVal;
    }


    @Override
    public void setProperties(Map props) {
        propMap = props;        
    }
    

    
 public boolean checkProp(Map map,YFSEnvironment env){
      
      boolean propertiesMatching = false;
      Set<Map.Entry<String,String>> set = map.entrySet();      
      String sysPropValue=null;
      for (Map.Entry<String,String> entry : set) {        
        sysPropValue = (String)env.getTxnObject((String) entry.getKey());
        if(null!= sysPropValue){
          if(entry.getValue().equalsIgnoreCase(sysPropValue)){
            propertiesMatching = true;
            
          }else{
            propertiesMatching = false;
          }
        }
      }
      return propertiesMatching;      
    }

}
