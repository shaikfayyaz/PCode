/*
 * File: KohlsPoCEvaluateXpathCondition.java  Created on Apr 14, 2017 for OMSR3 by TKMACJT
 * This class acts s utility for checking the XPATH passed in the Dynamic COndition
 * of the Sterling component. You can add n property in Condition that appends
 * to provide the xpatn expression that we need to check
 *
 * COPYRIGHT:
 * LICENSED MATERIALS - PROPERTY OF Kohls Stores
 * "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason  		Date     		Who Descriptions
 * ------- 		-------- 		--- -----------
 */
package com.kohls.poc.condition;

/**
 * @author TKMACJT
 *
 */
/**
 * 
 */


import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author TKMACJT
 *
 */
public class KohlsPoCEvaluateXpathCondition implements YCPDynamicConditionEx {
    
    private Map propMap;
    private static YFCLogCategory logger;
    
    static {
        logger = YFCLogCategory.instance(KohlsPoCEvaluateXpathCondition.class.getName());
    }

    /* (non-Javadoc)
     * @see com.yantra.ycp.japi.YCPDynamicConditionEx#evaluateCondition(com.yantra.yfs.japi.YFSEnvironment, java.lang.String, java.util.Map, org.w3c.dom.Document)
     */
    @Override
    public boolean evaluateCondition(YFSEnvironment env, String name,
            Map mapData, Document inDoc) {
        logger.beginTimer("KohlsPoCEvaluateXpathCondition");
        logger.verbose("In KohlsPoCEvaluateXpathCondition condition and input"+ XMLUtil.getXMLString(inDoc));

        boolean retVal = false;
        String xPathString = getXpathExpression(propMap);
        
        if (null == xPathString || "".equals(xPathString)) {
            logger.verbose("No XPath expression to evaluate... returning false");
            return retVal;
        }
        if (null == inDoc) {
            logger.verbose("Input Document to KohlsPoCEvaluateXpathCondition condition is null");
            return retVal;
        }
        else {
            logger.verbose("Input Document to KohlsPoCEvaluateXpathCondition condition is:\n\n"+"Evaluating " + xPathString + " with document"+XMLUtil.getXMLString(inDoc));
        }
        XPathFactory factory = XPathFactory.newInstance();
        XPath xpath = factory.newXPath();
        Object result;
        try {
            
            XPathExpression expr = xpath.compile(xPathString);
            result = expr.evaluate(inDoc, XPathConstants.BOOLEAN);
            Boolean bool = (Boolean)result;
            retVal = bool.booleanValue();
        } catch (XPathExpressionException e) {
            logger.error("ErrorDuringXpathEvluation", e);
        }
        finally {
            logger.verbose("KohlsPoCEvaluateXpathCondition condition return value is: "+retVal);
            logger.endTimer("KohlsPoCEvaluateXpathCondition");
        }
        return retVal;
    }


    @Override
    public void setProperties(Map props) {
        propMap = props;        
    }
    

    
 public String getXpathExpression(Map map){
      
      
      Set<Map.Entry<String,String>> set = map.entrySet();
      String xpath ="";
      for (Map.Entry<String,String> entry : set) {
        xpath = entry.getValue().toString() + xpath ;         
        
      }
      return xpath;      
    }

}
