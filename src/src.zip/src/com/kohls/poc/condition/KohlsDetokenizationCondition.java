package com.kohls.poc.condition;

import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XPathUtil;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsDetokenizationCondition implements YCPDynamicConditionEx {

	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsDetokenizationCondition.class.getName());

	/**
	 * This method will be verify if the ExtnIsDetokenized attribute in
	 * POS_ADDITIONAL_DATA is N
	 * 
	 * @param env
	 * @param String
	 * @param Map
	 * @param Document
	 */
	public boolean evaluateCondition(YFSEnvironment paramYFSEnvironment,
			String paramString, Map paramMap, Document paramDocument) {
		boolean isNotDetokenized = false;
		Element additionalDataEle = null;
		String name = null;
		String value = null;
		log.debug("Inside KohlsDetokenizationCondition");
		try {

			String xPath = "/InvoiceDetail/InvoiceHeader/AdminAuditList/AdminAudit/AdditionalDataList/AdditionalData";
			NodeList additionalDataList = ((NodeList) XPathUtil.getNodeList(
					paramDocument.getDocumentElement(), xPath));
			for (int i = 0; i < additionalDataList.getLength(); i++) {
				additionalDataEle = (Element) additionalDataList.item(i);
				name = additionalDataEle.getAttribute("Name");
				value = additionalDataEle.getAttribute("Value");
				if (name != null && name.equalsIgnoreCase("ExtnIsDetokenized")) {
					if (value != null && value.equalsIgnoreCase("N")) {
						isNotDetokenized = true;
					} else {
						isNotDetokenized = false;
					}
					break;
				}
			}
		} catch (Exception e) {
			log.error(e);
			log.debug("Inside KohlsDetokenizationCondition returning FALSE due to EXCEPTION!!!!!!!!!!");
		}

		return isNotDetokenized;

	}

	@Override
	public void setProperties(Map arg0) {
		// TODO Auto-generated method stub

	}

}
