package com.kohls.poc.condition;

import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.util.Map;

public class KohlsPoCCheckIfDisableHardTotals  implements YCPDynamicConditionEx {

    private Map propMap;
    private static YFCLogCategory logger;

    static {
        logger = YFCLogCategory.instance(KohlsPoCCheckIfDisableHardTotals.class.getName());
    }
    /**
     * This method will be verify if the Purpose attribute in
     * Order/@Purpose is SPS and /Order/References/Reference[@Name='DisableHardTotals]/@Value is 'Y'
     *
     * @param env
     * @param name
     * @param mapData
     * @param inDoc
     */
    public boolean evaluateCondition(YFSEnvironment env,
                                     String name, Map mapData, Document inDoc) {

        logger.beginTimer("KohlsPoCCheckIfDisableHardTotals");
        logger.debug("In KohlsPoCCheckIfDisableHardTotals condition");

        /* Initialize variables */
        Element eleOrder = null;
        String strPurpose = null;
        NodeList nlReference = null;
        Element eleReferences = null;
        int iCount = 0;
        boolean isDisableHardTotals = false;

        /* Retrieve the value of /Order/@Purpose */
        eleOrder = inDoc.getDocumentElement();
        strPurpose=  SCXmlUtil.getXpathAttribute(eleOrder, KohlsConstants.XPATH_ORDER_PURPOSE);

        /* Retrieve the value of Reference tag */
        eleReferences = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.A_REFERENCES);
		if(!YFCCommon.isVoid(eleReferences)) {
            nlReference = eleReferences.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
        }
        if(!YFCCommon.isVoid(nlReference)) {
            iCount = nlReference.getLength();
        }

        /*Loop through Order/References/Reference */
        for(int i=0; i<iCount; i++) {
            Element eleReference = (Element) nlReference.item(i);

            if("DisableHardTotals".equals(eleReference.getAttribute(KohlsPOCConstant.Name)) &&
                    KohlsPOCConstant.YES.equalsIgnoreCase(eleReference.getAttribute(KohlsPOCConstant.Value))) {
                isDisableHardTotals = true;
            }
        }

        logger.endTimer("KohlsPoCCheckIfDisableHardTotals");

        if("SPS".equals(strPurpose) && isDisableHardTotals) {
            return false;
        } else if("KCPaymentCorrection".equals(strPurpose)){
            return false;
        }
        return true;


    }

    @Override
    public void setProperties(Map arg0) {
        // TODO Auto-generated method stub

    }
}
