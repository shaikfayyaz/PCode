package com.kohls.poc.condition;

import java.util.Map;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPOCIsOmni2Enabled implements YCPDynamicConditionEx {

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPOCIsOmni2Enabled.class.getName());

	@Override
	public boolean evaluateCondition(YFSEnvironment env, String arg1, Map arg2, Document inDocument) {
		String extnIsOmni = "";
		Element eleOrder = inDocument.getDocumentElement();
		NodeList extnNodeList = eleOrder.getElementsByTagName(KohlsPOCConstant.A_EXTN);
		if(extnNodeList.getLength()>0) {
			Element eleExtn = (Element) extnNodeList.item(0);
			if(eleExtn.hasAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI)) {
				extnIsOmni = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_IS_OMNI);
			}
		}else {
			String orderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			logger.debug("orderHeaderKey :"+orderHeaderKey);
			try {
				Document  docOrderListOutput = null;
				if(!YFCCommon.isVoid(orderHeaderKey)) {
					YFCDocument docInputForGetOrderList = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER);
					docInputForGetOrderList.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
					logger.debug("Input:"+XMLUtil.getXMLString(docInputForGetOrderList.getDocument()));
					Document template = XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE_OMNI2_CHK);
					docOrderListOutput = KOHLSBaseApi.invokeAPI(env,template, KohlsPOCConstant.API_GET_ORDER_LIST, docInputForGetOrderList.getDocument());
					logger.debug("Output:"+XMLUtil.getXMLString(docOrderListOutput));
					Element orderListEle = docOrderListOutput.getDocumentElement();
					Element orderEle =  (Element) orderListEle.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);
					Element extnEle = (Element) orderEle.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
					extnIsOmni = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_OMNI);
					logger.debug("extnIsOmni :"+extnIsOmni);
				}
			} catch (Exception e) {
				 throw new YFSException(e.getMessage());
			}
		}
		Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
		String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);

		if(KohlsPOCConstant.FLAG_Y.equalsIgnoreCase(extnIsOmni) && KohlsPOCConstant.YES.equals(omni2Enabled)) {
			logger.debug("OMNI2 enabled true");
			return true;
		}
		return false;
	}

	@Override
	public void setProperties(Map arg0) {
	}

}
