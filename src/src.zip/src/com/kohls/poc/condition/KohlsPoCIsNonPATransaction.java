/*
 * File: KohlsPoCIsNonPATransaction.java Created on Jun 22, 2017 for POC_OMS_IBM_Returns by mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.condition;

import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.YCPDynamicConditionEx;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author mrjoshi
 *
 */
public class KohlsPoCIsNonPATransaction implements YCPDynamicConditionEx {

  private Map propMap;
  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPoCIsNonPATransaction.class.getName());
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.yantra.ycp.japi.YCPDynamicConditionEx#evaluateCondition(com.yantra.yfs.japi.YFSEnvironment,
   * java.lang.String, java.util.Map, org.w3c.dom.Document)
   */
  @Override
  public boolean evaluateCondition(YFSEnvironment paramYFSEnvironment, String paramString,
      Map paramMap, Document docInDocument) {
    logger.beginTimer("KohlsPoCIsNonPATransaction.evaluateCondition");
    boolean retVal = true;
    if (!YFCCommon.isVoid(docInDocument)) {
      Element eleInRoot = docInDocument.getDocumentElement();
      Element eleExtn = XMLUtil.getChildElement(eleInRoot, KohlsPOCConstant.E_EXTN);
      if (!YFCCommon.isVoid(eleExtn)) {
        String sExtnPOCFeature = eleExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
        if (!YFCCommon.isVoid(sExtnPOCFeature)
            && KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equals(sExtnPOCFeature)) {
          retVal = false;
        }
      }
    }
    logger.endTimer("KohlsPoCIsNonPATransaction.evaluateCondition");
    return retVal;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.yantra.ycp.japi.YCPDynamicConditionEx#setProperties(java.util.Map)
   */
  @Override
  public void setProperties(Map props) {
    propMap = props;
  }

}
