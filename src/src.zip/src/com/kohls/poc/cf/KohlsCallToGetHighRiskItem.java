package com.kohls.poc.cf;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * Class expects OrderHeaderKey as input 
 * get Risks data from KOHLS_DEF_EDG_HIGH_RISK_ITEM
 * matches Item dept/Major/Minor with risk data and sorts out put according to rank  
 * <Item_data> has risks related info, <Gift_CARD_AMT> has total gift card  amount and 
 * <ANLU_data> will have account look up information
 */
public class KohlsCallToGetHighRiskItem {

	HashMap<String, String> highRiskItem = new HashMap<String, String>();
	final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsCallToGetHighRiskItem.class);
	static HashMap<String, HashMap<String, String>> mpLoadRiskTable = new HashMap<String, HashMap<String, String>>();
	String todaysDate = "";
	int MAX_ITEMS = 72;
	double tranAmount = 0;
	String sANLU="";
	/**
	 * 
	 * @param env
	 * @param inputDoc - <Order OrderHeaderKey=''/>
	 * @return <FraudRiskData> <Item_Data>1:23:23:23</Item_Data><Item_Data>2:87:00:00</Item_Data>
	 * <GIFT_CARD_AMT>25.00</GIFT_CARD_AMT>  <ANLU_DATA>Y:82302:Street No</ANLU_DATA></FraudRiskData>
	 * @throws Exception
	 * @throws IllegalArgumentException
	 */
	public Document callGetHighRiskItem(YFSEnvironment env, Document inputDoc) {
		logger.beginTimer("KohlsCallToGetHighRiskItem.callGetHighRiskItem");
		Document outHighRiskItem = null;

		TreeMap<Double, String> riskItemMap = new TreeMap<Double, String>();
		try {
			todaysDate = KohlsDateUtil.getCurrentTime("YYYYMMDD");			
			// Get Current Order details
			Document outDocOrderDetails = getOrderDetailsForHighRiskItem(env,
					inputDoc);
			Element inDocRootEle = inputDoc.getDocumentElement();
			boolean showRiskItemMap = Boolean.valueOf(inDocRootEle.getAttribute("ShowRiskItemMap"));
			if(inDocRootEle.hasAttribute("MaxItemDataEle") && !YFCCommon.isVoid(inDocRootEle.getAttribute("MaxItemDataEle")))
			{
				MAX_ITEMS = Integer.valueOf(inDocRootEle.getAttribute("MaxItemDataEle"));
			}
			// Load Risk Data to HashMap object
			if (mpLoadRiskTable.isEmpty()) {
				getHighRiskItemDetails(env);
			} else {

				// if map is having yesterdays data, refresh it
				if (!mpLoadRiskTable.containsKey(todaysDate)) {
					mpLoadRiskTable.clear();
					getHighRiskItemDetails(env);
				}

			}

			if (!YFCCommon.isVoid(outDocOrderDetails)) {
				getRiskItemMap(outDocOrderDetails, env);
				riskItemMap = sortRiskItem();
				outHighRiskItem = getXMLFormatOfhighRiskItem(riskItemMap, showRiskItemMap);

			}
		} catch (Exception e) {
			logger.error("Exception in KohlsCallToGetHighRiskItem.callGetHighRiskItem" +e.getMessage());
		}

		logger.endTimer("KohlsCallToGetHighRiskItem.callGetHighRiskItem");

		return outHighRiskItem;
	}

	/**
	 * @param env
	 * @param inputDoc 
	 * @return Order details from GetOrderList API, Mark Gift card line for amount total calculation
	 * @throws Exception
	 */
	public Document getOrderDetailsForHighRiskItem(YFSEnvironment env,
			Document inputDoc) throws Exception {

		logger.beginTimer("KohlsCallToGetHighRiskItem.getOrderDetailsForHighRiskItem");

		Document outOrderDetails = invokeAPI(env,
				KohlsPOCConstant.API_CF_GET_ORDER_DETAILS_TEMPLATE,
				KohlsPOCConstant.API_GET_ORDER_DETAILS, inputDoc);

		if (!YFCCommon.isVoid(outOrderDetails)) {

			logger.debug("KohlsCallToGetHighRiskItem.getOrderDetailsForHighRiskItem  outDoc of getOrderDetails is "
					+ XMLUtil.getXMLString(outOrderDetails));
		}
		logger.endTimer("KohlsCallToGetHighRiskItem.getOrderDetailsForHighRiskItem");
		
		//CPE-11107
		Element eleReferences = XMLUtil.getChildElement(outOrderDetails.getDocumentElement(),KohlsPOCConstant.A_REFERENCES);
		NodeList ndlReference = eleReferences
				.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
		for (int k = 0; k < ndlReference.getLength(); k++) {
			Element eleRef = (Element) ndlReference.item(k);
			String sRefName="",sRefValue="";
			sRefName  = eleRef.getAttribute(KohlsPOCConstant.A_NAME);
			sRefValue = eleRef.getAttribute(KohlsPOCConstant.A_VALUE);
			if(sRefName.contains("AccountLookup") && sRefValue.contains("Account Look Up")){
				sANLU ="Y";
			}
			if(sRefName.contains("IFrameAccountLookupAddress") ){
				sANLU = "Y:"+sRefValue;
				break;
			}
		}
		NodeList ndlOrderLine = outOrderDetails.getDocumentElement()
				.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
		for (int i = 0; i < ndlOrderLine.getLength(); i++) {

			Element eleOrderLine = (Element) ndlOrderLine.item(i);

			NodeList nlCategory = eleOrderLine
					.getElementsByTagName(KohlsPOCConstant.A_CATEGORY);
			if (nlCategory.getLength() > 0) {
				for (int j = 0; j < nlCategory.getLength(); j++) {
					Element eleCategory = (Element) nlCategory.item(j);
					String sCategoryPath = eleCategory
							.getAttribute(KohlsPOCConstant.A_CATEGORY_PATH);
					if (!YFCCommon.isVoid(sCategoryPath)
							&& (sCategoryPath.contains("POSRetailerGiftCard") || sCategoryPath.contains("POSBlackhawkGiftCard"))) {
						eleOrderLine.setAttribute("IsGiftCard", "Y");
					}
				}
			}			
		}
		return outOrderDetails;
	}

	Document invokeAPI(YFSEnvironment env,
			String apiCfGetOrderDetailsTemplate, String apiGetOrderDetails,
			Document inputDoc) throws Exception {
		Document outDoc = KOHLSBaseApi.invokeAPI(env,
				apiCfGetOrderDetailsTemplate, apiGetOrderDetails, inputDoc);
		return outDoc;
	}

	/**
	 *  calculate gift card totals by looping through orderlines
	 *  creates Map by grouping similar risk level items
	 * @param docOrderDetails
	 * @param env
	 * @return updated highRiskItem map
	 * 
	 * @throws Exception
	 */
	public HashMap<String, String> getRiskItemMap(Document docOrderDetails,
			YFSEnvironment env) throws Exception {

		logger.beginTimer("KohlsCallToGetHighRiskItem.getRiskItemMap");

		NodeList ndlOrderLine = docOrderDetails.getDocumentElement()
				.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
		HashMap<String, String> mpRiskData = mpLoadRiskTable.get(todaysDate);
		for (int i = 0; i < ndlOrderLine.getLength(); i++) {

			Element eleOrderLine = (Element) ndlOrderLine.item(i);
			Element eleLinePriceInfo = SCXmlUtil.getChildElement(eleOrderLine,
					KohlsPOCConstant.E_LINE_PRICE_INFO, true);
			boolean isGiftCard = false;

			isGiftCard = ("Y".equalsIgnoreCase(eleOrderLine
					.getAttribute("IsGiftCard")) == true) ? true : false;
			Element eleExtn = (Element) eleOrderLine.getElementsByTagName(
					KohlsPOCConstant.A_EXTN).item(0);
			double iOrderedQty = Double.parseDouble(eleOrderLine
					.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY));
			String sDept = eleExtn
					.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT);
			String sMajorClass = eleExtn
					.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS);
			String sMinorClass = eleExtn
					.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS);
			String sMinorKey = sDept + "_" + sMajorClass + "_" + sMinorClass;
			String sMajorKey = sDept + "_" + sMajorClass + "_00";
			String sDeptKey = sDept + "_00_00";
			if (isGiftCard) {
				tranAmount = tranAmount
						+ Double.parseDouble(eleLinePriceInfo
								.getAttribute(KohlsPOCConstant.A_UNIT_PRICE));
			}
			if (!YFCCommon.isVoid(eleExtn
					.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT))
					&& iOrderedQty > 0) {
				if (mpRiskData.containsKey(sMinorKey)) {
					String sConcatVal = sDept + ":" + sMajorClass + ":"
							+ sMinorClass + ":R" + mpRiskData.get(sMinorKey);
					logger.debug("KohlsCallToGetHighRiskItem.getRiskItemMap in first if block");
					if (highRiskItem.containsKey(sConcatVal)) {
						int qty = Integer
								.parseInt(highRiskItem.get(sConcatVal)) + 1;
						highRiskItem.put(sConcatVal, String.valueOf(qty));
					} else {
						highRiskItem.put(sConcatVal, "1");
					}
					
					continue;
				}

				else if (mpRiskData.containsKey(sMajorKey)) {

					logger.debug("KohlsCallToGetHighRiskItem.getRiskItemMap in  else if block 1");

					String sConcatVal = sDept + ":" + sMajorClass + ":R"
							+ mpRiskData.get(sMajorKey);
					if (highRiskItem.containsKey(sConcatVal)) {
						int qty = Integer
								.parseInt(highRiskItem.get(sConcatVal)) + 1;
						highRiskItem.put(sConcatVal, String.valueOf(qty));
					} else {
						highRiskItem.put(sConcatVal, "1");
					}
					
					continue;
				} else if (mpRiskData.containsKey(sDeptKey)) {
					String sConcatVal = sDept + ":R" + mpRiskData.get(sDeptKey);
					logger.debug("KohlsCallToGetHighRiskItem.getRiskItemMap in   else if block 2");

					if (highRiskItem.containsKey(sConcatVal)) {
						int qty = Integer
								.parseInt(highRiskItem.get(sConcatVal)) + 1;
						highRiskItem.put(sConcatVal, String.valueOf(qty));
					} else {
						highRiskItem.put(sConcatVal, "1");
					}
					
					continue;
				}

			}
		}
		logger.endTimer("KohlsCallToGetHighRiskItem.getRiskItemMap");
		return highRiskItem;
	}

	/**
	 * @param env
	 * @return update mpLoadRiskTable map from table KOHLS_DEF_EDG_HIGH_RISK_ITEM
	 * @throws Exception
	 */
	private HashMap<String, HashMap<String, String>> getHighRiskItemDetails(
			YFSEnvironment env) throws Exception {
		HashMap<String, String> riskData = new HashMap<String, String>();
		logger.beginTimer("KohlsCallToGetHighRiskItem.getHighRiskItemDetails");
		Document docHighRiskItem = XMLUtil
				.createDocument(KohlsPOCConstant.KohlsDefEdgHighRiskItem);
		docHighRiskItem.getDocumentElement().setAttribute("ActiveFlag", "Y");
		Document outDocHighRiskItemList = invokeService(env,
				KohlsPOCConstant.KOHLS_GET_DefEdg_HighRiskItem_LIST,
				docHighRiskItem);
		if (!YFCCommon.isVoid(outDocHighRiskItemList)) {

			Iterator<?> itrRiskList = XMLUtil.getChildren(outDocHighRiskItemList
					.getDocumentElement());// KohlsDefEdgHighRiskItem
			while (itrRiskList.hasNext()) {
				Element eleRisk = (Element) itrRiskList.next();
				String sDdept = eleRisk
						.getAttribute(KohlsPOCConstant.A_DEPTNBR);
				String sMajorClass = eleRisk
						.getAttribute(KohlsPOCConstant.A_MAJOR_CLASS);
				String sMinorClass = eleRisk
						.getAttribute(KohlsPOCConstant.A_SUB_CLASS);
				String sRisk = eleRisk
						.getAttribute(KohlsPOCConstant.RISK_LEVEL);
				riskData.put(sDdept + "_" + sMajorClass + "_" + sMinorClass,
						sRisk);
			}
		}
		mpLoadRiskTable.put(todaysDate, riskData);
		return mpLoadRiskTable;
	}

	public Document invokeService(YFSEnvironment env,
			String kohlsGetDefedgHighriskitemList, Document docHighRiskItem)
			throws Exception {
		Document outDoc = KOHLSBaseApi.invokeService(env,
				kohlsGetDefedgHighriskitemList, docHighRiskItem);
		return outDoc;
	}

	/**
	 * creates Final treeMap by Sorting based on risk level 
	 * @return
	 */
	public TreeMap<Double, String> sortRiskItem()

	{
		logger.beginTimer("KohlsCallToGetHighRiskItem.sortRiskItem");
		TreeMap<Double, String> riskItemMap = new TreeMap<Double, String>();
		HashMap<String, Double> tempMap = new HashMap<>();
		for (Map.Entry<String, String> entry : highRiskItem.entrySet()) {
			String sKey = entry.getKey();
			logger.debug("KohlsCallToGetHighRiskItem.sortRiskItem inside the loop");
			// get Risk priority - after R in the string
			String tempRiskPriority = sKey.substring(sKey.lastIndexOf(':') + 2);
			if (!YFCCommon.isVoid(tempRiskPriority)) {
				logger.debug("KohlsCallToGetHighRiskItem.sortRiskItem tempRiskPriority-->"
						+ tempRiskPriority);
				String tempVal = entry.getValue() + ":"
						+ sKey.substring(0, sKey.lastIndexOf(':'));
				if (riskItemMap.containsKey(Double.valueOf(tempRiskPriority))) {
					Double riskPriority = 0.0;
					if(tempMap.containsKey(tempRiskPriority))
					{
						riskPriority = tempMap.get(tempRiskPriority);
						riskPriority = riskPriority + .1;
						riskPriority = Math.round(riskPriority * 100.0) / 100.0;
					}
					else
					{
						riskPriority = Double.parseDouble(tempRiskPriority);
					}					
					riskItemMap.put(riskPriority,
							tempVal);					
					tempMap.put(tempRiskPriority,riskPriority);
					
				} else {
					logger.debug("KohlsCallToGetHighRiskItem.sortRiskItem in the else block"
							+ tempVal);
					riskItemMap.put(Double.valueOf(tempRiskPriority), tempVal);
					tempMap.put(tempRiskPriority,Double.parseDouble(tempRiskPriority));
				}
			}
		}
		logger.endTimer("KohlsCallToGetHighRiskItem.sortRiskItem");
		return riskItemMap;

	}

	/**
	 *Creates output document as needed by gravity needed from final TreeMap
	 * @return Document - 
	 * <FraudRiskData>
	 * <Item_Data>1:23:23:23</Item_Data><Item_Data>2:87:00:00</Item_Data>
	 * <GIFT_CARD_AMT>25.00</GIFT_CARD_AMT>
	 * <ANLU_DATA>Y:82302:Street No</ANLU_DATA>
	 * </FraudRiskData>
	 * @throws Exception
	 */
	public Document getXMLFormatOfhighRiskItem(
			TreeMap<Double, String> riskItemMap,boolean showRiskItemMap) throws Exception

	{
		logger.beginTimer("KohlsCallToGetHighRiskItem.getXMLFormatOfhighRiskItem");
		Document docFraudRiskItem = XMLUtil
				.createDocument(KohlsPOCConstant.FRAUD_RISK_DATA);
		Element eleFraudRiskItem = docFraudRiskItem.getDocumentElement();
		int j = 0;
		if((showRiskItemMap || logger.isDebugEnabled()) && !riskItemMap.isEmpty())
		{
			eleFraudRiskItem.setAttribute("RiskItemMap",riskItemMap.toString());
		}
		for (Map.Entry<Double, String> entry : riskItemMap.entrySet()) {
			
			logger.debug("KohlsCallToGetHighRiskItem.getXMLFormatOfhighRiskItem in the loop");
			String tempDeptArr = entry.getValue();

			if (j < MAX_ITEMS) {
				Element eleHeader = XMLUtil.createChild(eleFraudRiskItem,
						KohlsPOCConstant.ITEM_DATA);
				logger.debug("KohlsCallToGetHighRiskItem.getXMLFormatOfhighRiskItem second loop");				
				XMLUtil.setNodeValue(eleHeader, tempDeptArr);				
				j++;
			}
		}
		if (tranAmount > 0) {
			Element eleHeader = XMLUtil.createChild(eleFraudRiskItem,
					KohlsPOCConstant.GIFT_CARD_AMT);
			logger.debug("KohlsCallToGetHighRiskItem.getXMLFormatOfhighRiskItem second  loop");
			XMLUtil.setNodeValue(eleHeader,
					new DecimalFormat("#0.00").format(tranAmount));
		}
		//CPE-11107 
		if(!YFCCommon.isVoid(sANLU)) {
			Element eleHeader = XMLUtil.createChild(eleFraudRiskItem,"ANLU_DATA");
			XMLUtil.setNodeValue(eleHeader, sANLU);
		}
		logger.endTimer("KohlsCallToGetHighRiskItem.getXMLFormatOfhighRiskItem");

		return docFraudRiskItem;
	}
}
