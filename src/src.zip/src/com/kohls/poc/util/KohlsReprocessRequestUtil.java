package com.kohls.poc.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ibm.sterling.Utils;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.services.jms.MessageUtil;
import com.yantra.interop.util.StringZipUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

import weblogic.servlet.utils.Base64;

public class KohlsReprocessRequestUtil {

	/**
	 * Utility class for Common Reprocess Agent 
	 */

	private static YFCLogCategory logger;
	//HashMap which contains the common code values for all the services
	public Map<String, String> propsFromCommonCode = new HashMap<String, String>();
	public static String DEFAULT_DATE = "2500-01-01T00:00:00";
	protected String sVersion = YFSSystem.getProperty("Version");
	//PerformanceImprovement(PI) - Start
	static private Properties props;
	//static private Map<String, Object> reprocessHM;
	static String reprocessTimeLapseThreshold = "";
	static int intReprocessRetryThreshold = 0;
	static int intFailureCounter = 0;
	static Timestamp lastFailedOverTS;
	//PI - End
	static {
		logger = YFCLogCategory.instance(KohlsReprocessRequestUtil.class);
		//PI - Start
		//reprocessHM = Collections.synchronizedMap(new HashMap<String, Object>());
		try {
			loadReprocessPropValues();
			//logger.debug("Initialising HashMap with default values" + reprocessHM);
		} catch (IOException e) {
			logger.error("Exception while loading ReprocessPropValues :" +e.getMessage());
		}
		//PI - End
	}

	/**
	 * This method will get the retry count of a record from the custom table
	 */
	public String getErrorCount(Element eleReprocessReq) {
		logger.beginTimer("KohlsReprocessRequestUtil.getErrorCount");
		logger.debug("Inside get errorcount ");
		String strErrorCount = null;
		strErrorCount = eleReprocessReq.getAttribute("RetryCount");
		logger.debug("strErrCount-->" + strErrorCount);
		logger.endTimer("KohlsReprocessRequestUtil.getErrorCount");
		return strErrorCount;
	}
	
	/**
	 * This method will get the max retry count for a service from the common code
	 */
	public String getMaxErrorCount(Element eleReprocessReq) {
		logger.beginTimer("KohlsReprocessRequestUtil.getMaxErrorCount");
		logger.debug("Inside getMaxErrorCount");
		String strMaxErrorCount = null;
		strMaxErrorCount = propsFromCommonCode
				.get(eleReprocessReq.getAttribute("ServiceName") + ".MaxErrorCount");
		logger.debug("strMaxErrCount-->" + strMaxErrorCount);
		logger.endTimer("KohlsReprocessRequestUtil.getMaxErrorCount");
		return strMaxErrorCount;
	}
	
	/**
	 * This method will get the BypassMQ for a service from the common code
	 * @throws Exception 
	 */
	public boolean bypassMQPosting(String serviceName) {
		logger.beginTimer("KohlsReprocessRequestUtil.bypassMQPosting");
		boolean bypassMQPosting = false;
		String codeValue = serviceName+ ".BypassMQPosting";
		try {
    		if (propsFromCommonCode.containsKey(codeValue)
    		   && Utils.isTrue(propsFromCommonCode.get(codeValue))) {
    		  bypassMQPosting = true;
    		}
		} catch (Exception e) {
		  bypassMQPosting = false;
		}
		logger.debug("BypassMQPosting for service "+ serviceName+" is "+ bypassMQPosting);
		logger.endTimer("KohlsReprocessRequestUtil.bypassMQPosting");
		return bypassMQPosting;
	}
	
	public boolean byPassMQPostingForCorpOnly(String serviceName) {
		logger.beginTimer("KohlsReprocessRequestUtil.byPassMQPostingForCorpOnly");
		boolean bypassMQPostingForCorpOnly = false;
		String codeValue = serviceName+ ".BypassMQPostingForCorpOnly";
		try {
    		if (propsFromCommonCode.containsKey(codeValue)
    		   && Utils.isTrue(propsFromCommonCode.get(codeValue))) {
    			bypassMQPostingForCorpOnly = true;
    		}
		} catch (Exception e) {
			bypassMQPostingForCorpOnly = false;
		}
		logger.debug("MQPostingForCorpOnly for service "+ serviceName+" is "+ bypassMQPostingForCorpOnly);
		logger.endTimer("KohlsReprocessRequestUtil.byPassMQPostingForCorpOnly");
		return bypassMQPostingForCorpOnly;
	}
	
	/**
     * This method will get the CompressionReqd for a service from the common code
     * @throws Exception 
     */
    public boolean compressionReqd(String serviceName) {
        logger.beginTimer("KohlsReprocessRequestUtil.compressionReqd");
        boolean compressionReqd = false;
        String codeValue = serviceName+ ".CompressionReqd";
        try {
          if (propsFromCommonCode.containsKey(codeValue) 
              && Utils.isTrue(propsFromCommonCode.get(codeValue))) {
            compressionReqd = true;
          }
        } catch (Exception e) {
          compressionReqd = true;
        }
        logger.debug("Compression Reqd for service "+ serviceName+" is "+ compressionReqd);
        logger.endTimer("KohlsReprocessRequestUtil.compressionReqd");
        return compressionReqd;
    }

	/**
	 * This method will be for inserting record in Aync table if there is a
	 * record already exist error during create/update the PO header
	 * 
	 * @param env
	 * @param docInput
	 * @throws Exception
	 */
	public void createReprocessRequest(YFSEnvironment env,
			String strServiceName, Document inDoc) throws Exception {
		logger.beginTimer("KohlsReprocessRequestUtil.createReprocessRequest");
		logger.debug("Inside createReprocessRequest");
		Element inElem = inDoc.getDocumentElement();
		Document inForAPI = XMLUtil
				.createDocument(KohlsPOCConstant.E_CUSTOM_REPROCESS_REQUEST);
		Element inElemForAPI = inForAPI.getDocumentElement();
		logger.debug("sServiceName " + strServiceName);
		inElemForAPI.setAttribute(KohlsPOCConstant.SERVICE, strServiceName);
		/* Purge date is defaulted to 2500-01-01T00:00:00 at DB level while 
		 inserting the record in database. */
		//inElemForAPI.setAttribute(KohlsPOCConstant.PURGE_DATE, DEFAULT_DATE);
		/* NextReprocessTS is defaulted to SYSDATE at DB level while 
		 inserting the record in database. */
		//inElemForAPI.setAttribute(KohlsPOCConstant.NEXT_REPROCESS_TS,calculateNextReprocessTimestamp(strServiceName));
		
		 String message = XMLUtil.getElementXMLString(inElem);
		 boolean compressionReqd = compressionReqd(strServiceName);
         if(compressionReqd) {
           String compressedMessage = compressXML (message);
           XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.MESSAGE, compressedMessage);
           XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.IS_COMPRESSED, KohlsPOCConstant.YES);
         } else {
           XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.MESSAGE, message);
         }
		
		if(!YFCCommon.isVoid(sVersion)){
			inElemForAPI.setAttribute("Version", sVersion);
		}
		
		logger.debug("createReprocessRequest ::"
				+ KohlsXMLUtil.getXMLString(inForAPI));
		Document outCreateAsyncRecord = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_CREATE_CUSTOM_REPROCESS_REQUEST,
				inForAPI);
		logger.debug("createReprocessRequest Output ::"
				+ KohlsXMLUtil.getXMLString(outCreateAsyncRecord));
		logger.endTimer("KohlsReprocessRequestUtil.createReprocessRequest");

	}
	
	public void createReprocessRequestWithRetryCount(YFSEnvironment env,
			String strServiceName, Document inDoc, String retryCount) throws Exception {
		logger.beginTimer("KohlsReprocessRequestUtil.createReprocessRequest");
		logger.debug("Inside createReprocessRequest");
		Element inElem = inDoc.getDocumentElement();
		Document inForAPI = XMLUtil
				.createDocument(KohlsPOCConstant.E_CUSTOM_REPROCESS_REQUEST);
		Element inElemForAPI = inForAPI.getDocumentElement();
		logger.debug("sServiceName " + strServiceName);
		inElemForAPI.setAttribute(KohlsPOCConstant.SERVICE, strServiceName);
		/* Purge date is defaulted to 2500-01-01T00:00:00 at DB level while 
		 inserting the record in database. */
		//inElemForAPI.setAttribute(KohlsPOCConstant.PURGE_DATE, DEFAULT_DATE);
		/* NextReprocessTS is defaulted to SYSDATE at DB level while 
		 inserting the record in database. */
		//inElemForAPI.setAttribute(KohlsPOCConstant.NEXT_REPROCESS_TS,calculateNextReprocessTimestamp(strServiceName));
		String message = XMLUtil.getElementXMLString(inElem);
        boolean compressionReqd = compressionReqd(strServiceName);
        if(compressionReqd) {
          String compressedMessage = compressXML (message);
          XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.MESSAGE, compressedMessage);
          XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.IS_COMPRESSED, KohlsPOCConstant.YES);
        } else {
          XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.MESSAGE, message);
        }
		XMLUtil.setAttribute(inElemForAPI, "RetryCount",
				retryCount);
		
		if(!YFCCommon.isVoid(sVersion)){
			inElemForAPI.setAttribute("Version", sVersion);
		}
		logger.debug("createReprocessRequest ::"
				+ KohlsXMLUtil.getXMLString(inForAPI));
		Document outCreateAsyncRecord = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_CREATE_CUSTOM_REPROCESS_REQUEST,
				inForAPI);
		logger.debug("createReprocessRequest Output ::"
				+ KohlsXMLUtil.getXMLString(outCreateAsyncRecord));
		logger.endTimer("KohlsReprocessRequestUtil.createReprocessRequest");

	}
	
	   /**
     * This method will be for inserting record in Aync table if there is a
     * record already exist error during create/update the PO header
     * 
     * @param env
     * @param docInput
     * @throws Exception
     */
    public void createReprocessRequest(YFSEnvironment env,
            String strServiceName, Document inDoc, String sColonyID) throws Exception {
        logger.beginTimer("KohlsReprocessRequestUtil.createReprocessRequest");
        logger.debug("Inside createReprocessRequest");
        Element inElem = inDoc.getDocumentElement();
        Document inForAPI = XMLUtil
                .createDocument(KohlsPOCConstant.E_CUSTOM_REPROCESS_REQUEST);
        Element inElemForAPI = inForAPI.getDocumentElement();
        logger.debug("sServiceName " + strServiceName);
        inElemForAPI.setAttribute(KohlsPOCConstant.SERVICE, strServiceName);
        if(!YFCCommon.isVoid(sColonyID)){
          inElemForAPI.setAttribute(KohlsPOCConstant.COLONY_ID, sColonyID);
        }
        /* Purge date is defaulted to 2500-01-01T00:00:00 at DB level while 
         inserting the record in database. */
        //inElemForAPI.setAttribute(KohlsPOCConstant.PURGE_DATE, DEFAULT_DATE);
        /* NextReprocessTS is defaulted to SYSDATE at DB level while 
         inserting the record in database. */
        //inElemForAPI.setAttribute(KohlsPOCConstant.NEXT_REPROCESS_TS,calculateNextReprocessTimestamp(strServiceName));
        String message = XMLUtil.getElementXMLString(inElem);
        boolean compressionReqd = compressionReqd(strServiceName);
        if(compressionReqd) {
          String compressedMessage = compressXML (message);
          XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.MESSAGE, compressedMessage);
          XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.IS_COMPRESSED, KohlsPOCConstant.YES);
        } else {
          XMLUtil.setAttribute(inElemForAPI, KohlsPOCConstant.MESSAGE, message);
        }
        if(!YFCCommon.isVoid(sVersion)){
            inElemForAPI.setAttribute("Version", sVersion);
        }
        logger.debug("createReprocessRequest ::"
                + KohlsXMLUtil.getXMLString(inForAPI));
        Document outCreateAsyncRecord = KOHLSBaseApi.invokeService(env,
                KohlsPOCConstant.SERVICE_CREATE_CUSTOM_REPROCESS_REQUEST,
                inForAPI);
        logger.debug("createReprocessRequest Output ::"
                + KohlsXMLUtil.getXMLString(outCreateAsyncRecord));
        logger.endTimer("KohlsReprocessRequestUtil.createReprocessRequest");

    }

	/**
	 * This method calculates the next reprocess timestamp
	 */
	public String calculateNextReprocessTimestamp(String serviceName)
			throws Exception {
		logger.beginTimer("KohlsReprocessRequestUtil.calculateNextReprocessTimestamp");
		logger.debug("Inside calculateNextReprocessTimestamp");
		int retryIntervalInMins = Integer.parseInt(propsFromCommonCode
				.get(serviceName + ".RetryInterval"));
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		Date nextReprocessTS = KohlsDateUtil.addToDate(
				sdf.parse(getCurrSysDateAsString()), Calendar.MINUTE,
				retryIntervalInMins);
		String strnextReprocessTS = sdf.format(nextReprocessTS);
		logger.endTimer("KohlsReprocessRequestUtil.calculateNextReprocessTimestamp");
		return strnextReprocessTS;
	}

	/**
	 * This method calculates the purge timestamp
	 */
	public String calculatePurgeTimestamp(String serviceName)
			throws Exception {
		logger.beginTimer("KohlsReprocessRequestUtil.calculatePurgeTimestamp");
		logger.debug("Inside calculatePurgeTimestamp");
		int purgeInHours = Integer.parseInt(propsFromCommonCode
				.get(serviceName + ".PurgeTime"));
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		Date purgeTS = KohlsDateUtil.addToDate(
				sdf.parse(getCurrSysDateAsString()), Calendar.HOUR,
				purgeInHours);
		String strPurgeTS = sdf.format(purgeTS);
		logger.endTimer("KohlsReprocessRequestUtil.calculatePurgeTimestamp");
		return strPurgeTS;
	}
	
	/**
	 * This method fetches the records to process from the custom table
	 */
	public Element getReprocessRecordFromDB(YFSEnvironment env,
			String strServiceName, String orderInvoiceKey) {
		logger.beginTimer("KohlsReprocessRequestUtil.getReprocessRecordFromDB");
		logger.debug("Inside getReprocessRecordFromDB");
		Document inGetReqDoc;
		try {
			inGetReqDoc = XMLUtil
					.getDocument(KohlsPOCConstant.TEMPLATE_INPUT_GET_CUSTOM_REPROCESS_REQ);
			inGetReqDoc.getDocumentElement().setAttribute("ServiceName",
					strServiceName);
			Document outGetAsyncReq = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SERVICE_GET_CUSTOM_REPROCESS_LIST_REQUEST,
					inGetReqDoc);
			logger.debug("The output xml is "
					+ XMLUtil.getXMLString(outGetAsyncReq));
			Element asyncReqElement = null;
			if (outGetAsyncReq != null) {
				NodeList asyncReqList = outGetAsyncReq
						.getElementsByTagName("KohlsReprocessRequest");
				for (int i = 0; i < asyncReqList.getLength(); i++) {
					asyncReqElement = (Element) asyncReqList.item(i);
					logger.debug("asyncReqElement " + asyncReqElement);
					logger.debug("asyncReqElement ServiceName"
							+ asyncReqElement.getAttribute("ServiceName"));
					logger.debug("asyncReqElement  Message"
							+ asyncReqElement.getAttribute("Message"));
					if (asyncReqElement.getAttribute("ServiceName")
							.equalsIgnoreCase(strServiceName)
							&& asyncReqElement.getAttribute("Message")
									.contains(orderInvoiceKey)) {
						return asyncReqElement;
					}
				}
			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error("ParserConfigurationException in updateReprocessRecord" + e.getMessage());
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error("SAXException in updateReprocessRecord" + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error("IOException in updateReprocessRecord" + e.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error("Exception in updateReprocessRecord" + e.getMessage());
		}
		logger.endTimer("KohlsReprocessRequestUtil.getReprocessRecordFromDB");
		return null;
	}

	/**
	 * This method updates the record in the custom table after
	 *  successful or failed execution of api / service 
	 */
	
	public void updateReprocessRecord(YFSEnvironment env, String sReprocessReqKey, String sNextReprocessTS,
			String sPurgeDate, String sIsSucess, String sErrorCount) {
		logger.beginTimer("KohlsReprocessRequestUtil.updateReprocessDate");
		logger.debug("Inside updateReprocessDate");
		Document docUpdateReprocessReqIn;
		try {
			docUpdateReprocessReqIn = XMLUtil.createDocument(KohlsPOCConstant.E_CUSTOM_REPROCESS_REQUEST);
			Element inEleRoot = docUpdateReprocessReqIn.getDocumentElement();
			if(!YFCCommon.isVoid(sNextReprocessTS)){
				inEleRoot.setAttribute(KohlsPOCConstant.NEXT_REPROCESS_TS, sNextReprocessTS);
			}
			if(!YFCCommon.isVoid(sPurgeDate)){
				inEleRoot.setAttribute(KohlsPOCConstant.PURGE_DATE, sPurgeDate);
			}
			if(!YFCCommon.isVoid(sIsSucess)){
				inEleRoot.setAttribute(KohlsPOCConstant.IS_SUCCESS_FLAG, sIsSucess);
			}
			if(!YFCCommon.isVoid(sErrorCount)){
				inEleRoot.setAttribute(KohlsPOCConstant.ERROR_COUNT, sErrorCount);
			}
			inEleRoot.setAttribute(KohlsPOCConstant.REPROCESS_REQ_KEY,sReprocessReqKey);
			logger.debug("Updating the record with following xml: \n"+ XMLUtil.getXMLString(docUpdateReprocessReqIn));
			KOHLSBaseApi.invokeService(env,	KohlsPOCConstant.SERVICE_UPDATE_CUSTOM_REPROCESS_REQUEST,
					docUpdateReprocessReqIn);

		} catch (ParserConfigurationException e) {
			//e.printStackTrace();
			logger.error("ParserConfigurationException in updateReprocessRecord" + e.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error("Exception in updateReprocessRecord" + e.getMessage());
		}
		
		logger.endTimer("KohlsReprocessRequestUtil.updateReprocessDate");
	}

	
	/**
	 * This method fetches the entries from common code for reprocess and
	 * populates the map
	 */
	public Map<String, String> loadPropsFromCommonCode(YFSEnvironment env,
			String strCommonCodeType) throws Exception {
		logger.beginTimer("KohlsReprocessRequestUtil.loadPropsFromCommonCode");
		// Populate the hashmap with all the common codes
		Document docInput = KohlsXMLUtil
				.createDocument(KohlsConstants.COMMON_CODE);
		Element eleInput = docInput.getDocumentElement();
		eleInput.setAttribute(KohlsConstants.CODE_TYPE, strCommonCodeType);
		Document docCommonCodeListOut = KohlsCommonUtil.invokeAPI(env,
				KohlsConstants.GET_COMMON_CODE_LIST, docInput);
		NodeList ndlstCommonCodeList = docCommonCodeListOut
				.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
		for (int i = 0; i < ndlstCommonCodeList.getLength(); i++) {
			Element eleCommonCode = (Element) ndlstCommonCodeList.item(i);
			if (!YFCCommon.isVoid(eleCommonCode
					.getAttribute(KohlsXMLLiterals.A_CODE_VALUE))) {
				propsFromCommonCode
						.put(eleCommonCode
								.getAttribute(KohlsXMLLiterals.A_CODE_VALUE),
								eleCommonCode
										.getAttribute(KohlsXMLLiterals.A_CODE_SHORT_DESCRIPTION));
			}
		}
		logger.endTimer("KohlsReprocessRequestUtil.loadPropsFromCommonCode");
		return propsFromCommonCode;
	}
	
	/** 
	 * This method fetches the entries from common code for reprocess and
     * populates the map
     */
    public Map<String, String> loadPropsFromCommonCode(YFSEnvironment env,
            String strCommonCodeType, String serviceName) throws Exception {
        logger.beginTimer("KohlsReprocessRequestUtil.loadPropsFromCommonCode");
        // Populate the hashmap with all the common codes
        Document docInput = KohlsXMLUtil
                .createDocument(KohlsConstants.COMMON_CODE);
        Element eleInput = docInput.getDocumentElement();
        eleInput.setAttribute(KohlsConstants.CODE_TYPE, strCommonCodeType);
        eleInput.setAttribute(KohlsConstants.CODE_VALUE, serviceName);
        eleInput.setAttribute(KohlsPOCConstant.CODE_VALUE_QRY_TYPE, KohlsPOCConstant.QRY_TYPE_LIKE);
        Document docCommonCodeListOut = KohlsCommonUtil.invokeAPI(env,
                KohlsConstants.GET_COMMON_CODE_LIST, docInput);
        NodeList ndlstCommonCodeList = docCommonCodeListOut
                .getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
        for (int i = 0; i < ndlstCommonCodeList.getLength(); i++) {
            Element eleCommonCode = (Element) ndlstCommonCodeList.item(i);
            if (!YFCCommon.isVoid(eleCommonCode
                    .getAttribute(KohlsXMLLiterals.A_CODE_VALUE))) {
                propsFromCommonCode
                        .put(eleCommonCode
                                .getAttribute(KohlsXMLLiterals.A_CODE_VALUE),
                                eleCommonCode
                                        .getAttribute(KohlsXMLLiterals.A_CODE_SHORT_DESCRIPTION));
            }
        }
        logger.endTimer("KohlsReprocessRequestUtil.loadPropsFromCommonCode");
        return propsFromCommonCode;
    }
	
    public static String codeShortDescription = null;
	
	/**
     * This method fetches the entries from common code for reprocess and
     * returns the code value
     */
    public String getCommonCodeValue (YFSEnvironment env, String strCommonCodeType, String defaultValue) throws Exception {
        logger.beginTimer("KohlsReprocessRequestUtil.getCommonCodeValue");
        // Populate the hashmap with all the common codes
        String codeValue = defaultValue;
        Document docInput = KohlsXMLUtil.createDocument(KohlsConstants.COMMON_CODE);
        Element eleInput = docInput.getDocumentElement();
        eleInput.setAttribute(KohlsConstants.CODE_TYPE, strCommonCodeType);
        Document docCommonCodeListOut = KohlsCommonUtil.invokeAPI(env, KohlsConstants.GET_COMMON_CODE_LIST, docInput);
        NodeList ndlstCommonCodeList = docCommonCodeListOut.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
        for (int i = 0; i < ndlstCommonCodeList.getLength(); i++) {
            Element eleCommonCode = (Element) ndlstCommonCodeList.item(i);
            if (!YFCCommon.isVoid(eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE))) {
              codeValue = eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE);
              if("TIMER_FOR_MQFAILURE".equalsIgnoreCase(strCommonCodeType))
              {
            	  	codeShortDescription = eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_SHORT_DESCRIPTION);
              }        
              break;
            }
        }
        logger.endTimer("KohlsReprocessRequestUtil.getCommonCodeValue");
        return codeValue;
    }

    
    /**
     * This method fetches the entries from common code for reprocess and
     * returns the code value
     */
    public String getCommonCodeValue (YFSEnvironment env, String strCommonCodeType, String strCodeValue, String defaultValue) throws Exception {
        logger.beginTimer("KohlsReprocessRequestUtil.getCommonCodeValue");
        // Populate the hashmap with all the common codes
        String codeValue = defaultValue;
        Document docInput = KohlsXMLUtil.createDocument(KohlsConstants.COMMON_CODE);
        Element eleInput = docInput.getDocumentElement();
        eleInput.setAttribute(KohlsConstants.CODE_TYPE, strCommonCodeType);
        eleInput.setAttribute(KohlsConstants.CODE_VALUE, strCodeValue);
        Document docCommonCodeListOut = KohlsCommonUtil.invokeAPI(env, KohlsConstants.GET_COMMON_CODE_LIST, docInput);
        NodeList ndlstCommonCodeList = docCommonCodeListOut.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
        for (int i = 0; i < ndlstCommonCodeList.getLength(); i++) {
            Element eleCommonCode = (Element) ndlstCommonCodeList.item(i);
            if (!YFCCommon.isVoid(eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE))) {
              codeValue = eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE);
              break;
            }
        }
        logger.endTimer("KohlsReprocessRequestUtil.getCommonCodeValue");
        return codeValue;
    }
    
	/**
	 * Gets the current system date
	 * 
	 * @return the current system date
	 */
	public static String getCurrSysDateAsString() {
		logger.beginTimer("KohlsReprocessRequestUtil.getCurrSysDateAsString");
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
		String str = sdf.format(yfcCurrntDt);
		logger.endTimer("KohlsReprocessRequestUtil.getCurrSysDateAsString");
		return str;
	}

	/**
	 * Compares 2 dates
	 * 
	 * @returns the flaf
	 */
	public static boolean isAfter(String strDate1, String strDate2) {
		logger.beginTimer("KohlsReprocessRequestUtil.isAfter");
		boolean isBefore = false;
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		Date date1;
		Date date2;
		try {
			date1 = sdf.parse(strDate1);
			date2 = sdf.parse(strDate2);
			if (date1.after(date2)) {
				isBefore = true;
			}
		} catch (Exception e) {
			//e.printStackTrace();
			logger.debug("Inside isAfter - Error while parsing the dates " +e.getMessage());
		}
		logger.endTimer("KohlsReprocessRequestUtil.isAfter");
		return isBefore;
	}

	/**
	 * This method deletes the record from the custom table if the sysdate is
	 * greater than purgedate
	 */
	public void deleteReprocessRecord(YFSEnvironment env, String sReprocessReqKey) {
		logger.beginTimer("KohlsReprocessRequestUtil.deleteReprocessRecord");
		logger.debug("Inside deleteReprocessRecord");
		Document inGetReqDoc;
		try {
			inGetReqDoc = XMLUtil
					.getDocument(KohlsPOCConstant.TEMPLATE_INPUT_DELETE_CUSTOM_REPROCESS_REQ);
			inGetReqDoc.getDocumentElement().setAttribute(
					KohlsPOCConstant.REPROCESS_REQ_KEY,sReprocessReqKey);
			Document outGetReprocessReq = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SERVICE_DELETE_CUSTOM_REPROCESS_REQUEST,
					inGetReqDoc);
			if(!YFCCommon.isVoid(outGetReprocessReq)) {
			  logger.debug("The output xml is "
					+ XMLUtil.getXMLString(outGetReprocessReq));	
			}
		} catch (Exception e) {
			logger.error("Exception while deleting the records" + e.getMessage());
			//e.printStackTrace();			
		}
		logger.endTimer("KohlsReprocessRequestUtil.deleteReprocessRecord");
	}
	//PerformanceImprovement-Start
	/**
	 * Loads the monitored URL properties from customer_overrides.properties
	 * into the collection
	 * 
	 * @return Properties
	 * @throws IOException
	 * yfs.REPROCESS_RETRY_THRESHOLD=3
	   yfs.REPROCESS_FAILOVER_TIMELAPSE_THRESHOLD=1800000
	 */
	public static void loadReprocessPropValues() throws IOException {
		logger.beginTimer("KohlsReprocessRequestUtil.loadReprocessPropValues");
		String reprocessRetryThreshold = getPropertyValue("REPROCESS_RETRY_THRESHOLD", "3");
		intReprocessRetryThreshold =Integer.parseInt(reprocessRetryThreshold);
		reprocessTimeLapseThreshold = getPropertyValue("REPROCESS_FAILOVER_TIMELAPSE_THRESHOLD", "1800000");
		logger.debug("reprocessRetryThreshold, intReprocessRetryThreshold,reprocessTimeLapseThreshold :" 
		+reprocessRetryThreshold+" "+intReprocessRetryThreshold+" "+reprocessTimeLapseThreshold);
		
		//reprocessHM.put("FAILURE_COUNTER",0);  
		updateLastFailoverTs(true);
		logger.endTimer("KohlsReprocessRequestUtil.loadReprocessPropValues");
		//return reprocessHM;
	}  

	/**
	 * This function is used to get the value for a property
	 * 
	 * @param property
	 *            name in string format
	 * @return String propValue
	 */
	public static String getPropertyValue(String property, String defaultValue) {
		logger.debug("Inside getPropertyValue method");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = defaultValue;
		}
		return propValue;

	}

	/**
	 * This method resets the failed counter values in the hashmap to zero
	 * 
	 * @return Void
	 */
	public static void resetFailedCounterAndTimer() {
		logger.debug("Inside resetFailedCounterAndTimer");
		intFailureCounter = 0;
		updateLastFailoverTs(true);
	}
	/**
	 * This method increments the failed counter values in the hashmap
	 * 
	 * @return Void
	 */
	public static void incrementFailedCounter() {
		logger.debug("Inside incrementFailedCounter");
		try{
		    intFailureCounter++;  
			if(intFailureCounter > intReprocessRetryThreshold && YFCCommon.isVoid(lastFailedOverTS)){
			  updateLastFailoverTs(false);
			}
		} catch (Exception e){
			logger.error("Exception Inside incrementFailedCounter" + e.getMessage());
		}
	}
	

	/**
	 * @param reset
	 */
	public static void updateLastFailoverTs(boolean reset) {
		logger.beginTimer("KohlsReprocessRequestUtil.updateLastFailoverTs");
		if (reset) {
		  logger.error("Resetting the failover timestamp");
		  lastFailedOverTS = null;
		} else {
		  try{
            Date date = new Date();
            long time;
            Timestamp currentTime;
            time = date.getTime();
            currentTime = new Timestamp(time);
            lastFailedOverTS = currentTime;
          }catch (Exception e){
              logger.error("Exception Inside updateLastFailoverTs" + e.getMessage());
          }
		}
		logger.endTimer("KohlsReprocessRequestUtil.updateLastFailoverTs");  
	}

	/**
	 * This method checks if the Failover_timelapse_threshold configured has
	 * elapsed or not
	 * 
	 * @return boolean
	 */
	public static boolean isThreaholdTimeElapsed() {  
		logger.beginTimer("KohlsReprocessRequestUtil.isThreaholdTimeElapsed");    
		Date date = new Date();
		long time = date.getTime();
		long timeLapseThreshold = Long.parseLong(reprocessTimeLapseThreshold);
		logger.debug("timeLapseThreshold:::"+timeLapseThreshold);
		Timestamp currentTime = new Timestamp(time);
		logger.debug("currentTime:::"+currentTime.getTime());
		if(!YFCCommon.isVoid(lastFailedOverTS)) {
		  logger.debug("lastFailoverTs:::"+lastFailedOverTS.getTime());
		}
		if ((currentTime.getTime() - lastFailedOverTS.getTime()) > timeLapseThreshold) {
			return true;
		}
		logger.endTimer("KohlsReprocessRequestUtil.isThreaholdTimeElapsed");
		return false;
	}
	//PerformanceImprovement-End
	
	/**
	 * Create By ibmadmin * 
	 * @param uncompressedString
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	public static String compressXML(String uncompressedString) throws UnsupportedEncodingException {
	  logger.beginTimer("KohlsReprocessRequestUtil.compressXML");
	  byte[] zippedData;
      try {
        zippedData = StringZipUtil.zipString(uncompressedString);
      } catch (IOException e) {
        zippedData = "".getBytes();
      }
      if(MessageUtil.isJMSDebuggerEnabled() || logger.isDebugEnabled()) {
        logger.info("Byte Size of xml data is : "+uncompressedString.getBytes().length);
        logger.info("Byte Size of compressed output is : "+zippedData.length);
      }
	  logger.endTimer("KohlsReprocessRequestUtil.compressXML");
	  return Base64.encode(zippedData);
	}
	
	/**
	 * Create By ibmadmin * 
     * @param xmlString
     * @return
	 * @throws UnsupportedEncodingException 
     */
    public static String decompressXML(String compressedString) throws UnsupportedEncodingException {
      logger.beginTimer("KohlsReprocessRequestUtil.decompressXML");
      byte[] compressedData = Base64.decode(compressedString);
      String uncompressedString;
      try {
        uncompressedString = StringZipUtil.unZipByteStream(new ByteArrayInputStream(compressedData));
      } catch (IOException e) {
        uncompressedString = "";
      }
      if(MessageUtil.isJMSDebuggerEnabled() || logger.isDebugEnabled()) {
        logger.info("Byte Size of compressed input is : "+compressedData.length);
        logger.info("Byte Size of xml data output is : "+uncompressedString.getBytes().length);
      }
      logger.endTimer("KohlsReprocessRequestUtil.decompressXML");
      return uncompressedString;
    }
}