/*
 * File: KohlsPocCreateReprocessMessageWrapper.java  Created on Jun 27, 2019 for POC_OMS_IBM_Returns by mrjoshi
 *
 * COPYRIGHT:
 * LICENSED MATERIALS - PROPERTY OF Kohls Stores
 * "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason  		Date     		Who Descriptions
 * ------- 		-------- 		--- -----------
 */
package com.kohls.poc.util;

import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author mrjoshi
 *
 */
public class KohlsPocCreateReprocessMessageWrapper {
  private final static YFCLogCategory logger = YFCLogCategory
      .instance(KohlsPocCreateReprocessMessageWrapper.class);
  
  public Document prepareInputForReprocessApi(YFSEnvironment env, Document docInXML) throws Exception{
    logger.beginTimer("KohlsPocCreateReprocessMessageWrapper.prepareInputForReprocessApi");
    Document docOutXML = null;
    if(logger.isDebugEnabled()) {
      logger.debug("Input xml to KohlsPocCreateReprocessMessageWrapper.prepareInputForReprocessApi is: "+XMLUtil.getXMLString(docInXML));
    }
    Element eleKohlsReprocessRequest = docInXML.getDocumentElement();
    String sMessage = eleKohlsReprocessRequest.getAttribute(KohlsPOCConstant.MESSAGE);
    if(YFCCommon.isVoid(sMessage)) {
      logger.error("Missing Message attribute in input xml: "+XMLUtil.getXMLString(docInXML));
      throw new YFSException("Missing Message in the input xml");
    }
    try {
      String sEscapedMessage = StringEscapeUtils.unescapeXml(sMessage);
      docOutXML = XMLUtil.getDocument(sEscapedMessage);
    } catch (Exception ex) {
      logger.error("Error while converting Message to Document: ",ex);
      throw new YFSException("Error while converting Message to Document");
    }
    if(logger.isDebugEnabled()) {
      logger.debug("Output xml of KohlsPocCreateReprocessMessageWrapper.prepareInputForReprocessApi is: "+XMLUtil.getXMLString(docOutXML));
    }
    logger.endTimer("KohlsPocCreateReprocessMessageWrapper.prepareInputForReprocessApi");
    return docOutXML;
  }
}
