package com.kohls.poc.util;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.math.NumberUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCCommercePSIStatusGenerator;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIDocumentsUtilForPOS;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIStatus;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.VerifonePointIntegrationClient;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.CapturePSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.NRSCPSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.TokenQuery;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.manager.OrderManager;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.manager.SessionManager;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCPinPadOperations extends NRSCPSIRequest {
  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPoCPinPadOperations.class.getName());
  }

  private boolean bIsDebugEnabled = logger.isDebugEnabled();
  // private boolean bIsDebugEnabled = true;

  static String[] declineCodes = {"6", "0", "93", "97", "1010", "59008", "59024"};
  static String[] expectedCodes =
      {"59049", "4", "5", "59001", "59007", "59046", "59026", "59023", "59025", "59027"};
  public static final List<String> ERROR_RESULT_CODES =
      Arrays.asList(new String[] {"59023", "59024", "59025", "59026", "59027"});
  static List<String> expectedCodesList = Arrays.asList(expectedCodes);
  static List<String> declineCodesList = Arrays.asList(declineCodes);

  static DecimalFormat formatter = new DecimalFormat("0.00");
  
  private static final int      START_SESSION_TIMEOUT            = 20000;

  private static final int      START_SESSION_RETRY_INTERVAL     = 50;


  public KohlsPoCPinPadOperations(PSIStatus status) {
    super(KohlsPOCConstant.PINPAD_PAYMENT_OPERATION, KohlsPOCConstant.PINPAD_CREDIT_OPERATION,
        status);
  }

  public KohlsPoCPinPadOperations(PSIStatus status, String functionType, String command) {
    super(functionType, command, status);
  }

  public KohlsPoCPinPadOperations() {}

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param docPayment
   * @return
   * @throws Exception
   */
  public Document doCreditRequest(YFSEnvironment env, Document docPayment) throws Exception {
    logger.beginTimer("KohlsPoCPinPadOperations.doCreditRequest");
    if (logger.isDebugEnabled()) {
      logger.debug("Input xml to KohlsPoCPinPadOperations is: " + XMLUtil.getXMLString(docPayment));
    }
    boolean isTrainingMode = ServerTypeHelper.amIOnTrainingServer();
    Document responseXml = null;

    Element elePayment =
        (Element) docPayment.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD).item(0);
    if (YFCCommon.isVoid(elePayment)) {
      throw new YFSException("No Payment method found to process");
    }
    Document docPSIInput = formInputForPSI(elePayment);
    Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);
    String paymentType = "";
    Element elePsiStatus =
        (Element) docPSIStatusOut.getElementsByTagName(KohlsXMLLiterals.E_PSI_STATUS).item(0);
    if (!YFCCommon.isVoid(elePsiStatus)) {
      YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
      NRSCCommercePSIStatusGenerator generator =
          new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
      PSIStatus psiStatus = generator.generatePSIStatus();
      KohlsPoCPinPadOperations request = new KohlsPoCPinPadOperations(psiStatus);
      paymentType = elePayment.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
      String token = elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
      String requestedAmount = elePayment.getAttribute(KohlsXMLLiterals.A_AMOUNT);
      String creditCardExpDate = elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
      String orderNo = elePayment.getAttribute(KohlsXMLLiterals.A_ORDER_NO);
      String sManualEntry = elePayment.getAttribute(KohlsXMLLiterals.A_MANUAL_ENTRY);
      String sKohlsChargeOnly = elePayment.getAttribute(KohlsXMLLiterals.A_KOHLS_CHARGE_ONLY);
      String isDebitTenderEnabled =
          elePayment.getAttribute(KohlsXMLLiterals.A_DEBIT_TENDER_ENABLED);

      if (!YFCCommon.isVoid(sManualEntry)
          && ("Y".equalsIgnoreCase(sManualEntry) || "true".equalsIgnoreCase(sManualEntry))) {
        sManualEntry = KohlsPOCConstant.TRUE.toUpperCase();
      } else {
        sManualEntry = KohlsPOCConstant.FALSE.toUpperCase();
      }

      request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, sManualEntry);

      if (YFCCommon.isVoid(orderNo)) {
        orderNo = elePayment.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1);
      }
      
      if(!YFCCommon.isVoid(orderNo) && orderNo.length() > 17) {
        orderNo = orderNo.substring(orderNo.length()-17);
      }
      
      if (!YFCCommon.isVoid(paymentType)) {

        if (KohlsPOCConstant.KOHL_CHARGE_CARD.equalsIgnoreCase(paymentType)) {
          if (KohlsPOCConstant.TRUE.equalsIgnoreCase(sManualEntry)) {
            // always use manual entry true for PRIV_LBL only for now
            request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, KohlsPOCConstant.TRUE.toUpperCase());
            if (KohlsPOCConstant.TRUE.equalsIgnoreCase(sKohlsChargeOnly)) {
              request.add(CapturePSIRequest.ExtFields.PAYMENT_TYPE,
                  KohlsPOCConstant.TENDER_TYPE_PRIV_LBL);
            } else {
              request.add(KohlsPOCConstant.PAYMENT_TYPES, KohlsPOCConstant.TENDER_TYPE_PRIV_LBL
                  + "|" + KohlsPOCConstant.PAYMENT_CREDIT_LABEL);
            }
          } else {
            request.add(CapturePSIRequest.ExtFields.PAYMENT_TYPE,
                KohlsPOCConstant.TENDER_TYPE_PRIV_LBL);
          }
          // MJ 05/09 Commented else block because of the defect 2915.
          /*
           * else { // always use manual entry true for PRIV_LBL only for now
           * request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, KohlsPOCConstant.TRUE.toUpperCase()); }
           */
        }
        // accomodating for debit transaction
        else if (KohlsPOCConstant.PAYMENT_DEBIT_CARD.equalsIgnoreCase(paymentType)) {
          request.add(CapturePSIRequest.ExtFields.PAYMENT_TYPE, KohlsPOCConstant.PAYMENT_DEBIT);
          request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, sManualEntry);
        } else if (KohlsPOCConstant.PAYMENT_CREDIT_CARD.equalsIgnoreCase(paymentType)
            && !YFCCommon.isVoid(token)) {
          request.add(CapturePSIRequest.ExtFields.PAYMENT_TYPE,
              KohlsPOCConstant.PAYMENT_CREDIT_LABEL);
          request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, sManualEntry);
        } else {
          if (KohlsPOCConstant.TRUE.equalsIgnoreCase(isDebitTenderEnabled)) {
            request.add(KohlsPOCConstant.PAYMENT_TYPES,
                KohlsPOCConstant.PAYMENT_CREDIT_PRIVATE_LABEL_DEBIT);
          } else {
            request.add(KohlsPOCConstant.PAYMENT_TYPES,
                KohlsPOCConstant.PAYMENT_CREDIT_PRIVATE_LABEL);
          }
        }
      }

      if (!YFCCommon.isVoid(token)) {
    	logger.debug("Processing CREDIT for PaymentType: " + paymentType + " and Card ending: " + token.substring(token.length() - 4));
        HashMap<String,String> rulesMap = KohlsPoCCommonAPIUtil.getRuleListByGroupName(env,KohlsPOCConstant.ASYNC_REFUND_PROCESSING, KohlsPOCConstant.KOHLS_RETAIL);
        if(!rulesMap.isEmpty())
        {
        	logger.beginTimer("KohlsPoCPinPadOperations.AsyncRefundProcessing - START");
        	String asynProcessingEnabled = rulesMap.get(KohlsPOCConstant.ASYNC_REFUND_PROCESSING);
        	if(KohlsPOCConstant.YES.equalsIgnoreCase(asynProcessingEnabled))
        	{
        		String asyncTimeOutValue = rulesMap.get(KohlsPOCConstant.ASYNC_TIMEOUT);
        		if(NumberUtils.isNumber(asyncTimeOutValue) && Long.parseLong(asyncTimeOutValue) > 0)
        		{
        			String timeoutInMs = String.valueOf(TimeUnit.SECONDS.toMillis(Long.parseLong(asyncTimeOutValue)));
        			request.add(KohlsPOCConstant.PAYMENT_RETURN_MSG_TIMEOUT, timeoutInMs);
        		}
        	}
        	logger.endTimer("KohlsPoCPinPadOperations.AsyncRefundProcessing - END");
        }
        request.add(CapturePSIRequest.ExtFields.CARD_TOKEN, token);
      }
      // make sure requested amount has 2 decimal places
      requestedAmount = formatter.format(Double.parseDouble(requestedAmount));
      request.add(CapturePSIRequest.ExtFields.TRANS_AMOUNT, requestedAmount);
      if (!YFCCommon.isVoid(creditCardExpDate)
          && !KohlsPOCConstant.KOHL_CHARGE_CARD.equalsIgnoreCase(paymentType)) {
        String month = creditCardExpDate.substring(0, 2);
        String year = creditCardExpDate.substring(2, 4);
        request.add(KohlsXMLLiterals.E_CARD_EXP_MONTH, month);
        request.add(KohlsXMLLiterals.E_CARD_EXP_YEAR, year);
      }

      if (isTrainingMode) {
        request.add(KohlsPOCConstant.TRAINING_MODE, "1");
      }

      // change for debit tender multiple scenarios

      logger.error("KohlsPoCPinPadOperations.doCreditRequest - request to Pinpad is "
          + XMLUtil.getXMLString(request.getDocument()));


      /*
       * VerifonePointIntegrationClient.startSession(psiStatus, !orderNo.contains("_")?orderNo :
       * orderNo.substring(0, orderNo.indexOf("_")), invoiceNumber(orderNo)); long start = 0; long
       * end = 0; start = System.currentTimeMillis(); responseXml =
       * VerifonePointIntegrationClient.sendWithCounterRetry(psiStatus, request); end =
       * System.currentTimeMillis();
       */

      SessionManager session = SessionManager.getSession(psiStatus);


      long start = 0;
      long end = 0;
      try {
        start = System.currentTimeMillis();
        managePinpadUpdates(session, true);
        responseXml = VerifonePointIntegrationClient.sendWithCounterRetry(psiStatus, request, true);

      } catch (Exception ex) {
        ex.printStackTrace();
        throw new YFSException(ex.getMessage());
      } finally {
        if (!YFCCommon.isVoid(responseXml)) {
          // String responseText = SCXmlUtil
          // .getChildElement(responseXml.getDocumentElement(), KohlsXMLLiterals.E_RESPONSE_TEXT)
          // .getTextContent();
          String resultCode = SCXmlUtil.getChildElement(responseXml.getDocumentElement(), "RESULT")
              .getTextContent();
          // String terminationStatus = SCXmlUtil.getChildElement(responseXml.getDocumentElement(),
          // KohlsXMLLiterals.E_TERMINATION_STATUS).getTextContent();
          if (!("5".equals(resultCode) || "4".equals(resultCode))) {
            try {
              // if (!KohlsPOCConstant.PAYMENT_DEBIT_CARD.equalsIgnoreCase(paymentType)) {
              VerifonePointIntegrationClient.refreshItemList(psiStatus);
              // }
            } catch (Exception ex) {
              // let the txn continue - log the occurrence
              logger.error(
                  "KohlsPoCPinPadOperations.doCreditRequest - exception trying to refresh item list");
            }
          }
        }
        managePinpadUpdates(session, false);
        end = System.currentTimeMillis();
      }

      if (!YFCCommon.isVoid(responseXml)) {
        Element responseDocElement = responseXml.getDocumentElement();
        NRSCPSIRequest.createChild(responseXml, null, KohlsXMLLiterals.E_AUTH_REQUEST_TIME,
            Long.toString(start));
        NRSCPSIRequest.createChild(responseXml, null, KohlsXMLLiterals.E_AUTH_RESP_TIME,
            Long.toString(end));
        logger.error("KohlsPoCPinPadOperations.doCreditRequest - response from pinpad is "
            + XMLUtil.getElementXMLString(responseDocElement));
        String responseCode = PSIDocumentsUtilForPOS.selectFirst(responseDocElement,
            KohlsXMLLiterals.E_RESULT_CODE, "990099");
        if (!(expectedCodesList.contains(responseCode))
            && !(declineCodesList.contains(responseCode))) {
          throw new Exception(PSIDocumentsUtilForPOS.selectFirst(responseDocElement,
              KohlsXMLLiterals.E_RESPONSE_TEXT, "unknown error"));
        }
      } else {
        throw new YFSException("Payment Failure");
      }
    }

    logger.endTimer("KohlsPoCPinPadOperations.doCreditRequest");

    return responseXml;

  }


  /**
   * Create By Bhoopesh *
   * 
   * @param orderNo
   * @return
   */
  protected String invoiceNumber(String orderNo) {
    int orderNoSize = orderNo.length();
    return orderNo.substring(orderNoSize - 4, orderNoSize);
  }

  /**
   * Create By Rob Fea *
   * 
   * @param elePayment
   * @return
   * @throws Exception
   */
  private Document formInputForPSI(Element elePayment) throws Exception {
    logger.beginTimer("KohlsPSARefund.formInputForPSI");
    Document docPSIStatus = XMLUtil.createDocument(KohlsXMLLiterals.E_PSI_STATUS);
    Element elePSIStatus = docPSIStatus.getDocumentElement();
    elePSIStatus.setAttribute(KohlsXMLLiterals.A_CLIENT_ID,
        elePayment.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
    if (!YFCCommon.isVoid(elePayment.getAttribute(KohlsXMLLiterals.A_STORE_ID))) {
      elePSIStatus.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE,
          elePayment.getAttribute(KohlsXMLLiterals.A_STORE_ID));
    } else {
      elePSIStatus.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE,
          elePayment.getAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE));
    }
    if (bIsDebugEnabled) {
      logger.debug("Input to getPSIStatusListForPOS" + XMLUtil.getXMLString(docPSIStatus));
    }
    logger.endTimer("KohlsPSARefund.formInputForPSI");
    return docPSIStatus;
  }

  public Document showItemsOnPinpad(YFSEnvironment env, Document input) throws Exception {
    Document responseXml = null;
    logger.beginTimer("KohlsPoCPinPadOperations.showLineItems");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Input xml to KohlsPoCPinPadOperations showLineItems is: " + XMLUtil.getXMLString(input));
    }
    Document docPSIInput = formInputForPSI(input.getDocumentElement());
    if ("PSIStatus".equals(input.getDocumentElement().getNodeName())) {
      docPSIInput = (Document) input.cloneNode(true);
    }
    Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);
    Element elePsiStatus =
        (Element) docPSIStatusOut.getElementsByTagName(KohlsXMLLiterals.E_PSI_STATUS).item(0);
    if (!YFCCommon.isVoid(elePsiStatus)) {
      YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
      NRSCCommercePSIStatusGenerator generator =
          new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
      PSIStatus psiStatus = generator.generatePSIStatus();
      OrderManager orderManager = SessionManager.getOrderManager(psiStatus);

      if (orderManager.inSession()) {
        VerifonePointIntegrationClient.refreshItemList(psiStatus);
        return XMLUtil.getDocument("<Order/>");
      }
    }

    Document orderDetailsDocument = SCXmlUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    orderDetailsDocument.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
        input.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));

    Document docGetOrderDetailsOut = KOHLSBaseApi.invokeAPI(env,
        "global/template/api/POC/managePSIOrder/managePSIOrderForPOS_POCReturns.xml",
        KohlsPOCConstant.API_GET_ORDER_DETAILS, orderDetailsDocument);
    Element elePSIStatus = input.getDocumentElement();
    String sTerminalID = elePSIStatus.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID);
    String sStoreID = elePSIStatus.getAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE_ATTRIBUTE);

    Element eleOrderOutRoot = docGetOrderDetailsOut.getDocumentElement();
    eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, sTerminalID);
    eleOrderOutRoot.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE_ATTRIBUTE, sStoreID);
    eleOrderOutRoot.setAttribute(KohlsPOCConstant.OPERATION,
        KohlsPOCConstant.OPERATION_UPDATE_SESSION);
    eleOrderOutRoot.setAttribute(KohlsPOCConstant.A_ORDER_DETAILS_INCLUDED, KohlsPOCConstant.TRUE);

    responseXml = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_PSI_ORDER_FOR_POS,
        docGetOrderDetailsOut);

    if (logger.isDebugEnabled()) {
      logger.debug("Here is the psi status: " + SCXmlUtil.getString(docPSIStatusOut));
    }

    logger.endTimer("KohlsPoCPinPadOperations.showLineItems");
    return responseXml;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param input‰
   * @return
   * @throws Exception
   */
  public Document showLineItems(YFSEnvironment env, Document input) throws Exception {
    Document responseXml = null;
    logger.beginTimer("KohlsPoCPinPadOperations.showLineItems");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "Input xml to KohlsPoCPinPadOperations showLineItems is: " + XMLUtil.getXMLString(input));
    }
    Document docPSIInput = formInputForPSI(input.getDocumentElement());
    Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);

    Document orderDetailsDocument = SCXmlUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    orderDetailsDocument.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
        input.getDocumentElement().getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));

    Document docGetOrderDetailsOut = KOHLSBaseApi.invokeAPI(env,
        "global/template/api/POC/managePSIOrder/managePSIOrderForPOS_POCReturns.xml",
        KohlsPOCConstant.API_GET_ORDER_DETAILS, orderDetailsDocument);
    Element elePSIStatus = input.getDocumentElement();
    String sTerminalID = elePSIStatus.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID);
    String sStoreID = elePSIStatus.getAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE_ATTRIBUTE);

    Element eleOrderOutRoot = docGetOrderDetailsOut.getDocumentElement();
    eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, sTerminalID);
    eleOrderOutRoot.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE_ATTRIBUTE, sStoreID);
    eleOrderOutRoot.setAttribute(KohlsPOCConstant.OPERATION,
        KohlsPOCConstant.OPERATION_UPDATE_SESSION);
    eleOrderOutRoot.setAttribute(KohlsPOCConstant.A_ORDER_DETAILS_INCLUDED, KohlsPOCConstant.TRUE);

    responseXml = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_PSI_ORDER_FOR_POS,
        docGetOrderDetailsOut);

    if (logger.isDebugEnabled()) {
      logger.debug("Here is the psi status: " + SCXmlUtil.getString(docPSIStatusOut));
    }

    logger.endTimer("KohlsPoCPinPadOperations.showLineItems");
    return responseXml;
  }

  /**
   * Create By Rob Fea *
   * 
   * @param env
   * @param docPayment
   * @return
   * @throws Exception
   */
  public Document doTokenQuery(YFSEnvironment env, Document docPayment) throws Exception {
    logger.beginTimer("KohlsPoCPinPadOperations.doTokenQuery");

    boolean isTrainingMode = ServerTypeHelper.amIOnTrainingServer();
    Document responseXml = null;

    Element elePayment =
        (Element) docPayment.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD).item(0);
    String paymentType = elePayment.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
    if (YFCCommon.isVoid(elePayment)) {
      throw new YFSException("No Payment method found to process");
    }
    Document docPSIInput = formInputForPSI(elePayment);
    Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);
    Element elePsiStatus =
        (Element) docPSIStatusOut.getElementsByTagName(KohlsXMLLiterals.E_PSI_STATUS).item(0);
    if (!YFCCommon.isVoid(elePsiStatus)) {
      YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
      NRSCCommercePSIStatusGenerator generator =
          new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
      PSIStatus psiStatus = generator.generatePSIStatus();

      SessionManager session = SessionManager.getSession(psiStatus);
      session.cancellableOperationStarting();
      OrderManager orderManager = SessionManager.getOrderManager(psiStatus);
      boolean localSessionStarted = false;
      if (!orderManager.inSession()) {
        //VerifonePointIntegrationClient.startSession(psiStatus, "0000", "0000");
        verifyPinPadSession (session);
       // System.out.println("Order Manager is session started");
        localSessionStarted = true;
      }
      NRSCPSIRequest query = new TokenQuery(psiStatus);
      if (!YFCCommon.isVoid(paymentType)) {
        if (KohlsPOCConstant.KOHL_CHARGE_CARD.equalsIgnoreCase(paymentType)) {
          query.add(CapturePSIRequest.ExtFields.PAYMENT_TYPE,
              KohlsPOCConstant.TENDER_TYPE_PRIV_LBL);
          query.add(KohlsXMLLiterals.E_MANUAL_ENTRY, KohlsPOCConstant.TRUE.toUpperCase());
        } else {
          query.add(KohlsXMLLiterals.E_MANUAL_ENTRY, KohlsPOCConstant.FALSE.toUpperCase());
        }
      } else {
        query.add(KohlsXMLLiterals.E_MANUAL_ENTRY, KohlsPOCConstant.FALSE.toUpperCase());
      }
      if (isTrainingMode) {
        query.add(KohlsPOCConstant.TRAINING_MODE, "1");
      }

      logger.error("KohlsPoCPinPadOperations.doTokenQuery - request to Pinpad is "
          + XMLUtil.getXMLString(query.getDocument()));
      
      try {
        //session.cancellableOperationStarting();
        responseXml = VerifonePointIntegrationClient.sendWithCounterRetry(psiStatus, query, true);
      } catch (Exception e) {
    	  	logger.error("KohlsPoCPinPadOperations.doTokenQuery: Error exception received from pinpad");
    	  	e.printStackTrace();
    	  	responseXml = (Document) docPayment.cloneNode(true);
      } finally {
    	  	session.cancellableOperationSent();
      }
      
      if (localSessionStarted) {
       // System.out.println("Order Manager is: cancelling"+orderManager.inSession());
        orderManager.forceSessionEnd();
        //VerifonePointIntegrationClient.finishSession(psiStatus);
      } else {
        try {
          VerifonePointIntegrationClient.refreshItemList(psiStatus);
        } catch (Exception ex) {
          // log the exception
          logger.error("KohlsPoCPinPadOperations.doTokenQuery - problem refreshing item list");
        }
      }

      Element responseDocElement = responseXml.getDocumentElement();
      logger.error("KohlsPoCPinPadOperations.doTokenQuery - response from pinpad is "
          + XMLUtil.getElementXMLString(responseDocElement));
    }
    logger.endTimer("KohlsPoCPinPadOperations.doTokenQuery");

      return responseXml;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param session
   * @param disable
   */
  protected void managePinpadUpdates(SessionManager session, boolean disable) {
    OrderManager order = SessionManager.getOrderManager(session.getPSIStatus());
    if (order != null) {
      if (logger.isDebugEnabled()) {
        logger.debug(new StringBuilder().append("managePINPadUpdates: ")
            .append((!(disable)) ? "enable" : "disable").toString());
      }
      if (disable == true) {
        order.disableUpdates();
      } else {
        order.enableUpdates();
      }
    } else {
      if (!(logger.isDebugEnabled())) {
        logger.debug("managePINPadUpdates: NO ORDER MANAGER");
      }
    }
  }
  
  private void verifyPinPadSession( SessionManager session )
  {
     if ( session != null )
     {
        final OrderManager orderMgr = SessionManager.getOrderManager( session.getPSIStatus() );
        if ( !( orderMgr.inSession() ) )
        {
           ScheduledExecutorService sessionStartPoll = Executors.newSingleThreadScheduledExecutor();
           Callable<Boolean> checkSessionStart = new Callable<Boolean>()
           {

              @Override
              public Boolean call() throws Exception
              {
                 return orderMgr.inSession();
              }

           };
           // start a PIN pad session if one has not yet been created
           orderMgr.pushSessionStart( null, "0000", "0000" );
           orderMgr.forceSessionStart( "0000", "0000" );

           try
           {
              // prevent race condition between session start and sending of the prompt request by blocking until session start completes
              boolean sessionStarted = false;
              int maxRetries = START_SESSION_TIMEOUT / ( ( START_SESSION_RETRY_INTERVAL == 0 ) ? 1 : START_SESSION_RETRY_INTERVAL );

              while ( !sessionStarted && maxRetries > 0 )
              {
                 ScheduledFuture<Boolean> pollResult = sessionStartPoll.schedule( checkSessionStart, START_SESSION_RETRY_INTERVAL, TimeUnit.MILLISECONDS );
                 try
                 {
                    sessionStarted = pollResult.get();
                 }
                 catch ( Exception e )
                 {
                    if ( logger.isDebugEnabled() )
                    {
                       // log and continue looping
                      logger.debug( "Thread interrupted while polling for session start", e );
                    }
                 }
                 finally
                 {
                    maxRetries--;
                 }
              }
              if ( maxRetries <= 0 )
              {
                 if ( logger.isInfoEnabled() )
                 {
                    logger.info( String.format("Session not started after polling for %d milliseconds; continuing with prompt request", START_SESSION_TIMEOUT ) );
                 }
              }
           }
           finally
           {
              sessionStartPoll.shutdown();
           }
        }
     }
  }
}
