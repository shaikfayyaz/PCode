package com.kohls.poc.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;


/**************************************************************************
 * File : KohlsGetFullSyncExportLevels.java 
 * Author : Yantriks Created : Dec 14 2017
 ***************************************************************************** 
 * This document has been prepared and written by Yantriks
 * on behalf of Kohls, and is copyright of Kohls
 *****************************************************************************/
 
public class KohlsGetFullSyncExportLevels extends KOHLSBaseApi {
	
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsGetFullSyncExportLevels.class.getName());
	
	public Document getExportLevels(YFSEnvironment env, Document inDoc) throws Exception {
		logger.debug("Beginning updateCommonCode with inDoc " + SCXmlUtil.getString(inDoc));
		
		//Initialize variables
		Element eleInDoc = inDoc.getDocumentElement();
		Document outDoc = SCXmlUtil.createDocument(KohlsPOCConstant.SYNC_EXPORT_LEVELS);
		Element eleOutDoc = outDoc.getDocumentElement();
		String  exportTime="", sequenceNo="";
		
		//Call getSyncProfileList
		Document docSyncProfile = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_PROFILE);
		logger.debug("Calling api with input " + SCXmlUtil.getString(docSyncProfile));
		Document docSyncProfileListOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST_TEMPLATE_PATH, KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST,
				docSyncProfile);
		logger.debug("docSyncProfileListOutput " + SCXmlUtil.getString(docSyncProfileListOutput));
		
		
		if (docSyncProfileListOutput != null) {
			ArrayList<Element> profileList = SCXmlUtil.getChildren(docSyncProfileListOutput.getDocumentElement(),
					KohlsPOCConstant.E_SYNC_PROFILE);
			
			//For each profile, call getSyncDBExport to find the maximum sequence number and profile name
			for (Element profile : profileList) {
				logger.debug("current profile " + SCXmlUtil.getString(profile));
				
				//Create syncDBExport input
				String sTableGroup = profile.getAttribute(KohlsPOCConstant.A_TABLE_GROUP);
				String sProfileName = profile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
				Document docExportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_EXPORT).getDocument();
				docExportSyncDB.getDocumentElement().setAttribute(KohlsPOCConstant.A_TABLE_GROUP, sTableGroup);
				
				//The input filter for SyncType will change according to whether we need full or delta export levels
				if(KohlsPOCConstant.DATASYNC_PROFLE_FULL.equals(eleInDoc.getAttribute(KohlsPOCConstant.COMMON_CODE_TYPE))){
					docExportSyncDB.getDocumentElement().setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_FULL);
				}else{
					docExportSyncDB.getDocumentElement().setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_DELTA);
				}
				
				//Call getSyncDBExportList api
				logger.debug("Calling api with input " + SCXmlUtil.getString(docExportSyncDB));
				Document getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
						KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST, docExportSyncDB);
				logger.debug("getSyncDBExportListOutputDoc " + SCXmlUtil.getString(getSyncDBExportListOutputDoc));
				
				//For each profile, get sequenceNo and exportTime
				 HashMap<String, String> seqNoExportTimeMap = getSequenceNumberDBExportTimeMap(getSyncDBExportListOutputDoc, 
						 sProfileName, eleInDoc);
				 
				 //Append new profile element with sequenceNo, exportTime and profileName
				 Element eleProfile = SCXmlUtil.createChild(eleOutDoc, KohlsPOCConstant.E_PROFILE);
				 for (Entry<String, String> entry : seqNoExportTimeMap.entrySet()) {
						sequenceNo = entry.getKey();
						exportTime = entry.getValue();
					}

				 eleProfile.setAttribute(KohlsPOCConstant.A_NAME, sProfileName);
				 eleProfile.setAttribute(KohlsPOCConstant.DB_EXPORT_TIME, exportTime);
				 eleProfile.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, sequenceNo);
				 logger.debug("current profile after setting values " + SCXmlUtil.getString(profile));
				}
			}
		
		return outDoc;
				
	}
	
	/*
	 * Method to find out maxiumum sequence no & db export time corresponding to that sequence number
	 */
	private HashMap<String, String> getSequenceNumberDBExportTimeMap(Document getListDoc, String syncProfile,
			Element eleInDoc) {
		logger.debug("Beginning getSequenceNumberDBExportTimeMap with getListDoc " + SCXmlUtil.getString(getListDoc));
		
		//Initialize variables
		String finalSeqNo = "", DBExportTime="";
		HashMap<String,String> sequenceNoDBExportTimeMap = new HashMap();
		ArrayList<Element> profileList = SCXmlUtil.getChildren(getListDoc.getDocumentElement(),
				KohlsPOCConstant.E_SYNC_DB_EXPORT);
		HashMap<String, String> profileSequenceMap = new HashMap<String, String>();
		String existingSeqNo = "";
		
		//Initialize profileSequenceMap to ZERO_DOT_ZERO
		for (Element eleProfile : profileList) {
			profileSequenceMap.put(eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID), KohlsPOCConstant.ZERO_DOT_ZERO);
		}
		
		//Find out the maximum sequence and corresponding dbExportTime
		for (Element eleProfile : profileList) {
			logger.info("current profile " + SCXmlUtil.getString(eleProfile));
			String currSyncProfileID = eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
			BigDecimal currSeqNo = new BigDecimal((eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO)));
			
			String strPrevSeqNo = profileSequenceMap.get(currSyncProfileID);
			BigDecimal prevSeqNo = new BigDecimal(strPrevSeqNo);

			if (currSeqNo.compareTo(prevSeqNo) ==1) {
				profileSequenceMap.put(currSyncProfileID, eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
				prevSeqNo = currSeqNo;
				DBExportTime = eleProfile.getAttribute(KohlsPOCConstant.DB_EXPORT_TIME);
			}
		}

		if (profileList.size() > 0 && !YFCObject.isVoid(profileSequenceMap.get(syncProfile))) {
			if(KohlsPOCConstant.DATASYNC_PROFLE_FULL.equals(eleInDoc.getAttribute(KohlsPOCConstant.COMMON_CODE_TYPE))){
				existingSeqNo = profileSequenceMap.get(syncProfile).split("\\.")[0];
			}else{
				existingSeqNo = profileSequenceMap.get(syncProfile);
			}
		} else {
			finalSeqNo = KohlsPOCConstant.ZERO_DOT_ZERO;
		}
		logger.info("finalSeqNo " + finalSeqNo);
		logger.info("DBExportTime " + DBExportTime);
		finalSeqNo = existingSeqNo;
		sequenceNoDBExportTimeMap.put(finalSeqNo, DBExportTime);
		return sequenceNoDBExportTimeMap;
	}
	
}
