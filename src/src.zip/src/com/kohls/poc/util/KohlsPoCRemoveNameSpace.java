package com.kohls.poc.util;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XPathUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;

public class KohlsPoCRemoveNameSpace {
	
	private static YFCLogCategory logger;
	
	static {
		logger = YFCLogCategory.instance(KohlsPoCRemoveNameSpace.class.getName());
	}

	
	public Document removeNameSpace(Document inDoc) throws Exception{
		logger.beginTimer("KohlsPoCRemoveNameSpace.removeNameSpace");
		if(logger.isDebugEnabled()){
			logger.debug(SCXmlUtil.getString(inDoc));
		}
		Document doc = null;
		String docStr = removeXmlStringNamespaceAndPreamble((SCXmlUtil.getString(inDoc)));
		doc = SCXmlUtil.createFromString(docStr);
		renameTaxElement(doc);
		if(logger.isDebugEnabled()){
			logger.debug(SCXmlUtil.getString(doc));
		}
		logger.endTimer("KohlsPoCRemoveNameSpace.removeNameSpace");
		return doc;
				
	}
	
	private void renameTaxElement(Document inDoc) throws Exception {
		NodeList ndlTax = XPathUtil.getNodeList(inDoc,"/priceResponse/transaction/itemList/item/tax");
		if (ndlTax!=null){
			 for (int c=0;c<ndlTax.getLength();c++){
				 inDoc.renameNode(ndlTax.item(c), "", "LineTax");
			 }
		}
	}

	public static String removeXmlStringNamespaceAndPreamble(String xmlString) {
		  return xmlString.replaceAll("xmlns.*?(\"|\').*?(\"|\')", "").replaceAll("ns(\\w+:)", ""); 
		 
		}

}
