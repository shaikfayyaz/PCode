package com.kohls.poc.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSConnectionHolder;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsSelectOfflineRecordForAlert implements YIFCustomApi{


	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsSelectOfflineRecordForAlert.class.getName());

	public Document getSterlingDBConn(YFSEnvironment env, Document inXML)
			throws Exception {

		Document docOfflineTranSync=null; 

		if(inXML!=null) {
		
		Element eleRoot = inXML.getDocumentElement();
		String strStore = eleRoot.getAttribute("Store");
		Double doubInminutes = (double) 25/(24*60); //Minutes converted into days
		PreparedStatement ps= null;

		try {
			logger.debug("In KohlsSelectOfflineRecordForAlert class - getSterlingDBConn method Input is: " + SCXmlUtil.getString(inXML));

			YFSConnectionHolder connHolder = (YFSConnectionHolder) env;
			Connection oracleConnection = connHolder.getDBConnection();
			StringBuffer strBuffer = new StringBuffer();
			strBuffer.append("SELECT COUNT(*) FROM POS_OFFLINE_TRX_Q"
								+ " WHERE TRX_STATUS=1"
								+" AND STORE_ID="+Integer.parseInt(strStore) 
								+" AND MODIFYTS"+"<"+"SYSDATE"+"-"+doubInminutes);

			logger.debug("Update Query prepared is: "+strBuffer.toString());

			ps = oracleConnection.prepareStatement(strBuffer.toString());
			ResultSet rs = ps.executeQuery();
			int count=0;
			while (rs.next()) {
				count = rs.getInt(1);		
			}
            docOfflineTranSync = SCXmlUtil.createDocument("OfflineTranSync");
            docOfflineTranSync.getDocumentElement().setAttribute("OrderCount", String.valueOf(count));
			logger.debug("Executed SQL Statement successfully");
			if(ps!=null){
				ps.close();
				logger.debug("Closed prepared statement");
			}

			return docOfflineTranSync;
		} catch (SQLException e) {
			logger.error("SQL Exception occured: "+e);
			throw new YFSException();
		}
		catch(Exception e){
			logger.error("Exception occured: "+e);
			throw new YFSException();
		}
		finally {
			if(ps!=null){
				ps.close();
				logger.debug("Closed prepared statement");
			}
		}
	 }
		return docOfflineTranSync;
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
	}


}
