package com.kohls.poc.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


/******************************************************************************************
 * File Name : KohlsSecurityUtil.java
 * 
 * Description : This class will check for the respective attributes passed as
 * arguments, in each elementLevel of input XML which is received. If element
 * name is in that input XML, then these attributes are either encrypted or
 * decrypted depending on the protegrity type that is passed as arguments to the
 * service, which invokes this Class.
 * 
 * Modification Log :
 * ------------------------------------------------------------
 * ---------------------------- Ver # Date Author Modification
 * ------------------
 * ---------------------------------------------------------------------- 0.01
 * 26-06-2015 IBM Initial Version
 * 
 * ----------------------------------------------------------------------------
 * ----------
 *****************************************************************************************/

public class KohlsPoCSecurityUtil {
	/** LOG variable for logging. */
	private static final YFCLogCategory LOG = YFCLogCategory
			.instance(KohlsPoCSecurityUtil.class.getName());
	/**
	 * securityPlatfrom reference for invoke Protegrity Server.
	 */
	private KohlsPoCInvokeDataSecurityPlatform securityPlatfrom = new KohlsPoCInvokeDataSecurityPlatform();
	/**
	 * properties reference to read configured arguments.
	 */
	private Properties props = null;
	/**
	 * sHostXC to save host details.
	 */
	private String sHostXC = null;
	
	/**
	 * policyUser is to save userName.
	 */
	private String policyUser = null;

	/**
	 * @param env
	 *            env
	 * @param inXml
	 *            inXml
	 * @return Document
	 * @throws Exception
	 *             exception This method will read sHostXC,dataElement and
	 *             policyUser from customer override properties file. This
	 *             method will read PROTEGRITY_TYPE from configuration
	 *             arguments. find FirstName,LastName, EmailId and ZipCode in
	 *             XML and replace attribute value with encrypted or decrypted
	 *             value based on protegrityType
	 * 
	 */
	public Document encryptDecryptXML(YFSEnvironment env, Document inXml)
			throws Exception {
		LOG.beginTimer("KohlsPoCSecurityUtil.encryptDecryptXML");
		LOG.debug("Input XML to KohlsPoCSecurityUtil.encryptDecryptXML is: "
				+ XMLUtil.getXMLString(inXml));
		
		String attribute = null;
		String attributePart1 = null;
		String attributePart2 = null;
		String[] delimitedSlash = null;
		String conversionType = null;
		String cryptingAttribute = null;
		String xPath = null;
		String attributeNo = null;
		String dataElement = null;
		/*
		 * Map<String, String> attributesDataMap = new HashMap<String,
		 * String>(); Element rootElement = inXml.getDocumentElement();
		 */
		int noOfAttributes = Integer.valueOf(this.props
				.getProperty(KohlsPOCConstant.NoOfAttributes));
		/*
		 * sHostXC = new String("nlg00601.tst.kohls.com:15911"); policyUser =
		 * new String("shdev");
		 */
		sHostXC = this
				.getPropertyValue(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
		policyUser = this.getPropertyValue(KohlsPOCConstant.POLICY_USER);
		LOG.debug("The PROTEGRITY_SERVER_HOST is : " + sHostXC);
		LOG.debug("The POLICY_USER is : " + policyUser);

		/*
		 * sHostXC = new String("localhost:15910"); policyUser = new
		 * String("shdev");
		 */

		LOG.debug("The noOfAttributes value is : " + noOfAttributes);
		try {
		  LOG.debug("Opening the protegrity connection");
		  securityPlatfrom.run(sHostXC, policyUser);
		  
		  for (int i = 0; i < noOfAttributes; i++) {

            attributeNo = "Attribute" + (i + 1);
            LOG.debug("The attribute No is : " + attributeNo);
            attributePart1 = this.props.getProperty(attributeNo + "_1");
            attributePart2 = this.props.getProperty(attributeNo + "_2");
            if (attributePart2 == null) {
                attributePart2 = " ";
            }
            // LOG.debug("The attribute value is : " + attributePart1);
            attribute = attributePart1.concat(attributePart2).trim();
            LOG.debug("The attribute to be encrypted is : " + attributePart2);
            delimitedSlash = attribute.split(KohlsPOCConstant.DelimitedSlash);
            conversionType = delimitedSlash[0];
            xPath = delimitedSlash[2];
            cryptingAttribute = delimitedSlash[3];
            dataElement = delimitedSlash[1];
            //Fix for defect 3604 - Start
            if (!YFCCommon.isVoid(cryptingAttribute) || !YFCCommon.isVoid(dataElement)) {
                // securityPlatfrom.run(sHostXC, dataElement, policyUser);
                searchAndReplaceByGenericXPath(inXml, conversionType,
                        cryptingAttribute, dataElement, xPath);

                // searchAndReplaceByXPath(inXml, conversionType,
                // cryptingAttribute,
                // dataElement);
                /*
                 * searchAndReplaceInElementLevel(rootElement, conversionType,
                 * attributesDataMap, cryptingAttribute, dataElement);
                 * readAllElements(rootElement, attributesDataMap,
                 * conversionType, cryptingAttribute, dataElement);
                 */
            }else{
                YFSException es = new YFSException();
                es.setErrorCode("Invalid Crypting Attribute or DataElement for Protegrity");
                es.setErrorDescription("Invalid Crypting Attribute or DataElement for Protegrity"
                        + "Please correct the configuration and try again");
                throw es;       
            }
            //Fix for defect 3604 - End
          }

          LOG.debug("Output XML from KohlsPoCSecurityUtil.encryptDecryptXML is: "
                + XMLUtil.getXMLString(inXml));
          
		} catch (Exception ex) {
		  LOG.error("Exception in KohlsPoCSecurityUtil.encryptDecryptXML", ex);
		} finally {
		  LOG.debug("Closing the protegrity connection");
		  securityPlatfrom.closeSession();
		}
		
		LOG.endTimer("KohlsPoCSecurityUtil.encryptDecryptXML");
		return inXml;

	}

	public void searchAndReplaceByGenericXPath(Document inXml,
			String conversionType, String cryptingAttribute,
			String dataElement, String xPath) throws Exception {
		LOG.beginTimer("KohlsPoCSecurityUtil.searchAndReplaceByGenericXPath");
		String[] delimitedSpace = null;
		String firstName = null;
		String lastName = null;
		String cryptingAttributeValue = null;

		try {
			NodeList baseElementList = ((NodeList) XPathUtil.getNodeList(
					inXml.getDocumentElement(), xPath));
			for (int i = 0; i < baseElementList.getLength(); i++) {
				Element baseElement = (Element) baseElementList.item(i);
				cryptingAttributeValue = baseElement
						.getAttribute(cryptingAttribute);
				if (!YFCCommon.isVoid(cryptingAttributeValue)) {
					// initializing the crypt only when attribute to be
					// encrypted has
					// not null value
					// Opening Session to connect to Protegrity server with
					// parameters
					// sHostXC,dataElement and policyUser.
				  
					//securityPlatfrom.run(sHostXC, dataElement, policyUser);
					
					if(conversionType.equalsIgnoreCase("Encrypt")){
						if (cryptingAttribute
								.equalsIgnoreCase(KohlsPOCConstant.ExtnTaxExemptCustName)
								&& baseElement.getAttribute(cryptingAttribute)
										.contains(KohlsPOCConstant.SPACE)) {
							delimitedSpace = cryptingAttributeValue
									.split(KohlsPOCConstant.SPACE);
							firstName = delimitedSpace[0];
							lastName = delimitedSpace[1];
							String firstNameEncryp = securityPlatfrom
									.returnEncryptedValue(firstName, dataElement);
							String lastNameEncryp = securityPlatfrom
									.returnEncryptedValue(lastName, dataElement);
							String encryptedVal = firstNameEncryp.concat(
									KohlsPOCConstant.SPACE).concat(lastNameEncryp);
							baseElement.setAttribute(cryptingAttribute,
									encryptedVal);
							baseElement.setAttribute(cryptingAttribute
									.concat(KohlsPOCConstant.DataElement),
									dataElement);
						} else if (cryptingAttribute
								.equalsIgnoreCase(KohlsPOCConstant.Value)) {
							if (baseElement.getAttribute(KohlsPOCConstant.Name)
									.contains(KohlsPOCConstant.DL)) {
								baseElement
										.setAttribute(
												cryptingAttribute,
												securityPlatfrom
														.returnEncryptedValue(cryptingAttributeValue, dataElement));
								baseElement.setAttribute(cryptingAttribute
										.concat(KohlsPOCConstant.DataElement),
										dataElement);
							}
						}
						// Manoj 10/14: Added for defect 5683 - Begin
						else if (cryptingAttribute
								.equalsIgnoreCase("CreditCardExpDate")) {
							if (cryptingAttributeValue.length() == 4) {
								String sFlippedExpDate = cryptingAttributeValue
										.substring(2)
										+ cryptingAttributeValue.substring(0, 2);
								cryptingAttributeValue = sFlippedExpDate;
							String sCCExpDateEncrypted = securityPlatfrom
									.returnEncryptedValue(cryptingAttributeValue, dataElement);
							baseElement.setAttribute(cryptingAttribute,
									sCCExpDateEncrypted);
							baseElement.setAttribute(cryptingAttribute
									.concat(KohlsPOCConstant.DataElement),
									dataElement);
							}
						}
						// Manoj 10/14: Added for defect 5683 - End
						else if (cryptingAttribute.equalsIgnoreCase(KohlsPOCConstant.EXTN_GEO_ZIPCODE)) {
							if (cryptingAttributeValue.trim().length() == 5
									|| cryptingAttributeValue.trim().length() == 6) {
								baseElement.setAttribute(cryptingAttribute,
										securityPlatfrom.returnEncryptedValue(cryptingAttributeValue, dataElement));
								baseElement.setAttribute(cryptingAttribute.concat(KohlsPOCConstant.DataElement),
										dataElement);
							} else {
								baseElement.setAttribute(cryptingAttribute, cryptingAttributeValue);
								baseElement.setAttribute(cryptingAttribute.concat(KohlsPOCConstant.DataElement),
										dataElement);
							}
						}
						else {
							String sCryptingAttributeValue = baseElement
									.getAttribute(cryptingAttribute);
							if (!YFCCommon.isVoid(sCryptingAttributeValue)) {
								baseElement
										.setAttribute(
												cryptingAttribute,
												securityPlatfrom
														.returnEncryptedValue(cryptingAttributeValue, dataElement));
								baseElement.setAttribute(cryptingAttribute
										.concat(KohlsPOCConstant.DataElement),
										dataElement);
							}
						}
					} else if(conversionType.equalsIgnoreCase("Decrypt")){						
						baseElement.setAttribute(cryptingAttribute, securityPlatfrom.returnDecryptedValue(cryptingAttributeValue, dataElement));
							baseElement.setAttribute(cryptingAttribute.concat(KohlsPOCConstant.DataElement),dataElement);
					} else {
						YFSException es = new YFSException();
						es.setErrorCode("Incorrect Conversion Type for Protegrity");
						es.setErrorDescription("Incorrect conversion type '"+conversionType+"' for Protegrity. Valid conversion types are: Encrypt, Decrypt."
								+ "Please correct the configuration and try again");
						throw es;		
					}
				}
			}
		} catch (YFSException e){
			throw e;
		}
		//Adding try catch block for defect 538 
		catch (Exception e) {
			e.printStackTrace();
			YFSException es = new YFSException();
			//Fix for defect 3604 - Start
			es.setErrorCode(" Protegrity Error !! ");
			//es.setErrorCode(e.getCause().toString());
			//Fix for defect 3604 - End
			es.setErrorDescription(e.getMessage());
			throw es;			
		} finally {			
			// Closing the Protegrity server session
			//securityPlatfrom.closeSession();
		}
		LOG.endTimer("KohlsPoCSecurityUtil.searchAndReplaceByGenericXPath");
	}

	public void searchAndReplaceByXPath(Document inXml, String conversionType,
			String cryptingAttribute, String dataElement) throws Exception {

		LOG.beginTimer("KohlsPoCSecurityUtil.searchAndReplaceByXPath");

		if (cryptingAttribute.equalsIgnoreCase("ExtnEReceiptEmailID")
				|| cryptingAttribute
						.equalsIgnoreCase("ExtnTaxExemptCustLicense")
				|| cryptingAttribute
						.equalsIgnoreCase("ExtnTaxExemptCustZipCode")
				|| cryptingAttribute.equalsIgnoreCase("ExtnTaxExemptCustName")) {

			Element orderExtnEle = KohlsXMLUtil.getElementByXpath(inXml,
					"InvoiceDetail/InvoiceHeader/Order/Extn");
			if (!YFCCommon.isVoid(orderExtnEle.getAttribute(cryptingAttribute))) {
				if (cryptingAttribute
						.equalsIgnoreCase(KohlsPOCConstant.ExtnTaxExemptCustName)
						&& orderExtnEle.getAttribute(cryptingAttribute)
								.contains(KohlsPOCConstant.SPACE)) {
					String[] delimitedSpace = orderExtnEle.getAttribute(
							cryptingAttribute).split(KohlsPOCConstant.SPACE);
					String firstName = delimitedSpace[0];
					String lastName = delimitedSpace[1];
					String firstNameEncryp = securityPlatfrom
							.returnEncryptedValue(firstName, dataElement);
					String lastNameEncryp = securityPlatfrom
							.returnEncryptedValue(lastName, dataElement);
					String encryptedVal = firstNameEncryp.concat(
							KohlsPOCConstant.SPACE).concat(lastNameEncryp);
					orderExtnEle.setAttribute(cryptingAttribute, encryptedVal);
					orderExtnEle.setAttribute(cryptingAttribute
							.concat(KohlsPOCConstant.DataElement), dataElement);
				} else {
					orderExtnEle.setAttribute(cryptingAttribute,
							securityPlatfrom.returnEncryptedValue(orderExtnEle
									.getAttribute(cryptingAttribute), dataElement));
					orderExtnEle.setAttribute(cryptingAttribute
							.concat(KohlsPOCConstant.DataElement), dataElement);
				}

			}

		}

		if (cryptingAttribute.equalsIgnoreCase("ZipCode")
				|| cryptingAttribute.equalsIgnoreCase("ExtraDetails5")
				|| cryptingAttribute.equalsIgnoreCase("CreditCardExpDate")) {

			List<Element> collectionDetailsList = KohlsXMLUtil
					.getElementListByXpath(inXml,
							"InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail");
			for (Element collectionDetailEle : collectionDetailsList) {
				Element paymentMethodEle = XMLUtil.getChildElement(
						collectionDetailEle, "PaymentMethod");
				Element personInfoBillToEle = XMLUtil.getChildElement(
						paymentMethodEle, "PersonInfoBillTo");

				if (cryptingAttribute.equalsIgnoreCase("ZipCode")) {
					personInfoBillToEle.setAttribute(cryptingAttribute,
							securityPlatfrom
									.returnEncryptedValue(personInfoBillToEle
											.getAttribute(cryptingAttribute), dataElement));
					personInfoBillToEle.setAttribute(cryptingAttribute
							.concat(KohlsPOCConstant.DataElement), dataElement);
				} else if (!YFCCommon.isVoid(paymentMethodEle
						.getAttribute(cryptingAttribute))) {
					paymentMethodEle.setAttribute(cryptingAttribute,
							securityPlatfrom
									.returnEncryptedValue(paymentMethodEle
											.getAttribute(cryptingAttribute), dataElement));
					paymentMethodEle.setAttribute(cryptingAttribute
							.concat(KohlsPOCConstant.DataElement), dataElement);
				}
			}

		}

		if (cryptingAttribute.equalsIgnoreCase(KohlsPOCConstant.Value)) {

			List<Element> referencesList = KohlsXMLUtil.getElementListByXpath(
					inXml,
					"InvoiceDetail/InvoiceHeader/Order/References/Reference");
			for (Element referenceEle : referencesList) {
				if (referenceEle.getAttribute(KohlsPOCConstant.Name).contains(
						KohlsPOCConstant.DL)) {
					referenceEle.setAttribute(cryptingAttribute,
							securityPlatfrom.returnEncryptedValue(referenceEle
									.getAttribute(cryptingAttribute), dataElement));
					referenceEle.setAttribute(cryptingAttribute
							.concat(KohlsPOCConstant.DataElement), dataElement);
				}
			}
		}
		LOG.endTimer("KohlsPoCSecurityUtil.searchAndReplaceByXPath");
	}

	/**
	 * @param element
	 *            Order
	 * @param map
	 *            map
	 * @param conversionType
	 *            Decryption
	 * @param cryptingAttribute
	 * @throws Exception
	 *             This method will get each child elements for given element.
	 */

	public void readAllElements(Element element, Map<String, String> map,
			String conversionType, String cryptingAttribute, String dataElement)
			throws Exception {
		LOG.beginTimer("KohlsPoCSecurityUtil.readAllElements");

		List<Element> elementList = SCXmlUtil.getChildrenList(element);
		for (Element elementObj : elementList) {
			searchAndReplaceInElementLevel(elementObj, conversionType, map,
					cryptingAttribute, dataElement);
			if (elementObj.getNodeType() == Node.ELEMENT_NODE) {
				readAllElements(elementObj, map, conversionType,
						cryptingAttribute, dataElement);
			}
		}

		LOG.endTimer("KohlsPoCSecurityUtil.readAllElements");
	}

	/**
	 * @param element
	 *            element
	 * @param conversionType
	 *            conversionType
	 * @param attributesDataMap
	 *            attributesDataMap
	 * @param cryptingAttribute
	 * @throws Exception
	 *             exception It will do equalsIgnoreCase check with respective
	 *             attributes, passed as arguments to the service, in each given
	 *             element. It will replace with respective attribute values
	 *             with encrypt or decrypt values by based on conversionType.
	 */

	public void searchAndReplaceInElementLevel(Element element,
			String conversionType, Map<String, String> attributesDataMap,
			String cryptingAttribute, String dataElement) throws Exception {
		LOG.beginTimer("KohlsPoCSecurityUtil.searchAndReplaceInElementLevel");
		Node childNode = null;
		String nodeValue = null;
		String[] delimitedSpace = null;
		String firstName = null;
		String lastName = null;
		String firstNameEncryp = null;
		String lastNameEncryp = null;
		String encryptedVal = null;
		String decryptedVal = null;
		NamedNodeMap attributesMap = element.getAttributes();
		LOG.debug("The attributesMap value is: " + attributesMap.toString());
		for (int i = 0; i < attributesMap.getLength(); ++i) {
			childNode = attributesMap.item(i);
			String nodeName = childNode.getNodeName().toLowerCase();
			if (nodeName.equalsIgnoreCase(cryptingAttribute)) {
				nodeValue = childNode.getNodeValue().trim();
				if (!nodeValue.isEmpty()) {
					/*
					 * if (attributesDataMap.get(childNode.getNodeName() +
					 * childNode.getNodeValue()) == null) {
					 */
					LOG.debug("childNode.getNodeName()+childNode.getNodeValue()......."
							+ childNode.getNodeName()
							+ childNode.getNodeValue());
					if (conversionType
							.equalsIgnoreCase(KohlsPOCConstant.Encrypt)) {
						if (cryptingAttribute
								.equalsIgnoreCase(KohlsPOCConstant.ExtnTaxExemptCustName)
								&& childNode.getNodeValue().contains(
										KohlsPOCConstant.SPACE)) {
							delimitedSpace = childNode.getNodeValue().split(
									KohlsPOCConstant.SPACE);
							firstName = delimitedSpace[0];
							lastName = delimitedSpace[1];
							firstNameEncryp = securityPlatfrom
									.returnEncryptedValue(firstName, dataElement);
							lastNameEncryp = securityPlatfrom
									.returnEncryptedValue(lastName, dataElement);
							encryptedVal = firstNameEncryp.concat(
									KohlsPOCConstant.SPACE).concat(
									lastNameEncryp);

							// encryptedVal =
							// "SUCCESSEncrypt".concat(firstName).concat(lastName);
							LOG.debug("Encrypted value in searchAndReplaceInElementLevel() --->encryptedVal"
									+ encryptedVal);
							setCryptedValues(element, attributesDataMap,
									dataElement, childNode, encryptedVal);
						} else if ((element.getTagName().equalsIgnoreCase(
								KohlsPOCConstant.Reference)
								&& element.getAttribute(KohlsPOCConstant.Name)
										.contains(KohlsPOCConstant.DL) && nodeName
									.equalsIgnoreCase(KohlsPOCConstant.Value))
								|| (!cryptingAttribute
										.equalsIgnoreCase(KohlsPOCConstant.Value))) {

							encryptedVal = securityPlatfrom
									.returnEncryptedValue(childNode
											.getNodeValue(), dataElement);

							// encryptedVal = "SUCCESSEncrypt";
							LOG.debug("Encrypted value in searchAndReplaceInElementLevel() --->encryptedVal"
									+ encryptedVal);
							setCryptedValues(element, attributesDataMap,
									dataElement, childNode, encryptedVal);
						}

					} else if (conversionType
							.equalsIgnoreCase(KohlsPOCConstant.Decrypt)) {

						if (cryptingAttribute
								.equalsIgnoreCase(KohlsPOCConstant.ExtnTaxExemptCustName)
								&& childNode.getNodeValue().contains(
										KohlsPOCConstant.SPACE)) {
							delimitedSpace = childNode.getNodeValue().split(
									KohlsPOCConstant.SPACE);
							firstName = delimitedSpace[0];
							lastName = delimitedSpace[1];

							firstNameEncryp = securityPlatfrom
									.returnDecryptedValue(firstName, dataElement);
							lastNameEncryp = securityPlatfrom
									.returnDecryptedValue(lastName, dataElement);
							decryptedVal = firstNameEncryp.concat(
									KohlsPOCConstant.SPACE).concat(
									lastNameEncryp);

							// decryptedVal =
							// "SUCCESSDecrypt".concat(firstName).concat(lastName);
							LOG.debug("KohlsProcessMessageForSecurity :: searchAndReplaceInElementLevel() --->decryptedVal"
									+ decryptedVal);
							setCryptedValues(element, attributesDataMap,
									dataElement, childNode, decryptedVal);
						} else if ((element.getTagName().equalsIgnoreCase(
								"Reference")
								&& element.getAttribute(KohlsPOCConstant.Name)
										.contains(KohlsPOCConstant.DL) && nodeName
									.equalsIgnoreCase(KohlsPOCConstant.Value))
								|| (!cryptingAttribute
										.equalsIgnoreCase(KohlsPOCConstant.Value))) {

							decryptedVal = securityPlatfrom
									.returnDecryptedValue(childNode
											.getNodeValue(), dataElement);

							// decryptedVal = "SUCCESSDecrypt";
							LOG.debug("KohlsProcessMessageForSecurity :: searchAndReplaceInElementLevel() --->decryptedVal"
									+ decryptedVal);
							setCryptedValues(element, attributesDataMap,
									dataElement, childNode, decryptedVal);
						}

					}
					// }
					LOG.debug("KohlsProcessMessageForSecurity :: searchAndReplaceInElementLevel() --->NodeValue"
							+ attributesDataMap.get(childNode.getNodeName()
									+ childNode.getNodeValue()));
				}
			}

		}

		LOG.endTimer("KohlsPoCSecurityUtil.searchAndReplaceInElementLevel");
	}

	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void setCryptedValues(Element element,
			Map<String, String> attributesDataMap, String dataElement,
			Node childNode, String encryptedVal) throws DOMException {
		LOG.beginTimer("KohlsPoCSecurityUtil.setCryptedValues");

		attributesDataMap.put(
				childNode.getNodeName() + childNode.getNodeValue(),
				encryptedVal);
		childNode.setNodeValue(attributesDataMap.get(childNode.getNodeName()
				+ childNode.getNodeValue()));
		element.setAttribute(
				childNode.getNodeName().concat(KohlsPOCConstant.DataElement),
				dataElement);
		LOG.endTimer("KohlsPoCSecurityUtil.setCryptedValues");
	}

	/**
	 * @param prop
	 *            prop
	 * @throws Exception
	 *             This function is used to set properties reference.
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		// LOG_CAT.debug("In the set properties method");

	}

	/**
	 * This function is used to get the value for a property.
	 * 
	 * @param property
	 *            property
	 * @return String propValue
	 */
	public String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		return propValue;

	}
	
	/**
	 * Create By mrjoshi * 
	 * @param env
	 * @param action: Secure, Desecure
	 * @param stringToBeToken
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> encryptDecryptUsingProtegrity (YFSEnvironment env, String sCallingOrgCode, String action, String stringToBeToken, String type) {
	  LOG.beginTimer("KohlsPoCSecurityUtil.encryptDecryptUsingProtegrity");
	  HashMap <String, String> resultSet = new HashMap <String, String> ();
	  if(YFCCommon.isVoid(action)) {
	    throw new YFSException("missing attribute: action");
	  }
	  if(YFCCommon.isVoid(stringToBeToken)) {
        throw new YFSException("missing attribute: stringToBeToken");
      }
	  if(YFCCommon.isVoid(type)) {
        throw new YFSException("missing attribute: type");
      }
	  
	  if(YFCCommon.isVoid(sCallingOrgCode)) {
	    sCallingOrgCode = "KOHLS-RETAIL";
	  }
	  try {
    	  Document docInXML = XMLUtil.getDocument("<InvokeUE EnterpriseCode='KOHLS-RETAIL' DocumentType='0001' UserExit='com.tgcs.tcx.gravity.nrsc.pos.japi.ue.security.POSSecureDataUE'><XMLData><SecureData CallingOrganizationCode='"+sCallingOrgCode+"' Action='"+action+"' Type='"+type+"'><Data Value='"+stringToBeToken+"'/></SecureData></XMLData></InvokeUE>");
    	  
    	  Document docOut = KOHLSBaseApi.invokeAPI(env, "invokeUE", docInXML);
    	  
    	  if(!YFCCommon.isVoid(docOut)) {
    	    NodeList nlData = docOut.getElementsByTagName("Data");
    	    for (int i=0; i<nlData.getLength(); i++) {
    	      Element eleData = (Element) nlData.item(i);
    	      resultSet.put("Status", eleData.getAttribute("Status"));
    	      resultSet.put("Value", eleData.getAttribute("Value"));
    	      if(!YFCCommon.isVoid(eleData.getAttribute("ErrorMessage"))) {
    	        resultSet.put("ErrorMessage", eleData.getAttribute("ErrorMessage"));
    	      }
    	    }
    	 }
	  }catch (Exception e) {
	    LOG.error("Error while doing +"+action+" operation");
	  } finally {
	    LOG.endTimer("KohlsPoCSecurityUtil.encryptDecryptUsingProtegrity");
	  }
      return resultSet;
	}
}
