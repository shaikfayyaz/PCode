package com.kohls.poc.util;

/**
 * This class contains the utility methods required for the
 * 
 * @(#) 
 */

import java.rmi.RemoteException;

import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.yantra.interop.services.jms.MessageUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;


/**
 * @author ibmadmin
 *
 */
public final class KohlsPoCXMLSizeLogger {

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCXMLSizeLogger.class.getName());
	
	
	/**
	 * Create By ibmadmin * 
	 * @param env
	 * @param inXML
	 * @return
	 * @throws YFSException
	 * @throws RemoteException
	 * @throws YFSUserExitException
	 */
	public Document logXMLSize(YFSEnvironment env, Document inXML) throws YFSException, RemoteException, YFSUserExitException{
	    logger.beginTimer("KohlsPoCXMLSizeLogger.logXMLSize");
		if (MessageUtil.isJMSDebuggerEnabled()) {
			MessageUtil.logJMSDebugMessage(logger, "Byte Size of xml data is : " + XMLUtil.getXMLString(inXML).getBytes().length);
		}
		logger.endTimer("KohlsPoCXMLSizeLogger.logXMLSize");
		return inXML;
	}
}
