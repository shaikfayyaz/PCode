package com.kohls.poc.util;

import org.w3c.dom.Document;

import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPOCConvertTimeToStoreLocaleTime extends KOHLSBaseApi{

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPOCConvertTimeToStoreLocaleTime.class.getName());

	/**This method converts the OpenRegister time as per the Pick Up store timezone. This logic will only get triggered during invoice publish of PICK lines of OMNI2 orders.
	 * 
	 * @param env
	 * @param inDoc
	 * @return
	 */
	public Document convertToStoreLocaleTime(YFSEnvironment env, Document inDoc) {
		Object pickStoreRegisterOpen = env.getTxnObject("PickStoreRegisterOpen");
		if(!YFCCommon.isVoid(pickStoreRegisterOpen) && KohlsPOCConstant.YES.equalsIgnoreCase(pickStoreRegisterOpen.toString())) {
			try {
				String orgCode = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
				if(logger.isDebugEnabled()) {
					logger.debug("Document before store locale time conversion: "+XMLUtil.getXMLString(inDoc));
					logger.debug("pickStoreRegisterOpen: "+pickStoreRegisterOpen.toString()+" orgCode: "+orgCode);
				}
				if(!YFCCommon.isVoid(orgCode)) {
					inDoc.getDocumentElement().setAttribute("OrgCode",orgCode);
					inDoc = invokeService(env,KohlsPOCConstant.OPEN_REGISTER_TIME_CONV_SERVICE, inDoc);
					if(logger.isDebugEnabled()) {
						logger.debug("Document after store locale time conversion: "+XMLUtil.getXMLString(inDoc));
					}
				}
			} catch (Exception ex) {
				logger.error("Exception occurred while store locale time conversion: "+ex.getMessage());
			}
		}
		return inDoc;
	}
}
