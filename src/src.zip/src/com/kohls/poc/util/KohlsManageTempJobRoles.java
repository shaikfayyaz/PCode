package com.kohls.poc.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsManageTempJobRoles {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsManageTempJobRoles.class.getName());
	public static final String FROM_DATE_START_STRING = "BETWEEN to_date('";
	public static final String TO_DATE_START_STRING = "AND to_date('";
	public static final String END_STRING = "','MM-DD-YYYY HH24:MI:SS')";
	public static final String BETWEEN = "BETWEEN";
	public static final String API_MANAGE_TEMP_JOB_ROLES_FOR_USERS = "manageTemporaryJobRolesForUsers";
	public static final String FROM_MODIFYTS = "FromModifyts";
	public static final String TO_MODIFYTS = "ToModifyts";
	public static final String MODIFYTS_QRY_TYPE = "ModifytsQryType";
	public static final String LOCALECODE = "yfs.install.localecode";
	public static final String LOCALE_CODE_EST = "en_US_EST";
	public static final String LOCALE_CODE_MST = "en_US_MST";
	public static final String FROM = "FROM";
	public static final String TO = "TO";
	
	/**
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws Exception
	 */
	public Document manageTempJobRoles(YFSEnvironment env, Document inDoc) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("Beginning manageTempJobRoles with inDoc " + SCXmlUtil.getString(inDoc));
		}
		String strQueryParFileContent = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_VALUE);
		StringBuffer sb = new StringBuffer(strQueryParFileContent);
		String srtFromTS = sb.substring(strQueryParFileContent.indexOf(FROM_DATE_START_STRING) + 17,
				strQueryParFileContent.indexOf(FROM_DATE_START_STRING) + 36);

		String srtToTS = sb.substring(strQueryParFileContent.indexOf(TO_DATE_START_STRING) + 13,
				strQueryParFileContent.indexOf(TO_DATE_START_STRING) + 32);
		String strOrgCode = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.STORE_ID);

		log.info("Before converstion timestamp for storeID " + strOrgCode + " from " + srtFromTS + " to " + srtToTS);
		// Convert the times in local time
		String strStartLocalTime = convertToLocaleTimeZone(env, srtFromTS, FROM);
		String strEndLocalTime = convertToLocaleTimeZone(env, srtToTS, TO);
		log.info("Converted timestamp from " + strStartLocalTime + " to " + strEndLocalTime);

		// call getOfflineTransactionQListForPOS api with complex query
		Document outDocForGetOfflineTrxQList = invokeGetOfflineTranQListPOS(env, strStartLocalTime, strEndLocalTime);

		ArrayList<Element> offlineTrxQList = SCXmlUtil.getChildren(outDocForGetOfflineTrxQList.getDocumentElement(),
				KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
		for (Element eleOfflineTrxQ : offlineTrxQList) {
			String strOperationInputXML = eleOfflineTrxQ.getAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML);
			if (log.isDebugEnabled()) {
				log.debug("strOperationInputXML is " + strOperationInputXML);
			}
			String strOpXML = strOperationInputXML.replaceAll("&lt;", "<").replaceAll("&quot;/", "\"");
			Document docDeleteTempJobRolesInput = SCXmlUtil.createFromString(strOpXML);
			if (log.isDebugEnabled()) {
				log.debug(
						"Transformed strOperationInputXML document " + SCXmlUtil.getString(docDeleteTempJobRolesInput));
			}
			if (!docDeleteTempJobRolesInput.getDocumentElement().getAttribute(KohlsPOCConstant.A_ACTION)
					.equalsIgnoreCase(KohlsPOCConstant.V_DELETE)) {
				checkLoginIDAndDeleteTempRole(env, docDeleteTempJobRolesInput);
			}
		}
		return outDocForGetOfflineTrxQList;
	}

	/**
	 * @param env
	 * @param timeStamp
	 * @param strTimestampType
	 * @return
	 * @throws Exception
	 */
	public String convertToLocaleTimeZone(YFSEnvironment env, String timeStamp, String strTimestampType)
			throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		if (log.isDebugEnabled()) {
			log.debug("Timestamp before conversion to locale " + timeStamp);
		}
		Date dateBeforeFormat = sdf.parse(timeStamp);

		Calendar cal = Calendar.getInstance();
		cal.setTime(dateBeforeFormat);
		String strLocaleCode = YFSSystem.getProperty(LOCALECODE);

		if (strLocaleCode.equalsIgnoreCase(LOCALE_CODE_EST)) {
			cal.add(Calendar.HOUR, 1);
		} else if (strLocaleCode.equalsIgnoreCase(KohlsPOCConstant.LOCALE_CODE_CST)) {
			cal.add(Calendar.HOUR, 0);
		} else if (strLocaleCode.equalsIgnoreCase(LOCALE_CODE_MST)) {
			cal.add(Calendar.HOUR, -1);
		} else if (strLocaleCode.equalsIgnoreCase(KohlsPOCConstant.LOCALE_CODE_PST)) {
			cal.add(Calendar.HOUR, -2);
		} else {
			if (strTimestampType.equals(FROM)) {
				cal.add(Calendar.HOUR, -2);
			} else if (strTimestampType.equals(TO)) {
				cal.add(Calendar.HOUR, 1);
			}
		}

		Date dataAfter = cal.getTime();
		SimpleDateFormat sdf5 = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_UPDATE_DATE_FORMAT);
		String strDateAfter = sdf5.format(dataAfter);
		log.info("strDateAfter after conversion " + strDateAfter);
		return strDateAfter;
	}

	/**
	 * @param env
	 * @param localStartTime
	 * @param localEndTime
	 * @return
	 * @throws Exception
	 */
	private Document invokeGetOfflineTranQListPOS(YFSEnvironment env, String localStartTime, String localEndTime)
			throws Exception {
		Document docOut = null;
		log.info("Getting the offline trxq list started");
		try {
			Document docOfflineTranQListIp = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			Element eleOfflineTranQ = docOfflineTranQListIp.getDocumentElement();
			eleOfflineTranQ.setAttribute(KohlsPOCConstant.NEED_OPERTION_XML, KohlsPOCConstant.YES);
			eleOfflineTranQ.setAttribute(FROM_MODIFYTS, localStartTime);
			eleOfflineTranQ.setAttribute(TO_MODIFYTS, localEndTime);
			eleOfflineTranQ.setAttribute(MODIFYTS_QRY_TYPE, BETWEEN);
			eleOfflineTranQ.setAttribute(KohlsPOCConstant.A_OPERATION_ID, API_MANAGE_TEMP_JOB_ROLES_FOR_USERS);
			Element eleOrderBy = SCXmlUtil.createChild(eleOfflineTranQ, KohlsPOCConstant.E_ORDER_BY);
			Element eleAttrib = SCXmlUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
			eleAttrib.setAttribute(KohlsPOCConstant.A_DESC, KohlsPOCConstant.NO);
			eleAttrib.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.OFFLINE_TRXQ_KEY);
			if (log.isDebugEnabled()) {
				log.debug("Input to offline trxq list API \n" + SCXmlUtil.getString(docOfflineTranQListIp));
			}
			docOut = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS,
					docOfflineTranQListIp);
			if (log.isDebugEnabled()) {
				log.debug("Output from offline trx q list API \n" + SCXmlUtil.getString(docOut));
			}
		} catch (Exception e) {
			log.error("Exception occured in invokeGetOfflineTranQListPOS method " + e.getMessage());
			throw e;
		}
		return docOut;
	}
	
	/**
	 * @param env
	 * @param inDoc
	 * @throws Exception
	 */
	private void checkLoginIDAndDeleteTempRole(YFSEnvironment env, Document inDoc) throws Exception {
		StringBuffer bfrElm = new StringBuffer();
		XPath xpath = XPathFactory.newInstance().newXPath();
		XPathExpression expr = xpath.compile("/*");
		Object result = expr.evaluate(inDoc, XPathConstants.NODESET);
		NodeList nodes = (NodeList) result;
		NamedNodeMap attributes = nodes.item(0).getAttributes();
		bfrElm.append("<TempJobRole ");
		for (int i = 0, len = attributes.getLength(); i < len; i++) {
			Attr attr = (Attr) attributes.item(i);
			log.info("Attribute and value " + attr.getName() + "=" + attr.getValue());
			bfrElm.append(attr.getName() + "='" + attr.getValue() + "' ");
		}
		bfrElm.append(">");
		if (log.isDebugEnabled()) {
			log.info("Root element and its attributes " + bfrElm.toString());
		}
		NodeList nod = inDoc.getElementsByTagName(KohlsPOCConstant.ELEM_USER);
		for (int i = 0; i < nod.getLength(); i++) {
			Element elm = ((Element) nod.item(i));
			String loginID = elm.getAttribute("LoginId");
			log.info("LoginId retrieved is " + loginID);
			Document userListInput = SCXmlUtil
					.createFromString("<User Loginid='" + loginID + "' MaximumRecords='5000'/>");
			Document userListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_USER_LIST, userListInput);
			if (log.isDebugEnabled()) {
				log.debug("getUserList output " + SCXmlUtil.getString(userListOutput));
			}
			if (userListOutput.getDocumentElement().hasChildNodes()) {
				Element userListElm = KohlsXPathUtil.getElementByXpath(userListOutput, "/UserList/User");
				if (!YFCCommon.isVoid(userListElm.getAttribute(KohlsPOCConstant.ATTR_LOGIN_ID))) {
					String fl = bfrElm.toString() + "<UserList> <User LoginId='" + loginID
							+ "'/> </UserList> </TempJobRole>";
					if (log.isDebugEnabled()) {
						log.debug("Input to manageTemporaryJobRolesForUsers before converting \n" + fl);
					}

					Document tmpRoleInput = SCXmlUtil.createFromString(fl);
					tmpRoleInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.DELETE);
					log.info("Input to manageTemporaryJobRolesForUsers \n" + SCXmlUtil.getString(tmpRoleInput));

					Document tmpRoleOutput = KohlsCommonUtil.invokeAPI(env, API_MANAGE_TEMP_JOB_ROLES_FOR_USERS,
							tmpRoleInput);
					log.info("Output from manageTemporaryJobRolesForUsers \n" + SCXmlUtil.getString(tmpRoleOutput));
				} else {
					log.warn("Loginid doesn't exits in the getUserList output");
				}
			} else {
				log.warn(loginID + " Loginid doesn't exits in the database");
			}
		}
	}
	
}
