package com.kohls.poc.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsGetReturnPassDetailsOutJson;
import com.kohls.poc.rest.KohlsGetReturnRestrictionOutJson;
import com.kohls.poc.rest.KohlsUpdateReturnPassInputJson;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

public class KohlsPoCRPUtil {

	private static YFCLogCategory logger;
	static final String RESTRICTED_RETURN_POLICY_DATE ="restrictedReturnPolicyDate";
	static final String RESTRICTED_RETURN_POLICY_DAYS ="restrictedReturnPolicyDays";

	static {
		logger = YFCLogCategory.instance(KohlsPoCRPUtil.class.getName());
	}

	public String processGetReturnPassDetailsJSonInput(Element eleInDoc) {
		logger.beginTimer("KohlsPoCRPUtil.processGetReturnPassDetailsOutput");
		logger.beginTimer("KohlsPoCRPUtil.processGetReturnPassDetailsOutput");
		return null;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String processUpdateReturnPassJSonInput(Element eleInDoc, String source) throws Exception {
		logger.beginTimer("KohlsPoCRPUtil.processUpdateReturnPassJSonInput");
		if(logger.isDebugEnabled()){
			logger.debug("Input to processUpdateReturnPassJSonInput is : " +XMLUtil.getElementXMLString(eleInDoc));
		}
		String action = "";
		Gson gson = new Gson();
		KohlsUpdateReturnPassInputJson inputJSON = new KohlsUpdateReturnPassInputJson();
		Map<String, List<Element>> mapReturnPassPassCodeDetails = new HashMap<String, List<Element>>();
		try {
			if(isReturnPassAvailable(eleInDoc)){
				if(!YFCCommon.isVoid(source) && KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source)){
					action = KohlsPOCConstant.ATTR_RETURN;
				}else if(!YFCCommon.isVoid(source) && KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)){
					action = KohlsPOCConstant.VOID;
				}
				NodeList nlOrderLine = eleInDoc.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
				if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > KohlsPOCConstant.ZERO_INT) {
					for (int ol = 0; ol < nlOrderLine.getLength(); ol++) {
						Element eleOrderLine = (Element) nlOrderLine.item(ol);
						String strOrderedQty = XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);
						if(!YFCCommon.isVoid(strOrderedQty) && ((KohlsPOCConstant.ATTR_RETURN.equalsIgnoreCase(action) && Double.valueOf(strOrderedQty)>0) ||
								KohlsPOCConstant.VOID.equalsIgnoreCase(action) && Double.valueOf(strOrderedQty)==0)){
							Element eleCustomerAttributes = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
							String strText3	= XMLUtil.getAttribute(eleCustomerAttributes, KohlsPOCConstant.TEXT3);
							if(!YFCCommon.isVoid(strText3)){
								if (mapReturnPassPassCodeDetails.containsKey(strText3)) {
									mapReturnPassPassCodeDetails.get(strText3).add(eleOrderLine);
								} else {
									List<Element> listReturnPassEligibleOrderLine = new ArrayList<Element>();
									listReturnPassEligibleOrderLine.add(eleOrderLine);
									mapReturnPassPassCodeDetails.put(strText3, listReturnPassEligibleOrderLine);
								}
							}
						}
					}
				}

				if(!YFCCommon.isVoid(mapReturnPassPassCodeDetails) && !mapReturnPassPassCodeDetails.isEmpty() && mapReturnPassPassCodeDetails.size()>0){
					inputJSON.setAction(action);
					String locationNumber = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
					String deviceId = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.A_TERMINAL_ID);
					String transactionNumber = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.A_POS_SEQUENCE_NO);
					String transactionTimestamp = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.A_ORDER_DATE);

					KohlsUpdateReturnPassInputJson.ReturnTransactionKey returnTransactionKey = inputJSON.new ReturnTransactionKey();
					if(!YFCCommon.isVoid(locationNumber) && !YFCCommon.isVoid(deviceId) && 
							!YFCCommon.isVoid(transactionNumber) && !YFCCommon.isVoid(transactionTimestamp)){
						returnTransactionKey.setLocationNumber(Integer.valueOf(locationNumber).toString());
						returnTransactionKey.setDeviceId(Integer.valueOf(deviceId).toString());
						returnTransactionKey.setTransactionNumber(Integer.valueOf(transactionNumber).toString());
						SimpleDateFormat currentFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
						SimpleDateFormat toFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
						returnTransactionKey.setTransactionTimestamp(toFormat.format(currentFormat.parse(transactionTimestamp)).toString());
					}
					inputJSON.setReturnTransactionKey(returnTransactionKey);

					List<KohlsUpdateReturnPassInputJson.PasscodeDetails> passCodeDetails = new ArrayList<KohlsUpdateReturnPassInputJson.PasscodeDetails>();
					Iterator itPassCodeDetailsMap = mapReturnPassPassCodeDetails.entrySet().iterator();
					while (itPassCodeDetailsMap.hasNext()) {
						Map.Entry passCodeDetailsMapPair = (Map.Entry) itPassCodeDetailsMap.next();
						String mapPassCode = (String) passCodeDetailsMapPair.getKey();
						List<Element> lsEligibleReturnPassOrderLine = (List<Element>) passCodeDetailsMapPair.getValue();

						KohlsUpdateReturnPassInputJson.PasscodeDetails passCodeDetail = inputJSON.new PasscodeDetails();
						passCodeDetail.setReturnPassCode(mapPassCode);

						List<KohlsUpdateReturnPassInputJson.Item> items = new ArrayList<KohlsUpdateReturnPassInputJson.Item>();
						if(!YFCCommon.isVoid(lsEligibleReturnPassOrderLine) && lsEligibleReturnPassOrderLine.size()>0){
							for (Element eleEligibleReturnPassOrderLine : lsEligibleReturnPassOrderLine) {
								KohlsUpdateReturnPassInputJson.Item item = inputJSON.new Item();
								Element eleItem = XMLUtil.getChildElement(eleEligibleReturnPassOrderLine, KohlsPOCConstant.E_ITEM);
								Element eleCustomAttributes = XMLUtil.getChildElement(eleEligibleReturnPassOrderLine, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
								String skuNumber = XMLUtil.getAttribute(eleItem, KohlsPOCConstant.A_ITEM_ID);
								String lineSequenceNumber = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.TEXT10);
								String upc = XMLUtil.getAttribute(eleItem, KohlsPOCConstant.A_UPC_CODE);
								item.setSkuNumber(skuNumber);
								item.setLineSequenceNumber(lineSequenceNumber);
								//item.setUpc(upc);

								String itemLocationNumber = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.TEXT7);
								String itemDeviceId = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.TEXT8);
								String itemTransactionNumber = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.TEXT9);
								String itemTransactionTimestamp = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.DATE2);

								KohlsUpdateReturnPassInputJson.TransactionKey transactionKey = inputJSON.new TransactionKey();
								if(!YFCCommon.isVoid(itemLocationNumber) && !YFCCommon.isVoid(itemDeviceId) && 
										!YFCCommon.isVoid(itemTransactionNumber) && !YFCCommon.isVoid(itemTransactionTimestamp)){
									transactionKey.setLocationNumber(Integer.valueOf(itemLocationNumber).toString());
									transactionKey.setDeviceId(Integer.valueOf(itemDeviceId).toString());
									transactionKey.setTransactionNumber(Integer.valueOf(itemTransactionNumber).toString());
									SimpleDateFormat currentFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
									SimpleDateFormat toFormat = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
									transactionKey.setTransactionTimestamp(toFormat.format(currentFormat.parse(itemTransactionTimestamp)).toString());
								}

								item.setTransactionKey(transactionKey);
								items.add(item);
							}
						}
						passCodeDetail.setItems(items);
						passCodeDetails.add(passCodeDetail);
					}
					inputJSON.setPasscodeDetails(passCodeDetails);
				}
			}
		} catch (Exception e) {
			logger.error("KohlsPoCRPUtil.processUpdateReturnPassJSonInput - Error while creating JSon input for ReturnPass Item status update API");
			e.printStackTrace();
			throw e;
		}
		logger.beginTimer("KohlsPoCRPUtil.processUpdateReturnPassJSonInput");
		return gson.toJson(inputJSON).toString();
	}
	public String processPostVoidReturnPassJSonInput(Element eleInDoc) {
		logger.beginTimer("KohlsPoCRPUtil.processPostVoidReturnPassOutput");
		logger.beginTimer("KohlsPoCRPUtil.processPostVoidReturnPassOutput");
		return null;
	}

	/**
//Sample Output
<Order ReceiptPreferenceEMailID="null" ReceiptPreferenceMethod="E_ONLY" createdDate="2019-01-03 12:29:44" orderNumber="11963928" refundMethod="DEFAULT" 
returnPassCode="RO06f1983ba7b0e036ad7728b6fa316cba437007" status="CREATED" transactionKey="null" updatedDate="2019-01-03 12:29:44" zipCode="9152">
<customerInfo emailID="abc10@gmail.com" loyaltyID="83431259502" profileID="3003100000707671"/>
<items>
	<item color="Gray Black" imageURL="https://media.kohlsimg.com/is/image/kohls/2991515_ALT?wid=50&hei=50&op_sharpen=1" lineSequenceNumber="2" 
	productID="2991515" reasonCode="1" reasonDesc="Damaged" size="10" skuNumber="90555227" title="Nike Revolution 4 Men's Running Shoes" upc="11223344">
		<transactionKey deviceId="63" locationNumber="9951" transactionNumber="526" transactionTimestamp="2018-06-20 08:04:34"/>
	</item>
	<item color="Gray Black" imageURL="https://media.kohlsimg.com/is/image/kohls/2991515_ALT?wid=50&hei=50&op_sharpen=1" lineSequenceNumber="3" 
	productID="2991515" reasonCode="1" reasonDesc="Damaged" size="10" skuNumber="90555226" title="Nike Revolution 4 Men's Running Shoes" upc="11223345">
		<transactionKey deviceId="63" locationNumber="9951" transactionNumber="526" transactionTimestamp="2018-06-20 08:04:34"/>
	</item>
</items>
</Order>
	 * @param outputJSon
	 * @return Document
	 */
	public Document processGetReturnPassDetailsOutput(String outputJSon) {
		logger.beginTimer("KohlsPoCRPUtil.processGetReturnPassDetailsOutput");

		Gson outGson = new Gson();
		Document docOrder = null;
		try {
			KohlsGetReturnPassDetailsOutJson parsedClass = outGson.fromJson(outputJSon, KohlsGetReturnPassDetailsOutJson.class);
			docOrder = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
			Element eleOrder = docOrder.getDocumentElement();
			if(!YFCCommon.isVoid(parsedClass)){
				eleOrder.setAttribute(KohlsPOCConstant.CREATED_DATE, parsedClass.getCreatedDate());
				eleOrder.setAttribute(KohlsPOCConstant.REFUND_METHOD, parsedClass.getRefundMethod());
				eleOrder.setAttribute(KohlsPOCConstant.RETURN_PASS_CODE, parsedClass.getReturnPassCode());
				eleOrder.setAttribute(KohlsPOCConstant.STATUS_LC, parsedClass.getStatus());
				eleOrder.setAttribute(KohlsPOCConstant.UPDATED_DATE, parsedClass.getUpdatedDate());
				eleOrder.setAttribute(KohlsPOCConstant.RECEIPT_ID, parsedClass.getReceiptId());
				if(!YFCCommon.isVoid(parsedClass.getOrderDetails())){
					eleOrder.setAttribute(KohlsPOCConstant.ORDER_NUMBER, parsedClass.getOrderDetails().getOrderNumber());
					eleOrder.setAttribute(KohlsPOCConstant.ZIP_CODE, parsedClass.getOrderDetails().getZipCode());
				}
				if(!YFCCommon.isVoid(parsedClass.getReceiptPreference())){
					eleOrder.setAttribute(KohlsPOCConstant.RECEIPT_PREFERENCE_METHOD, parsedClass.getReceiptPreference().getMethod());
					if(!YFCCommon.isVoid(parsedClass.getReceiptPreference().getEmailId())){
						eleOrder.setAttribute(KohlsPOCConstant.RECEIPT_PREFERENCE_EMAIL_ID, String.valueOf(parsedClass.getReceiptPreference().getEmailId()));
					}
				}
				if(!YFCCommon.isVoid(parsedClass.getCustomerInfo())){
					Element eleCustomerInfo = XMLUtil.createChild(eleOrder, KohlsPOCConstant.CUSTOMER_INFO);
					eleCustomerInfo.setAttribute(KohlsPOCConstant.EMAIL_ID, parsedClass.getCustomerInfo().getEmailID());
					eleCustomerInfo.setAttribute(KohlsPOCConstant.LOYALTY_ID, parsedClass.getCustomerInfo().getLoyaltyID());
					eleCustomerInfo.setAttribute(KohlsPOCConstant.PROFILE_ID, parsedClass.getCustomerInfo().getProfileID());
				}
				if(!YFCCommon.isVoid(parsedClass.getStoreDetails())){
					Element eleStoreDetails = XMLUtil.createChild(eleOrder, KohlsPOCConstant.STORE_DETAILS);
					eleStoreDetails.setAttribute(KohlsPOCConstant.STORE_ID_LC, parsedClass.getStoreDetails().getStoreId());
					eleStoreDetails.setAttribute(KohlsPOCConstant.NAME, parsedClass.getStoreDetails().getName());
					eleStoreDetails.setAttribute(KohlsPOCConstant.ADDR_ONE, parsedClass.getStoreDetails().getAddr1());
					eleStoreDetails.setAttribute(KohlsPOCConstant.ADDR_TWO, parsedClass.getStoreDetails().getAddr2());
					eleStoreDetails.setAttribute(KohlsPOCConstant.CITY, parsedClass.getStoreDetails().getCity());
					eleStoreDetails.setAttribute(KohlsPOCConstant.STATE, parsedClass.getStoreDetails().getState());
					eleStoreDetails.setAttribute(KohlsPOCConstant.ZIP_CODE, parsedClass.getStoreDetails().getZipCode());
					eleStoreDetails.setAttribute(KohlsPOCConstant.PHONE_NUMBER, parsedClass.getStoreDetails().getPhoneNumber());
				}

				Element eleItems = XMLUtil.createChild(eleOrder, KohlsPOCConstant.S_ITEMS);
				if(!YFCCommon.isVoid(parsedClass.getItems())){
					for (KohlsGetReturnPassDetailsOutJson.Item itemList : parsedClass.getItems()) {
						if(!YFCCommon.isVoid(parsedClass.getItems().size()>0)){
							Element eleItem = XMLUtil.createChild(eleItems, KohlsPOCConstant.S_ITEM);
							eleItem.setAttribute(KohlsPOCConstant.COLOR, itemList.getColor());
							eleItem.setAttribute(KohlsPOCConstant.IMAGE_URL, itemList.getImageURL());
							eleItem.setAttribute(KohlsPOCConstant.LINE_SEQUENCE_NUMBER, itemList.getLineSequenceNumber());
							eleItem.setAttribute(KohlsPOCConstant.PRODUCT_ID, itemList.getProductID());
							eleItem.setAttribute(KohlsPOCConstant.REASON_CODE, itemList.getReasonCode());
							eleItem.setAttribute(KohlsPOCConstant.REASON_DESC, itemList.getReasonDesc());
							eleItem.setAttribute(KohlsPOCConstant.SIZE, itemList.getSize());
							eleItem.setAttribute(KohlsPOCConstant.SKU_NUMBER, itemList.getSkuNumber());
							eleItem.setAttribute(KohlsPOCConstant.UPC, itemList.getUpc());
							eleItem.setAttribute(KohlsPOCConstant.STATUS_LC, itemList.getStatus());
							if(!YFCCommon.isVoid(itemList.getTitle())){
								String sItemTitle = itemList.getTitle();
								if(sItemTitle.contains(KohlsPOCConstant.A_SINGLE_QUOTE)){
									sItemTitle = sItemTitle.replaceAll(KohlsPOCConstant.A_SINGLE_QUOTE, KohlsPOCConstant.BLANK);
								}
								eleItem.setAttribute(KohlsPOCConstant.TITLE, sItemTitle);
							}
							Element eleTransactionKey = XMLUtil.createChild(eleItem, KohlsPOCConstant.TRANSACTION_KEY);
							eleTransactionKey.setAttribute(KohlsPOCConstant.DEVICE_ID, itemList.getTransactionKey().getDeviceId());
							eleTransactionKey.setAttribute(KohlsPOCConstant.LOCATION_NUMBER, itemList.getTransactionKey().getLocationNumber());
							eleTransactionKey.setAttribute(KohlsPOCConstant.TRANSACTION_NUMBER, itemList.getTransactionKey().getTransactionNumber());
							eleTransactionKey.setAttribute(KohlsPOCConstant.TRANSACTION_TIME_STAMP, itemList.getTransactionKey().getTransactionTimestamp());
						}
					}
				}
				if(logger.isDebugEnabled()){
					logger.debug("The GetOrderDetails output XML parsed from JSon : " +XMLUtil.getXMLString(docOrder));
				}
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		logger.beginTimer("KohlsPoCRPUtil.processGetReturnPassDetailsOutput");
		return docOrder;
	}
	public Document processCompleteReturnPassOutput(String string) {
		logger.beginTimer("KohlsPoCRPUtil.processCompleteReturnPassOutput");
		logger.beginTimer("KohlsPoCRPUtil.processCompleteReturnPassOutput");
		return null;
	}
	public Document processPostVoidReturnPassOutput(String string) {
		logger.beginTimer("KohlsPoCRPUtil.processPostVoidReturnPassOutput");
		logger.beginTimer("KohlsPoCRPUtil.processPostVoidReturnPassOutput");
		return null;
	}
	public boolean isReturnPassAvailable(Element eleInDoc) {
		logger.beginTimer("KohlsPoCRPUtil.isReturnPassAvailable");
		if(!YFCCommon.isVoid(eleInDoc)){
			Element eleReferences = XMLUtil.getChildElement(eleInDoc, KohlsPOCConstant.A_REFERENCES);
			NodeList nlOrderReference = eleReferences.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
			if (!YFCCommon.isVoid(nlOrderReference) && nlOrderReference.getLength() > KohlsPOCConstant.ZERO_INT) {
				for (int or = 0; or < nlOrderReference.getLength(); or++) {
					Element eleReference = (Element) nlOrderReference.item(or);
					if (!YFCCommon.isVoid(eleReference) && (eleReference.getAttribute(KohlsXMLLiterals.A_NAME).startsWith(KohlsPOCConstant.OTR_Q))) {
						return true;
					}
				}
			}
		}
		logger.beginTimer("KohlsPoCRPUtil.isReturnPassAvailable");
		return false;
	}
	
	public Document processReturnRestrictionOutput(String outputJSon) {
		
		logger.beginTimer("KohlsPoCRPUtil.processReturnRestrictionOutput");

		Gson outGson = new Gson();
		Document docOrder = null;
		try {
			
		KohlsGetReturnRestrictionOutJson parsedClass = outGson.fromJson(outputJSon, KohlsGetReturnRestrictionOutJson.class);
			docOrder = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
			Element eleOrder = docOrder.getDocumentElement();
			if(!YFCCommon.isVoid(parsedClass)){
				
				eleOrder.setAttribute(RESTRICTED_RETURN_POLICY_DATE, parsedClass.getReturnPolicyDate());
				eleOrder.setAttribute(RESTRICTED_RETURN_POLICY_DAYS, parsedClass.getReturnPolicyDays());
				
				if(logger.isDebugEnabled()){
					logger.debug("The processReturnRestrictionOutput output XML parsed from JSon : " +XMLUtil.getXMLString(docOrder));
				}
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		logger.beginTimer("KohlsPoCRPUtil.processReturnRestrictionOutput");
		return docOrder;
	}
}
