package com.kohls.poc.util;

import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.Properties;

public class KohlsMPoCSecurityUtil {
    /** LOG variable for logging. */
    private static final YFCLogCategory LOG = YFCLogCategory
            .instance(KohlsMPoCSecurityUtil.class.getName());
    /**
     * securityPlatfrom reference for invoke Protegrity Server.
     */
    private KohlsPoCInvokeDataSecurityPlatform securityPlatfrom = new KohlsPoCInvokeDataSecurityPlatform();
    /**
     * properties reference to read configured arguments.
     */
    private Properties props = null;
    /**
     * sHostXC to save host details.
     */
    private String sHostXC = null;
    /**
     * dataElement to save dataElement value.
     */
    private String dataElement = null;
    /**
     * policyUser is to save userName.
     */
    private String policyUser = null;

    /**
     * This method will read sHostXC,dataElement and
     * policyUser from customer override properties file. This
     * method will read PROTEGRITY_TYPE from configuration
     * arguments. replace the encrypted mPOC XML with decrypted XML based on protegrityType
     * @param env
     * @param inXml
     * @return
     * @throws Exception
     */
    public Document decryptXML(YFSEnvironment env, Document inXml) throws Exception {

        /* Initialize the variables*/
        String argName = null;
        String argValuePart1 = null;
        String argValuePart2 = null;
        String argValue = null;
        String[] delimitedSlash = null;
        String xPath = null;


        LOG.beginTimer("KohlsMPoCSecurityUtil.decryptXML");
        if(LOG.isDebugEnabled())
            LOG.debug("Input XML to KohlsMPoCSecurityUtil.decryptXML is: "
                + XMLUtil.getXMLString(inXml));

        /*Retrieve the number of elements that need to be ecrypted or decrypted */
        int noOfXpaths = Integer.valueOf(this.props
                .getProperty("NoOfXpaths"));

        sHostXC = this
                .getPropertyValue(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
        policyUser = this.getPropertyValue(KohlsPOCConstant.POLICY_USER);

        if(LOG.isDebugEnabled()) {
            LOG.debug("The PROTEGRITY_SERVER_HOST is : " + sHostXC);
            LOG.debug("The POLICY_USER is : " + policyUser);
            LOG.debug("The noOfXpaths value is : " + noOfXpaths);
        }

        for(int i=0; i<noOfXpaths; i++) {
            argName = "Xpath" + (i + 1);
            LOG.debug("The xpath No is : " + argName);
            argValuePart1 = this.props.getProperty(argName + "_1");
            argValuePart2 = this.props.getProperty(argName + "_2");
            if (argValuePart2 == null) {
                argValuePart2 = " ";
            }
            // LOG.debug("The attribute value is : " + attributePart1);
            argValue = argValuePart1.concat(argValuePart2).trim();
            LOG.debug("The value to be decrypted is : " + argValue);
            delimitedSlash = argValue.split(KohlsPOCConstant.DelimitedSlash);
            xPath = delimitedSlash[1];
            dataElement = delimitedSlash[0];

            if (!YFCCommon.isVoid(dataElement)) {
                decryptByGenericXPath(inXml, dataElement, xPath);
            }
        }

        return inXml;

    }

    /**
     * This method invokes protegrity and based on the dataElement, decrypts the encrypted information present in the node.
     * @param inXml
     * @param dataElement
     * @param xPath
     * @throws Exception
     */
    private void decryptByGenericXPath(Document inXml,
                                               String dataElement, String xPath) throws Exception {
       LOG.beginTimer("KohlsMPoCSecurityUtil.decryptByGenericXPath");
        String strDecryptedValue = null;

        try {
            NodeList baseElementList = ((NodeList) XPathUtil.getNodeList(
                    inXml.getDocumentElement(), xPath));
            for (int i = 0; i < baseElementList.getLength(); i++) {
                Element decryptedElement = null;
                Element baseElement = (Element) baseElementList.item(i);
                String encryptedValue = baseElement.getTextContent();

                if (!YFCCommon.isVoid(encryptedValue)) {

                    securityPlatfrom.run(sHostXC, policyUser);
                    strDecryptedValue = securityPlatfrom.returnDecryptedValue(encryptedValue, dataElement);

                    if(!YFCCommon.isVoid(strDecryptedValue)) {
                        decryptedElement = KohlsXMLUtil.getDocument(strDecryptedValue).getDocumentElement();
                        KohlsXMLUtil.removeChild(inXml.getDocumentElement(), baseElement);
                        KohlsXMLUtil.importElement(inXml.getDocumentElement(), decryptedElement);
                    }
                }
            }
        } catch (YFSException e){
            throw e;
        }
        //Adding try catch block for defect 538
        catch (Exception e) {
            e.printStackTrace();
            YFSException es = new YFSException();
            //Fix for defect 3604 - Start
            es.setErrorCode(" Protegrity Error !! ");
            //es.setErrorCode(e.getCause().toString());
            //Fix for defect 3604 - End
            es.setErrorDescription(e.getMessage());
            throw es;
        } finally {
            // Closing the Protegrity server session
            securityPlatfrom.closeSession();
        }
        LOG.endTimer("KohlsMPoCSecurityUtil.decryptByGenericXPath");
    }


    /**
     * This function is used to set properties reference.
     * @param prop
     * @throws Exception
     */
    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
        // LOG_CAT.debug("In the set properties method");

    }

    /**
     * This function is used to get the value for a property.
     * @param property
     * @return
     */
    public String getPropertyValue(String property) {

        String propValue;
        propValue = YFSSystem.getProperty(property);
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        return propValue;
    }
}
