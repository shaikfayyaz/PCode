package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsDeploymentUtil {
	static Logger log = Logger.getLogger(KohlsDeploymentUtil.class.getName());
	private static Statement stmt = null;
	Connection conn = null;
	String actionName = null;
	public static final String SECURITY_CIPHER = "Blowfish";
	public static final int MAX_CIPHER_KEY_LENGTH = 16;
	public static final String DEFAULT_ENCODING = "UTF-8";
	private static Base64 decoder = new Base64();
	private static String ISSQRYEXECUTOR = "ISSQRYEXECUTOR";

	/*
	 * Clearing the cache
	 */
	public void callModifyCache(YFSEnvironment env) throws Exception {
		log.info("Clearing the cache");
		Document docModifyCacheInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_CACHED_GROUPS);
		Element eleCachedGroups = docModifyCacheInput.getDocumentElement();
		Element eleCachedGroup = SCXmlUtil.createChild(eleCachedGroups, KohlsPOCConstant.E_CACHED_GROUP);
		eleCachedGroup.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR);
		eleCachedGroup.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_DATABASE);
		log.debug("Modify Cache Input is " + SCXmlUtil.getString(docModifyCacheInput));
		Document docModifyCacheOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MODIFY_CACHE,
				docModifyCacheInput);
		log.debug("Modify Cache Output is " + SCXmlUtil.getString(docModifyCacheOutput));
		
		// App server cache cleanup due to rmi issues		
		if (ServerTypeHelper.amIOnEdgeServer()) {
			String modifyCacheFile = YFSSystem.getProperty(KohlsPOCConstant.API_TESTER_PATH)
					+ KohlsPOCConstant.BACKWARD_SLASH + KohlsPOCConstant.CACHE_CLEAR_FILE;
			log.debug("Clear cache file path " + modifyCacheFile);
			File mFile = new File(modifyCacheFile);
			if (mFile.exists() && mFile.canExecute()) {
				final Runtime rTime = Runtime.getRuntime();
				Process p = rTime.exec(modifyCacheFile);
				final int returnCode = p.waitFor();
				final int exitValue = p.exitValue();
				log.info("Clear cache return code : " + returnCode + ", exit value : " + exitValue);
				BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
				String line;
				while ((line = reader.readLine()) != null) {
					log.info("Clear cache api output " + line);
				}
			} else {
				log.error("Clear cache file missing " + modifyCacheFile);
			}
		}
	}

	/*
	 * Get the table spaces from the database and update in XML file
	 */
	public void tableSpacesFromDB(YFSEnvironment env, String tableList, String schemaName, String versionXmlFile)
			throws Exception {
		PreparedStatement prepStatement = null;
		Connection connection = null;
		String tableSpaceList = "";
		log.debug("Table space table list is " + tableList);
		try {
			connection = ((YFSContext) env).getConnection();
			String tableSpaceQuery = "SELECT DISTINCT TABLESPACE_NAME FROM ( "
					+ "SELECT OWNER,TABLESPACE_NAME,TABLE_NAME FROM ALL_LOBS UNION "
					+ "SELECT OWNER,TABLESPACE_NAME,TABLE_NAME FROM ALL_TABLES UNION "
					+ "SELECT OWNER,TABLESPACE_NAME,TABLE_NAME FROM ALL_INDEXES UNION "
					+ "SELECT TABLE_OWNER AS OWNER,TABLESPACE_NAME,TABLE_NAME FROM ALL_TAB_PARTITIONS UNION "
					+ "SELECT I.TABLE_OWNER AS OWNER,IP.TABLESPACE_NAME,I.TABLE_NAME FROM ALL_IND_PARTITIONS IP, ALL_INDEXES I WHERE "
					+ "IP.INDEX_OWNER = I.OWNER AND IP.INDEX_NAME = I.INDEX_NAME ) " + "WHERE OWNER='" + schemaName
					+ "' AND " + "TABLE_NAME IN (" + tableList + ") " + "AND TRIM(TABLESPACE_NAME) IS NOT NULL";
			log.debug("Table space query constructed is " + tableSpaceQuery);
			prepStatement = connection.prepareStatement(tableSpaceQuery);
			ResultSet queryResultSet = prepStatement.executeQuery();
			while (queryResultSet.next()) {
				if (tableSpaceList.isEmpty()) {
					tableSpaceList = queryResultSet.getString(KohlsPOCConstant.TABLESPACE_NAME);
					log.debug("First table spaces is " + tableSpaceList);
				} else {
					tableSpaceList = tableSpaceList + "," + queryResultSet.getString(KohlsPOCConstant.TABLESPACE_NAME);
					log.debug("Table spaces are " + tableSpaceList);
				}
			}
			log.info("Table spaces are " + tableSpaceList);

			File fl = new File(versionXmlFile);
			if (fl.exists()) {
				FileWriter writer;
				log.info("Updating the synversion file with table spaces " + fl);
				Element eleSyncVersionDocument = null;
				Document docSyncVer = SCXmlUtil.getDocumentBuilder().parse(fl);
				eleSyncVersionDocument = docSyncVer.getDocumentElement();
				writer = new FileWriter(fl.getAbsoluteFile());
				Element eleProfileD = SCXmlUtil.createChild(eleSyncVersionDocument, KohlsPOCConstant.TABLE_SPACE);
				eleProfileD.setAttribute(KohlsPOCConstant.A_NAMES, tableSpaceList);
				writer.write(SCXmlUtil.getString(eleSyncVersionDocument));
				writer.close();
				log.debug("Updated synversion file is " + SCXmlUtil.getString(docSyncVer));
			} else {
				throw new YFCException("Sync version file is missing " + versionXmlFile);
			}
		} catch (Exception tableSpaceExp) {
			throw tableSpaceExp;
		}
	}

	/*
	 * Reading the table space from Sync version Xml file
	 */
	public String tableSpaceFromXmlFile(File fileNameWithFullPath) throws Exception {
		Document docSyncVer = SCXmlUtil.getDocumentBuilder().parse(fileNameWithFullPath);
		log.debug("Sync version xml file before table space is " + SCXmlUtil.getString(docSyncVer));
		String tableSpaces = "";
		if (docSyncVer.getElementsByTagName(KohlsPOCConstant.TABLE_SPACE).getLength() > 0) {
			Element element = (Element) docSyncVer.getElementsByTagName(KohlsPOCConstant.TABLE_SPACE).item(0);
			tableSpaces = element.getAttribute(KohlsPOCConstant.A_NAMES).replaceAll(",", ":SOF00001,") + ":SOF00001";
			log.info("Table spaces from xml file are " + tableSpaces);
		} else {
			log.info("Tablespaces is empty " + tableSpaces);
		}
		return tableSpaces;
	}
		
	public void manageSyncProcessRecordExpImp(YFSContext ctx, String strSyncProcess, String strSyncType, String strTargetId,
			String strSchemaType, ArrayList<String> actProfileListToUpdate, String syncDBDate ) throws Exception{		
		try {			
			// To get the DB entries for the custom table
			Document inputDocList = YFCDocument.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS).getDocument();
			Element inputDocListElm = inputDocList.getDocumentElement();
			inputDocListElm.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, strSchemaType);
			inputDocListElm.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, strSyncProcess);
			inputDocListElm.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, strTargetId);
			inputDocListElm.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, strSyncType);
					
			if (strSchemaType.equalsIgnoreCase(KohlsPOCConstant.TABLE_TYPE_MASTER)) {
				ArrayList<String> prtProfList = new ArrayList<String>();
				log.info("Active profile size " + actProfileListToUpdate.size());
				log.debug("Input to GetDataPumpSyncProcessList API" + XMLUtil.getXMLString(inputDocList));
				
				Document outDocList = KohlsCommonUtil.invokeService(ctx,
						KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, inputDocList);
				log.debug("Output of GetDataPumpSyncProcessList API" + XMLUtil.getXMLString(outDocList));
				ArrayList<Element> outDocDeltaRecords = SCXmlUtil.getChildren(outDocList.getDocumentElement(),
						KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);

			    //To pass as input create and manage API's
				Document inDocProfile = YFCDocument.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS)
						.getDocument();
				Element inDocProfileElm = inDocProfile.getDocumentElement();
				inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, strSchemaType);
				inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, strSyncProcess);
				inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, strTargetId);
				inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, strSyncType);
				
				if (outDocDeltaRecords.size() == 0) {
					log.info("No master profiles  present in DATAPUMP table");
					for (int k = 0; k < actProfileListToUpdate.size(); k++) {
						inDocProfileElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, actProfileListToUpdate.get(k));
						inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP, syncDBDate);
						log.debug("Input of CreateDataPumpSyncProcess for empty profile " + XMLUtil.getXMLString(inDocProfile));
						Document outDocProfile = KohlsCommonUtil.invokeService(ctx,
								KohlsPOCConstant.API_CREATE_DATA_PUMP_SYNC_PROCESS_LIST, inDocProfile);
						log.debug("Output of CreateDataPumpSyncProcess for empty profile " + XMLUtil.getXMLString(outDocProfile));
					}
				} else {					
					Element eleCommonCodeList = outDocList.getDocumentElement();
					NodeList nodeListProfile = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
					boolean emptyProfile = true;
					for (int i = 0; i < nodeListProfile.getLength(); i++) {
						Element eleCommonCode = ((Element) nodeListProfile.item(i));
						log.info("Profile name to update " + eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE));
						for (int p1 = 0; p1 < actProfileListToUpdate.size(); p1++) {
							if (actProfileListToUpdate.get(p1).equalsIgnoreCase(eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE))) {
								inDocProfileElm.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY, eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
								inDocProfileElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, actProfileListToUpdate.get(p1));
								inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP, syncDBDate);
								log.debug("Input of ManageDataPumpSyncProcess for each profile "
										+ XMLUtil.getXMLString(inDocProfile));
								Document docOutput = KohlsCommonUtil.invokeService(ctx,
										KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST, inDocProfile);
								log.debug("Output of ManageDataPumpSyncProcess for each profile "
										+ XMLUtil.getXMLString(docOutput));
								prtProfList.add(actProfileListToUpdate.get(p1));
							}else if (YFCCommon.isVoid(eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE)) && emptyProfile) {								
								log.debug("Existing empty master entry " + inDocProfileElm.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE));
								inDocProfileElm.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY, eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
								inDocProfileElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, actProfileListToUpdate.get(p1));
								inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP, syncDBDate);
								log.debug("Output of ManageDataPumpSyncProcess for EMPTY profile "
										+ XMLUtil.getXMLString(inDocProfile));
								Document docOutput2 = KohlsCommonUtil.invokeService(ctx,
										KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST, inDocProfile);
								log.debug("Output of ManageDataPumpSyncProcess for each profile "
										+ XMLUtil.getXMLString(docOutput2));
								prtProfList.add(actProfileListToUpdate.get(p1));
								emptyProfile = false;
							}
						}					
					}
					
					actProfileListToUpdate.removeAll(prtProfList); // to remove the list present in DB					
					// this is for missing profiles in the DB., may not require now
					for (int k = 0; k < actProfileListToUpdate.size(); k++) {
						inDocProfileElm.removeAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY);
						inDocProfileElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, actProfileListToUpdate.get(k));
						inDocProfileElm.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP, syncDBDate);
						log.debug("Input of CreateDataPumpSyncProcess for missing profile and new profile "
								+ XMLUtil.getXMLString(inDocProfile));
						Document docOutputMissingPrf = KohlsCommonUtil.invokeService(ctx,
								KohlsPOCConstant.API_CREATE_DATA_PUMP_SYNC_PROCESS_LIST, inDocProfile);
						log.debug("Input of CreateDataPumpSyncProcess for missing profile and new profile "
								+ XMLUtil.getXMLString(docOutputMissingPrf));
					}
				}
			} else if (strSchemaType.equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
				log.debug("Input to GetDataPumpSyncProcessList CONFIGURATION " + XMLUtil.getXMLString(inputDocList));
				Document outDoc2 = KohlsCommonUtil.invokeService(ctx,
						KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, inputDocList);
				log.info("Output from GetDataPumpSyncProcessList CONFIGURATION " + XMLUtil.getXMLString(outDoc2));
				ArrayList<Element> syncProcessList = SCXmlUtil.getChildren(outDoc2.getDocumentElement(),
						KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
				
				if (syncProcessList.size() == 0) {
					inputDocListElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, KohlsPOCConstant.P_CONFIGURATION_D);
					inputDocListElm.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP, syncDBDate);
					Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
							KohlsPOCConstant.API_CREATE_DATA_PUMP_SYNC_PROCESS_LIST, inputDocList);
					log.debug("Output from ManageDataPumpSyncProcess for missing CONFIGURATION " + XMLUtil.getXMLString(docOutput3));
				} else {
					Element eleCommonCodeList = outDoc2.getDocumentElement();
					NodeList nodeListProfileTime = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
					Element eleCommonCode = ((Element) nodeListProfileTime.item(0));
					inputDocListElm.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY, eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
					inputDocListElm.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP, syncDBDate);
					if (YFCCommon.isVoid(eleCommonCode.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE))) {
						inputDocListElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, KohlsPOCConstant.P_CONFIGURATION_D);
						log.info("Updating the empty sync profile ");
					}
					Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
							KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST, inputDocList);
					log.debug("Output from ManageDataPumpSyncProcess CONFIGURATION " + XMLUtil.getXMLString(docOutput3));
				}
			}
		} catch (Exception e) {
			throw e;
		}	
	}	
	
	// Get the commonCodeList based on the Type passed
	public Document callGetCommonCodeList(YFSContext ctx, String strSyncProfile) throws Exception {
		Document docCommonCodeListInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
		Element eleCommonCodeListInput = docCommonCodeListInput.getDocumentElement();
		eleCommonCodeListInput.setAttribute(KohlsPOCConstant.A_CODE_TYPE, strSyncProfile);
		log.debug("eleCommonCodeListInput is " + SCXmlUtil.getString(docCommonCodeListInput));

		Document docCommonCodeListOutput = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_GET_COMMON_CODE_LIST,
				docCommonCodeListInput);
		log.debug("docCommonCodeListOutput is " + SCXmlUtil.getString(docCommonCodeListOutput));
		return docCommonCodeListOutput;
	}	
	
	//Index creation
	//<Index StoreID="9916" Action="Create"/>
	
	public Document indexCreation(YFSEnvironment env, Document doc) throws Exception {
		log.info("Starting the Sql query execution");
		Document outDoc = SCXmlUtil.createDocument(KohlsPOCConstant.A_INDEX);
		Element outElm = outDoc.getDocumentElement();
		Element elmInDoc = doc.getDocumentElement();
		outElm.setAttribute(KohlsPOCConstant.STORE_ID, elmInDoc.getAttribute(KohlsPOCConstant.STORE_ID)); 
		try {
			if (elmInDoc.getAttribute(KohlsPOCConstant.ACTION).equalsIgnoreCase(KohlsPOCConstant.A_CREATE)) {
				ArrayList<String> queryListFromFile = fileContent(KohlsPOCConstant.QUERY_FILE);
				//ArrayList<String> queryListFromFile = fileContent(elmInDoc.getAttribute("FilePath"));
				YFSContext context = (YFSContext) env;
				conn = context.getDBConnection();
				stmt = conn.createStatement();
				for (String sqlQuery : queryListFromFile) {
					String errMsg = "";
					try {
						log.debug("Query being fired is " + sqlQuery);
						stmt.executeQuery(sqlQuery);
					} catch (SQLException ex) {
						errMsg = ex.getMessage();
						String[] er = errMsg.split(":");
						log.warn("Sql ORA code is " + er[0] + " and message is " + errMsg);
						if (!(er[0].contains(KohlsPOCConstant.INDEX_ALREADY_EXIST_CODE)
								|| er[0].contains(KohlsPOCConstant.COLUMN_LISTED_ALREADY)
								|| er[0].contains(KohlsPOCConstant.INDEX_DOES_NOT_EXIST))) {
							log.error("Query fired is " + sqlQuery);							
							outElm.setAttribute(KohlsPOCConstant.MESSAGE, ex.getMessage());
							return outDoc;
						}
					}
				}
				outElm.setAttribute(KohlsPOCConstant.MESSAGE, KohlsPOCConstant.SUCCESS);
				log.debug("Returning the success " + SCXmlUtil.getString(outDoc));
				return outDoc;
			} else {
				outElm.setAttribute(KohlsPOCConstant.MESSAGE, "Incorrect input passed");
				log.warn("Incorrect input passed is " + SCXmlUtil.getString(outDoc));
				return outDoc;
			}
		} catch (Exception e) {
			log.error("Exception in executeQuery " + e.getMessage());
			outElm.setAttribute(KohlsPOCConstant.MESSAGE, e.getMessage());
			return outDoc;
		} finally {
			if (stmt != null && !stmt.isClosed()) {
				try {
					stmt.close();
					log.info("Closed the statement execution connection");
				} catch (Exception e2) {
					log.warn("Cannot close statement " + e2.getMessage());
					outElm.setAttribute(KohlsPOCConstant.ErrorMessage, e2.getMessage());
					log.warn("Statement closing output " + SCXmlUtil.getString(outDoc));
					return outDoc;
				}
			}			
		}	
	}

	/*
	 * Read the query from the file and return the array list
	 */
	public ArrayList<String> fileContent(String queryPath) throws Exception {
		File fl = new File(queryPath);
		BufferedReader br = new BufferedReader(new FileReader(fl));
		String readLine = "";
		ArrayList<String> queryList = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		while ((readLine = br.readLine()) != null) {
			if (!readLine.contentEquals(KohlsPOCConstant.BACKWARD_SLASH)) {
				log.debug("Reading the line is " + readLine);
				sb.append(readLine);
			} else {
				queryList.add(sb.toString());
				log.debug("SQL statement is " + sb);				
				sb.setLength(0);
				log.debug("SB content after clear is " + sb);
			}
		}
		br.close();
		return queryList;
	}
	
	// Check the ORA file entry
	public boolean checkTnsNamesOraEntries() throws Exception {
		File tnsFile = new File(KohlsPOCConstant.TNS_NAMES_ORA);		
		FileReader fileReader = new FileReader(tnsFile);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line = null;
		if ((line = bufferedReader.readLine()) == null) {
			log.info("tnsnames file is empty" + KohlsPOCConstant.TNS_NAMES_ORA);
			fileReader.close();
			return false;
		} else {
			log.info("Entries present in tnsnames file");
			log.debug("Entry in tnsnames file is " + line);
			fileReader.close();
			return true;
		}
	}
	
	// Get the business date from accounting table
	public Document getBusinessDate(YFSEnvironment env, String storeID) throws Exception {
		log.info("Getting the business date");
		Document accPeriodInput = SCXmlUtil.createDocument(KohlsPOCConstant.A_ACC_PERIOD);
		Element accPeriodInputElm = accPeriodInput.getDocumentElement();
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_ORG_CODE,storeID);
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_PERIOD, KohlsPOCConstant.YES);
		log.debug("Input to get business date " + KohlsXMLUtil.getXMLString(accPeriodInput));
		Document outputDocDate = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_ACC_PERIOD_LIST_POS,
				accPeriodInput);
		log.debug("Output to get business date " + XMLUtil.getXMLString(outputDocDate));		
		return outputDocDate;
	}
	
	
	//decrypt
	public Properties loadPropertiesFromAbsoluteLocation(String propertyFilePath) throws Exception {
		log.info("Reading the property file");
		Properties prop = new Properties();
		File file = null;
		FileReader fr = null;
		log.debug("Properties File Path : " + propertyFilePath);
		try {
			file = new File(propertyFilePath);
			log.debug("Properties file created successfully");
			fr = new FileReader(file);
			log.debug("File Reader initiated successfully");
			prop.load((Reader) fr);
		} catch (Exception e) {
			log.error("Error in loading properties file " + e.getMessage() + e.getStackTrace());
			throw e;
		} finally {
			if (fr != null) {
				fr.close();
			}
			if (file != null) {
				file = null;
			}
		}
		return prop;
	}
	
	
	//Delta query execution
	public Document ISSQueryExecutor(YFSEnvironment env, Document inDoc) throws SQLException {
		Connection dbConnection = null;		
		try {
			log.info("Input to the service " + SCXmlUtil.getString(inDoc));
			String dbUser = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ELEM_USER);
			String deCiperPass = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.DB_PASSWORD);	
							
			KohlsRestAPIUtil restUtil = new KohlsRestAPIUtil();			
			String dbPassword = decryptField(restUtil.pwdForDecryption(ISSQRYEXECUTOR), deCiperPass);
			String dbQuery = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.QUERY);
			Properties jdbcProperties = loadPropertiesFromAbsoluteLocation(KohlsPOCConstant.JDBC_APP_FILE);
			String dbUrl = jdbcProperties.getProperty(KohlsPOCConstant.DEFAULT_CONFIGURATION);
			
			if (log.isDebugEnabled()) {
				log.debug("DB url formed is " + dbUrl);
			}

			Class.forName(KohlsPOCConstant.JDBC_DRIVER);	
			Document response = SCXmlUtil.createDocument(KohlsPOCConstant.A_SQL_LOAD);
			Element elm = response.getDocumentElement();
			
			dbConnection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
			stmt = dbConnection.createStatement();			

			Pattern p = Pattern.compile(KohlsPOCConstant.SELECT, Pattern.CASE_INSENSITIVE);
		    Matcher m = p.matcher(dbQuery);
		    if (m.find()){
				log.info("Executing the select query " + dbQuery);
				ResultSet rs = stmt.executeQuery(dbQuery);
				ResultSetMetaData rsmd = rs.getMetaData();
				int columnsNumber = rsmd.getColumnCount();
				StringBuffer bfr = new StringBuffer();
				for (int i = 1; i <= columnsNumber; i++) {
					if (i != 1)
						bfr.append(",  ");
					bfr.append(rsmd.getColumnName(i));
				}
				Element elmLastMsg = XMLUtil.createChild(elm, KohlsPOCConstant.COLUMNS);
				elmLastMsg.setAttribute(KohlsPOCConstant.NAMES, bfr.toString());
				log.info("Table column names " + bfr.toString());
				int ii = 1;
				while (rs.next()) {
					StringBuffer bfr1 = new StringBuffer();
					for (int i = 1; i <= columnsNumber; i++) {
						if (i != 1)
							bfr1.append(",  ");
						bfr1.append(rs.getString(i));
					}
					Element selectResponse = XMLUtil.createChild(elm, KohlsPOCConstant.RECORD);
					selectResponse.setAttribute(KohlsPOCConstant.DETAILS, bfr1.toString());
					log.info("\n" + ii + ") " + bfr1.toString());
					ii++;
				}
				log.info("Returned response to service \n " + SCXmlUtil.getString(response));
				rs.close();
				return response;
			} else {
				log.info("Executing the query " + dbQuery);
				stmt.executeQuery(dbQuery);
				response.getDocumentElement().setAttribute(KohlsPOCConstant.E_RESPONSE, KohlsPOCConstant.SUCCESS);
				log.info("Returned response to service \n " + SCXmlUtil.getString(response));
				return response;
			}
		} catch (Exception e) {
			log.error("Exception occurred in ISSQueryExecutor" + e.getMessage());
			return SCXmlUtil.createDocument(e.getMessage());
		} finally {
			YFSDBHome.closeStatement(stmt);
			if (!stmt.isClosed()) {
				stmt.close();
				log.info("Closing the statement");
			}
			if (!dbConnection.isClosed()) {
				dbConnection.close();
				log.info("Closed the db connection");
			}
		}	
	}	
	
	public static String decode(String crypticText) {
		if (crypticText != null) {
			return new String(decoder.decode(crypticText.getBytes()));
		}
		return null;
	}

	public static String decodeWithChar(String crypticText) {
		String decodedStr = decode(crypticText.substring(4).trim());
		return decodedStr;
	}

	public static String decryptField(String cipherKey, String data) {
		String retVal = null;
		if ((!(StringUtils.isEmpty(cipherKey))) && (data != null) && (data.length() > 2) && (data.startsWith("="))
				&& (data.endsWith("="))) {
			data = data.substring(1, data.length() - 1);
			try {
				if (cipherKey.length() > 16) {
					cipherKey = cipherKey.substring(0, 16);
				}
				SecretKeySpec keySpec = new SecretKeySpec(cipherKey.getBytes(), KohlsPOCConstant.BLOW_FISH);
				Cipher cipher = Cipher.getInstance(KohlsPOCConstant.BLOW_FISH);
				cipher.init(2, keySpec);
				byte[] valueToDecript = Base64.decodeBase64(data.getBytes(KohlsPOCConstant.UTF_8));
				byte[] decryptedText = cipher.doFinal(valueToDecript);
				retVal = new String(decryptedText, KohlsPOCConstant.UTF_8);
			} catch (Exception e) {
				retVal = null;
			}
		}
		return retVal;
	}
	
	// querySplitter to form the sql TODO temp mgr
	public ArrayList<String> querySplitter(String queryPath) throws Exception {
		log.info("Query splitter started with queryPath " + queryPath);
		File fl = new File(queryPath);
		BufferedReader br = new BufferedReader(new FileReader(fl));
		String readLine = "";
		ArrayList<String> queryList = new ArrayList<String>();
        StringBuilder queryBuilder = new StringBuilder();
        boolean allowSpace = false;
		while ((readLine = br.readLine()) != null) {
			if (!readLine.contentEquals(KohlsPOCConstant.BACKWARD_SLASH)) {
				log.debug("Reading the sql " + readLine);
				if (allowSpace) {
					queryBuilder.append(" " + readLine);
				} else {
					queryBuilder.append(readLine);
				}
				allowSpace = true;
			} else {
				queryList.add(queryBuilder.toString());
				log.debug("SQL statement formed " + queryBuilder);				
				queryBuilder.setLength(0);
				allowSpace = false;
				log.debug("SB content after clear is " + queryBuilder);
			}
		}
		br.close();
		return queryList;
	}
	
	
	public void handleDeleteSql(YFSEnvironment env, String absFile)
			throws Exception {
		log.info("handleDeleteSql started ");
		try {
			YFSContext context = (YFSContext) env;
			conn = context.getDBConnection();
			stmt = conn.createStatement();
			for (String delQuery : querySplitter(absFile)) {
				log.debug("Executing the query " + delQuery);
				stmt.executeQuery(delQuery);
			}
		} catch (Exception ex) {
			throw ex;
		} finally {
			if (stmt != null && !stmt.isClosed()) {
				stmt.close();
				log.info("Closed the statement execution connection");
			}
		}
	}
	
	public File createTimestampDir(String sourcePath, String destPath) throws Exception {
		String timeStampDir = sourcePath.replaceAll("^.*?(\\w+)\\W*$", "$1");
		String destTimeStampDir = destPath + KohlsPOCConstant.BACKWARD_SLASH + timeStampDir;
		log.info("Formed new directory path  " + destTimeStampDir);
		File nwDir = new File(destTimeStampDir);
		if (!nwDir.isDirectory()) {
			nwDir.mkdir();
			grantPermission(nwDir);
		}
		return nwDir;
	}

	public void grantPermission(File perDir) {
		perDir.setExecutable(true, false);
		perDir.setReadable(true, false);
		perDir.setWritable(true, false);
	}
}
