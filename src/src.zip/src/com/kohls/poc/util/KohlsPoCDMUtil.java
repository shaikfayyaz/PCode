package com.kohls.poc.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCDMUtil {

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCDMUtil.class.getName());
	}
	List responseList = new ArrayList<>();
	public Document toCheckUpdateOrCreate(Document docDamageReasonCodeRes,
			Document docDamageReasonCodeList, String Source, String sStandAlone, YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.toCheckUpdateOrCreate");
		Element eleDamageReasonCodeRes = null;
		NodeList ndlDamageReasonCode = null;
		Element eleDamageReasonCodeFromRes = null;
		
		if (Source.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {
			eleDamageReasonCodeRes = (Element) docDamageReasonCodeRes
					.getElementsByTagName(
							KohlsPOCConstant.ELEM_DM_SLIP_TEXT_LIST).item(0);
			ndlDamageReasonCode = eleDamageReasonCodeRes
					.getElementsByTagName(KohlsPOCConstant.ELEM_DM_SLIP_TEXT);
					
					if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate --Slip text"+XMLUtil.getElementXMLString(eleDamageReasonCodeRes));
				}

		} else {
			eleDamageReasonCodeRes = (Element) docDamageReasonCodeRes
					.getElementsByTagName("KohlsDamagedReasonCodesList")
					.item(0);
					if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate DM"+XMLUtil.getElementXMLString(eleDamageReasonCodeRes));
				}
			ndlDamageReasonCode = eleDamageReasonCodeRes
					.getElementsByTagName("KohlsDamagedReasonCodes");
					
		}

		for (int i = 0; i < ndlDamageReasonCode.getLength(); i++) {

			Element eleDamageReasonCode = (Element) ndlDamageReasonCode.item(i);
			if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate --record"+XMLUtil.getElementXMLString(eleDamageReasonCode));
				}
			if (Source.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {
				String sDispositionCode = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE);

				String sData = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_CODES);
				eleDamageReasonCodeFromRes = KohlsXPathUtil.getElementByXpath(
						docDamageReasonCodeList,
						"//KohlsDispositionSlipText[@DispositionCode='"+sDispositionCode+"' and @Codes='"+sData+"']");
								if (logger.isDebugEnabled()) {
									if(!YFCCommon.isVoid(eleDamageReasonCodeFromRes))
									{
					logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate-- Data exists in the Table"+XMLUtil.getElementXMLString(eleDamageReasonCodeFromRes));
									}
				}
				responseList.add(sDispositionCode+"-"+sData);

			} else {

				String sBusinesGroupNo = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_GROUP_NO);

				String sData = eleDamageReasonCode.getAttribute(KohlsPOCConstant.ATTR_DEPTS);
				eleDamageReasonCodeFromRes = KohlsXPathUtil
						.getElementByXpath(
								docDamageReasonCodeList,
								"//KohlsDamagedReasonCodes[@BusinessGroupNo='"+sBusinesGroupNo+"' and @Departments='"+sData+"']");

				if (logger.isDebugEnabled()) {
					if(!YFCCommon.isVoid(eleDamageReasonCodeFromRes))
					{
	logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate--data exists in the table"+XMLUtil.getElementXMLString(eleDamageReasonCodeFromRes));
					}
				}
				responseList.add(sBusinesGroupNo+"-"+sData);
			}
			if (!YFCCommon.isVoid(eleDamageReasonCodeFromRes)) {
				
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate--.UPDATE record");
					}
				eleDamageReasonCode.setAttribute(KohlsPOCConstant.A_UPDATE_FLAG, KohlsPOCConstant.FLAG_Y);
			}
			else
			{
				if (logger.isDebugEnabled()) {
				logger.debug("KohlsPoCDMUtil.toCheckUpdateOrCreate--.CREATE record");
				}
				eleDamageReasonCode.setAttribute(KohlsPOCConstant.A_CREATE_FLAG, KohlsPOCConstant.FLAG_Y);
				
			}
			
			if(sStandAlone.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
			{
				modifyTable(env, XMLUtil.getDocumentForElement(eleDamageReasonCode), Source);	
			}
		}

		logger.endTimer("KohlsPoCDMUtil.toCheckUpdateOrCreate");

		return docDamageReasonCodeRes;

	}

	public Document toDeleteRecordsFromTable(Document docDamageReasonCodeRes,
			Document docDamageReasonCodeList, String Source, String sStandAlone, YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.toDeleteRecordsFromTable");

		Element eleDamageReasonCodeList;
		NodeList ndlDamageReasonCode;
		Element eleDamageReasonCodeFromRes;

		if (Source.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {

			eleDamageReasonCodeList = (Element) docDamageReasonCodeList
					.getElementsByTagName(
							KohlsPOCConstant.ELEM_DM_SLIP_TEXT_LIST).item(0);

			ndlDamageReasonCode = eleDamageReasonCodeList
					.getElementsByTagName(KohlsPOCConstant.ELEM_DM_SLIP_TEXT);
					if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable -- Record "+XMLUtil.getElementXMLString(eleDamageReasonCodeList));
				}
		} else {

			eleDamageReasonCodeList = (Element) docDamageReasonCodeList
					.getElementsByTagName("KohlsDamagedReasonCodesList")
					.item(0);

			ndlDamageReasonCode = eleDamageReasonCodeList
					.getElementsByTagName("KohlsDamagedReasonCodes");
			if (logger.isDebugEnabled()) {
				logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable "+XMLUtil.getElementXMLString(eleDamageReasonCodeList));
			}
		}
		for (int k = 0; k < ndlDamageReasonCode.getLength(); k++) {

			Element eleDamageReasonCode = (Element) ndlDamageReasonCode.item(k);
			

			if (Source.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {

				String sDispositionCode = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE);

				String sData = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_CODES);
				
				eleDamageReasonCodeFromRes = KohlsXPathUtil.getElementByXpath(
						docDamageReasonCodeRes,
						"//KohlsDispositionSlipText[@DispositionCode='"
								+ sDispositionCode + "']");
				if (logger.isDebugEnabled()) {
					if(!YFCCommon.isVoid(eleDamageReasonCodeFromRes))
					{
					logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable-- Slip Text is "+XMLUtil.getElementXMLString(eleDamageReasonCodeFromRes));
					
				}

			}
				
				if (responseList.contains(sDispositionCode+"-"+sData)) {

					if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable -- Delete not Required");
					}
				continue;

			} else {
				eleDamageReasonCode.setAttribute(KohlsPOCConstant.A_DELETE_FLAG,KohlsPOCConstant.FLAG_Y);

				XMLUtil.importElement(
						docDamageReasonCodeRes.getDocumentElement(),
						eleDamageReasonCode);
						if (logger.isDebugEnabled()) {
								logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable - Delerting the record  "+XMLUtil.getElementXMLString(docDamageReasonCodeRes.getDocumentElement()));
						}
			}
				
			}else {

				String sDepartment = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_DEPTS);
				
				String sBusinesGroupNo = eleDamageReasonCode
						.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_GROUP_NO);
				
				eleDamageReasonCodeFromRes = KohlsXPathUtil
						.getElementByXpath(
								docDamageReasonCodeRes,
								"//KohlsDamagedReasonCodes[@BusinessGroupNo='"
										+ eleDamageReasonCode
										.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_GROUP_NO)
										+ "']");

				if (logger.isDebugEnabled()) {
					if(!YFCCommon.isVoid(eleDamageReasonCodeFromRes))
					{
					logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable--Record Exists  "+XMLUtil.getElementXMLString(eleDamageReasonCodeFromRes));
					}
				}
				
				if (responseList.contains(sBusinesGroupNo+"-"+sDepartment)) {

					if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable -- Record exists in the resposnse");
					}
				continue;

			} else {
				eleDamageReasonCode.setAttribute(KohlsPOCConstant.A_DELETE_FLAG,KohlsPOCConstant.FLAG_Y);

				XMLUtil.importElement(
						docDamageReasonCodeRes.getDocumentElement(),
						eleDamageReasonCode);
						if (logger.isDebugEnabled()) {
								logger.debug("KohlsPoCDMUtil.toDeleteRecordsFromTable - Record does not exist in tHe response  "+XMLUtil.getElementXMLString(docDamageReasonCodeRes.getDocumentElement()));
						}
			}
			}						
			if(sStandAlone.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y) )
			{
				if(!YFCCommon.isVoid(eleDamageReasonCode.getAttribute(KohlsPOCConstant.A_DELETE_FLAG)))
				{
					if(eleDamageReasonCode.getAttribute(KohlsPOCConstant.A_DELETE_FLAG).equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
					{
						modifyTable(env, XMLUtil.getDocumentForElement(eleDamageReasonCode), Source);
					}
				}
			}
		}

		logger.endTimer("KohlsPoCDMUtil.toDeleteRecordsFromTable");

		return docDamageReasonCodeRes;
	}

	public void modifyTable(YFSEnvironment env, Document docDispositionCode,
			String sSource) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.modifyTable");

		Element eleDispositionCode = docDispositionCode.getDocumentElement();

		if (!YFCCommon.isVoid(eleDispositionCode)) {

			if (eleDispositionCode.getAttribute(KohlsPOCConstant.A_CREATE_FLAG)
					.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))

			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.modifyTable--.CREATE record");
				}
				if (sSource
						.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {
					createDispositionSlipTxt(
							XMLUtil.getDocumentForElement(eleDispositionCode),
							env);
				} else {
					createDamageReasonCode(
							XMLUtil.getDocumentForElement(eleDispositionCode),
							env);
				}

			} else if (eleDispositionCode.getAttribute(
					KohlsPOCConstant.A_UPDATE_FLAG).equalsIgnoreCase(
							KohlsPOCConstant.FLAG_Y))

			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.modifyTable--.Update record");
				}
				if (sSource
						.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {
					updateDispositionSlipTxt(
							XMLUtil.getDocumentForElement(eleDispositionCode),
							env);
				} else {
					updateDamageReasonCode(env,
							XMLUtil.getDocumentForElement(eleDispositionCode));
				}
			}

			else if (eleDispositionCode.getAttribute(
					KohlsPOCConstant.A_DELETE_FLAG).equalsIgnoreCase(
							KohlsPOCConstant.FLAG_Y))

			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCDMUtil.modifyTable--.Delete record");
				}
				if (sSource
						.equalsIgnoreCase(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT)) {
					deleteDispositionSlipTxt(
							XMLUtil.getDocumentForElement(eleDispositionCode),
							env);
				} else {
					deleteDamageReasonCode(env,
							XMLUtil.getDocumentForElement(eleDispositionCode));

				}

			}

		}
		logger.endTimer("KohlsPoCDMUtil.modifyTable");

	}

	public void createDamageReasonCode(Document docDamageReasonCode,
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.createDamageReasonCode");

		KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_CREATE_DAMAGE_REASON_CODES,
				docDamageReasonCode);
		logger.endTimer("KohlsPoCDMUtil.createDamageReasonCode");

	}

	public void deleteDamageReasonCode(YFSEnvironment env,
			Document docDamageReasonCode) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.deleteDamageReasonCode");

		KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_DELETE_DAMAGE_REASON_CODES,
				docDamageReasonCode);
		logger.endTimer("KohlsPoCDMUtil.deleteDamageReasonCode");

	}

	public void updateDamageReasonCode(YFSEnvironment env,
			Document docDamageReasonCode) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.updateDamageReasonCode");

		KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_CHANGE_DAMAGE_REASON_CODES,
				docDamageReasonCode);
		logger.endTimer("KohlsPoCDMUtil.updateDamageReasonCode");

	}

	public void deleteDispositionSlipTxt(Document docDispotionSlipText,
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.deleteDispositionSlipTxt");
KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_DELETE_SLIP_TEXT,
				docDispotionSlipText);

		
		logger.endTimer("KohlsPoCDMUtil.deleteDispositionSlipTxt");

	}

	public void updateDispositionSlipTxt(Document docDispotionSlipText,
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.updateDispositionSlipTxt");

		KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_CHANGE_DM_SLIP_TEXT,
				docDispotionSlipText);
		logger.endTimer("KohlsPoCDMUtil.updateDispositionSlipTxt");

	}

	public void createDispositionSlipTxt(Document docDispotionSlipText,
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.createDispositionSlipTxt");

		
				KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_CREATE_DM_SLIP_TEXT,
				docDispotionSlipText);
		logger.endTimer("KohlsPoCDMUtil.createDispositionSlipTxt");

	}
	public Document getDispositionSlipTxt(
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.getDispositionSlipTxt");
		Document docDispotionSlipText= XMLUtil.createDocument(KohlsPOCConstant.ELEM_DM_SLIP_TEXT);

		Document docOutDispotionSlipTxtList=KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_GET_DM_SLIP_TEXT
				,docDispotionSlipText);

		logger.endTimer("KohlsPoCDMUtil.getDispositionSlipTxt");
		return docOutDispotionSlipTxtList;
	}
	public Document getDamageReasonCodeList(
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCDMUtil.getDamageReasonCodeList");
		Document docDamagedReasonCodes = XMLUtil.createDocument(KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES);

		Document docOutDamageReasonCodeList=KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.SERVICE_KOHLS_GET_DAMAGE_REASON_CODE_LIST,
				docDamagedReasonCodes);

		logger.endTimer("KohlsPoCDMUtil.getDamageReasonCodeList");
		return docOutDamageReasonCodeList; 
		
	}

	
	

}
