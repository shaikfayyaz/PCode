package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.Properties;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;
//import weblogic.net.http.HttpsURLConnection;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.json.JSONException;
import org.apache.commons.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sun.net.ssl.internal.www.protocol.https.HttpsURLConnectionOldImpl;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

/*
 * Sample input to user exit : <VerifoneDeviceProfile PINPadMACAddress="00:0B:4F:8A:9A:59" SerialNumber="169-026-742" />
 */
public class KohlsPoCHTTPPostUtil extends KOHLSBaseApi {


	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCHTTPPostUtil.class);
	private Properties _properties = null;
	static String strAuthUsername = null;
	static String strAuthPassword = null;

	String strtimeout = "";

	/*
	 *-------------customer_overrides details 
	 * VHQ_AUTH_FILE_LOC=
	 * VHQ_AUTH_FILE_NAME=
	 * VHQSDKRESTURL=
	 * dataServicesURL =
	 * stsUrl =
	 * --------------VHQAuthencation.properties file
	 * STS_AUTH_USERNAME=
	 * STS_AUTH_PASSWORD=
	 * STS_COMPANY_NAME=
	 */

	private String getAuthString() throws IOException {
		loadProperties();
		String auth = strAuthUsername + ":" + strAuthPassword;
		String encodedString = new String(Base64.encodeBase64(auth.getBytes()));
		String finalAuthString = "Basic " + encodedString;
		return finalAuthString;
	}

	private static String getDeviceLookupString(Document inputDoc){
		logger.beginTimer("KohlsPoCHTTPPostUtil.getDeviceLookupString");

		Element eleInputRoot = (Element) inputDoc.getDocumentElement();
		String strPINPadMACAddress = eleInputRoot.getAttribute(KohlsPOCConstant.PINPAD_MAC_ADDRESS);
		String strSerialNumber = eleInputRoot.getAttribute("SerialNumber");
		if (!YFCCommon.isVoid(strSerialNumber) && !strSerialNumber.contains("-")) {
			strSerialNumber = strSerialNumber.substring(0, 3) + "-" + strSerialNumber.substring(3, 6) + "-" + strSerialNumber.substring(6, 9);
		}
		// Payload
		String sdeviceInfo = null;
		if (!YFCCommon.isVoid(strPINPadMACAddress)) {
			sdeviceInfo = "?macAddress=" + strPINPadMACAddress;
		} else {
			sdeviceInfo = "?serialNumber=" + strSerialNumber;
		}

		return sdeviceInfo;
	}


	private String getDeviceProfileResponse(URLConnection conn) throws IOException {

		int responseCode = 0;
		String response = null;
		InputStream inputStream = null;

		if (conn instanceof HttpsURLConnection) {
			HttpsURLConnection newCon = (HttpsURLConnection) conn;
			logger.debug("URLConnection is :  javax.net.ssl.HttpsURLConnection");

			newCon.setRequestMethod("GET");
			newCon.setDoOutput(true);
			newCon.setConnectTimeout(Integer.parseInt(strtimeout));
			newCon.setRequestProperty("Authorization", getAuthString());
			responseCode = newCon.getResponseCode();
			logger.debug("Device profile REST URL Response Code:: " + responseCode);
			if(responseCode ==200){
				inputStream = newCon.getInputStream();
			}
		} else if (conn instanceof HttpsURLConnectionOldImpl) {
			HttpsURLConnectionOldImpl newCon = (HttpsURLConnectionOldImpl) conn;
			logger.debug("URLConnection is :  weblogic.net.http.HttpsURLConnection");
			// add request header
			newCon.setRequestMethod("GET");
			newCon.setDoOutput(true);
			newCon.setConnectTimeout(Integer.parseInt(strtimeout));
			newCon.setRequestProperty("Authorization", getAuthString());
			responseCode = newCon.getResponseCode();
			logger.debug("Device profile REST URL Response Code:: " + responseCode);
			if(responseCode == 200){
				inputStream = newCon.getInputStream();
			}
		} else if (conn instanceof weblogic.net.http.HttpsURLConnection) {
			weblogic.net.http.HttpsURLConnection newCon = (weblogic.net.http.HttpsURLConnection) conn;
			logger.debug("URLConnection is :  weblogic.net.http.HttpsURLConnection");
			// add request header
			newCon.setRequestMethod("GET");
			newCon.setDoOutput(true);
			newCon.setConnectTimeout(Integer.parseInt(strtimeout));
			newCon.setRequestProperty("Authorization", getAuthString());
			responseCode = newCon.getResponseCode();
			logger.debug("Device profile REST URL Response Code:: " + responseCode);
			if(responseCode == 200){
				inputStream = newCon.getInputStream();
			}
		} else {
			throw new YFCException("EXTN_CONNECT", "Unknown type. Connection type: " + conn.getClass().getName());
		}



		if (responseCode == 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
			String responseString =null;
			StringBuffer responseBuffer = new StringBuffer();

			while ((responseString = in.readLine()) != null) {
				responseBuffer.append(responseString);
			}
			in.close();
			response = responseBuffer.toString();

			logger.endTimer("KohlsPoCHTTPPostUtil.getDeviceProfileVHQ");
		}
		logger.debug("Response code " + responseCode + " Received from VHQ server");
		return response;
	}

	private String getDeviceProfileVHQ(Document inputDoc) {
		logger.beginTimer("KohlsPoCHTTPPostUtil.getDeviceProfileVHQ");
		// -- get Device profile REST URL
		String restUrl = getPropertyValue(_properties.getProperty("RESTURL"));

		String lookupString = getDeviceLookupString(inputDoc);

		try {

			URL restObj = new URL(null, restUrl + lookupString, new sun.net.www.protocol.https.Handler());
			if(logger.isDebugEnabled()) {
				logger.debug("restObj : " + restObj);
				logger.debug("restObj.openConnection() return type : " + restObj.openConnection().getClass().getName());
				logger.debug("@@java.protocol.handler.pkgs system property : " + System.getProperty("java.protocol.handler.pkgs"));
			}

			URLConnection newCon = restObj.openConnection();

			String response = null;
			response = getDeviceProfileResponse(newCon);

			if(!YFCCommon.isVoid(response)){
				return response;
			} else {
				throw new YFCException("Response not  Received from VHQ server");

			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
			throw new YFCException(e, "EXTN_CONNECT", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			throw new YFCException(e, "EXTN_IO", e.getMessage());
		}

	}

	public Document getDeviceprofile(YFSEnvironment env, Document inputDoc)  throws Exception
	{
		String sIPAdd = "";
		String sMACAddress = "";
		String sSerialNumber = "";

		logger.beginTimer("KohlsPoCHTTPPostUtil.getDeviceprofile");

		strtimeout = getPropertyValue(_properties.getProperty("TIMEOUT"));
		logger.debug("**************Initiating IP Lookup************");

		try {

			// call VHQ data service for Profile Information
			String strDeviceProfile = getDeviceProfileVHQ(inputDoc);

			// Retrieving Serial number and MacAddress from the Dataservice response
			logger.debug("IP Lookup Response is: " + strDeviceProfile);
			JSONObject json = new JSONObject(strDeviceProfile);


			if (json != null && !json.isEmpty()) {
				sIPAdd = (String) json.get("IPAddress");
				sMACAddress = (String) json.get("MACAddress");
				sSerialNumber = (String) json.get("SerialNumber");
			}

			//output XML for the UE
			//<VerifoneDeviceProfile  PINPadMACAddress="00:0B:4F:8A:9A:59" DeviceId="42" SerialNumber="169-026-742"  IpAddress="192.138.10.101" />

			logger.debug("sIPAdd is: " + sIPAdd + " sMACAddress is: "+ sMACAddress + " and sSerialNumber is: "+ sSerialNumber);
			Document docOutputUE = YFCDocument.createDocument("VerifoneDeviceProfile").getDocument();
			Element eleRootOutDoc = docOutputUE.getDocumentElement();
			eleRootOutDoc.setAttribute("PINPadMACAddress", sMACAddress);
			eleRootOutDoc.setAttribute("DeviceId", "");
			eleRootOutDoc.setAttribute("SerialNumber", sSerialNumber);
			eleRootOutDoc.setAttribute("IpAddress", sIPAdd);

			logger.endTimer("KohlsPoCHTTPPostUtil.getDeviceprofile");
			return docOutputUE;


		} catch (JSONException e) {
			logger.endTimer("KohlsPoCHTTPPostUtil.getDeviceprofile");
			e.printStackTrace();
			throw new YFCException("EXTN_OTHER", e.getMessage());
		}
	}



	public static String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		// customer_overrides.properties does not return any value
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		return propValue;

	}

	public void setProperties(Properties prop) throws Exception {
		_properties = prop;
	}

	// Read username, password from CustomerOverrides properties file
	private void loadProperties() throws IOException {
		logger.beginTimer("KohlsPoCHTTPPostUtil.loadProperties");
		InputStream inVHQ = null;

		// Loading the authentication file into the memory
		String strAuthFileLoc = getPropertyValue(_properties.getProperty("FILELOC")) + "/" + getPropertyValue(_properties.getProperty("FILENAME"));
		logger.debug("Authentication file Location is: " + strAuthFileLoc);

		try {
			File file = new File(strAuthFileLoc);
			inVHQ = new FileInputStream(file);
			logger.debug("**************LOADED PROPERTY FILE::" + inVHQ.toString());
			Properties propVHQ = new Properties();
			propVHQ.load(inVHQ);
			// logger.debug("**************LOADED PROPERTY FILE::" + propVHQ);
			strAuthUsername = (String) propVHQ.get("VHQ_USER_ID");
			strAuthPassword = (String) propVHQ.get("VHQ_USER_PASSWORD");
		} catch (Exception e) {
			e.getStackTrace();
			logger.debug("VHQ AUTH: Failed to retrieve username/password from credential file. Username or password is null or empty.");
			throw new YFCException(e, "Failed to retrieve username/password from credential file", e.getMessage());
		} 
		finally {
			inVHQ.close();
		}
		logger.endTimer("KohlsPoCHTTPPostUtil.loadProperties");
	}

}