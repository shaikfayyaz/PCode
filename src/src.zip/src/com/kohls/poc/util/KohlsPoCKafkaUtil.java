package com.kohls.poc.util;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsPmdmDataOutJson;
import com.kohls.wsauth.repackaged.apache.commons.codec.binary.Base64;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Created by tkma36l on 3/10/21.
 */
public class KohlsPoCKafkaUtil {

    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCKafkaUtil.class);


    private final String TOPIC;
    private final String BOOTSTRAP_SERVERS;
    private final String SESSION_TIMEOUT;
    private final String REQUEST_TIMEOUT;
    private final String RESET_STRATEGY;
    private final String GROUP_ID;
    private final String RETRY_THRESHOLD;
    private final String POLL_INTERVAL;
    private final String SECURITY_PROTOCOL;
    private final String SECURITY_PROTOCOL_VERSION;
    private final String KAFKA_TRUST_STORE;
    private final String KAFKA_TRUST_STORE_PWD;

    private final String KAFKA_SASL_MECHANISM;
    private final String KAFKA_SASL_JAAS_CONFIG;
    private final String KAFKA_SASL_USER;
    private final String KAFKA_SASL_PWD;


    private final String KAFKA_KEY_DESERIALIZER_CLASS = LongDeserializer.class.getName();
    private final String KAFKA_VALUE_DESERIALIZER_CLASS = StringDeserializer.class.getName();
    private Properties props;

    private String processName;

    public KohlsPoCKafkaUtil(String processName) {

        this.processName = processName;
        this.TOPIC = YFSSystem.getProperty(processName + "_KAFKA_TOPIC");
        this.BOOTSTRAP_SERVERS = YFSSystem.getProperty(processName + "_KAFKA_BOOTSTRAP_SERVERS");
        this.SESSION_TIMEOUT = YFSSystem.getProperty(processName + "_KAFKA_SESSION_TIMEOUT");
        this.REQUEST_TIMEOUT = YFSSystem.getProperty(processName + "_KAFKA_REQUEST_TIMEOUT");
        this.RESET_STRATEGY = YFSSystem.getProperty(processName + "_KAFKA_RESET_STRATEGY");
        this.GROUP_ID = YFSSystem.getProperty(processName + "_KAFKA_GROUPID");
        this.RETRY_THRESHOLD = YFSSystem.getProperty(processName + "_KAFKA_RETRY_ATTEMPTS");
        this.POLL_INTERVAL = YFSSystem.getProperty(processName + "_KAFKA_POLL_INTERVAL");
        this.SECURITY_PROTOCOL = YFSSystem.getProperty(processName + "_KAFKA_SECURITY_PROTOCOL");
        this.SECURITY_PROTOCOL_VERSION = YFSSystem.getProperty(processName + "_KAFKA_SECURITY_PROTOCOL_VERSION");
        this.KAFKA_TRUST_STORE = YFSSystem.getProperty(processName + "_KAFKA_TRUST_STORE");
        this.KAFKA_TRUST_STORE_PWD = new String(Base64.decodeBase64(
                YFSSystem.getProperty(processName + "_KAFKA_TRUST_STORE_PWD")));

        this.KAFKA_SASL_MECHANISM = YFSSystem.getProperty(processName + "_KAFKA_SASL_MECHANISM");
        this.KAFKA_SASL_JAAS_CONFIG = YFSSystem.getProperty(processName + "_KAFKA_SASL_JAAS_CONFIG");
        this.KAFKA_SASL_USER = YFSSystem.getProperty(processName + "_KAFKA_SASL_SASL_USER");
        this.KAFKA_SASL_PWD = YFSSystem.getProperty(processName + "_KAFKA_SASL_PWD");


//        this.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM = YFSSystem.getProperty(processName + "_KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM");

    }

    public List<Document> runConsumer(String feedType) {

        // get the PMDM properties from customer_override.properties
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, KAFKA_KEY_DESERIALIZER_CLASS);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KAFKA_VALUE_DESERIALIZER_CLASS);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, RESET_STRATEGY);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, SESSION_TIMEOUT);
        props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, REQUEST_TIMEOUT);

        props.put("ssl.enable", "true");
        props.put("ssl.endpoint.identification.algorithm", "");

        props.put("security.protocol", SECURITY_PROTOCOL);
        props.put("security.protocol.version", SECURITY_PROTOCOL_VERSION);

        props.put("ssl.truststore.location", KAFKA_TRUST_STORE);
        props.put("ssl.truststore.password", KAFKA_TRUST_STORE_PWD);


        if (!XMLUtil.isVoid(KAFKA_SASL_MECHANISM))
            props.put("sasl.mechanism", KAFKA_SASL_MECHANISM); // SCRAM-SHA-256 / SCRAM-SHA-512
        if (!XMLUtil.isVoid(KAFKA_SASL_JAAS_CONFIG))
            props.put("sasl.jaas.config", KAFKA_SASL_JAAS_CONFIG); // org.apache.kafka.common.security.scram.ScramLoginModule required

        if (!XMLUtil.isVoid(KAFKA_SASL_USER))
            props.put("username", KAFKA_SASL_USER);
        if (!XMLUtil.isVoid(KAFKA_SASL_PWD))
            props.put("password", KAFKA_SASL_PWD);


        // Consumer to subscribe to Topic and to poll the messages
        final Consumer<Long, String> consumer = new KafkaConsumer<>(props);

        // create list of documents to return
        List<Document> altSkuDataListResponse = new ArrayList<>();

        if ("AlternateSkuDataLoad".equals(processName)) {
            logger.debug("Starting Kafka Process Name: " + processName);
            runAlternateSkuDataLoad(consumer, altSkuDataListResponse, feedType);
        }

        return altSkuDataListResponse;
    }


    private void runAlternateSkuDataLoad(Consumer<Long, String> consumer, List<Document> altSkuDataListResponse,
                                         String feedType) {

        // Decide whether to go for full vs delta feed
        if ("DELTA".equals(feedType)) {
            //delta feed
            logger.debug("Performing PMDM duplicate upc DELTA feed");
            consumer.subscribe(Arrays.asList(TOPIC));
        } else {
            //full feed - Available Data in the topic from the beginning
            logger.debug("Performing PMDM duplicate upc Full feed");
            consumer.subscribe(Arrays.asList(TOPIC), new KohlsPoCKafkaResetRebalancer(consumer));
        }

        logger.debug("Begin polling for PMDM duplicate upc records");
        for (int i = 0; i < 10000; i++) {

            final ConsumerRecords<Long, String> consumerRecords = consumer.poll(Integer.parseInt(POLL_INTERVAL));

            if (consumerRecords.count() == 0) {
                logger.debug("No more consumer records.  Looped " + i + " times.");
                break;
            }
            logger.debug("Retrieved " + consumerRecords.count() + " records from kafka.");

            Document entriesDoc = SCXmlUtil.createDocument(KohlsPOCConstant.ALT_SKU_DATA_LIST);

            for (ConsumerRecord<Long, String> record : consumerRecords) {
                this.addElement(entriesDoc, record.value());
            }

            altSkuDataListResponse.add(entriesDoc);
        }
        consumer.commitAsync();
    }

    /**
     * @param inputDoc
     * @param jsonData
     */
    private void addElement(Document inputDoc, String jsonData) {

        try {

            Element entries = inputDoc.getDocumentElement();
            Element altSkuRecord = inputDoc.createElement("AltSkuMap");

            Gson outGson = new Gson();
            KohlsPmdmDataOutJson parsedData = outGson.fromJson(jsonData, KohlsPmdmDataOutJson.class);

            altSkuRecord.setAttribute(KohlsPOCConstant.A_SKUNBR, parsedData.skuNumber);
            altSkuRecord.setAttribute(KohlsPOCConstant.A_VENDOR_UPC_NBR, parsedData.upcNumber);

            entries.appendChild(altSkuRecord);
        } catch (JsonSyntaxException e) {
            logger.error("Json parse exception for the record - " + jsonData);
        }
    }
}
