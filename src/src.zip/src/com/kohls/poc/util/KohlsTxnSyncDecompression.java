package com.kohls.poc.util;

import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

/** 
 * @author Yantriks This document has been prepared and written by Yantriks on
 *         behalf of Kohls, and is copyright of Kohls
 */
public class KohlsTxnSyncDecompression implements YIFCustomApi {

	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsTxnSyncDecompression.class.getName());
	
    
	/** 
     * @param env
     * @param inDoc
     * @return outDocApi
     * @throws Exception
     */
	public Document blobDecompresser(YFSEnvironment env, Document inDoc) throws Exception {
	String CompressedInput = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.COMPRESSED_BLOB);
	String strDecompressedXML = KohlsReprocessRequestUtil.decompressXML(CompressedInput);
	Document decompressedBlobDocument = SCXmlUtil.createFromString(strDecompressedXML);
	String strApiName = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_API_NAME);
		NodeList nodeList = inDoc.getElementsByTagName(KohlsPOCConstant.TRX_SYNC_DETAILS);
		if (nodeList.getLength() > 0) {
			log.info(
					"Transaction sync CORP monitoring details : " + SCXmlUtil.getString(((Element) nodeList.item(0))));
		}
	//String uniqueID = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_UNIQUE_ID);
	//log.info("Operation and Unique Ids are  " + strApiName + ", " + uniqueID);
	//getNextTransaction sequence number 
	env.setTxnObject("OFFLINE_TRXN_SYNC", true);
	Document outDocApi = KohlsCommonUtil.invokeAPI(env, strApiName, decompressedBlobDocument);
	return outDocApi;
	}

	/**
	 * 
	 */
	@Override
	public void setProperties(Properties arg0) throws Exception {
	}

}
