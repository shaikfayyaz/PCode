/*
 * File: KohlsPoCManagePropertyValues.java  Created on Jul 26, 2018 for POC_OMS_IBM_Returns by mrjoshi
 *
 * COPYRIGHT:
 * LICENSED MATERIALS - PROPERTY OF Kohls Stores
 * "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason  		Date     		Who Descriptions
 * ------- 		-------- 		--- -----------
 */
package com.kohls.poc.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.util.webserviceUtil.FailoverUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author mrjoshi
 *
 */
public class KohlsPoCManagePropertyValues {
  
  private static YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCManagePropertyValues.class);
  FailoverUtil fs = FailoverUtil.getInstance();
  
  /**
   * Create By mrjoshi * 
   * @param env
   * @param docInXML
   * @return
   * @throws ClassNotFoundException
   * @throws NoSuchFieldException
   * @throws SecurityException
   * @throws NoSuchMethodException
   * @throws IllegalAccessException
   * @throws IllegalArgumentException
   * @throws InvocationTargetException
   * @throws InstantiationException
   */
  public Document getPropertyValue(YFSEnvironment env, Document docInXML) throws ClassNotFoundException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
    logger.beginTimer("KohlsPoCManagePropertyValues.getPropertyValue");
    Element elePropertyRoot = docInXML.getDocumentElement();
    
    /*Class<?> clazz = Class.forName(className);
    Method method = clazz.getDeclaredMethod(methodName, String.class);
    String value = (String) method.invoke(null, propertyName);
    if(YFCCommon.isVoid(value)) {
      value = "";
    }*/
    String value = fs.getWsProperties().toString();
    elePropertyRoot.setAttribute("PropertyValue", value);
    logger.endTimer("KohlsPoCManagePropertyValues.getPropertyValue");
    return docInXML;
  }
  
  /**
   * Create By mrjoshi * 
   * @param env
   * @param docInXML
   * @return
   * @throws ClassNotFoundException
   * @throws NoSuchFieldException
   * @throws SecurityException
   * @throws NoSuchMethodException
   * @throws IllegalAccessException
   * @throws IllegalArgumentException
   * @throws InvocationTargetException
   * @throws InstantiationException
   */
  public Document manageProperyValue (YFSEnvironment env, Document docInXML) throws ClassNotFoundException, NoSuchFieldException, SecurityException, NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
    logger.beginTimer("KohlsPoCManagePropertyValues.manageProperyValue");
    Element elePropertyRoot = docInXML.getDocumentElement();
    String propertyName = elePropertyRoot.getAttribute("PropertyName");
    String propertyValue = elePropertyRoot.getAttribute("PropertyValue");
    String className = elePropertyRoot.getAttribute("ClassName");
    String methodName = elePropertyRoot.getAttribute("MethodName");
    if(YFCCommon.isVoid(propertyName)) {
      throw new YFSException("PropertyName cannot be empty");
    }
    if(YFCCommon.isVoid(propertyValue)) {
      throw new YFSException("PropertyValue cannot be empty");
    }
    if(YFCCommon.isVoid(className)) {
      throw new YFSException("ClassName cannot be empty");
    }
    if(YFCCommon.isVoid(methodName)) {
      throw new YFSException("MethodName cannot be empty");
    }
    Class<?> clazz = Class.forName(className);
    Method method = clazz.getMethod(methodName, String.class, String.class);
    method.invoke(clazz.newInstance(), propertyName, propertyValue);
    elePropertyRoot.setAttribute("PropertyUpdate", "Success");
    logger.endTimer("KohlsPoCManagePropertyValues.manageProperyValue");
    return docInXML;
  }

}
