package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCDTUtil extends KOHLSBaseApi {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsCDTUtil.class.getName());
	public static final String BUILD_PROPERTIES_PATH = "BUILD_PROPERTIES_PATH";
	public static final String ENV_SOURCE_DB = "env.SOURCE_DB";
	public static final String ENV_SOURCE_PASSWORD = "env.SOURCE_PASSWORD";
	public static final String ENV_TARGET_DB = "env.TARGET_DB";
	public static final String ENV_TARGET_PASSWORD = "env.TARGET_PASSWORD";
	public static final String ENV_SOURCE_DB_2 = "env.SOURCE_DB_2";
	public static final String ENV_SOURCE_PASSWORD_2 = "env.SOURCE_PASSWORD_2";
	public static final String ENV_TARGET_DB_2 = "env.TARGET_DB_2";
	public static final String ENV_TARGET_PASSWORD_2 = "env.TARGET_PASSWORD_2";
	public static final String CDT_XML_ZIP_FILE = "CDTXmls";
	public static final String ISS_DATADUMP_IMPORT_DIRECTORY = "ISS_DATADUMP_IMPORT_DIRECTORY";
	public static final String ISS_DATADUMP_EXPORT_DIRECTORY = "ISS_DATADUMP_EXPORT_DIRECTORY";
	public static final String ISS_DATADUMP_IMPORT_DONEDIR = "ISS_DATADUMP_IMPORT_DONEDIR";
	public static final String ISS_DATADUMP_EXPORT_DONEDIR = "ISS_DATADUMP_EXPORT_DONEDIR";
	public static final String ISS_DATADUMP_DELTA_IMPORT_DIRECTORY = "ISS_DATADUMP_DELTA_IMPORT_DIRECTORY";
	public static final String ISS_DATADUMP_DELTA_EXPORT_DIRECTORY = "ISS_DATADUMP_DELTA_EXPORT_DIRECTORY";
	public static final String ISS_DATADUMP_DELTA_IMPORT_DONEDIR = "ISS_DATADUMP_DELTA_IMPORT_DONEDIR";
	public static final String ISS_DATADUMP_DELTA_EXPORT_DONEDIR = "ISS_DATADUMP_DELTA_EXPORT_DONEDIR";
	public static final String DEFAULT_TARGET = "MasterConfigCDTXMLTarget_POC";
	public static final String DEFAULT_SOURCE = "MasterConfigCDTXML_POC";
	public static final String PASSWORD = "password";
	public static final String SOURCE_DATABASE = "SourceDatabase";
	public static final String TARGET_DATABASE = "TargetDatabase";
	public static final String CONFIGSYNCH = "configsynch";
	public static final String SOURCE_TARGET_PREFS = "SourceTargetPrefs";
	public static final String SOURCE_TARGET_PAIR = "SourceTargetPair";
	public static final String CDT_META_XML="cdt_metadata.xml";

	/*
	 * Delete the existing CDT files and extract new CDT files from Corp database 
	 */
	public Document exportCDT(YFSEnvironment env, Document inputDoc) throws Exception {
		String sSourcePassword = getSourcePassword(env);
		String sCDTTargetPath = getCDTFilesPath(TARGET_DATABASE);
		checkIfSourceDatabaseEntryExistsInYDKPrefs(KohlsPOCConstant.A_EXPORT);
		log.info("CDT Target Path is " + sCDTTargetPath);
		final String cdtExportCommand = constructCDTCommand(env, ENV_TARGET_DB_2, sSourcePassword, DEFAULT_TARGET, "",
				KohlsPOCConstant.A_EXPORT);
		try {
			log.info("Deleting the CDT files present under " + sCDTTargetPath);
			deleteCDTFiles(sCDTTargetPath);			
			String zipFile = "";
			if (SCXmlUtil.getString(inputDoc).contains(KohlsPOCConstant.DB_DELTA_EXPORT)) {
				log.info("Extracting the CDT for delta");
				zipFile = YFSSystem.getProperty(ISS_DATADUMP_DELTA_EXPORT_DONEDIR) + KohlsPOCConstant.BACKWARD_SLASH
						+ CDT_XML_ZIP_FILE + KohlsPOCConstant.DOT + KohlsPOCConstant.ZIP;
				String strCDTOutputPath = YFSSystem.getProperty(ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
						+ KohlsPOCConstant.BACKWARD_SLASH + CDT_XML_ZIP_FILE + KohlsPOCConstant.UNDERSCORE
						+ KohlsPOCConstant.A_EXPORT + KohlsPOCConstant.DOT_LOG;
				executeCommand(cdtExportCommand, strCDTOutputPath, KohlsPOCConstant.A_EXPORT);
				createZipAndMove(sCDTTargetPath,zipFile);
			}else{
				log.info("Extracting the CDT for full");
				zipFile = YFSSystem.getProperty(ISS_DATADUMP_EXPORT_DONEDIR) + KohlsPOCConstant.BACKWARD_SLASH
						+ CDT_XML_ZIP_FILE + KohlsPOCConstant.DOT + KohlsPOCConstant.ZIP;
				String strCDTOutputPath = YFSSystem.getProperty(ISS_DATADUMP_EXPORT_DONEDIR)
						+ KohlsPOCConstant.BACKWARD_SLASH + CDT_XML_ZIP_FILE + KohlsPOCConstant.UNDERSCORE
						+ KohlsPOCConstant.A_EXPORT + KohlsPOCConstant.DOT_LOG;			
				executeCommand(cdtExportCommand, strCDTOutputPath, KohlsPOCConstant.A_EXPORT);
				createZipAndMove(sCDTTargetPath, zipFile);
			}
			
			// deleteFiles(sCDTTargetPath);
		} catch (Exception e) {
			log.error("Error in exporting CDT XMLs");
			throw e;
		}
		return null;
	}

	/*
	 *  Checks the source and target pair exists in ydkpref.xml file, it not it will
	 *  create it
	 */
	private void checkIfSourceDatabaseEntryExistsInYDKPrefs(String aExport) throws Exception {
		log.info("Checking the Database entry in the YDK pref file");
		File ydkPrefsFile = new File(KohlsPOCConstant.YDK_PREFS_FILE_PATH);
		Document docYDKPrefsFile;
		try {
			docYDKPrefsFile = SCXmlUtil.getDocumentBuilder().parse(ydkPrefsFile);
		} catch (Exception e) {
			log.error("Error in loading ydkprefs file");
			throw e;
		}
		Element elePreferences = docYDKPrefsFile.getDocumentElement();
		Element eleConfigsynch = SCXmlUtil.getChildElement(elePreferences, CONFIGSYNCH);

		Element eleSourceDatabases = null, eleTargetDatabases = null;
		eleSourceDatabases = SCXmlUtil.getChildElement(eleConfigsynch, KohlsPOCConstant.SOURCE_DATABASES);
		eleTargetDatabases = SCXmlUtil.getChildElement(eleConfigsynch, KohlsPOCConstant.TARGET_DATABASES);
		ArrayList<Element> targetDBArrayList = SCXmlUtil.getChildren(eleTargetDatabases, KohlsPOCConstant.A_DATABASE);
		ArrayList<Element> sourceDBArrayList = SCXmlUtil.getChildren(eleSourceDatabases, KohlsPOCConstant.A_DATABASE);
		Properties BuildProperties;
		try {
			BuildProperties = loadPropertiesFromAbsoluteLocation(KohlsPOCConstant.BUILD_PROPERTIES_PATH);
		} catch (Exception e) {
			log.error("Error while loading build.properties file");
			throw new YFCException("Error while loading build.properties file");
		}
		String sSourceDB = BuildProperties.getProperty(ENV_TARGET_DB_2);

		for (Element eleDatabase : sourceDBArrayList) {
			if (eleDatabase.getAttribute(KohlsPOCConstant.A_NAME).equals(sSourceDB)) {
				return;
			}
		}
		Element eleConstructedSourceDBEle = null;
		if (KohlsPOCConstant.A_EXPORT.equals(aExport)) {

			for (Element eleDatabase : targetDBArrayList) {
				if (eleDatabase.getAttribute(KohlsPOCConstant.A_NAME).equals(sSourceDB)) {
					eleConstructedSourceDBEle = SCXmlUtil.getCopy(eleDatabase);
				}
			}
		}
		log.info("Appending the target and source pair in ydkpref.xml");
		SCXmlUtil.importElement(eleSourceDatabases, eleConstructedSourceDBEle);
		FileWriter writer = new FileWriter(KohlsPOCConstant.YDK_PREFS_FILE_PATH);
		writer.write(SCXmlUtil.getString(docYDKPrefsFile));
		writer.close();
	}

	/*
	 * 
	*/
	private String getCDTFilesPath(String dbType) throws Exception {
		File ydkPrefsFile = new File(KohlsPOCConstant.YDK_PREFS_FILE_PATH);
		try {
			Document docYDKPrefsFile = SCXmlUtil.getDocumentBuilder().parse(ydkPrefsFile);
			Element elePreferences = docYDKPrefsFile.getDocumentElement();
			Element eleConfigsynch = SCXmlUtil.getChildElement(elePreferences, CONFIGSYNCH);

			Element eleSourceOrTargetDatabases = null;
			if (TARGET_DATABASE.equals(dbType)) {
				eleSourceOrTargetDatabases = SCXmlUtil.getChildElement(eleConfigsynch,
						KohlsPOCConstant.TARGET_DATABASES);
			} else if (SOURCE_DATABASE.equals(dbType)) {
				eleSourceOrTargetDatabases = SCXmlUtil.getChildElement(eleConfigsynch,
						KohlsPOCConstant.SOURCE_DATABASES);
			}
			ArrayList<Element> databaseArrayList = SCXmlUtil.getChildren(eleSourceOrTargetDatabases,
					KohlsPOCConstant.A_DATABASE);
			for (Element eleDatabase : databaseArrayList) {
				log.info("Current source eleDatabase " + SCXmlUtil.getString(eleDatabase));
				log.info("SOURCE_DATABASE " + SOURCE_DATABASE);
				log.info("dbType " + dbType);
				log.info("DEFAULT_SOURCE " + DEFAULT_SOURCE);
				log.info("Source Database is " + eleDatabase.getAttribute(KohlsPOCConstant.A_NAME));
				if (TARGET_DATABASE.equals(dbType)
						&& DEFAULT_TARGET.equals(eleDatabase.getAttribute(KohlsPOCConstant.A_NAME))) {
					File f = new File(eleDatabase.getAttribute(KohlsPOCConstant.FOLDER));
					if (!f.exists()) {
						new File(eleDatabase.getAttribute(KohlsPOCConstant.FOLDER)).mkdirs();
						log.info("New folder created " + eleDatabase.getAttribute(KohlsPOCConstant.FOLDER));
					}
					return eleDatabase.getAttribute(KohlsPOCConstant.FOLDER);
				}
				if (SOURCE_DATABASE.equals(dbType)
						&& DEFAULT_SOURCE.equals(eleDatabase.getAttribute(KohlsPOCConstant.A_NAME))) {
					File f = new File(eleDatabase.getAttribute(KohlsPOCConstant.FOLDER));
					if (!f.exists()) {
						new File(eleDatabase.getAttribute(KohlsPOCConstant.FOLDER)).mkdirs();
						log.info("New folder created " + eleDatabase.getAttribute(KohlsPOCConstant.FOLDER));
					}
					return eleDatabase.getAttribute(KohlsPOCConstant.FOLDER);
				}
			}

		} catch (Exception e) {
			log.error("Error in converting ydkPrefsFile to DOM object.");
			throw e;
		}
		return "";
	}

	/*
	 * 
	 */
	private void updateYDKPrefs(String sSourceDB, String sTargetDB) throws Exception {
		log.info("Input arguments are :" );
		log.info("sSourceDB " + sSourceDB);
		log.info("sTargetDB " + sTargetDB);
		File ydkPrefsFile = null;
		Boolean sourceTargetPairExists = false, sourceTargetReversalExists = false;
		Element eleCorrectedReversal = null;
		Document docYDKPrefsFile;
		String strSourceDatabase = "";
		ydkPrefsFile = new File(KohlsPOCConstant.YDK_PREFS_FILE_PATH);
		try {
			docYDKPrefsFile = SCXmlUtil.getDocumentBuilder().parse(ydkPrefsFile);
		} catch (Exception e) {
			log.error("Error in converting ydkPrefsFile to DOM object.");
			throw e;
		}
		if (!YFCCommon.isVoid(docYDKPrefsFile)) {
			Element elePreferences = docYDKPrefsFile.getDocumentElement();
			Element eleConfigsynch = SCXmlUtil.getChildElement(elePreferences, CONFIGSYNCH);
			Element eleSourceTargetPrefs = SCXmlUtil.getChildElement(eleConfigsynch, SOURCE_TARGET_PREFS);
			Element eleSourceTargetPrefs2 = SCXmlUtil.getChildElement(eleSourceTargetPrefs, SOURCE_TARGET_PREFS);
			ArrayList<Element> sourceTargetPairList = SCXmlUtil.getChildren(eleSourceTargetPrefs2, SOURCE_TARGET_PAIR);
			for (Element eleSourceTargetPair : sourceTargetPairList) {
				strSourceDatabase = eleSourceTargetPair.getAttribute(SOURCE_DATABASE);
				if (YFCCommon.equals(sSourceDB, strSourceDatabase)) {
					String strTargetDatabase = eleSourceTargetPair.getAttribute(TARGET_DATABASE);
					if (YFCCommon.equals(sTargetDB, strTargetDatabase)) {
						sourceTargetPairExists = true;
					}
				}

				if (sourceTargetPairExists) {
					return;
				}
			}
			log.info("Expected pair does not exist. So iterating to check if reversal exists.");
			for (Element eleSourceTargetPair : sourceTargetPairList) {
				strSourceDatabase = eleSourceTargetPair.getAttribute(SOURCE_DATABASE);
				log.info("Iterating again for reversal.");
				log.info("sSourceDB " + sSourceDB);
				log.info("strSourceDatabase is " + strSourceDatabase);
					String strTargetDatabase = eleSourceTargetPair.getAttribute(TARGET_DATABASE);
					if(YFCCommon.equals(sSourceDB,strTargetDatabase)){
						log.info("strTargetDatabase " + strTargetDatabase);
						sourceTargetReversalExists = true;
						log.debug("Correcting reversal element.");
						eleCorrectedReversal = SCXmlUtil.getCopy(eleSourceTargetPair);
						eleCorrectedReversal.setAttribute(SOURCE_DATABASE, sSourceDB);
						eleCorrectedReversal.setAttribute(TARGET_DATABASE, sTargetDB);
						break;
				}
			}

			if (!sourceTargetPairExists && sourceTargetReversalExists) {
				SCXmlUtil.importElement(eleSourceTargetPrefs2, eleCorrectedReversal);
				FileWriter writer = new FileWriter(KohlsPOCConstant.YDK_PREFS_FILE_PATH);
				writer.write(SCXmlUtil.getString(docYDKPrefsFile));
				writer.close();
			}
		}

	}

	/*
	 * Delete the previous CDT files
	 */
	private void deleteCDTFiles(String cdtFilesPath) {
		File f = null;
		File[] paths = null;
		try {
			log.info("Deleting the files if exits under " + cdtFilesPath);
			f = new File(cdtFilesPath);
			paths = f.listFiles();
			if (paths != null) {
				for (File path : paths) {
					log.debug("File being deleted " + path);
					path.delete();
				}
			}
		} catch (Exception e) {
			log.error("Error in deleting existing CDT files" + e);
			throw new YFCException("Error in deleteExistingCDTFiles");
		}
	}

	/*
	 * Creates the Zip file and move to Done directory
	 */
	private void createZipAndMove(String sCDTTargetPath, String zipFile) throws Exception {
		String srcDir = sCDTTargetPath + KohlsPOCConstant.BACKWARD_SLASH;
		log.info("Source path is" + srcDir + " and Zip file path location is " + zipFile);
		File cdtTargetFiles = new File(sCDTTargetPath);
		int j = 0;
		String targetFile = "";
		for (File cdtTargetFile : cdtTargetFiles.listFiles()) {
			if (cdtTargetFile.exists()) {
				targetFile = cdtTargetFile.getName();
				log.debug("Checking the cdt file entry " + targetFile);
				if (cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_BASE_RULES)
						|| cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_NODE_TYPE)
						|| cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_SUB_FLOW)
						|| cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_SHIPPING_PREFERENCE)
						|| cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_ITEM_NODE_DEFN)
						|| cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_PERSON_INFO)
						|| cdtTargetFile.getName().contains(KohlsPOCConstant.YFS_ATP_RULES)) {
					++j;
					log.info("Checking the cdt file entry " + targetFile);
				}
			}
		}
		log.info("Value of j is " + j);
		if (j != 7) { 		
			throw new YFCException("CDT_FILE_ENTRIES", " CDT contains missing file " + srcDir);
		}
		
		log.info("Creating zip and moving to done directory");
		byte[] buffer = new byte[1024];
		FileOutputStream fos = new FileOutputStream(zipFile);
		ZipOutputStream zos = new ZipOutputStream(fos);
		File dir = new File(srcDir);
		File[] files = dir.listFiles();
		if (files.length > 0) {
			for (int i = 0; i < files.length; i++) {
				log.debug("Adding file to cdt zip " + files[i].getName());
				FileInputStream fis = new FileInputStream(files[i]);
				zos.putNextEntry(new ZipEntry(files[i].getName()));
				int length;
				while ((length = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, length);
				}
				zos.closeEntry();
				fis.close();
			}
		}
		zos.close();
	}

	
	/*
	 * Importing the CDT to the target DB, updated the dmpFilePath as argument
	 */
	public Document importCDT(YFSEnvironment env, Document inputDoc, File dmpFilePath) throws Exception {
		log.info("Entered import cdt ");		
		String sCDTSourcePath = getCDTFilesPath(SOURCE_DATABASE);
		String cdtZipFile = "";
		String zipFilePath = "";
		String cdtToDoneDir = "";

		if(SCXmlUtil.getString(inputDoc).contains(KohlsPOCConstant.DB_DELTA_IMPORT)){			
			zipFilePath = dmpFilePath.getAbsolutePath()	+ KohlsPOCConstant.BACKWARD_SLASH
					+ CDT_XML_ZIP_FILE + KohlsPOCConstant.DOT + KohlsPOCConstant.ZIP;	
			log.info("Calling the DELTA CDT" + zipFilePath);
		}else{
			 cdtZipFile = YFSSystem.getProperty(ISS_DATADUMP_IMPORT_DIRECTORY) + KohlsPOCConstant.BACKWARD_SLASH
						+ CDT_XML_ZIP_FILE + KohlsPOCConstant.DOT + KohlsPOCConstant.ZIP;
			 zipFilePath = YFSSystem.getProperty(ISS_DATADUMP_IMPORT_DIRECTORY) + KohlsPOCConstant.BACKWARD_SLASH
							+ CDT_XML_ZIP_FILE + KohlsPOCConstant.DOT + KohlsPOCConstant.ZIP;
			 cdtToDoneDir = YFSSystem.getProperty(ISS_DATADUMP_IMPORT_DONEDIR) + KohlsPOCConstant.BACKWARD_SLASH;
		}
		
		final String command = constructCDTCommand(env, ENV_SOURCE_DB_2, ENV_SOURCE_PASSWORD_2, ENV_TARGET_DB_2,
				ENV_TARGET_PASSWORD_2, KohlsPOCConstant.A_IMPORT);
		try {
			log.debug("Deleting the CDT files present under " + sCDTSourcePath);
			deleteCDTFiles(sCDTSourcePath);
			log.info("Moving the CDT files to " + sCDTSourcePath);
			moveCDTZipAndUnzip(sCDTSourcePath, zipFilePath);			
			KohlsDeltaDataPump deltaPump = new KohlsDeltaDataPump();

			if (SCXmlUtil.getString(inputDoc).contains(KohlsPOCConstant.DB_DELTA_IMPORT)) {
				log.info("Deleting delta cdt zip files");
				executeCommand(command,
						dmpFilePath.getAbsolutePath() + KohlsPOCConstant.BACKWARD_SLASH + CDT_XML_ZIP_FILE
								+ KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.A_IMPORT + KohlsPOCConstant.DOT_LOG, KohlsPOCConstant.A_IMPORT); // TODO Need
				File donePath = deltaPump.findDoneDir(dmpFilePath.getAbsolutePath());
				deltaPump.filterFiles(dmpFilePath, donePath, CDT_XML_ZIP_FILE);
			} else {				
				executeCommand(command,
						YFSSystem.getProperty(ISS_DATADUMP_IMPORT_DIRECTORY) + KohlsPOCConstant.BACKWARD_SLASH
								+ CDT_XML_ZIP_FILE + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.A_IMPORT
								+ KohlsPOCConstant.DOT_LOG, KohlsPOCConstant.A_IMPORT);				
				log.info("Deleting full cdt zip files");
				File cdtPath = new File(YFSSystem.getProperty(ISS_DATADUMP_IMPORT_DIRECTORY));
				deltaPump.filterFiles(cdtPath, new File(cdtToDoneDir), CDT_XML_ZIP_FILE);
				
				/*File oldFile = new File(cdtZipFile);
				if (oldFile.renameTo(new File(cdtToDoneDir + oldFile.getName()))) {
					log.info(oldFile.getName() + " file moved successfully to " + cdtToDoneDir);
				} else {
					log.error("Unable to move to " + cdtToDoneDir + oldFile.getName());
				}*/
			}
		} catch (Exception e) {
			log.error("Error in importing CDT XMLs \n" + e);
			throw new YFCException("Error in importing CDT XMLs");
		}
		return null;
	}

	/*
	 * Unzipping the CDT zip files to source location
	 */
	private void moveCDTZipAndUnzip(String sCDTSourcePath, String zipFilePath) throws IOException {		
		String destDir = sCDTSourcePath + KohlsPOCConstant.BACKWARD_SLASH;
		log.info("Source zip path is " + zipFilePath + " and Destination path is " + destDir);		
		File cdtMetaXml = new File(destDir + CDT_META_XML);
		File dir = new File(destDir);
		if (!dir.exists())
			dir.mkdirs();
		byte[] buffer = new byte[1024];
		FileInputStream fis;
		try {
			fis = new FileInputStream(zipFilePath);
			ZipInputStream zis = new ZipInputStream(fis);
			ZipEntry ze = zis.getNextEntry();
			log.info("Unzipping the zip file : " + zipFilePath);
			while (ze != null) {
				String fileName = ze.getName();				
				File newFile = new File(destDir + File.separator + fileName);
				log.debug("Unzipping to " + newFile.getAbsolutePath());
				new File(newFile.getParent()).mkdirs();
				FileOutputStream fos = new FileOutputStream(newFile);
				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}
				fos.close();
				zis.closeEntry();
				ze = zis.getNextEntry();
			}
			zis.closeEntry();
			zis.close();
			fis.close();
			if(cdtMetaXml.exists()){
				log.info("Deleting the " + destDir + CDT_META_XML + " file " );
				cdtMetaXml.delete();
			}
				} catch (IOException e) {
			log.error("Error in unzipping " + e);
			throw e;
		}
	}

	
	/*
	 * Constructing the CDT command
	 */
	private String constructCDTCommand(YFSEnvironment env, String sourceDB, String sourcePassword, String sTargetDB,
			String sTargetPassword, String sAction) throws Exception {
		Properties BuildProperties;
		String sSourceDB = "";
		String command = "";
		log.info("Build properties path is " + KohlsPOCConstant.BUILD_PROPERTIES_PATH);
		try {
			BuildProperties = loadPropertiesFromAbsoluteLocation(KohlsPOCConstant.BUILD_PROPERTIES_PATH);
		} catch (Exception e) {
			log.error("Error while loading build.properties file.");
			throw new YFCException("Error while loading build.properties file.");
		}

		if (KohlsPOCConstant.A_EXPORT.equals(sAction)) {
			sSourceDB = BuildProperties.getProperty(sourceDB);
			sourcePassword = getSourcePassword(env);
			log.info("sSourceDB for Export is " + sSourceDB);
			log.info("sTargetDB for Export is " + sTargetDB);
			updateYDKPrefs(sSourceDB, sTargetDB);
			command = KohlsPOCConstant.KOHLS_CDT_SHELL_PATH + " " + sSourceDB + " " + sourcePassword + " " + sTargetDB
					+ " " + sTargetPassword;
		}

		if (KohlsPOCConstant.A_IMPORT.equals(sAction)) {
			sSourceDB = BuildProperties.getProperty(sourceDB);			
			sTargetDB = BuildProperties.getProperty(sTargetDB);
			sTargetPassword = BuildProperties.getProperty(sTargetPassword);
			log.info("sSourceDB for Import is " + sSourceDB);
			log.info("sTargetDB for Import is " + sTargetDB);
			command = KohlsPOCConstant.KOHLS_CDT_SHELL_PATH + " " + sSourceDB + " " + ENV_SOURCE_DB_2 + " " + sTargetDB
					+ " " + sTargetPassword;
		}
		// log.debug("Constructed CDT Command is " + command);
		return command;
	}

	/*
	 * Getting the source password from DB
	 */
	private String getSourcePassword(YFSEnvironment env) throws Exception {
		Document docGetColonyPoolListOutput;
		log.info("Calling  callGetColonyPoolLIst");
		docGetColonyPoolListOutput = callGetColonyPoolLIst(env);
		log.info("GetColonyPoolListOutput is " + SCXmlUtil.getString(docGetColonyPoolListOutput));
		Element eleColonyPoolListOut = docGetColonyPoolListOutput.getDocumentElement();
		Element eleColonyPool = SCXmlUtil.getFirstChildElement(eleColonyPoolListOut);
		log.info("ColonyPool is " + SCXmlUtil.getString(eleColonyPool));
		String sPoolId = eleColonyPool.getAttribute(KohlsPOCConstant.A_POOL_ID);
		Properties JDBCProperties;
		String sPassword;
		try {
			JDBCProperties = loadPropertiesFromAbsoluteLocation(
					YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
			sPassword = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + PASSWORD);
			log.info("Pool id is " + sPoolId);
		} catch (Exception e) {
			log.error("Error while loading JDBC_PROPERTIES_PATH "
					+ YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
			throw e;
		}
		return sPassword;
	}

	/*
	 * Getting the colony Pool List from DB
	 */
	private Document callGetColonyPoolLIst(YFSEnvironment env) {
		Document docGetColonyPoolListOutput = null;
		try {
			Document docGetColonyPoolListInput = YFCDocument.createDocument(KohlsPOCConstant.E_COLONY_POOL)
					.getDocument();
			Element eleColonyPoolInput = docGetColonyPoolListInput.getDocumentElement();
			eleColonyPoolInput.setAttribute(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.A_CONFIGURATION);
			log.info("GetColonyPoolListInput is " + SCXmlUtil.getString(docGetColonyPoolListInput));
			docGetColonyPoolListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COLONY_POOL_LIST,
					docGetColonyPoolListInput);
		} catch (Exception e) {
			log.error("Error in callGetColonyPool " + e.getMessage() + e.getStackTrace());
			throw new YFCException("Exception in callGetColonyPoolLIst");
		}
		return docGetColonyPoolListOutput;
	}

	/**
	 * Reading Property file
	 * 
	 * @param propertyFilePath
	 * @return
	 * @throws Exception
	 */
	public Properties loadPropertiesFromAbsoluteLocation(String propertyFilePath) throws Exception {
		log.info("Input to loadPropFromAbsloc is " + propertyFilePath);
		Properties prop = new Properties();
		File file = null;
		FileReader fr = null;
		try {
			file = new File(propertyFilePath);
			log.debug("Properties file created successfully");
			fr = new FileReader(file);
			log.debug("File Reader initiated successfully");
			prop.load((Reader) fr);
		} catch (Exception e) {
			log.error("Error loading properties file " + e.getMessage() + e.getStackTrace());
			throw e;
		} finally {
			if (fr != null) {
				fr.close();
			}
			if (file != null) {
				file = null;
			}
		}
		return prop;
	}

	/*
	 * Process the CDT command
	 */
	private void executeCommand(String command, String targetLogPath, String type) throws Exception {
		FileWriter fileWtr = new FileWriter(targetLogPath);
		try {
			final Runtime r = Runtime.getRuntime();
			log.info("CDT is inProgress ...");
			Process p = r.exec(command);
			final int returnCode = p.waitFor();
			log.info("Return code is " + returnCode);
			String line1, line2;
			
			final BufferedReader is2 = new BufferedReader(new InputStreamReader(p.getErrorStream()));			
			while ((line2 = is2.readLine()) != null) {	
				Pattern pattern = null;
				if (type.equalsIgnoreCase(KohlsPOCConstant.A_EXPORT)) {
					pattern = Pattern.compile("-SourcePassword(.*?)-TargetPassword");
				} else if (type.equalsIgnoreCase(KohlsPOCConstant.A_IMPORT)) {
					pattern = Pattern.compile("-TargetPassword(.*?)-TargetHTTPPassword");
				}
				Matcher matcher = pattern.matcher(line2);
				if (matcher.find()) {
					fileWtr.write(line2.replaceAll(matcher.group(1), " ***** ") +"\n");		
					log.info("Stream2 " + line2.replaceAll(matcher.group(1), " ***** "));
				}else{
					fileWtr.write(line2 +"\n");		
					log.info("Stream2 " + line2);
				}				
				if(!line2.contains("Connection Leak") && line2.contains(KohlsPOCConstant.A_ERROR_CODE)) {
					throw new YFSException("Error during the CDT is inProgress");		 
				}
			}	
			
			final BufferedReader is = new BufferedReader(new InputStreamReader(p.getInputStream()));			
			while ((line1 = is.readLine()) != null) {
				log.info("Stream1 " + line1);
				fileWtr.write(line1 + "\n");
			}			
		} catch (IOException | InterruptedException e) {
			log.error("Exception in CDT " + e.toString());
			throw e;
		}finally{
			log.info("Closing the file writer");
			fileWtr.close();
		}
	}
}
