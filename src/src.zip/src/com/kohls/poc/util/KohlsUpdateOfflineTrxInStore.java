package com.kohls.poc.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.w3c.dom.Document;

import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSConnectionHolder;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsUpdateOfflineTrxInStore implements YIFCustomApi {

	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsUpdateOfflineTrxInStore.class.getName());

	public Document getSterlingDBConnection(YFSEnvironment env, Document inXML) throws Exception {
		PreparedStatement ps = null;
		try {
			log.info("Updating the transaction status");
			log.debug("Input to getSterlingDBConnection is " + SCXmlUtil.getString(inXML));
			String strFirstOfflineTrxKey = inXML.getDocumentElement().getAttribute("FirstOfflineTrxKey");
			String strLastOfflineTrxKey = inXML.getDocumentElement().getAttribute("LastOfflineTrxKey");

			YFSConnectionHolder connHolder = (YFSConnectionHolder) env;
			Connection oracleConnection = connHolder.getDBConnection();
			StringBuffer strBuffer = new StringBuffer();
			strBuffer.append("UPDATE POS_OFFLINE_TRX_Q SET TRX_STATUS='2' WHERE OFFLINE_TRX_Q_KEY BETWEEN "
					+ strFirstOfflineTrxKey + " AND " + strLastOfflineTrxKey);
			log.debug("Update query prepared is " + strBuffer.toString());
			ps = oracleConnection.prepareStatement(strBuffer.toString());
			ps.executeQuery();
			log.info("Executed sql statement successfully");
			if (ps != null) {
				ps.close();
				log.debug("Closed prepared statement");
			}
			return inXML;
		} catch (SQLException e) {
			log.error("SQL Exception occured " + e);
			throw new YFSException();
		} catch (Exception e) {
			log.error("Exception occured " + e);
			throw new YFSException();
		} finally {
			if (ps != null) {
				ps.close();
				log.debug("Closed prepared statement in final");
			}
		}
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
	}
}
