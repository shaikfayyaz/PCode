package com.kohls.poc.util;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

public class ManageSyncDBImport {
	static Logger log = Logger.getLogger(ManageSyncDBImport.class.getName());
	Connection conn = null;
	String actionName = null, timeStamp = null;
	String sMasterPoolId = null, sConfigPoolId = null, strSequenceNoImport = null;
	private static YIFApi oApi = null;
	
	public void ManageSyncDBImport(YFSEnvironment env, Document doSyncVersion) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
		String syncDBDate = sdf.format(yfcCurrntDt);
		ArrayList<Element> profileListFromFile = SCXmlUtil.getChildren(doSyncVersion.getDocumentElement(), "Profile");
		log.debug("prifleList size "+ profileListFromFile.size());
		for(Element profileFile : profileListFromFile){
			Document docManageImportSyncDB = YFCDocument.createDocument("SyncDBImport").getDocument();
			Element eleManageImportSyncDB = docManageImportSyncDB.getDocumentElement();
			eleManageImportSyncDB.setAttribute("DBImportTime",syncDBDate);
			eleManageImportSyncDB.setAttribute("Operation","Manage");
			eleManageImportSyncDB.setAttribute("OrganizationCode","KOHLS-RETAIL");
			eleManageImportSyncDB.setAttribute("ProfileOrganizationCode",profileFile.getAttribute(KohlsPOCConstant.A_ORG_CODE));
			eleManageImportSyncDB.setAttribute("SyncProfileID",profileFile.getAttribute(KohlsPOCConstant.A_NAME));
			eleManageImportSyncDB.setAttribute("SyncTargetID",YFSSystem.getProperty("store.common.store.store.id"));

			//String strSequenceNoImport = getSequenceNoForImport(docSyncVersion, profileFile.getAttribute(KohlsPOCConstant.A_NAME));
			String strSequenceNoImport = profileFile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
			//For Store Full Sync
			eleManageImportSyncDB.setAttribute("SyncType",KohlsPOCConstant.SYNC_FULL);	 		  
			eleManageImportSyncDB.setAttribute("SequenceNo",strSequenceNoImport);
			log.debug("ManageSyncDBImport FULL-STORE input :: "+XMLUtil.getXMLString(docManageImportSyncDB));
			KohlsCommonUtil.invokeAPI(env,"manageSyncDBImport",docManageImportSyncDB);				

			//For Corp Full Sync
			Document manageSyncDBImportOutdoc = null;
			Element eleAdditionalInfo = SCXmlUtil.createChild(eleManageImportSyncDB, "yfcAdditionalInfo");
			eleAdditionalInfo.setAttribute("endpoint", "MOTHERSHIP");
			log.debug("ManageSyncDBImport FULL-MOTHERSHIP input :: "+XMLUtil.getXMLString(docManageImportSyncDB));
			callApi(env, docManageImportSyncDB, manageSyncDBImportOutdoc,"MOTHERSHIP", "manageSyncDBImport");

			//For Store Delta Sync
			eleManageImportSyncDB.setAttribute("SyncType",KohlsPOCConstant.SYNC_DELTA);
			String[] deltaSeqNo = strSequenceNoImport.split("\\."); // String array, each element is text between dots
			String deltaIntSeqValue = deltaSeqNo[0];
			eleManageImportSyncDB.setAttribute("SequenceNo",(deltaIntSeqValue+".1"));
			SCXmlUtil.removeNode(SCXmlUtil.getChildElement(eleManageImportSyncDB, "yfcAdditionalInfo"));
			log.debug("ManageSyncDBImport DELTA-STORE input :: "+XMLUtil.getXMLString(docManageImportSyncDB));
			KohlsCommonUtil.invokeAPI(env,"manageSyncDBImport",docManageImportSyncDB);

		
			eleAdditionalInfo = SCXmlUtil.createChild(eleManageImportSyncDB, "yfcAdditionalInfo");
			eleAdditionalInfo.setAttribute("endpoint", "MOTHERSHIP");
			log.debug("ManageSyncDBImport DELTA-MOTHERSHIP input :: "+XMLUtil.getXMLString(docManageImportSyncDB));
			callApi(env, docManageImportSyncDB, manageSyncDBImportOutdoc,"MOTHERSHIP", "manageSyncDBImport");
			
			callModifyCache(env);

		}	 		   
	}
	
	private void callModifyCache(YFSEnvironment env) throws Exception {
		Document docModifyCacheInput = SCXmlUtil.createDocument("CachedGroups");
		Element eleCachedGroups = docModifyCacheInput.getDocumentElement();
		Element eleCachedGroup = SCXmlUtil.createChild(eleCachedGroups, "CachedGroup");
		eleCachedGroup.setAttribute(KohlsPOCConstant.A_ACTION, "CLEAR");
		eleCachedGroup.setAttribute(KohlsPOCConstant.A_NAME, "Database");
		log.debug("docModifyCacheInput is " + SCXmlUtil.getString(docModifyCacheInput));
		Document docModifyCacheOutput = KohlsCommonUtil.invokeAPI(env, "modifyCache", docModifyCacheInput);
		log.debug("docModifyCacheOutput is " + SCXmlUtil.getString(docModifyCacheOutput));
	}

	public Document callApi(YFSEnvironment env, Document inXML,
			Document outDoc, String sEndpoint, String sApiName){
		try{
			Document tempOutput = null;

			oApi = getDefaultAPI((YFSContext) env, sEndpoint);

			String envString = "<env userId='gravity' progId='gravity'/>";
			YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(
					envString).getDocument());
			tempOutput = oApi.invoke(newEnv, sApiName, inXML);
			return tempOutput;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new YFCException("Exception in callApi");
		}
	}

	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			log.debug("YIFClient using endpoint definition");
			Map omap = new HashMap();
			try {
				omap.put("yif.httpapi.userid", YIFClientProperties.getInstance().getYIFProperty(
						"edge.integration.app.userid"));
				omap.put("yif.httpapi.password", YIFClientProperties.getInstance().getYIFProperty(
						"edge.integration.app.password"));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}

		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode("OMP922_002");
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(),
				"Edge_Server_Endpoint_Not_Configured"));
		throw oEx;
	}

	/**
	 * This method is to read values from customer override properties with the action and key value 
	 * example yfs.EXPORT.DIRECTORY
	 * @param actionName
	 * @param keyName
	 * @return
	 */

	public  String getConfigValue(String actionName, String keyName) {

		String prpertyKey = KohlsPOCConstant.KEY_TAG +"_"+actionName.toUpperCase() + "_" + keyName;
		log.debug(prpertyKey);
		return YFSSystem.getProperty(prpertyKey);
	}


}
