package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.List;

import com.google.gson.Gson;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsMosDataOutJson;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCMosUtil {
	private Properties props;
	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCMosUtil.class);

	private String Source;

	public Document getMosData(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.getMosData");

		Element eleMosData = inDoc.getDocumentElement();
		List<Document>mosDataList=  new ArrayList<Document>();

		if (!YFCCommon.isVoid(inDoc)) {

			if (!YFCCommon.isVoid(eleMosData.getAttribute(KohlsPOCConstant.E_SOURCE))) {
				Source = eleMosData.getAttribute(KohlsPOCConstant.E_SOURCE);
				if (YFCLogUtil.isDebugEnabled()) {
					logger.debug("KohlsPoCMosUtil.getMosData Source --"
							+ Source);
				}

			}
		}
		String path = getPropertyValue(props.getProperty("LogDir"));
		if (YFCLogUtil.isDebugEnabled()) {
			logger.debug("KohlsPoCMosUtil.getMosData path --" + path);
		}
		BufferedReader bufferedReader = new BufferedReader(new FileReader(path));

		Gson gson = new Gson();

		Object json = gson.fromJson(bufferedReader, Object.class);
		String sParseData = json.toString() ;
		if (YFCLogUtil.isDebugEnabled()) {
			logger.debug("KohlsPoCMosUtil.getMosData sParseData --"
					+ sParseData);
		}

		Document outMosDataFromJson = getMosDataListFromJson(null,sParseData);
		if (YFCLogUtil.isDebugEnabled()) {
			if (!YFCCommon.isVoid(outMosDataFromJson)) {
				logger.debug("KohlsPoCMosUtil.getMosData outMosDataFromJson --"
						+ XMLUtil.getXMLString(outMosDataFromJson));
			}
		}
		
		mosDataList = toCheckUpdateOrCreate(null,
				outMosDataFromJson, env);
		if (YFCLogUtil.isDebugEnabled()) {
			if (!YFCCommon.isVoid(mosDataList)) {
				logger.debug("KohlsPoCMosUtil.getMosData mosDataList --"
						+ (mosDataList.toString()));
			}
		}
		logger.endTimer("KohlsPoCMosUtil.getMosData");

		return outMosDataFromJson;

	}

	public Document getMosDataListFromJson(Document inputDoc, String sParseData)
			throws ParserConfigurationException {
		logger.beginTimer("KohlsPoCMosUtil.getMosDataListFromJson");

		Gson outGson = new Gson();
		sParseData = "[{ \"mosItemDetails\":" + sParseData + "}]";
		KohlsMosDataOutJson[] parsedClass = outGson.fromJson(sParseData,
				KohlsMosDataOutJson[].class); // input

		Document docMosData = null;
		if(YFCCommon.isVoid(inputDoc))
		{
			docMosData = SCXmlUtil.createDocument(KohlsPOCConstant.KOHLS_MOS_DATA_LIST);
		}
		else
		{
			docMosData = inputDoc;
		}
		
		
		Element eleDocMosDataList = docMosData.getDocumentElement();
		for (int j = 0; j < parsedClass.length; j++) {

			if (parsedClass[j].mosItemDetails.length != 0) {
				for (int i = 0; i < parsedClass[j].mosItemDetails.length; i++) {
					Element eleDocMosData = docMosData
							.createElement(KohlsPOCConstant.KOHLS_MOS_DATA);
					// Element
					// eleReturnReason=docReturnReasonCode.createElement("KohlsReturnReasonCode");
					if (!YFCCommon.isVoid(parsedClass[j].mosItemDetails[i].skuNbr) && parsedClass[j].mosItemDetails[i].skuNbr.length() == 7) {
						eleDocMosData.setAttribute(KohlsPOCConstant.A_SKUNBR, "0"
								+ parsedClass[j].mosItemDetails[i].skuNbr);
						if (YFCLogUtil.isDebugEnabled()) {

							logger.debug("KohlsPoCMosUtil.getMosDataListFromJson in if block  --");

						}

					} else {
						eleDocMosData.setAttribute(KohlsPOCConstant.A_SKUNBR,
								parsedClass[j].mosItemDetails[i].skuNbr);
						if (YFCLogUtil.isDebugEnabled()) {

							logger.debug("KohlsPoCMosUtil.getMosDataListFromJson else block");

						}
						
					}
					eleDocMosData.setAttribute(KohlsPOCConstant.A_MOS_START_DATE,
							parsedClass[j].mosItemDetails[i].mosStrtDte);// eleReturnReason.setAttribute("DepartmentNo",

					eleDocMosData.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
							KohlsPOCConstant.DEFAULT);
					eleDocMosData.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE,
							KohlsPOCConstant.UNIT_OF_MEASURE);
					
					eleDocMosDataList.appendChild(eleDocMosData);
				}
			}

		}
		//docMosData.appendChild(eleDocMosDataList);
		if (YFCLogUtil.isDebugEnabled()) {
			if (!YFCCommon.isVoid(docMosData)) {
				logger.debug("KohlsPoCMosUtil.getMosDataListFromJson docMosData --"
						+ XMLUtil.getXMLString(docMosData));
			}
		}
		logger.endTimer("KohlsPoCMosUtil.getMosDataListFromJson");

		return docMosData;
	
	}

	/*public void manageMosItem(YFSEnvironment env, Element eleKohlsMosData)
			throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.manageMosItem");

		Document docItemList = YFCDocument.createDocument("ItemList")
				.getDocument();
		Element eleItemList = docItemList.getDocumentElement();
		Element eleItem = docItemList.createElement("Item");
		eleItem.setAttribute("ItemID", eleKohlsMosData.getAttribute("SkuNbr"));

		eleItem.setAttribute("OrganizationCode", "DEFAULT");
		eleItem.setAttribute("UnitOfMeasure", "EACH");
		Element eleExtn = docItemList.createElement("Extn");

		Element eleKohlsMosDataList = docItemList
				.createElement("KohlsMosDataList");
		// Element eleMosData =docItemList.createElement("KohlsMosDataList");
		eleKohlsMosData.setAttribute("Operation", "Create");
		XMLUtil.importElement(eleKohlsMosDataList, eleKohlsMosData);
		eleExtn.appendChild(eleKohlsMosDataList);
		eleItem.appendChild(eleExtn);
		eleItemList.appendChild(eleItem);
		if (YFCLogUtil.isDebugEnabled()) {
			if (!YFCCommon.isVoid(docItemList)) {
				logger.debug("KohlsPoCMosUtil.manageMosItem docItemList --"
						+ XMLUtil.getXMLString(docItemList));
			}
		}
		
		KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_ITEM,
				docItemList);
		logger.endTimer("KohlsPoCMosUtil.manageMosItem");

		// return outDocItemList;

	}
*/
	public Document createMosData(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.createMosData");
		Document outDocItemList = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_CREATE_MOS_DATA, inDoc);
		logger.endTimer("KohlsPoCMosUtil.createMosData");

		return outDocItemList;

	}

	
	
	public Document getMosDataList(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.getMosDataList");

		Document outDocItemList = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_GET_MOS_DATA_LIST, inDoc);

		logger.endTimer("KohlsPoCMosUtil.getMosDataList");

		return outDocItemList;

	}

	public Document updateMosData(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.updateMosData");

		Document outDocItemList = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_CHANGE_MOS_DATA, inDoc);
		logger.endTimer("KohlsPoCMosUtil.updateMosData");

		return outDocItemList;

	}

	public List<Document> toCheckUpdateOrCreate(String source,Document docMosData,
			 YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.toCheckUpadteOrCreate");
		
		List<Document> mosDataList = new ArrayList<Document>();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");

		NodeList ndlMosData = docMosData.getElementsByTagName(KohlsPOCConstant.KOHLS_MOS_DATA);
		for (int i = 0; i < ndlMosData.getLength(); i++) {
			
			Element eleKohlsMosData = (Element) ndlMosData.item(i);
			//System.out.println("helloo "+eleKohlsMosData.getAttribute(KohlsPOCConstant.A_SKUNBR));
			String sMosData=getKohlsMosData(env, XMLUtil.getDocumentForElement(eleKohlsMosData));
			
			if (YFCCommon.isVoid(sMosData)) {

				eleKohlsMosData.setAttribute(KohlsPOCConstant.A_CREATE_FLAG, KohlsPOCConstant.FLAG_Y);
				
				
					if (YFCLogUtil.isDebugEnabled()) {
						if (!YFCCommon.isVoid(eleKohlsMosData)) {
							logger.debug("KohlsPoCMosUtil.toCheckUpadteOrCreate sMosData --"
									+ XMLUtil
									.getElementXMLString(eleKohlsMosData));
						}
					}
					if (KohlsPOCConstant.MOS_STAND_ALONE.equalsIgnoreCase(source)) {
						
						modifyTable(env, XMLUtil.getDocumentForElement(eleKohlsMosData));
						continue; 
					}
					else
					{
						((List<Document>) mosDataList)
						.add(XMLUtil.getDocumentForElement(eleKohlsMosData));
					}
					
			} else {
				
				String skuNbr = eleKohlsMosData.getAttribute(KohlsPOCConstant.A_SKUNBR);
				if(KohlsPOCConstant.MOS_KAFKA_OFFSET.equalsIgnoreCase(skuNbr))
				{
					int intToOffset =Integer.parseInt(eleKohlsMosData
							.getAttribute(KohlsPOCConstant.A_MOS_START_DATE));
					int intfromOffset = Integer.parseInt(sMosData);
					//logger.info("Done processing all the messages. Updating the Offset.");	
					if(intToOffset >  intfromOffset)
					{
						eleKohlsMosData.setAttribute(KohlsPOCConstant.A_UPDATE_FLAG, KohlsPOCConstant.FLAG_Y);					
						if (YFCLogUtil.isDebugEnabled()) {
							if (!YFCCommon.isVoid(eleKohlsMosData)) {
								logger.debug("KohlsPoCMosUtil.toCheckUpadteOrCraete sMosData --"
										+ XMLUtil
										.getElementXMLString(eleKohlsMosData));
							}
						}
						
						if (KohlsPOCConstant.MOS_STAND_ALONE.equalsIgnoreCase(source)) {
							
							modifyTable(env, XMLUtil.getDocumentForElement(eleKohlsMosData));
							continue; 
						}
						else
						{
							((List<Document>) mosDataList)
							.add(XMLUtil.getDocumentForElement(eleKohlsMosData));
						}
					}
				}
				else
				{
					Date dResMosDate = sdf.parse(eleKohlsMosData
							.getAttribute(KohlsPOCConstant.A_MOS_START_DATE));
					Date dTableMosDate = sdf.parse(sMosData);

					if (dResMosDate.compareTo(dTableMosDate) > 0) {

						eleKohlsMosData.setAttribute(KohlsPOCConstant.A_UPDATE_FLAG, KohlsPOCConstant.FLAG_Y);					
						if (YFCLogUtil.isDebugEnabled()) {
							if (!YFCCommon.isVoid(eleKohlsMosData)) {
								logger.debug("KohlsPoCMosUtil.toCheckUpadteOrCraete sMosData --"
										+ XMLUtil
										.getElementXMLString(eleKohlsMosData));
							}
						}
						
						if (KohlsPOCConstant.MOS_STAND_ALONE.equalsIgnoreCase(source)) {
							
							modifyTable(env, XMLUtil.getDocumentForElement(eleKohlsMosData));
							continue; 
						}
						else
						{
							((List<Document>) mosDataList)
							.add(XMLUtil.getDocumentForElement(eleKohlsMosData));
						}	

					}	
				}	
				
		}
		
			
		
		}
		logger.beginTimer("KohlsPoCMosUtil.toCheckUpadteOrCreate");
		return mosDataList;
		

	}

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		// LOG_CAT.debug("In the set properties method");

	}

	// CPE -9964- START
	public String getPropertyValue(String property) {
		logger.beginTimer("KohlsPoCMosUtil.getPropertyValue");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		// Manoj 10/22: updated to use configured property if
		// customer_overrides.properties does not return any value
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		logger.endTimer("KohlsPoCMosUtil.getPropertyValue");
		return propValue;

	}
	public  String   getKohlsMosData(YFSEnvironment env, Document inDoc) throws Exception
	{
		String sMosStartDate="";
		Document outDocGetMosData = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_GET_MOS_DATA, inDoc);
		logger.endTimer("KohlsPoCMosUtil.updateMosData");

		if(!YFCCommon.isVoid(outDocGetMosData))
		{
			
			
			Element eleKohlsMosData = (Element)outDocGetMosData.getElementsByTagName("KohlsMosData").item(0);
			sMosStartDate=eleKohlsMosData.getAttribute(KohlsPOCConstant.A_MOS_START_DATE);
		}
		return sMosStartDate;
		
	}

	public void modifyTable(YFSEnvironment env, Document inMosDoc
			) throws Exception {
		logger.beginTimer("KohlsPoCMosUtil.modifyTable");

		Element eleMosData = inMosDoc.getDocumentElement();

		if (!YFCCommon.isVoid(eleMosData)) {

			if (eleMosData.getAttribute(KohlsPOCConstant.A_CREATE_FLAG)
					.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))

			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCMosUtil.modifyTable--.CREATE record");
				}
				createMosData(env, XMLUtil.getDocumentForElement(eleMosData));

			} else if (eleMosData.getAttribute(
					KohlsPOCConstant.A_UPDATE_FLAG).equalsIgnoreCase(
							KohlsPOCConstant.FLAG_Y))

			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsPoCMosUtil.modifyTable--.Update record");
				}
				
				updateMosData(env,  XMLUtil.getDocumentForElement(eleMosData));
			}

		

		}
		logger.endTimer("KohlsPoCMosUtil.modifyTable");

	}



}
