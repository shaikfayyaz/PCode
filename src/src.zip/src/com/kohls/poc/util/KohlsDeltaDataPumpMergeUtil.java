package com.kohls.poc.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.tools.entityguru.generator.Attribute;
import com.yantra.tools.entityguru.generator.Entity;
import com.yantra.tools.entityguru.generator.EntityRepository;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dblayer.dbi.YFCEntityRepositoryImpl;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsDeltaDataPumpMergeUtil {
	private static YFCLogCategory log = YFCLogCategory.instance(KohlsDeltaDataPumpMergeUtil.class.getName());
	private static PreparedStatement prepStmt = null;
	private static Statement stmt = null;
	Connection conn = null;

	public static final String mergeFileMsg = "Merge_inProgress";

	public boolean processStagedDelta(YFSEnvironment env, File filesPath) throws Exception {
		boolean lowerXmlVersion = false;
		try {
			if (filesPath.isDirectory() & filesPath.listFiles().length > 0) {
				File deltaDirs[] = dirListByName(filesPath);
				log.info("STAGED - Found files under " + deltaDirs[0]);
				KohlsDeltaDataPump deltaPump = new KohlsDeltaDataPump();
				deltaPump.setPermission(deltaDirs[0]);
				if (deltaDirs[0].listFiles().length > 0) {
					lowerXmlVersion = deltaPump.processDumpFiles(env, deltaDirs[0]);
				}
				if (deltaDirs[0].isDirectory()) {
					if (deltaDirs[0].list().length == 0) {
						log.debug("STAGED - Deleting the empty directory " + deltaDirs[0]);
						deltaDirs[0].delete();
					} else {
						log.debug("STAGED - Directory is not empty" + deltaDirs[0]);
					}
				}
			} else {
				log.debug("STAGED - No files to process under " + filesPath);
			}
		} catch (Exception e) {
			log.error("STAGED -  Exception occured in processStagedDelta");
			processFileMovement(env, KohlsPOCConstant.DELTA_STAGED_INPRG_PATH, KohlsPOCConstant.DELTA_STAGED_ERROR_PATH,
					e);
		}
		return lowerXmlVersion;
	}


	public void filterFiles(File dir, File dest, String fileType) throws IOException {
		File[] files = dir.listFiles();
		log.debug("Calling the list file " + dir + " " + dest.getName());
		String fileName = null;
		String typeReceived = null;
		for (File sourceFile : files) {
			if (fileType.equalsIgnoreCase("ALL")) {
				typeReceived = sourceFile.getName();
				log.debug("typeReceived value is " + typeReceived);
			} else {
				typeReceived = fileType;
				log.debug("typeReceived value is " + typeReceived);
			}
			fileName = sourceFile.getName();
			if (fileName.contains(typeReceived)) {
				File destFile = new File(dest, fileName);
				try {
					moveErrorFiles(sourceFile, destFile);
				} catch (IOException e) {
					log.error("Exception in filterFiles");
					throw e;
				}
			}
		}
	}


	public static void moveErrorFiles(File sourceFile, File destFile) throws IOException {
		log.info("Moving files from " + sourceFile + " to " + destFile);
		InputStream in = null;
		OutputStream out = null;
		try {
			in = new FileInputStream(sourceFile);
			out = new FileOutputStream(destFile);
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			log.debug("Deleting the file after copy");
			sourceFile.delete();
		} finally {
			if (!YFCCommon.isVoid(in) || !YFCCommon.isVoid(out)) {
				in.close();
				out.close();
			}
		}
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static File[] dirListByName(File errFilesPath) throws Exception {
		log.info("Processing directory list " + errFilesPath);
		if (!errFilesPath.isDirectory()) {
			log.error("Error file path is not a directory " + errFilesPath);
			return null;
		}
		File fileList[] = errFilesPath.listFiles();
		Arrays.sort(fileList, new Comparator() {
			public int compare(final Object o1, final Object o2) {
				return new Long(((File) o1).getName()).compareTo(new Long(((File) o2).getName()));
			}
		});
		return fileList;
	}


	protected List<Document> getPartitionNumbers(YFSContext conn, String primaryTables, String orgTableList,
			String syncVerXmlPath) throws Exception {
		log.info("STAGED - Getting the partition list " + primaryTables + ", Orginal table mapping " + orgTableList);
		List<Document> partitionMergedList = new ArrayList<Document>();
		String[] tableList = primaryTables.replaceAll("'", "").split(",");
		String[] orgTables = orgTableList.split(",");
		HashMap<String, ArrayList<Document>> patitionDoc = new HashMap<String, ArrayList<Document>>();
		ArrayList<String> tables = new ArrayList<String>();
		ResultSet resultSet = null;
		try {
			String rankEnabledForImport = checkForRankEnabled(syncVerXmlPath);
			for (String primaryTable : tableList) {
				ArrayList<Document> partitionList = new ArrayList<Document>();
				String trimTable = "";
				String stagedTable = primaryTable.split("\\.")[1].trim();
				for (String mapTable : orgTables) {
					String[] tableStgSplit = mapTable.split(":");
					log.debug("Org table " + tableStgSplit[0] + ", Stg tabe" + stagedTable);
					if (stagedTable.equals(tableStgSplit[0].trim())) {
						trimTable = tableStgSplit[1].trim();
					}
				}

				String checkPartition = "SELECT PARTITION_NAME FROM DBA_TAB_PARTITIONS WHERE TABLE_NAME='" + stagedTable
						+ "' AND TABLE_OWNER='STERLING'";
				log.debug("STAGED - Get partition query " + checkPartition);
				prepStmt = conn.getConnection().prepareStatement(checkPartition);
				resultSet = prepStmt.executeQuery();
				int i = 0;
				while (resultSet.next()) {
					String partNumber = resultSet.getString("PARTITION_NAME");
					if (partNumber != null) {
						log.info("STAGED - Partition named as : " + partNumber);
						Document partitionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.PARTITION);
						Element elemTemplate = partitionDoc.getDocumentElement();
						elemTemplate.setAttribute(KohlsPOCConstant.ATTR_PRIMARY_TABLE, trimTable);
						elemTemplate.setAttribute(KohlsPOCConstant.ATTR_PARTITION_TABLE, stagedTable);
						elemTemplate.setAttribute(KohlsPOCConstant.ATTR_PARTITION_NAME, partNumber);
						elemTemplate.setAttribute(KohlsPOCConstant.ATTR_PARTITION_SYNC_XML, syncVerXmlPath);
						elemTemplate.setAttribute(KohlsPOCConstant.RANK_ENABLED, rankEnabledForImport);
						partitionList.add(partitionDoc);
						log.debug("STAGED - Partition xml formed " + SCXmlUtil.getString(partitionDoc));
						i++;
					}
				}
				//mix list start
				tables.add(primaryTable);
				patitionDoc.put(primaryTable, partitionList);
				log.info("STAGED - Total partitions for " + stagedTable + " - " + i);
			}
			partitionMergedList = mergeTablePartitions(patitionDoc, tables);
		} catch (Exception e) {
			log.error("STAGED - Exception in getPartitionNumbers");
			throw e;
		} finally {
			if (resultSet != null) {
				resultSet.close();
			}
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("STAGED - getPartitionNumbers prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
		return partitionMergedList;
	}


	public List<Document> mergeTablePartitions(HashMap<String, ArrayList<Document>> m, ArrayList<String> a) {
		log.info("STAGED - Number of tables " + m.size());
		int highestPartitionSize = 0;
		List<Document> mergedPartitions = new ArrayList<Document>();

		for (int i = 0; i < a.size(); i++) {
			if (highestPartitionSize < m.get(a.get(i)).size())
				highestPartitionSize = m.get(a.get(i)).size();
		}
		log.debug("STAGED - Highest number of iteration " + highestPartitionSize);
		for (int j = 0; j < highestPartitionSize; j++) {

			for (int i = 0; i < a.size(); i++) {
				if (m.get(a.get(i)).size() != 0) {
					mergedPartitions.add(m.get(a.get(i)).get(0));
					m.get(a.get(i)).remove(0);
				}
			}
		}
		for (Document e : mergedPartitions) {
			log.debug(SCXmlUtil.getString(e));
		}
		log.info("STAGED - Total of merge iteration count " + mergedPartitions.size());
		return mergedPartitions;
	}


	public void mergePartitionRecords(YFSContext ctx, String oraProcedure, String syncXmlPath,
			String rankEnabledForImport, String procedureName) throws Exception {
		File deltaCurPath = new File(syncXmlPath.split(KohlsPOCConstant.STG_SYNC_VER)[0]);
		partitionMergeFileCreation(deltaCurPath, oraProcedure, mergeFileMsg, rankEnabledForImport);
		conn = ctx.getConnection();
		Statement proStmt = conn.createStatement();
		try {
			proStmt.executeUpdate("BEGIN DBMS_OUTPUT.ENABLE(); END;");
			CallableStatement preparedCall;
			preparedCall = conn.prepareCall("{call " + oraProcedure + "}");
			log.debug("STAGED - Executing the procedure " + oraProcedure);
			preparedCall.execute();
			try (CallableStatement call = conn
					.prepareCall("DECLARE NUM INTEGER := 1000; BEGIN DBMS_OUTPUT.GET_LINES(?, NUM); END;")) {
				call.registerOutParameter(1, Types.ARRAY, "DBMSOUTPUT_LINESARRAY");
				call.execute();
				Array array = null;
				try {
					array = call.getArray(1);
					String[] dbOutputMsg = (String[]) array.getArray();
					if (dbOutputMsg.length > 0) {
						for (String output : dbOutputMsg) {
							if (!YFCCommon.isVoid(output))
							log.info("Output of procedure " + procedureName + " - " + output);
						}
					}
				} finally {
					if (array != null)
						array.free();
				}
				if (!((deltaCurPath.getAbsolutePath()).contains(KohlsPOCConstant.STG_INPRG))) {
					KohlsDeltaDataPump dPump = new KohlsDeltaDataPump();
					File donePath = dPump.findDoneDir(deltaCurPath.getAbsolutePath());
					log.info("STAGED - Moving sync xml file to done " + deltaCurPath.getName());
					String[] qryValues = oraProcedure.split("'");
					filterFiles(deltaCurPath, donePath, qryValues[1] + "_" + qryValues[5]);
					//boolean successValue = deletePartitionXml(deltaCurPath, oraProcedure);
					//log.info("STAGED - Deleting the partition file on success " + successValue);
				} else {
					if (deletePartitionXml(deltaCurPath, oraProcedure)) {
						log.info("STAGED - Processed partion file and deleted it");
					} else {
						log.info("STAGED - Processed partion file and failed to delete it");
					}
				}
			}
		} catch (Exception ore) {
			log.error("STAGED - Exception occurred while merging partition " + ore.getMessage());
			// ore.printStackTrace(); getmessage is not printing complete exceptionFileMove
			YFCException exp = new YFCException(ore);
			String err = exp.getContainedException().toString();
			partitionMergeFileCreation(deltaCurPath, oraProcedure, err, rankEnabledForImport);
		} finally {
			proStmt.executeUpdate("BEGIN DBMS_OUTPUT.DISABLE(); END;");
			proStmt.close();
		}
	}


	public void partitionMergeFileCreation(File currentDeltaPath, String mergeQry, String oraMsg,
			String rankEnabledForImport) throws Exception {
		String[] qryValues = mergeQry.split("'");
		log.debug("Length : " + qryValues.length + ", Values  " + qryValues[0] + " : " + qryValues[1] + " : "
				+ qryValues[2] + " : " + qryValues[3] + " : " + qryValues[4] + " : " + qryValues[5]);
		boolean fileExists = false;
		if (currentDeltaPath.isDirectory()) {
			for (File file : currentDeltaPath.listFiles()) {
				if (file.getName().contains(qryValues[1] + "_" + qryValues[5])) {
					Document inDoc = SCXmlUtil.getDocumentBuilder().parse(file.getAbsoluteFile());
					String descMsg = inDoc.getDocumentElement().getAttribute("OraMessage");
					if (descMsg.equalsIgnoreCase(mergeFileMsg) && !oraMsg.equalsIgnoreCase(mergeFileMsg)) {
						fileExists = false;
					} else {
						fileExists = true;
					}
				}
			}
			if (!fileExists) {
				FileWriter fWriter = new FileWriter(
						new File(currentDeltaPath.getAbsolutePath() + "/Merge_" + qryValues[1] + "_" + qryValues[5]));
				String xmlPath = currentDeltaPath.getAbsolutePath();
				if (xmlPath.contains(KohlsPOCConstant.STG_INPRG) && !oraMsg.equalsIgnoreCase(mergeFileMsg)) {
					xmlPath = xmlPath.replace(KohlsPOCConstant.STG_INPRG, KohlsPOCConstant.STG_ERROR);
				}
				if (KohlsPOCConstant.YES.equalsIgnoreCase(rankEnabledForImport)) {
					fWriter.write(SCXmlUtil.getString(constructRankMsgDoc(qryValues[1], qryValues[3],
							Long.parseLong(qryValues[5]), Long.parseLong(qryValues[7]), xmlPath, oraMsg,
							rankEnabledForImport)));
				} else {
					Document inDoc = SCXmlUtil.createDocument(KohlsPOCConstant.PARTITION);
					Element docElm = inDoc.getDocumentElement();
					setAttributeValue(qryValues[1], qryValues[3], qryValues[5], xmlPath, docElm, oraMsg,
							rankEnabledForImport);
					log.info("STAGED - Created the partition document " + SCXmlUtil.getString(inDoc));
					fWriter.write(SCXmlUtil.getString(inDoc));
				}
				fWriter.close();
			}
		}
	}


	public List<Document> loadPartitionFromXml(String syncVerXmlPath) throws Exception {
		log.info("STAGED - Checking the partition files " + syncVerXmlPath.split(KohlsPOCConstant.STG_SYNC_VER)[0]);
		List<Document> partitionList = new ArrayList<Document>();
		File currentDeltaPath = new File(syncVerXmlPath.split(KohlsPOCConstant.STG_SYNC_VER)[0]);
		if (currentDeltaPath.isDirectory()) {
			for (File file : currentDeltaPath.listFiles()) {
				if (file.getName().contains(KohlsPOCConstant.MERGE)) {
					Document docTemplate = SCXmlUtil.createFromFileOrUrl(file.getAbsoluteFile().toString());
					log.info("STAGED - Partition added in getPartitionFromXml " + SCXmlUtil.getString(docTemplate));
					partitionList.add(docTemplate);
				}
			}
		}
		return partitionList;
	}


	public boolean deletePartitionXml(File syncVerXmlPath, String mergeQry) throws Exception {
		String[] qryValues = mergeQry.split("'");
		log.info("STAGED - Check and delete the partition file under " + syncVerXmlPath.getAbsolutePath() + " - "
				+ qryValues[3]);
		if (syncVerXmlPath.isDirectory()) {
			for (File file : syncVerXmlPath.listFiles()) {
				log.debug("STAGED - File name " + file.getName());
				if (file.getName().contains(qryValues[1] + "_" + qryValues[5])) {
					return (file.delete());
				}
			}
		}
		return false;
	}


	public Element setAttributeValue(String primaryTable, String partitionTable, String partitionName, String xmlPath,
			Element elmValues, String oraMessage, String isRankEnabled) throws Exception {
		elmValues.setAttribute(KohlsPOCConstant.ATTR_PRIMARY_TABLE, primaryTable);
		elmValues.setAttribute(KohlsPOCConstant.ATTR_PARTITION_TABLE, partitionTable);
		elmValues.setAttribute(KohlsPOCConstant.ATTR_PARTITION_NAME, partitionName);
		elmValues.setAttribute(KohlsPOCConstant.ATTR_PARTITION_SYNC_XML, xmlPath);
		elmValues.setAttribute(KohlsPOCConstant.RANK_ENABLED, isRankEnabled);
		elmValues.setAttribute("OraMessage", oraMessage);
		log.debug("STAGED - Constructed element with values " + SCXmlUtil.getString(elmValues));
		return elmValues;
	}

	
	public void populateDeltaRecordsToExpTables(YFSContext ctx, String parQuery) throws Exception {
		conn = ctx.getConnection();
		Statement proStmt = conn.createStatement();
		try {
			proStmt.executeUpdate("BEGIN DBMS_OUTPUT.ENABLE(); END;");
			CallableStatement preparedCall;
			preparedCall = conn.prepareCall("{call " + parQuery + "}");
			log.info("STAGED - Populating the records " + parQuery);
			preparedCall.execute();
			try (CallableStatement call = conn
					.prepareCall("DECLARE NUM INTEGER := 1000; BEGIN DBMS_OUTPUT.GET_LINES(?, NUM); END;")) {
				call.registerOutParameter(1, Types.ARRAY, "DBMSOUTPUT_LINESARRAY");
				call.execute();
				Array array = null;
				try {
					array = call.getArray(1);
					String[] dbOutputMsg = (String[]) array.getArray();
					if (dbOutputMsg.length > 0) {
						for (String output : dbOutputMsg) {
							log.info(output);
						}
					}
				} finally {
					if (array != null)
						array.free();
				}
			}
		} catch (Exception exp) {
			log.error("STAGED - Exception occurred while createAndPopulateDeltaRecords " + exp.getMessage());
			throw exp;
		} finally {
			proStmt.executeUpdate("BEGIN DBMS_OUTPUT.DISABLE(); END;");
			proStmt.close();
		}
	}


	public Document processSyncVersionXml(YFSEnvironment env, String deltaCurXmlFile) throws Exception {
		File deltaCurPath = new File(deltaCurXmlFile.split(KohlsPOCConstant.STG_SYNC_VER)[0]);
		Document inDoc = null;
		try {
			if (deltaCurXmlFile.contains(KohlsPOCConstant.STG_ERROR)
					|| deltaCurXmlFile.contains(KohlsPOCConstant.STG_INPRG)) {
				boolean isWait = false;
				int i = Integer.parseInt(YFSSystem.getProperty(KohlsPOCConstant.DELTA_PARTITION_FILE_WAIT));
				int pollTime = Integer.parseInt(YFSSystem.getProperty("Delta.Partition.File.Poll"));
				while (i > 0) {
					for (File file : deltaCurPath.listFiles()) {
						if (file.getName().contains(KohlsPOCConstant.MERGE)) {
							log.info("File name in wait " + file.getName());
							isWait = true;
						}
					}
					if (isWait) {
						log.info("STAGED - contains error files, sleeping for sec " + pollTime);
						TimeUnit.SECONDS.sleep(pollTime);
						isWait = false;
					}
					--i;
				}
			}

			boolean fMatch = false;
			for (File file : deltaCurPath.listFiles()) {
				if (file.getName().contains(KohlsPOCConstant.MERGE)) {
					log.debug("STAGED - checking for merge file " + file.getName());
					fMatch = true;
				}
			}
			log.debug("STAGED - Merge matching value  " + fMatch);

			KohlsDeltaDataPump dPump = new KohlsDeltaDataPump();
			if (fMatch) {
				log.info("STAGED - Not processing " + deltaCurXmlFile);
				File inPrgFileDir = new File(KohlsPOCConstant.DELTA_STAGED_INPRG_PATH);
				Date date = new Date();
				if (inPrgFileDir.listFiles().length > 0) {
					log.error("STAGED - Moving files to resp error directory from "
							+ KohlsPOCConstant.DELTA_STAGED_INPRG_PATH);
					for (File fle : inPrgFileDir.listFiles()) {
						log.debug(date.toString() + " STAGED - Moving the files " + fle);
						dPump.exceptionFileMove(fle.toString(), KohlsPOCConstant.DELTA_STAGED_ERROR_PATH);
					}

					String xmlPath = deltaCurPath.getAbsolutePath();
					if (xmlPath.contains(KohlsPOCConstant.STG_INPRG)) {
						xmlPath = xmlPath.replace(KohlsPOCConstant.STG_INPRG, KohlsPOCConstant.STG_ERROR);
					}

					String erroMessage = "Error files created while merging records to primary table, For more info refer to " + xmlPath;
					dPump.raiseAlert(env, KohlsPOCConstant.DB_DELTA_IMPORT, erroMessage);
				}
			} else {
				log.info("STAGED - Sync DB import table updates started " + deltaCurXmlFile);
				dPump.callManageSyncDBImport(env, deltaCurPath);
				log.info("STAGED - Sync DB import table updates completed ");
				Date dmpdate = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
				String syncDBDate = sdf.format(dmpdate);
				updateDatapumpSyncTable(env, deltaCurXmlFile, syncDBDate);
				((YFSContext) env).commit();

				KohlsDeploymentUtil depUtil = new KohlsDeploymentUtil();
				depUtil.callModifyCache(env);

				File donePath = dPump.findDoneDir(deltaCurPath.getAbsolutePath());
				log.info("STAGED - Moving sync xml file to done " + deltaCurPath.getName());
				filterFiles(deltaCurPath, donePath, "SyncVersion");
				if (deltaCurPath.isDirectory()) {
					if (deltaCurPath.list().length == 0) {
						log.debug("STAGED - Deleting empty directory " + deltaCurPath);
						deltaCurPath.delete();
						log.info("STAGED - Delta sync STAGED-import type completed End Time :: " + currentDate());
					} else {
						log.debug("STAGED - Directory is not empty " + deltaCurPath);
					}
				}
				inDoc = SCXmlUtil.createFromString("<KohlsDataPump DataType='DeltaImport'/>");
			}
		} catch (Exception exp) {
			log.error("STAGED - Exception occured in processSyncVersionXml");
			processFileMovement(env, KohlsPOCConstant.DELTA_STAGED_INPRG_PATH, KohlsPOCConstant.DELTA_STAGED_ERROR_PATH,
					exp);
		}
		return inDoc;
	}


	public void updateDatapumpSyncTable(YFSEnvironment env, String deltaCurXmlFile, String syncDBDate)
			throws Exception {
		KohlsDeploymentUtil dUtil = new KohlsDeploymentUtil();
		File file = new File(deltaCurXmlFile);
		Document syncVerDoc = SCXmlUtil.getDocumentBuilder().parse(file);
		ArrayList<Element> profileListFromFile = SCXmlUtil.getChildren(syncVerDoc.getDocumentElement(),
				KohlsPOCConstant.E_PROFILE);
		ArrayList<String> profilesListFromXML = new ArrayList<String>();
		boolean cdtXmlVer = false;
		for (Element profileFileFromXML : profileListFromFile) {
			log.info("STAGED - Profile from XML file " + profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
			if (profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME)
					.equalsIgnoreCase(KohlsPOCConstant.P_CONFIGURATION_D)) {
				cdtXmlVer = true;
			} else {
				profilesListFromXML.add(profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
				log.info("STAGED - Profile adding to " + profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
			}
		}
		if (!profilesListFromXML.isEmpty()) {
			dUtil.manageSyncProcessRecordExpImp((YFSContext) env, KohlsPOCConstant.A_IMPORT,
					KohlsPOCConstant.SYNC_DELTA, YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP),
					KohlsPOCConstant.TABLE_TYPE_MASTER, profilesListFromXML, syncDBDate);
		}
		if (cdtXmlVer) {
			dUtil.manageSyncProcessRecordExpImp((YFSContext) env, KohlsPOCConstant.A_IMPORT,
					KohlsPOCConstant.SYNC_DELTA, YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP),
					KohlsPOCConstant.A_CONFIGURATION, profilesListFromXML, syncDBDate);
		}
	}


	public void processFileMovement(YFSEnvironment env, String inprgPath, String errorPath, Exception excep)
			throws Exception {
		log.error("STAGED - Moving the files to resp error from " + inprgPath);
		File inPrgFileDir = new File(inprgPath);
		KohlsDeltaDataPump dPump = new KohlsDeltaDataPump();
		if (inPrgFileDir.listFiles().length > 0) {
			for (File fle : inPrgFileDir.listFiles()) {
				log.info("STAGED - Moving the file " + fle);
				dPump.exceptionFileMove(fle.toString(), errorPath);
			}
		}
		YFCException exp = new YFCException(excep);
		String err = exp.getContainedException().toString();
		log.error("STAGED - Exception created " + exp.getLastErrorCode()
				+ exp.getContainedException().toString());
		dPump.raiseAlert(env, KohlsPOCConstant.DB_DELTA_IMPORT, err); // added bcz of throw is commented here
		KohlsDeploymentUtil dUtil = new KohlsDeploymentUtil();
		log.info("STAGED - Clearing cache after moving to error folder");
		dUtil.callModifyCache(env);
		log.info("STAGED - Cache clear completed.");
	}


	public static HashMap<String, String> getActiveTableSTGMap(Document docCommonCodeList) throws Exception {
		log.info("STAGED - Checking the table for active profile ");
		HashMap<String, String> activeTableSTGMap = new HashMap<String, String>();
		String strProfile = "", strStatus = "", strTable = "", strSTGTable = "";
		Element eleCommonCodeList = docCommonCodeList.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			strTable = eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE).trim();
			strStatus = eleCommonCode.getAttribute(KohlsConstants.CODE_LONG_DESC).trim();
			strProfile = eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION).trim();
			strSTGTable = eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_CODE_NAME).trim();
			log.debug("STAGED - strProfile  is " + strProfile);
			if (KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(strStatus)) {
				if (!strTable.equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
					activeTableSTGMap.put(strTable, strSTGTable);
				}
			}
		}
		return activeTableSTGMap;
	}

	public static boolean compareWithSysDeltaTime() throws Exception {
		Date currentDate = new Date();
		String stagingStTime = YFSSystem.getProperty(KohlsPOCConstant.DELTA_STAGE_START_TIME);
		String stagingEdTime = YFSSystem.getProperty(KohlsPOCConstant.DELTA_STAGE_END_TIME);
		int stagingStartTime = 0;
		int stagingEndTime = 0;
		if (YFCCommon.isVoid(stagingStTime) && YFCCommon.isVoid(stagingEdTime)) {
			stagingStartTime = 500;
			stagingEndTime = 2300;
		} else {
			stagingStartTime = Integer.parseInt(stagingStTime.replaceAll(":", ""));
			stagingEndTime = Integer.parseInt(stagingEdTime.replaceAll(":", ""));
		}

		SimpleDateFormat hourFrmt = new SimpleDateFormat("HHmm");
		int curHourMin = Integer.parseInt(hourFrmt.format(currentDate));
		log.info("STAGED - Checking system time range to process staged deltas " + "curHourMin : " + curHourMin
				+ " stagingStartTime : " + stagingStartTime + " stagingEndTime : " + stagingEndTime);
		if (curHourMin <= stagingStartTime || curHourMin >= stagingEndTime) {
			log.info("Processing staged files ");
			return true;
		} else {
			log.info("STAGED - Skipping the staged files processing ");
			return false;
		}
	}

	public HashMap<String, String> remapTableWithSTGTables(String syncXmlPath, Collection<String> finalDBList)
			throws Exception {
		File dumpFilePath = new File(syncXmlPath);
		File synXmlFile = null; 
		if (dumpFilePath.listFiles().length > 0) {
			for (File fle : dumpFilePath.listFiles()) {
				if (fle.getName().contains(KohlsPOCConstant.STG_SYNC_VER)) {
					synXmlFile = fle.getAbsoluteFile();
				}
			}
		}
		if (YFCCommon.isVoid(synXmlFile)) {
			throw new YFCException("STAGED - Sync version file not found " + synXmlFile);
		}
		log.info("STAGED - synXmlFile location " + synXmlFile);
		Document docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(synXmlFile.getAbsoluteFile());
		Element elmMapping = KohlsXPathUtil.getElementByXpath(docSyncVersion, "/SyncVersion/STGTableMapping");

		String[] tableList = elmMapping.getAttribute(KohlsPOCConstant.A_STG_TABLE_MAP).split(",");
		HashMap<String, String> tableSTGMap = new HashMap<String, String>();
		for (String tble : tableList) {
			String[] tableSTG = tble.split(":");
			for (String table : finalDBList) {
				if (tableSTG[0].equals(table)) {
					tableSTGMap.put(tableSTG[0], tableSTG[1]);
					log.info("STAGED - Added table and STG table " + tableSTG[0] + ", " + tableSTG[1]);
				}
			}
			log.debug("STAGED - Table and STG table list " + tble);
		}
		return tableSTGMap;
	}

	public String remapTableAndStgTableFromXml(String deltaCurPath) throws Exception {
		log.info("STAGED - synXmlFile location " + deltaCurPath);
		Document docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(deltaCurPath);
		Element elmMapping = KohlsXPathUtil.getElementByXpath(docSyncVersion, "/SyncVersion/STGTableMapping");
		String remappedTables = "";
		String tablesFromXml = elmMapping.getAttribute(KohlsPOCConstant.A_STG_TABLE_MAP);
		boolean first = true;
		for (String qq : tablesFromXml.split(",")) {
			log.debug("STAGED - Remapped Org and Stg tables " + remappedTables);
			String[] tableStgSplt = qq.split(":");
			if (first) {
				remappedTables += tableStgSplt[1] + ":" + tableStgSplt[0];
				first = false;
			} else {
				remappedTables = remappedTables + "," + tableStgSplt[1] + ":" + tableStgSplt[0];
			}
		}
		log.debug("STAGED - Remapped Org and Stg tables " + remappedTables);
		return remappedTables;
	}

	// Return the list of rank pl/sql messages based on the staged tables.
	public List<Document> recordRangeConstruction(YFSEnvironment env, String syncVerPath,
			Collection<String> updateToDBList, HashMap<String, String> getActTableSTGMapList) throws Exception {
		HashMap<String, ArrayList<Document>> patitionDoc = new HashMap<String, ArrayList<Document>>();
		ArrayList<String> tables = new ArrayList<String>();
		ResultSet resValues = null;
		try {
			int recordMax = Integer.parseInt(YFSSystem.getProperty(KohlsPOCConstant.RANK_RECORDS_PER_MERGE));
			String distTableList = "";
			boolean first = true;
			for (String table : updateToDBList) {
				if (first) {
					distTableList = "'" + table + "'";
					first = false;
				} else {
					distTableList = "'" + table + "'" + "," + distTableList;
				}
			}
			StringBuffer tableRecordsCountQuery = new StringBuffer(
					"SELECT TRIM(ENTITY) ENTITY, COUNT(*) AS COUNT FROM YFS_ENTITY_CHANGE WHERE ENTITY IN ("
							+ distTableList + ") GROUP BY ENTITY");
			log.info("Distinct table record count query formed : " + tableRecordsCountQuery);

			YFSContext ctx = (YFSContext) env;
			HashMap<String, String> tableRecordsCount = new HashMap<String, String>();
			prepStmt = ctx.getConnection().prepareStatement(tableRecordsCountQuery.toString());
			resValues = prepStmt.executeQuery();
			while (resValues.next()) {
				log.info("Table : " + resValues.getString(1) + ", Count : " + resValues.getString(2));
				tableRecordsCount.put(resValues.getString(1), resValues.getString(2));
			}
			for (String orgTable : tableRecordsCount.keySet()) {
				ArrayList<Document> rankDocList = new ArrayList<Document>();
				String tempTable = "";
				for (String orgMapTable : getActTableSTGMapList.keySet()) {
					if (orgMapTable.trim().equals(orgTable.trim())) {
						tempTable = getActTableSTGMapList.get(orgMapTable).trim();
					}
				}
				long totalRowCount = Long.parseLong(tableRecordsCount.get(orgTable));
				log.info("Total number of records for table " + orgTable + " - " + totalRowCount);
				if (totalRowCount > 0) {
					if (totalRowCount > recordMax) {
						long inc = 0;
						long numOfIterations = totalRowCount / recordMax;
						long remainOrderKeys = totalRowCount % recordMax;
						long remindRow = totalRowCount - remainOrderKeys + 1;
						for (int iterate = 0; iterate < numOfIterations; iterate++) {
							long maxRecordInc = inc + recordMax;
							long startRecord = inc + 1;
							rankDocList.add(constructRankMsgDoc(orgTable, tempTable, startRecord, maxRecordInc,
									syncVerPath, mergeFileMsg, KohlsPOCConstant.YES));
							inc = inc + recordMax;
							if (YFCLogUtil.isDebugEnabled())
								log.debug("Min and max keys are " + startRecord + ", " + maxRecordInc);
						}
						if (remainOrderKeys != 0) {
							rankDocList.add(constructRankMsgDoc(orgTable, tempTable, remindRow, totalRowCount,
									syncVerPath, mergeFileMsg, KohlsPOCConstant.YES));
							if (YFCLogUtil.isDebugEnabled())
								log.debug("Min and max keys are " + remindRow + ", " + totalRowCount);
						}
					} else {
						rankDocList.add(constructRankMsgDoc(orgTable, tempTable, Long.valueOf(1), totalRowCount,
								syncVerPath, mergeFileMsg, KohlsPOCConstant.YES));
						if (YFCLogUtil.isDebugEnabled())
							log.debug("Min and max keys are 1 " + ", " + totalRowCount);
					}
				}
				tables.add(orgTable);
				patitionDoc.put(orgTable, rankDocList);
			}
		} catch (Exception recordRangeConstructionEx) {
			log.error("Exception in recordRangeConstruction");
			throw recordRangeConstructionEx;
		} finally {
			if (resValues != null) {
				resValues.close();
			}
			YFSDBHome.closeStatement(prepStmt);
			prepStmt.close();
		}
		return mergeTablePartitions(patitionDoc, tables);
	}

	// Construct the rank message
	private Document constructRankMsgDoc(String primaryTable, String deltaTable, long startVal, long endVal,
			String xmlPath, String oraMessage, String isRankEnable) throws Exception {
		Document docMsg = SCXmlUtil.createDocument(KohlsPOCConstant.PARTITION);
		Element elmMsg = docMsg.getDocumentElement();
		elmMsg.setAttribute(KohlsPOCConstant.ATTR_PRIMARY_TABLE, primaryTable);
		elmMsg.setAttribute(KohlsPOCConstant.ATTR_PARTITION_TABLE, deltaTable);
		elmMsg.setAttribute(KohlsPOCConstant.RANK_BATCH_SIZE_START, String.valueOf(startVal));
		elmMsg.setAttribute(KohlsPOCConstant.RANK_BATCH_SIZE_END, String.valueOf(endVal));
		elmMsg.setAttribute(KohlsPOCConstant.ATTR_PARTITION_SYNC_XML, xmlPath);
		elmMsg.setAttribute(KohlsPOCConstant.RANK_ENABLED, isRankEnable);
		elmMsg.setAttribute("OraMessage", oraMessage);
		log.debug(SCXmlUtil.getString(docMsg));
		return docMsg;
	}
	
	// Get the columns for YFS_ENTITY_CHANGE table, exclude EXTN_RANK column
	private String getEntChgColumnNames(String strTableName) {
		log.info("Table name passed " + strTableName);
		EntityRepository entityRepos = (EntityRepository) YFCEntityRepositoryImpl.getInstance();
		Entity e1 = entityRepos.getEntityFromTableName(strTableName);
		List<Attribute> allAttribs = new ArrayList<Attribute>();
		allAttribs = e1.allAttributes();
		log.info("Attribute list is " + e1.allAttributes());
		StringBuffer strBuffColumnList = new StringBuffer();
		boolean first = false;
		for (Attribute colName : allAttribs) {
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("Column name is " + colName.getColumnName());
			}
			if (!KohlsPOCConstant.ENTITY_CHANGE_EXTN_RANK.equalsIgnoreCase(colName.getColumnName())) {
				if (first) {
					strBuffColumnList.append(",");
				}
				strBuffColumnList.append(colName.getColumnName());
				first = true;
			}
		}
		return strBuffColumnList.toString();
	}


	// Populate the YFS_ENTITY_CHANGE changes into temp table with ranking
	public void populateEntityChanges(YFSContext ctx, String parQuery, String sUserName, String podName)
			throws Exception {
		log.info("PopulateEntityChanges started");
		boolean entityTableExist = tableExistsCheck(ctx, KohlsPOCConstant.YFS_ENTITY_CHANGE + "_" + podName, sUserName);
		try {
			String columnList = getEntChgColumnNames(KohlsPOCConstant.YFS_ENTITY_CHANGE);
			String rankSelQuery = "SELECT RANK() OVER (PARTITION BY ENTITY ORDER BY ENTITY_KEY) \"EXTN_RANK\"" + ","
					+ columnList + " FROM " + sUserName + ".YFS_ENTITY_CHANGE ";
			PLTQueryBuilder qryBuilder = new PLTQueryBuilder(false);
			if (entityTableExist) {
				qryBuilder
						.append("INSERT INTO " + sUserName + ".YFS_ENTITY_CHANGE_" + podName + "(EXTN_RANK," + columnList + ") ");
			} else {
				qryBuilder.append(
						"CREATE TABLE " + sUserName + ".YFS_ENTITY_CHANGE_" + podName + "(EXTN_RANK," + columnList + ") AS ");
			}
			qryBuilder.append(
					parQuery.replace("\"", "").replace("QUERY=", "")
							.replace("SELECT * FROM YFS_ENTITY_CHANGE", rankSelQuery)
							.replace("YFS_ENTITY_CHANGE:", rankSelQuery));

			log.info("Populating entity changes query " + qryBuilder.getReadableWhereClause());
			prepStmt = ctx.getConnection().prepareStatement(qryBuilder.getReadableWhereClause(true));
			int copyCount = 0;
			copyCount = prepStmt.executeUpdate();
			ctx.commit();
			log.info("No of entity records inserted " + copyCount);
		} catch (Exception ce) {
			log.error("Exception during the populateEntityChanges");
			throw ce;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			prepStmt.close();
		}
		log.info("PopulateEntityChanges completed");
	}

	// Check the yfs entity change temp table exists and truncate the data
	private boolean tableExistsCheck(YFSContext ctx, String tableName, String userName) throws Exception {
		boolean tableExists = false;
		String partitionID = ctx.getPoolResolver().pushPartition("tableExistsCheck");
		try {
			ctx.getPoolResolver().addFact("TableType", "MASTER");
			PLTQueryBuilder oPLT = new PLTQueryBuilder(false);
			oPLT.append("SELECT COUNT(*) AS COUNT FROM DBA_TABLES WHERE TABLE_NAME ='" + tableName + "'");
			stmt = ctx.getConnectionForTable(tableName).createStatement();
			ResultSet resultSetTempTable = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			resultSetTempTable.next();
			int val = Integer.parseInt(resultSetTempTable.getString("COUNT"));
			log.info("Table exists value " + val);
			if (val != 0) {
				try {
					ResultSet rSetTruncate = stmt.executeQuery("TRUNCATE TABLE " + userName + "." + tableName);
					rSetTruncate.close();
					ctx.commit();
					log.info(userName + "." + tableName + " Table exists and truncated");
				} catch (Exception e) {
					throw e;
				}
				tableExists = true;
			}
			resultSetTempTable.close();
		} catch (Exception tableExistsCheckEx) {
			log.error("Exception in tableExistsCheck");
			throw tableExistsCheckEx;
		} finally {
			YFSDBHome.closeStatement(stmt);
			if (YFCLogUtil.isDebugEnabled()) {
				log.debug("Popping partitionID " + partitionID);
			}
			ctx.getPoolResolver().popPartition(partitionID);
		}
		return tableExists;
	}

	// Check the type of merge to be performed after import
	public static String checkForRankEnabled(String syncXmlCurPath) throws Exception {
		log.info("STAGED - syncXmlCurPath location " + syncXmlCurPath);
		String dumpFileName = "";
		Document docSyncVersion = null;
		String isRankEnabled = KohlsPOCConstant.NO;

		File dumpFilePath = new File(syncXmlCurPath);
		if (dumpFilePath.isDirectory()) {
			File[] files = dumpFilePath.listFiles();
			for (File f : files) {
				dumpFileName = f.getName();
				if (dumpFileName.contains(KohlsPOCConstant.V_SYNC_VERSION)) {
					docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(f);
					break;
				}
			}
		} else {
			docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(syncXmlCurPath);
		}
		Element elmMapping = KohlsXPathUtil.getElementByXpath(docSyncVersion, "/SyncVersion/STGTableMapping");
		if (!YFCCommon.isVoid(elmMapping)
				&& !YFCCommon.isVoid(elmMapping.getAttribute(KohlsPOCConstant.A_STG_TABLE_MAP).trim())) {
			log.info("STAGED - Mapping values " + elmMapping.getAttribute(KohlsPOCConstant.A_STG_TABLE_MAP));
			if (elmMapping.getAttribute(KohlsPOCConstant.A_STG_TABLE_MAP).trim()
					.contains(KohlsPOCConstant.YFS_ENTITY_CHANGE)) {
				isRankEnabled = KohlsPOCConstant.YES;
			}
		}
		return isRankEnabled;
	}

	// Get the system date
	public static Date currentDate() {
		Date dt = new Date();
		return dt;
	}
}
