package com.kohls.poc.util;

import com.yantra.yfc.log.YFCLogCategory;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.common.TopicPartition;

import java.util.Collection;

/**
 * Created by tkma36l on 3/10/21.
 */
public class KohlsPoCKafkaResetRebalancer implements ConsumerRebalanceListener {

    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCKafkaResetRebalancer.class);

    private final Consumer<Long, String> consumer;

    public KohlsPoCKafkaResetRebalancer(Consumer<Long, String> consumer) {
        this.consumer = consumer;
    }

    @Override
    public void onPartitionsRevoked(Collection<TopicPartition> collection) {

    }

    @Override
    public void onPartitionsAssigned(Collection<TopicPartition> collection) {
        if (!collection.isEmpty())
            for (TopicPartition topicPartition : collection) {
                consumer.seekToBeginning(topicPartition);
                logger.info(topicPartition.topic() + " - TopicPartition is set to beginning");
            }
    }
}
