package com.kohls.poc.util;

import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.kohls.poc.util.KohlsPoCXApiInvoker;

import java.io.BufferedReader;
import java.io.InputStreamReader;



import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


/**************************************************************************
 * File : KohlsPoCHTTPPostConnUtil.java 
 * Author : IBM Created : Dec 11 2015
 * Modified : Dec 11 2015 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 14/06/2013 IBM First Cut.
 ***************************************************************************** 
 * 
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file updates the training env with pinpad details using interop servlet
 * @author IBM
 * @version 0.1
 *****************************************************************************/
 
public class KohlsPoCHTTPPostConnUtil extends KOHLSBaseApi {
	
	
	private static final YFCLogCategory 
 	loggerForHttpPostConn = YFCLogCategory
		.instance(KohlsPoCHTTPPostConnUtil.class.getName());
	
	
	/**
 	 * This function calls the method to call interopAPI to update
 	 * the pin pad details using training environment
 	 * 
 	 * @param env
 	 * @param docPSIStatusList
 	 * @param strTrnModeUrl
	 * @throws Exception 
 	 * @exception YFSException
 	 *           
 	 */
	 public void updatePinPadDetails(YFSEnvironment env, Document docPSIStatusList,String strTrnModeUrl, String strUserID)
	 {
		 loggerForHttpPostConn.beginTimer("KohlsPoCHTTPPostConnUtil.updatePinPadDetails");
		 loggerForHttpPostConn.debug("Input Xml to KohlsPoCHTTPPostConnUtil.updatePinPadDetails method is: "+XMLUtil.getXMLString(docPSIStatusList));
		 
		 Element elePSIStatus;
		 
		try {
			elePSIStatus = (Element)((NodeList)XPathUtil.getNodeList(docPSIStatusList, "/PSIStatusList/PSIStatus")).item(0);
			//Starrt - Defect #3100
			elePSIStatus.removeAttribute("PSIStatusKey");
			loggerForHttpPostConn.debug("KohlsPoCHTTPPostConnUtil.updatePinPadDetails ----after removing PSIStatusKey is"+XMLUtil.getElementXMLString(elePSIStatus));
			//End - Defect #3100
			if(!YFCCommon.isVoid(elePSIStatus))
			{
				//invokeInteropAPI(KohlsPOCConstant.API_MANAGE_PSI_STATUS_FOR_POS,false,elePSIStatus,strTrnModeUrl,strUserID);
				invokeInteropAPIThroughCertificate(KohlsPOCConstant.API_MANAGE_PSI_STATUS_FOR_POS,elePSIStatus,strTrnModeUrl,strUserID);
			
			}
		} catch (Exception e) {
			loggerForHttpPostConn.debug("KohlsPoCHTTPPostConnUtil.updatePinPadDetails ---- Error out");
			 e.printStackTrace();
			loggerForHttpPostConn.endTimer("KohlsPoCHTTPPostConnUtil.updatePinPadDetails");

	}
	loggerForHttpPostConn.endTimer("KohlsPoCHTTPPostConnUtil.updatePinPadDetails");
}


	 public void invokeInteropAPIThroughCertificate(String sAPIName,Element sAPIInput,String strTrnModeUrl,String strUserID) throws Exception {
		 loggerForHttpPostConn.beginTimer("invokeInteropAPIThroughCertificate - begin");
		 try {
			 KohlsPoCXApiInvoker invoker = new  KohlsPoCXApiInvoker();
			 //Changes for KeyStore password decryption - Start
			 //String strPass = getPropertyValue(KohlsPOCConstant.STR_LOGIN_PASSWORD);
			 KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
			 String mykey = restApiutil.pwdForDecryption("PP");
			 String strKeystorepath = getPropertyValue(KohlsPOCConstant.STR_KSPath);
			 String strKeystorepass = restApiutil.decryptString(getPropertyValue(KohlsPOCConstant.STR_KSPassword), mykey);
			 //Changes for KeyStore password decryption - End
			 invoker.setUserId(strUserID);
			 //invoker.setPassword(strPass);
			 invoker.setProgId(KohlsPOCConstant.STR_ENV_PROGID_VALUE);
			 invoker.initialize(strKeystorepath, strKeystorepass, strUserID, strTrnModeUrl);
			 loggerForHttpPostConn.debug("The initialization is set");
			 Document retDoc = invoker.invoke(sAPIInput, sAPIName);
			 loggerForHttpPostConn.debug("The invoker is called" + XMLUtil.getXMLString(retDoc));
			 invoker.shutdown();
		 } catch (Exception e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
			 YFSException yfsException = (YFSException) e;
			 throw yfsException;
		 }
		 loggerForHttpPostConn.endTimer("invokeInteropAPIThroughCertificate - end");
	 }
	 
	 
	 
	/**
 	 * This function gets the url from customer_overrides.properties
 	 *
 	 * @param property
 	 *
 	 */

	public static String getPropertyValue(String property)
	{
		loggerForHttpPostConn.beginTimer("KohlsPoCHTTPPostConnUtil.getPropertyValue");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		// customer_overrides.properties does not return any value
		if(YFCCommon.isVoid(propValue)){
			loggerForHttpPostConn.debug("##############################Property is empty#################################");
			propValue = "";
		}
		loggerForHttpPostConn.endTimer("KohlsPoCHTTPPostConnUtil.getPropertyValue");
		return propValue;
	}

}
