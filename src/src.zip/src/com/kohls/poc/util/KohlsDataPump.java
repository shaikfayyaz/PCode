package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.dbclasses.YFS_Entity_ChangeDBHome;
import com.yantra.shared.dbi.YFS_Sync_DB_Export;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.core.YCPContext;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

// This custom API is used to export a table.
public class KohlsDataPump extends YCPBaseAgent {

	static Logger log = Logger.getLogger(KohlsDataPump.class.getName());
	public static final String FILENAME_SYNC_VERSION = "iss_export_SyncVersion_";
	public static final String ORACLE_PROCEDURE = "K_UTIL.K_UAPG_APP_GRAVITY_STERLING.K_UASP_POST_DPLY";	
	public static final String REGEX_PASSWORD = "/.*?@";
	public static final String REGEX_REPLACEMENT = "/*****";
	public static final String UNPACK_SQL_PROFILE = "{call DBMS_SQLTUNE.UNPACK_STGTAB_SQLPROF"
			+ "(staging_schema_owner=>'K_UTIL',"
			+ "REPLACE=> TRUE,"
			+ "staging_table_name=>'SQL_PROFILES')}";	
	private static final String GATHER_SCHEMA_STATS ="SYS.DBMS_STATS.GATHER_SCHEMA_STATS (OwnName => 'STERLING',"
			+ "Granularity => 'DEFAULT',Options => 'GATHER',Gather_Temp => FALSE,Estimate_Percent => SYS.DBMS_STATS.AUTO_SAMPLE_SIZE,"
			+ "Method_Opt => 'FOR ALL INDEXED COLUMNS SIZE AUTO ',Degree => 2,Cascade => TRUE ,No_Invalidate => FALSE)";
	public static Date expImpTimeStamp = null;
	public String strAllActiveProfileTableList = "";
	public String tableSpacesFromXml = "";
	public static String sConfigProfile = "";   
	public static String schemaName = "";
	private static Statement stmt = null;
	boolean isPodMigrationActive = false;
	boolean isConfigurationProfileActive = false;
	boolean bSyncVersionFileExists = false;
	boolean zeroDump = false, cdtFlag = false;
	boolean syncVerFlag = false;
	Connection conn = null;
	String actionName = null, timeStamp = null;
	String sMasterPoolId = null, sConfigPoolId = null, strSequenceNoImport = null;

	private static YIFApi oApi = null;

	private void createMapDir(YFSEnvironment env, String actionName)
			throws SQLException, ClassNotFoundException, Exception {
		String sqlMapDir = "";
		try {
			if (actionName.equalsIgnoreCase(KohlsPOCConstant.A_IMPORT)) {
				sqlMapDir = "CREATE OR REPLACE DIRECTORY data_pump_import_directory AS '"
						+ getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR) + "'";				
			} else if (actionName.equalsIgnoreCase(KohlsPOCConstant.A_EXPORT)) {
				sqlMapDir = "CREATE OR REPLACE DIRECTORY data_pump_export_directory AS '"
						+ getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR) + "'";
			} else if (actionName.equalsIgnoreCase(KohlsPOCConstant.A_SQL_TUNING)) {
				sqlMapDir = "CREATE OR REPLACE DIRECTORY data_pump_sql_directory AS '"
						+ KohlsPOCConstant.DB_DMP_INPGROGRESS_PATH + "'";
			}
			YCPContext context = (YCPContext) env;
			conn = context.getDBConnection();
			stmt = conn.createStatement();
			log.info("SQL Map Directory statement " + sqlMapDir);
			stmt.executeUpdate(sqlMapDir);
			stmt.close();
		} catch (Exception e) {
			log.error("Exception while creating directory " + e.toString());
			throw e;
		}
	}

	/**
	 * @param env
	 * @throws IOException
	 * @throws Exception
	 */
	private void exportTables(YFSEnvironment env) throws IOException, Exception {
		try {
			log.info("Export is in progress");
			actionName = KohlsPOCConstant.A_EXPORT;
			timeStamp = new SimpleDateFormat(KohlsPOCConstant.EXPORT_TABLES_DATE_FORMAT).format(new java.util.Date());
			Document docCommonCodeList = callGetCommonCodeList(env, KohlsPOCConstant.DATASYNC_PROFLE_FULL);

			HashMap<String, String> hashMapActiveProfileTableList = getActiveProfileTableListMap(docCommonCodeList);
			// Non-Pod migration, use common codes to do selective profile
			// updates in tables and sync_version file, Master profiles are
			// enabled, create dump and update sync version file
			if (hashMapActiveProfileTableList.size() != 0) {
				createExportDumpFiles(env);
				// MASTER db updates and SyncVersion file update
				if (!isPodMigrationActive) {
					manageMasterUpdates(env, hashMapActiveProfileTableList);
				}
			} else {
				// All master profiles disabled, create zero_ins_update dump
				log.info("No active master profiles to export");
				String zeroDumpFileInsUpd = getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE)
						+ KohlsPOCConstant.BACKWARD_SLASH + KohlsPOCConstant.ZERO_INS_UPD_DMP;
				createZeroDumpFile(zeroDumpFileInsUpd, "");
				zeroDump = true ;
			}

			// Config profiles are enabled, create CDT and update sync version
			if (isConfigurationProfileActive) {
				log.info("isConfigurationProfileActive value " + isConfigurationProfileActive);
				manageConfigUpdates(env);
				cdtFlag = true;
			} else {
				log.info("No active Config profiles to export");
				String zeroDumpFile = getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE)
						+ KohlsPOCConstant.BACKWARD_SLASH + KohlsPOCConstant.ZERO_CDT_ZIP;
				createZeroDumpFile(zeroDumpFile, "");					
			}
			
			if (isPodMigrationActive) {
				log.info("isPodMigrationActive value " + isPodMigrationActive);
				manageSyncDB(env, strAllActiveProfileTableList);
				zeroDump = false;
			}

			SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
			String syncDBDate = sdf.format(expImpTimeStamp);
			KohlsDeploymentUtil kdUtil = new KohlsDeploymentUtil();
			ArrayList<String> profilesList = new ArrayList<String>();
			for (String p11 : hashMapActiveProfileTableList.keySet()) {
				profilesList.add(p11);
			}
			
			// Custom table entry for master
			if (hashMapActiveProfileTableList.size() != 0) {
					log.info("Setting lastFullOrDeltaSyncDate to KOHLS_POS_DATAPUMP_SYNC_PROCESS table "
							+ KohlsPOCConstant.TABLE_TYPE_MASTER);
				kdUtil.manageSyncProcessRecordExpImp((YFSContext) env, KohlsPOCConstant.A_EXPORT,
						KohlsPOCConstant.SYNC_FULL, KohlsPOCConstant.CORP, KohlsPOCConstant.TABLE_TYPE_MASTER,
						profilesList, syncDBDate);
			}
	
			// Custom table entry for config
			if (isConfigurationProfileActive) {
				log.info("Setting lastFullOrDeltaSyncDate to KOHLS_POS_DATAPUMP_SYNC_PROCESS table "
						+ KohlsPOCConstant.A_CONFIGURATION);				
				kdUtil.manageSyncProcessRecordExpImp((YFSContext) env, KohlsPOCConstant.A_EXPORT,
						KohlsPOCConstant.SYNC_FULL, KohlsPOCConstant.CORP, KohlsPOCConstant.A_CONFIGURATION,
						profilesList, syncDBDate);
			}			
						
			log.info("Flag values are cdtFlag " + cdtFlag + " zeroDump " + zeroDump + " " + timeStamp);
			String versionXmlFile = getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE)
					+ KohlsPOCConstant.BACKWARD_SLASH + FILENAME_SYNC_VERSION
					+ timeStamp + KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION;
			
			if (!isConfigurationProfileActive && zeroDump) {
				createZeroDumpFile(versionXmlFile, "");
			} else {
				// CPD-2914 Added the below method
				if (!YFCCommon.isVoid(strAllActiveProfileTableList)) {
					KohlsDeploymentUtil dplutil = new KohlsDeploymentUtil();
					String tableSpaceTablesList = KohlsPOCConstant.A_SINGLE_QUOTE
							+ strAllActiveProfileTableList.replaceAll(",", "','") + KohlsPOCConstant.A_SINGLE_QUOTE;
					dplutil.tableSpacesFromDB(env, tableSpaceTablesList, schemaName, versionXmlFile);
				} else {
					log.info("No active tables,so tablespaces are not retrieved");
				}
			}
		} catch (Exception e) {
			log.error("Exception exportTables " + e.toString());
			throw e;
		}
	}

	private void createZeroDumpFile(String zeroDumpFile, String content) throws IOException {
		log.info("Creating file with name " + zeroDumpFile);
		FileWriter writer = new FileWriter(zeroDumpFile);
		writer.write(content);
		writer.close();
	}

	private void manageConfigUpdates(YFSEnvironment env) throws Exception {
		KohlsCDTUtil cdtUtil = new KohlsCDTUtil();
		cdtUtil.exportCDT(env, SCXmlUtil.createDocument(KohlsPOCConstant.A_EXPORT));
		log.info("Updating the configuration profiles");
		if (!isPodMigrationActive) {
			String syncVerForD = manageSyncDBUpdateForConfig(env, sConfigProfile, KohlsPOCConstant.DEFAULT);
			appendConfigVersion(syncVerForD);
			updateSyncExportedForConfig((YFSContext) env);
		}
	}

	
	private HashMap<String, String> getActiveProfileTableListMap(Document docCommonCodeList) {
		log.info("Checking the active profile");
		HashMap<String, String> profileIdTableListMap = new HashMap<String, String>();
		String strProfile = "", strStatus = "", strTable = "";
		strAllActiveProfileTableList=""; //clearing for the next run
		Element eleCommonCodeList = docCommonCodeList.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			strTable = eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE);
			strStatus = eleCommonCode.getAttribute(KohlsConstants.CODE_LONG_DESC);
			strProfile = eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION);
			log.info("strProfile " + strProfile);
			if (KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(strStatus)) {
				if (strTable.equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
					isConfigurationProfileActive = true;
					log.info("isConfigurationProfileActive in getActiveProfileTableListMap"
							+ isConfigurationProfileActive);
					sConfigProfile = strProfile;
				} else if (strProfile.equalsIgnoreCase(KohlsPOCConstant.P_POD_MIGRATION)) {
					log.info("isPodMigrationActive in getActiveProfileTableListMap" + isPodMigrationActive);
					isPodMigrationActive = true;
				} else {
					if (strAllActiveProfileTableList.isEmpty()) {
						strAllActiveProfileTableList = strTable;
					} else {
						strAllActiveProfileTableList = strAllActiveProfileTableList + ',' + strTable;
						log.info("Active table is " + strTable);
					}
					if (!strProfile.equalsIgnoreCase(KohlsPOCConstant.P_INITIAL_ISS_D)) {
						profileIdTableListMap.put(strProfile, strTable);
					}
				}
			} else {
				log.info("Inactive profile is " + strProfile);
			}
		}
		log.info("Final table list to export is " + strAllActiveProfileTableList);
		return profileIdTableListMap;
	}

	public static void globalDate() {
		expImpTimeStamp = new Date();
		log.info("Global date for all export is " + expImpTimeStamp);
	}

	public static void moveFilesUsingFileStream(File sourceFile, File destFile) throws IOException {
		log.info("Moving files from " + sourceFile + " to " + destFile);
		InputStream in = null;
		OutputStream out = null;
		try {
			in = new FileInputStream(sourceFile);
			out = new FileOutputStream(destFile);
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			log.info("Deleting the file after copy");
			sourceFile.delete();
		} finally {
			in.close();
			out.close();
		}
	}

	private void moveFiles(String dumpFileName, String logFileName) throws IOException {

		if (KohlsPOCConstant.EXPDAT_DMP.equals(dumpFileName)) {
			File file1 = new File(
					KohlsPOCConstant.DB_DMP_INPGROGRESS_PATH + KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);
			File file2 = new File(KohlsPOCConstant.DB_DMP_DONE_PATH + KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);
			moveFilesUsingFileStream(file1, file2);

			File file3 = new File(
					KohlsPOCConstant.DB_DMP_INPGROGRESS_PATH + KohlsPOCConstant.BACKWARD_SLASH + logFileName);
			File file4 = new File(KohlsPOCConstant.DB_DMP_ARCHIVE_PATH + KohlsPOCConstant.BACKWARD_SLASH + logFileName);
			moveFilesUsingFileStream(file3, file4);
			return;
		}
      
		File file1 = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);     

		File file2 = new File(
				getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);
		 
		moveFilesUsingFileStream(file1, file2); 
		File file3 = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + logFileName);
		File file4 = new File(
				getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH + logFileName);
		moveFilesUsingFileStream(file3, file4); 
	}

	private void manageSyncDB(YFSEnvironment env, String strAllActiveProfileTableList) throws Exception {
		// Get syncProfiles
		log.info("Export is in progress");
		log.info("Beginning manageSyncDB with strAllActiveProfileTableList " + strAllActiveProfileTableList);
		Document docSyncProfile = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_PROFILE);
		Document docSyncProfileListOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST_TEMPLATE_PATH, KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST,
				docSyncProfile);
		log.info("docSyncProfileListOutput is " + SCXmlUtil.getString(docSyncProfileListOutput));
		Document docSyncVersion = YFCDocument.createDocument(KohlsPOCConstant.V_SYNC_VERSION).getDocument();
		if (docSyncProfileListOutput != null) {
			ArrayList<Element> profileList = SCXmlUtil.getChildren(docSyncProfileListOutput.getDocumentElement(),
					KohlsPOCConstant.E_SYNC_PROFILE);
			for (Element profile : profileList) {
				String sSyncProfileID = profile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
				String sTableGroup = profile.getAttribute(KohlsPOCConstant.A_TABLE_GROUP);
				String sOrganizationCode = profile.getAttribute(KohlsConstant.A_ORGANIZATION_CODE);
				log.info("Current sSyncProfileID : " + sSyncProfileID + ", sTableGroup : " + sTableGroup
						+ ", sOrganizationCode : " + sOrganizationCode);
				manageSyncDBUpdate(env, sSyncProfileID, sTableGroup, sOrganizationCode, docSyncVersion);
				}
			
			updateSyncExportedForMaster((YFSContext) env, strAllActiveProfileTableList);
			updateSyncExportedForConfig((YFSContext) env);

			FileWriter writer = new FileWriter(
					getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH
							+ FILENAME_SYNC_VERSION + timeStamp + KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION);
			writer.write(SCXmlUtil.getString(docSyncVersion));
			writer.close();
			if (log.isDebugEnabled())
				log.info("manageSyncDB docSyncVersion is " + SCXmlUtil.getString(docSyncVersion));
		}
	}

	/**
	 * @param env
	 * @param syncProfile
	 * @param docSyncVersion
	 * @param strExportType
	 * @throws Exception
	 */
	public void manageSyncDBUpdate(YFSEnvironment env, String syncProfile, String TableGroup, String ProfileOrgCode,
			Document docSyncVersion) {
		log.info("Manage SyncDB Update begin for profile " + syncProfile);
		log.info("TableGroup is " + TableGroup);
		Document docExportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_EXPORT).getDocument();
		Element eleExportSyncDB = docExportSyncDB.getDocumentElement();

		try {
			String finalSeqNo = null;
			eleExportSyncDB.setAttribute(KohlsPOCConstant.A_TABLE_GROUP, TableGroup);
			SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_UPDATE_DATE_FORMAT);
			YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
			String syncDBDate = sdf.format(yfcCurrntDt);

			log.info("getSyncDBExportList Input  in manageSyncDBUpdate " + XMLUtil.getXMLString(docExportSyncDB));
			Document getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
					KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST, docExportSyncDB);
			log.info("getSyncDBExportList output in manageSyncDBUpdate "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

			finalSeqNo = getSequenceNumber(getSyncDBExportListOutputDoc, syncProfile);

			Element eleProfile = SCXmlUtil.createChild(docSyncVersion.getDocumentElement(), KohlsPOCConstant.E_PROFILE);
			log.info("eleProfile is before attr addition " + SCXmlUtil.getString(eleProfile));
			eleProfile.setAttribute(KohlsPOCConstant.A_NAME, syncProfile);
			eleProfile.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, finalSeqNo);
			eleProfile.setAttribute(KohlsPOCConstant.A_ORG_CODE, ProfileOrgCode);
			log.info("eleProfile is after attr addition " + SCXmlUtil.getString(eleProfile));
			log.info("docSyncVersion now is " + SCXmlUtil.getString(docSyncVersion));

			// Actual query to insert
			String TABLE_GROUP_EXPORT = XMLUtil.getAttribute(eleExportSyncDB, KohlsPOCConstant.A_TABLE_GROUP);
			log.info("TABLE_GROUP_EXPORT in manageSyncDBUpdate " + TABLE_GROUP_EXPORT);

			YCPContext ctx = (YCPContext) env;
			YFS_Sync_DB_Export exportEntity = YFS_Sync_DB_Export.newInstance();
			exportEntity.setDBContextRecursive(ctx);
			exportEntity.setSync_Type(KohlsPOCConstant.SYNC_FULL);
			exportEntity.setSequence_No(finalSeqNo);
			exportEntity.setDB_Export_Time(yfcCurrntDt);
			exportEntity.setSync_Profile_ID(syncProfile);
			exportEntity.setTableGroup(TABLE_GROUP_EXPORT);
			exportEntity.setOrganization_Code(ProfileOrgCode);

			log.info("Inserting new record into YFS_SYNC_DB_EXPORT:\nOrganizationCode: "
					+ exportEntity.getOrganization_Code() + "\nSyncProfileID: " + exportEntity.getSync_Profile_ID()
					+ "\nSyncType: " + exportEntity.getSync_Type() + "\nTableGroup: " + exportEntity.getTableGroup()
					+ "\nSequenceNo: " + exportEntity.getSequence_No() + "\n");

			exportEntity.insert();

			//The below api call is to verify if the records are inserted correctly
			getSyncDBExportListOutputDoc = null;
			getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST,
					docExportSyncDB);
			log.info("Post Insert -> getSyncDBExportList output in manageSyncDBUpdate "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

		} catch (Exception e) {
			log.error("Exception manageSyncDBUpdate is " + e.toString());
			throw new YFCException("Exception in manageSyncDBUpdate");
		}
	}

	private void manageMasterUpdates(YFSEnvironment env, HashMap<String, String> hashMapActiveProfileTableList)
			throws Exception {
		log.info("Beginning manageMasterUpdates ");
		Document docSyncProfile = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_PROFILE);
		Document docSyncProfileListOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST_TEMPLATE_PATH, KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST,
				docSyncProfile);
		log.info("docSyncProfileListOutput is " + SCXmlUtil.getString(docSyncProfileListOutput));
		Document docSyncVersion = YFCDocument.createDocument(KohlsPOCConstant.V_SYNC_VERSION).getDocument();

		// MASTER PROFILES UPDATE
		if (docSyncProfileListOutput != null) {
			ArrayList<Element> profileList = SCXmlUtil.getChildren(docSyncProfileListOutput.getDocumentElement(),
					KohlsPOCConstant.E_SYNC_PROFILE);
			for (Element profile : profileList) {
				String sSyncProfileID = profile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
				if (hashMapActiveProfileTableList.containsKey(sSyncProfileID)) {
					String sTableGroup = profile.getAttribute(KohlsPOCConstant.A_TABLE_GROUP);
					String sOrganizationCode = profile.getAttribute(KohlsConstant.A_ORGANIZATION_CODE);
					manageSyncDBUpdateForMaster(env, sSyncProfileID, sTableGroup, sOrganizationCode, docSyncVersion,
							hashMapActiveProfileTableList.get(sSyncProfileID));
				}
			}
			
			updateSyncExportedForMaster((YFSContext) env, strAllActiveProfileTableList);
			FileWriter writer = new FileWriter(
					getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH
							+ FILENAME_SYNC_VERSION + timeStamp + KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION);
			writer.write(SCXmlUtil.getString(docSyncVersion));
			writer.close();
			log.info("manageMasterUpdates docSyncVersion is " + SCXmlUtil.getString(docSyncVersion));
		}
	}
	
	private void updateSyncExportedForConfig(YFSContext ctx) throws SQLException {
		log.info("Starting Update Sync Exported for config");
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		String strCurrentDate = sdf.format(date);
		PLTQueryBuilder oPLT = new PLTQueryBuilder(false);
		oPLT.append("UPDATE YFS_ENTITY_CHANGE SET SYNC_EXPORTED='Y' WHERE SYNC_EXPORTED='N' AND MODIFYTS < to_date(\'"
				+ strCurrentDate
				+ "\',"
				+ "\'"
				+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");

		log.info("UpdateSyncExportedForConfig query being fired " + oPLT.getReadableWhereClause());
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.info("Executing SQL: " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			log.info("Updated Sync Exported Flag ");
			rs.close();
		} catch (Exception ex) {
			log.error("Error occurred");
			throw ex;
		} finally {
			YFSDBHome.closeStatement(stmt);
		}
	}

	private void appendConfigVersion(String syncVerForD) throws Exception {
		log.info("Update the sync version");
		File dumpFilePath = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH
				+ FILENAME_SYNC_VERSION + timeStamp + KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION);

		log.info("Dump File Path is " + dumpFilePath.getAbsolutePath());
		log.info("DumpFile name is " + dumpFilePath.getName());
		FileWriter writer;
		Element eleSyncVersionDocument = null;
		if (dumpFilePath.exists()) {
			Document docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(dumpFilePath);
			log.info("syncVersionDoc is " + SCXmlUtil.getString(docSyncVersion));
			eleSyncVersionDocument = docSyncVersion.getDocumentElement();
			log.info("Updating the file for sync version of config");
		} else {
			Document docSyncVersion = YFCDocument.createDocument(KohlsPOCConstant.V_SYNC_VERSION).getDocument();
			eleSyncVersionDocument = docSyncVersion.getDocumentElement();
			log.info("Writing the new file sync version for config");
		}
		writer = new FileWriter(dumpFilePath);
		log.info("eleSyncVersionDocument in appendConfigVersion " + SCXmlUtil.getString(eleSyncVersionDocument));
		Element eleProfileD = SCXmlUtil.createChild(eleSyncVersionDocument, KohlsPOCConstant.E_PROFILE);
		eleProfileD.setAttribute(KohlsPOCConstant.A_NAME, sConfigProfile);
		eleProfileD.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, KohlsPOCConstant.DEFAULT);
		eleProfileD.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, syncVerForD);
		log.info("Adding config profile element " + SCXmlUtil.getString(eleProfileD));

		log.info("Updating the writer for sync version of config");
		writer.write(SCXmlUtil.getString(eleSyncVersionDocument));
		writer.close();
	}

	public String manageSyncDBUpdateForConfig(YFSEnvironment env, String syncProfile, String ProfileOrgCode)
			throws Exception {
		log.info("Manage SyncDB Update begin for config profile" + syncProfile);
		Document docExportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_EXPORT).getDocument();
		Element eleExportSyncDB = docExportSyncDB.getDocumentElement();
		String fullSeqNo = "";

		try {
			String finalSeqNo = "";
			eleExportSyncDB.setAttribute(KohlsPOCConstant.A_TABLE_GROUP, KohlsPOCConstant.CONFIGURATION);
			SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_UPDATE_DATE_FORMAT);
			String syncDBDate = sdf.format(expImpTimeStamp);

			log.info("getSyncDBExportList Input  in API_GET_SYNC_DB_EXPORT_LIST is "
					+ XMLUtil.getXMLString(docExportSyncDB));
			Document getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
					KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST, docExportSyncDB);
			log.info("getSyncDBExportList output in API_GET_SYNC_DB_EXPORT_LIST is "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

			fullSeqNo = getSequenceNumber(getSyncDBExportListOutputDoc, syncProfile);
			log.info("fullSyncSeqNo " + fullSeqNo);

			YCPContext ctx = (YCPContext) env;
			YFS_Sync_DB_Export exportEntity = YFS_Sync_DB_Export.newInstance();
			exportEntity.setDBContextRecursive(ctx);
			exportEntity.setSync_Type(KohlsPOCConstant.SYNC_FULL);
			exportEntity.setSequence_No(fullSeqNo);
			exportEntity.setDB_Export_Time(YFCDate.getYFCDate(syncDBDate));
			exportEntity.setSync_Profile_ID(syncProfile);
			exportEntity.setTableGroup(KohlsPOCConstant.CONFIGURATION);
			exportEntity.setOrganization_Code(ProfileOrgCode);

			log.info("Inserting new record into YFS_SYNC_DB_EXPORT:\nOrganizationCode: "
					+ exportEntity.getOrganization_Code() + "\nSyncProfileID: " + exportEntity.getSync_Profile_ID()
					+ "\nSyncType: " + exportEntity.getSync_Type() + "\nTableGroup: " + exportEntity.getTableGroup()
					+ "\nSequenceNo: " + exportEntity.getSequence_No() + "\n");

			exportEntity.insert();
			getSyncDBExportListOutputDoc = null;
			getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST,
					docExportSyncDB);
			log.info("Post Insert getSyncDBExportList output in manageSyncDBUpdate is "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

		} catch (Exception e) {
			log.error("Exception manageSyncDBUpdate() is " + e.toString());
			throw e;
		}
		return fullSeqNo;
	}

	private void createExportDumpFiles(YFSEnvironment env) throws Exception {
		try {
			Document docGetColonyPoolListOutput = null;
			log.info("calling  callGetColonyPoolLIst");
			docGetColonyPoolListOutput = callGetColonyPoolList(env);
			log.info("docGetColonyPoolListOutput " + SCXmlUtil.getString(docGetColonyPoolListOutput));
			Element eleColonyPoolListOut = docGetColonyPoolListOutput.getDocumentElement();
			Element eleColonyPool = SCXmlUtil.getChildren(eleColonyPoolListOut, KohlsPOCConstant.E_COLONY_POOL).get(0);
			sMasterPoolId = eleColonyPool.getAttribute(KohlsPOCConstant.A_POOL_ID);
			callExpdpForPoolId(env, sMasterPoolId);
		} catch (Exception e) {
			log.error("Error while calling createExportDumpFiles method." + e.getStackTrace());
			throw e;
		}
	}

	private void callExpdpForPoolId(YFSEnvironment env, String sPoolId) throws Exception {
		try {
			Properties JDBCProperties;
			JDBCProperties = loadPropertiesFromAbsoluteLocation(YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
			String sUserName = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + KohlsPOCConstant.USER);
			String sPassword = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + KohlsPOCConstant.PASSWORD);
			String sUrl = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + KohlsPOCConstant.URL);
			String[] jdbcURLSplit = sUrl.split(KohlsPOCConstant.AT);
			schemaName = sUserName;
			callExpdp(sUserName, sPassword, jdbcURLSplit[1]);
		} catch (Exception e) {
			log.error("Error in callExpdpForPoolId " + e.getStackTrace());
			throw e;
		}
	}

	private Document callGetCommonCodeList(YFSEnvironment env, String strSyncProfile) throws Exception {
		log.info("callGetCommonCodeList beginning ");
		Document docCommonCodeListInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
		Element eleCommonCodeListInput = docCommonCodeListInput.getDocumentElement();
		eleCommonCodeListInput.setAttribute(KohlsPOCConstant.A_CODE_TYPE, strSyncProfile);
		log.info("eleCommonCodeListInput is " + SCXmlUtil.getString(docCommonCodeListInput));

		Document docCommonCodeListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COMMON_CODE_LIST,
				docCommonCodeListInput);
		log.info("docCommonCodeListOutput is " + SCXmlUtil.getString(docCommonCodeListOutput));
		return docCommonCodeListOutput;
	}

	public static HashMap<String, String[]> getValueAndDescMap(Document docCommonCodeList) {
		HashMap<String, String[]> hashMapCommonCode = new HashMap<String, String[]>();
		Element eleCommonCodeList = docCommonCodeList.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			String[] profileIdprofileStatusMap = new String[2];
			profileIdprofileStatusMap[0] = eleCommonCode.getAttribute(KohlsConstants.CODE_LONG_DESC);
			profileIdprofileStatusMap[1] = eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION);
			hashMapCommonCode.put(eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE), profileIdprofileStatusMap);
			log.info("Common Code Value and Short Desc " + eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE) + ","
					+ eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION));
		}
		return hashMapCommonCode;
	}

	private void callExpdp(String sUserName, String sPassword, String jdbcURL) throws Exception {
		String dumpFileName = sUserName + KohlsPOCConstant.UNDERSCORE + getConfigValue(actionName, KohlsPOCConstant.KEY_EXPORT_FILE)
				+ KohlsPOCConstant.TABLE_TYPE_MASTER + KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT
				+ KohlsPOCConstant.DMP_EXTENSION;

		String logFileName = getConfigValue(actionName, KohlsPOCConstant.KEY_LOG_FILE)
				+ KohlsPOCConstant.TABLE_TYPE_MASTER + KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT
				+ KohlsPOCConstant.LOG_EXTENSION;
		String statement = null;

		KohlsDeploymentUtil dpUtil = new KohlsDeploymentUtil();
		boolean oraFileEntry = dpUtil.checkTnsNamesOraEntries();
		if (oraFileEntry) {
			statement = KohlsPOCConstant.EXPORT_CMD + " " + sUserName + KohlsPOCConstant.BACKWARD_SLASH + sPassword
					+ KohlsPOCConstant.AT + KohlsPOCConstant.OMSR_CORP_HOST + " TABLES=" + strAllActiveProfileTableList
					+ " directory=data_pump_export_directory" + " dumpfile=" + dumpFileName
					+ " EXCLUDE=GRANT,PROCACT_INSTANCE logfile=" + logFileName; // For DB failure fix						
		} else {
			statement = KohlsPOCConstant.EXPORT_CMD + " " + sUserName + KohlsPOCConstant.BACKWARD_SLASH + sPassword
					+ KohlsPOCConstant.AT + "\"" + jdbcURL + "\"" + " TABLES=" + strAllActiveProfileTableList
					+ " directory=data_pump_export_directory" + " dumpfile=" + dumpFileName
					+ " EXCLUDE=GRANT,PROCACT_INSTANCE logfile=" + logFileName;
		}
		log.info("File path is " + getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);

		File inProgressDir = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR));
		setPermission(inProgressDir);
		String expStrippedStatement = statement.replaceAll(REGEX_PASSWORD, REGEX_REPLACEMENT);
		log.info("Statement executed inside for callExpdp is " + expStrippedStatement);
		executeStatement(statement, dumpFileName, logFileName);
		// revokePermission(inProgressDir);
	}

	public void setPermission(File perDir) {
		perDir.setExecutable(true, false);
		perDir.setReadable(true, false);
		perDir.setWritable(true, false);
	}

	public void revokePermission(File perDir) {
		perDir.setExecutable(false, false);
		perDir.setReadable(true, false);
		perDir.setWritable(true, false);
	}

	private Document callGetColonyPoolList(YFSEnvironment env) throws Exception {
		Document docGetColonyPoolListOutput = null;
		try {
			log.info("Getting the Colony pool list");
			Document docGetColonyPoolListInput = YFCDocument.createDocument(KohlsPOCConstant.E_COLONY_POOL)
					.getDocument();
			Element eleColonyPoolInput = docGetColonyPoolListInput.getDocumentElement();
			eleColonyPoolInput.setAttribute(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
			log.info("docGetColonyPoolListInput is " + SCXmlUtil.getString(docGetColonyPoolListInput));
			docGetColonyPoolListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COLONY_POOL_LIST,
					docGetColonyPoolListInput);
		} catch (Exception e) {
			log.error("Error in callGetColonyPool " + e.getStackTrace());
			throw e;
		}
		return docGetColonyPoolListOutput;
	}

	/* 
	 * @param env
	 * @throws IOException
	 * @throws Exception
	 */
	private void importExpdatDump(YFSEnvironment env) throws Exception {
		try {
			log.info("Entered importExpdatDump method");
			timeStamp = new SimpleDateFormat(KohlsPOCConstant.READ_DUMP_FILES_DATE_FORMAT).format(new java.util.Date());
			log.info("Got Timestamp");
			Properties JDBCProperties = loadPropertiesFromAbsoluteLocation(YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
			log.info("Read properties file successfully.");
			String sPoolID = YFSSystem.getProperty(KohlsPOCConstant.A_POOL_ID);
			log.info("Pool id is " + sPoolID);
			String sUserName = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.USER);
			String sPassword = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.PASSWORD);
			String sUrl = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.URL);
			String[] jdbcURLSplit = sUrl.split(KohlsPOCConstant.AT);

			YCPContext context = (YCPContext) env;
			conn = context.getDBConnection();
			stmt = conn.createStatement();

			String dumpFileName = null;
			String tableExistsAction = null;
			String implogfile = null;
			String ImportDir = KohlsPOCConstant.DB_DMP_INPGROGRESS_PATH;

			File file = new File(ImportDir);
			File[] files = file.listFiles();
			log.debug(
					"Before iterating through files with in progress path " + KohlsPOCConstant.DB_DMP_INPGROGRESS_PATH);
			for (File f : files) {
				dumpFileName = f.getName();
				log.info("ImportFileName --> " + dumpFileName);
				if (dumpFileName.contains(KohlsPOCConstant.EXPDAT_DMP)) {
					tableExistsAction = "TABLE_EXISTS_ACTION=TRUNCATE";
					implogfile = KohlsPOCConstant.EXPDAT_LOG + KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT
							+ KohlsPOCConstant.LOG_EXTENSION;
					callImpdpForSqlTuning(sUserName, sPassword, jdbcURLSplit[1], dumpFileName, tableExistsAction,
							implogfile);
				}
			}
		} catch (Exception e) {
			log.error("error in readDumpFileAndImportTables ");
			throw e;
		}
	}

	private void callImpdpForSqlTuning(String sUserName, String sPassword, String jdbcURLSplit, String dumpFileName,
			String tableExistsAction, String implogfile) throws Exception {
		String statement = KohlsPOCConstant.IMPORT_CMD + " " + sUserName
				+ KohlsPOCConstant.BACKWARD_SLASH + sPassword + KohlsPOCConstant.AT + "\""
				+ jdbcURLSplit + "\"" + " directory=data_pump_sql_directory "
				+ tableExistsAction + " dumpfile=" + dumpFileName + " logfile="
				+ implogfile;		
		String sqlStrippedStatement = statement.replaceAll(REGEX_PASSWORD, REGEX_REPLACEMENT);
		log.info("Import statement sql tuning is " + sqlStrippedStatement);
		executeStatement(statement, dumpFileName, implogfile);
	}

	public void unpackSqlProfile(YFSEnvironment env) throws SQLException {
		try {
			Connection connection = ((YCPContext) env).getConnection();
			log.info("got the connection " + connection);
			CallableStatement preparedCall;

			preparedCall = connection.prepareCall(UNPACK_SQL_PROFILE);
			log.info("Executing " + UNPACK_SQL_PROFILE);

			preparedCall.execute();
			log.info("DBA oracle procedure to unpack profile is over.");
		} catch (SQLException e) {
			log.error("Error in unpackSqlProfile");
			throw e;
		}
	}

	public void callOracleProcedure(YFSEnvironment env, String oracleProcedure ) throws SQLException {
		try {
			Connection connection = ((YCPContext) env).getConnection();
			log.info("Got the connection to execute oracle procedure id " + oracleProcedure);
			CallableStatement preparedCall;
			preparedCall = connection.prepareCall("{call " + oracleProcedure + "}");
			preparedCall.execute();
			log.info("Oracle procedure call completed.");
		} catch (SQLException e) {
			log.error("Error in callOracleProcedure " + e.getStackTrace());
			throw e;
		}
	}

	private void callManageSyncDBImport(YFSEnvironment env) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		String syncDBDate = sdf.format(expImpTimeStamp);
		ArrayList<Element> profileListFromFile = SCXmlUtil.getChildren(getSyncVersionDocument().getDocumentElement(),
				KohlsPOCConstant.E_PROFILE);
		log.info("Profile list size " + profileListFromFile.size());
		for (Element profileFile : profileListFromFile) {
			Document docManageImportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_IMPORT)
					.getDocument();
			Element eleManageImportSyncDB = docManageImportSyncDB.getDocumentElement();
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_DB_IMPORT_TIME, syncDBDate);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_OPERATION, KohlsPOCConstant.MANAGE);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_PROFILE_ORG_CODE,
					profileFile.getAttribute(KohlsPOCConstant.A_ORG_CODE));

			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID,
					profileFile.getAttribute(KohlsPOCConstant.A_NAME));
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID,
					YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP));

			String strSequenceNoImport = profileFile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
			
			// For Store Full Sync			
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_FULL);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, strSequenceNoImport);
			log.info("ManageSyncDBImport FULL-STORE input " + XMLUtil.getXMLString(docManageImportSyncDB));			
			KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MANAGE_SYNC_DB_IMPORT, docManageImportSyncDB);
			log.info("Updating the Store version completed");

			// For Corp Full Sync
			Document manageSyncDBImportOutdoc = null;
			Element eleAdditionalInfo = SCXmlUtil.createChild(eleManageImportSyncDB,
					KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
			eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
			log.info("ManageSyncDBImport FULL-CORP input " + XMLUtil.getXMLString(docManageImportSyncDB));			
			Document remoteOutDoc = callApi(env, docManageImportSyncDB, manageSyncDBImportOutdoc, KohlsPOCConstant.V_MOTHERSHIP,
					KohlsPOCConstant.API_MANAGE_SYNC_DB_IMPORT);
			NodeList nodeListCommonCode = remoteOutDoc.getElementsByTagName(KohlsPOCConstant.E_ERROR);
			if (nodeListCommonCode.getLength() > 0) {
				throw new YFCException("Exception in manageSyncDBImport " + SCXmlUtil.getString(remoteOutDoc));
			}
			log.info("Updating the Corp version completed");
		}		
	}

	private Document getSyncVersionDocument()
			throws SAXException, IOException, ParserConfigurationException, FactoryConfigurationError {
		Document docSyncVersion = null;
		String ImportDir = getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR);
		File file = new File(ImportDir);
		File[] files = file.listFiles();
		String dumpFileName;
		for (File f : files) {
			dumpFileName = f.getName();
			log.info("Import file name for configuration " + dumpFileName);
			if (dumpFileName.contains(KohlsPOCConstant.V_SYNC_VERSION)) {
				docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(f);
				break;
			}
		}
		return docSyncVersion;
	}

	private void readDumpFilesAndImportTables(YFSEnvironment env) throws Exception {
		try {
			String dumpFileName = null;
			String tableExistsAction = null;
			String expDumpFileName = null;
			String implogfile = null;
		    log.info("Reading and importing the dump files");
			actionName = KohlsPOCConstant.A_IMPORT;
			String ImportDir = getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR); 
			timeStamp = new SimpleDateFormat(KohlsPOCConstant.READ_DUMP_FILES_DATE_FORMAT).format(new java.util.Date());

			File file = new File(ImportDir);
			File[] files = file.listFiles();
			for (File f : files) {
				dumpFileName = f.getName();
				log.info("Import file name is " + dumpFileName);
				if (dumpFileName.contains(KohlsPOCConstant.TABLE_TYPE_MASTER)
						&& dumpFileName.contains(KohlsPOCConstant.DMP_EXTENSION)) {
					expDumpFileName = dumpFileName;
/*					tableExistsAction = "TABLE_EXISTS_ACTION=REPLACE";
					implogfile = getConfigValue(actionName, KohlsPOCConstant.KEY_LOG_FILE)
							+ KohlsPOCConstant.TABLE_TYPE_MASTER + KohlsPOCConstant.UNDERSCORE + timeStamp
							+ KohlsPOCConstant.DOT + KohlsPOCConstant.LOG_EXTENSION;
					callImpdp(tableExistsAction, dumpFileName, implogfile);
					callOracleProcedure(env, GATHER_SCHEMA_STATS );*/
				} else if (dumpFileName.contains(KohlsPOCConstant.ZERO_INS_UPD_DMP)) {
					zeroDump = true;
					f.delete();
				} else if (dumpFileName.contains(KohlsPOCConstant.CDT_FILE)) {
					log.info("CDTXml file is " + dumpFileName);
					if (dumpFileName.contains(KohlsPOCConstant.ZERO_CDT_ZIP)) {
						f.delete();
					} else {
						cdtFlag = true;
					}
				} else if (dumpFileName.contains(KohlsPOCConstant.V_SYNC_VERSION)) {	
					KohlsDeploymentUtil dputil = new KohlsDeploymentUtil();
					tableSpacesFromXml = dputil.tableSpaceFromXmlFile(f.getAbsoluteFile());
					syncVerFlag = true;
				}
			}
			
			//CPD-2914 moved from for loop to get update sync version file and populate the table spaces
			if(expDumpFileName != null && !expDumpFileName.isEmpty()){
				tableExistsAction = "TABLE_EXISTS_ACTION=REPLACE";
				implogfile = getConfigValue(actionName, KohlsPOCConstant.KEY_LOG_FILE)
						+ KohlsPOCConstant.TABLE_TYPE_MASTER + KohlsPOCConstant.UNDERSCORE + timeStamp
						+ KohlsPOCConstant.DOT + KohlsPOCConstant.LOG_EXTENSION;
				log.info("Input to callImpdp are " + tableExistsAction + ", " + expDumpFileName + ", "+ implogfile );
				callImpdp(tableExistsAction, expDumpFileName, implogfile);
				callOracleProcedure(env, GATHER_SCHEMA_STATS );
			}
				
			if (cdtFlag) {
				KohlsCDTUtil cdtUtil = new KohlsCDTUtil();
				File fullInProgressPath = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_IMPORT_DIR));
				cdtUtil.importCDT(env, SCXmlUtil.createDocument(KohlsPOCConstant.A_IMPORT), fullInProgressPath);
			}

			if (syncVerFlag) {
				callManageSyncDBImport(env);				
				YFSContext ctx = (YFSContext) env;
				KohlsDeploymentUtil kdUtil = new KohlsDeploymentUtil();
				SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
				String syncDBDate = sdf.format(expImpTimeStamp);
				String strTargetId = YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP);
				
				ArrayList<Element> profileListFromFile = SCXmlUtil.getChildren(getSyncVersionDocument().getDocumentElement(),
						KohlsPOCConstant.E_PROFILE);			
				ArrayList<String> profilesListFromXML = new ArrayList<String>();
				
				for (Element profileFileFromXML : profileListFromFile) {
						if(!profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME).equalsIgnoreCase(KohlsPOCConstant.P_CONFIGURATION_D)){
							profilesListFromXML.add(profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME)); // Got the profiles from xml file
						}
						log.info("Profiles from XML file " + profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
				}				
				
				if(expDumpFileName != null && !expDumpFileName.isEmpty()){
									
				kdUtil.manageSyncProcessRecordExpImp(ctx, KohlsPOCConstant.A_IMPORT, KohlsPOCConstant.SYNC_FULL, strTargetId,
						KohlsPOCConstant.TABLE_TYPE_MASTER, profilesListFromXML, syncDBDate );				
				}
				
				if(cdtFlag){									
					kdUtil.manageSyncProcessRecordExpImp(ctx, KohlsPOCConstant.A_IMPORT, KohlsPOCConstant.SYNC_FULL, strTargetId,
							KohlsPOCConstant.A_CONFIGURATION, profilesListFromXML, syncDBDate );					
				} 
				File file1 = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR) + KohlsPOCConstant.BACKWARD_SLASH );
			    File file2 = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH);
				filterFiles(file1, file2, KohlsPOCConstant.V_SYNC_VERSION);				
			} else {
				log.info("No Sync profile xml present");
			}	
		} catch (Exception e) {
			log.error("Reading dump file is having issues");
			throw e;
		}
	}


	private void callImpdp(String tableExistsAction, String dumpFileName, String implogfile) throws Exception {
		log.info("Import of dump started");
		String StoreID = YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP);
		Properties JDBCProperties = loadPropertiesFromAbsoluteLocation(YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
		String sPoolID = YFSSystem.getProperty(KohlsPOCConstant.A_POOL_ID);
		log.info("Pool id is " + sPoolID);
		String sUserName = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.USER);
		String sPassword = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.PASSWORD);
		String sUrl = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.URL);
		String[] jdbcURLSplit = sUrl.split(KohlsPOCConstant.AT);
		//String renameTableSpaces = tableSpacesFromXml.replaceAll(",", ":SOF00001,") +":SOF00001";	
		log.info("Table spaces are " + tableSpacesFromXml);
		stmt = conn.createStatement();
		String[] CorpUserName = dumpFileName.split(KohlsPOCConstant.UNDERSCORE);

		String statement = KohlsPOCConstant.IMPORT_CMD
				+ " "
				+ sUserName
				+ KohlsPOCConstant.BACKWARD_SLASH
				+ sPassword
				+ KohlsPOCConstant.AT
				+ "\""
				+ jdbcURLSplit [1]
				+ "\""
				+ " directory=data_pump_import_directory "
				+ tableExistsAction
				+ " dumpfile="
				+ dumpFileName
				+ " EXCLUDE=STATISTICS"
				+ " logfile="
				+ implogfile
				+ " remap_schema="
				+ CorpUserName[0]
				+ ":"
				+ sUserName
			//	+ " remap_tablespace=SOF00002:SOF00001,SOF00003:SOF00001,TDETBS02:SOF00001,OMSDATA01:SOF00001,SOF0000A:SOF00001"
		    //	+ " remap_tablespace="
			//	+ tableSpacesFromXml
				+ " TRANSFORM=DISABLE_ARCHIVE_LOGGING:Y TRANSFORM=SEGMENT_ATTRIBUTES:N "
				+ " JOB_NAME=FULL_"+ timeStamp
				+ " query=POS_PSI_STATUS:" + "\""
				+ "WHERE ORGANIZATION_CODE=\'" + StoreID + "\'\"";

		String impStatement = statement.replaceAll(REGEX_PASSWORD, REGEX_REPLACEMENT);
		log.info("Import statement is " + impStatement);
		executeStatement(statement, dumpFileName, implogfile);

	   //moveFiles(dumpFileName, implogfile); 
		File file1 = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DIR) + KohlsPOCConstant.BACKWARD_SLASH );
	    File file2 = new File(getConfigValue(actionName, KohlsPOCConstant.KEY_DATA_PUMP_DONE) + KohlsPOCConstant.BACKWARD_SLASH);		
		filterFiles( file1,  file2, KohlsPOCConstant.TABLE_TYPE_MASTER);
	}
	
	
	public void filterFiles(File dir, File dest, String fileType) throws IOException {
		File[] files = dir.listFiles();
		log.info("Calling the list file " + dir + " " + dest.getName());
		String fileName = null;
		for (File sourceFile : files) {
			fileName = sourceFile.getName();
			if (fileName.contains(fileType)) {
				File destFile = new File(dest, fileName);
				try {
					moveFilesUsingFileStream(sourceFile, destFile);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @param statement
	 * @param explogfile
	 * @param dumpFileName
	 * @throws IOException
	 * @throws Exception
	 */

	private void executeStatement(String command, String dumpFileName, String logFileName) throws Exception {
		final Runtime r = Runtime.getRuntime();
		//log.info("Starting statement execution " + command);
		Process p = r.exec(command);
		final int returnCode = p.waitFor();
		log.info("Return Code is " + returnCode);
		final int exitValue = p.exitValue();
		log.info("Exit Value is " + exitValue);
		final BufferedReader is = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = is.readLine()) != null) {
			log.info("Line 1 : " + line);
		}
		final BufferedReader is2 = new BufferedReader(new InputStreamReader(p.getErrorStream()));
		while ((line = is2.readLine()) != null) {
			log.info("Line 2 : " + line);
		}
		if (exitValue != 0) {
			throw new YFCException("Oracle command failed with exitValue " + exitValue);
		}
		moveFiles(dumpFileName, logFileName);
	}

	/**
	 * @param env
	 * @param syncProfile
	 * @param docSyncVersion
	 * @param isCorp
	 * @param isImportTable
	 * @param strExportType
	 * @throws Exception
	 */
	public void manageSyncDBUpdateForMaster(YFSEnvironment env, String syncProfile, String TableGroup,
			String ProfileOrgCode, Document docSyncVersion, String strTableList) throws Exception {
		log.info("ManageSyncDBUpdate begin for profile" + syncProfile);
		log.info("TableGroup " + TableGroup);
		Document docExportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_EXPORT).getDocument();
		Element eleExportSyncDB = docExportSyncDB.getDocumentElement();

		try {
			String finalSeqNo = null;
			eleExportSyncDB.setAttribute(KohlsPOCConstant.A_TABLE_GROUP, TableGroup);
			SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_UPDATE_DATE_FORMAT);
			YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
			String syncDBDate = sdf.format(yfcCurrntDt);

			log.info("getSyncDBExportList Input  in manageSyncDBUpdate :: " + XMLUtil.getXMLString(docExportSyncDB));
			Document getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
					KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST, docExportSyncDB);
			log.info("getSyncDBExportList output in manageSyncDBUpdate :: "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

			finalSeqNo = getSequenceNumber(getSyncDBExportListOutputDoc, syncProfile);

			Element eleProfile = SCXmlUtil.createChild(docSyncVersion.getDocumentElement(), KohlsPOCConstant.E_PROFILE);
			log.info("eleProfile is before attr addition " + SCXmlUtil.getString(eleProfile));
			eleProfile.setAttribute(KohlsPOCConstant.A_NAME, syncProfile);
			eleProfile.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, finalSeqNo);
			eleProfile
					.setAttribute(KohlsPOCConstant.A_ORG_CODE, ProfileOrgCode);
			log.info("eleProfile is after attr addition "
					+ SCXmlUtil.getString(eleProfile));
			log.info("docSyncVersion now is :: "
					+ SCXmlUtil.getString(docSyncVersion));

			// Actual query to insert
			String TABLE_GROUP_EXPORT = XMLUtil.getAttribute(eleExportSyncDB,
					KohlsPOCConstant.A_TABLE_GROUP);
			log.info("TABLE_GROUP_EXPORT in manageSyncDBUpdate :: "
					+ TABLE_GROUP_EXPORT);

			YCPContext ctx = (YCPContext) env;
			YFS_Sync_DB_Export exportEntity = YFS_Sync_DB_Export.newInstance();
			exportEntity.setDBContextRecursive(ctx);
			exportEntity.setSync_Type(KohlsPOCConstant.SYNC_FULL);
			exportEntity.setSequence_No(finalSeqNo);
			exportEntity.setDB_Export_Time(yfcCurrntDt);
			exportEntity.setSync_Profile_ID(syncProfile);
			exportEntity.setTableGroup(TABLE_GROUP_EXPORT);
			exportEntity.setOrganization_Code(ProfileOrgCode);

			log.info("Inserting new record into YFS_SYNC_DB_EXPORT:\nOrganizationCode: "
					+ exportEntity.getOrganization_Code()
					+ "\nSyncProfileID: "
					+ exportEntity.getSync_Profile_ID()
					+ "\nSyncType: "
					+ exportEntity.getSync_Type()
					+ "\nTableGroup: "
					+ exportEntity.getTableGroup()
					+ "\nSequenceNo: "
					+ exportEntity.getSequence_No() + "\n");

			exportEntity.insert();

			//updateSyncExportedForMaster((YFSContext) env, strTableList);
			// The below api call is to verify if the records are inserted correctly
			getSyncDBExportListOutputDoc = null;
			getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST,
					docExportSyncDB);
			log.info("Post Insert -> getSyncDBExportList output in manageSyncDBUpdate "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

		} catch (Exception e) {
			log.error("Exception manageSyncDBUpdate() is: " + e.toString());
			throw e;
		}
	}

	public Document callApi(YFSEnvironment env, Document inXML, Document outDoc, String sEndpoint, String sApiName) {
		try {
			Document tempOutput = null;
			oApi = getDefaultAPI((YFSContext) env, sEndpoint);
			String envString = "<env userId='gravity' progId='gravity'/>";
			YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
			tempOutput = oApi.invoke(newEnv, sApiName, inXML);
			return tempOutput;
		} catch (Exception e) {
			log.error("Call api is having issues " + e.getStackTrace());
			throw new YFCException("Exception in callApi");
		}
	}

	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			log.info("YIFClient using endpoint definition");
			Map omap = new HashMap();
			try {
				omap.put("yif.httpapi.userid",
						YIFClientProperties.getInstance().getYIFProperty("edge.integration.app.userid"));
				omap.put("yif.httpapi.password",
						YIFClientProperties.getInstance().getYIFProperty("edge.integration.app.password"));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}

		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode("OMP922_002");
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), "Edge_Server_Endpoint_Not_Configured"));
		throw oEx;
	}

	private String getSequenceNumber(Document getListDoc, String syncProfile) {
		String finalSeqNo = "";
		ArrayList<Element> profileList = SCXmlUtil.getChildren(getListDoc.getDocumentElement(),
				KohlsPOCConstant.E_SYNC_DB_EXPORT);
		HashMap<String, String> profileSequenceMap = new HashMap<String, String>();
		int prevSeqNo = 0;
		for (Element eleProfile : profileList) {
			profileSequenceMap.put(eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID), KohlsPOCConstant.ONE_DOT_ZERO);
		}
		for (Element eleProfile : profileList) {
			String currSyncProfileID = eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
			log.info("currSyncProfileID for map entry " + currSyncProfileID);
			log.info("SequenceNo for map entry " + eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
			int currSeqNo = (int) Double.parseDouble((eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO)));
			log.info("currSeqNo for map entry " + String.valueOf(currSeqNo));

			String strPrevSeqNo = profileSequenceMap.get(currSyncProfileID);
			log.info("strPrevSeqNo for map entry " + strPrevSeqNo);
			prevSeqNo = (int) Double.parseDouble(strPrevSeqNo);
			log.info("prevSeqNo for map entry " + String.valueOf(prevSeqNo));

			if (currSeqNo > prevSeqNo) {
				profileSequenceMap.put(currSyncProfileID, eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
				prevSeqNo = currSeqNo;
			}
		}

		log.info("Map after looping is ");
		for (Entry<String, String> entry : profileSequenceMap.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			log.info("key - value is " + key + " " + value);
		}

		log.info("Currently analyzed syncProfile and its SequenceNo " + syncProfile +", " + profileSequenceMap.get(syncProfile));
		if (profileList.size() > 0 && !YFCObject.isVoid(profileSequenceMap.get(syncProfile))) {
			int existingSeqNo = (int) Double.parseDouble(profileSequenceMap.get(syncProfile).split("\\.")[0]);
			int newSeqNo = existingSeqNo + 1;
			finalSeqNo = newSeqNo + KohlsPOCConstant.DOT_ZERO;
		} else {
			finalSeqNo = KohlsPOCConstant.ONE_DOT_ZERO;
		}
		return finalSeqNo;
	}

	private void updateSyncExportedForMaster(YFSContext ctx, String strTableList) throws Exception {
		log.info("Beginning updateSyncExportedForMaster");
		strTableList = "'" + strTableList;
		strTableList = strTableList.replaceAll(",", "\',\'");
		strTableList = strTableList + "'";
		String partitionID = ctx.getPoolResolver().pushPartition("updateSyncExported");
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		String strCurrentDate = sdf.format(date);
		log.debug("Current update Sync exported date and active table " + strCurrentDate + ", " + strTableList);
		ctx.getPoolResolver().addFact("TableType", "MASTER");
		PLTQueryBuilder oPLT = new PLTQueryBuilder(false);
		oPLT.append("UPDATE YFS_ENTITY_CHANGE SET SYNC_EXPORTED='Y' WHERE ENTITY IN ("
				+ strTableList
				+ ") AND SYNC_EXPORTED='N' AND MODIFYTS < to_date(\'"
				+ strCurrentDate
				+ "\',"
				+ "\'"
				+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT
				+ "\')");
		log.debug("updateSyncExported query being fired " + oPLT.getReadableWhereClause());
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.info("Executing sql for master " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			log.info("Updated sync exported flag");
			rs.close();
		} catch (Exception ex) {
			log.error("Error occurred in updateSyncExported");
			throw ex;
		} finally {
			log.info("fireSqlQuery updateSyncExportedending");
			YFSDBHome.closeStatement(stmt);
			log.info("Popping partitionID " + partitionID);
			ctx.getPoolResolver().popPartition(partitionID);
		}
	}

	/**
	 * getJobs to get the action need to perform either export or import of the
	 * profiles
	 **/
	@Override
	public List<Document> getJobs(YFSEnvironment env, Document inXML, Document lastMessageCreated) throws Exception {

		log.debug("GetJobs started");
		List<Document> lstTask = new ArrayList<Document>();
		log.info("Input to fullsync getJobs" + XMLUtil.getXMLString(inXML));
		try {
			YFCElement eleRoot = YFCDocument.getDocumentFor(inXML).getDocumentElement();
			String sDataType = eleRoot.getAttribute(KohlsPOCConstant.A_DATA_TYPE);
			log.info("Action name in getJobs is " + sDataType);
			// Input for datapump export
			Document docExportJobs = YFCDocument.createDocument(KohlsPOCConstant.E_KOHLS_GET_DATA_EXPORT).getDocument();
			Element eleServiceInput = docExportJobs.getDocumentElement();
			eleServiceInput.setAttribute(KohlsPOCConstant.A_DATA_TYPE, sDataType);
			log.debug("Input to export jobs is " + XMLUtil.getXMLString(docExportJobs));
			if (lastMessageCreated == null) {
				lstTask.add(docExportJobs);
			}
		} catch (Exception e) {
			log.error("Exception getJobs is " + e.toString());
			throw e;
		}
		return lstTask;
	}

	/**
	 * ExecuteJobs for export and import for profiles
	 * @throws Exception
	 */
	public void executeJob(YFSEnvironment env, Document indoc) throws Exception {
		try {
			log.debug("Starting the Data Pump Application");
			log.info("Input to fullsync executeJob" + XMLUtil.getXMLString(indoc));
			Element eleInDoc = indoc.getDocumentElement();
			actionName = eleInDoc.getAttribute(KohlsPOCConstant.A_DATA_TYPE);
			log.info("Action name is " + actionName);
			globalDate();
			KohlsDeploymentUtil dpUtil = new KohlsDeploymentUtil();
			if (actionName.equals(KohlsPOCConstant.A_IMPORT)) {
				KohlsDataPump datapump = new KohlsDataPump();
				datapump.createMapDir(env, actionName);
				datapump.readDumpFilesAndImportTables(env);	
				//CPE-11184 - Granting permissions and turning off logs for datapump tables
				callOracleProcedure(env,ORACLE_PROCEDURE);
				dpUtil.callModifyCache(env);	
			} else if (actionName.equals(KohlsPOCConstant.A_EXPORT)) {
				KohlsDataPump datapump = new KohlsDataPump();
				datapump.createMapDir(env, actionName);
				datapump.exportTables(env);	
				dpUtil.callModifyCache(env);
			} else if (actionName.equals(KohlsPOCConstant.A_DBA_TASKS)) {
				callOracleProcedure(env, ORACLE_PROCEDURE);
			} else if ((actionName.equals(KohlsPOCConstant.A_SQL_TUNING))) {
				log.info("actionName " + actionName);
				KohlsDataPump datapump = new KohlsDataPump();
				datapump.createMapDir(env, actionName);
				importExpdatDump(env);
				unpackSqlProfile(env);
			}
		} catch (Exception e) {
			log.error("Error in execute Job " + e.getStackTrace());
			throw e;
		}
	}	
	
	/**
	 * This method is to read values from customer override properties with the
	 * action and key value example yfs.EXPORT.DIRECTORY
	 * @param actionName
	 * @param keyName
	 * @return
	 */

	public String getConfigValue(String actionName, String keyName) {
		String prpertyKey = KohlsPOCConstant.KEY_TAG + KohlsPOCConstant.UNDERSCORE + actionName.toUpperCase() + KohlsPOCConstant.UNDERSCORE + keyName;
		log.info("Property key " + prpertyKey);
		return YFSSystem.getProperty(prpertyKey);
	}

	/**
	 * Reading Property file
	 * @param propertyFilePath
	 * @return
	 * @throws Exception
	 **/
	public Properties loadPropertiesFromAbsoluteLocation(String propertyFilePath) throws Exception {
		log.info("Inside method loadPropertiesFromAbsoluteLocation with input filePath as " + propertyFilePath);
		Properties prop = new Properties();
		File file = null;
		FileReader fr = null;
		try {
			file = new File(propertyFilePath);
			log.debug("Properties file created successfully");
			fr = new FileReader(file);
			log.info("File Reader initiated successfully");
			prop.load((Reader) fr);

		} catch (Exception e) {
			log.error("Error loading properties file " + e.getStackTrace());
			throw e;
		} finally {
			if (fr != null) {
				fr.close();
			}
			if (file != null) {
				file = null;
			}
		}
		return prop;
	}	
}
