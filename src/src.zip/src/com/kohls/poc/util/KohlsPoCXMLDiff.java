package com.kohls.poc.util;

import org.w3c.dom.Document;

import com.yantra.tools.yaxmldiff.XMLDiff;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;

public class KohlsPoCXMLDiff {
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCXMLDiff.class.getName());
	
	public Document diffXML (Document origDoc, Document newDoc) throws Exception{
		logger.beginTimer("KohlsPoCXMLDiff.diffXML");
		XMLDiff diff = new XMLDiff(YFCDocument.getDocumentFor(origDoc), YFCDocument.getDocumentFor(newDoc));
		YFCDocument diffDoc = YFCDocument.createDocument("Differences");
		YFCElement root = diffDoc.getDocumentElement();
		//YFCElement efile1 = root.createChild("document1");
		YFCElement efile2 = root.createChild("document2");
		//YFCElement efile1Changed = efile1.createChild("ElementsChanged");
		//YFCElement efile1Addded = efile1.createChild("ElementsAdded");
		//YFCElement efile2Changed = efile2.createChild("ElementsChanged");
		YFCElement efile2Addded = efile2.createChild("ElementsAdded");

		YFCElement tmp ;
		/*tmp = diff.getChangedInFile1().getDocumentElement();
		if (tmp != null) efile1Changed.importNode(tmp);*/

		/*tmp = diff.getAdditionsInFile1().getDocumentElement();
		 if (tmp != null) efile1Addded.importNode(tmp);*/

		/*tmp = diff.getChangedInFile2().getDocumentElement();
		if (tmp != null) efile2Changed.importNode(tmp);*/

		tmp = diff.getAdditionsInFile2().getDocumentElement();
		if (tmp != null) efile2Addded.importNode(tmp);
		logger.endTimer("KohlsPoCXMLDiff.diffXML");
		return diffDoc.getDocument();
	}

}
