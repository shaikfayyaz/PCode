package com.kohls.poc.util;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.TimeZone;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCSetStoreLocaleTime extends KOHLSBaseApi {

  private final static YFCLogCategory logger = YFCLogCategory
      .instance(KohlsPoCSetStoreLocaleTime.class);
  private Properties props = null;
  private static HashMap<String, String> storeLocaleMap = new HashMap<String, String>();

  // This method is called from KohlsPocCreateReprocessMessage class.a
  // This checks if the orders are created from STORE and if true,
  // Checks if the store's Locale is PST. If not, 
  // Required dates in the XMLs post to downstream are converted to PST time.

  public Document updateLocaleDate(YFSEnvironment env,Document inDoc) throws Exception
  {
    logger.beginTimer("KohlsPoCSetStoreLocaleTime.updateLocaleDate");
    String strOrgCode = null;
    if(!YFCCommon.isVoid(inDoc)){
      if(logger.isDebugEnabled()){
        logger.debug("Input to updateLocaleDate is"+XMLUtil.getXMLString(inDoc) );
      }

      String strXPath =  this.props.getProperty(KohlsPOCConstant.STRING_ORG_CODE_ELEMENT);
      String strOrgCodeAttr =  this.props.getProperty(KohlsPOCConstant.STRING_ORG_CODE_ATTR);
      Element eleNode = (Element)((NodeList) XPathUtil.getNodeList(
          inDoc.getDocumentElement(), strXPath)).item(0);
      if(!YFCCommon.isVoid(eleNode)){
        strOrgCode = eleNode.getAttribute(strOrgCodeAttr);
      }


      if(!YFCCommon.isVoid(strOrgCode) && !strOrgCode.equalsIgnoreCase(KohlsPOCConstant.EMPTY))
      {
        inDoc.getDocumentElement().setAttribute("OrgCode",strOrgCode );
        inDoc = invokeService(env,
            KohlsPOCConstant.SERVICE_CONVERT_TO_LOCALE_TIME, inDoc);

      }

      if(logger.isDebugEnabled()){
        logger.debug("Final doc returned from KohlsPoCSetStoreLocaleTime.updateLocaleDate \n " + XMLUtil.getXMLString(inDoc));
      }
    }

    logger.endTimer("KohlsPoCSetStoreLocaleTime.updateLocaleDate");
    return inDoc;
  }


  /**
   * Create By TKMACJT * 
   * @param env
   * @param inDoc
   * @param strOrgCode
   * @return
   * @throws Exception
   */
  private String setLocaleCodeFromOrg(YFSEnvironment env, String strOrgCode)
      throws Exception {
    logger.beginTimer("KohlsPoCSetStoreLocaleTime.setLocaleCodeFromOrg");
    if(logger.isDebugEnabled()){
      logger.debug("Store --  "+strOrgCode);
    }

    String strCode =  getLocaleCode(env,strOrgCode);
    
    logger.info("locale obtained for store "+strOrgCode+" is : "+ strCode);
    storeLocaleMap.put(strOrgCode, strCode);
    logger.endTimer("KohlsPoCSetStoreLocaleTime.setLocaleCodeFromOrg");
    return strCode;
  }


  private String getLocaleCode(YFSEnvironment environment,String strID) throws Exception
  {
    logger.beginTimer("KohlsPoCSetStoreLocaleTime.getLocaleCode");
    String strLocaleCode = "";
    String strLocaleTimezone = "";
    String strOutputTemplate = "<OrganizationList><Organization LocaleCode=''></Organization></OrganizationList>";
    Document docInput = KohlsXMLUtil
        .createDocument(KohlsPOCConstant.ATTR_ORGANIZATION);
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsConstants.ORGANIZATION_CODE, strID);
    if(logger.isDebugEnabled()){
      logger.debug("Input ot getOrganizationList is :"+XMLUtil.getXMLString(docInput));
    }
    Document docCommonCodeListOut = KohlsCommonUtil.invokeAPI(environment,XMLUtil.getDocument(strOutputTemplate),
        KohlsPOCConstant.API_GET_ORGANIZATION_LIST, docInput);
    if(!YFCCommon.isVoid(docCommonCodeListOut))
    {
      Element eleOrgList = docCommonCodeListOut.getDocumentElement();
      Element eleOrg = (Element)eleOrgList.getElementsByTagName(KohlsPOCConstant.ATTR_ORGANIZATION).item(0);
      if(!YFCCommon.isVoid(eleOrg))
      {
        strLocaleCode = eleOrg.getAttribute(KohlsPOCConstant.ATTR_LOCALE_CODE);
      }
    }

    // Getting Timezone for Locale.
    strLocaleTimezone = getTimezoneForLocaleCode (environment,strLocaleCode);
    logger.endTimer("KohlsPoCSetStoreLocaleTime.getLocaleCode");
    return strLocaleTimezone;
  }


  private String convertCorpDateTimeToStoreLocaleTime(String localeCode,String strDate) throws ParseException {
    logger.beginTimer("KohlsPoCSetStoreLocaleTime.convertCorpDateTimeToStoreLocaleTime");
    if(!strDate.equalsIgnoreCase(KohlsPOCConstant.EMPTY)){
      logger.debug("KohlsPoCSetStoreLocaleTime.convertCorpDateTimeToStoreLocaleTime --- localeCode is :"+ localeCode);
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
      Date dateBeforeConversion = sdf.parse(strDate);
      sdf.setTimeZone(TimeZone.getTimeZone(localeCode));
      strDate = sdf.format(dateBeforeConversion);
      logger.debug("KohlsPoCSetStoreLocaleTime.convertCorpDateTimeToStoreLocaleTime --- Converted date is :"+ strDate);
    }
    logger.endTimer("KohlsPoCSetStoreLocaleTime.convertCorpDateTimeToStoreLocaleTime");
    return strDate;
  }


  public Document callServiceToStoreLocaleInfo(YFSEnvironment env,Document invoiceDoc) throws Exception
  {
    logger.beginTimer("KohlsPoCSetStoreLocaleTime.callServiceToStoreLocaleInfo");
    String turnOffLocaleConversion = this.props.getProperty("TurnOffLocaleConversion");
    if("Y".equalsIgnoreCase(turnOffLocaleConversion)){
      return invoiceDoc;			  
    }
    int noOfAttributes = Integer.valueOf(this.props
        .getProperty(KohlsPOCConstant.NoOfAttributes));
    String attributeNo = null;
    String attribute = null;
    String attributePart1 = null;
    String attributePart2 = null;
    String[] delimitedSlash = null;
    String strXPath = null;
    String strDate = null;			

    // Setting install locale code in hash map
    String sInstallLocaleCode = YFSSystem.getProperty("yfs.install.localecode");
    if(!YFCCommon.isVoid(sInstallLocaleCode) && !storeLocaleMap.containsKey("INSTALL_TIME_ZONE")) {
       String sInstallTimeone = getTimezoneForLocaleCode (env,sInstallLocaleCode);
       storeLocaleMap.put("INSTALL_TIME_ZONE", sInstallTimeone);
    }
    
    String strOrgCode = invoiceDoc.getDocumentElement().getAttribute("OrgCode");
    String strMessageType = invoiceDoc.getDocumentElement().getAttribute("MessageType");
    logger.debug("KohlsPoCSetStoreLocaleTime.callServiceToStoreLocaleInfo --- public static works:"+ strOrgCode);
    invoiceDoc.getDocumentElement().removeAttribute("OrgCode");
    String strZoneCode = "";
    if(!storeLocaleMap.containsKey(strOrgCode)) {
      strZoneCode = setLocaleCodeFromOrg(env,strOrgCode);
    } else {
      strZoneCode = storeLocaleMap.get(strOrgCode);
    }

    // DO NOT process if order is in same timezone as install time zone. 
    if(!YFCCommon.isVoid(strZoneCode) 
        && !storeLocaleMap.get("INSTALL_TIME_ZONE").equalsIgnoreCase(strZoneCode)){
      for (int i = 0; i < noOfAttributes; i++) {
        attributeNo = "Attribute" + (i + 1);
        logger.debug("The attribute No is : " + attributeNo);
        attributePart1 = this.props.getProperty(attributeNo + "_1");
        attributePart2 = this.props.getProperty(attributeNo + "_2");
        if (attributePart2 == null) {
          attributePart2 = " ";
        }

        attribute = attributePart1.concat(attributePart2).trim();
        logger.debug("The attribute for which date is to be converted is : " + attributePart2);
        delimitedSlash = attribute.split(KohlsPOCConstant.STRING_DELIMITER);
        strXPath = delimitedSlash[0];
        strDate = delimitedSlash[1];

        NodeList nlXPathElementList = ((NodeList) XPathUtil.getNodeList(
            invoiceDoc.getDocumentElement(), strXPath));
        boolean skipConversion = false;
        if(!YFCCommon.isVoid(nlXPathElementList))
        {
        	 
          for(int j=0;j<nlXPathElementList.getLength();j++){
            Element eleCurrent = (Element)nlXPathElementList.item(j);           
            if(!YFCCommon.isVoid(eleCurrent.getAttribute(strDate))){
            	
            	  if(KohlsPOCConstant.ATTR_EXTN_ORDER_DATE.equalsIgnoreCase(strDate))
            	  {
            		  String extnSellerOrg = eleCurrent.getAttribute(KohlsPOCConstant.ATTR_EXTN_SELLER_ORG_CODE);
            		  if(KohlsPOCConstant.POST_SALE_ADJUSTMENT.equals(strMessageType) || KohlsPOCConstant.POST_SALE_VOID_AFTER.equals(strMessageType) || 
            				  KohlsPOCConstant.POST_SALE_VOID_DURING.equals(strMessageType))
            		  {
            			  if(!YFCCommon.isVoid(extnSellerOrg))
            			  {
            				  String strSellerZoneCode = null;
                    		  if(!storeLocaleMap.containsKey(extnSellerOrg)) {
                    		      strSellerZoneCode = setLocaleCodeFromOrg(env,extnSellerOrg);
                    		    } else {
                    		    	  strSellerZoneCode = storeLocaleMap.get(extnSellerOrg);
                    		    }
                    		  if(!YFCCommon.isVoid(strSellerZoneCode))
                    		  {
                    			  strZoneCode = strSellerZoneCode;
                    		  }
            			  }
            		  }
            		  else if(KohlsPOCConstant.EVEN_EXCHANGE.equals(strMessageType))
            		  {           			 
            			  skipConversion = true;
            		  } 
            	  }
            	  if(!skipConversion)
            	  {
        		      String strConvertedDate = convertCorpDateTimeToStoreLocaleTime(strZoneCode, eleCurrent.getAttribute(strDate));
                  eleCurrent.setAttribute(strDate, strConvertedDate);  
            	  }
              
            }
          }
        }
      }	
    }
    else
    {
    		  if(KohlsPOCConstant.POST_SALE_ADJUSTMENT.equals(strMessageType) || KohlsPOCConstant.POST_SALE_VOID_AFTER.equals(strMessageType) || 
				  KohlsPOCConstant.POST_SALE_VOID_DURING.equals(strMessageType))
		  {
    			  Element eleCurrent = (Element) XPathUtil.getNodeList(
    			            invoiceDoc.getDocumentElement(), "//InvoiceDetail/InvoiceHeader/Extn").item(0);
    			  if(!YFCCommon.isVoid(eleCurrent))
    			  {
    				  String extnSellerOrg = eleCurrent.getAttribute(KohlsPOCConstant.ATTR_EXTN_SELLER_ORG_CODE);
    				  if(!YFCCommon.isVoid(extnSellerOrg))
	    			  {
	    				  String strSellerZoneCode = null;
	    	      		  if(!storeLocaleMap.containsKey(extnSellerOrg)) {
	    	      		      strSellerZoneCode = setLocaleCodeFromOrg(env,extnSellerOrg);
	    	      		    } else {
	    	      		    	  strSellerZoneCode = storeLocaleMap.get(extnSellerOrg);
	    	      		    }
	    	      		  if(!YFCCommon.isVoid(strSellerZoneCode))
	    	      		  {
	    	      			 String strConvertedDate = convertCorpDateTimeToStoreLocaleTime(strSellerZoneCode, eleCurrent.getAttribute(KohlsPOCConstant.ATTR_EXTN_ORDER_DATE));
	    	                 eleCurrent.setAttribute(KohlsPOCConstant.ATTR_EXTN_ORDER_DATE, strConvertedDate);
	    	      		  }      	  
	    			   }
    			  }
    			  
		  }
    }
    logger.endTimer("KohlsPoCSetStoreLocaleTime.callServiceToStoreLocaleInfo");
    return invoiceDoc;
  }
  
  /**
   * Create By ibmadmin * 
   * @param env
   * @param sLocaleCode
   * @return
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws Exception
   */
  public String getTimezoneForLocaleCode (YFSEnvironment env, String sLocaleCode) throws ParserConfigurationException, SAXException, IOException, Exception {
    logger.beginTimer("KohlsPoCSetStoreLocaleTime.getLocaleCodeForOrg");
    String strLocaleTimezone = "";
    // Getting Timezone for Locale.
    if(!YFCCommon.isVoid(sLocaleCode)) {
      String strLocaleOutputTemplate = "<LocaleList><Locale Localecode='' Timezone=''/></LocaleList>";
      Document docGetLocaleListIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ATTR_LOCALE);
      Element eleLocaleInput = docGetLocaleListIn.getDocumentElement();
      eleLocaleInput.setAttribute(KohlsPOCConstant.ATTR_EJ_LOCALE_CODE, sLocaleCode);
      if(logger.isDebugEnabled()){
        logger.debug("Input ot getLocaleList is :"+XMLUtil.getXMLString(docGetLocaleListIn));
      } 
      Document getLocalListOut = KohlsCommonUtil.invokeAPI(env ,XMLUtil.getDocument(strLocaleOutputTemplate),
          KohlsPOCConstant.API_GET_LOCALE_LIST, docGetLocaleListIn);
      if(!YFCCommon.isVoid(getLocalListOut))
      {
        Element eleLocaleListOut = getLocalListOut.getDocumentElement();
        Element eleLocale = (Element)eleLocaleListOut.getElementsByTagName(KohlsPOCConstant.ATTR_LOCALE).item(0);
        if(!YFCCommon.isVoid(eleLocale))
        {
          strLocaleTimezone = eleLocale.getAttribute(KohlsPOCConstant.ATTR_TIME_ZONE);
        }
      }
    }
    logger.endTimer("KohlsPoCSetStoreLocaleTime.getLocaleCodeForOrg");
    return strLocaleTimezone;
  }

  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    // LOG_CAT.debug("In the set properties method");

  }

  /**
   * This function is used to get the value for a property.
   * 
   * @param property
   *            property
   * @return String propValue
   */
  public String getPropertyValue(String property) {

    String propValue;
    propValue = YFSSystem.getProperty(property);
    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    return propValue;

  }
}
