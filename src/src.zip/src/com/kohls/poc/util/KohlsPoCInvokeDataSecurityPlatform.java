package com.kohls.poc.util;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;

import com.protegrity.common.XCException;
import com.protegrity.xcclient.XCAPI;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

/******************************************************************************************
 * File Name      : KohlsInvokeDataSecurityPlatform.java
 *
 * Description    : This class will return encrypt or decrypt value for given parameter as input and it will connect to server to get return value.
 * Needed input parameters for getting encrypt or decrypt vaues are serverHost,dataElement and policyUser.
 *
 * Modification Log :
 * ----------------------------------------------------------------------------------------
 * Ver #   Date          Author            Modification
 * ----------------------------------------------------------------------------------------
 * 0.01    26-06-2015    IBM 		   Initial Version
 * --------------------------------------------------------------------------------------
 *****************************************************************************************/ 
public class KohlsPoCInvokeDataSecurityPlatform {

	/**
	 *  sHostXC to save host details.
	 */
	private String sHostXC      = null;
	/**
	 * dataElement to save dataElement value.
	 */
	private String dataElement  = null;
	/**
	 * policyUser is to save userName.
	 */
	private String policyUser = null;
	/**
	 * encryptedValue is to save encryptedValue.
	 */
	private String encryptedValue = null;
	
	/**
	 * policyUserB is to save XC_CHARSET bytes.
	 */
	private byte[] policyUserB = null;
	/**
	 * dataElementB is to save XC_CHARSET bytes.
	 */
	private byte[] dataElementB = null;
	/**
	 * dataB is to save XC_CHARSET bytes.
	 */
	private byte[] dataB = null;
	/**
	 * resultBytes is to save encrypted value.
	 */
	private byte[] resultBytes = null;
	
	/**
	 * declaring reference for XCAPI.
	 */
	private XCAPI xc = null;
	
	/**
	 * LOG variable for logging. 
	 */
	private static final YFCLogCategory LOG = YFCLogCategory.instance(KohlsPoCInvokeDataSecurityPlatform.class.getName());
  
 
/**
 * @param host host
 * @param data data
 * @param user user
 * @throws XCException XCException
 * This method will prepare XCAPI reference and it will open session to connect server with parameters sHostXC,dataElement and policyUser.
 */
public void run(String host, String user) throws XCException {
	LOG.beginTimer("KohlsPoCInvokeDataSecurityPlatform.run");
    sHostXC       =	host;
   // dataElement   = data;
    policyUser    = user;
    xc = new XCAPI();
    xc.openSession(policyUser, null, sHostXC);
    LOG.endTimer("KohlsPoCInvokeDataSecurityPlatform.run");
  }

/**
 * @throws XCException
 * This method will responsible for close session which is opend with XCAPI.
 */
public void closeSession() throws XCException {
	LOG.beginTimer("KohlsPoCInvokeDataSecurityPlatform.closeSession");
	if(!YFCCommon.isVoid(xc)){
		xc.closeSession();
	}
	LOG.endTimer("KohlsPoCInvokeDataSecurityPlatform.closeSession");
}

/**
 * @param sData sData
 * @return encryptedValue
 * @throws XCException XCException
 * @throws UnsupportedEncodingException
 * This method will return encrypted value for given input parameter. 
 */
public String returnEncryptedValue(String sData, String dataElement) throws XCException, UnsupportedEncodingException {
		  LOG.beginTimer("KohlsPoCInvokeDataSecurityPlatform.returnEncryptedValue");
	      policyUserB = policyUser.getBytes("UTF-8");
	      dataElementB = dataElement.getBytes("UTF-8");
	      dataB = sData.getBytes("UTF-8");
	      resultBytes = xc.encrypt(0, policyUserB, dataElementB, dataB); 
	      LOG.debug("resultBytes:::::::::::::::::" + resultBytes);
	      encryptedValue = new String(Base64.encodeBase64(resultBytes), "UTF-8");
	      LOG.endTimer("KohlsPoCInvokeDataSecurityPlatform.returnEncryptedValue");
	    return encryptedValue;
	  }
  
  /**
 * @param sData sData
 * @return decrypt value.
 * @throws UnsupportedEncodingException exception
 * @throws XCException
 * This method will responsible for return decrypt value to given input parameter.
 */
public String returnDecryptedValue(String sData, String dataElement) throws UnsupportedEncodingException, XCException {
		  LOG.beginTimer("KohlsPoCInvokeDataSecurityPlatform.returnDecryptedValue");
		  LOG.debug("Inside returnDecryptedValue");
	      LOG.debug("sData:::::::::::::::::" + sData);
	      policyUserB = policyUser.getBytes("UTF-8");
	      dataElementB = dataElement.getBytes("UTF-8");
	      dataB = Base64.decodeBase64(sData.getBytes("UTF-8"));
	      LOG.debug("dataB:::::::::::::::::" + dataB);
	      resultBytes = xc.decrypt(1, policyUserB, dataElementB, dataB); 
	      LOG.debug("resultBytes:::::::::::::::::" + new String(resultBytes, "UTF-8"));
	      LOG.endTimer("KohlsPoCInvokeDataSecurityPlatform.returnDecryptedValue");
	    return new String(resultBytes, "UTF-8");
  }
  
  /**
* @param sData sData
* @return decrypt value.
* @throws UnsupportedEncodingException exception
* @throws XCException
* This method will responsible for return decrypt value to given input parameter.
*/
public String returnDecryptedValueForDetokenization(String sData, String dataElement) throws UnsupportedEncodingException, XCException {
		  LOG.beginTimer("KohlsPoCInvokeDataSecurityPlatform.returnDecryptedValue");
		  LOG.debug("Inside returnDecryptedValue");
	      LOG.debug("sData:::::::::::::::::" + sData);
	      policyUserB = policyUser.getBytes("UTF-8");
	      dataElementB = dataElement.getBytes("UTF-8");
	      dataB = sData.getBytes("UTF-8");
	      LOG.debug("dataB:::::::::::::::::" + dataB);
	      resultBytes = xc.decrypt(1, policyUserB, dataElementB, dataB); 
	      LOG.debug("resultBytes:::::::::::::::::" + new String(resultBytes, "UTF-8"));
	      LOG.endTimer("KohlsPoCInvokeDataSecurityPlatform.returnDecryptedValue");
	    return new String(resultBytes, "UTF-8");
 }
  
}
