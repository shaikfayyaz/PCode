package com.kohls.poc.util;

import java.util.Properties;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.ysc.util.YSCLogCategory;

public class KohlsPoCDetokenization {

	private KohlsPoCInvokeDataSecurityPlatform invokeDataSecurity = new KohlsPoCInvokeDataSecurityPlatform();
	private static YSCLogCategory logger;
	static {
		logger = YSCLogCategory
				.instance(KohlsPoCInvokeDataSecurityPlatform.class.getName());
	}
	private Properties props = null;
	/**
	 * sHostXC to save host details.
	 */
	private String sHostXC = null;
	/**
	 * dataElement to save dataElement value.
	 */
	private String dataElement = null;
	/**
	 * policyUser is to save userName.
	 */
	private String policyUser = null;

	public Document decryptyXml(YFSEnvironment env, Document inXml)
			throws Exception {
		logger.beginTimer("KohlsPocDetokenization.encryptDecryptXML");
		logger.debug("Input XML to KohlsPocDetokenization.decryptyXML is: "
				+ XMLUtil.getXMLString(inXml));

		String attribute = null;
		String attributePart1 = null;
		String attributePart2 = null;
		String[] delimitedSlash = null;
		String conversionType = null;
		String cryptingAttribute = null;
		String xPath = null;
		String attributeNo = null;
		/*
		 * Map<String, String> attributesDataMap = new HashMap<String,
		 * String>(); Element rootElement = inXml.getDocumentElement();
		 */
		int noOfAttributes = Integer.valueOf(this.props
				.getProperty(KohlsPOCConstant.NoOfAttributes));
		/*
		 * sHostXC = new String("nlg00601.tst.kohls.com:15911"); policyUser =
		 * new String("shdev");
		 */
		sHostXC = this
				.getPropertyValue(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
		policyUser = this.getPropertyValue(KohlsPOCConstant.POLICY_USER);
		logger.debug("The PROTEGRITY_SERVER_HOST is : " + sHostXC);
		logger.debug("The POLICY_USER is : " + policyUser);

		/*
		 * sHostXC = new String("localhost:15910"); policyUser = new
		 * String("shdev");
		 */
		logger.debug("The noOfAttributes value is : " + noOfAttributes);

		for (int i = 0; i < noOfAttributes; i++) {

			attributeNo = "Attribute" + (i + 1);
			logger.debug("The attribute No is : " + attributeNo);
			attributePart1 = this.props.getProperty(attributeNo + "_1");
			attributePart2 = this.props.getProperty(attributeNo + "_2");
			if (attributePart2 == null) {
				attributePart2 = " ";
			}
			// logger.debug("The attribute value is : " + attributePart1);
			attribute = attributePart1.concat(attributePart2).trim();
			logger.debug("The attribute to be encrypted is : " + attributePart2);
			delimitedSlash = attribute.split(KohlsPOCConstant.DelimitedSlash);
			logger.debug("the attribute is " + attribute);

			conversionType = delimitedSlash[0];
			logger.debug("the conversionType is " + conversionType);

			xPath = delimitedSlash[2];
			logger.debug("the xPath is " + xPath);

			cryptingAttribute = delimitedSlash[3];
			logger.debug("the cryptingAtribute is " + cryptingAttribute);

			dataElement = delimitedSlash[1];
			logger.debug("the dataElement is " + dataElement);

			if (!YFCCommon.isVoid(cryptingAttribute)) {
				// invokeDataSecurity.run(sHostXC, dataElement, policyUser);
				searchAndReplaceByGenericXPath(inXml, conversionType,
						cryptingAttribute, dataElement, xPath);

			}
		}

		logger.debug("Output XML from KohlsPoCSecurityUtil.encryptDecryptXML is: "
				+ XMLUtil.getXMLString(inXml));
		logger.endTimer("KohlsPoCSecurityUtil.encryptDecryptXML");
		return inXml;

	}

	public void searchAndReplaceByGenericXPath(Document inXml,
			String conversionType, String cryptingAttribute,
			String dataElement, String xPath) throws Exception {
		logger.beginTimer("KohlsPoCSecurityUtil.searchAndReplaceByGenericXPath");
		String cryptingAttributeValue = null;

		try {
			logger.debug("The in the try block--->");
			NodeList baseElementList = ((NodeList) XPathUtil.getNodeList(
					inXml.getDocumentElement(), xPath));

			for (int i = 0; i < baseElementList.getLength(); i++) {
				Element baseElement = (Element) baseElementList.item(i);
				logger.debug("the base element is "
						+ XMLUtil.getElementXMLString(baseElement));
				Element eleExtn = XMLUtil.getChildElement(baseElement, "Extn");
				String extnIsDetokenized = eleExtn
						.getAttribute("ExtnIsDetokenized");
				String extnIsOfflineMode = eleExtn
						.getAttribute("ExtnOfflineMode");
				cryptingAttributeValue = baseElement
						.getAttribute(cryptingAttribute);
				logger.debug("the crypting attribute Value is "
						+ cryptingAttributeValue);
				if (extnIsDetokenized != null
						&& extnIsDetokenized.equalsIgnoreCase("N")) {
					if (extnIsOfflineMode != null
							&& !extnIsOfflineMode.equalsIgnoreCase("Y")) {
						if (!YFCCommon.isVoid(cryptingAttributeValue)
								&& cryptingAttribute
										.equalsIgnoreCase("PromotionId")) {
							// initializing the crypt only when attribute to be
							// encrypted has
							// not null value
							// Opening Session to connect to Protegrity server
							// with
							// parameters
							// sHostXC,dataElement and policyUser.
							invokeDataSecurity.run(sHostXC,
									policyUser);

							logger.debug("conversion type :: " + conversionType);
							String strDetokenize = invokeDataSecurity
									.returnDecryptedValueForDetokenization(cryptingAttributeValue, dataElement);
							logger.debug("the value after decrypting is "
									+ strDetokenize);
							setCryptedValues(baseElement, strDetokenize,
									cryptingAttribute);
							// Closing the Protegrity server session
							invokeDataSecurity.closeSession();
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			YFSException es = new YFSException();
			if (e.getClass().getName()
					.equalsIgnoreCase("com.protegrity.common.XCException")) {
				logger.debug("Setting the YFSException");
				es.setErrorCode("KC_OFFLINE");
				es.setErrorDescription("Unable to complete request (Protegrity), to Encrypt PII Data");
			}
			throw es;
		}
		logger.endTimer("KohlsPocDetokenization.searchAndReplaceByGenericXPath");
	}

	/**
	 * @param prop
	 *            prop
	 * @throws Exception
	 *             This function is used to set properties reference.
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		// logger_CAT.debug("In the set properties method");

	}

	/**
	 * This function is used to get the value for a property.
	 * 
	 * @param property
	 *            property
	 * @return String propValue
	 */
	public String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		return propValue;

	}

	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void setCryptedValues(Element baseElement, String strDetokenize,
			String cryptingAttribute) throws DOMException {
		logger.beginTimer("KohlsPoCSecurityUtil.setCryptedValues");

		Element eleExtn = XMLUtil.getChildElement(baseElement, "Extn");
		if (!YFCCommon.isVoid(strDetokenize)) {
			eleExtn.setAttribute("ExtnIsDetokenized", "Y");
			eleExtn.setAttribute("ExtnActivationBarCode",strDetokenize);
			baseElement.setAttribute(cryptingAttribute, strDetokenize);
		} else {
			eleExtn.setAttribute("ExtnIsDetokenized", "N");
		}
		logger.endTimer("KohlsPoCSecurityUtil.setCryptedValues");
	}
}
