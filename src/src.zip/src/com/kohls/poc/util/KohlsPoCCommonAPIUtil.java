package com.kohls.poc.util;

/**
 
 */
// Java Imports
import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import org.apache.log4j.MDC;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.custom.util.StringUtil;
import com.ibm.sterling.afc.xapiclient.japi.XApi;
import com.ibm.sterling.afc.xapiclient.japi.XApiClientCreationException;
import com.ibm.sterling.afc.xapiclient.japi.XApiClientFactory;
import com.ibm.sterling.afc.xapiclient.japi.XApiEnvironment;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.shared.omp.OMPTransactionCache;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.kohls.common.util.KohlsConstant;
import com.sterlingcommerce.baseutil.SCDateTimeUtil;
import com.yantra.yfc.util.YFCLocale;

import javax.xml.parsers.FactoryConfigurationError;

/**
 * Encapsulates set of utility methods
 */
/**
 * @author mrjoshi
 *
 */
/**
 * @author mrjoshi
 *
 */
public final class KohlsPoCCommonAPIUtil implements YIFCustomApi {

  /**
   * Utility class for Common API Calls
   */

  private static YFCLogCategory logger;

  private static String sLAST_EXCLUSION_DFN_CHNG_TS = null;
  public static HashMap<String, String> exclusionsMap = new HashMap<String, String>();
  private static Document docGetCommonCodeListForEComStores = null;
  private static List<String> ecommStoreLists = new ArrayList<String>();
  static {
    logger = YFCLogCategory.instance(KohlsReprocessRequestUtil.class);

  }



  public static void setRestrictedReturnIndicator(YFSEnvironment env, Element orderLine, String org)
      {

    String dept = null;

    try {

      logger.beginTimer("KohlsPocCommonAPIUtil.setRestrictedReturnIndicator");

      Element orderLineExtn = XMLUtil.getFirstElementByName(orderLine, "Extn");


      if (!YFCCommon.isVoid(orderLineExtn)) {

        dept = orderLineExtn.getAttribute("ExtnItemDept");

      } else {

        return;
      }

      boolean isRestrictedReturn = false;

// Document commodeCodeListDoc = getCommonCodeList(env, "DEPT_RESTRCT_RTN_DAY", dept, org);
      
      Document outDocGetRuleListForPOS = prepareAndFetchGetRuleListForPOS(env, "PREMIUM_ELECTRONIC");

      if (!YFCCommon.isVoid(outDocGetRuleListForPOS)) {

    	  NodeList nlRuleList = outDocGetRuleListForPOS.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_RULE);
			Element eleRule = null;
			for(int j=0 ; j<nlRuleList.getLength();j++){
				eleRule = (Element) nlRuleList.item(j);
				String[] sdepartments = (eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE)).split(",");
				for(String strDept:sdepartments){
					if((strDept.equalsIgnoreCase(dept))){
						isRestrictedReturn=true;
						break;
					}
				}
			}
      }

      if (isRestrictedReturn) {

        Element References = XMLUtil.getFirstElementByName(orderLine, "References");
        if (YFCCommon.isVoid(References)) {
          References = XMLUtil.createChild(orderLine, "References");

        }
        Element reference = XMLUtil.createChild(References, "Reference");
        XMLUtil.setAttribute(reference, "Name", "ExtnIsRestrictedReturn");
        XMLUtil.setAttribute(reference, "Value", "Y");
      }
    } catch (Exception e) {
      e.printStackTrace();
      logger
          .debug("Inside KohlsPocCommonAPIUtil.setRestrictedReturnIndicator - Error while during call.DATA::org:deptofItem:codeType"
              + org + dept + ":DEPT_RESTRCT_RTN_DAY");
    }

    logger.endTimer("KohlsPocCommonAPIUtil.setRestrictedReturnIndicator");

  }


  public static Document getCommonCodeList(YFSEnvironment env, String strCommonCodeType,
      String strCommonCodeValue, String strOrganizationCode) throws Exception {
    logger.beginTimer("KohlsPoCCommonAPIUtil.getCommonCodeList");
    Document docInput = KohlsXMLUtil.createDocument(KohlsConstants.COMMON_CODE);
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsConstants.ORGANIZATION_CODE, strOrganizationCode);
    eleInput.setAttribute(KohlsConstants.CODE_TYPE, strCommonCodeType);
    eleInput.setAttribute(KohlsConstants.CODE_VALUE, strCommonCodeValue);
    Document docCommonCodeList =
        KOHLSBaseApi.invokeAPI(env, KohlsConstants.GET_COMMON_CODE_LIST, docInput);
    logger.endTimer("KohlsPoCCommonAPIUtil.getCommonCodeList");
    return docCommonCodeList;
  }
  
  
	/**
	 * This method calls KohlsPoCGetExclusionDefnService service to fetch
	 * exclusion definitions from OMS.
	 * @param yfsEnv
	 * @param sMaxRecords
	 * @return
	 * @throws Exception
	 * @throws ParseException
	 */
	public static Document getExclusionRules(YFSEnvironment yfsEnv, String sMaxRecords)
			throws Exception, ParseException {
		logger.beginTimer("KohlsPoCCommonAPIUtil.getExclusionRules");
		Document indocExclusionRules = XMLUtil.createDocument(KohlsPOCConstant.E_EXCLUSION_DEFN);
		Element eleExclusionRules = indocExclusionRules.getDocumentElement();
		XMLUtil.setAttribute(eleExclusionRules, KohlsPOCConstant.E_EXCLUSION_ACTIVE, KohlsPOCConstant.YES);
		if(!YFCCommon.isVoid(sMaxRecords)){
			XMLUtil.setAttribute(eleExclusionRules, "MaximumRecords", sMaxRecords);
		}		
		Element eleOrderBy = XMLUtil.createChild(eleExclusionRules, "OrderBy");
		Element eleAttribute = XMLUtil.createChild(eleOrderBy, "Attribute");
		eleAttribute.setAttribute("Name", "ModifyTS");
		eleAttribute.setAttribute("Desc", "Y");
		Document outdocGetExclusionRules = KOHLSBaseApi.invokeService(yfsEnv,
				KohlsPOCConstant.API_GET_EXCLUSION_CLASSIFICATION, indocExclusionRules);
		logger.endTimer("KohlsPoCCommonAPIUtil.getExclusionRules");
		return outdocGetExclusionRules;
	}

	
	public static boolean hasExclusionsBeenModified(YFSEnvironment yfsEnv)
			throws Exception {
		logger.beginTimer("KohlsPoCCommonAPIUtil.hasExclusionsBeenModified");
		boolean hasExclusionsBeenModified = false;
		Document exclusionDefnsOutDoc = getExclusionRules(yfsEnv, "1");		
		String sModifyTS = "";
		NodeList nlExclusionList = exclusionDefnsOutDoc.getElementsByTagName(KohlsPOCConstant.E_EXCLUSION_DEFN);
		if (nlExclusionList.getLength() > KohlsPOCConstant.ZERO_INT) {
			logger.debug("The Exclusion list is present");
			sModifyTS = ((Element)nlExclusionList.item(0)).getAttribute("ModifyTS");
			//If Last ModifyTS on the Exclusions list is same as Last Cashed date, then, exclusion is not modified
			//otherwise its modified.
			logger.debug("LAST_EXCLUSION_DFN_CHNG_TS is: "+sLAST_EXCLUSION_DFN_CHNG_TS+" and ModifyTS is: "+sModifyTS);
			if(!YFCCommon.isVoid(sModifyTS) && !YFCCommon.isVoid(sLAST_EXCLUSION_DFN_CHNG_TS)
					&& sModifyTS.equalsIgnoreCase(sLAST_EXCLUSION_DFN_CHNG_TS)){
				logger.debug("#### Exclusions list has not changed.####" );
				
			}else{
				logger.debug("#### Exclusions list has been modified####. \n ### LAST_EXCLUSION_DFN_CHNG_TS is: "
						+sLAST_EXCLUSION_DFN_CHNG_TS+" and ModifyTS is: "+sModifyTS);
				hasExclusionsBeenModified = true;
			}
		}
		logger.endTimer("KohlsPoCCommonAPIUtil.hasExclusionsBeenModified");
		return hasExclusionsBeenModified;
	}
	
	public static void buildExclusionsMap(YFSEnvironment yfsEnv) throws ParseException, Exception {
		logger.beginTimer("KohlsItemExclusionDefinition.buildExclusionsMap");
		String finalExclusionInfo=null;
		if(!exclusionsMap.isEmpty()){
			exclusionsMap.clear();
		}		
		Document docExclusionsOut = getExclusionRules(yfsEnv, "");
		NodeList exclusionDefnList = docExclusionsOut.getElementsByTagName(KohlsPOCConstant.E_EXCLUSION_DEFN);
		if(exclusionDefnList.getLength() > 0){
			String sLastModifyTS = ((Element)docExclusionsOut.getElementsByTagName(KohlsPOCConstant.E_EXCLUSION_DEFN).item(0)).getAttribute("ModifyTS");
			sLAST_EXCLUSION_DFN_CHNG_TS = sLastModifyTS;		
			for(int i=0;i<exclusionDefnList.getLength();i++)
			{
				Element exclusionDefn=(Element)exclusionDefnList.item(i);
	
				String extnClass=exclusionDefn.getAttribute(KohlsPOCConstant.E_EXCLUSION_CLASS);
				String extnSubClass=exclusionDefn.getAttribute(KohlsPOCConstant.E_EXCLUSION_SUBCLASS);
				String extnDept=exclusionDefn.getAttribute(KohlsPOCConstant.E_EXCLUSION_DEPT);
				
				if(!StringUtil.isEmpty(extnDept)){
					finalExclusionInfo=extnDept;
				}
	
				if(!StringUtil.isEmpty(extnClass)){
					finalExclusionInfo=finalExclusionInfo+"-"+extnClass;
				}
	
				if(!StringUtil.isEmpty(extnSubClass)){
					finalExclusionInfo=finalExclusionInfo+"-"+extnSubClass;
				}
	
				exclusionsMap.put(finalExclusionInfo,exclusionDefn.getAttribute("ExclusionActiveDate"));
			}
		}
		
		logger.endTimer("KohlsItemExclusionDefinition.buildExclusionsMap");
	}
	

  public void setProperties(Properties arg0) throws Exception {
    // TODO Auto-generated method stub

  }
  
  //Added for PST-443 - Start
  public static String getCorrelationID() {
		String correlationID = null;
        if(!YFCCommon.isVoid(MDC.get("CORID"))){
        	correlationID = MDC.get("CORID").toString();
        }else {
			correlationID = "OMS-COR-ID" + +Thread.currentThread().getId() + "-"
					+ System.currentTimeMillis();
		}
		return correlationID;
  }
  //Added for PST-443 - End
	
  public static String getLocaleCode(YFSEnvironment env, String shipNode) throws FactoryConfigurationError, Exception {

        String localeCode = KohlsPOCConstant.LOCALE_CODE_CST;
        Document getShipNodeListInputXML = SCXmlUtil.createDocument(KohlsXMLLiterals.E_SHIP_NODE);
        Element shipNodeEle = getShipNodeListInputXML.getDocumentElement();

        shipNodeEle.setAttribute(KohlsXMLLiterals.A_SHIPNODE_KEY, shipNode);
        logger.debug("ShipNodeList inputXML::", SCXmlUtil.getString(getShipNodeListInputXML));

        Document getShipNodeListTemplate = SCXmlUtil.createDocument(KohlsXMLLiterals.E_SHIP_NODE_LIST);
        Element shipNodeList = getShipNodeListTemplate.getDocumentElement();
        Element shipNodeTemplateEle = SCXmlUtil.createChild(shipNodeList, KohlsXMLLiterals.E_SHIP_NODE);
        shipNodeTemplateEle.setAttribute(KohlsXMLLiterals.A_SHIP_NODE_KEY_ATTRIBUTE, "");
        shipNodeTemplateEle.setAttribute(KohlsXMLLiterals.A_LOCALE_CODE, "");
        logger.debug("getShipNodeList template:", SCXmlUtil.getString(getShipNodeListTemplate));
        env.setApiTemplate(KohlsConstant.API_GET_SHIP_NODE_LIST, getShipNodeListTemplate.getOwnerDocument());
        try {
            Document eleOutGetShipNodeList = KOHLSBaseApi.invokeAPI(env, getShipNodeListTemplate,
                    KohlsConstant.API_GET_SHIP_NODE_LIST, getShipNodeListInputXML);
            logger.debug("getShipNodeList Output XMP:", SCXmlUtil.getString(eleOutGetShipNodeList));
            env.clearApiTemplate(KohlsConstant.API_GET_SHIP_NODE_LIST);
            Element shipNodeListOutputElement = eleOutGetShipNodeList.getDocumentElement();
            ArrayList<Element> shipNodes = SCXmlUtil.getChildren(shipNodeListOutputElement,
                    KohlsXMLLiterals.E_SHIP_NODE);
            for (Element shipNodeElement : shipNodes) {
                String shipNodekey = shipNodeElement.getAttribute(KohlsXMLLiterals.A_SHIP_NODE_KEY_ATTRIBUTE);
                if (shipNodekey.equals(shipNode)) {
                    localeCode = shipNodeElement.getAttribute(KohlsXMLLiterals.A_LOCALE_CODE);
                    break;
                }
            }
        } catch (Exception e) {
            logger.error(e);
        }
        return localeCode;
    }

    public static String getTimeZoneID(YFSEnvironment env, String localeCode) throws Exception {
        logger.debug("Locale Code:", localeCode);
        String timezoneID = KohlsPOCConstant.TIME_ZONE_CST;
        Document getLocaleListInputDoc = SCXmlUtil.createDocument(KohlsXMLLiterals.E_LOCALE);
        getLocaleListInputDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_LOCALE_CODE, localeCode);
        logger.debug("GetLocaleList inputXML::", SCXmlUtil.getString(getLocaleListInputDoc));

        Document getLocaleListTemplateDoc = SCXmlUtil.createDocument(KohlsXMLLiterals.E_LOCALE_LIST);
        Element localeListElement = getLocaleListTemplateDoc.getDocumentElement();
        Element eleLocaleList = SCXmlUtil.createChild(localeListElement, KohlsXMLLiterals.E_LOCALE);
        eleLocaleList.setAttribute(KohlsXMLLiterals.A_LOCALE_CODE, "");
        eleLocaleList.setAttribute(KohlsXMLLiterals.A_TIME_ZONE, "");
        env.setApiTemplate(KohlsConstant.API_GET_LOCALE_LIST, getLocaleListTemplateDoc.getOwnerDocument());
        logger.debug("GetLocaleList Input XML:", SCXmlUtil.getString(getLocaleListInputDoc.getOwnerDocument()));
        try {
            Document getLocaleListOutputDocument = KOHLSBaseApi.invokeAPI(env, getLocaleListTemplateDoc,
                    KohlsConstant.API_GET_LOCALE_LIST, getLocaleListInputDoc);
            logger.debug("GetLocaleList Output XML:", SCXmlUtil.getString(getLocaleListOutputDocument));

            env.clearApiTemplate(KohlsConstant.API_GET_LOCALE_LIST);
            Element localeList = getLocaleListOutputDocument.getDocumentElement();
            ArrayList<Element> localeElements = SCXmlUtil.getChildren(localeList, KohlsXMLLiterals.E_LOCALE);
            for (Element localeElement : localeElements) {
                String currentLocaleCode = localeElement.getAttribute(KohlsXMLLiterals.A_LOCALE_CODE);
                if (localeCode.equals(currentLocaleCode)) {
                    logger.debug("*** FOUND TIME ZONE ID ***");
                    timezoneID = localeElement.getAttribute(KohlsXMLLiterals.A_TIME_ZONE);
                    break;
                }
            }
        } catch (Exception e) {
            logger.error(e);
        }
        logger.debug("Time Zone ID: ", timezoneID);
        return timezoneID;
    }

    public static String convert(String dateTime, String timeZone) throws ParseException {

        String convertedDate = SCDateTimeUtil.convert(dateTime, SCDateTimeUtil.ISO_DATETIMEZONE_FORMAT,
                SCDateTimeUtil.ISO_DATETIMEZONE_FORMAT,
                com.ibm.icu.util.TimeZone.getTimeZone(YFCLocale.getInstallationTimeZone()),
                com.ibm.icu.util.TimeZone.getTimeZone(timeZone));
        if (convertedDate.length() == 24) {
            convertedDate = convertedDate.substring(KohlsConstant.NUMBER_0, KohlsConstant.NUMBER_22).concat(":")
                    .concat(convertedDate.substring(KohlsConstant.NUMBER_22, KohlsConstant.NUMBER_24));
        }
        return convertedDate;
    }
    
    public static String getRuleValuesfromDB(YFSEnvironment env) throws Exception
	{
		logger.beginTimer("KohlsPocCommonAPIUtil.getRuleValuesfromDB");
		
	    String strRuleValue = "";
	    Document docGetRuleListInput = XMLUtil.createDocument("Rules");
	    Element eleRuleInput = docGetRuleListInput.getDocumentElement();
	    
	    eleRuleInput.setAttribute(KohlsPOCConstant.A_RULE_ID, "LPF_REWARD_LOOKUP");
	    Document docGetRuleListOut = KOHLSBaseApi.invokeAPI(env,
	        KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docGetRuleListInput);
	    if (docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).getLength() > 0) {
	      Element eleRule =
	          (Element) docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).item(0);
	      strRuleValue = eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
	    }
	    
	    logger.endTimer("KohlsPocCommonAPIUtil.getRuleValuesfromDB");
	    return strRuleValue;
	}
    
    public static Document prepareAndFetchGetRuleListForPOS ( YFSEnvironment env, String strGroupName){
  	  Document docGetRuleListForPOS = null;
    try{
  	  Document docInput = KohlsXMLUtil.createDocument(KohlsPOCConstant.E_RULE);
  	    Element eleInput = docInput.getDocumentElement();
  	    Element eleRuleMetaData = KohlsXMLUtil.createChild(eleInput, "RuleMetadata");			    
  	    eleRuleMetaData.setAttribute("GroupName", strGroupName);			   
  	  docGetRuleListForPOS =
  	        KOHLSBaseApi.invokeAPI(env,KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docInput);
    }
    catch(Exception e){
  	  logger.error("prepareAndFetchGetRuleListForPOS" + e);
    }
  	    return docGetRuleListForPOS;
    }
    
    public static HashMap<String,String> getRuleListByGroupName ( YFSEnvironment env, String strGroupName, String orgCode){
    	logger.beginTimer("KohlsPoCCommonAPIUtil.getRuleListByGroupName - START");
    	Document docGetRuleListForPOS = null;
    	HashMap<String,String> rulesMap = new HashMap<String,String>();
  	    try{
  	    	Document docInput = KohlsXMLUtil.createDocument(KohlsPOCConstant.E_RULE);
  	  	    Element eleInput = docInput.getDocumentElement();
  	  	    eleInput.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, orgCode);
  	  	    Element eleRuleMetaData = KohlsXMLUtil.createChild(eleInput, KohlsPOCConstant.RULE_META_DATA);			    
  	  	    eleRuleMetaData.setAttribute(KohlsPOCConstant.GROUP_NAME, strGroupName);			   
  	  	    docGetRuleListForPOS = KOHLSBaseApi.invokeAPI(env,KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docInput);
  	    }
  	    catch(Exception e){
  	  	  	logger.error("getRuleListByGroupName" + e);
  	    }
      if (!YFCCommon.isVoid(docGetRuleListForPOS)) {
      	  NodeList nlRuleList = docGetRuleListForPOS.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_RULE);
  			Element eleRule = null;
  			for(int j=0 ; j<nlRuleList.getLength();j++){
  				eleRule = (Element) nlRuleList.item(j);
  				String ruleID = eleRule.getAttribute(KohlsPOCConstant.A_RULE_ID);
  				String ruleValue = eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE); 	
  				rulesMap.put(ruleID, ruleValue);
  			}
        }
      logger.endTimer("KohlsPoCCommonAPIUtil.getRuleListByGroupName - END");
      return rulesMap;
      }	
/**
* This method as QueryTimeout attribute to the root element and if needed TimeoutLockedUpdates as true which is for
* update / change api's 
* @param env
* @param eleRoot
* @throws Exception
*/
public static void setQueryTimeOut(YFSEnvironment env, Element eleRoot, boolean bIsTimeOutNeeded) throws Exception {

String strRuleValue = getRuleValue(env, "MONITORED_TIMEOUT", "KOHLS-RETAIL", "");
if(!YFCCommon.isVoid(strRuleValue)) {
eleRoot.setAttribute("QueryTimeout", strRuleValue);
if(bIsTimeOutNeeded) {
eleRoot.setAttribute("TimeoutLockedUpdates", "true");
}
}
}
    
    /**
     * Create By ibmadmin *
     * 
     * @param docInput
     * @param elemOrdLine
     * @throws ParseException
     */
    public static String getRuleValue(YFSEnvironment env, String ruleID, String callingOrgCode, String defaultValue) throws Exception {
      logger.beginTimer("KohlsPoCCommonAPIUtil.getRuleValue");
      String strRuleValue = null;
      if(YFCCommon.isVoid(callingOrgCode)) {
        callingOrgCode = "KOHLS-RETAIL";
      }
      callingOrgCode = callingOrgCode.replaceFirst("^0+(?!$)", "");
      //Checking if rule is already called, then return value from env otherwise call 
      if(!YFCCommon.isVoid(env.getTxnObject(ruleID+"_"+callingOrgCode))){
        strRuleValue = (String)env.getTxnObject(ruleID+"_"+callingOrgCode);
        logger.debug("Returning value from Env object");
        logger.endTimer("KohlsPoCCommonAPIUtil.getRuleValue");
        return strRuleValue;
      }
      Document docGetRuleListInput = XMLUtil.createDocument("Rule");
      Element eleRuleInput = docGetRuleListInput.getDocumentElement();
      eleRuleInput.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, callingOrgCode);
      eleRuleInput.setAttribute(KohlsPOCConstant.A_RULE_ID, ruleID);
      Document docGetRuleListOut = KOHLSBaseApi.invokeAPI(env,
          KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docGetRuleListInput);
      if (docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).getLength() > 0) {
        Element eleRule =
            (Element) docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).item(0);
        strRuleValue = eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
        
      }
      if(strRuleValue == null)
      {
      	strRuleValue = defaultValue;
      }
      //setting value in env object to reuse it
      env.setTxnObject(ruleID+"_"+callingOrgCode, strRuleValue);
      logger.endTimer("KohlsPoCCommonAPIUtil.getRuleValue");
      return strRuleValue;
    }
    
    /**Returns if the Store isECom or Not
     * @param env
     * @return
     * @throws Exception
     */
    public static boolean isEcomStore( YFSEnvironment env, String storeNumber ) throws Exception
    {
    	logger.beginTimer("KohlsPoCCommonAPIUtil.isEcomStore");
    	boolean bEComStore = false;
    	if(!YFCCommon.isVoid(storeNumber)){
    		try{
    			if ( docGetCommonCodeListForEComStores == null && ecommStoreLists.size()==0)
    			{
    				docGetCommonCodeListForEComStores = KohlsPoCCommonAPIUtil.getCommonCodeList(env, KohlsPOCConstant.COMMON_CODE_TYPE_EComStores, 
    				    storeNumber, KohlsPOCConstant.DEFAULT);
    				NodeList commonCodeNodes = XPathUtil.getNodeList(docGetCommonCodeListForEComStores.getDocumentElement(), "//CommonCodeList/CommonCode" );
    				if ( commonCodeNodes != null )
    				{
    					String codeValue = null;
    					for(int index=0;index < commonCodeNodes.getLength();index++ )
    					{
    						Element commonCodeNode = (Element)commonCodeNodes.item( index );
    						codeValue = commonCodeNode.getAttribute( KohlsConstant.A_CODE_VALUE );
    						if(!YFCCommon.isVoid(codeValue)){
    							ecommStoreLists.add( String.valueOf(Integer.parseInt(codeValue)) );
    						}
    					}
    				}
    			}
    			if(!YFCCommon.isVoid(ecommStoreLists) && ecommStoreLists.size()>0){
    				if(ecommStoreLists.contains( String.valueOf(Integer.parseInt(storeNumber)) )){
    					bEComStore = true;
    				}
    			}
    		}catch(Exception e){
    			logger.error("Exception while checking EComStores");
    		}
    	}
    	logger.endTimer("KohlsPoCCommonAPIUtil.isEcomStore");
    	return bEComStore;
    }
    
    /**
     * Converts transaction number to Store ID
     * 
     * @param transactionNo
     * @return
     */
     public static String getStoreNumberFromTransactionNumber(String transactionNo) {
         String storeNumber = "";
         if (!YFCCommon.isVoid(transactionNo)) {
             String transactionNbrLength = Integer.toString(transactionNo.length());
             if ( KohlsPOCConstant.TRANSACTION_NO_LENGTH.equals(transactionNbrLength)) {
                 // Digit 12 to 16 of Transaction no is store no.
                 storeNumber = transactionNo.substring( 12, 16 );
                 
                 //MJ 05/05 Added logic to convert store to int 0039 -> 39.
                 storeNumber = String.valueOf(Integer.parseInt(storeNumber));
             } else {
                 logger.debug( "KohlsReturnUtil.getStoreIdFromTransNbr():  Transaction number is not 22 digit long, Input Transaction No Length =  " + transactionNbrLength );
             }
         }
         return storeNumber;
     }
     
     /**
      * Converts transaction number to Terminal ID
      * 
      * @param transactionNo
      * @return
      */
     public static String getTerminalIdFromTransactionNumber( String transactionNo )
     {
        String terminalId = "";
        if ( !YFCCommon.isVoid( transactionNo ) )
        {
           String transactionNbrLength = Integer.toString( transactionNo.length() );
           if ( KohlsPOCConstant.TRANSACTION_NO_LENGTH.equals( transactionNbrLength ) )
           {
              // Digit 16 to 18 of Transaction no is terminal id.
              terminalId = transactionNo.substring( 16, 18 );
           }
           else
           {
              logger.debug( "KohlsReturnUtil.getTerminalIdFromTransNbr():  Transaction number is not 22 digit long, Input Transaction No Length =  " + transactionNbrLength );
           }
        }
        return terminalId;
     }
     
     /**
      * Converts transaction number to Sequence Number
      * 
      * @param transactionNo
      * @return
      */
     public static String getSequenceNbrFromTransactionNumber( String transactionNo )
     {
        String sequenceNumber = KohlsCorpReturnsConstants.EMPTY_STRING;
        if ( !YFCCommon.isVoid( transactionNo ) )
        {
           String transactionNbrLength = Integer.toString( transactionNo.length() );
           if ( KohlsCorpReturnsConstants.TRANSACTION_NO_LENGTH.equals( transactionNbrLength ) )
           {
              // last 4 digit of Transaction no is sequence no.
              sequenceNumber = transactionNo.substring( 18, 22 );
           }
           else
           {
              logger.debug( "KohlsReturnUtil.getSequenceNbrFromTransNbr():  Transaction number is not 22 digit long, Input Transaction No Length =  " + transactionNbrLength );
           }
        }
        return sequenceNumber;
     }
     
     /**
      * Converts transaction number to Order Date in Data Base order Date Format
      * 
      * @param transactionNo
      * @return
      */
     public static String getOrderDateFromTransactionNumber( String transactionNo )
     {
        String formattedOrderDate = KohlsCorpReturnsConstants.EMPTY_STRING;
        if ( !YFCCommon.isVoid( transactionNo ) )
        {
           String transactionNbrLength = Integer.toString( transactionNo.length() );
           if ( KohlsCorpReturnsConstants.TRANSACTION_NO_LENGTH.equals( transactionNbrLength ) )
           {
              // First 12 digit of Transaction no is sale order date.
              String orderDate = transactionNo.substring( 0, 12 );
              DateFormat inputFormatter = new SimpleDateFormat( KohlsCorpReturnsConstants.TRANSACTION_NUMBER_DATE_FORMAT );
              DateFormat outputFormatter = new SimpleDateFormat( KohlsCorpReturnsConstants.ORDER_DATE_FORMAT );
              try
              {
                 formattedOrderDate = outputFormatter.format( (Date) inputFormatter.parse( orderDate ) );
              }
              catch ( ParseException exception )
              {
                 logger.error( "KohlsReturnUtil.getOrderDateFromTransNbr():  " + exception.getMessage() );
                 // use this format
                 // "yyyy-MM-dd'T'HH:mm:ss";
                 // original format is MMddyyHHmmss
                 if (transactionNo != null && !"".equalsIgnoreCase(transactionNo) && transactionNo.length() >= 12) {
                     // always going to be year 2000s
                     // 081517123045
                     formattedOrderDate = "20" + transactionNo.substring(4,6) + "-" + transactionNo.substring(0,2) + "-" + transactionNo.substring(2,4) + "T" 
                             + transactionNo.substring(6,8) + ":" + transactionNo.substring(8,10) + ":" + transactionNo.substring(10,12);
                 } else {
                     // default the txn time stamp
                      formattedOrderDate = "1970-01-01T00:00:00";
                 }
                 exception.printStackTrace();
              }
           }
           else
           {
             logger.debug( "KohlsReturnUtil.getOrderDateFromTransNbr():  Transaction number is not 22 digit long, Input Transaction No Length =  " + transactionNbrLength );
              if (transactionNo != null && !"".equalsIgnoreCase(transactionNo) && transactionNo.length() >= 12) {
                 formattedOrderDate = "20" + transactionNo.substring(4,6) + "-" + transactionNo.substring(0,2) + "-" + transactionNo.substring(2,4) + "T" 
                         + transactionNo.substring(6,8) + ":" + transactionNo.substring(8,10) + ":" + transactionNo.substring(10,12);
              } else {
                  // default the txn time stamp
                  formattedOrderDate = "1970-01-01T00:00:00";
              }
           }
        }
        return formattedOrderDate;
     }
    

     public static String getTransactionIdFromReceiptID(String receiptId)
     {
         String orig = receiptId;
         if ((receiptId == null) || (receiptId.length() < 6)) {
             throw new RuntimeException("Invalid Receipt");
         }
         if (receiptId.length() == 22) {
             return receiptId;
         }
         try {
             if (receiptId.startsWith("0")) {
                 receiptId = receiptId.substring(1);
             }
             if (receiptId.length() != 27) {
                 throw new RuntimeException("Invalid Receipt");
             }
             if (String.valueOf(receiptId.charAt(receiptId.length() - 1)).equals(String.valueOf(
                     calculateMod10CheckDigit(receiptId.substring(0, receiptId.length() - 1))))) {
                 String transId = trim1(receiptId);
                 transId = calculate10sComplement(transId);
                 if (String.valueOf(transId.charAt(transId.length() - 1)).equals(String.valueOf(
                         calculateMod10CheckDigit(transId.substring(0, transId.length() - 1))))) {
                     transId = trim1(transId);
                     transId = transId.substring(3);
                     return transId;
                 }
             }
             throw new RuntimeException("Invalid Receipt"); 
         } catch (Exception e) {
             throw ((RuntimeException)new RuntimeException().initCause(e));
         }
     }
     
     private static String trim1(String str) {
         return str.substring(0, str.length() - 1);
     }
     
     protected static int calculateMod10CheckDigit(final String id) throws Exception
     {
         // allowable characters within identifier
         String validChars = "0123456789";
         
         // this will be a running total
         int checkSum = 0;
         
         // loop through digits from right to left
         for (int i = 0; i < id.length(); i++) {
             
             // set ch to "current" character to be processed
             char ch = id.charAt( id.length() - i - 1 );

             // throw exception for invalid characters
             if ( validChars.indexOf( ch ) == -1 ) {
                 throw new Exception( "\"" + ch + "\" is an invalid character in Mod 10 Checker" );
             }

             // our "digit" is calculated using ASCII value - 48
             int digit = ch - 48;

             // weight will be the current digit's contribution to
             // the running total
             int weight;
             if ( i % 2 == 0 ) {
                 // for alternating digits starting with the rightmost, we
                 // use our formula this is the same as multiplying x 2 and
                 // adding digits together for values 0 to 9.
                 weight = ( 2 * digit ) - ( digit / 5 ) * 9;

             } else {
                 // even-positioned digits just contribute their ascii
                 // value minus 48
                 weight = digit;
             }
             
             // keep a running total of weights
             checkSum += weight;
         }
         
         // avoid sum less than 10 (if characters below "0" allowed,
         // this could happen)
         checkSum = Math.abs( checkSum ) + 10;

         // check digit is amount needed to reach next number
         // divisible by ten
         return ( 10 - ( checkSum % 10 ) ) % 10;
     }
     
     /**
         * 
         * @param id the id
         * @return the string
         * @throws Exception the exception
         */
     protected static final String calculate10sComplement(String id) throws Exception {      

         // Validate to make sure there are no special characters
         validateAllDigits(id);
         
         id = StringUtils.trim(id);

         int[] complementArray = new int[id.length()];

         boolean carry = true;

         // loop through digits from right to left
         for (int i = 0; i < id.length(); i++) {
             // set ch to "current" character to be processed
             int idx = id.length() - i - 1;
             char ch = id.charAt( idx );

             // our "digit" is calculated using ASCII value - 48
             int digit = ch - 48;
              
             int compDigit = 0;

             if (carry) {
                 if (digit != 0) {
                     carry = false;
                     compDigit = 10 - digit;
                 }
             } else {
                 compDigit = 9 - digit;
              }
              
              complementArray[idx] = compDigit;
           }

           StringBuffer buffer = new StringBuffer( "" );

           if ( carry ) // If we were all zeros
              buffer.append( "1" );

           for ( int x : complementArray )
           {
              buffer.append( x );
           }
           return buffer.toString();

        }
        
        private static void validateAllDigits( final String id ) throws Exception
        {
           String trimmedId = StringUtils.trim( id );
           // allowable characters within identifier
           String validChars = "0123456789";

           // loop through digits from right to left
           for ( int i = 0; i < trimmedId.length(); i++ )
           {

              // set ch to "current" character to be processed
              char ch = trimmedId.charAt( trimmedId.length() - i - 1 );

              // skip invalid characters
              if ( validChars.indexOf( ch ) == -1 )
              {
                 System.out.println( "\"" + ch + "\" is an invalid character when checking for 10's Complement for \"" + id + "\"" );
                 throw new Exception( "\"" + ch + "\" is an invalid character when checking for 10's Complement for \"" + id + "\"" );
              }
           }
        }

        
        /**
         * Create By mrjoshi * 
         * @param map
         * @param sortType
         * @return
         */
        @SuppressWarnings({"unchecked", "rawtypes"})
        public static HashMap sortHashMapByValue(HashMap map, final String sortType) {
          logger.beginTimer("KohlsPoCCommonAPIUtil.sortHashMapByValue");
            List list = new LinkedList(map.entrySet());
            // Custom Comparator here
            Collections.sort(list, new Comparator() {
                public int compare(Object o1, Object o2) {
                  if("ASC".equalsIgnoreCase(sortType)) {
                    return ((Comparable) ((Map.Entry) (o1)).getValue())
                        .compareTo(((Map.Entry) (o2)).getValue());
                  } else {
                    return ((Comparable) ((Map.Entry) (o2)).getValue())
                            .compareTo(((Map.Entry) (o1)).getValue());
                  }
                }
            });
      
            HashMap<Object, Object> sortedHashMap = new LinkedHashMap();
            for (Iterator<?> it = list.iterator(); it.hasNext();) {
                Map.Entry<String, Double> entry = (Map.Entry) it.next();
                sortedHashMap.put(entry.getKey(), entry.getValue());
            }  
          logger.endTimer("KohlsPoCCommonAPIUtil.sortHashMapByValue");
          return sortedHashMap;
        }
        
}
