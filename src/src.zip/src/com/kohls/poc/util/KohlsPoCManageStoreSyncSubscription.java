package com.kohls.poc.util;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;


/**************************************************************************
 * File : KohlsPoCManageStoreSyncSubscription.java 
 * Author : Yantriks Created : Mar 14 2017
 ***************************************************************************** 
 * This document has been prepared and written by Yantriks
 * on behalf of Kohls, and is copyright of Kohls
 *****************************************************************************/
 
public class KohlsPoCManageStoreSyncSubscription extends KOHLSBaseApi {
	
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCManageStoreSyncSubscription.class.getName());
	
	public Document manageStoreSubscription(YFSEnvironment env, Document inDoc) throws Exception {
		logger.debug("Beginning manageStoreSubscription with inDoc " + SCXmlUtil.getString(inDoc));
	    Document docSyncSubscriptionListInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_SUBSCRIPTION);
	    docSyncSubscriptionListInput.getDocumentElement().setAttribute(KohlsConstant.A_ORGANIZATION_CODE, KohlsConstant.KOHLS_RETAIL);
	    logger.debug("docSyncSubscriptionListInput " + SCXmlUtil.getString(docSyncSubscriptionListInput));
	    String strSubscriptionKey = getSubscriptionKey(env, docSyncSubscriptionListInput);
		logger.debug("strSubscriptionKey returned from getSubscriptionKey " + strSubscriptionKey);
		Element eleInDoc = inDoc.getDocumentElement();
		ArrayList<Element> syncStoreList = SCXmlUtil.getChildren(eleInDoc, KohlsPOCConstant.A_SYNC_STORE);
		for(Element syncStore: syncStoreList){
			logger.debug("current syncStore is " + SCXmlUtil.getString(syncStore));
			String strAction = "";
			logger.debug("syncStore.getAttribute(KohlsPOCConstant.A_ACTION) is " + syncStore.getAttribute(KohlsPOCConstant.A_ACTION));
			strAction = syncStore.getAttribute(KohlsPOCConstant.A_ACTION);
			logger.debug("strAction is " + strAction);
			
			if(KohlsPOCConstant.A_ACTION_ADD.equalsIgnoreCase(strAction)){
				callManageSyncTarget(env, KohlsPOCConstant.A_ACTION_ADD, syncStore, strSubscriptionKey);
			} else if (KohlsPOCConstant.REMOVE.equalsIgnoreCase(strAction)){
				callManageSyncTarget(env, KohlsPOCConstant.REMOVE, syncStore, strSubscriptionKey);
			}
		}
		return SCXmlUtil.createDocument("Success");
	}
	
	private Document callManageSyncTarget(YFSEnvironment env, String sAction, Element syncStore, String strSubscriptionKey) throws Exception {
		logger.debug("Beginning callManageSyncTarget with syncStore element " + SCXmlUtil.getString(syncStore));
		logger.debug("Beginning callManageSyncTarget with sAction " + sAction);
		logger.debug("Beginning callManageSyncTarget with strSubscriptionKey" + strSubscriptionKey);
	    Document docManageSyncTargetInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_TARGET);
	    Element eleSyncTarget = docManageSyncTargetInput.getDocumentElement();
	    if(KohlsPOCConstant.A_ACTION_ADD.equalsIgnoreCase(sAction)){
	    	eleSyncTarget.setAttribute(KohlsPOCConstant.A_OPERATION, KohlsPOCConstant.MANAGE);
	    } else  if(KohlsPOCConstant.REMOVE.equalsIgnoreCase(sAction)){
	    	eleSyncTarget.setAttribute(KohlsPOCConstant.A_OPERATION, KohlsPOCConstant.DELETE);
	    }
	    eleSyncTarget.setAttribute(KohlsConstant.A_ORGANIZATION_CODE, KohlsConstant.KOHLS_RETAIL);
	    eleSyncTarget.setAttribute(KohlsConstant.A_SHORT_DESCRIPTION, syncStore.getAttribute(KohlsConstant.STORE_ID_PARAMETER));
	    eleSyncTarget.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, syncStore.getAttribute(KohlsConstant.STORE_ID_PARAMETER));
	    eleSyncTarget.setAttribute(KohlsPOCConstant.A_SYNC_SUBSCRIPTION_KEY, strSubscriptionKey);
	    logger.debug("docManageSyncTargetInput is " + SCXmlUtil.getString(docManageSyncTargetInput));
	    Document docManageSyncTargetOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_MANAGE_SYNC_TARGET_TEMPLATE_PATH, KohlsPOCConstant.API_MANAGE_SYNC_TARGET, docManageSyncTargetInput);
		logger.debug("docManageSyncTargetOutput is " + SCXmlUtil.getString(docManageSyncTargetOutput));
		return docManageSyncTargetOutput;

	}

	private String getSubscriptionKey(YFSEnvironment env, Document docSyncSubscriptionListInput) throws Exception {
		logger.debug("Beginning getSubscriptionKey with docSyncSubscriptionListInput " + SCXmlUtil.getString(docSyncSubscriptionListInput));
		Document docSyncProfileListOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_GET_SYNC_SUBSCRIPTION_LIST_TEMPLATE_PATH, KohlsPOCConstant.API_GET_SYNC_SUBSCRIPTION_LIST, docSyncSubscriptionListInput);
		logger.debug("docSyncProfileListOutput is " + SCXmlUtil.getString(docSyncProfileListOutput));
		String sSyncSubscriptionKey = null;
		if(docSyncProfileListOutput != null) {
			ArrayList<Element> syncSubscriptionList = SCXmlUtil.getChildren(docSyncProfileListOutput.getDocumentElement(), KohlsPOCConstant.E_SYNC_SUBSCRIPTION);
				for(Element syncSubscription : syncSubscriptionList){
					logger.debug("current syncSubscription element " + SCXmlUtil.getString(syncSubscription));
					sSyncSubscriptionKey = syncSubscription.getAttribute(KohlsPOCConstant.A_SYNC_SUBSCRIPTION_KEY);
					logger.debug("current sSyncSubscriptionKey is " + sSyncSubscriptionKey);
					break;
				}
		}
		logger.debug("Ending getSubscriptionKey");
		return sSyncSubscriptionKey;
	}
}
