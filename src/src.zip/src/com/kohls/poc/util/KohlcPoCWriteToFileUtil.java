package com.kohls.poc.util;

import java.io.FileWriter;
import java.io.IOException;

import com.yantra.yfc.util.YFCCommon;
import com.yantra.ysc.util.YSCLogCategory;


public class KohlcPoCWriteToFileUtil 
{
		FileWriter fw;
		
		private static YSCLogCategory logger;
		static {
			logger = YSCLogCategory
					.instance(KohlcPoCWriteToFileUtil.class.getName());
		}
		public KohlcPoCWriteToFileUtil (String sFileNname, boolean bAppend) throws IOException{
		  logger.beginTimer("KohlcPoCWriteToFileUtil.constructor");
		  fw = new FileWriter(sFileNname, bAppend);
		  logger.endTimer("KohlcPoCWriteToFileUtil.constructor");
		}
		

		public void writeDataToFile
		
		(String sContentToWrite) throws Exception
		{
		  logger.beginTimer("KohlcPoCWriteToFileUtil.writeToFileData");
			fw.write(sContentToWrite);			
			logger.endTimer("KohlcPoCWriteToFileUtil.writeToFileData");
		}
		
		
		public void closeFile() throws Exception
        {
		  logger.beginTimer("KohlcPoCWriteToFileUtil.closeFile");
		  if(!YFCCommon.isVoid(fw)){		    
		    fw.close();   
		  }            
           logger.endTimer("KohlcPoCWriteToFileUtil.closeFile");
        }

}
