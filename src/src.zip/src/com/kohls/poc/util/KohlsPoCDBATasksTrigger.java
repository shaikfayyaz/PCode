package com.kohls.poc.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.core.YCPContext;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;


/**************************************************************************
 * File : KohlsPoCExecuteOracleProcedure.java 
 * Author : Yantriks Created : Dec 11 2017
 ***************************************************************************** 
 * This document has been prepared and written by Yantriks
 * on behalf of Kohls, and is copyright of Kohls
 *****************************************************************************/
 
public class KohlsPoCDBATasksTrigger extends KOHLSBaseApi {
	
	public static final String GRANT_VALIDATION_SCRIPT = "SELECT  decode(COUNT(1),0,'SUCCESS','NOT SUCCESS') as STATUS "
			+ "FROM (SELECT OBJECT_NAME FROM DBA_OBJECTS WHERE OWNER = 'STERLING' "
			+ "AND OBJECT_TYPE IN ('TABLE', 'VIEW') MINUS SELECT DISTINCT TABLE_NAME "
			+ "FROM DBA_TAB_PRIVS WHERE OWNER = 'STERLING' AND GRANTEE = 'OSREADER')";	
	public static final String ITEM_LOOKUP_VALIDATION_SCRIPT = "SELECT DECODE(COUNT (NAME),1,'SUCCESS','NOT SUCCESS') as STATUS "
			+ "FROM DBA_SQL_PROFILES WHERE NAME='SP_1wfp31u1uvpm6'";
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCDBATasksTrigger.class.getName());
	
	public Document triggerDBATask(YFSEnvironment env, Document inDoc) throws Exception {
		Element eleInDoc = inDoc.getDocumentElement();
		String strTask = eleInDoc.getAttribute(KohlsPOCConstant.A_TASK);
		String strAction= eleInDoc.getAttribute(KohlsPOCConstant.A_ACTION);
		Document outDoc = null;
			
		if(KohlsPOCConstant.A_TRIGGER.equalsIgnoreCase(strAction)){
			if(KohlsPOCConstant.A_ITEM_LOOKUP.equalsIgnoreCase(strTask)){
				outDoc = callItemLookupTuningScript(env, inDoc);
			}else if(KohlsPOCConstant.A_GRANT_PERMISSION.equalsIgnoreCase(strTask)){
				outDoc = callGrantPermissionScript(env, inDoc);
			}
			outDoc = callValidationScript(env, inDoc);
		}
		
			
		return outDoc;
	}
	
	public Document callGrantPermissionScript(YFSEnvironment env, Document inDoc) throws Exception {
		logger.debug("Beginning callGrantPermissionScript with inDoc " + SCXmlUtil.getString(inDoc));
		Element eleInDoc = inDoc.getDocumentElement();
		String strPerformValidation = eleInDoc.getAttribute(KohlsPOCConstant.A_PERFORM_VALIDATION);
		KohlsDataPump datapump = new KohlsDataPump();
		datapump.callOracleProcedure(env, KohlsPOCConstant.ORACLE_PROCEDURE);
		if(KohlsPOCConstant.YES.equalsIgnoreCase(strPerformValidation)){
			return callValidationScript(env, inDoc);
		}
		return SCXmlUtil.createDocument(KohlsPOCConstant.SUCCESS);
	}
	
	public Document callItemLookupTuningScript(YFSEnvironment env, Document inDoc) throws Exception {
		logger.debug("Beginning callItemLookupScript with inDoc " + SCXmlUtil.getString(inDoc));
		Element eleInDoc = inDoc.getDocumentElement();
		String strPerformValidation = eleInDoc.getAttribute(KohlsPOCConstant.A_PERFORM_VALIDATION);
		KohlsDataPump datapump = new KohlsDataPump();
		datapump.unpackSqlProfile(env);
		if(KohlsPOCConstant.YES.equalsIgnoreCase(strPerformValidation)){
			return callValidationScript(env, inDoc);
		}
		return SCXmlUtil.createDocument(KohlsPOCConstant.SUCCESS);
	}
	
	public Document callValidationScript(YFSEnvironment env, Document inDoc) throws Exception {
		logger.info("Beginning callValidationScript with inDoc " + SCXmlUtil.getString(inDoc));
		Element eleInDoc = inDoc.getDocumentElement();
		String strTask = eleInDoc.getAttribute(KohlsPOCConstant.A_TASK);
		String strScript = "";
		if(KohlsPOCConstant.A_GRANT_PERMISSION.equalsIgnoreCase(strTask)){
			strScript = GRANT_VALIDATION_SCRIPT;
		}else if(KohlsPOCConstant.A_ITEM_LOOKUP.equalsIgnoreCase(strTask)){
			strScript = ITEM_LOOKUP_VALIDATION_SCRIPT;
		}
		
		Document outDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_RESPONSE);
		
		if(!YFCObject.isVoid(strScript)){
		String strReturnString = executeSQLStatement(env, strScript );
		outDoc.getDocumentElement().setAttribute(KohlsPOCConstant.Value, strReturnString);
		}
		
		return outDoc;
	}
	
	private String executeSQLStatement(YFSEnvironment env, String statement) throws SQLException {
		YCPContext context = (YCPContext) env;
		Connection conn = context.getDBConnection();
		Statement stmt = conn.createStatement();
		logger.info("statement being executed " + statement);
		ResultSet rs = stmt.executeQuery(statement);
		String strReturnString = "";
		String rsValue = "";
		//last() method returns true if cursor is on a valid row, false if there are no rows in rs
		while (rs.next()) {
			rsValue =  rs.getString(KohlsPOCConstant.A_STATUS).trim();
		}
		if (KohlsPOCConstant.SUCCESS.equalsIgnoreCase(rsValue)) {
			logger.info("Validation Successful");
			strReturnString = "Validation Successful";
		}else{
			logger.info("Validation Unsuccessful");
			strReturnString = "Validation Unsuccessful";
		}
		rs.close();
		return strReturnString;
}
}
