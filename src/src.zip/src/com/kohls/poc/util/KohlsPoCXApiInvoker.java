package com.kohls.poc.util;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ibm.sterling.afc.xapiclient.japi.XApi;
import com.ibm.sterling.afc.xapiclient.japi.XApiClientFactory;
import com.ibm.sterling.afc.xapiclient.japi.XApiEnvironment;
import com.ibm.sterling.afc.xapiclient.japi.XApiException;
//import com.kohls.common.util.XMLUtil;
//import com.kohls.poc.batch.rebate.util.XMLUtils;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;

/**
 * This class is the interface to invoke Sterling APIs.
 */
public class KohlsPoCXApiInvoker {


	private static final YFCLogCategory 
	loggerForInvoker = YFCLogCategory
	.instance(KohlsPoCXApiInvoker.class.getName());

	/**
	 * This is the Sterling api interface
	 */
	private static XApi Xapi;

	/**
	 * The app user id
	 */
	private String userId ;

	/**
	 * The app program id
	 */
	private String progId ;

	/**
	 * The password token
	 */
	private String password ;

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the progId
	 */
	public String getProgId() {
		return progId;
	}

	/**
	 * @param progId
	 *            the progId to set
	 */
	public void setProgId(String progId) {
		this.progId = progId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * This is the environment that is needed to invoke any Sterling APIS.
	 */
	private static XApiEnvironment env;

	/**
	 * This is the session id for logging in and out with Sterling
	 */
	private static String sessionId;

	/**
	 * OMS server
	 */
	private String server;

	/**
	 * smcfs port
	 */
	private String port;


	/**
	 * @return the server
	 */
	public String getServer() {
		return server;
	}

	/**
	 * @param server the server to set
	 */
	public void setServer(String server) {
		this.server = server;
	}

	/**
	 * @return the port
	 */
	public String getPort() {
		return port;
	}

	/**
	 * @param port the port to set
	 */
	public void setPort(String port) {
		this.port = port;
	}

	/**
	 * This function initializes the api handle and the environment handle and
	 * login the user
	 * @param strKeystorepass 
	 * @param strKeystorepath 
	 * @param strPass 
	 * @param strUserID 
	 * @param strTrnModeUrl 
	 * 
	 * @exception Exception
	 *                if an error occurs
	 */
	public void initialize(String strKeystorepath, String strKeystorepass, String strUserID, String strTrnModeUrl) throws Exception {



		try{

			Map<String, String> props = new HashMap<String, String>();
			//String apiUrl = "https://retail-oms-test-f.tst.kohls.com/smcfs/interop/AuthorizationOnlyApiServlet";
			loggerForInvoker.debug("Sterling API URL: " + strTrnModeUrl);
			props.put("yif.httpapi.url", strTrnModeUrl);
			props.put("yif.httpapi.userid", strUserID);
			//props.put("yif.httpapi.password", strPass);
			//props.put("yif.httpapi.disableTrustStore", "true");
			props.put("yif.httpapi.urlStreamHandler", "sun.net.www.protocol.https.Handler");
			props.put("yif.apifactory.protocol", "HTTPS");
			props.put("yif.httpapi.disableKeyStore", "false");
			props.put("javax.net.ssl.keyStore", strKeystorepath);
			props.put("javax.net.ssl.keyStorePassword", strKeystorepass);
			props.put("javax.net.ssl.keyStoreType", "jks");
			loggerForInvoker.debug("The props value are populated and instance is being created");		
			Xapi = XApiClientFactory.getInstance().getApi("HTTPS", props);
			loggerForInvoker.debug("The Xapi is initialized");
			Map<String, String> appInfo = new HashMap<String, String>();

			appInfo.put("userId", strUserID);
			appInfo.put("progId", KohlsPOCConstant.STR_ENV_PROGID_VALUE);
			Document environmentDoc = XMLUtil.createDocument("YFSEnvironment",
					appInfo);
			env = Xapi.createEnvironment(environmentDoc);
			loggerForInvoker.debug("The initialization is successfull");
			
		}
		catch(Exception e){
			loggerForInvoker.debug(e.getMessage());
			loggerForInvoker.debug(e.getStackTrace());
			throw e;
		}
	}

	/**
	 * Logout the user and end the session
	 * 
	 * @throws Exception
	 */
	public void shutdown() throws Exception {
		loggerForInvoker.beginTimer("XApiInvoker.shutdown");
		Map<String, String> logoutInfo = new HashMap<String, String>();
		logoutInfo.put("UserId", env.getUserId());
		logoutInfo.put("SessionId", sessionId);
		Document logoutDoc = XMLUtil.createDocument("registerLogout",
				logoutInfo);
		// Using api.invoke to call registerLogout api
		Xapi.invoke(env, "registerLogout", logoutDoc);
		Xapi.releaseEnvironment(env);
		loggerForInvoker.endTimer("XApiInvoker.shutdown");
	}

	/**
	 * Invoke Sterling multiApi using the XML document.
	 * 
	 * @param xmlDoc
	 *            the api embedded xml document.
	 * @return the result document
	 * @throws Exception 
	 * @throws XApiException
	 */
	public Document invoke(Element sAPIInput,String apiName) throws Exception {
		loggerForInvoker.beginTimer("XApiInvoker.invoke");
		loggerForInvoker.debug("Input Xml to XApiInvoker.invoke method is: "+XMLUtil.getElementXMLString(sAPIInput));
		Document resultDoc = null;
		try{
			loggerForInvoker.debug("Invoking::::");
			resultDoc = Xapi.invoke(env, apiName, XMLUtil.getDocumentForElement(sAPIInput));	
			loggerForInvoker.debug("Invoking:::: Output" +XMLUtil.getXMLString(resultDoc));
		}catch(Exception e){
			loggerForInvoker.debug("XApiInvoker.invoke - Erroring");		
			loggerForInvoker.debug(e.getMessage());
			loggerForInvoker.debug(e.getStackTrace());
			loggerForInvoker.endTimer("XApiInvoker.invoke");
			throw e;
		}
		loggerForInvoker.endTimer("XApiInvoker.invoke");
		return resultDoc;
	}
}
