package com.kohls.poc.util;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author
 *
 */
public class KohlsPoCXMLTransformer {

	private static YFCLogCategory logger;
	private Properties props;

	static {
		logger = YFCLogCategory.instance(KohlsPoCXMLTransformer.class.getName());
	}

	/**
	 * @param resElement
	 * @return
	 * @throws Exception
	 */
	private Document pluResponseTransformation(Element resElement) throws Exception {
		logger.beginTimer("KohlsPoCXMLTransformer.pluResponseTransformation");
		//Adding logger.isDebugEnabled() validation for defect 4052

		resElement = validateErrorInResponse(resElement);

		if(KohlsPOCConstant.ZERO_INT == XMLUtil.getElementsCountByTagName(resElement, KohlsPOCConstant.E_ERRORS)) {
			 List<String> elementNameList = new ArrayList<String>();
			 elementNameList.add(KohlsPOCConstant.E_PARAMETERS);
			 elementNameList.add(KohlsPOCConstant.E_RECORD);
			 elementNameList.add(KohlsPOCConstant.E_XST_OFR);
			 elementNameList.add(KohlsPOCConstant.E_XST_OFR_SECT);
			 //elementNameList.add(KohlsPOCConstant.E_XST_OFR_BWP);
			 xmlStructureTransformation(resElement, elementNameList,KohlsPOCConstant.CONST_RES);
		}
		logger.endTimer("KohlsPoCXMLTransformer.pluResponseTransformation");

		return XMLUtil.getDocumentForElement(resElement);

	}

	/**
	 * @param resElement
	 * @return
	 * @throws ParserConfigurationException
	 */
	private Element validateErrorInResponse(Element resElement) throws ParserConfigurationException {

		logger.beginTimer("KohlsPoCXMLTransformer.validateErrorInResponse");


		   List<Element> detailEleList =  XMLUtil.getElementsByTagName(resElement, KohlsPOCConstant.E_DETAIL);

			Element errorsEle = XMLUtil.createDocument(KohlsPOCConstant.E_ERRORS).getDocumentElement();

			if(!YFCCommon.isVoid(detailEleList) && detailEleList.size() > KohlsPOCConstant.ZERO_INT){
				for (Element detailEle : detailEleList) {
					Element errorEle = XMLUtil.createChild(errorsEle,KohlsPOCConstant.E_ERROR);
					Element detailsEle = (Element) XMLUtil.getElementsByTagName(detailEle, KohlsPOCConstant.E_CODE).get(KohlsPOCConstant.ZERO_INT);
					Element messageEle = (Element) XMLUtil.getElementsByTagName(detailEle, KohlsPOCConstant.E_MESSAGE).get(KohlsPOCConstant.ZERO_INT);
					XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_CODE ,detailsEle.getTextContent() );
					XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_DESCRIPTION ,messageEle.getTextContent() );

				}

				return errorsEle;
			}

			logger.endTimer("KohlsPoCXMLTransformer.validateErrorInResponse");

			return resElement;
	}




	/**
	 * @param reqElement
	 * @return
	 * @throws Exception
	 */
	private Document  pluRequestTransformation(Element reqElement) throws Exception {
		logger.beginTimer("KohlsPoCXMLTransformer.pluRequestTransformation");
		if(logger.isDebugEnabled()){
			logger.debug(XMLUtil.getElementXMLString(reqElement));
		}
		Document pluLookupDoc = XMLUtil.createDocument(KohlsPOCConstant.REQ_TEM_PLULOOKUP);
		XMLUtil.setAttribute(pluLookupDoc.getDocumentElement(), KohlsPOCConstant.REQ_XMLNS_TEM, KohlsPOCConstant.REQ_NAMESPACE_PLUAPE);

		Element xmlInEle = XMLUtil.createChild(pluLookupDoc.getDocumentElement(), KohlsPOCConstant.REQ_TEM_XMLIN);

		XMLUtil.importElement(xmlInEle,reqElement);

		 List<String> elementNameList = new ArrayList<String>();
		 elementNameList.add(KohlsPOCConstant.E_PARAMETERS);

		 xmlStructureTransformation(pluLookupDoc.getDocumentElement(), elementNameList,KohlsPOCConstant.CONST_REQ);

		 logger.endTimer("KohlsPoCXMLTransformer.pluRequestTransformation");

		 return XMLUtil.getDocumentForElement(pluLookupDoc.getDocumentElement());
	}



	/**
	 * @param resElement
	 * @return
	 * @throws Exception
	 */
	private Document  apeResponseTransformation(Element resElement) throws Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.apeResponseTransformation");


		 resElement = validateErrorInResponse(resElement);

		if(KohlsPOCConstant.ZERO_INT == XMLUtil.getElementsCountByTagName(resElement, KohlsPOCConstant.E_ERROR)) {
			 List<String> elementNameList = new ArrayList<String>();
			 elementNameList.add(KohlsPOCConstant.E_ITEM);
			 elementNameList.add(KohlsPOCConstant.E_MODIFIER);
			 elementNameList.add(KohlsPOCConstant.E_TLD);
			 xmlStructureTransformation(resElement, elementNameList, KohlsPOCConstant.CONST_RES);
		 }

		logger.endTimer("KohlsPoCXMLTransformer.apeResponseTransformation");

		return XMLUtil.getDocumentForElement(resElement);
	}




	/**
	 * @param reqElement
	 * @return
	 * @throws Exception
	 */
	private Document apeRequestTransformation(Element reqElement) throws Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.apeRequestTransformation");


		//<tem:CalculateBasket xmlns:tem="http://tempuri.org/">
	   // <tem:xmlIn>

		Document apeRequestDoc = XMLUtil.createDocument(KohlsPOCConstant.REQ_TEM_CALCULATEBASKET);
		XMLUtil.setAttribute(apeRequestDoc.getDocumentElement(), KohlsPOCConstant.REQ_XMLNS_TEM, KohlsPOCConstant.REQ_NAMESPACE_PLUAPE);

		Element xmlInEle = XMLUtil.createChild(apeRequestDoc.getDocumentElement(), KohlsPOCConstant.REQ_TEM_XMLIN);

		XMLUtil.importElement(xmlInEle,reqElement);

		 List<String> elementNameList = new ArrayList<String>();
		 // Added <Promo/> element to the list for transforming  
		 elementNameList.add(KohlsPOCConstant.E_PROMO);
		 elementNameList.add(KohlsPOCConstant.E_PRICING);
		 elementNameList.add(KohlsPOCConstant.E_OFFER);
		 elementNameList.add(KohlsPOCConstant.E_CRITERIA);
		 elementNameList.add(KohlsPOCConstant.E_MERCHANDISE_SET);
		 elementNameList.add(KohlsPOCConstant.E_MANUAL_TLD);
		 elementNameList.add(KohlsPOCConstant.E_MANUAL_LID);


		 //For Exclusions Starts
		 List<Element> exclusionsEleList =  XMLUtil.getElementsByTagName(apeRequestDoc.getDocumentElement(), KohlsPOCConstant.E_EXCLUSIONS);
		 /*for (Element exclusionEle : exclusionsEleList) {
			 List<Element> elementList =  XMLUtil.getElementsByTagName(exclusionEle, KohlsPOCConstant.E_DEPARTMENTS);
	 		 convertAttrToEleForExclusions(elementList);
		 }*/
		 //For Exclusions End
		 
		// Suresh : Added for Sprint 5 exclusions : Start
		 //Manoj 09/30/2015: Commented for performance tuning
		/* for (Element exclusionEle : exclusionsEleList) {
			 List<Element> elementList =  XMLUtil.getElementsByTagName(exclusionEle, KohlsPOCConstant.E_EXCLUSION_TAG);
	 		 convertAttrToEleForExclusions(elementList);
		 }
		 */

		 // Suresh : Added for Sprint 5 exclusions : Start

		 //For ManualTLD Starts
		 List<Element> manualTLDEleList =  XMLUtil.getElementsByTagName(apeRequestDoc.getDocumentElement(), KohlsPOCConstant.E_MANUAL_TLD);
		 for (Element manualTLDEle : manualTLDEleList) {
			String legacyFlag = XMLUtil.getAttribute(manualTLDEle, KohlsPOCConstant.A_LEGACY_FLAG);
			 String ieIndicator = XMLUtil.getAttribute(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR);

			 		List<Element> elementList =  XMLUtil.getElementsByTagName(manualTLDEle, KohlsPOCConstant.E_DEPARTMENTS);

				  if(!YFCCommon.isStringVoid(legacyFlag) && !"None".equals(ieIndicator)){
					 Element DepartmentsEle =  XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.E_DEPARTMENTS);
			 		 convertAttrToEleForManualTLD(elementList,DepartmentsEle,Boolean.TRUE);
				   }else{
					   convertAttrToEleForManualTLD(elementList,null,Boolean.FALSE);
				   }

		 }
//		For ManualTLD End


		 xmlStructureTransformation(apeRequestDoc.getDocumentElement(), elementNameList,KohlsPOCConstant.CONST_REQ);

		 logger.endTimer("KohlsPoCXMLTransformer.apeRequestTransformation");


		 return XMLUtil.getDocumentForElement(apeRequestDoc.getDocumentElement());
	}




	/**
	 * @param elementList
	 * @param departmentsEle
	 * @param deptCreation
	 */
	private void convertAttrToEleForManualTLD(List<Element> elementList, Element departmentsEle, boolean deptCreation) {
		logger.beginTimer("KohlsPoCXMLTransformer.convertAttrToEleForManualTLD");


		for (Element ele : elementList) {
			 if(deptCreation){
				NamedNodeMap  nodeMap  = ele.getAttributes();
				for (int j = KohlsPOCConstant.ZERO_INT; j < nodeMap.getLength(); j++) {
			        Element newEle = XMLUtil.createChild(departmentsEle, nodeMap.item(j).getNodeName());
			        XMLUtil.setNodeValue(newEle, nodeMap.item(j).getNodeValue());
			        nodeMap.removeNamedItem(nodeMap.item(j).getNodeName());
			        j--;
			    }
			 }
			XMLUtil.removeChild((Element)ele.getParentNode(), ele);
		}
		logger.endTimer("KohlsPoCXMLTransformer.convertAttrToEleForManualTLD");

	}




	/**
	 * @param reqElement
	 * @param elementNameList
	 * @param type
	 */
	private void xmlStructureTransformation(Element reqElement, List<String> elementNameList,String type) {
		logger.beginTimer("KohlsPoCXMLTransformer.xmlStructureTransformation");

		for (String elementName : elementNameList) {
				 List<Element> elementList =  XMLUtil.getElementsByTagName(reqElement, elementName);
				 if(KohlsPOCConstant.CONST_REQ.equalsIgnoreCase(type)){
					 convertAttributeToElemnt(elementList);
				 }else if(KohlsPOCConstant.CONST_RES.equalsIgnoreCase(type)){
					 convertElemntToAttribute(elementList);
				 }
			}

		logger.endTimer("KohlsPoCXMLTransformer.xmlStructureTransformation");


	}


	/**
	 * @param eleList
	 */
	private void convertAttributeToElemnt(List<Element> eleList) {
		logger.beginTimer("KohlsPoCXMLTransformer.convertAttributeToElemnt");

		for (Element ele : eleList) {
			NamedNodeMap  nodeMap  = ele.getAttributes();
			for (int j = KohlsPOCConstant.ZERO_INT; j < nodeMap.getLength(); j++) {
		        Element newEle = XMLUtil.createChild(ele, nodeMap.item(j).getNodeName());
		        XMLUtil.setNodeValue(newEle, nodeMap.item(j).getNodeValue());
		        nodeMap.removeNamedItem(nodeMap.item(j).getNodeName());
		        j--;
		    }
		}
		logger.endTimer("KohlsPoCXMLTransformer.convertAttributeToElemnt");


	}


	/**
	 * @param eleList
	 */
	private void convertAttrToEleForExclusions(List<Element> eleList) {
		logger.beginTimer("KohlsPoCXMLTransformer.convertAttrToEleForExclusions");

		for (Element ele : eleList) {
			NamedNodeMap  nodeMap  = ele.getAttributes();
			for (int j = KohlsPOCConstant.ZERO_INT; j < nodeMap.getLength(); j++) {
		        Element newEle = XMLUtil.createChild((Element)ele.getParentNode(), nodeMap.item(j).getNodeName());
		        XMLUtil.setNodeValue(newEle, nodeMap.item(j).getNodeValue());
		        nodeMap.removeNamedItem(nodeMap.item(j).getNodeName());
		        j--;
		    }
			XMLUtil.removeChild((Element)ele.getParentNode(), ele);

		}
		logger.endTimer("KohlsPoCXMLTransformer.convertAttrToEleForExclusions");


	}

	/**
	 * @param eleList
	 */
	private  void convertElemntToAttribute(List<Element> eleList) {
		logger.beginTimer("KohlsPoCXMLTransformer.convertElemntToAttribute");

		for (Element ele : eleList) {
			Iterator ite = XMLUtil.getChildren(ele);
			while(ite.hasNext()) {
			      Element existEle = (Element)ite.next();
			      //if(!existEle.getNodeName().equalsIgnoreCase("lineTax") && !existEle.getNodeName().equalsIgnoreCase(KohlsPOCConstant.E_MODIFIER_LIST))
			    //checking the fee Value
			      //Added Rebates for R3 Sprint3 changes
			      if(!existEle.getNodeName().equalsIgnoreCase(KohlsPOCConstant.SMALL_ATTR_FEES) && !existEle.getNodeName().equalsIgnoreCase(KohlsPOCConstant.ELEM_LINE_TAX) && !existEle.getNodeName().equalsIgnoreCase(KohlsPOCConstant.E_MODIFIER_LIST) && !existEle.getNodeName().equalsIgnoreCase(KohlsPOCConstant.ELEM_REBATES))
			     {
				      XMLUtil.setAttribute(ele, existEle.getNodeName(), existEle.getTextContent());
				      XMLUtil.removeChild(ele, existEle);
			     }
			  }
		}
		logger.endTimer("KohlsPoCXMLTransformer.convertElemntToAttribute");

	}


	/**
	 * @param yfsEnv
	 * @param pluRequestDocument
	 * @return
	 * @throws Exception
	 */
	public  Document translatePluRequest(YFSEnvironment yfsEnv, Document pluRequestDocument) throws Exception{
		logger.beginTimer("KohlsPoCXMLTransformer.translatePluRequest");
		pluRequestDocument = pluRequestTransformation(pluRequestDocument.getDocumentElement());
		logger.endTimer("KohlsPoCXMLTransformer.translatePluRequest");
		return pluRequestDocument;

	}

	/**
	 * @param yfsEnv
	 * @param pluResponseDocument
	 * @return
	 * @throws Exception
	 */
	public  Document translatePluResponse(YFSEnvironment yfsEnv, Document pluResponseDocument) throws Exception{
		logger.beginTimer("KohlsPoCXMLTransformer.translatePluResponse");
		pluResponseDocument = pluResponseTransformation(pluResponseDocument.getDocumentElement());
		logger.endTimer("KohlsPoCXMLTransformer.translatePluResponse");
		return pluResponseDocument;
	}

	/**
	 * @param yfsEnv
	 * @param apeRequestDocument
	 * @return
	 * @throws Exception
	 */
	public Document translateApeRequest(YFSEnvironment yfsEnv, Document apeRequestDocument) throws Exception{
		logger.beginTimer("KohlsPoCXMLTransformer.translateApeRequest");
		apeRequestDocument = apeRequestTransformation(apeRequestDocument.getDocumentElement());
		logger.endTimer("KohlsPoCXMLTransformer.translateApeRequest");
		return apeRequestDocument;
	}

	/**
	 * @param yfsEnv
	 * @param apeResponseDocument
	 * @return
	 * @throws Exception
	 */
	public Document translateApeResponse(YFSEnvironment yfsEnv, Document apeResponseDocument) throws Exception{
		logger.beginTimer("KohlsPoCXMLTransformer.translateApeResponse");
		apeResponseDocument = apeResponseTransformation(apeResponseDocument.getDocumentElement());
		logger.endTimer("KohlsPoCXMLTransformer.translateApeResponse");
		return apeResponseDocument;
	}


	/**
	 * @param inputDoc
	 * @return
	 * @throws Exception
	 */
	public  Document translateTaxwareRequest(Document inputDoc) throws Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.translateTaxwareRequest");

		Document taxwareReqDoc = XMLUtil.createDocument(KohlsPOCConstant.GET_TAX_CALCULATION);
		//XMLUtil.setAttribute(taxwareReqDoc.getDocumentElement(), "xmlns:tax", "http://NextGenPOS.kohls.com/TaxServiceRequest/");

		XMLUtil.importElement(taxwareReqDoc.getDocumentElement(), inputDoc.getDocumentElement());

		changeTagName(taxwareReqDoc);

		logger.endTimer("KohlsPoCXMLTransformer.translateTaxwareRequest");

		return taxwareReqDoc;
	}

	/**
	 * @param taxwareReqDoc
	 */
	public  void changeTagName(Document taxwareReqDoc) {

		logger.beginTimer("KohlsPoCXMLTransformer.changeTagName");

		NodeList nodes = taxwareReqDoc.getElementsByTagName("*");
		for (int i = 0; i < nodes.getLength(); i++) {
			if (nodes.item(i) instanceof Element) {
				Element elem = (Element) nodes.item(i);
				taxwareReqDoc.renameNode(elem, KohlsPOCConstant.TAXWARE_NAMESPACE, KohlsPOCConstant.TAXWARE_REQ_PREFIX + elem.getNodeName());
			}
		}

		logger.endTimer("KohlsPoCXMLTransformer.changeTagName");

	}

	/**
	 * @param taxwareResponseDoc
	 * @return
	 * @throws Exception
	 */
	public  Document translateTaxwareResponse(Document taxwareResponseDoc) throws Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.translateTaxwareResponse");

		Element resElement = validateErrorInResponse(taxwareResponseDoc.getDocumentElement());

		if (KohlsPOCConstant.ZERO_INT == XMLUtil.getElementsCountByTagName(resElement, KohlsPOCConstant.E_ERROR)) {
			NodeList nodeList = taxwareResponseDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);

			Node orderNode = nodeList.item(0);

			Document taxwareResDoc = XMLUtil.newDocument();
			Node importedNode = taxwareResDoc.importNode(orderNode, true);
			taxwareResDoc.appendChild(importedNode);

			logger.endTimer("KohlsPoCXMLTransformer.translateTaxwareResponse");

			return taxwareResDoc;
		}

		logger.endTimer("KohlsPoCXMLTransformer.translateTaxwareResponse");
		return XMLUtil.getDocumentForElement(resElement);
	}



	/** This method translates the element format of TVS response to XML attribute format
	 * @param responseDoc
	 * @return Document
	 * @throws Exception
	 */
	
	public Document  translateTVSResponse(YFSEnvironment yfsEnv, Document responseDoc) throws Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.translateTVSResponse");
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPoCXMLTransformer.translateTVSResponse  : Response from TVS to be translated \n"+ XMLUtil.getXMLString(responseDoc));
		}
		String sPOCFeature= (String)yfsEnv.getTxnObject("ExtnPOCFeature");
		
		
/*//		Started changes for store mapping configuration
				Element eleTrans = (Element)(XPathUtil.getNode(responseDoc.getDocumentElement(), "//priceResponse/transaction"));
				Element eleShipNode = XMLUtil.getUniqueSubNode(eleTrans, KohlsPOCConstant.STORE_NUM);
				String strShipNodeValue = eleShipNode.getTextContent();
				if(!YFCCommon.isVoid(strShipNodeValue)) {
				int iStoreID = Integer.parseInt(strShipNodeValue);

				if (iStoreID < Integer.parseInt(KohlsPOCConstant.STORE_ID_CHECK) && !strShipNodeValue.equalsIgnoreCase(KohlsPOCConstant.ZERO)) {
					logger.debug("KohlsPoCXMLTransformer.tvsRequestTransformation : Store mapping required");
					strShipNodeValue = props.getProperty(strShipNodeValue);
					if(!YFCCommon.isStringVoid(strShipNodeValue))
					{
						XMLUtil.setNodeValue(eleShipNode, strShipNodeValue);
					}
				} 
		
			}*/
		
	    //Element elePriceRes = (Element)(XPathUtil.getNode(responseDoc.getDocumentElement(), "//priceResponse"));
		//Fix for defect 4073 - Start
		Element elePriceRes = responseDoc.getDocumentElement();
		//Fix for defect 4073 - End
		Element transactionEle = XMLUtil.getChildElement(elePriceRes, "transaction"); 
		Element storeNumEle = XMLUtil.getChildElement(transactionEle, "storeNum");
		transactionEle.setAttribute("storeNum", storeNumEle.getTextContent());
		transactionEle.removeChild(storeNumEle); 

		Element transIdEle = XMLUtil.getChildElement(transactionEle, "transactionId");
		if(!YFCCommon.isVoid(transIdEle))
		{
			transactionEle.setAttribute("transactionId", transIdEle.getTextContent());
			transactionEle.removeChild(transIdEle);
		}
		//Price for Prompt for Price logic in PA
		if (!YFCCommon.isVoid(sPOCFeature) && sPOCFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)){
			Element eleErrors = validateTVSErrorInResponse(elePriceRes);
			List eleErrorList = XMLUtil.getElementsByTagName(eleErrors, "Error");
			int iCount=0;// bPricePrompt;
			for(int i=0;i<eleErrorList.size();i++){
				
				Element eleError = (Element)eleErrorList.get(i);
				//Element eleCode= (Element)eleError.getElementsByTagName("ErrorCode").item(0);
				if(eleError.getAttribute("ErrorCode").equalsIgnoreCase("PROMPT_FOR_PRICE")
						|| eleError.getAttribute("ErrorCode").equalsIgnoreCase("PLUPRICEREQ")){ 
					++iCount;
				}
			}
			
			// check for for PROMPT_FOR_PRICE errors, if there are others continue processing as before
			//if there are no errors, proceed as before
			if(iCount!=eleErrorList.size()||iCount==0)
			{
				transactionEle = eleErrors;
			}else if(!YFCCommon.isVoid(eleErrorList) && eleErrorList.size() >0){
				transactionEle.appendChild(transactionEle.getOwnerDocument().importNode(eleErrors,false));
			}
		}else{
			transactionEle = validateTVSErrorInResponse(elePriceRes);
		}
			
		//Price for Prompt for Price logic in PA
		if(KohlsPOCConstant.ZERO_INT == XMLUtil.getElementsCountByTagName(transactionEle, KohlsPOCConstant.E_ERROR)){
			 List<String> elementNameList = new ArrayList<String>();
			 elementNameList.add(KohlsPOCConstant.ELEM_SMALL_ITEM);
			 elementNameList.add(KohlsPOCConstant.ELEM_MODIFIER);
			 elementNameList.add(KohlsPOCConstant.ELEM_PROMO);
			 elementNameList.add(KohlsPOCConstant.ELEM_OFFER);
			 elementNameList.add("tld");
			 //Changes for R3 Sprint3 - Start
			 elementNameList.add("rebate");
			 //Changes for R3 Sprint3 - End
			 //	Vineeta: TVS Phase 2 Changes - Taxware : Added lineTax element to the list
			// elementNameList.add(KohlsPOCConstant.SMALL_ELEM_LINE_TAX);
			 elementNameList.add(KohlsPOCConstant.ELEM_LINE_TAX);
			//Adding fee element to the list
			 elementNameList.add(KohlsPOCConstant.SMALL_ATTR_FEES);			 
			 xmlStructureTransformation(transactionEle, elementNameList, KohlsPOCConstant.CONST_RES);
		 }
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPoCXMLTransformer.translateTVSResponse End: Document returned \n"+XMLUtil.getDocumentForElement(transactionEle));
		}
		//Vineeta: TVS Phase 2 Changes - Taxware : Start
		 
		  //Fix for defect 4073 - Start
		 //NodeList nlItem = ((NodeList)XPathUtil.getNodeList(transactionEle, "//priceResponse/transaction/itemList/item"));
		//PRF-470 : Moved the code to PrepareUeResponse - start
		/* NodeList nlItem = transactionEle.getElementsByTagName("item");
		 //Fix for defect 4073 - End
		 if(!YFCCommon.isVoid(nlItem))
		 {
			 for(int i=0; i<nlItem.getLength();i++)
			 {
				 Element eleItem = (Element)nlItem.item(i);
				 //Element elelineTaxes = XMLUtil.createChild(eleItem, KohlsPOCConstant.SMALL_ELEM_LINE_TAXES);
				 //Changes for consolidating LineTaxes - Performance - Start
				 Element elelineTaxes = XMLUtil.createChild(eleItem, KohlsPOCConstant.ELEM_LINE_TAXES);
					// NodeList nlTax = (NodeList)XPathUtil.getNodeList(eleItem, KohlsPOCConstant.SMALL_ELEM_LINE_TAX);
					//Fix for defect 4073 - Start
					// NodeList nlTax = (NodeList)XPathUtil.getNodeList(eleItem, KohlsPOCConstant.ELEM_LINE_TAX);
					 List<Element> nlTax = XMLUtil.getElementsByTagName(eleItem, (KohlsPOCConstant.ELEM_LINE_TAX));
					 //eleItem.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
					//Fix for defect 4073 - End
					 double totalTaxPerLine = KohlsPOCConstant.ZERO_DBL;
					 double totalTaxRatePerLine = KohlsPOCConstant.ZERO_DBL;
					 if(!YFCCommon.isVoid(nlTax))
					 {
					//for(int j = 0; j < nlTax.getLength(); j++)
					 for(Element eleTax : nlTax)
					 {
						 //Element eleTax=(Element)nlTax.item(j);
						 String sTax = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.SMALL_TAX);
						 String sTaxPercent = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT);
						 //logger.debug("sTax and sTaxPercent values before: "+sTax +"and" +sTaxPercent);
						 if(YFCCommon.isVoid(sTax)){
							sTax = "0.0";
						 }
						 if(YFCCommon.isVoid(sTaxPercent)){
							 sTaxPercent = "0.0";
						 }
						 //logger.debug("sTax and sTaxPercent values after: "+sTax +"and" +sTaxPercent);
						 totalTaxPerLine = totalTaxPerLine + Double.valueOf(sTax);
						 totalTaxRatePerLine = totalTaxRatePerLine + Double.valueOf(sTaxPercent);
						 //logger.debug("The eleItem before removing child tax lines : " + XMLUtil.getElementXMLString(eleItem));
						 eleItem.removeChild(eleTax);
						 //logger.debug("The eleItem After removing child tax lines : " + XMLUtil.getElementXMLString(eleItem));
					 }
					 totalTaxPerLine = Math.round(totalTaxPerLine*1000.0)/1000.0;
					 totalTaxRatePerLine = Math.round(totalTaxRatePerLine*1000.0)/1000.0;
					 logger.debug("After Math   totalTaxPerLine "+totalTaxPerLine);
					 logger.debug("After Math totalTaxRatePerLine "+totalTaxRatePerLine);
					 DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					 twoDForm.setRoundingMode(RoundingMode.CEILING);
					 Element eleTaxNew = XMLUtil.createChild(elelineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
					 XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX, twoDForm.format(totalTaxPerLine));
					 XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, totalTaxRatePerLine+"");
					 logger.debug("After rounding   totalTaxPerLine "+twoDForm.format(totalTaxPerLine));
					 logger.debug("After rounding   totalTaxRatePerLine "+totalTaxRatePerLine);
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX, twoDForm.format(totalTaxPerLine));
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, String.valueOf(totalTaxRatePerLine));
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
					 }
				 }		 
				//Changes for consolidating LineTaxes - Performance - End	
			 }*/
		//PRF-470 : Moved the code to PrepareUeResponse - end
		 //	Vineeta: TVS Phase 2 Changes - Taxware : End
		logger.endTimer("KohlsPoCXMLTransformer.translateTVSResponse");
		return XMLUtil.getDocumentForElement(transactionEle);
	}


	/**
	 * 
	 * @param responseDoc
	 * @return
	 * @throws Exception
	 */
	public Document  translatePSATVSResponse(Document responseDoc) throws Exception {

      logger.beginTimer("KohlsPoCXMLTransformer.translatePSATVSResponse");
      if(logger.isDebugEnabled()){
    	  logger.debug("KohlsPoCXMLTransformer.translatePSATVSResponse  : Response from TVS to be translated \n"+ XMLUtil.getXMLString(responseDoc));    
      }
      Element elePriceRes = (Element)(XPathUtil.getNode(responseDoc.getDocumentElement(), "//adjustmentResponse"));
      Element transactionEle = XMLUtil.getChildElement(elePriceRes, "transaction"); 
      Element storeNumEle = XMLUtil.getChildElement(transactionEle, "storeNum");
	  //Added void check for store element 04/13/2016
	  if(!YFCCommon.isVoid(storeNumEle))
	  {
		transactionEle.setAttribute("storeNum", storeNumEle.getTextContent());
		transactionEle.removeChild(storeNumEle);
	  }	  

      Element transIdEle = XMLUtil.getChildElement(transactionEle, "transactionId");
      if(!YFCCommon.isVoid(transIdEle))
      {
         transactionEle.setAttribute("transactionId", transIdEle.getTextContent());
         transactionEle.removeChild(transIdEle);
      }
      
      transactionEle = validatePSATVSErrorInResponse(elePriceRes); 

      if(KohlsPOCConstant.ZERO_INT == XMLUtil.getElementsCountByTagName(transactionEle, KohlsPOCConstant.E_ERROR)) {
          List<String> elementNameList = new ArrayList<String>();
          elementNameList.add(KohlsPOCConstant.ELEM_SMALL_ITEM);
          elementNameList.add(KohlsPOCConstant.ELEM_MODIFIER);
          elementNameList.add(KohlsPOCConstant.ELEM_PROMO);
          elementNameList.add(KohlsPOCConstant.ELEM_OFFER);
          elementNameList.add("tld");
          //   Vineeta: TVS Phase 2 Changes - Taxware : Added lineTax element to the list
         // elementNameList.add(KohlsPOCConstant.SMALL_ELEM_LINE_TAX);
          elementNameList.add(KohlsPOCConstant.ELEM_LINE_TAX);
	//Adding fee element to the list
			 elementNameList.add(KohlsPOCConstant.SMALL_ATTR_FEES);	
          
          xmlStructureTransformation(transactionEle, elementNameList, KohlsPOCConstant.CONST_RES);
       }
      if(logger.isDebugEnabled()){
    	  logger.debug("KohlsPoCXMLTransformer.translatePSATVSResponse End: Document returned \n"+XMLUtil.getDocumentForElement(transactionEle));
      }
      //Vineeta: TVS Phase 2 Changes - Taxware : Start
       
       NodeList nlItem = ((NodeList)XPathUtil.getNodeList(transactionEle, "//adjustmentResponse/transaction/itemList/item"));
       if(!YFCCommon.isVoid(nlItem))
       {
          for(int i=0; i<nlItem.getLength();i++)
          {
        	  	//Fix for defect 4158 - Start
				 Element eleItem = (Element)nlItem.item(i);
				 //Element elelineTaxes = XMLUtil.createChild(eleItem, KohlsPOCConstant.SMALL_ELEM_LINE_TAXES);
				 //Changes for consolidating LineTaxes - Performance - Start
				 Element elelineTaxes = XMLUtil.createChild(eleItem, KohlsPOCConstant.ELEM_LINE_TAXES);
					// NodeList nlTax = (NodeList)XPathUtil.getNodeList(eleItem, KohlsPOCConstant.SMALL_ELEM_LINE_TAX);
					//Fix for defect 4073 - Start
					// NodeList nlTax = (NodeList)XPathUtil.getNodeList(eleItem, KohlsPOCConstant.ELEM_LINE_TAX);
					 List<Element> nlTax = XMLUtil.getElementsByTagName(eleItem, (KohlsPOCConstant.ELEM_LINE_TAX));
					 //eleItem.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
					//Fix for defect 4073 - End
					 double totalTaxPerLine = KohlsPOCConstant.ZERO_DBL;
					 double totalTaxRatePerLine = KohlsPOCConstant.ZERO_DBL;
					 double dBasisAmt = KohlsPOCConstant.ZERO_DBL;
					 if(!YFCCommon.isVoid(nlTax))
					 {
					//for(int j = 0; j < nlTax.getLength(); j++)
					 for(Element eleTax : nlTax)
					 {
						 //Element eleTax=(Element)nlTax.item(j);
						 String sTax = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.SMALL_TAX);
						 String sTaxPercent = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT);
						 //logger.debug("sTax and sTaxPercent values before: "+sTax +"and" +sTaxPercent);
						 if(YFCCommon.isVoid(sTax)){
							sTax = "0.0";
						 }
						 if(YFCCommon.isVoid(sTaxPercent)){
							 sTaxPercent = "0.0";
						 }
						 //logger.debug("sTax and sTaxPercent values after: "+sTax +"and" +sTaxPercent);
						 totalTaxPerLine = totalTaxPerLine + Double.valueOf(sTax);
						 totalTaxRatePerLine = totalTaxRatePerLine + Double.valueOf(sTaxPercent);
						 //logger.debug("The eleItem before removing child tax lines : " + XMLUtil.getElementXMLString(eleItem));
						 eleItem.removeChild(eleTax);
						 //logger.debug("The eleItem After removing child tax lines : " + XMLUtil.getElementXMLString(eleItem));
						 String sTaxBasis = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.TAX_BASIS);
						 try {
							 if (!YFCCommon.isVoid(sTaxBasis) && Double.parseDouble(sTaxBasis) > dBasisAmt) {
								 dBasisAmt = Double.parseDouble(sTaxBasis);
							 }
						 }catch (Exception e) {
							 logger.error("Error occured while coputing taxBasis amt. Continuing transaction");
						 }
					 }
					 totalTaxPerLine = Math.round(totalTaxPerLine*1000.0)/1000.0;
					 totalTaxRatePerLine = Math.round(totalTaxRatePerLine*1000.0)/1000.0;
					 logger.debug("After Math   totalTaxPerLine "+totalTaxPerLine);
					 logger.debug("After Math totalTaxRatePerLine "+totalTaxRatePerLine);
					 DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					 twoDForm.setRoundingMode(RoundingMode.CEILING);
					 Element eleTaxNew = XMLUtil.createChild(elelineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
					 XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX, twoDForm.format(totalTaxPerLine));
					 XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, totalTaxRatePerLine+"");
					 logger.debug("After rounding   totalTaxPerLine "+twoDForm.format(totalTaxPerLine));
					 logger.debug("After rounding   totalTaxRatePerLine "+totalTaxRatePerLine);
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX, twoDForm.format(totalTaxPerLine));
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, String.valueOf(totalTaxRatePerLine));
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
					 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
					 if(dBasisAmt > 0) {
						 Element eleTaxExtn = XMLUtil.createChild(eleTaxNew, KohlsPOCConstant.E_EXTN);
						 eleTaxExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, new DecimalFormat("#0.00").format(dBasisAmt));
					 }
					 }
					//Fix for defect 4158 - End
          }
       }
       //   Vineeta: TVS Phase 2 Changes - Taxware : End
      logger.endTimer("KohlsPoCXMLTransformer.translatePSATVSResponse");
      return XMLUtil.getDocumentForElement(transactionEle);
   }
	


	/** This method converts the TVS XML request to element format 
	 * @param reqDoc
	 * @return Document
	 * @throws Exception
	 */

	
	public Document translateTVSRequest(Document reqDoc) throws Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.translateTVSRequest");
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPoCXMLTransformer.translateTVSRequest : Reqest document is \n"+XMLUtil.getXMLString(reqDoc));
		}
		XMLUtil.setAttribute(reqDoc.getDocumentElement(), "xmlns", "http://kohls.com/tvs/poc");
		XMLUtil.setAttribute(reqDoc.getDocumentElement(), "xmlns:ns2", "http://kohls.com/tvs");
		
		//Added for Department transformation for legacy coupons
		List<Element> manualTLDEleList =  XMLUtil.getElementsByTagName(reqDoc.getDocumentElement(), "manualTLD");
		 for (Element manualTLDEle : manualTLDEleList) {
			String legacyFlag = manualTLDEle.getAttribute("legacyFlag");
			String ieIndicator = manualTLDEle.getAttribute("IEIndicator");
			List<Element> elementList =  XMLUtil.getElementsByTagName(manualTLDEle, "departments");
			if(!YFCCommon.isStringVoid(legacyFlag) && !"None".equals(ieIndicator)){
				Element DepartmentsEle =  XMLUtil.createChild(manualTLDEle, "departments");
				convertAttrToEleForManualTLD(elementList,DepartmentsEle,Boolean.TRUE);
			}else{
				convertAttrToEleForManualTLD(elementList,null,Boolean.FALSE);
			}
		 }

		 List<String> elementNameList = new ArrayList<String>();
		 elementNameList.add("transaction");
		 elementNameList.add("storeAddress");
		 elementNameList.add("item");
		 elementNameList.add(KohlsPOCConstant.ELEM_OFFER);
		 elementNameList.add(KohlsPOCConstant.ELEM_MANUAL_TLD);
		 elementNameList.add(KohlsPOCConstant.ELEM_MANUAL_LID);
		 
		 //For Exclusions Starts
		 //List<Element> exclusionsEleList =  XMLUtil.getElementsByTagName(reqDoc.getDocumentElement(), KohlsPOCConstant.ELE_EXCLUSIONS);
		// Suresh : Added for Sprint 5 exclusions : Start
		 
		 /*for (Element exclusionEle : exclusionsEleList) {
			 List<Element> elementList =  XMLUtil.getElementsByTagName(exclusionEle, KohlsPOCConstant.ELE_EXCLUSION_TAG);
	 		 convertAttrToEleForExclusions(elementList);
		 }*/

		 // Suresh : Added for Sprint 5 exclusions : Start
		 //For Exclusions End

		 xmlStructureTransformation(reqDoc.getDocumentElement(), elementNameList,KohlsPOCConstant.CONST_REQ);
		 

			//	Started changes for store mapping configuration
			Element eleTrans = (Element)(XPathUtil.getNode(reqDoc.getDocumentElement(), "//priceRequest/transaction"));
			Element eleShipNode = XMLUtil.getUniqueSubNode(eleTrans, KohlsPOCConstant.STORE_NUM);
			String strShipNodeValue = eleShipNode.getTextContent();
			if(!YFCCommon.isVoid(strShipNodeValue)) {
			int iStoreID = Integer.parseInt(strShipNodeValue);

			if (iStoreID > Integer.parseInt(KohlsPOCConstant.STORE_ID_CHECK)) {
				strShipNodeValue = props.getProperty(strShipNodeValue);
				logger.debug("KohlsPoCXMLTransformer.tvsRequestTransformation : Store mapping required to : "+strShipNodeValue);
				if(!YFCCommon.isStringVoid(strShipNodeValue))
				{
					XMLUtil.setNodeValue(eleShipNode, strShipNodeValue);
				}
			} 
		}	
			
		 Document returnDoc = XMLUtil.getDocumentForElement(reqDoc.getDocumentElement());
		 if(logger.isDebugEnabled()){
			 logger.debug("KohlsPoCXMLTransformer.translateTVSRequest : Document returned \n"+XMLUtil.getXMLString(returnDoc));
		 }
		 logger.endTimer("KohlsPoCXMLTransformer.translateTVSRequest");
		 return returnDoc;
	
	}

	/** This method validate the TVS response and returns Error element if any
	 * @param resElement
	 * @return Element
	 * @throws ParserConfigurationException
	 */
	private Element validateTVSErrorInResponse(Element resElement) throws ParserConfigurationException,Exception {

		logger.beginTimer("KohlsPoCXMLTransformer.validateTVSErrorInResponse");
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPoCXMLTransformer.validateTVSErrorInResponse : input element \n"+ XMLUtil.getElementXMLString(resElement));
		}
		NodeList listItemErrors =  XPathUtil.getNodeList(resElement, "//priceResponse/transaction/itemList/item/errors/error");
		NodeList listTransactionErrors = XPathUtil.getNodeList(resElement, "//priceResponse/transaction/errors/error");
		Element errorsEle = null;
		
			errorsEle = XMLUtil.createDocument(KohlsPOCConstant.E_ERRORS).getDocumentElement();
			
			// Error check at Item level
			
			if(!YFCCommon.isVoid(listItemErrors) && listItemErrors.getLength() > KohlsPOCConstant.ZERO_INT){
				for(int i=0;i<listItemErrors.getLength();i++)
				{
					Element eleItemError = (Element)listItemErrors.item(i);
					Element errorEle = XMLUtil.createChild(errorsEle,KohlsPOCConstant.E_ERROR);
					Element detailsEle = (Element) XMLUtil.getElementsByTagName(eleItemError, KohlsPOCConstant.E_CODE).get(KohlsPOCConstant.ZERO_INT);
					Element messageEle = (Element) XMLUtil.getElementsByTagName(eleItemError, KohlsPOCConstant.E_MESSAGE).get(KohlsPOCConstant.ZERO_INT);
					XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_CODE ,detailsEle.getTextContent() );
					XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_DESCRIPTION ,messageEle.getTextContent() );
					}
				}
				
				//	Error check at transaction level
				if(!YFCCommon.isVoid(listTransactionErrors) && listTransactionErrors.getLength() > KohlsPOCConstant.ZERO_INT){
					for(int i=0;i<listTransactionErrors.getLength();i++)
					{
						Element eleTransError = (Element)listTransactionErrors.item(i);
						Element errorEle = XMLUtil.createChild(errorsEle,KohlsPOCConstant.E_ERROR);
						Element detailsEle = (Element) XMLUtil.getElementsByTagName(eleTransError, KohlsPOCConstant.E_CODE).get(KohlsPOCConstant.ZERO_INT);
						Element messageEle = (Element) XMLUtil.getElementsByTagName(eleTransError, KohlsPOCConstant.E_MESSAGE).get(KohlsPOCConstant.ZERO_INT);
						XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_CODE ,detailsEle.getTextContent() );
						XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_DESCRIPTION ,messageEle.getTextContent() );
					}

				
			
			}
			
			if(errorsEle.hasChildNodes())
			{
				if(logger.isDebugEnabled()){
					logger.debug("KohlsPoCXMLTransformer.validateErrorInResponse: There are errors \n "+ XMLUtil.getElementXMLString(errorsEle));
				}
				logger.endTimer("KohlsPoCXMLTransformer.validateErrorInResponse");
				return errorsEle;
			}
			else
			{
				if(logger.isDebugEnabled()){
					logger.debug("KohlsPoCXMLTransformer.validateErrorInResponse: There are no errors \n "+ XMLUtil.getElementXMLString(resElement));
				}
				logger.endTimer("KohlsPoCXMLTransformer.validateErrorInResponse");
				return resElement;
			}
	}
	

	private Element validatePSATVSErrorInResponse(Element resElement) throws ParserConfigurationException,Exception {

      logger.beginTimer("KohlsPoCXMLTransformer.validatePSATVSErrorInResponse");
      if(logger.isDebugEnabled()){
    	  logger.debug("KohlsPoCXMLTransformer.validatePSATVSErrorInResponse : input element \n"+ XMLUtil.getElementXMLString(resElement));
      }
      NodeList listItemErrors =  XPathUtil.getNodeList(resElement, "//adjustmentResponse/transaction/itemList/item/errors/error");
      NodeList listTransactionErrors = XPathUtil.getNodeList(resElement, "//adjustmentResponse/transaction/errors/error");
      Element errorsEle = null;
      
         errorsEle = XMLUtil.createDocument(KohlsPOCConstant.E_ERRORS).getDocumentElement();
         
         // Error check at Item level
         
         if(!YFCCommon.isVoid(listItemErrors) && listItemErrors.getLength() > KohlsPOCConstant.ZERO_INT){
            for(int i=0;i<listItemErrors.getLength();i++)
            {
               Element eleItemError = (Element)listItemErrors.item(i);
               Element errorEle = XMLUtil.createChild(errorsEle,KohlsPOCConstant.E_ERROR);
               Element detailsEle = (Element) XMLUtil.getElementsByTagName(eleItemError, KohlsPOCConstant.E_CODE).get(KohlsPOCConstant.ZERO_INT);
               Element messageEle = (Element) XMLUtil.getElementsByTagName(eleItemError, KohlsPOCConstant.E_MESSAGE).get(KohlsPOCConstant.ZERO_INT);
               XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_CODE ,detailsEle.getTextContent() );
               XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_DESCRIPTION ,messageEle.getTextContent() );
               }
            }
            
            // Error check at transaction level
            if(!YFCCommon.isVoid(listTransactionErrors) && listTransactionErrors.getLength() > KohlsPOCConstant.ZERO_INT){
               for(int i=0;i<listTransactionErrors.getLength();i++)
               {
                  Element eleTransError = (Element)listTransactionErrors.item(i);
                  Element errorEle = XMLUtil.createChild(errorsEle,KohlsPOCConstant.E_ERROR);
                  Element detailsEle = (Element) XMLUtil.getElementsByTagName(eleTransError, KohlsPOCConstant.E_CODE).get(KohlsPOCConstant.ZERO_INT);
                  Element messageEle = (Element) XMLUtil.getElementsByTagName(eleTransError, KohlsPOCConstant.E_MESSAGE).get(KohlsPOCConstant.ZERO_INT);
                  XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_CODE ,detailsEle.getTextContent() );
                  XMLUtil.setAttribute(errorEle,KohlsPOCConstant.A_ERROR_DESCRIPTION ,messageEle.getTextContent() );
               }

            
         
         }
         
         if(errorsEle.hasChildNodes())
         {
        	if(logger.isDebugEnabled()){
        		logger.debug("KohlsPoCXMLTransformer.validatePSATVSErrorInResponse: There are errors \n "+ XMLUtil.getElementXMLString(errorsEle));
        	}
            logger.endTimer("KohlsPoCXMLTransformer.validatePSATVSErrorInResponse");
            return errorsEle;
         }
         else
         {
        	if(logger.isDebugEnabled()){
        		logger.debug("KohlsPoCXMLTransformer.validatePSATVSErrorInResponse: There are no errors \n "+ XMLUtil.getElementXMLString(resElement));
        	}
            logger.endTimer("KohlsPoCXMLTransformer.validatePSATVSErrorInResponse");
            return resElement;
         }
   }
   
		/**
	* 
	* @param arg0 the properties variable
	* @throws Exception the exception
	*/
	public void setProperties(Properties arg0) throws Exception  {
	this.props  =  arg0;
	}

	/**
	* 
	* @param property the property to set
	* @return String the property value
	*/
	public String getPropertyValue(String property)  {
	String propValue;
	propValue  =  YFSSystem.getProperty(property);

	if (YFCCommon.isVoid(propValue)) {
	propValue  =  property;
	}
	return propValue;

	}
	}
