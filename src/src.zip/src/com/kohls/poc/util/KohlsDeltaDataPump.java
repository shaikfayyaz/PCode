package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
//import java.util.concurrent.TimeUnit;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.dbclasses.YFS_Entity_ChangeDBHome;
import com.yantra.shared.dbclasses.YFS_Sync_DB_ExportDBHome;
import com.yantra.shared.dbclasses.YFS_Sync_DB_ImportDBHome;
import com.yantra.shared.dbclasses.YFS_User_Group_ListDBHome;
import com.yantra.shared.dbi.YFS_Sync_DB_Export;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.tools.entityguru.generator.Entity;
import com.yantra.tools.entityguru.generator.EntityRepository;
import com.yantra.ycp.core.YCPContext;
import com.yantra.ycp.core.YCPTemplateManager;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dblayer.dbi.YFCEntityRepositoryImpl;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDataBuf;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

/*The Class exports dumps for delta change.*/
public class KohlsDeltaDataPump extends YCPBaseAgent {
	private static YFCLogCategory log = YFCLogCategory.instance(KohlsDeltaDataPump.class.getName());
	
	public static final String UPDATE_SYNC_EXPORTED_DATE_FORMAT = "MM-dd-yyyy HH:mm:ss";
	public static final String DELTA_STORE_LIST = "Stores";
	public static final String TMP_MNGR_ROLE = "TempManagerRole";
	public static final String TEMPORARY_USERGROUP = "TEMPORARY_USERGROUP";
	private static final String DELTA_TYPE_STAGED = "STAGED";
	public static String timeStamp = null;
	public static Date expImpTimeStamp = null;
	private static Statement stmt = null;
	private static YIFApi oApi = null;
	Connection conn = null;
	String actionName = null;
	String sMasterPoolId = null;
	String sConfigPoolId = null;
	String strSequenceNoImport = null;	
	String strQueryParDelete = null;	
	private static PreparedStatement prepStmt = null;
	
	public static String schemaName = "";
	public static String deltaCurDirPath = "";
	private static String partitionTableList = "";
	private static String tableListMappingStg = "";
	public static String tableListToGetTableSpace = "";
	private static ArrayList<String> profileToIgnoreTables = new ArrayList<String>();
	private static ArrayList<String> profileUpdateToDB = new ArrayList<String>();
	private static ArrayList<String> trimProfiles = new ArrayList<String>();
	private static HashMap <String,String> timeTablesGroup = new HashMap <String,String>();
	boolean cdtFlagUpdate = false;
	private static boolean cdtProfileActive = false;
	private static boolean masterProfileActive = false;
	private static ArrayList<String> exportProfilesList = new ArrayList<String>();
	private static String exportProfilesSTGTableList = "";
	private static HashMap <String,String> profileDeltaTypeMap = new HashMap <String,String>();
	private static ArrayList<String> statsTableList = new ArrayList<String>();
	private static String ISS_SCHEMA = "STERLING";
	
	public void createMapDir(YFSEnvironment env, String actionName, String dmpFilePath)
			throws SQLException, ClassNotFoundException, Exception {
		String sqlMapDir = "";
		try {
			if (actionName.equalsIgnoreCase(KohlsPOCConstant.DB_DELTA_IMPORT)) {
				sqlMapDir = "CREATE OR REPLACE DIRECTORY data_pump_import_directory AS '" + dmpFilePath + "'";
				log.debug("Import dump file path is " + dmpFilePath);
			} else if (actionName.equalsIgnoreCase(KohlsPOCConstant.DB_DELTA_EXPORT)) {
				sqlMapDir = "CREATE OR REPLACE DIRECTORY data_pump_export_directory AS '"
						+ YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY) + "'";
			}
			YCPContext context = (YCPContext) env;
			conn = context.getDBConnection();
			stmt = conn.createStatement();
			log.info("SQL map directory statement is " + sqlMapDir);
			stmt.executeUpdate(sqlMapDir);
			stmt.close();
		} catch (Exception e) {
			log.error("Exception while creating directory " + e.toString());
			throw e;
		}
	}

	private void exportTables(YFSContext ctx) throws IOException, Exception {
		try {
			actionName = KohlsPOCConstant.A_EXPORT;
			timeStamp = new SimpleDateFormat(KohlsPOCConstant.EXPORT_TABLES_DATE_FORMAT).format(new java.util.Date());
			log.info("Current timestamp while exporting is " + timeStamp);
			String dumpFileNameMaster = getConfigValue(actionName, KohlsPOCConstant.KEY_EXPORT_FILE)
					+ KohlsPOCConstant.TABLE_TYPE_MASTER + KohlsPOCConstant.UNDERSCORE + timeStamp
					+ KohlsPOCConstant.DOT_DMP;
			log.debug("Dump file name as " + dumpFileNameMaster);
			createExportDumpFiles(ctx, dumpFileNameMaster);
		} catch (Exception e) {
			log.error("Exception in Export Tables is " + e.toString());
			throw e;
		}
	}

	private void moveFiles(String dumpFileName, String logFileName) throws IOException {
		File file1 = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY)
				+ KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);
		File file2 = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + dumpFileName);
		moveErrorFiles(file1, file2);

		File file3 = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY)
				+ KohlsPOCConstant.BACKWARD_SLASH + logFileName);
		File file4 = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + logFileName);
		moveErrorFiles(file3, file4);
	}

	private void generateSyncVersionFile(YFSEnvironment env, ArrayList<String> activeProfiles, String sImportType, 
			String exportedProfilesSTGTableList) throws Exception {
		log.info("Enter GenerateSyncVersionFile() :: Getting the profile list");
		Document docSyncProfile = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_PROFILE);
		Element eleSyncProfile = docSyncProfile.getDocumentElement();
		Element eleComplexQuery = SCXmlUtil.createChild(eleSyncProfile, KohlsConstants.COMPLEX_QUERY);
		Element eleOr = SCXmlUtil.createChild(eleComplexQuery, KohlsConstants.OR);
		for (int il = 0; il < activeProfiles.size(); il++) {
			Element eleExp = SCXmlUtil.createChild(eleOr, KohlsConstants.EXP);
			eleExp.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_SYNC_PROFILE_ID);
			eleExp.setAttribute(KohlsPOCConstant.A_VALUE, activeProfiles.get(il));
			log.info("Current profile passed to complexQuery is " + activeProfiles.get(il));
		}
		log.debug("Formed complex query " + SCXmlUtil.getString(docSyncProfile));
		Document docSyncProfileListOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST_TEMPLATE_PATH, KohlsPOCConstant.API_GET_SYNC_PROFILE_LIST,
				docSyncProfile);
		log.debug("docSyncProfileListOutput is " + SCXmlUtil.getString(docSyncProfileListOutput));
		Document docSyncVersion = YFCDocument.createDocument(KohlsPOCConstant.V_SYNC_VERSION).getDocument();
		if (!YFCCommon.isVoid(docSyncProfileListOutput)) {
			log.debug("Entered docSyncProfileListOutput non null condition ");
			ArrayList<Element> profileList = SCXmlUtil.getChildren(docSyncProfileListOutput.getDocumentElement(),
					KohlsPOCConstant.E_SYNC_PROFILE);
			log.info("Size of profileList " + profileList.size());
			for (Element profile : profileList) {
				String sSyncProfileID = profile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
				String sTableGroup = profile.getAttribute(KohlsPOCConstant.A_TABLE_GROUP);
				String sOrganizationCode = profile.getAttribute(KohlsConstant.A_ORGANIZATION_CODE);
				log.debug("Current sSyncProfileID, sTableGroup , sOrganizationCode are " + sSyncProfileID + ", "
						+ sTableGroup + ", " + sOrganizationCode);
				updateSyncVersionToDB(env, sSyncProfileID, sTableGroup, sOrganizationCode, docSyncVersion, true, false);
			}
			log.debug("Writing the new file sync version for master");
			String syncVersionFileName = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
					+ KohlsPOCConstant.BACKWARD_SLASH + sImportType + KohlsPOCConstant.UNDERSCORE 
					+ KohlsPOCConstant.FILENAME_SYNC_VERSION + timeStamp
					+ KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION;
			FileWriter writer = new FileWriter(syncVersionFileName);
			log.debug("Created file writer sync version for master");
			writer.write(SCXmlUtil.getString(docSyncVersion));
			writer.close();
			
			if (!YFCCommon.isVoid(tableListToGetTableSpace)) {
				KohlsDeploymentUtil deployUtil = new KohlsDeploymentUtil();
				deployUtil.tableSpacesFromDB(env, tableListToGetTableSpace, schemaName, syncVersionFileName);
				
				// Merge Changes to add the STG Table Mapping
				File fl = new File(syncVersionFileName);
				if (fl.exists() && syncVersionFileName.contains("STAGED_SyncVersion")) {
					log.debug("Updating the synversion file with table spaces " + fl);
					Element eleSyncVersionDocument = null;
					Document docSyncVer = SCXmlUtil.getDocumentBuilder().parse(fl);
					eleSyncVersionDocument = docSyncVer.getDocumentElement();
					writer = new FileWriter(fl.getAbsoluteFile());
					Element eleProfileD = SCXmlUtil.createChild(eleSyncVersionDocument, "STGTableMapping");
					eleProfileD.setAttribute(KohlsPOCConstant.A_STG_TABLE_MAP, exportedProfilesSTGTableList);
					writer.write(SCXmlUtil.getString(eleSyncVersionDocument));
					writer.close();
				}
			}else{
				log.info("No active delta tables,so tablespaces are not retrieved");
			}

			if (log.isDebugEnabled())
				log.debug("Sync Version is " + SCXmlUtil.getString(docSyncVersion));
		}
		log.info("Exit GenerateSyncVersionFile() :: Returing the table list");		
	}

	private void createExportDumpFiles(YFSContext ctx, String dumpFileNameMaster) throws Exception {
		try {
			log.info("Enter createExportDumpFiles() :: Generating the export dump files");
			actionName = KohlsPOCConstant.A_EXPORT;
			Document docGetColonyPoolListOutput;
			log.debug("Getting colony pool list");
			docGetColonyPoolListOutput = callGetColonyPoolList(ctx);
			log.debug("Get colony pool list output " + SCXmlUtil.getString(docGetColonyPoolListOutput));
			Element eleColonyPoolListOut = docGetColonyPoolListOutput.getDocumentElement();
			ArrayList<Element> eleColonyPoolList = SCXmlUtil.getChildren(eleColonyPoolListOut,
					KohlsPOCConstant.E_COLONY_POOL);
			String sPoolId = null;
			Boolean isMasterPoolRead = false;

			for (Element eleColonyPool : eleColonyPoolList) {
				if (isMasterPoolRead) {
					break;
				}
				sPoolId = eleColonyPool.getAttribute(KohlsPOCConstant.A_POOL_ID);
				log.debug("sPoolId is " + sPoolId);
				String sTableType = eleColonyPool.getAttribute(KohlsPOCConstant.TABLE_TYPE);
				log.debug("Table Type is " + sTableType);
				if (KohlsPOCConstant.TABLE_TYPE_MASTER.equals(sTableType) && !isMasterPoolRead) {
					sMasterPoolId = eleColonyPool.getAttribute(KohlsPOCConstant.A_POOL_ID);
					log.debug("Master Pool Id is " + sMasterPoolId);
					isMasterPoolRead = true;
				}
			}
			String explogfileMaster = getConfigValue(actionName, KohlsPOCConstant.KEY_LOG_FILE)
					+ KohlsPOCConstant.TABLE_TYPE_MASTER + KohlsPOCConstant.UNDERSCORE + timeStamp
					+ KohlsPOCConstant.DOT + KohlsPOCConstant.LOG_EXTENSION;
			
			HashMap<String, String> profileIdMapInsertUpdate = new HashMap<String, String>();
			HashMap<String, String> profileIdMapDeleteUpdate = new HashMap<String, String>();
			HashMap<String, String> profileIdMapAll = new HashMap<String, String>();
						
			Document docCommonCodeList = callGetCommonCodeList(ctx, KohlsPOCConstant.DATASYNC_PROFILE);
			String deltaDonePath = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
			+ KohlsPOCConstant.BACKWARD_SLASH;
			HashMap<String, String> actTableProfileList = getActiveTableAndProfile(docCommonCodeList);	

			KohlsDeltaDataPumpMergeUtil mUtil = new KohlsDeltaDataPumpMergeUtil();
			HashMap<String, String> getActiveTableSTGMapList = mUtil.getActiveTableSTGMap(docCommonCodeList);
			
			if (actTableProfileList.isEmpty()) { 
				String zeroDumpFile = deltaDonePath + KohlsPOCConstant.ZERO_INS_UPD_DMP;
				createZeroDumpFile(zeroDumpFile, "");	
				String zeroDelUpdFile = deltaDonePath + KohlsPOCConstant.ZERO_DEL_UPD_DMP;
				createZeroDumpFile(zeroDelUpdFile, "");	
				masterProfileActive = false;
				log.info("No active profiles and masterProfileActive value is " + masterProfileActive );
			}else {
				masterProfileActive = true;
				trimProfiles.clear(); // to clear before loading 
				trimProfiles = trimProfileList(actTableProfileList); // get active profile				
				log.info("Getting lastFullOrDeltaSyncDate from MASTER DB is having entries");
				HashMap<String, String> profileAndLastSyncMasterDate = getLastSyncDateForMaster(ctx,
						KohlsPOCConstant.TABLE_TYPE_MASTER, trimProfiles);

				//get profile and lastsync timestamp
				for (String key : profileAndLastSyncMasterDate.keySet()) {
					log.info("Final list profile and timestamp profileAndLastSyncMasterDateInstant is " + key + ", "
							+ profileAndLastSyncMasterDate.get(key));
				}
				// for DELAY profiles, need to pass actTableProfileList,

				// profileAndLastSyncMasterDate
				boolean bIsInsertDump = false;
				boolean bIsDeleteDump = false;
				ArrayList<Boolean> arrInsertDumpFlag = new ArrayList();
				ArrayList<Boolean> arrDeleteDumpFlag = new ArrayList();
				ArrayList<String> uniqueImportTypeSet = new ArrayList();
				for (String profile : profileDeltaTypeMap.keySet()) {
					if(!uniqueImportTypeSet.contains(profileDeltaTypeMap.get(profile))){
						uniqueImportTypeSet.add(profileDeltaTypeMap.get(profile));
					}
				}
				
				for(String strImportType : uniqueImportTypeSet){
					HashMap<String, String> profileAndLastSyncMasterDateClone = (HashMap) profileAndLastSyncMasterDate.clone();
					bIsInsertDump = callExpdpForPoolId(ctx, sMasterPoolId, explogfileMaster,
							KohlsPOCConstant.INSERT_UPDATE, actTableProfileList, profileAndLastSyncMasterDateClone, strImportType,getActiveTableSTGMapList);
					bIsDeleteDump  = callExpdpForPoolId(ctx, sMasterPoolId, explogfileMaster,
							KohlsPOCConstant.DELETE_UPDATE, actTableProfileList, profileAndLastSyncMasterDateClone, strImportType,getActiveTableSTGMapList);
					arrInsertDumpFlag.add(bIsInsertDump);
					arrDeleteDumpFlag.add(bIsDeleteDump);
					
					if (isDeltaDBUpdateEnabled()) {
						if (bIsInsertDump || bIsDeleteDump) {						
						 //manageSyncDBExport(ctx, trimProfiles); //passing the trimmed profile list, one profile contains many tables
						 ArrayList<String> exportTrimProfilesList = new ArrayList<String>(new HashSet<String>(exportProfilesList)); //removing the duplicate entries
						 generateSyncVersionFile(ctx, exportTrimProfilesList, strImportType, exportProfilesSTGTableList); //passing the trimmed profile list, one profile contains many tables
						 updateSyncExportedFlag(ctx);
						} else {
							log.info("No delta change observed hence not performing any action for import type " + strImportType);
						}
						exportProfilesList.clear();
						exportProfilesSTGTableList="";
						tableListToGetTableSpace = ""; 
					} else {
						String strFltrTableList = filteredTableList(ctx, profileIdMapAll);
						if (strFltrTableList.isEmpty()) {
							log.info("No table to update the sync flag");
						} else {
							updateSyncExportedFlag(ctx);
						}
					}
				}
				
				// change the hashMap var name profileIdMapInsertUpdate
				if(arrInsertDumpFlag.contains(true)){
					profileIdMapAll.putAll(profileIdMapInsertUpdate);
				} else {
					String zeroDumpFile = deltaDonePath + KohlsPOCConstant.ZERO_INS_UPD_DMP;
					createZeroDumpFile(zeroDumpFile, "");
				}
				if(arrDeleteDumpFlag.contains(true)){
					profileIdMapAll.putAll(profileIdMapDeleteUpdate);
				} else {
					String zeroDumpFile = deltaDonePath + KohlsPOCConstant.ZERO_DEL_UPD_DMP;
					createZeroDumpFile(zeroDumpFile, "");
				}
			} // active profiles end
		} catch (Exception e) {
			log.error("Exception in createExportDumpFiles is  " + e.getMessage() + e.getStackTrace());
			throw e;
		}
	}

	public String filteredTableList(YFSEnvironment env, HashMap<String, String> profileIdMapAll) throws Exception {
		String strTableList = "";
		for (String strTableName : profileIdMapAll.keySet()) {
			log.debug("Current filteredTableName is " + strTableName);
			if (YFCCommon.isVoid(strTableList)) {
				strTableList = "'" + strTableName + "'";
			} else {
				strTableList = strTableList + ",'" + strTableName + "'";
			}
		}
		log.debug("filteredTableList is " + strTableList);
		return strTableList;
	}

	private String getSyncDateFromSyncProcessTable(YFSContext ctx, String tableType) throws Exception {
		String strFinalTS = "";
		if (tableType.equals(KohlsPOCConstant.TABLE_TYPE_MASTER)) {
			strFinalTS = getLastSyncDate(ctx, KohlsPOCConstant.TABLE_TYPE_MASTER);			
		} else {
			strFinalTS = getLastSyncDate(ctx, KohlsPOCConstant.A_CONFIGURATION);
		}
		log.info("Final time stamp retrieved is " + strFinalTS);
		return strFinalTS;
	}

	//New Expdp Created a map with profile and time
	private HashMap<String, String> getLastSyncDateForMaster(YFSContext ctx, String strSyncSchemaType,
			ArrayList<String> profileName) throws Exception {
		log.info("Enter getLastSyncDateForMaster() :: Checking the time stamp in Master");
		try {
			ArrayList<String> userActivatedProfileNames = new ArrayList<String>();
			for (String prf : profileName) {
				userActivatedProfileNames.add(prf);
			}
			log.info("Active profiles and copied profile size are " + profileName.size() + ", "
					+ userActivatedProfileNames.size());
			SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
			Document lastFullDeltaSynInDoc = SCXmlUtil.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
			Element lastFullElm = lastFullDeltaSynInDoc.getDocumentElement();
			lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, KohlsPOCConstant.A_EXPORT);
			lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);
			lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
			log.debug("Input to full last sync date call " + XMLUtil.getXMLString(lastFullDeltaSynInDoc));
			Document lastFullDeltaSynOutDoc = KohlsCommonUtil.invokeService(ctx,
					KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, lastFullDeltaSynInDoc);
			log.debug("Output to last sync date call is " + XMLUtil.getXMLString(lastFullDeltaSynOutDoc));
			Element elmLastFullSyncDateOutDoc = lastFullDeltaSynOutDoc.getDocumentElement();
			NodeList nodeListFullDelta = elmLastFullSyncDateOutDoc
					.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);

			HashMap<String,String> fullProfileDate = new HashMap<String,String>(); // full sync profile list and its date
			HashMap<String,String> deltaProfileDate = new HashMap<String,String>(); //delta sync profile list and its date
			profileDeltaTypeMap.clear();
			for (int il = 0; il < nodeListFullDelta.getLength(); il++) {
				Element eleFullDelta = ((Element) nodeListFullDelta.item(il));
				if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equals(KohlsPOCConstant.SYNC_DELTA)) {
					profileDeltaTypeMap.put(eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE), 
							eleFullDelta.getAttribute(KohlsPOCConstant.A_IMPORT_TYPE));
					deltaProfileDate.put(eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE),
							eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
					log.debug("Delta profile is " + eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE));
				} else if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equals(KohlsPOCConstant.SYNC_FULL)) {
					fullProfileDate.put(eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE),
							eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
					log.debug("Full profile is " + eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE));
				}
			}

			HashMap<String, String> profileAndTimeStamp = new HashMap<String, String>();
			ArrayList <String>presentProfileList = new ArrayList<String>();
			//Assumption - all full and delta profiles are populated.
			for (String prof : userActivatedProfileNames) {
				for (String deltaPrf : deltaProfileDate.keySet()) {
					if (prof.equalsIgnoreCase(deltaPrf)) {
						log.debug("Delta profile from cust table and user act profile " + deltaPrf + " >>> " + prof);
						String deltaSyncDateCustomTableFrmt = sdf
								.format(YFCDate.getYFCDate(deltaProfileDate.get(deltaPrf)));
						
						String deltaSyncDateCustomTable = YFCDate.getYFCDate(deltaProfileDate.get(deltaPrf)).toString();
						String fullSyncDate = "";
						String fullSyncDateFmt = "";
						for (String fullPrf : fullProfileDate.keySet()) { // if any fullsync done for that profile
							if (prof.equalsIgnoreCase(fullPrf)) {
								fullSyncDateFmt = sdf.format(YFCDate.getYFCDate(fullProfileDate.get(fullPrf)));
								fullSyncDate = YFCDate.getYFCDate(fullProfileDate.get(fullPrf)).toString();
								log.debug("Full Sync dates format " + fullSyncDateFmt  + " > " + fullSyncDate);
							}
						}
						log.info("Passing fullsync date is " + fullSyncDate);
						if (YFCCommon.isVoid(fullSyncDate)) {
							throw new YFCException(
									"Perform a fullsync before performing a delta sync for profile " + prof);
						} else {
							//if (Long.parseLong(deltaSyncDateCustomTable) > Long.parseLong(fullSyncDate)) {
							if (!YFCCommon.isVoid(deltaSyncDateCustomTable)) {
								profileAndTimeStamp.put(prof, deltaSyncDateCustomTableFrmt);
								presentProfileList.add(prof);
								log.debug("Full Sync date is " + prof + " : " + Long.parseLong(fullSyncDate));
								log.debug("Delta Sync date and full Sync date " + prof + " - "
										+ deltaSyncDateCustomTable + " : " + deltaSyncDateCustomTableFrmt);
							} else {
								profileAndTimeStamp.put(prof, fullSyncDateFmt);
								presentProfileList.add(prof);
								log.debug("Full Sync date is " + prof + " : " + Long.parseLong(fullSyncDate));
								log.debug("Delta Sync date is not present and full Sync date " + prof + " - "
										+ deltaSyncDateCustomTable + " : " + fullSyncDateFmt);
							}
						}
					}
				}
			}
			
			userActivatedProfileNames.removeAll(presentProfileList);
			log.debug("profileName and userActivatedProfileNames are " + profileName.size() +", " + userActivatedProfileNames.size());

			// Checking and updating the missing profiles timestamp and also for the POD scenario where it has 1 entry with empty profile
			if (YFCCommon.isVoid(profileAndTimeStamp)) {
				for (String newPrf : profileName) {					
					for (String prfFull : fullProfileDate.keySet()) { // if any fullsync done for that profile
						if (newPrf.equalsIgnoreCase(prfFull)) {
							String fullSyncDateFmt = sdf.format(YFCDate.getYFCDate(fullProfileDate.get(prfFull)));
							profileAndTimeStamp.put(newPrf, fullSyncDateFmt);
							log.debug("No delta profiles present, hence adding all " + newPrf +", " + fullSyncDateFmt);
						}
					}
				}
			} else {
				// for absent profiles i.e for new profiles, get last sync				
				for (String missingPrf : userActivatedProfileNames) {					
					for (String flProfile : fullProfileDate.keySet()) { // if any fullsync done for that profile
						if (missingPrf.equalsIgnoreCase(flProfile)) {
							String fullSyncDateFmt = sdf.format(YFCDate.getYFCDate(fullProfileDate.get(flProfile)));
							profileAndTimeStamp.put(missingPrf, fullSyncDateFmt);
							log.debug("New profile added with fullsync date " + missingPrf +", " + fullSyncDateFmt );
						}
					}				
				}
			}	
			
			return profileAndTimeStamp;
		} catch (Exception ex) {
			log.error("Not able to get the last sync date for all active profiles");
			throw ex;
		}
	}
	
	
	private String getLastSyncDate(YFSContext ctx, String strSyncSchemaType) throws Exception {
		log.info("Enter getLastSyncDate() :: Checking the time stamp in Master");
		try {
			Document inputDoc = YFCDocument.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS).getDocument();
			Element eleInput = inputDoc.getDocumentElement();
			eleInput.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, strSyncSchemaType);
			eleInput.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_DELTA);
			eleInput.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);
			log.debug("Input to GetDataPumpSyncProcessList " + XMLUtil.getXMLString(inputDoc));
			Document outDoc = KohlsCommonUtil.invokeService(ctx, KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST,
					inputDoc);
			log.debug("Output of GetDataPumpSyncProcessList " + XMLUtil.getXMLString(outDoc));
			ArrayList<Element> syncProcessList = SCXmlUtil.getChildren(outDoc.getDocumentElement(),
					KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
			String strLastFullOrDeltaSyncDate = "";
			for (Element eleSyncProcess : syncProcessList) {
				strLastFullOrDeltaSyncDate = eleSyncProcess.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP);
			}
			SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
			String strFinalDate = sdf.format(YFCDate.getYFCDate(strLastFullOrDeltaSyncDate));
			log.info("Last Full Or Delta Sync Entity Change Record " + strFinalDate);
			return strFinalDate;
		} catch (Exception ex) {
			log.error("Error occurred");
			throw ex;
		}
	}

	private boolean checkIfSyncProcessTablePopulated(YFSContext ctx, String strTableType, String strSyncProcess)
			throws Exception {
		log.info("Enter checkIfSyncProcessTablePopulated() :: Checking the Sync process table has values " + strTableType);
		Document inputDoc = YFCDocument.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS).getDocument();
		Element eleInput = inputDoc.getDocumentElement();
		eleInput.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, strTableType);
		eleInput.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, strSyncProcess);
		eleInput.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_DELTA);
		eleInput.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);
		log.debug("Input to GetDataPumpSyncProcessList " + XMLUtil.getXMLString(inputDoc));
		Document outDoc = KohlsCommonUtil.invokeService(ctx, KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST,
				inputDoc);
		log.debug("Output of GetDataPumpSyncProcessList \n" + XMLUtil.getXMLString(outDoc));

		ArrayList<Element> syncProcessList = SCXmlUtil.getChildren(outDoc.getDocumentElement(),
				KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
		log.info("syncProcessList.size() is " + syncProcessList.size());

		if (syncProcessList.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	private void createZeroDumpFile(String zeroDumpFile, String content) throws IOException {
		log.info("Enter createZeroDumpFile() :: Creating file with name " + zeroDumpFile);
		FileWriter writer = new FileWriter(zeroDumpFile);
		writer.write(content);
		writer.close();
	}

	private boolean checkIfAnyConfigChange(YFSEnvironment env, String strLastSyncConfigDate) throws Exception {
		log.info("Enter checkIfAnyConfigChange() :: Checking for any config changes present");
		ArrayList<Element> excludeList = new ArrayList<Element>();
		excludeList = getExcludeTableList((YFSContext) env);
		String strList = "";
		if (!YFCCommon.isVoid(excludeList)) {
			for (Element eleExclude : excludeList) {
				if (YFCCommon.isVoid(strList)) {
					strList = "'" + eleExclude.getAttribute(KohlsPOCConstant.A_NAME) + "'";
				} else {
					strList = strList + ",'" + eleExclude.getAttribute(KohlsPOCConstant.A_NAME) + "'";
				}
			}
		}
		YFSContext yctx = (YFSContext) env;
		ArrayList<String> finalList = fireSqlForConfig(yctx, strList, strLastSyncConfigDate);
		log.info("FinalList size config changes is " + finalList.size());
		if (finalList.size() > 0) {
			return true;
		}
		return false;
	}

	private ArrayList<String> fireSqlForConfig(YFSContext ctx, String strList, String strLastSyncConfigDate)
			throws Exception {
		log.info("Enter fireSqlForConfig() :: Checking for config changes");
		PLTQueryBuilder oPLT = new PLTQueryBuilder(false);
		oPLT.append("SELECT" + " DISTINCT(ENTITY)");
		oPLT.append(" FROM YFS_ENTITY_CHANGE");
		if (!YFCCommon.isVoid(strList)) {
			oPLT.append(" WHERE ENTITY NOT IN (" + strList + ") AND DB_OPERATION IN ('INSERT','UPDATE','DELETE')"
					+ " AND CREATETS> to_date(\'" + strLastSyncConfigDate + "\'," + "\'"
					+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
		} else {
			oPLT.append(" WHERE DB_OPERATION IN ('INSERT','UPDATE','DELETE')" + " AND CREATETS> to_date(\'"
					+ strLastSyncConfigDate + "\'," + "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
		}
		log.debug("Query being fired " + oPLT.getReadableWhereClause());
		ArrayList<String> entityList = new ArrayList<String>();
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.debug("Executing SQL: " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			while (rs.next()) {
				log.debug("Entered rs.next() entity is " + rs.getString("ENTITY").trim());
				entityList.add(rs.getString("ENTITY").trim());
			}
			rs.close();
			return entityList;
		} catch (Exception ex) {
			log.error("Error occurred in fireSqlForConfig");
			throw ex;
		} finally {
			log.debug("Fire Query ending in fireSqlForConfig");
			YFSDBHome.closeStatement(stmt);
		}
	}

	private String getLastFullOrDeltaSyncDate(YFSEnvironment env, String strTableType) {
		log.info("Enter getLastFullOrDeltaSyncDate() :: Checking for lastest table changes");
		YCPContext ctx = (YCPContext) env;
		String strTableTypeQuery = "";
		log.debug("Getting the modified table list with strTableType " + strTableType);
		if (strTableType.equals(KohlsPOCConstant.TABLE_TYPE_MASTER)) {
			strTableTypeQuery = " NOT IN('Configuration')";
		} else {
			strTableTypeQuery = " IN ('Configuration')";
		}
		PLTQueryBuilder pltQueryBuilder = new PLTQueryBuilder(false);
		StringBuffer sb = new StringBuffer();
		YFSContext yctx = (YFSContext) env;
		PLTQueryBuilder query = new PLTQueryBuilder();
		query.appendString(KohlsPOCConstant.DB_SYNC_TYPE, "=", KohlsPOCConstant.SYNC_DELTA);
		int i = YFS_Sync_DB_ExportDBHome.getInstance().countWithWhere(yctx, query);
		log.debug("Number of records with full sync " + i);
		String strSyncTypeQuery = "SYNC_TYPE='DELTA'";
		if (i > 0) {
			strSyncTypeQuery = "SYNC_TYPE='DELTA'";
		} else {
			strSyncTypeQuery = "SYNC_TYPE='FULL'";
		}

		pltQueryBuilder
				.append(sb.append("WHERE SYNC_DB_EXPORT_KEY = ( SELECT MAX(SYNC_DB_EXPORT_KEY) FROM YFS_SYNC_DB_EXPORT"
						+ " WHERE TABLEGROUP" + strTableTypeQuery + " AND " + strSyncTypeQuery + ")"));
		log.debug("getReadableWhereClause " + pltQueryBuilder.getReadableWhereClause());
		YFS_Sync_DB_Export lastFullOrDeltaSyncEntityChangeRecord = YFS_Sync_DB_ExportDBHome.getInstance()
				.selectWithWhere(ctx, pltQueryBuilder);
		SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		String strLastFullOrDeltaSyncDate = "";
		if (!YFCCommon.isVoid(lastFullOrDeltaSyncEntityChangeRecord)) {
			log.debug("Last Full Or Delta Sync Entity Change Record " + lastFullOrDeltaSyncEntityChangeRecord);
			YFCDate timestampLastFullSyncDate = lastFullOrDeltaSyncEntityChangeRecord.getDB_Export_Time();
			log.debug("Timestamp Last Full Sync Date is " + timestampLastFullSyncDate);
			strLastFullOrDeltaSyncDate = sdf.format(timestampLastFullSyncDate);
			log.info("Last Full Sync date is " + strLastFullOrDeltaSyncDate);
		}
		return strLastFullOrDeltaSyncDate;
	}

	private boolean callExpdpForPoolId(YFSContext ctx, String sPoolId,
			String explogfile, String dumpType, HashMap<String, String> actTableProfileList,
			HashMap<String, String> profileAndLastSyncMasterDate, String sImportType,
			HashMap<String, String> getActiveTableSTGMapList) throws Exception {
		try {
			Properties JDBCProperties;
			JDBCProperties = loadPropertiesFromAbsoluteLocation(
					YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
			log.debug("JDBC properties path is " + YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
			String sUserName = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + KohlsPOCConstant.USER);
			String sPassword = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + KohlsPOCConstant.PASSWORD);
			String sUrl = JDBCProperties.getProperty(sPoolId + KohlsPOCConstant.DOT + KohlsPOCConstant.URL);
			String[] jdbcURLSplit = sUrl.split(KohlsPOCConstant.AT);
			schemaName = sUserName;
			HashMap<String,String> profileLatSyncDateMap =  callExpdp(ctx, sUserName, sPassword, jdbcURLSplit[1], explogfile, dumpType,
					actTableProfileList, profileAndLastSyncMasterDate, sImportType, getActiveTableSTGMapList);

			if(!YFCCommon.isVoid(profileLatSyncDateMap)){
				return true;
			}else {
				return false;
			}
		} catch (Exception e) {
			log.error("Error in callExpdpForPoolId " + e.getMessage());
			throw e;
		}
	}

	public static HashMap<String, String[]> getValueAndDescMap(Document docCommonCodeList) {
		HashMap<String, String[]> hashMapCommonCode = new HashMap<String, String[]>();
		Element eleCommonCodeList = docCommonCodeList.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			String[] profileIdPrimaryKeyArray = new String[2];
			profileIdPrimaryKeyArray[0] = eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION);
			profileIdPrimaryKeyArray[1] = eleCommonCode.getAttribute(KohlsConstants.CODE_LONG_DESC);
			hashMapCommonCode.put(eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE), profileIdPrimaryKeyArray);
			log.debug("Common Code Value and Short Desc " + eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE) + ","
					+ eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION));
		}
		return hashMapCommonCode;
	}

	public ArrayList<String> trimProfileList(HashMap<String, String> fullList) {
		ArrayList<String> trimlist = new ArrayList<String>();
		for (String key : fullList.keySet()) {
			trimlist.add(fullList.get(key));
			log.debug("Profile name is " + fullList.get(key));
		}
		Set<String> hs = new HashSet<>();
		hs.addAll(trimlist);
		trimlist.clear();
		trimlist.addAll(hs);
		for (String ll : trimlist) {
			log.debug("Trimlist profile is " + ll);
		}
		return trimlist;
	}
		
	private HashMap<String, String> callExpdp(YFSContext ctx, String sUserName, String sPassword, String jdbcURL,
			 String logfile, String dumpType,
			HashMap<String, String> actTableProfileList, HashMap<String, String> profileAndLastSyncMasterDate, String sImportType,
			HashMap<String, String> getActiveTableSTGMapList)
			throws Exception { // removed String lastFullOrDeltaSyncDate,
		String statement = null;
		String parFile = "";
		boolean isFirstTableRead = false;
		String dumpFileName = "";
		boolean isFirst = true;
		boolean isFirstProfile = true;
		String tableListMaster = "";
		log.info("Enter callExpdp() :: Exporting the data dump");		
		SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		String strCurrentDate = sdf.format(expImpTimeStamp);	
		String QUERY_MASTER = "QUERY=";
		String stagedQueryPar = "";
		log.debug("Dump logfile is " + logfile);
		PLTQueryBuilder oPLT = new PLTQueryBuilder(false);		

		// MERGE get property values
		ArrayList<String> tablesProcs = new ArrayList<String>();
		String partitionHoldSize = YFSSystem.getProperty(KohlsPOCConstant.DELTA_PARTITION_TABLE_SIZE);
		String podType = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_POD_TYPE);
		String partitionEnabled = YFSSystem.getProperty(KohlsPOCConstant.DELTA_EXPORT_PARTITION_ENABLED);

		if (sImportType.equalsIgnoreCase(KohlsPOCConstant.A_STAGED)) {
			List<String> stagedProfiles = new ArrayList<String>();
			for (String prf : profileDeltaTypeMap.keySet()) {
				if (profileDeltaTypeMap.get(prf).equalsIgnoreCase(KohlsPOCConstant.A_STAGED)) {
					log.info("Staged profile added " + prf + ", " + profileDeltaTypeMap.get(prf));
					stagedProfiles.add(prf);
				}
			}
			log.info("Before removing profiles " + profileAndLastSyncMasterDate);
			Iterator<String> iterator = profileAndLastSyncMasterDate.keySet().iterator();
			while (iterator.hasNext()) {
				String profile = iterator.next();
				if (!stagedProfiles.contains(profile)) {
					iterator.remove();
					log.debug("Removing profile " + profile);
				}
			}
			log.info("After removing profiles " + profileAndLastSyncMasterDate);
		} else {
			for (Entry<String, String> entry : profileDeltaTypeMap.entrySet()) {
				String profile = entry.getKey();
				String DeltaType = entry.getValue();
				if (!profileDeltaTypeMap.get(profile).equals(sImportType)) {
					profileAndLastSyncMasterDate.remove(profile);
				}
				log.debug("Profile and deltatype are " + profile + ", " + DeltaType);
			}
		}
		//If no profiles are active for this import type - skip the rest of the method and return
		if(profileAndLastSyncMasterDate.size()==0){
			log.info("No profiles of importType " + sImportType + " are ACTIVE.");
			return null;
		}
		
		if (KohlsPOCConstant.INSERT_UPDATE.equals(dumpType)) {
			logfile = sImportType
					+ KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.INSERT_UPDATE + KohlsPOCConstant.UNDERSCORE
					+ KohlsPOCConstant.A_EXPORT + KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
			dumpFileName = sImportType + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.INSERT_UPDATE
					+ KohlsPOCConstant.UNDERSCORE + sUserName + KohlsPOCConstant.UNDERSCORE + timeStamp
					+ KohlsPOCConstant.DOT_DMP;
				
			for (String key : profileAndLastSyncMasterDate.keySet()) {
				if(profileAndLastSyncMasterDate.containsKey(key))
				log.debug("Active profile name is with modified date " + key);
				String strList = "";
				for (String key1 : actTableProfileList.keySet()) {
					log.debug("Date profile name and tableprofile " + actTableProfileList.get(key1) + " : " + key);
					if (actTableProfileList.get(key1).contains(key)) {
						if (isFirst) {
							isFirst = false;
							strList = key1;
						} else {
							strList = strList + "','" + key1;
							log.debug("strList > " + strList);
						}
					}
				}
				isFirst = true; //for next set
				log.debug(" Final strList, isFirstProfile > " + strList + ", " + isFirstProfile);
				if (isFirstProfile) {
					isFirstProfile = false;
					oPLT.append("SELECT" + " DISTINCT(ENTITY)");
					oPLT.append(" FROM YFS_ENTITY_CHANGE");
					oPLT.append(" WHERE ENTITY IN ('" + strList + "') AND DB_OPERATION IN ('INSERT','UPDATE')"
							+ " AND MODIFYTS BETWEEN to_date(\'" + profileAndLastSyncMasterDate.get(key) + "\'," + "\'"
							+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
							+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
				    log.debug("Query being fired fireSqlQueryForInsertUpdate111 " + oPLT.getReadableWhereClause());
				} else {					
					oPLT.append(" UNION SELECT" + " DISTINCT(ENTITY)");
					oPLT.append(" FROM YFS_ENTITY_CHANGE");
					oPLT.append(" WHERE ENTITY IN ('" + strList + "') AND DB_OPERATION IN ('INSERT','UPDATE')"
							+ " AND MODIFYTS BETWEEN to_date(\'" + profileAndLastSyncMasterDate.get(key) + "\'," + "\'"
							+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
							+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
				    log.debug("Query being fired fireSqlQueryForInsertUpdate222 " + oPLT.getReadableWhereClause());
				}
			}
			log.info("Query being fired fireSqlQueryForInsertUpdate " + oPLT.getReadableWhereClause());
			ArrayList<String> finalListInsertUpdate = fireSqlQueryForInsertUpdate(ctx, oPLT, strCurrentDate);			
			// Returning null to convey that no delta table change			
			if (finalListInsertUpdate.size() > 0) {

				if (KohlsPOCConstant.A_STAGED.equalsIgnoreCase(sImportType)) {
					catalogRecordCount(ctx, sUserName);
				}
				tableListMaster = finalListInsertUpdate.toString().replace("[", "").replace("]", "").replace(", ", ",");
				log.info("INSERT_UPDATE final table is " + tableListMaster);
			} else {
				return null;
			}

			for (String tableFromProfTable : actTableProfileList.keySet()) {
				log.debug("tableFromProfTable : " + tableFromProfTable + " profile : "
						+ actTableProfileList.get(tableFromProfTable));
				for (String profileFromProfTimeStamp : profileAndLastSyncMasterDate.keySet()) {
					if (actTableProfileList.get(tableFromProfTable).equalsIgnoreCase(profileFromProfTimeStamp)) {
						log.debug("tableFromProfTable is " + tableFromProfTable + ", profileFromProfTimeStamp : "
								+ profileFromProfTimeStamp + ", Timestamp from profile : "
								+ profileAndLastSyncMasterDate.get(profileFromProfTimeStamp));
						for (int ii = 0; ii < finalListInsertUpdate.size(); ii++) {
							log.info("Final List table name is " + finalListInsertUpdate.get(ii).toString());
							if (finalListInsertUpdate.get(ii).toString().equalsIgnoreCase(tableFromProfTable)) {
								log.debug(tableFromProfTable + " time stamp is "
										+ profileAndLastSyncMasterDate.get(profileFromProfTimeStamp));
								String strPrimaryKey = getPrimaryKey(tableFromProfTable);
								String splOperator = "";
								if (!isFirstTableRead) {
									splOperator = "";
									isFirstTableRead = true;
								} else {
									splOperator = ",";
								}
								// Constructing the query par file
								QUERY_MASTER = QUERY_MASTER + splOperator + tableFromProfTable + ":" + "\""
										+ "WHERE " + strPrimaryKey + " IN ("
										+ "select YFS_ENTITY_CHANGE.ENTITY_KEY from YFS_ENTITY_CHANGE where "
										+ "ENTITY = '" + tableFromProfTable
										+ "' AND DB_OPERATION IN ('INSERT','UPDATE')"
										+ " AND TABLE_TYPE=\'MASTER\' AND MODIFYTS BETWEEN to_date(\'"
										+ profileAndLastSyncMasterDate.get(profileFromProfTimeStamp) + "\'," + "\'"
										+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'"
										+ strCurrentDate + "\'," + "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT
										+ "\') )" + "\"";
								log.debug("INSERT UPDATE Query master is " + QUERY_MASTER);

								// MERGE to load the proc -- Pass each Stage table name to the PL/SQL
								if (DELTA_TYPE_STAGED.equalsIgnoreCase(sImportType)
										&& KohlsPOCConstant.YES.equalsIgnoreCase(partitionEnabled)) {
									String stgTable = "";
									for (String key : getActiveTableSTGMapList.keySet()) {
										if (key.equals(tableFromProfTable)) {
											stgTable = getActiveTableSTGMapList.get(key) + "_" + podType;
											log.info("STAGED - Table name " + stgTable);
											break;
										}
									}

									String proc = sUserName + ".ALTER_DELTA_STAGING_TABLES(\'" + tableFromProfTable + "\','" + stgTable
											+ "\',to_date(\'" + profileAndLastSyncMasterDate.get(profileFromProfTimeStamp) + "\','"
											+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\'),to_date('" + strCurrentDate 
											+ "\','" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')," + partitionHoldSize + ")";
									log.info("STAGED - Proc added to list " + proc);
									tablesProcs.add(proc);
								}
							}
						}
						log.debug("Query master in iteration \n" + QUERY_MASTER);
					}
				}
			}
			log.info("Final INSERT UPDATE Query master is \n " + QUERY_MASTER);
			// Returning null to convey that none of the tables returned from query are part of common code
			parFile = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY)
					+ KohlsPOCConstant.BACKWARD_SLASH + KohlsPOCConstant.INSERT_UPDATE + KohlsPOCConstant.UNDERSCORE
					+ KohlsPOCConstant.QUERY_PAR_FILE + KohlsPOCConstant.DOT_PAR;
			FileWriter writer = new FileWriter(parFile);			
			writer.write(QUERY_MASTER);
			log.debug("Created file writer for Insert and Update");
			writer.close();
		} // End of INSERT_UPDATE
		else if (KohlsPOCConstant.DELETE_UPDATE.equals(dumpType)) {
			logfile = sImportType
					+ KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.DELETE_UPDATE + KohlsPOCConstant.UNDERSCORE
					+ KohlsPOCConstant.A_EXPORT + KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
			dumpFileName = sImportType + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.DELETE_UPDATE
					+ KohlsPOCConstant.UNDERSCORE + sUserName + KohlsPOCConstant.UNDERSCORE + timeStamp
					+ KohlsPOCConstant.DOT_DMP;
			String tempMgrQuery ="";
			for (String profileKey : profileAndLastSyncMasterDate.keySet()) {
				log.debug("Active profile name is with modified date " + profileKey);
				String tableListForDel = "";
				for (String tableKey : actTableProfileList.keySet()) {
					log.debug("date profile name and tableprofile " + actTableProfileList.get(tableKey) + " : "
							+ profileKey);
					if (actTableProfileList.get(tableKey).equalsIgnoreCase(profileKey)) {
						if (isFirst) {
							isFirst = false;
							tableListForDel = tableKey;
						} else {
							tableListForDel = tableListForDel + "','" + tableKey;
							log.debug("tableListForDel > " + tableListForDel);
						}
					}
				}
				isFirst = true; // for next set
				log.debug("Final tableListForDel, isFirstProfile tableListForDel " + tableListForDel + ", " + isFirstProfile);				
				if (isFirstProfile) {
					isFirstProfile = false;
					oPLT.append("SELECT" + " DISTINCT(ENTITY)");
					oPLT.append(" FROM YFS_ENTITY_CHANGE");
					oPLT.append(" WHERE ENTITY IN ('" + tableListForDel
							+ "') AND DB_OPERATION IN ('INSERT','DELETE','UPDATE')" + " AND MODIFYTS BETWEEN to_date(\'"
							+ profileAndLastSyncMasterDate.get(profileKey) + "\'," + "\'"
							+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
							+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
					log.debug("Query being fired fireSqlForDeleteUpdate-1 " + oPLT.getReadableWhereClause());
				} else {					
					oPLT.append(" UNION SELECT" + " DISTINCT(ENTITY)");
					oPLT.append(" FROM YFS_ENTITY_CHANGE");
					oPLT.append(" WHERE ENTITY IN ('" + tableListForDel
							+ "') AND DB_OPERATION IN ('INSERT','DELETE','UPDATE')" + " AND MODIFYTS BETWEEN to_date(\'"
							+ profileAndLastSyncMasterDate.get(profileKey) + "\'," + "\'"
							+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
							+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
					log.debug("Query being fired fireSqlForDeleteUpdate-2 " + oPLT.getReadableWhereClause());
				}
				Document docCommonCodeList = callGetCommonCodeList(ctx, TEMPORARY_USERGROUP);
				Element eleCommonCodeList = docCommonCodeList.getDocumentElement();

				NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
				String strTempManagerList = "(";
				for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
					Element eleCommonCode = ((Element) nodeListCommonCode.item(i));	
					strTempManagerList = strTempManagerList + "\'" 
											+ eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE) + "\',";
					log.debug("TEMPORARY_USERGROUP Common Code Value and Short Desc "
								+ eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE));
					}
				strTempManagerList = strTempManagerList.substring(0,strTempManagerList.length()-1);
				strTempManagerList = strTempManagerList + ")";
			
				if (profileKey.equalsIgnoreCase("P_USER_D")) {
					tempMgrQuery = "select \'\' || trim(USER_KEY) || \'\'||\',\' || trim(USERGROUP_KEY) || \'\' || \'\'"
							+ " AS RESULT FROM YFS_USER_GROUP_LIST WHERE USERGROUP_KEY IN " 
							+ strTempManagerList + " AND MODIFYTS BETWEEN to_date(\'"
							+ profileAndLastSyncMasterDate.get(profileKey) + "\'," + "\'"
							+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
							+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')";
					log.info("Temp SQL query formed " + tempMgrQuery);
				}				                                                                                                                                                         
			}
			log.info("Query being fired fireSqlForDeleteUpdate " + oPLT.getReadableWhereClause());
			ArrayList<String> finalListDeleteUpdate = fireSqlForDeleteUpdate(ctx, oPLT);
			timeTablesGroup.clear(); // to store time and its table list
			tableListToGetTableSpace = ""; // to clear the previous data on re-run
			String tableListForDelete = KohlsPOCConstant.A_SINGLE_QUOTE
					+ finalListDeleteUpdate.toString().replace("[", "").replace("]", "").replace(", ", "','")
					+ KohlsPOCConstant.A_SINGLE_QUOTE;
			log.debug("Tables list to delete is  " + tableListForDelete);
			if (finalListDeleteUpdate.size() == 0) {
				log.debug("Tables list to delete update insert is empty");
				return null;
			} else {
				//if(strImportType.equals(KohlsPOCConstant.A_INSTANT)){
					tableListToGetTableSpace = tableListForDelete;
				/*} else if(strImportType.equals(KohlsPOCConstant.A_INSTANT)){
					tableListToGetTableSpace = tableListForDelete;
				}*/
				exportProfilesList.clear(); // clear the arraylist start
				for (String entityTable : finalListDeleteUpdate) {
					for (String table : actTableProfileList.keySet()) {
						if (table.equalsIgnoreCase(entityTable)) {
							log.debug("Adding the entity entry table profiles " + actTableProfileList.get(table));
							exportProfilesList.add(actTableProfileList.get(table));
						}
					}
				}
			}
			
			for (String profileFromProfTimeStamp : profileAndLastSyncMasterDate.keySet()) {
				String tablesList = "";
				String finalDate = "";
				log.debug("profileFromProfTimeStamp profile is " + profileFromProfTimeStamp + " TimeStamp : " + actTableProfileList.get(profileFromProfTimeStamp));
				for (String tableFromProfTable : actTableProfileList.keySet()) {
					if (actTableProfileList.get(tableFromProfTable).equalsIgnoreCase(profileFromProfTimeStamp)) {
						log.debug("tableFromProfTable table is " + tableFromProfTable + ", profileFromProfTimeStamp is " + profileFromProfTimeStamp + ", Timestamp from profile "
						 + profileAndLastSyncMasterDate.get(profileFromProfTimeStamp));
						for (int ii = 0; ii < finalListDeleteUpdate.size(); ii++) {
							log.debug("Final list table name is " + finalListDeleteUpdate.get(ii).toString());
							if (finalListDeleteUpdate.get(ii).toString().equalsIgnoreCase(tableFromProfTable)) {
								finalDate = profileAndLastSyncMasterDate.get(profileFromProfTimeStamp);
								if (YFCCommon.isVoid(tablesList)) {
									tablesList = tableFromProfTable ;
								} else {
									tablesList = tablesList + "','" + tableFromProfTable;
								}
								 log.debug("Forming the table list for the same profile > " + finalDate + ", " + tablesList);
							}
						}						 
					}
				}
				if (!YFCCommon.isVoid(finalDate) && !YFCCommon.isVoid(tablesList)) {
					log.debug("Formed time stamp and table list " + finalDate + ", " + tablesList);
					if (!isFirstTableRead) {
						QUERY_MASTER = QUERY_MASTER + "YFS_ENTITY_CHANGE:" + "\""
								+ "WHERE DB_OPERATION IN ('INSERT','DELETE','UPDATE')" + " AND ENTITY in (\'" + tablesList
								+ "\') AND TABLE_TYPE=\'MASTER\' AND MODIFYTS BETWEEN to_date(\'" + finalDate + "\'," + "\'"
								+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
								+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')";
						timeTablesGroup.put(profileFromProfTimeStamp, finalDate + ";" + tablesList);
						log.debug("Entry to timeTablesGroup " + profileFromProfTimeStamp + ", " + finalDate + ";"
								+ tablesList);
						isFirstTableRead = true;
					} else {
						QUERY_MASTER = QUERY_MASTER
								+ " UNION SELECT * FROM YFS_ENTITY_CHANGE WHERE DB_OPERATION IN ('INSERT','DELETE','UPDATE')"
								+ " AND ENTITY IN (\'" + tablesList
								+ "\') AND TABLE_TYPE=\'MASTER\' AND MODIFYTS BETWEEN to_date(\'" + finalDate + "\'," + "\'"
								+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\',"
								+ "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')"; 
						timeTablesGroup.put(profileFromProfTimeStamp, finalDate + ";" + tablesList);
						log.debug("Entry to timeTablesGroup " + profileFromProfTimeStamp + ", " + finalDate + ";"
								+ tablesList);
						}
				}
				log.debug("INSERT UPDATE DELETE for each entry " + QUERY_MASTER);
			}

			String QUERY_MASTER_DELETE = QUERY_MASTER + "\"";
			log.info("INSERT UPDATE DELETE query par entry is " + QUERY_MASTER_DELETE);
			parFile = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY)
					+ KohlsPOCConstant.BACKWARD_SLASH + KohlsPOCConstant.DELETE_UPDATE + KohlsPOCConstant.UNDERSCORE
					+ KohlsPOCConstant.QUERY_PAR_FILE + KohlsPOCConstant.DOT_PAR;
			tableListMaster = KohlsPOCConstant.YFS_ENTITY_CHANGE;

			FileWriter writer = new FileWriter(parFile);
			writer.write(QUERY_MASTER_DELETE);
			log.debug("Created par file for delete and update" + parFile);
			writer.close();
			stagedQueryPar = QUERY_MASTER_DELETE;
			if (YFCCommon.isVoid(tempMgrQuery)) {
				log.info("There are no changes for temp mgr role");
			}else{
				tempMgrSqlGenerator(ctx, tempMgrQuery);
			}
		}
		log.debug("Dump file name is " + dumpFileName + " " + sImportType + " " + dumpType);

		String parStagedFile = "";
		if ((DELTA_TYPE_STAGED.equalsIgnoreCase(sImportType) && KohlsPOCConstant.INSERT_UPDATE.equalsIgnoreCase(dumpType))
				&& KohlsPOCConstant.YES.equalsIgnoreCase(partitionEnabled)) {
			String STGtableListMaster = tableListMaster;
			String STGToOrgTableMAPList = "";
			String[] STGtableListMasterSplit = STGtableListMaster.split(",");
			String OrgTableMAPName = "";

			//clear the Exported STG Gobal variable
			exportProfilesSTGTableList = "";
			
			for (int iKey = 0; iKey < STGtableListMasterSplit.length; iKey++) {
				for (String key :  getActiveTableSTGMapList.keySet()) {
				    if (key.equals(STGtableListMasterSplit[iKey])) {
						OrgTableMAPName = key;
				    	log.info("Key i.e. Table value"+ key);
		                break;
		            }
				}

				if (iKey == STGtableListMasterSplit.length-1 ) 
				{
					STGToOrgTableMAPList += getActiveTableSTGMapList.get(OrgTableMAPName) + "_" + podType;
					exportProfilesSTGTableList += OrgTableMAPName + ":" + getActiveTableSTGMapList.get(OrgTableMAPName)
							+ "_" + podType;
				}
				else
				{
					STGToOrgTableMAPList += getActiveTableSTGMapList.get(OrgTableMAPName) + "_" + podType + ",";
					exportProfilesSTGTableList += OrgTableMAPName + ":" + getActiveTableSTGMapList.get(OrgTableMAPName)
							+ "_" + podType + ",";
				}
			}
			
			tableListMaster = STGToOrgTableMAPList;
			
			log.info("Merged table list " + tableListMaster + ", Procedure size " + tablesProcs.size());
			KohlsDeltaDataPumpMergeUtil mergeUtil = new KohlsDeltaDataPumpMergeUtil();
			for (String proc : tablesProcs) {
				mergeUtil.populateDeltaRecordsToExpTables(ctx, proc);
			}
		}else {
			parStagedFile = " PARFILE=" + parFile;
		}
		//Remapping entity change table to temp table for ranking entity : CPE-13106
		if ((DELTA_TYPE_STAGED.equalsIgnoreCase(sImportType) && KohlsPOCConstant.DELETE_UPDATE.equalsIgnoreCase(dumpType))
				&& KohlsPOCConstant.NO.equalsIgnoreCase(partitionEnabled)) {
			KohlsDeltaDataPumpMergeUtil mUtil = new KohlsDeltaDataPumpMergeUtil();
			mUtil.populateEntityChanges(ctx, stagedQueryPar, sUserName, podType);
			tableListMaster = KohlsPOCConstant.YFS_ENTITY_CHANGE + "_" + podType;
			parStagedFile = "";
			exportProfilesSTGTableList = KohlsPOCConstant.YFS_ENTITY_CHANGE + ":" + tableListMaster;
		}

		KohlsDeploymentUtil dpUtil = new KohlsDeploymentUtil();
		boolean oraFileEntry = dpUtil.checkTnsNamesOraEntries();
		if (oraFileEntry) {
			statement = KohlsPOCConstant.EXPORT_CMD + " " + sUserName + KohlsPOCConstant.BACKWARD_SLASH + sPassword
					+ KohlsPOCConstant.AT + KohlsPOCConstant.OMSR_CORP_HOST + " TABLES=" + tableListMaster
					+ " directory=data_pump_export_directory" + " dumpfile=" + dumpFileName + " logfile=" + logfile
					+ parStagedFile;
		} else {
			statement = KohlsPOCConstant.EXPORT_CMD + " " + sUserName + KohlsPOCConstant.BACKWARD_SLASH + sPassword
					+ KohlsPOCConstant.AT + "\"" + jdbcURL + "\"" + " TABLES=" + tableListMaster
					+ " directory=data_pump_export_directory" + " dumpfile=" + dumpFileName + " logfile=" + logfile					
					+ parStagedFile;
		}
		String strippedStatement = statement.replaceAll(KohlsPOCConstant.REGEX_PASSWORD,
				KohlsPOCConstant.REGEX_REPLACEMENT);
		log.info("Execute statement is " + strippedStatement);
		statementExecution(statement, dumpFileName, logfile, KohlsPOCConstant.DB_DELTA_EXPORT);
		File parSource = new File(parFile); // Par move to Done
		File parTarget = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + sImportType + KohlsPOCConstant.UNDERSCORE 
				+ dumpType + KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_PAR);
		moveErrorFiles(parSource, parTarget);
		//boolean result = Files.deleteIfExists(file.toPath());
		//log.debug("Par file deleted " + result);
		return actTableProfileList;
	}

		
	private HashMap<String, String> getActiveTableAndProfile(Document docCommonCodeList) {
		log.info("Enter getActiveTableAndProfile() :: Checking the active profile");
		//String delayedProfile = "P_CATALOG__D";
		HashMap<String, String> tableAndProfileId = new HashMap<String, String>();
		//HashMap<String, String> delayedTableAndProfileId = new HashMap<String, String>();
		String strProfile = "", strStatus = "", strTable = "";
		Element eleCommonCodeList = docCommonCodeList.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			strTable = eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE).trim();
			strStatus = eleCommonCode.getAttribute(KohlsConstants.CODE_LONG_DESC).trim();
			strProfile = eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION).trim();
			log.debug("strProfile  is " + strProfile);
			if (KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(strStatus)) {
				if (strTable.equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
					cdtProfileActive = true;
					log.info("Configuration profile is active " + cdtProfileActive);
				} else {
					/*if (delayedProfile.equalsIgnoreCase("delayedProfile")) {
						delayedTableAndProfileId.put(strTable, strProfile);
					} else {*/
						tableAndProfileId.put(strTable, strProfile);
					//}
					log.debug("Active profile is " + cdtProfileActive);
				}
			} else {
				log.info("Inactive profile is " + strProfile);
				if (strTable.equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
					cdtProfileActive = false;
					log.info("Configuration profile is inactive " + cdtProfileActive);
				}
			}
		}
		return tableAndProfileId;
	}

	
	// Temp mgr sql file writer
	private void tempMgrSqlGenerator(YFSContext ctx, String tempMgrSql) throws Exception {
		log.info("Enter tempMgrSqlGenerator() :: Starting the temp mgr sql formation");
		String partitionID = ctx.getPoolResolver().pushPartition("tempMgrSqlGenerator");
		ctx.getPoolResolver().addFact(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
		log.debug("tempMgrSqlGenerator query being fired " + tempMgrSql);
		
		String tmpMgrFile = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + profileDeltaTypeMap.get(KohlsPOCConstant.P_USER_D) 
				+ KohlsPOCConstant.UNDERSCORE + TMP_MNGR_ROLE + 
				KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.TXT;
		try {
			stmt = ctx.getConnectionForTable(YFS_User_Group_ListDBHome.getInstance().getTableName()).createStatement();
			ResultSet rs = stmt.executeQuery(tempMgrSql);
			FileWriter writer = null;
			boolean bFileWriter = true;
			
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			StringBuffer bfr = new StringBuffer();
			for (int i = 1; i <= columnsNumber; i++) {
				if (i != 1)
					bfr.append(",  ");
				bfr.append(rsmd.getColumnName(i));
			}
			int ii = 1;
			StringBuffer bfr1 = new StringBuffer();
			while (rs.next()) {
				bfr1.setLength(0);
				if(bFileWriter){
					writer = new FileWriter(tmpMgrFile);
					bFileWriter = false;
				}
				for (int i = 1; i <= columnsNumber; i++) {
					if (i != 1)
						bfr1.append(",  ");

					bfr1.append(rs.getString(i));
					
				}
				writer.write(bfr1.toString() + "\n");
				log.debug("Temp role keys formed " + bfr1.toString());
				writer.write("/" + "\n");		
				ii++;
			}
			if(writer != null){
				writer.close();
			}
			rs.close();			
		} catch (Exception ex) {
			log.error("Error occurred in tempMgrSqlGenerator");
			throw ex;
		} finally {		
			log.info("fireSqlQuery tempMgrSqlGeneratorending closing");
			YFSDBHome.closeStatement(stmt);
			log.debug("Popping partitionID " + partitionID);
			ctx.getPoolResolver().popPartition(partitionID);
		}		
	}
	
	
	private ArrayList<String> fireSqlQueryForInsertUpdate(YFSContext ctx, PLTQueryBuilder oPLT, String strCurrentDate)
			throws Exception {
		log.info("Enter fireSqlQueryForInsertUpdate() :: Checking for insert and update changes");
		String partitionID = ctx.getPoolResolver().pushPartition("fireSqlQueryForInsertUpdate");
		ctx.getPoolResolver().addFact(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
		ArrayList<String> entityList = new ArrayList<String>();
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.debug("Executing SQL fireSqlQueryForInsertUpdate " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			while (rs.next()) {
				log.debug("Entered rs.next() entity is " + rs.getString(KohlsPOCConstant.A_ENTITY).trim());
				entityList.add(rs.getString(KohlsPOCConstant.A_ENTITY).trim());
			}
			rs.close();
			return entityList;
		} catch (Exception ex) {
			log.error("Error occurred in fireSqlQueryForInsertUpdate");
			throw ex;
		} finally {
			log.debug("fireSqlQueryForInsertUpdate ending");
			YFSDBHome.closeStatement(stmt);
			log.debug("Popping partitionID fireSqlQueryForInsertUpdate " + partitionID);
			ctx.getPoolResolver().popPartition(partitionID);
		}
	}
	
	private ArrayList<String> fireSqlForDeleteUpdate(YFSContext ctx, PLTQueryBuilder oPLT)
			throws Exception {
		log.info("Enter fireSqlForDeleteUpdate() :: Checking for delete and update changes");
		String partitionID = ctx.getPoolResolver().pushPartition("fireSqlForDeleteUpdate");
		ctx.getPoolResolver().addFact(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);		
		log.debug("Query being fired for fireSqlForDeleteUpdate " + oPLT.getReadableWhereClause());
		ArrayList<String> entityList = new ArrayList<String>();
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.debug("Executing SQL " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));

			while (rs.next()) {
				log.debug("Entered rs.next() entity is " + rs.getString(KohlsPOCConstant.A_ENTITY).trim());
				entityList.add(rs.getString(KohlsPOCConstant.A_ENTITY).trim());
			}
			rs.close();
			return entityList;
		} catch (Exception ex) {
			log.error("Error occurred in fireSqlForDeleteUpdate");
			throw ex;
		} finally {
			log.debug("fireSqlForDeleteUpdate ending");
			YFSDBHome.closeStatement(stmt);
			log.debug("Popping partitionID fireSqlForDeleteUpdate " + partitionID);
			ctx.getPoolResolver().popPartition(partitionID);
		}
	}

	private Document callGetColonyPoolList(YFSEnvironment env) throws Exception {
		Document docGetColonyPoolListOutput = null;
		try {
			log.info("Enter callGetColonyPoolList() :: Getting the Colony pool list");
			Document docGetColonyPoolListInput = YFCDocument.createDocument(KohlsPOCConstant.E_COLONY_POOL)
					.getDocument();
			Element eleColonyPoolInput = docGetColonyPoolListInput.getDocumentElement();
			eleColonyPoolInput.setAttribute(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
			log.debug("docGetColonyPoolListInput is " + SCXmlUtil.getString(docGetColonyPoolListInput));
			docGetColonyPoolListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COLONY_POOL_LIST,
					docGetColonyPoolListInput);
		} catch (Exception e) {
			log.error("Error in callGetColonyPool " + e.getMessage() + e.getStackTrace());
			throw e;
		}
		return docGetColonyPoolListOutput;
	}
	
	private void handleDeleteUpdateEntries(String sUserName, String sPassword, String jdbcURLSplit, YFSEnvironment env,
			String deltaName)
			throws Exception {
		log.info("Enter handleDeleteUpdateEntries() :: Starting the database changes");
		YCPContext ctx = (YCPContext) env;
		Collection<String> trimTableList = filterTableList(ctx, KohlsPOCConstant.DELETE_UPDATE);
		statsTableList.clear();
		PreparedStatement pstmt = null;
		String dbOperation = "";
		String isDeleteEnabled = YFSSystem.getProperty(KohlsPOCConstant.DELTA_RECORDS_DELETE_ENABLED);

		if (deltaName.contains(KohlsPOCConstant.A_STAGED) && KohlsPOCConstant.NO.equalsIgnoreCase(isDeleteEnabled)) {
			dbOperation = " AND DB_OPERATION='DELETE'";
			log.debug("Merge is enabled for Deletes only");
		}

		for (String strEntity : trimTableList) {					
			EntityRepository entityRepos = (EntityRepository) YFCEntityRepositoryImpl.getInstance();
			Entity e1 = entityRepos.getEntityFromTableName(strEntity);
			String primaryKey = e1.getPrimaryKeyAttributes()[0].getColumnName(); //Get the primary key from entity name
			try {
				StringBuffer deleteStmt = new StringBuffer(
				"DELETE FROM " + strEntity + " WHERE " + primaryKey 
								+ " IN ( SELECT ENTITY_KEY FROM YFS_ENTITY_CHANGE WHERE ENTITY='" + strEntity + "'" + dbOperation + ")");
				log.info("Query being fired during handleDeleteUpdate " + deleteStmt);
				pstmt = ctx.getConnection().prepareStatement(deleteStmt.toString());
				int euRetVal = 0;
				euRetVal = pstmt.executeUpdate();
				log.debug("Delete handleDeleteUpdateEntries query return value is " + euRetVal);
			} catch (SQLException ex) {
				throw ex;
			}finally{
				log.debug("handleDeleteUpdateEntries ending");
				YFSDBHome.closeStatement(pstmt);
				if(!pstmt.isClosed()){
					pstmt.close();
				}
			}
		}
		statsTableList.addAll(trimTableList);
	}

	private ArrayList<String> fireSQLToGetDistinctEntities(YCPContext ctx, String operationType) throws SQLException {
		PLTQueryBuilder selectStatement = new PLTQueryBuilder(false);
		selectStatement.append("SELECT" + " DISTINCT(ENTITY)");
		selectStatement.append(" FROM YFS_ENTITY_CHANGE");
		if (operationType.equals(KohlsPOCConstant.INSERT_UPDATE)) {
			selectStatement.append(" WHERE DB_OPERATION in ('INSERT','UPDATE')");
		}
		log.debug("Query being fired " + selectStatement.getReadableWhereClause());

		ArrayList<String> entityList = new ArrayList<String>();
		try {
			stmt = ctx.getConnection().createStatement();
			log.debug("Executing SQL: " + selectStatement.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(selectStatement.getReadableWhereClause(false));

			while (rs.next()) {
				log.debug("Entered rs.next() entity is " + rs.getString("ENTITY").trim());
				entityList.add(rs.getString("ENTITY").trim());
			}
			rs.close();
			return entityList;
		} catch (Exception ex) {
			throw ex;
		} finally {
			log.debug("fireSQLToGetDistinctEntities ending");
			YFSDBHome.closeStatement(stmt);
			if (!stmt.isClosed()) {
				stmt.close();
			}
		}
	}

	public void callManageSyncDBImport(YFSEnvironment env, File dumpFilePath) throws Exception {
		log.info("Enter callManageSyncDBImport() :: Update the import changes to database");

		for (File f : dumpFilePath.listFiles()) {
			if (f.getName().startsWith(KohlsPOCConstant.STG_SYNC_VER)) {
				catalogRecordCount((YFSContext) env, ISS_SCHEMA);
			}
		}
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
		String syncDBDate = sdf.format(yfcCurrntDt);
		ArrayList<Element> profileListFromFile = SCXmlUtil
				.getChildren(getSyncVersionDocument(dumpFilePath).getDocumentElement(), KohlsPOCConstant.E_PROFILE);
		log.debug("prifleList size " + profileListFromFile.size());
		for (Element profileFile : profileListFromFile) {
			Document docManageImportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_IMPORT)
					.getDocument();
			Element eleManageImportSyncDB = docManageImportSyncDB.getDocumentElement();
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_DB_IMPORT_TIME, syncDBDate);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_OPERATION, KohlsPOCConstant.MANAGE);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_PROFILE_ORG_CODE,
					profileFile.getAttribute(KohlsPOCConstant.A_ORG_CODE));
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID,
					profileFile.getAttribute(KohlsPOCConstant.A_NAME));
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID,
					YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP));

			String strSequenceNoImport = profileFile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
			
			// For Store Delta Sync
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_DELTA);
			eleManageImportSyncDB.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, strSequenceNoImport);
			log.debug("ManageSyncDBImport Store input is " + XMLUtil.getXMLString(docManageImportSyncDB));
			KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MANAGE_SYNC_DB_IMPORT, docManageImportSyncDB);

			// For Corp Delta Sync
			Document manageSyncDBImportOutdoc = null;
			Element eleAdditionalInfo = SCXmlUtil.createChild(eleManageImportSyncDB,
					KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
			eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
			log.debug("ManageSyncDBImport MotherShip input is " + XMLUtil.getXMLString(docManageImportSyncDB));
			Document remoteOutDoc = callApi(env, docManageImportSyncDB, manageSyncDBImportOutdoc, KohlsPOCConstant.V_MOTHERSHIP,
					KohlsPOCConstant.API_MANAGE_SYNC_DB_IMPORT);
			NodeList nodeListCommonCode = remoteOutDoc.getElementsByTagName(KohlsPOCConstant.E_ERROR);
			if (nodeListCommonCode.getLength() > 0) { // remote call failure
				throw new YFCException("Exception in manageSyncDBImport " + SCXmlUtil.getString(remoteOutDoc));
			}
			/*File donePath = findDoneDir(dumpFilePath.getAbsolutePath());
			log.info("Moving the sync xml file to done directory " + " " + dumpFilePath.getName());
			filterFiles(dumpFilePath, donePath, "SyncVersion");*/ //moved to profile handling to Code
		}
	}

	private Document getSyncVersionDocument(File dumpFilePath) throws Exception {
		Document docSyncVersion = null;
		File[] files = dumpFilePath.listFiles();
		String dumpFileName;
		log.info("Enter getSyncVersionDocument() :: Getting the Sync version");
		for (File f : files) {
			dumpFileName = f.getName();
			log.debug("Import file name for configuration is " + dumpFileName);
			if (dumpFileName.contains(KohlsPOCConstant.V_SYNC_VERSION)) {
				docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(f);
				break;
			}
		}
		return docSyncVersion;
	}

	public void processAndDelEmptyDir(YFSEnvironment env, File filesPath) throws Exception {
		if (filesPath.isDirectory() & filesPath.listFiles().length > 0) {
			File errorFiles[] = dirListByName(filesPath);
			for (File errFileDir : errorFiles) {
				log.info("Found files under " + errFileDir);
				setPermission(errFileDir);
				if (errFileDir.listFiles().length > 0) {
					processDumpFiles(env, errFileDir);
				}				
				if (errFileDir.isDirectory()) {
					if (errFileDir.list().length == 0) {
						log.debug("Deleting the empty directory " + errFileDir);
						errFileDir.delete();
					} else {
						log.debug("Directory is not empty" + errFileDir);
					}
				}
			}
		} else {
			log.debug("No files to process under " + filesPath);
		}
	}

	private void readDumpFilesAndImportTables(YFSEnvironment env, String inProgressPath, String errorPath)
			throws Exception {
		KohlsDeploymentUtil deployUtil = new KohlsDeploymentUtil();
		try {
			log.info("Enter readDumpFilesAndImportTables() :: Read and import files under Error directory " + errorPath);
			File errFilePath = new File(errorPath);
			processAndDelEmptyDir(env, errFilePath);
			log.info("Read and import files under inProgress directory " + inProgressPath);
			File inPrgFileDir = new File(inProgressPath);
			processAndDelEmptyDir(env, inPrgFileDir);
			/*//Calling the DB procedure
			statsProcedureConstruction(env);*/
			deployUtil.callModifyCache(env);
		} catch (Exception e) {
			log.error("Moving the files to resp error directory from " + inProgressPath);
			File inPrgFileDir = new File(inProgressPath);
			Date date = new Date();
			if (inPrgFileDir.listFiles().length > 0) {
				for (File fle : inPrgFileDir.listFiles()) {
					log.debug(date.toString() + " Moving the files " + fle);
					exceptionFileMove(fle.toString(), errorPath);
				}
			}
			YFCException exp = new YFCException(e);
			String err = exp.getContainedException().toString();
			log.error("Exception in readDumpFilesAndImportTables " + exp.getLastErrorCode() + exp.getContainedException().toString());
			raiseAlert(env, KohlsPOCConstant.DB_DELTA_IMPORT, err); // added bcz of throw is commented here
			log.info("Clearing cache after moving to error folder");
			deployUtil.callModifyCache(env);
			log.info("Cache clear completed.");
			// throw e; to process rest of the deltas
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static File[] dirListByName(File errFilesPath) throws Exception {
		log.info("Enter dirListByName() :: Processing directory list " + errFilesPath);
		if (!errFilesPath.isDirectory()) {
			log.error("Error file path is not a directory " + errFilesPath);
			return null;
		}
		File fileList[] = errFilesPath.listFiles();
		Arrays.sort(fileList, new Comparator() {
			public int compare(final Object o1, final Object o2) {
				return new Long(((File) o1).getName()).compareTo(new Long(((File) o2).getName()));
			}
		});
		return fileList;
	}

	public boolean processDumpFiles(YFSEnvironment env, File dmpFilePath) throws Exception {
		log.info("Enter processDumpFiles() :: Processing the dump files");
		actionName = KohlsPOCConstant.A_IMPORT;
		timeStamp = new SimpleDateFormat(KohlsPOCConstant.READ_DUMP_FILES_DATE_FORMAT).format(new java.util.Date());
		Properties JDBCProperties = loadPropertiesFromAbsoluteLocation(
				YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
		String sPoolID = YFSSystem.getProperty(KohlsPOCConstant.A_POOL_ID);
		log.debug("Pool id is " + sPoolID);
		String sUserName = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.USER);
		String sPassword = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.PASSWORD);
		String sUrl = JDBCProperties.getProperty(sPoolID + KohlsPOCConstant.DOT + KohlsPOCConstant.URL);
		String[] jdbcURLSplit = sUrl.split(KohlsPOCConstant.AT);
		
		String dumpFileName = null;
		String tableList = null;
		String implogfile = null;
		String tempMgrFile = null;
		boolean isDeleteUpdateImportPending = false;
		boolean zeroINSUPDDMPFlag = false;
		boolean zeroDELUPDDMPFlag = false;
		boolean cdtXMLFlag = false, syncVerFlag = false;
		String insUpdName = null, delUpdName = null;
		String tableSpacesList = "";
		File filesList[] = dmpFilePath.listFiles();
		String syncVersionFileName = "";
		for (File f : filesList) {
			dumpFileName = f.getName();
			log.info("Files under source directory is " + dumpFileName);
			if (dumpFileName.contains(KohlsPOCConstant.INSERT_UPDATE)
					&& dumpFileName.toString().endsWith(KohlsPOCConstant.DOT_DMP)) {
				log.debug("Insert and Update dump file is " + dumpFileName);
				insUpdName = dumpFileName;
			} else if (dumpFileName.contains(KohlsPOCConstant.DELETE_UPDATE)
					&& dumpFileName.toString().endsWith(KohlsPOCConstant.DOT_DMP)) {
				isDeleteUpdateImportPending = true;
				log.debug("Delete and Update dump file is " + dumpFileName);
				delUpdName = dumpFileName;
			} else if (dumpFileName.contains(KohlsPOCConstant.ZERO_INS_UPD_DMP)) {
				f.delete();
				zeroINSUPDDMPFlag = true;
				log.debug("Insert and Update contains zero changes  " + dumpFileName +  "," + zeroINSUPDDMPFlag );
			} else if (dumpFileName.contains(KohlsPOCConstant.ZERO_DEL_UPD_DMP)) {
				f.delete();
				zeroDELUPDDMPFlag = true;
				log.debug("Delete and Update contains zero changes " + dumpFileName + ", " + zeroDELUPDDMPFlag);
			} else if (dumpFileName.contains(KohlsPOCConstant.CDT_FILE)) {
				log.debug("CDTXml file is " + dumpFileName);
				if (dumpFileName.contains(KohlsPOCConstant.ZERO_CDT_ZIP)) {
					f.delete();
				} else {
					cdtXMLFlag = true;
				}
			} else if (dumpFileName.contains(KohlsPOCConstant.V_SYNC_VERSION)) {				
				syncVersionFileName = dumpFileName;
				log.debug("Sync file is " + syncVersionFileName);
				BufferedReader readLn = new BufferedReader(new FileReader(f.getAbsoluteFile()));
				if (readLn.readLine() == null) {
					log.info("Switch is OFF ");
					f.delete();
				}else{
					log.debug("Switch is ON ");
					syncVerFlag = true;
				}
				readLn.close();
				KohlsDeploymentUtil deployUtil = new KohlsDeploymentUtil();
				tableSpacesList = deployUtil.tableSpaceFromXmlFile(f.getAbsoluteFile());
			} else if(dumpFileName.contains(KohlsPOCConstant.DELETE_UPDATE)
					&& dumpFileName.toString().endsWith(KohlsPOCConstant.DOT_PAR)){
				String line;
				strQueryParDelete = "";
				final BufferedReader is = new BufferedReader(new FileReader(f.getAbsoluteFile()));
				while ((line = is.readLine()) != null) {
					log.debug("Query par is : " + line);
					strQueryParDelete = strQueryParDelete + line;
				}
				is.close();
			} else if (dumpFileName.contains(TMP_MNGR_ROLE) && dumpFileName.toString().endsWith(KohlsPOCConstant.TXT)) {
				tempMgrFile = f.getAbsoluteFile().toString();
				log.info("tempMgrFile absolute file path " + tempMgrFile);
			}
		}

		// tableList = tableListMaster; Prepare the ignore and add profiles
		getProfileListFromXml(env,dmpFilePath);

		if (profileUpdateToDB.size() != 0) {
			// UPDATE DELETE
			if (isDeleteUpdateImportPending && delUpdName != null) {
				if (delUpdName.contains(KohlsPOCConstant.A_INSTANT)) {
					implogfile = KohlsPOCConstant.A_INSTANT + KohlsPOCConstant.UNDERSCORE
							+ KohlsPOCConstant.DELETE_UPDATE + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.A_IMPORT
							+ KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
				} else {
					implogfile = KohlsPOCConstant.A_STAGED + KohlsPOCConstant.UNDERSCORE
							+ KohlsPOCConstant.DELETE_UPDATE + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.A_IMPORT
							+ KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
				}
				log.debug("Import log file for Delete and Update is " + implogfile);
				log.info("Delete Update changes Started for File Path -> " + dmpFilePath.getAbsolutePath() + "And File Name -> " + implogfile);
				callImpdp(env, sUserName, sPassword, jdbcURLSplit[1], tableList, delUpdName, implogfile,
						dmpFilePath.getAbsolutePath(), tableSpacesList, syncVersionFileName);
				log.info("Delete Update changes Completed");
				handleDeleteUpdateEntries(sUserName, sPassword, jdbcURLSplit[1], env, delUpdName);

				log.debug( "tempMgrFileva value is " + tempMgrFile);
				
				if (!YFCCommon.isVoid(tempMgrFile)) {
					handleDeleteWithBindingVariables(env, tempMgrFile);
				}
				
				isDeleteUpdateImportPending = false;				
			}
			// INSERT UPDATE
			if (!isDeleteUpdateImportPending && insUpdName != null) {
				if (insUpdName.contains(KohlsPOCConstant.A_INSTANT)) {
					implogfile = KohlsPOCConstant.A_INSTANT + KohlsPOCConstant.UNDERSCORE
							+ KohlsPOCConstant.INSERT_UPDATE + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.A_IMPORT
							+ KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
				} else {
					implogfile = KohlsPOCConstant.A_STAGED + KohlsPOCConstant.UNDERSCORE
							+ KohlsPOCConstant.INSERT_UPDATE + KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.A_IMPORT
							+ KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
				}
				log.debug("Import log file for Insert and Update is " + implogfile);
				log.info("Insert Update changes Started for File Path -> " + dmpFilePath.getAbsolutePath() + "And File Name -> " + implogfile);
				callImpdp(env, sUserName, sPassword, jdbcURLSplit[1], tableList, insUpdName, implogfile,
						dmpFilePath.getAbsolutePath(), tableSpacesList, syncVersionFileName);
				
				log.info("Insert Update changes Completed");
			}
			
			// Clear cache
			if ((insUpdName != null) || (delUpdName != null)) {
				KohlsDeploymentUtil clearCache = new KohlsDeploymentUtil();
				clearCache.callModifyCache(env);
			}

			if (!YFCCommon.isVoid(tempMgrFile)) {
				File donePath = findDoneDir(dmpFilePath.getAbsolutePath());
				log.info("Get the Temp User Manager xml file " + " " + dmpFilePath.getName());
				filterFiles(dmpFilePath, donePath, TMP_MNGR_ROLE);
			}
			// CDT
			if (!cdtFlagUpdate) {
				if (cdtXMLFlag) {
					log.info("CDT changes Started");
					KohlsCDTUtil cdtUtil = new KohlsCDTUtil();
					cdtUtil.importCDT(env, SCXmlUtil.createDocument(KohlsPOCConstant.DB_DELTA_IMPORT), dmpFilePath);
					log.info("CDT changes completed");
				} else {
					log.debug("No CDT files present");
				}
			} else {
				if (cdtFlagUpdate) {
					log.info("CDT process is ignored and flag is " + cdtFlagUpdate);
					File donePath = findDoneDir(dmpFilePath.getAbsolutePath());
					filterFiles(dmpFilePath, donePath, KohlsPOCConstant.CDT_XML_ZIP_FILE);
				}
			}

			// SYNC
			String deltaDeletesEnabled = YFSSystem.getProperty(KohlsPOCConstant.DELTA_RECORDS_DELETE_ENABLED);
			if ((syncVerFlag && KohlsPOCConstant.YES.equalsIgnoreCase(deltaDeletesEnabled))
					|| (syncVerFlag && syncVersionFileName.contains("INSTANT_SyncVersion"))) {
				log.info("Invoke Manage Sync DB Import version XML File");
				callManageSyncDBImport(env, dmpFilePath);
				log.info("Sync DB Import table updates completed");
				KohlsDeploymentUtil dUtil = new KohlsDeploymentUtil();
				SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
				String syncDBDate = sdf.format(expImpTimeStamp);
				String SyncVersionFile = "";
				for (File fl : dmpFilePath.listFiles()) {
					if (fl.getName().contains(KohlsPOCConstant.V_SYNC_VERSION)) {
						SyncVersionFile = dmpFilePath.getAbsolutePath() + KohlsPOCConstant.BACKWARD_SLASH
								+ fl.getName();
						log.info("SyncVersionFile is " + SyncVersionFile);
					}
				}

				if (!YFCCommon.isVoid(SyncVersionFile)) {
					Document syncVerDoc = SCXmlUtil.getDocumentBuilder().parse(SyncVersionFile);
					ArrayList<Element> profileListFromFile = SCXmlUtil.getChildren(syncVerDoc.getDocumentElement(),
							KohlsPOCConstant.E_PROFILE);
					ArrayList<String> profilesListFromXML = new ArrayList<String>();
					boolean cdtXmlVer = false;
					for (Element profileFileFromXML : profileListFromFile) {
						if (profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME)
								.equalsIgnoreCase(KohlsPOCConstant.P_CONFIGURATION_D)) {
							cdtXmlVer = true;
						} else {
							if (!(profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME)
									.equals(KohlsPOCConstant.P_USER_KR)
									|| profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME)
											.equals(KohlsPOCConstant.P_CONFIGURATION_KR)
									|| profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME)
											.equals(KohlsPOCConstant.P_CONFIGURATION_KC))) {
							profilesListFromXML.add(profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
							log.info("Profiles adding to " + profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
							}
						}
						log.info("Profiles from XML file " + profileFileFromXML.getAttribute(KohlsPOCConstant.A_NAME));
					}
					if (!profilesListFromXML.isEmpty()) {
						dUtil.manageSyncProcessRecordExpImp((YFSContext) env, KohlsPOCConstant.A_IMPORT,
								KohlsPOCConstant.SYNC_DELTA, YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP),
								KohlsPOCConstant.TABLE_TYPE_MASTER, profilesListFromXML, syncDBDate);
					}
					if (cdtXmlVer) {
						dUtil.manageSyncProcessRecordExpImp((YFSContext) env, KohlsPOCConstant.A_IMPORT,
								KohlsPOCConstant.SYNC_DELTA, YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP),
								KohlsPOCConstant.A_CONFIGURATION, profilesListFromXML, syncDBDate);
					}
					File donePath = findDoneDir(dmpFilePath.getAbsolutePath()); // moved to here
					log.info("Moving sync xml file to done directory " + " " + dmpFilePath.getName());
					filterFiles(dmpFilePath, donePath, "SyncVersion");
				}
			}						
			((YFSContext) env).commit();
			log.info("Committed the changes after processing delta");

			if (KohlsPOCConstant.NO.equalsIgnoreCase(deltaDeletesEnabled) && syncVersionFileName.startsWith("STAGED_SyncVersion")) {
				deltaCurDirPath = dmpFilePath.getAbsolutePath().toString() + "/" + syncVersionFileName;
			} else {
			//Calling the DB procedure
			statsProcedureConstruction(env);
			}
		}else{
			log.info("All the profiles in XML having lower version than Database profile versions");
			File donePath = findDoneDir(dmpFilePath.getAbsolutePath());
			filterFiles(dmpFilePath, donePath, KohlsPOCConstant.ALL_FILES);
		
			if (dmpFilePath.isDirectory() & dmpFilePath.listFiles().length == 0) {
				setPermission(dmpFilePath);
				dmpFilePath.delete();
			}
			return true;
		}
		return false;
	}
	
	// querySplitter to form the sql
	public ArrayList<String> querySplitter(String queryPath) throws Exception {
		log.info("Enter querySplitter() :: Query splitter started with queryPath " + queryPath);
		File fl = new File(queryPath);
		BufferedReader br = new BufferedReader(new FileReader(fl));
		String readLine = "";
		ArrayList<String> queryList = new ArrayList<String>();
        StringBuilder queryBuilder = new StringBuilder();
        boolean allowSpace = false;
		while ((readLine = br.readLine()) != null) {
			if (!readLine.contentEquals(KohlsPOCConstant.BACKWARD_SLASH)) {
				log.debug("Reading the sql " + readLine);
				if (allowSpace) {
					queryBuilder.append(" " + readLine.trim());
				} else {
					queryBuilder.append(readLine);
				}
				allowSpace = true;
			} else {
				queryList.add(queryBuilder.toString());
				log.debug("SQL statement formed " + queryBuilder);				
				queryBuilder.setLength(0);
				allowSpace = false;
				log.debug("SB content after clear is " + queryBuilder);
			}
			
		}
		br.close();
		return queryList;
	}
	
	public void handleDeleteWithBindingVariables(YFSEnvironment env, String absFile)
			throws Exception {
		log.info("Enter handleDeleteWithBindingVariables () :: started ");
		try {
			String[] strVariables = null;
			YFSContext ctx = (YFSContext) env;
			String deleteQry = "DELETE FROM STERLING.YFS_USER_GROUP_LIST WHERE trim(USER_KEY) = ? AND trim(USERGROUP_KEY) = ?";
			prepStmt = ctx.getConnection().prepareStatement(deleteQry);
			for (String deleteVariables : querySplitter(absFile)) {	
				strVariables = deleteVariables.split(KohlsPOCConstant.COMMA);
				log.debug("userkey: " + strVariables[0] +  ", usergroupkey: " + strVariables[1]);
				prepStmt.setString(1, strVariables[0]);
				prepStmt.setString(2, strVariables[1]);				
				int delResult = prepStmt.executeUpdate();	
				log.debug("Count of updated records is: "+delResult);				
			}
		} catch (Exception ex) {
			log.error("Error occured in delete execution of temp keys:"+ex.getMessage());
			throw ex;
		} 

		finally {
			if (prepStmt != null && !prepStmt.isClosed()) {
				prepStmt.close();
				log.info("Closed the prepared connection for delete from temp manager file");
			}
		}
	}
	
	private Document callGetCommonCodeList(YFSEnvironment env, String strSyncProfile) throws Exception {
		Document docCommonCodeListInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
		Element eleCommonCodeListInput = docCommonCodeListInput.getDocumentElement();
		eleCommonCodeListInput.setAttribute(KohlsPOCConstant.A_CODE_TYPE, strSyncProfile);
		log.debug("eleCommonCodeListInput is " + SCXmlUtil.getString(docCommonCodeListInput));

		Document docCommonCodeListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COMMON_CODE_LIST,
				docCommonCodeListInput);
		log.debug("docCommonCodeListOutput is " + SCXmlUtil.getString(docCommonCodeListOutput));
		return docCommonCodeListOutput;
	}

	private void callImpdp(YFSEnvironment env, String sUserNameMaster, String sPasswordMaster, String jdbcURLSplit,
			String tableList, String dumpFileName, String implogfile, String dmpFilePath, String tableSpacesList, String xmlFileName)
				throws Exception {
		log.info("Enter callImpdp() :: Import of dump started");
		String[] CorpUserName = dumpFileName.split(KohlsPOCConstant.UNDERSCORE);
		log.debug("File name to split is " + dumpFileName + " and value is " + CorpUserName[3]);
		createMapDir(env, KohlsPOCConstant.DB_DELTA_IMPORT, dmpFilePath);
		String statement = null;
		YCPContext ctx = (YCPContext) env;
		String tableListMaster = "";
		String tableExistsAction = "";
		String tableListOriginal = "";
		String isRankEnable = "";
		KohlsDeltaDataPumpMergeUtil mUtil = new KohlsDeltaDataPumpMergeUtil();
		String isDeleteEnabled = YFSSystem.getProperty(KohlsPOCConstant.DELTA_RECORDS_DELETE_ENABLED);
		if (xmlFileName.contains(DELTA_TYPE_STAGED)) {
			isRankEnable = KohlsDeltaDataPumpMergeUtil.checkForRankEnabled(dmpFilePath + "/" + xmlFileName);
		}

		HashMap<String, String> tableStgMap = new HashMap<String, String>();
		if (dumpFileName.contains(KohlsPOCConstant.INSERT_UPDATE)) {
			log.info("INSERT_UPDATE Dump file matches to " + dumpFileName);
			Collection<String> updateToDBList = filterTableList(ctx,KohlsPOCConstant.INSERT_UPDATE);
			if (updateToDBList.size() != 0){							
				log.info("updateToDBList is " + updateToDBList);
				boolean isFirst = true;				
				String impParams = "", remapTable = "";
				if (dumpFileName.contains(DELTA_TYPE_STAGED)) {
					log.info("Processing STAGED Dump file Name " + dumpFileName);
					remapTable = " REMAP_TABLE=";
					// Check for rank enabled and form the staged table : CPE-13106 
					if (KohlsPOCConstant.YES.equalsIgnoreCase(isRankEnable)) {
						if (KohlsPOCConstant.NO.equalsIgnoreCase(isDeleteEnabled)) {
							String stdRemapTables = "";
							HashMap<String, String> getActTableSTGMapList = KohlsDeltaDataPumpMergeUtil
									.getActiveTableSTGMap(callGetCommonCodeList(ctx, KohlsPOCConstant.DATASYNC_PROFILE));
							for (String tableNameFromList : updateToDBList) {
								log.info("Table name " + tableNameFromList);
								String stagedTable = "";
								for (String orgTable : getActTableSTGMapList.keySet()) {
									if (orgTable.trim().equals(tableNameFromList.trim())) {
										stagedTable = getActTableSTGMapList.get(orgTable).trim();
									}
								}

								if (isFirst) {
									isFirst = false;
									tableListMaster = "'" + CorpUserName[3] + "." + tableNameFromList;
									stdRemapTables = tableNameFromList + ":" + stagedTable;
								} else {
									tableListMaster = tableListMaster + "','" + CorpUserName[3] + "."
											+ tableNameFromList;
									stdRemapTables = stdRemapTables + "," + tableNameFromList + ":" + stagedTable;
								}
							}
							impParams = " TRANSFORM=SEGMENT_ATTRIBUTES:N EXCLUDE=GRANT,INDEX,CONSTRAINT,STATISTICS ";
							tableExistsAction = "TABLE_EXISTS_ACTION=REPLACE";
							remapTable = remapTable + stdRemapTables;
						} else {
							log.info("STAGED Processing dump file Name " + dumpFileName);
							for (String key : updateToDBList) {
								log.info("STAGED table name for deleted " + key);
								if (isFirst) {
									isFirst = false;
									tableListMaster = "'" + CorpUserName[3] + "." + key;
								} else {
									tableListMaster = tableListMaster + "','" + CorpUserName[3] + "." + key;
								}
							}
							impParams = " remap_tablespace=" + tableSpacesList;
							tableExistsAction = "TABLE_EXISTS_ACTION=APPEND";
							remapTable = "";
						}
					} else {
						tableStgMap = mUtil.remapTableWithSTGTables(dmpFilePath, updateToDBList);
						for (String key : tableStgMap.keySet()) {
							log.info("STAGED table name is " + key);
							if (isFirst) {
								isFirst = false;
								remapTable = remapTable + tableStgMap.get(key) + ":" + key;
								tableListMaster = "'" + CorpUserName[3] + "." + tableStgMap.get(key);

							} else {
								remapTable = remapTable + "," + tableStgMap.get(key) + ":" + key;
								tableListMaster = tableListMaster + "','" + CorpUserName[3] + "."
										+ tableStgMap.get(key);
							}
						}
						tableListOriginal = remapTable; // Assign the mapping tablelist

						if (KohlsPOCConstant.NO.equalsIgnoreCase(isRankEnable)
								&& KohlsPOCConstant.NO.equalsIgnoreCase(isDeleteEnabled)) {
							impParams = " TRANSFORM=SEGMENT_ATTRIBUTES:N";
							tableExistsAction = "TABLE_EXISTS_ACTION=REPLACE";
							remapTable = "";
						} else {
							impParams = " remap_tablespace=" + tableSpacesList;
							tableExistsAction = "TABLE_EXISTS_ACTION=APPEND";
						}
					}
				} else {
					log.info("Processing INSTANT Dump file Name " + dumpFileName);
					for (String key : updateToDBList) {
						log.info("INSTANT table name " + key);
						if (isFirst) {
							isFirst = false;
							tableListMaster = "'" + CorpUserName[3] + "." + key;
						} else {
							tableListMaster = tableListMaster + "','" + CorpUserName[3] + "." + key;
						}
					}
					impParams = " remap_tablespace=" + tableSpacesList;
					tableExistsAction = "TABLE_EXISTS_ACTION=APPEND";
				}

				if (isFirst == false) {
					tableListMaster = tableListMaster + "'";
				}
			
				log.info("Final Import Master table list(s) are " + tableListMaster);
				statement = KohlsPOCConstant.IMPORT_CMD + " " + sUserNameMaster + KohlsPOCConstant.BACKWARD_SLASH
						+ sPasswordMaster + KohlsPOCConstant.AT + "\"" + jdbcURLSplit + "\""
						+ " directory=data_pump_import_directory " + tableExistsAction + " TABLES=" + tableListMaster
						+ " dumpfile=" + dumpFileName + " logfile=" + implogfile + " remap_schema=" + CorpUserName[3]
						+ ":" + sUserNameMaster + " TRANSFORM=DISABLE_ARCHIVE_LOGGING:Y"
						+ " JOB_NAME=INSERT_" + timeStamp + impParams + remapTable;
				String strippedStatement = statement.replaceAll(KohlsPOCConstant.REGEX_PASSWORD,
						KohlsPOCConstant.REGEX_REPLACEMENT);
				log.debug("Import is inprogress and command is " + strippedStatement);	
				 statementExecution(statement, dumpFileName, implogfile, KohlsPOCConstant.DB_DELTA_IMPORT);
			}else{
				log.info("No profiles to import in the dump");
			}
		} else {
			tableExistsAction = "TABLE_EXISTS_ACTION=TRUNCATE";
			statement = KohlsPOCConstant.IMPORT_CMD + " " + sUserNameMaster + KohlsPOCConstant.BACKWARD_SLASH
					+ sPasswordMaster + KohlsPOCConstant.AT + "\"" + jdbcURLSplit + "\""
					+ " directory=data_pump_import_directory " + tableExistsAction + " dumpfile=" + dumpFileName
					+ " logfile=" + implogfile + " remap_schema=" + CorpUserName[3] + ":" + sUserNameMaster					
					+ " TRANSFORM=DISABLE_ARCHIVE_LOGGING:Y TRANSFORM=SEGMENT_ATTRIBUTES:N " +" JOB_NAME=DELETE_"+ timeStamp ;
			// Remapping the table : CPE-13106
			if (dumpFileName.contains(DELTA_TYPE_STAGED) && KohlsPOCConstant.YES.equalsIgnoreCase(isRankEnable)) {
				Collection<String> etyTable = new HashSet<String>();
				etyTable.add(KohlsPOCConstant.YFS_ENTITY_CHANGE);
				tableStgMap = mUtil.remapTableWithSTGTables(dmpFilePath, etyTable);
				statement = statement + " REMAP_TABLE=" + tableStgMap.get(KohlsPOCConstant.YFS_ENTITY_CHANGE) + ":"
						+ KohlsPOCConstant.YFS_ENTITY_CHANGE;
			}
			String strippedStatement = statement.replaceAll(KohlsPOCConstant.REGEX_PASSWORD,
					KohlsPOCConstant.REGEX_REPLACEMENT);
			log.debug("Import is inprogress and command is " + strippedStatement);				
			 statementExecution(statement, dumpFileName, implogfile, KohlsPOCConstant.DB_DELTA_IMPORT);
		}

		File sour = new File(dmpFilePath + KohlsPOCConstant.BACKWARD_SLASH);
		File donePath = null;
		donePath = findDoneDir(dmpFilePath);
		
		String fileType = CorpUserName[1] + KohlsPOCConstant.UNDERSCORE + CorpUserName[2];
		if( ! fileType.contains(KohlsPOCConstant.DELETE_UPDATE)){
			filterFiles(sour, donePath, KohlsPOCConstant.INSERT_UPDATE);
			filterFiles(sour, donePath, KohlsPOCConstant.DELETE_UPDATE);
		}		
		if (sour.isDirectory() & sour.listFiles().length == 0) {
			setPermission(sour);
			sour.delete();
		}
		partitionTableList = "";
		tableListMappingStg = "";
		if (KohlsPOCConstant.NO.equalsIgnoreCase(isRankEnable)) {
			partitionTableList = tableListMaster;
			tableListMappingStg = tableListOriginal.replace("REMAP_TABLE=", "");
		}
	}
	
	public Collection<String> filterTableList(YCPContext ctx, String operationType) throws Exception {
		ArrayList<String> entityList = fireSQLToGetDistinctEntities(ctx, operationType);
		Document docCommonCodeList = callGetCommonCodeList(ctx, KohlsPOCConstant.DATASYNC_PROFILE);
		ArrayList<String> tableListToIgnore = getValueAndDescMapForProfile(docCommonCodeList, profileToIgnoreTables);			
		Collection<String> entityDeleteList = entityList;
		Collection<String> tablesToIgnoreList = new HashSet<String>(tableListToIgnore);
		Collection<String> trimTableList = new HashSet<String>();
		log.info("Table ListFromDBandXML before " + tablesToIgnoreList + " entityDeleteList before " + entityDeleteList);				
		trimTableList.addAll(tablesToIgnoreList);
		trimTableList.addAll(entityDeleteList);
		trimTableList.removeAll(tablesToIgnoreList);
		log.info("TrimTableList is " + trimTableList);
		return trimTableList;
	}	
	
	public void setPermission(File perDir) {
		perDir.setExecutable(true, false);
		perDir.setReadable(true, false);
		perDir.setWritable(true, false);
	}

	public File findDoneDir(String sourcePath) throws Exception {
		String subTimeStampDir = sourcePath.replaceAll("^.*?(\\w+)\\W*$", "$1");
		String newDir = KohlsPOCConstant.DELTA_DONE_PATH + KohlsPOCConstant.BACKWARD_SLASH + subTimeStampDir;
		log.info("Finding the done path and creating dir is " + newDir);
		File nwDir = new File(newDir);
		if (!nwDir.isDirectory()) {
			nwDir.mkdir();
			setPermission(nwDir);
		}
		return nwDir;
	}

	public void filterFiles(File dir, File dest, String fileType) throws IOException {
		File[] files = dir.listFiles();
		log.debug("Calling the list file " + dir + " " + dest.getName());
		String fileName = null;
		String typeReceived = null;
		for (File sourceFile : files) {
			if(fileType.equalsIgnoreCase("ALL")){
				typeReceived = sourceFile.getName();
				log.debug("typeReceived value is " + typeReceived);
			}else{
				typeReceived = fileType;
				log.debug("typeReceived value is " + typeReceived);
			}			
			fileName = sourceFile.getName();
			if (fileName.contains(typeReceived)) {
				File destFile = new File(dest, fileName);
				try {
					moveErrorFiles(sourceFile, destFile);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void moveErrorFiles(File sourceFile, File destFile) throws IOException {
		log.info("Enter moveErrorFiles() ::  Moving files from " + sourceFile + " to " + destFile);
		InputStream in = null;
		OutputStream out = null;
		try {
			in = new FileInputStream(sourceFile);
			out = new FileOutputStream(destFile);
			byte[] buf = new byte[1024];
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			log.debug("Deleting the file after copy");
			sourceFile.delete();
		} finally {
			in.close();
			out.close();
		}
	}

	public void statementExecution(String command, String dumpFileName, String explogfile, String type)
			throws Exception {
		final Runtime r = Runtime.getRuntime();
		log.info("Enter statementExecution() :: Starting statement execution " + dumpFileName );
		Process p = r.exec(command);
		final int returnCode = p.waitFor();
		log.info("Return Code is " + returnCode);
		final int exitValue = p.exitValue();
		log.info("Exit Value is " + exitValue);
		final BufferedReader is = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = is.readLine()) != null) {
			log.debug("Oracle message 1 : " + line);
		}
		final BufferedReader is2 = new BufferedReader(new InputStreamReader(p.getErrorStream()));
		String oraCodes = "";
		String oraStagedCodes = "";
		boolean haltProcess = false;
		while ((line = is2.readLine()) != null) {
			log.info("Oracle message 2 : " + line);
			if ((type.equalsIgnoreCase(KohlsPOCConstant.DB_DELTA_IMPORT) && exitValue != 0) && line.contains("ORA-")) {
				oraCodes = oraCodes + ", " + line.split(":")[0];
			}

			if (type.equalsIgnoreCase(KohlsPOCConstant.DB_DELTA_IMPORT)) {
				if (line.contains("out of")) {
					haltProcess = true;
				}
				if (line.contains("ORA-") || line.contains("KUP-")) {
					oraStagedCodes = oraStagedCodes + ", " + line.split(":")[0];
				}
			}

		}
		if (exitValue != 0) {
			if (type.equalsIgnoreCase(KohlsPOCConstant.DB_DELTA_IMPORT)) {
				throw new YFCException("Oracle command failed with exitValue " + exitValue + oraCodes);
			} else {
				throw new YFCException("Oracle command failed with exitValue " + exitValue);
			}
		}

		if (haltProcess) {
			throw new YFCException("Staged Oracle command failed with exitValue " + exitValue + "," + oraStagedCodes);
		}

		if (type.equals(KohlsPOCConstant.DB_DELTA_EXPORT)) {
			log.debug("Moving export file");
			moveFiles(dumpFileName, explogfile);
		}
	}

	public void updateSyncVersionToDB(YFSEnvironment env, String syncProfile, String TableGroup, String ProfileOrgCode,
			Document docSyncVersion, boolean isCorp, boolean isImportTable) throws Exception {
		log.info("Enter updateSyncVersionToDB() :: Manage SyncDB update begin for profile" + syncProfile);
		log.debug("TableGroup " + TableGroup);
		Document docExportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_EXPORT).getDocument();
		Element eleExportSyncDB = docExportSyncDB.getDocumentElement();
		try {
			String finalSeqNo = "";
			eleExportSyncDB.setAttribute(KohlsPOCConstant.A_TABLE_GROUP, TableGroup);
			SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
			YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
			String syncDBDate = sdf.format(yfcCurrntDt);
			log.debug("getSyncDBExportList Input  in API_GET_SYNC_DB_EXPORT_LIST is "
					+ syncDBDate + finalSeqNo + XMLUtil.getXMLString(docExportSyncDB));
			Document getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
					KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST, docExportSyncDB);
			log.debug("getSyncDBExportList output in API_GET_SYNC_DB_EXPORT_LIST is "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));
			String fullSyncSeqNo = getSequenceNumber(getSyncDBExportListOutputDoc, syncProfile);
			log.debug("fullSyncSeqNo " + fullSyncSeqNo);
			Element eleProfile = SCXmlUtil.createChild(docSyncVersion.getDocumentElement(), KohlsPOCConstant.E_PROFILE);
			log.debug("eleProfile is before attr addition " + SCXmlUtil.getString(eleProfile));
			eleProfile.setAttribute(KohlsPOCConstant.A_NAME, syncProfile);
			eleProfile.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, fullSyncSeqNo);
			eleProfile.setAttribute(KohlsPOCConstant.A_ORG_CODE, ProfileOrgCode);
			log.debug("eleProfile is after attr addition " + SCXmlUtil.getString(eleProfile));
			log.debug("SyncVersion now is " + SCXmlUtil.getString(docSyncVersion));
			// Actual query to insert
			String TABLE_GROUP_EXPORT = XMLUtil.getAttribute(eleExportSyncDB, KohlsPOCConstant.A_TABLE_GROUP);
			log.debug("TABLE_GROUP_EXPORT in manageSyncDBUpdate is " + TABLE_GROUP_EXPORT);
			YCPContext ctx = (YCPContext) env;
			YFS_Sync_DB_Export exportEntity = YFS_Sync_DB_Export.newInstance();
			exportEntity.setDBContextRecursive(ctx);
			exportEntity.setSync_Type(KohlsPOCConstant.SYNC_DELTA);
			exportEntity.setSequence_No(fullSyncSeqNo);
			exportEntity.setDB_Export_Time(yfcCurrntDt);
			exportEntity.setSync_Profile_ID(syncProfile);
			exportEntity.setTableGroup(TABLE_GROUP_EXPORT);
			exportEntity.setOrganization_Code(ProfileOrgCode);
			log.debug("Inserting new record into YFS_SYNC_DB_EXPORT:\nOrganizationCode: "
					+ exportEntity.getOrganization_Code() + "\nSyncProfileID: " + exportEntity.getSync_Profile_ID()
					+ "\nSyncType: " + exportEntity.getSync_Type() + "\nTableGroup: " + exportEntity.getTableGroup()
					+ "\nSequenceNo: " + exportEntity.getSequence_No() + "\n");
			exportEntity.insert();
			getSyncDBExportListOutputDoc = null;
			getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST,
					docExportSyncDB);
			log.debug("Post Insert getSyncDBExportList output in manageSyncDBUpdate is "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));
		} catch (Exception e) {
			log.error("Exception manageSyncDBUpdate is " + e.toString());
			throw e;
		}
	}

	public String manageSyncDBUpdateForConfig(YFSEnvironment env, String syncProfile, String ProfileOrgCode)
			throws Exception {
		log.info("Enter manageSyncDBUpdateForConfig() :: Manage SyncDB Update begin for config profile" + syncProfile);
		Document docExportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_EXPORT).getDocument();
		Element eleExportSyncDB = docExportSyncDB.getDocumentElement();
		String deltaSyncSeqNo = "";
		try {
			String finalSeqNo = "";
			eleExportSyncDB.setAttribute(KohlsPOCConstant.A_TABLE_GROUP, KohlsPOCConstant.CONFIGURATION);
			SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
			YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
			String syncDBDate = sdf.format(yfcCurrntDt);

			log.debug("getSyncDBExportList Input  in API_GET_SYNC_DB_EXPORT_LIST is "
					+ syncDBDate + finalSeqNo + XMLUtil.getXMLString(docExportSyncDB));
			Document getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
					KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST, docExportSyncDB);
			log.debug("getSyncDBExportList output in API_GET_SYNC_DB_EXPORT_LIST is "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));

			deltaSyncSeqNo = getSequenceNumber(getSyncDBExportListOutputDoc, syncProfile);
			log.debug("deltaSyncSeqNo " + deltaSyncSeqNo);

			YCPContext ctx = (YCPContext) env;
			YFS_Sync_DB_Export exportEntity = YFS_Sync_DB_Export.newInstance();
			exportEntity.setDBContextRecursive(ctx);
			exportEntity.setSync_Type(KohlsPOCConstant.SYNC_DELTA);
			exportEntity.setSequence_No(deltaSyncSeqNo);
			exportEntity.setDB_Export_Time(yfcCurrntDt);
			exportEntity.setSync_Profile_ID(syncProfile);
			exportEntity.setTableGroup("Configuration");
			exportEntity.setOrganization_Code(ProfileOrgCode);
			log.debug("Inserting new record into YFS_SYNC_DB_EXPORT:\nOrganizationCode: "
					+ exportEntity.getOrganization_Code() + "\nSyncProfileID: " + exportEntity.getSync_Profile_ID()
					+ "\nSyncType: " + exportEntity.getSync_Type() + "\nTableGroup: " + exportEntity.getTableGroup()
					+ "\nSequenceNo: " + exportEntity.getSequence_No() + "\n");

			exportEntity.insert();
			getSyncDBExportListOutputDoc = null;
			getSyncDBExportListOutputDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SYNC_DB_EXPORT_LIST,
					docExportSyncDB);
			log.debug("Post Insert getSyncDBExportList output in manageSyncDBUpdate is "
					+ SCXmlUtil.getString(getSyncDBExportListOutputDoc));
		} catch (Exception e) {
			log.error("Exception manageSyncDBUpdate() is " + e.toString());
			throw e;
		}
		return deltaSyncSeqNo;
	}

	public Document callApi(YFSEnvironment env, Document inXML, Document outDoc, String sEndpoint, String sApiName) {
		try {
			Document tempOutput = null;
			oApi = getDefaultAPI((YFSContext) env, sEndpoint);
			log.debug("callApi is in progress");
			String envString = "<env userId='gravity' progId='gravity'/>";
			YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
			tempOutput = oApi.invoke(newEnv, sApiName, inXML);
			return tempOutput;
		} catch (Exception e) {
			log.error("Error in callApi " + e.getMessage() + e.getStackTrace());
			throw new YFCException("Exception in callApi");
		}
	}

	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			log.debug("YIFClient using endpoint definition");
			Map omap = new HashMap();
			try {
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_USERID,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_USERID));
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_PASSWD,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_PASSWD));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}
		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode(KohlsPOCConstant.EDGE_SERVER_ERROR_CODE);
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), KohlsPOCConstant.EDGE_SER_NOT_CONFIGURED));
		throw oEx;
	}

	private String getSequenceNumber(Document getListDoc, String syncProfile) {
		String finalSeqNo = "";
		log.info("Enter getSequenceNumber() :: Getting the sequence number");
		ArrayList<Element> profileList = SCXmlUtil.getChildren(getListDoc.getDocumentElement(),
				KohlsPOCConstant.E_SYNC_DB_EXPORT);
		HashMap<String, String> profileSequenceMap = new HashMap<String, String>();
		int prevSeqNo = 0;
		for (Element eleProfile : profileList) {
			profileSequenceMap.put(eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID),
					KohlsPOCConstant.ONE_DOT_ZERO);
		}
		for (Element eleProfile : profileList) {
			String currSyncProfileID = eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
			String orgCode = eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID);
			log.debug("currSyncProfileID for map entry and Org " + currSyncProfileID +", " + orgCode);
			log.debug("SequenceNo for map entry " + eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
			int currSeqNo = (int) Double.parseDouble((eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO)));
			log.debug("currSeqNo for map entry " + String.valueOf(currSeqNo));

			String strPrevSeqNo = profileSequenceMap.get(currSyncProfileID);
			log.debug("strPrevSeqNo for map entry " + strPrevSeqNo);
			prevSeqNo = (int) Double.parseDouble(strPrevSeqNo);
			log.debug("prevSeqNo for map entry " + String.valueOf(prevSeqNo));
			if (currSeqNo > prevSeqNo) {
				profileSequenceMap.put(currSyncProfileID, eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
				prevSeqNo = currSeqNo;
			}
		}

		log.debug("Map after looping is ");
		for (Entry<String, String> entry : profileSequenceMap.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			log.debug("Profile and version are " + key + ", " + value);
		}

		log.debug("Currently analysed syncProfile and sequenceNo is " + syncProfile + ", " + profileSequenceMap.get(syncProfile));		
		if (profileList.size() > 0 && !YFCObject.isVoid(profileSequenceMap.get(syncProfile))) {
			int existingSeqNo = (int) Double.parseDouble(profileSequenceMap.get(syncProfile).split("\\.")[0]);
			int newSeqNo = existingSeqNo;
			finalSeqNo = newSeqNo + KohlsPOCConstant.DOT_ZERO;
		} else {
			throw new YFCException("Please perform full sync before performing delta sync for profile " + syncProfile);
		}
		int finalDelta = 0;
		finalDelta = getDeltaValue(finalSeqNo, profileList, syncProfile);
		log.debug("syncProfile and finalDelta sequence No " + syncProfile + ", " + finalDelta);
		return finalSeqNo.split("\\.")[0] + KohlsPOCConstant.DOT + finalDelta;
	}

	private ArrayList<Element> getExcludeTableList(YFSContext ctx) {
		ArrayList<Element> excludeList = new ArrayList<Element>();
		try {
			YFCDataBuf oBuf = new YFCDataBuf();
			oBuf.append(KohlsPOCConstant.A_ENTERPRISE_CODE, "");
			oBuf.append(KohlsPOCConstant.ATTR_DOC_TYPE, "");
			YFCDocument eCDMDoc = YCPTemplateManager.getInstance().getResourceTemplate(ctx,
					KohlsPOCConstant.CHANGE_DATA_MANAGEMENT_RULES, null, oBuf);
			log.debug("eCDMDoc " + eCDMDoc);
			if (eCDMDoc != null) {
				Document docCDM = eCDMDoc.getDocument();
				excludeList = getExcludeList(ctx,
						SCXmlUtil.getChildElement(docCDM.getDocumentElement(), KohlsPOCConstant.E_RULES));
				return excludeList;
			}
		} catch (YFCException ex) {
			log.error("Exception in getExcludeTableList method");
			throw ex;
		}
		return excludeList;
	}

	private static ArrayList<Element> getExcludeList(YFSContext ctx, Element rules) {
		if (rules == null) {
			return null;
		}
		ArrayList<Element> ruleList = SCXmlUtil.getChildren(rules, KohlsPOCConstant.E_RULE);
		for (Element rule : ruleList) {
			log.debug("Current rule element is " + SCXmlUtil.getString(rule));
			String ruleName = rule.getAttribute(KohlsPOCConstant.A_NAME);
			if (ruleName.equals(KohlsPOCConstant.E_EXCLUDE_FROM_SYNC)) {
				Element eleExcludeList = SCXmlUtil.getChildElement(rule, KohlsPOCConstant.E_EXCLUDE_LIST);
				ArrayList<Element> excludeList = SCXmlUtil.getChildren(eleExcludeList, KohlsPOCConstant.EXCLUDE);
				return excludeList;
			}
		}
		return null;
	}

	//Compare and increment the delta version
	private int getDeltaValue(String finalSeqNo, ArrayList<Element> profileList, String syncProfile) {
		int fullSyncSeqNo = (int) Double.parseDouble(finalSeqNo.split("\\.")[0]);
		log.debug("fullSyncSeqNo is " + fullSyncSeqNo);
		int finalDelta = 0;
		for (Element eleProfile : profileList) {
			log.debug("eleProfile is " + SCXmlUtil.getString(eleProfile));
			log.debug("Seq No " + eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
			int currFullNo = (int) Double
					.parseDouble((eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO).split("\\.")[0]));
			log.debug("currFullNo is " + currFullNo);
			int currDeltaNo = (int) Double
					.parseDouble((eleProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO).split("\\.")[1]));
			log.debug("currDeltaNo is " + currDeltaNo);
			log.debug("syncProfileId " + eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID));
			if ((currFullNo == fullSyncSeqNo)
					&& syncProfile.equals(eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID))) {
				if (finalDelta < currDeltaNo) {
					finalDelta = currDeltaNo;
				}
			}
		}
		return finalDelta + 1;
	}

	//table list and timestamp differs as per new expdp	
	private void updateSyncExportedFlag(YFSContext ctx) throws SQLException {
		log.info("Enter updateSyncExportedFlag() :: Starting update sync exported for Master");
		String partitionID = ctx.getPoolResolver().pushPartition("updateSyncExported");
		SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		String strCurrentDate = sdf.format(expImpTimeStamp);
		log.info("Current update for sync exported is " + strCurrentDate);
		ctx.getPoolResolver().addFact("TableType", "MASTER");
		PLTQueryBuilder oPLT = new PLTQueryBuilder(false);	
		boolean flag1 = true;
		for(String dbProfile : timeTablesGroup.keySet()){
			String[] profileTimeStampTables = timeTablesGroup.get(dbProfile).split(";");
			log.info("DB last sync date and  tables " + profileTimeStampTables[0] +", " + profileTimeStampTables[1]);
			if(flag1){
				oPLT.append("UPDATE YFS_ENTITY_CHANGE SET SYNC_EXPORTED='Y' WHERE ( ENTITY IN ('" + profileTimeStampTables[1]				
				+ "') AND MODIFYTS BETWEEN  to_date(\'" + profileTimeStampTables[0] + "\'," + "\'"
				+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\'," + "\'"
				+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')) ");				
			flag1 = false;
			}else{
				oPLT.append(" OR ( ENTITY IN ('" + profileTimeStampTables[1]				
				+ "') AND MODIFYTS BETWEEN  to_date(\'" + profileTimeStampTables[0] + "\'," + "\'"
				+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\') AND to_date(\'" + strCurrentDate + "\'," + "\'"
				+ KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')) ");
			}				
		}							
		log.debug("updateSyncExported query being fired " + oPLT.getReadableWhereClause());
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.debug("Executing SQL  " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			log.debug("Updated Sync Exported Flag ");
			rs.close();
		} catch (Exception ex) {
			log.error("Error occurred in updateSyncExported");
			throw ex;
		} finally {
			log.debug("fireSqlQuery updateSyncExportedending");
			YFSDBHome.closeStatement(stmt);
			log.debug("Popping partitionID " + partitionID);
			ctx.getPoolResolver().popPartition(partitionID);
		}
	}

	private void updateSyncExportedForConfig(YFSContext ctx) throws SQLException {
		log.info("Enter updateSyncExportedForConfig() :: Starting Update Sync Exported for config");
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(UPDATE_SYNC_EXPORTED_DATE_FORMAT);
		String strCurrentDate = sdf.format(date);
		log.debug("Current date is " + strCurrentDate);
		PLTQueryBuilder oPLT = new PLTQueryBuilder(false);
		oPLT.append("UPDATE YFS_ENTITY_CHANGE SET SYNC_EXPORTED='Y' WHERE SYNC_EXPORTED=\'N\' AND CREATETS < to_date(\'"
				+ strCurrentDate + "\'," + "\'" + KohlsPOCConstant.ORACLE_QUERY_DATE_FORMAT + "\')");
		log.debug("New query being fired " + oPLT.getReadableWhereClause());
		try {
			stmt = ctx.getConnectionForTable(YFS_Entity_ChangeDBHome.getInstance().getTableName()).createStatement();
			log.debug("Executing SQL: " + oPLT.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(oPLT.getReadableWhereClause(true));
			log.debug("Updated Sync Exported Flag ");
			rs.close();
		} catch (Exception ex) {
			log.error("Error occurred");
			throw ex;
		}
	}

	@Override
	public List<Document> getJobs(YFSEnvironment env, Document inXML, Document lastMessageCreated) throws Exception {
		log.info("Enter getJobs() :: Get jobs started with input : " + XMLUtil.getXMLString(inXML));
		List<Document> lstTask = new ArrayList<Document>();
		if (!YFCCommon.isVoid(lastMessageCreated)) {
			log.info("Input to lastMessageCreated " + XMLUtil.getXMLString(lastMessageCreated));
		}
		String isDeleteEnabled = YFSSystem.getProperty(KohlsPOCConstant.DELTA_RECORDS_DELETE_ENABLED);

		try {
			YFCElement eleRoot = YFCDocument.getDocumentFor(inXML).getDocumentElement();
			String sDataType = eleRoot.getAttribute(KohlsPOCConstant.A_DATA_TYPE);
			log.info("Action type is " + sDataType);
			KohlsDeltaDataPumpMergeUtil mUtil = new KohlsDeltaDataPumpMergeUtil();
			Document msgDocInput = YFCDocument.createDocument(KohlsPOCConstant.E_KOHLS_GET_DATA_EXPORT).getDocument();
			if (lastMessageCreated == null) {				
				if (sDataType.contentEquals("DeltaImport")) {
					// segregate the files
					File fle = new File(KohlsPOCConstant.DELTA_INPROGRESS_PATH);
					if (fle.listFiles().length > 0) {
						segregateFiles(KohlsPOCConstant.DELTA_INPROGRESS_PATH,KohlsPOCConstant.DELTA_STAGED_INPRG_PATH);
					}

					KohlsDeploymentUtil depUtil = new KohlsDeploymentUtil();
					boolean isFullSyncPerformed = checkIfFullSyncPerformed(env);

					if (isFullSyncPerformed) {
						globalDate();
						log.info("INSTANT - Going to perform INSTANT-import type Start Time :: "
								+ KohlsDeltaDataPumpMergeUtil.currentDate());
						KohlsDeltaDataPump datapump = new KohlsDeltaDataPump();
						File instantErrPath = new File(KohlsPOCConstant.DELTA_ERROR_PATH);
						File InstantInPrgPath = new File(KohlsPOCConstant.DELTA_INPROGRESS_PATH);
						if ((instantErrPath.isDirectory() && instantErrPath.listFiles().length > 0)
								|| (InstantInPrgPath.isDirectory() && InstantInPrgPath.listFiles().length > 0)) {
							datapump.readDumpFilesAndImportTables(env, KohlsPOCConstant.DELTA_INPROGRESS_PATH,
									KohlsPOCConstant.DELTA_ERROR_PATH);
							log.info("INSTANT - Clearing the cache");
							depUtil.callModifyCache(env);
							log.info("INSTANT - Delta sync INSTANT-import type completed End Time :: "
									+ KohlsDeltaDataPumpMergeUtil.currentDate());
						} else {
							log.info("INSTANT - No delta files to process for INSTANT-import type");
						}

						if (KohlsPOCConstant.YES.equalsIgnoreCase(
								YFSSystem.getProperty(KohlsPOCConstant.DELTA_RECORDS_DELETE_ENABLED))) {
							boolean isStagedDeltaProces = KohlsDeltaDataPumpMergeUtil.compareWithSysDeltaTime();
							if (isStagedDeltaProces) {
								datapump.readDumpFilesAndImportTables(env, KohlsPOCConstant.DELTA_STAGED_INPRG_PATH,
										KohlsPOCConstant.DELTA_STAGED_ERROR_PATH);
							}
						}
					} else {
						// checkIfFullSyncPerformed is moving to error directory
						throw new YFCException("Please perform full sync import before performing delta import");
					}
				}

				Element eleServiceInput = msgDocInput.getDocumentElement();
				eleServiceInput.setAttribute(KohlsPOCConstant.A_DATA_TYPE, sDataType);
				eleServiceInput.setAttribute("DeltaType", KohlsPOCConstant.A_INSTANT);
				log.info("Input created in getjobs " + XMLUtil.getXMLString(msgDocInput));				
				lstTask.add(msgDocInput);
			} else {
				if (KohlsPOCConstant.NO.equalsIgnoreCase(isDeleteEnabled)) {
					Element mesgXmlPartElm = KohlsXPathUtil.getElementByXpath(lastMessageCreated, "/Partition");
					boolean isStagedDeltaProces = KohlsDeltaDataPumpMergeUtil.compareWithSysDeltaTime();
					globalDate();
					if ((sDataType.contentEquals("DeltaImport") && YFCCommon.isVoid(mesgXmlPartElm)) && isStagedDeltaProces) {
						log.info("STAGED - Values before cleanup " + deltaCurDirPath + ", " + partitionTableList + ", "+ tableListMappingStg);
						deltaCurDirPath = ""; // Clear the global variable
						partitionTableList = "";
						tableListMappingStg = "";
						log.info("STAGED - Values after cleanup " + deltaCurDirPath + ", " + partitionTableList + ", "+ tableListMappingStg);
						YFSContext ctex = (YFSContext) env;
						File stagedErrPath = new File(KohlsPOCConstant.DELTA_STAGED_ERROR_PATH);
						File stagedIngPrgPath = new File(KohlsPOCConstant.DELTA_STAGED_INPRG_PATH);
						boolean nextStgDelta = false;
						if (stagedErrPath.isDirectory() && stagedErrPath.listFiles().length > 0) {
							log.info("STAGED - Going to perform the Stage-import Reprocess Error Start Time :: "
											+ KohlsDeltaDataPumpMergeUtil.currentDate());
							nextStgDelta = mUtil.processStagedDelta(env, stagedErrPath);
						} else if (stagedIngPrgPath.isDirectory() && stagedIngPrgPath.listFiles().length > 0) {
							log.info("STAGED - Going to perform the Stage-import Start Time :: "
											+ KohlsDeltaDataPumpMergeUtil.currentDate());
							nextStgDelta = mUtil.processStagedDelta(env, stagedIngPrgPath);
						}
						if (nextStgDelta) {
							lstTask.add(SCXmlUtil.createFromString("<KohlsDataPump DataType='DeltaImport'/>"));
							log.info("STAGED - Get jobs completed");
							return lstTask;
						}
						log.info("STAGED - Values updated " + deltaCurDirPath + ", " + partitionTableList + ", "+ tableListMappingStg);
						if (!YFCCommon.isVoid(deltaCurDirPath)) {
							List<Document> errList = mUtil.loadPartitionFromXml(deltaCurDirPath);
							if (errList.size() != 0) {
								lstTask.addAll(errList);
								log.info("STAGED - Error list size completed " + lstTask.size());
							} else { // Check for rank enabled and construct the messages : CPE-13106
								if (KohlsPOCConstant.YES.equalsIgnoreCase(
										KohlsDeltaDataPumpMergeUtil.checkForRankEnabled(deltaCurDirPath))) {
									log.info("STAGED - Merge Import Type is Rank() Approach :: "
											+ KohlsDeltaDataPumpMergeUtil.currentDate());
									Collection<String> updateToDBList = filterTableList((YCPContext) env,
											KohlsPOCConstant.INSERT_UPDATE);
									HashMap<String, String> getActTableSTGMapList = KohlsDeltaDataPumpMergeUtil
											.getActiveTableSTGMap(
													callGetCommonCodeList(env, KohlsPOCConstant.DATASYNC_PROFILE));
									return mUtil.recordRangeConstruction(env, deltaCurDirPath, updateToDBList,
											getActTableSTGMapList);
								} else {
									if (YFCCommon.isVoid(partitionTableList)) {
										log.info("STAGED - Merge Import Type is Partition Approach :: "
												+ KohlsDeltaDataPumpMergeUtil.currentDate());
										Collection<String> updateToDBList = filterTableList((YCPContext) env,
												KohlsPOCConstant.INSERT_UPDATE);
										String tableListMaster = "";
										if (updateToDBList.size() != 0) {
											boolean isFirst = true;
											HashMap<String, String> tableStgMap = new HashMap<String, String>();
											tableStgMap = mUtil.remapTableWithSTGTables(
													deltaCurDirPath.split(KohlsPOCConstant.STG_SYNC_VER)[0],
													updateToDBList);
											for (String key : tableStgMap.keySet()) {
												log.info("STAGED - key is " + key);
												if (isFirst) {
													isFirst = false;
													tableListMaster = "'DUMMY." + tableStgMap.get(key);
												} else {
													tableListMaster = tableListMaster + "','DUMMY."
															+ tableStgMap.get(key);
												}
											}
											if (isFirst == false) {
												tableListMaster = tableListMaster + "'";
											}
											partitionTableList = tableListMaster;
											tableListMappingStg = mUtil.remapTableAndStgTableFromXml(deltaCurDirPath);
										}
									}
									lstTask = mUtil.getPartitionNumbers(ctex, partitionTableList, tableListMappingStg,
											deltaCurDirPath);
								}
							}
						}
					} else {
						if (mesgXmlPartElm != null && !YFCCommon.isVoid(deltaCurDirPath)) {
							Document inDoc = mUtil.processSyncVersionXml(env, deltaCurDirPath);
							if (!YFCCommon.isVoid(inDoc)) {
								lstTask.add(inDoc);
							}
						} else if (!YFCCommon.isVoid(mesgXmlPartElm) && YFCCommon.isVoid(deltaCurDirPath)) {
							lstTask.add(SCXmlUtil.createFromString("<KohlsDataPump DataType='DeltaImport'/>"));
							log.info("STAGED - Agent stopped and started");
						}
					}
				}
			}
			log.info("Get jobs process completed");
		} catch (Exception e) {
			log.error("Exception in getJobs is " + e.toString());
			throw e;
		}
		return lstTask;
	}

	public static void globalDate() {
		expImpTimeStamp = new Date();
		log.info("Global date for all operations " + expImpTimeStamp);
	}
	
	public void executeJob(YFSEnvironment env, Document indoc) throws Exception {
		try {
			log.info("Enter executeJob() ::  Input to delta sync execute job is " + XMLUtil.getXMLString(indoc));
			Element eleInDoc = indoc.getDocumentElement();
			actionName = eleInDoc.getAttribute(KohlsPOCConstant.A_DATA_TYPE);
			YFSContext ctx = (YFSContext) env;
			KohlsDeploymentUtil depUtil = new KohlsDeploymentUtil();			
			log.debug("Action name is " + actionName);
			NodeList nodeListKeys = indoc.getElementsByTagName(KohlsPOCConstant.PARTITION);

			if (actionName.equals(KohlsPOCConstant.DB_DELTA_EXPORT)) {
				boolean isFullSyncPerformed = checkIfFullSyncPerformedOnCorp(env);
				String doneDeltaExpPath = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
						+ KohlsPOCConstant.BACKWARD_SLASH;
				File doneFilePath = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR));
				File filesList[] = doneFilePath.listFiles();
				for (File f : filesList) {
					f.delete();
				}
				if (isFullSyncPerformed) {
					KohlsDeltaDataPump deltaExport = new KohlsDeltaDataPump();	
					log.info("Setting the global date");
					globalDate();
					log.info("Going to perform the export");
					deltaExport.createMapDir(env, actionName, "");
					deltaExport.exportTables(ctx);
					log.info("Export of dump files completed");
					boolean isConfigChanged = false;
					log.info("Configuration profile value is " + cdtProfileActive);
					if (cdtProfileActive) {
						boolean bIsSyncProcessTablePopulated = checkIfSyncProcessTablePopulated(ctx,
								KohlsPOCConstant.A_CONFIGURATION, KohlsPOCConstant.A_EXPORT);
						String strLastSyncConfigDate = "";
						log.debug("bIsSyncProcessTablePopulated for Config is " + bIsSyncProcessTablePopulated);
						if (!bIsSyncProcessTablePopulated) {
							strLastSyncConfigDate = getLastFullOrDeltaSyncDate(env, KohlsPOCConstant.A_CONFIGURATION);
							log.info("Getting last Full Or Delta Sync Date from DB is " + strLastSyncConfigDate);
						} else {
							strLastSyncConfigDate = getSyncDateFromSyncProcessTable(ctx, KohlsPOCConstant.A_CONFIGURATION);
							log.info("Getting last Full Or Delta Sync Date is " + strLastSyncConfigDate);
						}
						isConfigChanged = checkIfAnyConfigChange(env, strLastSyncConfigDate);
					}
					if (isConfigChanged) {
						KohlsCDTUtil cdtUtil = new KohlsCDTUtil();
						log.info("CDT extract Started");
						cdtUtil.exportCDT(env, SCXmlUtil.createDocument(KohlsPOCConstant.DB_DELTA_EXPORT));
						log.info("CDT extract completed");
						if (isDeltaDBUpdateEnabled()) {
							log.debug("Updating the configuration profiles");
							String syncVerForD = manageSyncDBUpdateForConfig(env, KohlsPOCConstant.P_CONFIGURATION_D,
									KohlsPOCConstant.DEFAULT);							
							appendConfigVersion(env, syncVerForD, profileDeltaTypeMap.get(KohlsPOCConstant.P_CONFIGURATION_D));
							updateSyncExportedForConfig(ctx);
						}
					} else {
						String zeroDumpFile = doneDeltaExpPath + KohlsPOCConstant.ZERO_CDT_ZIP;
						createZeroDumpFile(zeroDumpFile, "");
					}
					
					File filePath = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR));
					boolean bAllZeros = checkIfZeroPresent(env, filePath);
					log.debug("bAllZeros value is " + bAllZeros);

					/* Checking if all zero dumps, if yes then adding a dummy sync version file Second case is when the
					 * db update is not enabled, sync version file will not be available. Hence creating a dummy sync
					 * version file	 */
					if (bAllZeros || !isDeltaDBUpdateEnabled()) {
						log.debug("Creating the dummy version file");
						String dummyVersionFile = doneDeltaExpPath + KohlsPOCConstant.FILENAME_SYNC_VERSION + timeStamp
								+ KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION;
						createZeroDumpFile(dummyVersionFile, "");
					}
					storeTargetList(env);
					log.info("Targeted Delta Sync Store list file generated");
					
					KohlsDeploymentUtil dpUtil = new KohlsDeploymentUtil();
					SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
					String syncDBDate = sdf.format(expImpTimeStamp);
					ArrayList<String> profilesList = new ArrayList<String>();
					for (String p11 : trimProfiles) { // this is impacting the global if assigned directly
						profilesList.add(p11);
					}
					
					log.info("masterProfileActive " + masterProfileActive);
					
					if( masterProfileActive ){
					log.debug("Setting lastFullOrDeltaSyncDate to KOHLS_POS_DATAPUMP_SYNC_PROCESS table "
							+ KohlsPOCConstant.TABLE_TYPE_MASTER);
					
					dpUtil.manageSyncProcessRecordExpImp(ctx, KohlsPOCConstant.A_EXPORT,
							KohlsPOCConstant.SYNC_DELTA, KohlsPOCConstant.CORP, KohlsPOCConstant.TABLE_TYPE_MASTER,
							profilesList, syncDBDate);					
					}else{
						log.info("Master profiles are not active and hence generating ZERO dump files");
						String zeroDumpFileInsUpd =  doneDeltaExpPath + KohlsPOCConstant.ZERO_INS_UPD_DMP;
						createZeroDumpFile(zeroDumpFileInsUpd, "");
						String zeroDumpFileDelUpd = doneDeltaExpPath + KohlsPOCConstant.ZERO_DEL_UPD_DMP;
						createZeroDumpFile(zeroDumpFileDelUpd, "");
					}
					
					if ( cdtProfileActive ) {
						log.debug("Setting lastFullOrDeltaSyncDate to KOHLS_POS_DATAPUMP_SYNC_PROCESS table "
								+ KohlsPOCConstant.A_CONFIGURATION);
						dpUtil.manageSyncProcessRecordExpImp(ctx, KohlsPOCConstant.A_EXPORT,
								KohlsPOCConstant.SYNC_DELTA, KohlsPOCConstant.CORP, KohlsPOCConstant.A_CONFIGURATION,
								profilesList, syncDBDate);
					}else{
						log.info("Config profile is not active and hence generating ZERO CDT file");
						String zeroDumpFile = doneDeltaExpPath + KohlsPOCConstant.ZERO_CDT_ZIP;
						createZeroDumpFile(zeroDumpFile, "");
					}
					
					if (!masterProfileActive && !isConfigChanged) {
						String dummyVersionFile = doneDeltaExpPath + KohlsPOCConstant.FILENAME_SYNC_VERSION + timeStamp
								+ KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION;
						createZeroDumpFile(dummyVersionFile, "");
					}					
					depUtil.callModifyCache(env);
					log.info("Clearing cache call completed");
				} else {					
					String zeroDumpFile = doneDeltaExpPath + KohlsPOCConstant.ZERO_CDT_ZIP;
					createZeroDumpFile(zeroDumpFile, "");
					String zeroDumpFileInsUpd =  doneDeltaExpPath + KohlsPOCConstant.ZERO_INS_UPD_DMP;
					createZeroDumpFile(zeroDumpFileInsUpd, "");
					String zeroDumpFileDelUpd = doneDeltaExpPath + KohlsPOCConstant.ZERO_DEL_UPD_DMP;
					createZeroDumpFile(zeroDumpFileDelUpd, "");
					String dummyVersionFile = doneDeltaExpPath + KohlsPOCConstant.FILENAME_SYNC_VERSION + timeStamp
							+ KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION;
					createZeroDumpFile(dummyVersionFile, "");
				}
			} else if (actionName.equals(KohlsPOCConstant.DB_DELTA_IMPORT)
					&& eleInDoc.getAttribute("DeltaType").equalsIgnoreCase(KohlsPOCConstant.A_INSTANT)) {
				log.info("INSTANT - Dummy execute job message");
			} else if (nodeListKeys.getLength() > 0) {
				KohlsDeltaDataPumpMergeUtil utl = new KohlsDeltaDataPumpMergeUtil();
				Element elmKey = (Element) nodeListKeys.item(0);
				String rankEnabledForImport = elmKey.getAttribute(KohlsPOCConstant.RANK_ENABLED);

				if (KohlsPOCConstant.YES.equalsIgnoreCase(rankEnabledForImport)) {
					String mergeQuery = "STERLING.MERGE_RANK_TABLE('"
							+ elmKey.getAttribute(KohlsPOCConstant.ATTR_PRIMARY_TABLE) + "','"
							+ elmKey.getAttribute(KohlsPOCConstant.ATTR_PARTITION_TABLE) + "','"
							+ elmKey.getAttribute(KohlsPOCConstant.RANK_BATCH_SIZE_START) + "','"
							+ elmKey.getAttribute(KohlsPOCConstant.RANK_BATCH_SIZE_END) + "')";
					log.debug("STAGED - Merge rank query formed " + mergeQuery);
					utl.mergePartitionRecords(ctx, mergeQuery,
							elmKey.getAttribute(KohlsPOCConstant.ATTR_PARTITION_SYNC_XML), rankEnabledForImport,
							"MERGE_RANK_TABLE");
					log.info("STAGED - Execute rank job completed ");
				} else {
					String mergeQuery = "STERLING.MERGE_TABLE('"
							+ elmKey.getAttribute(KohlsPOCConstant.ATTR_PRIMARY_TABLE) + "','"
							+ elmKey.getAttribute(KohlsPOCConstant.ATTR_PARTITION_TABLE) + "','"
							+ elmKey.getAttribute(KohlsPOCConstant.ATTR_PARTITION_NAME) + "')";
					log.debug("STAGED - Merge query formed " + mergeQuery);
					utl.mergePartitionRecords(ctx, mergeQuery,
							elmKey.getAttribute(KohlsPOCConstant.ATTR_PARTITION_SYNC_XML), rankEnabledForImport,
							"MERGE_TABLE");
					log.info("STAGED - Execute job completed ");
				}
			}
		} catch (Exception e) {
			YFCException exp = new YFCException(e);
			String err = exp.getContainedException().toString();
			log.error("Exception in executejob " + exp.getLastErrorCode() + exp.getContainedException().toString());
			raiseAlert(env, actionName, err);
		    throw e; //Alert is not creating bcz of this enabling this		
		}
	}

	//Add the queue and createException permission on corp 
	public void raiseAlert(YFSEnvironment env, String dumpType, String detailDesc) throws Exception {
		log.error(dumpType + " - Alert raised due to failures");
		Document inDocInbox = SCXmlUtil.createDocument(KohlsPOCConstant.E_Inbox);
		Element inEleInbox = inDocInbox.getDocumentElement();
		inEleInbox.setAttribute(KohlsPOCConstant.A_ACT_FLAG, KohlsPOCConstant.YES);
		inEleInbox.setAttribute(KohlsPOCConstant.A_CONSOLIDATE, KohlsPOCConstant.NO);
		inEleInbox.setAttribute(KohlsPOCConstant.A_Queue_Id, KohlsPOCConstant.A_KOHLS_DATAPUMP_SYNC);		
		inEleInbox.setAttribute(KohlsPOCConstant.A_DETAIL_DESC, detailDesc);
		inEleInbox.setAttribute(KohlsPOCConstant.A_AUTO_RESOLVE_FLAG, KohlsPOCConstant.NO); 
		inEleInbox.setAttribute(KohlsPOCConstant.A_ERROR_TYPE, KohlsPOCConstant.NONREPROCESS);
		if (dumpType.equals(KohlsPOCConstant.DB_DELTA_EXPORT)) {
			inEleInbox.setAttribute(KohlsPOCConstant.ExceptionType, KohlsPOCConstant.A_DATAPUMP_EXP_DELTA_FAILED);
			inEleInbox.setAttribute(KohlsPOCConstant.A_ERR_DESC, KohlsPOCConstant.ERR_DESC_EXP);
			log.debug("Calling createException with input " + SCXmlUtil.getString(inDocInbox));
			Document outDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.CREATE_EXP_API, inDocInbox);
			log.debug("Output of createException is " + SCXmlUtil.getString(outDoc));
		} else if (dumpType.equals(KohlsPOCConstant.DB_DELTA_IMPORT)) {
			inEleInbox.setAttribute(KohlsPOCConstant.ExceptionType, KohlsPOCConstant.A_DATAPUMP_IMP_DELTA_FAILED);
			inEleInbox.setAttribute(KohlsPOCConstant.A_ERR_DESC, KohlsPOCConstant.ERR_DESC_IMP);
			String shipNodeKey = YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP);
			inEleInbox.setAttribute(KohlsPOCConstant.A_SHIP_NODE_KEY, shipNodeKey);
			Document createExceptionOutdoc = null;
			Element eleAdditionalInfo = SCXmlUtil.createChild(inEleInbox, KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
			eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
			log.debug("createException input to MotherShip is " + XMLUtil.getXMLString(inDocInbox));
			callApi(env, inDocInbox, createExceptionOutdoc, KohlsPOCConstant.V_MOTHERSHIP, KohlsPOCConstant.CREATE_EXP_API);
		}
	}
		
	private boolean isDeltaDBUpdateEnabled() {
		if (YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_DB_UPDATE_ENABLE)
				.equalsIgnoreCase(KohlsPOCConstant.TRUE)) {
			log.info("Delta DB Update is enabled");
			return true;
		} else {
			log.info("Delta DB Update is disabled");
			return false;
		}
	}

	private boolean checkIfZeroPresent(YFSEnvironment env, File filePath) throws Exception {
		log.info("Enter checkIfZeroPresent() :: Checking if the dump file present");
		log.debug("filePath in checkIfDumpPresent " + filePath.getName());
		boolean flg = false;
		int i = 0;
		if (filePath.isDirectory() & filePath.listFiles().length > 0) {
			for (File doneFile : filePath.listFiles()) {
				log.debug("Found files under " + doneFile.getName());
				if (doneFile.getName().contains(KohlsPOCConstant.ZERO_INS_UPD_DMP)
						|| doneFile.getName().contains(KohlsPOCConstant.ZERO_DEL_UPD_DMP)
						|| doneFile.getName().contains(KohlsPOCConstant.ZERO_CDT_ZIP)) {
					++i;
				}
			}

			if (i == 3) {
				flg = true;
			}
		}
		return flg;
	}

	private boolean checkIfFullSyncPerformed(YFSEnvironment env) throws Exception {
		boolean fllSyncFlag = false;
		try {
			log.info("Enter checkIfFullSyncPerformed() :: Checking full sync performed on Store");
			YFSContext yctx = (YFSContext) env;
			PLTQueryBuilder query = new PLTQueryBuilder();
			query.appendString(KohlsPOCConstant.DB_SYNC_TYPE, "=", KohlsPOCConstant.SYNC_FULL);
			int i = YFS_Sync_DB_ImportDBHome.getInstance().countWithWhere(yctx, query);
			log.debug("Count of number of records with Full Sync is " + i); //
			if (i > 0) {
				fllSyncFlag = true;
			} else {
				/* This will compare the Delta and Full version, if no Full ver
				 * import in DB, then Delta ver and Full dumps present under
				 * their corresponding path. Also where Full greater delta
				 * version, delta files will be removed.				
				 */
				throw new YFCException("Please perform full sync before delta import.");
			}
		} catch (Exception e) {
			log.error("No full sync performed, moving the files to error directory");
			segregateFiles(KohlsPOCConstant.DELTA_INPROGRESS_PATH, KohlsPOCConstant.DELTA_STAGED_ERROR_PATH);
			File inPrgFileDir = new File(KohlsPOCConstant.DELTA_INPROGRESS_PATH);
			if (inPrgFileDir.listFiles().length > 0) {
				for (File dirlist : inPrgFileDir.listFiles()) {
					exceptionFileMove(dirlist.toString(), KohlsPOCConstant.DELTA_ERROR_PATH);
				}
			}
		}
		return fllSyncFlag;
	}

	public void exceptionFileMove(String dmpFilePath, String errorPath) throws IOException {
		File inPrgPath = new File(dmpFilePath);
		String timeStampDir = dmpFilePath.replaceAll("^.*?(\\w+)\\W*$", "$1");
		log.info("Directory to be created under error dir " + timeStampDir);
		File errDirPath = new File(errorPath + KohlsPOCConstant.BACKWARD_SLASH + timeStampDir);
		if (!errDirPath.exists()) {
			log.debug("Creating error directory " + errDirPath);
			errDirPath.mkdirs();
			setPermission(errDirPath);
		}
		File[] files = inPrgPath.listFiles();
		for (File sourceFile : files) {
			File destFile = new File(errDirPath, sourceFile.getName());
			moveErrorFiles(sourceFile, destFile);
		}
		log.debug("Deleting the empty dir" + inPrgPath);
		if (inPrgPath.isDirectory() & inPrgPath.listFiles().length == 0) {
			setPermission(inPrgPath);
			inPrgPath.delete();
		}
	}

	private boolean checkIfFullSyncPerformedOnCorp(YFSEnvironment env) {
		log.info("Enter checkIfFullSyncPerformedOnCorp() :: Checking full sync performed on Corp");
		YFSContext yctx = (YFSContext) env;
		String partitionID = yctx.getPoolResolver().pushPartition("checkIfFullSyncPerformedOnCorp");
		try {
			yctx.getPoolResolver().addFact(KohlsPOCConstant.TABLE_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
			PLTQueryBuilder query = new PLTQueryBuilder();
			query.appendString(KohlsPOCConstant.DB_SYNC_TYPE, "=", KohlsPOCConstant.SYNC_FULL);
			int i = YFS_Sync_DB_ExportDBHome.getInstance().countWithWhere(yctx, query);
			log.debug("Count of number of records with Full Sync is " + i);
			if (i > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			log.error("Exception in method checkIfFullSyncPerformedOnCorp ");
			throw e;
		} finally {
			log.debug("Popping partitionID checkIfFullSyncPerformedOnCorp" + partitionID);
			yctx.getPoolResolver().popPartition(partitionID);
		}
	}
	
	private void appendConfigVersion(YFSEnvironment env, String syncVerForD, String sImportType) throws Exception {
		log.info("Enter appendConfigVersion() :: Update the sync version");

		Document lastFullDeltaSynInDoc = SCXmlUtil.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
		Element lastFullElm = lastFullDeltaSynInDoc.getDocumentElement();
		/*lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, KohlsPOCConstant.A_EXPORT);
		lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);*/
		lastFullElm.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, KohlsPOCConstant.P_CONFIGURATION_D);
		lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_DELTA);
		log.info("Input to full last sync date call " + XMLUtil.getXMLString(lastFullDeltaSynInDoc));
		Document lastFullDeltaSynOutDoc = KohlsCommonUtil.invokeService(env,
				KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, lastFullDeltaSynInDoc);
		log.info("Output to last sync date call is " + XMLUtil.getXMLString(lastFullDeltaSynOutDoc));
		Element elmLastFullSyncDateOutDoc = lastFullDeltaSynOutDoc.getDocumentElement();
		Element eleDatapumpSyncProcess = (Element) elmLastFullSyncDateOutDoc
				.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS).item(0);

		File dumpFilePath = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR)
				+ KohlsPOCConstant.BACKWARD_SLASH + eleDatapumpSyncProcess.getAttribute(KohlsPOCConstant.A_IMPORT_TYPE)
				+ KohlsPOCConstant.UNDERSCORE + KohlsPOCConstant.FILENAME_SYNC_VERSION + timeStamp
				+ KohlsPOCConstant.DOT + KohlsPOCConstant.XML_EXTENSION);

		FileWriter writer;
		Element eleSyncVersionDocument = null;
		if (dumpFilePath.exists()) {
			log.debug("Dump File Path is " + dumpFilePath.getAbsolutePath());
			log.debug("DumpFile name is " + dumpFilePath.getName());
			Document docSyncVersion = SCXmlUtil.getDocumentBuilder().parse(dumpFilePath);
			log.debug("syncVersionDoc is " + SCXmlUtil.getString(docSyncVersion));
			eleSyncVersionDocument = docSyncVersion.getDocumentElement();
			log.debug("Updating the file for sync version of config ");

		} else {
			Document docSyncVersion = YFCDocument.createDocument(KohlsPOCConstant.V_SYNC_VERSION).getDocument();
			eleSyncVersionDocument = docSyncVersion.getDocumentElement();
			log.debug("Writing the new file sync version for config");
		}
		writer = new FileWriter(dumpFilePath);
		log.debug("eleSyncVersionDocument in appendConfigVersion " + SCXmlUtil.getString(eleSyncVersionDocument));
		Element eleProfileD = SCXmlUtil.createChild(eleSyncVersionDocument, KohlsPOCConstant.E_PROFILE);
		eleProfileD.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.P_CONFIGURATION_D);
		eleProfileD.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, KohlsPOCConstant.DEFAULT);
		eleProfileD.setAttribute(KohlsPOCConstant.A_SEQUENCE_NO, syncVerForD);
		log.debug("Adding config profile element " + SCXmlUtil.getString(eleProfileD));
		writer.write(SCXmlUtil.getString(eleSyncVersionDocument));
		log.debug("Updated the writer for sync version of config");
		writer.close();
	}

	public String getConfigValue(String actionName, String keyName) {
		String prpertyKey = KohlsPOCConstant.KEY_TAG + KohlsPOCConstant.UNDERSCORE + actionName.toUpperCase()
				+ KohlsPOCConstant.UNDERSCORE + keyName;
		log.debug("Property key : " + prpertyKey);
		return YFSSystem.getProperty(prpertyKey);
	}

	public Properties loadPropertiesFromAbsoluteLocation(String propertyFilePath) throws Exception {
		log.info("Enter loadPropertiesFromAbsoluteLocation() :: Reading the property file");
		Properties prop = new Properties();
		File file = null;
		FileReader fr = null;
		log.debug("Properties File Path : " + propertyFilePath);
		try {
			file = new File(propertyFilePath);
			log.debug("Properties file created successfully");
			fr = new FileReader(file);
			log.debug("File Reader initiated successfully");
			prop.load((Reader) fr);
		} catch (Exception e) {
			log.error("Error in loading properties file " + e.getMessage() + e.getStackTrace());
			throw e;
		} finally {
			if (fr != null) {
				fr.close();
			}
			if (file != null) {
				file = null;
			}
		}
		return prop;
	}

	public void storeTargetList(YFSEnvironment env) throws Exception {
		log.info("Enter storeTargetList() :: Creating the store list file");
		Document inputDoc = SCXmlUtil.createDocument(KohlsPOCConstant.A_SYNC_TARGET);
		log.debug("getSyncTargetList API input is " + KohlsXMLUtil.getXMLString(inputDoc));
		Document outputDoc = KohlsCommonUtil.invokeAPI(env, getStoreListTemp(), KohlsPOCConstant.A_GET_SYNC_TARGET_LIST,
				inputDoc);
		log.debug("getSyncTargetList API output is " + KohlsXMLUtil.getXMLString(outputDoc));
		int numOfStores = Integer
				.parseInt(outputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
		log.debug("TotalNumberOfRecords is "
				+ outputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
		if (numOfStores != 0) {
			Element eleStoreList = outputDoc.getDocumentElement();
			NodeList nodeList = eleStoreList.getElementsByTagName(KohlsPOCConstant.A_SYNC_TARGET);
			String strList = "";
			for (int i = 0; i < nodeList.getLength(); i++) {
				Element eleCommonCode = ((Element) nodeList.item(i));
				strList = strList + eleCommonCode.getAttribute(KohlsPOCConstant.A_SYNC_TARGETID)
						+ KohlsPOCConstant.SPACE;
			}
			String storeListFile = YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY)
					+ KohlsPOCConstant.BACKWARD_SLASH + DELTA_STORE_LIST + KohlsPOCConstant.UNDERSCORE + timeStamp
					+ KohlsPOCConstant.TXT;
			log.debug("storeListFile " + storeListFile);
			File nw = new File(storeListFile);
			log.debug("New file is " + nw.getName());
			if (!nw.exists()) {
				nw.createNewFile();
				log.debug("creating file is " + nw.getName());
			}
			BufferedWriter out = new BufferedWriter(new FileWriter(nw));
			out.write(strList);
			out.close();
			File storeFilePath = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DIRECTORY));
			log.debug("storeFilePath " + storeFilePath.getPath());
			File donePath = new File(YFSSystem.getProperty(KohlsPOCConstant.ISS_DATADUMP_DELTA_EXPORT_DONEDIR));
			log.debug("donePath " + donePath.getPath());
			filterFiles(storeFilePath, donePath, DELTA_STORE_LIST);
		}
	}

	public static Document getStoreListTemp() throws Exception {
		YFCDocument yfcDocStoreList = YFCDocument.createDocument(KohlsPOCConstant.A_SYNC_TARGET_LIST);
		yfcDocStoreList.getDocumentElement().setAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS, "");
		YFCElement yfcEleCommonCodeList = yfcDocStoreList.getDocumentElement();
		YFCElement yfcEleCommonCode = yfcDocStoreList.createElement(KohlsPOCConstant.A_SYNC_TARGET);
		yfcEleCommonCode.setAttribute(KohlsPOCConstant.A_SYNC_TARGETID, "");
		yfcEleCommonCodeList.appendChild(yfcEleCommonCode);
		if (log.isDebugEnabled()) {
			log.debug("Store Output Template is " + XMLUtil.getXMLString(yfcDocStoreList.getDocument()));
		}
		return yfcDocStoreList.getDocument();
	}

	public String getPrimaryKey(String strTableName) {
		EntityRepository entityRepos = (EntityRepository) YFCEntityRepositoryImpl.getInstance();
		Entity e1 = entityRepos.getEntityFromTableName(strTableName);
		String primaryKey = e1.getPrimaryKeyAttributes()[0].getColumnName();
		log.debug("Primary key is " + primaryKey);
		return primaryKey;
	}
			
	// Get all the profiles from xml file
	private void getProfileListFromXml(YFSEnvironment env, File dumpFilePath) throws Exception {
		profileToIgnoreTables.clear();
		profileUpdateToDB.clear();
		ArrayList<Element> profileListFromFile = SCXmlUtil
				.getChildren(getSyncVersionDocument(dumpFilePath).getDocumentElement(), KohlsPOCConstant.E_PROFILE);
		log.info("Number of profiles in Sync version XML File " + profileListFromFile.size());		
		log.debug("profileUpdateToDB size and  tables before  " + profileUpdateToDB.size() + ", " + profileUpdateToDB);
		log.debug("profileToIgnoreTables  size and  tables before " + profileToIgnoreTables.size() + ", " + profileToIgnoreTables);		
		for (Element profileFile : profileListFromFile) {
			String profileName = profileFile.getAttribute(KohlsPOCConstant.A_NAME);
			log.info("Profile fileName from XML file is " + profileName);
			if (!(profileName.equals(KohlsPOCConstant.P_USER_KR)
					|| profileName.equals(KohlsPOCConstant.P_CONFIGURATION_KR)
					|| profileName.equals(KohlsPOCConstant.P_CONFIGURATION_KC))) {
				
				String seqNoFromXml = profileFile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
				String retSeqnoFromDB = callGetSyncProfileList(env, profileFile.getAttribute(KohlsPOCConstant.A_NAME));
				
				boolean  finalVersionFlag = false;
				int seqNoFromXmlFull = (int) Double.parseDouble((seqNoFromXml.split("\\.")[0]));	
				int seqNoFromXmlDelta = (int) Double.parseDouble((seqNoFromXml.split("\\.")[1]));
				
				int retSeqnoFromDBFull = (int) Double.parseDouble((retSeqnoFromDB.split("\\.")[0]));
				int retSeqnoFromDBDelta = (int) Double.parseDouble((retSeqnoFromDB.split("\\.")[1]));
								
				if (seqNoFromXmlFull == retSeqnoFromDBFull) {
					if (seqNoFromXmlDelta > retSeqnoFromDBDelta) {
						finalVersionFlag = true;
						log.info("Full version are same, seqNoFromXml  and finalVersionFlag  " + seqNoFromXml + ", " + finalVersionFlag);
					} else {
						finalVersionFlag = false;
						log.info("Full version are same, retSeqnoFromDB  and finalVersionFlag  " + retSeqnoFromDB + ", " + finalVersionFlag);
					}
				} else {
					if (seqNoFromXmlFull > retSeqnoFromDBFull) {						
						finalVersionFlag = true;
						log.info("seqNoFromXml  and finalVersionFlag  " + seqNoFromXml + ", " + finalVersionFlag);
					} else {						
						finalVersionFlag = false;
						log.info("retSeqnoFromDB  and finalVersionFlag  " + retSeqnoFromDB + ", " + finalVersionFlag);
					}
				}
				log.debug("finalVersionFlag is " + finalVersionFlag);
							
				log.info("Profile Name is " + profileName + " seqNoFromXml is " + seqNoFromXml + " retSeqnoFromDB is "
						+ retSeqnoFromDB);
				
				//if (seqNoFromXml.compareTo(retSeqnoFromDB) > 0) {
				if(finalVersionFlag){
					profileUpdateToDB.add(profileName); // profile to be considered in impdp
					log.debug("profileUpdateToDB name and size " + profileName + ", " + profileUpdateToDB.size());
				} else {
					if (profileName.equals(KohlsPOCConstant.P_CONFIGURATION_D)) {
						cdtFlagUpdate = true;
					}
					profileToIgnoreTables.add(profileName); // to pass in delete queries and remove it
					log.debug("Profile To Ignore Tables is " + profileName + ", cdtFlagUpdate is " + cdtFlagUpdate + " and Size is " + profileToIgnoreTables.size());
				}
				
			}
		}
		log.info("Profile update to DB  is " + profileUpdateToDB + " and size is " + profileUpdateToDB.size());
		log.info("Profile to ignore are " + profileToIgnoreTables + " and size is " + profileToIgnoreTables.size());
	}

	 //Send each profile as input and get the full and delta versions 
	private String callGetSyncProfileList(YFSEnvironment env, String profileID) throws Exception {
		log.info("Enter callGetSyncProfileList() :: Getting the get sync profile list");
		String finalValue = "";
		String deltaVal = "";
		String fullVal = "";
		
		Document docSyncProfile = SCXmlUtil.createDocument(KohlsPOCConstant.E_SYNC_DB_IMPORT);
		docSyncProfile.getDocumentElement().setAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID, profileID);
		Document docSyncProfileListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SYNC_DB_IMPORT,
				docSyncProfile);
		log.debug("getSyncDBImportList is " + SCXmlUtil.getString(docSyncProfileListOutput));
		if (docSyncProfileListOutput != null) {
			ArrayList<Element> profileList = SCXmlUtil.getChildren(docSyncProfileListOutput.getDocumentElement(),
					KohlsPOCConstant.E_SYNC_DB_IMPORT);
			for (Element profile : profileList) {
				log.debug("DBA Sync version and profile are "
						+ profile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO) + ", " + SCXmlUtil.getString(profile));
				if (profile.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equalsIgnoreCase(KohlsPOCConstant.SYNC_DELTA)) {
					deltaVal = profile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
				} else if (profile.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equalsIgnoreCase(KohlsPOCConstant.SYNC_FULL)) {
					fullVal = profile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
				}
			}

			if (!YFCCommon.isVoid(fullVal) && !YFCCommon.isVoid(deltaVal)) {
				int currFull = (int) Double.parseDouble((fullVal.split("\\.")[0]));
				int currDeltaFullVer = (int) Double.parseDouble((deltaVal.split("\\.")[0]));
				if (currDeltaFullVer >= currFull) {
					log.info("deltaVal version higher is " + deltaVal);
					finalValue = deltaVal;
				} else {
					log.info("fullVal version higher is " + fullVal);
					finalValue = fullVal;
				}
			} else {
				if (!YFCCommon.isVoid(fullVal)) {
					finalValue = fullVal;
					log.debug("fullVal version is " + finalValue);
				} else if (!YFCCommon.isVoid(deltaVal)) {
					finalValue = deltaVal;
					log.debug("deltaVal version is " + finalValue);
				}
			}
		} else {
			throw new YFCException("Perform a fullsync before performing a delta sync for profile ");
		}
		return finalValue;
	}
	
		
	public static ArrayList<String> getValueAndDescMapForProfile(Document docCommonCodeList, ArrayList<String> profiles) {
		log.info("Enter getValueAndDescMapForProfile() :: Get the table Map");
		ArrayList<String> commonCodeList = new ArrayList<String>();
		Element eleCommonCodeList = docCommonCodeList.getDocumentElement();

		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			log.debug("Profiles is " + profiles);
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));			
			if (profiles.contains(eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION))) {
				commonCodeList.add(eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE));
				log.debug("getValueAndDescMapForProfile Common Code Value and Short Desc "
						+ eleCommonCode.getAttribute(KohlsConstants.CODE_VALUE) + ","
						+ eleCommonCode.getAttribute(KohlsConstants.CODE_SHORT_DESCRIPTION));
			}
		}
		return commonCodeList;
	}	
	
	//Segregate the files between staging and instant
	public void segregateFiles(String deltaInProgress, String stagedInProgress) throws Exception {
		File sourceDir = new File(deltaInProgress);
		File segregateDirs[] = dirListByName(sourceDir);
		for (File segregateDir : segregateDirs) {
			log.info("Segregate files under " + segregateDir);
			setPermission(segregateDir);
			if (segregateDir.isDirectory()) {
				if (segregateDir.list().length == 0) {
					log.info("Deleting the empty directory " + segregateDir);
					segregateDir.delete();
				} else {
					log.info("Directory is not empty " + segregateDir);
					KohlsDeploymentUtil depUtil = new KohlsDeploymentUtil();
					File[] matchingFiles = segregateDir.listFiles(new FilenameFilter() {
						public boolean accept(File dir, String name) {
							return name.startsWith(KohlsPOCConstant.A_STAGED);
						}
					});
					if (matchingFiles.length > 0) {
						File newDestDir = depUtil.createTimestampDir(segregateDir.getAbsolutePath(), stagedInProgress);
						filterFiles(segregateDir, newDestDir, KohlsPOCConstant.A_STAGED);
					} else {
						log.info("No staged files found under " + segregateDir);
					}
				}

				for (File fileName : segregateDir.listFiles()) {
					if (fileName.getName().contains("ZERO_")) {
						log.info("Deleting the zero file " + fileName.getName());
						fileName.delete();
					}
				}
			}
		}
	}

	//Execute the procedure
	private void dbProcedureExecution(YFSEnvironment env, String oraProcedure) throws SQLException {
		try {
			Connection connection = ((YCPContext) env).getConnection();
			log.debug("Got the connection ");
			CallableStatement preparedCall;
			preparedCall = connection.prepareCall("{call " + oraProcedure + "}");
			log.info("Executing the procedure " + oraProcedure);
			preparedCall.execute();
			log.info("Procedure execution completed");
		} catch (SQLException e) {
			log.error("Error in dbProcedureExecution" + e.getMessage());
			throw e;
		}
	}

	//Construct the procedure
	private void statsProcedureConstruction(YFSEnvironment env) throws Exception {
		int statsTableListSize = statsTableList.size();
		log.info("Enter statsProcedureConstruction() :: Stats table count : " + statsTableListSize);
		String finalStatsProcedure = "";
		if (statsTableListSize != 0) {
			String statsTableQuery = "";
			int i = 1;
			for (String tableName : statsTableList) {
				statsTableQuery = statsTableQuery + "filter_lst (" + i + ").objname := '" + tableName + "';";
				++i;
			}
			finalStatsProcedure = "DECLARE filter_lst DBMS_STATS.OBJECTTAB := DBMS_STATS.OBJECTTAB (); "
					+ "BEGIN filter_lst.EXTEND (" + statsTableListSize + "); filter_lst (1).ownname := 'STERLING';"
					+ statsTableQuery + "DBMS_STATS.GATHER_SCHEMA_STATS (ownname => 'STERLING',obj_filter_list => "
					+ "filter_lst, Estimate_Percent => SYS.DBMS_STATS.AUTO_SAMPLE_SIZE, Method_Opt => "
					+ "'FOR ALL INDEXED COLUMNS SIZE AUTO', Degree => 1, Cascade => TRUE, No_Invalidate => FALSE);END";
			log.debug("finalStatsProcedure : " + finalStatsProcedure);
			dbProcedureExecution(env, finalStatsProcedure);
		}
	}

	// Takes the schema name and calculate the records count for 3 tables.
	private void catalogRecordCount(YFSContext yctx, String masterSchema) throws Exception {
		log.info("Catalog schema name : " + masterSchema);
		PreparedStatement prepStmt = null;
		ResultSet recordsCount = null;
		try {
			String countQry = "SELECT 'YFS_ITEM' TABLE_NAME, COUNT (1) COUNT FROM " + masterSchema
					+ ".YFS_ITEM UNION ALL SELECT 'YFS_ITEM_ALIAS' TABLE_NAME, COUNT (1) COUNT FROM " + masterSchema
					+ ".YFS_ITEM_ALIAS"
					+ " UNION ALL SELECT 'YFS_ADDITIONAL_ATTRIBUTE' TABLE_NAME, COUNT (1) COUNT FROM "
					+ masterSchema + ".YFS_ADDITIONAL_ATTRIBUTE";

			prepStmt = yctx.getConnection().prepareStatement(countQry);
			recordsCount = prepStmt.executeQuery();
			String catalogTableCount = "";
			while (recordsCount.next()) {
				catalogTableCount = catalogTableCount + recordsCount.getString("TABLE_NAME") + " : "
						+ recordsCount.getString("COUNT") + " ";
			}
			log.info("Catalog records count for table " + catalogTableCount);
		} catch (Exception ex) {
			log.error("Expection in catalogRecordCount", ex);
			throw ex;
		} finally {
			if (recordsCount != null) {
				recordsCount.close();
			}
			if (prepStmt != null) {
				YFSDBHome.closeStatement(prepStmt);
				prepStmt.close();
			}
		}
	}
}
