package com.kohls.poc.util;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;


/**************************************************************************
 * File : KohlsPoCCheckStoreSyncStatus.java 
 * Author : Yantriks Created : Jan 15 2018
 ***************************************************************************** 
 * This document has been prepared and written by Yantriks
 * on behalf of Kohls, and is copyright of Kohls
 *****************************************************************************/
 
public class KohlsPoCCheckStoreSyncStatus extends KOHLSBaseApi {
	
	private static YIFApi oApi = null;
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCCheckStoreSyncStatus.class.getName());
	String strDBImportTimeStore = "", strDBImportTimeCorp = "";
	boolean bStoreIsSyncedInLastTwoDays = true;
	String ERROR_MESSAGE = "Store is out of sync.";
	
	public Document checkStoreSyncStatus(YFSEnvironment env, Document inDoc) throws Exception {
		
		Document docSyncVersion = getSyncVersionDocumentFile(KohlsPOCConstant.STORE_DATA_DMP_PATH + 
									KohlsPOCConstant.DONE_DIR_PATH);
		
		Document docStoreImportLevels = getImportLevels(env, KohlsPOCConstant.CORP);
		HashMap<String, String> profileIdSeqNoMapCorp = new HashMap<String, String>();
		profileIdSeqNoMapCorp = getMapFromOutDoc(docStoreImportLevels);
		logger.info("docStoreImportLevels is " + SCXmlUtil.getString(docStoreImportLevels));
		Document docCorpImportLevels = getImportLevels(env, KohlsPOCConstant.A_STORE);
		HashMap<String, String> profileIdSeqNoMapStore = new HashMap<String, String>();
		profileIdSeqNoMapStore = getMapFromOutDoc(docStoreImportLevels);
		logger.info("docCorpImportLevels is " + SCXmlUtil.getString(docCorpImportLevels));
		
		Document doErrorOutput = SCXmlUtil.createDocument(KohlsPOCConstant.V_SYNC_VERSION);
		doErrorOutput.getDocumentElement().setAttribute(KohlsPOCConstant.MESSAGE, ERROR_MESSAGE);
		
		Element eleDocSyncVerion  = docSyncVersion.getDocumentElement();
		logger.info("docSyncVersion is " + SCXmlUtil.getString(docSyncVersion));
		ArrayList<Element> syncProfileList = SCXmlUtil.getChildren(eleDocSyncVerion, KohlsPOCConstant.E_PROFILE);
		String strProfile = "";
		String strSeqNo = "";
	
		for(Element eleSyncProfile : syncProfileList){
			strProfile = eleSyncProfile.getAttribute(KohlsPOCConstant.A_NAME);
			strSeqNo = eleSyncProfile.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO);
			logger.info("sequence No at Corp " + profileIdSeqNoMapCorp.get(strProfile));
			logger.info("sequence No at Store " + profileIdSeqNoMapStore.get(strProfile));
			logger.info("sequence No at XML File " + strSeqNo);
			if(strSeqNo.equalsIgnoreCase(profileIdSeqNoMapCorp.get(strProfile)) &&
					strSeqNo.equalsIgnoreCase(profileIdSeqNoMapStore.get(strProfile))){
				eleSyncProfile.setAttribute(KohlsPOCConstant.ATTR_STATUS, KohlsPOCConstant.A_SYNC);
			}else{
				eleSyncProfile.setAttribute(KohlsPOCConstant.ATTR_STATUS, KohlsPOCConstant.A_OUT_OF_SYNC);
			}
		}
		logger.info("docSyncVersion after modification " + SCXmlUtil.getString(docSyncVersion));
		if(bStoreIsSyncedInLastTwoDays){
			return docSyncVersion;
		}else {
			return doErrorOutput;
		}
	}
		
	
	private HashMap<String, String> getMapFromOutDoc(Document docStoreImportLevels) throws ParseException {
		HashMap<String, String> profileIdSeqNoMap = new HashMap<String, String>();
		Element eleStoreImportLevels = docStoreImportLevels.getDocumentElement();
		logger.info("eleStoreImportLevels " + SCXmlUtil.getString(eleStoreImportLevels));
		ArrayList<Element> syncDBImportList = SCXmlUtil.getChildren(eleStoreImportLevels, 
				KohlsPOCConstant.E_SYNC_DB_IMPORT);
		Date finalDate = null;
		Date currentDate = null;
		for(Element eleSyncDBImport : syncDBImportList){
			logger.info("eleSyncDBImport " + SCXmlUtil.getString(eleSyncDBImport));
			logger.info("eleSyncDBImport.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID) " +
					eleSyncDBImport.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID));
			logger.info("eleSyncDBImport.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO) " + 
					eleSyncDBImport.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
				strDBImportTimeStore = eleSyncDBImport.getAttribute(KohlsPOCConstant.A_DB_IMPORT_TIME);
				currentDate = new SimpleDateFormat(KohlsPOCConstant.UPDATE_SYNC_EXPORTED_DATE_FORMAT).
						parse(strDBImportTimeStore);
				
				if(YFCObject.isVoid(finalDate) || (finalDate==null) || currentDate.after(finalDate)){
					finalDate = currentDate;
				}
				
			profileIdSeqNoMap.put(eleSyncDBImport.getAttribute(KohlsPOCConstant.A_SYNC_PROFILE_ID), 
					eleSyncDBImport.getAttribute(KohlsPOCConstant.A_SEQUENCE_NO));
		}
		
		final Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DATE, -2);
	    Date DateBeforeTwoDays = cal.getTime();
	    
	    if(DateBeforeTwoDays.after(finalDate)){
	    	bStoreIsSyncedInLastTwoDays = false;
	    }
		
		return profileIdSeqNoMap;
	}


	private Document getSyncVersionDocumentFile(String path) throws SAXException, IOException, ParserConfigurationException, FactoryConfigurationError {
		Document docSyncVer = null;
		File file = new File(path);
		File[] files = file.listFiles();
		for (File f : files) {
			String dumpFileName = f.getName();
			logger.info("dumpFileName " + dumpFileName);
			if(dumpFileName.contains(KohlsPOCConstant.V_SYNC_VERSION)){
				docSyncVer = SCXmlUtil.getDocumentBuilder().parse(f.getAbsoluteFile());
				break;
			}
		}
		
		return docSyncVer;
	}



	public Document getImportLevels(YFSEnvironment env, String strDBType) throws Exception {
		//The input filter for SyncType will change according to whether we need full or delta export levels
		Document docImportSyncDB = YFCDocument.createDocument(KohlsPOCConstant.E_SYNC_DB_IMPORT).getDocument();
		Document getSyncDBImportListOutputDoc = null;
		docImportSyncDB.getDocumentElement().setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_FULL);
			
		if(KohlsPOCConstant.A_STORE.equalsIgnoreCase(strDBType)){
				
				//Call getSyncDBImportList api
				getSyncDBImportListOutputDoc = KohlsCommonUtil.invokeAPI(env,
						KohlsPOCConstant.API_GET_SYNC_DB_IMPORT, docImportSyncDB);
				return getSyncDBImportListOutputDoc;
				
			}else if(KohlsPOCConstant.CORP.equalsIgnoreCase(strDBType)){
				
				Element eleAdditionalInfo = SCXmlUtil.createChild(docImportSyncDB.getDocumentElement(),
						KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
				eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
				logger.info("ManageSyncDBImport FULL-MOTHERSHIP input " + XMLUtil.getXMLString(docImportSyncDB));
				logger.info("Getting the Corp version");
				getSyncDBImportListOutputDoc = callApi(env, docImportSyncDB, getSyncDBImportListOutputDoc, KohlsPOCConstant.V_MOTHERSHIP,
						KohlsPOCConstant.API_GET_SYNC_DB_IMPORT);
			}
			return getSyncDBImportListOutputDoc;
	}
	
	public Document callApi(YFSEnvironment env, Document inXML, Document outDoc, String sEndpoint, String sApiName) throws Exception {
		try {
			Document tempOutput = null;
			YIFApi oApi = getDefaultAPI((YFSContext) env, sEndpoint);
			String envString = "<env userId='gravity' progId='gravity'/>";
			YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
			tempOutput = oApi.invoke(newEnv, sApiName, inXML);
			return tempOutput;
		} catch (Exception e) {
			throw e;
		}
	}
	
	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			Map omap = new HashMap();
			try {
				omap.put("yif.httpapi.userid",
						YIFClientProperties.getInstance().getYIFProperty("edge.integration.app.userid"));
				omap.put("yif.httpapi.password",
						YIFClientProperties.getInstance().getYIFProperty("edge.integration.app.password"));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}

		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode("OMP922_002");
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), "Edge_Server_Endpoint_Not_Configured"));
		throw oEx;
	}
	
}
