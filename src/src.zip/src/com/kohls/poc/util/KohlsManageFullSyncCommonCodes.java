package com.kohls.poc.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
 
public class KohlsManageFullSyncCommonCodes extends KOHLSBaseApi {
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsManageFullSyncCommonCodes.class.getName());
	public static String strAllOthersStatus = "";
	HashMap<String, String> mapProfileStatus = new HashMap<String, String>();

	public Document updateCommonCode(YFSEnvironment env, Document inDoc) throws Exception {
		logger.debug("Beginning updateCommonCode with inDoc " + SCXmlUtil.getString(inDoc));
		Document docManageCommonCodeOutput = null;

		// Construct a map of profileName, Status from input and set flags
		Element eleProfileList = SCXmlUtil.getChildElement(inDoc.getDocumentElement(), KohlsPOCConstant.E_PROFILE_LIST);
		HashMap<String, String> profiles = new HashMap<String, String>();
		profiles = getProfileNameProfileStatusMap(eleProfileList, profiles);

		// Construct getCommonCodeListInput for given codeType
		Document docCommonCodeListInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
		Element eleInDoc = inDoc.getDocumentElement();
		docCommonCodeListInput.getDocumentElement().setAttribute(KohlsConstant.A_CODE_TYPE,
				eleInDoc.getAttribute(KohlsPOCConstant.COMMON_CODE_TYPE));
		logger.debug("docCommonCodeListInput " + SCXmlUtil.getString(docCommonCodeListInput));

		// Call getCommonCodeList to get all commonCodes for given codeType
		Document docGetCommonCodeListOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COMMON_CODE_LIST,
				docCommonCodeListInput);
		logger.debug("docGetCommonCodeListOutput is " + SCXmlUtil.getString(docGetCommonCodeListOutput));

		// Tweak the input to either activate or deactivate profiles based on input
		ArrayList<Element> commonCodeList = createManageCommonCodeInputs(env, docGetCommonCodeListOutput, profiles);

		// Iterate through each element and call manageCommonCode for each codeShortDescription(Profile)
		for (Element eleCommonCode : commonCodeList) {
			logger.debug("current eleCommonCode is " + SCXmlUtil.getString(eleCommonCode));
			docManageCommonCodeOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MANAGE_COMMON_CODE,
					SCXmlUtil.createFromString(SCXmlUtil.getString(eleCommonCode)));
			logger.info("docManageCommonCodeOutput is " + docManageCommonCodeOutput);
		}
	    
		Document outDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_PROFILE_LIST);
		Element eleDocOut = outDoc.getDocumentElement();
		// Returning profileList output
		for (String strProfile : mapProfileStatus.keySet()) {
			logger.info("DEBUG current profile is " + strProfile);
			Element eleProfile = SCXmlUtil.createChild(eleDocOut, KohlsPOCConstant.E_PROFILE);
			eleProfile.setAttribute(KohlsPOCConstant.Name, strProfile);
			eleProfile.setAttribute(KohlsPOCConstant.A_STATUS, mapProfileStatus.get(strProfile));
		}
		return outDoc;
	}
	
	private HashMap<String, String> getProfileNameProfileStatusMap(Element eleProfileList,
			HashMap<String, String> profiles) {
		logger.info(
				"Beginning getProfileNameProfileStatusMap with eleProfileList " + SCXmlUtil.getString(eleProfileList));
		ArrayList<Element> profileListFromInput = SCXmlUtil.getChildren(eleProfileList, KohlsPOCConstant.E_PROFILE);

		for (Element eleProfile : profileListFromInput) {
			logger.info(" eleProfile " + SCXmlUtil.getString(eleProfile));
			if (KohlsPOCConstant.ALL_OTHERS.equalsIgnoreCase(eleProfile.getAttribute(KohlsPOCConstant.A_NAME))) {
				if (KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(eleProfile.getAttribute(KohlsPOCConstant.A_STATUS))) {
					strAllOthersStatus = KohlsPOCConstant.ACTIVE_CAPS;
				} else {
					strAllOthersStatus = KohlsPOCConstant.INACTIVE_CAPS;
				}
			} else {
				profiles.put(eleProfile.getAttribute(KohlsPOCConstant.A_NAME),
						eleProfile.getAttribute(KohlsPOCConstant.A_STATUS));
			}
		}
		return profiles;
	}

	private ArrayList<Element> createManageCommonCodeInputs(YFSEnvironment env, Document docGetCommonCodeListOutput,
			HashMap<String, String> profiles) throws Exception {
		logger.debug("Beginning createManageCommonCodeInputs with docGetCommonCodeListOutput "
				+ SCXmlUtil.getString(docGetCommonCodeListOutput));
		ArrayList<Element> commonCodeList = new ArrayList<Element>();
		if (docGetCommonCodeListOutput != null) {
			// Get list of commonCode elements
			commonCodeList = SCXmlUtil.getChildren(docGetCommonCodeListOutput.getDocumentElement(),
					KohlsPOCConstant.E_COMMON_CODE);
			// Iterate through commonCodes and udpate the status based on the input
			for (Element eleCommonCode : commonCodeList) {
				// check if specific profile is given, if yes set status or else set generic status
				if (profiles.containsKey(eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC))) {
					eleCommonCode.setAttribute(KohlsPOCConstant.A_CODE_LONG_DESC,
							profiles.get(eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC)));
					logger.info("Setting element to inactive " + SCXmlUtil.getString(eleCommonCode));
				} else {
					eleCommonCode.setAttribute(KohlsPOCConstant.A_CODE_LONG_DESC, strAllOthersStatus);
					logger.info("Setting element to " + SCXmlUtil.getString(eleCommonCode));
				}

				if (!mapProfileStatus.containsKey(eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC))) {
					mapProfileStatus.put(eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC),
							eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_LONG_DESC));
				}
			}
		}
		return commonCodeList;
	}

	// Get the profile list for Delta/Full
	private ArrayList<String> getProfileList(YFSContext ctx, String profileType) throws Exception {
		KohlsDeploymentUtil dUtil = new KohlsDeploymentUtil();
		Document profileListDoc = dUtil.callGetCommonCodeList(ctx, profileType); // DATASYNC_PROFILE
		Element eleCommonCodeList = profileListDoc.getDocumentElement();
		ArrayList<String> profileList = new ArrayList<String>();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.E_COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			profileList.add(eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC));
			logger.info("Profile name " + eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC));
		}
		Set<String> hs = new HashSet<>();
		hs.addAll(profileList);
		profileList.clear();
		profileList.addAll(hs);
		for (String ll : profileList) {
			logger.info("Trimed profile is " + ll);
		}
		return profileList;
	}

	//Check the date from custom table and populate the same to all - Full/Delta
	// <Profiles> <Profile SyncType="FULL"/> <Profile SyncType="DELTA"/> </Profiles>	 
	public Document getSyncDatetoPopulate(YFSEnvironment env, Document InDoc) throws Exception {
		try {
			YFSContext ctx = (YFSContext) env;
			Element eleStoreList = InDoc.getDocumentElement();
			NodeList storeNodeList = eleStoreList.getElementsByTagName(KohlsPOCConstant.E_PROFILE);
			ArrayList<String> types = new ArrayList<String>();
			for (int i = 0; i < storeNodeList.getLength(); i++) {
				Element storenumberElm = ((Element) storeNodeList.item(i));
				if (storenumberElm.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equalsIgnoreCase(KohlsPOCConstant.SYNC_FULL)) {
					types.add(KohlsPOCConstant.SYNC_FULL);
				} else if (storenumberElm.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equalsIgnoreCase(KohlsPOCConstant.SYNC_DELTA)) {
					types.add(KohlsPOCConstant.SYNC_DELTA);
				}
			}
			logger.info("Input received to pupolate profiles " + SCXmlUtil.getString(InDoc));
			// < DataPumpSyncProcess SyncProcess='Export' SyncTargetID='CORP' />			
			Document lastFullDeltaSynInDoc = SCXmlUtil.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
			Element lastFullElm = lastFullDeltaSynInDoc.getDocumentElement();
			lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, KohlsPOCConstant.A_EXPORT);
			lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);
			if (types.size() == 2) {
				logger.info("It has DELTA and FULL");
			} else if (types.size() == 1) {
				lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, types.get(0));
			} else if(types.size() < 2 || types.isEmpty()){				
				logger.error("The profiles passed are incorrect");
				Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.CORP);
				Element errElm = errDoc.getDocumentElement();
				errElm.setAttribute(KohlsPOCConstant.MESSAGE, "The profiles passed are incorrect");
				return errDoc;				
			}
			logger.info("Input to GetDataPumpSyncProcessList is " + SCXmlUtil.getString(lastFullDeltaSynInDoc));
			Document lastFullDeltaSynOutDoc = KohlsCommonUtil.invokeService(ctx,
					KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, lastFullDeltaSynInDoc);
			logger.info("GetDataPumpSyncProcessList output is " + SCXmlUtil.getString(lastFullDeltaSynOutDoc));
			Element elmLastFullSyncDateOutDoc = lastFullDeltaSynOutDoc.getDocumentElement();
			NodeList nodeListFullDelta = elmLastFullSyncDateOutDoc
					.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);

			Document docDataPumpSyncProcess = SCXmlUtil.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
			Element elmDataPumpSyncProcess = docDataPumpSyncProcess.getDocumentElement();
			elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, KohlsPOCConstant.A_EXPORT);
			elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);
			for (int il = 0; il < nodeListFullDelta.getLength(); il++) {
				Element eleFullDelta = ((Element) nodeListFullDelta.item(il));
				if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equals(KohlsPOCConstant.SYNC_DELTA)
						&& YFCCommon.isVoid(eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE))) {
					// DELTA
					elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_DELTA);
					if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE).equalsIgnoreCase(KohlsPOCConstant.TABLE_TYPE_MASTER)) {
						boolean DeltaProfileVal = true;
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
						for (String prf : getProfileList(ctx, KohlsPOCConstant.DATASYNC_PROFILE)) {
							logger.info("Delta profile is " + prf);
							if (!prf.equalsIgnoreCase(KohlsPOCConstant.P_CONFIGURATION_D)) {
								if (DeltaProfileVal) {
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY,
											eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP,
											eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, prf);
									logger.debug("Input to ManageDataPumpSyncProcess MASTER is "
											+ XMLUtil.getXMLString(docDataPumpSyncProcess));
									Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
											KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST,
											docDataPumpSyncProcess);									
									DeltaProfileVal = false;
									logger.debug("Output from ManageDataPumpSyncProcess MASTER " + DeltaProfileVal + ", "
											+ XMLUtil.getXMLString(docOutput3));
									elmDataPumpSyncProcess.removeAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY);
								} else {
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP,
											eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, prf);
									logger.debug("Input from ManageDataPumpSyncProcess MASTER "
											+ XMLUtil.getXMLString(docDataPumpSyncProcess));
									Document docOutput3 = KohlsCommonUtil.invokeService(env,
											KohlsPOCConstant.API_CREATE_DATA_PUMP_SYNC_PROCESS_LIST,
											docDataPumpSyncProcess);
									logger.debug("Output from ManageDataPumpSyncProcess MASTER " + DeltaProfileVal + " = "
											+ XMLUtil.getXMLString(docOutput3));
								}
							}
						}
					} else if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE).equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, KohlsPOCConstant.A_CONFIGURATION);
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY,
								eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP,
								eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
						logger.debug("Input from ManageDataPumpSyncProcess CONFIG "
								+ XMLUtil.getXMLString(docDataPumpSyncProcess));
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE,
								KohlsPOCConstant.P_CONFIGURATION_D);
						Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
								KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST, docDataPumpSyncProcess);
						logger.debug("Output from ManageDataPumpSyncProcess CONFIGURATION "
								+ XMLUtil.getXMLString(docOutput3));
					}
				} else if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equals(KohlsPOCConstant.SYNC_FULL)
						&& YFCCommon.isVoid(eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE))) {
					elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_TYPE, KohlsPOCConstant.SYNC_FULL);
					if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE).equalsIgnoreCase(KohlsPOCConstant.TABLE_TYPE_MASTER)) {
						boolean NoProfileVal = true;
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
						for (String prf : getProfileList(ctx, KohlsPOCConstant.DATASYNC_PROFLE_FULL)) {
							logger.info("Full profile is " + prf);
							if (!(prf.equalsIgnoreCase(KohlsPOCConstant.P_INITIAL_ISS_D) || prf.equalsIgnoreCase(KohlsPOCConstant.P_POD_MIGRATION)
									|| prf.equalsIgnoreCase(KohlsPOCConstant.P_CONFIGURATION_D))) {								
								if (NoProfileVal) {
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY,
											eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP,
											eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, prf);
									logger.debug("Input from ManageDataPumpSyncProcess MASTER "
											+ XMLUtil.getXMLString(docDataPumpSyncProcess));
									Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
											KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST,
											docDataPumpSyncProcess);
									logger.debug("Output from ManageDataPumpSyncProcess MASTER " + " = " + NoProfileVal
											+ XMLUtil.getXMLString(docOutput3));
									NoProfileVal = false;
									elmDataPumpSyncProcess.removeAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY);
								} else {
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP,
											eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
									elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE, prf);
									logger.debug("Input to CreateDataPumpSyncProcess MASTER "
											+ XMLUtil.getXMLString(docDataPumpSyncProcess));
									Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
											KohlsPOCConstant.API_CREATE_DATA_PUMP_SYNC_PROCESS_LIST,
											docDataPumpSyncProcess);
									logger.debug("Output from CreateDataPumpSyncProcess MASTER " + NoProfileVal + " = "
											+ XMLUtil.getXMLString(docOutput3));
								}
							}
						}
					} else if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE).equalsIgnoreCase(KohlsPOCConstant.A_CONFIGURATION)) {
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, KohlsPOCConstant.A_CONFIGURATION);
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY,
								eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROCESS_KEY));
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP,
								eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_LAST_TIMESTAMP));
						elmDataPumpSyncProcess.setAttribute(KohlsPOCConstant.E_SYNC_PROFILE,
								KohlsPOCConstant.P_CONFIGURATION_D);
						logger.debug("Input to ManageDataPumpSyncProcess CONFIGURATION "
								+ XMLUtil.getXMLString(docDataPumpSyncProcess));
						Document docOutput3 = KohlsCommonUtil.invokeService(ctx,
								KohlsPOCConstant.API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST, docDataPumpSyncProcess);
						logger.debug("Output from ManageDataPumpSyncProcess CONFIGURATION " + XMLUtil.getXMLString(docOutput3));
					}
				}
			}
			Document resultDoc = KohlsCommonUtil.invokeService(ctx,
					KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, lastFullDeltaSynInDoc);
			logger.info("Final output of GetDataPumpSyncProcessList " + XMLUtil.getXMLString(resultDoc));
			return outputProfileDoc(resultDoc);
		} catch (Exception e) {
			logger.error("Exception while populating the table " + e.getMessage());
			Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.CORP);
			Element errElm = errDoc.getDocumentElement();
			errElm.setAttribute(KohlsPOCConstant.MESSAGE, e.getMessage());
			return errDoc;
		}
	}
	
	private Document outputProfileDoc(Document resultDoc) throws Exception {
		Element eleProfileList = resultDoc.getDocumentElement();
		NodeList nodeListProfile = eleProfileList.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
		logger.debug("Length of the nodes is " + nodeListProfile.getLength());
		int fullVal = 0, deltaVal = 0;
		for (int i = 0; i < nodeListProfile.getLength(); i++) {
			Element eleProfile = ((Element) nodeListProfile.item(i));
			if (eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equalsIgnoreCase(KohlsPOCConstant.SYNC_FULL)) {
				fullVal++;
			} else if (eleProfile.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equalsIgnoreCase(KohlsPOCConstant.SYNC_DELTA)) {
				deltaVal++;
			}
		}
		Document outDocProfile = SCXmlUtil.createDocument(KohlsPOCConstant.CORP);
		Element elmDocProfile = outDocProfile.getDocumentElement();
		Element elmchildFull = SCXmlUtil.createChild(elmDocProfile, KohlsPOCConstant.SYNC_FULL);
		elmchildFull.setAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS, String.valueOf(fullVal));
		Element elmChildDelta = SCXmlUtil.createChild(elmDocProfile, KohlsPOCConstant.SYNC_DELTA);
		elmChildDelta.setAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS, String.valueOf(deltaVal));
		logger.info(SCXmlUtil.getString(outDocProfile));
		return outDocProfile;
	}
		
}
