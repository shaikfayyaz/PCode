package com.kohls.poc.util;

import java.io.BufferedReader;
import java.io.FileReader;

public class KohlsPocLCSGeneralStub {
	protected static String TEST_FILE_PATH="/kohls/apps/file/";
	public static String getTextFile(String FilePathName, String sPlaceHolder)  throws Exception {
		
		BufferedReader br = new BufferedReader(new FileReader(TEST_FILE_PATH+FilePathName+".txt"));
		String jsonResponse="";
		try {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    jsonResponse = sb.toString();
		} finally {
		    br.close();
		}
		return jsonResponse;
	}
	
	public static String getTextFile(String fileName)  throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String jsonResponse="";
		try {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    jsonResponse = sb.toString();
		} finally {
			if (br != null) {
				br.close();
			}
		}
		return jsonResponse;
	}
	

}
