package com.kohls.poc.util;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCCommercePSIStatusGenerator;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIDocumentsUtilForPOS;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIStatus;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.VerifonePointIntegrationClient;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.CapturePSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.NRSCPSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.TokenQuery;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.VoidPSIRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.manager.OrderManager;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.manager.SessionManager;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCPinPadPostVoidOperations extends NRSCPSIRequest {
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCPinPadPostVoidOperations.class.getName());
	}

	private boolean bIsDebugEnabled = logger.isDebugEnabled();
	// private boolean bIsDebugEnabled = true;

	static String[] declineCodes = {"6", "0", "93", "97", "1010", "59008", "59024"};
	static String[] expectedCodes =
		{"59049", "4", "5", "7", "59001", "59007", "59046", "59026", "59023", "59025", "59027"};
	public static final List<String> ERROR_RESULT_CODES =
			Arrays.asList(new String[] {"59023", "59024", "59025", "59026", "59027"});
	static List<String> expectedCodesList = Arrays.asList(expectedCodes);
	static List<String> declineCodesList = Arrays.asList(declineCodes);

	static DecimalFormat formatter = new DecimalFormat("0.00");

	private static final int      START_SESSION_TIMEOUT            = 20000;

	private static final int      START_SESSION_RETRY_INTERVAL     = 50;


	public KohlsPoCPinPadPostVoidOperations(PSIStatus status) {
		super(KohlsPOCConstant.PINPAD_PAYMENT_OPERATION, KohlsPOCConstant.PINPAD_VOID_OPERATION,
				status);
	}

	public KohlsPoCPinPadPostVoidOperations(PSIStatus status, String functionType, String command) {
		super(functionType, command, status);
	}

	public KohlsPoCPinPadPostVoidOperations() {}

	/**
	 * Created By IBM
	 * 
	 * @param env
	 * @param docPayment
	 * @return
	 * @throws Exception
	 */
	public Document doVoidRequest(YFSEnvironment env, Document docPayment) throws Exception {
		logger.beginTimer("KohlsPoCPinPadPostVoidOperations.doVoidRequest");
		if (logger.isDebugEnabled()) {  
			logger.debug("Input xml to KohlsPoCPinPadPostVoidOperations is: " + XMLUtil.getXMLString(docPayment));
		}
		boolean isTrainingMode = ServerTypeHelper.amIOnTrainingServer();
		Document responseXml = null;

		Element elePayment = docPayment.getDocumentElement();

		if (YFCCommon.isVoid(elePayment)) {
			throw new YFSException("No Payment method found to process");
		}
		//Calling getPSIStatus API
		Document docPSIInput = formInputForPSI(elePayment);
		Document docPSIStatusOut = KOHLSBaseApi.invokeAPI(env, "getPSIStatusListForPOS", docPSIInput);
		Element elePsiStatus =
				(Element) docPSIStatusOut.getElementsByTagName(KohlsXMLLiterals.E_PSI_STATUS).item(0);

		if (!YFCCommon.isVoid(elePsiStatus)) {
			YFSContext ctx = YFSContextManager.getInstance().getContextFor(env);
			NRSCCommercePSIStatusGenerator generator =
					new NRSCCommercePSIStatusGenerator(elePsiStatus, ctx);
			PSIStatus psiStatus = generator.generatePSIStatus();
			KohlsPoCPinPadPostVoidOperations request = new KohlsPoCPinPadPostVoidOperations(psiStatus);
			updatePSIRequest(elePayment, request);

			SessionManager session = SessionManager.getSession(psiStatus);
			session.cancellableOperationStarting();
			OrderManager orderManager = SessionManager.getOrderManager(psiStatus);
			boolean localSessionStarted = false;
			if (!orderManager.inSession()) {
				verifyPinPadSession (session);
				localSessionStarted = true;
			}

			long start = 0;
			long end = 0;
			try {
				start = System.currentTimeMillis();
				managePinpadUpdates(session, true);
				responseXml = VerifonePointIntegrationClient.sendWithCounterRetry(psiStatus, request, true);

			} catch (Exception ex) {
				ex.printStackTrace();
				throw new YFSException(ex.getMessage());
			} finally {
				if (!YFCCommon.isVoid(responseXml)) {

					String resultCode = SCXmlUtil.getChildElement(responseXml.getDocumentElement(), "RESULT")
							.getTextContent();
					// String terminationStatus = SCXmlUtil.getChildElement(responseXml.getDocumentElement(),
					// KohlsXMLLiterals.E_TERMINATION_STATUS).getTextContent();
					if (!("5".equals(resultCode) || "4".equals(resultCode))) {
						try {
							// if (!KohlsPOCConstant.PAYMENT_DEBIT_CARD.equalsIgnoreCase(paymentType)) {
							VerifonePointIntegrationClient.refreshItemList(psiStatus);
							// }
						} catch (Exception ex) {
							// let the txn continue - log the occurrence
							logger.error(
									"KohlsPoCPinPadPostVoidOperations.doVoidRequest - exception trying to refresh item list");
						}
					}
				}
				managePinpadUpdates(session, false);
				session.cancellableOperationSent();
				end = System.currentTimeMillis();

				if (localSessionStarted || orderManager.inSession()) {
					// System.out.println("Order Manager is: cancelling"+orderManager.inSession());
					orderManager.forceSessionEnd();
					//VerifonePointIntegrationClient.finishSession(psiStatus);
				} else {
					logger.error("KohlsPoCPinPadOperations.doTokenQuery - problem refreshing item list");
				}
			}

			if (!YFCCommon.isVoid(responseXml)) {
				Element responseDocElement = responseXml.getDocumentElement();
				NRSCPSIRequest.createChild(responseXml, null, KohlsXMLLiterals.E_AUTH_REQUEST_TIME,
						Long.toString(start));
				NRSCPSIRequest.createChild(responseXml, null, KohlsXMLLiterals.E_AUTH_RESP_TIME,
						Long.toString(end));
				logger.error("KohlsPoCPinPadPostVoidOperations.doVoidRequest - response from pinpad is "
						+ XMLUtil.getElementXMLString(responseDocElement));
				String responseCode = PSIDocumentsUtilForPOS.selectFirst(responseDocElement,
						KohlsXMLLiterals.E_RESULT_CODE, "990099");
				if (!(expectedCodesList.contains(responseCode))
						&& !(declineCodesList.contains(responseCode))) {
					logger.error(
							"KohlsPoCPinPadPostVoidOperations.doVoidRequest - exception trying to refresh item list");
				}
			} else {
				throw new YFSException("Payment Failure");
			}
		}

		logger.endTimer("KohlsPoCPinPadPostVoidOperations.doVoidRequest");

		return responseXml;

	}

	/**
	 * @param elePayment
	 * @param request
	 */
	private void updatePSIRequest(Element elePayment,
			KohlsPoCPinPadPostVoidOperations request) {
		String paymentType = elePayment.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
		String token = elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO);
		//String requestedAmount = elePayment.getAttribute(KohlsXMLLiterals.A_AMOUNT);
		String ctroutD = elePayment.getAttribute("ExtraDetails10");
		//String creditCardExpDate = elePayment.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE);
		String orderNo = elePayment.getAttribute(KohlsXMLLiterals.A_ORDER_NO);
		String sManualEntry = elePayment.getAttribute(KohlsXMLLiterals.A_MANUAL_ENTRY);
		String sKohlsChargeOnly = elePayment.getAttribute(KohlsXMLLiterals.A_KOHLS_CHARGE_ONLY);
		String isDebitTenderEnabled =
				elePayment.getAttribute(KohlsXMLLiterals.A_DEBIT_TENDER_ENABLED);

		if (!YFCCommon.isVoid(sManualEntry)
				&& ("Y".equalsIgnoreCase(sManualEntry) || "true".equalsIgnoreCase(sManualEntry))) {
			sManualEntry = KohlsPOCConstant.TRUE.toUpperCase();
		} else {
			sManualEntry = KohlsPOCConstant.FALSE.toUpperCase();
		}

		request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, sManualEntry);

		if (YFCCommon.isVoid(orderNo)) {
			orderNo = elePayment.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1);
		}

		if(!YFCCommon.isVoid(orderNo) && orderNo.length() > 17) {
			orderNo = orderNo.substring(orderNo.length()-17);
		}

		if (!YFCCommon.isVoid(paymentType)) {

			if (KohlsPOCConstant.KOHL_CHARGE_CARD.equalsIgnoreCase(paymentType)) {
				if (KohlsPOCConstant.TRUE.equalsIgnoreCase(sManualEntry)) {
					// always use manual entry true for PRIV_LBL only for now
					request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, KohlsPOCConstant.TRUE.toUpperCase());
					if (KohlsPOCConstant.TRUE.equalsIgnoreCase(sKohlsChargeOnly)) {
						request.add(VoidPSIRequest.ExtFields.PAYMENT_TYPE,
								KohlsPOCConstant.TENDER_TYPE_PRIV_LBL);
					} else {
						request.add(KohlsPOCConstant.PAYMENT_TYPES, KohlsPOCConstant.TENDER_TYPE_PRIV_LBL
								+ "|" + KohlsPOCConstant.PAYMENT_CREDIT_LABEL);
					}
				} else {
					request.add(VoidPSIRequest.ExtFields.PAYMENT_TYPE,
							KohlsPOCConstant.TENDER_TYPE_PRIV_LBL);
				}
			}
			// accomodating for debit transaction
			/* else if (KohlsPOCConstant.PAYMENT_DEBIT_CARD.equalsIgnoreCase(paymentType)) {
        request.add(VoidPSIRequest.ExtFields.PAYMENT_TYPE, KohlsPOCConstant.PAYMENT_DEBIT);
        request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, sManualEntry);
      } */else if (KohlsPOCConstant.PAYMENT_CREDIT_CARD.equalsIgnoreCase(paymentType)
			&& !YFCCommon.isVoid(token)) {
		request.add(VoidPSIRequest.ExtFields.PAYMENT_TYPE,
				KohlsPOCConstant.PAYMENT_CREDIT_LABEL);
		request.add(KohlsXMLLiterals.E_MANUAL_ENTRY, sManualEntry);
      } else {
		if (KohlsPOCConstant.TRUE.equalsIgnoreCase(isDebitTenderEnabled)) {
			request.add(KohlsPOCConstant.PAYMENT_TYPES,
					KohlsPOCConstant.PAYMENT_CREDIT_PRIVATE_LABEL_DEBIT);
		} else {
			request.add(KohlsPOCConstant.PAYMENT_TYPES,
					KohlsPOCConstant.PAYMENT_CREDIT_PRIVATE_LABEL);
		}
      }
		}
		request.add(VoidPSIRequest.ExtFields.CTROUTD, ctroutD);  

		logger.error("KohlsPoCPinPadPostVoidOperations.doVoidRequest - request to Pinpad is "
				+ XMLUtil.getXMLString(request.getDocument()));
	}


	protected String invoiceNumber(String orderNo) {
		int orderNoSize = orderNo.length();
		return orderNo.substring(orderNoSize - 4, orderNoSize);
	}

	private Document formInputForPSI(Element elePayment) throws Exception {
		logger.beginTimer("KohlsPSARefund.formInputForPSI");
		Document docPSIStatus = XMLUtil.createDocument(KohlsXMLLiterals.E_PSI_STATUS);
		Element elePSIStatus = docPSIStatus.getDocumentElement();
		elePSIStatus.setAttribute(KohlsXMLLiterals.A_CLIENT_ID,
				elePayment.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
		if (!YFCCommon.isVoid(elePayment.getAttribute(KohlsXMLLiterals.A_STORE_ID))) {
			elePSIStatus.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE,
					elePayment.getAttribute(KohlsXMLLiterals.A_STORE_ID));
		} else {
			elePSIStatus.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE,
					elePayment.getAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE));
		}
		if (bIsDebugEnabled) {
			logger.debug("Input to getPSIStatusListForPOS" + XMLUtil.getXMLString(docPSIStatus));
		}
		logger.endTimer("KohlsPSARefund.formInputForPSI");
		return docPSIStatus;
	}

	protected void managePinpadUpdates(SessionManager session, boolean disable) {
		OrderManager order = SessionManager.getOrderManager(session.getPSIStatus());
		if (order != null) {
			if (logger.isDebugEnabled()) {
				logger.debug(new StringBuilder().append("managePINPadUpdates: ")
						.append((!(disable)) ? "enable" : "disable").toString());
			}
			if (disable == true) {
				order.disableUpdates();
			} else {
				order.enableUpdates();
			}
		} else {
			if (!(logger.isDebugEnabled())) {
				logger.debug("managePINPadUpdates: NO ORDER MANAGER");
			}
		}
	}

	public void verifyPinPadSession( SessionManager session )
	{
		if ( session != null )
		{
			final OrderManager orderMgr = SessionManager.getOrderManager( session.getPSIStatus() );
			if ( !( orderMgr.inSession() ) )
			{
				ScheduledExecutorService sessionStartPoll = Executors.newSingleThreadScheduledExecutor();
				Callable<Boolean> checkSessionStart = new Callable<Boolean>()
						{

					@Override
					public Boolean call() throws Exception
					{
						return orderMgr.inSession();
					}

						};
						// start a PIN pad session if one has not yet been created
						orderMgr.pushSessionStart( null, "0000", "0000" );
						orderMgr.forceSessionStart( "0000", "0000" );

						try
						{
							// prevent race condition between session start and sending of the prompt request by blocking until session start completes
							boolean sessionStarted = false;
							int maxRetries = START_SESSION_TIMEOUT / ( ( START_SESSION_RETRY_INTERVAL == 0 ) ? 1 : START_SESSION_RETRY_INTERVAL );

							while ( !sessionStarted && maxRetries > 0 )
							{
								ScheduledFuture<Boolean> pollResult = sessionStartPoll.schedule( checkSessionStart, START_SESSION_RETRY_INTERVAL, TimeUnit.MILLISECONDS );
								try
								{
									sessionStarted = pollResult.get();
								}
								catch ( Exception e )
								{
									if ( logger.isDebugEnabled() )
									{
										// log and continue looping
										logger.debug( "Thread interrupted while polling for session start", e );
									}
								}
								finally
								{
									maxRetries--;
								}
							}
							if ( maxRetries <= 0 )
							{
								if ( logger.isInfoEnabled() )
								{
									logger.info( String.format("Session not started after polling for %d milliseconds; continuing with prompt request", START_SESSION_TIMEOUT ) );
								}
							}
						}
						finally
						{
							sessionStartPoll.shutdown();
						}
			}
		}
	}

	/**
	 * This method changes the credit card type to 05,06,07,08 depending on the input
	 * @param strCreditCardType
	 * @return
	 */

	public String changeCreditCardType(String strCreditCardType) {
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setCreditCardType --Start");
			logger.debug("KohlsPSARefund.setCreditCardType before strCreditCardType"
					+ strCreditCardType);
		}
		if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_VISA)) {
			strCreditCardType = KohlsConstant.VISA_05;
		} else if (strCreditCardType
				.equalsIgnoreCase(KohlsConstant.PSA_MASTERCARD)) {
			strCreditCardType = KohlsConstant.MASTERCARD_06;
		} else if (strCreditCardType
				.equalsIgnoreCase(KohlsConstant.PSA_DISCOVER)) {
			strCreditCardType = KohlsConstant.DISCOVER_07;
		} else if (strCreditCardType.equalsIgnoreCase(KohlsConstant.PSA_AMEX)) {
			strCreditCardType = KohlsConstant.AMEX_08;
		}
		if(bIsDebugEnabled){
			logger.debug("KohlsPSARefund.setCreditCardType after strCreditCardType"
					+ strCreditCardType);
			logger.debug("KohlsPSARefund.setCreditCardType --End");
		}
		return strCreditCardType;
	}
	
	public static void updatePinpadSession(YFSEnvironment yfsEnv, Element eleCurrPayMeth, Document inDoc){
		logger.beginTimer("KohlsPSAChargeForPV.updatePinpadSession --Start");
		
		try {
			Element eleOrderOutRoot = inDoc.getDocumentElement();
	        eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, eleCurrPayMeth.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
	        eleOrderOutRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, eleCurrPayMeth.getAttribute(KohlsPOCConstant.A_STORE_ID));
	        eleOrderOutRoot.setAttribute(KohlsPOCConstant.OPERATION,
	                "updateSession");  
	        eleOrderOutRoot.setAttribute(KohlsPOCConstant.A_ORDER_DETAILS_INCLUDED, KohlsPOCConstant.TRUE);
			KOHLSBaseApi.invokeAPI(yfsEnv, KohlsPOCConstant.API_MANAGE_PSI_ORDER_FOR_POS, inDoc);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.beginTimer("KohlsPSAChargeForPV.updatePinpadSession --Start");
		
	}
}
