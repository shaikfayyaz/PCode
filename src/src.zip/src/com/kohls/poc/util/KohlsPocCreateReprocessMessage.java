package com.kohls.poc.util;

import java.util.Properties;

import org.apache.commons.lang.math.NumberUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPocCreateReprocessMessage extends KOHLSBaseApi {

	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPocCreateReprocessMessage.class);
	private Properties _properties = null;
	KohlsReprocessRequestUtil requestUtilObj = new KohlsReprocessRequestUtil();
	
	public Document createMessageForReprocessing(YFSEnvironment env,
			Document inputDoc) throws Exception {
		logger.beginTimer("KohlsPocCreateReprocessMessage.createMessageForReprocessing");
		String sServciceName =_properties.getProperty("Service");
		String inputHasColony =_properties.getProperty("InputHasColony");
		boolean isCorpOrder = isCorpOrder(inputDoc);
		
		logger.debug("Service retirived is "+sServciceName);
		requestUtilObj.loadPropsFromCommonCode(env,"COMMON_REPROCESS", sServciceName);
		boolean bypassMQPosting = requestUtilObj.bypassMQPosting(sServciceName);
		boolean byPassMQPostingForCorpOnly = requestUtilObj.byPassMQPostingForCorpOnly(sServciceName);
		if(byPassMQPostingForCorpOnly && isCorpOrder) // Only for a Corp order and for a configured service name, MQ posting will be bypassed.
		{
			bypassMQPosting = true;
			logger.debug("MQ Posting for the Service"+sServciceName+"will be skipped");
		}
		String isTimerRequired = null;
		if(!YFCCommon.isVoid(env.getTxnObject("isTimerRequired")))
		{
			 isTimerRequired = (String)env.getTxnObject("isTimerRequired");
		}
		else
		{
			isTimerRequired = requestUtilObj.getCommonCodeValue(env, "TIMER_FOR_MQFAILURE", "N");
			env.setTxnObject("isTimerRequired", isTimerRequired);
		}
		
		String isDirectToMQ = null;
		if(!YFCCommon.isVoid(env.getTxnObject("isDirectToMQ")))
		{
			isDirectToMQ = (String)env.getTxnObject("isDirectToMQ");
		}
		else
		{
			isDirectToMQ = requestUtilObj.getCommonCodeValue(env, "DIRECT_MQ_SERVICE", "N");
			env.setTxnObject("isDirectToMQ", isDirectToMQ);
		}
		//PerformanceImprovement-Start
		//Map<String, Object> hmReprocessHM = requestUtilObj.getReprocessHM();
		int iFailureCounter =   KohlsReprocessRequestUtil.intFailureCounter;  
		int iRetryThreshold = KohlsReprocessRequestUtil.intReprocessRetryThreshold;  
		logger.debug("iFailureCounter , iRetryThreshold : " +iFailureCounter+" "+iRetryThreshold);
		//Y is direct , N is through Agent
		if(KohlsPOCConstant.YES.equalsIgnoreCase(isDirectToMQ) && !bypassMQPosting) {
			try{
				if((iFailureCounter <= iRetryThreshold)){
					logger.info("Message Posted directly to MQ");
					if(KohlsPOCConstant.YES.equalsIgnoreCase(isTimerRequired)){ 
						invokeServiceWithTimer(env, sServciceName, inputDoc);
					}else{
						invokeService(env, sServciceName, inputDoc);
					}
				} else if(iFailureCounter > iRetryThreshold){
				    logger.info("Counter Threshold has elapsed : "+iFailureCounter);
					if(KohlsReprocessRequestUtil.isThreaholdTimeElapsed()){
					    logger.info("Threshold timelapse has passed. so calling service");
						invokeService(env, sServciceName, inputDoc);
						//Reset the counter only if successful call happens
						logger.info("Successfully able to post to MQ. So resetting the counters");
						KohlsReprocessRequestUtil.resetFailedCounterAndTimer();
					} else {
					    logger.info("Threshold timelapse has note yet passed. so creating reprocess table entry");
						callCreateReprocessRequest(env, sServciceName, inputDoc,inputHasColony);
						KohlsReprocessRequestUtil.incrementFailedCounter();  
					}
				}
			} catch (Exception e) {
				logger.error("Exception in putting directly to MQ");
				//e.printStackTrace();
				if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {
					YFSException es = (YFSException) e;
					if(es.getErrorCode().equalsIgnoreCase("EX_Reprocess_Table")){
						logger.error(e.getMessage());
						throw es;
					}else{
					    logger.error("MQ issue is not resolved yet. Creating reprocess table entry!");
					    logger.error(e.getMessage());
					    KohlsReprocessRequestUtil.incrementFailedCounter(); 
						callCreateReprocessRequest(env, sServciceName, inputDoc,inputHasColony);
						 
					}
				} else {
				    logger.error("MQ issue is not resolved yet. Creating reprocess table entry!");
				    logger.error(e.getMessage());
					KohlsReprocessRequestUtil.incrementFailedCounter();  
					callCreateReprocessRequest(env, sServciceName, inputDoc,inputHasColony);
				}
			}
			

		} else {
			logger.info("Message Posted to MQ through Reprocess Agent");
			callCreateReprocessRequest(env, sServciceName, inputDoc,inputHasColony);
		}
		//PerformanceImprovement-End
		logger.endTimer("KohlsPocCreateReprocessMessage.createMessageForReprocessing");
		return inputDoc;
	}

	
   private void invokeServiceWithTimer(YFSEnvironment env, String sServciceName, Document inputDoc) throws Exception {
	   long startTime = System.currentTimeMillis();
	   KOHLSBaseApi.invokeService(env,sServciceName,inputDoc);
	   long endTime = System.currentTimeMillis();
	   long totalTime = endTime - startTime;
	   logger.debug("Total Time taken by Service : "+sServciceName+" in posting the message to the queue"+": "+totalTime);
	   incrementFailureCounterIfRequired(totalTime);
		
	}

	
	public void incrementFailureCounterIfRequired(long serviceExecutionTime) {
		
		String sTimeLapseThreshold = KohlsReprocessRequestUtil.getPropertyValue("REPROCESS_MQ_FAILOVER_TIMELAPSE_THRESHOLD", "25");
		if(!YFCCommon.isVoid(KohlsReprocessRequestUtil.codeShortDescription) 
				&& NumberUtils.isNumber(KohlsReprocessRequestUtil.codeShortDescription))
		{
			sTimeLapseThreshold = KohlsReprocessRequestUtil.codeShortDescription;
		}
		//String sTimeLapseThreshold = KohlsReprocessRequestUtil.getPropertyValue("REPROCESS_MQ_FAILOVER_TIMELAPSE_THRESHOLD", "300");
		long timeLapseThreshold = Long.parseLong(sTimeLapseThreshold);
		if(serviceExecutionTime>=timeLapseThreshold){
			logger.debug("Incrementing the failure Counter because MQ posting response time is greater than expected");
			KohlsReprocessRequestUtil.incrementFailedCounter();
		}
		
		
	}



	/**
	 * This method checks for the EntryType attribute in the Order XML. If the inputDoc is not an OrderXML it will return FALSE;
	 * This criteria will be used to identify if Direct Posting to MQ should be enabled or not for a service.
	 * @param inputDoc
	 * @return
	 */
	private boolean isCorpOrder(Document inputDoc) {
		logger.beginTimer("KohlsPocCreateReprocessMessage.isCorpOrder");
		boolean corpOrder = false;

		Element eOrder = (Element) inputDoc.getElementsByTagName(KohlsConstant.ELEM_ORDER).item(0);
        if(!YFCCommon.isVoid(eOrder)){ // A void eOrder will mean that its not an Order XML.
        	String sEntryType= XMLUtil.getAttribute(eOrder, KohlsPOCConstant.ATTR_ENTRY_TYPE);
        	if(KohlsConstants.STORE.equals(sEntryType)){
        		//Only When EntryType="STORE", the order is identified as a CORP order. For ISS the entryType will be "STORE-EDGE".
        		logger.debug("The Order is Generated at CORP");
        		corpOrder = true;
        	}
        }
        logger.endTimer("KohlsPocCreateReprocessMessage.isCorpOrder");
		return corpOrder;
	}

	private void callCreateReprocessRequest(YFSEnvironment env,
			String sServciceName, Document inputDoc, String inputHasColony) throws YFSException{
		logger.beginTimer("KohlsPocCreateReprocessMessage.callCreateReprocessRequest");
		
		try{
		if(ServerTypeHelper.amIOnEdgeServer() || "Y".equalsIgnoreCase(inputHasColony)){
			  requestUtilObj.createReprocessRequest(env, sServciceName, inputDoc);
			}else{
			  requestUtilObj.createReprocessRequest(env, sServciceName, inputDoc, "STORE_GRP_01");
			}
		}catch(Exception e){
            logger.error("Exception in putting to Reprocess table" +e.getMessage());
            throw new YFSException ("Exception posting message to Reprocess table",
            		"EX_Reprocess_Table","Exception posting message to Reprocess table");
		}
		logger.endTimer("KohlsPocCreateReprocessMessage.callCreateReprocessRequest");
	}


	public void setProperties(Properties prop) throws Exception {
		_properties = prop;
	}
}
