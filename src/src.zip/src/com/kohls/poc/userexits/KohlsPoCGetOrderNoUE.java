/*
 * File: KohlsPoCGetOrderNoUE.java Created on Jun 15, 2018 for POC_OMS_IBM_Returns by ibmadmin
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.userexits;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ibm.sterling.Utils;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.tgcs.tcx.gravity.pos.userexit.impl.GetOrderNoUEForPOS;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSGetOrderNoUE;

/**
 * @author ibmadmin
 *
 */
public class KohlsPoCGetOrderNoUE implements YFSGetOrderNoUE {

  private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCGetOrderNoUE.class);
  private static final String desiredDateFormat = "yyMMdd";
  private static final String desiredDateFormat_WithTime = "yyMMddHHmmss";
  private static final String YEAR_FORMAT = "yy";

  /*
   * (non-Javadoc)
   * 
   * @see com.yantra.yfs.japi.ue.YFSGetOrderNoUE#getOrderNo(com.yantra.yfs.japi.YFSEnvironment,
   * java.util.Map)
   */
  public String getOrderNo(YFSEnvironment env, Map inMap) throws YFSUserExitException {
    logger.beginTimer("KohlsPoCGetOrderNoUE.getOrderNo");
    String orderNumber = "";
    try {
      orderNumber = generateOrderNumber(env, inMap);
    } catch (Exception e) {
      logger.error("Error in generating order no: "+ e.getMessage());
      throw new YFSUserExitException (e.getMessage());
    }
    logger.debug("Order Number for Kohls = " + orderNumber);
    logger.endTimer("KohlsPoCGetOrderNoUE.getOrderNo");
    return orderNumber;
  }

  /**
   * Create By ibmadmin *
   * 
   * @param env
   * @param inMap
   * @return
   * @throws Exception 
   */
  @SuppressWarnings("deprecation")
  private String generateOrderNumber(YFSEnvironment env, Map inMap) throws Exception {
    logger.beginTimer("KohlsPoCGetOrderNoUE.generateOrderNumber");
    String sequenceNumber = (String) inMap.get("PosSequenceNo");
    StringBuilder orderNumberStringBuilder = null;
    String storeNumber = (String) inMap.get("SellerOrganizationCode");
    String registerNumber = (String) inMap.get("TerminalID");
    String operatorId = (String) inMap.get("OperatorID");

    if (StringUtils.isBlank(operatorId)) {
      // If any of the above keys are missing..resort back to default order numbering scheme.
      GetOrderNoUEForPOS baseGetOrderNoUEForPOS = new GetOrderNoUEForPOS();
      logger.endTimer("KohlsPoCGetOrderNoUE.generateOrderNumber");
      return baseGetOrderNoUEForPOS.getOrderNo(env, inMap);
    } else {
      // pad zeros if length of sequence # is less than 4
      if (StringUtils.isNotBlank(sequenceNumber)) {
        while (sequenceNumber.length() < 4) {
          sequenceNumber = "0" + sequenceNumber;
        }
      }

      orderNumberStringBuilder = new StringBuilder();

      // MON-DD-YR
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat(desiredDateFormat);
      String callingOrgCode = (String) inMap.get(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
      String ruleValue = KohlsPoCCommonAPIUtil.getRuleValue(env, "USE_TIME_IN_ORDER_NO", callingOrgCode, "N");
      if(Utils.isTrue(ruleValue)) {
        simpleDateFormat = new SimpleDateFormat(desiredDateFormat_WithTime);
      }
      String formattedDate = null;
      YFCDate sOrderDate = (YFCDate) inMap.get(KohlsPOCConstant.A_ORDER_DATE);
      if(!YFCCommon.isVoid(sOrderDate)) {
        //Date orderDate = new SimpleDateFormat(KohlsPOCConstant.INV_DATE_FORMAT).parse(sOrderDate);
        formattedDate = simpleDateFormat.format(sOrderDate);
      } else {
        formattedDate = simpleDateFormat.format(new Date(System.currentTimeMillis()));
      }
      
      orderNumberStringBuilder.append(getDateFormatForTrainingMode(formattedDate));

      // Capture only the last 4 digits of incoming ORG/Store id
      if (storeNumber.length() > 4) {
        int end = storeNumber.length();
        int start = end - 4;
        storeNumber = storeNumber.substring(start, end);
      } else {
        for (int i = storeNumber.length(); i < 4; ++i) {
          orderNumberStringBuilder.append("0");
        }
      }
      orderNumberStringBuilder.append(storeNumber);

      // Append 3 digit register number..pad zeros accordingly

      if (StringUtils.isBlank(registerNumber)) {
        orderNumberStringBuilder.append("000");
      } else if (registerNumber.length() == 3) {
        orderNumberStringBuilder.append(registerNumber);
      } else if (registerNumber.length() > 3) {
        orderNumberStringBuilder
            .append(registerNumber.substring(registerNumber.length() - 3, registerNumber.length()));
      } else if (registerNumber.length() < 3) {
        for (int i = registerNumber.length(); i < 3; ++i) {
          orderNumberStringBuilder.append("0");
        }
        orderNumberStringBuilder.append(registerNumber);
      }

      // Append 4 digit Sequence number..pad zeros if needed
      if (StringUtils.isBlank(sequenceNumber)) {
        sequenceNumber = StringUtils.trimToEmpty(sequenceNumber);
      }
      for (int j = sequenceNumber.length(); j < 4; ++j) {
        orderNumberStringBuilder.append("0");
      }
      orderNumberStringBuilder.append(sequenceNumber);
    }
    logger.endTimer("KohlsPoCGetOrderNoUE.generateOrderNumber");
    return orderNumberStringBuilder.toString();
  }

  private String getDateFormatForTrainingMode(String dateFormat) {
    logger.beginTimer("KohlsPoCGetOrderNoUE.getDateFormatForTrainingMode");
    if (ServerTypeHelper.amIOnTrainingServer() && "yy".length() >= 2)

    {
      int yearTensIndex = "yy".length() - 2;
      char dateFormatChars[] = dateFormat.toCharArray();
      int indexToChange = "yyMMdd".indexOf("yy") + yearTensIndex;
      dateFormatChars[indexToChange] = '9';
      dateFormat = String.valueOf(dateFormatChars);
    }
    logger.endTimer("KohlsPoCGetOrderNoUE.getDateFormatForTrainingMode");
    return dateFormat;
  }

}
