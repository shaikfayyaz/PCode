package com.kohls.poc.api;

import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCHTTPPostConnUtil;
import com.kohls.common.util.XMLUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : KohlsPoCPinPadPairing.java
 * Author : IBM Created : Dec 11 2015
 * Modified : Dec 11 2015 Version : 0.1
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 14/06/2013 IBM First Cut.
 *****************************************************************************
 *
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 * This file is called ON_SUCCESS event of POS_MANAGE_ADMIN_AUDIT transaction.
 * It checks if a training environment is available, if present it gets the pin pad
 * details for store terminal ID combination and updates the training environment
 *
 * @author IBM
 * @version 0.1
 *****************************************************************************/



public class KohlsPoCPinPadPairing extends KOHLSBaseApi {

	private static final YFCLogCategory
 	loggerForPinPadPairing = YFCLogCategory
		.instance(KohlsPoCPinPadPairing.class.getName());

	private Properties _properties = null;

	/**
 	 * This function checks if a training environment is available,if present it gets
 	 * the pin pad details for store terminal ID combination and calls updatePinPadDetails
 	 * method of KohlsPoCHTTPPostConnUtil class to update the pin pad details
 	 *
 	 * @param env
 	 * @param inDoc
 	 * @exception YFSException
 	 *
 	 */

	public void checkPinPadPairingtoTrnMode(YFSEnvironment env, Document inDoc)
	{
		loggerForPinPadPairing.beginTimer("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode");
		
		
		if(loggerForPinPadPairing.isDebugEnabled())
			loggerForPinPadPairing.debug("Input Xml to KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode method is: "+XMLUtil.getXMLString(inDoc));

		//Fetch the URL to training mode if any

		String strTrnModeUrl = getPropertyValue(KohlsPOCConstant.TRAINING_MODE_URL);
		if(!YFCCommon.isVoid(strTrnModeUrl) && !strTrnModeUrl.equalsIgnoreCase(KohlsPOCConstant.EMPTY))
		{
			loggerForPinPadPairing.debug("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode - Training mode URL:"+strTrnModeUrl);
			Element eleAdminAccount = inDoc.getDocumentElement();

			//Create Input for getPSIStatusListForPOS API

			Document docInput =  YFCDocument.createDocument(KohlsPOCConstant.ATTR_PSI_STATUS).getDocument();
		    Element elePSIStatus = docInput.getDocumentElement();
		    elePSIStatus.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleAdminAccount.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
		    elePSIStatus.setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID, eleAdminAccount.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));

		    //Invoking getPSIStatusListForPOS API
		    try{
			    Document docOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_PSI_STATUS_LIST_FOR_POS, docInput);

			    //Call to Training mode
				 if(!YFCCommon.isVoid(docOutput) && docOutput.getDocumentElement().hasChildNodes())
				 {
					 //Changes for getting UserId from COP file - For Production issue - Start
					 //String strUserID = _properties.getProperty(KohlsPOCConstant.STR_USER_ID);
					 String strUserID = getPropertyValue(KohlsPOCConstant.STR_USER_ID);
					 //Changes for getting UserId from COP file - For Production issue - End
					 if(!YFCCommon.isVoid(strUserID) && !strUserID.equalsIgnoreCase(KohlsPOCConstant.EMPTY))
					 {
						loggerForPinPadPairing.debug("The userId from COP file is :" +strUserID); 
						new KohlsPoCHTTPPostConnUtil().updatePinPadDetails(env,docOutput,strTrnModeUrl,strUserID);
					 }
					 else
					 {
						loggerForPinPadPairing.debug("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode: userID is empty or invalid");
					 }
				 }
				 else
				 {
					loggerForPinPadPairing.debug("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode: There are no records in pos_psi_status table for combination -"+eleAdminAccount.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE)+"\t :"+eleAdminAccount.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
				 }
			 }
			 catch(Exception exception)
			 {
				 loggerForPinPadPairing.debug("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode -- Errored out ");
				 exception.printStackTrace();
			 	loggerForPinPadPairing.endTimer("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode");
			 }
		}
		else
		{
			loggerForPinPadPairing.debug("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode - Training mode URL is missing or empty");
		}
		 loggerForPinPadPairing.endTimer("KohlsPoCPinPadPairing.checkPinPadPairingtoTrnMode");
	}

	/**
 	 * This function gets the url from customer_overrides.properties
 	 *
 	 * @param property
 	 *
 	 */

	public static String getPropertyValue(String property)
	{
		loggerForPinPadPairing.beginTimer("KohlsPoCPinPadPairing.getPropertyValue");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		// customer_overrides.properties does not return any value
		if(YFCCommon.isVoid(propValue)){
		loggerForPinPadPairing.debug("##############################Property is empty#################################");
			propValue = "";
		}
		loggerForPinPadPairing.endTimer("KohlsPoCPinPadPairing.getPropertyValue");
		return propValue;
	}


	/**
 	 * This function set the url to properties object
 	 *
 	 * @param prop
 	 *
 	 */
	public void setProperties(Properties prop) throws Exception {
        _properties = prop;
    }
}
