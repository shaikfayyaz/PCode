
/**
 * @author chidananda
 * 
 * This Java class checks for item exclusive. If Exclusive appends ExtnIsExclusionItem attribute as Y at orderLine extension node
 *
 */
package com.kohls.poc.api;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.japi.YFSEnvironment;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCBeforeChangeOrderUE;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.custom.util.StringUtil;


public class KohlsItemExclusionDefinition {

	private static YFCLogCategory logger;
	
	static {
		logger = YFCLogCategory.instance(KohlsItemExclusionDefinition.class.getName());
		
	}
	private static HashMap<String, String> exclusionsMap = new HashMap<String, String>(); 

	public Document getItemExclusionDefinition(YFSEnvironment yfsEnv, Document inputXML)
	{
		
		logger.beginTimer("KohlsItemExclusionDefinition.getItemExclusionDefinition and Status : Start ");
		
		if(inputXML==null)
		{

			logger.debug("KohlsItemExclusionDefinition.getItemExclusionDefinition Input to method getItemExclusionDefinition : Input Document Shpould not be null");
			return inputXML;
		}

		if(logger.isDebugEnabled()){
			logger.debug("KohlsItemExclusionDefinition.getItemExclusionDefinition Input to method getItemExclusionDefinition :"
					+ XMLUtil.getXMLString(inputXML));

        }
		inputXML= updateExclusiveInfo(yfsEnv,inputXML);
		
		if(logger.isDebugEnabled()){
			logger.debug("KohlsItemExclusionDefinition.updateExclusiveInfo output from getItemExclusionDefinition method :"
					+ XMLUtil.getXMLString(inputXML));
		}
		
		
			logger.endTimer("KohlsItemExclusionDefinition.getItemExclusionDefinition and Status :  End");
		return inputXML;
	}




	private Document updateExclusiveInfo(YFSEnvironment yfsEnv, Document inputXML) {

		String finalExclusionInfo=null;
		try {


			Element orderLines = XMLUtil.getFirstElementByName(inputXML.getDocumentElement(),KohlsXMLLiterals.E_ORDER_LINES);
			NodeList orderLineList = orderLines.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);


			for(int i=0;i<orderLineList.getLength();i++)
			{

				Element orderLine=(Element)orderLineList.item(i);
				Element orderLineExtn=XMLUtil.getChildElement(orderLine,KohlsXMLLiterals.E_EXTN);

				String extnClass=orderLineExtn.getAttribute("ExtnItemClass");
				String extnSubClass=orderLineExtn.getAttribute("ExtnItemSubClass");
				String extnDept=orderLineExtn.getAttribute("ExtnItemDept");

				//Execute for the first time
				if(exclusionsMap.isEmpty())
				{
					Document exclusionDefnsOutDoc = KohlsPoCPnPUtil.getExclusions(yfsEnv, "");
					
					if(logger.isDebugEnabled()){
						logger.debug("ItemExclusionDefinition.updateExclusiveInfo output from ItemExclusion API :"
								+ XMLUtil.getXMLString(exclusionDefnsOutDoc));
					}
						
					updateMap(exclusionDefnsOutDoc);
				}


				if(!StringUtil.isEmpty(extnDept))
				{

					finalExclusionInfo=extnDept;

				}

				if(!StringUtil.isEmpty(extnClass))
				{

					finalExclusionInfo=finalExclusionInfo+"-"+extnClass;

				}

				if(!StringUtil.isEmpty(extnSubClass))
				{

					finalExclusionInfo=finalExclusionInfo+"-"+extnSubClass;

				} 

				if (exclusionsMap.containsKey(finalExclusionInfo)){

					SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
					Date activeDate = sdf.parse(exclusionsMap.get(finalExclusionInfo));
					if(YFCDateUtils.getCurrentDate(false).after(activeDate)){
						orderLineExtn.setAttribute("ExtnIsExclusionItem","Y");
					}
				}




			}



		} catch (Exception e) {
			logger.error(e.getMessage());
		}




		return inputXML;
	}

	private void updateMap(Document exclusionDefnsOutDoc) {

		//exclusionsMap
		String finalExclusionInfo=null;
		NodeList exclusionDefnList = exclusionDefnsOutDoc.getElementsByTagName("ExclusionDefn");
		for(int i=0;i<exclusionDefnList.getLength();i++)
		{
			Element exclusionDefn=(Element)exclusionDefnList.item(i);

			String extnClass=exclusionDefn.getAttribute("ExclusionClass");
			String extnSubClass=exclusionDefn.getAttribute("ExclusionSubClass");
			String extnDept=exclusionDefn.getAttribute("ExclusionDept");


			if(!StringUtil.isEmpty(extnDept))
			{

				finalExclusionInfo=extnDept;

			}

			if(!StringUtil.isEmpty(extnClass))
			{

				finalExclusionInfo="-"+extnClass;

			}

			if(!StringUtil.isEmpty(extnSubClass))
			{

				finalExclusionInfo="-"+extnSubClass;

			}

			exclusionsMap.put(finalExclusionInfo,exclusionDefn.getAttribute("ExclusionActiveDate"));
		}

	}


}
