package com.kohls.poc.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * This class is used to stamp the returnOrderLineKey of CORP in
 * CustomAttributes element of ExchangeOrder.This class will be invoked from
 * LoadOfflineOrder on success event.
 * 
 */
public class KohlsUpdateCustomAttributesForEE extends KOHLSBaseApi {
    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsUpdateCustomAttributesForEE.class
            .getName());
    private Map<String, String> returnOrderLineMap = new HashMap<String, String>();
    private Map<String, String> orderedQtyGTZeroMapForReturn = new TreeMap<String, String>();
    private Map<String, String> orderedQtyGTZeroMapForExchange=new TreeMap<String, String>();
    
    public Document updateCustomAttributes(YFSEnvironment env, Document inputXML) throws Exception {
        Element exchangeOrderElement = inputXML.getDocumentElement();
        String entryType = exchangeOrderElement.getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE);
        logger.debug("KohlsUpdateCustomAttributesForEE.updateCustomAttributes  entryType ::" + entryType);
        logger.debug("KohlsUpdateCustomAttributesForEE.updateCustomAttributes  inputXML ::" + inputXML);

        if (KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE.equals(entryType)) {
            // get the return orderlist
            // Form the getOrderList input for return order
            Document returnOrderListForExchange = getReturnOrderListForExchange(env, exchangeOrderElement);
            
            //Fix for PST-5899 - START
            createOrderedQtyMapForReturnAndExchange(returnOrderListForExchange.getDocumentElement(),true);
            
            createOrderedQtyMapForReturnAndExchange(exchangeOrderElement,false);
            //Fix for PST-5899 - END

            
            // get the return orderlinekey for corresponding PrimeLineNo
            updateReturnOrderLineMap(env, returnOrderListForExchange);
            // Form the changeOrder input to stamp customAttributes
            Document inputChangeOrderDoc = formInputXMLForChangeOrder(env, exchangeOrderElement);
            // invoke changeOrder API
            updateOrder(env, inputChangeOrderDoc);

        }
        return inputXML;

    }

    /**
     * @param env
     * @param inputChangeOrderDoc
     * @throws Exception
     */
    private void updateOrder(YFSEnvironment env, Document inputChangeOrderDoc) throws Exception {
        if (null != inputChangeOrderDoc) {
            NodeList orderLineList = inputChangeOrderDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
            if (orderLineList.getLength() > 0) {
                logger.debug("KohlsUpdateCustomAttributesForEE.updateOrder  ::");
                invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, inputChangeOrderDoc);
            }
        }
    }

    /**
     * @param env
     * @param exchangeOrderElement
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     * @throws Exception
     */
    private Document getReturnOrderListForExchange(YFSEnvironment env, Element exchangeOrderElement)
            throws ParserConfigurationException, SAXException, IOException, Exception {
        String returnOrderHeaderKey = exchangeOrderElement
                .getAttribute(KohlsPOCConstant.A_RETURN_ORDER_HEADER_KEY_FOR_EXCHANGE);
        logger.debug("KohlsUpdateCustomAttributesForEE.updateCustomAttributes  ReturnOrderHeaderKeyForExchange ::"
                + returnOrderHeaderKey);
        Document inputReturnOrderListDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        inputReturnOrderListDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
                returnOrderHeaderKey);
        Document returnOrderListTemplate = XMLUtil
                .getDocument("<OrderList><Order OrderNo='' OrderHeaderKey=''><OrderLines><OrderLine OrderedQty='' PrimeLineNo='' SubLineNo='' OrderLineKey=''/></OrderLines></Order></OrderList>");
        Document returnOrderListDoc = invokeAPI(env, returnOrderListTemplate, KohlsPOCConstant.API_GET_ORDER_LIST,
                inputReturnOrderListDoc);
        return returnOrderListDoc;
    }
    
    /**
     * @param returnOrderListForExchange
     * @return
     * This is fix for PST-5899
     * This method filters out the orderline on the basis of orderedQty, 
     * and puts the primelineno and orderline key of the active line
     * in the map for both exchange and return order 
     */
    private void createOrderedQtyMapForReturnAndExchange(Element returnOrderListForExchangeEle,boolean IsreturnOrder){
		NodeList orderLinesList = returnOrderListForExchangeEle.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES);
        if (orderLinesList.getLength() > 0) {
            Element orderLinesElement = (Element) orderLinesList.item(0);           	
            List<Element> orderLineList = XMLUtil.getElementsByTagName(orderLinesElement,
                    KohlsPOCConstant.ELEM_ORDER_LINE);
           
	            for (Element orderLine : orderLineList) {
	            	if(!YFCCommon.isVoid(orderLine)){
	            	String sOrderedQty=orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
	            	String sPrimeLineNo=orderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
	
	            	Double dOrderedQty=Double.parseDouble(sOrderedQty);
	            	String sOrderLineKey=orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
	
	            	if(dOrderedQty>0){
	            		if(IsreturnOrder)
	            		{
	            			orderedQtyGTZeroMapForReturn.put(sPrimeLineNo, sOrderLineKey);
	            		}
	            		else{
	            			orderedQtyGTZeroMapForExchange.put(sPrimeLineNo, sOrderLineKey);
	            		}                			
	            	}
	            }
           	  }
            }   	
    }
    
    

    /**
     * @param env
     * @param returnOrderList
     */
    private void updateReturnOrderLineMap(YFSEnvironment env, Document returnOrderList) {
        if (null != returnOrderList) {
            NodeList orderLinesList = returnOrderList.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES);
            if (orderLinesList.getLength() > 0) {
                Element orderLinesElement = (Element) orderLinesList.item(0);
                List<Element> orderLineList = XMLUtil.getElementsByTagName(orderLinesElement,
                        KohlsPOCConstant.ELEM_ORDER_LINE);
                for (Element orderLine : orderLineList) {
                    String primeLineNo = orderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                    logger.debug("KohlsUpdateCustomAttributesForEE.updateReturnOrderLineMap return primeLineNo ::"
                            + primeLineNo);
                    String orderLineKey = orderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
                    logger.debug("KohlsUpdateCustomAttributesForEE.updateReturnOrderLineMap  return orderLineKey ::"
                            + orderLineKey);
                    returnOrderLineMap.put(primeLineNo, orderLineKey);
                }
            }
        }

    }

    /**
     * @param env
     * @param exchangeOrderElement
     * @return
     * @throws ParserConfigurationException
     */
    private Document formInputXMLForChangeOrder(YFSEnvironment env, Element exchangeOrderElement)
            throws ParserConfigurationException {    	
        Document inputChangeOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element inputChangeOrderElement = inputChangeOrderDoc.getDocumentElement();
        inputChangeOrderElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
                exchangeOrderElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
        Element exchangeOrderLinesElement = inputChangeOrderDoc.createElement(KohlsPOCConstant.ELEM_ORDER_LINES);
        inputChangeOrderElement.appendChild(exchangeOrderLinesElement);
        //Fix for PST-5899- START
        Set exchangeSet = orderedQtyGTZeroMapForExchange.entrySet();
        Set returnSet = orderedQtyGTZeroMapForReturn.entrySet();
        Iterator exchangeItr = exchangeSet.iterator();
        Iterator returnIterator = returnSet.iterator();
        while(exchangeItr.hasNext()&& returnIterator.hasNext()) {
        	 Entry exchangeEntry = (Entry)exchangeItr.next();
        	 Entry returnEntry = (Entry)returnIterator.next();
        	 logger.debug("key is: "+ exchangeEntry.getKey()+" & Value is: "+exchangeEntry.getValue());
        	 logger.debug("key is: "+ returnEntry.getKey()+" & Value is: "+returnEntry.getValue());
        	
                 logger.debug("KohlsUpdateCustomAttributesForEE.formInputXMLForChangeOrder  exchange primeLineNo ::"
                        + exchangeEntry.getKey());
                 logger.debug("KohlsUpdateCustomAttributesForEE.formInputXMLForChangeOrder  exchange orderLineKey ::"
                        + exchangeEntry.getValue());
                 //Fix for PST-5899- END
                Element exchangeOrderLineElement = inputChangeOrderDoc.createElement(KohlsPOCConstant.ELEM_ORDER_LINE);
                exchangeOrderLinesElement.appendChild(exchangeOrderLineElement);
                 logger.debug("exchangeOrderLineElement:: "+XMLUtil.getElementXMLString(exchangeOrderLineElement));
                exchangeOrderLineElement.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY,
                		(String) exchangeEntry.getValue());
                Element customAttributesElement = inputChangeOrderDoc
                        .createElement(KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
                exchangeOrderLineElement.appendChild(customAttributesElement);
               
                
                if (!YFCCommon.isVoid((String) returnEntry.getValue())) {
                	 logger.debug("KohlsUpdateCustomAttributesForEE.formInputXMLForChangeOrder  exchange returnOrderLineKey ::"
                            + returnEntry.getValue());
                    customAttributesElement.setAttribute(KohlsPOCConstant.A_TEXT2, (String) returnEntry.getValue());
                }
        	}
    	 logger.debug("inputChangeOrderDoc: "+XMLUtil.getXMLString(inputChangeOrderDoc));
        return inputChangeOrderDoc;
    }
}
