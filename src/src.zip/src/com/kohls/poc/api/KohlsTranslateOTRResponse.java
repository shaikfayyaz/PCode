package com.kohls.poc.api;

import com.ibm.icu.text.DecimalFormat;
import com.ibm.sterling.Utils;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsPoCInvokeDataSecurityPlatform;
import com.protegrity.common.XCException;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.ParserConfigurationException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

public class KohlsTranslateOTRResponse {

    private static final YFCLogCategory log =
            YFCLogCategory.instance(KohlsTranslateOTRResponse.class.getName());
    private static final String EXTN_IS_RESTRICTED_RETURN = "ExtnIsRestrictedReturn";
    public static final String ENABLE_RETURN_RESTRICTION = "ENABLE_RETURN_RESTRICTION";
    private static final String MAX_SEQUENCE_LINE = "MaxSequenceLine";
    DecimalFormat df = new DecimalFormat("#0.00");

    /*
     * public static void main(String[] args) throws Exception {
     *
     * Document docOutput = null;
     *
     * DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
     * javax.xml.parsers.DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder(); Document
     * reqDoc = docBuilder.parse(new File("E:\\Order.xml"));
     * System.out.println(XMLUtil.getXMLString(reqDoc)); docOutput = translateRSResponse(reqDoc);
     * System.out.println(XMLUtil.getXMLString(docOutput)); }
     */
//PST-4465 - Adding PocFeature parameter
    public Document translateRSResponse(YFSEnvironment env, Document docInXML, String sPOCFeature) throws Exception {

        log.beginTimer("KohlsTranslateOTRResponse.translateRSResponse");
        // List<String> RS_BAD_DATA_CODE = Arrays.asList("000001F0", "000102",
        // "000000F9" ,"000101");
        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("######### translateRSResponse input XML #########"
                    + KohlsUtil.extractStringFromNode(docInXML));
        }

        HashMap<String, String> mapTenderEntryMethod = new HashMap<String, String>() {
            {
                put("00", "KEYED");
                put("01", "SWIPED");
                put("04", "SWIPED");
                put("02", "SCANNED");
                put("06", "TAPPED");
            }
        };

        Element eleOpenToReturn = (Element) docInXML.getElementsByTagName("OpenToReturn").item(0);
        Element eleHeader = (Element) docInXML.getElementsByTagName("Header").item(0);
        Document docOutXML = XMLUtil.createDocument("Order");
        Element eleOrder = docOutXML.getDocumentElement();
        Element eleExtn = docOutXML.createElement("Extn");
        eleOrder.appendChild(eleExtn);
        eleOrder.setAttribute("EnterpriseCode", "KOHLS-RETAIL");
        String sTerminalId = "";
        String sTranNo = "";
        String sStoreId = "";
        int maxSequenceLine = 0;
        Element eleOTRResponseCde =
                (Element) eleOpenToReturn.getElementsByTagName("ResponseCde").item(0);
        String sresponseCode = eleOTRResponseCde.getAttribute("responseReasonCde");
        String sOrderDate = "";
        String sTransDetails = "";
        String sGiftReceiptInd = "false";

        if (!YFCCommon.isVoid(env.getTxnObject(KohlsPOCConstant.TRAN_DETAILS))) {
            sTransDetails = (String) env.getTxnObject(KohlsPOCConstant.TRAN_DETAILS);
        }

        if (!YFCCommon.isVoid(sTransDetails)) {
            String[] sTransactionDetail = sTransDetails.split("-");
            if (sTransactionDetail.length > 3) {
                sGiftReceiptInd = sTransactionDetail[3];
            }
        }

        // MJ 07-06: Changes for CAPE-3786 - Begin
        // If no RKC Active events, dont create Kohls Cash line charge.
        boolean bRKCEventChecked = false;
        String docGetActiveRKCEvent = (String) env.getTxnObject("GetActiveRKCEvent");
        // this will be true for POC Returns and false for EE.
        if (!YFCCommon.isVoid(docGetActiveRKCEvent)) {
            bRKCEventChecked = true;
        }
        // MJ 07-06: Changes for CAPE-3786 - end

        //First read from OTR response. If not available then read from request.
        sOrderDate = getString("TransactionTmst", eleOpenToReturn);
        if (YFCCommon.isVoid(sOrderDate)) {
            sOrderDate = getString("TransactionTmst", eleHeader);
        }

        sStoreId = getString("LocationNbr", eleOpenToReturn);
        if (YFCCommon.isVoid(sStoreId)) {
            sStoreId = getString("LocationNbr", eleHeader);
        }

        if (!YFCCommon.isVoid(getString("DeviceId", eleOpenToReturn))) {
            sTerminalId = prepadString("DeviceId", eleOpenToReturn, 2, "0");
        } else if (!YFCCommon.isVoid(getString("DeviceId", eleHeader))) {
            sTerminalId = prepadString("DeviceId", eleHeader, 2, "0");
        }

        if (!YFCCommon.isVoid(getString("TransactionNbr", eleOpenToReturn))) {
            sTranNo = prepadString("TransactionNbr", eleOpenToReturn, 4, "0");
        } else if (!YFCCommon.isVoid(getString("TransactionNbr", eleHeader))) {
            sTranNo = prepadString("TransactionNbr", eleHeader, 4, "0");
        }

        //Take the TransactionAvailableAmt from RS response. If not available then
        //Fetch from OMS rules. If still not available then default to 150.00
        String strtrasactionalAmount = getString("TransactionAvailableAmt", eleOpenToReturn);
        if (YFCCommon.isVoid(strtrasactionalAmount)) {
            Document docOutRule = KohlsPoCPnPUtil.getRuleListForPOSCaller(env, eleOrder, "OTR_AMOUNT");
            if (!YFCCommon.isVoid(docOutRule)) {
                Element eleRule = (Element) docOutRule.getElementsByTagName("Rule").item(0);
                if (!YFCCommon.isVoid(eleRule)) {
                    strtrasactionalAmount = eleRule.getAttribute("RuleValue");
                } else {
                    strtrasactionalAmount = "150.00";
                }
            }
        }

        eleOrder.setAttribute("TerminalID", sTerminalId);
        eleOrder.setAttribute("PosSequenceNo", sTranNo);
        eleOrder.setAttribute("POSSequenceNumber", sTranNo);
        eleOrder.setAttribute("TransactionTmst", sOrderDate);
        eleOrder.setAttribute("OrderDate", sOrderDate);
        eleOrder.setAttribute("OperatorID", getString("OperatorId", eleHeader));
        eleOrder.setAttribute("TrainingModeInd", getString("TrainingModeInd", eleHeader));
        eleOrder.setAttribute("TransactionCde", getString("TransactionCde", eleHeader));
        eleOrder.setAttribute("StoreName", getString("LocationNm", eleOpenToReturn));

        //cpe-4498 for negative transaction amount, make it 0
        //String strtrasactionalAmount = getString("TransactionAvailableAmt", eleOpenToReturn);
        // CPE-10631
        String sMultiChannelOrderNbr = getString("MultiChannelOrderNbr", eleOpenToReturn);
        Element eleOrderCustomAttributes = XMLUtil.createChild(eleOrder, "CustomAttributes");
        eleOrderCustomAttributes.setAttribute("Text13", sMultiChannelOrderNbr);
        //just to test- remove this condition.
        double dTransactionAmt = 0;
        if (!YFCCommon.isVoid(strtrasactionalAmount)) {
            dTransactionAmt = Double.parseDouble(strtrasactionalAmount);
            if (dTransactionAmt < 0) {
                dTransactionAmt = 0;
            }
        }
        eleOrder.setAttribute("TransactionAvailableAmt", dTransactionAmt + "");
        eleOrder.setAttribute("ReturnShipAmt", getString("ReturnShipAmt", eleOpenToReturn));
        eleOrder.setAttribute("DocumentType", "0001");
        eleOrder.setAttribute("EnterpriseCode", "KOHLS-RETAIL");
        String sOrigBizDay = getString("OriginalBusinessDte", eleOpenToReturn);
        if (!YFCCommon.isVoid(sOrigBizDay)) {
            eleOrder.setAttribute("OrderNo", getOrderNo(env, sOrderDate, sStoreId, sTerminalId, sTranNo));
            eleOrderCustomAttributes.setAttribute(KohlsPOCConstant.ATTR_DATE_9, sOrigBizDay);
            //eleOrderCustAttribs.setAttribute("Date4", lcsDateFormatForEJ.format(dEndDate));
        } else {
            eleOrder.setAttribute("OrderNo", "0");
        }

        eleOrder.setAttribute("SellerOrganizationCode", sStoreId);
        eleOrder.setAttribute("InvoiceComplete", "Y");
        eleOrder.setAttribute("TotalAdjustmentAmount", "");
        eleOrder.setAttribute("EntryType", "STORE");
        eleOrder.setAttribute("OrderComplete", "N");

        // String strResponseReasonCdeWithDesc =
        // transformResponseCodesWithDesc(eleOTRResponseCde);
        // String[] arrResponseReasonCdeWithDesc =
        // strResponseReasonCdeWithDesc.split("-");

        // eleExtn.setAttribute("ExtnOTRResponse",
        // arrResponseReasonCdeWithDesc[0]);
        String sResponseReasonCde = eleOTRResponseCde.getAttribute("responseReasonCde");
        eleExtn.setAttribute("ExtnOTRResponse", sResponseReasonCde);

        String sIsRestrictedReturn = getString("ReturnRestrictionPolicyViolated", eleOpenToReturn);

        if (!YFCCommon.isVoid(sIsRestrictedReturn)) {
            log.info("KohlsReturnRestrictStatus:: Restricted Return Indicator in RS response --> " + sIsRestrictedReturn);
            eleExtn.setAttribute(EXTN_IS_RESTRICTED_RETURN, sIsRestrictedReturn);
        }
        eleExtn.setAttribute("ExtnOTRResponseType", getString("ResponseCde", eleOpenToReturn));
        eleExtn.setAttribute("ExtnOrigPosSequenceNo", sTranNo);
        eleExtn.setAttribute("ExtnAuthorizedAwards", "Y");
        eleExtn.setAttribute("ExtnLidOfferExempt", "N");
        if (!YFCCommon.isVoid(getString("CustomerEmailAddress", eleOpenToReturn))) {
            eleExtn.setAttribute("ExtnEReceiptEmailID",
                    getString("CustomerEmailAddress", eleOpenToReturn));
        }

        // MJ 09/22 Changes for CAPE-4327 - start
        String sCustomerAssociateNo = getString("CustomerAssociateId", eleOpenToReturn);
        if (!YFCCommon.isVoid(sCustomerAssociateNo)) {
            eleExtn.setAttribute("ExtnCustomerAssociateNo", sCustomerAssociateNo);
        }
        // MJ 09/22 Changes for CAPE-4327 - End

        Element eleCleanReceiptInd = docOutXML.createElement("CleanReceiptInd");
        eleOrder.appendChild(eleCleanReceiptInd);
        String cleanReceiptInd = getString("CleanReceiptInd", eleOpenToReturn);
        if (YFCCommon.isVoid(cleanReceiptInd)) {
            cleanReceiptInd = "false";
        }
        eleCleanReceiptInd.setTextContent(cleanReceiptInd);

        //OMNI2 Add OmniBagIndicator
        Map<String, String> omni2ConfigMap = getConfigMap(env);
        String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);

        if (!YFCCommon.isVoid(getString("OmniBagInd", eleOpenToReturn))) {
            //OMNI2 - Start ==  Added to block Price Adjustment and PSA for OMNI orders.
            String omniBagInd = getString("OmniBagInd", eleOpenToReturn);
            if (KohlsPOCConstant.TRUE.equalsIgnoreCase(omniBagInd) && KohlsPOCConstant.YES.equals(omni2Enabled)) {
                if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature)) {
                    YFSException yfsEx = new YFSException();
                    yfsEx.setErrorCode(KohlsPOCConstant.OMNI_PA_ERR_CODE);
                    yfsEx.setErrorDescription(KohlsPOCConstant.OMNI_PA_ERR_CODE_DESC);
                    throw yfsEx;
                } else if (KohlsPOCConstant.ATTR_PSA.equalsIgnoreCase(sPOCFeature)) {
                    YFSException yfsEx = new YFSException();
                    yfsEx.setErrorCode(KohlsPOCConstant.OMNI_PSA_ERR_CODE);
                    yfsEx.setErrorDescription(KohlsPOCConstant.OMNI_PSA_ERR_CODE_DESC);
                    throw yfsEx;
                }
            }
            //OMNI2 - End ==  Added to block Price Adjustment and PSA for OMNI orders.
            Element eleOmniBagInd = docOutXML.createElement("OmniBagInd");
            eleOrder.appendChild(eleOmniBagInd);
            eleOmniBagInd.setTextContent(getString("OmniBagInd", eleOpenToReturn));
        }
        //OMNI2 Add OmniBagIndicator

        Element eleResponseReasonDesc = docOutXML.createElement("responseReasonDesc");
        eleOrder.appendChild(eleResponseReasonDesc);
        eleResponseReasonDesc.setTextContent(eleOTRResponseCde.getAttribute("responseReasonDesc"));

        Element elePersonInfoShipTo = docOutXML.createElement("PersonInfoShipTo");
        eleOrder.appendChild(elePersonInfoShipTo);
        elePersonInfoShipTo.setAttribute("AddressLine1", "EMPTY ADDRESS");

        Element elePersonInfoBillTo = docOutXML.createElement("PersonInfoBillTo");
        eleOrder.appendChild(elePersonInfoBillTo);
        elePersonInfoBillTo.setAttribute("AddressLine1", "EMPTY ADDRESS");

        Element elePriceInfo = docOutXML.createElement("PriceInfo");
        eleOrder.appendChild(elePriceInfo);

        elePriceInfo.setAttribute("ReportingConversionRate", "1");

        // for adding promotions
        Element elePromotions = docOutXML.createElement("Promotions");
        eleOrder.appendChild(elePromotions);
        HashMap<String, String> promotionMap = new HashMap<String, String>();

        Element eleOrderLines = docOutXML.createElement("OrderLines");
        eleOrder.appendChild(eleOrderLines);
        String sPrimeLineNo = "";

        Double dTLDPercentAmt = 0.0D;
        Double dTLDPercentPriceAmt = 0.0D;

        // Changes for PR-343 - Start
        Double dEffTaxRate = 0.00;
        Double dTaxAmount = 0.00;
        Double dTotalTaxAmount = 0.00;
        int iOrderLineCount = 0;
        String sGiftFlag = "";
        // Changes for PR-343 - End
        double dTotalFeeTaxAmount = KohlsPOCConstant.ZERO_DBL;
        NodeList nlOTRReturnLineItem = eleOpenToReturn.getElementsByTagName("ReturnLineItem");
        for (int i = 0; i < nlOTRReturnLineItem.getLength(); i++) {

            Element eleOrderLine = docOutXML.createElement("OrderLine");
            eleOrderLines.appendChild(eleOrderLine);
            // Fix for PR-360 - Start
            eleOrderLine.setAttribute("DeliveryMethod", "CARRY");
            log.debug("The delivery type is set as CARRY");
            // Fix for PR-360 - End
            // Fix for 4255 - Start
            /* Fix for CAPE-1038 START */
            Element eleLineCharges = docOutXML.createElement("LineCharges");
            eleOrderLine.appendChild(eleLineCharges);
            /* Fix for CAPE-1038 END */
            Element eleOTRReturnLineItem = (Element) nlOTRReturnLineItem.item(i);

            eleOrderLine.setAttribute("POSMerchandiseId",
                    getString("POSMerchandiseId", eleOTRReturnLineItem));
            eleOrderLine.setAttribute("ItemID", getString("SKUNbr", eleOTRReturnLineItem));
            eleOrderLine.setAttribute("GiftCardInd", getString("GiftCardInd", eleOTRReturnLineItem));

            sGiftFlag = getString("GiftReceiptInd", eleOTRReturnLineItem);
            if (sGiftFlag.equalsIgnoreCase("true")) {
                sGiftFlag = "Y";
            } else {
                sGiftFlag = "N";
            }
            eleOrderLine.setAttribute("GiftFlag", sGiftFlag);
            eleOrderLine.setAttribute("GiftReceiptInd", sGiftFlag);

            eleOrderLine.setAttribute("GiftRegistryId",
                    getString("GiftRegistryId", eleOTRReturnLineItem));
            sPrimeLineNo = getString("LineSequenceNbr", eleOTRReturnLineItem);
            eleOrderLine.setAttribute("PrimeLineNo", sPrimeLineNo);
            if (maxSequenceLine < Integer.parseInt(sPrimeLineNo)) {
                maxSequenceLine = Integer.parseInt(sPrimeLineNo);
            }
            String sReturnedInd = getString("ReturnedInd", eleOTRReturnLineItem);
            if (sReturnedInd.equalsIgnoreCase("true")) {
                sReturnedInd = "Y";
            } else {
                sReturnedInd = "N";
            }
            eleOrderLine.setAttribute("IsReturnedItem", sReturnedInd);
            eleOrderLine.setAttribute("PipelineId", "POS_Simple_Sales_Pipeline");
            eleOrderLine.setAttribute("PipelineOwnerKey", "DEFAULT");
            eleOrderLine.setAttribute("ShipNode", sStoreId);
            eleOrderLine.setAttribute("OrderedQty", "1");
            eleOrderLine.setAttribute("StatusQuantity", "1");
            eleOrderLine.setAttribute("InvoiceComplete", "Y");
            /*
             * eleOrderLine.setAttribute("InvoicedExtendedPrice",
             * Double.toString(Double.parseDouble(getString("RegularRetailAmt", eleOTRReturnLineItem))));
             */
            eleOrderLine.setAttribute("InvoicedQuantity", "1");
            eleOrderLine.setAttribute("ShippedQuantity", "1");
            eleOrderLine.setAttribute("OtherCharges", "");

            Element eleItem = docOutXML.createElement("Item");
            eleOrderLine.appendChild(eleItem);

            eleItem.setAttribute("ItemID", getString("SKUNbr", eleOTRReturnLineItem));
            eleItem.setAttribute("UPCCode", getString("POSMerchandiseId", eleOTRReturnLineItem));
            eleItem.setAttribute("ItemDesc", getString("DetailDesc", eleOTRReturnLineItem));
            eleItem.setAttribute("ItemShortDesc", getString("DetailReceiptDesc", eleOTRReturnLineItem));
            eleItem.setAttribute("UnitOfMeasure", "EACH");
            eleItem.setAttribute("Createts", getString("TransactionTmst", eleOpenToReturn));

            Element eleLinePriceInfo = docOutXML.createElement("LinePriceInfo");
            eleOrderLine.appendChild(eleLinePriceInfo);

            Element eleAwards = docOutXML.createElement("Awards");
            eleOrderLine.appendChild(eleAwards);
            // Changes for #495 - Unit Price not populated as there is no
            // RegularRetailAmt
            String sRegularRetailAmt = getString("RegularRetailAmt", eleOTRReturnLineItem);
            /*
             * Double dUnitPrice = Double.parseDouble(sRegularRetailAmt); if (YFCCommon.isVoid(dUnitPrice)
             * || dUnitPrice == 0D) { dUnitPrice = Double.parseDouble(getString("ActualPriceAmt",
             * eleOTRReturnLineItem)); } eleLinePriceInfo.setAttribute("UnitPrice",
             * Double.toString(dUnitPrice));
             */

            // Changes for #4090 - List Price Not populated - Start - POC
            // Returns Dev Team
            eleLinePriceInfo.setAttribute("ListPrice", sRegularRetailAmt);
            eleLinePriceInfo.setAttribute("RetailPrice",
                    getString("CustomerChargedAmt", eleOTRReturnLineItem));

            List<Element> listFee = XMLUtil.getElementsByTagName(eleOTRReturnLineItem, "Fee");
            //passing OrigFee argument as null/empty so that it gets initialized to FEE amount
            if (listFee.size() > KohlsPOCConstant.ZERO_INT) {
                transformRSLineFeeElement(i, eleOTRReturnLineItem, listFee);
            }
            List<Element> nlFee = XMLUtil.getElementsByTagName(eleOTRReturnLineItem, KohlsPOCConstant.SMALL_ATTR_FEES);
            String strLineFeeAmountRate = modifyFeeDeatils(nlFee, eleOrderLine, "-", null);
            double dLineFeeAmount = getRateBasedLineTaxFeeAmount(strLineFeeAmountRate);
            if (YFCCommon.isVoid(dLineFeeAmount)) {
                dLineFeeAmount = KohlsPOCConstant.ZERO_DBL;
            }
            dTotalFeeTaxAmount = dTotalFeeTaxAmount + dLineFeeAmount;

            // Changes for #4090 - List Price Not populated - End - POC Returns
            // Dev Team
            Double dLineTotal = 0.0D;
            String taxAmt = getString("ReturnTaxAmt", eleOTRReturnLineItem);
            Double dTaxAmt = Double.parseDouble(taxAmt);

            dLineTotal = Double.parseDouble(getString("ReturnPriceAmt", eleOTRReturnLineItem)) + dTaxAmt + dLineFeeAmount;
            eleLinePriceInfo.setAttribute("LineTotal", Double.toString(dLineTotal));
            eleLinePriceInfo.setAttribute("InvoicedLineTotal", Double.toString(dLineTotal));
            eleLinePriceInfo.setAttribute("OrderedPricingQty", "1");
            eleLinePriceInfo.setAttribute("InvoicedPricingQty", "1");
            eleLinePriceInfo.setAttribute("ActualPricingQty", "1");
            Element eleLineTaxes = XMLUtil.getChildElement(eleOrderLine, "LineTaxes", true);

            // Adding LineTax element only when Tax > 0
            Element eleLineTaxExtn = null;
            if (!YFCCommon.isVoid(taxAmt)) {
                if (dTaxAmt > 0) {
                    Element eleLineTax = docOutXML.createElement("LineTax");
                    eleLineTaxExtn = XMLUtil.createChild(eleLineTax, "Extn");
                    eleLineTaxes.appendChild(eleLineTax);
                    eleLineTax.setAttribute("ChargeCategory", "Price");
                    eleLineTax.setAttribute("ChargeName", "Price");
                    eleLineTax.setAttribute("InvoicedTax", taxAmt);
                    eleLineTax.setAttribute("TaxName", "State Tax");
                    //PST-4465 - Start
                    if ("PSA".equalsIgnoreCase(sPOCFeature)) {
                        Double dTaxRatePct = Double.valueOf(getString("TaxRatePct", eleOTRReturnLineItem));
                        dTaxRatePct = dTaxRatePct * 100;
                        eleLineTax.setAttribute("TaxPercentage", df.format(Math.abs(dTaxRatePct)));
                    } else {
                        eleLineTax.setAttribute("TaxPercentage", getString("TaxRatePct", eleOTRReturnLineItem));
                    }
                    //PST-4465 - Start
                    eleLineTax.setAttribute("Tax", taxAmt);
                    eleLinePriceInfo.setAttribute("TaxableFlag", "Y");
                } else {
                    if (Double.valueOf(getString("TaxRatePct", eleOTRReturnLineItem)) > 0) {
                        eleLinePriceInfo.setAttribute("TaxableFlag", "Y");
                    } else {
                        eleLinePriceInfo.setAttribute("TaxableFlag", "N");
                    }
                }
            }


            // Changes for PR-343 - Start
            String sTaxPercent = getString("TaxRatePct", eleOTRReturnLineItem);
            String sTaxableAmount = getString("TaxableAmt", eleOTRReturnLineItem);

            if (!YFCCommon.isStringVoid(sTaxPercent)) {
                Double dTaxPercent = getConvertToDoubleVal(sTaxPercent);
                if (Double.compare(dTaxPercent, KohlsPOCConstant.ZERO_DBL) > 0) {
                    iOrderLineCount++;
                    dEffTaxRate += dTaxPercent;
                    if (!YFCCommon.isStringVoid(sTaxableAmount)) {
                        Double dTaxableAmount = getConvertToDoubleVal(sTaxableAmount);
                        dTotalTaxAmount += dTaxableAmount;
                    }
                }
            }
            // String sTaxAmt = getString("ReturnTaxAmt", eleOTRReturnLineItem);
            if (!YFCCommon.isStringVoid(taxAmt)) {
                dTaxAmt = getConvertToDoubleVal(taxAmt);
                dTaxAmount += dTaxAmt;
            }
            // Changes for PR-343 - End
            //Setting BasisAmount
            if (!YFCCommon.isVoid(eleLineTaxExtn) && !nlFee.isEmpty()) {
                eleLineTaxExtn.setAttribute("ExtnBasisAmount", getString("FeeBasisAmount", nlFee.get(0)));
            }
            Element eleOrderStatuses = docOutXML.createElement("OrderStatuses");
            eleOrderLine.appendChild(eleOrderStatuses);
            Element eleOrderStatus = docOutXML.createElement("OrderStatus");
            eleOrderStatuses.appendChild(eleOrderStatus);

            eleOrderStatus.setAttribute("ReleaseNo", "");
            eleOrderStatus.setAttribute("StatusReason", "");
            eleOrderStatus.setAttribute("StatusQty", "1.0");
            eleOrderStatus.setAttribute("StatusDate", "");
            if (sReturnedInd.equalsIgnoreCase("N")) {
                eleOrderStatus.setAttribute("Status", "1100.0005");
            } else {
                eleOrderStatus.setAttribute("Status", "3700.01");
            }

            Element eleSchedule = docOutXML.createElement("Schedule");
            eleOrderStatus.appendChild(eleSchedule);

            eleSchedule.setAttribute("ShipNode", sStoreId);

            Element eleOrderLineExtn = docOutXML.createElement("Extn");
            eleOrderLine.appendChild(eleOrderLineExtn);

            String sStatusCode = getString("ItemStatusCode", eleOTRReturnLineItem);
            if (YFCCommon.isVoid(sStatusCode)) {
                sStatusCode = "0";
            }

            //CPE-9632 - set Text11 of custom attributes with item status code
            Element eleCustomAttributes = XMLUtil.getChildElement(eleOrderLine, "CustomAttributes", true);
            eleCustomAttributes.setAttribute("Text11", sStatusCode);
            eleCustomAttributes.setAttribute("Text7", sStoreId);
            eleCustomAttributes.setAttribute("Text8", sTerminalId);
            eleCustomAttributes.setAttribute("Text9", sTranNo);
            eleCustomAttributes.setAttribute("Text10", sPrimeLineNo);

            //CPE-9632 - end
            eleOrderLineExtn.setAttribute("ExtnSkuStatusCode", sStatusCode);
            // Added for PA - begin
            eleOrderLineExtn.setAttribute("ExtnSimplePromoPrice",
                    getString("ActualPriceAmt", eleOTRReturnLineItem));
            // Added for PA - End
            eleOrderLineExtn.setAttribute("ExtnNetPrice",
                    getString("ReturnPriceAmt", eleOTRReturnLineItem));
            eleOrderLineExtn.setAttribute("ExtnReturnPrice",
                    getString("ReturnPriceAmt", eleOTRReturnLineItem));
            eleOrderLineExtn.setAttribute("ExtnTaxableAmount",
                    getString("TaxableAmt", eleOTRReturnLineItem));
            eleOrderLineExtn.setAttribute("ExtnIsDiscountable", "Y");

            //CPE-11077 Adding ExtnPLURetailAmt from RS to OMS
            eleOrderLineExtn.setAttribute("ExtnPLURetailAmt", sRegularRetailAmt);

            eleOrderLineExtn.setAttribute("ExtnMultiChannelOrderNbr", sMultiChannelOrderNbr);
            // MJ 09/22 Changes for CAPE-4327 - start
            String sTaxProductCode = getString("TaxProductCodeDescription", eleOTRReturnLineItem);
            if (!YFCCommon.isVoid(sTaxProductCode)) {
                eleOrderLineExtn.setAttribute("ExtnTaxProductCode", sTaxProductCode);
            }

            eleOrderLine.appendChild(eleCustomAttributes);
            String sPromotionalSchemeCode = getString("PromotionalSchemeCode", eleOTRReturnLineItem);
            if (!YFCCommon.isVoid(sPromotionalSchemeCode)) {
                eleCustomAttributes.setAttribute("Text16", sPromotionalSchemeCode);
            }
            String sPromotionalInterfaceIdentifier =
                    getString("PromotionalInterfaceIdentifier", eleOTRReturnLineItem);
            if (!YFCCommon.isVoid(sPromotionalInterfaceIdentifier)) {
                eleCustomAttributes.setAttribute("Text17", sPromotionalInterfaceIdentifier);
            }
            eleCustomAttributes.setAttribute("Text13", sMultiChannelOrderNbr);
            // MJ 09/22 Changes for CAPE-4327 - End


            Element eleLIDPromotions = docOutXML.createElement("Promotions");
            eleOrderLine.appendChild(eleLIDPromotions);

            HashMap<String, Element> awardMap = new HashMap<String, Element>();

            Double dPriceAmt = 0.0D;
            Double dUnitPrice_temp =
                    Double.parseDouble(getString("ReturnPriceAmt", eleOTRReturnLineItem));
            boolean bPercentOffExists = false;
            boolean bIsPriceAlreadyAdded = false;
            // Fix for PR-424 - Start
            Double dUnitPriceForPPItem = 0.00;
            // Fix for PR-424 - End
            Double dblAwardAmt = 0.0;
            NodeList nlOTRItemDetail = eleOTRReturnLineItem.getElementsByTagName("ItemDetail");
            for (int j = 0; j < nlOTRItemDetail.getLength(); j++) {
                Document docSalesHubData = null;
                Element eleData = null;
                Element eleOTRItemDetail = (Element) nlOTRItemDetail.item(j);
                String sDetailAmt = getString("DetailAmt", eleOTRItemDetail);
                String sDetailDesc = getString("DetailDesc", eleOTRItemDetail);
                String sItemDetailLineSeqNbr = getString(KohlsPOCConstant.LineSequenceNbr, eleOTRItemDetail);
                int intItemDetailLineSeqNbr = Integer.valueOf(sItemDetailLineSeqNbr) - 1;
                if (!YFCCommon.isVoid(sDetailAmt)) {
                    Element eleAward = docOutXML.createElement("Award");
                    eleAwards.appendChild(eleAward);
                    //CPE-4947 - Start
                    String sDisplayOnlyInd = getString("DisplayOnlyInd", eleOTRItemDetail);
                    eleAward.setAttribute("Temp_DisplayOnlyInd", sDisplayOnlyInd);
                    //CPE-4947 - End
                    String sAwardAmt = Double.toString(Double.parseDouble(sDetailAmt));
                    dblAwardAmt = Double.valueOf(sAwardAmt);
                    eleAward.setAttribute("Description", sDetailDesc);
                    // Changes for POC Returns. - begin
                    /*
                     * if (sDetailAmt.startsWith("-")) { eleAward.setAttribute("AwardAmount", sAwardAmt); }
                     * else { eleAward.setAttribute("AwardAmount", "-" + sAwardAmt); }
                     */
                    if (!sDetailAmt.startsWith("-")) {
                        eleAward.setAttribute("AwardAmount", "-" + sAwardAmt);
                    } else {
                        eleAward.setAttribute("AwardAmount",
                                df.format(Math.abs(Double.parseDouble(sAwardAmt))));
                    }
                    // Changes for POC Returns. - end
                    eleAward.setAttribute("AwardApplied", "Y");
                    eleAward.setAttribute("IsPromotionOnOrder", "N");
                    eleAward.setAttribute("IsPromotionOnOrderLine", "N");
                    eleAward.setAttribute("PromotionId", "");
                    eleAward.setAttribute("AwardId", UUID.randomUUID().toString());
                    Element eleAwardExtn = docOutXML.createElement("Extn");
                    // MJ 09/06 Changes for CAPE-4114 start
                    String sDiscountCde = getString("DiscountCde", eleOTRItemDetail);
                    String sExtnDiscountTypeCode = "";
                    String sExtnDiscountReasonCode = "";
                    if (!YFCCommon.isVoid(sDiscountCde)) {
                        sExtnDiscountTypeCode = sDiscountCde.substring(sDiscountCde.length() - 1);
                        sExtnDiscountReasonCode = sDiscountCde.substring(0, sDiscountCde.length() - 1);
                        eleAward.setAttribute("ExtnDiscountTypeCode", sExtnDiscountTypeCode);
                        eleAwardExtn.setAttribute("ExtnDiscountTypeCode", sExtnDiscountTypeCode);
                        eleAward.setAttribute("ExtnDiscountReasonCode", sExtnDiscountReasonCode);
                        eleAwardExtn.setAttribute("ExtnDiscountReasonCode", sExtnDiscountReasonCode);
                    }
                    // MJ 09/06 Changes for CAPE-4114 end


                    eleAward.appendChild(eleAwardExtn);
                    // Fix for PR-449 - Start
                    eleAwardExtn.setAttribute("ExtnNetDelta", sAwardAmt);
                    eleAwardExtn.setAttribute("ExtnRetrnDelta",
                            String.valueOf(Math.abs(Double.valueOf(sAwardAmt))));
                    // Fix for PR-449 - End
                    eleAwardExtn.setAttribute("ExtnAwardRcptDesc",
                            getString("DetailReceiptDesc", eleOTRItemDetail));
                    eleAwardExtn.setAttribute("ExtnAwardSequence",
                            getString("LineSequenceNbr", eleOTRItemDetail));

                    //CPE-4947 start
                    if ("true".equalsIgnoreCase(sDisplayOnlyInd)) {
                        // should not populate the award map.
                        continue;
                    }
                    //CPE-4947 end
                    String itemDetailsSeqNo = getString("LineSequenceNbr", eleOTRItemDetail);
                    awardMap.put(sAwardAmt + "_" + sDiscountCde + "_" + itemDetailsSeqNo, eleAward);

                    // Added logic for LID promotions.
                    if (sDetailDesc.equalsIgnoreCase("Price")) {
                        dPriceAmt = Double.parseDouble(sDetailAmt);
                        // Fix for PR-424 - Start
                        dUnitPriceForPPItem = dPriceAmt;
                        // Fix for PR-424 - End
                    } else if (sDetailDesc.contains("Markdown")) {
                        Element eleLIDPromotion = docOutXML.createElement("Promotion");
                        eleLIDPromotions.appendChild(eleLIDPromotion);
                        eleLIDPromotion.setAttribute("OverrideAdjustmentValue",
                                "-" + Math.abs(Double.parseDouble(sAwardAmt)));
                        eleLIDPromotion.setAttribute("IsExternal", "Y");
                        eleLIDPromotion.setAttribute("PromotionGroup", "MANUAL");
                        eleLIDPromotion.setAttribute("PromotionApplied", "Y");
                        Element elePromoExtn = docOutXML.createElement("Extn");
                        eleLIDPromotion.appendChild(elePromoExtn);
                        String sPromotionID;
                        if (sDetailDesc.contains("$")) {
                            docSalesHubData = XMLUtil.createDocument("Data");
                            eleData = docSalesHubData.getDocumentElement();
                            // Fix for 4255 - Start
                            if (dblAwardAmt > 0) {
                                sPromotionID = KohlsPOCConstant.AMOUNT_OFF_MANUAL_0000 + (j + 1);
                                eleLIDPromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.AMOUNT_OFF);
                                if (!YFCCommon.isVoid(eleData)) {
                                    eleData.setAttribute(KohlsPOCConstant.A_BUY_ITEM, KohlsPOCConstant.NO);
                                    eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_AMOUNT_OFF);
                                    eleData.setAttribute(KohlsPOCConstant.A_PRECEDENCE, KohlsPOCConstant.NINE);
                                    eleAwardExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(docSalesHubData));
                                }
                            } else {
                                sPromotionID = KohlsPOCConstant.PRICE_OVERRIDE_MANUAL;
                                eleLIDPromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.PRICE_OVERRIDE);
                                if (!YFCCommon.isVoid(eleData)) {
                                    eleData.setAttribute(KohlsPOCConstant.A_BUY_ITEM, KohlsPOCConstant.NO);
                                    eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.PRICE_OVER_RIDE);
                                    eleData.setAttribute(KohlsPOCConstant.A_PRECEDENCE, KohlsPOCConstant.EIGHT);
                                    eleAwardExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(docSalesHubData));
                                }
                            }
                            eleLIDPromotion.setAttribute("PromotionId", sPromotionID);
                            elePromoExtn.setAttribute("ExtnDiscountAmount",
                                    "-" + Math.abs(Double.parseDouble(sAwardAmt)));
                        } else {
                            sPromotionID = "PERCENT_OFF_MANUAL_0000" + (j + 1);
                            eleLIDPromotion.setAttribute("PromotionType", "PERCENT_OFF");
                            eleLIDPromotion.setAttribute("PromotionId", sPromotionID);
                            Double dDiscountPercent = Double.parseDouble(sDetailAmt) / dPriceAmt;
                            elePromoExtn.setAttribute("ExtnDiscountPercent",
                                    df.format(Math.abs(dDiscountPercent * 100)));
                            // MJ 09/17 Changes for CAPE-4086 - start
                            eleAward.setAttribute("ExtnDiscountPercent", df.format(Math.abs(dDiscountPercent)));
                            // MJ 09/17 Changes for CAPE-4086 - end
                        }
                        eleAward.setAttribute("PromotionId", sPromotionID);
                        if (!YFCCommon.isVoid(sDiscountCde.substring(0, sDiscountCde.length() - 1))) {
                            elePromoExtn.setAttribute("ExtnReasonCode",
                                    sDiscountCde.substring(0, sDiscountCde.length() - 1));
                        } else {
                            elePromoExtn.setAttribute("ExtnReasonCode", "709");
                        }
                    }
                    // Added logic for Accurate TLD % off calculation.
                    else if (sDetailDesc.equalsIgnoreCase("% Transaction Discount")) {
                        if (!bIsPriceAlreadyAdded) {
                            dTLDPercentPriceAmt = dTLDPercentPriceAmt + dPriceAmt;
                            bIsPriceAlreadyAdded = true;
                        }
                        dTLDPercentAmt = dTLDPercentAmt + Double.parseDouble(sDetailAmt);
                        bPercentOffExists = true;
                    } else if (sDetailDesc.equalsIgnoreCase("$ Transaction Discount") && bPercentOffExists) {
                        dTLDPercentPriceAmt = dTLDPercentPriceAmt + Double.parseDouble(sDetailAmt);
                    }
                }
            }

            Element eleDiscounts = docOutXML.createElement("Discounts");
            eleOrderLine.appendChild(eleDiscounts);

            Double dOtherCharges = 0.0D;

            NodeList nlOTRDiscount = eleOTRReturnLineItem.getElementsByTagName("Discount");

            for (int j = 0; j < nlOTRDiscount.getLength(); j++) {
                Element eleOTRDiscount = (Element) nlOTRDiscount.item(j);
                String sDiscountCde = getString("DiscountCde", eleOTRDiscount);

                String sDiscountCdeType = sDiscountCde.substring(sDiscountCde.length() - 1);
                String sDiscountSeqNbr = getString(KohlsPOCConstant.Seq_Number, eleOTRDiscount);
                /*
                 * if ("734R".equalsIgnoreCase(sDiscountCde) && !bRKCEventChecked) { continue; }
                 */

                //CPE-4947 start
                String sDiscountAmt =
                        Double.toString(Math.abs(Double.parseDouble(getString("DiscountAmt", eleOTRDiscount))));
                Double dDiscountAmt =
                        Math.abs(Double.parseDouble(getString("DiscountAmt", eleOTRDiscount)));


                Element eleAward = null;
                Element eleAwardExtn = null;
                Document docSalesHubData = null;
                Element eleData = null;
                String mapKey = "";
                for (Entry<String, Element> e : awardMap.entrySet()) {
                    if (e.getKey().startsWith(sDiscountAmt + "_" + sDiscountCde)) {
                        mapKey = e.getKey();
                        break;
                    }
                }
                if (!YFCCommon.isVoid(mapKey)) {
                    eleAward = awardMap.get(mapKey);
                    eleAward.setAttribute("PromotionId", sDiscountCde + "_00001");
                    eleAward.setAttribute("AwardId",
                            sDiscountCde + "_" + sTranNo + "_" + sPrimeLineNo + "_" + j);
                    eleAwardExtn = (Element) eleAward.getElementsByTagName("Extn").item(0);
                    docSalesHubData = XMLUtil.createDocument("Data");
                    eleData = docSalesHubData.getDocumentElement();

                    awardMap.remove(mapKey);

                    String sTemp_DisplayOnlyInd = eleAward.getAttribute("Temp_DisplayOnlyInd");
                    if (sTemp_DisplayOnlyInd.equalsIgnoreCase("true")) {
                        continue;
                    }
                }

                //CPE-4947 end
                Element eleLineCharge = null;
                Element eleLineChargesExtn = null;
                if (!("true".equalsIgnoreCase(sGiftReceiptInd) && sDiscountCde.equalsIgnoreCase("734R"))) {

                    eleLineCharge = docOutXML.createElement("LineCharge");
                    eleLineCharges.appendChild(eleLineCharge);

                    dUnitPrice_temp = dUnitPrice_temp + Math.abs(dDiscountAmt);
                    eleLineChargesExtn = XMLUtil.createChild(eleLineCharge, "Extn");


                    eleLineCharge.setAttribute("ChargeAmount", sDiscountAmt);
                    eleLineCharge.setAttribute("InvoicedChargeAmount", sDiscountAmt);
                    eleLineCharge.setAttribute("IsBillable", "Y");
                    eleLineCharge.setAttribute("IsDiscount", "Y");
                    eleLineCharge.setAttribute("IsManual", "Y");
                    // Fix for 4095, 4132 - Start
                    eleLineCharge.setAttribute("ChargePerLine", sDiscountAmt);
                    eleLineCharge.setAttribute("InvoicedChargePerLine", sDiscountAmt);
                    // Fix for 4095, 4132 - End

                    // MJ 09/06 Changes for CAPE-4114 start
                    if (!YFCCommon.isVoid(sDiscountCde)) {
                        eleLineChargesExtn.setAttribute("ExtnDiscountTypeCode",
                                sDiscountCde.substring(sDiscountCde.length() - 1));
                        eleLineChargesExtn.setAttribute("ExtnDiscountReasonCode",
                                sDiscountCde.substring(0, sDiscountCde.length() - 1));
                    }
                    // MJ 09/06 Changes for CAPE-4114 end
                    // MJ 09/15 Changes for CAPE-4081 - start
                    String sDiscountPercent = getString("DiscountPct", eleOTRDiscount);
                    if (!YFCCommon.isVoid(sDiscountPercent)) {
                        eleLineChargesExtn.setAttribute("ExtnDiscountPercent", sDiscountPercent);
                    }
                    // MJ 09/15 Changes for CAPE-4081 - End

                }
                String sChargeName = "";
                String sChargeCategory = "";
                if (sDiscountCde.equalsIgnoreCase("734Q")) {
                    sChargeCategory = "ManualTLD";
                    sChargeName = "TLDPercentOff";
                    // Per Dan P, if its 734 in RS, then data collect should have 733.
                    // So, setting DiscountTypeCode as 733
                    eleLineChargesExtn.setAttribute("ExtnDiscountReasonCode", "733");
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "PERCENT_OFF");
                        eleData.setAttribute("Precedence", "41");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);

                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }
                } else if (sDiscountCde.equalsIgnoreCase("734K")) {
                    sChargeCategory = "ManualTLD";
                    sChargeName = "TLDAmountOff";
                    // Per Dan P, if its 734 in RS, then data collect should have 733.
                    // So, setting DiscountTypeCode as 733
                    eleLineChargesExtn.setAttribute("ExtnDiscountReasonCode", "733");
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "AMOUNT_OFF");
                        eleData.setAttribute("Precedence", "37");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }
                } else if (sDiscountCde.equalsIgnoreCase("728S")) {
                    sChargeCategory = "SeniorDiscount";
                    sChargeName = "SeniorCitizen";
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "SENIOR_DISCOUNT");
                        eleData.setAttribute("Precedence", "72");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);

                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }
                } else if (sDiscountCde.equalsIgnoreCase("760Q") || sDiscountCde.equalsIgnoreCase("760R")) {
                    //PST-4465 - Start
                    if ("PSA".equalsIgnoreCase(sPOCFeature)) {
                        sChargeCategory = "OfferDiscount";
                        sChargeName = "OfferDiscount";
                    } else {
                        sChargeCategory = "ManualTLD";
                        sChargeName = "TLDPercentOff";
                    }
                    //PST-4465 - End
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "PERCENT_OFF");
                        eleData.setAttribute("Precedence", "39");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);
                        //PST-4465 - Start
                        if ("PSA".equalsIgnoreCase(sPOCFeature)) {
                            eleAwardExtn.setAttribute("ExtnDiscountTypeCode", sDiscountCdeType);
                            eleAwardExtn.setAttribute("ExtnDiscountReasonCode", "760");
                        }
                        //PST-4465 - End
                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }
                } else if (sDiscountCde.equalsIgnoreCase("790P")) {
                    sChargeCategory = "AssociateDiscount";
                    sChargeName = "AssociateDiscount";
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "ASSOCIATE_DISCOUNT");
                        eleData.setAttribute("Precedence", "73");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }
                } else if (sDiscountCde.equalsIgnoreCase("761I")) {
                    sChargeCategory = "OfferDiscount";
                    sChargeName = "LIDOfferDollarOff";
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "TIERED_PERCENT_OFF");
                        eleData.setAttribute("Precedence", "40");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);
                        //PST-4465 - Start
                        if ("PSA".equalsIgnoreCase(sPOCFeature)) {
                            eleAwardExtn.setAttribute("ExtnDiscountTypeCode", sDiscountCdeType);
                            eleAwardExtn.setAttribute("ExtnDiscountReasonCode", "760");
                        }
                        //PST-4465 - End
                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }
                } else if (sDiscountCde.equalsIgnoreCase("760K")) {
                    sChargeCategory = "OfferDiscount";
                    sChargeName = "OfferDiscount";
                    if (!YFCCommon.isVoid(eleData)) {
                        eleData.setAttribute("BWPBuyAmt", sDiscountAmt);
                        eleData.setAttribute("DiscountPercent", getString("DiscountPct", eleOTRDiscount));
                        eleData.setAttribute("DiscountType", "TIERED_PERCENT_OFF");
                        eleData.setAttribute("Precedence", "40");
                        eleAwardExtn.setAttribute("ExtnTaxDelta", sDiscountAmt);
                        eleAwardExtn.setAttribute("ExtnNetDelta", sDiscountAmt);
                        //PST-4465 - Start
                        if ("PSA".equalsIgnoreCase(sPOCFeature)) {
                            eleAwardExtn.setAttribute("ExtnDiscountTypeCode", sDiscountCdeType);
                            eleAwardExtn.setAttribute("ExtnDiscountReasonCode", "760");
                        }
                        //PST-4465 - End
                        eleAwardExtn.setAttribute("ExtnSalesHubData", XMLUtil.getXMLString(docSalesHubData));
                        // awardMap.remove(sDiscountAmt);
                    }

                } else if (sDiscountCde.equalsIgnoreCase("734R")) {
                    if ("false".equalsIgnoreCase(sGiftReceiptInd)) {
                        sChargeCategory = "KohlsCashDiscount";
                        sChargeName = "KohlsCash";
                        Element eleDiscount = docOutXML.createElement("Discount");
                        eleDiscounts.appendChild(eleDiscount);
                        eleDiscount.setAttribute("DiscountAmt", getString("DiscountAmt", eleOTRDiscount));
                        eleDiscount.setAttribute("DiscountCde", getString("DiscountCde", eleOTRDiscount));
                        eleDiscount.setAttribute("DiscountPct", getString("DiscountPct", eleOTRDiscount));
                        eleDiscount.setAttribute("SequenceNbr", getString("SequenceNbr", eleOTRDiscount));
                        eleExtn.setAttribute("ExtnLidOfferExempt", "Y");
                        // Per Dan P, if its 734 in RS, then data collect should have 733.
                        // So, setting DiscountTypeCode as 733
                        eleLineChargesExtn.setAttribute("ExtnDiscountReasonCode", "733");
                    }
                } else if (sDiscountCde.equalsIgnoreCase("765L")) {
                    sChargeCategory = "GRProratedKCAmt";
                    sChargeName = "GRProratedKCAmt";
                    Element eleDiscount = docOutXML.createElement("Discount");
                    eleDiscounts.appendChild(eleDiscount);
                    eleDiscount.setAttribute("DiscountAmt", getString("DiscountAmt", eleOTRDiscount));
                    eleDiscount.setAttribute("DiscountCde", getString("DiscountCde", eleOTRDiscount));
                    eleDiscount.setAttribute("DiscountPct", getString("DiscountPct", eleOTRDiscount));
                    eleDiscount.setAttribute("SequenceNbr", getString("SequenceNbr", eleOTRDiscount));
                    eleExtn.setAttribute("ExtnLidOfferExempt", "Y");
                } else if (sDiscountCde.equalsIgnoreCase("760D")) {
                    sChargeCategory = "OfferDiscount";
                    sChargeName = "LIDOfferDollarOff";
                    Element eleDiscount = docOutXML.createElement("Discount");
                    eleDiscounts.appendChild(eleDiscount);
                    eleDiscount.setAttribute("DiscountAmt", getString("DiscountAmt", eleOTRDiscount));
                    eleDiscount.setAttribute("DiscountCde", getString("DiscountCde", eleOTRDiscount));
                    eleDiscount.setAttribute("DiscountPct", getString("DiscountPct", eleOTRDiscount));
                    eleDiscount.setAttribute("SequenceNbr", getString("SequenceNbr", eleOTRDiscount));
                    eleExtn.setAttribute("ExtnLidOfferExempt", "Y");
                } else if (sDiscountCde.equalsIgnoreCase("760P")) {
                    sChargeCategory = "OfferDiscount";
                    sChargeName = "LIDOfferPercentOff";
                    Element eleDiscount = docOutXML.createElement("Discount");
                    eleDiscounts.appendChild(eleDiscount);
                    eleDiscount.setAttribute("DiscountAmt", getString("DiscountAmt", eleOTRDiscount));
                    eleDiscount.setAttribute("DiscountCde", getString("DiscountCde", eleOTRDiscount));
                    eleDiscount.setAttribute("DiscountPct", getString("DiscountPct", eleOTRDiscount));
                    eleDiscount.setAttribute("SequenceNbr", getString("SequenceNbr", eleOTRDiscount));
                    eleExtn.setAttribute("ExtnLidOfferExempt", "Y");
                }

                // Update the promotion map
                if (!YFCCommon.isVoid(promotionMap.get(sDiscountCde))) {
                    String[] sMapValue = promotionMap.get(sDiscountCde).split("_");
                    double dTempDiscAmt = Double.parseDouble(sMapValue[0]);
                    double dOTRDiscountAmt = Double.parseDouble(getString("DiscountAmt", eleOTRDiscount));
                    dTempDiscAmt = dTempDiscAmt + dOTRDiscountAmt;
                    double dTempDiscPercet = Double.parseDouble(sMapValue[1]);
                    double dDiscountPercent = Double.parseDouble(getString("DiscountPct", eleOTRDiscount));
                    if (dTempDiscPercet < dDiscountPercent) {
                        dTempDiscPercet = dDiscountPercent;
                    }
                    promotionMap.put(sDiscountCde,
                            df.format(dTempDiscAmt) + "_" + Double.toString(dTempDiscPercet));
                } else {
                    if (!("true".equalsIgnoreCase(sGiftReceiptInd) && sDiscountCde.equalsIgnoreCase("734R"))) {

                        promotionMap.put(sDiscountCde, getString("DiscountAmt", eleOTRDiscount) + "_"
                                + getString("DiscountPct", eleOTRDiscount));
                    }
                }
                if (!(YFCCommon.isVoid(sChargeCategory) && YFCCommon.isVoid(sChargeName))) {

                    eleLineCharge.setAttribute("ChargeCategory", sChargeCategory);
                    eleLineCharge.setAttribute("ChargeName", sChargeName);
                }

                dOtherCharges = dOtherCharges + dDiscountAmt;

            }

            Double dTotalChargeAmt = 0.0D;
            Double dAwardAmt = 0.0;
            boolean bPromoDiscountCreated = false;
            Element elePromoLineCharge = null;
            if (!awardMap.isEmpty()) {

                for (String key : awardMap.keySet()) {
                    Element eleAward = awardMap.get(key);

                    if (key.contains("_")) {
                        dAwardAmt = Double.parseDouble(key.substring(0, key.indexOf("_")));

                    } else {
                        dAwardAmt = Double.parseDouble(key);
                    }
                    // dAwardAmt = Double.parseDouble(key);


                    String sDescription = eleAward.getAttribute("Description");
                    if (!sDescription.equalsIgnoreCase("Price")
                            && !sDescription.toLowerCase().contains("cash")) {
                        Element eleLineCharge = docOutXML.createElement("LineCharge");
                        eleLineCharges.appendChild(eleLineCharge);
                        eleLineCharge.setAttribute("ChargeAmount", df.format(dAwardAmt));

                        eleLineCharge.setAttribute("InvoicedChargeAmount", df.format(dAwardAmt));
                        eleLineCharge.setAttribute("ChargePerLine", df.format(dAwardAmt));
                        eleLineCharge.setAttribute("InvoicedChargePerLine", df.format(dAwardAmt));
                        eleLineCharge.setAttribute("IsBillable", "Y");
                        eleLineCharge.setAttribute("IsDiscount", "Y");
                        eleLineCharge.setAttribute("IsManual", "Y");

                        // MJ 09/06 changes for CAPE-4114 begin
                        Element eleLineChargeExtn = XMLUtil.createChild(eleLineCharge, "Extn");
                        if (!YFCCommon.isVoid(eleAward.getAttribute("ExtnDiscountTypeCode"))
                                && !YFCCommon.isVoid(eleAward.getAttribute("ExtnDiscountReasonCode"))) {
                            eleLineChargeExtn.setAttribute("ExtnDiscountTypeCode",
                                    eleAward.getAttribute("ExtnDiscountTypeCode"));
                            eleLineChargeExtn.setAttribute("ExtnDiscountReasonCode",
                                    eleAward.getAttribute("ExtnDiscountReasonCode"));
                        }
                        // MJ 09/17 Changes for CAPE-4086 - start
                        if (!YFCCommon.isVoid(eleAward.getAttribute("ExtnDiscountPercent"))) {
                            eleLineChargeExtn.setAttribute("ExtnDiscountPercent",
                                    eleAward.getAttribute("ExtnDiscountPercent"));
                        }
                        // MJ 09/17 Changes for CAPE-4086 - end
                        // MJ 09/06 changes for CAPE-4114 end

                        dOtherCharges = dOtherCharges + dAwardAmt;
                        if (sDescription.toLowerCase().contains("offer")) {
                            if ("P".equals(eleAward.getAttribute("ExtnDiscountTypeCode"))
                                    && "760".equals(eleAward.getAttribute("ExtnDiscountReasonCode"))) {
                                eleLineCharge.setAttribute("ChargeCategory", "OfferDiscount");
                                eleLineCharge.setAttribute("ChargeName", "LIDOfferPercentOff");
                            } else if ("D".equals(eleAward.getAttribute("ExtnDiscountTypeCode"))
                                    && "760".equals(eleAward.getAttribute("ExtnDiscountReasonCode"))) {
                                eleLineCharge.setAttribute("ChargeCategory", "OfferDiscount");
                                eleLineCharge.setAttribute("ChargeName", "LIDOfferDollarOff");
                            } else {
                                eleLineCharge.setAttribute("ChargeCategory", "OfferDiscount");
                                eleLineCharge.setAttribute("ChargeName", "OfferDiscount");
                            }
                            // dOtherCharges = dOtherCharges + dAwardAmt;
                            dUnitPrice_temp = dUnitPrice_temp + Math.abs(dAwardAmt);
                        } else if (sDescription.contains("Markdown")) {
                            // dOtherCharges = dOtherCharges -
                            // Math.abs(dAwardAmt);
                            if (sDescription.contains("$")) {
                                if (dAwardAmt > 0) {
                                    eleLineCharge.setAttribute("ChargeCategory", "ManualLID");
                                    eleLineCharge.setAttribute("ChargeName", "LIDAmountOff");
                                    dUnitPrice_temp = dUnitPrice_temp + Math.abs(dAwardAmt);
                                } else {
                                    eleLineCharge.setAttribute("ChargeCategory", "PriceOverrideInc");
                                    eleLineCharge.setAttribute("ChargeName", "PriceOverrideIncreaseAmount");
                                    eleLineCharge.setAttribute("IsDiscount", "N");
                                    eleLineCharge.setAttribute("ChargeAmount", df.format(Math.abs(dAwardAmt)));
                                    eleLineCharge.setAttribute("InvoicedChargeAmount",
                                            df.format(Math.abs(dAwardAmt)));
                                    eleLineCharge.setAttribute("ChargePerLine", df.format(Math.abs(dAwardAmt)));
                                    eleLineCharge.setAttribute("InvoicedChargePerLine",
                                            df.format(Math.abs(dAwardAmt)));
                                    dUnitPrice_temp = dUnitPrice_temp - Math.abs(dAwardAmt);
                                }
                            } else {
                                eleLineCharge.setAttribute("ChargeCategory", "ManualLID");
                                eleLineCharge.setAttribute("ChargeName", "LIDPercentOff");
                                dUnitPrice_temp = dUnitPrice_temp + Math.abs(dAwardAmt);
                            }
                        } else if (sDescription.toLowerCase().contains("price adj")) {
                            eleLineCharge.setAttribute("ChargeCategory", "PriceAdjDiscount");
                            eleLineCharge.setAttribute("ChargeName", "PriceAdjDiscount");
                            // dOtherCharges = dOtherCharges + dAwardAmt;
                            dUnitPrice_temp = dUnitPrice_temp + Math.abs(dAwardAmt);
                        } else if (sDescription.toLowerCase().contains("savings")) {
                            eleLineCharge.setAttribute("ChargeCategory", "PromoDiscount");
                            eleLineCharge.setAttribute("ChargeName", "PromoDiscount");
                            // dOtherCharges = dOtherCharges + dAwardAmt;
                            dUnitPrice_temp = dUnitPrice_temp + Math.abs(dAwardAmt);
                        } else if (sDescription.toLowerCase().contains("bogo")) {
                            eleLineCharge.setAttribute("ChargeCategory", "PromoDiscount");
                            eleLineCharge.setAttribute("ChargeName", "BOGODiscount");
                            // dOtherCharges = dOtherCharges + dAwardAmt;
                            dUnitPrice_temp = dUnitPrice_temp + Math.abs(dAwardAmt);
                        } else {
                            eleLineCharges.removeChild(eleLineCharge);
                            dTotalChargeAmt = dAwardAmt + dTotalChargeAmt;
                        }
                    }
                }
                dOtherCharges = dOtherCharges + dTotalChargeAmt;
            }

            eleOrderLine.setAttribute("OtherCharges", df.format(dOtherCharges));
            groupLineCharges(eleOrderLine);

            eleOrderLine.setAttribute("InvoicedExtendedPrice", df.format(dUnitPrice_temp));
            eleLinePriceInfo.setAttribute("InvoicedExtendedPrice", df.format(dUnitPrice_temp));
            eleLinePriceInfo.setAttribute("Tax", taxAmt);
            eleLinePriceInfo.setAttribute("UnitPrice", df.format(dUnitPrice_temp));
            eleOrderLineExtn.setAttribute("ExtnSellingPrice", df.format(dUnitPrice_temp));

        }

        // if Promoption map is not empty then add promotion element at order
        if (promotionMap.size() > 0) {
            for (String key : promotionMap.keySet()) {
                Element elePromotion = docOutXML.createElement("Promotion");
                elePromotions.appendChild(elePromotion);

                String[] sMapValue = promotionMap.get(key).split("_");
                String sDiscountAmt = sMapValue[0];
                String sDiscountPct = sMapValue[1];

                // Setting common attributes
                elePromotion.setAttribute("OverrideAdjustmentValue", sDiscountAmt);
                elePromotion.setAttribute("IsExternal", "Y");
                elePromotion.setAttribute("PromotionGroup", "MANUAL");
                elePromotion.setAttribute("PromotionApplied", "Y");
                Element elePromExtn = docOutXML.createElement("Extn");
                elePromotion.appendChild(elePromExtn);
                elePromExtn.setAttribute("ExtnDiscountAmount", sDiscountAmt);
                elePromExtn.setAttribute("ExtnPromotionFlag", "Y");
                // MJ 12/07 Changes for CPE-4384, CPE-4385 start
                if (!YFCCommon.isVoid(sDiscountPct)) {
                    elePromExtn.setAttribute("ExtnDiscountPercent", String.valueOf((int) (Double.parseDouble(sDiscountPct) * 100)));
                }
                // MJ 12/07 Changes for CPE-4384, CPE-4385 end

                // Setting Specific attributes
                if (key.equalsIgnoreCase("734Q") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    Double dActualDiscPercent = dTLDPercentAmt / dTLDPercentPriceAmt * 100;
                    elePromotion.setAttribute("PromotionType", "PERCENT_OFF");
                    elePromotion.setAttribute("PromotionId", "734Q_00001");
                    // Fix for defect 4146 - Start
                    String promoDescription = "Tran Disc" + " " + dActualDiscPercent;
                    elePromotion.setAttribute("Description", promoDescription);
                    // Fix for defect 4146 - End
                    elePromExtn.setAttribute("ExtnPromoSequence", "2");
                    elePromExtn.setAttribute("ExtnScannedSequence", "2");
                    //elePromExtn.setAttribute("ExtnDiscountPercent", df.format(Math.abs(dActualDiscPercent)));

                }
                if (key.equalsIgnoreCase("728S") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    elePromotion.setAttribute("PromotionType", "SENIOR_DISCOUNT");
                    elePromotion.setAttribute("PromotionId", "728S_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "3");
                    elePromExtn.setAttribute("ExtnPromotionResponse", "<RuleList/>");
                    elePromExtn.setAttribute("ExtnScannedSequence", "3");
                    // elePromExtn.setAttribute("ExtnDiscountPercent",
                    //     Double.toString(Double.parseDouble(sDiscountPct) * 100));

                } else if (key.equalsIgnoreCase("760Q") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    elePromotion.setAttribute("PromotionType", "OFFER");
                    elePromotion.setAttribute("PromotionId", "760Q_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "4");
                    elePromExtn.setAttribute("ExtnPromotionFlag", "Y");
                    elePromExtn.setAttribute("ExtnScannedSequence", "4");
                    elePromExtn.setAttribute("ExtnScannedSequence", "4");
                    elePromExtn.setAttribute("ExtnDiscountTypeCode", "Q");
                    elePromExtn.setAttribute("ExtnDiscountReasonCode", "760");

                } else if (key.equalsIgnoreCase("790P") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    elePromotion.setAttribute("PromotionType", "ASSOCIATE_DISCOUNT");
                    elePromotion.setAttribute("PromotionId", "790P_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "5");
                    elePromExtn.setAttribute("ExtnPromotionFlag", "Y");
                    elePromExtn.setAttribute("ExtnScannedSequence", "5");

                } else if (key.equalsIgnoreCase("761I") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    // Setting as "OFFER" for Defect: 4184
                    elePromotion.setAttribute("PromotionType", "OFFER");
                    elePromotion.setAttribute("PromotionId", "761I_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "6");
                    elePromExtn.setAttribute("ExtnPromotionFlag", "Y");
                    elePromExtn.setAttribute("ExtnScannedSequence", "6");
                    elePromExtn.setAttribute("ExtnDiscountTypeCode", "I");
                    elePromExtn.setAttribute("ExtnDiscountReasonCode", "761");
                }
                //PST-2818 - Start
                else if (key.equalsIgnoreCase("760K") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    // Setting as "OFFER" for Defect: 4184
                    elePromotion.setAttribute("PromotionType", "OFFER");
                    elePromotion.setAttribute("PromotionId", "760K_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "6");
                    elePromExtn.setAttribute("ExtnPromotionFlag", "Y");
                    elePromExtn.setAttribute("ExtnScannedSequence", "6");
                }
                //PST-2818 - End

                else if (key.equalsIgnoreCase("734K") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    elePromotion.setAttribute("PromotionType", "AMOUNT_OFF");
                    elePromotion.setAttribute("PromotionId", "734K_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "1");
                    elePromExtn.setAttribute("ExtnScannedSequence", "1");
                    //elePromExtn.setAttribute("ExtnDiscountPercent",
                    //    Double.toString(Double.parseDouble(sDiscountPct) * 100));

                    // Changes for PR-299 - Start
                } else if (key.equalsIgnoreCase("734R") && Double.parseDouble(sDiscountAmt) != 0.00) {
                    elePromotion.setAttribute("PromotionType", "KOHLS_CASH");
                    elePromotion.setAttribute("PromotionId", "734R_00001");
                    elePromExtn.setAttribute("ExtnPromoSequence", "1");
                    elePromExtn.setAttribute("ExtnScannedSequence", "1");
                    //elePromExtn.setAttribute("ExtnDiscountPercent",
                    //    Double.toString(Double.parseDouble(sDiscountPct) * 100));

                }
                // Changes for PR-299 - End
            }

        }
        eleOrder.setAttribute(MAX_SEQUENCE_LINE, Integer.toString(maxSequenceLine));
        Element elePaymentMethods = docOutXML.createElement("PaymentMethods");
        eleOrder.appendChild(elePaymentMethods);
        Element eTendersAvailableForReturn = docOutXML.createElement("TendersAvailableForReturn");
        eleOrder.appendChild(eTendersAvailableForReturn);

        NodeList nlOTRReturnTender = eleOpenToReturn.getElementsByTagName("ReturnTender");

        double dTotalAvailableAmt = 0.0D;
        boolean bKMCTenderProcessed = false;
        Element eleKMCPaymentMethod = null;
        Element eleKMCOTRTender = null;
        for (int i = 0; i < nlOTRReturnTender.getLength(); i++) {
            Element eleOTRReturnTender = (Element) nlOTRReturnTender.item(i);
            String sTenderTypeCode = getString("TenderTypeCde", eleOTRReturnTender);
            // MJ 07-22 Added logic to consolidate the multiple KMCs from RS in case of Gift Registry
            // Lookup or Gift Receipt Return -start
            if (bKMCTenderProcessed && "KohlsMerchandiseReturnCredit".equalsIgnoreCase(sTenderTypeCode)) {
                String sAvailableAmt = getString("AvailableAmt", eleOTRReturnTender);
                dTotalAvailableAmt = dTotalAvailableAmt + Double.parseDouble(sAvailableAmt);
                Double dTempAvailableAmt =
                        Double.parseDouble(eleKMCPaymentMethod.getAttribute("TotalAuthorized"));
                eleKMCPaymentMethod.setAttribute("TotalAuthorized",
                        df.format(Double.parseDouble(sAvailableAmt) + dTempAvailableAmt));
                eleKMCPaymentMethod.setAttribute("TotalCharged",
                        df.format(Double.parseDouble(sAvailableAmt) + dTempAvailableAmt));
                eleKMCPaymentMethod.setAttribute("RequestAmount",
                        df.format(Double.parseDouble(sAvailableAmt) + dTempAvailableAmt));
                Element elePaymentDetails =
                        (Element) eleKMCPaymentMethod.getElementsByTagName("PaymentDetails").item(0);
                elePaymentDetails.setAttribute("ProcessedAmount",
                        df.format(Double.parseDouble(sAvailableAmt) + dTempAvailableAmt));

                Element eleAvailableAmt =
                        (Element) eleKMCOTRTender.getElementsByTagName("AvailableAmt").item(0);
                XMLUtil.setNodeValue(eleAvailableAmt,
                        df.format(Double.parseDouble(sAvailableAmt) + dTempAvailableAmt));
                continue;
            }

            Element elePaymentMethod = docOutXML.createElement("PaymentMethod");
            String sExpDate = getString("ExpirationDte", eleOTRReturnTender);
            // If Exp date from RS is encrypted then decrypting the same
            if (!YFCCommon.isVoid(sExpDate) && sExpDate.length() != 4) {
                sExpDate = decryptExpirationDate(sExpDate);
                setString("ExpirationDte", eleOTRReturnTender, sExpDate);
            }
            Element eleRetTender = (Element) docOutXML.importNode(eleOTRReturnTender, true);
            eTendersAvailableForReturn.appendChild(eleRetTender);

            if ("KohlsMerchandiseReturnCredit".equalsIgnoreCase(sTenderTypeCode)) {
                bKMCTenderProcessed = true;
                eleKMCPaymentMethod = elePaymentMethod;
                eleKMCOTRTender = eleRetTender;
            }
            // Consolidate multiple KMCs - end

            String sTenderManagementOrderNbr = getString("TenderManagementOrderNbr", eleOTRReturnTender);
            String sTenderId = getString("TenderId", eleOTRReturnTender);
            String sAvailableAmt = getString("AvailableAmt", eleOTRReturnTender);
            dTotalAvailableAmt = dTotalAvailableAmt + Double.parseDouble(sAvailableAmt);
            String sTransNo = getString("TransactionNbr", eleOpenToReturn);

            if (sTenderTypeCode.equalsIgnoreCase("KohlsCharge")) {
                elePaymentMethod.setAttribute("PaymentType", "KOHLS_CHARGE_CARD");
                elePaymentMethod.setAttribute("CreditCardType", "04");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "CREDIT_CARD");
            } else if (sTenderTypeCode.equalsIgnoreCase("Cash")) {
                elePaymentMethod.setAttribute("PaymentType", "CASH");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "OTHER");
            } else if (sTenderTypeCode.equalsIgnoreCase("MasterCardCredit")) {
                elePaymentMethod.setAttribute("PaymentType", "CREDIT_CARD");
                elePaymentMethod.setAttribute("CreditCardType", "06");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "CREDIT_CARD");
            } else if (sTenderTypeCode.equalsIgnoreCase("VisaCredit")) {
                elePaymentMethod.setAttribute("PaymentType", "CREDIT_CARD");
                elePaymentMethod.setAttribute("CreditCardType", "05");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "CREDIT_CARD");
            } else if (sTenderTypeCode.equalsIgnoreCase("DiscoverCredit")) {
                elePaymentMethod.setAttribute("PaymentType", "CREDIT_CARD");
                elePaymentMethod.setAttribute("CreditCardType", "07");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "CREDIT_CARD");
            } else if (sTenderTypeCode.equalsIgnoreCase("AmericanExpressCredit")) {
                elePaymentMethod.setAttribute("PaymentType", "CREDIT_CARD");
                elePaymentMethod.setAttribute("CreditCardType", "08");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "CREDIT_CARD");
            } else if (sTenderTypeCode.equalsIgnoreCase("KohlsMerchandiseReturnCredit")) {
                elePaymentMethod.setAttribute("PaymentType", "KMC");
                elePaymentMethod.setAttribute("CreditCardType", "02");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "STORED_VALUE_CARD");
            }

            // CAPE-263 -- Start
            else if (sTenderTypeCode.equalsIgnoreCase("ATMDebit")) {
                elePaymentMethod.setAttribute("PaymentType", "DEBIT_CARD");
                elePaymentMethod.setAttribute("CreditCardType", "19");
                elePaymentMethod.setAttribute("PaymentTypeGroup", "DEBIT_CARD");
            }

            // CAPE-263 -- End

            // CAPE-4074 - start
            if (!("CASH".equals(elePaymentMethod.getAttribute("PaymentType"))
                    || "KMC".equals(elePaymentMethod.getAttribute("PaymentType")))) {
                String sTenderSource = getString("TenderSource", eleOTRReturnTender);
                if (!YFCCommon.isVoid(sTenderSource)) {
                    String sEntryMethod = mapTenderEntryMethod.get(sTenderSource);
                    if (!YFCCommon.isVoid(sEntryMethod)) {
                        elePaymentMethod.setAttribute("EntryMethod", sEntryMethod);
                    }
                }
            }
            // CAPE-4074 - End

            /*
             * else { elePaymentMethod.setAttribute("PaymentType", sTenderTypeCode.toUpperCase());
             * elePaymentMethod.setAttribute("PaymentTypeGroup", "OTHER"); }
             */
            if (!YFCCommon.isVoid(elePaymentMethod.getAttribute("PaymentType"))) {
                if (sTenderTypeCode.equalsIgnoreCase("ATMDebit")) {
                    elePaymentMethod.setAttribute("DebitCardNo", sTenderId);
                } else {
                    elePaymentMethod.setAttribute("CreditCardNo", sTenderId);
                }
                elePaymentMethod.setAttribute("CreditCardExpDate", sExpDate);
                elePaymentMethod.setAttribute("TotalAuthorized", sAvailableAmt);
                elePaymentMethod.setAttribute("TotalCharged", sAvailableAmt);
                elePaymentMethod.setAttribute("RequestAmount", sAvailableAmt);
                elePaymentMethod.setAttribute("PaymentReference1", sOrigBizDay + sTransNo);

                elePaymentMethod.setAttribute("PaymentReference2", sTenderManagementOrderNbr);

                // elePaymentMethod.setAttribute("PaymentTypeGroup", "OTHER");
                elePaymentMethod.setAttribute("SuspendAnyMoreCharges", "Y");
                elePaymentMethods.appendChild(elePaymentMethod);

                Element elePaymentDetailsList = docOutXML.createElement("PaymentDetailsList");
                elePaymentMethod.appendChild(elePaymentDetailsList);

                Element PaymentDetails = docOutXML.createElement("PaymentDetails");
                elePaymentDetailsList.appendChild(PaymentDetails);
                PaymentDetails.setAttribute("ChargeType", "CHARGE");
                PaymentDetails.setAttribute("ProcessedAmount", sAvailableAmt);
                PaymentDetails.setAttribute("RequestProcessed", "Y");
                PaymentDetails.setAttribute("InPerson", "N");
                PaymentDetails.setAttribute("CallForAuthorizationStatus", "CHECKED");
                PaymentDetails.setAttribute("Reference1", sOrigBizDay + sTransNo);
            }

        }
        elePriceInfo.setAttribute("TotalAmount", Double.toString(dTotalAvailableAmt));
        elePriceInfo.setAttribute("InvoicedAmount", Double.toString(dTotalAvailableAmt));
        // Changes for PR-343 - Start
        Document docTaxInd = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
        Element eleTaxDetList = docTaxInd.getDocumentElement();
        //CPE-214 Changes - Start
        String strTotalFeeTaxAmount = String.valueOf(dTotalFeeTaxAmount);
        XMLUtil.setAttribute(eleTaxDetList, KohlsPOCConstant.Total_Fee_Tax_Amount, strTotalFeeTaxAmount);
        //CPE-214 Changes - End
        Element eleTaxDetail = XMLUtil.createChild(eleTaxDetList, KohlsPOCConstant.E_TAX_DETAIL);
        if (iOrderLineCount > 0) {
            String sEffTaxRate = ((dEffTaxRate / iOrderLineCount) * 100) + "";
            eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE, sEffTaxRate);
        }
        String sTaxAmount = dTaxAmount + "";
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTaxAmount);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT,
                String.format("%.2f", dTotalTaxAmount));
        eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
                XMLUtil.getElementXMLString(eleTaxDetList));
        // Changes for PR-343 - End
        if ("false".equalsIgnoreCase(sGiftReceiptInd)) {
            Element eDeductibleOffers = docOutXML.createElement("DeductibleOffers");
            eleOrder.appendChild(eDeductibleOffers);
            NodeList nlOTRDeductibleOffer =
                    eleOpenToReturn.getElementsByTagName(KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
            Element eleCustomerDetail =
                    XMLUtil.getChildElement(eleOpenToReturn, KohlsXMLLiterals.E_LOYALTY_CUSTOMER_DETAILS);
            if (!YFCCommon.isVoid(nlOTRDeductibleOffer) && nlOTRDeductibleOffer.getLength() > 0) {

                for (int i = 0; i < nlOTRDeductibleOffer.getLength(); i++) {

                    Element eleDedOffer =
                            (Element) docOutXML.importNode((Element) nlOTRDeductibleOffer.item(i), true);
                    // MJ Changes for CAPE-4221 - start, if OfferBalanceAmt is -ve, set it as 0
                    String sOfferBalanceAmt =
                            eleDedOffer.getElementsByTagName("OfferBalanceAmt").item(0).getTextContent();
                    if (!YFCCommon.isVoid(sOfferBalanceAmt)) {
                        try {
                            Double dOfferBalanceAmt = Double.parseDouble(sOfferBalanceAmt);
                            if (dOfferBalanceAmt < 0) {
                                eleDedOffer.getElementsByTagName("OfferBalanceAmt").item(0).setTextContent("0.00");
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            log.error("Exception while setting the OfferBalanceAmt. Continue with transaction");
                        }
                    }
                    // MJ changes for CAPE-4221 - End
                    // PST-3419, 3296 - Start
                    String sEligibleAmt =
                            eleDedOffer.getElementsByTagName("EligibleAmt").item(0).getTextContent();
                    String sEarnedAmt =
                            eleDedOffer.getElementsByTagName("EarnedAmt").item(0).getTextContent();
                    if (!YFCCommon.isVoid(sEligibleAmt) && !YFCCommon.isVoid(sEarnedAmt)) {
                        try {
                            Double dEligibleAmt = Double.parseDouble(sEligibleAmt);
                            Double dEarnedAmt = Double.parseDouble(sEarnedAmt);
                            if (dEligibleAmt < 0) {
                                eleDedOffer.getElementsByTagName("EligibleAmt").item(0).setTextContent("0.00");
                            }
                            if (dEarnedAmt < 0) {
                                eleDedOffer.getElementsByTagName("EarnedAmt").item(0).setTextContent("0.00");
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            log.error(
                                    "Exception while setting the EligibleAmt and EarnedAmt. Continue with transaction");
                        }
                    }
                    // PST-3419, 3296 - End
                    if (!YFCCommon.isVoid(eleCustomerDetail)) {
                        Element elecustomer = (Element) docOutXML.importNode(eleCustomerDetail, true);
                        eleDedOffer.appendChild(elecustomer);
                    }
                    eDeductibleOffers.appendChild(eleDedOffer);
                }
            } else if (!YFCCommon.isVoid(eleCustomerDetail)) {
                Element eleDeductibleOffer = docOutXML.createElement(KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
                eDeductibleOffers.appendChild(eleDeductibleOffer);
                Element elecustomer = (Element) docOutXML.importNode(eleCustomerDetail, true);
                eleDeductibleOffer.appendChild(elecustomer);
            }
        }

        Element ePOCOrder = docOutXML.createElement("POCOrder");
        eleOrder.appendChild(ePOCOrder);
        ePOCOrder.setTextContent("false");
        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("######### translateRSResponse output XML #########"
                    + KohlsUtil.extractStringFromNode(docOutXML));
        }

        log.endTimer("KohlsTranslateOTRResponse.translateRSResponse");
        return docOutXML;
    }

    private String prepadString(String sAttribute, Element eleHeader, int iNoOfTimes, String sStringtoPrepad) {
        // TODO Auto-generated method stub
        return KohlsPoCPnPUtil.prepadString(getString(sAttribute, eleHeader), iNoOfTimes, sStringtoPrepad);
    }

    /**
     * @param i
     * @param eleOTRReturnLineItem
     * @param listFee
     * @throws DOMException
     */
    private void transformRSLineFeeElement(int i, Element eleOTRReturnLineItem,
                                           List<Element> listFee) throws DOMException {
        log.beginTimer("KohlsTranslateOTRResponse.transformRSLineFeeElement");
        try {
            if (!YFCCommon.isVoid(listFee) && listFee.size() > 0) {
                for (int f = 0; f < listFee.size(); f++) {
                    Element eleFee = (Element) listFee.get(f);
                    if (!YFCCommon.isVoid(eleFee)) {
                        Iterator ite = XMLUtil.getChildren(eleFee);
                        while (ite.hasNext()) {
                            Element existEle = (Element) ite.next();
                            XMLUtil.setAttribute(eleFee, existEle.getNodeName(), existEle.getTextContent());
                            XMLUtil.removeChild(eleFee, existEle);
                        }
                    }
                    Element feesEle = XMLUtil.createChild(eleOTRReturnLineItem, KohlsPOCConstant.SMALL_ATTR_FEES);
                    XMLUtil.setAttribute(feesEle, KohlsPOCConstant.SMALL_ATTR_BASIS_AMOUNT, eleFee.getAttribute("FeeBasisAmount"));
                    XMLUtil.setAttribute(feesEle, KohlsPOCConstant.SMALL_ATTR_CAL_AMT, eleFee.getAttribute("FeeAmt"));
                    XMLUtil.setAttribute(feesEle, KohlsPOCConstant.SMALL_ATTR_FEE_ID, eleFee.getAttribute("FeeId"));
                    XMLUtil.setAttribute(feesEle, KohlsPOCConstant.SMALL_ATTR_IS_TAXABLE, eleFee.getAttribute("FeeTaxable"));
                    String sFeeRate = eleFee.getAttribute("FeeRate");
                    if (!YFCCommon.isVoid(sFeeRate)) {
                        try {
                            Double dFee = Double.parseDouble(sFeeRate) * 100;
                            sFeeRate = new DecimalFormat("#0.00").format(dFee);
                        } catch (Exception ex) {
                            log.error("Error while transforming fee Rate " + ex.getMessage());
                            sFeeRate = "0.00";
                        }
                    } else {
                        sFeeRate = "0.00";
                    }
                    XMLUtil.setAttribute(feesEle, KohlsPOCConstant.SMALL_ATTR_RATE_FEE, sFeeRate);
                    XMLUtil.setAttribute(feesEle, KohlsPOCConstant.SMALL_SHORT_DESCRIPTION, eleFee.getAttribute("FeeDescription"));
                }
            }
        } catch (Exception e) {
            log.error("Exception while transforming TaxFee element from KohlsTranslateOTRResponse.transformRSLineFeeElement" + e.getStackTrace());
        }
        log.endTimer("KohlsTranslateOTRResponse.transformRSLineFeeElement");
    }

    protected String getString(String tagName, Element element) {
        log.beginTimer("KohlsTranslateOTRResponse.getString");
        NodeList list = element.getElementsByTagName(tagName);
        if (list != null && list.getLength() > 0) {
            NodeList subList = list.item(0).getChildNodes();

            if (subList != null && subList.getLength() > 0) {
                log.endTimer("KohlsTranslateOTRResponse.getString");
                return subList.item(0).getNodeValue();
            }
        }
        log.endTimer("KohlsTranslateOTRResponse.getString");
        return null;
    }

    protected void setString(String tagName, Element element, String sValue) {
        log.beginTimer("KohlsTranslateOTRResponse.setString");
        NodeList list = element.getElementsByTagName(tagName);
        if (list != null && list.getLength() > 0) {
            NodeList subList = list.item(0).getChildNodes();

            if (subList != null && subList.getLength() > 0) {
                log.endTimer("KohlsTranslateOTRResponse.getString");
                subList.item(0).setNodeValue(sValue);
            }
        }
    }

    protected String getOrderNo(YFSEnvironment env, String sOrderDate, String sStoreId, String sTerminalId,
                                String sTranNo) throws ParseException {
        log.beginTimer("KohlsTranslateOTRResponse.getOrderNo");

        log.debug("sOrderDate" + sOrderDate + " sStoreId: " + sStoreId + " sTerminalId: " + sTerminalId
                + " sTranNo: " + sTranNo);
        String desiredDateFormat = "";

        String ruleValue;
        try {
            ruleValue = getUseTimeInOrderNoRuleValue(env, sStoreId);
        } catch (Exception e) {
            ruleValue = "N";
        }
        if (Utils.isTrue(ruleValue)) {
            desiredDateFormat = "yyMMddhhmmss";
        } else {
            desiredDateFormat = "yyMMdd";
        }

        String YEAR_FORMAT = "yy";
        SimpleDateFormat sdf1 = new SimpleDateFormat(desiredDateFormat);
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

        if (YFCCommon.isVoid(sOrderDate)) {
            sOrderDate = sdf2.format(new Date(System.currentTimeMillis()));
        }

        StringBuilder orderNumberStringBuilder = null;

        // pad zeros if length of sequence # is less than 4
        if (StringUtils.isNotBlank(sTranNo)) {
            while (sTranNo.length() < 4) {
                sTranNo = "0" + sTranNo;
            }
        }

        orderNumberStringBuilder = new StringBuilder();

        // MON-DD-YR

        String formattedDate = sdf1.format(sdf2.parse(sOrderDate));
        orderNumberStringBuilder.append(formattedDate);

        // Capture only the last 4 digits of incoming ORG/Store id
        if (sStoreId.length() > 4) {
            int end = sStoreId.length();
            int start = end - 4;
            sStoreId = sStoreId.substring(start, end);
        } else {
            for (int i = sStoreId.length(); i < 4; ++i) {
                orderNumberStringBuilder.append("0");
            }
        }
        orderNumberStringBuilder.append(sStoreId);

        // Append 3 digit register number..pad zeros accordingly

        if (StringUtils.isBlank(sTerminalId)) {
            orderNumberStringBuilder.append("000");
        } else if (sTerminalId.length() == 3) {
            orderNumberStringBuilder.append(sTerminalId);
        } else if (sTerminalId.length() > 3) {
            orderNumberStringBuilder
                    .append(sTerminalId.substring(sTerminalId.length() - 3, sTerminalId.length()));
        } else if (sTerminalId.length() < 3) {
            for (int i = sTerminalId.length(); i < 3; ++i) {
                orderNumberStringBuilder.append("0");
            }
            orderNumberStringBuilder.append(sTerminalId);
        }

        // Append 4 digit Sequence number..pad zeros if needed
        if (StringUtils.isBlank(sTranNo)) {
            sTranNo = StringUtils.trimToEmpty(sTranNo);
        }
        for (int j = sTranNo.length(); j < 4; ++j) {
            orderNumberStringBuilder.append("0");
        }
        orderNumberStringBuilder.append(sTranNo);


        // return map;
        /*
         * String sOrderNo = ""; sBusinessDay = sBusinessDay.replace("-", ""); sOrderNo = sBusinessDay +
         * sStoreId + "0" + sTerminalId + sTranNo;
         */
        // Changes for PR-26 - POC Returns Team -- Start
        /*
         * Issue: TerminalId in Receipt is printed wrongly Fix: Import the OrderNo properly
         */
        // sOrderNo = sOrderNo.substring(2);
        // Changes for PR-26 - POC Returns Team -- End
        log.endTimer("KohlsTranslateOTRResponse.getOrderNo");
        return orderNumberStringBuilder.toString();
    }

    /**
     * @param orderLineEle
     * @throws ParserConfigurationException
     */
    @SuppressWarnings("rawtypes")
    public void groupLineCharges(Element orderLineEle) {
        log.beginTimer("KohlsTranslateOTRResponse.groupLineCharges");
        Element originalLineCharges =
                XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);
        Element modifiedLineCharges =
                XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);

        NodeList lineChargesList = orderLineEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);

        Map<String, List<Element>> chargeCategoryMap = new HashMap<String, List<Element>>();

        for (int i = 0; i < lineChargesList.getLength(); i++) {

            Element lineCharge = ((Element) lineChargesList.item(i));
            Element eleExtn = (Element) lineCharge.getElementsByTagName("Extn").item(0);
            String sDiscountCode = eleExtn.getAttribute("ExtnDiscountReasonCode");
            String sDiscountCodeType = eleExtn.getAttribute("ExtnDiscountTypeCode");
            if (sDiscountCode.equals("762") && sDiscountCodeType.equalsIgnoreCase("J")) {
                lineCharge.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, "LIDOfferDiscount");
                lineCharge.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, "OfferDiscount");

            }

            String ChargeCategory = XMLUtil.getAttribute(lineCharge, KohlsPOCConstant.ATTR_CHARGE_NAME);
            if (chargeCategoryMap.containsKey(ChargeCategory)) {
                chargeCategoryMap.get(ChargeCategory).add(lineCharge);
            } else {
                List<Element> tempCategoryList = new ArrayList<Element>();
                tempCategoryList.add(lineCharge);

                chargeCategoryMap.put(ChargeCategory, tempCategoryList);


            }
        }

        Iterator entries = chargeCategoryMap.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry entry = (Map.Entry) entries.next();
            List<Element> chargeCategoryList = (List<Element>) entry.getValue();
            double chargeAmount = KohlsPOCConstant.ZERO_DBL;
            ;

            for (Element chargeCatgoryElement : chargeCategoryList) {
                String tempChargeAmount =
                        XMLUtil.getAttribute(chargeCatgoryElement, KohlsPOCConstant.A_CHARGE_PER_LINE);
                chargeAmount += Math.abs(Double.valueOf(tempChargeAmount));
            }
            Element tempLineCharge = (Element) chargeCategoryList.get(0).cloneNode(true);
            XMLUtil.setAttribute(tempLineCharge, KohlsPOCConstant.A_CHARGE_PER_LINE, chargeAmount + "");
            XMLUtil.setAttribute(tempLineCharge, "ChargeAmount", chargeAmount + "");
            XMLUtil.setAttribute(tempLineCharge, "InvoicedChargeAmount", chargeAmount + "");
            XMLUtil.setAttribute(tempLineCharge, "InvoicedChargePerLine", chargeAmount + "");
            modifiedLineCharges.appendChild(tempLineCharge);
        }
        XMLUtil.removeChild(orderLineEle, originalLineCharges);
        log.endTimer("KohlsTranslateOTRResponse.groupLineCharges");
    }

    /**
     * @param sEncryptedDate
     * @return sDecryptedDate
     * @throws UnsupportedEncodingException
     * @throws XCException
     * @description: this method decrypts the encrypted CC/KCC exp date by using protegrity.
     */
    public String decryptExpirationDate(String sEncryptedDate)
            throws UnsupportedEncodingException, XCException {
        log.beginTimer("KohlsTranslateOTRResponse.decryptExpirationDate");
        log.debug("ExpirationDte from RS Is encrypted. Initiating decryption....");
        KohlsPoCInvokeDataSecurityPlatform securityPlatfrom = new KohlsPoCInvokeDataSecurityPlatform();
        String sHostXC = YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
        String policyUser = YFSSystem.getProperty(KohlsPOCConstant.POLICY_USER);
        String dataElement = "DATE";
        securityPlatfrom.run(sHostXC, policyUser);
        String sDecryptedDate = securityPlatfrom.returnDecryptedValue(sEncryptedDate, dataElement);
        log.debug("ExpirationDte decryption completed successfully .....");
        log.endTimer("KohlsTranslateOTRResponse.decryptExpirationDate");
        return sDecryptedDate;
    }

    /**
     * Transforms RS response code and description based on ResponseCde
     *
     * @param strResponseCode
     * @param strResponseDesc
     * @return
     */
    public String transformResponseCodesWithDesc(Element eleOTRResponseCde) {

        String strModResponseDesc = null;
        String strResponseReasonCde = eleOTRResponseCde.getAttribute("responseReasonCde");
        String strResponseReasonCdeVal = eleOTRResponseCde.getTextContent();
        StringBuilder stringBuilder = new StringBuilder();

        if (YFCCommon.isVoid(strResponseReasonCde)) {

            stringBuilder.append("000000-");
            stringBuilder.append("EDIT_ERROR"); // can be changed later based on
            // response from legacy
            strModResponseDesc = stringBuilder.toString();
            return strModResponseDesc;

        } else {

            if (strResponseReasonCdeVal.equalsIgnoreCase("Offline")) {

                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F9-");
                stringBuilder.append("CREDIT_OFFLINE");

            } else if (strResponseReasonCdeVal.equalsIgnoreCase("EditError")) {

                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F2-");
                stringBuilder.append("EDIT_ERROR");
            } else if (strResponseReasonCdeVal.equalsIgnoreCase("HardDecline")) {

                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F7-");
                stringBuilder.append("DENIED");
            } else if (strResponseReasonCdeVal.equalsIgnoreCase("Approval")) {

                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F0-");
                stringBuilder.append("APPROVED");
            } else if (strResponseReasonCdeVal.equalsIgnoreCase("TransactionNotFound")) {
                stringBuilder.append("000001");
                stringBuilder.append("F0-");
                stringBuilder.append("REFERAL");
            } else if (strResponseReasonCdeVal.equalsIgnoreCase("RefundAuth")) {
                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F1-");
                stringBuilder.append("");// reqd
            } else if (strResponseReasonCdeVal.equalsIgnoreCase("CorporateRefundRequired")) {
                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F8-");
                stringBuilder.append("REFERAL");
            } else {
                stringBuilder.append(strResponseReasonCde);
                stringBuilder.append("F2-");
                stringBuilder.append("EDIT_ERROR");
            }

            strModResponseDesc = stringBuilder.toString();

            return strModResponseDesc;

        }

    }

    public String modifyFeeDeatils(List<Element> nlFee, Element eleOrderLine, String delemiter, String origFee) {
        String strLineFeeAmountRate = KohlsPoCPnPUtil.updateFeeDetails(nlFee, eleOrderLine, "-", null, null);
        return strLineFeeAmountRate;
    }

    public double getRateBasedLineTaxFeeAmount(String strLineFeeAmountRate) {
        double feeAmount = KohlsPoCPnPUtil.getRateBasedLineTaxFeeAmount(strLineFeeAmountRate);
        return feeAmount;
    }

    public Double getConvertToDoubleVal(String sTaxableAmount) {
        Double dTaxAmount = KohlsPoCPnPUtil.convertToDouble(sTaxableAmount);
        return dTaxAmount;
    }

    public Map<String, String> getConfigMap(YFSEnvironment env) {
        Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
        return omni2ConfigMap;
    }

    public String getUseTimeInOrderNoRuleValue(YFSEnvironment env, String sStoreId) {
        String ruleValue;
        try {
            ruleValue = KohlsPoCCommonAPIUtil.getRuleValue(env, "USE_TIME_IN_ORDER_NO", sStoreId, "N");
        } catch (Exception e) {
            ruleValue = "N";
        }
        return ruleValue;
    }
}
