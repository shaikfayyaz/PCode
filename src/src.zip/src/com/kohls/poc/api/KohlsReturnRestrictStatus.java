package com.kohls.poc.api;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


import org.w3c.dom.Document;
import org.w3c.dom.Element;


import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsReturnRestrictStatus {

	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsReturnRestrictStatus.class.getName());
	static final String RESTRICTED_RETURN_POLICY_DATE ="restrictedReturnPolicyDate";
	static final String RESTRICTED_RETURN_POLICY_DAYS ="restrictedReturnPolicyDays";
	static final String RESTRICTION_START_DATE ="2019-09-01";
	static final int RESTRICTION_NO_OF_DAYS =180;
	static Calendar dRestrictionStartDate = null;
	static int iRestrictionDays = 0;
	static Calendar dStaticCurrentDate = null;
	static boolean refreshNeeded = true;
	
	public static String getRestrictionStatus(YFSEnvironment env,
			String sOrderDate, String sStoreId) throws Exception {
		log.beginTimer("KohlsReturnRestrictStatus.getRestrictionStatus");
		String isRestrictedStatus = KohlsPOCConstant.FALSE;
		try
		{
			String sysDate =null;
			SimpleDateFormat sdfYMD = new SimpleDateFormat("yyyy-MM-dd");
			Calendar cal = Calendar.getInstance();
			sysDate = sdfYMD.format(cal.getTime());
			Date dCurrentSysDate = sdfYMD.parse(sysDate);
			if (refreshNeeded) {
				 log.info("KohlsReturnRestrictStatus:: Fetch and Set RP config, Never set before");
				 callRPConfigurationAPI(env,dCurrentSysDate,sStoreId);
			} else if (dCurrentSysDate.after(dStaticCurrentDate.getTime())) {
				log.info("KohlsReturnRestrictStatus:: Refresh RP config. First call of the day");
				callRPConfigurationAPI(env,dCurrentSysDate,sStoreId);
			}
			else {
				log.info("KohlsReturnRestrictStatus:: No need to Refresh RP config for the current sys date. Current values are, Restriction Start date: " + dRestrictionStartDate.getTime() + " Restriction # of days: " +iRestrictionDays);
			}
			if(!YFCCommon.isVoid(sOrderDate)){
				Calendar saleTranDate = Calendar.getInstance();
				saleTranDate.setTime(sdfYMD.parse(sOrderDate));
				if (saleTranDate.equals(dRestrictionStartDate) || saleTranDate.after(dRestrictionStartDate)) {
					Calendar retRestrictionDay = Calendar.getInstance();
					retRestrictionDay.setTime(sdfYMD.parse(sOrderDate));
					retRestrictionDay.add(Calendar.DAY_OF_MONTH, iRestrictionDays);
					if (retRestrictionDay.getTime().before(dCurrentSysDate)) {
						isRestrictedStatus = KohlsPOCConstant.TRUE;
					} 
					log.info("KohlsReturnRestrictStatus:: Sale Restriction Start Date = " + dRestrictionStartDate.getTime() 
					+ " , Restriction # of days = " +iRestrictionDays +" , Current Sale Transaction date = "+saleTranDate.getTime()+
					" , Current System date = "+dCurrentSysDate+" , Last day to Return = "+retRestrictionDay.getTime()+" , Is Restricted Return? "+isRestrictedStatus);
				}
				else
				{
					log.info("KohlsReturnRestrictStatus:: Sale Restriction Start Date = " + dRestrictionStartDate.getTime() 
					+ " , Restriction # of days = " +iRestrictionDays +" , Current Sale Transaction date = "+saleTranDate.getTime()+
					" , Current System date = "+dCurrentSysDate+" , Last day to Return = N/A , Is Restricted Return? "+isRestrictedStatus);
				}
			}
		}
		catch(Exception e)
		{
			log.error("KohlsReturnRestrictStatus:: Unknown Error, responding back with Return Restricted = false",e);
		}
		log.endTimer("KohlsReturnRestrictStatus.getRestrictionStatus");
		return isRestrictedStatus;
	}

	private static void callRPConfigurationAPI(YFSEnvironment env, Date dcurrentdate, String sStoreId) throws Exception {
		
		log.beginTimer("KohlsReturnRestrictStatus.callRPConfigurationAPI");
		SimpleDateFormat sdfMDY = new SimpleDateFormat("MM-dd-yyyy");
		Document docRPResponse = null;
		Document inDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleOrder = inDoc.getDocumentElement();
		eleOrder.setAttribute(KohlsPOCConstant.E_SOURCE,"ReturnRestrictionCall");
		eleOrder.setAttribute(KohlsPOCConstant.FUNCTION,"RP_AUTHMGR");
		eleOrder.setAttribute(KohlsPOCConstant.ATTR_STORE_NO,sStoreId);
		
		Calendar prevSysDate = Calendar.getInstance();
		prevSysDate.setTime(dcurrentdate);
		prevSysDate.add(Calendar.DAY_OF_MONTH, -1);	
		
		if( log.isDebugEnabled() ){
			log.debug("Input Request KohlsCallRPWrapper :: "+XMLUtil.getXMLString(inDoc));
		}
		
		try
		{
		
		docRPResponse = KohlsCommonUtil.invokeService(env, KohlsPOCConstant.KOHLS_CALL_RP_WRAPPER, inDoc);
		
		if( log.isDebugEnabled() ){
			log.debug("Output document to RP Call :: "+XMLUtil.getXMLString(inDoc));
		}
		if(!YFCCommon.isVoid(docRPResponse) && docRPResponse.hasChildNodes()){

		Element eleRPResponse = docRPResponse.getDocumentElement();
		
		if(!YFCCommon.isVoid(eleRPResponse)){
			String strReturnRestrictionDate =eleRPResponse.getAttribute(RESTRICTED_RETURN_POLICY_DATE);
			String strReturnRestrictionDays =eleRPResponse.getAttribute(RESTRICTED_RETURN_POLICY_DAYS);
				if (!YFCCommon.isStringVoid(strReturnRestrictionDate) && !YFCCommon.isStringVoid(strReturnRestrictionDays))
				{
					log.info("KohlsReturnRestrictStatus:: Restriction Start date from RP response --> "+strReturnRestrictionDate+". Restriction No of days from RP response --> "+strReturnRestrictionDays);
					Date restrictionDateMDY = sdfMDY.parse(strReturnRestrictionDate);
					dRestrictionStartDate =  Calendar.getInstance();
					dRestrictionStartDate.setTime(restrictionDateMDY);
					iRestrictionDays = Integer.parseInt(strReturnRestrictionDays);
					dStaticCurrentDate = Calendar.getInstance();
					dStaticCurrentDate.setTime(dcurrentdate);
					refreshNeeded = false;
				}				
				else
				{
					log.info("KohlsReturnRestrictStatus:: Unexpected RP response while retrieving Return Restriction config information, falling back to Static days");
					checkandFallbacktoStaticDays(dcurrentdate,prevSysDate);
				}
			}
		}
		else
		{
			log.info("KohlsReturnRestrictStatus:: Exception while retrieving Return Restriction config information from RP, falling back to Static days");
			checkandFallbacktoStaticDays(dcurrentdate,prevSysDate);	
		}
		}
		catch(Exception e){
			log.error("KohlsReturnRestrictStatus:: Error in KohlsReturnRestrictStatus.callRPConfigurationAPI, falling back to Static days",e);
			checkandFallbacktoStaticDays(dcurrentdate,prevSysDate);
				
		}
	}
	
	
	private static void checkandFallbacktoStaticDays(Date dcurrentdate, Calendar previousSysdate) throws ParseException
	{
			log.beginTimer("KohlsReturnRestrictStatus.checkandFallbacktoStaticDays");
			if(iRestrictionDays==0 || (!YFCCommon.isVoid(dStaticCurrentDate) && dStaticCurrentDate.before(previousSysdate)))
			{
				iRestrictionDays = RESTRICTION_NO_OF_DAYS;
				dStaticCurrentDate = Calendar.getInstance();
				dStaticCurrentDate.setTime(dcurrentdate);
				dRestrictionStartDate = Calendar.getInstance();
				SimpleDateFormat sdfYMD = new SimpleDateFormat("yyyy-MM-dd");
				dRestrictionStartDate.setTime(sdfYMD.parse(RESTRICTION_START_DATE));
				refreshNeeded = true;
				log.info("KohlsReturnRestrictStatus:: Fetching Static constant values. Sale Restriction Start date: " + dRestrictionStartDate.getTime() + " Restriction # of days: " +iRestrictionDays);
			}
			else
			{
				log.info("KohlsReturnRestrictStatus:: Dates Not Reset. Current values are, Sale Restriction Start date: " + dRestrictionStartDate.getTime() + " Restriction # of days: " +iRestrictionDays);
			}
			log.endTimer("KohlsReturnRestrictStatus.checkandFallbacktoStaticDays");

	}

}	