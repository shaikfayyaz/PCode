package com.kohls.poc.api;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

//import weblogic.net.http.HttpsURLConnection;
import javax.net.ssl.HttpsURLConnection;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCDigitalKohlsCashAPI extends KOHLSBaseApi {
	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCDigitalKohlsCashAPI.class);
	
	
	String strCouponId="";
	String ID,EMAIL_ADDR,AMT_EARNED,RECEIPT_ID,DATETIME,STORE_NUM,REG_ID,TRAN_NUM,ACT_AMT,SCAN_IND,QUA_AMT ="";
	 
 	/**
 	 * This function generates the document to be sent to Sales Hub
 	 * 
 	 * @param env
 	 * @param inputPublishInvoiceDetail
 	 * @return docOutputPublishPOSInvoice
 	 * @exception Exception
 	 *           
 	 */
	 public String invokeDKCService(
			 	YFSEnvironment env, Document inputDoc) throws YFSException{
		 

		 Element eleDigitalKC = (Element)inputDoc.getDocumentElement();
		 ID=eleDigitalKC.getAttribute("EventID");
		 EMAIL_ADDR=eleDigitalKC.getAttribute("EmailID");
		 AMT_EARNED=eleDigitalKC.getAttribute("AmountEarned");
		 RECEIPT_ID=eleDigitalKC.getAttribute("ReceiptID");
		 DATETIME=eleDigitalKC.getAttribute("DateTime");
		 STORE_NUM=eleDigitalKC.getAttribute("StoreID");
		 REG_ID=eleDigitalKC.getAttribute("TerminalID");
		 TRAN_NUM=eleDigitalKC.getAttribute("TransactionNo");
		 ACT_AMT=eleDigitalKC.getAttribute("ActivityAmount");
		 SCAN_IND="false";
		 QUA_AMT=eleDigitalKC.getAttribute("QualifiedAmount");
		 String outputFromDKCService="";
		try {
			outputFromDKCService = getBarcodeFromDKC();
		} catch (IOException e) {
			e.printStackTrace();
		}
		 return outputFromDKCService;
	 }
	 
	/*
	 * 
	 * 
	 * {
		   "event": {
		      "id": "String",
		      "emailAddress": "String",
		      "amountEarned": "String"
		      
		    },
		   "transactionDetails": {
		      "receiptId": "String",
		      "dateTime": "String",
		      "storeNumber": "String",
		      "registarId": "String",
		      "transactionNumber": "String",
		      "activityAmount": "String",
		      "scanedIndicator": false,
		      "qualifiedAmount": "String"
		    }
		}
	 *
	 * 
	 */

	public String getBarcodeFromDKC() throws IOException {
		URL obj;
		String reqJson = "{\"event\":{ \"id\":\"" + ID+ "\", \"emailAddress\":" + EMAIL_ADDR
							+ "\", \"amountEarned\":"+ AMT_EARNED
							+"\" },\" \"transactionDetails\": { \"receiptId \": "+ RECEIPT_ID
							+ "\", \"dateTime\":"+ DATETIME
							+ "\", \"storeNumber\":"+ STORE_NUM
							+ "\", \"registarId\":"+ REG_ID
							+ "\", \"transactionNumber\":"+ TRAN_NUM
							+ "\", \"activityAmount\":"+ ACT_AMT
							+ "\", \"scanedIndicator\":"+ SCAN_IND
							+ "\", \"qualifiedAmount\":"+ QUA_AMT
							+"\" } }";
				
		logger.debug("Request Json is: " + reqJson);
		try {
			obj = new URL("https://ms-qa.tst.kohls.com/dep/api/v1/kohls-cash/issue");
			HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

			// add request header
			con.setRequestMethod("POST");
			con.setReadTimeout(Integer.parseInt("300"));
			con.setConnectTimeout(Integer.parseInt("300"));
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");
			con.setRequestProperty("X-DEP-Date","");
			con.setRequestProperty("Content-Length",reqJson.length()+"");
			con.setRequestProperty("Host","");
			con.setDoOutput(true);
			

			//Signature = Base64( HMAC-SHA256( AccessKeySecret, StringToSign)
			//Authorization = “DEP1-HMAC-SHA256” + “ ” + AccessKeyId + “:” + Signature

			con.setRequestProperty("Authorization", new String("authToken"));

			DataOutputStream buffer = new DataOutputStream(
					con.getOutputStream());
			buffer.writeBytes(reqJson);
			buffer.flush();
			buffer.close();
			int responseCode = con.getResponseCode();
			logger.debug("Device profile REST URL Response Code:: " + responseCode);

			if(responseCode==200){
				BufferedReader inBufReader = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = inBufReader.readLine()) != null) {
					response.append(inputLine);
				}
				inBufReader.close();// print result

				logger.debug("The DKC response::" + response.toString());
				JSONObject json = new JSONObject(response.toString());
				strCouponId=(String)json.get("barcode");
				
			}else {
				throw new YFCException("EXTN_CONNECT","Response code received is "+responseCode);
			}
			
		} catch( Exception e){
			throw new IOException();
		}
		return "strCouponId";
	}
}
