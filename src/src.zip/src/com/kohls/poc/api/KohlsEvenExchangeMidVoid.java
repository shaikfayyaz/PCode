package com.kohls.poc.api;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.yantra.yfs.japi.YFSEnvironment;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

public class KohlsEvenExchangeMidVoid extends KOHLSBaseApi {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsEvenExchangeMidVoid.class.getName());
	
	public Document docOrderOutput = null;

	public Document generateOutputForMidVoid(YFSEnvironment env,
			Document inputDoc) {

		Document docInputForGetOrderList = null;
		Document docInputForGetOrderDetails = null;
		Document docSalesOrderList = null;
		Document docOrigSalesOrder = null;
		Document outputDoc = null;
		Element eleOrigInvoice = null;
		Element eleReturnOrder = null;
		Element eleOrigOrder = null;
		Element eleOrderDetailsInput = null;
		Element eleROHeaderKey = null;
		Element eleOrderInput = null;
		String strDerivedFromOrderHeaderKey = null;

		String strOrderHeaderKey = null;
		String strROHeaderKey = null;
		KohlsOMSToTibco omsToTibco = new KohlsOMSToTibco();

		try {
			eleOrigInvoice = (Element) XPathUtil.getNodeList(inputDoc,
					"/InvoiceDetail/InvoiceHeader").item(0);

			eleOrigOrder = (Element) XPathUtil.getNodeList(inputDoc,
					"/InvoiceDetail/InvoiceHeader/Order").item(0);
		
			strOrderHeaderKey = eleOrigOrder.getAttribute("OrderHeaderKey");
		
			/*
			 * Create Input XML for getOrderList API to fetch
			 * ReturnOrderForExchange from exchange
			 */

			docInputForGetOrderList = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			eleOrderInput = docInputForGetOrderList.getDocumentElement();
			eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOrderHeaderKey);

			/* 
			 * Replacing order element of exchange with template driven order
			 * element for inclusion of customAttributes -- 6/6/16
			 */
			Document inputDoc1 = invokeService(env, "GetLinkedOrderList",
					docInputForGetOrderList);
			
			Element eleNewOrigOrder = (Element) XPathUtil.getNodeList(
					inputDoc1, "/Order").item(0);

			XMLUtil.removeChild(eleOrigInvoice, eleOrigOrder);
			XMLUtil.importElement(eleOrigInvoice, eleNewOrigOrder);
			
			
			if(logger.isDebugEnabled())
				logger.debug("Updated input document is :::"
						+ XMLUtil.getXMLString(inputDoc));
			
			outputDoc = invokeService(env, "GetOrderListDetails",
					docInputForGetOrderList);

			eleROHeaderKey = (Element) ((NodeList) XPathUtil
					.getNodeList(outputDoc.getDocumentElement(),
							"/OrderList/Order/ReturnOrdersForExchange/ReturnOrderForExchange"))
					.item(0);
			
			if(!YFCCommon.isVoid(eleROHeaderKey)){
			strROHeaderKey = eleROHeaderKey
					.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
			}
			if (!YFCCommon.isVoid(strROHeaderKey)) {
			// Create Input XML for getOrderDetails API

				docInputForGetOrderDetails = YFCDocument
						.createDocument("Order").getDocument();
			eleOrderDetailsInput = docInputForGetOrderDetails
					.getDocumentElement();

			eleOrderDetailsInput.setAttribute(
					KohlsPOCConstant.ATTR_ORD_HDR_KEY, strROHeaderKey);

			// API Call for getting Order element of Return order

		docOrderOutput = invokeService(env, "GetLinkedOrderList",
					docInputForGetOrderDetails);

				Element eleOrder = (Element) XPathUtil.getNode(
						docOrderOutput.getDocumentElement(), "/Order");
			
			Element eleExtnTax = (Element) ((NodeList) XPathUtil
					.getNodeList(docOrderOutput.getDocumentElement(),
							"/Order/Extn")).item(0);
			
				
				Element eleTempOrderLine = (Element) ((NodeList) XPathUtil
						.getNodeList(
								docOrderOutput.getDocumentElement(),
								"/Order/OrderLines/OrderLine/Extn")).item(0);
				

				String strExtnTaxDetails = eleExtnTax
						.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
			 Element eleTaxDetails = null;
				if (!YFCCommon.isVoid(strExtnTaxDetails)) {
					Document docExtnTaxDetails = XMLUtil
							.getDocument(strExtnTaxDetails);
					eleExtnTax.setAttribute(
							KohlsPOCConstant.A_EXTN_TAX_DETAILS,
							KohlsPOCConstant.BLANK);
				 eleTaxDetails = docExtnTaxDetails.getDocumentElement();
				 XMLUtil.importElement(eleOrder,eleTaxDetails);
			 }
			 
				NodeList ndListOrderLine = (NodeList) XPathUtil.getNodeList(
						docOrderOutput.getDocumentElement(),
						"/Order/OrderLines/OrderLine/Awards/Award");
			
				if (ndListOrderLine.getLength() != 0) {
					for (int i = 0; i < ndListOrderLine.getLength(); i++) {
						Element eleCurrentAward = (Element) ndListOrderLine
								.item(i);
						Element eleExtnChild = XMLUtil.getChildElement(
								eleCurrentAward, "Extn");
						String strSalesHubData = eleExtnChild
								.getAttribute("ExtnSalesHubData");
					 Element eleSalesHub = null;
						if (!YFCCommon.isVoid(strSalesHubData)) {
							Document docSalesHub = XMLUtil
									.getDocument(strSalesHubData);
							eleExtnChild.setAttribute("ExtnSalesHubData",
									KohlsPOCConstant.BLANK);
						 eleSalesHub = docSalesHub.getDocumentElement();
					
						 XMLUtil.importElement(eleExtnChild, eleSalesHub);
						 						 
					 }
					 			
				 }	 
			 }
						
			eleReturnOrder = docOrderOutput.getDocumentElement();
			
			if(logger.isDebugEnabled())
				logger.debug("Order element of return order is ::"
						+ XMLUtil.getElementXMLString(eleReturnOrder));
	
				inputDoc = updatedDocumentForMidVoid(env, inputDoc);
				
				if(logger.isDebugEnabled())
					logger.debug("Value returned by the method updatedDocumentForMidVoid "
							+ XMLUtil.getXMLString(inputDoc));
    	
				// Adding Extn Attributes For Defect# 2546 -- Begin --06/07/16 
				
				docSalesOrderList = invokeService(env, "GetSalesOrderList",
						docInputForGetOrderDetails);
				
				Element eleOrderLineKey = (Element) ((NodeList) XPathUtil
						.getNodeList(docSalesOrderList.getDocumentElement(),
								"/OrderList/Order/OrderLines/OrderLine")).item(0);
				
				if (!YFCCommon.isVoid(eleOrderLineKey)) {
				
					strDerivedFromOrderHeaderKey = eleOrderLineKey
						.getAttribute(KohlsXMLLiterals.A_DERIVED_FROM_ORDER_HEADER_KEY);
				}
				
				if (!(YFCCommon.isStringVoid(strDerivedFromOrderHeaderKey))) {
				
				
					logger.debug("Derived from order header key exists:::"+strDerivedFromOrderHeaderKey);
					
					
					Document docInputForSales = YFCDocument.createDocument("Order")
							.getDocument();
					Element eleOrderInput1 = docInputForSales.getDocumentElement();
					eleOrderInput1.setAttribute("OrderHeaderKey", strDerivedFromOrderHeaderKey);

					
				docOrigSalesOrder = invokeService(env, "GetLinkedOrderList",
						docInputForSales);
				
				
				Element eleSalesData = (Element) ((NodeList) XPathUtil
						.getNodeList(docOrigSalesOrder.getDocumentElement(),
								"/Order")).item(0);
				
				String strOrigPosSequenceNo = eleSalesData.getAttribute("PosSequenceNo");
				String strSellerOrgCode = eleSalesData.getAttribute("SellerOrganizationCode");
				String strTerminalID = eleSalesData.getAttribute("TerminalID");
				String strOrderDate = eleSalesData.getAttribute("OrderDate");
				
				
				
				
				Element eleUpdatedInvoice = (Element) ((NodeList) XPathUtil
						.getNodeList(inputDoc.getDocumentElement(),
								"/InvoiceDetail/InvoiceHeader")).item(0);
				
					Element eleExtn = XMLUtil.getChildElement(eleUpdatedInvoice, "Extn", true);
					
					eleExtn.setAttribute("ExtnSellerOrganisationCode",
							strSellerOrgCode);
					
					eleExtn.setAttribute("ExtnPosSequenceNo",
							strOrigPosSequenceNo);
					
					eleExtn.setAttribute("ExtnTerminalID",
							strTerminalID);
					
					
					eleExtn.setAttribute("ExtnOrderDate", strOrderDate);
				
				
				}
	else {
					
					
					logger.debug("Entering block for Non - Receipted Flow" );
					
					Element eleUpdatedInvoice = (Element) ((NodeList) XPathUtil
							.getNodeList(inputDoc.getDocumentElement(),
									"/InvoiceDetail/InvoiceHeader")).item(0);
					
					Element eleExtn = XMLUtil.getChildElement(eleUpdatedInvoice, "Extn", true);
					
					
					// Fix For Sale in POS Sale and Even Exchange Void in POC -- Begin -- 9/6/16
					
					Element eleCustomAttributeTextDate = (Element) ((NodeList) XPathUtil
							.getNodeList(
									docOrderOutput.getDocumentElement(),
									"/Order/OrderLines/OrderLine/CustomAttributes")).item(0);
					
					if(!(YFCCommon.isVoid(eleCustomAttributeTextDate)))
					{		
					if(!(YFCCommon.isVoid(eleCustomAttributeTextDate.getAttribute("Text3")))&&!(YFCCommon.isVoid(eleCustomAttributeTextDate.getAttribute("Date1")))&&
							!(YFCCommon.isVoid(eleTempOrderLine.getAttribute("ExtnSalesTransactionNo")))&&!(YFCCommon.isVoid(eleTempOrderLine.getAttribute("ExtnSalesTerminalID")))) 
					
									{
										logger.debug("Inside POS Sale Transaction Block");
						          		String strText3 = eleCustomAttributeTextDate.getAttribute("Text3");
						          		String strDate1 = eleCustomAttributeTextDate.getAttribute("Date1");
						          		eleExtn.setAttribute("ExtnSellerOrganisationCode",strText3);
						          		eleExtn.setAttribute("ExtnOrderDate",strDate1);
						
									}
					}
					// Fix For Sale in POS Sale and Even Exchange Void in POC -- End -- 9/6/16
					else
					{
								logger.debug("Non-Receipted Flow for Normal EvenExchange");
								String strReturnDate = eleReturnOrder.getAttribute("OrderDate");	
						eleExtn.setAttribute("ExtnOrderDate", strReturnDate);
					
					}
				}
				
				
				// Adding Extn Attributes For Defect# 2546 -- Begin -- 7/6/16
					
				logger.debug("Invoking final method --- calculateTotalOrderLines");
                
				inputDoc = omsToTibco.calculateTotalOrderLines(inputDoc);
				
				if(logger.isDebugEnabled())
					logger.debug("Output of final method call is ---"
							+ XMLUtil.getXMLString(inputDoc));

			/*
				 * Commenting this block of code due to change in requirement --
				 * begin-- 6/6/16
				 * 
				 * 
				 * // Re-placing Exchange Order element with Return order
				 * element eleOrigInvoice.removeChild(eleOrigOrder);
				 * XMLUtil.importElement(eleOrigInvoice, eleReturnOrder);
				 * 
				 * Commenting this block of code due to change in requirement --
				 * End -- 6/6/16
				 */
					
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return inputDoc;

	}

	public Document updatedDocumentForMidVoid(YFSEnvironment env,
			Document docFinalXMLtoTibco) {

		HashMap<String, String> hmap = new HashMap<String, String>();
		HashMap<String, String> hmap2 = new HashMap<String, String>();
		String strKey = null;
		String strExchngeOLkey = null;
		String strReturnOLkey = null;
		String strExtnRIpairlineKey = null;
		String negative = "-";
		Element eleOrderLineExchange = null;

		try {
						
			logger.debug("Inside updatedDocumentForMidVoid method");
			
			
			if(logger.isDebugEnabled())
				logger.debug("Return order document is :"
						+ XMLUtil.getXMLString(docOrderOutput));
			
			NodeList ndlOrderLineForExchange = ((NodeList) XPathUtil
					.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
							"/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine"));
			
			NodeList ndlOrderLineForReturn = ((NodeList) XPathUtil.getNodeList(
					docOrderOutput.getDocumentElement(),
					"/Order/OrderLines/OrderLine"));

			for (int i = 0; i < ndlOrderLineForExchange.getLength(); i++) {

				Element eleOrderLineForExchange = (Element) ndlOrderLineForExchange
						.item(i);

				Element eleItemLevel = XMLUtil.getChildElement(
						eleOrderLineForExchange, "Item");
				
				if(logger.isDebugEnabled())
					logger.debug("Item level element from  exchange nodelist is :::"
							+ XMLUtil.getElementXMLString(eleOrderLineForExchange));

				// Fix for UPC code -- begin -- 6/6/16

				Document docGetItemListInput = YFCDocument.createDocument(
						KohlsPOCConstant.ELEM_ITEM).getDocument();
				Element eleItemInput = docGetItemListInput.getDocumentElement();
				String strItemId = eleItemLevel.getAttribute("ItemID");
				String strUPCCode = eleItemLevel.getAttribute("UPCCode");
				eleItemInput
						.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);

				Document docItemListOutput1 = KOHLSBaseApi
						.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST,
								KohlsPOCConstant.API_GET_ITEM_LIST,
								docGetItemListInput);

				if (YFCCommon.isVoid(strUPCCode) || strUPCCode.isEmpty()
						|| strUPCCode == null) {
					String upc_code = KohlsPoCPnPUtil
							.getUpcCode(docItemListOutput1);

					if (YFCCommon.isVoid(upc_code) || upc_code.isEmpty()
							|| upc_code == null) {
						upc_code = "No UPC Found";
					}
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE,
							upc_code);
				} else {
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE,
							strUPCCode);
				}

				// Fix for UPC code -- end -- 6/6/16

				// Commented as a part of Custom Attribute fix -- begin

				/*
				 * Element eleOrderLineForExchangeExtn = (Element) ((NodeList)
				 * XPathUtil .getNodeList(
				 * docFinalXMLtoTibco.getDocumentElement(),
				 * "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine/Extn"
				 * )).item(i);
				 */

				// Commented as a part of Custom Attribute fix -- End

				Element eleOrderLineForExchangeCustom = (Element) ((NodeList) XPathUtil
						.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
								"/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine/CustomAttributes"))
						.item(i);
				
				
				if(logger.isDebugEnabled())
					logger.debug("Custom Attribute element is::"
							+ XMLUtil
							.getElementXMLString(eleOrderLineForExchangeCustom));

				// Commented as a part of Custom Attribute fix -- Begin

				/*
				 * strExtnRIpairlineKey
				 * =eleOrderLineForExchangeExtn.getAttribute
				 * ("ExtnReturnItemPairLineKey");
				 */

				// Commented as a part of Custom Attribute fix -- End

				strExtnRIpairlineKey = eleOrderLineForExchangeCustom
						.getAttribute(KohlsXMLLiterals.Text2);

				strExchngeOLkey = eleOrderLineForExchange
						.getAttribute("OrderLineKey");

				logger.debug("ExtnReturnItemPairLineKey is :::"
						+ strExtnRIpairlineKey);
				logger.debug("OrderLineKey for the exchange order is ::"
						+ strExchngeOLkey);

				if ((!YFCCommon.isVoid(strExtnRIpairlineKey))
						&& (!YFCCommon.isVoid(strExchngeOLkey))) {
					hmap.put(strExchngeOLkey, strExtnRIpairlineKey);
					hmap2.put(strExtnRIpairlineKey, strExchngeOLkey);
				}

			}

			Element eleOrderLineParent = (Element) XPathUtil.getNode(
					docFinalXMLtoTibco.getDocumentElement(),
					"/InvoiceDetail/InvoiceHeader/Order/OrderLines");
			
			
			if(logger.isDebugEnabled())
				logger.debug("Orderlines element for exchange is "
						+ XMLUtil.getElementXMLString(eleOrderLineParent));

			NodeList ndlOrderLine1 = XPathUtil.getNodeList(
					docFinalXMLtoTibco.getDocumentElement(),
					"/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine");

			for (int b = 0; b < ndlOrderLine1.getLength(); b++) {
				XMLUtil.removeChild(eleOrderLineParent,
						(Element) ndlOrderLine1.item(b));

			}

			for (int i = 0; i < ndlOrderLineForReturn.getLength(); i++) {

				logger.debug("Entered nodelist iteration of return order");

				Element eleOrderLineForReturn = (Element) ndlOrderLineForReturn
						.item(i);
				
				
				if(logger.isDebugEnabled())
					logger.debug("Current element in return orderline is ::"
							+ XMLUtil.getElementXMLString(eleOrderLineForReturn));
				
				Element eleItemLevel = XMLUtil.getChildElement(
						eleOrderLineForReturn, "Item");
				Element eleLinePriceInfo = XMLUtil.getChildElement(
						eleOrderLineForReturn, "LinePriceInfo");
				Element eleLineOverrallTotals = XMLUtil.getChildElement(
						eleOrderLineForReturn, "LineOverallTotals");

				// Fix for UPC code -- begin -- 6/6/16

				Document docGetItemListInput = YFCDocument.createDocument(
						KohlsPOCConstant.ELEM_ITEM).getDocument();
				Element eleItemInput = docGetItemListInput.getDocumentElement();
				String strItemId = eleItemLevel.getAttribute("ItemID");
				String strUPCCode = eleItemLevel.getAttribute("UPCCode");
				eleItemInput
						.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);

				Document docItemListOutput1 = KOHLSBaseApi
						.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST,
								KohlsPOCConstant.API_GET_ITEM_LIST,
								docGetItemListInput);

				if (YFCCommon.isVoid(strUPCCode) || strUPCCode.isEmpty()
						|| strUPCCode == null) {

					String upc_code = KohlsPoCPnPUtil
							.getUpcCode(docItemListOutput1);
					if (YFCCommon.isVoid(upc_code) || upc_code.isEmpty()
							|| upc_code == null) {
						upc_code = "No UPC Found";
					}
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE,
							upc_code);
				} else {
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE,
							strUPCCode);
				}

				// Fix for UPC code -- end -- 6/6/16

				String strLineTotal1 = eleLinePriceInfo
						.getAttribute("LineTotal");
				String strLineTotal2 = eleLineOverrallTotals
						.getAttribute("LineTotal");
				strLineTotal2 = negative.concat(strLineTotal2);
				strLineTotal1 = negative.concat(strLineTotal1);
				eleLinePriceInfo.setAttribute("LineTotal", strLineTotal1);
				eleLineOverrallTotals.setAttribute("LineTotal", strLineTotal2);

				strReturnOLkey = eleOrderLineForReturn
						.getAttribute("OrderLineKey");
				logger.debug("Return orderlinekey" + strReturnOLkey);
				if (!YFCCommon.isVoid(strReturnOLkey)) {

					if ((hmap.containsValue(strReturnOLkey))) {
						strKey = hmap2.get(strReturnOLkey);

						for (int x = 0; x < ndlOrderLineForExchange.getLength(); x++) {
							eleOrderLineExchange = (Element) ndlOrderLineForExchange
									.item(x);
							
							if(logger.isDebugEnabled())
								logger.debug("Exchange element under nested for loop is::"
										+ XMLUtil
										.getElementXMLString(eleOrderLineExchange));
							String strOLkey = eleOrderLineExchange
									.getAttribute("OrderLineKey");
							logger.debug("Order Line Key for Exchange :::"
											+ strOLkey);
							if (strOLkey.equals(strKey)) {
								XMLUtil.importElement(eleOrderLineParent,
										eleOrderLineForReturn);
								XMLUtil.appendChild(eleOrderLineParent,
										eleOrderLineExchange);
								break;
							}
						}

					} else {
						XMLUtil.importElement(eleOrderLineParent,
								eleOrderLineForReturn);
					}

				}

			}

			/*
			 * Element eleExtraExchange = (Element) ((NodeList) XPathUtil
			 * .getNodeList( docFinalXMLtoTibco.getDocumentElement(),
			 * "/InvoiceDetail/InvoiceHeader/Order/OrderLinesForExchange"
			 * )).item(0);
			 * 
			 * 
			 * 
			 * XMLUtil.removeChild((Element) eleExtraExchange.getParentNode(),
			 * eleExtraExchange);
			 */

		}

		catch (Exception e) {
			logger.debug("Exception thrown" + e);
		}

		return docFinalXMLtoTibco;
	}

}
