package com.kohls.poc.api;

import java.rmi.RemoteException;
import java.text.DecimalFormat;
import java.math.RoundingMode;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.xml.parsers.ParserConfigurationException;
import com.kohls.common.util.*;
import com.kohls.poc.constant.KohlsPOCConstant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * This class is called for creating POS Orders in OMS, publishes the payment signatures
 * and Audits to downstream systems.
 *
 * @author YANTRIKS
 *
 */

public class KohlsCreateStoreOrderPOS implements YIFCustomApi {

    private static final YFCLogCategory log = YFCLogCategory.instance(KohlsCreateStoreOrderPOS.class.getName());
    private static YIFApi api;
    private Properties props = null;
    public static final String A_SIG_LINK_ID = "SigLinkID";
    public static final String A_IS_DRAFT_ORDER = "IsDraftOrder";
    public static final String A_BYPASS_PRICING = "BypassPricing";
    public static final String A_MANAGER_ID = "ManagerID" ;
    public static final String E_SIG_CAP_OBJECT = "SigCapObject";
    public static final String A_SIGNATURE_DATE_FORMAT="SignatureDataFormat";
    public static final String A_APPEND_RECEIPT_DATA="AppendReceiptData";
    public static final String A_ORIGINIAL_TOTAL_AMOUNT="OriginalTotalAmount";
    public static final String A_DATA_ENCODING="DataEncoding";
    private static final String A_3_BYTE_ASCII="3ByteAscii";
    private static final String API_MANAGE_SIG_CAP_FOR_POS="manageSigCapForPOS";
    private static final String A_EXTRA_DETAILS_3="ExtraDetails3";
    private static final String API_TEMPLATE_GET_ORDER_LIST="<OrderList><Order OrderNo='' OrderHeaderKey='' OriginalTotalAmount='' SellerOrganizationCode=''><Extn ExtnIsVoidDuring=''/>" +
            "<OrderLines><OrderLine OrderLineKey='' PrimeLineNo=''><ItemDetails ItemID='' ItemKey=''/></OrderLine></OrderLines><ChargeTransactionDetails><ChargeTransactionDetail ChargeTransactionKey='' PaymentKey='' OfflineStatus=''>" +
            "<PaymentMethod PaymentType=''/></ChargeTransactionDetail>" +
            "</ChargeTransactionDetails><PaymentMethods><PaymentMethod ExtraDetails3='' PaymentKey=''><Extn ExtnVoidIndicator=''/></PaymentMethod></PaymentMethods></Order></OrderList>";
    private static final String E_CONFIRM_DRAFT_ORDER ="ConfirmDraftOrder";

    public KohlsCreateStoreOrderPOS() throws YIFClientCreationException {
        api = YIFClientFactory.getInstance().getLocalApi();
    }

    public void invoke(YFSEnvironment env,Document inXML) throws Exception{
        if(YFCLogUtil.isDebugEnabled()){
            log.debug("<!-------- Begining of KohlsCreateStoreOrderPOS invoke method ----------- >" + SCXmlUtil.getString(inXML));
        }
        
        boolean isVoidTenderIsPresent = false;
        List<String> listPaymentKey = new ArrayList();
		List<String> listCancelledOrderLines = new ArrayList<>();
		Element eleRoot = inXML.getDocumentElement();
		Element eleOrder=KohlsXMLUtil.getChildElement(eleRoot, KohlsPOCConstant.ELEM_ORDER);

        try {
			String strConsolidateLineTax = this.props.getProperty(KohlsPOCConstant.CONSOLIDATE_LINE_TAX);
			if (!YFCCommon.isVoid(strConsolidateLineTax) && KohlsPOCConstant.YES.equalsIgnoreCase(strConsolidateLineTax)) {
				inXML = consolidateLineTaxes(inXML, listCancelledOrderLines);
			} else {
                NodeList nlOrderLineList = eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
                if (!YFCCommon.isVoid(nlOrderLineList) && nlOrderLineList.getLength() > KohlsPOCConstant.ZERO_INT) {
                    for (int i = 0; i < nlOrderLineList.getLength(); i++) {
                        Element eleOrderLine = ((Element) nlOrderLineList.item(i));
                        if(KohlsPOCConstant.ACTION_CANCEL.equals(eleOrderLine.getAttribute(KohlsPOCConstant.ACTION))) {
                            listCancelledOrderLines.add(eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
                            eleOrderLine.removeAttribute(KohlsPOCConstant.ACTION);
                        }
                    }
                }
            }
            //Create Draft Order in OMS for this Store Order
            //Added for SPS order to set the source system as txn object.
            String strPurpose=eleOrder.getAttribute(KohlsPOCConstant.A_PURPOSE);
            if(!YFCCommon.isVoid(strPurpose) && "SPS".equalsIgnoreCase(strPurpose))  
            {
            	   env.setTxnObject(KohlsPOCConstant.SOURCE_SYSTEM, "SPS");
            }
            HashMap<String,Element> hmGiftLines = getGiftCardLines(eleOrder);
            Document outDocCreateDraftOrder=createDraftOrderForSPSOrder(env,eleOrder,listCancelledOrderLines);
            Document outDocGetOrderList=null;
            String strIsVoidDuring = null;

            Element eleExtn = SCXmlUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
            if(!YFCCommon.isVoid(eleExtn)) {
                strIsVoidDuring = SCXmlUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
            }

            if(!YFCObject.isNull(outDocCreateDraftOrder) && !YFCObject.isVoid(outDocCreateDraftOrder)){
                //getOrderList to get the paymentKeys
                Document getOrderListTemplate=SCXmlUtil.createFromString(API_TEMPLATE_GET_ORDER_LIST);
                env.setApiTemplate(KohlsPOCConstant.API_GET_ORDER_LIST, getOrderListTemplate);
                outDocGetOrderList=api.invoke(env, KohlsPOCConstant.API_GET_ORDER_LIST,outDocCreateDraftOrder);
                env.clearApiTemplate(KohlsPOCConstant.API_GET_ORDER_LIST);

                if(!YFCObject.isNull(outDocGetOrderList) && !YFCObject.isVoid(outDocGetOrderList)){
                    if(YFCLogUtil.isDebugEnabled()){
                        log.debug("Output of getOrderList::"+SCXmlUtil.getString(outDocGetOrderList));
                    }
                    if(!YFCCommon.isVoid(hmGiftLines) && (!hmGiftLines.isEmpty())){
                        this.callManageStoredValueLineForPOS(env,hmGiftLines,outDocGetOrderList, strIsVoidDuring);
                    }

                    NodeList paymentMethodList = outDocGetOrderList.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
                    for (int j = 0; j < paymentMethodList.getLength(); j++)
                    {
                        Element elePaymentMethod = (Element) paymentMethodList.item(j);
                        Element elePaymentExtn = SCXmlUtil.getChildElement(elePaymentMethod, KohlsPOCConstant.E_EXTN);
                        String strTemp = null;

                        if(!YFCCommon.isVoid(elePaymentExtn)) {
                            strTemp = elePaymentExtn.getAttribute("ExtnVoidIndicator");

                        }
                        if(!YFCCommon.isVoid(strTemp)) {
                            listPaymentKey.add(elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY));
                            isVoidTenderIsPresent = true;

                        }
                        if (null != elePaymentMethod.getAttribute(A_EXTRA_DETAILS_3))
                        {
                            String strPaymentMethodSigLinkID = elePaymentMethod.getAttribute(A_EXTRA_DETAILS_3);
                            //Iterate through SigCap only if its linked to a PaymentMethod
                            if(!YFCObject.isVoid(strPaymentMethodSigLinkID)){
                                String strPaymentKey = elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
                                NodeList sigCapList = eleRoot.getElementsByTagName(KohlsPOCConstant.ATTR_SIGN_CAP);
                                for (int k = 0; k < sigCapList.getLength(); k++)
                                {
                                    Element eleSigCap = (Element) sigCapList.item(k);
                                    if (null != eleSigCap.getAttribute(A_SIG_LINK_ID))
                                    {
                                        if (eleSigCap.getAttribute(A_SIG_LINK_ID).equalsIgnoreCase(strPaymentMethodSigLinkID)) {

                                            //Add PaymentKey to SigCap Element, to be used for signature updates further
                                            eleSigCap.setAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY, strPaymentKey);

                                            //Publish Signature Information of payments to downstream systems for this Store Order
                                            manageSigCapForPOS(env,eleSigCap,eleOrder);

                                            break;
                                        } else{
                                            continue;
                                        }
                                    }
                                }

                            }
                        }	} } }


            /* Fetch to ChargeTransactionDetail for SAF ELIGIBLE scenario voiding */
            NodeList chargeTranList = outDocGetOrderList.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);

            if(!YFCCommon.isVoid(chargeTranList)) {
                for(int i=0; i<chargeTranList.getLength(); i++) {
                    Element eleChargeTranDetail = (Element) chargeTranList.item(i);
                    String strTemp = eleChargeTranDetail.getAttribute(KohlsPOCConstant.A_OFFLINE_STATUS);

                    if(!YFCCommon.isVoid(strTemp) && KohlsConstant.YES.equals(strTemp)) {
                        listPaymentKey.add(eleChargeTranDetail.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY));
                        isVoidTenderIsPresent=true;
                    }
                }
            }
			
            /* Invoke capturePayment API */
            if(isVoidTenderIsPresent) {
                invokeVoidChargeTransaction(env, outDocGetOrderList.getDocumentElement(), listPaymentKey);
            }
			
			// Integrated enrollment to data collect.
			Element eleAdminAuditList = KohlsXMLUtil.getChildElement(inXML.getDocumentElement(), KohlsPOCConstant.E_ADMIN_AUDIT_LIST);
			if (!YFCCommon.isVoid(eleAdminAuditList))
				manageAdminAuditForPOS(env, eleAdminAuditList);
						
			//Publish Audit Information to downstream systems for this Store Order
            if (!YFCObject.isVoid(outDocGetOrderList))
                manageTransactionAuditForPOS(env, inXML, outDocGetOrderList, strIsVoidDuring);

            //CPE-7525 - Start
            env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.TRUE);
            //CPE-7525 - End
            //Confirm Draft Order to publish it to downstream system
            if (!YFCObject.isVoid(outDocCreateDraftOrder))
                confirmDraftOrderForStore(env, outDocCreateDraftOrder.getDocumentElement());


            //CPE-7525 - Start
            env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.TRUE);
            //CPE-7525 - End
            if (!YFCCommon.isVoid(strIsVoidDuring) && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {
                cancelOrderForStore(env, outDocCreateDraftOrder.getDocumentElement());
            }

            //Publish Signature Information of payments to downstream systems for this Store Order
            invokeManageReceiptData(env, SCXmlUtil.getChildElement(eleRoot, KohlsPOCConstant.ELE_RECEIPT_DATA),
                    outDocGetOrderList.getDocumentElement(), strIsVoidDuring);
            
        } catch (Exception ex) {
            log.error("Unable to create Store Order:: "+SCXmlUtil.getString(inXML));
            throw ex;
        }
    }
    
	/*
	 * This method is consolidate the line tax for mpoc orders.
	 * @param inDoc.
	 */

	protected Document consolidateLineTaxes(Document inDoc, List<String>listCancelledOrderLines) {
		log.beginTimer("KohlsCreateStoreOrderPOS::consolidateLineTaxes");
		Element eleOrder = KohlsXMLUtil.getChildElement(inDoc.getDocumentElement(), KohlsPOCConstant.E_ORDER);
		NodeList nlOrderLineList = eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
		if (!YFCCommon.isVoid(nlOrderLineList) && nlOrderLineList.getLength() > KohlsPOCConstant.ZERO_INT) {
			for (int i = 0; i < nlOrderLineList.getLength(); i++) {
				Element eleOrderLine = ((Element) nlOrderLineList.item(i));
				if("CANCEL".equals(eleOrderLine.getAttribute(KohlsPOCConstant.ACTION))) {
                    listCancelledOrderLines.add(eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
                    eleOrderLine.removeAttribute(KohlsPOCConstant.ACTION);
                }
				Element eleLineTaxes = KohlsXMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);
				List<Element> nlTax = XMLUtil.getElementsByTagName(eleLineTaxes, (KohlsPOCConstant.ELEM_LINE_TAX));
				double totalTaxPerLine = KohlsPOCConstant.ZERO_DBL;
				double totalTaxRatePerLine = KohlsPOCConstant.ZERO_DBL;
				if (!YFCCommon.isVoid(nlTax)) {
					for (Element eleTax : nlTax) {
						String sTax = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.ATTR_TAX);
						String sTaxPercent = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.ATTR_TAX_PERCENT);
						if (YFCCommon.isVoid(sTax)) {
							sTax = "0.0";
						}
						if (YFCCommon.isVoid(sTaxPercent)) {
							sTaxPercent = "0.0";
						}
						totalTaxPerLine = totalTaxPerLine + Double.valueOf(sTax);
						totalTaxRatePerLine = totalTaxRatePerLine + Double.valueOf(sTaxPercent);
						eleLineTaxes.removeChild(eleTax);
					}
					totalTaxPerLine = Math.round(totalTaxPerLine * 1000.0) / 1000.0;
					totalTaxRatePerLine = Math.round(totalTaxRatePerLine * 1000.0) / 1000.0;
					DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					twoDForm.setRoundingMode(RoundingMode.CEILING);
					Element eleTaxNew = XMLUtil.createChild(eleLineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
					XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX,
							twoDForm.format(totalTaxPerLine));
					XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, totalTaxRatePerLine + "");
					eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
					eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
					eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX, twoDForm.format(totalTaxPerLine));
					eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, String.valueOf(totalTaxRatePerLine));
					eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
					eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
					eleLineTaxes.appendChild(eleTaxNew);
				}
				if (log.isDebugEnabled()) {
					log.debug("LineTax consolidated:: " + XMLUtil.getXMLString(inDoc));
				}
			}
		}
		log.endTimer("KohlsCreateStoreOrderPOS::consolidateLineTaxes");
		return inDoc;
	}

    /* This method is added as part of integrated enrollment to capture the customer data using manageAdminAdminForPOS API 
     * 
     * @param env.
     * @param Element.
     * @throws ParserConfigurationException.
     * @throws Exception.
     */

	public void manageAdminAuditForPOS(YFSEnvironment env, Element eleAdminAuditList)
			throws ParserConfigurationException, Exception {
		log.beginTimer("KohlsCreateStoreOrderPOS::manageAdminAuditForPOS -Begin");
		if (YFCLogUtil.isDebugEnabled()) {
			log.debug("Inside KohlsCreateStoreOrderPOS ::manageAdminAuditForPOS :: Input to the method"
					+ SCXmlUtil.getString(eleAdminAuditList));
		}
		Document docmanageAdminAuditOutDoc = null;
		NodeList nlAdminAuditList = eleAdminAuditList.getElementsByTagName(KohlsPOCConstant.ELE_ADMIN_AUDIT);
		if ((!YFCCommon.isVoid(nlAdminAuditList)) && (nlAdminAuditList.getLength() > 0)) {
			for (int i = 0; i < nlAdminAuditList.getLength(); i++) {
				docmanageAdminAuditOutDoc = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_ADMIN_AUDIT_FOR_POS,
						XMLUtil.createDocument((Element) nlAdminAuditList.item(i)));
			}
		}
		if (YFCLogUtil.isDebugEnabled()) {
			log.debug("Inside KohlsCreateStoreOrderPOS ::manageAdminAuditForPOS :: Output to the method"
					+ SCXmlUtil.getString(docmanageAdminAuditOutDoc));
		}
		log.endTimer("KohlsCreateStoreOrderPOS::manageAdminAuditForPOS -End");

	}

    /**
     * This method will create Input and call manageTransactionAuditForPOS, to publish audit information to downstream systems.
     * manageTransactionAuditForPOS input xml :
     * @param inXML
     * @throws Exception
     * @throws ParserConfigurationException
     * @throws RemoteException
     * @throws YFSException
     */
    private static void manageTransactionAuditForPOS(YFSEnvironment env,Document inXML, Document outDocGetOrderList, String strIsVoidDuring) throws Exception {

        Element eleOrder = SCXmlUtil.getChildElement(inXML.getDocumentElement(), "Order");
        Element eleGetOrderListOrder = SCXmlUtil.getXpathElement(outDocGetOrderList.getDocumentElement(), "/OrderList/Order");

        Document mngTransAudForPOSIndoc = SCXmlUtil.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
        Element tranAuditEle = mngTransAudForPOSIndoc.getDocumentElement();

        if (!YFCObject.isVoid(eleOrder)) {

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY)))
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE)))
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, eleOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE));

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE)))
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));

            if (!YFCObject.isVoid(eleOrder.getAttribute(A_MANAGER_ID)))
                tranAuditEle.setAttribute(A_MANAGER_ID, eleOrder.getAttribute(A_MANAGER_ID));

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID)))
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, eleOrder.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID));

            if (!YFCObject.isVoid(eleGetOrderListOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, eleGetOrderListOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));

            if (!YFCObject.isVoid(eleGetOrderListOrder.getAttribute(A_ORIGINIAL_TOTAL_AMOUNT)))
                tranAuditEle.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, eleGetOrderListOrder.getAttribute(A_ORIGINIAL_TOTAL_AMOUNT));

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)))
                tranAuditEle.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO)))
                tranAuditEle.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER, eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));

            //ProcedureId will always be 201
            if (!YFCCommon.isVoid(strIsVoidDuring) && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "voidTransaction");
            } else {
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "createOrder");
            }

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID)))
                tranAuditEle.setAttribute(KohlsPOCConstant.A_TERMINAL_ID, eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO)))
                tranAuditEle.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, eleOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO));

        }
        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("Inside manageTransactionAuditForPOS::: Input to manageTransactionAuditForPOS::"
                    + SCXmlUtil.getString(mngTransAudForPOSIndoc));
        }
        api.invoke(env, KohlsPOCConstant.API_MANAGE_TRANSACTION_AUDIT_FOR_POS, mngTransAudForPOSIndoc);

    }



    /** This method will be used to publish signature captures on payment methods to downstream systems.
     * manageSigCapForPOS :
     * @param eleSigCap
     * @throws Exception
     * @throws RemoteException
     * @throws YFSException
     */
    private static void manageSigCapForPOS(YFSEnvironment env,Element eleSigCap, Element eleOrder) throws Exception {

        Document mngSigCapForPOSIndoc = SCXmlUtil.createDocument(KohlsPOCConstant.ATTR_SIGN_CAP);
        Element mngSigCapForPOSEle = mngSigCapForPOSIndoc.getDocumentElement();

        if (!YFCObject.isVoid(eleOrder) && !YFCObject.isVoid(eleSigCap)) {

            if (!YFCObject.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE)))
                mngSigCapForPOSEle.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));

            mngSigCapForPOSEle.setAttribute(KohlsPOCConstant.ATTR_PARENT_TABLE, KohlsPOCConstant.YFS_PAYMENT);

            if (!YFCObject.isVoid(eleSigCap.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY)))
                mngSigCapForPOSEle.setAttribute(KohlsPOCConstant.ATTR_PARENT_TABLE_KEY, eleSigCap.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY));

            mngSigCapForPOSEle.setAttribute(A_SIGNATURE_DATE_FORMAT, A_3_BYTE_ASCII);

            Element sigCapObjectEle = SCXmlUtil.createChild(mngSigCapForPOSEle, E_SIG_CAP_OBJECT);

            if (!YFCObject.isVoid(eleSigCap)) {
                Element eleInputSigCapObject = (Element) eleSigCap.getElementsByTagName(E_SIG_CAP_OBJECT).item(0);

                if (!YFCObject.isVoid(eleInputSigCapObject.getTextContent()))
                    sigCapObjectEle.setTextContent(eleInputSigCapObject.getTextContent());

                if (!YFCObject.isVoid(eleInputSigCapObject.getAttribute(A_DATA_ENCODING)))
                    sigCapObjectEle.setAttribute(A_DATA_ENCODING, eleInputSigCapObject.getAttribute(A_DATA_ENCODING));
            }
        }
        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("Inside manageSigCapForPOS::: Input to manageSigCapForPOS::"
                    + SCXmlUtil.getString(mngSigCapForPOSIndoc));
        }
        api.invoke(env, API_MANAGE_SIG_CAP_FOR_POS, mngSigCapForPOSIndoc);
    }

    /**
     * This method is used to create Draft Orders for given Store Orders in the Input.
     * @param env
     * @param eleOrder
     */
    private static Document createDraftOrderForSPSOrder(YFSEnvironment env, Element eleOrder, List<String> listCancelledOrderLines) throws Exception {

        if (!YFCObject.isVoid(eleOrder)) {
            eleOrder.setAttribute(A_IS_DRAFT_ORDER, KohlsPOCConstant.YES);
            eleOrder.setAttribute(A_BYPASS_PRICING, KohlsPOCConstant.YES);
            eleOrder.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
        }
        Document outDocCreateDraftOrder = null;
        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("Inside createDraftOrderForSPS::: Input to createDraftOrder::"
                    + SCXmlUtil.getString(eleOrder));
        }
        outDocCreateDraftOrder = api.createOrder(env, XMLUtil.createDocument(eleOrder));
		
		if(!YFCCommon.isVoid(listCancelledOrderLines)) {

            if (!YFCObject.isVoid(outDocCreateDraftOrder)) {
                Document inDoc = SCXmlUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
                Element eleInDoc = inDoc.getDocumentElement();
                Element eleCreateOrderDoc = outDocCreateDraftOrder.getDocumentElement();
                Element eleOrderLines = SCXmlUtil.createChild(eleInDoc, KohlsPOCConstant.ELEM_ORDER_LINES);

                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
                eleInDoc.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);

                for (String strPrimeLineNo : listCancelledOrderLines) {
                    Element eleOrderLine = SCXmlUtil.createChild(eleOrderLines, KohlsPOCConstant.ELEM_ORDER_LINE);
                    eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, strPrimeLineNo);
                    eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO, KohlsPOCConstant.A_SUB_LINE_NO);
                    eleOrderLine.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_CANCEL);
                }

                if (!YFCCommon.isVoid(inDoc)) {
                    api.changeOrder(env, inDoc);
                }
            }
        }
        return outDocCreateDraftOrder;
    }


    /**
     * This method is used to create Draft Orders for given Store Orders in the Input.
     * @param env
     * @param eleCreateOrderDoc
     */
    private static Document confirmDraftOrderForStore(YFSEnvironment env, Element eleCreateOrderDoc) throws Exception {

        Document inDoc = SCXmlUtil.createDocument(E_CONFIRM_DRAFT_ORDER);
        Element eleInDoc = inDoc.getDocumentElement();

        if (!YFCObject.isVoid(eleCreateOrderDoc)) {

            if (!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));

            if (!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));

            if (!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));

            if (!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));

            eleInDoc.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
        }

        Document outDocCreateDraftOrder = null;
        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("Inside confirmDraftOrderForStore::: Input to confirmDraftOrderForStore::"
                    + SCXmlUtil.getString(outDocCreateDraftOrder));
        }
        outDocCreateDraftOrder = api.confirmDraftOrder(env, inDoc);

        return outDocCreateDraftOrder;
    }

    private HashMap<String,Element> getGiftCardLines (Element eleOrder){

        HashMap <String,Element>hmGiftLines = new HashMap ();

        NodeList nlOrderLine = eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);

        if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength()>0){

            int nlOrderLineLen = nlOrderLine.getLength();
            for (int i=0;i<nlOrderLineLen;i++){
                Element eleOrderLine =(Element) nlOrderLine.item(i);
                String sPrimeLineNo= eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                NodeList nlStoredValueLines = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_STORED_VALUE_LINE);
                if (!YFCCommon.isVoid(nlStoredValueLines) && nlStoredValueLines.getLength()>0){
                    Element eleStoreValueLine = (Element)nlStoredValueLines.item(0);
                    hmGiftLines.put(sPrimeLineNo, eleStoreValueLine);
                }
            }
        }
        return hmGiftLines;
    }


    private void callManageStoredValueLineForPOS(YFSEnvironment env,HashMap<String,Element> hmGiftLines,Document outDocGetOrderList,
                                                 String strIsVoidDuring) throws Exception {

        if (YFCLogUtil.isDebugEnabled()) {
            log.debug("Inside callManageStoredValueLineForPOS::: Output of getOrderList::"
                    + SCXmlUtil.getString(outDocGetOrderList));
        }
        Element eleOrder = SCXmlUtil.getXpathElement(outDocGetOrderList.getDocumentElement(), "/OrderList/Order");

        if (!YFCCommon.isVoid(eleOrder)) {
            String sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
            String sOrder = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);

            for (Map.Entry<String, Element> entry : hmGiftLines.entrySet()) {
                String sPrimeLineNo = entry.getKey();
                Element eleStoreValueLine = entry.getValue();
                eleStoreValueLine.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
                eleStoreValueLine.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sOrder);
                Element eleMatchedOrderLine = (Element) XPathUtil.getNode(outDocGetOrderList,
                        "/OrderList/Order/OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNo + "']");
                eleStoreValueLine.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY,
                        eleMatchedOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY));
                Element eleItem = XMLUtil.getChildElement(eleMatchedOrderLine, KohlsPOCConstant.E_ITEM_DETAILS);
                if (!YFCCommon.isVoid(eleItem)) {
                    eleStoreValueLine.setAttribute("ItemKey", eleItem.getAttribute("ItemKey"));
                }
                if (YFCLogUtil.isDebugEnabled()) {
                    log.debug("Inside callManageStoredValueLineForPOS::: Input to manageStoredValueLineForPOS::"
                            + SCXmlUtil.getString(KohlsXMLUtil.getDocumentForElement(eleStoreValueLine)));
                }

                if (!YFCCommon.isVoid(strIsVoidDuring) && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {
                    eleStoreValueLine.setAttribute(KohlsPOCConstant.A_STATUS, "Void");
                }

                api.invoke(env, "manageStoredValueLineForPOS", KohlsXMLUtil.getDocumentForElement(eleStoreValueLine));
            }
        }
    }

    /**
     * This method is used to cancel  Orders for given Store Orders in the Input for Mid Void scenarios.
     * @param env
     * @param eleCreateOrderDoc
     */
    private static void cancelOrderForStore(YFSEnvironment env, Element eleCreateOrderDoc) throws Exception {

        Document inDoc=SCXmlUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleInDoc=inDoc.getDocumentElement();

        if(!YFCObject.isVoid(eleCreateOrderDoc)){
            eleInDoc.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
            eleInDoc.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_CANCEL);

            if(!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));

            if(!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));

            if(!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));

            if(!YFCObject.isVoid(eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY)))
                eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));

            eleInDoc.setAttribute("VoidIndicator", "C");
            eleInDoc.setAttribute("Purpose", "SPS");
        }

        if(!YFCCommon.isVoid(inDoc)) {
            if(log.isDebugEnabled()) {
                log.debug("The input XML to KohlsCreateStoreOrderPOS.cancelOrderForStore - " + SCXmlUtil.getString(inDoc));
            }
            api.invoke(env, KohlsPOCConstant.API_CHANGE_ORDER, inDoc);
        }

    }

    /**
     * This method is used to invoke capturePayment API
     * @param env
     * @throws Exception
     */

    private void invokeVoidChargeTransaction(YFSEnvironment env, Element eleRoot, List<String> hmPaymentKey) throws Exception {
        /* Initialize variables */
        Document docCapturePaymentIn = null;
        NodeList nlChargeTransaction = null;
        Element eleOrder = null;
        Element elePreviousChargeTranDtls = null;
        Element eleChargeTransactionDetails = null;
        Element eleCapturePayment = null;
        Element elePaymentMethods = null;
        int iCount = 0;
        List listChargeTransactionKey = new ArrayList<String>();

        eleOrder = KohlsXMLUtil.getChildElement(eleRoot, KohlsPOCConstant.ELEM_ORDER);

        if (!YFCCommon.isVoid(eleOrder)) {

            /* Prepare Input XML for capturePayment API */
            docCapturePaymentIn = KohlsXMLUtil.createDocument(KohlsXMLLiterals.E_CAPTURE_PAYMENT);
            eleCapturePayment = docCapturePaymentIn.getDocumentElement();
            eleCapturePayment.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
            eleCapturePayment.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
            eleCapturePayment.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
            eleCapturePayment.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
            eleCapturePayment.setAttribute("ProceedOnZeroAmountFailure", "N");

            elePreviousChargeTranDtls = KohlsXMLUtil.createChild(eleCapturePayment, "PreviousChargeTransactionDetails");
            elePaymentMethods = KohlsXMLUtil.createChild(eleCapturePayment, "PaymentMethods");

            /* Retrieve the PaymentMethods */
            eleChargeTransactionDetails = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);

            if (!YFCCommon.isVoid(eleChargeTransactionDetails)) {
                nlChargeTransaction = eleChargeTransactionDetails.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
            }

            if (!YFCCommon.isVoid(nlChargeTransaction)) {
                iCount = nlChargeTransaction.getLength();
            }

            /* Loop through each chargeTransactionDetail */
            for (int i = 0; i < iCount; i++) {
                Element eleTemp = (Element) nlChargeTransaction.item(i);
                String strPaymentkey = eleTemp.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);

                if (!YFCCommon.isVoid(strPaymentkey) && hmPaymentKey.contains(strPaymentkey)) {
                    Element elePayment = KohlsXMLUtil.createChild(elePaymentMethods, KohlsPOCConstant.E_PAYMENT_METHOD);
                    elePayment.setAttribute("PaymentKey", strPaymentkey);
                    elePayment.setAttribute("IsCorrection", "Y");
                    elePayment.setAttribute("Operation", "Suspend");
                    elePayment.setAttribute("RequestedAmount", "0.0");

                    KohlsXMLUtil.appendChild(elePaymentMethods, elePayment);

                    Element eleChargTran = KohlsXMLUtil.createChild(elePreviousChargeTranDtls, "ChargeTransactionDetail");
                    eleChargTran.setAttribute("ChargeTransactionKey", eleTemp.getAttribute("ChargeTransactionKey"));
                    listChargeTransactionKey.add(eleTemp.getAttribute("ChargeTransactionKey"));
                    eleChargTran.setAttribute("Operation", "Void");
                    eleChargTran.setAttribute("PaymentType", SCXmlUtil.getChildElement(eleTemp, "PaymentMethod").getAttribute("PaymentType"));

                    KohlsXMLUtil.appendChild(elePreviousChargeTranDtls, eleChargTran);

                } else {
                    continue;
                }
            }

            KohlsXMLUtil.appendChild(eleCapturePayment, elePreviousChargeTranDtls);
            KohlsXMLUtil.appendChild(eleCapturePayment, elePaymentMethods);

            if (log.isDebugEnabled()) {
                log.debug("The input XML to capturePayment - " + KohlsXMLUtil.getXMLString(docCapturePaymentIn));
            }

                /* Invoke capturePayment API */
            api.invoke(env, KohlsXMLLiterals.API_CAPTURE_PAYMENT, docCapturePaymentIn);

            //invokeExecuteCollectionForCTR(env, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY), listChargeTransactionKey);

        }
    }


    /**
     * This method invokes getChargeTransactionList to verify if the UserExitStatus is 'INVOKED'. If the UserExitStatus
     * is not 'INVOKED', then the executeCollection API is invoked for the Charge Transaction Record.
     * @param env
     * @param strOrderHeaderKey
     */

    public static void invokeExecuteCollectionForCTR(YFSEnvironment env, String strOrderHeaderKey,
                                                     List<String> listChargeTransactionKey) throws Exception {

        log.beginTimer("KohlsMPOCCommonUtil.invokeExecuteCollectionForCTR - Begin Timer ");

        /* Initialize variables*/
        Document docExecuteCollection = null;
        Element eleExecuteCollection = null;

        /* Prepare Input XML to requestCollection API */
        docExecuteCollection = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        eleExecuteCollection = docExecuteCollection.getDocumentElement();
        eleExecuteCollection.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);

        if (log.isDebugEnabled()) {
            log.debug("The input XML to requestCollection API : " + KohlsXMLUtil.getXMLString(
                    docExecuteCollection));
        }
        KOHLSBaseApi.invokeAPI(env,"requestCollection", docExecuteCollection);

        log.endTimer("KohlsMPOCCommonUtil.invokeExecuteCollectionForCTR - End Timer ");

    }

    /**
     * This method invokes manageReceiptDataForPOS API to add the ReceiptData for create order and mid void.
     * @param env
     * @param eleReceiptData
     */
    public static void invokeManageReceiptData(YFSEnvironment env, Element eleReceiptData, Element eleOrderList, String strIsVoidDuring)
            throws Exception {

        log.beginTimer("invokeManageReceiptData - Begin Timer");

        /* Initialize variables */
        Document docInManageReceipt = null;
        Element eleRoot = null;
        Element eleGetOrder = null;

        /* Prepare Input XML For manageReceiptDataForPOS API */
        docInManageReceipt = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELE_RECEIPT_DATA);
        eleRoot = docInManageReceipt.getDocumentElement();
        eleGetOrder = KohlsXMLUtil.getChildElement(eleOrderList, KohlsPOCConstant.ELEM_ORDER);

        if (!YFCCommon.isVoid(eleReceiptData)) {
            eleRoot.setAttribute("AppendReceiptData", KohlsPOCConstant.YES);
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, eleReceiptData.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME));
            eleRoot.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, eleReceiptData.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
            if (!YFCCommon.isVoid(eleReceiptData.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE))) {
                eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleReceiptData.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
            } else {
                eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleGetOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
            }
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, eleReceiptData.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID));
            eleRoot.setAttribute(KohlsPOCConstant.A_TERMINAL_ID, eleReceiptData.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
            //eleRoot.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, eleReceiptData.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
            eleRoot.setAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER, eleReceiptData.getAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER));
            eleRoot.setAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA, eleReceiptData.getAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA));

            if (log.isDebugEnabled()) {
                log.debug("The input XML to invokeManageReceiptData - "
                        + KohlsXMLUtil.getXMLString(docInManageReceipt));
            }
            /* Invoke manageTransactionAuditForPOS API */
            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_RECEIPT_DATA_FOR_POS, docInManageReceipt);
        }

        log.endTimer("invokeManageReceiptData - End Timer");
    }

	/**
	 * This function is used to set properties reference.
	 * 
	 * @param prop
	 * @throws Exception
	 */
	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}

	/**
	 * This function is used to get the value for a property.
	 * 
	 * @param property
	 * @return
	 */
	public String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		return propValue;
	}
}