package com.kohls.poc.api;

import java.util.Properties;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.shared.ycp.YFSContext;

public class KohlsProcessInvoiceAndCTRRecords implements YIFCustomApi {

	/**
	 * This class is responsible for processing the voided charge so that
	 * VoidTransaction S and V balance each other and then invoke a service to
	 * create invoice so that charge for this invoice should have the correct
	 * collection details.
	 * 
	 */

	private static final YFCLogCategory logExecuteCharge = YFCLogCategory
			.instance(KohlsProcessInvoiceAndCTRRecords.class.getName());
	public static final String GET_ORDER_LIST_OMNI_TEMPLATE = "<OrderList><Order OperatorID='' OrderHeaderKey='' PosSequenceNo='' PostVoided='' SellerOrganizationCode=''  TerminalID='' ><Extn ExtnOrigPosSequenceNo='' ExtnSuspendSeqNum=''/><OrderLines><OrderLine PrimeLineNo='' SubLineNo='' OrderedQty='' DeliveryMethod=''><LineOverallTotals/></OrderLine></OrderLines></Order></OrderList>";
	boolean isResolvedHold=false;
	/**
	 * Logic to call execute collection to process the void charge
	 * 
	 * @param env
	 * @param inputDoc
	 */
	public void executeCTRRecords(YFSEnvironment env, Document inputDoc) {
		logExecuteCharge.beginTimer("executeCTRRecords - Begin Timer");
		String orderHeaderKey="";
		try {
			Element eleDoc = inputDoc.getDocumentElement();
			 orderHeaderKey = eleDoc.getAttribute("OrderHeaderKey");
			applyORResolveOmniHold(env, orderHeaderKey, KohlsPOCConstant.HOLD_REMOVED_STATUS);
			((YFSContext) env).commit();
			isResolvedHold=true;
			Document outGetChargeTransaction = callGetChargeTransactionList(env, orderHeaderKey);

			NodeList ndlstChargeTransaction = SCXmlUtil.getXpathNodes(outGetChargeTransaction.getDocumentElement(),
					KohlsPOCConstant.XPATH_CHARGE_TYPE_CHARGE);
			int nodeLength = ndlstChargeTransaction.getLength();
			Element eleChargeTransactionDetail = null;
			if (nodeLength == 1) {
				eleChargeTransactionDetail = (Element) ndlstChargeTransaction.item(0);
			} else if (nodeLength > 1) {
				eleChargeTransactionDetail = (Element) ndlstChargeTransaction.item(nodeLength-1);
			}
			if (!YFCCommon.isVoid(eleChargeTransactionDetail)) {
				String chargeTransactionkey = eleChargeTransactionDetail
						.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY);
				env.setTxnObject("ProcessVoidCharge", "Y");
				Document executeCollectionInput = XMLUtil.createDocument(KohlsPOCConstant.ATTR_EXECUTE_COLLECTION);
				Element eleExecuteCollection = executeCollectionInput.getDocumentElement();
				eleExecuteCollection.setAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY, chargeTransactionkey);
				KOHLSBaseApi.invokeAPI(env, "executeCollection", executeCollectionInput);
				Document requestCollectionInput = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
				Element eleRequestCollection = requestCollectionInput.getDocumentElement();
				eleRequestCollection.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, orderHeaderKey);
				KOHLSBaseApi.invokeAPI(env, "requestCollection", requestCollectionInput);
			}
			((YFSContext) env).commit();
			applyORResolveOmniHold(env, orderHeaderKey, KohlsPOCConstant.SHIPMENT_CREATED_STATUS);
			KOHLSBaseApi.invokeService(env, "KohlsProcessInvoiceRecords", inputDoc);
		} catch (Exception ex) {
			logExecuteCharge.error(ex);
			try {
				if(isResolvedHold)
				{
					applyORResolveOmniHold(env, orderHeaderKey, KohlsPOCConstant.SHIPMENT_CREATED_STATUS);
				}
				KOHLSBaseApi.invokeService(env, "KohlsReprocessInvoiceRecords", inputDoc);
				
			} catch (Exception e) {
				throw new YFCException("Error while  Processing   execption block " + ex);
			}
		}

		logExecuteCharge.endTimer("executeCTRRecords - End Timer");
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * getChargeTransactionList API call for voided charge with VoidTransaction as V
	 * 
	 * @param env
	 * @param orderHeaderKey
	 * @return
	 */
	private Document callGetChargeTransactionList(YFSEnvironment env, String orderHeaderKey) {
		try {
			logExecuteCharge.beginTimer("KohlsVoidChargeTransaction.callGetChargeTransactionList - Begin Timer");
			if (YFCLogUtil.isDebugEnabled()) {
				logExecuteCharge.debug(
						"The input XML to KohlsVoidChargeTransaction.callGetChargeTransactionList -OrderHeaderKey "
								+ orderHeaderKey);
			}
			Document getChargeTransactionListDoc = XMLUtil
					.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
			Element eleChargeTransactionDetail = getChargeTransactionListDoc.getDocumentElement();
			eleChargeTransactionDetail.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			eleChargeTransactionDetail.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE,
					KohlsPOCConstant.CHARGE_TYPE_CHARGE);
			eleChargeTransactionDetail.setAttribute(KohlsXMLLiterals.A_STATUS, KohlsXMLLiterals.ATTR_OPEN);
			eleChargeTransactionDetail.setAttribute(KohlsPOCConstant.ATTR_VOID_TRANSACTION,
					KohlsPOCConstant.STATIC_CONSTANT_VOID);
			Document outChargeTransaction = KOHLSBaseApi.invokeAPI(env,
					KohlsPOCConstant.TEMPLATE_GET_CHARGE_TRANSACTION_LIST,
					KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, getChargeTransactionListDoc);
			logExecuteCharge.endTimer("KohlsVoidChargeTransaction:: callGetChargeTransactionList - End Timer");
			return outChargeTransaction;
		} catch (Exception ex) {
			logExecuteCharge.error(ex);
			throw new YFCException("Error while  calling getChargeTransactionList " + ex);
		}
	}

	/**
	 * Logic to create carry invoices and then create records to post message to POP
	 * queue and order update Q
	 * 
	 * @param env
	 * @param inputDoc
	 */
	public void processInvoiceRecords(YFSEnvironment env, Document inputDoc) {
		logExecuteCharge.beginTimer("processInvoiceRecords - Begin Timer");
		try {
			String orderHeaderKey = inputDoc.getDocumentElement().getAttribute("OrderHeaderKey");
			Document getOrderListInputDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleInput = getOrderListInputDoc.getDocumentElement();

			eleInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);

			String sDoc = GET_ORDER_LIST_OMNI_TEMPLATE;
			Document docGetOrderListTemplate = XMLUtil.getDocument(sDoc);
			Document orderListDocOutput = KOHLSBaseApi.invokeAPI(env, docGetOrderListTemplate, "getOrderList",
					getOrderListInputDoc);
			Element inDoc = (Element) orderListDocOutput.getElementsByTagName("Order").item(0);
			double dblCarryLineTotal = 0;
			double finalLineTotal = 0;
			NodeList orderLineList = inDoc.getElementsByTagName(KohlsConstants.ORDER_LINE);
			Document createOrderInvoice = XMLUtil.createDocument(KohlsConstants.ORDER);
			Element eleOrderInvoice = createOrderInvoice.getDocumentElement();
			eleOrderInvoice.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			eleOrderInvoice.setAttribute(KohlsPOCConstant.A_LIGHT_INVOICE, KohlsPOCConstant.YES);
			eleOrderInvoice.setAttribute(KohlsPOCConstant.A_TRANSACTION_ID,
					KohlsPOCConstant.CREATE_INVOICE_TRANSACTION);
			eleOrderInvoice.setAttribute(KohlsPOCConstant.ATTR_IGNORE_STATUS_CHECK, KohlsPOCConstant.YES);
			Element eleOrderLines = XMLUtil.createChild(eleOrderInvoice, KohlsPOCConstant.ELEM_ORDER_LINES);
			Document orderStatusChange = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_STATUS_CHANGE);
			Element eleOrderStatus = orderStatusChange.getDocumentElement();
			eleOrderStatus.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			eleOrderStatus.setAttribute(KohlsPOCConstant.A_TRANSACTION_ID,
					KohlsPOCConstant.TRANSACTION_POS_CHANGE_ORDER_STATUS);
			Element eleOrderLinesStatus = XMLUtil.createChild(eleOrderStatus, KohlsPOCConstant.ELEM_ORDER_LINES);
			int orderlineLength = orderLineList.getLength();
			Boolean isCarry = false;
			for (int count = 0; count < orderlineLength; count++) {
				Element eleOrderLine = (Element) orderLineList.item(count);
				String primeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
				String subLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO);
				String Qty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
				String deliverMethod = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_DELIVERY_METHOD);
				if (KohlsPOCConstant.ATTR_DELIVERY_TYPE_CARRY.equalsIgnoreCase(deliverMethod)) {
					Element newEleOrderLine = XMLUtil.createChild(eleOrderLines, KohlsConstants.ORDER_LINE);
					newEleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, primeLineNo);
					newEleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO, subLineNo);
					newEleOrderLine.setAttribute(KohlsPOCConstant.A_QUANTITY, Qty);
					Element newEleOrderLineStatus = XMLUtil.createChild(eleOrderLinesStatus, KohlsConstants.ORDER_LINE);
					newEleOrderLineStatus.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, primeLineNo);
					newEleOrderLineStatus.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO, subLineNo);
					newEleOrderLineStatus.setAttribute(KohlsPOCConstant.E_BASE_DROP_STATUS,
							KohlsPOCConstant.STORE_ORDER_INVOICED_STATUS);
					newEleOrderLineStatus.setAttribute(KohlsPOCConstant.ATTR_CHANGE_FOR_ALL_AVAILABLE_QTY,
							KohlsPOCConstant.YES);
					Element eleLineOverallTotals = (Element) eleOrderLine
							.getElementsByTagName(KohlsPOCConstant.E_LINE_OVERALL_TOTALS).item(0);
					dblCarryLineTotal = Double
							.parseDouble(eleLineOverallTotals.getAttribute(KohlsXMLLiterals.A_LINE_TOTAL));
					finalLineTotal = finalLineTotal + dblCarryLineTotal;
					isCarry = true;
				}
			}

			if (isCarry) {
				KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CREATE_ORDER_INVOICE, createOrderInvoice);
				KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER_STATUS, orderStatusChange);
			}
			publishMessageForPOP(env, inputDoc);
			publishMessageForOrderUpdate(env, inputDoc);
		} catch (Exception ex) {
			logExecuteCharge.error("Exception while processing Invoice" + ex);
			throw new YFCException("Error while  processing  Invoice " + ex);
		}
		logExecuteCharge.endTimer("processInvoiceRecords - End Timer");
	}

	/**
	 * Logic to create and resolve OMNI and POP hold
	 * 
	 * @param env
	 * @param orderHeaderKey
	 * @param status
	 */
	private void applyORResolveOmniHold(YFSEnvironment env, String orderHeaderKey, String status) {
		try {
			logExecuteCharge.beginTimer("KohlsVoidChargeTransaction.applyOmniHold - Begin Timer");
			Document changeOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			Element eleChangeOrder = changeOrder.getDocumentElement();
			eleChangeOrder.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			Element elelOrderHoldTypes = XMLUtil.createChild(eleChangeOrder, KohlsXMLLiterals.E_ORDER_HOLD_TYPES);
			Element elelOrderHoldType = XMLUtil.createChild(elelOrderHoldTypes, KohlsXMLLiterals.E_ORDER_HOLD_TYPE);
			Element elelPOPHoldType = XMLUtil.createChild(elelOrderHoldTypes, KohlsXMLLiterals.E_ORDER_HOLD_TYPE);
			elelOrderHoldType.setAttribute(KohlsXMLLiterals.A_HOLD_TYPE, "OMNI_HOLD");
			elelOrderHoldType.setAttribute(KohlsXMLLiterals.A_REASON, "Its an Omni Order");
			elelOrderHoldType.setAttribute(KohlsXMLLiterals.E_STATUS, status);
			elelPOPHoldType.setAttribute(KohlsXMLLiterals.A_HOLD_TYPE, "POP_HOLD");
			elelPOPHoldType.setAttribute(KohlsXMLLiterals.A_REASON, "Its an POP hold Order");
			elelPOPHoldType.setAttribute(KohlsXMLLiterals.E_STATUS, status);
			KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, changeOrder);
		} catch (Exception ex) {
			logExecuteCharge.error(ex);
			throw new YFCException("Error while  Applying/Resolving  hold " + ex);
		}
		logExecuteCharge.endTimer("KohlsVoidChargeTransaction:: applyOmniHold - End Timer");
	}

	/**
	 * Post message to POP queue
	 * 
	 * @param env
	 * @param inDocForPOP
	 * @throws Exception
	 */
	private void publishMessageForPOP(YFSEnvironment env, Document inDocForPOP) throws Exception {
		logExecuteCharge.beginTimer("PostOrderForPOP - Begin Timer");
		if (logExecuteCharge.isDebugEnabled()) {
			logExecuteCharge.debug("The input XML to postOrderForPOP - " + KohlsXMLUtil.getXMLString(inDocForPOP));
		}

		try {
			KOHLSBaseApi.invokeService(env, KohlsPOCConstant.A_SERVICE_POP, inDocForPOP);
		} catch (Exception ex) {
			logExecuteCharge
					.debug("Inside catch block XML to postOrderForPOP. XML would be posted to KohlsReprocess table "
							+ KohlsXMLUtil.getXMLString(inDocForPOP));
			KOHLSBaseApi.invokeService(env, KohlsPOCConstant.A_SERVICE_REPROCESS_POP, inDocForPOP);
		}

		logExecuteCharge.endTimer("PostOrderForPOP - End Timer");
	}

	/**
	 * Post messages to order update queue
	 * 
	 * @param env
	 * @param inDocForOrderUpdate
	 * @throws Exception
	 */
	private void publishMessageForOrderUpdate(YFSEnvironment env, Document inDocForOrderUpdate) throws Exception {
		logExecuteCharge.beginTimer("publishMessageForOrderUpdate - Begin Timer");
		if (logExecuteCharge.isDebugEnabled()) {
			logExecuteCharge.debug("The input XML to publishMessageForOrderUpdate - "
					+ KohlsXMLUtil.getXMLString(inDocForOrderUpdate));
		}

		try {
			KOHLSBaseApi.invokeService(env, "KohlsPublishOrderUpdateToMQ", inDocForOrderUpdate);
		} catch (Exception ex) {
			logExecuteCharge
					.debug("Inside catch block XML to postOrderForPOP. XML would be posted to KohlsReprocess table "
							+ KohlsXMLUtil.getXMLString(inDocForOrderUpdate));
			KOHLSBaseApi.invokeService(env, "KohlsReprocessRequestToMQ", inDocForOrderUpdate);
		}

		logExecuteCharge.endTimer("publishMessageForOrderUpdate - End Timer");
	}
}
