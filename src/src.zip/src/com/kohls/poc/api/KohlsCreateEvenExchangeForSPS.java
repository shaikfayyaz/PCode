package com.kohls.poc.api;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * This class is called for creating EE in OMS.
 *
 * @author YANTRIKS
 */
public class KohlsCreateEvenExchangeForSPS {

    private static final YFCLogCategory log = YFCLogCategory.instance(KohlsCreateEvenExchangeForSPS.class.getName());

    /**
     * This method is used to invoke calling methods to createDraftOrder for
     * return,create Draft sale Order and update Return Order to Sale Order and
     * Confirm return and Sale Order and call ManageReceiptDataForPOS.
     *
     * @param env
     * @param inXML
     * @throws Exception
     */
    public void evenExchange(YFSEnvironment env, Document inXML) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.evenExchange");
        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.evenExchange - " + KohlsXMLUtil.getXMLString(inXML));
        }

		/* Initialize Variables */
        Document docCreateReturnOrder = null;
        Document docCreateSalesOrder = null;
        Document docCreateSalesOrderOut = null;
        Document docGetOrgSaleDetails = null;
        Element eleOrderDetails = null;
        Element eleExtn = null;
        String strIsVoidDuring = null;
        String strOrgSaleReceiptID = null;

        try {

            // Setting the SourceSystem as 'SPS'
            env.setTxnObject(KohlsPOCConstant.SOURCE_SYSTEM, "SPS");

            Element eleOrderRoot = inXML.getDocumentElement();
            NodeList nlOrders = eleOrderRoot.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);

			/* if no order is present in the input xml then throw error */
            if (YFCCommon.isVoid(nlOrders)) {
                YFSException e = new YFSException();
                e.setErrorDescription(KohlsPOCConstant.POC_NO_RECORD_FOUND_ERROR_CODE);
                throw e;
            } else {
                /* loop through the Order Elements in the input and retrieve the Sales and Return Order */
                for (int i = 0; i < nlOrders.getLength(); i++) {
                    Element eleOrder = (Element) nlOrders.item(i);
                    String strDocType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
                    if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equals(strDocType)) {
                        docCreateReturnOrder = KohlsXMLUtil.getDocumentForElement(eleOrder);
                        eleExtn = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
                    } else if (KohlsPOCConstant.SO_DOCUMENT_TYPE.equals(strDocType)) {
                        docCreateSalesOrder = KohlsXMLUtil.getDocumentForElement(eleOrder);
                    } else {
                        YFSException e = new YFSException();
                        e.setErrorDescription("Invalid Order XML");
                    }
                }
            }

			/* Validate if the Even Exchange is Mid Void or Receipted EE*/
            if (!YFCCommon.isVoid(eleExtn)) {
                strIsVoidDuring = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
                strOrgSaleReceiptID = eleExtn.getAttribute("ExtnOriginalSaleReceiptID");
            }

			/* Invoke getOrderList API to fetch the Original Sales Order Details */
            if (!YFCCommon.isVoid(strOrgSaleReceiptID)) {
                docGetOrgSaleDetails = invokeGetOrderList(env, strOrgSaleReceiptID);
            }
            if (!YFCCommon.isVoid(docGetOrgSaleDetails)) {
                eleOrderDetails = KohlsXMLUtil.getChildElement(docGetOrgSaleDetails.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);
            }
            /* Create the return Order */
            Document docCreateReturnOrderOut = createDraftOrderForEE(env, docCreateReturnOrder, eleOrderDetails, strIsVoidDuring);
            Element eleReturnOrder = docCreateReturnOrderOut.getDocumentElement();

			/* Create the Sales order */
            if (!YFCCommon.isVoid(docCreateSalesOrder) && !YFCCommon.isVoid(docCreateReturnOrderOut)) {
                docCreateSalesOrderOut = createDraftOrderForEE(env, docCreateSalesOrder, eleReturnOrder, strIsVoidDuring);
            }

			/* Prepare input and invoke manageTransactionAuditForPOS API */
            invokeManageTransAudit(env, docCreateReturnOrder,
                    eleReturnOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO), strIsVoidDuring);

			/* Confirm the sales draft order */
            if (!YFCCommon.isVoid(docCreateSalesOrder)) {
                confirmOrderForEE(env, docCreateSalesOrderOut);
            }

			/* Confirm the return draft order */
            confirmOrderForEE(env, docCreateReturnOrderOut);

            /* Create invoice for the return order */
            createOrderInvoiceForReturn(env, docCreateReturnOrderOut);

			/* Prepare input and invoke manageReceiptDataForPOS API */
            invokeManageReceiptDataForPOS(env, KohlsXMLUtil.getChildElement(eleOrderRoot, KohlsPOCConstant.ELE_RECEIPT_DATA),
                    docCreateReturnOrder);

			/* Invoke changeOrder to cancel the order for Mid Void scenarios */
            if (!YFCCommon.isVoid(strIsVoidDuring) && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {

                if (!YFCCommon.isVoid(docCreateSalesOrderOut)) {
                    cancelOrderForStore(env, docCreateSalesOrderOut);
                }
                cancelOrderForStore(env, docCreateReturnOrderOut);
            }
        } catch (Exception e) {
            log.error(e);
            throw e;
        }

        log.endTimer("KohlsCreateEvenExchangeForSPS.evenExchange");
    }

    /**
     * This method is used to create a draft sale/return Order for even exchange.
     *
     * @param env
     * @param inDoc
     * @param eleOrderDetails
     * @param strIsVoidDuring
     * @return
     * @throws Exception
     */
    private Document createDraftOrderForEE(YFSEnvironment env, Document inDoc, Element eleOrderDetails, String strIsVoidDuring) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.createDraftOrderForEE");

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.createDraftOrderForEE - " + KohlsXMLUtil.getXMLString(inDoc));
        }

		/* Initialize Variables */
        Document docCreateDraftOrderTemplate = KohlsXMLUtil.getDocument("<Order OrderNo='' SellerOrganizationCode='' OrderHeaderKey='' EnterpriseCode='' DocumentType=''>" +
                "<OrderLines><OrderLine OrderLineKey='' PrimeLineNo='' OrderedQty=''><Item ItemID=''/></OrderLine></OrderLines></Order>");
        Element eleRootOrder = null;
        String strDocumentType = null;

        /* Get the document Type */
        if (!YFCCommon.isVoid(inDoc)) {
            eleRootOrder = inDoc.getDocumentElement();
            strDocumentType = eleRootOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
        }

        /* Verify whether the order has Original saleOrder if yes then add SO details to return order like OHK/OLK */
        if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equals(strDocumentType) && (!YFCCommon.isVoid(eleOrderDetails))
                && !(KohlsPOCConstant.YES.equals(strIsVoidDuring))) {
            inDoc = addSaleOrderDetail(inDoc, eleOrderDetails, true);
        }

        if (KohlsPOCConstant.SO_DOCUMENT_TYPE.equals(strDocumentType) && !YFCCommon.isVoid(eleOrderDetails)) {
            eleRootOrder.setAttribute(KohlsPOCConstant.A_RETURN_ORDER_HEADER_KEY_FOR_EXCHANGE,
                    eleOrderDetails.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
            inDoc = addSaleOrderDetail(inDoc, eleOrderDetails, false);
        }

			/* Invoke createOrder API to create the return/sales order */
        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.createDraftOrderForEE - " + KohlsXMLUtil.getXMLString(inDoc));
        }

        Document docCreateDraftOrderOut = KOHLSBaseApi.invokeAPI(env, docCreateDraftOrderTemplate, KohlsPOCConstant.API_CREATE_ORDER, inDoc);

        if (log.isDebugEnabled()) {
            log.debug("The output XML from KohlsCreateEvenExchangeForSPS.createDraftOrderForEE - "
                    + KohlsXMLUtil.getXMLString(docCreateDraftOrderOut));
        }

        log.endTimer("KohlsCreateEvenExchangeForSPS.createDraftOrderForEE");
        return docCreateDraftOrderOut;
    }

    /**
     * This method updates the original saleOrder details to return order like
     * orderHeaderKey and OrderLineKey by calling the getOrderList api with OrderNo
     * of OriginalSaleOrder.
     *
     * @param docCreateOrder
     * @param eleGetOrder
     * @param bIsReturnOrder
     * @return
     * @throws Exception
     */
    private Document addSaleOrderDetail(Document docCreateOrder, Element eleGetOrder, boolean bIsReturnOrder) {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.addSaleOrderDetail");

		/* Initialize variables */
        Map<String, String> hmSOOrder = new LinkedHashMap<>();
        Map<String, String> hmProcessedSOOrder = new LinkedHashMap<>();
        Element eleCreateOrder = docCreateOrder.getDocumentElement();

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.addSaleOrderDetail - "
                    + KohlsXMLUtil.getXMLString(docCreateOrder));
        }

		/* Retrieve the OrderHeaderKey for Original Sales Order */
        String strOrderHeaderKey = eleGetOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        if (bIsReturnOrder) {
            eleCreateOrder.setAttribute(KohlsPOCConstant.A_POS_ORIG_SALES_ORDER_NO,
                    eleGetOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
        }

        NodeList nlOrderLinesList = eleGetOrder.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
        if (!YFCCommon.isVoid(nlOrderLinesList)) {
            int iCount = nlOrderLinesList.getLength();

			/* Loop through each order lines of original sale order API and insert into  map(OLK,ItemID) */
            for (int i = 0; i < iCount; i++) {
                Element eleSOTemp = (Element) nlOrderLinesList.item(i);
                Element eleSOItem = KohlsXMLUtil.getChildElement(eleSOTemp, KohlsPOCConstant.ELEM_ITEM);
                String strOrderedQty = eleSOTemp.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
                if (!YFCCommon.isVoid(strOrderedQty) && 0 < Double.parseDouble(strOrderedQty)) {
                    if (!KohlsPOCConstant.YES.equals(eleSOTemp.getAttribute("HasDerivedChild"))) {
                        hmSOOrder.put(eleSOTemp.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY),
                                eleSOItem.getAttribute(KohlsPOCConstant.ATTR_ITEMID));
                        if(!bIsReturnOrder) {
                            hmProcessedSOOrder.put(eleSOTemp.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY),
                                    eleSOTemp.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
                        }
                    } else if (bIsReturnOrder) {
                        hmProcessedSOOrder.put(eleSOTemp.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY),
                                eleSOItem.getAttribute(KohlsPOCConstant.ATTR_ITEMID));
                    }
                }
            }
        }

		/* Loop through the return order and stamp the sale order details */
        if (!YFCCommon.isVoid(docCreateOrder)) {
            NodeList nlCreateOLinesList = docCreateOrder.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);

            if (!YFCCommon.isVoid(nlCreateOLinesList)) {
                /* Loop through each order lines in getOrderList API of Return Order */
                for (int j = 0; j < nlCreateOLinesList.getLength(); j++) {
                    Element eleROTemp = (Element) nlCreateOLinesList.item(j);
                    String strROItemID = KohlsXMLUtil.getChildElement(eleROTemp, KohlsPOCConstant.E_ITEM).getAttribute(
                            KohlsPOCConstant.A_ITEM_ID);
                    String strPrimeLineNo = eleROTemp.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

					/* Update OHK and OLK for respective ItemID to the input xml */
                    if (hmSOOrder.containsValue(strROItemID)) {
                        for (String obj : hmSOOrder.keySet()) {
                            if(strROItemID.equals(hmSOOrder.get(obj))) {
                                if (bIsReturnOrder) {
                                    Element eleDerivedFrom = KohlsXMLUtil.createChild(eleROTemp, "DerivedFrom");
                                    eleDerivedFrom.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
                                    eleDerivedFrom.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY, String.valueOf(obj));
                                } else {
                                    Element eleCustomAttribute = KohlsXMLUtil.getChildElement(eleROTemp,
                                            KohlsPOCConstant.CUST_ATTRIBUTES);
                                    Element eleExtn = KohlsXMLUtil.getChildElement(eleROTemp,
                                            KohlsPOCConstant.E_EXTN);
                                    eleCustomAttribute.setAttribute(KohlsPOCConstant.TEXT2, String.valueOf(obj));
                                    eleExtn.setAttribute("ExtnReturnItemPairLineKey", String.valueOf(obj));
                                }
                                hmSOOrder.remove(obj);
                                break;
                            }
                        }
                    } else if((!bIsReturnOrder && hmProcessedSOOrder.containsValue(strPrimeLineNo))) {
                        for (String obj : hmProcessedSOOrder.keySet()) {
                            if (strPrimeLineNo.equals(hmProcessedSOOrder.get(obj))) {
                                Element eleCustomAttribute = KohlsXMLUtil.getChildElement(eleROTemp,
                                        KohlsPOCConstant.CUST_ATTRIBUTES);
                                Element eleExtn = KohlsXMLUtil.getChildElement(eleROTemp,
                                        KohlsPOCConstant.E_EXTN);
                                eleCustomAttribute.setAttribute(KohlsPOCConstant.TEXT2, String.valueOf(obj));
                                eleExtn.setAttribute("ExtnReturnItemPairLineKey", String.valueOf(obj));
                                hmProcessedSOOrder.remove(obj);
                                break;
                            }
                        }
                    } else if (bIsReturnOrder && hmProcessedSOOrder.containsValue(strROItemID)) {
                        for (String obj : hmProcessedSOOrder.keySet()) {
                            if(strROItemID.equals(hmProcessedSOOrder.get(obj))) {
                                eleROTemp.setAttribute(KohlsPOCConstant.A_DERIVED_FRM_ORDER_HDR_KEY, strOrderHeaderKey);
                                eleROTemp.setAttribute(KohlsPOCConstant.A_DERIVED_FROM_ORDER_LINE_KEY, String.valueOf(obj));
                                hmProcessedSOOrder.remove(obj);
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("The output XML from KohlsCreateEvenExchangeForSPS.addSaleOrderDetail - "
                    + KohlsXMLUtil.getXMLString(docCreateOrder));
        }
        log.endTimer("KohlsCreateEvenExchangeForSPS.addSaleOrderDetail");

        return docCreateOrder;
    }

    /**
     * This method is used to confirm the Order for EvenExchange.
     *
     * @param env
     * @param inDoc
     * @throws Exception
     */
    private void confirmOrderForEE(YFSEnvironment env, Document inDoc) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.confirmOrderForEE");

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.confirmOrderForEE - "
                    + KohlsXMLUtil.getXMLString(inDoc));
        }

		/* Prepare the input XML to confirmDraftOrder API */
        Document docConfirmDraftOrder = KohlsXMLUtil.createDocument("ConfirmDraftOrder");
        Element eleConfirmDraftOrder = docConfirmDraftOrder.getDocumentElement();
        Element eleInRoot = inDoc.getDocumentElement();

        if (!YFCCommon.isVoid(eleInRoot)) {

            eleConfirmDraftOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleInRoot.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
            eleConfirmDraftOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
                    eleInRoot.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
            eleConfirmDraftOrder.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
                    eleInRoot.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
            eleConfirmDraftOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
                    eleInRoot.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
            eleConfirmDraftOrder.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
        }

        if (log.isDebugEnabled()) {
            log.debug("The input XML to confirmDraftOrder API - " + KohlsXMLUtil.getXMLString(docConfirmDraftOrder));
        }

        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CONFIRM_DRAFT_ORDER, docConfirmDraftOrder);

        log.endTimer("KohlsCreateEvenExchangeForSPS.confirmOrderForEE");
    }

    /**
     * This method is used to is used to create invoice for Return Order.
     *
     * @param env
     * @param inDoc
     * @throws Exception
     */
    private void createOrderInvoiceForReturn(YFSEnvironment env, Document inDoc) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.createOrderInvoice");

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.createOrderInvoiceForReturn - "
                    + KohlsXMLUtil.getXMLString(inDoc));
        }

        // setting env object to skip the Repricing UE call.
        env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.TRUE);

        /* Prepare the input XML to confirmDraftOrder API */
        Document docProcessReturnOrder = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleProcessReturnOrder = docProcessReturnOrder.getDocumentElement();
        Element eleInRoot = inDoc.getDocumentElement();

        if (!YFCCommon.isVoid(eleInRoot)) {

            eleProcessReturnOrder.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE,
                    eleInRoot.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));
            eleProcessReturnOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
                    eleInRoot.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
            eleProcessReturnOrder.setAttribute(KohlsPOCConstant.A_TRANSACTION_ID, "POS_RETURN_INVOICE.0003.ex");
        }

        if (log.isDebugEnabled()) {
            log.debug("The input XML to createOrderInvoice API - " + KohlsXMLUtil.getXMLString(docProcessReturnOrder));
        }

        KOHLSBaseApi.invokeAPI(env, "createOrderInvoice", docProcessReturnOrder);

        log.endTimer("KohlsCreateEvenExchangeForSPS.createOrderInvoice");
    }

    /**
     * This method will create Input and call manageTransactionAuditForPOS, to
     * publish audit information to downstream systems.
     *
     * @param env
     * @param docReturnOrder
     * @param strOrderNo
     * @param strIsVoidDuring
     * @throws YFSException
     */
    private void invokeManageTransAudit(YFSEnvironment env, Document docReturnOrder, String strOrderNo,
                                        String strIsVoidDuring) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.invokeManageTransAudit");

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.invokeManageTransAudit - "
                    + KohlsXMLUtil.getXMLString(docReturnOrder));
        }

		/* Prepare input xml to manageTransactionAuditForPOS */
        Document docInManageTranAudit = KohlsXMLUtil.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
        Element eleRoot = docInManageTranAudit.getDocumentElement();
        Element eleReturnOrder = docReturnOrder.getDocumentElement();

        eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
        eleRoot.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
        eleRoot.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
        eleRoot.setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
        eleRoot.setAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO));

        if (!YFCCommon.isVoid(strIsVoidDuring) && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "voidTransaction");
        } else {
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "createOrder");
        }

        eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, strOrderNo);
        eleRoot.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, KohlsPOCConstant.ZERO);
        eleRoot.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
        eleRoot.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER,
                eleReturnOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));
        eleRoot.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
                eleReturnOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
        eleRoot.setAttribute(KohlsPOCConstant.A_IS_EXCHANGE_ORDER, KohlsPOCConstant.YES);

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.invokeManageTransAudit - "
                    + KohlsXMLUtil.getXMLString(docInManageTranAudit));
        }

        /* Invoke manageTransactionAuditForPOS API */
        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_TRANSACTION_AUDIT_FOR_POS, docInManageTranAudit);

        log.endTimer("KohlsCreateEvenExchangeForSPS.invokeManageTransAudit");
    }

    /**
     * This method is used to cancel Orders for given Store Orders in the Input for
     * Mid Void scenarios.
     *
     * @param env
     * @param outCreateOrder
     * @throws Exception
     */
    private void cancelOrderForStore(YFSEnvironment env, Document outCreateOrder) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.cancelOrderForStore");
        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.cancelOrderForStore - "
                    + KohlsXMLUtil.getXMLString(outCreateOrder));
        }

		/* Prepare input XML to changeOrder API */
        Document inDoc = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleInDoc = inDoc.getDocumentElement();
        Element eleCreateOrderDoc = outCreateOrder.getDocumentElement();

        if (!YFCCommon.isVoid(eleCreateOrderDoc)) {
            eleInDoc.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
            eleInDoc.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_CANCEL);
            eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
                    eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
            eleInDoc.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
                    eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
            eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
                    eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
            eleInDoc.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
                    eleCreateOrderDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));

            eleInDoc.setAttribute("SystemInitiatedVoid", KohlsPOCConstant.BLANK);
            eleInDoc.setAttribute("VoidIndicator", "C");
            eleInDoc.setAttribute("Purpose", "SPS");
            Element eleExtn = KohlsXMLUtil.createChild(eleInDoc, KohlsPOCConstant.E_EXTN);
            eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_IS_VOID_DURING, KohlsPOCConstant.YES);
        }
        if (!YFCCommon.isVoid(inDoc)) {
            if (log.isDebugEnabled()) {
                log.debug("The input XML to KohlsCreateEvenExchangeForSPS.changeOrder - "
                        + KohlsXMLUtil.getXMLString(inDoc));
            }
            /* Invoke changeOrder API */
            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, inDoc);

        }

        log.endTimer("KohlsCreateEvenExchangeForSPS.cancelOrderForStore");
    }

    /**
     * This method is a common method to invoke getOrderList API based on the Receipt ID
     *
     * @param env
     * @param strOrgSaleReceiptID
     * @return
     * @throws Exception
     */
    private Document invokeGetOrderList(YFSEnvironment env, String strOrgSaleReceiptID) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.invokeGetOrderList");

		/* Prepare the input XML for getOrderList */
        Document docGetOrderListIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleGetOrder = docGetOrderListIn.getDocumentElement();
        eleGetOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.SO_DOCUMENT_TYPE);
        eleGetOrder.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.KOHLS_RETAIL);
        Element eleExtn = KohlsXMLUtil.createChild(eleGetOrder, KohlsPOCConstant.A_EXTN);
        eleExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID, strOrgSaleReceiptID);
        Element eleOrderBy = KohlsXMLUtil.createChild(docGetOrderListIn.getDocumentElement(), KohlsPOCConstant.E_ORDER_BY);
        Element eleAttribute = KohlsXMLUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
        eleAttribute.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
        eleAttribute.setAttribute("Desc", KohlsPOCConstant.NO);

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.getOrderList - " + KohlsXMLUtil.getXMLString(docGetOrderListIn));
        }

        Document docGetOrderListTemplate = KohlsXMLUtil
                .getDocument("<OrderList><Order OrderNo='' OrderHeaderKey=''>"
                        + "<OrderLines><OrderLine OrderLineKey='' PrimeLineNo='' HasDerivedChild='' OrderedQty=''>" +
                        "<Item ItemID=''/></OrderLine></OrderLines></Order></OrderList>");
        Document docGetOrderListOut = KOHLSBaseApi.invokeAPI(env, docGetOrderListTemplate, KohlsPOCConstant.API_GET_ORDER_LIST, docGetOrderListIn);

        if (log.isDebugEnabled()) {
            log.debug("The output XML to KohlsCreateEvenExchangeForSPS.getOrderList - " + KohlsXMLUtil.getXMLString(docGetOrderListOut));
        }
        log.endTimer("KohlsCreateEvenExchangeForSPS.invokeGetOrderList");

        return docGetOrderListOut;
    }

    /**
     * This method is used to update the receipt data for the respective order
     *
     * @param env
     * @param eleManageReceipt
     * @param docCreateReturnOrder
     * @throws Exception
     */
    private void invokeManageReceiptDataForPOS(YFSEnvironment env, Element eleManageReceipt,
                                               Document docCreateReturnOrder) throws Exception {

        log.beginTimer("KohlsCreateEvenExchangeForSPS.invokeManageReceiptData");

        if (log.isDebugEnabled()) {
            log.debug("The input XML to KohlsCreateEvenExchangeForSPS.invokeManageReceiptDataForPOS - "
                    + KohlsXMLUtil.getElementXMLString(eleManageReceipt));
        }

		/* Prepare Input XML For manageReceiptDataForPOS API */
        Document docInManageReceipt = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELE_RECEIPT_DATA);
        Element eleRoot = docInManageReceipt.getDocumentElement();

        if (!YFCCommon.isVoid(eleManageReceipt)) {
            eleRoot.setAttribute(KohlsPOCConstant.A_APPEND_RECEIPT_DATA, KohlsPOCConstant.YES);
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME,
                    eleManageReceipt.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME));
            if (!YFCCommon.isVoid(eleManageReceipt.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE))) {
                eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
                        eleManageReceipt.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
            } else {
                eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, docCreateReturnOrder.getDocumentElement()
                        .getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
            }
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,
                    eleManageReceipt.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID));
            eleRoot.setAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER,
                    eleManageReceipt.getAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER));
            eleRoot.setAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA,
                    eleManageReceipt.getAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA));
            eleRoot.setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
                    eleManageReceipt.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
            eleRoot.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
                    eleManageReceipt.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));

            if (log.isDebugEnabled()) {
                log.debug("The input XML to manageReceiptDataForPOS - "
                        + KohlsXMLUtil.getXMLString(docInManageReceipt));
            }

			/* Invoke manageReceiptDataForPOS API */
            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_RECEIPT_DATA_FOR_POS, docInManageReceipt);

        }

        log.endTimer("KohlsCreateEvenExchangeForSPS.invokeManageReceiptData");
    }
}