package com.kohls.poc.api;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.custom.util.XPathUtil;
import com.ibm.icu.util.Calendar;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsPoCMathsUtil;
import com.kohls.common.util.KohlsPoCXPathUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**************************************************************************
 * File : KohlsPoCGetOrderDetailForRSOffline.java Author : RajeshG Created : Mar 05 2017 Modified :
 * Mar 05 2017 Version : 1.0
 ***************************************************************************** 
 * ***************************************************************************
 * Copyright @ 2016. This document is in copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Java component is implemented as part of MAD-378
 * 
 * @author Rajesh G
 * @version 1.0
 *****************************************************************************/

public class KohlsPoCGetOrderDetailForRSOffline extends KOHLSBaseApi {

  

	private Properties props;
	
	private static YFCLogCategory logger;
	
	static {
		logger = YFCLogCategory.instance(KohlsPoCGetOrderDetailForRSOffline.class
				.getName());
	}

	/**
	 * This method will be called whenever we need getOrderDetail
	 * output similating the RS output
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws Exception
	 */
	public   Document getOrderDetailsForRSOffline(YFSEnvironment env,Document inDoc,boolean checkDate)  throws Exception {
		
		logger.beginTimer("Start KohlsPoCGetOrderDetailForRSOffline.getOrderDetailsForRSOffline");
		if(null == inDoc){ 
  		   logger.debug("KohlsPoCGetOrderDetailForRSOffline.getOrderDetailsForRSOffline InDoc--->"+"ReceiveD null as input Doc");  		
  		   return simulateTransactionNotFound(inDoc);
		 }
		 logger.debug("KohlsPoCGetOrderDetailForRSOffline.getOrderDetailsForRSOffline InDoc--->"+XMLUtil.getXMLString(inDoc));
		
		
		 Document orderDetailsOutputDoc = null;
		 Document orderListOutputDoc = null;
        
        Document inputDocForGetOrderList = prepareInputDocForGetOrderList(inDoc,env);
        
        
//        
//        File fXmlFile = new File("getOrderDetailsForRSOfflinePSATemplate.xml");
//        DocumentBuilderFactory dbFactory = DocumentBuilderFactory
//                .newInstance();
//        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
//        Document  tem = dBuilder.parse(fXmlFile);
//      
//        orderListOutputDoc = KohlsCommonUtil.invokeAPI(env,tem, KohlsConstant.API_GET_ORDER_LIST, inputDocForGetOrderList);
        
	KohlsPoCCommonAPIUtil.setQueryTimeOut(env, inputDocForGetOrderList.getDocumentElement(), false);
        orderListOutputDoc = KohlsCommonUtil.invokeAPI(env,KohlsXMLLiterals.GET_ORDERLIIST_FOR_RSOFFLINE, KohlsConstant.API_GET_ORDER_LIST, inputDocForGetOrderList);
        
        Element orderEle = null;
        
        if( null != orderListOutputDoc){
          
          orderEle =  KohlsPoCXPathUtil.getElementByXPath(orderListOutputDoc, "/OrderList/Order");
          
          if( null == orderEle){
            return simulateTransactionNotFound(inDoc);
          } else {
                // CPE-2472 changes start
                String status = orderEle.getAttribute(KohlsPOCConstant.A_STATUS);
                logger.debug("The status of the order is  :" + status);
                if (KohlsPOCConstant.A_SYNCHED.equals(status)) {
                    logger.debug("Order is synched to corp   :");
                    return simulateTransactionNotFound(inDoc);
                }
                // CPE-2472 end
          }
        }else{
                    
          return simulateTransactionNotFound(inDoc);
        }
        
        orderDetailsOutputDoc = XMLUtil.getDocument(XMLUtil.getElementXMLString(orderEle));
        
               
        boolean isPSApprovedWithReceiptClean = setPSApprovedWithReceiptClean(orderDetailsOutputDoc,checkDate);
        
        orderDetailsOutputDoc = simulateRSResponse(isPSApprovedWithReceiptClean, orderDetailsOutputDoc);
		
      //Method to update extn attributes at Order level and calling change Order
        invokeChangeOrderExtn(env,orderDetailsOutputDoc);
		
		logger.endTimer("KohlsPoCGetOrderDetailForRSOffline.getOrderDetailsForRSOffline");

		return orderDetailsOutputDoc;

	}

	/**
	   * Create By TKMACJT * 
	   * @param inXML
	   * @return
	 * @throws Exception 
	   */
	  private Document prepareInputDocForGetOrderList(Document inXML,YFSEnvironment env)
	      throws Exception {
	    
	    Element orderElementFromInput = inXML.getDocumentElement();
	      String strEnterpriseCode = orderElementFromInput.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE);
	      String storeId = orderElementFromInput.getAttribute(KohlsXMLLiterals.A_STORE_NUMBER);
	      String strDocumentType = orderElementFromInput.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE);
	      String strExtnRecp = orderElementFromInput.getAttribute(KohlsXMLLiterals.A_ORDER_NUMBER);
	      if (strExtnRecp.startsWith("0")){
	          strExtnRecp=strExtnRecp.substring(1);
	      }
	      Document inputDocForGetOrderList = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);            
	      Element yfcEleGetOrder = inputDocForGetOrderList.getDocumentElement();
	      yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, strEnterpriseCode);
	      yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, strDocumentType);
		  // MAD-378 CR
		  yfcEleGetOrder.setAttribute(KohlsPOCConstant.A_DRAFT_ORDER_FLAG, KohlsPOCConstant.V_N);
		  // Passing SellerOrganizationCode to make sure sterling Identifies the Shard correctly.
          String originalSaleStoreNumber = "";
          try {
            originalSaleStoreNumber = getStoreNumberFromTransactionNumber(getTransactionIdFromReceiptID(strExtnRecp));
          } catch (Exception e){
            originalSaleStoreNumber = "";
          }
          if(!YFCCommon.isVoid(originalSaleStoreNumber)){
            yfcEleGetOrder.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, String.valueOf(Integer.parseInt(originalSaleStoreNumber)));
          }
	      Element extnElement=XMLUtil.createChild(yfcEleGetOrder, KohlsXMLLiterals.E_EXTN);
	      extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, strExtnRecp);
	      
	      if(XMLUtil.getElementsByTagName(orderElementFromInput, "yfcAdditionalInfo").size() > 0){
	        inputDocForGetOrderList.getDocumentElement().appendChild(inputDocForGetOrderList.importNode(
	            (Element)XMLUtil.getElementsByTagName(orderElementFromInput, "yfcAdditionalInfo").get(0), true));
	       
	      }else{
	        if(ServerTypeHelper.amIOnEdgeServer()){
	          Element additionalInfo =XMLUtil.createChild(yfcEleGetOrder, "yfcAdditionalInfo");
              additionalInfo.setAttribute("endpoint", "MOTHERSHIP,LOCAL");	          
	        }
//	        String serverType = null;
//	          if(storeId!=null && !storeId.isEmpty()){
//	              serverType = OfflineApiHelper.getServerType((YFSContext)env, storeId);
//	              logger.debug("serverType is "+serverType);
//	          }
//	          
//	          if(serverType!=null && serverType.equalsIgnoreCase("edge")) {
//	            Element additionalInfo =XMLUtil.createChild(yfcEleGetOrder, "yfcAdditionalInfo");
//	            additionalInfo.setAttribute("endpoint", "MOTHERSHIP,LOCAL");
//	              
//	          } else {  
//	            // Do nothing
//	              
//	          }
	        
	      }
	      
	    return inputDocForGetOrderList;
	  } 
	  
	  
	  
	  /**
	   * Create By TKMACJT * 
	   * @param isPSApprovedWithReceiptClean
	   * @param orderEle
	   * @return
	   * @throws Exception 
	   * @throws NumberFormatException 
	   */
	  public Document simulateRSResponse(boolean isPSApprovedWithReceiptClean, Document inputOrderDetailDoc)
	      throws NumberFormatException, Exception {
	    
	    Document  orderDetailDoc = null;
	    
	    Element orderEle = KohlsPoCXPathUtil.getElementByXPath(inputOrderDetailDoc, "/Order");
	    Element orderExtnEle = KohlsPoCXPathUtil.getElementByXPath(inputOrderDetailDoc, "/Order/Extn");
	    if(null == orderExtnEle ){
          orderExtnEle = XMLUtil.createChild(orderEle, "Extn");
        }
	    Element orderPriceInfoEle = KohlsPoCXPathUtil.getElementByXPath(inputOrderDetailDoc, "/Order/PriceInfo");
	    if(null == orderPriceInfoEle ){
	      orderPriceInfoEle = XMLUtil.createChild(orderEle, "PriceInfo");
        }
	    
	    if(isPSApprovedWithReceiptClean){
	            
	            Element cleanRecptInd=XMLUtil.createChild(orderEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
	            XMLUtil.setNodeValue(cleanRecptInd,KohlsConstant.TRUE);	 
	            Element responseReasonDesc=XMLUtil.createChild(orderEle,KohlsXMLLiterals.E_REPONSE_REASON_DESC);
	            XMLUtil.setNodeValue(responseReasonDesc,"Approval"); 
	            XMLUtil.setAttribute(orderExtnEle, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, "000000");
	            XMLUtil.setAttribute(orderExtnEle, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE, "Approval");
	          }else{
	            
	            Element cleanRecptInd=XMLUtil.createChild(orderEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
	            XMLUtil.setNodeValue(cleanRecptInd,KohlsConstant.FALSE);
	            Element responseReasonDesc=XMLUtil.createChild(orderEle,KohlsXMLLiterals.E_REPONSE_REASON_DESC);
	            XMLUtil.setNodeValue(responseReasonDesc,"HardDecline");  
	            XMLUtil.setAttribute(orderExtnEle, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, "000000");
	            XMLUtil.setAttribute(orderExtnEle, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE, "HardDecline");
	            
	          }
	    
	    
	    
        Element txnAvblAmount=XMLUtil.createChild(orderEle,KohlsXMLLiterals.TRANSACTION_AVAILABLE_AMT);
        XMLUtil.setNodeValue(txnAvblAmount,orderPriceInfoEle.getAttribute("TotalAmount"));
        Element POCOrder=XMLUtil.createChild(orderEle,KohlsXMLLiterals.E_POC_ORDER);
        XMLUtil.setNodeValue(POCOrder,KohlsConstant.TRUE);
        
        // Other Constants set by RS Response
        //        TransactionTmst
        XMLUtil.setAttribute(orderEle, "TransactionTmst", orderEle.getAttribute("Createts"));
        XMLUtil.setAttribute(orderEle, "TransactionAvailableAmt", orderPriceInfoEle.getAttribute("TotalAmount"));
        
        String receiptId = XMLUtil.getAttribute(orderEle, "ExtnReceiptID");
        boolean trainingIndicator = getTrainingModIndicator(receiptId);
        Element trainingIndicatorEle=XMLUtil.createChild(orderEle,"TrainingModeInd");
        if(trainingIndicator){
          XMLUtil.setNodeValue(trainingIndicatorEle,KohlsConstant.TRUE);
        }else{
          XMLUtil.setNodeValue(trainingIndicatorEle,KohlsConstant.FALSE); 
        }
        
		// Method to set the Tenders available for return.
        setAvailableTendersForReturn(orderEle);
        
        //Method to update deductible offers
        setDeductibleOffersForKC(orderEle);
	    
	    return inputOrderDetailDoc;
	  }

	
	/* (non-Javadoc)
	 * @see com.kohls.common.util.KOHLSBaseApi#setProperties(java.util.Properties)
	 */
	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		logger.debug("In the set properties method");

	}
	
	 public  boolean setPSApprovedWithReceiptClean(Document orderDetails,boolean checkSameDate) throws IllegalArgumentException, Exception{
	      
	      
	      Element orderExtnElement = KohlsPoCXPathUtil.getElementByXPath(orderDetails, "/Order/Extn");
	      Element orderElement = KohlsPoCXPathUtil.getElementByXPath(orderDetails, "/Order");
	      
	      String psaStatus = XMLUtil.getAttribute(orderExtnElement, "ExtnPsaStatus");
	      String hasDerivedChild = XMLUtil.getAttribute(orderElement, "HasDerivedChild");
	      String storeNoFromOrderList = XMLUtil.getAttribute(orderElement, "SellerOrganizationCode");
	      
	      // MAD-378 CR changes
          String postVoided = XMLUtil.getAttribute(orderElement, KohlsPOCConstant.A_POST_VOIDED);
          if (KohlsPOCConstant.V_Y.equals(postVoided)) {
            logger.debug("Original sale is PostVoided, cleanRecptInd is false   :");
            return false;
          }
          if (!YFCCommon.isVoid(psaStatus) && !KohlsPOCConstant.PSA_VOIDED_STATUS.equals(psaStatus)
                && !KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equals(psaStatus)
                && !KohlsPOCConstant.EXTN_PSA_STARTED.equals(psaStatus)
                && !KohlsPOCConstant.EXTN_PSA_IN_PROGRESS.equals(psaStatus)) {
            logger.debug("PSA  is in progress or completed status, cleanRecptInd is false   :");
            return false;
          }
          // MAD-378 CR changes
	      if(!YFCCommon.isVoid(hasDerivedChild)){
            return false;
          }
	      
	      if(checkSameDate){
  	        SimpleDateFormat dateFormatter = new SimpleDateFormat(KohlsConstants.DATE_FORMAT);
  	        String orderDateString = XMLUtil.getAttribute(orderElement, KohlsPOCConstant.A_ORDER_DATE);
      	    if(YFCCommon.isVoid(orderDateString)){
      	         return false;
      	    }
  	        Date orderDate;
  	        Date currentDate;
            try {
              orderDate = dateFormatter.parse(orderDateString);
              currentDate = dateFormatter.parse(dateFormatter.format(Calendar.getInstance().getTime()));
              
            } catch (ParseException e) {
               return false;
            }
  	        int  dateDiff =   KohlsDateUtil.getDifferenceInDays(orderDate, currentDate);
  	        if(dateDiff != 0 ){
  	         return false;
  	        }
	        
	      }
	      
	      
	      return true;
	    }
	   
	   

	 
	 public Document simulateTransactionNotFound(Document inDoc) throws TransformerException{
	   
	   if(null != inDoc && inDoc.getDocumentElement() != null ){
	     
	     Element orderEle = inDoc.getDocumentElement();
	     Element orderExtnEle = KohlsPoCXPathUtil.getElementByXPath(inDoc, "/Order/Extn");
	     if(null == orderExtnEle ){
	       orderExtnEle = XMLUtil.createChild(orderEle, "Extn");
	     }
	     Element cleanRecptInd=XMLUtil.createChild(orderEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
         XMLUtil.setNodeValue(cleanRecptInd,KohlsConstant.FALSE);  
         Element responseReasonDesc=XMLUtil.createChild(orderEle,KohlsXMLLiterals.E_REPONSE_REASON_DESC);
         XMLUtil.setNodeValue(responseReasonDesc,"TransactionNotFound"); 
         XMLUtil.setAttribute(orderExtnEle, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, "TransactionNotFound");
         XMLUtil.setAttribute(orderExtnEle, KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE, "TransactionNotFound");
	   }
	   return inDoc;
	   
	   
	 }
	 
	public boolean getTrainingModIndicator(String receipt) throws NumberFormatException, Exception{
	   boolean trainingInd = false;
	   
	   if ( receipt.startsWith( "0" ) )
       {
          receipt = receipt.substring( 1, receipt.length() );
       }
       if ( receipt.length() == 27 )
           //ReceiptUtil.RECEIPT_LENGTH )
       {
          int receiptCheckDigit = Integer.parseInt( receipt.substring( receipt.length() - 1 ) );
          String receiptWithoutCheckDigit = receipt.substring( 0, receipt.length() - 1 );
          if ( KohlsPoCMathsUtil.validateDigitForMod10( receiptCheckDigit, receiptWithoutCheckDigit ) )
          {
             String TensCompliment = "";
             TensCompliment = KohlsPoCMathsUtil._10sComplement( receiptWithoutCheckDigit );
             receiptCheckDigit = Integer.parseInt( TensCompliment.substring( TensCompliment.length() - 1 ) );
             String decodedReceiptId = TensCompliment.substring( 0, TensCompliment.length() - 1 );

             if ( KohlsPoCMathsUtil.validateDigitForMod10( receiptCheckDigit, decodedReceiptId ) )
             {
                
                String trainingId = decodedReceiptId.substring( decodedReceiptId.substring( 0, decodedReceiptId.length() - 10 ).length() - 2,
                    decodedReceiptId.substring( 0, decodedReceiptId.length() - 10 ).length() );
                if ( trainingId != null && trainingId.equalsIgnoreCase( "88" ) )
                {
                   return true;
                }
             }
          }
       }
	   return trainingInd;
	   
	 }
	 
	/**
	    * Converts transaction number to Store ID
	    * 
	    * @param transactionNo
	    * @return
	    */
	public static String getStoreNumberFromTransactionNumber(String transactionNo) {
		String storeNumber = "";
		if (!YFCCommon.isVoid(transactionNo)) {
			String transactionNbrLength = Integer.toString(transactionNo.length());
			if ( KohlsPOCConstant.TRANSACTION_NO_LENGTH.equals(transactionNbrLength)) {
				// Digit 12 to 16 of Transaction no is store no.
	            storeNumber = transactionNo.substring( 12, 16 );
	            
	            //MJ 05/05 Added logic to convert store to int 0039 -> 39.
	            storeNumber = String.valueOf(Integer.parseInt(storeNumber));
			} else {
				logger.debug( "KohlsReturnUtil.getStoreIdFromTransNbr():  Transaction number is not 22 digit long, Input Transaction No Length =  " + transactionNbrLength );
			}
		}
		return storeNumber;
	}
	   

	public static String getTransactionIdFromReceiptID(String receiptId)
	{
		String orig = receiptId;
		if ((receiptId == null) || (receiptId.length() < 6)) {
			throw new RuntimeException("Invalid Receipt");
		}
		if (receiptId.length() == 22) {
			return receiptId;
		}
		try {
			if (receiptId.startsWith("0")) {
				receiptId = receiptId.substring(1);
			}
			if (receiptId.length() != 27) {
				throw new RuntimeException("Invalid Receipt");
			}
			if (String.valueOf(receiptId.charAt(receiptId.length() - 1)).equals(String.valueOf(
					calculateMod10CheckDigit(receiptId.substring(0, receiptId.length() - 1))))) {
				String transId = trim1(receiptId);
				transId = calculate10sComplement(transId);
				if (String.valueOf(transId.charAt(transId.length() - 1)).equals(String.valueOf(
						calculateMod10CheckDigit(transId.substring(0, transId.length() - 1))))) {
					transId = trim1(transId);
					transId = transId.substring(3);
					return transId;
				}
			}
			throw new RuntimeException("Invalid Receipt"); 
		} catch (Exception e) {
			throw ((RuntimeException)new RuntimeException().initCause(e));
		}
	}
	
	private static String trim1(String str) {
		return str.substring(0, str.length() - 1);
	}
	
	protected static int calculateMod10CheckDigit(final String id) throws Exception
	{
		// allowable characters within identifier
		String validChars = "0123456789";
		
		// this will be a running total
		int checkSum = 0;
		
		// loop through digits from right to left
		for (int i = 0; i < id.length(); i++) {
			
			// set ch to "current" character to be processed
			char ch = id.charAt( id.length() - i - 1 );

			// throw exception for invalid characters
			if ( validChars.indexOf( ch ) == -1 ) {
				throw new Exception( "\"" + ch + "\" is an invalid character in Mod 10 Checker" );
			}

			// our "digit" is calculated using ASCII value - 48
			int digit = ch - 48;

			// weight will be the current digit's contribution to
			// the running total
			int weight;
			if ( i % 2 == 0 ) {
				// for alternating digits starting with the rightmost, we
	            // use our formula this is the same as multiplying x 2 and
	            // adding digits together for values 0 to 9.
	            weight = ( 2 * digit ) - ( digit / 5 ) * 9;

			} else {
	            // even-positioned digits just contribute their ascii
	            // value minus 48
	            weight = digit;
			}
			
			// keep a running total of weights
			checkSum += weight;
		}
		
		// avoid sum less than 10 (if characters below "0" allowed,
		// this could happen)
		checkSum = Math.abs( checkSum ) + 10;

		// check digit is amount needed to reach next number
		// divisible by ten
		return ( 10 - ( checkSum % 10 ) ) % 10;
	}
	
	/**
	    * 
	    * @param id the id
	    * @return the string
	    * @throws Exception the exception
	    */
	protected static final String calculate10sComplement(String id) throws Exception {      

		// Validate to make sure there are no special characters
		validateAllDigits(id);
		
		id = StringUtils.trim(id);

		int[] complementArray = new int[id.length()];

		boolean carry = true;

		// loop through digits from right to left
		for (int i = 0; i < id.length(); i++) {
			// set ch to "current" character to be processed
			int idx = id.length() - i - 1;
			char ch = id.charAt( idx );

			// our "digit" is calculated using ASCII value - 48
			int digit = ch - 48;
	         
			int compDigit = 0;

			if (carry) {
				if (digit != 0) {
					carry = false;
					compDigit = 10 - digit;
				}
			} else {
				compDigit = 9 - digit;
	         }
	         
	         complementArray[idx] = compDigit;
	      }

	      StringBuffer buffer = new StringBuffer( "" );

	      if ( carry ) // If we were all zeros
	         buffer.append( "1" );

	      for ( int x : complementArray )
	      {
	         buffer.append( x );
	      }
	      return buffer.toString();

	   }
	   
	   private static void validateAllDigits( final String id ) throws Exception
	   {
	      String trimmedId = StringUtils.trim( id );
	      // allowable characters within identifier
	      String validChars = "0123456789";

	      // loop through digits from right to left
	      for ( int i = 0; i < trimmedId.length(); i++ )
	      {

	         // set ch to "current" character to be processed
	         char ch = trimmedId.charAt( trimmedId.length() - i - 1 );

	         // skip invalid characters
	         if ( validChars.indexOf( ch ) == -1 )
	         {
	            System.out.println( "\"" + ch + "\" is an invalid character when checking for 10's Complement for \"" + id + "\"" );
	            throw new Exception( "\"" + ch + "\" is an invalid character when checking for 10's Complement for \"" + id + "\"" );
	         }
	      }
	   }
	   	 /**
     * @param orderEle
     * @throws Exception
     */
    private void setAvailableTendersForReturn(Element orderEle) throws Exception {
        logger.debug("KohlsPoCGetOrderDetailForRSOffline.setAvailableTendersForReturn  --Begin");
        NodeList paymentMethodList = XPathUtil.getNodeList(orderEle, "PaymentMethods");
        Element tendersAvailableForReturn = XMLUtil.createChild(orderEle, "TendersAvailableForReturn");
        Double finalAmt = 0.0;
        int isSkip = 1;
        if (paymentMethodList.getLength() > 0) {
            Element paymentMethodsElement = (Element) paymentMethodList.item(0);
            List<Element> paymentMethods = XMLUtil.getElementsByTagName(paymentMethodsElement, "PaymentMethod");
            Integer index = 0;
            //CPE-4175 start
            for (Element paymentMethod : paymentMethods) {
              	 String totalCharged = paymentMethod.getAttribute("TotalCharged");
                   String paymentRef = paymentMethod.getAttribute("PaymentReference6");
                   String paymentType = paymentMethod.getAttribute("PaymentType");
                  if (Double.parseDouble(totalCharged) != 0 && !"PSA".equalsIgnoreCase(paymentRef) && 
               		   ("CASH".equals(paymentType)||"CHECK".equals(paymentType))) {
	               	   String avaibleAmt = paymentMethod.getAttribute("TotalCharged");
	               	   finalAmt = finalAmt + (Double.parseDouble(avaibleAmt)); 
	               	   logger.debug("Printing final cmout$$$$$$"+finalAmt);
                  }
               }
            //CPE-4175 End
            for (Element paymentMethod : paymentMethods) {
                logger.debug("Looping the payment methods from details  :");
                String totalCharged = paymentMethod.getAttribute("TotalCharged");
                String paymentRef = paymentMethod.getAttribute("PaymentReference6");
                String paymentType = paymentMethod.getAttribute("PaymentType");
                if (Double.parseDouble(totalCharged) != 0 && !KohlsPOCConstant.ATTR_PSA.equalsIgnoreCase(paymentRef)) {
                	 //CPE-4175 start
                	if("CASH".equals(paymentType)||"CHECK".equals(paymentType)){
	                	if(isSkip>1){
	                		continue;
	                	}
                	}
                	 //CPE-4175 End
                    logger.debug("total charged amount is not zero   :");
                    Element returnTender = XMLUtil.createChild(tendersAvailableForReturn, "ReturnTender");
                    tendersAvailableForReturn.appendChild(returnTender);
                    Element availableAmt = XMLUtil.createChild(returnTender, "AvailableAmt");
                    String avaibleAmt = paymentMethod.getAttribute("TotalCharged");
                    //CPE-4175 start
                    if("CASH".equals(paymentType)||"CHECK".equals(paymentType)){
                    	isSkip++;
                    	XMLUtil.setNodeValue(availableAmt, String.valueOf(finalAmt));
                    }else{
                    	XMLUtil.setNodeValue(availableAmt, avaibleAmt);
                    }
                    //CPE-4175 End
                    returnTender.appendChild(availableAmt);
                    Element tenderSource = XMLUtil.createChild(returnTender, "TenderSource");
                    XMLUtil.setNodeValue(tenderSource, "00");
                    returnTender.appendChild(tenderSource);
                    Element chargeInd = XMLUtil.createChild(returnTender, "KohlsChargeZeroBalanceInd");
                    XMLUtil.setNodeValue(chargeInd, "false");
                    returnTender.appendChild(chargeInd);
                    Element tenderOrderManagementNbr = XMLUtil.createChild(returnTender, "TenderManagementOrderNbr");
                    Integer count = ++index;
                    XMLUtil.setNodeValue(tenderOrderManagementNbr, count.toString());
                    returnTender.appendChild(tenderOrderManagementNbr);
                   
                    setTenderTypeCode(paymentMethod, returnTender, paymentType);
                }
            }

        }
        logger.debug("KohlsPoCGetOrderDetailForRSOffline.setAvailableTendersForReturn  --End");
    }

    /**
     * @param paymentMethod
     * @param returnTender
     * @param paymentType
     */
    private void setTenderTypeCode(Element paymentMethod, Element returnTender, String paymentType) {
        logger.debug("KohlsPoCGetOrderDetailForRSOffline.setTenderTypeCode  --Begin");
        String strCreditCardExpDate = XMLUtil.getAttribute(paymentMethod, KohlsPOCConstant.CreditCardExpDate);
        if(YFCCommon.isVoid(strCreditCardExpDate)){
        	strCreditCardExpDate = "0000";
        }
        if ("CASH".equals(paymentType) || "CHECK".equals(paymentType) ) {
            Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
            XMLUtil.setNodeValue(tenderTypeCde, "Cash");
            returnTender.appendChild(tenderTypeCde);

        } else if ("KOHLS_CHARGE_CARD".equals(paymentType)) {
            Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
            XMLUtil.setNodeValue(tenderTypeCde, "KohlsCharge");
            returnTender.appendChild(tenderTypeCde);

            Element tenderId = XMLUtil.createChild(returnTender, "TenderId");
            XMLUtil.setNodeValue(tenderId, paymentMethod.getAttribute("PrimaryAccountNo"));
            returnTender.appendChild(tenderId);

            Element expirationDte = XMLUtil.createChild(returnTender, "ExpirationDte");
            XMLUtil.setNodeValue(expirationDte, strCreditCardExpDate);
            returnTender.appendChild(expirationDte);

        } else if ("CREDIT_CARD".equals(paymentType)) {
            String creditcardType = paymentMethod.getAttribute("CreditCardType");
            if ("06".equals(creditcardType)) {
                Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
                XMLUtil.setNodeValue(tenderTypeCde, "MasterCardCredit");
                returnTender.appendChild(tenderTypeCde);
            } else if ("05".equals(creditcardType)) {
                Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
                XMLUtil.setNodeValue(tenderTypeCde, "VisaCredit");
                returnTender.appendChild(tenderTypeCde);
            } else if ("07".equals(creditcardType)) {
                Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
                XMLUtil.setNodeValue(tenderTypeCde, "DiscoverCredit");
                returnTender.appendChild(tenderTypeCde);
            } else if ("08".equals(creditcardType)) {
                Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
                XMLUtil.setNodeValue(tenderTypeCde, "AmericanExpressCredit");
                returnTender.appendChild(tenderTypeCde);
            }

            Element tenderId = XMLUtil.createChild(returnTender, "TenderId");
            XMLUtil.setNodeValue(tenderId, paymentMethod.getAttribute("PrimaryAccountNo"));
            returnTender.appendChild(tenderId);

            Element expirationDte = XMLUtil.createChild(returnTender, "ExpirationDte");
            XMLUtil.setNodeValue(expirationDte, strCreditCardExpDate);
            returnTender.appendChild(expirationDte);

        } else if ("DEBIT_CARD".equals(paymentType)) {
            String creditcardType = paymentMethod.getAttribute("CreditCardType");
            if ("19".equals(creditcardType)) {
                Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
                XMLUtil.setNodeValue(tenderTypeCde, "ATMDebit");
                returnTender.appendChild(tenderTypeCde);
            } else {
                Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
                XMLUtil.setNodeValue(tenderTypeCde, "DebitCard");
                returnTender.appendChild(tenderTypeCde);
            }

            Element tenderId = XMLUtil.createChild(returnTender, "TenderId");
            XMLUtil.setNodeValue(tenderId, paymentMethod.getAttribute("PrimaryAccountNo"));
            returnTender.appendChild(tenderId);

            Element expirationDte = XMLUtil.createChild(returnTender, "ExpirationDte");
            XMLUtil.setNodeValue(expirationDte, strCreditCardExpDate);
            returnTender.appendChild(expirationDte);

        } else if ("KMC".equals(paymentType)) {
            Element tenderTypeCde = XMLUtil.createChild(returnTender, "TenderTypeCde");
            XMLUtil.setNodeValue(tenderTypeCde, "KohlsMerchandiseReturnCredit");
            returnTender.appendChild(tenderTypeCde);

        }
        logger.debug("KohlsPoCGetOrderDetailForRSOffline.setTenderTypeCode  --End");
    }

    private void setDeductibleOffersForKC(Element orderEle) {
    	logger.debug("KohlsPoCGetOrderDetailForRSOffline.setDeductibleOffersForKC --start ");
        NodeList ndReference = orderEle.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
		if(!YFCCommon.isVoid(ndReference) && ndReference.getLength() > KohlsPOCConstant.ZERO_INT)
		{
			Element eleDeductibleOffers = XMLUtil.createChild(orderEle, KohlsPOCConstant.DEDUCTIBLE_OFFERS);
			Element eleDeductibleOffer = XMLUtil.createChild(eleDeductibleOffers,KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
			Element eleLoyalty = null;
			for(int k=0; k<ndReference.getLength(); k++)
			{
				logger.debug("KohlsPoCGetOrderDetailForRSOffline inside references loop"+ndReference.getLength());
				Element eleReference = ((Element)ndReference.item(k));
				if(!YFCCommon.isVoid(eleReference) && (KohlsPOCConstant.A_KCA_EXTN_COUPON_AMT.equals(eleReference.getAttribute("Name")))){
					
					Element offerBalanceAmt = XMLUtil.createChild(eleDeductibleOffer, KohlsXMLLiterals.E_OFFER_BALANCE_AMOUNT);
					String sCoupounAmt = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
					XMLUtil.setNodeValue(offerBalanceAmt,sCoupounAmt);
					eleDeductibleOffer.appendChild(offerBalanceAmt);
					
					Element earnedAmt = XMLUtil.createChild(eleDeductibleOffer, KohlsXMLLiterals.E_EARNED_AMOUNT);
					XMLUtil.setNodeValue(earnedAmt,sCoupounAmt);
					eleDeductibleOffer.appendChild(earnedAmt);
					
					Element initialOfferAmt = XMLUtil.createChild(eleDeductibleOffer, KohlsPOCConstant.INITIAL_OFFER_AMT);
					XMLUtil.setNodeValue(initialOfferAmt,sCoupounAmt);
					eleDeductibleOffer.appendChild(initialOfferAmt);
				}
				if(!YFCCommon.isVoid(eleReference) && (KohlsPOCConstant.A_KCA_EXTN_QUALIFYING_AMT.equals(eleReference.getAttribute("Name")))){
					String sQualifingAmt = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
					Element eleEligibleAmt = XMLUtil.createChild(eleDeductibleOffer, KohlsXMLLiterals.E_ELIGIBLE_AMOUNT);
					XMLUtil.setNodeValue(eleEligibleAmt, sQualifingAmt);
					eleDeductibleOffer.appendChild(eleEligibleAmt);
				}
				if(!YFCCommon.isVoid(eleReference) && (KohlsPOCConstant.A_KCA_EXTN_ACTIVATION_BARCODE.equals(eleReference.getAttribute("Name")))){
					String sActivationBarcode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
					Element individualAmt = XMLUtil.createChild(eleDeductibleOffer, KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID);
					XMLUtil.setNodeValue(individualAmt, sActivationBarcode);
					eleDeductibleOffer.appendChild(individualAmt);
					
					Element postSaleAmt = XMLUtil.createChild(eleDeductibleOffer, KohlsPOCConstant.POST_SALE_IND);
					XMLUtil.setNodeValue(postSaleAmt, "false");
					eleDeductibleOffer.appendChild(postSaleAmt);
				}
				
				
				if(YFCCommon.isVoid(eleLoyalty) && !YFCCommon.isVoid(orderEle.getAttribute("CustomerRewardsNo"))){
					eleLoyalty = XMLUtil.createChild(eleDeductibleOffer,KohlsCorpReturnsConstants.LCS_LOYALTY_CUSTOMER_DETAILS);
					String sValue = orderEle.getAttribute("CustomerRewardsNo");
					Element eleLoyaltyNumber =  XMLUtil.createChild(eleDeductibleOffer,KohlsCorpReturnsConstants.LCS_LOYALTY_NUMBER);
					eleLoyaltyNumber.setTextContent(sValue);
					Element eleLoyaltyNumberoff =  XMLUtil.createChild(eleLoyalty,KohlsCorpReturnsConstants.LCS_LOYALTY_NUMBER);
					eleLoyaltyNumberoff.setTextContent(sValue);
				}
				
				if(!YFCCommon.isVoid(eleLoyalty) && ("KCA_EverydayEarnNonKcc".equals(eleReference.getAttribute("Name")))){
					
					String sValue = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
					Element eleNonKcEarned =  XMLUtil.createChild(eleLoyalty,KohlsCorpReturnsConstants.LCS_EVERY_DAY_NON_KCC_EARNED_AMOUNT);
					eleNonKcEarned.setTextContent(sValue);
				}
				if(!YFCCommon.isVoid(eleLoyalty) && ("KCA_EverydayEarnKcc".equals(eleReference.getAttribute("Name")))){
					
					String sValue = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
					Element eleNonKcEarned =  XMLUtil.createChild(eleLoyalty,KohlsCorpReturnsConstants.LCS_EVERY_DAY_KCC_EARNED_AMOUNT);
					eleNonKcEarned.setTextContent(sValue);
				}
				
				
			}
			logger.debug("Appended DeductibleOffer element :: "+XmlUtils.getString(eleDeductibleOffers));
		}
    }
    
    private void invokeChangeOrderExtn(YFSEnvironment env,Document inputOrderDetailDoc){
    	
    	logger.debug("KohlsPoCGetOrderDetailForRSOffline.invokeChangeOrderExtn --Start ");
    	try {
    		 	Element orderEle = KohlsPoCXPathUtil.getElementByXPath(inputOrderDetailDoc, "/Order");
		    	Element eleCleanReceiptInd = XMLUtil.getUniqueSubNode(orderEle, KohlsXMLLiterals.E_CLEAN_RECEIPT_IND);
				String sCleanReceiptInd = eleCleanReceiptInd.getTextContent();
		    	if("true".equalsIgnoreCase(sCleanReceiptInd)){
		    		Element orderExtnEle = KohlsPoCXPathUtil.getElementByXPath(inputOrderDetailDoc, "/Order/Extn");
		    		String extnOTRResponse = orderExtnEle.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE);
		    		String extnOTRResponseType = orderExtnEle.getAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE);
		    		
		    		 Document chgOrdDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		 			 Element chgOrdDocEle = chgOrdDoc.getDocumentElement();
		 			 Element changeOrderExtnEle = XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_EXTN);
		 			 
		 			 changeOrderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE, extnOTRResponse);
		 			 changeOrderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_OTR_RESPONSE_TYPE, extnOTRResponseType);
		 			if(! YFCCommon.isVoid(orderEle.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0))){
		 				changeOrderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, 
							 XMLUtil.getElementXMLString((Element)orderEle.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0)));
		 				orderExtnEle.setAttribute(KohlsXMLLiterals.A_EXTN_DEDUCTIBLE_OFFERS, 
							 XMLUtil.getElementXMLString((Element)orderEle.getElementsByTagName(KohlsXMLLiterals.A_DEDUCTIBLE_OFFERS).item(0)));
		 			}
					 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, orderEle.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE));
					 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, orderEle.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE));
					 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, orderEle.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
					 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, orderEle.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
					 chgOrdDocEle.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsConstant.YES);
					 //PST-2664 change started
					 Element eleAdditionalInfo = KohlsPoCXPathUtil.getElementByXPath(inputOrderDetailDoc,KohlsXMLLiterals.X_PATH_YFCADDITIONALINFO);
					 String sEndpoint = eleAdditionalInfo.getAttribute(KohlsXMLLiterals.A_ENDPOINT);
					 if(ServerTypeHelper.amIOnEdgeServer() && !YFCCommon.isVoid(sEndpoint)){
				          Element additionalInfo =XMLUtil.createChild(chgOrdDocEle, KohlsXMLLiterals.E_YFCADDITIONALINFO);
			             	  additionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);	          
				        }
					 //PST-2664 change end
					 // set env object to skip change order on success action
					 env.setTxnObject(KohlsPOCConstant.TXN_IS_CHANGEORDER_FOR_RECEIPT_SCAN, KohlsPOCConstant.FLAG_Y);
					 logger.debug("invokeChangeOrderExtn method before ChangeOrder ::"+XmlUtils.getString(chgOrdDocEle));
					 KohlsCommonUtil.invokeAPI(env, KohlsConstants.CHANGE_ORDER_API, chgOrdDoc);
		    	}
		    } catch (Exception e) {
			logger.error("KohlsPoCGetOrderDetailForRSOffline.invokeChangeOrderExtn error ::"+e);
		}
    	logger.debug("KohlsPoCGetOrderDetailForRSOffline.invokeChangeOrderExtn --End ");
    	
    }
	

}
