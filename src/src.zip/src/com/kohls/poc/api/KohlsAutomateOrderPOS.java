package com.kohls.poc.api;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

public class KohlsAutomateOrderPOS implements YIFCustomApi {

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsAutomateOrderPOS.class.getName());
	private static YIFApi oApi = null;
	public static final String GET_ITEM_LIST_TEMPLATE = "<ItemList><Item ItemID='' UnitOfMeasure='' OrganizationCode=''><PrimaryInformation DefaultProductClass=''/><ClassificationCodes TaxProductCode=''/><Extn ExtnEmpDiscCode='' ExtnDept='' ExtnClass='' ExtnSubClass='' ExtnMerchandiseTaxCode=''/></Item></ItemList>";

	/**
	 * This service/method takes input(docInXML) in the below format and creates/confirms an order by calling necessary APIs in sequence; createOrderForPOS, makePaymentForPOS, confirmDraftOrder.  
	 * 	<Order EnterpriseCode="" EntryType="" OperatorID="" SellerOrganizationCode="" TerminalID="">
	 *		<OrderLines>
	 *  		<OrderLine BarcodeValue="" DeliveryMethod="" />
	 *		</OrderLines>	
	 *	</Order>
	 * @param env
	 * @param docInXML
	 * @return docOutXML
	 * @throws Exception
	 */
	public Document createPOSOrder(YFSEnvironment env, Document docInXML) throws Exception {
		logger.timer("createPOSOrder method - Starts");
		logger.debug("Incoming XML message to createPOSOrder method is: " + SCXmlUtil.getString(docInXML));

		Document docCreateOrderPOS = null, docOutXML = null;
		try {
			Element elemOrderLines = SCXmlUtil.getChildElement(docInXML.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
			ArrayList<Element> listOrderLine = SCXmlUtil.getChildren(elemOrderLines, KohlsPOCConstant.ELEM_ORDER_LINE);

			if (!listOrderLine.isEmpty() && listOrderLine.size() >= 1) {		
				docCreateOrderPOS = loadTemplateCreateOrderForPOS();
				logger.debug("create order input xml- fresh template is:"+ SCXmlUtil.getString(docCreateOrderPOS));
				docCreateOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
				docCreateOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));
				docCreateOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
				docCreateOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID));
				docCreateOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE));
				Element eleExtn = SCXmlUtil.getChildElement(docCreateOrderPOS.getDocumentElement(), KohlsPOCConstant.E_EXTN);
				Calendar cal = Calendar.getInstance();
				String currentBusinessDay = new SimpleDateFormat(KohlsPOCConstant.REQUEST_DATETIME_FORMAT).format(new Date(cal.getTimeInMillis()));
				eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_REQUEST_DATE_TIME, currentBusinessDay);
				Element eleOrderLines = SCXmlUtil.getChildElement(docCreateOrderPOS.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
				Element eleOrderLine = SCXmlUtil.getChildElement(eleOrderLines, KohlsPOCConstant.ELEM_ORDER_LINE);
				Element eleItem = SCXmlUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_ITEM);
				eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SHIP_NODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
				eleOrderLine.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));

				for (int orderLineCount = 0; orderLineCount < listOrderLine.size(); orderLineCount++) {
					Element elemOrderLine = listOrderLine.get(orderLineCount);
					String strItemID = elemOrderLine.getAttribute(KohlsPOCConstant.ATTR_BARCODE_VALUE);
					eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_BARCODE_VALUE, strItemID);
					eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_DELIVERY_METHOD, elemOrderLine.getAttribute(KohlsPOCConstant.ATTR_DELIVERY_METHOD));		
					eleItem.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemID);
					//String Quantity = elePurchasedItem.getAttribute("Quantity");
					logger.info("Item being processed: " + strItemID);
					Document docItemDtls = callGetItemList(env, strItemID);
					logger.debug("getItemList output XML: " + SCXmlUtil.getString(docItemDtls));
					
					if(orderLineCount==0) {
						eleOrderLine = copyItemAttribsToOrderLine(docItemDtls, eleOrderLine);
						logger.debug("Order Line after getting modified, when the order line count is only 1, is: "+SCXmlUtil.getString(eleOrderLine));
						}
					
					while ((orderLineCount + 1) < listOrderLine.size()) {
						// Copy order line element and set necessary attributes, append it to the create order document
						logger.info("Creating new order line element.");
						Element eleOrderLineToCopy = SCXmlUtil.getCopy(eleOrderLine);
						Element eleUpdatedOrdLine = copyItemAttribsToOrderLine(docItemDtls, eleOrderLineToCopy);
						logger.debug("Modified new order line element is: "+SCXmlUtil.getString(eleUpdatedOrdLine));
						eleOrderLines.appendChild(docCreateOrderPOS.importNode(eleUpdatedOrdLine, true));
						break;
					}
				}
				logger.debug("create order input xml- modified is:"+ SCXmlUtil.getString(docCreateOrderPOS));
			} else {
				logger.info("Invalid input..OrderLine element is missing");
				throw new YFCException("Invalid input XML.. Item is missing.");
			}
			//Calling APIs for creating and confirming an order with cash payment
			Document docOpConfirmOrderPOS = callApisInSequence(env, docCreateOrderPOS);
			String strTranNum = docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
			logger.info("Transaction number/Unique id is: " + strTranNum);
			String strOrderNum = docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
			logger.info("Order " + strOrderNum + " created and confirmed successfully.");
			String strOrderHeaderKey = docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			logger.info("Order header key " + strOrderHeaderKey);

			docOutXML = SCXmlUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOrderNum);
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.A_TRANSACTION_NO, strTranNum);
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID));
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORG_CODE, docOpConfirmOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
			Element elePriceInfo = SCXmlUtil.getChildElement(docOpConfirmOrderPOS.getDocumentElement(), KohlsPOCConstant.ELE_PRICE_INFO);
			docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_AMOUNT, elePriceInfo.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT));
			
		} catch (Exception e) {
			logger.error("Exception occured while creating and confirming an order in KohlsAutomateOrderPOS Class.");
			logger.error("Error message is:"+e.getMessage());
			throw e;
		}

		return docOutXML;
	}

	/**
	 * This service accepts input XML for createOrderForPOS API and creates a draft order followed by doing payment for an order. Finally, order is confirmed by 
	 * calling confirmDraftOrder API.
	 * @param env
	 * @param docModifiedCreateOrderPOS
	 * @return
	 */
	private Document callApisInSequence(YFSEnvironment env, Document docModifiedCreateOrderPOS) {
		Document docOpForCreateOrderPOS = null;
		try {
			docOpForCreateOrderPOS = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_CREATE_ORDER_FOR_POS, docModifiedCreateOrderPOS);
			logger.debug("*********Output of createOrderForPOS API is*******:"+SCXmlUtil.getString(docOpForCreateOrderPOS));
			/*//manage till status before making payment so that the business day is set to current day
			manageTillStatusForCurrentDay(env, docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE),
					docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_TERMINAL_ID) );
			*/invokeMakePaymentForPOS(env, docOpForCreateOrderPOS);	
			invokeConfirmDraftOrder(env, docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
		
		} catch (Exception e) {
			throw new YFCException("Exception while creating an order : "+ e.getMessage());
		}
		return docOpForCreateOrderPOS;
	}

	/**
	 * 
	 * @param env
	 * @param docOpForCreateOrderPOS
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws DOMException
	 * @throws Exception
	 */
	private void invokeMakePaymentForPOS(YFSEnvironment env, Document docOpForCreateOrderPOS)
			throws ParserConfigurationException, SAXException, IOException, DOMException, Exception {
		Element elePriceInfo = SCXmlUtil.getChildElement(docOpForCreateOrderPOS.getDocumentElement(), KohlsPOCConstant.ELE_PRICE_INFO);

		Document docIpMakePaymentForPOS = loadTemplateForPaymentPOS();
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
		docIpMakePaymentForPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_CLIENT_ID,
				docOpForCreateOrderPOS.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));

		Element elePaymentMethods = SCXmlUtil.getChildElement(docIpMakePaymentForPOS.getDocumentElement(),
				KohlsPOCConstant.E_PAYMENT_METHODS);
		Element elePaymentMethod = SCXmlUtil.getChildElement(elePaymentMethods, KohlsPOCConstant.E_PAYMENT_METHOD);
		elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_REQUESTED_AMOUNT, elePriceInfo.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT));
		logger.debug("Make Payment for POS Input XML:" + SCXmlUtil.getString(docIpMakePaymentForPOS));
		Document docOpMakePaymentForPOS = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MAKE_PAYMENT_FOR_POS, docIpMakePaymentForPOS);
		logger.debug("Make Payment for POS Output XML:" + SCXmlUtil.getString(docOpMakePaymentForPOS));
		logger.info("Payment done successfully...");
	}

	/**
	 * 
	 * @param env
	 * @param strOHK
	 * @throws Exception
	 */
	private void invokeConfirmDraftOrder(YFSEnvironment env, String strOHK) throws Exception {
		Document docIpForConfirmOrderPOS = SCXmlUtil.createDocument(KohlsPOCConstant.DOC_CONFIRM_DRAFTORDER_INPUT);
		docIpForConfirmOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHK);
		/*docIpForConfirmOrderPOS.getDocumentElement().setAttribute("OrderNo",
				docOpForCreateOrderPOS.getDocumentElement().getAttribute("OrderNo"));*/
		docIpForConfirmOrderPOS.getDocumentElement().setAttribute("DisplayLocalizedFieldInLocale", "en_US");
		docIpForConfirmOrderPOS.getDocumentElement().setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);

		KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_CONFIRMDRAFTORDER, docIpForConfirmOrderPOS);
		logger.info("Draft order confirmed successfully.....");
	}

	/**
	 * 
	 * @param env
	 * @param strItemID
	 * @return
	 */
	private Document callGetItemList(YFSEnvironment env, String strItemID) {

		Document docIpForGetItemList, docOpForGetItemList = null;

		try {
			docIpForGetItemList = SCXmlUtil.createDocument(KohlsPOCConstant.E_ITEM);
			docIpForGetItemList.getDocumentElement().setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemID);
			env.setApiTemplate(KohlsPOCConstant.API_GET_ITEM_LIST, SCXmlUtil.createFromString(GET_ITEM_LIST_TEMPLATE));
			docOpForGetItemList = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_ITEM_LIST, docIpForGetItemList);
			env.clearApiTemplate(KohlsPOCConstant.API_GET_ITEM_LIST);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return docOpForGetItemList;
	}

	/**
	 * 
	 * @param docItemDetails
	 * @param eleOrderLine
	 * @return
	 * @throws TransformerException
	 */
	private Element copyItemAttribsToOrderLine(Document docItemDetails, Element eleOrderLine)
			throws TransformerException {
		logger.info("Inside copyItemAttribsToOrderLine method---starts");
		logger.debug("getItemList input: " + SCXmlUtil.getString(docItemDetails));

		Element eleItemList = docItemDetails.getDocumentElement();
		Element eleItem = SCXmlUtil.getChildElement(eleItemList, KohlsPOCConstant.E_ITEM);
		Element elePrimaryInfo = SCXmlUtil.getChildElement(eleItem, KohlsPOCConstant.A_PRIMARY_INFORMATION);
		Element eleExtn = SCXmlUtil.getChildElement(eleItem, KohlsPOCConstant.E_EXTN);
		Element eleClassificationCodes = SCXmlUtil.getChildElement(eleItem, KohlsPOCConstant.ELE_CLASSIFICATION_CODES);

		Element eleItemPOS = SCXmlUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_ITEM);
		Element eleReferences = SCXmlUtil.getChildElement(eleOrderLine, KohlsPOCConstant.A_REFERENCES);
		NodeList nlReference = eleReferences.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
		  for(int referenceCnt=0; referenceCnt<nlReference.getLength(); referenceCnt++){
		  	 Element eleReference = (Element)nlReference.item(referenceCnt);
		    if(eleReference.getAttribute(KohlsPOCConstant.A_NAME).equalsIgnoreCase(KohlsPOCConstant.EMP_DISC_CODE)){
		    	eleReference.setAttribute(KohlsPOCConstant.A_VALUE, eleExtn.getAttribute(KohlsPOCConstant.EMP_DISC_CODE));
		    	break;
		    }
		  } 
		eleItemPOS.setAttribute(KohlsPOCConstant.A_ITEM_ID, eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID));
		eleItemPOS.setAttribute(KohlsPOCConstant.A_PRODUCT_CLASS, elePrimaryInfo.getAttribute(KohlsPOCConstant.ATTR_DEFAULT_PRODUCT_CLASS));
		eleItemPOS.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, eleItem.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE));

		Element eleExtnPOS = SCXmlUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
		eleExtnPOS.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS, eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_CLASS));
		eleExtnPOS.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT, eleExtn.getAttribute(KohlsPOCConstant.E_EXTN_DEPT));
		eleExtnPOS.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS, eleExtn.getAttribute(KohlsPOCConstant.EXTNSUBCLASS));
		eleExtnPOS.setAttribute(KohlsPOCConstant.A_EXTN_MDX_TAX_CODE, eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_MERCHANDISE_TAXCODE));
		eleExtnPOS.setAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE, eleClassificationCodes.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE));
		logger.info("Inside copyItemAttribsToOrderLine method---Ends");
		return eleOrderLine;

	}

		
	/**
	 * This service/method takes input XML with necessary details like OrderNo, OrderAmount, etc. and post-voids the order in CORP for the already synched order.
	 * If the order is not yet synched, it post-voids the order in STORE. 
	 * @param env
	 * @param docInXML
	 * <Order OrderNo="" EnterpriseCode="" OperatorID="" OrderAmount="" OrganizationCode="" TerminalID=""/>
	 * @return
	 * @throws Exception
	 */
	public Document voidTransactionForPOS(YFSEnvironment env, Document docInXML) throws Exception {
		logger.timer("voidTransactionForPOSs method - Starts");
		Document docOutXML = null; 	
		Document docVoidTransactionForPOSTemplate = getTemplateForVoidTransaction();
		
		try {
				Document docIpGetOrderList = docIpGetOrderList(docInXML, KohlsPOCConstant.V_MOTHERSHIP);
				Document docOpGetOrderList = callApi(env, docIpGetOrderList, KohlsPOCConstant.V_MOTHERSHIP, KohlsPOCConstant.GET_ORDER_LIST, null);
				logger.info("Output of remote api getOrderList is: "+SCXmlUtil.getString(docOpGetOrderList));
				
				if(!YFCCommon.isVoid(docOpGetOrderList) && docOpGetOrderList.getDocumentElement().hasChildNodes()) {
					logger.info("Order exists in CORP. Hence, directly voiding it.");
					Document docIpVoidTranPOS = voidTransactionForPOSInput(docInXML, KohlsPOCConstant.V_MOTHERSHIP);
					logger.debug("Input to CORP voidTransactionForPOS API: "+SCXmlUtil.getString(docIpVoidTranPOS));
					Document docOutCORPVoidTranPOS = callApi(env, docIpVoidTranPOS, KohlsPOCConstant.V_MOTHERSHIP, KohlsPOCConstant.API_VOID_TRAN_FOR_POS, docVoidTransactionForPOSTemplate);
					logger.debug("Output of CORP voidTransactionForPOS API: "+SCXmlUtil.getString(docOutCORPVoidTranPOS));
					NodeList nlError = docOutCORPVoidTranPOS.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_ERROR);
					if(nlError.getLength() >  0) {
						Element eleError = (Element)nlError.item(0); 
						throw new YFSException(eleError.getAttribute("ErrorRelatedMoreInfo"),
								eleError.getAttribute(KohlsPOCConstant.A_ERROR_CODE), "voidTransactionForPOS API mothership call failure - CORP");
					}
					docOutXML = SCXmlUtil.createDocument("PostVoid");
					docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_STATUS, KohlsPOCConstant.SUCCESS);
					docOutXML.getDocumentElement().setAttribute("Env", KohlsPOCConstant.CORP);
				}
				else {
					logger.info("Order yet not created in CORP. Hence, proceeding to void in store.");
					Document docIpVoidTranPOS = voidTransactionForPOSInput(docInXML, KohlsPOCConstant.ENDPOINT_LOCAL);
					logger.debug("Input to Store voidTransactionForPOS API: "+SCXmlUtil.getString(docIpVoidTranPOS));
					Document docOutStoreVoidTranPOS = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_VOID_TRAN_FOR_POS, docIpVoidTranPOS);
					logger.debug("Output of Store voidTransactionForPOS API: "+SCXmlUtil.getString(docOutStoreVoidTranPOS));
					NodeList nlError = docOutStoreVoidTranPOS.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_ERROR);
					if(nlError.getLength() >  0) {
						Element eleError = (Element)nlError.item(0); 
						throw new YFSException(eleError.getAttribute("ErrorRelatedMoreInfo"),
								eleError.getAttribute(KohlsPOCConstant.A_ERROR_CODE), "voidTransactionForPOS local API call failure - STORE");
					}
					docOutXML = SCXmlUtil.createDocument("PostVoid");
					docOutXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_STATUS, KohlsPOCConstant.SUCCESS);
					docOutXML.getDocumentElement().setAttribute("Env", KohlsPOCConstant.A_STORE);
				}
				logger.debug("Output XML is: "+SCXmlUtil.getString(docOutXML));
				logger.timer("voidTransactionForPOSs method - Ends");
				return docOutXML;
			} catch(Exception e) {
				logger.error("Exception occured while calling voidTransactionForPOS API: "+e.getMessage());
				throw e;
			}
		}

	/**
	 * 
	 * @param docInXML
	 * @param strEndPoint
	 * @return
	 * @throws Exception
	 */
	private Document voidTransactionForPOSInput(Document docInXML, String strEndPoint) throws Exception {	
		String strVoidTranPOS = "<?xml version='1.0' encoding='UTF-8'?>\r\n"
				+ "<Order Action='CANCEL' DisplayLocalizedFieldInLocale='en_US'\r\n"
				+ "    DocumentType='' EnterpriseCode='' IgnoreOrdering='Y'\r\n"
				+ "    ModificationReasonCode='' ModificationReference1=''\r\n"
				+ "    ModificationReference2='' ModificationReference3=''\r\n"
				+ "    ModificationReference4='' OperatorID='' OrderAmount=''\r\n"
				+ "    OrderHeaderKey='' OrderNo=''\r\n"
				+ "    OrganizationCode='' OverrideManagerId='' POSSequenceNumber=''\r\n"
				+ "    PosSequenceNo='' PostVoidConfirmedFlag='Y' ProcedureID='postVoid'\r\n"
				+ "    RequiresManagerOverride='N' SecondaryOrderHeaderKey=''\r\n"
				+ "    SystemInitiatedVoid='' TerminalID='' TransactionNo='' VoidOrphanReturnOrder=''>\r\n"
				+ "    <yfcAdditionalInfo endpoint=''/>\r\n" + "    <Promotions Reset='N'/>\r\n"
				+ "</Order>";
		Document docIpVoidTranPOS = SCXmlUtil.createFromString(strVoidTranPOS);
		docIpVoidTranPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
		docIpVoidTranPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_AMOUNT, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_AMOUNT));
		docIpVoidTranPOS.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
		docIpVoidTranPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
		docIpVoidTranPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
		docIpVoidTranPOS.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID));
		Element eleYFCAdditionalInfo = SCXmlUtil.getChildElement(docIpVoidTranPOS.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
		eleYFCAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, strEndPoint);
		return docIpVoidTranPOS;
	}

	/**
	 * 
	 * @param docInXML
	 * @param strEndPoint
	 * @return
	 * @throws DOMException
	 */
	private Document docIpGetOrderList(Document docInXML, String strEndPoint) throws DOMException{
		Document docIpGetOrderList = SCXmlUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
		docIpGetOrderList.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
		docIpGetOrderList.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
		docIpGetOrderList.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
		docIpGetOrderList.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
		Element eleYFCAddInfo = SCXmlUtil.createChild(docIpGetOrderList.getDocumentElement(), KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
		eleYFCAddInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, strEndPoint);
		logger.debug("docIpGetOrderList XML is: "+SCXmlUtil.getString(docIpGetOrderList));
		return docIpGetOrderList;
	}

	/**
	 * 
	 * @param env
	 * @param inXML
	 * @param sEndpoint
	 * @param sApiName
	 * @param docApiTemplate
	 * @return
	 * @throws Exception
	 */
	// Calling the remote Api
	private Document callApi(YFSEnvironment env, Document inXML, String sEndpoint, String sApiName, Document docApiTemplate) throws Exception {
		Document outDocCallApi = null;
		try {
		oApi = getDefaultAPI((YFSContext) env, sEndpoint);
		logger.info("Call Api is inProgress");
		String envString = "<env userId='gravity' progId='gravity'/>";
		YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
		if(docApiTemplate!=null) {
			newEnv.setApiTemplate(sApiName, docApiTemplate);
		}
		outDocCallApi = oApi.invoke(newEnv, sApiName, inXML);
		newEnv.clearApiTemplate(sApiName);
		logger.debug("Remote call output in callApi " + sApiName + "\n " + SCXmlUtil.getString(outDocCallApi));
		return outDocCallApi;
		}
		catch(Exception e) {
			throw e;
		}
	}

	/**
	 * 
	 * @param env
	 * @param endpoint
	 * @return
	 * @throws YIFClientCreationException
	 * @throws YFSUserExitException
	 */
	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			logger.debug("YIFClient using endpoint definition");
			Map<String, String> omap = new HashMap<String, String>();
			try {
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_USERID,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_USERID));
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_PASSWD,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_PASSWD));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}
		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode(KohlsPOCConstant.EDGE_SERVER_ERROR_CODE);
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), KohlsPOCConstant.EDGE_SER_NOT_CONFIGURED));
		throw oEx;
	}

/*	public Document getCORPOHKBySeqNo(YFSEnvironment env, String strPOSSeqNo) throws Exception {
		String strGetOrderList = "<Order BusinessDay='' DisplayLocalizedFieldInLocale='en_US'\r\n"
				+ "			    DocumentType='' DraftOrderFlag=\"\" EnterpriseCode='KOHLS-RETAIL'\r\n"
				+ "			    IgnoreOrdering='N' POSSequenceNumber='275'\r\n"
				+ "			    SellerOrganizationCode='9916' Status='1100.100' StatusQryType='NE' TerminalID='63'>\r\n"
				+ "			    <OrderBy>\r\n" + "			        <Attribute Desc='Y' Name='OrderDate'/>\r\n"
				+ "			    </OrderBy>\r\n" + "			    <yfcAdditionalInfo endpoint='MOTHERSHIP'/>\r\n"
				+ "			</Order>";
		Document docGetOrderList = SCXmlUtil.createFromString(strGetOrderList);
		docGetOrderList.getDocumentElement().setAttribute("POSSequenceNumber", strPOSSeqNo);
		Document docOpGetOrderList = callApi(env, docGetOrderList, KohlsPOCConstant.V_MOTHERSHIP, "getOrderList");
		return docOpGetOrderList;
	}*/


	/**
	 * 
	 * @return void transaction template
	 */
	private Document getTemplateForVoidTransaction() {
		String strVoidTran = "<Order Action='' Createts='' DocumentSubType='' DocumentType=''\r\n" + 
				"				EnterpriseCode='' IsFromRemote='' Modifyts='' OrderDate=''\r\n" + 
				"				OrderHeaderKey='' OrderNo='' OrganizationCode=''\r\n" + 
				"				OriginalPosSequenceNo='' OriginalTransactionNo=''\r\n" + 
				"				POSSequenceNumber='' PosSequenceNo=''\r\n" + 
				"				PostVoidConfirmedFlag='' SaleVoided=''\r\n" + 
				"				SellerOrganizationCode='' Status='' TerminalID='' TransactionNo=''>\r\n" + 
				"				<ChargeTransactionDetails>\r\n" + 
				"					<ChargeTransactionDetail/>\r\n" + 
				"				</ChargeTransactionDetails>\r\n" + 
				"				<PaymentMethods>\r\n" + 
				"					<PaymentMethod/>\r\n" + 
				"				</PaymentMethods>\r\n" + 
				"			</Order>";
		
		return SCXmlUtil.createFromString(strVoidTran); 
	}
	
	/**
	 * 
	 * @return template of makePaymentForPOS API
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private Document loadTemplateForPaymentPOS() throws ParserConfigurationException, SAXException, IOException {
		String strMakePaymentForPOS = "<?xml version='1.0' encoding='UTF-8'?>\r\n"
				+ "<MakePaymentForPOS CardsRequiringImprint='' ClientID=''\r\n"
				+ "    CustomerRewardsHash='' DisplayLocalizedFieldInLocale='en_US'\r\n"
				+ "    DocumentType='' EnterpriseCode='' ForceSignature=''\r\n"
				+ "    OperatorID='' OrderHeaderKey=''\r\n" + "    OrderNo='' OrganizationCode=''\r\n"
				+ "    RemainingToCharge='' StoreID='' TerminalID=''>\r\n" + "    <PaymentMethods>\r\n"
				+ "        <PaymentMethod Currency='' ExtraDetails1='' ExtraDetails10=''\r\n"
				+ "            ExtraDetails2='' ExtraDetails3='' ExtraDetails4=''\r\n"
				+ "            ExtraDetails5='' ExtraDetails6='' ExtraDetails7=''\r\n"
				+ "            ExtraDetails8='' ExtraDetails9='' PaymentType='CASH'\r\n"
				+ "            PaymentTypeGroup='' RequestedAmount='' SecondaryIDType=''/>\r\n"
				+ "    </PaymentMethods>\r\n" + "</MakePaymentForPOS>";
		return SCXmlUtil.createFromString(strMakePaymentForPOS);
	}
	
	/**
	 * 
	 * @return template for createOrderForPOS API
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private Document loadTemplateCreateOrderForPOS() throws ParserConfigurationException, SAXException, IOException {
		String strCreateOrderPOSXML = "<?xml version='1.0' encoding='UTF-8'?><Order DisplayLocalizedFieldInLocale='en_US' DocumentSubType=''\r\n"
				+ "		    DocumentType='' DraftOrderFlag='Y' EnterpriseCode=''\r\n"
				+ "		    EntryType='' IgnoreOrdering='Y' OperatorID=''\r\n"
				+ "		    OrderHeaderKey='' RequiresManagerOverride=''\r\n"
				+ "		    SellerOrganizationCode='' TerminalID='' TerminalType='kohls'>\r\n"
				+ "		    <AppContextInfo Channel='null'/>\r\n"
				+ "		    <PersonInfoBillTo AddressLine1='EMPTY ADDRESS'/>\r\n" + "		    <OrderLines>\r\n"
				+ "		        <OrderLine Action='CREATE' ApprovalCode=''\r\n"
				+ "		            BarcodeValue='' DeliveryMethod=''\r\n"
				+ "		            EnterpriseCode='' InStorePaymentRequired=''\r\n"
				+ "		            OrderHeaderKey='' OrderLineKey='' OrderNo='' ShipNode='' ValidateItem='Y'>\r\n"
				+ "		            <Item ItemID='' ProductClass='' UPCCode='' UnitOfMeasure=''/>\r\n"
				+ "		            <OrderLineTranQuantity OrderedQty='' SettledQuantity='' TransactionalUOM='EACH'/>\r\n"
				+ "		            <References>\r\n"
				+ "		                <Reference Name='entryMethod' Value='Keyed'/>\r\n"
				+ "		                <Reference Name='ExtnEmpDiscCode' Value='S'/>\r\n"
				+ "		                <Reference Name='ExtnIsRestrictedReturn' Value='N'/>\r\n"
				+ "		            </References>\r\n" + "		            <Extn ExtnItemClass='' ExtnItemDept=''\r\n"
				+ "		                ExtnItemSubClass='' ExtnMdxTaxCode='' ExtnTaxProductCode=''/>\r\n"
				+ "		            <CustomAttributes/>\r\n" + "		        </OrderLine>\r\n"
				+ "		    </OrderLines>\r\n" + "		    <CustomAttributes Boolean4='N'/>\r\n"
				+ "		    <Extn ExtnRequestDateTime=''/>\r\n" + "		</Order>";
		return SCXmlUtil.createFromString(strCreateOrderPOSXML);
	}
	
	@Override
	public void setProperties(Properties arg0) throws Exception {

	}

}
