package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCPAPostVoid {

	private String strPVPosSeqNo = null;
	private String strReqDate = null;
	private Element eleVoidedPaymentMethod = null;
	private Element eleVoidedOrder = null;
	private static final YFCLogCategory loggerForPAPostVoid = YFCLogCategory
			.instance(KohlsPoCPAPostVoid.class.getName());
	
	
	/**
	 * This method checks for record in KohlsSalesForPA table ;
	 * if record exists, PostVoidData column is updated
	 * if record does not exist, a new record is created in the 
	 * table.
	 * 
	 * KohlsCheckAndSaveOrigSales will invoke this method
	 * in case of PostVoid indicators given by gravity.
	 * The service will be modified to invoke this method
	 * 
	 * Current status - Unit Testing and Integration in progress.
	 * @param env
	 * @param docInput
	 * @return docCustomApiOutput
	 * @exception SAXParseException
	 * @exception Exception
	 * 
	 */
	public Document checkAndUpdatePostVoidData(YFSEnvironment env,
			Document inputDoc) {
		Document docApiInput = null;
		Document docAPIOutput = null;
		Document docApiInputForGetOrderDet = null;
		Document docCustomApiOutput = null;
		Element eleRoot = null;
		String strOHKey = null;
		try {
			loggerForPAPostVoid.beginTimer("----checkAndUpdatePostVoidData---");
			
			strOHKey = inputDoc.getDocumentElement().getAttribute(
					"OrderHeaderKey");
			loggerForPAPostVoid.debug("OrderHeaderKey is:::" + strOHKey);

			docApiInput = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			eleRoot = docApiInput.getDocumentElement();
			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);

			docApiInputForGetOrderDet = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderRoot = docApiInputForGetOrderDet
					.getDocumentElement();
			eleOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOHKey);

			docAPIOutput = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docApiInput);

		} catch (Exception e) {
			loggerForPAPostVoid.error(e);
		} finally {
			try {
				loggerForPAPostVoid
						.debug("Inside Finally Block for API Execution");
				if (YFCCommon.isVoid(docAPIOutput)) {
					docCustomApiOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSaveSalesDetails", docApiInputForGetOrderDet);
					loggerForPAPostVoid
							.debug("Inside Finally Block for Creating API Data");
				} else {
					docCustomApiOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSavePostVoidDetails",
							docApiInputForGetOrderDet);
					loggerForPAPostVoid
							.debug("Inside Finally Block for Change API Data");
				}

			} catch (Exception e) {
				loggerForPAPostVoid.error(e);
			}
			
			loggerForPAPostVoid.endTimer("----checkAndUpdatePostVoidData---");	
			
		}
		return docCustomApiOutput;
	}

	
	/**
	 * This is the main method which will prepare the final document to be
	 * posted to Tibco Queue This is still work in progress
	 * 
	 * @param env
	 * @param docInput
	 * @return Finaldoc
	 * @exception SAXParseException
	 * @exception Exception
	 * 
	 */

	public Document updateVoidAfterDocForPA(YFSEnvironment env,
			Document docInput) {
		
		Document Finaldoc = null;
		Element eleInvHeaderExtn = null;
		Element eleInvHeader = null;
		Element eleFinalRoot = null;
		String strOrderDate = null;
		String strPosSeqNo = null; 
		String strSellerOrgCode = null;
		String strTerminalId = null;
		String strIsFirstPAPV = null;
		try 
		{
			loggerForPAPostVoid.beginTimer("----updateVoidAfterDocForPA----");
			
			//strIsFirstPAPV=(String)env.getTxnObject(KohlsXMLLiterals.ATTR_IS_FIRST_PA_POST_VOID);
			
			if(YFCCommon.isStringVoid(strIsFirstPAPV))
			{
			Finaldoc = PrepareInputForDataCollect(env , docInput);
			
			
			Element EleOrder = (Element) XPathUtil.getNode(Finaldoc.getDocumentElement(),
					KohlsPOCConstant.X_INV_ORDER);
			
			String strOrderHkey = EleOrder.getAttribute("OrderHeaderKey");

			Document docInputForKohlsSalesForPA = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			Element eleRoot = docInputForKohlsSalesForPA.getDocumentElement();
			eleRoot.setAttribute("OrderHeaderKey", strOrderHkey);

			// Method call to fetch XML from KohlsSalesForPA custom table
			Document outputDoc = getStoredData(env, docInputForKohlsSalesForPA);
			
			// Changes for Defect # 3663 -- Begin -- 9/1/16
			
			eleVoidedOrder = (Element) XPathUtil.getNode(outputDoc.getDocumentElement(),
					"/KOHLSSalesForPA/PostVoidData/Order");
			
			NodeList ndlVoidedPaymentMethod = XPathUtil.getNodeList(outputDoc.getDocumentElement(),
					"/KOHLSSalesForPA/PostVoidData/Order/PaymentMethods/PaymentMethod[@PaymentReference6='PA']");
			
			int length = ndlVoidedPaymentMethod.getLength();
			
			eleVoidedPaymentMethod = (Element) ndlVoidedPaymentMethod.item(length - 1);
			
			
			if(loggerForPAPostVoid.isDebugEnabled())
				loggerForPAPostVoid.debug("PaymenMethod element is:::"+XMLUtil.getElementXMLString(eleVoidedPaymentMethod));
			
			// Changes for Defect # 3663 -- End -- 9/1/16
			
			//Fix for PR-434 - Start
			String voidedTraxNumber = XMLUtil.getAttribute(eleVoidedOrder, "TransactionNo");
			String voidedPOSSeqNumber = XMLUtil.getAttribute(eleVoidedOrder, "PosSequenceNo");
			//Finaldoc = getTransactionAuditDetails(env , Finaldoc);  
			//Using a new method to add the Audit detials for PostVoid Procedure ID-204
			Finaldoc = getTransactionAuditDetailsForPV(env , Finaldoc, voidedTraxNumber, voidedPOSSeqNumber);  
			//Fix for PR-434 - End
			
			Finaldoc = cloneOrderlines(Finaldoc);
			
			
			// Fetching PostVoided Order element from clob object to be populated at Extn level
			
			// Changes for Defect # 3663 -- Begin -- 9/1/16
			
			if(!YFCCommon.isVoid(eleVoidedOrder) && !YFCCommon.isVoid(eleVoidedPaymentMethod))
			{
			
						strOrderDate = eleVoidedOrder.getAttribute("OrderDate");
						strPosSeqNo = eleVoidedOrder.getAttribute("PosSequenceNo"); 
						strSellerOrgCode = eleVoidedPaymentMethod.getAttribute("StoreID");
						strTerminalId = eleVoidedPaymentMethod.getAttribute("TerminalID");
						
						loggerForPAPostVoid.debug("StoreID is "+strSellerOrgCode+"TerminalID is"+strTerminalId);	
			}
			
			// Changes for Defect # 3663 -- End -- 9/1/16
				
			// Fetching InvoiceHeader Element and creating child extn element
			
				eleInvHeader = (Element) XPathUtil.getNode(Finaldoc.getDocumentElement(),
					KohlsPOCConstant.XPATH_INVOICE_HEADER);
			
				eleInvHeaderExtn = XMLUtil.createChild(eleInvHeader, KohlsPOCConstant.A_EXTN);
			
				// Populating data at extn level
			
			eleInvHeaderExtn.setAttribute("ExtnOrderDate", strReqDate);
			eleInvHeaderExtn.setAttribute("ExtnPosSequenceNo", strPosSeqNo);
			eleInvHeaderExtn.setAttribute("ExtnShipNode",strSellerOrgCode );
			eleInvHeaderExtn.setAttribute("ExtnSellerOrganisationCode", strSellerOrgCode);
			eleInvHeaderExtn.setAttribute("ExtnTerminalID", strTerminalId);
			
			
				// Updated PosSequenceNo as fetched from TransactionAudits
				Element InvOrder = (Element) XPathUtil.getNode(Finaldoc.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER);
				
				// Setting Seller Organization Code and Terminal ID from PaymentMethod -- Begin -- 9/1/16
				
					InvOrder.setAttribute("SellerOrganizationCode", strSellerOrgCode);
					InvOrder.setAttribute("TerminalID", strTerminalId);
				
				// Setting Seller Organization Code and Terminal ID from PaymentMethod -- End -- 9/1/16
					
			if(!YFCCommon.isStringVoid(strPVPosSeqNo))
				{
					InvOrder.setAttribute("PosSequenceNo", strPVPosSeqNo);
				}
			else
				{
				InvOrder.setAttribute("PosSequenceNo", strPosSeqNo);
				}
			// Setting metadata attributes 
			Finaldoc.getDocumentElement().setAttribute("MessageType", "PA_VoidAfter");
			Finaldoc.getDocumentElement().setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
			}
			else
			{
				Finaldoc = YFCDocument.createDocument("InvoiceDetail").getDocument();
				eleFinalRoot = Finaldoc.getDocumentElement();
				//eleFinalRoot.setAttribute(KohlsXMLLiterals.ATTR_IS_FIRST_PA_POST_VOID, KohlsPOCConstant.NO);
			}
			
			loggerForPAPostVoid.endTimer("----updateVoidAfterDocForPA----");
		} catch (Exception e) {
			loggerForPAPostVoid.error(e);
		}

		return Finaldoc;
	}

	/**
	 * This function parses a getOrderDetails output into a clob object to be
	 * inserted into KohlsSalesForPA custom table in post void scenarios.
	 * 
	 * @param env
	 * @param docInput
	 * @return docInputForPostVoidData
	 * @exception Exception
	 * 
	 */
	public Document preparePostVoidDataClob(YFSEnvironment env,
			Document docInput) {
		try {
			
			loggerForPAPostVoid.beginTimer("----preparePostVoidDataClob----");
			Element elePAOrder = (Element) XPathUtil.getNode(docInput,
					"Order");

			String strOHkey = elePAOrder
					.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

			String PADataXML = XMLUtil.getXMLString(docInput);

			Document docInputForPostVoidData = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();

			Element eleInputForPAData = docInputForPostVoidData
					.getDocumentElement();

			eleInputForPAData.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOHkey);

			eleInputForPAData.setAttribute("PostVoidData", PADataXML);

			return docInputForPostVoidData;

		} catch (Exception e) {

			e.printStackTrace();

		}

		loggerForPAPostVoid.endTimer("----preparePostVoidDataClob----");
		return docInput;

	}

	/**
	 * This method makes an API call to KohlsSalesForPA custom table and parses
	 * the clob columns in document objects and returns the final document
	 * 
	 * @param env
	 * @param docInput
	 * @return outputDoc
	 * @exception SAXParseException
	 * @exception Exception
	 * 
	 */

	public Document getStoredData(YFSEnvironment env, Document docInput) {
		Document outputDoc = null;
		try {
			loggerForPAPostVoid.beginTimer("getStoredData --- Begin ");
			
			
			if(loggerForPAPostVoid.isDebugEnabled())
				loggerForPAPostVoid.debug("API Input to GetKohlsSalesDetails :::"
						+ XMLUtil.getXMLString(docInput));

			// API call to fetch data from db
			outputDoc = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInput);

			Element eleRootElement = outputDoc.getDocumentElement();

			// Fetching and parsing clob into string objects
			String strSalesClob = eleRootElement
					.getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);

			loggerForPAPostVoid.debug("Clob Object for sales is :::"
					+ strSalesClob);

			String strPAPostVoidClob = eleRootElement
					.getAttribute("PostVoidData");

			loggerForPAPostVoid.debug("Clob Object for PA Post Void is :::"
					+ strPAPostVoidClob);

			if (!strSalesClob.isEmpty()) {
				Document docClobData = XMLUtil.getDocument(strSalesClob);
				eleRootElement.setAttribute(
						KohlsPOCConstant.ATTR_ORIG_SALE_DATA,
						KohlsPOCConstant.BLANK);
				Element eleNewClob = docClobData.getDocumentElement();
				XMLUtil.importElement(eleRootElement, eleNewClob);
			}

			if (!strPAPostVoidClob.isEmpty()) {
				Document docClobData = XMLUtil.getDocument(strPAPostVoidClob);
				eleRootElement.setAttribute("PostVoidData",
						KohlsPOCConstant.BLANK);
				Element elePAPostVoidData = XMLUtil.createChild(
						eleRootElement, "PostVoidData");
				Element eleNewClob = docClobData.getDocumentElement();
				XMLUtil.importElement(elePAPostVoidData, eleNewClob);
				
				if(loggerForPAPostVoid.isDebugEnabled())
					loggerForPAPostVoid.debug("After Appending :::"
							+ XMLUtil.getElementXMLString(elePAPostVoidData));
			}
			
			
			if(loggerForPAPostVoid.isDebugEnabled())
				loggerForPAPostVoid.debug("After updated ; Document output :::"
						+ XMLUtil.getXMLString(outputDoc));

			loggerForPAPostVoid.endTimer("getStoredData --- End ");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return outputDoc;
	}

	public Document PrepareInputForDataCollect(YFSEnvironment env , Document Inputdoc)
	{
		String strOHKey = null;
		String strInvoiceKey = null; 
		Document docInputForChargeTransDet = null;
		Document docInputForGetOrderInvDet = null;
		Document docOutputForChargeTransDet = null;
		Document docOutputForGetOrderInvDet = null;
		try
		{
			loggerForPAPostVoid.beginTimer("-----PrepareInputForDataCollect----");
			
			strOHKey = Inputdoc.getDocumentElement().getAttribute("OrderHeaderKey");
			
			docInputForChargeTransDet = YFCDocument.createDocument(
					"ChargeTransactionDetail").getDocument();
			Element eleRoot = docInputForChargeTransDet.getDocumentElement();
			eleRoot.setAttribute("OrderHeaderKey", strOHKey);
			
			docOutputForChargeTransDet = KOHLSBaseApi.invokeAPI(env, "getChargeTransactionList", docInputForChargeTransDet); 
			
			strInvoiceKey = getInvoiceKey(docOutputForChargeTransDet);
			
			docInputForGetOrderInvDet = YFCDocument.createDocument(
					"GetOrderInvoiceDetails").getDocument();
			eleRoot = docInputForGetOrderInvDet.getDocumentElement();
			eleRoot.setAttribute("InvoiceKey", strInvoiceKey);
			
			docOutputForGetOrderInvDet = KOHLSBaseApi.invokeService(env,"getOrderInvDetForPV", docInputForGetOrderInvDet);
			
			//Changes for PR-274 - Start
         if ( !YFCCommon.isVoid( docOutputForGetOrderInvDet ) )
         {
            if ( YFCLogUtil.isDebugEnabled() )
            {
               loggerForPAPostVoid.debug( "KohlsPoCPAPostVoid.PrepareInputForDataCollect docOutputForGetOrderInvDet=" + XMLUtil.getXMLString( docOutputForGetOrderInvDet ) );
            }

            Element eleOrder = (Element) ( XPathUtil.getNodeList( docOutputForGetOrderInvDet.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER ).item( 0 ) );
            if ( !YFCCommon.isVoid( eleOrder ) )
            {
               Element elePromotions = (Element) eleOrder.getElementsByTagName( KohlsPOCConstant.E_PROMOTIONS ).item( 0 );
               if ( !YFCCommon.isVoid( elePromotions ) )
               {
                  String sPromotionApplied = null;
                  Element elePromotion = null;
                  Element eleExtn = null;
                  NodeList nlPromotion = elePromotions.getElementsByTagName( KohlsPOCConstant.E_PROMOTION );
                  if ( !YFCCommon.isVoid( nlPromotion ) )
                  {
                     for ( int i = 0; i < nlPromotion.getLength(); i++ )
                     {
                        elePromotion = (Element) nlPromotion.item( i );
                        eleExtn = (Element) elePromotion.getElementsByTagName( KohlsPOCConstant.A_EXTN ).item( 0 );
                        String sExtnActivationBarCode = eleExtn.getAttribute( KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE );
                        sPromotionApplied = elePromotion.getAttribute( KohlsPOCConstant.A_PROMOTION_APPLIED );
                        String sPromotionType = elePromotion.getAttribute( KohlsPOCConstant.A_PROMOTION_TYPE );
                        if ( KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase( sPromotionType ) && !YFCCommon.isVoid( sExtnActivationBarCode ) )
                        {
                           sPromotionApplied = "Y";
                           elePromotion.setAttribute( KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES );
                        }
                        if ( KohlsPOCConstant.NO.equalsIgnoreCase( sPromotionApplied ) )
                        {
                        	//Fix for PR-699 - Start
                        	if( KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase( sPromotionType ) && !YFCCommon.isVoid( sExtnActivationBarCode ) ){
                        		Element eleKCSPromosForPV = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
                        		Element eleKCSPromoForPV = XMLUtil.createChild(eleKCSPromosForPV, KohlsPOCConstant.E_PROMOTION);
                        		XMLUtil.setAttribute(eleKCSPromoForPV, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
                        		XMLUtil.setAttribute(eleKCSPromoForPV, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
                        		Element eleKCSExtnForPV = XMLUtil.createChild(eleKCSPromoForPV, KohlsPOCConstant.E_EXTN);
                        		XMLUtil.setAttribute(eleKCSExtnForPV, KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE, sExtnActivationBarCode);
                        		if ( YFCLogUtil.isDebugEnabled() )
                                {
                                   loggerForPAPostVoid.debug( "eleKCSPromosForPV added to Order element before removing all the promotions: " + XMLUtil.getElementXMLString( eleOrder ) );
                                }
                        	}
                        	//Fix for PR-688 - End
                           eleOrder.removeChild( elePromotions );
                        }
                     }
                     if ( YFCLogUtil.isDebugEnabled() )
                     {
                        loggerForPAPostVoid.debug( "eleKCSPromosForPV added to Order element after removing all the promotions: " + XMLUtil.getElementXMLString( eleOrder ) );
                     }
                  }
               }
            }
         }
			//Changes for PR-274 - End
			
			loggerForPAPostVoid.endTimer("-----PrepareInputForDataCollect-----");
		}
		catch(Exception e)
		{
			loggerForPAPostVoid.error(e);
		}
		return docOutputForGetOrderInvDet;
	}
	
	public String getInvoiceKey(Document Inputdoc)
	{
		String strKey = null;
		try
		{
			
			loggerForPAPostVoid.beginTimer("getInvoiceKey");
			
			
			if(loggerForPAPostVoid.isDebugEnabled())
				loggerForPAPostVoid.debug("Input to method is:::"+XMLUtil.getXMLString(Inputdoc));
			
			NodeList ndlChargeTransDetail = XPathUtil.getNodeList(Inputdoc, "ChargeTransactionDetails/ChargeTransactionDetail[@ChargeType='ADJUSTMENTS']");
			
			int length = ndlChargeTransDetail.getLength();
			
			for(int i=0;i<length;i++)
			{
				
				Element eleCurrentChargeTrans = (Element) ndlChargeTransDetail.item(i);
				
				if(loggerForPAPostVoid.isDebugEnabled())
					loggerForPAPostVoid.debug("Current ChargeTransaction Element is ::"+XMLUtil.getElementXMLString(eleCurrentChargeTrans));
				
				String strChargeType = eleCurrentChargeTrans.getAttribute("ChargeType");
				
				String strDebitAmount = eleCurrentChargeTrans.getAttribute("DebitAmount");
				
				Double longvalue = Double.parseDouble(strDebitAmount);
				
				if(longvalue < 0 )
				{
					//System.out.println("Inside negativeDebitValue storing TransactionDate");
				
					strReqDate = eleCurrentChargeTrans.getAttribute("TransactionDate");
					
				//	System.out.println("Current TransactionDate is :::"+strReqDate);
				}
				
				
				
				if(!YFCCommon.isStringVoid(strChargeType))
				{
						if("ADJUSTMENTS".equalsIgnoreCase(strChargeType))
							{
								loggerForPAPostVoid.debug("Inside ChargeType ADJUSTMENT block");
								strKey = eleCurrentChargeTrans.getAttribute("OrderInvoiceKey");
								loggerForPAPostVoid.debug("InvoiceKey is :::"+strKey);
							}
				}
				
				
			}
			
			loggerForPAPostVoid.endTimer("getInvoiceKey");
		}
		catch(Exception e)
		{
			loggerForPAPostVoid.error(e);
		}
		return strKey;
	}

	public Document getTransactionAuditDetails(YFSEnvironment env , Document Inputdoc)
	{
		try
		{
			loggerForPAPostVoid.beginTimer("getTransactionAuditDetails");
			Element eleOrder = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER);
			Element eleInvHeader = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.XPATH_INVOICE_HEADER);
			String strOrderNo = eleOrder.getAttribute("OrderNo"); 
			String strSellerOrgCode = eleVoidedPaymentMethod.getAttribute("StoreID");
			
			
			if(loggerForPAPostVoid.isDebugEnabled())
				loggerForPAPostVoid
				.debug("Voided payment Method element present in getTransactionAuditDetails method"
						+ XMLUtil.getElementXMLString(eleVoidedPaymentMethod));
			
			// Creating Transaction Audits for Post Void -- Begin
			
			Document docAPIInput = YFCDocument.createDocument("TransactionAudit").getDocument();
			Element eleAPIInput = docAPIInput.getDocumentElement();
			eleAPIInput.setAttribute("OrderNumber", eleOrder.getAttribute("OrderNo"));
			eleAPIInput.setAttribute("OrganizationCode",strSellerOrgCode);
			eleAPIInput.setAttribute("OperatorID", eleVoidedPaymentMethod.getAttribute("OperatorID"));
			eleAPIInput.setAttribute("Action", KohlsPOCConstant.ACTION_CREATE);
			eleAPIInput.setAttribute("DateTime", eleOrder.getAttribute("OrderDate"));
			eleAPIInput.setAttribute("TerminalID", eleVoidedPaymentMethod.getAttribute("TerminalID"));
			eleAPIInput.setAttribute("ProcedureID", "postVoid");
			eleAPIInput.setAttribute("DocumentType", KohlsPOCConstant.SO_DOCUMENT_TYPE);
			
			Document orderListDocOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),"manageTransactionAuditForPOS", docAPIInput);
			
			// Creating Transaction Audits for Post Void -- End
			
			loggerForPAPostVoid.debug("Order Number and Seller Organization Code are ::"+strOrderNo+" "+strSellerOrgCode);
			
			Document inTranDoc = YFCDocument.createDocument("TransactionAudit").getDocument();
			Element eleInput = inTranDoc.getDocumentElement();
			eleInput.setAttribute("OrderNumber", strOrderNo);
			eleInput.setAttribute("OrganizationCode",strSellerOrgCode);
			
			// Fix for Picking PostVoid Transaction Aduit Details -- Begin
			
			//eleInput.setAttribute("ProcedureID","204");
			
			// Fix for Picking PostVoid Transaction Aduit Details -- End

			//Document orderListDocOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),"getTransactionAuditListForPOS", inTranDoc);
			
			NodeList nlElements = orderListDocOutput.getElementsByTagName("TransactionAudit");
			if(nlElements.getLength()>0){
			Element tranAudit = (Element) nlElements.item(0);
			strPVPosSeqNo = tranAudit.getAttribute("TransactionNumber"); 
			strPVPosSeqNo = strPVPosSeqNo.substring(18, 22);
			Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
			XMLUtil.importElement(eleTranAudits, tranAudit);
			
			// Setting Time Stamps for PA and PA Post Void Txn -- Begin
			
			eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
			eleInvHeader.setAttribute("DateInvoiced",tranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
			
			// Setting Time Stamps for PA and PA Post Void Txn  -- End
			
			}
			else
			{
				
				eleInput.setAttribute("ProcedureID","213");
				
				orderListDocOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),"getTransactionAuditListForPOS", inTranDoc);
				
				nlElements = orderListDocOutput.getElementsByTagName("TransactionAudit");
				if(nlElements.getLength()>0){
				Element tranAudit = (Element) nlElements.item(0);
				
				strPVPosSeqNo = tranAudit.getAttribute("TransactionNumber"); 
				strPVPosSeqNo = strPVPosSeqNo.substring(18, 22);
				Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
				XMLUtil.importElement(eleTranAudits, tranAudit);
				
				// Setting Time Stamps for PA and PA Post Void Txn -- Begin
				
				eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
				eleInvHeader.setAttribute("DateInvoiced",tranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
				
				// Setting Time Stamps for PA and PA Post Void Txn  -- End
				
				
			}
			}
			loggerForPAPostVoid.endTimer("getTransactionAuditDetails");
		}	
		catch(Exception e)
		{
			loggerForPAPostVoid.error(e);
		}
		
		return Inputdoc;
	}
	
	public Document cloneOrderlines(Document docInput)
	{
		Element eleCurrentOrderline = null;
		Element eleClone = null;
		try
		{
			NodeList ndlOrderline = XPathUtil.getNodeList(docInput.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINE);
			Element eleOrderlines = (Element) XPathUtil.getNode(docInput.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINES);
			int length = ndlOrderline.getLength();
			
			for(int i=0;i<length;i++)
			{
				eleCurrentOrderline = (Element) ndlOrderline.item(i);
				eleCurrentOrderline.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
				eleClone =	(Element) eleCurrentOrderline.cloneNode(true);
				eleClone.setAttribute(KohlsPOCConstant.A_TYPE,"Return");
				XMLUtil.appendChild(eleOrderlines, eleClone);
				
			}
			
			Integer TotalNumberOfRecords = length*2;
			eleOrderlines.setAttribute("TotalNumberOfRecords",TotalNumberOfRecords.toString());
					
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	return docInput;	
	}
	
	//Fix for PR-434 - Start
	//Using a new method to add the Audit detials for PostVoid Procedure ID-204
	public Document getTransactionAuditDetailsForPV(YFSEnvironment env , Document Inputdoc, String voidedTraxNumber, String voidedPOSSeqNumber)
	{
		loggerForPAPostVoid.beginTimer("***** getTransactionAuditDetailsForPV - Begin *****");
		try
		{
			Element eleOrder = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER);
			Element eleInvHeader = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.XPATH_INVOICE_HEADER);
			String strOrderNo = eleOrder.getAttribute("OrderNo"); 
			String strSellerOrgCode = eleVoidedPaymentMethod.getAttribute("StoreID");
			if(loggerForPAPostVoid.isDebugEnabled()){
				loggerForPAPostVoid.debug("Voided payment Method element present in getTransactionAuditDetails method"
						+ XMLUtil.getElementXMLString(eleVoidedPaymentMethod));
			}
			Document inTranDoc = YFCDocument.createDocument("TransactionAudit").getDocument();
			Element eleInput = inTranDoc.getDocumentElement();
			eleInput.setAttribute("OrderNumber", strOrderNo);
			eleInput.setAttribute("OrganizationCode",strSellerOrgCode);
			eleInput.setAttribute("ProcedureID","204");

			Document getTraxAuditListOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
					"getTransactionAuditListForPOS", inTranDoc);
			//loggerForPAPostVoid.debug("The getTraxAuditListOutput Document is : " +XMLUtil.getXMLString(getTraxAuditListOutput));
			NodeList nlElements = getTraxAuditListOutput.getElementsByTagName("TransactionAudit");
			
			//Check if Audit entry for procedure - 204 is already updated
			if(nlElements.getLength()>0){
				Element eleGetTranAudit = (Element) nlElements.item(0);
				strPVPosSeqNo = eleGetTranAudit.getAttribute("TransactionNumber"); 
				strPVPosSeqNo = strPVPosSeqNo.substring(18, 22);
				Element eleGetTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
				XMLUtil.importElement(eleGetTranAudits, eleGetTranAudit);
				if(loggerForPAPostVoid.isDebugEnabled()){
					loggerForPAPostVoid.debug("The eleTranAudits element imported from getTraxAudit API : " +XMLUtil.getElementXMLString(eleGetTranAudits));
				}
				eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
				eleInvHeader.setAttribute("DateInvoiced",eleGetTranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
			}
			
			//If entry for 204 is not available then, create an entry by calling manageTransactionAuditForPOS
			else
			{
				Document docManageTraxAuditInput = YFCDocument.createDocument("TransactionAudit").getDocument();
				Element elemanageTraxAuditInput = docManageTraxAuditInput.getDocumentElement();
				elemanageTraxAuditInput.setAttribute("OrderNumber", eleOrder.getAttribute("OrderNo"));
				elemanageTraxAuditInput.setAttribute("OrganizationCode",strSellerOrgCode);
				elemanageTraxAuditInput.setAttribute("OperatorID", eleVoidedPaymentMethod.getAttribute("OperatorID"));
				elemanageTraxAuditInput.setAttribute("Action", KohlsPOCConstant.ACTION_CREATE);
				elemanageTraxAuditInput.setAttribute("DateTime", eleOrder.getAttribute("OrderDate"));
				elemanageTraxAuditInput.setAttribute("TerminalID", eleVoidedPaymentMethod.getAttribute("TerminalID"));
				elemanageTraxAuditInput.setAttribute("ProcedureID", "postVoid");
				elemanageTraxAuditInput.setAttribute("DocumentType", KohlsPOCConstant.SO_DOCUMENT_TYPE);
				elemanageTraxAuditInput.setAttribute("OriginalTransactionNumber", voidedTraxNumber);
				//elemanageTraxAuditInput.setAttribute("TransactionNumber", voidedTraxNumber);
				loggerForPAPostVoid.debug("The voidedPOSSeqNumber and voidedTraxNumber value are : " 
						+voidedPOSSeqNumber + "and" +voidedTraxNumber);
				//String str = voidedTraxNumber.substring(18,22);
				/*int newTraxSeqNumber = Integer.parseInt(voidedPOSSeqNumber);
					newTraxSeqNumber++;
					loggerForPAPostVoid.debug("The newTraxSeqNumber value are : " +newTraxSeqNumber);
					String newTraxNum = voidedTraxNumber.substring(0, 18).concat(String.valueOf(newTraxSeqNumber));*/
				String tempPVTranxNumber = voidedTraxNumber.substring(18,22);
				Document inGetTerminalStatusDoc = YFCDocument.createDocument("TerminalStatus").getDocument();
				Element eleGetTerminalStatus = inGetTerminalStatusDoc.getDocumentElement();
				eleGetTerminalStatus.setAttribute("OrganizationCode",strSellerOrgCode);
				eleGetTerminalStatus.setAttribute("TerminalID", eleVoidedPaymentMethod.getAttribute("TerminalID"));
				if(loggerForPAPostVoid.isDebugEnabled()){
					loggerForPAPostVoid.debug("The inGetTerminalStatusDoc values is : " +XMLUtil.getXMLString(inGetTerminalStatusDoc));
				}
				
				//Call getTerminalStatusDetailsForPOS to get the available Seq no for PostVoid Transaction.
				Document getTerminalStatusOut = KOHLSBaseApi.invokeAPI(env,"getTerminalStatusDetailsForPOS", inGetTerminalStatusDoc);
				Element eleGetTerminalStatusOut = getTerminalStatusOut.getDocumentElement();
				String postVoidSeqNumber = XMLUtil.getAttribute(eleGetTerminalStatusOut, "SequenceNumber");
				String postVoidTranNumber = tempPVTranxNumber.concat(postVoidSeqNumber);  
				loggerForPAPostVoid.debug("The postVoidTranNumber and postVoidSeqNumber values are : " +postVoidTranNumber + "and" +postVoidSeqNumber);
				elemanageTraxAuditInput.setAttribute("TransactionNumber", postVoidTranNumber);
				elemanageTraxAuditInput.setAttribute("POSSequenceNumber", postVoidSeqNumber);
				
				//Call manageTransactionAuditForPOS along with TranxNo and SeqNo.
				Document docManageTraxAuditOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
						"manageTransactionAuditForPOS", docManageTraxAuditInput);
				NodeList eleManageTraxAuditOutput = docManageTraxAuditOutput.getElementsByTagName("TransactionAudit");
				
				//Add the TranAudit details of ProcedureId-204 to the invoice message 
				if(eleManageTraxAuditOutput.getLength()>0){
					Element eleManageTranAudit = (Element) eleManageTraxAuditOutput.item(0);
					strPVPosSeqNo = String.valueOf(postVoidSeqNumber);
					Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
					XMLUtil.importElement(eleTranAudits, eleManageTranAudit);
					if(loggerForPAPostVoid.isDebugEnabled()){
						loggerForPAPostVoid.debug("The eleTranAudits element imported from ManageTraxAudit API : " +XMLUtil.getElementXMLString(eleTranAudits));
					}
					eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
					eleInvHeader.setAttribute("DateInvoiced",eleManageTranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
				}
				loggerForPAPostVoid.debug("Order Number and Seller Organization Code are ::"+strOrderNo+" "+strSellerOrgCode);
			}

			loggerForPAPostVoid.endTimer("***** getTransactionAuditDetailsForPV - End *****");
		}	
		catch(Exception e)
		{
			loggerForPAPostVoid.error(e);
		}

		return Inputdoc;
	}
	//Fix for PR-434 - End
}
