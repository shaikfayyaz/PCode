package com.kohls.poc.api;

import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * 
 * @author TKMAL8R This class is written as part of CPE-9494. PoC to stamp
 *         attributes from Customer Information Prompt onto Order. When the
 *         customer provides their Contact/Billing information, PoC needs to
 *         stamp this information in the appropriate place in the order details
 *         so this information can be acted upon by the OMSe agents for Omni
 *         fulfillment and payment processing.
 */
public class KohlsPoCUpdateCustomerInfo implements YIFCustomApi {

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCUpdateCustomerInfo.class.getName());

	/**
	 * 
	 * @param env
	 * @param inDoc
	 * @throws Exception
	 */
	public void updateCustomerInfo(YFSEnvironment env, Document inDoc) {
		logger.beginTimer("KohlsPoCUpdateCustomerInfo.updateCustomerInfo - BeginTimer");

		if (logger.isDebugEnabled()) {
			logger.debug("The input XML to KohlsPoCUpdateCustomerInfo.updateCustomerInfo - "+ KohlsXMLUtil.getXMLString(inDoc));
		}
		try {
			Element elePersonInfoBTFromInDoc = (Element) inDoc.getDocumentElement()
					.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO).item(0);
			Element elePersonInfoMarkForInDoc = (Element) inDoc.getDocumentElement()
	               .getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_MARK_FOR).item(0);

			if (!YFCCommon.isVoid(elePersonInfoBTFromInDoc)) {

				// call GetOrderList
				Document docInOrder = XMLUtil.createDocument(KohlsConstants.ORDER);
				Element eleInOrder = docInOrder.getDocumentElement();
				String ordHeaderKey = inDoc.getDocumentElement().getAttribute(KohlsConstants.ORDER_HEADER_KEY);
				String extnTextNotificationInd = "";
            Element eleOrderIn = (Element) inDoc.getElementsByTagName(KohlsConstants.ORDER).item(0);
            if ( !YFCCommon.isVoid( eleOrderIn ) ) {
               Element eleExtnIn = (Element) eleOrderIn.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
               if ( !YFCCommon.isVoid( eleExtnIn ) && eleExtnIn.hasAttribute( KohlsConstants.EXTN_TEXT_NOTIFICATION_IND ) ) {
                  extnTextNotificationInd = eleExtnIn.getAttribute( KohlsConstants.EXTN_TEXT_NOTIFICATION_IND) ;
               }
            }
				if (!YFCCommon.isVoid(ordHeaderKey)) {
					eleInOrder.setAttribute(KohlsConstants.ORDER_HEADER_KEY, ordHeaderKey);
					String strTemplate = "<OrderList> <Order OrderHeaderKey='' > <Extn ExtnIsOmni=''/> <PersonInfoBillTo/>  <PersonInfoMarkFor/> <OrderLines> <OrderLine OrderLineKey=''/> <PersonInfoMarkFor/> </OrderLines> </Order> </OrderList>";
					YFCDocument yfcDocTemplate = YFCDocument.parse(strTemplate);
					Document docTemplate = yfcDocTemplate.getDocument();

					Document docOutGetOrderList = KOHLSBaseApi.invokeAPI(env, docTemplate,KohlsPOCConstant.API_GET_ORDER_LIST, docInOrder);

					Element eleOrder = (Element) docOutGetOrderList.getElementsByTagName(KohlsConstants.ORDER).item(0);
					Element eleExtn = (Element) eleOrder.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
					String isOmni = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI);
					logger.debug("KohlsPoCUpdateCustomerInfo.updateCustomerInfo - Value of ExtnIsOmni", isOmni);

					logger.debug("KohlsPoCUpdateCustomerInfo.updateCustomerInfo - Calling CommonCode to fetch OMNI2_ENABLED");
					Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env,KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
					String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);

					logger.debug("KohlsPoCUpdateCustomerInfo.updateCustomerInfo - Value of omni2Enabled", omni2Enabled);
					// Invoke changeOrder if ExtnIsOMNI is Y and common code OMNI2_CONFIG is enabled
					if (KohlsPOCConstant.YES.equals(isOmni) && KohlsPOCConstant.YES.equals(omni2Enabled)) {
						// Input to changeOrder
					   
					   if( "Y".equals( extnTextNotificationInd ) ) {
					      eleExtn.setAttribute( KohlsConstants.EXTN_TEXT_NOTIFICATION_IND, extnTextNotificationInd );
					      eleExtn.setAttribute( KohlsConstants.EXTN_TEXT_PHONE, elePersonInfoBTFromInDoc.getAttribute( KohlsXMLLiterals.A_DAY_PHONE ) );
					   } 
						Document docInChangeOrder = XMLUtil.createDocument(eleOrder);

						// InDoc's personInfoBT attributes
						Element inPersonInfoBT = (Element) docInChangeOrder.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO).item(0);
						inPersonInfoBT.removeAttribute(KohlsXMLLiterals.A_PERSONINFOKEY);

						// set changeOrder input PersonInfo attributes
						inPersonInfoBT.setAttribute(KohlsXMLLiterals.A_FIRST_NAME,
								elePersonInfoBTFromInDoc.getAttribute(KohlsXMLLiterals.A_FIRST_NAME));
						inPersonInfoBT.setAttribute(KohlsXMLLiterals.A_LAST_NAME,
								elePersonInfoBTFromInDoc.getAttribute(KohlsXMLLiterals.A_LAST_NAME));
						inPersonInfoBT.setAttribute(KohlsXMLLiterals.A_EMAIL_ID,
								elePersonInfoBTFromInDoc.getAttribute(KohlsXMLLiterals.A_EMAIL_ID));
						inPersonInfoBT.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,
								elePersonInfoBTFromInDoc.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
						inPersonInfoBT.setAttribute(KohlsXMLLiterals.A_DAY_PHONE,
								elePersonInfoBTFromInDoc.getAttribute(KohlsXMLLiterals.A_DAY_PHONE));
					   
						

                  // set changeOrder input PersonInfoMarkFor attributes
                  if ( !YFCCommon.isVoid( elePersonInfoMarkForInDoc ) )
                  {
                	  //CPE-11971 changes BEGIN
                	  Element eleOrderLines =  (Element) docInChangeOrder.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);
                	  NodeList nlOrderLine = eleOrderLines.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
                	  int nlLength = nlOrderLine.getLength();
                	  for(int count = 0; count < nlLength ; count++) {
                		  Element eleOrderLine = (Element) nlOrderLine.item(count);
                		  Element inPersonInfoMarkFor = (Element) eleOrderLine.getElementsByTagName( KohlsXMLLiterals.E_PERSON_INFO_MARK_FOR ).item( 0 );
                		  if ( YFCCommon.isVoid( inPersonInfoMarkFor ) )
                          {
                             Element elementPersonInfoMarkFor = docInChangeOrder.createElement( KohlsXMLLiterals.E_PERSON_INFO_MARK_FOR );
                             eleOrderLine.appendChild( elementPersonInfoMarkFor );
                             elementPersonInfoMarkFor.setAttribute( KohlsXMLLiterals.A_FIRST_NAME, elePersonInfoMarkForInDoc.getAttribute( KohlsXMLLiterals.A_FIRST_NAME ) );
                             elementPersonInfoMarkFor.setAttribute( KohlsXMLLiterals.A_LAST_NAME, elePersonInfoMarkForInDoc.getAttribute( KohlsXMLLiterals.A_LAST_NAME ) );
                             elementPersonInfoMarkFor.setAttribute( KohlsXMLLiterals.A_EMAIL_ID, elePersonInfoMarkForInDoc.getAttribute( KohlsXMLLiterals.A_EMAIL_ID ) );
                          }
                          else
                          {
                             if ( inPersonInfoMarkFor.hasAttribute( KohlsXMLLiterals.A_PERSONINFOKEY ) )
                             {
                                inPersonInfoMarkFor.removeAttribute( KohlsXMLLiterals.A_PERSONINFOKEY );
                             }
                             inPersonInfoMarkFor.setAttribute( KohlsXMLLiterals.A_FIRST_NAME, elePersonInfoMarkForInDoc.getAttribute( KohlsXMLLiterals.A_FIRST_NAME ) );
                             inPersonInfoMarkFor.setAttribute( KohlsXMLLiterals.A_LAST_NAME, elePersonInfoMarkForInDoc.getAttribute( KohlsXMLLiterals.A_LAST_NAME ) );
                             inPersonInfoMarkFor.setAttribute( KohlsXMLLiterals.A_EMAIL_ID, elePersonInfoMarkForInDoc.getAttribute( KohlsXMLLiterals.A_EMAIL_ID ) );
                          }
                		  
                	  }
                     // InDoc's PersonInfoMarkFor attributes
                	//CPE-11971 changes END
                     
                  }

						if (logger.isDebugEnabled()) {
							logger.debug("KohlsPoCUpdateCustomerInfo.updateCustomerInfo - Input to ChangeOrder",
									XMLUtil.getXMLString(docInChangeOrder));
						}
						KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, docInChangeOrder);
					}
				}
			}
		}catch(Exception e) {
			YFSException yfsEx = new YFSException();
			yfsEx.setErrorCode(KohlsPOCConstant.CUST_INFO_ERR_CODE);
			yfsEx.setErrorDescription(KohlsPOCConstant.CUST_INFO_ERR_CODE_DESC);
			throw yfsEx;
		}
		logger.endTimer("KohlsPoCUpdateCustomerInfo.updateCustomerInfo - EndTimer");

	}

	@Override
	public void setProperties(Properties arg0) throws Exception {

	}

}
