package com.kohls.poc.api;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCPSAPostVoid {

	private String strPVPosSeqNo = null;
	//private String strReqDate = null;
	private Element eleVoidedPaymentMethod = null;
	private Element eleVoidedOrder = null;
	private static final YFCLogCategory loggerForPSAPostVoid = YFCLogCategory
			.instance(KohlsPoCPSAPostVoid.class.getName());
	
	
	/**
	 * This method checks for record in KohlsSalesForPsa table ;
	 * if record exists, PostVoidData column is updated
	 * if record does not exist, a new record is created in the 
	 * table.
	 * 
	 * KohlsCheckAndSaveOrigSales will invoke this method
	 * in case of PostVoid indicators given by gravity.
	 * The service will be modified to invoke this method
	 * 
	 * Current status - Unit Testing and Integration in progress.
	 * @param env
	 * @param docInput
	 * @return docCustomApiOutput
	 * @exception SAXParseException
	 * @exception Exception
	 * 
	 */
	public Document checkAndUpdatePostVoidData(YFSEnvironment env,
			Document inputDoc) {
		Document docApiInput = null;
		Document docAPIOutput = null;
		Document docApiInputForGetOrderDet = null;
		Document docCustomApiOutput = null;
		Element eleRoot = null;
		String strOHKey = null;
		try {
			loggerForPSAPostVoid.beginTimer("----checkAndUpdatePostVoidData---");
			
			strOHKey = inputDoc.getDocumentElement().getAttribute(
					"OrderHeaderKey");
			loggerForPSAPostVoid.debug("OrderHeaderKey is:::" + strOHKey);

			docApiInput = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			eleRoot = docApiInput.getDocumentElement();
			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);

			docApiInputForGetOrderDet = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderRoot = docApiInputForGetOrderDet
					.getDocumentElement();
			eleOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOHKey);

			docAPIOutput = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docApiInput);

		} catch (Exception e) {
			loggerForPSAPostVoid.error(e);
		} finally {
			try {
				loggerForPSAPostVoid
						.debug("Inside Finally Block for API Execution");
				if (YFCCommon.isVoid(docAPIOutput)) {
					docCustomApiOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSaveSalesDetails", docApiInputForGetOrderDet);
					loggerForPSAPostVoid
							.debug("Inside Finally Block for Creating API Data");
				} else {
					docCustomApiOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSavePostVoidDetails",
							docApiInputForGetOrderDet);
					loggerForPSAPostVoid
							.debug("Inside Finally Block for Change API Data");
				}

			} catch (Exception e) {
				loggerForPSAPostVoid.error(e);
			}
			
			loggerForPSAPostVoid.endTimer("----checkAndUpdatePostVoidData---");	
			
		}
		return docCustomApiOutput;
	}

	
	/**
	 * This is the main method which will prepare the final document to be
	 * posted to Tibco Queue This is still work in progress
	 * 
	 * @param env
	 * @param docInput
	 * @return Finaldoc
	 * @exception SAXParseException
	 * @exception Exception
	 * 
	 */

	public Document updateVoidAfterDocForPsa(YFSEnvironment env,
			Document docInput) {
		
		Document Finaldoc = null;
		Element eleInvHeaderExtn = null;
		Element eleFinalRoot = null;
		String strPosSeqNo = null; 
		String strSellerOrgCode = null;
		String strTerminalId = null;
		String strIsFirstPSAPV = null;
		try 
		{
			loggerForPSAPostVoid.beginTimer("----updateVoidAfterDocForPsa----");
			
			strIsFirstPSAPV=(String)env.getTxnObject(KohlsXMLLiterals.ATTR_IS_FIRST_PSA_POST_VOID);
			
			if(YFCCommon.isStringVoid(strIsFirstPSAPV))
			{
			Finaldoc = PrepareInputForDataCollect(env , docInput);
			
			
			Element EleOrder = (Element) XPathUtil.getNode(Finaldoc.getDocumentElement(),
					KohlsPOCConstant.X_INV_ORDER);
			
			String strOrderHkey = EleOrder.getAttribute("OrderHeaderKey");

			Document docInputForKohlsSalesForPsa = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			Element eleRoot = docInputForKohlsSalesForPsa.getDocumentElement();
			eleRoot.setAttribute("OrderHeaderKey", strOrderHkey);

			// Method call to fetch XML from KohlsSalesForPsa custom table
			Document outputDoc = getStoredData(env, docInputForKohlsSalesForPsa);
			
			// Changes for Defect # 3663 -- Begin -- 9/1/16
			
			eleVoidedOrder = (Element) XPathUtil.getNode(outputDoc.getDocumentElement(),
					"/KOHLSSalesForPsa/PostVoidData/Order");
			
			NodeList ndlVoidedPaymentMethod = XPathUtil.getNodeList(outputDoc.getDocumentElement(),
					"/KOHLSSalesForPsa/PostVoidData/Order/PaymentMethods/PaymentMethod[@PaymentReference6='PSA']");
			
			int length = ndlVoidedPaymentMethod.getLength();
			
			eleVoidedPaymentMethod = (Element) ndlVoidedPaymentMethod.item(length - 1);
			
			
			if(loggerForPSAPostVoid.isDebugEnabled())
				loggerForPSAPostVoid.debug("PaymenMethod element is:::"+XMLUtil.getElementXMLString(eleVoidedPaymentMethod));
			
			// Changes for Defect # 3663 -- End -- 9/1/16
			
			//Fix for PR-434 - Start
			String voidedTraxNumber = XMLUtil.getAttribute(eleVoidedOrder, "TransactionNo");
			String voidedPOSSeqNumber = XMLUtil.getAttribute(eleVoidedOrder, "PosSequenceNo");
			//Finaldoc = getTransactionAuditDetails(env , Finaldoc);  
			//Using a new method to add the Audit detials for PostVoid Procedure ID-204
			Finaldoc = getTransactionAuditDetailsForPV(env , Finaldoc, voidedTraxNumber, voidedPOSSeqNumber);  
			//Fix for PR-434 - End
			
			Finaldoc = cloneOrderlines(Finaldoc);
			
			
			// Fetching PostVoided Order element from clob object to be populated at Extn level
			
			// Changes for Defect # 3663 -- Begin -- 9/1/16
			
			if(!YFCCommon.isVoid(eleVoidedOrder) && !YFCCommon.isVoid(eleVoidedPaymentMethod))
			{
			
						strPosSeqNo = eleVoidedOrder.getAttribute("PosSequenceNo"); 
						strSellerOrgCode = eleVoidedPaymentMethod.getAttribute("StoreID");
						strTerminalId = eleVoidedPaymentMethod.getAttribute("TerminalID");
						
						loggerForPSAPostVoid.debug("StoreID is "+strSellerOrgCode+"TerminalID is"+strTerminalId);	
			}
			
			// Changes for Defect # 3663 -- End -- 9/1/16
				
			// Fetching InvoiceHeader Element and creating child extn element
			
				//eleInvHeader = (Element) XPathUtil.getNode(Finaldoc.getDocumentElement(),
				//	KohlsPOCConstant.XPATH_INVOICE_HEADER);
			
				//PR-515 Begin
				// eleInvHeaderExtn = XMLUtil.createChild(eleInvHeader,
				// KohlsPOCConstant.A_EXTN, );

				eleInvHeaderExtn = (Element) XPathUtil.getNode(
						Finaldoc.getDocumentElement(),
						KohlsPOCConstant.X_INV_EXTN);
				if ( !YFCCommon.isVoid( eleInvHeaderExtn ) ){
					 
			// Populating data at extn level
			//eleInvHeaderExtn.setAttribute("ExtnOrderDate", strReqDate);
			//PR-515 End
			eleInvHeaderExtn.setAttribute("ExtnPosSequenceNo", strPosSeqNo);
			eleInvHeaderExtn.setAttribute("ExtnShipNode",strSellerOrgCode );
			eleInvHeaderExtn.setAttribute("ExtnSellerOrganisationCode", strSellerOrgCode);
			eleInvHeaderExtn.setAttribute("ExtnTerminalID", strTerminalId);
				 }
				else {
					 loggerForPSAPostVoid.debug("Invoice Header/Extn element is null for transaction: "+voidedTraxNumber );
				 }	
			
			
				// Updated PosSequenceNo as fetched from TransactionAudits
				Element InvOrder = (Element) XPathUtil.getNode(Finaldoc.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER);
				
				// Setting Seller Organization Code and Terminal ID from PaymentMethod -- Begin -- 9/1/16
				
					InvOrder.setAttribute("SellerOrganizationCode", strSellerOrgCode);
					InvOrder.setAttribute("TerminalID", strTerminalId);
				
				// Setting Seller Organization Code and Terminal ID from PaymentMethod -- End -- 9/1/16
					
			if(!YFCCommon.isStringVoid(strPVPosSeqNo))
				{
					InvOrder.setAttribute("PosSequenceNo", strPVPosSeqNo);
				}
			else
				{
				InvOrder.setAttribute("PosSequenceNo", strPosSeqNo);
				}
			// Setting metadata attributes 
			Finaldoc.getDocumentElement().setAttribute("MessageType", "PSA_VoidAfter");
			Finaldoc.getDocumentElement().setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
			}
			else
			{
				Finaldoc = YFCDocument.createDocument("InvoiceDetail").getDocument();
				eleFinalRoot = Finaldoc.getDocumentElement();
				eleFinalRoot.setAttribute(KohlsXMLLiterals.ATTR_IS_FIRST_PSA_POST_VOID, KohlsPOCConstant.NO);
			}
			
			loggerForPSAPostVoid.endTimer("----updateVoidAfterDocForPsa----");
		} catch (Exception e) {
			loggerForPSAPostVoid.error(e);
		}

		return Finaldoc;
	}

	/**
	 * This function parses a getOrderDetails output into a clob object to be
	 * inserted into KohlsSalesForPsa custom table in post void scenarios.
	 * 
	 * @param env
	 * @param docInput
	 * @return docInputForPostVoidData
	 * @exception Exception
	 * 
	 */
	public Document preparePostVoidDataClob(YFSEnvironment env,
			Document docInput) {
		try {
			
			loggerForPSAPostVoid.beginTimer("----preparePostVoidDataClob----");
			Element elePSAOrder = (Element) XPathUtil.getNode(docInput,
					"Order");

			String strOHkey = elePSAOrder
					.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

			String PSADataXML = XMLUtil.getXMLString(docInput);

			Document docInputForPostVoidData = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();

			Element eleInputForPSAData = docInputForPostVoidData
					.getDocumentElement();

			eleInputForPSAData.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					strOHkey);

			eleInputForPSAData.setAttribute("PostVoidData", PSADataXML);

			return docInputForPostVoidData;

		} catch (Exception e) {

			e.printStackTrace();

		}

		loggerForPSAPostVoid.endTimer("----preparePostVoidDataClob----");
		return docInput;

	}

	/**
	 * This method makes an API call to KohlsSalesForPsa custom table and parses
	 * the clob columns in document objects and returns the final document
	 * 
	 * @param env
	 * @param docInput
	 * @return outputDoc
	 * @exception SAXParseException
	 * @exception Exception
	 * 
	 */

	public Document getStoredData(YFSEnvironment env, Document docInput) {
		Document outputDoc = null;
		try {
			loggerForPSAPostVoid.beginTimer("getStoredData --- Begin ");
			
			
			if(loggerForPSAPostVoid.isDebugEnabled())
				loggerForPSAPostVoid.debug("API Input to GetKohlsSalesDetails :::"
						+ XMLUtil.getXMLString(docInput));

			// API call to fetch data from db
			outputDoc = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInput);

			Element eleRootElement = outputDoc.getDocumentElement();

			// Fetching and parsing clob into string objects
			String strSalesClob = eleRootElement
					.getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);

			loggerForPSAPostVoid.debug("Clob Object for sales is :::"
					+ strSalesClob);
			String strPSAPostVoidClob = eleRootElement
					.getAttribute("PostVoidData");

			loggerForPSAPostVoid.debug("Clob Object for PSA Post Void is :::"
					+ strPSAPostVoidClob);

			if (!strSalesClob.isEmpty()) {
				Document docClobData = XMLUtil.getDocument(strSalesClob);
				eleRootElement.setAttribute(
						KohlsPOCConstant.ATTR_ORIG_SALE_DATA,
						KohlsPOCConstant.BLANK);
				Element eleNewClob = docClobData.getDocumentElement();
				XMLUtil.importElement(eleRootElement, eleNewClob);
			}

			if (!strPSAPostVoidClob.isEmpty()) {
				Document docClobData = XMLUtil.getDocument(strPSAPostVoidClob);
				eleRootElement.setAttribute("PostVoidData",
						KohlsPOCConstant.BLANK);
				Element elePSAPostVoidData = XMLUtil.createChild(
						eleRootElement, "PostVoidData");
				Element eleNewClob = docClobData.getDocumentElement();
				XMLUtil.importElement(elePSAPostVoidData, eleNewClob);
				
				if(loggerForPSAPostVoid.isDebugEnabled())
					loggerForPSAPostVoid.debug("After Appending :::"
							+ XMLUtil.getElementXMLString(elePSAPostVoidData));
			}
			
			
			if(loggerForPSAPostVoid.isDebugEnabled())
				loggerForPSAPostVoid.debug("After updated ; Document output :::"
						+ XMLUtil.getXMLString(outputDoc));

			loggerForPSAPostVoid.endTimer("getStoredData --- End ");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return outputDoc;
	}

	public Document PrepareInputForDataCollect(YFSEnvironment env , Document Inputdoc)
	{
		String strOHKey = null;
		String strInvoiceKey = null; 
		Document docInputForChargeTransDet = null;
		Document docInputForGetOrderInvDet = null;
		Document docOutputForChargeTransDet = null;
		Document docOutputForGetOrderInvDet = null;
		
		try
		{
			loggerForPSAPostVoid.beginTimer("-----PrepareInputForDataCollect----");
			
			strOHKey = Inputdoc.getDocumentElement().getAttribute("OrderHeaderKey");
			
			docInputForChargeTransDet = YFCDocument.createDocument(
					"ChargeTransactionDetail").getDocument();
			Element eleRoot = docInputForChargeTransDet.getDocumentElement();
			eleRoot.setAttribute("OrderHeaderKey", strOHKey);
			eleRoot.setAttribute("ChargeType", "ADJUSTMENTS");
			
			docOutputForChargeTransDet = KOHLSBaseApi.invokeAPI(env, "getChargeTransactionList", docInputForChargeTransDet); 
			
			double postVoidAmount = getPostVoidAmount(Inputdoc);
			
			strInvoiceKey = getInvoiceKey(docOutputForChargeTransDet,postVoidAmount);
			
			docInputForGetOrderInvDet = YFCDocument.createDocument(
					"GetOrderInvoiceDetails").getDocument();
			eleRoot = docInputForGetOrderInvDet.getDocumentElement();
			eleRoot.setAttribute("InvoiceKey", strInvoiceKey);
			
			docOutputForGetOrderInvDet = KOHLSBaseApi.invokeService(env,"getOrderInvDetForPV", docInputForGetOrderInvDet);
			
			//Changes for PR-274 - Start
         if ( !YFCCommon.isVoid( docOutputForGetOrderInvDet ) )
         {
            if ( YFCLogUtil.isDebugEnabled() )
            {
               loggerForPSAPostVoid.debug( "KohlsPoCPSAPostVoid.PrepareInputForDataCollect docOutputForGetOrderInvDet=" + XMLUtil.getXMLString( docOutputForGetOrderInvDet ) );
            }

            Element eleOrder = (Element) ( XPathUtil.getNodeList( docOutputForGetOrderInvDet.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER ).item( 0 ) );
            if ( !YFCCommon.isVoid( eleOrder ) )
            {
               Element elePromotions = (Element) eleOrder.getElementsByTagName( KohlsPOCConstant.E_PROMOTIONS ).item( 0 );
               if ( !YFCCommon.isVoid( elePromotions ) )
               {
                  String sPromotionApplied = null;
                  Element elePromotion = null;
                  Element eleExtn = null;
                  Element eleKCSPromosForPV = null;
	              Boolean bPromosToDelete=false;
                  NodeList nlPromotion = elePromotions.getElementsByTagName( KohlsPOCConstant.E_PROMOTION );
                  if ( !YFCCommon.isVoid( nlPromotion ) && nlPromotion.getLength()>0)
                  {
                	 //PST-1760 - Start
                	 //Element eleKCSPromosForPV = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
                	 //PST-1760 - End
                     for ( int i = 0; i < nlPromotion.getLength(); i++ )
                     {
                        elePromotion = (Element) nlPromotion.item( i );
                        eleExtn = (Element) elePromotion.getElementsByTagName( KohlsPOCConstant.A_EXTN ).item( 0 );
                        String sExtnActivationBarCode = eleExtn.getAttribute( KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE );
                        sPromotionApplied = elePromotion.getAttribute( KohlsPOCConstant.A_PROMOTION_APPLIED );
                        String sPromotionType = elePromotion.getAttribute( KohlsPOCConstant.A_PROMOTION_TYPE );
                        if ( KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase( sPromotionType ) && !YFCCommon.isVoid( sExtnActivationBarCode ) )
                        {
                           sPromotionApplied = "Y";
                           elePromotion.setAttribute( KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES );
                        }
                        if ( KohlsPOCConstant.NO.equalsIgnoreCase( sPromotionApplied ) )
                        {
                        	//Fix for PR-699 - Start
                        	if( KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase( sPromotionType ) && !YFCCommon.isVoid( sExtnActivationBarCode ) ){
                        		//Element eleKCSPromosForPV = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS); - Commented for PST-1760
                        		// Modified for CPE-3927
                        		if (YFCCommon.isVoid(eleKCSPromosForPV)){
    	                    		eleKCSPromosForPV = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
    	                    	     }
                        		Element eleKCSPromoForPV = XMLUtil.createChild(eleKCSPromosForPV, KohlsPOCConstant.E_PROMOTION);
                        		XMLUtil.setAttribute(eleKCSPromoForPV, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
                        		XMLUtil.setAttribute(eleKCSPromoForPV, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
                        		Element eleKCSExtnForPV = XMLUtil.createChild(eleKCSPromoForPV, KohlsPOCConstant.E_EXTN);
                        		XMLUtil.setAttribute(eleKCSExtnForPV, KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE, sExtnActivationBarCode);
                        		bPromosToDelete=true;
                        		if ( YFCLogUtil.isDebugEnabled() )
                                {
                                   loggerForPSAPostVoid.debug( "eleKCSPromosForPV added to Order element before removing all the promotions: " + XMLUtil.getElementXMLString( eleOrder ) );
                                }
                        	}
                        	//Fix for PR-688 - End Fix moved outside the loop as same element was getting deleted in loop
                           //eleOrder.removeChild( elePromotions );
                        }
                     }
                     if(bPromosToDelete){ 
                         eleOrder.removeChild( elePromotions );
                         }
                     
                     if ( YFCLogUtil.isDebugEnabled() )
                     {
                        loggerForPSAPostVoid.debug( "eleKCSPromosForPV added to Order element after removing all the promotions: " + XMLUtil.getElementXMLString( eleOrder ) );
                     }
                  }
               }
            }
         }
			//Changes for PR-274 - End
			
			loggerForPSAPostVoid.endTimer("-----PrepareInputForDataCollect-----");
		}
		catch(Exception e)
		{
			loggerForPSAPostVoid.error(e);
		}
		return docOutputForGetOrderInvDet;
	}
	
	private double getPostVoidAmount(Document inputdoc) {
		
		double refundAmount = 0.0;
		String tranNo = inputdoc.getDocumentElement().getAttribute("TransactionNo");
		Element paymentMethods = SCXmlUtil.getChildElement(inputdoc.getDocumentElement(), "PaymentMethods");
		 NodeList nlPaymentmethod = paymentMethods.getElementsByTagName( KohlsPOCConstant.E_PAYMENT_METHOD );
	     if ( !YFCCommon.isVoid( nlPaymentmethod ) && nlPaymentmethod.getLength()>0)
	     {
	   	 //PST-1760 - Start
	   	 //Element eleKCSPromosForPV = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
	   	 //PST-1760 - End
	        for ( int i = 0; i < nlPaymentmethod.getLength(); i++ )
	        {
	        		Element elePayment = (Element) nlPaymentmethod.item( i );
	        		if(tranNo.equalsIgnoreCase(elePayment.getAttribute("PaymentReference7")))
	        		{
	        			refundAmount = refundAmount + Double.valueOf(elePayment.getAttribute("TotalRefundedAmount"));
	        		}
	        }
	     }
		
		return refundAmount;
		// TODO Auto-generated method stub
		
	}


	public String getInvoiceKey(Document Inputdoc, double postVoidAmount)
	{
		String invoiceKey = null;
		try
		{
			
			loggerForPSAPostVoid.beginTimer("getInvoiceKey");
			
			
			if(loggerForPSAPostVoid.isDebugEnabled())
				loggerForPSAPostVoid.debug("Input to method is:::"+XMLUtil.getXMLString(Inputdoc));
			
			NodeList ndlChargeTransDetail = XPathUtil.getNodeList(Inputdoc, "ChargeTransactionDetails/ChargeTransactionDetail[@ChargeType='ADJUSTMENTS']");
			
			int length = ndlChargeTransDetail.getLength();
			
			String transactionDateTime = null; 
			String currentTransactionDateTime = null; 
			Element eleChargeTransLatest = null;
			
			for(int i=0;i<length;i++)
			{
				
				Element eleCurrentChargeTrans = (Element) ndlChargeTransDetail.item(i);
				
				if(loggerForPSAPostVoid.isDebugEnabled()) {
					loggerForPSAPostVoid.debug("Current ChargeTransaction Element is ::"+XMLUtil.getElementXMLString(eleCurrentChargeTrans));
				}
				String debitAmount = eleCurrentChargeTrans.getAttribute("DebitAmount");
				
				if( Double.valueOf(debitAmount) > 0 )
				{					
					if ( YFCCommon.isVoid( eleChargeTransLatest ) ) 
					{
						eleChargeTransLatest = eleCurrentChargeTrans;
						transactionDateTime = eleCurrentChargeTrans.getAttribute("TransactionDate");
					}
					else 
					{
						currentTransactionDateTime = eleCurrentChargeTrans.getAttribute("TransactionDate");

						if ( KohlsDateUtil.compareDateStrings(KohlsPOCConstant.A_TIME_FORMAT, currentTransactionDateTime, transactionDateTime ) >= 0 ) 
						{
							eleChargeTransLatest = eleCurrentChargeTrans;
							transactionDateTime = currentTransactionDateTime;
						}
					}
				}

			}	

			// Taking the invoice key from latest date time - ChargeTransactionDetail
			if (! YFCCommon.isVoid( eleChargeTransLatest ) )  {
				invoiceKey = eleChargeTransLatest.getAttribute("OrderInvoiceKey"); 
			} 
			if( loggerForPSAPostVoid.isDebugEnabled() ) 
			{
				loggerForPSAPostVoid.debug("InvoiceKey is :::"+invoiceKey);
			}
			loggerForPSAPostVoid.endTimer("getInvoiceKey");
		}
		catch(Exception e)
		{
			loggerForPSAPostVoid.error("Unable to find the Invoice Key ", e);
		}
		return invoiceKey;
	}

	public Document getTransactionAuditDetails(YFSEnvironment env , Document Inputdoc)
	{
		try
		{
			loggerForPSAPostVoid.beginTimer("getTransactionAuditDetails");
			Element eleOrder = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER);
			Element eleInvHeader = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.XPATH_INVOICE_HEADER);
			String strOrderNo = eleOrder.getAttribute("OrderNo"); 
			String strSellerOrgCode = eleVoidedPaymentMethod.getAttribute("StoreID");
			
			
			if(loggerForPSAPostVoid.isDebugEnabled())
				loggerForPSAPostVoid
				.debug("Voided payment Method element present in getTransactionAuditDetails method"
						+ XMLUtil.getElementXMLString(eleVoidedPaymentMethod));
			
			// Creating Transaction Audits for Post Void -- Begin
			
			Document docAPIInput = YFCDocument.createDocument("TransactionAudit").getDocument();
			Element eleAPIInput = docAPIInput.getDocumentElement();
			eleAPIInput.setAttribute("OrderNumber", eleOrder.getAttribute("OrderNo"));
			eleAPIInput.setAttribute("OrganizationCode",strSellerOrgCode);
			eleAPIInput.setAttribute("OperatorID", eleVoidedPaymentMethod.getAttribute("OperatorID"));
			eleAPIInput.setAttribute("Action", KohlsPOCConstant.ACTION_CREATE);
			eleAPIInput.setAttribute("DateTime", eleOrder.getAttribute("OrderDate"));
			eleAPIInput.setAttribute("TerminalID", eleVoidedPaymentMethod.getAttribute("TerminalID"));
			eleAPIInput.setAttribute("ProcedureID", "postVoid");
			eleAPIInput.setAttribute("DocumentType", KohlsPOCConstant.SO_DOCUMENT_TYPE);
			
			Document orderListDocOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),"manageTransactionAuditForPOS", docAPIInput);
			
			// Creating Transaction Audits for Post Void -- End
			
			loggerForPSAPostVoid.debug("Order Number and Seller Organization Code are ::"+strOrderNo+" "+strSellerOrgCode);
			
			Document inTranDoc = YFCDocument.createDocument("TransactionAudit").getDocument();
			Element eleInput = inTranDoc.getDocumentElement();
			eleInput.setAttribute("OrderNumber", strOrderNo);
			eleInput.setAttribute("OrganizationCode",strSellerOrgCode);
			
			// Fix for Picking PostVoid Transaction Aduit Details -- Begin
			
			//eleInput.setAttribute("ProcedureID","204");
			
			// Fix for Picking PostVoid Transaction Aduit Details -- End

			//Document orderListDocOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),"getTransactionAuditListForPOS", inTranDoc);
			
			NodeList nlElements = orderListDocOutput.getElementsByTagName("TransactionAudit");
			if(nlElements.getLength()>0){
			Element tranAudit = (Element) nlElements.item(0);
			strPVPosSeqNo = tranAudit.getAttribute("TransactionNumber"); 
			strPVPosSeqNo = strPVPosSeqNo.substring(18, 22);
			Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
			XMLUtil.importElement(eleTranAudits, tranAudit);
			
			// Setting Time Stamps for PSA and PSA Post Void Txn -- Begin
			
			eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
			eleInvHeader.setAttribute("DateInvoiced",tranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
			
			// Setting Time Stamps for PSA and PSA Post Void Txn  -- End
			
			}
			else
			{
				
				eleInput.setAttribute("ProcedureID","213");
				
				orderListDocOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),"getTransactionAuditListForPOS", inTranDoc);
				
				nlElements = orderListDocOutput.getElementsByTagName("TransactionAudit");
				if(nlElements.getLength()>0){
				Element tranAudit = (Element) nlElements.item(0);
				
				strPVPosSeqNo = tranAudit.getAttribute("TransactionNumber"); 
				strPVPosSeqNo = strPVPosSeqNo.substring(18, 22);
				Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
				XMLUtil.importElement(eleTranAudits, tranAudit);
				
				// Setting Time Stamps for PSA and PSA Post Void Txn -- Begin
				
				eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
				eleInvHeader.setAttribute("DateInvoiced",tranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
				
				// Setting Time Stamps for PSA and PSA Post Void Txn  -- End
				
				
			}
			}
			loggerForPSAPostVoid.endTimer("getTransactionAuditDetails");
		}	
		catch(Exception e)
		{
			loggerForPSAPostVoid.error(e);
		}
		
		return Inputdoc;
	}
	
	public Document cloneOrderlines(Document docInput)
	{
		Element eleCurrentOrderline = null;
		Element eleClone = null;
		try
		{
			NodeList ndlOrderline = XPathUtil.getNodeList(docInput.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINE);
			Element eleOrderlines = (Element) XPathUtil.getNode(docInput.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINES);
			int length = ndlOrderline.getLength();
			
			for(int i=0;i<length;i++)
			{
				eleCurrentOrderline = (Element) ndlOrderline.item(i);
				//changes start for 6031
				if (YFCCommon.isVoid(eleCurrentOrderline.getAttribute(KohlsPOCConstant.A_GIFT_REG_ID))) {
				eleCurrentOrderline.setAttribute("GiftRegistryID", eleCurrentOrderline.getAttribute(KohlsPOCConstant.A_GIFT_REG_ID).trim());
				} 		
				//changes end for 6031
				eleCurrentOrderline.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
				eleClone =	(Element) eleCurrentOrderline.cloneNode(true);
				eleClone.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.ATTR_PSA);
				XMLUtil.appendChild(eleOrderlines, eleClone);
				
			}
			
			Integer TotalNumberOfRecords = length*2;
			eleOrderlines.setAttribute("TotalNumberOfRecords",TotalNumberOfRecords.toString());
					
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	return docInput;	
	}
	
	//Fix for PR-434 - Start
	//Using a new method to add the Audit detials for PostVoid Procedure ID-204
	public Document getTransactionAuditDetailsForPV(YFSEnvironment env , Document Inputdoc, String voidedTraxNumber, String voidedPOSSeqNumber)
	{
		loggerForPSAPostVoid.beginTimer("***** getTransactionAuditDetailsForPV - Begin *****");
		try
		{
			Element eleOrder = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER);
			Element eleInvHeader = (Element) XPathUtil.getNode(Inputdoc.getDocumentElement(),KohlsPOCConstant.XPATH_INVOICE_HEADER);
			String strOrderNo = eleOrder.getAttribute("OrderNo"); 
			String strSellerOrgCode = eleVoidedPaymentMethod.getAttribute("StoreID");
			String strInvTotalAmount = KohlsPOCConstant.ZERO_STR;
			if(!YFCCommon.isVoid(eleInvHeader.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT))){
				strInvTotalAmount = String.valueOf(Math.abs(Double.valueOf(eleInvHeader.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT))));
			}
			if(loggerForPSAPostVoid.isDebugEnabled()){
				loggerForPSAPostVoid.debug("Voided payment Method element present in getTransactionAuditDetails method"
						+ XMLUtil.getElementXMLString(eleVoidedPaymentMethod));
			}
			Document inTranDoc = YFCDocument.createDocument("TransactionAudit").getDocument();
			Element eleInput = inTranDoc.getDocumentElement();
			eleInput.setAttribute("OrderNumber", strOrderNo);
			eleInput.setAttribute("OrganizationCode",strSellerOrgCode);
			eleInput.setAttribute("ProcedureID","204");
			//PR-964 - Start
			Element eleOrderBy = XMLUtil.createChild(eleInput, "OrderBy");
			Element eleAttribute = XMLUtil.createChild(eleOrderBy, "Attribute");
			eleAttribute.setAttribute("Name", "TransactionNumber");
			eleAttribute.setAttribute("Desc", "Y");
			if(loggerForPSAPostVoid.isDebugEnabled()){
				loggerForPSAPostVoid.debug("getTransactionAuditListForPOS input is :"
						+ XMLUtil.getElementXMLString(eleInput));
			}
			//PR-964 - End
			Document getTraxAuditListOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
					"getTransactionAuditListForPOS", inTranDoc);
			//loggerForPSAPostVoid.debug("The getTraxAuditListOutput Document is : " +XMLUtil.getXMLString(getTraxAuditListOutput));
			NodeList nlElements = getTraxAuditListOutput.getElementsByTagName("TransactionAudit");
			
			//Check if Audit entry for procedure - 204 is already updated
			if(nlElements.getLength()>0){
				Element eleGetTranAudit = (Element) nlElements.item(0);
				strPVPosSeqNo = eleGetTranAudit.getAttribute("TransactionNumber"); 
				strPVPosSeqNo = strPVPosSeqNo.substring(18, 22);
				eleGetTranAudit.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, strInvTotalAmount);
				Element eleGetTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
				XMLUtil.importElement(eleGetTranAudits, eleGetTranAudit);
				if(loggerForPSAPostVoid.isDebugEnabled()){
					loggerForPSAPostVoid.debug("The eleTranAudits element imported from getTraxAudit API : " +XMLUtil.getElementXMLString(eleGetTranAudits));
				}
				eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
				eleInvHeader.setAttribute("DateInvoiced",eleGetTranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
			}
			
			//If entry for 204 is not available then, create an entry by calling manageTransactionAuditForPOS
			else
			{
				//MAD-626 changes Start
				String sOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
				loggerForPSAPostVoid.debug(" inside else as no record in manageTransactionAudit ::"+sOrderHeaderKey);
				if(sOrderHeaderKey != null){
					
					Document docGetOrderDetails = YFCDocument.createDocument("Order").getDocument();
					Element eleGetOrderDetails = docGetOrderDetails.getDocumentElement();
					eleGetOrderDetails.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
					Document orderDetails = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_DETAILS_TEMPLATE),"getOrderDetails", docGetOrderDetails);
					loggerForPSAPostVoid.debug("orderDetails ::"+XMLUtil.getXMLString(orderDetails));
					Element eleorder = orderDetails.getDocumentElement();
					Element sCustomAtr = (Element) XPathUtil.getNode(eleorder,"/Order/CustomAttributes");
					String transactionNo = sCustomAtr.getAttribute("Text19");
					String modifyts = eleOrder.getAttribute("Modifyts");
					loggerForPSAPostVoid.debug("modifyts :::"+modifyts+" transactionNo ::::"+transactionNo);
					if(!XMLUtil.isVoid(modifyts) || !XMLUtil.isVoid(transactionNo)){
						
						loggerForPSAPostVoid.debug("transactionNo not null :: inside");
						Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
						Element eleTraxAudit = XMLUtil.createChild(eleTranAudits,"TransactionAudit");
						eleTraxAudit.setAttribute("OrderNumber", eleOrder.getAttribute("OrderNo"));
						eleTraxAudit.setAttribute("OrganizationCode",strSellerOrgCode);
						eleTraxAudit.setAttribute("OperatorID", eleVoidedPaymentMethod.getAttribute("OperatorID"));
						eleTraxAudit.setAttribute("BusinessDay", modifyts.substring(0, 10));
						eleTraxAudit.setAttribute("TransactionNumber",transactionNo);
						eleTraxAudit.setAttribute("Modifyts",modifyts);
						eleTraxAudit.setAttribute("Createts",modifyts);
						//eleTraxAudit.setAttribute("TransAuditKey","");
						eleTraxAudit.setAttribute("isHistory","N");
						eleTraxAudit.setAttribute("TerminalID",eleOrder.getAttribute("TerminalID"));
						eleTraxAudit.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, strInvTotalAmount);		
						
						eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
						String voidSeqNo = transactionNo.substring(18,22);
						eleOrder.setAttribute("PosSequenceNo", voidSeqNo);
						eleInvHeader.setAttribute("DateInvoiced",modifyts);
						strPVPosSeqNo = voidSeqNo;
						loggerForPSAPostVoid.debug(" printing eleInvHeader ::"+XMLUtil.getElementXMLString(eleInvHeader));
					}else {
						//MAD-626 changes end
						Document docManageTraxAuditInput = YFCDocument.createDocument("TransactionAudit").getDocument();
						Element elemanageTraxAuditInput = docManageTraxAuditInput.getDocumentElement();
						elemanageTraxAuditInput.setAttribute("OrderNumber", eleOrder.getAttribute("OrderNo"));
						elemanageTraxAuditInput.setAttribute("OrganizationCode",strSellerOrgCode);
						elemanageTraxAuditInput.setAttribute("OperatorID", eleVoidedPaymentMethod.getAttribute("OperatorID"));
						elemanageTraxAuditInput.setAttribute("Action", KohlsPOCConstant.ACTION_CREATE);
						elemanageTraxAuditInput.setAttribute("DateTime", eleOrder.getAttribute("Modifyts")); //PR-486 should order modified date
						elemanageTraxAuditInput.setAttribute("TerminalID", eleVoidedPaymentMethod.getAttribute("TerminalID"));
						elemanageTraxAuditInput.setAttribute("ProcedureID", "postVoid");
						elemanageTraxAuditInput.setAttribute("DocumentType", KohlsPOCConstant.SO_DOCUMENT_TYPE);
						elemanageTraxAuditInput.setAttribute("OriginalTransactionNumber", voidedTraxNumber);
						elemanageTraxAuditInput.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, strInvTotalAmount);
						//elemanageTraxAuditInput.setAttribute("TransactionNumber", voidedTraxNumber);
						loggerForPSAPostVoid.debug("The voidedPOSSeqNumber and voidedTraxNumber value are : " 
								+voidedPOSSeqNumber + "and" +voidedTraxNumber);
						//String str = voidedTraxNumber.substring(18,22);
						/*int newTraxSeqNumber = Integer.parseInt(voidedPOSSeqNumber);
							newTraxSeqNumber++;
							loggerForPSAPostVoid.debug("The newTraxSeqNumber value are : " +newTraxSeqNumber);
							String newTraxNum = voidedTraxNumber.substring(0, 18).concat(String.valueOf(newTraxSeqNumber));*/
						String tempPVTranxNumber = voidedTraxNumber.substring(18,22);
						Document inGetTerminalStatusDoc = YFCDocument.createDocument("TerminalStatus").getDocument();
						Element eleGetTerminalStatus = inGetTerminalStatusDoc.getDocumentElement();
						eleGetTerminalStatus.setAttribute("OrganizationCode",strSellerOrgCode);
						eleGetTerminalStatus.setAttribute("TerminalID", eleVoidedPaymentMethod.getAttribute("TerminalID"));
						if(loggerForPSAPostVoid.isDebugEnabled()){
							loggerForPSAPostVoid.debug("The inGetTerminalStatusDoc values is : " +XMLUtil.getXMLString(inGetTerminalStatusDoc));
						}
						
						//Call getTerminalStatusDetailsForPOS to get the available Seq no for PostVoid Transaction.
						Document getTerminalStatusOut = KOHLSBaseApi.invokeAPI(env,"getTerminalStatusDetailsForPOS", inGetTerminalStatusDoc);
						Element eleGetTerminalStatusOut = getTerminalStatusOut.getDocumentElement();
						String postVoidSeqNumber = XMLUtil.getAttribute(eleGetTerminalStatusOut, "SequenceNumber");
						//String postVoidTranNumber = tempPVTranxNumber.concat(postVoidSeqNumber);
						String postVoidTranNumber = createPSAPostvoidTransactionNO(eleOrder.getAttribute("Modifyts"), strSellerOrgCode, eleVoidedPaymentMethod.getAttribute("TerminalID"), postVoidSeqNumber );
						loggerForPSAPostVoid.debug("The postVoidTranNumber and postVoidSeqNumber values are : " +postVoidTranNumber + "and" +postVoidSeqNumber);
						elemanageTraxAuditInput.setAttribute("TransactionNumber", postVoidTranNumber);
						elemanageTraxAuditInput.setAttribute("POSSequenceNumber", postVoidSeqNumber);
						
						//Call manageTransactionAuditForPOS along with TranxNo and SeqNo.
						Document docManageTraxAuditOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
								"manageTransactionAuditForPOS", docManageTraxAuditInput);
						NodeList eleManageTraxAuditOutput = docManageTraxAuditOutput.getElementsByTagName("TransactionAudit");
						
						//Add the TranAudit details of ProcedureId-204 to the invoice message 
						if(eleManageTraxAuditOutput.getLength()>0){
							Element eleManageTranAudit = (Element) eleManageTraxAuditOutput.item(0);
							strPVPosSeqNo = String.valueOf(postVoidSeqNumber);
							Element eleTranAudits=XMLUtil.createChild(eleInvHeader, "TransactionAudits");
							XMLUtil.importElement(eleTranAudits, eleManageTranAudit);
							if(loggerForPSAPostVoid.isDebugEnabled()){
								loggerForPSAPostVoid.debug("The eleTranAudits element imported from ManageTraxAudit API : " +XMLUtil.getElementXMLString(eleTranAudits));
							}
							eleOrder.setAttribute("OrderDate", eleOrder.getAttribute("Modifyts"));
							eleInvHeader.setAttribute("DateInvoiced",eleManageTranAudit.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));
						}
						loggerForPSAPostVoid.debug("Order Number and Seller Organization Code are ::"+strOrderNo+" "+strSellerOrgCode);
					}
			}
			}
			// PR-515 - Begin - Get TransactionTimeStamp for original PSA that
			// is being voided
			Document inDoc = YFCDocument.createDocument("TransactionAudit")
					.getDocument();
			Element eleDoc = inDoc.getDocumentElement();
			eleDoc.setAttribute("OrderNumber", strOrderNo);
			eleDoc.setAttribute("OrganizationCode", strSellerOrgCode);
			eleDoc.setAttribute("ProcedureID", "213");
			eleDoc.setAttribute("TransactionNumber", voidedTraxNumber);

			if (loggerForPSAPostVoid.isDebugEnabled()) {
				loggerForPSAPostVoid
						.debug("Calling getTransactionAuditListForPOS API with input doc : "
								+ XMLUtil.getXMLString(inDoc));
			}
			Document psaTranDateDocOutput = KOHLSBaseApi
					.invokeAPI(
							env,
							XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
							"getTransactionAuditListForPOS", inDoc);
			NodeList nPSATranEleList = psaTranDateDocOutput
					.getElementsByTagName("TransactionAudit");

			String strPSADateTime = null;
			if (nPSATranEleList != null && nPSATranEleList.getLength() > 0) {
				Element elePSATranAudit = (Element) nPSATranEleList.item(0);
				strPSADateTime = elePSATranAudit.getAttribute("DateTime");
			}
			
			Element eleInvHeaderExtn = XMLUtil.createChild(eleInvHeader,
					KohlsPOCConstant.A_EXTN);
			// Populating PSA DateTime at InvoiceHeader/Extn Level
			// CPE-2674 changes start
            		if (YFCCommon.isVoid(strPSADateTime)) {
                		strPSADateTime = eleOrder.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS) 	;
            		}
            		// CPE-2674 changes end
			eleInvHeaderExtn.setAttribute("ExtnOrderDate", strPSADateTime);
			// PR-515 - End
			
			// Getting PSA Store.
			String sPSAStore = strSellerOrgCode;
			if(YFCCommon.isVoid(sPSAStore) && !YFCCommon.isVoid(voidedTraxNumber) && !(voidedTraxNumber.length() < 16)) {
				sPSAStore = voidedTraxNumber.substring(12, 16);
			}
			String loyaltyStore = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, sPSAStore, KohlsPOCConstant.EMPTY);
			if(!YFCCommon.isVoid(loyaltyStore) && !loyaltyStore.contains("V2")){
				eleInvHeader.setAttribute("Version", "V1");
			} else {
				eleInvHeader.setAttribute("Version", "V2");
				updateUnearnPromotionsForPSAPV(eleOrder);
			}

			loggerForPSAPostVoid.endTimer("***** getTransactionAuditDetailsForPV - End *****");
		}	
		catch(Exception e)
		{
			loggerForPSAPostVoid.error(e);
		}

		return Inputdoc;
	}
	private void updateUnearnPromotionsForPSAPV(Element eleOrder) {
		loggerForPSAPostVoid.beginTimer("***** KohlsPoCPSAPostVoid.updateUnearnPromotionsForPSAPV *****");
		try {
			Element elePSAPromotions = XMLUtil.getChildElement(eleVoidedOrder, KohlsPOCConstant.E_PROMOTIONS);
			Element elePSAPostVoidPromotions = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS,true);
			if(!YFCCommon.isVoid(elePSAPromotions) && elePSAPromotions.hasChildNodes()){
				Element elePSAPromotion = null;
				NodeList nlPSAPromotion = elePSAPromotions.getElementsByTagName( KohlsPOCConstant.E_PROMOTION );
				if ( !YFCCommon.isVoid( nlPSAPromotion ) && nlPSAPromotion.getLength()>0)
				{
					for ( int i = 0; i < nlPSAPromotion.getLength(); i++ )
					{
						elePSAPromotion = (Element) nlPSAPromotion.item( i );
						String strPromotionType = XMLUtil.getAttribute(elePSAPromotion, KohlsPOCConstant.A_PROMOTION_TYPE);
						if(KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(strPromotionType) ||
								KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(strPromotionType)||
								KohlsPOCConstant.KOHLSCASH.equalsIgnoreCase(strPromotionType)){
							XMLUtil.importElement(elePSAPostVoidPromotions, elePSAPromotion);
						}
					}
				}
			}
		}catch (Exception e){
			loggerForPSAPostVoid.error("Exception in updateUnearnPromotionsForPSAPV " + e);
		}
		loggerForPSAPostVoid.endTimer("***** KohlsPoCPSAPostVoid.updateUnearnPromotionsForPSAPV *****");
	}


	//Fix for PR-434 - End
	
	//PR-486 Begin
	/****
	 * 
	 * @param postVoidDate
	 * @param strSellerOrgCode
	 * @param registerNo
	 * @param postVoidSeqNumber
	 * @return
	 */
	private String createPSAPostvoidTransactionNO( String postVoidDate, String strSellerOrgCode, String registerNo, String postVoidSeqNumber )
	  {
	     String postVoidTransactionNo = postVoidSeqNumber;
	     try {
	        DateFormat inputFormatter = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss" );
	        DateFormat outputFormatter = new SimpleDateFormat( "MMddyyHHmmss" );
	        String formattedPVOrderDate = outputFormatter.format( (Date) inputFormatter.parse( postVoidDate ) );
	        StringBuffer sb = new StringBuffer(formattedPVOrderDate);
	        sb.append( leftPaddingZeros( strSellerOrgCode, 4 ) );
	        sb.append( leftPaddingZeros( registerNo, 2 ) );
	        sb.append( leftPaddingZeros( postVoidSeqNumber, 4 ) );
	        postVoidTransactionNo = sb.toString();
	     } catch (Exception e) {
	        loggerForPSAPostVoid.error("Exception in createPSAPostvoidTransactionNO " + e);
	        e.printStackTrace();
	     }
	     return postVoidTransactionNo;
	  }
	  
	  /***
	   * 
	   * @param String
	   * @param lengthOfSting
	   * @return String
	   */
	  public  String leftPaddingZeros(String str, int lengthOfSting) {
	     return String.format("%1$" + lengthOfSting + "s", str).replace(' ', '0');
	   }
	   
	   ////PR-486 End
}
