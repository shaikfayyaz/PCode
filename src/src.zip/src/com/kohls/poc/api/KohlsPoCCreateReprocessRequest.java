/*
 * File: KohlsPoCCreateReprocessRequest.java Created on Sep 18, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.api;

import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dblayer.PLTCompressionHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author mrjoshi This class reads the arguments configured in application manager and creates the
 *         record in the KOHLS_REPROCESS_REQUEST table Parameters to be configured in the
 *         application manager ServiceName = Service / API that need to be invoked IsFlow = whether
 *         the service to be invoked is flow or API
 */

public class KohlsPoCCreateReprocessRequest extends KOHLSBaseApi {

  private static final YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCCreateReprocessRequest.class.getName());

  Properties props;

  public Document createReprocessRequest(YFSEnvironment env, Document docInXML) throws Exception {
    logger.beginTimer("KohlsPoCCreateReprocessRequest.createReprocessRequest");
    String sServiceName = props.getProperty("ServiceName");
    String sIsFlow = props.getProperty("IsFlow");
    if (YFCCommon.isVoid(sServiceName)) {
      throw new YFSException("Service Name not configured", "0000", "Service Name not configured");
    }
    if (YFCCommon.isVoid(sIsFlow)) {
      sIsFlow = "N";
    }
    Document docReprocessRequestInput = XMLUtil.createDocument("KohlsReprocessRequest");
    Element eleReprocessRequestRoot = docReprocessRequestInput.getDocumentElement();
    eleReprocessRequestRoot.setAttribute("ServiceName", sServiceName);
    eleReprocessRequestRoot.setAttribute("IsFlow", sIsFlow);
    
    Document docInputgetCommonCodeList = XMLUtil.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
    Element eleCommonCode = docInputgetCommonCodeList.getDocumentElement();
    eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
	        "COMPRESSED_XML");
	  Document  docCommonCodeListOuput = KOHLSBaseApi.invokeAPI(env,
	        KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docInputgetCommonCodeList);
	  Element commonCode =
	            (Element) docCommonCodeListOuput.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE).item(0);
	  
	  String sCodeValue = commonCode.getAttribute(KohlsPOCConstant.ATTR_CODE_VALUE);
    
    if(KohlsXMLLiterals.CONST_Y.equalsIgnoreCase(sCodeValue)){
	    String docInput = PLTCompressionHelper.compress("KOHLS_REPROCESS_REQUEST", "KOHLS_REPROCESS_REQUEST", XMLUtil.getXMLString(docInXML));
	    eleReprocessRequestRoot.setAttribute("Message",docInput);
	    eleReprocessRequestRoot.setAttribute("IsCompressed","Y");
    }
    else{
	    eleReprocessRequestRoot.setAttribute("Message", XMLUtil.getXMLString(docInXML));
	    eleReprocessRequestRoot.setAttribute("IsCompressed","N");
    }
    invokeService(env, "KohlsCreateReprocessRecord", docReprocessRequestInput);
    logger.endTimer("KohlsPoCCreateReprocessRequest.createReprocessRequest");
    return docInXML;
  }

  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */

  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    logger.debug("In the set properties method");

  }
}
