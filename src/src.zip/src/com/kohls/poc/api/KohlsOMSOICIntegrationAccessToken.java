package com.kohls.poc.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONException;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.kohls.ws.auth.client.AuthRequest;
import com.kohls.ws.auth.client.WsAuthClientUtil;
import com.kohls.ws.auth.shared.AuthInitializer;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;	
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSException;

/**
 *  This class will be used to create client and access token requests to OIC.
 *  Integrates with OIC when there is no active access token is session else will reuse existing
 *  token for placing create and cancel reservation requests to OIC.
 */
@SuppressWarnings("deprecation")
class KohlsOMSOICIntegrationAccessToken {
	
	private static String accessToken;
	private static long tokenValidUntil;
	private static int tokenExprityMin;
	
	private static String strOrderDate;
	private static final String HEADER_CONTENT_TYPE = "content-type";
	private static final String HEADER_CONTENT_TYPE_VALUE = "application/json";
	private static final String HEADER_CONTENT_TYPE_KOHLS_TOKEN = "X-KOHLS-Auth-Token"; 
	private static final String HEADER_CONTENT_TYPE_JWT_TOKEN = "X-KOHLS-CreateDateTime"; 
	private static final String HTTP_BODY = "body";
	private static final String SUCCESS = "Success";
	private static final String FAILURE="Failure";
	private static final String OIC_ISSUER_ID= "oicpoc-app";
	private static final String OIC_RECIPIENT_ID = "apis";
	private static final String OIC_ACCESS_TOKEN = "access_token" ;
	private static final String OIC_TOKEN_TYPE = "token_type" ;
	private static final String OIC_EXPIRES_IN = "expires_in";
	private static final String OIC_TOKEN = "token"; 
	private static final String A_OIC_TOKEN_URL="OIC_INVENTORY_TOKEN_URL";
	private static final String strOICUrl=YFSSystem.getProperty(A_OIC_TOKEN_URL);
	private static final String A_OMS_OIC_RETRY_LIMIT="OMS_OIC_RETRY_LIMIT";
	private static final String strRetryLimit=YFSSystem.getProperty(A_OMS_OIC_RETRY_LIMIT);
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsOMSOICIntegrationAdapter.class.getName());
	}
	
	private static YIFApi api = null;
	static {
	try {
		api = YIFClientFactory.getInstance().getApi();
	} catch (YIFClientCreationException e) {
		e.printStackTrace();
	}
	}
	public KohlsOMSOICIntegrationAccessToken() {
	}
	
	
	/** Get client and server token for OIC calls
	 * @return
	 * @throws JSONException
	 * @throws IOException
	 */
	public  String getKohlsOICAuth() throws JSONException, IOException,YFSException{
		String content = getToken();
		if(!YFCObject.isVoid(content))
			try{
		 accessToken=getAccessToken(content);
			}catch(YFSException e){
	 			throw e;
	 		}
		return accessToken;
	}

	
	/** Verify existing authorization token else create new auth token.
	 * @param content
	 * @return
	 * @throws JSONException
	 * @throws IOException
	 */
	private static String getAccessToken(String content) throws JSONException, IOException,YFSException {
		if(logger.isDebugEnabled()) 
			logger.debug("Inside getAccessToken::"+accessToken);
		try{
		if(!YFCObject.isVoid(content)){
		if (isTokenExpired() || null== accessToken ) {
			accessToken = execute(content);
			if(!YFCObject.isVoid(tokenExprityMin))
			 tokenValidUntil = (tokenExprityMin * 1000) + System.currentTimeMillis();
			if(logger.isDebugEnabled()) 
				logger.debug("Next Token Valid Time::tokenValidUntil::"+accessToken);
		} }
		}catch(YFSException e){
	    	throw e;
	    }
    	return accessToken;
	}

	
	/** Get new client token for OIC call.
	 * @return
	 */
	private static String getToken() {
		AuthInitializer.init();
		String me = OIC_ISSUER_ID, recepient = OIC_RECIPIENT_ID;	 
		AuthRequest authRequest = WsAuthClientUtil.newBrokreredAuthRequest(me, recepient);
		String content = authRequest.getBodyContent();
		if(logger.isDebugEnabled())
			logger.debug("Client token:"+content);
		return content;
	}
	
	
   /** Get new server token for OIC calls, retry few times before throwing error.
	 * @param message
	 * @return
	 * @throws JSONException
	 * @throws IOException
	 */
	public static String execute(String message) throws JSONException, IOException,YFSException {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		StringBuilder responseString = new StringBuilder();
		String returnString = "";
		int retryLimit=1;
		try{
			//Verify if OIC URL exists in properties file
			if(!YFCObject.isVoid(strOICUrl)){
				returnString = callOicForServerToken(message, httpClient,responseString, returnString, retryLimit);
		    }
			//Handle blank OIC URL
			else {
				logger.error("Inside KohlsOMSOICIntegrationAccessToken.execute() - OIC URL is Blank ");
			}
	    // handle response here...
		}catch (YFSException e) {
				logger.error("Error in Getting Server Auth Token >>> KohlsOMSOICIntegrationAcessToken.execute():Unable to get Token from OIC");
				throw e;
		}catch (Exception e) {
				//Handle Connect Exception, Unknown Host, IO Exception, Socket TimeOut Exception  - Yet to be decided with kohls team
				logger.error("Error in Getting Server Auth Token >>> KohlsOMSOICIntegrationAcessToken.execute():Unable to get Token from OIC", e);
				if (e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.net.UnknownHostException || e.getCause() instanceof java.net.UnknownServiceException|| e.getCause() instanceof java.io.IOException || e.getCause() instanceof java.net.SocketTimeoutException) {
					throw new YFSException("Error in Getting Server Auth Token:Unable to get Token from OIC");
				}
		}finally {
	    	   httpClient.close();
	    }
		return returnString;
	}


	/**
	 * @param message
	 * @param httpClient
	 * @param responseString
	 * @param returnString
	 * @param retryLimit
	 * @return
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws NumberFormatException
	 * @throws UnsupportedOperationException
	 * @throws JsonSyntaxException
	 */
	private static String callOicForServerToken(String message,
			CloseableHttpClient httpClient, StringBuilder responseString,
			String returnString, int retryLimit) throws IOException,
			ClientProtocolException, NumberFormatException,
			UnsupportedOperationException, JsonSyntaxException {
		HttpPost request = new HttpPost(strOICUrl);
		request = createPostRequest(request, message);
		//Retry till retry intervals
		CloseableHttpResponse response = httpClient.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();
		if(!YFCObject.isVoid(strRetryLimit)){
		retryLimit=Integer.parseInt(strRetryLimit);
		}
		if (responseCode != 200) {
			for (int i = 1; i <= retryLimit; i++) {
				response = httpClient.execute(request);
				responseCode = response.getStatusLine().getStatusCode();
				if (responseCode == 200) {
					break;
		}}}
		
		//Proceed further only when have success response from OIC for Auth Token
		if(responseCode==200){
		BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
		String output1;
		while ((output1 = br.readLine()) != null) {
			responseString.append(output1); 
		}
	
		//Verify server token in the response and build Error as needed to the customer
		String json = responseString.toString();
		if(logger.isDebugEnabled()) 
			logger.debug("Inside execute:: Server Token::"+json);
		returnString = verifyOICResponseForServerToken(returnString, json);
		}
		return returnString;
	}


	/**
	 * @param returnString
	 * @param json
	 * @return
	 * @throws JsonSyntaxException
	 */
	private static String verifyOICResponseForServerToken(String returnString,
			String json) throws JsonSyntaxException {
		JsonParser parser = new JsonParser();
		JsonElement jsonEle = parser.parse(json);
		if (jsonEle.isJsonObject()) {
			JsonObject jsonObj = jsonEle.getAsJsonObject();
			JsonObject body = jsonObj.getAsJsonObject(HTTP_BODY);
			returnString = body.get(OIC_ACCESS_TOKEN).getAsString();
			returnString = body.get(OIC_TOKEN_TYPE).getAsString() + " " + returnString;
			
			//Get Token Expiry and Validity details
			tokenExprityMin = body.get(OIC_EXPIRES_IN).getAsInt();
			if(logger.isDebugEnabled())
				logger.debug(returnString + "\n Timeout: "+body.get(OIC_EXPIRES_IN).getAsInt());
			
			
			//Final Token to be used for all OIC Requests
			if(logger.isDebugEnabled()) { 
			  logger.debug("Use Below Token for All OIC Requests");
			  logger.debug("*********************************************");
			  logger.debug(returnString + "\n Timeout: " + body.get(OIC_EXPIRES_IN).getAsInt());
		      logger.debug("*********************************************");
			}
		}
		return returnString;
	}

   
	/** 
	 * Create Post request for Auth token call to OIC.
	 * @param request
	 * @param message
	 * @return
	 */
	public static HttpPost createPostRequest(HttpPost request, final String message) {
		request.addHeader(HEADER_CONTENT_TYPE, HEADER_CONTENT_TYPE_VALUE);
		request.addHeader(HEADER_CONTENT_TYPE_JWT_TOKEN, strOrderDate);
		if(logger.isDebugEnabled())  logger.debug("Inside createPostRequest- X-KOHLS-CreateDateTime"+strOrderDate);
		JsonObject jsonObj = new JsonObject();
		jsonObj.addProperty(OIC_TOKEN, message);
		if(logger.isDebugEnabled())  logger.debug("Inside createPostRequest::"+jsonObj.toString());
			try {
				request.setEntity(new StringEntity(jsonObj.toString()));
				//request.setEntity(entity);
			} catch (UnsupportedEncodingException e) {
				if(logger.isDebugEnabled())  logger.debug("UnsupportedEncodingException " + e);
			}
			return request;
		}
	
	
    /**
     *  Verify if the existing token has been expired.
    * @return
    */
	private static boolean isTokenExpired() {
		if(tokenValidUntil < (System.currentTimeMillis()))
			return true;
		else
			return false;
		}

	
	
	 /** Makes create reservation and cancel reservation calls to OIC for every add or cancel line respectively.
	 * @param xmlToJSONString
	 * @param httpURL
	 * @param strOICToken
	 * @return SUCCESS/FAILURE
	 * @throws Exception 
	 */
	public String callOIC(String xmlToJSONString,String httpURL,String strOICToken) throws YFSException{
		String output = "";
		String strFinalResponse="";
		try{
		
		if(logger.isDebugEnabled())  logger.debug("Input of callOIC::xmlToJSONString"+xmlToJSONString+" ::: httpURL:"+httpURL+"::: strOICToken:"+strOICToken);
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost postRequest = new HttpPost(httpURL);
		
		//Set Header values for OIC Calls
		setHeaderForHttpCalls(xmlToJSONString, strOICToken, postRequest);
		
		//Make Http Calls for Reservation creation/Cancellations in OIC
		BufferedReader br = makeCallToOIC(httpClient, postRequest);
		
		//Verify Responses From OIC Calls
		strFinalResponse = callOICAndVerifyValidStatus(strFinalResponse, br); 
		
		//Close http Connection 
		httpClient.getConnectionManager().shutdown();
		
		if(logger.isDebugEnabled()) logger.debug("output of callOIC:: Final Response"+strFinalResponse);
		
		//Add Code to handle exception Scenarios
		}catch(YFSException e){
			throw e;
		}catch (Exception e) {
		//Handle Connect Exception, Unknown Host, IO Exception, Socket TimeOut Exception  - Yet to be decided with kohls team
			logger.error("Exception when invoking the OIC::",e);
				throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM :: Connection Exception at OIC","UNABLE TO ADD ITEM :: Connection Exception at OIC");
		}   return  strFinalResponse;
	}


	/**
	 * @param httpClient
	 * @param postRequest
	 * @return
	 * @throws IOException
	 * @throws ClientProtocolException
	 * @throws UnsupportedOperationException
	 */
	private BufferedReader makeCallToOIC(DefaultHttpClient httpClient,
			HttpPost postRequest) throws IOException, ClientProtocolException,
			UnsupportedOperationException {
		HttpResponse response = httpClient.execute(postRequest);
		BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
		if(logger.isDebugEnabled())  logger.debug("Output from Server .... \n");
		return br;
	}


	/**
	 * @param strFinalResponse
	 * @param br
	 * @return
	 * @throws IOException
	 * @throws NumberFormatException
	 * @throws YFSException
	 */
	private String callOICAndVerifyValidStatus(String strFinalResponse,
			BufferedReader br) throws IOException, NumberFormatException,
			YFSException {
		String output;
		//Verify response for required statuses and messages
		while ((output = br.readLine()) != null) {
			String statusCode = getJsonAttribute(output, "\"status\":");
			String statusMessage = getJsonAttribute(output, "\"message\":");
			if(logger.isDebugEnabled())  logger.debug("response from OIC:: statusCode"+statusCode);
			if(logger.isDebugEnabled())  logger.debug("response from OIC:: statusMessage"+statusMessage);
			int intStatusCode=0;
			if(!YFCObject.isVoid(statusCode)){
				intStatusCode=Integer.parseInt(statusCode);
			}
			//*** verify status code and throw error on failure response
			//Item not found or Inventory not available responses from OIC
			if (intStatusCode== 350 || intStatusCode== 250){
				if(logger.isDebugEnabled())  logger.debug("Error in OIC Response");
				strFinalResponse=FAILURE;
				throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM::Inventory Not Available - OIC Error:"+statusCode, "UNABLE TO ADD ITEM :: Inventory Not Available at OIC ");
				}
			//4** - Client Exceptions, 5** - server Exceptions
			else if (statusCode.startsWith("4") || statusCode.startsWith("5") || statusMessage.contains("ConnectException")){
				throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM :: Exception at OIC","UNABLE TO ADD ITEM :: Exception at OIC, Please try again later");
			}
			//Success Response from OIC
			else if(intStatusCode== 200){
				strFinalResponse=SUCCESS;
				if(logger.isDebugEnabled())  logger.debug(output);
			}
		}
		return strFinalResponse;
	}


	/**
	 * @param xmlToJSONString
	 * @param strOICToken
	 * @param postRequest
	 * @throws UnsupportedEncodingException
	 */
	private void setHeaderForHttpCalls(String xmlToJSONString,
			String strOICToken, HttpPost postRequest)
			throws UnsupportedEncodingException {
		//Set Header for Token Information
		postRequest.addHeader(HEADER_CONTENT_TYPE, HEADER_CONTENT_TYPE_VALUE);
		postRequest.addHeader(HEADER_CONTENT_TYPE_KOHLS_TOKEN, strOICToken);
		if(!xmlToJSONString.startsWith("[")){
			xmlToJSONString="["+xmlToJSONString+"]";
		}
		StringEntity input1 = new StringEntity(xmlToJSONString);
		if(logger.isDebugEnabled())  logger.debug("xmlToJSONString::"+xmlToJSONString);
		input1.setContentType(HEADER_CONTENT_TYPE_VALUE);
		postRequest.setEntity(input1);
	}
	
	
	/** This method will get the status and message attribute values from JSON response.
	 * @param jsonStr
	 * @param attr
	 * @return
	 */
	public static String getJsonAttribute(String jsonStr, String attr) {
		//return null if attribute is not found.
		if(jsonStr.indexOf(attr) == -1)
			return null;
		
		//get substring starting after the attribute. 
		jsonStr = jsonStr.substring(jsonStr.indexOf(attr)+attr.length());
		
		//format ending - get substring till , if it is not last attribute. If it is last attribute, get substring till }.
		jsonStr = jsonStr.indexOf(",") > -1 ? jsonStr.substring(0,jsonStr.indexOf(",")) : jsonStr.substring(0,jsonStr.indexOf("}"));
		return jsonStr.trim();
	}
}