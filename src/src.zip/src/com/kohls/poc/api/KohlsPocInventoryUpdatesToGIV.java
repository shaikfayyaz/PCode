package com.kohls.poc.api;

//Java Imports
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : KohlsPoc KohlsPocInventoryUpdatesToGIV.java Author : IBM Created :
 * April 7 2015 Modified : April 8 2015 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 04/07/2013 IBM First Cut.
 ***************************************************************************** 
 * 
 * Copyright @ 2015. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the various attributes with respect to Inventory Updates to
 * be sent to GIV. It creates a document with these attibutes and post the
 * message to Outbound GIV queue.
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/

public class KohlsPocInventoryUpdatesToGIV extends KOHLSBaseApi {
	private static final YFCLogCategory loggerForInvUpdatesToGIV = YFCLogCategory
			.instance(KohlsPocInventoryUpdatesToGIV.class.getName());
	
	private boolean bRecycleFee = false;
	
	private int intQty = 1;
	private String strOrderHeaderKey = null;
	private String strEnterpriseCode = null;
	private String strOrganizationCode = null;
	private String strTerminalID;
	private String strOrigPosSeqNo =null;
	private String strOrderDate;
	private String strPosSequenceNo;
	private String strMessageType;
	private String strOrderPurpose;
	private String delimiter = "_";	
	HashMap<String, Integer> mapItemQty = new HashMap<String, Integer>();
	private String documentType=null;
	private List<String> specialSKUlist = new ArrayList<String>();

	/**
	 * This function generates the document to be sent to GIV. The sample
	 * template sent is as below: 
	 * <Items> 
	 * <Item AdjustmentType="ADJUSTMENT"
	 * Availability="TRACK" ETA="1900-01-01" ItemID="" OrganizationCode=""
	 * ProductClass="Good" Quantity="" ReasonCode="Sale" Reference_2=""
	 * Reference_3="" Reference_4="" ShipNode="" SupplyType="ONHAND"
	 * UnitOfMeasure="" /> 
	 * </Items>
	 * 
	 * @param env
	 * @param inputPublishInvoiceDetail
	 * @return docOutputPublishPOSInvoice
	 * @exception Exception
	 * 
	 */
	public Document generateAndPublishInventoryUpdatesToGIV(YFSEnvironment env,
			Document inDoc) throws YFSException {

		
		loggerForInvUpdatesToGIV
				.beginTimer("KohlsPocInventoryUpdatesToGIV.generateAndPublishInventoryUpdatesToGIV");
		Document inputPublishGIV = null;
		
		try {
			if(loggerForInvUpdatesToGIV.isDebugEnabled())
				loggerForInvUpdatesToGIV
				.debug("Input XML to KohlsPocInventoryUpdatesToGIV.generateAndPublishInventoryUpdatesToGIV is: \n"
						+ XMLUtil.getXMLString(inDoc));
			
			// load recycle fee skus in the list 
			loadSpecialSKUs(env);
			
			// Fetch map with items and qty eligible to publish to GIV
			getOrderListDetails(env, inDoc);
			String sGivRuleEnabled=givRuleEnabled(env);
				inputPublishGIV = YFCDocument.createDocument(
						KohlsPOCConstant.ELEM_ITEMS).getDocument();
				Element eleInvHdr = inputPublishGIV.getDocumentElement();
				if (strMessageType
						.equalsIgnoreCase(KohlsPOCConstant.POST_VOID)) {
					if (documentType.equalsIgnoreCase(KohlsPOCConstant.RO_DOCUMENT_TYPE)) {
						
						if(!YFCCommon.isVoid(sGivRuleEnabled))
						{
						if(sGivRuleEnabled.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
						{
					
					Element eleOrginalTransaction = XMLUtil.createChild(eleInvHdr,
							KohlsPOCConstant.ORIG_TRANSCTION);
					
					eleOrginalTransaction.setAttribute(KohlsPOCConstant.ATTR_SHIP_NODE, strOrganizationCode);
					
					eleOrginalTransaction.setAttribute(KohlsPOCConstant.REFERENCE_ONE, strTerminalID);
					
					eleOrginalTransaction.setAttribute(KohlsPOCConstant.REFERENCE_TWO, strOrigPosSeqNo);
					
					
					eleOrginalTransaction.setAttribute(KohlsPOCConstant.REFERENCE_THREE, strOrderDate);
					}
					}
					}
					
				}
				
				
				Element eleItem = null;
				Set entries = mapItemQty.entrySet();
				Iterator iterator = entries.iterator();
				String key = null;
				String[] aryIDUOM = null;
				while (iterator.hasNext()) {
					Map.Entry entry = (Map.Entry) iterator.next();
					key = (String) entry.getKey();
					aryIDUOM = key.split(delimiter);
					eleItem = XMLUtil.createChild(eleInvHdr,
							KohlsPOCConstant.ELEM_ITEM);
					eleItem.setAttribute(KohlsPOCConstant.ADJUSTMENTTYPE,
							KohlsPOCConstant.ADJUSTMENT);
					eleItem.setAttribute(KohlsPOCConstant.AVAILABLITY,
							KohlsPOCConstant.TRACK);
					eleItem.setAttribute(KohlsPOCConstant.ETA,
							KohlsPOCConstant.DEFAULT_ETA);
					eleItem.setAttribute(KohlsPOCConstant.A_ITEM_ID,
							aryIDUOM[0]);
					
					// Sending +ve quantity for post voided lines
					if (strMessageType
							.equalsIgnoreCase(KohlsPOCConstant.POST_VOID)) {
						if (documentType.equalsIgnoreCase(KohlsPOCConstant.SO_DOCUMENT_TYPE)) {
						eleItem.setAttribute(KohlsPOCConstant.A_QUANTITY, entry
								.getValue().toString());
						} else if  (documentType.equalsIgnoreCase(KohlsPOCConstant.RO_DOCUMENT_TYPE)) {
							eleItem.setAttribute(KohlsPOCConstant.A_QUANTITY, "-".concat(entry
									.getValue().toString()));
						}
						eleItem.setAttribute("ReasonCode", "POST_VOID");
					}
					// Sending -ve quantity and Reason code as SALE for Sale
					// lines
					if (strMessageType.equalsIgnoreCase(KohlsPOCConstant.SALE)) {
						eleItem.setAttribute(KohlsPOCConstant.A_QUANTITY,
								"-".concat(entry.getValue().toString()));
						if(!YFCCommon.isStringVoid(strOrderPurpose) && strOrderPurpose.equalsIgnoreCase(KohlsXMLLiterals.CONST_EXCHANGE)){
							eleItem.setAttribute("ReasonCode", KohlsXMLLiterals.CONST_EXCHANGE);
						}
						else{
						eleItem.setAttribute("ReasonCode", "SALE");
						}
					} else if (strMessageType.equalsIgnoreCase(KohlsXMLLiterals.A_RETURN)) {
						// Sending +ve quantity for return lines
						eleItem.setAttribute(KohlsPOCConstant.A_QUANTITY, entry
								.getValue().toString());
						eleItem.setAttribute("ReasonCode", "RETURN");
						if(aryIDUOM.length>=3)
						{
							if(!YFCCommon.isVoid(sGivRuleEnabled))
							{
								if(sGivRuleEnabled.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
								{
									if(aryIDUOM[2].equals(KohlsPOCConstant.FLAG_Y))
									{
										eleItem.setAttribute(KohlsPOCConstant.REASON_TEXT,
												"01");
									}
							}
							}
								
							
						}
					}
					eleItem.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE,
							aryIDUOM[1]);
					//Defect 4326 - fix - Start
					eleItem.setAttribute(KohlsPOCConstant.A_ORG_CODE,
							KohlsPOCConstant.ITEM_ORGANIZATION_CODE);
					//Defect 4326 - fix - End
					eleItem.setAttribute(KohlsPOCConstant.A_PRODUCT_CLASS,
							KohlsPOCConstant.PRODUCT_CLASS_GOOD);
					eleItem.setAttribute("Reference_1", strTerminalID);
					
					
						eleItem.setAttribute("Reference_2", strPosSequenceNo);
						
					
					eleItem.setAttribute("Reference_3", strOrderDate);
					eleItem.setAttribute(KohlsPOCConstant.ATTR_SHIP_NODE,
							strOrganizationCode);
					
					if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase(documentType)) {
						boolean boolEcomStore = KohlsCommonUtil.isReceivingNodeEFC(env,strOrganizationCode);
						if(boolEcomStore) {
							eleItem.setAttribute(KohlsPOCConstant.ATTR_SUPPLY_TYPE,
									KohlsPOCConstant.SUPPLY_TYPE_EF_ONHAND);
						}
						else {
							eleItem.setAttribute(KohlsPOCConstant.ATTR_SUPPLY_TYPE,
									KohlsPOCConstant.SUPPLY_TYPE);
						}
					} //if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase(documentType))
					else {
						eleItem.setAttribute(KohlsPOCConstant.ATTR_SUPPLY_TYPE,
								KohlsPOCConstant.SUPPLY_TYPE);
					}
				}		
		} catch (Exception exception) {
			loggerForInvUpdatesToGIV
			.endTimer("KohlsPocInventoryUpdatesToGIV.generateAndPublishInventoryUpdatesToGIV");
			exception.printStackTrace();
			if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
			}
		}

		loggerForInvUpdatesToGIV
				.endTimer("KohlsPocInventoryUpdatesToGIV.generateAndPublishInventoryUpdatesToGIV");
		
		if(loggerForInvUpdatesToGIV.isDebugEnabled())
			loggerForInvUpdatesToGIV.debug("*** Message to be published is \n" + XMLUtil.getXMLString(inputPublishGIV));
		return inputPublishGIV;
	}

	/**
	 * This function fetches the order details to be posted to GIV.
	 * 
	 * @param env
	 * @param inputDoc
	 * @return 
	 * @exception Exception
	 * 
	 */
	private void getOrderListDetails(YFSEnvironment env, Document inDoc)
			throws YFSException {
		loggerForInvUpdatesToGIV
				.beginTimer("KohlsPocInventoryUpdatesToGIV.getOrderListDetails");
		
		loggerForInvUpdatesToGIV
				.debug("KohlsPocInventoryUpdatesToGIV.getOrderListDetails -- Calling getOrderLineDetails");
		try {
			//Document docOrderListOutput = XMLUtil
					//.createDocument("OrderList");
			Element eleInDoc = inDoc.getDocumentElement();
			String strMessageTypeindoc = eleInDoc.getAttribute("MessageType");
			// String srtOrderHeaderKey =
			// eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

			/**Document docGetOrderListInput = XMLUtil
					.createDocument(KohlsPOCConstant.ELEM_ORDER);
			Element eleGetOrderListInput = docGetOrderListInput
					.getDocumentElement();
			eleGetOrderListInput.setAttribute(
					KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
			eleGetOrderListInput.setAttribute(
					KohlsPOCConstant.ATTR_MESSAGE_TYPE, strMessageTypeindoc);

			// Call getOrderList API
			/*docOrderListOutput = invokeAPI(env,
					KohlsPOCConstant.GET_ORDER_LIST_TEMPLATE_FOR_GIV,
					KohlsPOCConstant.API_GET_ORDER_LIST, docGetOrderListInput);*/
			//Element eleImportOrder = XMLUtil.importElement(docOrderListOutput.getDocumentElement(), eleInDoc);
			//docOrderListOutput.getDocumentElement().appendChild(eleImportOrder);
			// Setting Order Level Details
			setOrderLevelDetails(env, inDoc, strMessageTypeindoc);

			// Removing OrderLines that need not be sent to GIV
			NodeList ndListOrderLine = eleInDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			
			if (ndListOrderLine.getLength() != 0) {
				Element eleItem = null;
				Element eleOrderLineExtn = null;
				String strOrderedQty = null;
				String strItemID = null;
				String strItemUOM = null;
				String strIDUOM = null;
				String sExtnDept = null;
				String sExtnSubClass = null;
				String sDummySKUNo = null;
				
				//OMNI2 Begin
				Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
				String codeShortDesc = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);
				if(YFCCommon.isVoid(codeShortDesc)) {
					codeShortDesc = "N";
				}
				//OMNI2 End

				for (int i = 0; i < ndListOrderLine.getLength(); i++) {
					Element eleOrderLine = (Element) ndListOrderLine.item(i);
					 String  sDamageFlag ="";
					//Omni 2 changes to add delivery method check: Starts - CPE-9266
					String deliveryMethod = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_DELIVERY_METHOD);
					//check if deliveryMethod is "CARRY"
					if ((!YFCCommon.isVoid(eleOrderLine) && KohlsPOCConstant.ATTR_DELIVERY_TYPE_CARRY.equals(deliveryMethod)) || KohlsPOCConstant.NO.equalsIgnoreCase(codeShortDesc)) {
					//Omni 2 changes to add delivery method check: Ends - CPE-9266
						
					if (!YFCCommon.isVoid(eleOrderLine)) {
						Element eleOrderAddlnData =KohlsXPathUtil.getElementByXpath(XMLUtil.getDocumentForElement(eleOrderLine), "//OrderLineAddnlDataList/OrderLineAddnlData[@Name='DispositionDetails']");
						
						if(!YFCCommon.isVoid(eleOrderAddlnData))
						{
							 if(loggerForInvUpdatesToGIV.isDebugEnabled())
									loggerForInvUpdatesToGIV.debug("Order Addlitional Data is   : "
											+ XMLUtil.getElementXMLString(eleOrderAddlnData));
								
							
							    sDamageFlag =
							          KohlsXPathUtil.getString(XMLUtil.getDocument(eleOrderAddlnData.getAttribute("Value")), "//DispositionDetails[@DamagedFlag='Y']/@DamagedFlag");
							  
							  
							    if(loggerForInvUpdatesToGIV.isDebugEnabled())
									loggerForInvUpdatesToGIV.debug("Damage Flag is  : "
											+ sDamageFlag);
								
						}
				

						strOrderedQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
						if(YFCCommon.isVoid(strOrderedQty)){
							strOrderedQty = "0.00";
						}
						eleItem = XMLUtil.getFirstElementByName(eleOrderLine,KohlsPOCConstant.ELEM_ITEM);
						
						if(loggerForInvUpdatesToGIV.isDebugEnabled())
							loggerForInvUpdatesToGIV.debug(" Item node List is : "
									+ XMLUtil.getElementXMLString(eleItem));
						strItemID = eleItem
								.getAttribute(KohlsPOCConstant.A_ITEM_ID);
						strItemUOM = eleItem
								.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE);
						if(sDamageFlag.equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
						{
							strIDUOM = strItemID.concat(delimiter).concat(strItemUOM).concat(delimiter).concat(sDamageFlag);
						}
						else{
							strIDUOM = strItemID.concat(delimiter).concat(strItemUOM);
								
						}
						
						eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, "Extn");
						sExtnDept = eleOrderLineExtn
								.getAttribute("ExtnItemDept");
						sExtnSubClass = eleOrderLineExtn
								.getAttribute("ExtnItemSubClass");
						sDummySKUNo = KohlsPoCPnPUtil.prepadString(sExtnDept,
								3, "0")
								+ KohlsPoCPnPUtil.prepadString(sExtnSubClass,
										2, "0") + "000";
						bRecycleFee = isRecycleFeeSKU(strItemID);
						
						//Check if item was voided in the middle of transaction and if yes
						// then do not add it in the map
						if (strMessageType.equalsIgnoreCase(KohlsPOCConstant.SALE)
						    || strMessageType.equalsIgnoreCase(KohlsPOCConstant.RETURN)) {
							if (Double.parseDouble(strOrderedQty) ==
									Double.parseDouble(KohlsPOCConstant.OdotO)
									|| strItemID.equalsIgnoreCase(sDummySKUNo)
									|| bRecycleFee) {
								loggerForInvUpdatesToGIV
										.debug("Order line "+eleOrderLine.getAttribute(
														KohlsPOCConstant.ATTR_PRIME_LINE_NO)
												+ " is voided during the sale. Hence, "
												+ "removing The orderline for SALE scenario.");
								//XMLUtil.removeChild(eleOrderLines, eleOrderLine);
								continue;
							} 
						} else if (strMessageType
								.equalsIgnoreCase(KohlsPOCConstant.POST_VOID)) {
							Element eleTranQty = (Element) XMLUtil
									.getChildElement(eleOrderLine,
											"OrderLineTranQuantity");
							String strShippedQuantity = eleTranQty
									.getAttribute("ShippedQuantity");
							if (YFCCommon.isVoid(strShippedQuantity)){
								strShippedQuantity = "0.00";
							}
							if (strItemID.equalsIgnoreCase(sDummySKUNo)
									|| bRecycleFee 
									|| Double.parseDouble(strShippedQuantity) ==
												Double.parseDouble(KohlsPOCConstant.OdotO)) {
								loggerForInvUpdatesToGIV
										.debug("The ordered quantity for the line "
												+ strItemID
												+ "is :"
												+ strOrderedQty);
								loggerForInvUpdatesToGIV
										.debug("Order line "+ eleOrderLine.getAttribute(
														KohlsPOCConstant.ATTR_PRIME_LINE_NO)
												+" is voided during the sale. Hence, "
												+"removing The orderline for PostVoid scenario.");
								//XMLUtil.removeChild(eleOrderLines, eleOrderLine);
								continue;
							}
						} 
						
						// Update the map with item and qty
						if (YFCObject.isNull(mapItemQty.get(strIDUOM))) {
							mapItemQty.put(strIDUOM, 1);
						} else {
							mapItemQty.put(strIDUOM,
									(mapItemQty.get(strIDUOM) + intQty));
						}						
					}
				}
				}
			}

		} catch (Exception exception) {
			loggerForInvUpdatesToGIV
			.endTimer("KohlsPocInventoryUpdatesToGIV.getOrderListDetails");
			exception.printStackTrace();
			if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
			}
		}
		loggerForInvUpdatesToGIV
				.endTimer("KohlsPocInventoryUpdatesToGIV.getOrderListDetails");		
	}

	private boolean isRecycleFeeSKU(String strItemID)
			throws Exception {
		loggerForInvUpdatesToGIV.beginTimer("KohlsPocInventoryUpdatesToGIV.isRecycleFeeSKU");
		
		if(!specialSKUlist.isEmpty() && specialSKUlist.contains(strItemID)) {
		  loggerForInvUpdatesToGIV.debug("Its a special sku");
		  return true;
		}
		
		loggerForInvUpdatesToGIV.endTimer("KohlsPocInventoryUpdatesToGIV.isRecycleFeeSKU");
		return false;
	}

	/**
	 * This function sets order level static variables.
	 * 
	 * @param env
	 * @param docInvDtlInput
	 * @param strMessageType2
	 */

	private void setOrderLevelDetails(YFSEnvironment env,
			Document docInvDtlInput, String strMessageTypeinDoc) {
		loggerForInvUpdatesToGIV
				.beginTimer("KohlsPocInventoryUpdatesToGIV.setOrderLevelDetails");
		Element eleOrder = (Element) ((NodeList) docInvDtlInput
				.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER)).item(0);

		if (!YFCDocument.isVoid(eleOrder)) {
			Element eleExtn = (Element)eleOrder.getElementsByTagName("Extn").item(0);
			
					if(!YFCCommon.isVoid(eleExtn))
					{
						
						strOrigPosSeqNo=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
					}
			strOrderHeaderKey = eleOrder
					.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			strEnterpriseCode = eleOrder
					.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
			strTerminalID = eleOrder
					.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
			strOrderDate = eleOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
			strPosSequenceNo = eleOrder
					.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
			strOrganizationCode = eleOrder
					.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
			strMessageType = strMessageTypeinDoc;
			documentType=eleOrder
					.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
			strOrderPurpose = eleOrder.getAttribute(KohlsXMLLiterals.ATTR_ORDER_PURPOSE);
			
			if(YFCLogUtil.isDebugEnabled()){
			loggerForInvUpdatesToGIV.debug("KohlsPocInventoryUpdatesToGIV.setOrderLevelDetails strOrderPurpose="+strOrderPurpose);
			}
		}
		loggerForInvUpdatesToGIV
				.endTimer("KohlsPocInventoryUpdatesToGIV.setOrderLevelDetails");
	}
	
	  /**
	   * Create By ibmadmin * 
	   * @param env
	   * @return
	   * @throws Exception
	   */
	  protected void loadSpecialSKUs(YFSEnvironment env) throws Exception {
	    loggerForInvUpdatesToGIV.beginTimer("KohlsPocInventoryUpdatesToGIV.loadSpecialSKUs");
	    Document docInputgetCommonCodeList = XMLUtil.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
	    Element eleCommonCode = docInputgetCommonCodeList.getDocumentElement();
	    
	    //Adding Recycle Fee sku
	    eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
	        KohlsPOCConstant.CODE_TYPE_RECYCLEFEESKUS);
	    Document docCommonCodeListOuput = KOHLSBaseApi.invokeAPI(env,
	        KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docInputgetCommonCodeList);
	    NodeList commonCodeNL =
	        docCommonCodeListOuput.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
	    for (int i = 0; i < commonCodeNL.getLength(); i++) {
	      Element eleCommonCodeOut = (Element) commonCodeNL.item(i);
	      specialSKUlist.add(eleCommonCodeOut.getAttribute(KohlsPOCConstant.ATTR_CODE_NAME));
	    }
	    
	    // Adding spl skus such as shipping sku and Penalty sku in case of returns
	    eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
	        KohlsPOCConstant.VAL_KOHLS_SPL_ITEMS_RET);
	    docCommonCodeListOuput = KOHLSBaseApi.invokeAPI(env,
	        KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docInputgetCommonCodeList);
	    
	    commonCodeNL =
            docCommonCodeListOuput.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
	    for (int i = 0; i < commonCodeNL.getLength(); i++) {
          Element eleCommonCodeOut = (Element) commonCodeNL.item(i);
          specialSKUlist.add(eleCommonCodeOut.getAttribute(KohlsXMLLiterals.A_CODE_VALUE));
        }
	    loggerForInvUpdatesToGIV.endTimer("KohlsPocInventoryUpdatesToGIV.loadSpecialSKUs");
	  }

	  public String givRuleEnabled(YFSEnvironment env) throws Exception {
		  loggerForInvUpdatesToGIV.beginTimer("KohlsPocInventoryUpdatesToGIV.givRuleEnabled");
		    Document docInput = YFCDocument.createDocument("Rule").getDocument();
		    Element eleInput = docInput.getDocumentElement();
		    eleInput.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
		    eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, KohlsPOCConstant.GIV_ENHANCEMENT);
		    Document docOutRule =
		        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docInput);
		    if (!YFCCommon.isVoid(docOutRule)) {
		      Element eleRule = (Element) docOutRule.getElementsByTagName(KohlsPOCConstant.E_RULE).item(0);

		      if (!YFCCommon.isVoid(eleRule)) {
		    	  loggerForInvUpdatesToGIV.endTimer("KohlsPocInventoryUpdatesToGIV.givRuleEnabled");
		        return eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
		      }
		    }
		    loggerForInvUpdatesToGIV.endTimer("KohlsPocInventoryUpdatesToGIV.givRuleEnabled");
		    return "N";
		  }
}
