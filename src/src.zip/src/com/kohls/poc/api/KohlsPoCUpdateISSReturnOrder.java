package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.util.ServerType;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCUpdateISSReturnOrder extends KOHLSBaseApi {
    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCUpdateISSReturnOrder.class);

    public Document updateOrder(YFSEnvironment env, Document inDoc) throws Exception {
    	
    		 logger.debug("KohlsPoCUpdateISSReturnOrder.updateOrder  Begin");
	    	 if(ServerTypeHelper.amIOnEdgeServer())
	    	 {
	        
	        Element inElement = inDoc.getDocumentElement();
	        String orderHeaderkey = inElement.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
	        Document inputOrderListDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
	        inputOrderListDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderkey);
	        String orderListTemplate = KohlsPOCConstant.GETORDERLISTFOREXCHANGE_TEMPLATE;
	        Document orderListDoc = invokeAPI(env, orderListTemplate, KohlsPOCConstant.API_GET_ORDER_LIST,
	                inputOrderListDoc);
	        if (!YFCCommon.isVoid(orderListDoc)) {
	
	            NodeList exchangeList = XPathUtil.getNodeList(orderListDoc.getDocumentElement(),
	                    KohlsPOCConstant.EXCHANGEORDER_XPATH);
	            if (exchangeList.getLength() > 0) {
	                logger.debug("Return is associated with exchange");
	                Document inputChangeOrderDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
	                inputChangeOrderDoc.getDocumentElement()
	                        .setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderkey);
	                inputChangeOrderDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORDER_NAME,
	                        KohlsPOCConstant.CONSTANT_RETURN_WITH_EXCHANGE);
	                invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, inputChangeOrderDoc);
	            }
	
	        }
	        logger.debug("KohlsPoCUpdateISSReturnOrder.updateOrder  End");
	        
	    }
	    	return inDoc;
    }
}
