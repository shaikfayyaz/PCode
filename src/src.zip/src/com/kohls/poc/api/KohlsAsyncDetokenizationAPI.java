package com.kohls.poc.api;

import java.util.Properties;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCInvokeDataSecurityPlatform;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsAsyncDetokenizationAPI extends KOHLSBaseApi {

	/**
	 * This custom API is used to invoke createReprocessRequest API. The service
	 * name which is to be passed in the input of createReprocessRequest api is
	 * passed a argument to this custom api.
	 * 
	 */

	String sServiceName = "";
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsAsyncDetokenizationAPI.class
				.getName());
	}
	private KohlsPoCInvokeDataSecurityPlatform invokeDataSecurity = new KohlsPoCInvokeDataSecurityPlatform();
	KohlsReprocessRequestUtil requestUtilObj = new KohlsReprocessRequestUtil();
	private Properties props = null;
	/**
	 * sHostXC to save host details.
	 */
	private String sHostXC = null;
	/**
	 * dataElement to save dataElement value.
	 */
	private String dataElement = null;
	/**
	 * policyUser is to save userName.
	 */
	private String policyUser = null;

	public Document decryptyXml(YFSEnvironment env, Document inXml)
			throws Exception {
		logger.beginTimer("KohlsPocDetokenization.encryptDecryptXML");
		
		if(logger.isDebugEnabled()){
			logger.debug("Input XML to KohlsPocDetokenization.decryptyXML is: "+ XMLUtil.getXMLString(inXml));
			logger.debug("commonCodeProperties Before loading ::"+ requestUtilObj.propsFromCommonCode);
		}
		
		String attribute = null;
		String attributePart1 = null;
		String attributePart2 = null;
		String[] delimitedSlash = null;
		String conversionType = null;
		String cryptingAttribute = null;
		String xPath = null;
		String attributeNo = null;
		/*
		 * Map<String, String> attributesDataMap = new HashMap<String,
		 * String>(); Element rootElement = inXml.getDocumentElement();
		 */
		int noOfAttributes = Integer.valueOf(this.props
				.getProperty(KohlsPOCConstant.NoOfAttributes));
		/*
		 * sHostXC = new String("nlg00601.tst.kohls.com:15911"); policyUser =
		 * new String("shdev");
		 */
		sHostXC = this
				.getPropertyValue(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
		policyUser = this.getPropertyValue(KohlsPOCConstant.POLICY_USER);
		logger.debug("The PROTEGRITY_SERVER_HOST is : " + sHostXC);
		logger.debug("The POLICY_USER is : " + policyUser);

		/*
		 * sHostXC = new String("localhost:15910"); policyUser = new
		 * String("shdev");
		 */
		logger.debug("The noOfAttributes value is : " + noOfAttributes);

		for (int m = 0; m < noOfAttributes; m++) {

			attributeNo = "Attribute" + (m + 1);
			logger.debug("The attribute No is : " + attributeNo);
			attributePart1 = this.props.getProperty(attributeNo + "_1");
			attributePart2 = this.props.getProperty(attributeNo + "_2");
			if (attributePart2 == null) {
				attributePart2 = " ";
			}
			// logger.debug("The attribute value is : " + attributePart1);
			attribute = attributePart1.concat(attributePart2).trim();
			logger.debug("The attribute to be encrypted is : " + attributePart2);
			delimitedSlash = attribute.split(KohlsPOCConstant.DelimitedSlash);
			logger.debug("the attribute is " + attribute);

			conversionType = delimitedSlash[0];
			logger.debug("the conversionType is " + conversionType);

			xPath = delimitedSlash[2];
			logger.debug("the xPath is " + xPath);

			cryptingAttribute = delimitedSlash[3];
			logger.debug("the cryptingAtribute is " + cryptingAttribute);

			dataElement = delimitedSlash[1];
			logger.debug("the dataElement is " + dataElement);

			if (!YFCCommon.isVoid(cryptingAttribute)) {
				// invokeDataSecurity.run(sHostXC, dataElement, policyUser);
				searchAndReplaceByGenericXPath(env, inXml, conversionType,
						cryptingAttribute, dataElement, xPath);

			}
			
		}
		
		if(logger.isDebugEnabled())
			logger.debug("Output XML from KohlsPoCSecurityUtil.encryptDecryptXML is: "+ XMLUtil.getXMLString(inXml));
		
		logger.endTimer("KohlsPoCSecurityUtil.encryptDecryptXML");
		return inXml;

	}

	public Document searchAndReplaceByGenericXPath(YFSEnvironment env,
			Document inDoc, String conversionType, String cryptingAttribute,
			String dataElement, String xPath) throws Exception {

		logger.beginTimer("KohlsPoCSecurityUtil.searchAndReplaceByGenericXPath");
		String cryptingAttributeValue = null;
		Element inElem = inDoc.getDocumentElement();
		
		if(logger.isDebugEnabled())
			logger.debug("the input element of the service is "+ XMLUtil.getElementXMLString(inElem));
		
		sServiceName = this.props.getProperty(KohlsPOCConstant.SERVICE_NAME);
		// Load the Collections for the first time call
//      if (YFCCommon.isVoid(requestUtilObj.propsFromCommonCode)) {
            requestUtilObj.loadPropsFromCommonCode(env, KohlsPOCConstant.COMMON_CODE_FOR_REPROCESS, sServiceName);
            logger.debug("commonCodeProperties after loading ::"
                    + requestUtilObj.propsFromCommonCode);
//      }
		String strErrCount = null;
		Element eleExtn = null;
		Element baseElement = null;
		Element awardEle = null;
		String extnIsDetokenized;
		String orderInvoiceKey = XPathUtil.getString(
				inDoc.getDocumentElement(),
				"/InvoiceDetail/InvoiceHeader/@OrderInvoiceKey");
		Element eleReprocessReq = requestUtilObj
				.getReprocessRecordFromDB(env, sServiceName, orderInvoiceKey);
		try {
			NodeList awardsList = (NodeList) XPathUtil
					.getNodeList(inDoc.getDocumentElement(),
					 "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine/Awards/Award");
			NodeList baseElementList = ((NodeList) XPathUtil.getNodeList(
					inDoc.getDocumentElement(), xPath));
			for (int i = 0; i < baseElementList.getLength(); i++) {
				baseElement = (Element) baseElementList.item(i);
				
				
				if(logger.isDebugEnabled())
					logger.debug("the base element is "+ XMLUtil.getElementXMLString(baseElement));
				
				eleExtn = XMLUtil.getChildElement(baseElement, "Extn");
				extnIsDetokenized = eleExtn.getAttribute("ExtnIsDetokenized");
				cryptingAttributeValue = baseElement
						.getAttribute(cryptingAttribute);
				if (!YFCCommon.isVoid(awardsList)) {
					for (int j = 0; j < awardsList.getLength(); j++) {
						awardEle = (Element) awardsList.item(j);
						if (!YFCCommon.isVoid(awardEle)
								&& cryptingAttributeValue.equals(awardEle
										.getAttribute("PromotionId"))) {
							break;
						}
					}
				}
				logger.debug("the crypting attribute Value is "
						+ cryptingAttributeValue);
				if (extnIsDetokenized != null
						&& extnIsDetokenized.equalsIgnoreCase("N")) {
					if (!YFCCommon.isVoid(cryptingAttributeValue)
							&& cryptingAttribute
									.equalsIgnoreCase("PromotionId")) {
						// initializing the crypt 
						invokeDataSecurity
								.run(sHostXC, policyUser);

						logger.debug("conversion type :: " + conversionType);
						String strDetokenize = invokeDataSecurity
								.returnDecryptedValueForDetokenization(cryptingAttributeValue, dataElement);
						logger.debug("the value after decrypting is "
								+ strDetokenize);
						setCryptedValues(env, inDoc, baseElement, strDetokenize,
								cryptingAttribute, awardEle);
						// Closing the Protegrity server session
						invokeDataSecurity.closeSession();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			YFSException es = new YFSException();
			if (e.getClass().getName()
					.equalsIgnoreCase("com.protegrity.common.XCException")) {
				logger.debug("Setting the YFSException");
				es.setErrorCode("Protegrity Server Down");
				es.setErrorDescription("Unable to complete request (Protegrity), to Encrypt PII Data");
			}
			int maxErrCount = Integer.parseInt(requestUtilObj.propsFromCommonCode
					.get(sServiceName + ".MaxErrorCount"));
			logger.debug("sMaxErrorCount" + maxErrCount);
			if (!YFCCommon.isVoid(eleReprocessReq)) {
				strErrCount = requestUtilObj
						.getErrorCount(eleReprocessReq);
			}
//			String version = this.getPropertyValue("VERSION");
//			if(YFCCommon.isVoid(version)){
//				version = "";
//			}
			String version="";
			logger.debug("Version ::"+version);
			logger.debug("strErrCount is null or not-->" + strErrCount);
			if(YFCCommon.isVoid(strErrCount)){
				logger.debug("Inside If strErrCount is 0");
				logger.debug("Service Name :: "+sServiceName);
				strErrCount="0";
				requestUtilObj
						.createReprocessRequest(env, sServiceName, inDoc);
				eleExtn.setAttribute("ExtnMaxErrorCount", strErrCount);
			}else{
				logger.debug("strErrCount-->" + Integer.parseInt(strErrCount));
				if (Integer.parseInt(strErrCount) < maxErrCount) {
					logger.debug("Inside MaxErrorCount less than 5");
					eleExtn.setAttribute("ExtnMaxErrorCount", strErrCount);
					if (Integer.parseInt(strErrCount) == (maxErrCount - 1)) {
					logger.debug("Before SetDefaultValues");
					eleExtn.setAttribute("ExtnMaxErrorCount", strErrCount);
						setDefaultValues(env, inDoc, baseElement, cryptingAttribute,
								awardEle);
					}
				}
				logger.debug("Throwing exception");
				throw e;
			}
		}
		logger.endTimer("KohlsPocDetokenization.searchAndReplaceByGenericXPath");
		return inDoc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.yantra.interop.japi.YIFCustomApi#setProperties(java.util.Properties)
	 */
	public void setProperties(Properties prop) throws Exception {
		props = prop;
	}

	public static String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		// customer_overrides.properties does not return any value
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}

		return propValue;

	}

	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void setCryptedValues(YFSEnvironment env,Document inDoc,Element baseElement, String strDetokenize,
			String cryptingAttribute, Element awardEle) throws DOMException {
		logger.beginTimer("KohlsPoCSecurityUtil.setCryptedValues");
		logger.debug("KohlsPoCSecurityUtil.setCryptedValues strDetokenize::"
				+ strDetokenize);
		Element eleExtn = XMLUtil.getChildElement(baseElement, "Extn");
		if (!YFCCommon.isVoid(strDetokenize)) {
			eleExtn.setAttribute("ExtnIsDetokenized", "Y");
			eleExtn.setAttribute("ExtnActivationBarCode",strDetokenize);
			baseElement.setAttribute(cryptingAttribute, strDetokenize);
			if(!YFCCommon.isVoid(awardEle))
			awardEle.setAttribute(cryptingAttribute, strDetokenize);
		} else {
			eleExtn.setAttribute("ExtnIsDetokenized", "N");
		}
		try {
			KOHLSBaseApi.invokeService(env, "KohlsPoCDetokeniseToSalesHub", inDoc);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Exception while invoking the service");
		}
		logger.endTimer("KohlsPoCSecurityUtil.setCryptedValues");
	}
	
	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void setDefaultValues(YFSEnvironment env,Document inDoc, Element baseElement,
			String cryptingAttribute, Element awardEle) throws DOMException {
		logger.beginTimer("KohlsPoCSecurityUtil.setCryptedValues");

		Element eleExtn = XMLUtil.getChildElement(baseElement, "Extn");
		eleExtn.setAttribute("ExtnIsDetokenized", "N");
		eleExtn.setAttribute("ExtnActivationBarCode","");
		baseElement.setAttribute(cryptingAttribute, "");
		if(!YFCCommon.isVoid(awardEle))
		awardEle.setAttribute(cryptingAttribute, "");
		try {
			KOHLSBaseApi.invokeService(env, "KohlsPoCDetokeniseToSalesHub", inDoc);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Exception while invoking the service");
		}
		logger.endTimer("KohlsPoCSecurityUtil.setCryptedValues");
		}

	public void throwError(YFSEnvironment env, Document inXML) {
		throw new YFSException(KohlsXMLUtil.getXMLString(inXML),
				"Protegrity Server Down",
				"Unable to complete request (Protegrity), to Encrypt PII Data");
	}

	
	public Document removeErrorCount(YFSEnvironment env, Document inXML)
			throws Exception {
		logger.debug("RemoveErrorCount - Start");
		String xpath = this.props.getProperty("xpath");
		NodeList promotionList = ((NodeList) XPathUtil.getNodeList(
				inXML.getDocumentElement(), xpath));
		Element promotionEle = null;
		Element eleExtn = null;
		for (int i = 0; i < promotionList.getLength(); i++) {
			logger.debug("Inside for");
			promotionEle = (Element) promotionList.item(i);
			eleExtn = XMLUtil.getChildElement(promotionEle, "Extn");
			if(!YFCCommon.isVoid(eleExtn.getAttribute("ExtnMaxErrorCount"))){
				eleExtn.removeAttribute("ExtnMaxErrorCount");
			}
		}	
		
		if(logger.isDebugEnabled())
			logger.debug("inXML after removing errorcount ::"+ XMLUtil.getXMLString(inXML));
		
		logger.debug("RemoveErrorCount - End");
		return inXML;
	}
}
