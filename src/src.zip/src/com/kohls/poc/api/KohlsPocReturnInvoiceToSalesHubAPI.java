package com.kohls.poc.api;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


 

 public  class KohlsPocReturnInvoiceToSalesHubAPI extends KOHLSBaseApi {
 	 private static final YFCLogCategory 
 	loggerForPosInvoice = YFCLogCategory
		.instance(KohlsPocReturnInvoiceToSalesHubAPI.class.getName());
 	 
 	 private String strOrderHeaderKey=null;
 	 private String strOrganizationCode=null;
 	 private String strEnterpriseCode=null;
 	 private String strOrderNo=null;
 	 private boolean bIsVoidDuring = false;
 	 //CPE-7581 start
 	 private boolean bIsReturnOrder = false;
 	//CPE-7581 end
 	 private  Map<String, Element> mTieredDiscount = new LinkedHashMap<String, Element>();
 	 
 	/**
 	 * This function generates the document to be sent to Sales Hub
 	 * 
 	 * @param env
 	 * @param inputPublishInvoiceDetail
 	 * @return docOutputPublishPOSInvoice
 	 * @exception Exception
 	 *  The file extracts Invoice Information during the Void During flow of 
         *  Return with or without an return item in the flow of Evenexchange         
 	 */
	 public Document generateAndPublishPOSInvoiceToSalesHub(
			 	YFSEnvironment env, Document inputPublishInvoiceDetail) throws Exception{
		 
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub");
		 Document docVoidTenderChargeTransactionDetails = null;
		 Element eleInvoiceHeader = null;
		 
		 try {
			 
			 if(loggerForPosInvoice.isDebugEnabled())
				 loggerForPosInvoice.debug("Input XML to KohlsPocReturnInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub is: \n"+
						 XMLUtil.getXMLString(inputPublishInvoiceDetail));
		
		//Changes for 2455 - Start
		
		Element eleOriginalOrder = (Element)((NodeList)XPathUtil.getNodeList(inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);
		
		String sOHKey=eleOriginalOrder.getAttribute("OrderHeaderKey");
		
		Document docOrigInput = XMLUtil.getDocument("<Order ReturnOrderHeaderKeyForExchange='"+sOHKey+"'/>");
		
		// Document docGetOrderDetailsOutTemplate = XMLUtil.getDocument("<Order><ExchangeOrders><ExchangeOrder /></ExchangeOrders></Order>"); 	
			
		// Document docGetOrderDetails = KohlsCommonUtil.invokeAPI(env, docGetOrderDetailsOutTemplate, "getOrderDetails",docOrigInput);
			
		Document docGetOrderDetails = KohlsCommonUtil.invokeAPI(env, "getOrderList", docOrigInput);
		 
		 Element eleExchange = (Element)((NodeList)XPathUtil.getNodeList(docGetOrderDetails.getDocumentElement(), "/OrderList/Order")).item(0);
		 
		 if(!YFCCommon.isVoid(eleExchange)){
		 String sxchOHKey = eleExchange.getAttribute("OrderHeaderKey");
			if(!YFCCommon.isVoid(sxchOHKey)){
				
				Element eleInv = inputPublishInvoiceDetail.getDocumentElement();
				eleInv.setAttribute("hasExchange", "Y");
				
				return inputPublishInvoiceDetail;
			}
		
		 }
		
		
		//Changes for 2455 - End
		 
		//Fetch getOrderList API
		 Document docGetOrderListDetails = this.getOrderListDetails(env, inputPublishInvoiceDetail);
		 
		 
		
		 Element eleOrder = (Element)((NodeList)XPathUtil.getNodeList(docGetOrderListDetails.getDocumentElement(), "/OrderList/Order")).item(0);
		 Element eleOrderExtn = (Element)((NodeList)XPathUtil.getNodeList(docGetOrderListDetails.getDocumentElement(), "/OrderList/Order/Extn")).item(0);
		 
		// PST-8708 - Start
		if (!YFCCommon.isVoid(eleOrderExtn))
		{
			String sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE); 
    		if (KohlsPOCConstant.NON_RECEIPTED_RET.equalsIgnoreCase(sExtnPOCFeature)) 
    		{
				if (!YFCCommon.isVoid(eleOrderExtn.getAttribute(KohlsConstant.EXTN_DL_FOR_SYS)))
				{
					String sExtnDLForSys=eleOrderExtn.getAttribute(KohlsConstant.EXTN_DL_FOR_SYS);
					eleOrderExtn.setAttribute(KohlsConstant.EXTN_DL_NUMBER_FORMAT, sExtnDLForSys);
					KohlsPocInvoiceToSalesHubAPI kohlsPocInvoiceToSalesHubAPI = new KohlsPocInvoiceToSalesHubAPI();
					eleOrderExtn.setAttribute(KohlsConstant.EXTN_DL_FOR_SYS, kohlsPocInvoiceToSalesHubAPI.convertDL(sExtnDLForSys));
				}
			}
		} //PST-8708 - End

		 String strExtnTaxDetails=eleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
		 String sIDScanDetails = eleOrderExtn.getAttribute("ExtnIDScanDetails");
		 Element eleIDScanDetails=null;
		 if(!YFCCommon.isVoid(sIDScanDetails))
		 {
			 Document docExtnIDScanDetils=XMLUtil.getDocument(sIDScanDetails);
			 eleOrderExtn.setAttribute("ExtnIDScanDetails", KohlsPOCConstant.BLANK);
			 eleIDScanDetails = docExtnIDScanDetils.getDocumentElement();
			 XMLUtil.importElement(eleOrder,eleIDScanDetails);
		 }
		 Element eleTaxDetails = null;
		 if(!YFCCommon.isVoid(strExtnTaxDetails))
		 {
			 Document docExtnTaxDetails=XMLUtil.getDocument(strExtnTaxDetails);
			 eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
			 eleTaxDetails = docExtnTaxDetails.getDocumentElement();
			 XMLUtil.importElement(eleOrder,eleTaxDetails);
		 }
		 
		 eleInvoiceHeader = (Element) ((NodeList) XPathUtil.getNodeList(inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader")).item(0);
		 Element eleInvoiceOrder = (Element) ((NodeList) XPathUtil.getNodeList(inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);
		 eleInvoiceHeader.removeChild(eleInvoiceOrder);
		 
		 XMLUtil.importElement(eleInvoiceHeader, eleOrder);
		 Element eleInvOrder = (Element)((NodeList)XPathUtil.getNodeList(inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);
		 
	
		 
		 Element elePaymentMethods = (Element)((NodeList)XPathUtil.getNodeList(inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order/PaymentMethods")).item(0);
		 eleInvOrder.removeChild(elePaymentMethods);
		 
	 	 docVoidTenderChargeTransactionDetails = this.getVoidTenderChargeTransactionDetails(env);
		 NodeList ndListVTCTDetails = docVoidTenderChargeTransactionDetails.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
		 Element eleVoidTenderChargeTransactionDetails = (Element) ndListVTCTDetails.item(0);
		 XMLUtil.importElement(eleInvOrder, eleVoidTenderChargeTransactionDetails);
		 		 
		 Document docTransAuditList = this.getCreateTransactionDetails(env);
		 Element eleTransAuditDetails = (Element)((NodeList)docTransAuditList.getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDITS)).item(0);
		 XMLUtil.importElement(eleInvoiceHeader, eleTransAuditDetails);
		 
		 inputPublishInvoiceDetail=addAuthIDForCollectionDetails(env,inputPublishInvoiceDetail);
		 // PST-843 changes start
         inputPublishInvoiceDetail = setDateInvoicedForSaleSyncedToCorp(env, inputPublishInvoiceDetail, eleInvoiceHeader, eleInvoiceOrder);
         // PST-843 changes end
		 if(mTieredDiscount.size()>0){
			
			 Element eleTLDList = inputPublishInvoiceDetail.createElement("TransactionLevelDiscountList");
			 eleInvOrder.appendChild(eleTLDList);
			 for(String key : mTieredDiscount.keySet()){
				 XMLUtil.importElement(eleTLDList, mTieredDiscount.get(key));				
			 }
			 mTieredDiscount.clear();
		 }
	 }
	catch (Exception exception){
		exception.printStackTrace();
		 if (exception instanceof YFSException) {
			YFSException yfsException = (YFSException) exception;
			throw yfsException;
		 }
	}	
		 if (bIsVoidDuring){
			 //CPE-7581 changes
			 if(bIsReturnOrder){
				 inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "ReturnVoidDuring");				 
			 }else{
				 //CPE-7581 changes end
				 inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "EE_VoidDuring");
			 }
		 } else {
			 inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "");
		 }
		 
		 if(loggerForPosInvoice.isDebugEnabled())
			 loggerForPosInvoice.debug("Output XML from KohlsPocReturnInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub is: \n"+
					 XMLUtil.getXMLString(inputPublishInvoiceDetail));

		 inputPublishInvoiceDetail = removeLineDetails(env,inputPublishInvoiceDetail);
		 
		 if(loggerForPosInvoice.isDebugEnabled())
			 loggerForPosInvoice.debug("Output XML from KohlsPocReturnInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub after removeLineDetails() is: \n"+
					 XMLUtil.getXMLString(inputPublishInvoiceDetail));
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub");
		 return inputPublishInvoiceDetail;
	 }
	 
	 
	
		 
	 
	 public Document addAuthIDForCollectionDetails(YFSEnvironment env, Document invoiceInputDoc) throws Exception{
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.addAuthIDForCollectionDetails");
		 NodeList eleCollectionList = (NodeList) XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail");
		 
		

		 for(int i = 0; i < eleCollectionList.getLength(); i++){
			 
			 Element eleCollection = (Element)eleCollectionList.item(i);
			 Element elePaymentMethod = (Element) XMLUtil.getChildElement(eleCollection,"PaymentMethod");
		 }

		 
		 
		 
		 Document docOutputPymtExtnList = null;
		 for(int i = 0; i < eleCollectionList.getLength(); i++){
			 Element eleCollection=(Element)eleCollectionList.item(i);
			 if(!YFCCommon.isVoid(eleCollection.getAttribute("AuthorizationID"))){
				 String sAuthID=eleCollection.getAttribute("AuthorizationID");
				 String[] authIDSplits=sAuthID.split("=");
				 eleCollection.setAttribute("AuthorizationID", authIDSplits[0]);
			 }
			 Element eleCreditCardTransactions = (Element)eleCollection.getElementsByTagName(KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTIONS).item(0);
			 NodeList ndListCreditCardTransList = eleCollection.getElementsByTagName(KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTION);
			 if(ndListCreditCardTransList.getLength() == 0 && !YFCCommon.isVoid(eleCollection.getAttribute("CallForAuthorizationStatus")) && eleCollection.getAttribute("CallForAuthorizationStatus").equalsIgnoreCase("CLOSED"))
			 {
		
				 // If the Payment extension is null then call KohlsPoCGetPaymentExtnList service
				 if(YFCCommon.isVoid(docOutputPymtExtnList)){
					 Element eleOrder = (Element)((NodeList)XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);
					 Document docInputForPaymentExtnList =  YFCDocument.createDocument(KohlsPOCConstant.ELEM_KOHLS_PAYMENT_EXTENSION).getDocument();
					 docInputForPaymentExtnList.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
					 docOutputPymtExtnList = invokeService(env,"KohlsPoCGetPaymentExtnList", docInputForPaymentExtnList);
				 }
				 String sPaymentKey = eleCollection.getAttribute("PaymentKey");
				 Element elePymtExtn = (Element)((NodeList)XPathUtil.getNodeList(docOutputPymtExtnList.getDocumentElement(), 
						 "/KohlsPaymentExtensionList/KohlsPaymentExtension[@PaymentKey='"+sPaymentKey+"']")).item(0);				 
				//Set the attributes from elePymtExt to eleCreditCardTran
				 String strExtnPaymentData=elePymtExtn.getAttribute("ExtnPaymentData");
				 if(!YFCCommon.isVoid(strExtnPaymentData))
				 {
					 Document docExtnPaymentData=XMLUtil.getDocument(strExtnPaymentData);
					 XMLUtil.importElement(eleCreditCardTransactions,docExtnPaymentData.getDocumentElement());
				 }
			 }
		
		 }
		 
		
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.addAuthIDForCollectionDetails");		 
	 return invoiceInputDoc;
	 }
	 /**
	 	 * This function fetches the order details to be posted to Sales Hub.
	 	 * 
	 	 * @param env
	 	 * @param inputDoc
	 	 * @return docOutputPublishPOSInvoice
	 	 * @exception Exception
	 	 *           
	 	 */
	 private Document getOrderListDetails(YFSEnvironment env, Document inVoiceInputDoc) throws YFSException {
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.getOrderListDetails");
		 Document docOrderListOutput = null;
		 loggerForPosInvoice.debug("KohlsPocReturnInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub -- Calling getOrderLineDetails");
		 	try {
		 		
		 		setOrderLevelDetails(env, inVoiceInputDoc);
		 		
		 		//Create Input XML for getOrderList API
				 
				 Document docInputForGetOrderList =  YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
				 Element eleOrderInput = docInputForGetOrderList.getDocumentElement();
				 eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
				 eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, strEnterpriseCode);
			
				 // Call getOrderList API
				 docOrderListOutput = invokeAPI(env,KohlsPOCConstant.GET_ORDER_LIST_OUTPUT,KohlsPOCConstant.API_GET_ORDER_LIST, docInputForGetOrderList);
				 // MAD-101 start
				 Element orderElement = null;
				 if (!YFCCommon.isVoid(docOrderListOutput)) {
					orderElement = (Element) ((NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(), "/OrderList/Order")).item(0);
					orderElement.removeAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER);
				 }
				 // MAD-101 End
				 //Check if transaction is Void During or Sale
				 Element eleOrderExtn = (Element)((NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(), "/OrderList/Order/Extn")).item(0);
				 String sExtnIsVoidDuring = eleOrderExtn.getAttribute("ExtnIsVoidDuring");
				 if (!YFCCommon.isVoid(sExtnIsVoidDuring) && "Y".equalsIgnoreCase(sExtnIsVoidDuring)){
					 bIsVoidDuring = true;
				 }
				 //CPE-7581 changes for mid void of return message type
				 String sExtnPOCFeature = eleOrderExtn.getAttribute("ExtnPOCFeature"); 
				 if(bIsVoidDuring && !YFCCommon.isVoid(sExtnPOCFeature) && (KohlsPOCConstant.RECEIPTED_RET.equalsIgnoreCase(sExtnPOCFeature) || 
						 KohlsPOCConstant.NON_RECEIPTED_RET.equalsIgnoreCase(sExtnPOCFeature))){
					 bIsReturnOrder = true; 
				 }
				 //CPE-7581 changes for mid void of return message type
				 NodeList ndListOrderLine = (NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(), "/OrderList/Order/OrderLines/OrderLine");
				 if(ndListOrderLine.getLength() != 0)
				 {
					 for(int i = 0; i < ndListOrderLine.getLength(); i++)
					 {
						DecimalFormat df = new DecimalFormat("0.00");
						Element eleOrderLine = (Element)ndListOrderLine.item(i);
						 if(!YFCCommon.isVoid(eleOrderLine)){
							//Null check start
							 String sOrderLineKey=eleOrderLine.getAttribute("OrderLineKey");
							 Element eleItem = XMLUtil.getFirstElementByName(eleOrderLine, "Item");
							
							 if(loggerForPosInvoice.isDebugEnabled())
								 loggerForPosInvoice.debug(" Item node List is : "+XMLUtil.getElementXMLString(eleItem));							 
							 String strItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
							 String strUPCCode = eleItem.getAttribute(KohlsPOCConstant.ATTR_UPC_CODE);
							 String strUnitCost = eleItem.getAttribute(KohlsPOCConstant.ATTR_UNIT_COST);
							 String strTaxPdtCode = eleItem.getAttribute(KohlsPOCConstant.ATTR_TAX_PRODUCT_CODE);
							 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.getItemList");
							 Document docItemListOutput = KohlsPoCPnPUtil.getItemListOutPut(env,strItemID);
							 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.getItemList");
							 Element eleItemOutput = (Element)((NodeList) XPathUtil.getNodeList(docItemListOutput.getDocumentElement(), "/ItemList/Item")).item(0);
							 if(!YFCCommon.isVoid(strUPCCode)){
								 eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
							 } else{
								 eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, KohlsPoCPnPUtil.getUpcCode(docItemListOutput));
							 }	
							 eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_UNIT_COST, strUnitCost);
							 eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_TAX_PRODUCT_CODE, strTaxPdtCode);
							 Element eleItemExtn = (Element)XPathUtil.getNode(docItemListOutput.getDocumentElement(), "/ItemList/Item/Extn");
							 String sExtnDept = eleItemExtn.getAttribute("ExtnDept");
							 String sExtnSubClass = eleItemExtn.getAttribute("ExtnSubClass");
							 String sDummySKUNo = KohlsPoCPnPUtil.prepadString(sExtnDept, 3, "0")+KohlsPoCPnPUtil.prepadString(sExtnSubClass, 2, "0")+"000";									 
							 if(strItemID.equalsIgnoreCase(sDummySKUNo)){
								 loggerForPosInvoice.debug("dummy sku no is: "+sDummySKUNo);
								 eleOrderLine.setAttribute("IsDummySKU", "Y");
							 }
							 XMLUtil.removeChild(eleOrderLine, eleItem);
							 XMLUtil.importElement(eleOrderLine, eleItemOutput);
							 
							 //adding clob logic data start
							 NodeList nlAwardList=XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(), 
									 "/OrderList/Order/OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/Awards/Award");
							 
							 if (nlAwardList!=null){
								 for (int j=0;j<nlAwardList.getLength();j++){
									 Element eleAward=(Element)nlAwardList.item(j);
									 String sAwardApplied = eleAward.getAttribute("AwardApplied");
									 Element eleExtn=XMLUtil.getChildElement(eleAward, "Extn");
									 if(!YFCCommon.isVoid(eleExtn)){
										 loggerForPosInvoice.verbose("*******Inside ExtnElemet****");
										 String strExtnSalHubData=eleExtn.getAttribute("ExtnSalesHubData");
										 String sExtnPromoScheme = eleExtn.getAttribute("ExtnPromoScheme");
										 int iExtnPromoScheme = 0;
										 if(!YFCCommon.isVoid(sExtnPromoScheme)){
											 iExtnPromoScheme = Integer.parseInt(sExtnPromoScheme);
										 }
										 if(!YFCCommon.isVoid(strExtnSalHubData)){
											 Document docSalesHubData=XMLUtil.getDocument(strExtnSalHubData);
											 eleExtn.setAttribute("ExtnSalesHubData", "");
											 Element eleDataSalesHub=docSalesHubData.getDocumentElement();
											 XMLUtil.importElement(eleExtn, eleDataSalesHub);
											 //Manoj 10/24 : identifying the Tierd Promos and appending at the Order level
											 if(iExtnPromoScheme>= 400 && iExtnPromoScheme <= 500 && sAwardApplied.equalsIgnoreCase("Y")) {
												 String sPromoInterfaceId = eleDataSalesHub.getAttribute("PromoInterfaceId");
												 String sDiscountPercent = eleDataSalesHub.getAttribute("DiscountPercent");
												 if(!YFCCommon.isVoid(sDiscountPercent)){
													 sDiscountPercent = df.format(Double.parseDouble(sDiscountPercent)/100.0);
												 }
												 String sTierAmtRchd = eleDataSalesHub.getAttribute("TierAmtRchd");
												 String sTierQtyRchd = eleDataSalesHub.getAttribute("TierQtyRchd");
												 String sAwardAmount = eleAward.getAttribute("AwardAmount");
												 if(!mTieredDiscount.containsKey(sPromoInterfaceId)){
													 Document docTLD = XMLUtil.createDocument("TransactionLevelDiscount");
													 Element eleTLD = docTLD.getDocumentElement();
													 eleTLD.setAttribute("PromoInterfaceId",sPromoInterfaceId);
													 eleTLD.setAttribute("DiscountPercent",sDiscountPercent);
													 eleTLD.setAttribute("TierAmtRchd",sTierAmtRchd);
													 eleTLD.setAttribute("TierQtyRchd",sTierQtyRchd);
													 eleTLD.setAttribute("AwardAmount", sAwardAmount);
													 eleTLD.setAttribute("PromoScheme",sExtnPromoScheme);
													 eleTLD.setAttribute("DiscountTypeCode", "T");
													 mTieredDiscount.put(sPromoInterfaceId, eleTLD);
												 }else{
													 Element eleTLD = mTieredDiscount.get(sPromoInterfaceId);
													 String sAwardAmt = eleTLD.getAttribute("AwardAmount");
													 Double dOrigAwardAmt = 0.00;
													 if(!YFCCommon.isVoid(sAwardAmt)){
														 dOrigAwardAmt = Double.parseDouble(sAwardAmt);
													 }
													 Double dAwardAmt = 0.00;
													 if(!YFCCommon.isVoid(sAwardAmount)){
														 dAwardAmt = Double.parseDouble(sAwardAmount);
													 }
													 eleTLD.setAttribute("AwardAmount", df.format(dOrigAwardAmt+dAwardAmt));
													 mTieredDiscount.remove(sPromoInterfaceId);
													 mTieredDiscount.put(sPromoInterfaceId, eleTLD);
												 }
											 }
										 }
										 
									 }
								 }
							 }
							 
							 
							 //clod logic end
							 
						
							 Element eleAdditionalAttr = (Element) XPathUtil.getNode(docItemListOutput.getDocumentElement(), 
									 "/ItemList/Item/AdditionalAttributeList/AdditionalAttribute[@Name='POSStoredValueCategory']");
							 if(!YFCCommon.isVoid(eleAdditionalAttr))
							 {
								 String strValue = eleAdditionalAttr.getAttribute(KohlsPOCConstant.A_VALUE);
								 if(strValue.equalsIgnoreCase(KohlsPOCConstant.STRING_RETAILER) || strValue.equalsIgnoreCase(KohlsPOCConstant.STRING_BLACKHAWK))
								 {
									 //Form input xml for getStoredValueLineListForPOS  API
									 
									 Document docStoredValueLineListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_STORED_VALUE_LINE).getDocument();
									 Element eleStoredValueLineListInput = docStoredValueLineListInput.getDocumentElement();
									 eleStoredValueLineListInput.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY, sOrderLineKey);
									 
									 //Invoke getStoredValueLineListForPOS  API
									 Document docStoredValueLineListOutput = invokeAPI(env,XMLUtil.getDocument(KohlsPOCConstant.GET_STORED_VALUE_LINE_LIST_TEMPLATE),
											 KohlsPOCConstant.API_GET_STORED_VALUE_LINE_LIST_FOR_POS,docStoredValueLineListInput);
									 Element eleStoredValueLine = (Element)((NodeList) XPathUtil.getNodeList(docStoredValueLineListOutput.getDocumentElement(), "/StoredValueLineList/StoredValueLine")).item(0);
									 XMLUtil.importElement(eleOrderLine, eleStoredValueLine); 
								 }
								 
							 }
						 }
					 }
				 }
						 
		 	}
			catch (Exception exception){
				exception.printStackTrace();
				 if (exception instanceof YFSException) {
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
				 }
			}
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.getOrderListDetails");
		 return docOrderListOutput;
	 }
	 

	 
	 
	 
	 
	 
	 /**
	  * This function returns the charge transactions details for a void transaction if any.
	  * 
	  * @param env
	  * @return docVoidChargeTransDetailsOutput
	  * @exception
	  */
	 
	
	 private Document getVoidTenderChargeTransactionDetails(YFSEnvironment env) throws YFSException {
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.getVoidTenderChargeTransactionDetails");		 
		 Document docVoidChargeTransDetailsOutput = null;
		 
		 try {
		//			Invoke getChargeTransactionList API
			 Document docVoidChargeTransOutput = getChargeTransactionDetails(env,this.strOrderHeaderKey,this.strOrganizationCode);
			 
			 	
			 NodeList ndChargeTransDtl = (NodeList) XPathUtil.getNodeList(docVoidChargeTransOutput.getDocumentElement(), "/ChargeTransactionDetails/ChargeTransactionDetail");
			 for(int i = 0; i < ndChargeTransDtl.getLength(); i++)
			 {
				 Element eleChargeTransDetail = (Element)ndChargeTransDtl.item(i);
				 Element elePaymentMethod = (Element) XMLUtil.getChildElement(eleChargeTransDetail,"PaymentMethod");
				
			 }
			 
			 Element eleChargeTransactionsDetail = (Element) ((NodeList) docVoidChargeTransOutput.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL)).item(0);
			 docVoidChargeTransDetailsOutput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS).getDocument();
			 Element eleChargeTransDtls = docVoidChargeTransDetailsOutput.getDocumentElement();
			 XMLUtil.importElement(eleChargeTransDtls, eleChargeTransactionsDetail);
			 
			}
			catch (Exception exception){
				exception.printStackTrace();
				 if (exception instanceof YFSException) {
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
			 } 
		 }
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.getVoidTenderChargeTransactionDetails");
			 return docVoidChargeTransDetailsOutput;
		 }
	 
	 public Document getChargeTransactionDetails(YFSEnvironment env,String strOrderHeaderKey, String strOrganizationCode) throws Exception {
//			Create input XML for getChargeTransactionList API
			 Document docInputForGetChargeTransactionList = YFCDocument.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL).getDocument();
			 Element eleChargeTransactionInput = (Element) docInputForGetChargeTransactionList.getDocumentElement();
			 eleChargeTransactionInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
			 eleChargeTransactionInput.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
			 eleChargeTransactionInput.setAttribute(KohlsPOCConstant.ATTR_VOID_TRANSACTION, KohlsPOCConstant.STATIC_CONSTANT_SUBMITTED);
			 
			 //Invoke getChargeTransactionList API
			 Document docVoidChargeTransOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_VOID_CHARGE_TRANSACTION_OUTPUT, KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, docInputForGetChargeTransactionList);
			 return docVoidChargeTransOutput;
		}
/**
	  * This function returns Audit Details for Void Transaction.
	  * 
	  * @param env
	  * @return docChargeTransactionDetailsOutput
	  * @exception
	  */
	 
	 private Document getVoidTransactionAuditDetails(YFSEnvironment env) throws YFSException
	 {
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.getVoidTransactionAuditDetails");
		 Document docVoidTransDtls = null;
		 try {
			 
		 Document docTransAuditOutput = setTransAuditDetails(env,KohlsPOCConstant.STATIC_CONSTANT_VOIDED_TRANSACTION_PROCEDURE_ID);
		 docVoidTransDtls = YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDITS).getDocument();
		 if(!YFCDocument.isNull(docTransAuditOutput))
		 {
			 Element eleFinalVoidTransDtls = docVoidTransDtls.getDocumentElement();
			 NodeList ndListTransDetails = (NodeList) docTransAuditOutput.getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
			 if (ndListTransDetails.getLength() != 0) {
				 	 for(int i = 0; i < ndListTransDetails.getLength(); i++) {
						 Element eleVoidTransElement = (Element) ndListTransDetails.item(i);
						 String strAmount = (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_AMOUNT);
						 String strTerminalID = (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
						 String strTransNum = (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM);
						 String strTransAuditKey = (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_AUDIT_KEY);
						 
						 Element  eleTransOutputElement = XMLUtil.createChild(eleFinalVoidTransDtls, KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, strOrderNo);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, KohlsPOCConstant.STATIC_CONSTANT_VOIDED_TRANSACTION_PROCEDURE_ID);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_AMOUNT, strAmount);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, strTransNum);
						 eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TRANS_AUDIT_KEY, strTransAuditKey);
					 }
			 }
		 }
		 }
		 catch (Exception exception){
				exception.printStackTrace();
				 if (exception instanceof YFSException) {
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
				 }
			}
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.getVoidTransactionAuditDetails");
		 return docVoidTransDtls;		 
	 }
	 

	
	 
	 private Document getCreateTransactionDetails(YFSEnvironment env) throws YFSException
	 {
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.getCreateTransactionDetails");
		 Document docTransSpecDetail = null;
		 try {
		 
		 docTransSpecDetail = setTransAuditDetails(env, KohlsPOCConstant.STATIC_CONSTANT_CREATE_TRANSACTION_PROCEDURE_ID);
		 }
		 catch (Exception exception){
				exception.printStackTrace();
				 if (exception instanceof YFSException) {
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
				 }
			}
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.getCreateTransactionDetails");
		 
		 return docTransSpecDetail;
	 }
	 
	 
	 
	 
	 /**
	  * This function sets order level static variables.
	  * @param env
	  * @param docInvDtlInput
	  */
	 
	 private void setOrderLevelDetails(YFSEnvironment env, Document docInvDtlInput)
	 {
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.setOrderLevelDetails");
		 Element eleOrder =  (Element) ((NodeList) docInvDtlInput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER)).item(0);
			   
			 if(!YFCDocument.isVoid(eleOrder))
			 {
				 strOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
				 strEnterpriseCode = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
				 strOrganizationCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
				 strOrderNo = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
			 }
			 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.setOrderLevelDetails");
	 }
	
	 
	 /**
	  * This function retrieves audit level information for various procedure IDs.
	  * @param env
	  * @param String procedureID
	  * @return docSignInAuthAuditOutput
	  */
	 
	 private Document setTransAuditDetails(YFSEnvironment env, String procedureID)
	 {
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.setTransAuditDetails");
		 Document docSignInAuthAuditOutput = null;
		 try {
			 Document docTransAuditDetails = YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT).getDocument();
			 Element eleTransactionAuditDetails = docTransAuditDetails.getDocumentElement();
			 eleTransactionAuditDetails.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, strOrderNo);
			 eleTransactionAuditDetails.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
			 eleTransactionAuditDetails.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, procedureID);
			 
			 docSignInAuthAuditOutput = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
					 KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS, docTransAuditDetails);
		 }
		 catch (Exception exception){
				exception.printStackTrace();
				 if (exception instanceof YFSException) {
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
				 }
			}
		 loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.setTransAuditDetails");
		 return docSignInAuthAuditOutput;
	 }
	 
	 /**
	  * This method generates the Sales Hub message for Void During transactions.
	 * @param env
	 * @param inputDocument
	 * @return
	 * @throws Exception
	 */
	public Document generateSuspendedXMLToSalesHub (
			 	YFSEnvironment env, Document inputDocument) throws Exception{		 
		 Document docVoidDuringDtls = null;
		 Document outputDocument = null;
		 loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub");
		 
		 if(loggerForPosInvoice.isDebugEnabled())
			 loggerForPosInvoice.debug("Input XML to KohlsPocReturnInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub is: \n"+
					 XMLUtil.getXMLString(inputDocument));
	 	Element eleInputOrder = (Element)((NodeList)XPathUtil.getNodeList(inputDocument.getDocumentElement(), "/Order")).item(0);
	 	docVoidDuringDtls =  YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
	 	Element eleInvDtl = docVoidDuringDtls.getDocumentElement();
	 	eleInvDtl.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
	 	Element eleInvHdr = XMLUtil.createChild(eleInvDtl, KohlsPOCConstant.ATTR_INVOICE_HEADER);
		Element eleOrder = XMLUtil.createChild(eleInvHdr, KohlsPOCConstant.ELEM_ORDER);
	 	eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
	 	eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
	 	eleOrder.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
	 	eleOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
	 	eleOrder.setAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE, eleInputOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
	 	outputDocument = generateAndPublishPOSInvoiceToSalesHub(env, docVoidDuringDtls);
	 	Element eleOrderOut = (Element)((NodeList)XPathUtil.getNodeList(outputDocument.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);
	 	Element eleOrderExtn = (Element)((NodeList)XPathUtil.getNodeList(outputDocument.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order/Extn")).item(0);
	 	Element eleInvoiceHeader = (Element)((NodeList)XPathUtil.getNodeList(outputDocument.getDocumentElement(), "/InvoiceDetail/InvoiceHeader")).item(0);
	 	Element eleOverallTotals = (Element)((NodeList)XPathUtil.getNodeList(outputDocument.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order/OverallTotals")).item(0);
	 	eleInvoiceHeader.setAttribute("TotalAmount", eleOverallTotals.getAttribute("GrandTotal"));
	 	eleInvoiceHeader.setAttribute("DateInvoiced", eleOrderOut.getAttribute("Modifyts"));
	 	eleInvoiceHeader.setAttribute("AmountCollected", eleOverallTotals.getAttribute("GrandTotal"));
	 	eleInvoiceHeader.setAttribute("TotalDiscount", eleOrderExtn.getAttribute("ExtnTotalSavings"));
	 	outputDocument.getDocumentElement().setAttribute("MessageType", "Suspend");
	 	
	 	if(loggerForPosInvoice.isDebugEnabled())
	 		loggerForPosInvoice.debug("KohlsPocReturnInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub"+XMLUtil.getXMLString(outputDocument));
	 	loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub");
		 return outputDocument;
	 }
	
	 private Document removeLineDetails(YFSEnvironment env, Document inputPublishInvoiceDetail) throws Exception {
		 
		 String sOHKey="";
		 Document docRetCustom = null;
		 String strText3 ="";
		 String strDate1 = "";
		 Element eleInvoiceHeader = XMLUtil.getChildElement(inputPublishInvoiceDetail.getDocumentElement() , "InvoiceHeader");
		 Element eleLineDetails = XMLUtil.getChildElement(eleInvoiceHeader, "LineDetails");
		 XMLUtil.removeChild(eleInvoiceHeader, eleLineDetails);
		 Element eleOrder = XMLUtil.getChildElement(eleInvoiceHeader, "Order");
		
		 Element eleExtn = XMLUtil.getChildElement(eleInvoiceHeader, "Extn", true);
		 
		 if(!YFCCommon.isVoid(eleOrder)){
			sOHKey=eleOrder.getAttribute("OrderHeaderKey");
			 if(!YFCCommon.isVoid(sOHKey)){
		 
		
		 Document docRetCustomInp=XMLUtil.getDocument("<Order OrderHeaderKey='"+sOHKey+"'/>");
		 Document docRetCustomTempl = XMLUtil.getDocument("<Order><OrderLines><OrderLine><CustomAttributes Text2='' Text3='' Date1='' /></OrderLine></OrderLines></Order>");
		try{
		docRetCustom = KohlsCommonUtil.invokeAPI(env, docRetCustomTempl, "getOrderDetails", docRetCustomInp);
		}catch(YFSException ex){
			loggerForPosInvoice.error("KohlsPocReturnInvoiceToSalesHubAPI.removeLineDetails"+ex.getErrorDescription());
		}
		 Element eleCustom = (Element) ((NodeList) XPathUtil
					.getNodeList(docRetCustom.getDocumentElement(),
							"/Order/OrderLines/OrderLine/CustomAttributes")).item(0);
		
		
		 
         if(!(YFCCommon.isVoid(eleCustom)))
         {        
                         
                             loggerForPosInvoice.debug("KohlsPocReturnInvoiceToSalesHubAPI.removeLineDetails inside CustomAttributes manipulate");
                             if(!YFCCommon.isVoid(eleCustom.getAttribute("Text3"))){
                             strText3 = eleCustom.getAttribute("Text3");
                             eleExtn.setAttribute("ExtnSellerOrganisationCode",strText3);
                             }
                             if(!YFCCommon.isVoid(eleCustom.getAttribute("Date1"))){
                             strDate1 = eleCustom.getAttribute("Date1");
                             eleExtn.setAttribute("ExtnOrderDate",strDate1);
                             }
                       
                         }
         
         
			 }
		 }
		 return inputPublishInvoiceDetail;
	}
	
	/**
     * Method to get the actual order confirm timestamp for the Return as part
     * of EE confirmed in ISS.PST-843.
     * 
     * @param env
     * @param inputPublishInvoiceDetail
     * @param eleInvoiceHeader
     * @param eleInvoiceOrder
     * @throws Exception
     * 
     */
    private Document setDateInvoicedForSaleSyncedToCorp(YFSEnvironment env, Document inputPublishInvoiceDetail,
            Element eleInvoiceHeader, Element eleInvoiceOrder) throws Exception {
        loggerForPosInvoice.beginTimer("KohlsPocReturnInvoiceToSalesHubAPI.setDateInvoicedForSaleSyncedToCorp");
        String entryType = eleInvoiceOrder.getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE);
        loggerForPosInvoice.debug("EntryType for ISS order  :" + entryType);
        if (KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE.equals(entryType)) {

            Element inputTransactionAuditElement = (Element) ((NodeList) XPathUtil.getNodeList(
                    inputPublishInvoiceDetail.getDocumentElement(), KohlsPOCConstant.TRANSACTION_AUDIT_XPATH)).item(0);
            if (!YFCCommon.isVoid(inputTransactionAuditElement)) {
                loggerForPosInvoice
                        .debug("Get the values for input to getOfflineTrxQ from transaction audit of invoice XML");
                Document inputOfflineTrxQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
                Element inputOfflineTrxQElement = inputOfflineTrxQDoc.getDocumentElement();
                inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.V_N);
                inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID,
                        KohlsPOCConstant.API_LOAD_OFFLINE_ORDER_FOR_POS);
                inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
                        inputTransactionAuditElement.getAttribute(KohlsPOCConstant.A_ORG_CODE));
                inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID,
                        inputTransactionAuditElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM));
                String getOfflineTrxQTemplate = KohlsPOCConstant.GET_OFFLINE_TRANSACTION_QLIST_TEMPLATE;
                Document getOfflineTrxQs = invokeAPI(env, getOfflineTrxQTemplate,
                        KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS, inputOfflineTrxQDoc);
                if (!YFCCommon.isVoid(getOfflineTrxQs)) {
                    NodeList offlineTrxQList = XPathUtil.getNodeList(getOfflineTrxQs.getDocumentElement(),
                            KohlsPOCConstant.OFFLINE_TRX_Q_XPATH);
                    if (offlineTrxQList.getLength() > 0) {
                        Element offlineTrxQElement = (Element) offlineTrxQList.item(0);
                        String operationTs = offlineTrxQElement.getAttribute(KohlsPOCConstant.A_OPERATION_TS);
                        loggerForPosInvoice.debug("The operation ts from the pos offline entry   :" + operationTs);
                        eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_DATE_INVOICED, operationTs);
                    }
                }

            }

        }
        loggerForPosInvoice.endTimer("KohlsPocReturnInvoiceToSalesHubAPI.setDateInvoicedForSaleSyncedToCorp");
        return inputPublishInvoiceDetail;
    }
}

 
  
 
