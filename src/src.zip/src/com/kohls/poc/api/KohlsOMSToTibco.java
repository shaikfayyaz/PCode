package com.kohls.poc.api;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

//import com.kohls.is.co.util.xml.XMLDocument;

/**************************************************************************
 * File : KohlsPoc KohlsOMSToTibco.java Author : Kohls, Jan 11 2016 Modified :
 * Jan 11 2016 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 11/01/2016
 *****************************************************************************/

public class KohlsOMSToTibco extends KOHLSBaseApi {
    private static final YFCLogCategory loggerForPosInvoice = YFCLogCategory.instance(KohlsOMSToTibco.class.getName());

    private String strOrderHeaderKey = null;
    private String strOrganizationCode = null;
    private String strEnterpriseCode = null;
    private String strOrderNo = null;
    private Document docFinalUpdatedXML = null;
    private String strExtnRIpairlineKey = null;
    private String strExchngeOLkey = null;
    private String strReturnOLkey = null;
    private Map<String, Element> mTieredDiscount = new LinkedHashMap<String, Element>();

    /**
     * This function generates the Even Exchange document to be sent to Tibco
     * Author Kohls
     * 
     * @param env
     * @param inputPublishInvoiceDetail
     * @return docOutputPublishPOSInvoice
     * @throws IOException
     * @throws SAXException
     * @throws ParserConfigurationException
     * @exception Exception
     * 
     */

    public Document generateOMSToTibco(YFSEnvironment env, Document inVoiceInputDoc) {

        loggerForPosInvoice.beginTimer("KohlsOMSToTibco.GetOrderInvoiceDetails");
        Document docOrderListOutput = null;
        Document docOrderOutput = null;
        Document docOrderReturnList = null;
        Document docFinalXMLtoTibco = null;
        Document docROSalesOrderOutput = null;
        Document docItemListOutput = null;
        Document docLinkedSourceOutput = null;
        Document docNewOrderOutput = null;
        Document docNewReturnOrderOutput = null;
        Document docOrderLineForExchange = null;
        String strPOCStoreID = null;
        String strText3 = null;
        String strPOCDate = null;
        String strDate1 = null;
        String strPOCTransNo = null;
        String strPOCTerminalID = null;
        String strExtnReturnItem = null;
        String SOrderDate = null;
        String SOrderDate1 = null;
        String strReturnItemId = null;
        String strOrderHeaderKey = null;
        String strROHeaderKey = null;
        String eleDerivedFromOrderLineKey = null;
        String eleDerivedFromOrderHeaderKey = null;
        String strOrderLineKey = null;
        String strExtnSalesTerminalId = null;
        String strExtnSalesTerminalId1 = null;
        String strExtnSalesTransNo = null;
        String strExtnSalesTransNo1 = null;
        /* String strExtnReturnItemPairLineKey = null; */
        String strText2 = null;
        String strExtnTaxDetails = null;
        String strItemID = null;
        String strExtnCallBackType = null;
        String strPosSequenceNo = null;
        String strSellerOrganizationCode = null;
        String strSellerOrganizationCode1 = null;
        String strTerminalID = null;
        String strExtnTaxClobDetails = null;
        String strNewExtnOrgnCode = null;
        Element eleTaxClobDetails = null;
        Element eleInvHeader = null;

        loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco -- Calling GetOrderInvoiceDetails ");
        try {

            Element eleinvoice = inVoiceInputDoc.getDocumentElement();

            Document docInputForGetOrderInvoiceDetails = YFCDocument.createDocument("GetOrderInvoiceDetails")
                    .getDocument();

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docInputForGetOrderInvoiceDetails  "
                        + XMLUtil.getXMLString(docInputForGetOrderInvoiceDetails));

            /*
             * System.out.println("############docInputForGetOrderInvoiceDetails"
             * + docInputForGetOrderInvoiceDetails);
             */

            Element eleOrderInvoiceInput = docInputForGetOrderInvoiceDetails.getDocumentElement();

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleOrderInvoiceInput BEFORE::  "
                        + XMLUtil.getElementXMLString(eleOrderInvoiceInput));

            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco ATTR_ENTERPRISE_CODE ::  "
                    + KohlsPOCConstant.ATTR_ENTERPRISE_CODE + "" + KohlsXMLLiterals.A_ENTERPRISE_CODE);

            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco ATTR_INVOICE_NO ::  "
                    + KohlsPOCConstant.ATTR_INVOICE_NO + "" + KohlsXMLLiterals.A_INVOICE_NO);

            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco ATTR_ORDER_INVOICE_KEY ::  "
                    + KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY + "" + KohlsPOCConstant.E_INVOICE_KEY);

            eleOrderInvoiceInput.setAttribute("EnterpriseCode", eleinvoice.getAttribute("EnterpriseCode"));
            eleOrderInvoiceInput.setAttribute("InvoiceNo", eleinvoice.getAttribute("InvoiceNo"));
            eleOrderInvoiceInput.setAttribute("InvoiceKey", eleinvoice.getAttribute("InvoiceKey"));

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleOrderInvoiceInput AFTER ::  "
                        + XMLUtil.getElementXMLString(eleOrderInvoiceInput));

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docInputForGetOrderInvoiceDetails ::  "
                        + XMLUtil.getXMLString(docInputForGetOrderInvoiceDetails));
            /*
             * loggerForPosInvoice
             * .debug("KohlsOMSToTibco.generateOMSToTibco docDC ::  "
             * +XMLUtil.getDocument(KohlsPOCConstant.DATACOLLECT));
             * loggerForPosInvoice
             * .debug("KohlsOMSToTibco.generateOMSToTibco docDC XML ::  "
             * +XMLUtil
             * .getDocument("/global/template/api/DataCollect_Invoice.xml"));
             * loggerForPosInvoice
             * .debug("KohlsOMSToTibco.generateOMSToTibco docDC XML1 ::  "
             * +XMLUtil
             * .getDocument("global/template/api/DataCollect_Invoice.xml"));
             * 
             * 
             * Document docDC =
             * XMLUtil.getDocument(KohlsPOCConstant.DATACOLLECT);
             * 
             * loggerForPosInvoice
             * .debug("KohlsOMSToTibco.generateOMSToTibco docDC1 ::  "
             * +XMLUtil.getXMLString(docDC));
             */

            docOrderListOutput = invokeService(env, "GetOrderInvoiceDetails", docInputForGetOrderInvoiceDetails);

            /*
             * docOrderListOutput = invokeAPI(env, docDC,
             * "getOrderInvoiceDetails", docInputForGetOrderInvoiceDetails);
             */

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docOrderListOutput ::  "
                        + XMLUtil.getXMLString(docOrderListOutput));

            Element eleOrder = (Element) ((NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order")).item(0);

            strOrderHeaderKey = eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);

            strPosSequenceNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
            strSellerOrganizationCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
            strTerminalID = eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
			// PST-843 changes
            String entryType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE);
            loggerForPosInvoice.debug("Entry type for order  :" + entryType);

            // PST-843 changes

            Element eleExtnReturnItem = (Element) ((NodeList) XPathUtil
                    .getNodeList(docOrderListOutput.getDocumentElement(),
                            "/InvoiceDetail/InvoiceHeader/LineDetails/LineDetail/Extn")).item(0);

            if (!YFCCommon.isVoid(eleExtnReturnItem)) {
                strExtnReturnItem = eleExtnReturnItem.getAttribute(KohlsXMLLiterals.A_EXTN_RETURN_ITEM_PAIR_KEY);

            }

            // Fetching ItemID of exchange order from Output

            Element eleItemID = (Element) ((NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/LineDetails/LineDetail")).item(0);
            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleItemID ::  " + eleItemID);
            if (!YFCCommon.isVoid(eleItemID)) {
                strItemID = eleItemID.getAttribute(KohlsPOCConstant.ATTR_ITEMID);
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco strItemID  " + strItemID);
            }

            // Preparing input for getItemList API call

            Document docItemListInput = YFCDocument.createDocument("Item").getDocument();
            Element eleItemListInput = docItemListInput.getDocumentElement();
            eleItemListInput.setAttribute("ItemID", strItemID);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco input to getItemDetails  "
                        + XMLUtil.getXMLString(docItemListInput));

            /*
             * Preparing input template for getOrderList Document
             * docItemListOutputTemplate = XMLUtil .getDocument(
             * "<ItemList><Item><Extn ExtnCallbackTypeCode=''/></Item></ItemList>"
             * );
             */

            // Fetching ExtnCallbackTypeCode from API output

            docItemListOutput = invokeService(env, "GetOrderItemDetails", docItemListInput);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco output of getItemList is :: "
                        + XMLUtil.getXMLString(docItemListOutput));

            Element eleItem = (Element) ((NodeList) XPathUtil.getNodeList(docItemListOutput.getDocumentElement(),
                    "/ItemList/Item/Extn")).item(0);
            strExtnCallBackType = eleItem.getAttribute("ExtnCallbackTypeCode");

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco Extn node :: "
                        + XMLUtil.getElementXMLString(eleItem) + "ExtnCallbackTypeCode value" + strExtnCallBackType);

            // System.out.println("KohlsOMSToTibco.generateOMSToTibco ExtnCallBackType ::  "+eleExtnItem);
            /*
             * if(!YFCCommon.isVoid(eleExtnItem)) { strExtnCallBackType =
             * eleExtnItem.getAttribute("ExtnCallBackTypeCode");
             * System.out.println
             * ("KohlsOMSToTibco.generateOMSToTibco ExtnCallBackType ::  "
             * +strExtnCallBackType); }
             */

            // End of getItemList API call

            /**** Second API call to GetOrderDetails *****/

            Document docInputForGetOrderDetails = YFCDocument.createDocument("Order").getDocument();
            Element eleOrderDetailsInput = docInputForGetOrderDetails.getDocumentElement();

            eleOrderDetailsInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docInputForGetOrderDetails::  "
                        + XMLUtil.getXMLString(docInputForGetOrderDetails));

            docOrderOutput = invokeService(env, "GetOrderDetails", docInputForGetOrderDetails);
            //PST-5317 - Start
            removeDeletedOrderLines(docOrderOutput, "N");
            //PST-5317 - End
			// PST-843 changes
            String transactionNo = "";
            if (!YFCCommon.isVoid(docOrderOutput)) {
                transactionNo = docOrderOutput.getDocumentElement().getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
                loggerForPosInvoice.debug("Transaction no to stamp dateInvoice for ISS  :" + transactionNo);
            }

            // PST-843 changes

            /*
             * docOrderOutput = invokeAPI(env,
             * XMLUtil.getDocument(KohlsPOCConstant.DATACOLLECT_ORDER),
             * KohlsPOCConstant.GET_ORDER_DETAILS, docInputForGetOrderDetails);
             */

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docOrderOutput::  "
                        + XMLUtil.getXMLString(docOrderOutput));

            /******* To get Return Order For Exchange -- Third API call getOrderList */

            Document docInputForGetOrderList = YFCDocument.createDocument("Order").getDocument();
            Element eleOrderListInput = docInputForGetOrderList.getDocumentElement();

            eleOrderListInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docInputForGetOrderList::  "
                        + XMLUtil.getXMLString(docInputForGetOrderList));

            docOrderReturnList = invokeService(env, "GetOrderListDetails", docInputForGetOrderList);

            /*
             * docOrderReturnList = invokeAPI( env,
             * XMLUtil.getDocument(KohlsPOCConstant.DATACOLLECT_ORDER_LIST),
             * KohlsPOCConstant.GET_ORDER_LIST, docInputForGetOrderList);
             */

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docOrderReturnList::  "
                        + XMLUtil.getXMLString(docOrderReturnList));

            Element eleROHeaderKey = (Element) ((NodeList) XPathUtil.getNodeList(
                    docOrderReturnList.getDocumentElement(),
                    "/OrderList/Order/ReturnOrdersForExchange/ReturnOrderForExchange")).item(0);
            strROHeaderKey = eleROHeaderKey.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);

            /** To get Linked Source Key --- Fourth API call to getOrderList **/

            Document docInputForSalesOrder = YFCDocument.createDocument("Order").getDocument();
            Element eleSalesOrderInput = docInputForSalesOrder.getDocumentElement();

            eleSalesOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strROHeaderKey);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docInputForSalesOrder::  "
                        + XMLUtil.getXMLString(docInputForSalesOrder));
            docROSalesOrderOutput = invokeService(env, "GetSalesOrderList", docInputForSalesOrder);
            //PST-5317 - Start
            removeDeletedOrderLines(docROSalesOrderOutput, "Y");
            //PST-5317 - End
            docNewReturnOrderOutput = invokeService(env, "GetLinkedOrderList", docInputForSalesOrder);
            //PST-5317 - Start
            removeDeletedOrderLines(docNewReturnOrderOutput, "N");
            //PST-5317 - End

            Element eleReturnOrd = (Element) ((NodeList) XPathUtil.getNodeList(
                    docNewReturnOrderOutput.getDocumentElement(), "/Order")).item(0);

            // Changes For Adding POC Data of Sales if exists -- Begin --
            // 18/5/16

            Element eleTempOrderLine = (Element) ((NodeList) XPathUtil.getNodeList(
                    docNewReturnOrderOutput.getDocumentElement(), "/Order/OrderLines/OrderLine/Extn")).item(0);

            // Fix for Customized table -Start

            Element eleCustomAttributeTextDate = (Element) ((NodeList) XPathUtil.getNodeList(
                    docNewReturnOrderOutput.getDocumentElement(), "/Order/OrderLines/OrderLine/CustomAttributes"))
                    .item(0);
            if (!(YFCCommon.isVoid(eleCustomAttributeTextDate.getAttribute("Text3")))
                    && !(YFCCommon.isVoid(eleCustomAttributeTextDate.getAttribute("Date1")))
                    && !(YFCCommon.isVoid(eleTempOrderLine.getAttribute("ExtnSalesTransactionNo")))
                    && !(YFCCommon.isVoid(eleTempOrderLine.getAttribute("ExtnSalesTerminalID"))))

            {
                /*
                 * strPOCStoreID =
                 * eleTempOrderLine.getAttribute("ExtnSalesStoreId");
                 */

                strText3 = eleCustomAttributeTextDate.getAttribute("Text3");

                // Fix for Customized table -End
                /*
                 * strPOCDate =
                 * eleTempOrderLine.getAttribute("ExtnSalesTransactionDate");
                 */

                strDate1 = eleCustomAttributeTextDate.getAttribute("Date1");

                strPOCTransNo = eleTempOrderLine.getAttribute("ExtnSalesTransactionNo");
            }
            if (!YFCCommon.isVoid(eleTempOrderLine.getAttribute("ExtnSalesTerminalID"))) {
                strPOCTerminalID = eleTempOrderLine.getAttribute("ExtnSalesTerminalID");
            }

            // Changes For Adding POC Data of Sales if exists -- End -- 18/5/16

            /*
             * docROSalesOrderOutput = invokeAPI( env,
             * XMLUtil.getDocument(KohlsPOCConstant
             * .DATACOLLECT_SALES_ORDER_LIST), KohlsPOCConstant.GET_ORDER_LIST,
             * docInputForSalesOrder);
             */

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docROSalesOrderOutput::  "
                        + XMLUtil.getXMLString(docROSalesOrderOutput));

            /*
             * Element eleLinkedKey = (Element) ((NodeList)
             * XPathUtil.getNodeList(
             * docROSalesOrderOutput.getDocumentElement(),
             * "/OrderList/Order")).item(0);
             * 
             * if (eleLinkedKey != null) { eleLinkedSrcKey = eleLinkedKey
             * .getAttribute(KohlsXMLLiterals.A_LINKED_SOURCE_KEY); }
             */

            /**** To get Order Level */
            Element eleOrderLevel = (Element) ((NodeList) XPathUtil.getNodeList(
                    docROSalesOrderOutput.getDocumentElement(), "/OrderList/Order")).item(0);
            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleOrderLevel::  " + eleOrderLevel);

            if (!YFCCommon.isVoid(eleOrderLevel)) {
                strExtnSalesTerminalId1 = eleOrderLevel.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID);
                strExtnSalesTransNo1 = eleOrderLevel.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
                SOrderDate1 = eleOrderLevel.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
                strSellerOrganizationCode1 = eleOrderLevel.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE);
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleOrderLevel::  "
                        + strSellerOrganizationCode1 + "" + SOrderDate1 + "" + strExtnSalesTransNo1 + ""
                        + strExtnSalesTerminalId1);
            } else {
                loggerForPosInvoice.debug("eleOrderLevel is null");
            }

            /*** Fix for Return Item details ***/

            Element eleItemLevel = (Element) ((NodeList) XPathUtil.getNodeList(
                    docROSalesOrderOutput.getDocumentElement(), "/OrderList/Order/OrderLines/OrderLine/Item")).item(0);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleItemLevel::"
                        + XMLUtil.getElementXMLString(eleItemLevel));

            strReturnItemId = eleItemLevel.getAttribute(KohlsPOCConstant.A_ITEM_ID);
            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco strReturnItemId ::" + strReturnItemId);

            /**** To get Order Line Key */

            Element eleOrderLineKey = (Element) ((NodeList) XPathUtil.getNodeList(
                    docROSalesOrderOutput.getDocumentElement(), "/OrderList/Order/OrderLines/OrderLine")).item(0);

            if (!YFCCommon.isVoid(eleOrderLineKey)) {
                eleDerivedFromOrderLineKey = eleOrderLineKey
                        .getAttribute(KohlsXMLLiterals.A_DERIVED_FROM_ORDER_LINE_KEY);
                eleDerivedFromOrderHeaderKey = eleOrderLineKey
                        .getAttribute(KohlsXMLLiterals.A_DERIVED_FROM_ORDER_HEADER_KEY);
                strOrderLineKey = eleOrderLineKey.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY);
            }
            eleOrderLineKey.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, strExtnReturnItem);

            /** To get Extn details from Linked Source Key **/

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleOrderLineKey ::  "
                        + XMLUtil.getElementXMLString(eleOrderLineKey));
            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleDerivedFromOrderHeaderKey ::  "
                    + eleDerivedFromOrderHeaderKey);

            // if (eleDerivedFromOrderHeaderKey == null) {

            // if (eleDerivedFromOrderHeaderKey.equalsIgnoreCase(null)) {

            if (eleDerivedFromOrderHeaderKey == null || "".equals(eleDerivedFromOrderHeaderKey)
                    || eleDerivedFromOrderHeaderKey.equalsIgnoreCase("")) {


                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleDerivedFromOrderHeaderKey ::  "
                        + eleDerivedFromOrderHeaderKey);
                Document docInputForNewGetOrderDetails = YFCDocument.createDocument("Order").getDocument();
                Element eleOrderNewDetailsInput = docInputForNewGetOrderDetails.getDocumentElement();

                // System.out.println("############## strROHeaderKey ******"
                // +strROHeaderKey);

                eleOrderNewDetailsInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strROHeaderKey);
               // System.out.println("KohlsOMSToTibco.generateOMSToTibco docInputForNewGetOrderDetails ::  "
               //         + XMLUtil.getXMLString(docInputForNewGetOrderDetails));

                docNewOrderOutput = invokeService(env, "GetLinkedOrderList", docInputForNewGetOrderDetails);
                //PST-5317 - Start
                removeDeletedOrderLines(docNewOrderOutput, "N");
                //PST-5317 - End
                /*
                 * getOrderDetails API call to fetch order level details of
                 * Return Order
                 * 
                 * docNewReturnOrderOutput =
                 * invokeService(env,"GetLinkedOrderList"
                 * ,docInputForSalesOrder);
                 * 
                 * Element eleReturnOrd = (Element) ((NodeList) XPathUtil
                 * .getNodeList( docNewReturnOrderOutput.getDocumentElement(),
                 * "/Order")).item(0);
                 */

                // Changes For adding new element OrderLineForExchange Begin --
                // 6/5/16

                docOrderLineForExchange = invokeService(env, "GetLinkedOrderList", docInputForGetOrderDetails);
                //PST-5317 - Start
                removeDeletedOrderLines(docOrderLineForExchange, "N");
                //PST-5317 - End
                Element eleOrderLineForExchange = XMLUtil.createChild(eleReturnOrd, "OrderLinesForExchange");

                Element eleExchngeOrderChild = XMLUtil.createChild(eleOrderLineForExchange, "OrderLines");
                Element eleOrderLineForExchange1 = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderLineForExchange.getDocumentElement(), "/Order/OrderLines")).item(0);

                // eleOrderLineForExchange = (Element)
                // eleOrderLineForExchange1.cloneNode(true);

                XMLUtil.importElement(eleExchngeOrderChild, eleOrderLineForExchange1);

                //System.out.println("eleOrderLineForExchange:::" + XMLUtil.getElementXMLString(eleOrderLineForExchange));

                // Changes For adding new element OrderLineForExchange End --
                // 6/5/16

                //System.out.println("KohlsOMSToTibco.generateOMSToTibco docNewOrderOutput ::  "
                //        + XMLUtil.getXMLString(docNewOrderOutput));

                Element eleNewExtnItems = (Element) ((NodeList) XPathUtil.getNodeList(
                        docNewOrderOutput.getDocumentElement(), "/Order/OrderLines/OrderLine/Extn")).item(0);

                if (!YFCCommon.isVoid(eleNewExtnItems)) {

                    eleNewExtnItems.removeAttribute("ExtnSalesTerminalID");
                    eleNewExtnItems.removeAttribute("ExtnSalesTransactionNo");

                    eleNewExtnItems.removeAttribute(KohlsXMLLiterals.A_EXTN_RETURN_ITEM_PAIR_KEY);

                    docNewOrderOutput.getDocumentElement().removeAttribute("ExtnSalesTerminalID");
                    docNewOrderOutput.getDocumentElement().removeAttribute("ExtnSalesTransactionNo");
                    docNewOrderOutput.getDocumentElement()
                            .removeAttribute(KohlsXMLLiterals.A_EXTN_RETURN_ITEM_PAIR_KEY);

                }

                // Fix for Item and Return Order Details for Non - Receipted
                // EvenExchange -- 3/5/16

                Element eleExtnLineDtls = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderListOutput.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/LineDetails/LineDetail"))
                        .item(0);

                Element customerextn = docOrderListOutput.createElement("Extn");

                customerextn.setAttribute("ExtnReturnTerminalID", strExtnSalesTerminalId1);
                customerextn.setAttribute("ExtnReturnTransactionNo", strExtnSalesTransNo1);
                customerextn.setAttribute("ExtnReturnOrderDate", SOrderDate1);
                customerextn.setAttribute("ExtnReturnOrganizationCode", strSellerOrganizationCode1);
                customerextn.setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE, strExtnCallBackType);
                customerextn.setAttribute("ExtnReturnItemID", strReturnItemId);

                eleExtnLineDtls.appendChild(customerextn);

                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnTerminalID", strExtnSalesTerminalId1);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnTransactionNo", strExtnSalesTransNo1);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnOrderDate", SOrderDate1);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnOrganizationCode",
                        strSellerOrganizationCode1);
                docOrderListOutput.getDocumentElement().setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE,
                        strExtnCallBackType);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnItemID", strReturnItemId);

                // End of Fix for Item and Return Order Details for Non -
                // Receipted EvenExchange -- 3/5/16

            }

            else // if(eleDerivedFromOrderHeaderKey != null)
            {
                //System.out.println("*********Inside NOT equal to NULL*************");
                Document docInputForLinkedKey = YFCDocument.createDocument("Order").getDocument();
                Element eleLinkedSourceInput = docInputForLinkedKey.getDocumentElement();

                eleLinkedSourceInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleDerivedFromOrderHeaderKey);

                if (loggerForPosInvoice.isDebugEnabled())
                    loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docInputForLinkedKey::  "
                            + XMLUtil.getXMLString(docInputForLinkedKey));
                docLinkedSourceOutput = invokeService(env, "GetLinkedOrderList", docInputForLinkedKey);
                //PST-5317 - Start
                removeDeletedOrderLines(docLinkedSourceOutput, "N");
                //PST-5317 - End
                /*
                 * getOrderDetails API call to fetch order level details of
                 * Return Order
                 * 
                 * docNewReturnOrderOutput =
                 * invokeService(env,"GetLinkedOrderList"
                 * ,docInputForSalesOrder);
                 * 
                 * Element eleReturnOrd = (Element) ((NodeList) XPathUtil
                 * .getNodeList( docNewReturnOrderOutput.getDocumentElement(),
                 * "/Order")).item(0);
                 */

                // Changes For adding new element OrderLineForExchange Begin --
                // 6/5/16

                docOrderLineForExchange = invokeService(env, "GetLinkedOrderList", docInputForGetOrderDetails);
                //PST-5317 - Start
                removeDeletedOrderLines(docOrderLineForExchange, "N");
                //PST-5317 - End
                Element eleOrderLineForExchange = XMLUtil.createChild(eleReturnOrd, "OrderLinesForExchange");

                Element eleExchngeOrderChild = XMLUtil.createChild(eleOrderLineForExchange, "OrderLines");

                Element eleOrderLineForExchange1 = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderLineForExchange.getDocumentElement(), "/Order/OrderLines")).item(0);

                // eleOrderLineForExchange = (Element)
                // eleOrderLineForExchange1.cloneNode(true);

                XMLUtil.importElement(eleExchngeOrderChild, eleOrderLineForExchange1);

                //System.out.println("eleOrderLineForExchange:::" + XMLUtil.getElementXMLString(eleOrderLineForExchange));

                // Changes For adding new element OrderLineForExchange End --
                // 6/5/16

                // Fix for returning Order Level Details for the Sales Order --
                // Begin -- 6/5/16

                Element eleOrigSalesOrder = (Element) ((NodeList) XPathUtil.getNodeList(
                        docLinkedSourceOutput.getDocumentElement(), "/Order")).item(0);

                String strSalesOrderDate = eleOrigSalesOrder.getAttribute("OrderDate");
                String strSalesTransNo = eleOrigSalesOrder.getAttribute("PosSequenceNo");
                String strSalesTerminalID = eleOrigSalesOrder.getAttribute("TerminalID");
                String strSalesOrgCode = eleOrigSalesOrder.getAttribute("SellerOrganizationCode");

                // Fix for returning Order Level Details for the Sales Order --
                // End -- -- 6/5/16

                /*
                 * docLinkedSourceOutput = invokeAPI( env,
                 * XMLUtil.getDocument(KohlsPOCConstant
                 * .DATACOLLECT_LINKED_SOURCE_LIST),
                 * KohlsPOCConstant.GET_ORDER_DETAILS, docInputForLinkedKey);
                 */

                if (loggerForPosInvoice.isDebugEnabled())
                    loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docLinkedSourceOutput::  "
                            + XMLUtil.getXMLString(docLinkedSourceOutput));

                // System.out.println("*************** docLinkedSourceOutput:: ********"+XMLUtil.getXMLString(docLinkedSourceOutput));

                Element eleExtnItems = (Element) ((NodeList) XPathUtil.getNodeList(
                        docLinkedSourceOutput.getDocumentElement(), "/Order/OrderLines/OrderLine/Extn")).item(0);

                //System.out.println("##############eleExtnItems ::  " + XMLUtil.getElementXMLString(eleExtnItems));

                if (!YFCCommon.isVoid(eleExtnItems)) {
                    strExtnSalesTerminalId = eleExtnItems.getAttribute(KohlsPOCConstant.A_EXTN_SALES_TERMINAL_ID);
                    strExtnSalesTransNo = eleExtnItems.getAttribute(KohlsPOCConstant.A_EXTN_SALES_TRANSACTION_NO);

                    /*
                     * strExtnReturnItemPairLineKey = eleExtnItems
                     * .getAttribute(
                     * KohlsXMLLiterals.A_EXTN_RETURN_ITEM_PAIR_KEY);
                     */

                }

                // Fix for Customized table change -start

                Element eleCustomAttributesText2 = (Element) ((NodeList) XPathUtil.getNodeList(
                        docLinkedSourceOutput.getDocumentElement(), "/Order/OrderLines/OrderLine/CustomAttributes"))
                        .item(0);

                //System.out.println("##############eleExtnItems ::  "
                //        + XMLUtil.getElementXMLString(eleCustomAttributesText2));

                if (!YFCCommon.isVoid(eleCustomAttributesText2)) {

                    strText2 = eleCustomAttributesText2.getAttribute(KohlsXMLLiterals.Text2);
                }

                // Fix for Customized table change -End

                /** To remove Extn attributes from Order line **/

                NodeList ndlstOrderLines = docLinkedSourceOutput.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
                for (int k = 0; k < ndlstOrderLines.getLength(); k++) {
                    Element eleOrderLine = (Element) ndlstOrderLines.item(k);
                    NodeList eleOrderLineExtn = eleOrderLine.getElementsByTagName(KohlsXMLLiterals.E_EXTN);
                    if (eleOrderLineExtn.getLength() > 0) {
                        for (int g = 0; g < eleOrderLineExtn.getLength(); g++) {
                            Element eleProm = (Element) eleOrderLineExtn.item(g);

                            eleProm.removeAttribute(KohlsPOCConstant.A_EXTN_SALES_TERMINAL_ID);
                            eleProm.removeAttribute(KohlsPOCConstant.A_EXTN_SALES_TRANSACTION_NO);
                            eleProm.removeAttribute(KohlsXMLLiterals.A_EXTN_RETURN_ITEM_PAIR_KEY);
                            docLinkedSourceOutput.getDocumentElement().removeAttribute(
                                    KohlsPOCConstant.A_EXTN_SALES_TERMINAL_ID);
                            docLinkedSourceOutput.getDocumentElement().removeAttribute(
                                    KohlsPOCConstant.A_EXTN_SALES_TRANSACTION_NO);
                            docLinkedSourceOutput.getDocumentElement().removeAttribute(
                                    KohlsXMLLiterals.A_EXTN_RETURN_ITEM_PAIR_KEY);
                        }
                    }
                }

                /** To get OrderDate in yyyy-MM-dd format **/

                Element eleLinkedOrder = (Element) ((NodeList) XPathUtil.getNodeList(
                        docLinkedSourceOutput.getDocumentElement(), "/Order")).item(0);

                DateFormat dateFormatDate = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);

                SOrderDate = XMLUtil.getAttribute(eleLinkedOrder, KohlsPOCConstant.A_ORDER_DATE);

                Date orderDateOb = dateFormatDate.parse(SOrderDate1);
                SOrderDate1 = dateFormatDate.format(orderDateOb);

                /** Get Extn details based on Order Line & Return Item **/

                Element eleExtnLineDtls = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderListOutput.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/LineDetails/LineDetail"))
                        .item(0);

                Element customerextn = docOrderListOutput.createElement("Extn");

                customerextn.setAttribute("ExtnReturnTerminalID", strExtnSalesTerminalId1);
                customerextn.setAttribute("ExtnReturnTransactionNo", strExtnSalesTransNo1);
                customerextn.setAttribute("ExtnReturnOrderDate", SOrderDate1);
                customerextn.setAttribute("ExtnReturnOrganizationCode", strSellerOrganizationCode1);
                customerextn.setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE, strExtnCallBackType);
                customerextn.setAttribute("ExtnReturnItemID", strReturnItemId);

                eleExtnLineDtls.appendChild(customerextn);

                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnTerminalID", strExtnSalesTerminalId1);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnTransactionNo", strExtnSalesTransNo1);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnOrderDate", SOrderDate1);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnOrganizationCode",
                        strSellerOrganizationCode1);
                docOrderListOutput.getDocumentElement().setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE,
                        strExtnCallBackType);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnItemID", strReturnItemId);

                NodeList ndcprOrderLines = docLinkedSourceOutput.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
                for (int m = 0; m < ndcprOrderLines.getLength(); m++) {
                    Element elecprOrderLine = (Element) ndcprOrderLines.item(m);

                    // Fix for Customized table -start
                    if ((eleDerivedFromOrderLineKey.equalsIgnoreCase(elecprOrderLine.getAttribute("OrderLineKey")))
                            && (strOrderLineKey.equalsIgnoreCase(strText2))) {
                        // Fix for Customized table -End
                        Element eleExtnLineItemsDtl = (Element) ((NodeList) XPathUtil.getNodeList(
                                docOrderListOutput.getDocumentElement(),
                                "/InvoiceDetail/InvoiceHeader/LineDetails/LineDetail")).item(0);

                        Element customer = docOrderListOutput.createElement("Extn");

                        customer.setAttribute("ExtnReturnTerminalID", strExtnSalesTerminalId1);
                        customer.setAttribute("ExtnReturnTransactionNo", strExtnSalesTransNo1);
                        customer.setAttribute("ExtnReturnOrderDate", SOrderDate1);
                        customer.setAttribute("ExtnReturnOrganizationCode", strSellerOrganizationCode1);
                        customer.setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE, strExtnCallBackType);
                        customer.setAttribute("ExtnReturnItemID", strReturnItemId);
                        eleExtnLineItemsDtl.appendChild(customer);

                        docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnTerminalID",
                                strExtnSalesTerminalId1);
                        docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnTransactionNo",
                                strExtnSalesTransNo1);
                        docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnOrderDate", SOrderDate1);
                        docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnOrganizationCode",
                                strSellerOrganizationCode1);
                        docOrderListOutput.getDocumentElement().setAttribute(KohlsPOCConstant.EXTN_CALL_BACK_TYPE,
                                strExtnCallBackType);
                        docOrderListOutput.getDocumentElement().setAttribute("ExtnReturnItemID", strReturnItemId);

                    }

                }

                /** To get the Extn Ship node value **/

                if (!YFCCommon.isVoid(eleLinkedOrder)) {
                    strExtnTaxDetails = eleLinkedOrder.getAttribute("SellerOrganizationCode");
                }
                Element eleExtnShipNode = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderListOutput.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Extn")).item(0);

                if (eleExtnShipNode != null) {
                    eleExtnShipNode.setAttribute("ExtnShipNode", strExtnTaxDetails);
                    docOrderListOutput.getDocumentElement().setAttribute("ExtnShipNode", strExtnTaxDetails);
                }

                // Setting Sales Attributes at Extn Level

                eleExtnShipNode.setAttribute("ExtnSellerOrganisationCode", strSalesOrgCode);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnSellerOrganisationCode", strSalesOrgCode);
                eleExtnShipNode.setAttribute("ExtnPosSequenceNo", strSalesTransNo);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnPosSequenceNo", strSalesTransNo);
                eleExtnShipNode.setAttribute("ExtnTerminalID", strSalesTerminalID);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnTerminalID", strSalesTerminalID);
                eleExtnShipNode.setAttribute("ExtnOrderDate", strSalesOrderDate);
                docOrderListOutput.getDocumentElement().setAttribute("ExtnOrderDate", strSalesOrderDate);

               // System.out.println("############## eleDerivedFromOrderHeaderKey FINAL XML::  "
                //        + eleDerivedFromOrderHeaderKey);

            }

            // System.out.println("############## eleDerivedFromOrderHeaderKey FINAL XML 1::  "
            // +eleDerivedFromOrderHeaderKey);

            /** Final XML Document **/

            // if (eleDerivedFromOrderHeaderKey!= null)

            // System.out.println("############## eleDerivedFromOrderHeaderKey FINAL XML 2::  "
            // +eleDerivedFromOrderHeaderKey);
            if (eleDerivedFromOrderHeaderKey == null || "".equals(eleDerivedFromOrderHeaderKey)
                    || eleDerivedFromOrderHeaderKey.equalsIgnoreCase(""))

            {
               // System.out.println("*********Final XML Docum block Inside equal to NULL*************");

                // System.out.println("############## eleDerivedFromOrderHeaderKey FINAL INSIDE::  "
                // +eleDerivedFromOrderHeaderKey);

                eleInvHeader = (Element) ((NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
                        "/InvoiceDetail/InvoiceHeader")).item(0);

                Element eleNewInvoiceOrder = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderListOutput.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);

                eleInvHeader.removeChild(eleNewInvoiceOrder);

                // System.out.println("***KohlsOMSToTibco.generateOMSToTibco eleInvHeader NEW 1 :: ******"+XMLUtil.getElementXMLString(eleInvHeader));

                Element eleNewInvOrder = (Element) ((NodeList) XPathUtil.getNodeList(
                        docNewOrderOutput.getDocumentElement(), "/Order")).item(0);

                // Changes For adding new element OrderLineForExchange Begin --
                // 6/5/16

                Element eleOrderLineForExchange = XMLUtil.createChild(eleNewInvOrder, "OrderLinesForExchange");

                Element eleExchngeOrderChild = XMLUtil.createChild(eleOrderLineForExchange, "OrderLines");

                Element eleOrderLineForExchange1 = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderLineForExchange.getDocumentElement(), "/Order/OrderLines")).item(0);

                XMLUtil.importElement(eleExchngeOrderChild, eleOrderLineForExchange1);

                // Changes For adding new element OrderLineForExchange End --
                // 6/5/16

                if (!YFCCommon.isVoid(eleNewInvOrder)) {
                    strNewExtnOrgnCode = eleNewInvOrder.getAttribute("SellerOrganizationCode");
                }
                Element eleNewExtnShipNode = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderListOutput.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Extn")).item(0);

                if (!YFCCommon.isVoid(eleNewExtnShipNode)) {
                    eleNewExtnShipNode.setAttribute("ExtnShipNode", strNewExtnOrgnCode);

                    // Setting POC Sales Related Attributes at Extn level --
                    // Begin -- 18/5/16
                    // Fix for Customized table-start
                    if (!(YFCCommon.isVoid(strText3)) && !(YFCCommon.isVoid(strDate1))
                            && !(YFCCommon.isVoid(strPOCTransNo)) && !(YFCCommon.isVoid(strPOCTerminalID))) {
                        eleNewExtnShipNode.setAttribute("ExtnSellerOrganisationCode", strText3);
                        eleNewExtnShipNode.setAttribute("ExtnShipNode", strText3);

                        // Fix for Customized table-End
                        eleNewExtnShipNode.setAttribute("ExtnPosSequenceNo", strPOCTransNo);
                    }

                    if (!YFCCommon.isVoid(strPOCTerminalID)) {
                        eleNewExtnShipNode.setAttribute("ExtnTerminalID", strPOCTerminalID);
                        eleNewExtnShipNode.setAttribute("ExtnOrderDate", strDate1);
                    }

                    if (!YFCCommon.isVoid(strPOCDate)) {
                        eleNewExtnShipNode.setAttribute("ExtnOrderDate", strPOCDate);
                    }

                    // Setting POC Sales Related Attributes at Extn level -- End
                    // -- 18/5/16

                    /*
                     * docNewOrderOutput.getDocumentElement().setAttribute(
                     * "ExtnShipNode", strNewExtnOrgnCode);
                     */
                }

                // System.out.println("***KohlsOMSToTibco.generateOMSToTibco eleNewInvOrder NEW  :: ******"+XMLUtil.getElementXMLString(eleNewInvOrder));

                // XMLUtil.importElement(eleInvHeader, eleReturnOrd);

                // Non-Receipted Tax Clob Fix -- Begin -- 17/5/16

                Element eleExtnTaxClob = (Element) ((NodeList) XPathUtil.getNodeList(
                        docNewOrderOutput.getDocumentElement(), "/Order/Extn")).item(0);

               // System.out.println("********eleExtnTaxClob *******" + XMLUtil.getElementXMLString(eleExtnTaxClob));

                // Start - Change for Tax Details - 10/18
                // if (eleExtnTaxClob != null) {
                if (!YFCCommon.isVoid(eleExtnTaxClob)) {
                    strExtnTaxClobDetails = eleExtnTaxClob.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);

                  //  System.out.println("********strExtnTaxClobDetails *******" + strExtnTaxClobDetails);

                } else {
                 //   System.out.println("Else block for null tax details");
                }

                // if(!YFCCommon.isVoid(strExtnTaxClobDetails))

                if (!strExtnTaxClobDetails.isEmpty()) {
                    Document docExtnTaxClobDetails = XMLUtil.getDocument(strExtnTaxClobDetails);
                    eleExtnTaxClob.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
                    eleTaxClobDetails = docExtnTaxClobDetails.getDocumentElement();
                 //   System.out.println("********eleTaxClobDetails inside if *******"
                  //          + XMLUtil.getElementXMLString(eleTaxClobDetails));

                    XMLUtil.importElement(eleNewInvOrder, eleTaxClobDetails);

                } else {
                    //System.out.println("Else block for null tax details---2");
                }

                // Non-Receipted Tax Clob Fix -- End -- 17/5/16

                XMLUtil.importElement(eleInvHeader, eleNewInvOrder);

            } else {

               // System.out.println("*********Final XML Docum block Inside NOT equal to NULL*************");

                // System.out.println("############## eleDerivedFromOrderHeaderKey FINAL XML 3::  "
                // +eleDerivedFromOrderHeaderKey);

                eleInvHeader = (Element) ((NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
                        "/InvoiceDetail/InvoiceHeader")).item(0);

                Element eleInvOrder = (Element) ((NodeList) XPathUtil.getNodeList(
                        docOrderListOutput.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order")).item(0);

                eleInvHeader.removeChild(eleInvOrder);

                Element eleOrigOrd = (Element) ((NodeList) XPathUtil.getNodeList(
                        docLinkedSourceOutput.getDocumentElement(), "/Order")).item(0);

              //  System.out.println("********eleOrigOrd Element original order before*******"
                 //       + XMLUtil.getElementXMLString(eleOrigOrd));

                /*
                 * Element eleExtnItems1 = (Element) ((NodeList)
                 * XPathUtil.getNodeList(
                 * docLinkedSourceOutput.getDocumentElement(),
                 * "/Order/Extn")).item(0);
                 * System.out.println("********eleExtnItems1 *******"
                 * +XMLUtil.getElementXMLString(eleExtnItems1));
                 */

                Element eleExtnTaxClob = (Element) ((NodeList) XPathUtil.getNodeList(
                        docLinkedSourceOutput.getDocumentElement(), "/Order/Extn")).item(0);

               // System.out.println("********eleExtnTaxClob *******" + XMLUtil.getElementXMLString(eleExtnTaxClob));

                // Start - Change for Tax Details - 10/18
                // if (eleExtnTaxClob != null) {
                if (!YFCCommon.isVoid(eleExtnTaxClob)) {
                    strExtnTaxClobDetails = eleExtnTaxClob.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);

                 //   System.out.println("********strExtnTaxClobDetails *******" + strExtnTaxClobDetails);

                } else {
                   // System.out.println("Else block for null tax details");
                }

                // if(!YFCCommon.isVoid(strExtnTaxClobDetails))

                if (!strExtnTaxClobDetails.isEmpty()) {
                    Document docExtnTaxClobDetails = XMLUtil.getDocument(strExtnTaxClobDetails);
                    eleExtnTaxClob.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
                    eleTaxClobDetails = docExtnTaxClobDetails.getDocumentElement();
                 //   System.out.println("********eleTaxClobDetails inside if *******"
                  //          + XMLUtil.getElementXMLString(eleTaxClobDetails));
                    // docGetOrderListDetails.importNode(eleTaxDetails, true);
                    XMLUtil.importElement(eleOrigOrd, eleTaxClobDetails);

                } else {
                   // System.out.println("Else block for null tax details---2");
                }

                // System.out.println("********eleExtnTaxClob *******"+XMLUtil.getElementXMLString(eleExtnTaxClob));

                // Element eleOrderLineForExchange =
                // XMLUtil.createChild(eleReturnOrd, "OrderLinesForExchange");

              //  System.out.println("********eleOrigOrd Element original order after*******"
               //         + XMLUtil.getElementXMLString(eleOrigOrd));

                XMLUtil.importElement(eleInvHeader, eleReturnOrd);

               // System.out.println("***KohlsOMSToTibco.generateOMSToTibco eleInvDtl:: ******"
                 //       + XMLUtil.getElementXMLString(eleInvHeader));

                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco Final Doc::  ");
            }

            docFinalXMLtoTibco = YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
            Element eleInvDtl = docFinalXMLtoTibco.getDocumentElement();

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco docFinalXMLtoTibco::  "
                        + XMLUtil.getXMLString(docFinalXMLtoTibco));

            eleInvDtl.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
            eleInvDtl.setAttribute("MessageType", "EvenExchange");

           // System.out.println("***KohlsOMSToTibco.generateOMSToTibco eleInvHeader 1 :: ******"
          //          + XMLUtil.getElementXMLString(eleInvHeader));
           // System.out.println("***KohlsOMSToTibco.generateOMSToTibco eleInvDtl 1 :: ******"
            //        + XMLUtil.getElementXMLString(eleInvDtl));
					
			// PST-843 changes
            eleInvHeader = setDateInvoicedForSaleSyncedToCorp(env, eleInvHeader, strSellerOrganizationCode, transactionNo, entryType);

            // PST-843 changes

            XMLUtil.importElement(eleInvDtl, eleInvHeader);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco eleInvDtl::  "
                        + XMLUtil.getElementXMLString(eleInvDtl));

            docFinalXMLtoTibco = updatedDocument(docFinalXMLtoTibco, env);
            Element eleInvoice=    (Element) docFinalXMLtoTibco.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELE_INVOICE_HEADER).item(0);
            //PST-2563 - update the invoice status of even exchange order from 00 to 01 
            
            if (!YFCCommon.isVoid(eleInvoice)) {
            	if(!YFCCommon.isVoid(eleInvoice.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY)))
            	{
            		 updateInvoiceStatus(env, eleInvoice.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY));
            	}
            }

           

        }

        catch (Exception excp) {
            loggerForPosInvoice.debug("KohlsOMSToTibco.generateOMSToTibco ex::  " + excp);
           // System.out.println("Inside catch block" + excp);
            excp.printStackTrace();

        }

        return docFinalXMLtoTibco;
    }

    public Document updatedDocument(Document docFinalXMLtoTibco, YFSEnvironment env) {

    	loggerForPosInvoice.beginTimer("KohlsOMSToTibco.updatedDocument");
        HashMap<String, String> hmap = new HashMap<String, String>();
        HashMap<String, String> hmap2 = new HashMap<String, String>();
        String strKey = null;
        Element eleOrderLineExchange = null;
        String negative = "-";
        try {
            NodeList ndlOrderLineForExchange = ((NodeList) XPathUtil.getNodeList(
                    docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/OrderLinesForExchange/OrderLines/OrderLines/OrderLine"));

            NodeList ndlOrderLineForReturn = ((NodeList) XPathUtil.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine"));

            for (int i = 0; i < ndlOrderLineForExchange.getLength(); i++) {

                Element eleOrderLineForExchange = (Element) ((NodeList) XPathUtil.getNodeList(
                        docFinalXMLtoTibco.getDocumentElement(),
                        "/InvoiceDetail/InvoiceHeader/Order/OrderLinesForExchange/OrderLines/OrderLines/OrderLine"))
                        .item(i);

                Element eleItemLevel = XMLUtil.getChildElement(eleOrderLineForExchange, "Item");
              //  System.out.println("Item level element from  exchange nodelist is :::"
               //         + XMLUtil.getElementXMLString(eleItemLevel));
                // Fix for UPC code -- begin -- 12/5/16
                Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
                Element eleItemInput = docGetItemListInput.getDocumentElement();
                String strItemId = eleItemLevel.getAttribute("ItemID");
                String strUPCCode = eleItemLevel.getAttribute("UPCCode");
                eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);

                Document docItemListOutput1 = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST,
                        KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);
		
		Element eleItemOutput = docItemListOutput1.getDocumentElement();
                Element eleExtn= (Element) eleItemOutput.getElementsByTagName("Extn").item(0);
                XMLUtil.importElement(eleItemLevel, eleExtn);

                if (YFCCommon.isVoid(strUPCCode) || strUPCCode.isEmpty() || strUPCCode == null) {
                    String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput1);

                    if (YFCCommon.isVoid(upc_code) || upc_code.isEmpty() || upc_code == null) {
                        upc_code = "No UPC Found";
                    }
                    eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code);
                } else {
                    eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
                }

                // Fix for UPC code -- end -- 12/5/16

                Element eleOrderLineForExchangeExtn = (Element) ((NodeList) XPathUtil
                        .getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                                "/InvoiceDetail/InvoiceHeader/Order/OrderLinesForExchange/OrderLines/OrderLines/OrderLine/Extn"))
                        .item(i);
                
                //Start of PST-971
                if(!YFCObject.isVoid(eleOrderLineForExchangeExtn)){
					 if(eleOrderLineForExchangeExtn.hasAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE)){

						 String extnSimplePromoPrice = eleOrderLineForExchangeExtn.getAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE);

						 if(YFCCommon.isVoid(extnSimplePromoPrice)){
							 eleOrderLineForExchangeExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
						 }
					 }else{
						 eleOrderLineForExchangeExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
					 }
				 }else{
					 Element extnOrderLine = docFinalXMLtoTibco.createElement(KohlsPOCConstant.A_EXTN);
					 extnOrderLine.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
					 eleOrderLineForExchange.appendChild(extnOrderLine);
				 }
                //End of PST-971
                
                Element eleOrderLineForExchangeCustom = (Element) ((NodeList) XPathUtil
                        .getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                                "/InvoiceDetail/InvoiceHeader/Order/OrderLinesForExchange/OrderLines/OrderLines/OrderLine/CustomAttributes"))
                        .item(i);

                /*
                 * strExtnRIpairlineKey
                 * =eleOrderLineForExchangeExtn.getAttribute
                 * ("ExtnReturnItemPairLineKey");
                 */
                strExtnRIpairlineKey = eleOrderLineForExchangeCustom.getAttribute(KohlsXMLLiterals.Text2);

                strExchngeOLkey = eleOrderLineForExchange.getAttribute("OrderLineKey");

              //  System.out.print("ExtnReturnItemPairLineKey is :::" + strExtnRIpairlineKey);
              //  System.out.println("OrderLineKey for the exchange order is ::" + strExchngeOLkey);

                if ((!YFCCommon.isVoid(strExtnRIpairlineKey)) && (!YFCCommon.isVoid(strExchngeOLkey))) {
                    hmap.put(strExchngeOLkey, strExtnRIpairlineKey);
                    hmap2.put(strExtnRIpairlineKey, strExchngeOLkey);
                }
                //Fix for PR-722 - Start
				Element eleReferencesEx = XMLUtil.getChildElement(eleOrderLineForExchange, KohlsPOCConstant.A_REFERENCES);
				Element eleReferenceEx = XMLUtil.createChild(eleReferencesEx, KohlsPOCConstant.A_REFERENCE);
				XMLUtil.setAttribute(eleReferenceEx, "Name", "ExtnIsDeletedReturnLine");
				XMLUtil.setAttribute(eleReferenceEx, "Value", "N");
				//Fix for PR-722 - End

            }

            Element eleOrderLineParent = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/OrderLines");
            NodeList ndlOrderLine1 = XPathUtil.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine");

            for (int b = 0; b < ndlOrderLine1.getLength(); b++) {
                XMLUtil.removeChild(eleOrderLineParent, (Element) ndlOrderLine1.item(b));

            }

            for (int i = 0; i < ndlOrderLineForReturn.getLength(); i++) {
                Element eleOrderLineForReturn = (Element) ndlOrderLineForReturn.item(i);
                //PST-5317 - Start
                String strOLForReturnQrderedQty = XMLUtil.getAttribute(eleOrderLineForReturn, KohlsPOCConstant.ATTR_ORDERED_QTY);
                if(!(KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(strOLForReturnQrderedQty))){
                //PST-5317 - End
                Element eleItemLevel = XMLUtil.getChildElement(eleOrderLineForReturn, "Item");
                Element eleLinePriceInfo = XMLUtil.getChildElement(eleOrderLineForReturn, "LinePriceInfo");
                Element eleLineOverrallTotals = XMLUtil.getChildElement(eleOrderLineForReturn, "LineOverallTotals");
                
                //Start of PST-971
                Element eleOrderLineForExtn = (Element) eleOrderLineForReturn.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
                

                if(!YFCObject.isVoid(eleOrderLineForExtn)){
					 if(eleOrderLineForExtn.hasAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE)){

						 String extnSimplePromoPrice = eleOrderLineForExtn.getAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE);

						 if(YFCCommon.isVoid(extnSimplePromoPrice)){
							 eleOrderLineForExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
						 }
					 }else{
						 eleOrderLineForExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
					 }
				 }else{
					 Element extnOrderLine = docFinalXMLtoTibco.createElement(KohlsPOCConstant.A_EXTN);
					 extnOrderLine.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
					 eleOrderLineForReturn.appendChild(extnOrderLine);
				 }
                //End of PST-971

                // Fix for UPC code -- begin -- 12/5/16

                Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
                Element eleItemInput = docGetItemListInput.getDocumentElement();
                String strItemId = eleItemLevel.getAttribute("ItemID");
                String strUPCCode = eleItemLevel.getAttribute("UPCCode");
                eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);

                Document docItemListOutput1 = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST,
                        KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);

		Element eleItemOutput = docItemListOutput1.getDocumentElement();
                Element eleExtn= (Element) eleItemOutput.getElementsByTagName("Extn").item(0);
                XMLUtil.importElement(eleItemLevel, eleExtn);

                if (YFCCommon.isVoid(strUPCCode) || strUPCCode.isEmpty() || strUPCCode == null) {

                    String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput1);
                    if (YFCCommon.isVoid(upc_code) || upc_code.isEmpty() || upc_code == null) {
                        upc_code = "No UPC Found";
                    }
                    eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code);
                } else {
                    eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
                }

                // Fix for UPC code -- end -- 12/5/16

                String strLineTotal1 = eleLinePriceInfo.getAttribute("LineTotal");
                String strLineTotal2 = eleLineOverrallTotals.getAttribute("LineTotal");
                strLineTotal2 = negative.concat(strLineTotal2);
                strLineTotal1 = negative.concat(strLineTotal1);
                eleLinePriceInfo.setAttribute("LineTotal", strLineTotal1);
                eleLineOverrallTotals.setAttribute("LineTotal", strLineTotal2);
                //Fix for PR-722 - Start
				Element eleReferencesRt = XMLUtil.getChildElement(eleOrderLineForReturn, KohlsPOCConstant.A_REFERENCES);
				Element eleReferenceRt = XMLUtil.createChild(eleReferencesRt, KohlsPOCConstant.A_REFERENCE);
				XMLUtil.setAttribute(eleReferenceRt, "Name", "ExtnIsDeletedReturnLine");
				if("-0.00".equalsIgnoreCase(strLineTotal1) && "-0.00".equalsIgnoreCase(strLineTotal2)){
					XMLUtil.setAttribute(eleReferenceRt, "Value", "Y");
				}else{
					XMLUtil.setAttribute(eleReferenceRt, "Value", "N");
				}
				//Fix for PR-722 - End
                // Changes for 4090 if required -- POC Returns Team - Start
                String strUnitPrice = eleLinePriceInfo.getAttribute("UnitPrice");
                if (!YFCCommon.isStringVoid(strUnitPrice)) {
                    eleLinePriceInfo.setAttribute("ListPrice", strUnitPrice);
                }
                // Changes for 4090 if required -- POC Returns Team - End

              //  System.out.println("current element in return is :::"
              //          + XMLUtil.getElementXMLString(eleOrderLineForReturn));
                strReturnOLkey = eleOrderLineForReturn.getAttribute("OrderLineKey");
              //  System.out.println("Return orderlinekey" + strReturnOLkey);
                if (!YFCCommon.isVoid(strReturnOLkey)) {

                    if ((hmap.containsValue(strReturnOLkey))) {
                        strKey = hmap2.get(strReturnOLkey);

                        for (int x = 0; x < ndlOrderLineForExchange.getLength(); x++) {
                            eleOrderLineExchange = (Element) ndlOrderLineForExchange.item(x);
                            String strOLkey = eleOrderLineExchange.getAttribute("OrderLineKey");
                         //   System.out.println("Order Line Key for Exchange :::" + strOLkey);
                            if (strOLkey.equals(strKey)) {
                                XMLUtil.appendChild(eleOrderLineParent, (Element) ndlOrderLine1.item(x));
                                XMLUtil.appendChild(eleOrderLineParent, eleOrderLineExchange);
                                break;
                            }
                        }

                    } else {
                        XMLUtil.appendChild(eleOrderLineParent, (Element) ndlOrderLine1.item(i));
                    }

                }
            }//PST-5317 - Closing If loop
            }

            Element eleExtraExchange = (Element) ((NodeList) XPathUtil
                    .getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                            "/InvoiceDetail/InvoiceHeader/Order/OrderLinesForExchange")).item(0);

            XMLUtil.removeChild((Element) eleExtraExchange.getParentNode(), eleExtraExchange);

            docFinalXMLtoTibco = calculateTotalOrderLines(docFinalXMLtoTibco);
            docFinalXMLtoTibco = setReturnOrderLinePrimeLineNo(env, docFinalXMLtoTibco);

        }

        catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        loggerForPosInvoice.endTimer("KohlsOMSToTibco.updatedDocument");
        return docFinalXMLtoTibco;
    }

    public Document calculateTotalOrderLines(Document docFinalXMLtoTibco) {

    	loggerForPosInvoice.beginTimer("KohlsOMSToTibco.calculateTotalOrderLines");
        try {

            NodeList ndlOrderLine = ((NodeList) XPathUtil.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine"));

            Integer totalNumberCount = ndlOrderLine.getLength();

            //String totalNumber = totalNumberCount.toString();

            Element eleOrderLines = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/OrderLines");

            //eleOrderLines.setAttribute("TotalNumberOfRecords", totalNumber);

            // Fix for ExtnTaxDetails clob object -- begin -- 18/5/16

            Element eleOrder = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order");

            Element eleExtnTax = (Element) ((NodeList) XPathUtil.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
                    "/InvoiceDetail/InvoiceHeader/Order/Extn")).item(0);

            String strExtnTaxDetails = eleExtnTax.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
            Element eleTaxDetails = null;
            if (!YFCCommon.isVoid(strExtnTaxDetails)) {
                Document docExtnTaxDetails = XMLUtil.getDocument(strExtnTaxDetails);
                eleExtnTax.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
                eleTaxDetails = docExtnTaxDetails.getDocumentElement();
                XMLUtil.importElement(eleOrder, eleTaxDetails);
            }

            // Fix for ExtnTaxDetails clob object -- end -- 18/5/16

            // Changes to remove ExtnSalesTransactionDate and ExtnSalesStoreId
            // -- Start 21/5/16
            //PST-3637 - Start
            String strOrderedQty = "";
            //PST-3637 - End
            for (int i = 0; i < ndlOrderLine.getLength(); i++) {

                Element eleOrderLine = (Element) ndlOrderLine.item(i);
                Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, "Extn");
                String strExtnSalesTransactionDate = eleOrderLineExtn.getAttribute("ExtnSalesTransactionDate");
                String strExtnSalesStoreId = eleOrderLineExtn.getAttribute("ExtnSalesStoreId");

                if (!(YFCCommon.isVoid(strExtnSalesTransactionDate))) {
                    eleOrderLineExtn.removeAttribute("ExtnSalesTransactionDate");
                }
                if (!(YFCCommon.isVoid(strExtnSalesStoreId))) {
                    eleOrderLineExtn.removeAttribute("ExtnSalesStoreId");
                }

                // Changes to remove the CustomAttributes - Start POC Returns
                // Team
                Element eleCustomAttributes = XMLUtil.getChildElement(eleOrderLine, "CustomAttributes");
                if (!YFCCommon.isVoid(eleCustomAttributes)) {
                    String strText2 = eleCustomAttributes.getAttribute(KohlsXMLLiterals.Text2);

                  //  System.out.println("StrText2 :::" + strText2);
                    if (!YFCCommon.isVoid(strText2)) {
                        eleOrderLineExtn.setAttribute("ExtnReturnItemPairLineKey", strText2);
                    }

                }
                //XMLUtil.removeChild(eleOrderLine, eleCustomAttributes);
                //PST-3637 - Start
                strOrderedQty = XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);
                if(strOrderedQty.equalsIgnoreCase(KohlsPOCConstant.ZERO_STR) && totalNumberCount>1){
                	eleOrderLines.removeChild(eleOrderLine);
                	totalNumberCount--;
                	loggerForPosInvoice.debug("The eleOrderLineForExchange element after removing is : " +XMLUtil.getElementXMLString(eleOrderLine));
                }
                //PST-3637 - End
                // Changes to remove the CustomAttributes - Start POC Returns
                // Team
            }
            // Changes to remove ExtnSalesTransactionDate and ExtnSalesStoreId
            // -- End 21/5/16
            //PST-3637 - Start
            String totalNumber = totalNumberCount.toString();
            eleOrderLines.setAttribute("TotalNumberOfRecords", totalNumber);
            //PST-3637 - End
        }

        catch (Exception e) {
            e.printStackTrace();
        }
        loggerForPosInvoice.endTimer("KohlsOMSToTibco.calculateTotalOrderLines");
        return docFinalXMLtoTibco;
    }

    public Document generateReturnToTibco(YFSEnvironment env, Document docgetOrderInput) throws Exception {

        Document docReturnOut = XMLUtil.createDocument("InvoiceDetail");
        Element eleInvoiceDetail = docReturnOut.getDocumentElement();
        eleInvoiceDetail.setAttribute("MessageType", "EE_VoidDuring");
        eleInvoiceDetail.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
        Element eleInvoiceheader = XMLUtil.createChild(eleInvoiceDetail, "InvoiceHeader");

        Element elegetOrderInput = docgetOrderInput.getDocumentElement();
        eleInvoiceheader.setAttribute("DateInvoiced", elegetOrderInput.getAttribute("Modifyts"));
        eleInvoiceheader.setAttribute("TotalAmount", "0.00");
        docReturnOut.adoptNode(elegetOrderInput);
        XMLUtil.appendChild(eleInvoiceheader, elegetOrderInput);

        Element eleTempOrder = (Element) XPathUtil.getNode(docReturnOut.getDocumentElement(),
                "/InvoiceDetail/InvoiceHeader/Order");

        Element eleExtnTax = (Element) ((NodeList) XPathUtil.getNodeList(docReturnOut.getDocumentElement(),
                "/InvoiceDetail/InvoiceHeader/Order/Extn")).item(0);

        String strExtnTaxDetails = eleExtnTax.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
        Element eleTaxDetails = null;
        if (!YFCCommon.isVoid(strExtnTaxDetails)) {
            Document docExtnTaxDetails = XMLUtil.getDocument(strExtnTaxDetails);
            eleExtnTax.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
            eleTaxDetails = docExtnTaxDetails.getDocumentElement();
            XMLUtil.importElement(eleTempOrder, eleTaxDetails);
        }

        return docReturnOut;
    }

    public Document checkAndUpdateIfExchangeOrder(YFSEnvironment env, Document docInput) {
        try {
            Element EleOrder = (Element) XPathUtil.getNode(docInput, "/InvoiceDetail/InvoiceHeader/Order");
            String strOrderHkey = EleOrder.getAttribute("OrderHeaderKey");

            Document docInputForGetOrderDetails = YFCDocument.createDocument("Order").getDocument();
            Element eleRoot = docInputForGetOrderDetails.getDocumentElement();
            eleRoot.setAttribute("OrderHeaderKey", strOrderHkey);
            // Preparing Document Template to check Order Purpose
            Document docTemplate = XMLUtil.getDocument("<Order OrderPurpose=''/>");

            // Invoking getOrderDetails with Template
            Document docOutput = KOHLSBaseApi
                    .invokeAPI(env, docTemplate, "getOrderDetails", docInputForGetOrderDetails);

            String strOrderPurpose = docOutput.getDocumentElement().getAttribute("OrderPurpose");

            // Updating MessageType in case of Exchange Order
            if (strOrderPurpose.equalsIgnoreCase("Exchange")) {
                Element eleInvoiceDetail = docInput.getDocumentElement();
                eleInvoiceDetail.setAttribute("MessageType", "EE_VoidAfter");
                docInput = updateVoidAfterDocForEE(env, docInput);
            }

        } catch (Exception e) {
            loggerForPosInvoice.error("Exception thrown::" + e);
        }

        return docInput;
    }

    public Document updateVoidAfterDocForEE(YFSEnvironment env, Document docInput) {

        String strDerivedFromOrderHeaderKey = null;
        String strOrderInvoiceKey = null;
        Document docLinkedSourceOutput = null;
        try {
            loggerForPosInvoice.beginTimer("updateVoidAfterDocForEE--Begin");
            Element EleOrder = (Element) XPathUtil.getNode(docInput, "/InvoiceDetail/InvoiceHeader/Order");
            Element EleInvHeader = (Element) XPathUtil.getNode(docInput, "/InvoiceDetail/InvoiceHeader");
            String strOrderHkey = EleOrder.getAttribute("OrderHeaderKey");
            loggerForPosInvoice.debug("OrderHeaderKey :::" + strOrderHkey);
            Element eleInvoiceExtn = XMLUtil.createChild(EleInvHeader, "Extn");
            Document docInputForGetOrderDetails = YFCDocument.createDocument("Order").getDocument();
            Element eleRoot = docInputForGetOrderDetails.getDocumentElement();
            eleRoot.setAttribute("OrderHeaderKey", strOrderHkey);
            Document docTemplate = XMLUtil
                    .getDocument("<OrderList><Order OrderHeaderKey=''><ReturnOrdersForExchange><ReturnOrderForExchange OrderHeaderKey=''/></ReturnOrdersForExchange><ChargeTransactionDetails><ChargeTransactionDetail OrderInvoiceKey=''/></ChargeTransactionDetails><OverallTotals GrandCharges='' GrandDiscount='' GrandTax='' GrandTotal='' HdrCharges='' HdrDiscount='' HdrTax='' HdrTotal='' LineSubTotal=''/></Order></OrderList>");

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("API Input:::" + XMLUtil.getXMLString(docInputForGetOrderDetails));
            Document docOrderOutput = KOHLSBaseApi.invokeAPI(env, docTemplate, "getOrderList",
                    docInputForGetOrderDetails);

            NodeList ndlChargeTransDetails = XPathUtil.getNodeList(docOrderOutput,
                    "/OrderList/Order/ChargeTransactionDetails/ChargeTransactionDetail");

            for (int i = 0; i < ndlChargeTransDetails.getLength(); i++) {
                Element eleCurrent = (Element) ndlChargeTransDetails.item(i);

                if (loggerForPosInvoice.isDebugEnabled())
                    loggerForPosInvoice.debug("Current ChargeTransactionDetail in iteration::"
                            + XMLUtil.getElementXMLString(eleCurrent));
                strOrderInvoiceKey = eleCurrent.getAttribute("OrderInvoiceKey");
                if (!(YFCCommon.isVoid(strOrderInvoiceKey))) {
                    loggerForPosInvoice.debug("Selected OrderInvoiceKey is" + strOrderInvoiceKey);
                    break;
                }
            }

            // MAD-337 start
            /*
             * The below code gets the invoice key from the
             * previous(KohlsPoCPublishVoidInvoice) API component only for Post
             * Void scenarios Load offline transaction(For the orders synced
             * from ISS to Corp.
             */
            String postVoidInvoiceKey = (String) env.getTxnObject(KohlsPOCConstant.TXN_POST_VOID_INVOICE_KEY);
            if (!YFCCommon.isVoid(postVoidInvoiceKey)) {
                strOrderInvoiceKey = postVoidInvoiceKey;
                loggerForPosInvoice.debug("The orderInvoiceKey for postvoid scenario is   :" + strOrderInvoiceKey);
            }

            // MAD-337 End
            Document docInputForGetOrderInvDetails = YFCDocument.createDocument("GetOrderInvoiceDetails").getDocument();
            Element eleInvRoot = docInputForGetOrderInvDetails.getDocumentElement();
            eleInvRoot.setAttribute("InvoiceKey", strOrderInvoiceKey);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("Input to GetOrderInvoiceDetails:::"
                        + XMLUtil.getXMLString(docInputForGetOrderInvDetails));
            Document docInvOutput = invokeService(env, "GetOrderInvoiceDetails", docInputForGetOrderInvDetails);
            Element eleNewInvHeader = (Element) XPathUtil.getNode(docInvOutput, "/InvoiceDetail/InvoiceHeader");
            Element eleInvOrder = (Element) XPathUtil.getNode(docInvOutput, "/InvoiceDetail/InvoiceHeader/Order");
            Element eleOverallTotals = (Element) XPathUtil.getNode(docOrderOutput, "/OrderList/Order/OverallTotals");
            // Element eleOrderRoot = docOrderOutput.getDocumentElement();
            // MAD-337 changes start
            String strOperatorID = "";
            String strOrderDate = "";
            if (!YFCCommon.isVoid(postVoidInvoiceKey)) {
                loggerForPosInvoice.debug("OperatorID is fetched from transaction audit");
                Element transactionAuditElement = (Element) XPathUtil.getNode(docInput,
                        "/InvoiceDetail/InvoiceHeader/TransactionAudits/TransactionAudit");
                strOperatorID = transactionAuditElement.getAttribute("OperatorID");
                strOrderDate = EleOrder.getAttribute("OrderDate");

            } else {
                strOperatorID = eleInvOrder.getAttribute("OperatorID");
                strOrderDate = eleInvOrder.getAttribute("OrderDate");

            }
            EleOrder.setAttribute("OperatorID", strOperatorID);
            EleOrder.setAttribute("OrderDate", strOrderDate);
            // MAD-337 changes end
            String strDateInvoiced = eleNewInvHeader.getAttribute("DateInvoiced");
            String strTotalAmount = eleNewInvHeader.getAttribute("TotalAmount");

            EleInvHeader.setAttribute("DateInvoiced", strDateInvoiced);
            EleInvHeader.setAttribute("TotalAmount", strTotalAmount);

            docInput.adoptNode(eleOverallTotals);
            XMLUtil.appendChild(EleOrder, eleOverallTotals);

            // Fetching Original Sales Data

            Element eleReturnOrders = (Element) XPathUtil.getNode(docOrderOutput,
                    "/OrderList/Order/ReturnOrdersForExchange/ReturnOrderForExchange");
            String strReturnOHKey = eleReturnOrders.getAttribute("OrderHeaderKey");
            Document docInputForSale = YFCDocument.createDocument("Order").getDocument();
            Element eleOrderForSale = docInputForSale.getDocumentElement();
            eleOrderForSale.setAttribute("OrderHeaderKey", strReturnOHKey);

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("Input to GetSalesOrderList::" + XMLUtil.getXMLString(docInputForSale));
            Document docSalesOrderOutput = invokeService(env, "GetSalesOrderList", docInputForSale);

            // Commenting for #4162 -- POC Returns Team -- Start
            /*
             * Element eleOrderLine = (Element) ((NodeList)
             * XPathUtil.getNodeList( docSalesOrderOutput.getDocumentElement(),
             * "/OrderList/Order/OrderLines/OrderLine")).item(0); if
             * (!YFCCommon.isVoid(eleOrderLine)) { strDerivedFromOrderHeaderKey
             * = eleOrderLine
             * .getAttribute(KohlsXMLLiterals.A_DERIVED_FROM_ORDER_HEADER_KEY);
             * loggerForPosInvoice.debug("DerivedFromOrderHeaderKey is :::" +
             * strDerivedFromOrderHeaderKey); } // Receipted Flow for fetching
             * Sales Detail if
             * (!(YFCCommon.isVoid(strDerivedFromOrderHeaderKey))) { Document
             * docInputForSales = YFCDocument.createDocument("Order")
             * .getDocument(); Element eleLinkedSourceInput = docInputForSales
             * .getDocumentElement();
             * 
             * eleLinkedSourceInput.setAttribute(
             * KohlsPOCConstant.ATTR_ORD_HDR_KEY, strDerivedFromOrderHeaderKey);
             * docLinkedSourceOutput = invokeService(env, "GetLinkedOrderList",
             * docInputForSales); Element eleOrigSalesOrder = (Element)
             * ((NodeList) XPathUtil .getNodeList(
             * docLinkedSourceOutput.getDocumentElement(), "/Order")).item(0);
             * Element eleReturnOrderExtn = (Element) XPathUtil.getNode(
             * docSalesOrderOutput, "/OrderList/Order/Extn");
             * 
             * String strSalesOrderDate = eleOrigSalesOrder
             * .getAttribute("OrderDate"); String strSalesTransNo =
             * eleReturnOrderExtn .getAttribute("ExtnOrigPosSequenceNo"); String
             * strSalesTerminalID = eleOrigSalesOrder
             * .getAttribute("TerminalID"); String strSalesOrgCode =
             * eleOrigSalesOrder .getAttribute("SellerOrganizationCode");
             * 
             * // Setting Sales Attributes at Extn Level
             * eleInvoiceExtn.setAttribute("ExtnShipNode", strSalesOrgCode);
             * 
             * eleInvoiceExtn.setAttribute("ExtnSellerOrganisationCode",
             * strSalesOrgCode);
             * eleInvoiceExtn.setAttribute("ExtnPosSequenceNo",
             * strSalesTransNo); eleInvoiceExtn.setAttribute("ExtnTerminalID",
             * strSalesTerminalID); eleInvoiceExtn.setAttribute("ExtnOrderDate",
             * strSalesOrderDate); }
             */
            // Non - Receipted Flow
            // else {
            // Commenting for #4162 -- POC Returns Team -- End
            Element eleReturnOrder = (Element) XPathUtil.getNode(docSalesOrderOutput, "/OrderList/Order");
            Element eleReturnOrderExtn = (Element) XPathUtil.getNode(docSalesOrderOutput, "/OrderList/Order/Extn");

            String strSalesOrderDate = eleReturnOrder.getAttribute("OrderDate");
            String strSalesTransNo = eleReturnOrderExtn.getAttribute("ExtnOrigPosSequenceNo");
            String strSalesTerminalID = eleReturnOrder.getAttribute("TerminalID");
            String strSalesOrgCode = eleReturnOrder.getAttribute("SellerOrganizationCode");

            eleInvoiceExtn.setAttribute("ExtnShipNode", strSalesOrgCode);

            eleInvoiceExtn.setAttribute("ExtnSellerOrganisationCode", strSalesOrgCode);
            eleInvoiceExtn.setAttribute("ExtnPosSequenceNo", strSalesTransNo);
            eleInvoiceExtn.setAttribute("ExtnTerminalID", strSalesTerminalID);
            eleInvoiceExtn.setAttribute("ExtnOrderDate", strSalesOrderDate);

            // }

            if (loggerForPosInvoice.isDebugEnabled())
                loggerForPosInvoice.debug("Final Updated Document :::" + XMLUtil.getXMLString(docInput));
            loggerForPosInvoice.endTimer("updateVoidAfterDocForEE--End");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return docInput;
    }

    /**
     * 
     * Rewriting the code for HPQC #4197
     * 
     * The idea is to get the Return Order Details and Overwrite the PrimeLineNo
     * attribute of Return OrderLines in DC xml with the ones from the sale
     * 
     * @param yfsEnv
     * @param docDataCollect
     * @return
     */
    private Document setReturnOrderLinePrimeLineNo(YFSEnvironment yfsEnv, Document docDataCollect) {
        // Changes for #4197 - POC Returns Team -- Start
        try {
            if (loggerForPosInvoice.isDebugEnabled()) {
                loggerForPosInvoice.debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo -- Start");
                loggerForPosInvoice.debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo docDataCollect="
                        + XMLUtil.getXMLString(docDataCollect));
            }

            Element eleOrder = (Element) docDataCollect.getDocumentElement().getElementsByTagName("Order").item(0);
            if (!YFCCommon.isVoid(eleOrder)) {
                String strOHKey = eleOrder.getAttribute("OrderHeaderKey");
                if (loggerForPosInvoice.isDebugEnabled()) {
                    loggerForPosInvoice.debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo strOHKey=" + strOHKey);
                }
                Document docGetOrderListInp = XMLUtil.getDocument("<Order/>");
                if (!YFCCommon.isVoid(docGetOrderListInp)) {
                    Element eleGetOrderListInp = docGetOrderListInp.getDocumentElement();
                    Document docGetOrderListTemp = XMLUtil
                            .getDocument("<OrderList><Order OrderHeaderKey=''><OrderLines><OrderLine OrderLineKey=''><CustomAttributes Text5=''/>"
                                    + "</OrderLine></OrderLines></Order></OrderList>");
                    if (!YFCCommon.isVoid(docGetOrderListTemp) && loggerForPosInvoice.isDebugEnabled()) {
                        loggerForPosInvoice.debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo docGetOrderListTemp="
                                + XMLUtil.getXMLString(docGetOrderListTemp));
                    }
                    if (!YFCCommon.isStringVoid(strOHKey)) {
                        eleGetOrderListInp.setAttribute("OrderHeaderKey", strOHKey);
                        Document docGetOrderListOut = KohlsCommonUtil.invokeAPI(yfsEnv, docGetOrderListTemp,
                                KohlsPOCConstant.GET_ORDER_LIST, docGetOrderListInp);
                        if (!YFCCommon.isVoid(docGetOrderListOut)) {
                            if (loggerForPosInvoice.isDebugEnabled()) {
                                loggerForPosInvoice
                                        .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo docGetOrderListOut="
                                                + XMLUtil.getXMLString(docGetOrderListOut));
                            }
                            Map<String, String> mOrderLine2PrimeLine = new HashMap<String, String>();
                            NodeList ndlOrderLine = docGetOrderListOut.getDocumentElement().getElementsByTagName(
                                    "OrderLine");
                            int iSize = ndlOrderLine.getLength();
                            for (int i = 0; i < iSize; i++) {
                                Element eleCurrOrderLine = (Element) ndlOrderLine.item(i);
                                if (loggerForPosInvoice.isDebugEnabled()) {
                                    loggerForPosInvoice
                                            .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo eleCurrOrderLine="
                                                    + XMLUtil.getElementXMLString(eleCurrOrderLine));
                                }
                                Element eleCurrCustAttr = XMLUtil.getChildElement(eleCurrOrderLine, "CustomAttributes");
                                if (loggerForPosInvoice.isDebugEnabled()) {
                                    loggerForPosInvoice
                                            .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo eleCurrCustAttr="
                                                    + XMLUtil.getElementXMLString(eleCurrCustAttr));
                                }
                                if (!YFCCommon.isVoid(eleCurrOrderLine) && !YFCCommon.isVoid(eleCurrCustAttr)) {
                                    String sCurrOLKey = eleCurrOrderLine.getAttribute("OrderLineKey");
                                    String sText5 = eleCurrCustAttr.getAttribute("Text5");
                                    if (loggerForPosInvoice.isDebugEnabled()) {
                                        loggerForPosInvoice
                                                .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo sCurrOLKey="
                                                        + sCurrOLKey + " sText5=" + sText5);
                                    }
                                    if (!YFCCommon.isStringVoid(sCurrOLKey) && !YFCCommon.isStringVoid(sText5)) {
                                        mOrderLine2PrimeLine.put(sCurrOLKey, sText5);
                                    }
                                }
                            }
                            if (loggerForPosInvoice.isDebugEnabled()) {
                                loggerForPosInvoice
                                        .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo mOrderLine2PrimeLine="
                                                + mOrderLine2PrimeLine);
                            }

                            NodeList ndlDCOrderLine = docDataCollect.getDocumentElement().getElementsByTagName(
                                    "OrderLine");
                            iSize = ndlDCOrderLine.getLength();
                            for (int i = 0; i < iSize; i = i + 2) {
                                Element eleCurrOrderLine = (Element) ndlDCOrderLine.item(i);
                                if (loggerForPosInvoice.isDebugEnabled()) {
                                    loggerForPosInvoice
                                            .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo eleCurrOrderLine="
                                                    + XMLUtil.getElementXMLString(eleCurrOrderLine));
                                }
                                String sCurrOLKey = eleCurrOrderLine.getAttribute("OrderLineKey");
                                if (!YFCCommon.isStringVoid(sCurrOLKey)) {
                                    String sPrimeLine = mOrderLine2PrimeLine.get(sCurrOLKey);
                                    if (!YFCCommon.isStringVoid(sPrimeLine)) {
                                        if (loggerForPosInvoice.isDebugEnabled()) {
                                            loggerForPosInvoice
                                                    .debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo sPrimeLine"
                                                            + sPrimeLine);
                                        }
                                        eleCurrOrderLine.setAttribute("PrimeLineNo", sPrimeLine);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (loggerForPosInvoice.isDebugEnabled()) {
                loggerForPosInvoice.debug("KohlsOMSToTibco.setReturnOrderLinePrimelineNo -- End");
            }
        } catch (Exception e) {
            loggerForPosInvoice.error(e.getMessage());
        }
        // Changes for #4197 - POC Returns Team -- End
        return docDataCollect;
    }
	
	/**
     * Method to get the actual order confirm timestamp for the Return as part
     * of EE confirmed in ISS.PST-843.
     * 
     * @param env
     * @param inputPublishInvoiceDetail
     * @param eleInvoiceHeader
     * @param eleInvoiceOrder
     * @throws Exception
     * 
     */
    private Element setDateInvoicedForSaleSyncedToCorp(YFSEnvironment env, Element eleInvoiceHeader,
            String sellerOrganizationCode, String transactionNo, String entryType) throws Exception {
        loggerForPosInvoice.beginTimer("KohlsOMSToTibco.setDateInvoicedForSaleSyncedToCorp");
        loggerForPosInvoice.debug("EntryType for ISS order  :" + entryType);
        if (KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE.equals(entryType)) {
            Document inputOfflineTrxQDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
            Element inputOfflineTrxQElement = inputOfflineTrxQDoc.getDocumentElement();
            inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.V_N);
            inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.UNIQUE_ID_MULTI_API);
            inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, sellerOrganizationCode);
            inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, transactionNo);
            String getOfflineTrxQTemplate = KohlsPOCConstant.GET_OFFLINE_TRANSACTION_QLIST_TEMPLATE;
            Document getOfflineTrxQs = invokeAPI(env, getOfflineTrxQTemplate,
                    KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS, inputOfflineTrxQDoc);
            if (!YFCCommon.isVoid(getOfflineTrxQs)) {
                NodeList offlineTrxQList = XPathUtil.getNodeList(getOfflineTrxQs.getDocumentElement(),
                        KohlsPOCConstant.OFFLINE_TRX_Q_XPATH);
                if (offlineTrxQList.getLength() > 0) {
                    Element offlineTrxQElement = (Element) offlineTrxQList.item(0);
                    String operationTs = offlineTrxQElement.getAttribute(KohlsPOCConstant.A_OPERATION_TS);
                    loggerForPosInvoice.debug("The operation ts from the pos offline entry   :" + operationTs);
                    eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_DATE_INVOICED, operationTs);
                }
            }

        }

        return eleInvoiceHeader;
    }
    private void updateInvoiceStatus(YFSEnvironment env, String sOrderInvoiceKey) throws Exception {
    	loggerForPosInvoice.beginTimer("KohlsOMSToTibco.updateInvoiceStatus");
        Document docChangeOrderInvoiceInXML = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_INVOICE);
        docChangeOrderInvoiceInXML.getDocumentElement()
            .setAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY, sOrderInvoiceKey);
        docChangeOrderInvoiceInXML.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_STATUS,
            KohlsPOCConstant.INVOICE_PUBLISHED_STATUS);
        try{
        	invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER_INVOICE, docChangeOrderInvoiceInXML);
            
        }
        catch(Exception e)
        {
        	  loggerForPosInvoice.debug("Change Order Invoice api call failed:" + sOrderInvoiceKey);
        }
        loggerForPosInvoice.endTimer("KohlsOMSToTibco.updateInvoiceStatus");
      }
    
    //PST-5317 - Start
    private void removeDeletedOrderLines(Document inDoc, String isListDoc) throws Exception {
    	loggerForPosInvoice.beginTimer("KohlsOMSToTibco.removeDeletedOrderLines");
    	if(loggerForPosInvoice.isDebugEnabled()){
    		loggerForPosInvoice.debug("KohlsOMSToTibco.removeDeletedOrderLines inDoc is: " +XMLUtil.getXMLString(inDoc));
    	} 
    	try{
    		Element eleInDoc = inDoc.getDocumentElement();
    		Element eleOrder = null;
    		Element eleOrderLines= null;

    		if(!YFCCommon.isVoid(eleInDoc)){
    			if(KohlsPOCConstant.YES.equalsIgnoreCase(isListDoc)){
    				eleOrder = XMLUtil.getChildElement(eleInDoc, KohlsPOCConstant.ELEM_ORDER);
    			}else{
    				eleOrder = eleInDoc;
    			}
    			eleOrderLines = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);
    			if(loggerForPosInvoice.isDebugEnabled()){
    				loggerForPosInvoice.debug("KohlsOMSToTibco.removeDeletedOrderLines eleOrderLines is: " +XMLUtil.getElementXMLString(eleOrderLines));
    			} 
    			//NodeList nlOrderLine = eleOrder.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    			List<Element> nlOrderLine = XMLUtil.getElementsByTagName(eleOrder,KohlsPOCConstant.E_ORDER_LINE);
    			Iterator<Element> iter = nlOrderLine.iterator();
    			if (nlOrderLine.size() > KohlsPOCConstant.ZERO_INT) {
    				loggerForPosInvoice.debug("The size of nlOrderLine : " + nlOrderLine.size());
    				while (iter.hasNext()) {
    					Element eleOrderLine = iter.next();
    					String strOrderedQty = XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);

    					if(KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(strOrderedQty))
    					{
    						XMLUtil.removeChild(eleOrderLines, eleOrderLine);
    					}
    				}  
    			}
    			if(loggerForPosInvoice.isDebugEnabled()){
    				loggerForPosInvoice.debug("KohlsOMSToTibco.removeDeletedOrderLines removed eleOrderLines is: " +XMLUtil.getElementXMLString(eleOrderLines));
    			} 
    		}
    	}catch(Exception e){
    		loggerForPosInvoice.error("Error while removing deleted orderlines from KohlsOMSToTibco.removeDeletedOrderLines");
    	}

    	loggerForPosInvoice.endTimer("KohlsOMSToTibco.removeDeletedOrderLines");

    }
    //PST-5317 - End

}
