package com.kohls.poc.api;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.bcsupport.YCPBCTemplateTrimmer;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCreateInputForPA extends KOHLSBaseApi {

  private static final YFCLogCategory logger =
      YFCLogCategory.instance(KohlsCreateInputForPA.class.getName());

  private static String strOrderInvoiceKey = null;
  private String strPSASellerOrgCode = null;
  private static Document docGetOrderInvoiceDetailsInput = null;
  private Map<String, Element> mTieredDiscount = new LinkedHashMap<String, Element>();
  Document docOrderListOutput = null;
  Document doc = null;
  Document docOriginalSale = null;
  Document docInputForOrigSale = null;
  Document docInputForgetOrderDetail = null;
  NodeList ndlOriginalSaleOrder = null;
  NodeList ndlPSASaleOrder = null;
  Element eleInputForOrigSale = null;
  Element elePAOrder = null;
  Element eleRootElement = null;
  Element eleOrderOfSale = null;
  String strOHkey = null;
  String strClobData = null;
  String strNoUPCMsg = "No UPC Found";

  /**
   * This function prepares an input document for DataCollect Author Kohls
   * 
   * @param env
   * @param inputdoc
   * @return docGetOrderInvoiceDetailsInput
   * @exception Exception
   * 
   */

  /**
   * This function iterates over an input document to fetch ChargeTransactionDetails and remove
   * empty CreditCard Elements Author Kohls
   * 
   * @param docInput
   * @return docInput
   * @exception Exception
   * 
   */

  public Document consolidateInvoiceMessage(YFSEnvironment env, Document docFinal)
      throws Exception {

    logger.beginTimer("KohlsCreateInputForPA.consolidateInvoiceMessage");
    logger.debug("Invoice Key is::" + strOrderInvoiceKey);
    if (logger.isDebugEnabled()) {
      logger.debug("API input for getOrderInvoiceDetails is:::" + XMLUtil.getXMLString(docFinal));
      logger.debug("docFinal Input value is : " + XMLUtil.getXMLString(docFinal));
    }
    try {

      Element eleOrder = (Element) ((NodeList) XPathUtil.getNodeList(docFinal.getDocumentElement(),
          KohlsPOCConstant.X_INV_ORDER)).item(0);
      strPSASellerOrgCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);

      // Begin Changes for Newly added Extn attributes at Order Level
      String strOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      logger.debug("OrderHeaderKey is::" + strOrderHeaderKey);

      // Consolidating the Invoice Collection and updating InvooiceHeader
      // details
      consolidateInvoiceCollectionWithHeaderDetails(env, docFinal, strOrderHeaderKey);
      if (logger.isDebugEnabled()) {
        logger.debug("Output of consolidateInvoiceCollectionWithHeaderDetails is::"
            + XMLUtil.getXMLString(docFinal));
      }
      // Preparing document for Input
      Document docGetOrderDetailsInput =
          YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
      Element eleOrderInput = docGetOrderDetailsInput.getDocumentElement();
      eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
      logger.debug("PA seller Organization code is:::" + strPSASellerOrgCode);
      docFinal = updateSales(env, docFinal);

      if (logger.isDebugEnabled()) {
        logger.debug(
            "docFinal after Order element removed from OL : " + XMLUtil.getXMLString(docFinal));
      }
      // Trimmer Util
      TrimdocFinalAgainstXsdTemplate(docFinal);
    }

    catch (YFSException exception) {
      logger.error(exception);
      throw exception;
    }
    if (logger.isDebugEnabled()) {
      logger.debug("The Final document sent Tibco Queue : " + XMLUtil.getXMLString(docFinal));
    }
    logger.endTimer("KohlsCreateInputForPA.consolidateInvoiceMessage");
    return docFinal;
  }

  /*
   * This methods takes Tibco xsd as template and trims the docFinal before sending to Tibco This
   * will ensure no extra attributes are sent to SH via Tibco
   */
  private void TrimdocFinalAgainstXsdTemplate(Document docFinal)
      throws ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsCreateInputForPA.TrimdocFinalAgainstXsdTemplate");
    Document document1 = XMLUtil.createDocument(docFinal.getElementsByTagName("Order").item(0));
    InputStream fileToReadFrom = KohlsCreateInputForPA.class
        .getResourceAsStream(KohlsPOCConstant.SEND_INVOICE_DETAIL_TO_TIBCO);
    Document document2 = XMLUtil.getDocument(fileToReadFrom);
    document2 = XMLUtil.createDocument(document2.getElementsByTagName("Order").item(0));
    YFCDocument oOutDoc = YFCDocument.getDocumentFor(document1);

    YFCDocument oTempDoc = YFCDocument.getDocumentFor(document2);

    YCPBCTemplateTrimmer oTempTrim = new YCPBCTemplateTrimmer();

    oTempTrim.trimTheOutputBasedOnTemplate(oOutDoc.getDocumentElement(),
        oTempDoc.getDocumentElement(), false);

    if (logger.isDebugEnabled()) {
      logger.debug("OutputDoc after trimming is --->" + oOutDoc.getDocumentElement());
    }
    logger.endTimer("KohlsCreateInputForPA.TrimdocFinalAgainstXsdTemplate");
  }

  public Document updateSales(YFSEnvironment env, Document inputDoc) throws Exception {
    logger.beginTimer("KohlsCreateInputForPA.updateSales");

    try {
      logger.debug("Inside Append Sale Method");
      elePAOrder = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_ORDER);
      strOHkey = elePAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      Element elePSAInvHeader =
          (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.XPATH_INVOICE_HEADER);
      String strOIKey = elePSAInvHeader.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
      if (logger.isDebugEnabled()) {
        logger.debug(
            "Appended Invoice Header Element is ::" + XMLUtil.getElementXMLString(elePSAInvHeader));
      }
      // Fetching CollectionDetails from API Output and Appending -- End
      // -- 6/17/16

      // Prepare Input document for API call to fetch original Sales Data
      docInputForOrigSale =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
      eleInputForOrigSale = docInputForOrigSale.getDocumentElement();
      eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
      if (logger.isDebugEnabled()) {
        logger.debug("Document input to API call is::" + XMLUtil.getXMLString(docInputForOrigSale));
      }
      // API call to fetch sales Data
      docOriginalSale =
          invokeService(env, KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInputForOrigSale);

      // Preparing input document for API call to fetch getOrderDetails

      docInputForgetOrderDetail =
          YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
      eleInputForOrigSale = docInputForgetOrderDetail.getDocumentElement();
      eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
      if (logger.isDebugEnabled()) {
        logger
            .debug("Document output of the API call is::" + XMLUtil.getXMLString(docOriginalSale));
      }
      // Parsing Clob Element into Document format
      Element eleRootElement = docOriginalSale.getDocumentElement();

      String strClobData =
          docOriginalSale.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);

      logger.debug("Clob object is:::" + strClobData);

      if (!strClobData.isEmpty()) {
        Document docClobData = XMLUtil.getDocument(strClobData);
        eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA, KohlsPOCConstant.BLANK);
        Element eleNewClob = docClobData.getDocumentElement();
        XMLUtil.importElement(eleRootElement, eleNewClob);

      }
      if (logger.isDebugEnabled()) {
        logger
            .debug("After import root element is::" + XMLUtil.getElementXMLString(eleRootElement));
      }

      // Fetching Order element from original Sales document

      eleOrderOfSale =
          (Element) XPathUtil.getNode(docOriginalSale, KohlsPOCConstant.X_KOHLS_SALES_ORDER);
      // Aj
      Element eleInvOrderLines = (Element) inputDoc.getElementsByTagName("OrderLines").item(0);
      NodeList nlInvOrderline = XPathUtil.getNodeList(inputDoc, KohlsPOCConstant.X_INV_ORDERLINE);

      if (nlInvOrderline.getLength() != 0) {
        for (int i = 0; i < nlInvOrderline.getLength(); i++) {

          Double dText12OfReturn = null;
          Double dExtnRetPriceOfReturn = null;
          boolean bCondition1 = false;
          boolean bCondition2 = false;
          boolean bCondition3 = false;
          boolean bCondition4 = false;
          DecimalFormat df = new DecimalFormat("0.00");
          Element eleInvOrderLine = (Element) nlInvOrderline.item(i);

          String sPrimeLineNo = eleInvOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
          Element eleExtn = (Element) eleInvOrderLine.getElementsByTagName("Extn").item(0);
          String sExtnRetPriceOfReturn = eleExtn.getAttribute("ExtnReturnPrice");
          String sExtnSkuStatusCode = eleExtn.getAttribute("ExtnSkuStatusCode");
          String sExtnIsPriceEntered = eleExtn.getAttribute("ExtnIsPriceEntered");
          Element eleCutomAttributes =
              (Element) eleInvOrderLine.getElementsByTagName("CustomAttributes").item(0);
          String sText12OfReturn = eleCutomAttributes.getAttribute("Text12");
          String sText11OfReturn = eleCutomAttributes.getAttribute("Text11");
          dText12OfReturn = 0.0;
          if (!YFCCommon.isVoid(sText12OfReturn))
            dText12OfReturn = Double.parseDouble(sText12OfReturn);
          dExtnRetPriceOfReturn = Double.parseDouble(sExtnRetPriceOfReturn);
          bCondition1 = dText12OfReturn > dExtnRetPriceOfReturn;
          bCondition2 = "Eligible".equalsIgnoreCase(sText11OfReturn);
          bCondition3 = "30".equalsIgnoreCase(sExtnSkuStatusCode);
          bCondition4 = "Y".equalsIgnoreCase(sExtnIsPriceEntered);

          if (bCondition3 || bCondition4) {
            eleInvOrderLines.removeChild(eleInvOrderLine);
            if (logger.isDebugEnabled()) {
              logger.debug("Else If condition  met----- " + XMLUtil.getXMLString(inputDoc));
            }
          } else if (bCondition1 && bCondition2) {
            eleInvOrderLine.setAttribute("Type", "Sale");
            // Removing promotions if any on the new line
            Element elePromotions =
                XMLUtil.getChildElement(eleInvOrderLine, KohlsPOCConstant.E_PROMOTIONS);
            if (!YFCCommon.isVoid(elePromotions)) {
              eleInvOrderLine.removeChild(elePromotions);
            }
            // fetch order line from docOriginalSale which has same
            // primelineno and appending the matching element to
            // Invoice Doc at OrderLines level
            Element eleOriginalOrderLine =
                SCXmlUtil.getXpathElement(docOriginalSale.getDocumentElement(),
                    "//KOHLSSalesForPsa/Order/OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNo
                        + "']");
            eleOriginalOrderLine.setAttribute("Type", "Return");
            XMLUtil.importElement(eleInvOrderLines, eleOriginalOrderLine);
            if (logger.isDebugEnabled()) {
              logger.debug("if condition meets **** "
                  + XMLUtil.getXMLString(eleInvOrderLines.getOwnerDocument()));
            }
          } else {
            // removing the orderline element which is not matching
            // given criteria. These lines will not be sent to
            // Tibco.
            eleInvOrderLines.removeChild(eleInvOrderLine);
            if (logger.isDebugEnabled()) {
              logger.debug("If condition doesn't meet----- " + XMLUtil.getXMLString(inputDoc));
            }
          }

        }
      }
      // Mapping TaxDetails
      inputDoc = MapTaxIndicators(inputDoc);

      // Removing Promotions

      inputDoc = removeOrderPromotions(inputDoc);

      // New Method Invocation For Appending Promotions And Taxes

      // MJ 04/12 - Not needed for PA, so commenting.
      // inputDoc = AppendPromotionAndTaxes(docOriginalSale, inputDoc);

      // inputDoc = ConsolidateTaxAndTotalAmt(docOriginalSale,inputDoc);

      // Fetching Sales Order Data And Populating at InvoiceHeader level
      // -- Begin -- 6/15/16

      /*
       * Element elePSAextn = XMLUtil.getChildElement(elePAOrder, KohlsPOCConstant.A_EXTN);
       * 
       * String strPosSeqNo = elePSAextn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
       * String strOrderDate = eleOrderOfSale.getAttribute(KohlsPOCConstant.A_ORDER_DATE); String
       * strTerminalId = eleOrderOfSale.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID); String
       * strSellerOrgCode = eleOrderOfSale.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
       * 
       * Element eleInvheaderExtn = (Element) XPathUtil.getNode(inputDoc,
       * KohlsPOCConstant.X_INV_EXTN);
       * 
       * eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_ORDER_DATE, strOrderDate);
       * eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_POS_SEQUEN_NO, strPosSeqNo);
       * eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_TERMINAL_ID, strTerminalId);
       * eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SELLER_ORG_CODE,
       * strSellerOrgCode);
       * 
       * // Adding Sales Data at Extn Level -- 6/25/16
       * eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SHIP_NODE, strSellerOrgCode);
       */

      // Fetching Sales Order Data And Populating at InvoiceHeader level
      // -- End -- -- 6/15/16

      // Removing Clob Object from Sales Award Element -- Begin -- 6/15/16

      // Extracting Tiered Promo Discounts and Storing for #3135 -- Begin
      // -- 27/7/16 --
      /*
       * NodeList ndlOrderline = XPathUtil.getNodeList(docOriginalSale,
       * KohlsPOCConstant.X_KOHLS_SALES_ORDERLINE);
       * 
       * if (ndlOrderline.getLength() != 0) { for (int i = 0; i < ndlOrderline.getLength(); i++) {
       * 
       * DecimalFormat df = new DecimalFormat("0.00"); Element eleOrderLine = (Element)
       * ndlOrderline.item(i); if (logger.isDebugEnabled()) { logger.debug(
       * "Current OrderLine Element is ::" + XMLUtil.getElementXMLString(eleOrderLine)); } if
       * (!YFCCommon.isVoid(eleOrderLine)) { String sOrderLineKey =
       * eleOrderLine.getAttribute("OrderLineKey"); NodeList ndlAwards =
       * XPathUtil.getNodeList(docOriginalSale.getDocumentElement(),
       * "/KOHLSSalesForPsa/Order/OrderLines/OrderLine[@OrderLineKey='" + sOrderLineKey +
       * "']/Awards/Award");
       * 
       * if (ndlAwards != null) { for (int c = 0; c < ndlAwards.getLength(); c++) { Element eleAward
       * = (Element) ndlAwards.item(c); String sAwardApplied =
       * eleAward.getAttribute("AwardApplied");
       * 
       * if (logger.isDebugEnabled()) logger .debug( "Current Award Element is:::" +
       * XMLUtil.getElementXMLString(eleAward)); Element eleExtn = XMLUtil.getChildElement(eleAward,
       * KohlsPOCConstant.A_EXTN);
       * 
       * if (logger.isDebugEnabled()) logger.debug( "Current Extn element under Award is:::" +
       * XMLUtil.getElementXMLString(eleExtn)); if (!YFCCommon.isVoid(eleExtn)) { String
       * sExtnPromoScheme = eleExtn.getAttribute("ExtnPromoScheme"); int iExtnPromoScheme = 0; if
       * (!YFCCommon.isVoid(sExtnPromoScheme)) { iExtnPromoScheme =
       * Integer.parseInt(sExtnPromoScheme); } String strExtnSaleHubData =
       * eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA); logger.debug(
       * "Extn element exists:Checking SalesHubData attribute"); if
       * (!YFCCommon.isVoid(strExtnSaleHubData)) { logger.debug(
       * "Inside Clob block : Parsing into document object"); Document docSalesHubData =
       * XMLUtil.getDocument(strExtnSaleHubData);
       * eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.BLANK);
       * Element eleDataSalesHub = docSalesHubData.getDocumentElement(); logger.debug(
       * "Importing parsed Clob object into Extn element"); XMLUtil.importElement(eleExtn,
       * eleDataSalesHub); if (iExtnPromoScheme >= 400 && iExtnPromoScheme <= 500 &&
       * sAwardApplied.equalsIgnoreCase("Y")) { logger.debug( "Inside Promo Scheme Block"); String
       * sPromoInterfaceId = eleDataSalesHub.getAttribute("PromoInterfaceId"); String
       * sDiscountPercent = eleDataSalesHub.getAttribute("DiscountPercent"); if
       * (!YFCCommon.isVoid(sDiscountPercent)) { sDiscountPercent =
       * df.format(Double.parseDouble(sDiscountPercent) / 100.0); logger.debug(
       * "Inside not null block of Discount Percent"); } String sTierAmtRchd =
       * eleDataSalesHub.getAttribute("TierAmtRchd"); String sTierQtyRchd =
       * eleDataSalesHub.getAttribute("TierQtyRchd"); String sAwardAmount =
       * eleAward.getAttribute("AwardAmount"); if (!mTieredDiscount.containsKey(sPromoInterfaceId))
       * { logger.debug( "Updating mTieredDiscount hashmap with element and promoInterfaceId");
       * Document docTLD = XMLUtil.createDocument("TransactionLevelDiscount"); Element eleTLD =
       * docTLD.getDocumentElement(); eleTLD.setAttribute("PromoInterfaceId", sPromoInterfaceId);
       * eleTLD.setAttribute("DiscountPercent", sDiscountPercent);
       * eleTLD.setAttribute("TierAmtRchd", sTierAmtRchd); eleTLD.setAttribute("TierQtyRchd",
       * sTierQtyRchd); eleTLD.setAttribute("AwardAmount", sAwardAmount);
       * eleTLD.setAttribute("PromoScheme", sExtnPromoScheme);
       * eleTLD.setAttribute("DiscountTypeCode", "T"); mTieredDiscount.put(sPromoInterfaceId,
       * eleTLD); // Adding logger condition check // as per PRF-208 if (logger.isDebugEnabled())
       * logger.debug(sPromoInterfaceId + "Corresponding element is" +
       * XMLUtil.getElementXMLString(eleTLD)); } else { logger .debug(
       * "Else Block for insertion in HashMap with promoInterfaceId"); Element eleTLD =
       * mTieredDiscount.get(sPromoInterfaceId); String sAwardAmt =
       * eleTLD.getAttribute("AwardAmount"); Double dOrigAwardAmt = 0.00; if
       * (!YFCCommon.isVoid(sAwardAmt)) { dOrigAwardAmt = Double.parseDouble(sAwardAmt); } Double
       * dAwardAmt = 0.00; if (!YFCCommon.isVoid(sAwardAmount)) { dAwardAmt =
       * Double.parseDouble(sAwardAmount); } eleTLD.setAttribute("AwardAmount",
       * df.format(dOrigAwardAmt + dAwardAmt)); mTieredDiscount.remove(sPromoInterfaceId);
       * mTieredDiscount.put(sPromoInterfaceId, eleTLD);
       * 
       * if (logger.isDebugEnabled()) logger.debug(sPromoInterfaceId + "Corresponding element is" +
       * XMLUtil.getElementXMLString(eleTLD)); } }
       * 
       * } } } } } }
       * 
       * }
       */
      // Extracting Tiered Promo Discounts and Storing for # 3135 -- End
      // -- 27/7/16 --

      // Removing Clob Object from Sales Award Element -- End -- 6/15/16

      // Preparing NodeList of Sales and PSA Orderline to integrate

      /*
       * ndlOriginalSaleOrder = ((NodeList)
       * XPathUtil.getNodeList(docOriginalSale.getDocumentElement(),
       * KohlsPOCConstant.X_KOHLS_SALES_ORDERLINE));
       * 
       * ndlPSASaleOrder = ((NodeList) XPathUtil.getNodeList(inputDoc.getDocumentElement(),
       * KohlsPOCConstant.X_INV_ORDERLINE));
       */

      // Fetching Temp NodeList of OrderLine elements in PSA document

      /*
       * NodeList ndlTemp = XPathUtil.getNodeList(inputDoc.getDocumentElement(),
       * KohlsPOCConstant.X_INV_ORDERLINE); // Fetching Parent element of Temp
       * 
       * Element eleTempParent = (Element) XPathUtil.getNode(inputDoc.getDocumentElement(),
       * KohlsPOCConstant.X_INV_ORDERLINES);
       * 
       * // Preparing Temp
       * 
       * for (int b = 0; b < ndlTemp.getLength(); b++) { XMLUtil.removeChild(eleTempParent,
       * (Element) ndlTemp.item(b)); }
       */

      // Comparing PrimeLineNo of Sales with PSA and Setting into Temp

      /*
       * for (int i = 0; i < ndlOriginalSaleOrder.getLength(); i++) { Element eleCurrentElement =
       * (Element) ndlOriginalSaleOrder.item(i); String strOrigPrimeLineNo =
       * eleCurrentElement.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO); Element eleItemLevel =
       * XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.ELEM_ITEM);
       * 
       * // Fix for 2969 -- begin
       * 
       * Element eleCurrentExtn = XMLUtil.getChildElement(eleCurrentElement, "Extn"); if
       * (logger.isDebugEnabled()) { logger .debug( "Current Extn Element is::" +
       * XMLUtil.getElementXMLString(eleCurrentExtn)); } String strTaxInd =
       * eleCurrentExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);
       * 
       * strTaxInd = UpdateTaxIndType(strTaxInd);
       * 
       * eleCurrentExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, strTaxInd);
       * 
       * // Fix for 2969 -- End
       * 
       * // Fix for UPC code at Sales OrderLine -- begin -- 6/15/16
       * 
       * Document docGetItemListInput =
       * YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument(); Element eleItemInput
       * = docGetItemListInput.getDocumentElement(); String strItemId =
       * eleItemLevel.getAttribute(KohlsPOCConstant.A_ITEM_ID); String strUPCCode =
       * eleItemLevel.getAttribute(KohlsPOCConstant.A_UPC_CODE);
       * eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);
       * 
       * Document docItemListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST,
       * KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);
       * 
       * if (YFCCommon.isVoid(strUPCCode) || strUPCCode.isEmpty() || strUPCCode == null) {
       * 
       * String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput); if
       * (YFCCommon.isVoid(upc_code) || upc_code.isEmpty() || upc_code == null) { upc_code =
       * strNoUPCMsg; } eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code); } else
       * { eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode); }
       * 
       * // Fix for UPC code at Sales OrderLine -- end -- 6/15/16
       * 
       * // Setting LineTotal for Sales as negative -- Begin Element eleLinePriceInfo =
       * XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.E_LINE_PRICE_INFO); Element
       * eleLineOverrallTotals = XMLUtil.getChildElement(eleCurrentElement,
       * KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
       * 
       * String strLineTotal1 = eleLinePriceInfo.getAttribute(KohlsPOCConstant.E_LINE_TOTAL); String
       * strLineTotal2 = eleLineOverrallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL);
       * strLineTotal2 = strnegative.concat(strLineTotal2); strLineTotal1 =
       * strnegative.concat(strLineTotal1);
       * eleLinePriceInfo.setAttribute(KohlsPOCConstant.E_LINE_TOTAL, strLineTotal1);
       * eleLineOverrallTotals.setAttribute(KohlsPOCConstant.E_LINE_TOTAL, strLineTotal2);
       * 
       * // Removing PLUResponseClob Object -- Begin
       * 
       * Element eleCurrentElementExtn = XMLUtil.getChildElement(eleCurrentElement,
       * KohlsPOCConstant.A_EXTN);
       * eleCurrentElementExtn.setAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE,
       * KohlsPOCConstant.BLANK);
       * 
       * // Removing PLUResponseClob Object -- End
       * 
       * // Fetching ExtnPLURetailAmt from Sale OrderLine Extn String strSalePLURetailAmt =
       * eleCurrentElementExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT); if
       * (logger.isDebugEnabled()) { logger .debug( "Current sale element is::" +
       * XMLUtil.getElementXMLString(eleCurrentElement)); logger.debug("Current PrimeLine No is:::"
       * + strOrigPrimeLineNo); } for (int j = 0; j < ndlPSASaleOrder.getLength(); j++) { Element
       * eleCurrentPSAElement = (Element) ndlPSASaleOrder.item(j);
       * 
       * Element eleCurrentPSAElementExtn = XMLUtil.getChildElement(eleCurrentPSAElement,
       * KohlsPOCConstant.A_EXTN);
       * 
       * String strPSAPrimeLineNo =
       * eleCurrentPSAElement.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
       * 
       * // Fetching ExtnPLURetailAmt from PSA OrderLine Extn
       * 
       * String strPSAPLURetailAmt =
       * eleCurrentPSAElementExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT); if
       * (logger.isDebugEnabled()) { logger.debug( "Current PSA element is::" +
       * XMLUtil.getElementXMLString(eleCurrentPSAElement)); logger .debug(
       * "Current PrimeLine No of PSA element is:::" + strPSAPrimeLineNo); } if
       * (strOrigPrimeLineNo.equals(strPSAPrimeLineNo)) { // Fix for 3557 -- Begin -- 8/25/16 logger
       * .debug( "Inside Matching PrimeLine Number block ; now checking PLURetailAmounts"); if
       * ((strSalePLURetailAmt.equalsIgnoreCase("0.00") &&
       * !strSalePLURetailAmt.equalsIgnoreCase(strPSAPLURetailAmt) &&
       * !YFCCommon.isStringVoid(strPSAPLURetailAmt))) {
       * eleCurrentElementExtn.setAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT,
       * strPSAPLURetailAmt); } // Fix for 3557 -- End -- 8/25/16
       * 
       * inputDoc.adoptNode(eleCurrentElement); XMLUtil.appendChild(eleTempParent,
       * eleCurrentElement); XMLUtil.appendChild(eleTempParent, eleCurrentPSAElement); } else {
       * logger.debug("Inside else block: Shouldn't be here"); } } }
       */

      // inputDoc = calculateTotalOrderLines(inputDoc);
      inputDoc = getNodeListToRemove(inputDoc);
      // inputDoc = setExternalPaymentAndRemoveKCS(inputDoc);
      // inputDoc = removeCollectionOrChargeTranDetails(env, inputDoc);

    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      logger.endTimer("KohlsCreateInputForPA.updateSales");
    }
    return inputDoc;
  }

  /**
   * @param env
   * @param docFinal
   * @param strOrderHeaderKey
   * @return
   * @throws Exception ComplexQuery Input for calling getOrderInvoiceList
   *         <OrderInvoice OrderHeaderKey="1116112403585922866901" > <ComplexQuery Operator="AND">
   *         <And> <Or> <Exp Name="InvoiceType" Value="CREDIT_MEMO" InvoiceTypeQryType="EQ"/> <Exp
   *         Name="InvoiceType" Value="DEBIT_MEMO" InvoiceTypeQryType="EQ"/> </Or> </And>
   *         </ComplexQuery> </OrderInvoice>
   */
  public void consolidateInvoiceCollectionWithHeaderDetails(YFSEnvironment env, Document docFinal,
      String strOrderHeaderKey) throws Exception {

    logger.beginTimer("KohlsCreateInputForPA.consolidateInvoiceCollectionWithHeaderDetails");

    try {
      logger.debug(
          "OrderHeaderKey in consolidateCollectionDetails method input is : " + strOrderHeaderKey);
      if (!YFCCommon.isVoid(strOrderHeaderKey) && !YFCCommon.isVoid(docFinal)) {

        Element eleFinal = docFinal.getDocumentElement();
        Element eleInvoiceHeaderOrg = XMLUtil.getChildElement(eleFinal, "InvoiceHeader");
        Element eleCollectionDetailsOrg =
            (Element) XMLUtil.getElementsByTagName(eleFinal, "CollectionDetails").get(0);

        if (logger.isDebugEnabled())
          logger.debug("The eleCollectionDetailsOrg Output : "
              + XMLUtil.getElementXMLString(eleCollectionDetailsOrg));
        // Create input for getOrderInvoiceList
        Document inGetOrderInvoiceList =
            XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_INP_CQ);
        inGetOrderInvoiceList.getDocumentElement().setAttribute("OrderHeaderKey",
            strOrderHeaderKey);

        // Calling getOrderInvoiceList API to get all the Invoices
        // associated to the current PSA Order
        Document getOrderInvoiceListTemplate =
            XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_OUT_TEMP);
        Document outGetOrderInvoiceList = KOHLSBaseApi.invokeAPI(env, getOrderInvoiceListTemplate,
            "getOrderInvoiceList", inGetOrderInvoiceList);

        if (logger.isDebugEnabled())
          logger.debug("The outGetOrderInvoiceList Output : "
              + XMLUtil.getXMLString(outGetOrderInvoiceList));

        Double conAmountCollected = KohlsPOCConstant.ZERO_DBL;
        Double conLineSubTotal = KohlsPOCConstant.ZERO_DBL;
        Double conTotalAmount = KohlsPOCConstant.ZERO_DBL;
        Double conTotalTax = KohlsPOCConstant.ZERO_DBL;
        Double conTotalDiscount = KohlsPOCConstant.ZERO_DBL;
        DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
        // Calling getOrderInvoiceDetails for each Invoice and getting
        // the associated, Payment Collection details and Invoice header
        // details.
        NodeList nlOrderInvoiceList = outGetOrderInvoiceList.getElementsByTagName("OrderInvoice");

        Document docCollectionDetails = XMLUtil.createDocument("CollectionDetails");
        if (nlOrderInvoiceList.getLength() > 0) {
          for (int i = 0; i < nlOrderInvoiceList.getLength(); i++) {
            Element eleOrderInvoice = (Element) nlOrderInvoiceList.item(i);
            conAmountCollected = conAmountCollected
                + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "AmountCollected"));
            conTotalAmount = conTotalAmount
                + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalAmount"));
            conTotalTax =
                conTotalTax + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalTax"));

            conLineSubTotal = conLineSubTotal
                + (Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalAmount"))
                    - Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalTax")));

            String srtOrderInvoiceKey = XMLUtil.getAttribute(eleOrderInvoice, "OrderInvoiceKey");
            Document getOrderInvoiceDetailsInp = XMLUtil.createDocument("GetOrderInvoiceDetails");
            getOrderInvoiceDetailsInp.getDocumentElement().setAttribute("InvoiceKey",
                srtOrderInvoiceKey);

            // Document docGetOrderInvoiceDetailsOutTemplate =
            // XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT_TEMP);
            Document docGetOrderInvDetailsOutput =
                KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT,
                    KohlsPOCConstant.GET_INVOICE_ORDER_DET, getOrderInvoiceDetailsInp);
            /*
             * KohlsCommonUtil.invokeAPI(env, docGetOrderInvoiceDetailsOutTemplate, KohlsPOCConstant
             * .GET_INVOICE_ORDER_DET,getOrderInvoiceDetailsInp);
             */

            if (logger.isDebugEnabled())
              logger.debug("docGetOrderInvDetailsOutput output value is : "
                  + XMLUtil.getXMLString(docGetOrderInvDetailsOutput));
            Element eleInvoiceHeader = XMLUtil
                .getChildElement(docGetOrderInvDetailsOutput.getDocumentElement(), "InvoiceHeader");
            conTotalDiscount = conTotalDiscount
                + Double.parseDouble(XMLUtil.getAttribute(eleInvoiceHeader, "TotalDiscount"));
            NodeList nlCollectionDetailsList =
                docGetOrderInvDetailsOutput.getElementsByTagName("CollectionDetail");
            if (nlCollectionDetailsList.getLength() > 0) {
              for (int j = 0; j < nlCollectionDetailsList.getLength(); j++) {
                Element eleCollectionDetail = (Element) nlCollectionDetailsList.item(j);
                Element elePaymentMethod =
                    XMLUtil.getChildElement(eleCollectionDetail, "PaymentMethod");
                if (!YFCCommon.isVoid(elePaymentMethod)) {
                  // Element elePaymentMethod = (Element)
                  // eleCollectionDetail.getElementsByTagName("PaymentMethod"
                  // ).item( 0 );
                  // elePaymentMethod.setAttribute("TotalCharged",
                  // eleCollectionDetail.getAttribute("AmountCollected"));
                  XMLUtil.setAttribute(elePaymentMethod, "TotalCharged",
                      XMLUtil.getAttribute(eleCollectionDetail, "AmountCollected"));
                  // Fix for PR-528, PR-558 - Start
                  XMLUtil.importElement(docCollectionDetails.getDocumentElement(),
                      eleCollectionDetail);
                  // Fix for PR-528, PR-558 - End
                }
              }
            }
          }
        }
        // Fix for PR-439 - Start
        int iTotalLines = XMLUtil.getElementsCountByTagName(
            docCollectionDetails.getDocumentElement(), "CollectionDetail");
        XMLUtil.setAttribute(docCollectionDetails.getDocumentElement(), "TotalLines",
            String.valueOf(iTotalLines));
        // Fix for PR-439 - End
        eleInvoiceHeaderOrg.setAttribute("AmountCollected", twoDForm.format(conAmountCollected));
        eleInvoiceHeaderOrg.setAttribute("LineSubTotal", twoDForm.format(conLineSubTotal));
        eleInvoiceHeaderOrg.setAttribute("TotalAmount", twoDForm.format(conTotalAmount));
        eleInvoiceHeaderOrg.setAttribute("TotalTax", twoDForm.format(conTotalTax));
        eleInvoiceHeaderOrg.setAttribute("TotalDiscount", twoDForm.format(conTotalDiscount));
        // Updating the OverallTotals on the order
        Element eleOverallTotals =
            (Element) XPathUtil.getNode(docFinal, KohlsPOCConstant.X_INV_OVERALL_TOTALS);
        if (!YFCCommon.isVoid(eleOverallTotals)) {
          eleOverallTotals.setAttribute("GrandTax", twoDForm.format(Math.abs(conTotalTax)));
          eleOverallTotals.setAttribute("GrandTotal", twoDForm.format(Math.abs(conTotalAmount)));
          eleOverallTotals.setAttribute("LineSubTotal", twoDForm.format(Math.abs(conLineSubTotal)));
          eleOverallTotals.setAttribute("GrandCharges", "0.00");
        }
        if (logger.isDebugEnabled()) {
          logger.debug("Consolidated CollectionDetails element : "
              + XMLUtil.getXMLString(docCollectionDetails));
        }
        if (!YFCCommon.isVoid(docCollectionDetails)) {
          if (logger.isDebugEnabled()) {
            logger.debug(
                "The inDoc inside removing loop is : " + XMLUtil.getElementXMLString(eleFinal));
          }
          XMLUtil.removeChild(eleInvoiceHeaderOrg, eleCollectionDetailsOrg);
          XMLUtil.importElement(eleInvoiceHeaderOrg, docCollectionDetails.getDocumentElement());
          if (logger.isDebugEnabled()) {
            logger.debug("The inDoc inside after removing and attaching loop is : "
                + XMLUtil.getElementXMLString(eleFinal));
          }
          logger.debug("Successfully consolidated Payment Collection details");
        }

      } else {
        YFSException eYFS = new YFSException("OrderHeaderKey is Null", "OrderHeaderKey is Null",
            "OrderHeaderKey is Null");
        throw eYFS;
      }
    } catch (Exception e) {
      logger.verbose(e);
      throw e;
    } finally {
      logger.endTimer("KohlsCreateInputForPA.consolidateInvoiceCollectionWithHeaderDetails");
    }
  }

  public Document AppendPromotionAndTaxes(Document docOrigSale, Document docPSA) {
    logger.beginTimer("KohlsCreateInputForPA.AppendPromotionAndTaxes");
    try {

      NodeList ndlSalesPromotion =
          XPathUtil.getNodeList(docOrigSale, KohlsPOCConstant.X_KOHLS_SALES_PROMOTION);

      // Updating type code for Sale Promotions

      for (int a = 0; a < ndlSalesPromotion.getLength(); a++) {
        Element eleCurrentPromotion = (Element) ndlSalesPromotion.item(a);
        eleCurrentPromotion.setAttribute(KohlsPOCConstant.A_TYPE, KohlsPOCConstant.SALE);
      }

      Element elePSAParentPromotion =
          (Element) XPathUtil.getNode(docPSA, KohlsPOCConstant.X_INV_PROMOTIONS);

      NodeList ndlPSAPromotion = XPathUtil.getNodeList(docPSA, KohlsPOCConstant.X_INV_PROMOTION);

      // Updating type code for PSA Promotions

      for (int b = 0; b < ndlPSAPromotion.getLength(); b++) {

        // defect 3403 changes start
        String getPromotion = null;
        String IsPromotionApplied = null;
        // defect 3403 changes End
        Element eleCurrentPSAPromotion = (Element) ndlPSAPromotion.item(b);
        eleCurrentPSAPromotion.setAttribute(KohlsPOCConstant.A_TYPE, "PA");

        // defect 3403 changes start
        // getPromotion.getAttribute("PromotionType");
        // IsPromotionApplied.getAttribute("PromotionApplied");
        getPromotion = (String) eleCurrentPSAPromotion.getAttribute("PromotionType");
        IsPromotionApplied = (String) eleCurrentPSAPromotion.getAttribute("PromotionApplied");

        if (getPromotion.equalsIgnoreCase("KOHLS_CASH_EARNED")
            && IsPromotionApplied.equalsIgnoreCase("N")) {
          // XMLUtil.removeChild(elePSAParentPromotion,ndlPSAPromotion);
          XMLUtil.removeChild(elePSAParentPromotion, eleCurrentPSAPromotion);
        } else {
          eleCurrentPSAPromotion.setAttribute("PromotionApplied", "Y");
        }
        // defect 3403 changes End
      }

      for (int a = 0; a < ndlSalesPromotion.getLength(); a++) {
        XMLUtil.importElement(elePSAParentPromotion, (Element) ndlSalesPromotion.item(a));
      }

      Element eleOrigSaleOrder =
          (Element) XPathUtil.getNode(docOrigSale, KohlsPOCConstant.X_KOHLS_SALES_ORDER);

      Element eleOrigSaleOrderExtn =
          XMLUtil.getChildElement(eleOrigSaleOrder, KohlsPOCConstant.A_EXTN);

      String strExtnTaxDetails =
          eleOrigSaleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
      Element eleTaxDetails = null;
      if (!YFCCommon.isVoid(strExtnTaxDetails)) {
        Document docExtnTaxDetails = XMLUtil.getDocument(strExtnTaxDetails);
        eleOrigSaleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
            KohlsPOCConstant.BLANK);
        eleTaxDetails = docExtnTaxDetails.getDocumentElement();
        XMLUtil.importElement(eleOrigSaleOrder, eleTaxDetails);
      }

      NodeList ndlTaxDetail =
          XPathUtil.getNodeList(eleOrigSaleOrder, KohlsPOCConstant.X_KOHLS_SALES_TAX_DETAIL);

      Element elePSATaxDetailList =
          (Element) XPathUtil.getNode(docPSA, KohlsPOCConstant.X_INV_TAX_DETAIL_LIST);

      // Updating Tax Indicator for Sales Tax

      if (!(YFCCommon.isVoid(ndlTaxDetail))) {
        for (int c = 0; c < ndlTaxDetail.getLength(); c++) {
          Element eleCurrentTax = (Element) ndlTaxDetail.item(c);
          String strTaxInd = eleCurrentTax.getAttribute(KohlsPOCConstant.A_TAX_INDICATOR);
          strTaxInd = UpdateTaxIndType(strTaxInd);
          eleCurrentTax.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, strTaxInd);
          eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE, KohlsPOCConstant.SALE);
        }

      }

      NodeList ndlPSATaxDetail = XPathUtil.getNodeList(docPSA, KohlsPOCConstant.X_INV_TAX_DETAIL);

      for (int d = 0; d < ndlPSATaxDetail.getLength(); d++) {
        Element eleCurrentTax = (Element) ndlPSATaxDetail.item(d);
        eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE, "PA");
      }

      for (int c = 0; c < ndlTaxDetail.getLength(); c++) {
        XMLUtil.importElement(elePSATaxDetailList, (Element) ndlTaxDetail.item(c));
      }

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsCreateInputForPA.AppendPromotionAndTaxes");
    }
    return docPSA;

  }

  public String UpdateTaxIndType(String strTaxInd) {
    logger.beginTimer("KohlsCreateInputForPA.UpdateTaxIndType");
    if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_1)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_A;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_2)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_B;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_3)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_C;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_4)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_D;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_5)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_E;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_6)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_F;
    } else {
      strTaxInd = KohlsPOCConstant.CONST_HASH;
    }
    logger.endTimer("KohlsCreateInputForPA.UpdateTaxIndType");
    return strTaxInd;
  }

  public Document calculateTotalOrderLines(Document docFinalXMLtoTibco) {
    logger.beginTimer("KohlsCreateInputForPA.calculateTotalOrderLines");
    String strExtnSimplePromoPrice = null;
    Element eleOrderLineExtn = null;
    Element eleOrderLine = null;
    Element eleLinePriceInfo = null;
    String strUnitPrice = null;
    try {
      logger.beginTimer("--- calculateTotalOrderLines ---");
      NodeList ndlOrderLine = ((NodeList) XPathUtil
          .getNodeList(docFinalXMLtoTibco.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINE));

      Integer totalNumberCount = ndlOrderLine.getLength();

      String totalNumber = totalNumberCount.toString();

      Element eleOrderLines = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
          KohlsPOCConstant.X_INV_ORDERLINES);

      eleOrderLines.setAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS, totalNumber);

      if (!(YFCCommon.isVoid(ndlOrderLine))) {
        for (int i = 0; i < totalNumberCount; i++) {
          eleOrderLine = (Element) ndlOrderLine.item(i);
          // Code changes for Sale POS and PSA POC defect 3374 --
          // Begin -- 9/8/16

          eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.A_EXTN);

          strExtnSimplePromoPrice = eleOrderLineExtn.getAttribute("ExtnSimplePromoPrice");

          if (YFCCommon.isStringVoid(strExtnSimplePromoPrice)) {
            logger.debug(
                "Entering code block for Empty ExtnSimplePromoPrice : fetching and Appending");
            eleLinePriceInfo = XMLUtil.getChildElement(eleOrderLine, "LinePriceInfo");
            strUnitPrice = eleLinePriceInfo.getAttribute("UnitPrice");
            eleOrderLineExtn.setAttribute("ExtnSimplePromoPrice", strUnitPrice);

          }
          // Code changes for Sale POS and PSA POC defect 3374 -- End
          // -- 9/8/16

          Integer count = i + 1;
          String strCurrValue = count.toString();
          eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_LINE_SEQ_NO, strCurrValue);
          if (count % 2 == 0) {
            eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE, "PA");
          } else {
            eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE, "Return");
          }

        }
        // Fix for Original Terminal ID -- Begin -- 4/8/16

        logger.debug("Entering code block for Sale Terminal Id fix ");
        // Element eleTransAudit = (Element) XPathUtil
        // .getNodeList(docFinalXMLtoTibco.getDocumentElement(),
        // "/InvoiceDetail/InvoiceHeader/TransactionAudits/TransactionAudit")
        // .item(0);

        Element eleTransAudit = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/Order");

        if (!YFCCommon.isVoid(eleTransAudit)) {

          // String strTransNumber = eleTransAudit
          // .getAttribute("TransactionNumber");

          String strOrderNumber = eleTransAudit.getAttribute("OrderNo");

          String strSubstring = strOrderNumber.substring(11, 13);
          logger.debug("Sales Terminal Id is ::" + strSubstring);
          Element eleInvExtn = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
              "/InvoiceDetail/InvoiceHeader/Extn");
          eleInvExtn.setAttribute("ExtnTerminalID", strSubstring);

        }

        // Fix for Original Terminal ID -- End -- 4/8/16

        if (!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
          Element eleOrder = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
              "/InvoiceDetail/InvoiceHeader/Order");

          eleOrder.setAttribute("SellerOrganizationCode", strPSASellerOrgCode);
        }

      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsCreateInputForPA.calculateTotalOrderLines");
    }
    return docFinalXMLtoTibco;
  }

  public Document getNodeListToRemove(Document docInput) {
    logger.beginTimer("KohlsCreateInputForPA.getNodeListToRemove");
    try {
      logger.beginTimer("---Inside getNodeListToRemove ---");
      if (logger.isDebugEnabled()) {
        logger.debug("Input to getNodeListToRemove is ::" + XMLUtil.getXMLString(docInput));
      }
      /***************************/
      // Added for PSA Credit Card -- To be removed soon-- Start
      // docInput = mockCreditDetailsFromSale(docInput);
      // Added for PSA Credit Card -- To be removed soon-- End
      /****************************/

      if (logger.isDebugEnabled())
        logger.debug(
            "API output of mockCreditDetailsFromSale is ::" + XMLUtil.getXMLString(docInput));

      // Method Call to remove Empty CreditCardElement
      docInput =
          removeCreditCardEmptyElement(docInput, KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
      // Method Call to remove Duplicate Payment Elements
      docInput = removeDuplicatePayments(docInput);

      // Method Call to remove Empty CreditCardElement
      // docInput = removeCreditCardEmptyElement(docInput, KohlsXMLLiterals.E_COLLECITON_DETAIL);

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsCreateInputForPA.getNodeListToRemove");
    }
    return docInput;
  }

  public Document removeCreditCardEmptyElement(Document docInput, String str) {
    logger.beginTimer("KohlsCreateInputForPA.removeCreditCardEmptyElement");
    String strAuthTime = null;
    String strTranRequestTime = null;
    NodeList ndlistInput = null;
    try {
      if (str.equalsIgnoreCase(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS)) {
        ndlistInput = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);
        logger.debug("Fetching nodelist of ChargeTransactionDetail");
      } else {
        ndlistInput = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_COLLECTION_DETAIL);
        logger.debug("Fetching nodelist of CollectionDetails");
      }

      logger.beginTimer("removeCreditCardEmptyElement");
      // Iterate over NodeList of ChargeTransactionDetails
      for (int i = 0; i < ndlistInput.getLength(); i++) {
        // Fetch Current ChargeTransactionDetail element
        Element eleCurrentElement = (Element) ndlistInput.item(i);

        Element eleCreditCardParent =
            (Element) XPathUtil.getNode(eleCurrentElement, KohlsPOCConstant.X_CREDIT_CARD_TRANS);

        if (logger.isDebugEnabled())
          logger.debug("Current ChargeTransactionElement is::"
              + XMLUtil.getElementXMLString(eleCurrentElement));

        if (!YFCCommon.isVoid(eleCreditCardParent)) {

          if (logger.isDebugEnabled())
            logger.debug("Current CreditCard Transactions element is::"
                + XMLUtil.getElementXMLString(eleCreditCardParent));
          int countChild =
              eleCreditCardParent.getElementsByTagName("CreditCardTransaction").getLength();
          logger.debug("CreditCardTransaction nodelist count is :::" + countChild);

          if (countChild == 0) {
            logger
                .debug("No CreditCardTransaction element exists. Removing CreditCardTransactions");
            XMLUtil.removeChild(eleCurrentElement, eleCreditCardParent);
          } else {
            // [START] Defect: 4176 -- Commented the old and added
            // new line
            // Element eleCreditCard = (Element)
            // XPathUtil.getNode(eleCurrentElement,
            // KohlsPOCConstant.X_CREDIT_CARD_TRAN);
            Element eleCreditCard =
                (Element) eleCurrentElement.getElementsByTagName("CreditCardTransaction").item(0);
            // [END] Defect: 4176
            strAuthTime = eleCreditCard.getAttribute("AuthTime");
            strTranRequestTime = eleCreditCard.getAttribute("TranRequestTime");
            logger.debug("AuthTime is " + strAuthTime);
            logger.debug("TranRequestTime is " + strTranRequestTime);
            if (YFCCommon.isStringVoid(strAuthTime) || YFCCommon.isStringVoid(strTranRequestTime)) {
              XMLUtil.removeChild(eleCurrentElement, eleCreditCardParent);
            }

          }

        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    finally {
      logger.endTimer("KohlsCreateInputForPA.removeCreditCardEmptyElement");
    }
    return docInput;
  }

  public Document removeDuplicatePayments(Document docInput) {
    logger.beginTimer("KohlsCreateInputForPA.removeDuplicatePayments");
    String strPaymentKey = null;
    try {
      logger.beginTimer("removeDuplicatePayments");
      NodeList ndlChargeTransDetails =
          XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);

      // Iterate over ChargeTransactionDetails NodeList
      for (int i = 0; i < ndlChargeTransDetails.getLength(); i++) {
        // Fetch Current ChargeTransactionDetail Element
        Element eleCurrent = (Element) ndlChargeTransDetails.item(i);

        if (logger.isDebugEnabled())
          logger.debug(
              "Current ChargeTransactionElement ::" + XMLUtil.getElementXMLString(eleCurrent));
        Element elePaymentMethod =
            XMLUtil.getChildElement(eleCurrent, KohlsPOCConstant.E_PAYMENT_METHOD);
        if (!(YFCCommon.isVoid(elePaymentMethod))) {
          strPaymentKey = elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
          logger.debug("Payment Key is" + strPaymentKey);
        }
        if (!YFCCommon.isVoid(strPaymentKey)) {
          for (int j = i + 1; j < ndlChargeTransDetails.getLength(); j++) {
            Element eleNextChargeTrans = (Element) ndlChargeTransDetails.item(j);

            if (logger.isDebugEnabled())
              logger.debug("Comparing with the following chargeTransactionElement"
                  + XMLUtil.getElementXMLString(eleNextChargeTrans));
            Element eleNextPaymentMethod =
                XMLUtil.getChildElement(eleNextChargeTrans, KohlsPOCConstant.E_PAYMENT_METHOD);
            if (!(YFCCommon.isVoid(eleNextPaymentMethod))) {
              String strNextPaymentKey =
                  eleNextPaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);

              if (!(YFCCommon.isVoid(strNextPaymentKey))
                  && strPaymentKey.equals(strNextPaymentKey)) {
                logger.debug("Removing duplicate child");
                XMLUtil.removeChild(eleNextChargeTrans, eleNextPaymentMethod);
              }
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsCreateInputForPA.removeDuplicatePayments");
    }
    return docInput;

  }

  public Document removeCollectionOrChargeTranDetails(YFSEnvironment env, Document inputDoc) {
    logger.beginTimer("KohlsCreateInputForPA.removeCollectionOrChargeTranDetails");
    try {
      logger.debug("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails - Start");
      Element eleCollectionDetails = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_DETAILS)
          .item(0);
      Element eleInvoiceHeader = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER)
          .item(0);
      Element eleInvChargeTrans = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAILS)
          .item(0);
      Element eleInvOrder = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER).item(0);
      NodeList nlCollectionDetailsList = eleInvoiceHeader.getElementsByTagName("CollectionDetail");

      String strTotalNo = KohlsPOCConstant.ZERO;
      strTotalNo = eleCollectionDetails.getAttribute("TotalLines");
      if (logger.isDebugEnabled()) {
        logger.debug(
            "nlCollectionDetailsList.getLength() value : " + nlCollectionDetailsList.getLength()
                + "  " + XMLUtil.getElementXMLString(eleCollectionDetails));
      }
      if (nlCollectionDetailsList.getLength() == 0) {
        XMLUtil.removeChild(eleInvoiceHeader, eleCollectionDetails);
      } else {
        XMLUtil.removeChild(eleInvOrder, eleInvChargeTrans);
        XMLUtil.createChild(eleInvOrder, "ChargeTransactionDetails");
      }

    } catch (Exception e) {
      logger.debug(e.getMessage());
    }
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails Output"
          + XMLUtil.getXMLString(inputDoc));
    }

    logger.beginTimer("KohlsCreateInputForPA.removeCollectionOrChargeTranDetails");

    return inputDoc;
  }

  public Document setExternalPaymentAndRemoveKCS(Document inputDoc) {
    logger.beginTimer("KohlsCreateInputForPA.setExternalPaymentAndRemoveKCS");
    String strCheck = null;
    String strCollectionDate = null;
    boolean bKCSMaximized = false;
    try {
      Element eleInvoiceHeader = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER)
          .item(0);
      NodeList ndlCollectionDetail =
          XPathUtil.getNodeList(inputDoc, KohlsPOCConstant.X_INV_COLLECTION_DETAIL);

      Element eleCollectionDetails =
          (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_COLLECTION_DETAILS);

      for (int i = 0; i < ndlCollectionDetail.getLength(); i++) {
        Element eleCurrentElement = (Element) ndlCollectionDetail.item(i);
        if (!YFCCommon.isVoid(eleCurrentElement)) {
          if (logger.isDebugEnabled()) {
            logger.debug("Current CollectionDetail Element ::"
                + XMLUtil.getElementXMLString(eleCurrentElement));
          }
          // New fix for CreditCardTransaction after Tendering Changes
          // -- Begin -- 8/8/16

          strCollectionDate = eleCurrentElement.getAttribute("CollectionDate");

          logger.debug("Fetching ExecutionDate to be set ::" + strCollectionDate);

          if (!YFCCommon.isStringVoid(strCollectionDate)) {

            logger.debug("ExecutionDate exists , Explicitly setting it into CollectionDetails"
                + strCollectionDate);
            eleCurrentElement.setAttribute("ExecutionDate", strCollectionDate);
          }

          // New fix for CreditCardTransaction after Tendering Changes
          // -- End -- 8/8/16

          Element elePaymentMethod =
              (Element) XPathUtil.getNode(eleCurrentElement, "PaymentMethod");
          if (!YFCCommon.isVoid(elePaymentMethod)) {
            if (logger.isDebugEnabled()) {
              logger.debug("Current Payment Method Element ::"
                  + XMLUtil.getElementXMLString(elePaymentMethod));
            }
            strCheck = elePaymentMethod.getAttribute("PaymentType");
            logger.debug("Payment Type is ::" + strCheck);
            if (strCheck.equalsIgnoreCase("CREDIT_CARD") || strCheck.equalsIgnoreCase("DEBIT_CARD")
                || strCheck.equalsIgnoreCase("KOHLS_CHARGE_CARD")) {
              logger.debug("Inside External Payment block");
              elePaymentMethod.setAttribute("IsExternalPayment", "P");

            }
            if ("KOHLS_CASH".equalsIgnoreCase(strCheck)) {
              XMLUtil.removeChild(eleCollectionDetails, eleCurrentElement);
              String CollDetsize = eleCollectionDetails.getAttribute("TotalLines");
              Integer int1 = Integer.valueOf(CollDetsize);
              int1--;
              eleCollectionDetails.setAttribute("TotalLines", int1.toString());
              // Fix for PR-439 - Start
              bKCSMaximized = true;
              // Fix for PR-439 - End
            }

          }
        }
      }
      /*
       * if (bKCSMaximized) { XMLUtil.removeChild(eleInvoiceHeader, eleCollectionDetails); //
       * inputDoc.getDocumentElement().removeChild("CollectionDetails"); Element
       * newEleCollectionDetails = XMLUtil.createChild(eleInvoiceHeader, "CollectionDetails");
       * newEleCollectionDetails.setAttribute("TotalLines", "0"); }
       */
    } catch (Exception e) {
      logger.verbose(e);
    }
    logger.endTimer("KohlsCreateInputForPA.setExternalPaymentAndRemoveKCS");
    return inputDoc;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param orderDetail
   * @return
   * @throws Exception
   * 
   *         This method adds the "TaxDetailsList" element on the order.
   */
  private Document MapTaxIndicators(Document orderDetail) throws Exception {
    logger.beginTimer("KohlsCreateInputForPA.MapTaxIndicators");
    Document docTaxDetailsList = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element eleTaxDetailsRoot = docTaxDetailsList.getDocumentElement();

    HashMap<Double, String> mapTaxDetails_Return = new HashMap<Double, String>();
    HashMap<Double, String> mapTaxDetails_Sale = new HashMap<Double, String>();

    DecimalFormat df = new DecimalFormat("#0.00");

    String sTaxIndicatorRepo_Return = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String sTaxIndicatorRepo_Sale = "123456789";

    Element eleOrderExtn =
        (Element) XPathUtil.getNode(orderDetail, "/InvoiceDetail/InvoiceHeader/Order/Extn");

    NodeList nlOrderLine = orderDetail.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        double dUnitPrice = 0.00D;
        double dTaxPercent = 0.00D;
        double dTax = 0.00D;
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        String sType = eleOrderLine.getAttribute("Type");
        Element eleCustomAttributes =
            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
        if (YFCCommon.isVoid(eleCustomAttributes)) {
          continue;
        }
        Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
        String sExtnTaxbleAmount =
            eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);

        NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
        for (int j = 0; j < nlLineTax.getLength(); j++) {
          Element eleLineTax = (Element) nlLineTax.item(j);
          String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
          String sTaxPercent = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
          Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
          if (!YFCCommon.isVoid(eleLineTaxExtn)) {
            dTax = dTax + Double.parseDouble(sTax);
          }
          if (!YFCCommon.isVoid(sTaxPercent)) {
            dTaxPercent = dTaxPercent + Double.parseDouble(sTaxPercent);
            if("Sale".equals(sType)){
              dTaxPercent = dTaxPercent / 100;
            }
          }
        }
        if (!YFCCommon.isVoid(sExtnTaxbleAmount)) {
          dUnitPrice = dUnitPrice + Double.parseDouble(sExtnTaxbleAmount);
        }
        // setting map for Sale
        if ("Return".equals(sType)) {
          if (mapTaxDetails_Return.containsKey(dTaxPercent)) {
            String[] sTemp = mapTaxDetails_Return.get(dTaxPercent).split("_");
            double dTax_Temp = Double.parseDouble(sTemp[0]);
            double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
            String sTaxIndicator = sTemp[2];
            mapTaxDetails_Return.remove(dTaxPercent);
            mapTaxDetails_Return.put(dTaxPercent, df.format(dTax_Temp - dTax) + "_"
                + df.format(dTaxableAmount_Temp - dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          } else {
            String sTaxIndicator;
            sTaxIndicator = String.valueOf(sTaxIndicatorRepo_Return.charAt(0));
            sTaxIndicatorRepo_Return = sTaxIndicatorRepo_Return.substring(1);
            mapTaxDetails_Return.put(dTaxPercent,
                df.format(0-dTax) + "_" + df.format(0-dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          }
        } else {
          if (mapTaxDetails_Sale.containsKey(dTaxPercent)) {
            String[] sTemp = mapTaxDetails_Sale.get(dTaxPercent).split("_");
            double dTax_Temp = Double.parseDouble(sTemp[0]);
            double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
            String sTaxIndicator = sTemp[2];
            mapTaxDetails_Sale.remove(dTaxPercent);
            mapTaxDetails_Sale.put(dTaxPercent, df.format(dTax_Temp + dTax) + "_"
                + df.format(dTaxableAmount_Temp + dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          } else {
            String sTaxIndicator;
            sTaxIndicator = "T" + String.valueOf(sTaxIndicatorRepo_Sale.charAt(0));
            sTaxIndicatorRepo_Sale = sTaxIndicatorRepo_Sale.substring(1);
            mapTaxDetails_Sale.put(dTaxPercent,
                df.format(dTax) + "_" + df.format(dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          }
        }

      }
    }

    // Forming Tax details for Sale
    if (mapTaxDetails_Sale.size() > 0) {
      for (Double dTaxPercent : mapTaxDetails_Sale.keySet()) {
        Element eleTaxDetail =
            XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE, df.format(dTaxPercent));
        String sTemp[] = mapTaxDetails_Sale.get(dTaxPercent).split("_");
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
      }
    }
    
    // Forming Tax details for Return
    if (mapTaxDetails_Return.size() > 0) {
      for (Double dTaxPercent : mapTaxDetails_Return.keySet()) {
        Element eleTaxDetail =
            XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE, df.format(dTaxPercent));
        String sTemp[] = mapTaxDetails_Return.get(dTaxPercent).split("_");
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
      }
    }

    eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
        XMLUtil.getElementXMLString(eleTaxDetailsRoot));
    Element eleOrder =
        (Element) XPathUtil.getNode(orderDetail, "/InvoiceDetail/InvoiceHeader/Order");
    Element eleTaxDetailList =
        XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_TAX_DETAIL_LIST);
    if (!YFCCommon.isVoid(eleTaxDetailList)) {
      eleOrder.removeChild(eleTaxDetailList);
    }
    Element eleTaxDetailsRoot_Temp = (Element) orderDetail.importNode(eleTaxDetailsRoot, true);
    eleOrder.appendChild(eleTaxDetailsRoot_Temp);
    if (logger.isDebugEnabled()) {
      logger.debug("End of taxDetailsList logicccc" + XMLUtil.getXMLString(orderDetail));
    }
    logger.endTimer("KohlsCreateInputForPA.MapTaxIndicators");
    return orderDetail;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param docInvoiceDetails
   * @return
   * 
   *         This method removes the promotion from the order.
   */
  private Document removeOrderPromotions(Document docInvoiceDetails) {
    logger.beginTimer("KohlsCreateInputForPA.removeOrderPromotions");
    Element elePromotions = XMLUtil.getChildElement(docInvoiceDetails.getDocumentElement(),
        KohlsPOCConstant.E_PROMOTIONS);
    if (!YFCCommon.isVoid(elePromotions)) {
      NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        if ("KOHLS_CASH_UNEARNED".equalsIgnoreCase(sPromotionType)
            || "KOHLS_CASH_REISSUE".equalsIgnoreCase(sPromotionType)) {
          continue;
        }
        elePromotions.removeChild(elePromotion);
      }
    }
    logger.endTimer("KohlsCreateInputForPA.removeOrderPromotions");
    return docInvoiceDetails;
  }
}
