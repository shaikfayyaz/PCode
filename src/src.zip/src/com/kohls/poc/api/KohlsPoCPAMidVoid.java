package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCPAMidVoid {

	String strNoUPCMsg="No UPC Found";
	
	private static final YFCLogCategory loggerForPAMidvoid = YFCLogCategory
			.instance(KohlsPoCPAMidVoid.class.getName());

/*PA DataCollect is triggered on on_success of change order.
PostVoid for EE and Sales is triggered on on_cancel of change order.
This code should be invoked after conditional checks of PA mid void
at on_cancel of change order */
	

	/**
	 * This method prepares a xml document to be send to Tibco when a mid void 
	 * is performed on a PA transaction
	 * Author Kohls
	 * @param env
	 * @param InputDoc
	 * @return InputDoc
	 * @exception Exception
	 * 
	 */
		
public Document PAMidVoid(YFSEnvironment env , Document InputDoc)
{
		Document docKohlsSalesForPSA = null;
		Document Outputdoc = null;
		String strOrderInvKey = null;
	try
	{
		loggerForPAMidvoid.beginTimer("PAMidVoid --- Begin ");
		String strOHKey = InputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		
		Document docApiInput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
		Element eleRoot = docApiInput.getDocumentElement();
		eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("API input to getStoredData is ::"+XMLUtil.getXMLString(docApiInput));
		
		loggerForPAMidvoid.debug("Invoking getStoredData ");
		docKohlsSalesForPSA = getStoredData(env, docApiInput);
		
		NodeList ndlChargeTransDet = XPathUtil.getNodeList(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/PSAData/Order/ChargeTransactionDetails/ChargeTransactionDetail");
		
		NodeList ndlSaleChargeTransDet = XPathUtil.getNodeList(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/Order/ChargeTransactionDetails/ChargeTransactionDetail");
		
		if (YFCCommon.isVoid(ndlChargeTransDet.item(0)))
		{
			strOrderInvKey = getInvoiceKeyOnElement(ndlSaleChargeTransDet);
		}
		else
		{
			strOrderInvKey = getInvoiceKeyOnElement(ndlChargeTransDet);
		}
		// Preparing API Input for API Call
		/* Added for Fix of PR-31 Defect#4244 Start */
		if(!YFCCommon.isVoid(strOrderInvKey)){
		loggerForPAMidvoid.debug("PA Mid void Invoice Key is present ::"+strOrderInvKey);
		Document docInput = YFCDocument.createDocument("GetOrderInvoiceDetails").getDocument();
		Element eledocInputRoot = docInput.getDocumentElement();
		eledocInputRoot.setAttribute("InvoiceKey",strOrderInvKey);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("API Input is ::"+XMLUtil.getXMLString(docInput));
		
		Document docOrderInvDetails = KOHLSBaseApi.invokeService(env, "GetOrderInvDetailsForMidVoid",docInput);
		
		
		loggerForPAMidvoid.debug("Invoking AppendOrderLines method");
		Outputdoc = AppendOrderlines(docKohlsSalesForPSA,docOrderInvDetails);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("XML Returned by AppendOrderlines method :::"+XMLUtil.getXMLString(Outputdoc));
		
		Element elePsaOrder = (Element) XPathUtil.getNode(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/PSAData/Order");
		//aj
		if(YFCCommon.isVoid(elePsaOrder))
		{		
			
				loggerForPAMidvoid.debug("Inside Receipted Void Flow");
				Outputdoc = updatePAMidVoidDocument(Outputdoc);
			
		}
		
		
		loggerForPAMidvoid.debug("Invoking updateUPCCode method");
		
		Outputdoc = updateUPCCode(env,Outputdoc);
		}
		else{
			loggerForPAMidvoid.debug("PA Mid void Invoice Key is blank ::"+strOrderInvKey);
			Outputdoc = YFCDocument.createDocument("Order").getDocument();
			Element eleOutputdoc = Outputdoc.getDocumentElement();			
			eleOutputdoc.setAttribute("Reason","PA Mid void Invoice Key is null");
		}
		/* Added for Fix of PR-31 Defect#4244 End */
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("Final XML is ::"+XMLUtil.getXMLString(Outputdoc));
		
		loggerForPAMidvoid.beginTimer("PAMidVoid --- End ");
	}
	catch(Exception e) {e.printStackTrace(); }
	return Outputdoc;
}


/*	This Method makes an API call to fetch clob objects of sale and psa  
 * 	orders and parses them into XML format
 */
public Document getStoredData(YFSEnvironment env , Document docInput)
{
	Document outputDoc = null;
	try
	{
		loggerForPAMidvoid.beginTimer("FetchKohlsSalesForPA --- Begin ");
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("API Input to GetKohlsSalesDetails :::"+XMLUtil.getXMLString(docInput));
		
		// API call to fetch data from db
		outputDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInput);
		
		Element eleRootElement = outputDoc.getDocumentElement();
		
		// Fetching and parsing clob into string objects
		String strSalesClob =eleRootElement.getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);
		
		loggerForPAMidvoid.debug("Clob Object for sales is :::"+strSalesClob);
		
		 String strPSAClob = eleRootElement.getAttribute("PSAData");
		 //aj
		 loggerForPAMidvoid.debug("Clob Object for PSA is :::"+strPSAClob);
		 
		if (!strSalesClob.isEmpty()) {
			Document docClobData = XMLUtil.getDocument(strSalesClob);
			eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA,KohlsPOCConstant.BLANK);
			Element eleNewClob = docClobData.getDocumentElement();
			XMLUtil.importElement(eleRootElement, eleNewClob);
			}
		
		if(!strPSAClob.isEmpty()) {
			Document docClobData = XMLUtil.getDocument(strPSAClob);
			eleRootElement.setAttribute("PSAData",KohlsPOCConstant.BLANK);
			//aj
			Element elePSAData = XMLUtil.createChild(eleRootElement, "PSAData");
			Element eleNewClob = docClobData.getDocumentElement();
			XMLUtil.importElement(elePSAData, eleNewClob);
			
			
			if(loggerForPAMidvoid.isDebugEnabled())
				loggerForPAMidvoid.debug("After Appending :::"+ XMLUtil.getElementXMLString(elePSAData));
		}
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("After updated ; Document output :::"+ XMLUtil.getXMLString(outputDoc));
		
		loggerForPAMidvoid.endTimer("FetchKohlsSalesForPA --- End ");
		
	}
	catch(Exception e){ e.printStackTrace();}
	return outputDoc;
}


public Document AppendOrderlines(Document docSalesAndPsa,Document docInvoice)
{
	
	
	try
	{
		
		loggerForPAMidvoid.debug("Inside Append OrderLines Method -- Begin ");
		
		Element eleSaleOrder = (Element) XPathUtil.getNode(docSalesAndPsa, KohlsPOCConstant.X_KOHLS_SALES_ORDER);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("Sales Element is ::"+XMLUtil.getElementXMLString(eleSaleOrder));
		
		
		String strSaleSellerOrgCode = eleSaleOrder.getAttribute("SellerOrganizationCode");
		String strSaleTerminalId = eleSaleOrder.getAttribute("TerminalID");
		String strSalePosSeqNo = eleSaleOrder.getAttribute("PosSequenceNo");
		String strSaleOrderDate = eleSaleOrder.getAttribute("OrderDate");
		//Start PR-626 fix
		String strPSASellerOrgCode = eleSaleOrder.getAttribute("TransactionNo");
		if(!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
		// Extracting Seller Organization code from the Updated Transaction Number
		strPSASellerOrgCode = strPSASellerOrgCode.substring(12, 16);
		
		loggerForPAMidvoid.debug("PA seller Organization code is:::"+strPSASellerOrgCode);
		}
		// End PR-626 fix
		
		
		

		NodeList ndlAwards = XPathUtil.getNodeList(docSalesAndPsa,KohlsPOCConstant.X_KOHLS_SALES_AWARD);
		 
		NodeList ndlPsaAwards = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OrderLines/OrderLine/Awards/Award");
		
		// Removing SalesHubData Clob object from Sales award
		
		 if (ndlAwards!=null){
			 for (int c=0;c<ndlAwards.getLength();c++){
				 Element eleAward=(Element)ndlAwards.item(c);
		
				 
				 Element eleExtn=XMLUtil.getChildElement(eleAward, KohlsPOCConstant.A_EXTN);
				 
				 
				 if(!YFCCommon.isVoid(eleExtn)){
					
					 String strExtnSaleHubData=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
					 
					 if(!YFCCommon.isVoid(strExtnSaleHubData)){
						
						 Document docSalesHubData=XMLUtil.getDocument(strExtnSaleHubData);
						 eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.BLANK);
						 Element eleDataSalesHub=docSalesHubData.getDocumentElement();
						
						 XMLUtil.importElement(eleExtn, eleDataSalesHub);
						 
					 }
				 }
			 }
		 } 
		 
		
		
		 // Removing SalesHubData Clob object from PSA award -- : Refactor Later
		 
		 
		 if (ndlPsaAwards!=null){
			 for (int c=0;c<ndlPsaAwards.getLength();c++){
				 Element eleAward=(Element)ndlPsaAwards.item(c);
		
				 //System.out.println("Inside PSA salesHubData Clob fix");
				 
				 Element eleExtn=XMLUtil.getChildElement(eleAward, KohlsPOCConstant.A_EXTN);
				 
				 
				 if(!YFCCommon.isVoid(eleExtn)){
					
					// System.out.println("Extn element containing PSA salesHubData Clob exist");
					 String strExtnSaleHubData=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
					 
					 if(!YFCCommon.isVoid(strExtnSaleHubData)){
						
						 Document docSalesHubData=XMLUtil.getDocument(strExtnSaleHubData);
						 eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.BLANK);
						 Element eleDataSalesHub=docSalesHubData.getDocumentElement();
						
						 XMLUtil.importElement(eleExtn, eleDataSalesHub);
						 
						// System.out.println("After appending"+XMLUtil.getElementXMLString(eleExtn));
						 
					 }
				 }
			 }
		 } 
		 
		 
		 
		 Element eleSaleOrderlines = (Element) XPathUtil.getNode(docSalesAndPsa,"/KOHLSSalesForPsa/Order/OrderLines");
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("Sale Orderlines element is :::"+XMLUtil.getElementXMLString(eleSaleOrderlines));
		
		NodeList ndlSaleOrderline = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/Order/OrderLines/OrderLine");
		
		
		
		for(int b=0;b<ndlSaleOrderline.getLength();b++)
		{
			
			Element eleCurrentElement = (Element)ndlSaleOrderline.item(b);
			// Fix for 2969 -- begin
			
			loggerForPAMidvoid.debug("Fix for 2969 in PA MID VOiD - Begin");
			Element eleCurrentExtn = XMLUtil.getChildElement(eleCurrentElement,"Extn");
			
			
			if(loggerForPAMidvoid.isDebugEnabled())
				loggerForPAMidvoid.debug("Current Extn Element is::"+XMLUtil.getElementXMLString(eleCurrentExtn));
			
			String strTaxInd = eleCurrentExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);
			
			strTaxInd = UpdateTaxIndType(strTaxInd);
			
			eleCurrentExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, strTaxInd);
			
			loggerForPAMidvoid.debug("Fix for 2969 in PSA MID VOiD - End");
			
			// Fix for 2969 -- End
			
			XMLUtil.removeChild(eleSaleOrderlines,(Element) ndlSaleOrderline.item(b));
		
		}
		
		
		
		NodeList ndlPSAOrderline = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OrderLines/OrderLine");
		
		if(!YFCCommon.isVoid(ndlPSAOrderline.item(0)))
		{
		for(int i=0;i<ndlSaleOrderline.getLength();i++)
		{
			Element eleCurrentSaleOrderline = (Element) ndlSaleOrderline.item(i);
			eleSaleOrderlines.appendChild(eleCurrentSaleOrderline );
			eleSaleOrderlines.appendChild(ndlPSAOrderline.item(i));
		}
		}
		else 
		{
			for(int i=0;i<ndlSaleOrderline.getLength();i++)
			{
				Element eleCurrentSaleOrderline = (Element) ndlSaleOrderline.item(i);
				eleSaleOrderlines.appendChild(eleCurrentSaleOrderline );
			
			}
		}
		
		Element eleInvOrder = (Element) XPathUtil.getNode(docInvoice.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER);
		
		String strOrigPosSeqNo = eleInvOrder.getAttribute("PosSequenceNo");
		String strOrigOrderDate = eleInvOrder.getAttribute("OrderDate");
		String strOrigTerminalID = eleInvOrder.getAttribute("TerminalID");
		String strOrigSellerOrgCode = eleInvOrder.getAttribute("SellerOrganizationCode");
		
		Element eleInvExtn = (Element) XPathUtil.getNode(docInvoice.getDocumentElement(),KohlsPOCConstant.X_INV_EXTN);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("Setting Sales Attributes at Extn level::"+XMLUtil.getElementXMLString(eleInvExtn));
		
		eleInvExtn.setAttribute("ExtnOrderDate",strOrigOrderDate);
		eleInvExtn.setAttribute("ExtnPosSequenceNo", strOrigPosSeqNo);
		eleInvExtn.setAttribute("ExtnSellerOrganisationCode",strOrigSellerOrgCode);
		eleInvExtn.setAttribute("ExtnTerminalID",strOrigTerminalID);
		eleInvExtn.setAttribute("ExtnShipNode",strOrigSellerOrgCode);
		//Start PR-626 fix
		eleInvOrder.setAttribute("SellerOrganizationCode", strPSASellerOrgCode);
		//End PR-626 fix
		eleInvOrder.setAttribute("TerminalID", strSaleTerminalId);
		eleInvOrder.setAttribute("PosSequenceNo", strSalePosSeqNo);
		eleInvOrder.setAttribute("OrderDate", strSaleOrderDate);
		
		
		
		docInvoice.adoptNode(eleSaleOrderlines);
		eleInvOrder.appendChild(eleSaleOrderlines);
		XMLUtil.createChild(eleInvOrder, "TaxDetailList");
		
		Integer noOfPromotions = eleInvOrder.getElementsByTagName("Promotion").getLength();
		loggerForPAMidvoid.debug("No of Existing promotion element ::"+noOfPromotions);
		if(noOfPromotions.equals(0))
		{
			loggerForPAMidvoid.debug("Creating Promotion child element ; Does not exist ");
			XMLUtil.createChild(eleInvOrder, "Promotions");
		}
		
		loggerForPAMidvoid.debug("Invoking calculateTotalOrderLines ");
		
		docInvoice = calculateTotalOrderLines(docInvoice);
		
		loggerForPAMidvoid.debug("Invoking ConsolidateTaxAndTotalAmt ");
		
		docInvoice = ConsolidateTaxAndTotalAmt(docSalesAndPsa,docInvoice);
		
		loggerForPAMidvoid.debug("Invoking AppendPromotionAndTaxes ");
		
		docInvoice = AppendPromotionAndTaxes(docSalesAndPsa,docInvoice);
		
		loggerForPAMidvoid.debug("Invoking setMessageType ");
		
		docInvoice = setMessageType(docInvoice);
		
		loggerForPAMidvoid.debug("Invoking setExternalPayment ");
		docInvoice = setExternalPayment(docInvoice);
		
		
		loggerForPAMidvoid.debug("Inside Append OrderLines Method -- End ");
		
	}
	catch(Exception e) {e.printStackTrace();}
	
	return docInvoice;
}

public Document AppendPromotionAndTaxes (Document docSalesAndPsa, Document docInvoice )
{
	try
	{
			loggerForPAMidvoid.debug("Inside AppendPromotionAndTaxes Method -- Begin ");
			
			NodeList ndlSalesPromotion = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/Order/Promotions/Promotion");
		
			// Updating type code for Sale Promotions
			
			loggerForPAMidvoid.debug("Setting Promotion type for sale");
			for(int a=0;a<ndlSalesPromotion.getLength();a++)
			{
				Element eleCurrentPromotion = (Element) ndlSalesPromotion.item(a);
				eleCurrentPromotion.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
			}
			
			
			NodeList ndlPSAPromotion = XPathUtil.getNodeList(docSalesAndPsa, "/KOHLSSalesForPsa/PSAData/Order/Promotions/Promotion");
			
			// Updating type code for PSA Promotions
			
			if(!YFCCommon.isVoid(ndlPSAPromotion)) {
			loggerForPAMidvoid.debug("Setting Promotion type for PA");
			for(int b=0;b<ndlPSAPromotion.getLength();b++)
			{
				Element eleCurrentPSAPromotion = (Element) ndlPSAPromotion.item(b);
				eleCurrentPSAPromotion.setAttribute(KohlsPOCConstant.A_TYPE,"Return");
			}
					
		
		Element elePSAParentPromotion = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.X_INV_PROMOTIONS);
		
		
		
		
		for(int a=0;a<ndlSalesPromotion.getLength();a++)
		{
			docInvoice.adoptNode(ndlSalesPromotion.item(a));
			docInvoice.adoptNode(ndlPSAPromotion.item(a));
			XMLUtil.importElement(elePSAParentPromotion,(Element) ndlSalesPromotion.item(a));
			XMLUtil.importElement(elePSAParentPromotion,(Element) ndlPSAPromotion.item(a));
		}
		
			}
			else
			{
				Element elePSAParentPromotion = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.X_INV_PROMOTIONS);
				for(int a=0;a<ndlSalesPromotion.getLength();a++)
				{
					docInvoice.adoptNode(ndlSalesPromotion.item(a));
					//docInvoice.adoptNode(ndlPSAPromotion.item(a));
					XMLUtil.importElement(elePSAParentPromotion,(Element) ndlSalesPromotion.item(a));
					//XMLUtil.importElement(elePSAParentPromotion,(Element) ndlPSAPromotion.item(a));
				}
			}
		
		Element eleOrigSaleOrder = (Element) XPathUtil.getNode(docSalesAndPsa,KohlsPOCConstant.X_KOHLS_SALES_ORDER);
		
		Element eleOrigSaleOrderExtn = XMLUtil.getChildElement(eleOrigSaleOrder,KohlsPOCConstant.A_EXTN);
		
		 String strExtnTaxDetails=	eleOrigSaleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
		 Element eleTaxDetails = null;
		 if(!YFCCommon.isVoid(strExtnTaxDetails))
		 {
			 Document docExtnTaxDetails=XMLUtil.getDocument(strExtnTaxDetails);
			 eleOrigSaleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
			 eleTaxDetails = docExtnTaxDetails.getDocumentElement();
			 XMLUtil.importElement(eleOrigSaleOrder,eleTaxDetails);
		 }
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("Fixing Tax Clob Issue"+XMLUtil.getElementXMLString(eleOrigSaleOrder));
		 
		 NodeList ndlTaxDetail = XPathUtil.getNodeList(eleOrigSaleOrder,KohlsPOCConstant.X_KOHLS_SALES_TAX_DETAIL);
		 
		
		 loggerForPAMidvoid.debug("Setting Tax indicator for Sales");
		 
		 // Updating Tax Indicator for Sales Tax
		 
		 if(!(YFCCommon.isVoid(ndlTaxDetail)))
				 {
			 		for(int c=0;c<ndlTaxDetail.getLength();c++)
			 		{
			 			Element eleCurrentTax = (Element) ndlTaxDetail.item(c);
			 			String strTaxInd = eleCurrentTax.getAttribute(KohlsPOCConstant.A_TAX_INDICATOR);
			 			strTaxInd = UpdateTaxIndType(strTaxInd);
			 			eleCurrentTax.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, strTaxInd);
			 			eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
			 		}
		
			 		}
		 
		 
		 
		 Element elePSATaxDetail = (Element) XPathUtil.getNode(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/Extn");
			
		 if(!YFCCommon.isVoid(elePSATaxDetail)) {
			System.out.println("Tax Clob Element is ::"+XMLUtil.getElementXMLString(elePSATaxDetail));
			 String strExtnPSATaxDetails=	elePSATaxDetail.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
			 Element elePSATaxDetails = null;
			 if(!YFCCommon.isVoid(strExtnTaxDetails))
			 {
				 Document docExtnTaxDetails=XMLUtil.getDocument(strExtnPSATaxDetails);
				 elePSATaxDetail.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
				 elePSATaxDetails = docExtnTaxDetails.getDocumentElement();
				 XMLUtil.importElement(elePSATaxDetail,elePSATaxDetails);
				 
			 }
		 }
		 NodeList ndlPSATaxDetail = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/Extn/TaxDetailList/TaxDetail");
		 
		 if(!YFCCommon.isVoid(ndlPSATaxDetail)) {
		 
		 loggerForPAMidvoid.debug("Setting Tax Indicator for PSA");
		 
		 for(int d=0;d<ndlPSATaxDetail.getLength();d++)
		 {
			 Element eleCurrentTax = (Element) ndlPSATaxDetail.item(d);
			 eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE,"Return");
		}
		 
		 Element eleTaxDetailList = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.X_INV_TAX_DETAIL_LIST);
		 
		for(int c=0;c<ndlTaxDetail.getLength();c++)
		 {
			docInvoice.adoptNode(ndlTaxDetail.item(c));
			docInvoice.adoptNode(ndlPSATaxDetail.item(c));
			XMLUtil.importElement(eleTaxDetailList,(Element)ndlTaxDetail.item(c));
			XMLUtil.importElement(eleTaxDetailList,(Element)ndlPSATaxDetail.item(c));
			
		 }
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("After appending ::"+XMLUtil.getElementXMLString(eleTaxDetailList));
		 } 

		loggerForPAMidvoid.debug("Inside AppendPromotionAndTaxes Method -- End ");
		 
	}
	catch(Exception e) {e.printStackTrace();}
	return docInvoice;
	
}

public String getInvoiceKeyOnElement (NodeList ndlInput)
{	
	String strKey = null;
	try
	{
		loggerForPAMidvoid.debug("Inside getInvoiceKeyOnElement");
		
		for(int i=0;i<ndlInput.getLength();i++)
			{
				loggerForPAMidvoid.debug("Inside iteration for nodelist");
				Element eleCurrent = (Element) ndlInput.item(i);
				
				if(loggerForPAMidvoid.isDebugEnabled())
					loggerForPAMidvoid.debug(XMLUtil.getElementXMLString(eleCurrent));
				String str = eleCurrent.getAttribute("OrderInvoiceKey");
				if(!YFCCommon.isStringVoid(str))
				{
					strKey = str;
					
				}
			}
		
		loggerForPAMidvoid.debug("Inside getInvoiceKeyOnElement -- End");
	}	
	catch(Exception ex) { ex.printStackTrace(); }
	return strKey;
}

public Document calculateTotalOrderLines(Document docInput)
{
	
	try{
		
		loggerForPAMidvoid.debug("Inside calculateTotalOrderLines Method -- Begin ");
		
		NodeList ndlOrderLine = ((NodeList) XPathUtil
				.getNodeList(docInput.getDocumentElement(),
						KohlsPOCConstant.X_INV_ORDERLINE));
		
		Integer totalNumberCount = ndlOrderLine.getLength();
		
		loggerForPAMidvoid.debug("OrderLine count is ::"+totalNumberCount);
		
		String totalNumber = totalNumberCount.toString();
		
		Element eleOrderLines =(Element) XPathUtil.getNode(docInput.getDocumentElement(),KohlsPOCConstant.X_INV_ORDERLINES);
		
		eleOrderLines.setAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS,totalNumber);
							
		if(!(YFCCommon.isVoid(ndlOrderLine))){
			for(int i=0;i<totalNumberCount;i++)
			{
				Element eleOrderLine = (Element) ndlOrderLine.item(i);
				Integer count = i+1;
				String strCurrValue = count.toString();
					eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_LINE_SEQ_NO,strCurrValue);
					loggerForPAMidvoid.debug("Setting Line Sequence Number :::" + strCurrValue);
						if(count%2 == 0)
					{
						eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE,"Return");
					}
					else
					{
						eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
					}
									
		}
	
		}
		
		loggerForPAMidvoid.debug("Inside calculateTotalOrderLines Method -- End ");
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	return docInput;
	}

public String UpdateTaxIndType(String strTaxInd)
{
	
	loggerForPAMidvoid.debug("Inside UpdateTaxIndType -- begin");
	if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_1)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_A;}
	else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_2)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_B;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_3)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_C;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_4)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_D;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_5)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_E;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_6)){strTaxInd = KohlsPOCConstant.ATTR_TAX_F;}
	else	{strTaxInd = KohlsPOCConstant.CONST_HASH;}
	
	
	loggerForPAMidvoid.debug("Tax indicator Returned"+strTaxInd);
	
	loggerForPAMidvoid.debug("Inside UpdateTaxIndType -- End");
	
	return strTaxInd;
	
}

public Document ConsolidateTaxAndTotalAmt(Document docSalesAndPsa, Document docInvoice)
{
	
	try {
		
		
		loggerForPAMidvoid.debug("Inside ConsolidateTaxAndTotalAmt Method -- Begin ");
		
		// Re-calculating Grand Tax Amount
		
		Element eleOrigSaleOvrTotal = (Element) XPathUtil.getNode(docSalesAndPsa,KohlsPOCConstant.X_KOHLS_SALES_OVERALL_TOTALS);
		String strSalesGrandTax = eleOrigSaleOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
		
		Element elePSAOvrTotal = (Element) XPathUtil.getNode(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OverallTotals");
		
		if(!YFCCommon.isVoid(elePSAOvrTotal))
			
		{
		
		String strPSAGrandTax = elePSAOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
		
		loggerForPAMidvoid.debug("Sale and PSA Taxes are ::"+strSalesGrandTax+strPSAGrandTax);
		
		Float calculatedValue = Float.parseFloat(strPSAGrandTax) - Float.parseFloat(strSalesGrandTax);
		
	
		//rounding the values 06/23/016 - Start 
		strPSAGrandTax = String.format("%.2f", calculatedValue);
        //rounding the values 06/23/016 - End 
		
		elePSAOvrTotal.setAttribute(KohlsPOCConstant.ATTR_GRAND_TAX, strPSAGrandTax);
	
	
		// Re-calculating Total Amount
	
			String strTotalAmount = eleOrigSaleOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);
			
			Element elePSAInvHeader = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.XPATH_INVOICE_HEADER);
			
			String strPSATotalAmnt = elePSAOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);
			
			loggerForPAMidvoid.debug("Sale and PSA Taxes are ::"+strTotalAmount+strPSATotalAmnt);
			
			Float calculatedValueTotalAmnt = Float.parseFloat(strPSATotalAmnt) - Float.parseFloat(strTotalAmount);
			
			
			//rounding the values 06/23/016 - Start 
		    strPSATotalAmnt = String.format("%.2f", calculatedValueTotalAmnt);
            //rounding the values 06/23/016 - End 
			
			elePSAInvHeader.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, strPSATotalAmnt);
		
	
			loggerForPAMidvoid.debug("Inside ConsolidateTaxAndTotalAmt Method -- End ");
		}		
			
	} 
	catch (Exception e)
	
	{e.printStackTrace();}
	
	
	return docInvoice;
}

public Document setMessageType(Document docInvoice)
{
	try
	{
		
		loggerForPAMidvoid.debug("Inside setMessageType Method -- Begin ");
		Element eleOrder = (Element) XPathUtil.getNode(docInvoice, "/InvoiceDetail/InvoiceHeader/Order");
		Element eleInvDetails =	(Element) XPathUtil.getNode(docInvoice, "/InvoiceDetail");
		eleInvDetails.setAttribute("MessageType", "PA_VoidDuring");
		eleInvDetails.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
		
		Element eleOrderExtn = XMLUtil.createChild(eleOrder, "Extn");
		eleOrderExtn.setAttribute("ExtnIsVoidDuring","Y");
		
		loggerForPAMidvoid.debug("Inside setMessageType Method -- End ");
	}
	catch(Exception e)
	{e.printStackTrace();
	}
	return docInvoice;
}

public Document updateUPCCode(YFSEnvironment env , Document docInvoice)
{
	try
	{
		loggerForPAMidvoid.debug("Inside updateUPCCode Method -- Begin ");
		
		NodeList ndlOrderline = XPathUtil.getNodeList(docInvoice.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINE);
	
		for(int i=0;i<ndlOrderline.getLength();i++)
		{
		Element eleCurrentElement = (Element) ndlOrderline.item(i);
		Element eleItemLevel = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.ELEM_ITEM);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("Current Item is :::"+XMLUtil.getElementXMLString(eleItemLevel));
		
		Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
		Element eleItemInput = docGetItemListInput.getDocumentElement();
		String strItemId = eleItemLevel
				.getAttribute(KohlsPOCConstant.A_ITEM_ID);
		String strUPCCode= eleItemLevel
				.getAttribute(KohlsPOCConstant.A_UPC_CODE);
		eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("API Input is ::"+XMLUtil.getXMLString(docGetItemListInput));
		
		Document docItemListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST, KohlsPOCConstant.API_GET_ITEM_LIST,docGetItemListInput);
		
		if(YFCCommon.isVoid(strUPCCode)|| strUPCCode.isEmpty() || strUPCCode == null) {
		
			String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput);
			if(YFCCommon.isVoid(upc_code)|| upc_code.isEmpty() || upc_code == null)
			{
				upc_code=strNoUPCMsg;
			}
			eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code );
		}
		else {
			eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
		}
			
		}
		
		loggerForPAMidvoid.debug("Inside updateUPCCode Method -- End ");
		
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return docInvoice;
		
}


public Document checkAndInsertSalesData (YFSEnvironment env , Document docInput) 
 {
		Document docAPIOutput = null;
		Document docApiInputForGetOrderDet = null;
		Document docInsertAPIOutput = null;
		String strOHKey = null;
		try {
			loggerForPAMidvoid
					.beginTimer(" --- checkAndInsertSalesData --- Begin ");

			strOHKey = docInput.getDocumentElement().getAttribute(
					"OrderHeaderKey");
			if(!YFCCommon.isStringVoid(strOHKey)){
			Document docApiInput = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			Element eleRoot = docApiInput.getDocumentElement();
			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);

			docAPIOutput = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docApiInput);

		}
 	}
		catch (Exception e) {
			loggerForPAMidvoid.error(e);
		} finally {
			try {
				if (YFCCommon.isVoid(docAPIOutput)) {
					
					loggerForPAMidvoid.debug("Inside Finally Block for API Execution");
					docApiInputForGetOrderDet = YFCDocument.createDocument(
							KohlsPOCConstant.ELEM_ORDER).getDocument();
					Element eleOrderRoot = docApiInputForGetOrderDet
							.getDocumentElement();
					eleOrderRoot.setAttribute(
							KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
					docInsertAPIOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSaveSalesDetails", docApiInputForGetOrderDet);
				}

			}

			catch (Exception e) {
				loggerForPAMidvoid.error(e);
			}
			
		}
		loggerForPAMidvoid
		.endTimer(" --- checkAndInsertSalesData --- End");
		return docInsertAPIOutput;
	}

public Document checkAndUpdatePsaData (YFSEnvironment env , Document docInput)
 {
		loggerForPAMidvoid.beginTimer(" --- checkAndUpdatePsaData -- Begin");
		Document docAPIOutput = null;
		Document docInsertAPIOutput = null;
		Document docApiInputForGetOrderDet = null;
		try {
			String strOHKey = docInput.getDocumentElement().getAttribute(
					"OrderHeaderKey");
			loggerForPAMidvoid.debug("Order Header Key:::"+strOHKey);
			
			Document docApiInput = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			Element eleRoot = docApiInput.getDocumentElement();
			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);

			docApiInputForGetOrderDet = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderRoot = docApiInputForGetOrderDet
					.getDocumentElement();
			eleOrderRoot.setAttribute(
					KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
			
			
			
			docAPIOutput = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docApiInput);
			
		} catch (Exception e) {
			loggerForPAMidvoid.error(e);
		} finally {
			try {
				loggerForPAMidvoid.debug("Inside Finally Block for API Execution");
				if (YFCCommon.isVoid(docAPIOutput)) {
					docInsertAPIOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSaveSalesDetails", docApiInputForGetOrderDet);
					loggerForPAMidvoid.debug("Inside Finally Block for Creating API Data");
				} else {
					docInsertAPIOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSavePsaDetails", docApiInputForGetOrderDet);
					loggerForPAMidvoid.debug("Inside Finally Block for Change API Data");
				}

			} catch (Exception e) {
				loggerForPAMidvoid.error(e);
			}

		}
		loggerForPAMidvoid.endTimer(" --- checkAndUpdatePsaData -- End");
		return docInsertAPIOutput;
		
	}

public Document updatePAMidVoidDocument(Document inputDoc)
{ 
	Document OutputDoc = null;
	loggerForPAMidvoid.beginTimer("Inside updatePAMidVoidDocument -- Begin ");
	try
	{
		NodeList ndlOrderLine = XPathUtil.getNodeList(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine");
		
		Element eleOrderlines = (Element) XPathUtil.getNode(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/OrderLines");
		
		Element eleOrderline = (Element) XPathUtil.getNode(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine");
	
		eleOrderlines.removeChild(eleOrderline);
		
		
		if(loggerForPAMidvoid.isDebugEnabled())
			loggerForPAMidvoid.debug("After removal ::"+ XMLUtil.getElementXMLString(eleOrderlines));
		
		
		for(int i=0;i<ndlOrderLine.getLength();i++)
		{
			Element eleCurrent = (Element) ndlOrderLine.item(i);
			Node eleclone = eleCurrent.cloneNode(true);
			XMLUtil.appendChild(eleOrderlines, eleCurrent);
			XMLUtil.appendChild(eleOrderlines, (Element) eleclone);
			
			
			if(loggerForPAMidvoid.isDebugEnabled())
				loggerForPAMidvoid.debug("After appending ::"+XMLUtil.getElementXMLString(eleOrderlines));
			
		}
		NodeList ndlTaxDetailList = XPathUtil.getNodeList(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail");
		NodeList ndlTaxDetail = XPathUtil.getNodeList(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail");
		Element eleTaxDetailList = (Element) XPathUtil.getNode(inputDoc,"/InvoiceDetail/InvoiceHeader/Order/TaxDetailList");
		
		
		if(!YFCCommon.isVoid(ndlTaxDetailList.item(0)))
		{
			System.out.println("Inside not void of taxdetail list");
			Element eleTaxDetail = (Element) XPathUtil.getNode(inputDoc,"/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail");
			eleTaxDetailList.removeChild(eleTaxDetail);
			
			if(loggerForPAMidvoid.isDebugEnabled())
				loggerForPAMidvoid.debug("After tax detail removal::"+XMLUtil.getElementXMLString(eleTaxDetailList));
	
		for(int i=0;i<ndlTaxDetail.getLength();i++)
		{
			Element eleCurrent = (Element) ndlTaxDetail.item(i);
			XMLUtil.appendChild(eleTaxDetailList, eleCurrent);
			Element eleClone = (Element) eleCurrent.cloneNode(true);
			eleClone.setAttribute("TaxIndicator", KohlsPOCConstant.ATTR_TAX_1);
			eleClone.setAttribute("Type", KohlsPOCConstant.ATTR_PSA);
			XMLUtil.appendChild(eleTaxDetailList, eleClone);
			
			if(loggerForPAMidvoid.isDebugEnabled())
				loggerForPAMidvoid.debug("After appending Tax ::"+XMLUtil.getElementXMLString(eleTaxDetailList));
		}
		}
		loggerForPAMidvoid.endTimer("Inside updatePAMidVoidDocument -- End ");
		inputDoc = calculateTotalOrderLines(inputDoc);
		OutputDoc = inputDoc;
			
	}
	catch(Exception e)
	{
		loggerForPAMidvoid.error(e);
	}
		
	return OutputDoc;
}

public Document setExternalPayment(Document inputDoc)
{
		String strCheck = null;
		try {
			loggerForPAMidvoid.beginTimer("setExternalPayment");
			NodeList ndlCollectionDetail = XPathUtil.getNodeList(inputDoc,
					KohlsPOCConstant.X_INV_COLLECTION_DETAIL);

			for (int i = 0; i < ndlCollectionDetail.getLength(); i++) {
				Element eleCurrentElement = (Element) ndlCollectionDetail
						.item(0);
				if (!YFCCommon.isVoid(eleCurrentElement)) {
					
					if(loggerForPAMidvoid.isDebugEnabled())
						loggerForPAMidvoid.debug("Current CollectionDetail Element ::"
								+ XMLUtil.getElementXMLString(eleCurrentElement));
					Element elePaymentMethod = (Element) XPathUtil.getNode(
							eleCurrentElement, "PaymentMethod");
					if (!YFCCommon.isVoid(elePaymentMethod)) {
						
						if(loggerForPAMidvoid.isDebugEnabled())
							loggerForPAMidvoid.debug("Current Payment Method Element ::"
									+ XMLUtil
									.getElementXMLString(elePaymentMethod));
						strCheck = elePaymentMethod.getAttribute("PaymentType");
						loggerForPAMidvoid.debug("Payment Type is ::" + strCheck);
						if (strCheck.equalsIgnoreCase("CREDIT_CARD")
								|| strCheck.equalsIgnoreCase("DEBIT_CARD")) {
							loggerForPAMidvoid.debug("Inside External Payment block");
							elePaymentMethod.setAttribute("IsExternalPayment","P");

						}

					}
				}
			}
		}
		catch(Exception e){e.printStackTrace();}
	loggerForPAMidvoid.endTimer("setExternalPayment");
		return inputDoc;
	}

}

