package com.kohls.poc.api;

import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

public class KohlsStoreBusinessDateCorrection {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsStoreBusinessDateCorrection.class.getName());
	public String currStoreStatus;
	public static final String ASC = "asc";
	private static YIFApi oApi = null;
	private String logToFile = null;

	// - Any change the store is in Closed state, and business is ASC close?
	public void storeBusinessDateCorrection(YFSEnvironment env, Document doc) throws Exception {
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		String systemDate = sdf.format(currDate);
		SimpleDateFormat dateFmt = new SimpleDateFormat(KohlsPOCConstant.HD_DATE_FORMAT);
		String sysDateToMsg = dateFmt.format(currDate);		
		String storeID = null;
		
		try {
			storeID = doc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_STORE_ID);
			logToFile = doc.getDocumentElement().getAttribute(KohlsPOCConstant.A_LOGTOFILE);
			log.info("Store " + storeID + " - Input to StoreBusinessDateCorrection service " + SCXmlUtil.getString(doc));
			
			YFSContext ctx = (YFSContext) env;
			boolean dateRangePresent = false;
			String storeDate ="";	
			//Get the business date			
			 Document outputDocDate = getBusinessDate(ctx, storeID); 
			currStoreStatus = null;
			Element eleCommonCodeList = outputDocDate.getDocumentElement();
			NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);
			Element eleCommonCode = ((Element) nodeListCommonCode.item(0));
			int noOfRecords = Integer
					.parseInt(outputDocDate.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));		
			if (noOfRecords == 0) {
				throw new YFCException("Store " + storeID + " - Current period is not set to Y, unable to retrieve the Business date");
			} else {
				storeDate = eleCommonCode.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);	
				currStoreStatus = eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_STATUS);	
				log.info("Store " + storeID + " - No of records, business date and status " + noOfRecords + ", " + storeDate +  ", " + currStoreStatus);
			}
						
			String currSysDate = YFCDate.getYFCDate(systemDate).toString().substring(0, 8);
			String storeBussinessDate = YFCDate.getYFCDate(storeDate).toString().substring(0, 8);
			HashMap<String, String[]> datesOutPut = getCommonCodeDates(ctx, KohlsPOCConstant.AUTO_STORE_CLOSE_DATES);	
			SimpleDateFormat formatter = new SimpleDateFormat(KohlsPOCConstant.V_DATE_FORMAT);
			int ascCloseTime = Integer.parseInt(YFSSystem.getProperty(KohlsPOCConstant.ASC_CLOSE_TIME));
			
			SimpleDateFormat hourFrmt = new SimpleDateFormat("HH");
			String currentHour = hourFrmt.format(currDate);
			String advCurrSysDate = "";
			if (Integer.parseInt(currentHour) >= ascCloseTime) {				
				Calendar caldr = Calendar.getInstance();
				caldr.clear();
				caldr.setTime(currDate);
				caldr.add(Calendar.DATE, 1);
				String incSysDate = sdf.format(caldr.getTime());
				advCurrSysDate = YFCDate.getYFCDate(incSysDate).toString().substring(0, 8);
				log.info("Store " + storeID + " - Advanced system date to next day " + advCurrSysDate);
			} else {
				advCurrSysDate = currSysDate;
				log.info("Store " + storeID + " - Advance system date set as sys date " + advCurrSysDate);
			}
			
			for (String startDate : datesOutPut.keySet()) {
				log.debug("Store " + storeID + " - Start date is " + startDate);
				String endDate = datesOutPut.get(startDate)[0];
				String ascDate = datesOutPut.get(startDate)[1];	
				if (Long.parseLong(advCurrSysDate) >= Long.parseLong(startDate)
						&& Long.parseLong(advCurrSysDate) <= Long.parseLong(endDate)) {
					String rangeDateMsg = dateFmt.format(formatter.parse(ascDate));
					if (ascDate.equals(storeBussinessDate)) { 
						log.info("Store " + storeID + " - ASC and business dates are same");
						closeOpenTills(ctx, storeID, ascDate);
						if(currStoreStatus.equalsIgnoreCase(KohlsPOCConstant.CLOSE)){
							log.info("Store " + storeID + " - ASC and Business dates are same and store in closed status");							
							storeOpenForAccForPOS(ctx, ascDate, storeDate, rangeDateMsg,
									KohlsPOCConstant.YES, storeID);							
						}						
					} else {		
						log.info("Store " + storeID + " - ASC and business dates are not same");
						closeOpenTills(ctx, storeID, ascDate);
						storeCloseForAccForPOS(ctx, storeID);
						storeOpenForAccForPOS(ctx, ascDate, storeDate, rangeDateMsg,
								KohlsPOCConstant.YES, storeID);						
					}					
					dateRangePresent = true;					
					log.info("Store " + storeID + " - System date is in range \n System Date : "
							+ Long.parseLong(advCurrSysDate) + "\n Start Date : " + Long.parseLong(startDate)
							+ "\n End Date    : " + endDate + "\n ASC Date : " + ascDate + "\n Flag : "
							+ dateRangePresent);
				} else {
					log.info("Store " + storeID + " - System date is not in range \n System Date : "
							+ Long.parseLong(advCurrSysDate) + "\n Start Date  : " + Long.parseLong(startDate)
							+ "\n End Date    : " + endDate + "\n ASC Date    : " + ascDate + "\n Flag : "
							+ dateRangePresent);
				}
			}		
			
			if (!dateRangePresent) {
				log.info("Store " + storeID + " - System date not in range, Comparing the sys date and business date "
						+ currSysDate + ", " + storeBussinessDate);
				
				if (Integer.parseInt(currentHour) >= ascCloseTime) {
					log.info("Store " + storeID + " - Comparing the tills date with next business day" + advCurrSysDate);
					closeOpenTills(ctx, storeID, advCurrSysDate);
				} else {
					log.info(
							"Store " + storeID + " - Comparing the tills date with current business day " + currSysDate);
					closeOpenTills(ctx, storeID, currSysDate);
				}

				log.info("Store " + storeID + " - Setting business date as system date " + currSysDate);				
				
				if (currStoreStatus.equalsIgnoreCase(KohlsPOCConstant.OPEN)) {
					if (Integer.parseInt(currentHour) >= ascCloseTime) {
						if (Long.parseLong(advCurrSysDate) == Long.parseLong(storeBussinessDate)) {
							log.info("Store " + storeID
									+ " - Store close skipped and store already opened for next day " + advCurrSysDate);
						} else {
							log.info("Store " + storeID + " - Closing the store for the opened business date");
							storeCloseForAccForPOS(ctx, storeID);
							log.info("Store " + storeID + " - Opening the store for the next business day "
									+ advCurrSysDate);
							storeOpenForAccForPOS(ctx, advCurrSysDate, storeDate, sysDateToMsg, KohlsPOCConstant.NO,
									storeID);
						}
					} else if (Integer.parseInt(currentHour) < ascCloseTime) {
						if (Long.parseLong(currSysDate) == Long.parseLong(storeBussinessDate)) {
							log.info("Store " + storeID
									+ " - Store close skipped and store already opened for today's business date " + currSysDate);
						} else {
							log.info("Store " + storeID + " - Closing the store for the opened business date");
							storeCloseForAccForPOS(ctx, storeID);
							log.info("Store " + storeID + " - Opening the store for the today's business day "
									+ currSysDate);
							storeOpenForAccForPOS(ctx, currSysDate, storeDate, sysDateToMsg, KohlsPOCConstant.NO,
									storeID);
						}
					}
				} else { // for close and reconcil
					if (Integer.parseInt(currentHour) >= ascCloseTime) {
						log.info(
								"Store " + storeID + " - Setting business date as next day system date " + advCurrSysDate);
						storeOpenForAccForPOS(ctx, advCurrSysDate, storeDate, sysDateToMsg, KohlsPOCConstant.NO,
								storeID);
					} else if (Integer.parseInt(currentHour) < ascCloseTime) {
						log.info("Store " + storeID + " - Setting business date as system date " + currSysDate);
						storeOpenForAccForPOS(ctx, currSysDate, storeDate, sysDateToMsg, KohlsPOCConstant.NO, storeID);
					}
				}	
			}
		} catch (Exception e) {
			if (logToFile.equalsIgnoreCase(KohlsPOCConstant.YES)) {
				log.error("Store " + storeID
						+ " - Exceptions noticed during auto store close, please refer the error log");
				String logPath = KohlsPOCConstant.AUTO_STORE_CLOSE_LOG + KohlsPOCConstant.BACKWARD_SLASH + ASC
						+ KohlsPOCConstant.UNDERSCORE + YFCDate.getYFCDate(systemDate).toString()
						+ KohlsPOCConstant.UNDERSCORE + storeID + KohlsPOCConstant.DOT_LOG;
				FileWriter writer = new FileWriter(logPath);
				writer.write(e.getMessage());
				log.debug("Store " + storeID + " - Exceptions written to log file");
				writer.close();
			}
		}
	}

	// Get the business date from CORP - Done
	public Document getBusinessDate(YFSContext ctx, String storeID) throws Exception {
		log.info("Store " + storeID + " - Getting the business date");
		Document accPeriodInput = SCXmlUtil.createDocument(KohlsPOCConstant.A_ACC_PERIOD);
		Element accPeriodInputElm = accPeriodInput.getDocumentElement();
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_ORG_CODE,storeID);
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_PERIOD, KohlsPOCConstant.YES);
		log.debug("Store " + storeID + " - Input to get business date " + KohlsXMLUtil.getXMLString(accPeriodInput));
		Document outputDocDate = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_GET_ACC_PERIOD_LIST_POS,
				accPeriodInput);
		log.debug("Store " + storeID + " - Output to get business date " + XMLUtil.getXMLString(outputDocDate));		
		return outputDocDate;
	}
	
	
	// Get the dates from common code and forms the hashmap
	public HashMap<String, String[]> getCommonCodeDates(YFSContext ctx, String strSyncProfile) throws Exception {
		log.info("Getting the dates range");
		Document ascCommCodeDateInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
		Element eleCommonCodeListInput = ascCommCodeDateInput.getDocumentElement();
		eleCommonCodeListInput.setAttribute(KohlsPOCConstant.A_CODE_TYPE, strSyncProfile);
		log.debug("Input to commonCode API " + SCXmlUtil.getString(ascCommCodeDateInput));
		Document ascCommCodeDateOutput = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_GET_COMMON_CODE_LIST,
				ascCommCodeDateInput);
		log.debug("Output from commonCode API " + SCXmlUtil.getString(ascCommCodeDateOutput));
		HashMap<String, String[]> hashMapCommonCode = new HashMap<String, String[]>();

		Element eleCommonCodeList = ascCommCodeDateOutput.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsConstants.COMMON_CODE);
		for (int i = 0; i < nodeListCommonCode.getLength(); i++) {
			Element eleCommonCode = ((Element) nodeListCommonCode.item(i));
			String[] endAndAscDates = new String[2];
			endAndAscDates[0] = eleCommonCode.getAttribute(KohlsPOCConstant.CODE_SHORT_DESC);
			endAndAscDates[1] = eleCommonCode.getAttribute(KohlsPOCConstant.CODE_LONG_DESC);
			hashMapCommonCode.put(eleCommonCode.getAttribute(KohlsPOCConstant.CODE_VALUE), endAndAscDates);
			log.debug("Start, End and ASC are " + eleCommonCode.getAttribute(KohlsPOCConstant.CODE_VALUE) + ", "
					+ eleCommonCode.getAttribute(KohlsPOCConstant.CODE_SHORT_DESC) + ", "
					+ eleCommonCode.getAttribute(KohlsPOCConstant.CODE_LONG_DESC));
		}
		return hashMapCommonCode;
	}
		
		
    //Close the store if it is matching to ASC date
	public void storeCloseForAccForPOS(YFSContext ctx, String sd) throws Exception { 
		log.info("Store " + sd + " - Store close is inProgress");
		try {
			Document storeCloseInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_STORE_CLOSE_ACC_POS);
			Element storeCloseElm = storeCloseInput.getDocumentElement();
			log.info("Store number is " + sd.toString().trim());
			storeCloseElm.setAttribute(KohlsPOCConstant.A_CLOSE_TYPE, KohlsPOCConstant.AUTO);
			storeCloseElm.setAttribute(KohlsPOCConstant.CTX_ORG_CODE, sd.toString().trim());
			storeCloseElm.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
			storeCloseElm.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, KohlsPOCConstant.ADMIN);
			storeCloseElm.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, sd.toString().trim());
			log.debug("Store " + sd + " - Input to StoreCloseForAccountingForPOS API " + SCXmlUtil.getString(storeCloseInput));
			Document outputAccDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_STORE_CLOSE_ACC_POS, storeCloseInput);
			log.debug("Store " + sd + " - Output from StoreCloseForAccountingForPOS API " + SCXmlUtil.getString(outputAccDoc));
		} catch (Exception ie) {
			log.error("Store " + sd + " - Exception in store closing " + ie.getMessage());
			throw ie;
		}
	}
	
	
    // Open the store for the date passed
	public void storeOpenForAccForPOS(YFSEnvironment env, String businessDate, String storeDate, String rangeDateMsg,
			String flag, String storeID) throws Exception {
		try {
			YFSContext ctx = (YFSContext) env;
			log.info("Store " + storeID + " - Store open is inProgress" );
			Document multiApiOpenAccInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_STORE_OPEN_ACC_POS);
			Element elmOpenAccDoc = multiApiOpenAccInput.getDocumentElement();
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, businessDate);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.CTX_ORG_CODE,
					storeID);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.A_OPEN_TYPE, KohlsPOCConstant.MANUAL);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, KohlsPOCConstant.ADMIN);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
					storeID);
			log.debug("Store " + storeID + " - Input to storeOpenForAccountingForPOS API " + SCXmlUtil.getString(multiApiOpenAccInput));
			Document outputAccDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_STORE_OPEN_ACC_POS,
					multiApiOpenAccInput);
			log.debug("Store " + storeID + " - Output to storeOpenForAccountingForPOS API " + SCXmlUtil.getString(outputAccDoc));
			
			callManageOfflineTransactionQForPOS(env, multiApiOpenAccInput, outputAccDoc);
			if (logToFile.equalsIgnoreCase(KohlsPOCConstant.YES)) {
				dateCorrectionLogToFile(KohlsPOCConstant.YES, storeDate, rangeDateMsg, flag, storeID);
			}
		} catch (Exception e) {
			log.error("Store " + storeID + " - Exception in store opening " + e.getMessage());
			throw e;
		}
	}
	
   
	public Document callApi(YFSEnvironment env, Document inXML, String sEndpoint, String sApiName) {
		try {
			Document tempOutput = null;
			oApi = getDefaultAPI((YFSContext) env, sEndpoint);
			log.info("callApi is in progress");
			String envString = "<env userId='gravity' progId='gravity'/>";
			YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
			tempOutput = oApi.invoke(newEnv, sApiName, inXML);
			return tempOutput;
		} catch (Exception e) {
			log.error("Error in callApi " + e.getMessage() + e.getStackTrace());
			throw new YFCException("Exception in callApi");
		}
	}

	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			log.debug("YIFClient using endpoint definition");
			Map omap = new HashMap();
			try {
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_USERID,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_USERID));
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_PASSWD,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_PASSWD));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}
		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode(KohlsPOCConstant.EDGE_SERVER_ERROR_CODE);
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), KohlsPOCConstant.EDGE_SER_NOT_CONFIGURED));
		throw oEx;
	}

	private void callManageOfflineTransactionQForPOS(YFSEnvironment env, Document multiApiOpenAccInput,
			Document outputAccDoc) throws Exception {
		log.info("callManageOfflineTransactionQForPOS started");
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		String systemDate = sdf.format(currDate);
		
		Element eleMultiApiOpenAccInput = multiApiOpenAccInput.getDocumentElement();
		Element eleOutputAccDoc = outputAccDoc.getDocumentElement();
		String strOpenDateTime = "", strBusinessDay = "", strOpenType = "";
		ArrayList<Element> elePOSStatusList = SCXmlUtil.getChildren(eleOutputAccDoc, KohlsPOCConstant.E_POS_STATUS);
		for (Element elePOSStatus : elePOSStatusList) {
			if (KohlsPOCConstant.A_ACC_PERIOD.equals(elePOSStatus.getAttribute(KohlsPOCConstant.A_TYPE))) {
				Element eleAccPeriod = SCXmlUtil.getChildElement(elePOSStatus, KohlsPOCConstant.A_ACC_PERIOD);
				strOpenDateTime = eleAccPeriod.getAttribute(KohlsPOCConstant.A_OPEN_TIME);
				strBusinessDay = eleAccPeriod.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
				strOpenType = eleAccPeriod.getAttribute(KohlsPOCConstant.A_OPEN_TYPE);
			}
		}
		Document docManageOfflineTrxQForPOSInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
		Element eleDocManageOfflineTrxQ = docManageOfflineTrxQForPOSInput.getDocumentElement();
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_OPERATION_ID, KohlsPOCConstant.API_STORE_OPEN_ACC_POS);
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CREATE);
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_OPEN_TIME, strOpenDateTime);
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_ORG_CODE,
				eleMultiApiOpenAccInput.getAttribute(KohlsPOCConstant.CTX_ORG_CODE));
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.STORE_ID,
				eleMultiApiOpenAccInput.getAttribute(KohlsPOCConstant.CTX_ORG_CODE));
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.ONE);
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_OPERATION_TS, systemDate);
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.YES);

		log.debug("eleDocManageOfflineTrxQ " + SCXmlUtil.getString(eleDocManageOfflineTrxQ));
		Document docOpearationInputXML = SCXmlUtil.createDocument(KohlsPOCConstant.E_STORE_OPEN_ACC_POS);
		Element eleOperationInpuXML = docOpearationInputXML.getDocumentElement();
		eleOperationInpuXML.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY, strBusinessDay);
		eleOperationInpuXML.setAttribute(KohlsPOCConstant.A_OPEN_TIME, strOpenDateTime);
		eleOperationInpuXML.setAttribute(KohlsPOCConstant.A_OPEN_TYPE, strOpenType);
		eleOperationInpuXML.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
				eleMultiApiOpenAccInput.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
		eleOperationInpuXML.setAttribute(KohlsPOCConstant.A_ORG_CODE,
				eleMultiApiOpenAccInput.getAttribute(KohlsPOCConstant.CTX_ORG_CODE));

		String strOperationInputXML = SCXmlUtil.getString(docOpearationInputXML);
		eleDocManageOfflineTrxQ.setAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML, strOperationInputXML);
		log.debug("eleDocManageOfflineTrxQ after " + SCXmlUtil.getString(eleDocManageOfflineTrxQ));

		// Call manageOfflineTrxQ
		log.debug("Calling manageOfflineTransactionQForPOS api with input "
				+ SCXmlUtil.getString(docManageOfflineTrxQForPOSInput));
		Document manageOutput = KohlsCommonUtil.invokeAPI(env,
				KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, docManageOfflineTrxQForPOSInput);
		log.debug("manageOfflineTransactionQForPOS output" + SCXmlUtil.getString(manageOutput));
	}
	   

	//Close open tills greater or less than the business day
	public void closeOpenTills(YFSContext ctx, String storeNo, String businessDay) throws Exception {
		try {
			Document outputDoc = getTillStatusForStore(ctx, storeNo);
			int numOfRegisters = Integer
					.parseInt(outputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
			log.info("Store " + storeNo + " - Number of opened registers " + numOfRegisters);
			if (numOfRegisters != 0) {
				Element eleStoreList = outputDoc.getDocumentElement();
				NodeList nodeList = eleStoreList.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS);
				for (int i = 0; i < nodeList.getLength(); i++) {
					Element eleCommonCode = ((Element) nodeList.item(i));
					String tillBusinessDate = YFCDate
							.getYFCDate(eleCommonCode.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY)).toString()
							.substring(0, 8);
					if (Long.parseLong(tillBusinessDate) != Long.parseLong(businessDay)) {
						Document forceCloseTillInDoc = SCXmlUtil
								.createDocument(KohlsPOCConstant.E_FORCE_CLOSE_TILl_ACC_POS);
						Element forceCloseTillElm = forceCloseTillInDoc.getDocumentElement();
						forceCloseTillElm.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
								eleCommonCode.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
						forceCloseTillElm.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY,
								eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
						forceCloseTillElm.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID,
								eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID));
						forceCloseTillElm.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
						forceCloseTillElm.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, KohlsPOCConstant.ADMIN);
						forceCloseTillElm.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,
								eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
						forceCloseTillElm.setAttribute(KohlsPOCConstant.ATTR_TILL_ID,
								eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
						forceCloseTillElm.setAttribute(KohlsPOCConstant.A_VOID_ORDER, KohlsPOCConstant.YES);
						try {
							log.debug("Store " + storeNo + " - Input to forceCloseTillForAccountingForPOS API is \n"
									+ SCXmlUtil.getString(forceCloseTillInDoc));
							Document outDoc = KohlsCommonUtil.invokeAPI(ctx,
									KohlsPOCConstant.API_FORCE_CLOSE_TILL_FOR_ACC_POS, forceCloseTillInDoc);
							log.debug("Store " + storeNo + " - Output to forceCloseTillForAccountingForPOS API is \n"
									+ SCXmlUtil.getString(outDoc));
						} catch (Exception exp) {							
							//log.info(" Error Contains POSACCT100140 -> " +forceExp.getMessage().contains("POSACCT100140"));
							log.error("Store " + storeNo + " - forceTillClose API having exceptions " + exp.getMessage());
							Document errDoc = SCXmlUtil.createFromString(exp.getMessage().toString());
							NodeList errorNodeList = errDoc.getElementsByTagName(KohlsPOCConstant.E_ERROR);
							if (errorNodeList.getLength() > 0) {
								Element errElm = (Element) errorNodeList.item(0);
								String errCode = errElm.getAttribute("ErrorCode");
								if (errCode.equalsIgnoreCase("POSACCT100140")) {
									log.info("Store " + storeNo + " - Error having POSACCT100140");
								} else {
									throw exp;
								}
							}
						}
					}
				}
			} else {
				log.info("Store " + storeNo + " - None of the registers are opened for this store");
			}
		} catch (Exception ee) {
			log.error("Store " + storeNo + " - closeOpenTills having exceptions " + ee.getMessage());
			throw ee;
		}
	}
	
	
	//Get the till status
	public Document getTillStatusForStore(YFSContext ctx, String storeNo) throws Exception {
		log.info("Store " + storeNo + " - Getting the till status");
		Document inputDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
		inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORG_CODE, storeNo);
		inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_CURRENT_STATUS, KohlsPOCConstant.OPEN);		
		log.debug("Store " + storeNo + " - Input to getTillStatusListForPOS API " + KohlsXMLUtil.getXMLString(inputDoc));
		Document outputDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.GET_TILL_STAT_LIST_POS_TEMPLATE,
				KohlsPOCConstant.API_GET_TILL_STATUS_LIST_FOR_POS, inputDoc);
		log.debug("Store " + storeNo + " - Output getTillStatusListForPOS API " + KohlsXMLUtil.getXMLString(outputDoc));
		return outputDoc;
	}	
	
	/*After correcting the business date, write the info to log file
	 <AutoStoreClose IsCorrected="N" CorrectedFromDate="2018-03-05"
	 CorrectedToDate="2018-03-06" FromCommonCodeDateRange="Y|N"/> */	
	private void dateCorrectionLogToFile(String isCorrected, String correctedFromDate, String correctedToDate,
			String fromCommonCodeDateRange, String storeID) throws Exception {
		Document ascOutputDoc = SCXmlUtil.createDocument(KohlsPOCConstant.AUTO_STORE_CLOSE);
		Element ascElem = ascOutputDoc.getDocumentElement();
		ascElem.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, storeID);
		ascElem.setAttribute(KohlsPOCConstant.IS_CORRECTED, isCorrected);
		ascElem.setAttribute(KohlsPOCConstant.COMMONCODE_DATE_RANGE, fromCommonCodeDateRange);
		ascElem.setAttribute(KohlsPOCConstant.CORRECTED_TO_DATE, correctedToDate);
		ascElem.setAttribute(KohlsPOCConstant.CORRECTED_FROM_DATE, correctedFromDate);
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		String systemDate = sdf.format(currDate);
		String logPath = KohlsPOCConstant.AUTO_STORE_CLOSE_LOG + KohlsPOCConstant.BACKWARD_SLASH + ASC
				+ KohlsPOCConstant.UNDERSCORE + YFCDate.getYFCDate(systemDate).toString() + KohlsPOCConstant.UNDERSCORE
				+ storeID + KohlsPOCConstant.DOT_LOG;
		FileWriter writer = new FileWriter(logPath);
		writer.write(SCXmlUtil.getString(ascOutputDoc));
		writer.close();
		log.info("Store " + storeID + " - Business date corrected and written to log file");
	}
}
