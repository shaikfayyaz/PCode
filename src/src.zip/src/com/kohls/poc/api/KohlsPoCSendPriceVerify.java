package com.kohls.poc.api;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCSendPriceVerify extends KOHLSBaseApi{
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCSendPriceVerify.class.getName());
	}
	
	/**
	 * @param yfsEnv
	 * @param inputXML
	 */
	public void getPriceVerifyDetails(YFSEnvironment yfsEnv, Document inputXML){
		Document outPutDoc=null;
		
		if(logger.isDebugEnabled())
			logger.debug("InputDocument:"+ XMLUtil.getXMLString(inputXML));
		try {
		
			Element eleOutOrder=(Element)(XPathUtil.getNodeList(inputXML.getDocumentElement(), KohlsPOCConstant.ELE_ORDER).item(0));
			Element eleItem=(Element)(XPathUtil.getNodeList(inputXML.getDocumentElement(),KohlsPOCConstant.ELE_ITEM ).item(0));
			outPutDoc = XMLUtil.newDocument();
			Element invoiceDetailEle =  outPutDoc.createElement(KohlsPOCConstant.ELE_INVOICE_DETAIL);
			invoiceDetailEle.setAttribute("xmlns" ,"http://www.sterlingcommerce.com/documentation");
			invoiceDetailEle.setAttribute("MessageType", "PriceInquiry");
			Element invoiceHeaderEle = outPutDoc.createElement(KohlsPOCConstant.ELE_INVOICE_HEADER);
			if (!YFCCommon.isVoid(eleOutOrder)){
				/*if(!YFCCommon.isVoid(eleOutOrder.getAttribute("Extn_Is_TVS_Store")))
				{
					eleOutOrder.removeAttribute("Extn_Is_TVS_Store");
					logger.debug("Inside Remove");
				}*/
		    XMLUtil.importElement(invoiceHeaderEle, eleOutOrder);
			}
	        invoiceDetailEle.appendChild(invoiceHeaderEle);
			outPutDoc.appendChild(invoiceDetailEle);
			Document salesHubDoc = XMLUtil.createDocument(KohlsPOCConstant.ELE_EXTN_POC_STAGING);
			Element eleExtnPoc = salesHubDoc.getDocumentElement();
			eleExtnPoc.setAttribute(KohlsPOCConstant.ATTR_XMLDATA,XMLUtil.getXMLString(outPutDoc));
			eleExtnPoc.setAttribute(KohlsPOCConstant.ATTR_REFERENCE1, eleItem.getAttribute(KohlsPOCConstant.ATTR_ITEMID));
			eleExtnPoc.setAttribute(KohlsPOCConstant.ATTR_REFERENCE2, eleOutOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
			//PST-926 changes Start
			if(ServerTypeHelper.amIOnEdgeServer()){
		          Element additionalInfo =XMLUtil.createChild(eleExtnPoc, "yfcAdditionalInfo");
	              	  additionalInfo.setAttribute("endpoint", "MOTHERSHIP");	          
		        }
			//PST-926 changes End
			invokeService(yfsEnv, KohlsPOCConstant.API_PRICE_VERIFY_SALES_HUB_GEN, salesHubDoc);
			
			} catch (ParserConfigurationException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}
	/**
	 * @param yfsEnv
	 * @param inputDoc
	 * @return
	 */
	public Document generateFinalSalesHubMessage(YFSEnvironment yfsEnv,Document inputDoc) {
		
		if(logger.isDebugEnabled())
			logger.debug("InputDocument:"+ XMLUtil.getXMLString(inputDoc));
		Document finalSalesHubDoc = null;
		String strPocStagingKey=null;
		Element eleAdminAudit;
		String sOrganizationCode = null;
		try {
			eleAdminAudit = (Element)(XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_ADMIN_AUDIT).item(0));
			String strItemID=eleAdminAudit.getAttribute(KohlsPOCConstant.ATTR_ITEMID);
			sOrganizationCode = eleAdminAudit.getAttribute("OrganizationCode");
			String strTransNo=eleAdminAudit.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM);
			Document OutPutDoc=invokeService(yfsEnv, KohlsPOCConstant.API_GET_EXTN_POC_STAGING_LIST,  createInputForExtnStaging(strItemID, sOrganizationCode));
			
			if(logger.isDebugEnabled())
				logger.debug("OutDoc From GetExtnPoCStagingList:"+ XMLUtil.getXMLString(OutPutDoc));
			//Start PST-5923	
			if(!XMLUtil.isVoid(OutPutDoc)) {
				if(!(OutPutDoc.getChildNodes().item(0).hasChildNodes())) 
				{
					logger.debug("Blank Response from GetExtnPoCStagingList...");
					String BlankResponse="<InvoiceDetail MessageType='BLANK' />";
					finalSalesHubDoc=XMLUtil.getDocument(BlankResponse);
					return finalSalesHubDoc;
				}	
			}
			//End PST-5923
			Element eleExtnPoCStaging = (Element)((NodeList)XPathUtil.getNodeList(OutPutDoc.getDocumentElement(), KohlsPOCConstant.XPATH_EXTN_POC_STAGING).item(0));
			String strClobData=eleExtnPoCStaging.getAttribute(KohlsPOCConstant.ATTR_XMLDATA);
			strPocStagingKey=eleExtnPoCStaging.getAttribute(KohlsPOCConstant.ATTR_POC_STAGING_KEY);
			if(!YFCCommon.isVoid(strClobData)){
				finalSalesHubDoc=XMLUtil.getDocument(strClobData);
				Document auditInfoDoc=getAuditInfo( yfsEnv , strItemID, strTransNo);
				Element eleAdminAuditList = (Element)(XPathUtil.getNodeList(auditInfoDoc.getDocumentElement(),KohlsPOCConstant.ELE_ADMIN_AUDIT_LIST).item(0));
				Element eleInvoiceHeader = (Element)(XPathUtil.getNodeList(finalSalesHubDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER).item(0));
				XMLUtil.importElement(eleInvoiceHeader, eleAdminAuditList);
				
				if(logger.isDebugEnabled())
					logger.debug("FinalOutPut Document:"+XMLUtil.getXMLString(finalSalesHubDoc));
				Document deleterecDoc=createInputForExtnStaging(strItemID, sOrganizationCode);
				Element eleEtxnPOCStaging=deleterecDoc.getDocumentElement();
				eleEtxnPOCStaging.setAttribute("PocStagingKey",strPocStagingKey);
				invokeService(yfsEnv, KohlsPOCConstant.API_DELETE_EXTN_POC_STAGING_LIST, deleterecDoc);
				//Start : DM - 1138
				finalSalesHubDoc = checkAndUpdateDataForSmartSku(finalSalesHubDoc);
				//End : DM - 1138
			}
			
		} catch (Exception e) {
	
			e.printStackTrace();
		}
		return finalSalesHubDoc;		
	}
	/**
	 * @param strItemID
	 * @return
	 * @throws ParserConfigurationException
	 */
	private Document createInputForExtnStaging(String strItemID, String sOrganizationCode) throws ParserConfigurationException{
		Document extnpocstagingDoc= XMLUtil.newDocument();
		Element eleEtxnPOCStaging=extnpocstagingDoc.createElement(KohlsPOCConstant.ELE_EXTN_POC_STAGING);
		eleEtxnPOCStaging.setAttribute("Reference1",strItemID);
		eleEtxnPOCStaging.setAttribute("Reference2",sOrganizationCode);
		extnpocstagingDoc.appendChild(eleEtxnPOCStaging);
		return extnpocstagingDoc;
	}
	
	
  /**
 * @param env
 * @param strItemID
 * @param strTransNo
 * @return
 * @throws Exception
 */
private Document getAuditInfo(YFSEnvironment env ,String strItemID,String strTransNo) throws Exception {
	    Document adminauditDoc= XMLUtil.newDocument();
		Element eleAdminAudit=adminauditDoc.createElement(KohlsPOCConstant.ELE_ADMIN_AUDIT);
		eleAdminAudit.setAttribute(KohlsPOCConstant.ATTR_ITEMID, strItemID);
		eleAdminAudit.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, strTransNo);
		eleAdminAudit.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,KohlsPOCConstant.STR_106);
		adminauditDoc.appendChild(eleAdminAudit);
		Document outDoc=invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ADMIN_AUDIT_TEMPLATE), KohlsPOCConstant.STR_GET_ADMIN_AUDIT_LIST_FOR_POS, adminauditDoc);
		env.clearApiTemplate(KohlsPOCConstant.STR_GET_ADMIN_AUDIT_LIST_FOR_POS);
		return outDoc;
  }

//Start : DM - 1138
private Document checkAndUpdateDataForSmartSku(Document saleHubDoc) throws Exception{
	
	logger.beginTimer("KohlsPoCSendPriceVerify.checkAndUpdateDataForSmartSku");
	if(logger.isDebugEnabled()){
		logger.debug("Input to updateDataForSmartSku:"+XMLUtil.getXMLString(saleHubDoc));
	}
	Element eleAddnDataList = (Element)saleHubDoc.getElementsByTagName(KohlsPOCConstant.ELE_ADDITIONAL_DATA_LIST).item(0);
	if(!YFCCommon.isVoid(eleAddnDataList)){
		Element eleAddnData = (Element) XPathUtil.getNodeList(eleAddnDataList,"//AdditionalDataList/AdditionalData[@Name='Item']").item(0);
		if(!YFCCommon.isVoid(eleAddnData)){
			String strValue = eleAddnData.getAttribute(KohlsPOCConstant.A_VALUE);
			Document docItemInfo = XMLUtil.getDocument(strValue);
			Element eleSmartSku = (Element)docItemInfo.getElementsByTagName("SmartSku").item(0);
			if(!YFCCommon.isVoid(eleSmartSku)){
				if(logger.isDebugEnabled()){
					logger.debug("Smart Sku information is available");
				}
				String strOrigSku = eleSmartSku.getAttribute("OriginalSKU");
				Element eleItem = (Element)saleHubDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);
				String strItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
				if(strItemID.equals(strOrigSku)){
					Element eleOrderLines = (Element)saleHubDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES).item(0); 
					Element eleOrderLineExtn =	(Element) XPathUtil.getNodeList(eleOrderLines,"//OrderLines/OrderLine/Extn").item(0);
					String sExtnDept = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT);
		            String sExtnSubClass = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS);
		            String sDummySKUNo = KohlsPoCPnPUtil.prepadString(sExtnDept, 3, "0")
		                  + KohlsPoCPnPUtil.prepadString(sExtnSubClass, 2, "0") + "000";
		              eleItem.setAttribute(KohlsPOCConstant.A_ITEM_ID, sDummySKUNo);
				}
			}
		}
	}
	if(logger.isDebugEnabled()){
		logger.debug("XML from updateDataForSmartSku:"+XMLUtil.getXMLString(saleHubDoc));
	}
	logger.endTimer("KohlsPoCSendPriceVerify.checkAndUpdateDataForSmartSku");
	return saleHubDoc;
	}
//End : DM - 1138

}
