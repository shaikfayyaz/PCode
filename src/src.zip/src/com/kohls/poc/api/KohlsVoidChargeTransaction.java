package com.kohls.poc.api;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * This class is responsible for creating invoice,changing the carry line status
 * to store order invoiced voiding the charge transaction created by Toshiba
 * gravity,creating a new auth and applying omni hold.
 * 
 * @author Yantriks
 *
 */
// OMNI2 changes Begin - Void Charge Transaction
public class KohlsVoidChargeTransaction implements YIFCustomApi {

	private static final YFCLogCategory logVoidCharge = YFCLogCategory
			.instance(KohlsVoidChargeTransaction.class.getName());
	boolean isCarryLineTotalZero = false;

	public Document processVoidChargeTransaction(YFSEnvironment env, Document inDoc) {
		try {
			logVoidCharge.beginTimer("KohlsVoidChargeTransaction.processVoidChargeTransaction - Begin Timer");
			if (logVoidCharge.isDebugEnabled()) {
				logVoidCharge.debug("The input XML to KohlsVoidChargeTransaction.processVoidChargeTransaction - "
						+ KohlsXMLUtil.getXMLString(inDoc));
			}
			Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
			String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);
			String invAsyncPosting = omni2ConfigMap.get("INV_ASYNC_POSTING");
			if (KohlsPOCConstant.YES.equals(omni2Enabled)) {
				String carryLineTotal = "";
				double dblCarryLineTotal = 0;
				double finalLineTotal = 0;
				String orderHeaderKey = inDoc.getDocumentElement().getAttribute(KohlsConstants.ORDER_HEADER_KEY);
				NodeList orderLineList = inDoc.getDocumentElement().getElementsByTagName(KohlsConstants.ORDER_LINE);
				Document createOrderInvoice = XMLUtil.createDocument(KohlsConstants.ORDER);
				Element eleOrderInvoice = createOrderInvoice.getDocumentElement();
				eleOrderInvoice.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
				eleOrderInvoice.setAttribute(KohlsPOCConstant.A_LIGHT_INVOICE, KohlsPOCConstant.YES);
				eleOrderInvoice.setAttribute(KohlsPOCConstant.A_TRANSACTION_ID,
						KohlsPOCConstant.CREATE_INVOICE_TRANSACTION);
				eleOrderInvoice.setAttribute(KohlsPOCConstant.ATTR_IGNORE_STATUS_CHECK, KohlsPOCConstant.YES);
				Element eleOrderLines = XMLUtil.createChild(eleOrderInvoice, KohlsPOCConstant.ELEM_ORDER_LINES);
				Document orderStatusChange = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_STATUS_CHANGE);
				Element eleOrderStatus = orderStatusChange.getDocumentElement();
				eleOrderStatus.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
				eleOrderStatus.setAttribute(KohlsPOCConstant.A_TRANSACTION_ID,
						KohlsPOCConstant.TRANSACTION_POS_CHANGE_ORDER_STATUS);
				Element eleOrderLinesStatus = XMLUtil.createChild(eleOrderStatus, KohlsPOCConstant.ELEM_ORDER_LINES);
				int orderlineLength = orderLineList.getLength();
				Boolean isCarry = false;
				for (int count = 0; count < orderlineLength; count++) {
					Element eleOrderLine = (Element) orderLineList.item(count);
					String primeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
					String subLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO);
					String Qty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
					String deliverMethod = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_DELIVERY_METHOD);
					if (KohlsPOCConstant.ATTR_DELIVERY_TYPE_CARRY.equalsIgnoreCase(deliverMethod)) {
						Element newEleOrderLine = XMLUtil.createChild(eleOrderLines, KohlsConstants.ORDER_LINE);
						newEleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, primeLineNo);
						newEleOrderLine.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO, subLineNo);
						newEleOrderLine.setAttribute(KohlsPOCConstant.A_QUANTITY, Qty);
						Element newEleOrderLineStatus = XMLUtil.createChild(eleOrderLinesStatus,
								KohlsConstants.ORDER_LINE);
						newEleOrderLineStatus.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, primeLineNo);
						newEleOrderLineStatus.setAttribute(KohlsPOCConstant.ATTR_SUB_LINE_NO, subLineNo);
						newEleOrderLineStatus.setAttribute(KohlsPOCConstant.E_BASE_DROP_STATUS,
								KohlsPOCConstant.STORE_ORDER_INVOICED_STATUS);
						newEleOrderLineStatus.setAttribute(KohlsPOCConstant.ATTR_CHANGE_FOR_ALL_AVAILABLE_QTY,
								KohlsPOCConstant.YES);
						Element eleLineOverallTotals = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_OVERALL_TOTALS).item(0);
						dblCarryLineTotal = Double.parseDouble(eleLineOverallTotals.getAttribute(KohlsXMLLiterals.A_LINE_TOTAL));
						finalLineTotal = finalLineTotal + dblCarryLineTotal;
						isCarry = true;
					}
				}
				
				if(0.0 == finalLineTotal) {
					isCarryLineTotalZero = true;
				}

				Document outGetChargeTransaction = callGetChargeTransactionList(env, orderHeaderKey);
				NodeList ndlstChargeTransaction = SCXmlUtil.getXpathNodes(outGetChargeTransaction.getDocumentElement(),
						KohlsPOCConstant.XPATH_CHARGE_TYPE_CHARGE);
				int nodeLength = ndlstChargeTransaction.getLength();
				ArrayList<String> paymentKeyList = new ArrayList<String>();
				for (int count = 0; count < nodeLength; count++) {
					Element eleChargeTransactionDetail = (Element) ndlstChargeTransaction.item(count);
					Element eleCreditCardTransactions = XMLUtil.getChildElement(eleChargeTransactionDetail,
							KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTIONS);
					Element eleCreditCardTransaction = XMLUtil.getChildElement(eleCreditCardTransactions,
							KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTION);
					Element elePaymentType = XMLUtil.getChildElement(eleChargeTransactionDetail,
							KohlsXMLLiterals.E_PAYMENT_METHOD);
					String suspendForAnyMoreCharge = elePaymentType
							.getAttribute(KohlsXMLLiterals.A_SUSPEND_ANY_MORE_CHARGES);
					if (!YFCCommon.isVoid(eleCreditCardTransaction) && !KohlsPOCConstant.YES.equals(suspendForAnyMoreCharge)) {
						voidChargeTransaction(env, eleChargeTransactionDetail);
						recordExternalCharges(env, inDoc, orderHeaderKey, eleChargeTransactionDetail,
								paymentKeyList, omni2ConfigMap, isCarry);
					}
				}
				if (isCarry && "Y".equals (invAsyncPosting)) {
					env.setTxnObject("IsCarryLine", "Y");
				}
				else if(isCarry && (YFCCommon.isVoid(invAsyncPosting) || "N".equals (invAsyncPosting)))
				{
					KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CREATE_ORDER_INVOICE, createOrderInvoice);
					KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER_STATUS, orderStatusChange);
				}
				applyOmniHold(env, orderHeaderKey, inDoc, paymentKeyList);
			} 
		} catch (Exception ex) {
			logVoidCharge.error(ex);
			throw new YFCException("Error thrown creating invoice for carry lines " + ex);
		}
		logVoidCharge.endTimer("KohlsVoidChargeTransaction.evenExchange - End Timer");
		return inDoc;
	}

	private Document callGetChargeTransactionList(YFSEnvironment env, String orderHeaderKey) {
		try {
			logVoidCharge.beginTimer("KohlsVoidChargeTransaction.callGetChargeTransactionList - Begin Timer");
			if (YFCLogUtil.isDebugEnabled()) {
				logVoidCharge.debug(
						"The input XML to KohlsVoidChargeTransaction.callGetChargeTransactionList -OrderHeaderKey "
								+ orderHeaderKey);
			}
			Document getChargeTransactionListDoc = XMLUtil
					.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
			Element eleChargeTransactionDetail = getChargeTransactionListDoc.getDocumentElement();
			eleChargeTransactionDetail.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			eleChargeTransactionDetail.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE,
					KohlsPOCConstant.CHARGE_TYPE_CHARGE);
			Document outChargeTransaction = KOHLSBaseApi.invokeAPI(env,
					KohlsPOCConstant.TEMPLATE_GET_CHARGE_TRANSACTION_LIST,
					KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, getChargeTransactionListDoc);
			logVoidCharge.endTimer("KohlsVoidChargeTransaction:: callGetChargeTransactionList - End Timer");
			return outChargeTransaction;
		} catch (Exception ex) {
			logVoidCharge.error(ex);
			throw new YFCException("Error thrown creating invoice for carry lines " + ex);
		}
	}

	/**
	 * This method is responsible for voiding the charge where chargeType is
	 * "CHARGE" And Status of that chargeType is "closed"
	 * 
	 * @param env
	 * @param eleChargeTransactionDetail
	 */

	private void voidChargeTransaction(YFSEnvironment env, Element eleChargeTransactionDetail) {
		try {
			logVoidCharge.beginTimer("KohlsVoidChargeTransaction::voidChargeTransaction - BeginTimer");

			if (YFCLogUtil.isDebugEnabled()) {
				logVoidCharge.debug("The input XML to KohlsVoidChargeTransaction.voidChargeTransaction - "
						+ KohlsXMLUtil.getElementXMLString(eleChargeTransactionDetail));
			}
			String chargeTrnsactionKey = eleChargeTransactionDetail
					.getAttribute(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_KEY);
			Document voidTransactionDoc = XMLUtil.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
			Element eleVoidTransactions = voidTransactionDoc.getDocumentElement();
			Element eleVoidTransaction = XMLUtil.createChild(eleVoidTransactions,
					KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
			eleVoidTransaction.setAttribute(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_KEY, chargeTrnsactionKey);
			KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_VOID_CHARGE_TRANSACTION, voidTransactionDoc);

		} catch (Exception ex) {
			logVoidCharge.error(ex);
			throw new YFCException("Error thrown while voinding the charge transaction " + ex);
		}
		logVoidCharge.endTimer("KohlsVoidChargeTransaction:: voidChargeTransaction - End Timer");
	}

	/**
	 * This method is responsible for recording the external charge with ChargeType
	 * as AUTHORIZATION
	 * 
	 * @param env
	 * @param orderDoc
	 * @param carryTotal
	 * @param orderHeaderKey
	 * @param eleChargeTransactionDetail
	 * @param isCarry
	 * @throws paymentKeyLst
	 */ 

	private void recordExternalCharges(YFSEnvironment env, Document orderDoc, String orderHeaderKey,
			Element eleChargeTransactionDetail, ArrayList<String> paymentKeyLst, Map<String, String> omni2ConfigMap,
			boolean isCarry) {
		try {

			logVoidCharge.beginTimer("KohlsVoidChargeTransaction::recordExternalCharges - BeginTimer");

			if (YFCLogUtil.isDebugEnabled()) {
				logVoidCharge.debug("The input XML to KohlsVoidChargeTransaction.recordExternalCharges - "
						+ KohlsXMLUtil.getElementXMLString(eleChargeTransactionDetail));
			}
			String orderNo = orderDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
			Element eleOrderDoc = orderDoc.getDocumentElement();
			Document recordExternalChargesDoc = XMLUtil.createDocument(KohlsXMLLiterals.E_RECORD_EXTERNAL_CHARGES);
			Element eleRecordExternalCharges = recordExternalChargesDoc.getDocumentElement();
			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_CLIENT_ID,
					eleOrderDoc.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
			eleRecordExternalCharges.setAttribute(KohlsPOCConstant.A_DISPLAY_LOCALIZED_FIELD_IN_LOCALE,
					KohlsPOCConstant.LOCALE_STRING);
			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE,
					eleOrderDoc.getAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE));
			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE,
					eleOrderDoc.getAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE));
			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_OPERATOR_ID,
					eleOrderDoc.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID));
			eleRecordExternalCharges.setAttribute(KohlsXMLLiterals.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
			eleRecordExternalCharges.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			eleRecordExternalCharges.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, orderNo);
			eleRecordExternalCharges.setAttribute(KohlsPOCConstant.A_DISPLAY_LOCALIZED_FIELD_IN_LOCALE,
					KohlsPOCConstant.LOCALE_STRING);
			Element elePaymentMethod = recordExternalChargesDoc.createElement(KohlsXMLLiterals.E_PAYMENT_METHOD);
			Element elePaymentDetailsList = recordExternalChargesDoc
					.createElement(KohlsXMLLiterals.E_PAYMENT_DETAILS_LIST);
			Element elePaymentDetails = recordExternalChargesDoc.createElement(KohlsXMLLiterals.E_PAYMENT_DETAILS);

			eleRecordExternalCharges.appendChild(elePaymentMethod);
			elePaymentMethod.appendChild(elePaymentDetailsList);
			elePaymentDetailsList.appendChild(elePaymentDetails);

			Element elePaymentType = XMLUtil.getChildElement(eleChargeTransactionDetail,
					KohlsXMLLiterals.E_PAYMENT_METHOD);
			String paymentKey = elePaymentType.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY);
			paymentKeyLst.add(paymentKey);
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_KEY, paymentKey);
			elePaymentMethod.setAttribute(KohlsPOCConstant.A_ACCOUNT_TYPE,
					elePaymentType.getAttribute(KohlsPOCConstant.A_ACCOUNT_TYPE));
			elePaymentMethod.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY,
					elePaymentType.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_DISP_CREDIT_CARD_NO,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_DISP_CREDIT_CARD_NO));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_DISP_PAYMENT_REF_1,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_DISP_PAYMENT_REF_1));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_MAX_CHARGE_LIMIT,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_MAX_CHARGE_LIMIT));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_ENTRY_METHOD,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_ENTRY_METHOD));
			elePaymentMethod.setAttribute(KohlsPOCConstant.A_EXTRA_DETAILS_9,
					elePaymentType.getAttribute(KohlsPOCConstant.A_EXTRA_DETAILS_9));
			elePaymentMethod.setAttribute(KohlsPOCConstant.A_EXTRA_DETAILS_10,
					elePaymentType.getAttribute(KohlsPOCConstant.A_EXTRA_DETAILS_10));

			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2));
			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_3,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_3));

			elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,
					elePaymentType.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE));
			elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID,
					elePaymentType.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID));
			elePaymentMethod.setAttribute(KohlsPOCConstant.STORE_ID,
					elePaymentType.getAttribute(KohlsPOCConstant.STORE_ID));
			elePaymentMethod.setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
					eleOrderDoc.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
			// Add
			elePaymentMethod.setAttribute(KohlsPOCConstant.A_IS_EXTERNAL_PAYMENT, KohlsPOCConstant.YES);

			elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TILL_ID,
					elePaymentType.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));

			String authID = omni2ConfigMap.get(KohlsXMLLiterals.A_AUTHORIZATION_ID);
			String paymentType = elePaymentType.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
			if (!YFCObject.isVoid(paymentType)) {
				Element eleCreditCardTransactions = XMLUtil.getChildElement(eleChargeTransactionDetail,
						KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTIONS);
				Element eleCreditCardTransaction = XMLUtil.getChildElement(eleCreditCardTransactions,
						KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTION);
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_CODE,
						eleCreditCardTransaction.getAttribute(KohlsXMLLiterals.A_AUTH_CODE));
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE,
						eleCreditCardTransaction.getAttribute(KohlsXMLLiterals.A_AUTH_RETURN_CODE));
				elePaymentDetails.setAttribute(KohlsPOCConstant.A_AUTH_RETURN_FLAG,
						eleCreditCardTransaction.getAttribute(KohlsPOCConstant.A_AUTH_RETURN_FLAG));
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_RETURN_MESSAGE,
						eleCreditCardTransaction.getAttribute(KohlsXMLLiterals.A_AUTH_RETURN_MESSAGE));
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_TIME,
						eleCreditCardTransaction.getAttribute(KohlsXMLLiterals.A_AUTH_TIME));
				// Add AuthWindow value from common code to current system date
				DateFormat formatter = new SimpleDateFormat(KohlsPOCConstant.A_TIME_FORMAT);
				String setAuthorixationExpDate = "";
				String authWindow = omni2ConfigMap.get(KohlsPOCConstant.A_AUTH_WINDOW_COMMON_CODE_VALUE);
				int x = Integer.parseInt(authWindow);
				if (isCarry && !isCarryLineTotalZero) {
					String authTimeFromAjb = eleCreditCardTransaction.getAttribute(KohlsXMLLiterals.A_AUTH_TIME);
					// AuthTime="2018-05-22T06:09:33-05:00"

					Date date = formatter.parse(authTimeFromAjb);
					/*
					 * Add authWindow x hours to the server date
					 */
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date);
					calendar.add(Calendar.HOUR, x);
					setAuthorixationExpDate = formatter.format(calendar.getTime());
				} else {
					//Fix done as part of CPE-11483 for POP API call from OMSE end running
					//into issues with currentDate and time. Stamping AuthExpiration date as currentDate-24Hrs 
					Date date = new Date();
					/*
					 * Reduce authWindow x hours from server date
					 */
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date);
					calendar.add(Calendar.HOUR, -x);
					setAuthorixationExpDate = formatter.format(calendar.getTime());
				}
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTH_EXPIRY_DATE, setAuthorixationExpDate);
				if (YFCCommon.isVoid(authID)) {
					String actualAuthId = eleChargeTransactionDetail.getAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID);
					authID = actualAuthId.substring(4, actualAuthId.length());
				}
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID, authID);
				elePaymentDetails.setAttribute(KohlsPOCConstant.A_CVV_AUTH_CODE,
						eleCreditCardTransaction.getAttribute(KohlsPOCConstant.A_CVV_AUTH_CODE));
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_SEQ,
						elePaymentType.getAttribute(KohlsXMLLiterals.A_CHARGE_SEQ));
				elePaymentDetails.setAttribute(KohlsXMLLiterals.A_INTERNAL_RETURN_CODE,
						eleCreditCardTransaction.getAttribute(KohlsXMLLiterals.A_INTERNAL_RETURN_CODE));
				Element elePersonInfoBillInDoc = XMLUtil.getChildElement(orderDoc.getDocumentElement(),
						KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
				Element eleInput = XMLUtil.createChild(elePaymentMethod, KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
				XMLUtil.importElement(eleInput, elePersonInfoBillInDoc);
			}

			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE, KohlsPOCConstant.CHARGE_TYPE_AUTH);
			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_IN_PERSON,
					eleChargeTransactionDetail.getAttribute(KohlsXMLLiterals.A_IN_PERSON));
			String reqAmtofVoid = eleChargeTransactionDetail.getAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT);
			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, reqAmtofVoid);
			elePaymentDetails.setAttribute(KohlsXMLLiterals.A_PROCESSED_AMOUNT, reqAmtofVoid);
			KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.API_RECORD_EXTERNAL_CHARGES, recordExternalChargesDoc);
		} catch (Exception ex) {
			logVoidCharge.error(ex);
			throw new YFCException("Error thrown while recording charge type as AUTHORIZATION " + ex);
		}
		logVoidCharge.endTimer("KohlsVoidChargeTransaction:: recordExternalCharges - End Timer");
	}

	/**
	 * Logic to apply omni hold
	 * 
	 * @param env
	 * @param orderHeaderKey
	 */

	private void applyOmniHold(YFSEnvironment env, String orderHeaderKey, Document inDoc,
			ArrayList<String> paymentKeyList) {
		try {
			logVoidCharge.beginTimer("KohlsVoidChargeTransaction.applyOmniHold - Begin Timer");
			if (YFCLogUtil.isDebugEnabled()) {
				logVoidCharge.debug("The input XML to KohlsVoidChargeTransaction.applyOmniHold -"
						+ KohlsXMLUtil.getXMLString(inDoc));
			}
			Document changeOrder = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			Element eleChangeOrder = changeOrder.getDocumentElement();
			eleChangeOrder.setAttribute(KohlsConstants.ORDER_HEADER_KEY, orderHeaderKey);
			Element elelOrderHoldTypes = XMLUtil.createChild(eleChangeOrder, KohlsXMLLiterals.E_ORDER_HOLD_TYPES);
			Element elelOrderHoldType = XMLUtil.createChild(elelOrderHoldTypes, KohlsXMLLiterals.E_ORDER_HOLD_TYPE);
			Element elelPOPHoldType = XMLUtil.createChild(elelOrderHoldTypes, KohlsXMLLiterals.E_ORDER_HOLD_TYPE);
			elelOrderHoldType.setAttribute(KohlsXMLLiterals.A_HOLD_TYPE, "OMNI_HOLD");
			elelOrderHoldType.setAttribute(KohlsXMLLiterals.A_REASON, "Its an Omni Order");
			elelOrderHoldType.setAttribute(KohlsXMLLiterals.E_STATUS, KohlsPOCConstant.SHIPMENT_CREATED_STATUS);
			elelPOPHoldType.setAttribute(KohlsXMLLiterals.A_HOLD_TYPE, "POP_HOLD");
			elelPOPHoldType.setAttribute(KohlsXMLLiterals.A_REASON, "Its an POP hold Order");
			elelPOPHoldType.setAttribute(KohlsXMLLiterals.E_STATUS, KohlsPOCConstant.SHIPMENT_CREATED_STATUS);
			KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, changeOrder);
		} catch (Exception ex) {
			logVoidCharge.error(ex);
			throw new YFCException("Error thrown while applying omni hold " +ex);
		}
		logVoidCharge.endTimer("KohlsVoidChargeTransaction:: applyOmniHold - End Timer");
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
	}
	
	// Adding for OrderHeaderKey to be posted to MQ. If failed, post to KohlsReprocess table
	public void postOrderForPOP(YFSEnvironment env, Document inDoc) throws Exception {
		logVoidCharge.beginTimer("PostOrderForPOP - Begin Timer");
		if (logVoidCharge.isDebugEnabled()) {
			logVoidCharge.debug("The input XML to postOrderForPOP - " + KohlsXMLUtil.getXMLString(inDoc));
		}

		try {
			KOHLSBaseApi.invokeService(env,KohlsPOCConstant.A_SERVICE_POP, inDoc);
		} catch (Exception ex) {
			logVoidCharge.debug("Inside catch block XML to postOrderForPOP. XML would be posted to KohlsReprocess table " + KohlsXMLUtil.getXMLString(inDoc));
			KOHLSBaseApi.invokeService(env,KohlsPOCConstant.A_SERVICE_REPROCESS_POP, inDoc);
		}

		logVoidCharge.endTimer("PostOrderForPOP - End Timer");
	}
}
