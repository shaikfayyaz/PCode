package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPOCOpenPickUpStoreRegister extends KOHLSBaseApi{

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPOCOpenPickUpStoreRegister.class.getName());

	/**
	 * @param env
	 * @param inDoc
	 */
	public Document  verifyAndOpenRegister(YFSEnvironment env, Document inDoc) {
		logger.beginTimer("KohlsPOCOpenPickUpStoreRegister.verifyAndOpenStoreNRegister");
		if(logger.isDebugEnabled()) {
			logger.debug("KohlsPOCOpenPickUpStoreRegister inDoc: "+XMLUtil.getXMLString(inDoc));
		}
		
		Element invHeaderEle = (Element) inDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ATTR_INVOICE_HEADER).item(0);
		Element extnEle = (Element) invHeaderEle.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
		if(extnEle.hasAttribute(KohlsXMLLiterals.A_EXTN_OCF)) {
			String extnOCF = extnEle.getAttribute(KohlsXMLLiterals.A_EXTN_OCF);
			if("BPS".equalsIgnoreCase(extnOCF)) {
				String extnReceiptID = extnEle.getAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);
				String currentStore = "";
				String terminalID = "";
				logger.debug("Pick Invoice extnReceiptID: "+extnReceiptID);
				
				if(!YFCCommon.isVoid(extnReceiptID)) {
					extnReceiptID = extnReceiptID.substring(extnReceiptID.length()-10, extnReceiptID.length());
					currentStore = extnReceiptID.substring(0,4);
					int storeLength = currentStore.length();
					if(4==storeLength) {
						currentStore = currentStore.replaceFirst("^0+(?!$)", "");
					}
					terminalID = extnReceiptID.substring(4,6);
				}else {
					//proceeding with default terminal id.
					String extnShipNode = extnEle.getAttribute(KohlsPOCConstant.ATTR_EXTN_SHIP_NODE);
					currentStore = extnShipNode;
					terminalID = "90";
				}
				//Checking  if register is already open.
				String currentRegisterStatus = getRegisterStatus(env,currentStore,terminalID);
				if(KohlsPOCConstant.OPEN.equalsIgnoreCase(currentRegisterStatus)) {
					logger.debug("Register "+terminalID+" is already open for store "+currentStore);
				}else {
					env.setTxnObject("PickStoreRegisterOpen", "Y");
					openRegister(env, currentStore, terminalID);
				}
			}else {
				return inDoc;
			}
		}
		logger.endTimer("KohlsPOCOpenPickUpStoreRegister.verifyAndOpenStoreNRegister");
		return inDoc;
	}

	/**
	 * @param env
	 * @param currentStore
	 * @param terminalID
	 * @return
	 */
	private void openRegister(YFSEnvironment env, String currentStore, String terminalID) {
		logger.beginTimer("KohlsPOCOpenPickUpStoreRegister.openRegister");
		try {
			verifyNOpenStore(env,currentStore);
			Document openTillForAccountingForPOSInputDoc = SCXmlUtil.createDocument("OpenTillForAccountingForPOS");
			Element openTillForAccountingForPOSEle = openTillForAccountingForPOSInputDoc.getDocumentElement();
			openTillForAccountingForPOSEle.setAttribute(KohlsPOCConstant.A_TERMINAL_ID, terminalID);
			openTillForAccountingForPOSEle.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, "admin");
			openTillForAccountingForPOSEle.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, currentStore);
			openTillForAccountingForPOSEle.setAttribute(KohlsPOCConstant.A_TERMINAL_TYPE, "kohls");
			openTillForAccountingForPOSEle.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, "1");
			Document outDocOpenTillForAccountingForPOS;
			
			if(logger.isDebugEnabled()) {
				logger.debug("Input of openTillForAccountingForPOS: "+XMLUtil.getXMLString(openTillForAccountingForPOSInputDoc));
			}

			outDocOpenTillForAccountingForPOS = invokeAPI(env, "openTillForAccountingForPOS", openTillForAccountingForPOSInputDoc);
			if(logger.isDebugEnabled() && !YFCCommon.isVoid(outDocOpenTillForAccountingForPOS)) {
				logger.debug("Output of openTillForAccountingForPOS: "+XMLUtil.getXMLString(outDocOpenTillForAccountingForPOS));
			}
			if (!YFCCommon.isVoid(outDocOpenTillForAccountingForPOS)) {
				NodeList tillStatusNodeList = outDocOpenTillForAccountingForPOS.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS);
				if(tillStatusNodeList.getLength()>0) {
					Element tillStatusEle = (Element) tillStatusNodeList.item(0);
					if (!YFCCommon.isVoid(tillStatusEle)) {
						String businessDay = tillStatusEle.getAttribute("BusinessDay");
						String tillID = tillStatusEle.getAttribute("TillID");
						String drawerID = tillStatusEle.getAttribute("DrawerID");
						logger.debug("Register opened for Store="+currentStore+" TerminalID="+terminalID+" TillID="+tillID+" DrawerID="+drawerID+" BusinessDay="+businessDay);
					}		
				}
			}
		} catch (Exception ex) {
			throw new YFSException(ex.getMessage());
		}
		logger.endTimer("KohlsPOCOpenPickUpStoreRegister.openRegister");
	}

	/**
	 * verify and open store
	 * 
	 * @param docGetCurrentTillStatusListForPOS_Output
	 * @return
	 * @throws Exception
	 */
	private void verifyNOpenStore(YFSEnvironment env, String sCurrentStore) throws Exception {
		logger.beginTimer("KohlsPOCOpenPickUpStoreRegister.verifyAndOpenStore");
		// <AccountingPeriod OrganizationCode="Required"/>
		// <AccountingPeriod AccountingPeriodKey="" BusinessDay="" CloseDateTime="" CurrentPeriod=""
		// OpenDateTime="" OrganizationCode="" Status="Open"
		// SyncID=""/>

		String strIsStoreOpen = "Close";
		String strStoreBusinessDayToOpen = KohlsDateUtil.getCurrentDateTime("yyyy-MM-dd");
		// call getCurrentAccountingperiodforpos
		Document inDocGetCurrentAccountingperiodforpos = SCXmlUtil.createDocument("AccountingPeriod");
		Element eleGetCurrentAccountingperiodforpos =
				inDocGetCurrentAccountingperiodforpos.getDocumentElement();
		eleGetCurrentAccountingperiodforpos.setAttribute("OrganizationCode", sCurrentStore);
		if(logger.isDebugEnabled()) {
			logger.debug("Input of getCurrentAccountingPeriodForPOS: "+XMLUtil.getXMLString(inDocGetCurrentAccountingperiodforpos));
		}
		
		Document outDocGetCurrentAccountingperiodforpos =
				invokeAPI(env, "getCurrentAccountingPeriodForPOS", inDocGetCurrentAccountingperiodforpos);

		if (!YFCCommon.isVoid(outDocGetCurrentAccountingperiodforpos) && logger.isDebugEnabled()) {
			logger.debug("Output of getCurrentAccountingPeriodForPOS: "+XMLUtil.getXMLString(outDocGetCurrentAccountingperiodforpos));
			strIsStoreOpen =
					outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("Status");
			strStoreBusinessDayToOpen = 
					outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("BusinessDay");
		}

		//Added for unOperated Store     
		if (!YFCCommon.isVoid(strIsStoreOpen) && !strIsStoreOpen.equals("Open") || strIsStoreOpen.length()==0) {
			// call StoreOpenForAccountingForPOS
			Document inDocStoreOpenForAccountingForPOS = SCXmlUtil.createDocument("StoreOpenForAccountingForPOS");
			Element eleStoreOpenForAccountingForPOS = inDocStoreOpenForAccountingForPOS.getDocumentElement();
			eleStoreOpenForAccountingForPOS.setAttribute("BusinessDay", strStoreBusinessDayToOpen);
			eleStoreOpenForAccountingForPOS.setAttribute("OperatorID", "admin");// TBD
			eleStoreOpenForAccountingForPOS.setAttribute("OrganizationCode", sCurrentStore);
			if(logger.isDebugEnabled()) {
				logger.debug("Input of storeOpenForAccountingForPOS: "+XMLUtil.getXMLString(inDocStoreOpenForAccountingForPOS));
			}
			Document onDocStoreOpenForAccountingForPOS = invokeAPI(env, "storeOpenForAccountingForPOS", inDocStoreOpenForAccountingForPOS);
			if(logger.isDebugEnabled() && !YFCCommon.isVoid(onDocStoreOpenForAccountingForPOS)) {
				logger.debug("Output of storeOpenForAccountingForPOS: "+XMLUtil.getXMLString(onDocStoreOpenForAccountingForPOS));
			}
		}
		logger.endTimer("KohlsPOCOpenPickUpStoreRegister.verifyNOpenStore");
	}

	/**
	 * @param env
	 * @param currentStore
	 * @param terminalID
	 * @return
	 */
	private String  getRegisterStatus(YFSEnvironment env, String currentStore, String terminalID) {
		logger.beginTimer("KohlsPOCOpenPickUpStoreRegister.getRegisterStatus");
		String currentStatus = null;

		Document getCurrentTillStatusListForPOSInputDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
		getCurrentTillStatusListForPOSInputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,currentStore);
		getCurrentTillStatusListForPOSInputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_TERMINAL_ID,terminalID);

		try {
			if(logger.isDebugEnabled()) {
				logger.debug("Input of getCurrentTillStatusForPOS : "+XMLUtil.getXMLString(getCurrentTillStatusListForPOSInputDoc));
			}
			Document getCurrentTillStatusListForPOSOutputDoc = invokeAPI(env, "getCurrentTillStatusForPOS", getCurrentTillStatusListForPOSInputDoc);
			if(!YFCCommon.isVoid(getCurrentTillStatusListForPOSOutputDoc)) {
				if(logger.isDebugEnabled()) {
					logger.debug("Output of getCurrentTillStatusForPOS : "+XMLUtil.getXMLString(getCurrentTillStatusListForPOSOutputDoc));
				}
				Element tillStatusEle = getCurrentTillStatusListForPOSOutputDoc.getDocumentElement();

				if(tillStatusEle.hasAttribute(KohlsPOCConstant.A_CURRENT_STATUS)) {
					currentStatus = tillStatusEle.getAttribute(KohlsPOCConstant.A_CURRENT_STATUS);
				}
			}
		} catch (Exception ex) {
			throw new YFSException(ex.getMessage());
		}
		logger.endTimer("KohlsPOCOpenPickUpStoreRegister.getRegisterStatus");
		return currentStatus;
	}

}
