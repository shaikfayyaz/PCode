package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.tgcs.tcx.gravity.pos.order.hangoff.AbstractOrderHangOff;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPOCHangOffSync extends AbstractOrderHangOff{

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPOCHangOffSync.class);

	/*
	 * (non-Javadoc)
	 * @see com.tgcs.tcx.gravity.pos.order.hangoff.AbstractOrderHangOff#extract(com.yantra.yfc.dom.YFCDocument, com.yantra.yfs.japi.YFSEnvironment)
	 * 
	 * extract Method fetch the records from kohlsPaymentExtension table of Instore server by calling getKohlsPaymentExtensionList and returns the same.
	 */

	@Override
	public YFCDocument extract(YFCDocument inDoc, YFSEnvironment env) throws Exception {
		String orderHeaderKey=null;
		Document inputDoc=null;
		Document outputDoc=null;
		
		
		if(logger.isDebugEnabled())
			logger.debug("Document to extract method of HangOffSync class:" + XMLUtil.getXMLString(inDoc.getDocument()));

		orderHeaderKey=inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		logger.debug("orderHeaderKey in HangOffSync.extract method:" + orderHeaderKey);
		if(orderHeaderKey!=null)
		{
			try{
				inputDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KOHLS_PAYMENT_EXTENSION).getDocument();
				inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
				
				
				if(logger.isDebugEnabled())
					logger.debug("Input document of getKohlsPaymentExtensionList API :" + XMLUtil.getXMLString(inputDoc));

				outputDoc=KOHLSBaseApi.invokeService(env, KohlsPOCConstant.API_GET_KHOLS_PAYMENT_EXTENSION, inputDoc);
				if(outputDoc!=null)
				{
					
					if(logger.isDebugEnabled())
						logger.debug("output document of getKohlsPaymentExtensionList API :" + XMLUtil.getXMLString(outputDoc));
					outputDoc=stampCardNoForHangOff(outputDoc,inDoc);
					return YFCDocument.getDocumentFor(outputDoc);

				}
			}
			catch (Exception e)
			{
				logger.error("Exception occurred while fetching the records from the  Khols Payment Extension table:" + e.toString());
				throw e;
			}

		}
		return null;


	}
	/*
	 * (non-Javadoc)
	 * @see com.tgcs.tcx.gravity.pos.order.hangoff.AbstractOrderHangOff#load(com.yantra.yfc.dom.YFCDocument, com.yantra.yfc.dom.YFCDocument, com.yantra.yfc.dom.YFCDocument, com.yantra.yfs.japi.YFSEnvironment)
	 * load Method inserts record to kohlsPaymentExtension table of corporate server by calling manageKohlsPaymentExtension.
	 */



	@Override
	public void load(YFCDocument oldOrderDoc, YFCDocument newOrderDoc, YFCDocument	hangOffDoc, YFSEnvironment env) throws Exception {
		logger.debug("Inside load method of KohlsPOCHangOffSync");

		if(!YFCObject.isVoid(oldOrderDoc) && !YFCObject.isVoid(newOrderDoc) && !YFCObject.isVoid(hangOffDoc)) {
			
			
			if(logger.isDebugEnabled()){
				logger.debug("Old Order Document to Load method of HangOffSync class:" + XMLUtil.getXMLString(oldOrderDoc.getDocument()));			
				logger.debug("New Order Document to Load method of HangOffSync class:" + XMLUtil.getXMLString(newOrderDoc.getDocument()));			
				logger.debug("Hangoff Table Document to Load method of HangOffSync class:" + XMLUtil.getXMLString(hangOffDoc.getDocument()));	
				logger.debug("Modified for Hangoff sync:" + XMLUtil.getXMLString(oldOrderDoc.getDocument()));
			}


			NodeList paymentMethodsInstore=null;
			NodeList paymentMethodsCorporate=null;
			NodeList kohlsHangOffPaymentList=null;

			Document inputDocToApi=null;

			Element paymentNode=null;
			Element paymentElementOfCorp=null;

			String paymentKey=null;
			String corpOrderHeaderKey=null;
			String paymentType=null;




			paymentMethodsInstore= KohlsXPathUtil.getNodeList(oldOrderDoc.getDocument(), "Order/PaymentMethods/PaymentMethod");
			paymentMethodsCorporate= KohlsXPathUtil.getNodeList(newOrderDoc.getDocument(), "Order/PaymentMethods/PaymentMethod");
			corpOrderHeaderKey=newOrderDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			kohlsHangOffPaymentList=KohlsXPathUtil.getNodeList(hangOffDoc.getDocument(), "//KohlsPaymentExtension");

			if(kohlsHangOffPaymentList != null && kohlsHangOffPaymentList.getLength()>0) {	
				if(paymentMethodsInstore != null && paymentMethodsInstore.getLength() > 0){
					if(paymentMethodsCorporate != null && paymentMethodsCorporate.getLength() > 0){			
						if(paymentMethodsInstore.getLength()==paymentMethodsCorporate.getLength()) {
							for(int i=0;i<kohlsHangOffPaymentList.getLength();i++)
							{

								paymentNode=(Element)kohlsHangOffPaymentList.item(i);

								paymentType=paymentNode.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);

								logger.debug("paymentType ::::::::***:" + paymentType);


								if(paymentNode.getAttribute("SvcNo")!=null && paymentNode.getAttribute("SvcNo").length()>0)
								{

									paymentElementOfCorp=KohlsXPathUtil.getElementByXpath(newOrderDoc.getDocument(), "Order/PaymentMethods/PaymentMethod[@PaymentType='"+paymentType+"' and @SvcNo='"+paymentNode.getAttribute("SvcNo")+"' ]");

									paymentNode.removeAttribute("SvcNo");
								}
								else if(paymentNode.getAttribute("CreditCardNo")!=null && paymentNode.getAttribute("CreditCardNo").length()>0)
								{
									paymentElementOfCorp=KohlsXPathUtil.getElementByXpath(newOrderDoc.getDocument(), "Order/PaymentMethods/PaymentMethod[@PaymentType='"+paymentType+"' and @CreditCardNo='"+paymentNode.getAttribute("CreditCardNo")+"' ]");
									paymentNode.removeAttribute("CreditCardNo");
								}


								else if(paymentNode.getAttribute("DebitCardNo")!=null && paymentNode.getAttribute("DebitCardNo").length()>0)
								{
									paymentElementOfCorp=KohlsXPathUtil.getElementByXpath(newOrderDoc.getDocument(), "Order/PaymentMethods/PaymentMethod[@PaymentType='"+paymentType+"' and @DebitCardNo='"+paymentNode.getAttribute("DebitCardNo")+"' ]");
									paymentNode.removeAttribute("DebitCardNo");
								}

								if(paymentElementOfCorp!=null)
								{
									paymentKey=paymentElementOfCorp.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);

									logger.debug("PaymentKey ::::::::***:" + paymentKey);

									if(paymentKey!=null)
									{
										inputDocToApi=XMLUtil.getDocumentForElement(paymentNode);
										inputDocToApi.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, corpOrderHeaderKey);
										inputDocToApi.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY, paymentKey);
										inputDocToApi.getDocumentElement().removeAttribute("PaymentExtensionKey");
										
										if(logger.isDebugEnabled())
											logger.debug("Input document of createKohlsPaymentExtension API :" + XMLUtil.getXMLString(inputDocToApi));
										if(inputDocToApi!=null)
										{
											KOHLSBaseApi.invokeService(env, KohlsPOCConstant.API_CREATE_KHOLS_PAYMENT_EXTENSION,inputDocToApi);

										}

									}
								}

							}	
						}
						else {
							throw new Exception("Both Instore and Corporate payment methods are not equal");
						}

					}
				}
			}
		}




	}


	/*
	 * (non-Javadoc)
	 * @see com.tgcs.tcx.gravity.pos.order.hangoff.AbstractOrderHangOff#purge(com.yantra.yfc.dom.YFCDocument, com.yantra.yfs.japi.YFSEnvironment)
	 * purge Method deletes record from kohlsPaymentExtension table of Instore server by calling deleteKohlsPaymentExtension.
	 */

	@Override
	public void purge( YFCDocument inDoc, YFSEnvironment env) throws Exception {
		
		
		if(logger.isDebugEnabled())
			logger.debug("Input Document to purge method of HangOffSync class:" + XMLUtil.getXMLString(inDoc.getDocument()));

		String orderHeaderKey=null;
		Document inputDoc=null;

		orderHeaderKey=inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		inputDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_KOHLS_PAYMENT_EXTENSION).getDocument();
		inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, orderHeaderKey);
		
		
		if(logger.isDebugEnabled())
			logger.debug("Input document of deleteKohlsPaymentExtension API :" + XMLUtil.getXMLString(inputDoc));
		KOHLSBaseApi.invokeService(env, KohlsPOCConstant.API_DELETE_KHOLS_PAYMENT_EXTENSION, inputDoc);


	}

	/**
	 * @param outputDoc
	 * @param inDoc
	 * @return
	 * @throws Exception 
	 */
	private Document stampCardNoForHangOff(Document outputDocOfHangOff, YFCDocument inDocOfOrder) throws Exception {



		NodeList paymentExtensionNodeList=null;

		String paymentkey=null;
		String paymentType=null;
		Element paymentElement=null;

		try {
			paymentExtensionNodeList=KohlsXPathUtil.getNodeList(outputDocOfHangOff, "//KohlsPaymentExtension");

			for(int i=0;i<paymentExtensionNodeList.getLength();i++)
			{
				paymentElement=(Element)paymentExtensionNodeList.item(i);
				paymentkey=paymentElement.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
				paymentType=paymentElement.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);

				if(paymentkey!=null && paymentType!=null)
				{

					if(paymentType.equalsIgnoreCase("GIFT_CARD"))
					{

						paymentElement.setAttribute("SvcNo",KohlsXPathUtil.getElementByXpath(inDocOfOrder.getDocument(), "Order/PaymentMethods/PaymentMethod[@PaymentKey='"+paymentkey+"']").getAttribute("SvcNo"));

					}

					else if(paymentType.equalsIgnoreCase("CREDIT_CARD") || paymentType.equalsIgnoreCase("KOHLS_CHARGE_CARD")  )
					{

						paymentElement.setAttribute("CreditCardNo",KohlsXPathUtil.getElementByXpath(inDocOfOrder.getDocument(), "Order/PaymentMethods/PaymentMethod[@PaymentKey='"+paymentkey+"']").getAttribute("CreditCardNo"));


					}

					else if(paymentType.equalsIgnoreCase("DEBIT_CARD") )
					{

						paymentElement.setAttribute("DebitCardNo",KohlsXPathUtil.getElementByXpath(inDocOfOrder.getDocument(), "Order/PaymentMethods/PaymentMethod[@PaymentKey='"+paymentkey+"']").getAttribute("DebitCardNo"));


					}


				}


			}


		} catch (Exception e) {
			throw new Exception("Error in stampCardNoForHangOff");
		}





		return outputDocOfHangOff;
	}



}



