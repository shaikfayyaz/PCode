package com.kohls.poc.api;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.security.dv.SCEncoder;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsManageOfflineTransactionQForPOS extends KOHLSBaseApi  {
		
		private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsManageOfflineTransactionQForPOS.class.getName());
		
		private static PreparedStatement prepStmt = null;
		private static String tranSchema = "";
		private static Statement stmt = null;
		
		public Document getOfflineTrxQDetails(YFSEnvironment env, Document inDoc) throws Exception {
			logger.info("Beginning getOfflineTrxQDetails with inDoc " + SCXmlUtil.getString(inDoc));
			
			Document docTransactionQListOutput = null; 
			Element eleOfflineTrxQ = null;
			String offlineTrxQKey = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
			if(offlineTrxQKey.contains(KohlsPOCConstant.TRUE)){
				logger.info("inDoc is " + SCXmlUtil.getString(inDoc));
				StringBuffer strBuffer = new StringBuffer(offlineTrxQKey.substring(0, offlineTrxQKey.length()-4));
				inDoc.getDocumentElement().setAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY,strBuffer.toString());
				logger.info("inDoc for getOfflineTransactionQDetails is " + SCXmlUtil.getString(inDoc));
				docTransactionQListOutput = getOfflineTransactionQDetails(env, inDoc, true);
				logger.info("docTransactionQListOutput is " + SCXmlUtil.getString(docTransactionQListOutput));
				eleOfflineTrxQ = SCXmlUtil.getChildElement(docTransactionQListOutput.getDocumentElement(), KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
				
			}else {
				//Call getOfflineTrxQList
				docTransactionQListOutput = getOfflineTransactionQDetails(env, inDoc, false);
				eleOfflineTrxQ = SCXmlUtil.getChildElement(docTransactionQListOutput.getDocumentElement(), KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			}
			Document docOutput = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			if(!YFCObject.isNull(eleOfflineTrxQ)){
			logger.info("eleOfflineTrxQ is " + SCXmlUtil.getString(eleOfflineTrxQ));
			Document docTransactionQOutput = SCXmlUtil.createFromString(SCXmlUtil.getString(eleOfflineTrxQ));
			Element eleOutDoc = docTransactionQOutput.getDocumentElement();
			logger.info("eleOutDoc is " + SCXmlUtil.getString(eleOutDoc));
			String strOperationXML = eleOutDoc.getAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML);
			logger.info("strOperationXML is " + strOperationXML);
			String encodedOut = SCEncoder.getEncoder().encodeForHTMLAttribute(SCXmlUtil.getString(SCXmlUtil.createFromString(strOperationXML)));
			
			logger.debug("encodedOut " + encodedOut );
			eleOutDoc.setAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML, encodedOut);
			
			logger.info("outdoc after encode " + SCXmlUtil.getString(docTransactionQOutput) );
			return docTransactionQOutput;
			}else {
			return docOutput;
			}
		}

		
		public Document updateOfflineTrxQDetails(YFSEnvironment env, Document inDoc) throws Exception {
			logger.info("Beginning updateOfflineTrxQDetails with inDoc " + SCXmlUtil.getString(inDoc));
			
			Document docTransactionQListOutput = null;
			String strHistorySelected = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_CHECK_BOX_HISTORY_SELECTED);
			logger.info("strHistorySelected inside updateOfflineTrxQDetails " + strHistorySelected);
			if(YFCCommon.equals(strHistorySelected, KohlsPOCConstant.TRUE)){
				return docTransactionQListOutput =  deleteFromHistoryAndUpdateInLive(env, inDoc);
			}else{
				//Call getOfflineTrxQList
				 docTransactionQListOutput = getOfflineTransactionQDetails(env, inDoc, false);
			}

			Element eleInDoc = inDoc.getDocumentElement();
			String strOperationXML = eleInDoc.getAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML);
			
			Element eleOfflineTrxQ = SCXmlUtil.getChildElement(docTransactionQListOutput.getDocumentElement(), KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			
			eleOfflineTrxQ.setAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML, strOperationXML);
			eleOfflineTrxQ.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.STRING_ONE);
			eleOfflineTrxQ.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.MANAGE);
			
			Document manageInput = SCXmlUtil.createFromString(SCXmlUtil.getString(eleOfflineTrxQ));
			//Call manageOfflineTrxQ
			logger.debug("Calling manageOfflineTransactionQForPOS api with input " + SCXmlUtil.getString(manageInput));
			Document manageOutput = KohlsCommonUtil.invokeAPI(env,
					KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS,
					manageInput);
			logger.debug("manageOfflineTransactionQForPOS output" + SCXmlUtil.getString(manageOutput));
			
			logger.debug("getList call input" + SCXmlUtil.getString(manageOutput));
			Document outDoc = getOfflineTransactionQDetails(env, manageOutput, false);
			logger.debug("getList call output" + SCXmlUtil.getString(outDoc));
			Element eleOffTrxQ = SCXmlUtil.getChildElement(outDoc.getDocumentElement(), KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			
			Document finalOutDoc = SCXmlUtil.createFromString(SCXmlUtil.getString(eleOffTrxQ));
			logger.info("finalOutDoc call output" + SCXmlUtil.getString(finalOutDoc));
		
			return finalOutDoc;
		}


		/**
		 * This method returns schema name for the pool ID passed in the input argument
		 * @param env
		 * @param poolID
		 * @return
		 * @throws Exception
		 */
		private String getSchemaNameForPoolID(YFSEnvironment env, String poolID) throws Exception {
			logger.info("Get schema name for PoolID started");
			String trxSchema = null;
			Document docIpGetDBPoolList = SCXmlUtil.createDocument(KohlsPOCConstant.DOC_DB_POOL);
			docIpGetDBPoolList.getDocumentElement().setAttribute(KohlsPOCConstant.A_POOL_ID, poolID);
			if (logger.isDebugEnabled())
				logger.debug("Input to getDBPoolList is \n" + SCXmlUtil.getString(docIpGetDBPoolList));
			Document docOpGetDBPoolList = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_DB_POOL_LIST,
					docIpGetDBPoolList);
			if (logger.isDebugEnabled())
				logger.debug("Output from getDBPoolList is \n" + SCXmlUtil.getString(docOpGetDBPoolList));
			Element eleParamList = (Element) docOpGetDBPoolList.getDocumentElement()
					.getElementsByTagName(KohlsPOCConstant.E_PARAM_LIST).item(0);
			ArrayList<Element> listParam = SCXmlUtil.getChildren(eleParamList, KohlsPOCConstant.E_PARAM);
			for (Element eleParam : listParam) {
				if (eleParam.getAttribute(KohlsPOCConstant.A_NAME).equals(KohlsPOCConstant.A_SCHEMA)) {
					trxSchema = eleParam.getAttribute(KohlsPOCConstant.A_VALUE);
					logger.info("Get schema name " + trxSchema + " for PoolID completed");
				}
			}
			if (YFCCommon.isVoid(trxSchema)) {
				throw new YFCException("Exception in Get schema name for PoolID, Schema is null");
			}
			return trxSchema;
		}
		
		
		
		public Document getOfflineTransactionQDetails(YFSEnvironment env, Document inDoc, boolean isHistory)
					throws Exception {
				logger.info("Getting the offline transactions list");
				inDoc.getDocumentElement().setAttribute(KohlsPOCConstant.NEED_OPERTION_XML, KohlsPOCConstant.YES);
				String outPutTemplate  = "";
				Document outDocGetOffTransQListForPOS = null;
				if(isHistory){
					outDocGetOffTransQListForPOS = getOutdocWithBlobFromHistory(env, inDoc);
					logger.info("output is " + SCXmlUtil.getString(outDocGetOffTransQListForPOS));
				}else{
					outPutTemplate = "<OfflineTransactionQs> <OfflineTransactionQ DATAXML='' IsLocal='' Modifyts='' "
						+ "OfflineTrxQKey='' OperationID='' OperationInputXML='' OperationTS='' StoreID='' "
						+ "TrxStatus='' UniqueID='' ReplicationSeq=''><Extn ExtnRetryCount=''/>	</OfflineTransactionQ>"
						+ "	</OfflineTransactionQs>";
					outDocGetOffTransQListForPOS = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(outPutTemplate),
							KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS,inDoc);
				}
				logger.debug("getOfflineTransactionQListForPOS input " + SCXmlUtil.getString(inDoc));
				
				logger.debug("outDocGetOffTransQListForPOS output " + SCXmlUtil.getString(outDocGetOffTransQListForPOS));
				logger.info("Getting the offline transactions list completed");
				return outDocGetOffTransQListForPOS;
		}
		
		
		private Document getOutdocWithBlobFromHistory(YFSEnvironment env, Document inDoc) throws Exception {
			String strOfflineTrxQKey = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
			YFSContext ctx = (YFSContext) env;	
			ResultSet rs = null;
			String s = "", strStoreID="", strOperationID="", strUniqueID="", strReplicationSeq="";
			String strOperationTS="", strDataXML="", strIsLocal="", strExtnRetryCount="";
			
			String strOpreationInputXML = "";
				String poolID = getPoolIDForTrxTable(ctx);
				if (!YFCCommon.isVoid(poolID)) {
					tranSchema = getSchemaNameForPoolID(ctx, poolID) + KohlsPOCConstant.DOT;
				} else {
					throw new YFCException("Exception in get PoolID, pool is null");
				}
				try {
				PLTQueryBuilder getPLT = new PLTQueryBuilder(false);
				getPLT.append("SELECT OFFLINE_TRX_Q_KEY,OPERATION_INPUT_XML,STORE_ID,OPERATION_ID,"
						+ "UNIQUE_ID,REPLICATION_SEQ,OPERATION_TS,"
						+ "DATA_XML,IS_LOCAL,EXTN_RETRY_COUNT FROM " + tranSchema + 
						"KOHLS_POS_OFFLINE_TRX_Q_H WHERE OFFLINE_TRX_Q_KEY='"+
						strOfflineTrxQKey+"'");
				logger.info("Executing the get query " + getPLT.getReadableWhereClause());			
				prepStmt = ctx.getConnection().prepareStatement(getPLT.getReadableWhereClause(true));
				rs = prepStmt.executeQuery(getPLT.getReadableWhereClause(true));
				Blob b = null;
				Clob cDataXML = null;
				if (rs.next()) {
					strStoreID = rs.getString("STORE_ID");
					strOperationID = rs.getString("OPERATION_ID");
					strUniqueID = rs.getString("UNIQUE_ID");
					strReplicationSeq = rs.getString("REPLICATION_SEQ");
					strOperationTS = rs.getString("OPERATION_TS");
					cDataXML = rs.getClob("DATA_XML");
					strIsLocal = rs.getString("IS_LOCAL");
					strExtnRetryCount = rs.getString("EXTN_RETRY_COUNT");
					b = rs.getBlob("OPERATION_INPUT_XML");				
				}
				
				
				if(YFCObject.isNull(b)){
					return SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_QS);
				}
				strDataXML = cDataXML.getCharacterStream().toString();
				InputStream inStream = b.getBinaryStream();
				InputStreamReader inStreamReader = new InputStreamReader(inStream);
				BufferedReader reader = new BufferedReader(inStreamReader);
				StringBuffer buf = new StringBuffer();
				while((s=reader.readLine())!=null){
					buf.append(s);
				}
				strOpreationInputXML = buf.toString();
				logger.info("strOpreationInputXML is " + strOpreationInputXML);
				rs.close();
				} catch (Exception cl) {
					logger.error("Exception during querying for operation XML");
					throw cl;
				} finally {
					YFSDBHome.closeStatement(stmt);
					if (logger.isDebugEnabled())
						logger.debug("getOfflineTransactionQDetails statement closed");
				}
			Document outDocGetOffTransQListForPOS = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_QS);
			Element eleOfflineTrxQForPOS = SCXmlUtil.createChild(outDocGetOffTransQListForPOS.getDocumentElement(), 
					"OfflineTransactionQ");
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, strStoreID);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_OPERATION_ID, strOperationID);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, strUniqueID);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_REPLICATION_SEQ, strReplicationSeq);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_OPERATION_TS, strOperationTS);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_DATA_XML, strDataXML);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_IS_LOCAL, strIsLocal);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_EXTN_RETRY_COUNT, strExtnRetryCount);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML, strOpreationInputXML);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY, strOfflineTrxQKey);
			eleOfflineTrxQForPOS.setAttribute(KohlsPOCConstant.A_CHECK_BOX_HISTORY_SELECTED, KohlsPOCConstant.TRUE);
			return outDocGetOffTransQListForPOS;
		}


		/**
		 * This method is used to retrieve pool ID for the transaction table
		 * @param env
		 * @return
		 * @throws Exception
		 */
		private String getPoolIDForTrxTable(YFSEnvironment env) throws Exception {
			logger.info("Get PoolID for trx table started");
			//TODO if more than one trx schema ? how to handle it
			String poolID = null;
			Document inDocToGetPoolList = SCXmlUtil.createDocument(KohlsPOCConstant.E_COLONY_POOL);
			inDocToGetPoolList.getDocumentElement().setAttribute(KohlsPOCConstant.TABLE_TYPE,
					KohlsPOCConstant.A_TRANSACTION);
			if (logger.isDebugEnabled())
				logger.debug("Input to get the colony pool list \n" + SCXmlUtil.getString(inDocToGetPoolList));
			Document outDocToGetPoolList = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COLONY_POOL_LIST,
					inDocToGetPoolList);
			if (logger.isDebugEnabled())
				logger.debug("Output from get colony pool list \n" + SCXmlUtil.getString(outDocToGetPoolList));

			if (outDocToGetPoolList.getDocumentElement().hasChildNodes()) {
				Element eleColonyPool = (Element) outDocToGetPoolList.getDocumentElement()
						.getElementsByTagName(KohlsPOCConstant.E_COLONY_POOL).item(0);
				poolID = eleColonyPool.getAttribute(KohlsPOCConstant.A_POOL_ID);
				logger.info("Get PoolID is " + poolID);
			}
			logger.info("Get PoolID for trx table completed");
			return poolID;
		}

	
		public Document getPosOfflineTrxQList(YFSEnvironment env, Document docInXML) throws Exception {
		logger.info("Entering getPosOfflineTrxQHistoryList with input " + SCXmlUtil.getString(docInXML));
		Document docOutput = null;
		try {
			if(docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_CHECK_BOX_HISTORY_SELECTED).equals(KohlsPOCConstant.TRUE)){
				docOutput = callOfflineHistoryList(env, docInXML);
			}else {
				docOutput = callOfflineLiveList(env, docInXML);
			}
		} catch (Exception e) {
			logger.error("getList api call failed");
			throw e;
		}
		return docOutput;
	}
	
	private Document callOfflineLiveList(YFSEnvironment env, Document docInXML) throws Exception {
		logger.info("Invoking API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS Service with input " + SCXmlUtil.getString(docInXML));
		Document docOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS, docInXML);
		logger.info("API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS output " + SCXmlUtil.getString(docOutput));
		return docOutput;
	}

	private Document callOfflineHistoryList(YFSEnvironment env, Document docInXML) throws Exception {
		Element eleInput = docInXML.getDocumentElement();
		docInXML.renameNode(eleInput, null, KohlsPOCConstant.E_KOHLS_P0S_OFFLINE_TRXQ_HISTORY);
		logger.info("Invoking KohlsPOSOfflineTrxQHistoryList Service with input " + SCXmlUtil.getString(docInXML));
		Document docHistoryOutput = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_Q_HISTORY_LIST, 
				docInXML);
		Element elePosOfflineTrxQHistorys = docHistoryOutput.getDocumentElement();
		logger.info("KohlsPOSOfflineTrxQHistoryList output " + SCXmlUtil.getString(elePosOfflineTrxQHistorys));
		docHistoryOutput.renameNode(elePosOfflineTrxQHistorys, null, KohlsPOCConstant.E_OFFLINE_TRANSACTION_QS);
		logger.info("docHistoryOutput after rename of list node " + SCXmlUtil.getString(docHistoryOutput));
		ArrayList<Element> KohlsPosOffflineTrxQHistoryList = SCXmlUtil.getChildren(elePosOfflineTrxQHistorys, 
				KohlsPOCConstant.E_KOHLS_P0S_OFFLINE_TRXQ_HISTORY);
		for(Element eleKohlsPosOffflineTrxQHistory:KohlsPosOffflineTrxQHistoryList) {
				docHistoryOutput.renameNode(eleKohlsPosOffflineTrxQHistory, null, KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
				eleKohlsPosOffflineTrxQHistory.setAttribute(KohlsPOCConstant.A_CHECK_BOX_HISTORY_SELECTED, KohlsPOCConstant.TRUE);
		}
		logger.info("final  docHistoryOutput " + SCXmlUtil.getString(docHistoryOutput));
		return docHistoryOutput;
	}
	
	public Document deleteFromHistoryAndUpdateInLive(YFSEnvironment env, Document docInXML) throws Exception {
		logger.info("deleteFromHistoryAndUpdateInLive start ");
		Document docOpLiveInsert = null;
		try{
			YFSContext yctx = (YFSContext) env;
			logger.info("Input XML to deleteFromHistoryAndUpdateInLive method is:"+SCXmlUtil.getString(docInXML));
			Document outDoc = getOutdocWithBlobFromHistory(yctx, docInXML);
			logger.info("Output of callOfflineHistoryList is " + SCXmlUtil.getString(outDoc));
			Element eleOfflineTrxQ = SCXmlUtil.getChildElement(outDoc.getDocumentElement(), KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			eleOfflineTrxQ.removeAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
			eleOfflineTrxQ.removeAttribute(KohlsPOCConstant.DB_MODIFYTS);
			eleOfflineTrxQ.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.STRING_ONE);	
			eleOfflineTrxQ.setAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML, 
			docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML));
			Document manageInDoc = SCXmlUtil.createFromString(SCXmlUtil.getString(eleOfflineTrxQ));
			logger.info("Input document for manageOfflineTransactionQForPOS " + SCXmlUtil.getString(manageInDoc));
			docOpLiveInsert = KOHLSBaseApi.invokeAPI(yctx, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS,
		    		manageInDoc);
		    logger.info("Output of manageOfflineTransactionQForPOS API is:"+SCXmlUtil.getString(docOpLiveInsert));	
		
			Document docIpHistoryRecordDelete  = SCXmlUtil.createDocument(KohlsPOCConstant.E_KOHLS_P0S_OFFLINE_TRXQ_HISTORY);
			docIpHistoryRecordDelete.getDocumentElement().setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.DELETE);
			docIpHistoryRecordDelete.getDocumentElement().setAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY, 
					docInXML.getDocumentElement().getAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY));
			deleteFromHistory(env, docIpHistoryRecordDelete);
		}catch(Exception e){
			logger.error("Exception in deleteFromHistoryAndUpdateInLive method.");
			throw e;
		}
			/*logger.info("Input to KohlsPOSOfflineTrxQHistoryDelete service is:"+SCXmlUtil.getString(docIpHistoryRecordDelete));
			Document docHistoryDeleteOutput = KOHLSBaseApi.invokeService(yctx, KohlsPOCConstant.API_DELETE_OFFLINE_TRANSACTION_Q_HISTORY, docIpHistoryRecordDelete);
			logger.info("Record deleted from Kohls POS History table:"+SCXmlUtil.getString(docHistoryDeleteOutput));
			 */				
			return docOpLiveInsert;	
	}
	
	private void deleteFromHistory(YFSEnvironment env, Document inDoc) throws Exception {
		String strOfflineTrxQKey = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
		YFSContext ctx = (YFSContext) env;	
		ResultSet rs = null;
		try {
			PLTQueryBuilder deletePLT = new PLTQueryBuilder(false);
			deletePLT.append("DELETE FROM " + tranSchema + 
					"KOHLS_POS_OFFLINE_TRX_Q_H WHERE OFFLINE_TRX_Q_KEY='"+
					strOfflineTrxQKey+"'");
			logger.info("Executing the get query " + deletePLT.getReadableWhereClause());			
			prepStmt = ctx.getConnection().prepareStatement(deletePLT.getReadableWhereClause(true));
			rs = prepStmt.executeQuery(deletePLT.getReadableWhereClause(true));
			rs.close();
			} catch (Exception cl) {
				logger.error("Exception during deleteFromHistory");
				throw cl;
			} finally {
				YFSDBHome.closeStatement(stmt);
				if (logger.isDebugEnabled())
					logger.debug("deleteFromHistory statement closed");
			}
	}
}
