package com.kohls.poc.api;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXMLLiterals;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.apache.commons.lang3.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.util.ArrayList;
import java.util.List;

/**
 * This class in invoked for post voids of SPS Orders.
 */
public class KohlsPostVoidStoreOrderSPS {

    private static YFCLogCategory logger;

    static {
        logger = YFCLogCategory.instance(KohlsPostVoidStoreOrderSPS.class.getName());
    }

    public void invoke(YFSEnvironment env, Document inDoc) throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invoke");

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.invoke - " + KohlsXMLUtil.getXMLString(inDoc));
        }

        /* Initialize Variables */
        Element eleRoot = null;
        Element eleOrder = null;
        Element eleRootOrder = null;
        Element eleReceiptData = null;
        Document docGetOrderList = null;
        NodeList nlOrders = null;
        Element eleChargeTransactionDetails = null;
        NodeList nlChargeTransaction = null;
        String strOrderInvoiceKey = null;
        String strNewTranNo = null;
        String strNewPosSeqNo = null;
        boolean bIsExchange = false;
        String strOperator = null;
        int iCount = 0;

        try {
            eleRoot = inDoc.getDocumentElement();
            eleRootOrder = KohlsXMLUtil.getChildElement(eleRoot, KohlsPOCConstant.ELEM_ORDER);
            eleReceiptData = KohlsXMLUtil.getChildElement(eleRoot, KohlsPOCConstant.ELE_RECEIPT_DATA);

            /* Invoke getOrderList API to retrieve the order to be voided */
            docGetOrderList = invokeGetOrderList(env, KohlsXMLUtil.getChildElement(eleRootOrder, KohlsPOCConstant.E_EXTN));
            nlOrders = (docGetOrderList.getDocumentElement()).getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);

            /* if no order is found with that receipt id then throw error */
            if (YFCCommon.isVoid(nlOrders)) {
                YFSException e = new YFSException();
                e.setErrorDescription(KohlsPOCConstant.POC_NO_RECORD_FOUND_ERROR_CODE);
                throw e;
            } else {

                for (int j = 0; j < nlOrders.getLength(); j++) {
                    eleOrder = (Element) nlOrders.item(j);
                    String strExchange = eleOrder.getAttribute("OrderPurpose");
                    String strDocType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);

                    /* Retrieve the OrderInvoiceKey from /OrderList/Order/ChargeTransactionDetails/ChargeTransactionDetail */
                    eleChargeTransactionDetails = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);

                    if (!YFCCommon.isVoid(eleChargeTransactionDetails)) {
                        nlChargeTransaction = eleChargeTransactionDetails.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
                    }

                    if (!YFCCommon.isVoid(nlChargeTransaction)) {
                        iCount = nlChargeTransaction.getLength();
                    }

                    /* Loop through each ChargeTransactionDetail to get the OrderInvoiceKey */
                    for (int i = 0; i < iCount; i++) {
                        Element eleChargeTransactionDetail = (Element) nlChargeTransaction.item(i);
                        strOrderInvoiceKey = eleChargeTransactionDetail.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);

                        if (!YFCCommon.isVoid(strOrderInvoiceKey)) {
                            break;
                        }
                    }

                    if (!YFCCommon.isVoid(strExchange) && "EXCHANGE".equals(strExchange)) {
                        bIsExchange = true;
                    }

                    /* Invoke manageStoredValueLineForPOS API to deactivate blackhawk gift card */
                    invokeManageStoredValueForPOS(env, eleOrder);

                    /* Invoke voidInvoice API to void the order invoice */
                    invokeVoidInvoice(env, strOrderInvoiceKey, strDocType);


                    /* Invoke capturePayment API to void the ChargeTransactionDetail for an Order */
                    List<String> listChargeTransactionKey = invokeCapturePayment(env, eleOrder);

                    /* Invoke processOrderPayments API to close the CTRs for an Order */
                    invokeExecuteCollection(env, eleOrder, listChargeTransactionKey);

                    /* Invoke changeOrder API to cancel the order*/
                    strNewTranNo = eleRootOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
                    strOperator = eleRootOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID);
                    strNewPosSeqNo = eleRootOrder.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO);

                    //CPE-7525 - Start
                    env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.TRUE);
                    //CPE-7525 - End
                    invokeChangeOrder(env, eleOrder, strNewPosSeqNo,
                            strOperator, eleRootOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO));
                }

                /* Invoke manageTransactionAuditForPOS to update the TransactionAudit record */
                invokeManageTransAudit(env, eleOrder, strNewTranNo, strOperator, strNewPosSeqNo, bIsExchange);

                /* Invoke manageReceiptDataForPOS */
                invokeManageReceiptData(env, eleReceiptData, eleOrder,
                        KohlsPOCConstant.STATIC_CONSTANT_VOIDED_TRANSACTION_PROCEDURE_ID);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw e;
        }

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invoke");
    }

    /**
     * This method invokes getOrderList API to fetch the invoice and payment details of the order to be voided.
     *
     * @param env
     * @param eleOrderExtn
     * @return
     */
    private Document invokeGetOrderList(YFSEnvironment env, Element eleOrderExtn) throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeGetOrderList");

        /* Initialize variables */
        Document docGetOrderListIn = null;
        Element eleGetOrder = null;
        String strTemplate = "/global/template/api/POC/sps/POC_getOrderList_OrderState.xml";
        Element eleAttribute = null;
        Element eleOrderBy = null;
        Document docGetOrderListOut = null;

        /* Prepare the input XML document for getOrderList API */
        docGetOrderListIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        eleGetOrder = docGetOrderListIn.getDocumentElement();
        eleGetOrder.setAttribute(KohlsPOCConstant.A_TRANSACTION_NO, eleOrderExtn.getAttribute(
                "ExtnOriginalTransactionNo"));
        eleGetOrder.setAttribute(KohlsPOCConstant.A_MAXIMUM_RECORDS, "2");
        eleOrderBy = KohlsXMLUtil.createChild(docGetOrderListIn.getDocumentElement(), KohlsPOCConstant.E_ORDER_BY);
        eleAttribute = KohlsXMLUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
        eleAttribute.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_DOC_TYPE);
        eleAttribute.setAttribute("Desc", KohlsPOCConstant.NO);

        KohlsXMLUtil.appendChild(eleOrderBy, eleAttribute);
        KohlsXMLUtil.appendChild(eleGetOrder, eleOrderBy);

        /* Invoke getOrderList API */

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.getOrderList - " + KohlsXMLUtil.getXMLString(docGetOrderListIn));
        }

        docGetOrderListOut = KOHLSBaseApi.invokeAPI(env, strTemplate, KohlsPOCConstant.API_GET_ORDER_LIST, docGetOrderListIn);

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.getOrderList - " + KohlsXMLUtil.getXMLString(docGetOrderListOut));
        }

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeGetOrderList");

        return docGetOrderListOut;
    }

    /**
     * This method invokes changeOrderInvoice to set InvoiceStatus to "00" and then invokes voidInvoice API to void the invoice.
     *
     * @param env
     * @param strOrderInvoiceKey
     * @return
     */
    private void invokeVoidInvoice(YFSEnvironment env, String strOrderInvoiceKey, String strDocType) throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeVoidInvoice");

        /* Prepare the input XML document for voidInvoice API */
        Document docInVoidInvoice = KohlsXMLUtil.createDocument(KohlsPOCConstant.E_ORDER_INVOICE);
            Element eleOrderInvoice = docInVoidInvoice.getDocumentElement();
            eleOrderInvoice.setAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY, strOrderInvoiceKey);
            eleOrderInvoice.setAttribute(KohlsPOCConstant.A_STATUS, KohlsPOCConstant.INVOICE_CREATED_STATUS);

        if(!KohlsPOCConstant.RO_DOCUMENT_TYPE.equals(strDocType)) {
             /* Invoke changeOrderInvoice API */
            if (logger.isDebugEnabled()) {
                logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.changeOrderInvoice - " + KohlsXMLUtil.getXMLString(docInVoidInvoice));
            }

            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER_INVOICE, docInVoidInvoice);
        }

        /* Invoke voidInvoice API */
        eleOrderInvoice.setAttribute(KohlsPOCConstant.ATTR_IGNORE_STATUS_CHECK, KohlsPOCConstant.YES);
        eleOrderInvoice.setAttribute(KohlsPOCConstant.A_TRANSACTION_ID, "VOID_INVOICE.0001.ex");
        eleOrderInvoice.removeAttribute(KohlsPOCConstant.A_STATUS);

        /* Invoke voidInvoice API */
        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.voidInvoice - " + KohlsXMLUtil.getXMLString(docInVoidInvoice));
        }

        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_VOID_INVOICE, docInVoidInvoice);

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeVoidInvoice");

    }


    /**
     * This method invokes changeOrder API to cancel order.
     *
     * @param env
     * @param eleOrder
     * @param strPosSeqNo,
     * @param strOperator
     * @param strTranNo
     * @return
     */
    private void invokeChangeOrder(YFSEnvironment env, Element eleOrder, String strPosSeqNo, String strOperator,
                                   String strTranNo) throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeChangeOrder");

        /* Initialize variables */
        Document docInChangeOrder = null;
        Element eleChangeOrder = null;
        String strOrgPosSeqNo = null;
        Element eleChangeExtn = null;

        /* Prepare input XML to changeOrder API to cancel the order */
        docInChangeOrder = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);

        strOrgPosSeqNo = eleOrder.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO);
        eleChangeOrder = docInChangeOrder.getDocumentElement();

        eleChangeOrder.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_CANCEL);
        eleChangeOrder.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
        eleChangeOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
        //eleChangeOrder.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, eleOrder.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));
        eleChangeOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
        //eleChangeOrder.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
        //eleChangeOrder.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "voidTransaction");
        eleChangeOrder.setAttribute(KohlsXMLLiterals.A_POS_SEQ_NO, strPosSeqNo);
        eleChangeOrder.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NO, strTranNo);
        eleChangeOrder.setAttribute(KohlsXMLLiterals.A_POST_VOIDED, KohlsPOCConstant.YES);
        eleChangeOrder.setAttribute("PostVoidedBy", strOperator);
        eleChangeOrder.setAttribute("VoidIndicator", KohlsPOCConstant.V_POSTVOID_P);
        eleChangeExtn = KohlsXMLUtil.createChild(eleChangeOrder, KohlsPOCConstant.E_EXTN);
        eleChangeExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ORIGINAL_POS_SEQ_NO, strOrgPosSeqNo);

            /* Invoke changeOrder API */
        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.invokeChangeOrder - " + KohlsXMLUtil.getXMLString(docInChangeOrder));
        }

        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, docInChangeOrder);

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeChangeOrder");
    }

    /**
     * This method will create Input and call manageTransactionAuditForPOS, to publish audit information to downstream systems.
     *
     * @param env
     * @param eleOrder
     * @param strTranNo
     * @param strOperator
     * @throws YFSException
     */
    private void invokeManageTransAudit(YFSEnvironment env, Element eleOrder, String strTranNo, String strOperator, String strNewPosSeqNo,
                                        boolean bIsExchange)
            throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeManageTransAudit");

        /* Initialize variables */
        Document docInManageTranAudit = null;
        Element eleOverallTotal = null;
        Element eleRoot = null;
        Element eleOrderState = null;

        /* Prepare input xml to manageTransactionAuditForPOS */
        docInManageTranAudit = KohlsXMLUtil.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);

        eleRoot = docInManageTranAudit.getDocumentElement();
        eleOrderState = KohlsXMLUtil.createChild(eleRoot, "OrderState");

        eleOverallTotal = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELE_OVERALLTOTALS);

        eleRoot.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
        eleRoot.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
        eleRoot.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, strOperator);
        eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
        eleRoot.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, eleOverallTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL));
        eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
        eleRoot.setAttribute("OriginalTransactionNumber", eleOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO));
        eleRoot.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER, strNewPosSeqNo);
        eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, KohlsPOCConstant.STRING_POST_VOID);
        eleRoot.setAttribute(KohlsPOCConstant.A_TERMINAL_ID, eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
        eleRoot.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER, strTranNo);
		eleRoot.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));

        if (bIsExchange) {
            eleRoot.setAttribute("IsExchangeOrder", KohlsPOCConstant.YES);
        }

        if (!YFCCommon.isVoid(eleOrder)) {
            eleOrderState.setAttribute("OrderData", StringEscapeUtils.escapeXml(KohlsXMLUtil.getElementXMLString(eleOrder)));
            KohlsXMLUtil.appendChild(eleRoot, eleOrderState);
        }


        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.invokeManageTransAudit - "
                    + KohlsXMLUtil.getXMLString(docInManageTranAudit));
        }

            /* Invoke manageTransactionAuditForPOS API */
        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_TRANSACTION_AUDIT_FOR_POS, docInManageTranAudit);

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeManageTransAudit");

    }

    /**
     * This method is used to invoke capturePayment API
     *
     * @param env
     * @throws Exception
     */

    private List<String> invokeCapturePayment(YFSEnvironment env, Element eleOrder) throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeCapturePayment");

        /* Initialize variables */
        Document docCapturePaymentIn = null;
        NodeList nlPayment = null;
        NodeList nlChargeTrn = null;
        Element elePreviousChargeTranDtls = null;
        Element eleChargeTransactionDetails = null;
        Element eleCapturePayment = null;
        Element eleCapturePaymentMethods = null;
        Element elePaymentMethods = null;
        List<String> listPaymentKey = new ArrayList<>();
        List<String> listChargeTxnKey = new ArrayList<>();

        int iCount = 0;

            /* Prepare Input XML for capturePayment API */
        docCapturePaymentIn = KohlsXMLUtil.createDocument(KohlsXMLLiterals.E_CAPTURE_PAYMENT);
        eleCapturePayment = docCapturePaymentIn.getDocumentElement();
        eleCapturePayment.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
        eleCapturePayment.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
        eleCapturePayment.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, eleOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
        eleCapturePayment.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, eleOrder.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));
        eleCapturePayment.setAttribute("ProceedOnZeroAmountFailure", KohlsPOCConstant.NO);

            /* Retrieve the Payment Methods associated with the order that needs to be voided */
        elePaymentMethods = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PAYMENT_METHODS);
        eleCapturePaymentMethods = KohlsXMLUtil.createChild(eleCapturePayment, KohlsPOCConstant.E_PAYMENT_METHODS);

        if (!YFCCommon.isVoid(elePaymentMethods)) {
            nlPayment = elePaymentMethods.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
        }

            /* Get the # of payment methods for an Order */
        if (!YFCCommon.isVoid(nlPayment)) {
            iCount = nlPayment.getLength();
        }

            /* Loop through each PaymentMethods/PaymentMethod */
        for (int i = 0; i < iCount; i++) {
            Element eleTemp = (Element) nlPayment.item(i);
            String strPaymentKey = eleTemp.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
            listPaymentKey.add(strPaymentKey);

                /* Create the PaymentMethod in CapturePayment/PaymentMethods */
            Element elePaymentMethod = KohlsXMLUtil.createChild(eleCapturePaymentMethods, KohlsPOCConstant.E_PAYMENT_METHOD);
            elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY, strPaymentKey);
            elePaymentMethod.setAttribute(KohlsXMLLiterals.A_IS_CORRECTION, KohlsPOCConstant.YES);
            elePaymentMethod.setAttribute(KohlsPOCConstant.OPERATION, KohlsPOCConstant.SUSPEND);
            elePaymentMethod.setAttribute(KohlsXMLLiterals.A_REQUESTED_AMOUNT, "0.00");

            KohlsXMLUtil.appendChild(eleCapturePaymentMethods, elePaymentMethod);
        }

        KohlsXMLUtil.appendChild(eleCapturePayment, eleCapturePaymentMethods);

            /* Retrieve the ChargeTransactionDetails associated with the order that needs to be voided */
        eleChargeTransactionDetails = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
        elePreviousChargeTranDtls = KohlsXMLUtil.createChild(eleCapturePayment, "PreviousChargeTransactionDetails");
        iCount = 0;

        if (!YFCCommon.isVoid(eleChargeTransactionDetails)) {
            nlChargeTrn = eleChargeTransactionDetails.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
        }

        /* Get the # of Charge TransactionDetail for an Order */
        if (!YFCCommon.isVoid(nlChargeTrn)) {
            iCount = nlChargeTrn.getLength();
        }

            /* Loop through each ChargeTransactionDetails/ChargeTransactionDetail */
        for (int i = 0; i < iCount; i++) {
            Element eleTemp = (Element) nlChargeTrn.item(i);
            String strPaymentKey = eleTemp.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
            String strVoidIndicator = eleTemp.getAttribute(KohlsPOCConstant.ATTR_VOID_TRANSACTION);

            if (!YFCCommon.isVoid(strPaymentKey) && listPaymentKey.contains(strPaymentKey) &&
                    !KohlsPOCConstant.STATIC_CONSTANT_SUBMITTED.equals(strVoidIndicator) &&
                    !KohlsPOCConstant.STATIC_CONSTANT_VOID.equals(strVoidIndicator)) {
                Element elePaymentMethod = KohlsXMLUtil.createChild(eleCapturePaymentMethods,
                        KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
                elePaymentMethod.setAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY,
                        eleTemp.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY));
                listChargeTxnKey.add(eleTemp.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY));
                elePaymentMethod.setAttribute(KohlsPOCConstant.OPERATION, "Void");
                KohlsXMLUtil.appendChild(elePreviousChargeTranDtls, elePaymentMethod);
            }
        }

        KohlsXMLUtil.appendChild(eleCapturePayment, elePreviousChargeTranDtls);

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to capturePayment - " + KohlsXMLUtil.getXMLString(docCapturePaymentIn));
        }

            /* Invoke capturePayment API */
        KOHLSBaseApi.invokeAPI(env, KohlsXMLLiterals.API_CAPTURE_PAYMENT, docCapturePaymentIn);

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeCapturePayment");
        return listChargeTxnKey;
    }

    /**
     * This method is used for invoking executeCollection which will close all the open CTR.
     *
     * @param env
     * @param eleOrder
     */
    private static void invokeExecuteCollection(YFSEnvironment env, Element eleOrder, List<String> listChargeTransactionKey)
            throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeExecuteCollection");

        /* Initialize variables */
        Document docGetChargeTransactionList = null;
        Element eleProcessOrder = null;

        /* Prepare Input XML to processOrderPayments API */
        docGetChargeTransactionList = KohlsXMLUtil.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
        eleProcessOrder = docGetChargeTransactionList.getDocumentElement();
        eleProcessOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
                eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));

        String strTemplate = "<ChargeTransactionDetails>\n" +
                "<ChargeTransactionDetail UserExitStatus=\"\" ChargeTransactionKey=\"\" ChargeType=\"\"/>\n" +
                "</ChargeTransactionDetails>";

            /*Invoke processOrderPayments to close the charge transaction records */
        Document getChargeTransactionDetailsOut = KOHLSBaseApi.invokeAPI(env, KohlsXMLUtil.getDocument(strTemplate),
                "getChargeTransactionList", docGetChargeTransactionList);

        if (!YFCCommon.isVoid(getChargeTransactionDetailsOut)) {
            Element eleChargetxnDetails = docGetChargeTransactionList.getDocumentElement();

            NodeList nlChargeTxnDetails = eleChargetxnDetails.getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL);
            int iCount = 0;

            if (!YFCCommon.isVoid(nlChargeTxnDetails)) {
                iCount = nlChargeTxnDetails.getLength();
            }

            Document docExecuteCollection = KohlsXMLUtil.createDocument(KohlsPOCConstant.ATTR_EXECUTE_COLLECTION);
            Element eleExcuteCollection = docExecuteCollection.getDocumentElement();

            for (int i = 0; i < iCount; i++) {
                Element eleChargeTxnDetail = (Element) nlChargeTxnDetails.item(i);
                String strChargeTransactionKey = eleChargeTxnDetail.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY);
                String strUserExitStatus = eleChargeTxnDetail.getAttribute("UserExitStatus");
                String strChargeType = eleChargeTxnDetail.getAttribute(KohlsXMLLiterals.A_CHARGE_TYPE);

                if (!YFCCommon.isVoid(strUserExitStatus) && !"INVOKED".equals(strUserExitStatus) &&
                        (listChargeTransactionKey.contains(strChargeTransactionKey) || (listChargeTransactionKey.isEmpty() &&
                                KohlsPOCConstant.ACTION_CANCEL.equals(strChargeType)))) {
                    eleExcuteCollection.setAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY, strChargeTransactionKey);
                    KOHLSBaseApi.invokeAPI(env, "executeCollection", docExecuteCollection);
                }
            }
        }

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeExecuteCollection");

    }

    /**
     * This method invokes manageReceiptDataForPOS API to add the ReceiptData.
     *
     * @param env
     * @param eleReceiptData
     */
    private void invokeManageReceiptData(YFSEnvironment env, Element eleReceiptData, Element eleOrder,
                                        String strProcedureID) throws Exception {

        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeManageReceiptData");

        /* Initialize variables */
        Document docInManageReceipt = null;
        Element eleRoot = null;

        /* Prepare Input XML For manageReceiptDataForPOS API */
        docInManageReceipt = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELE_RECEIPT_DATA);
        eleRoot = docInManageReceipt.getDocumentElement();

        if (!YFCCommon.isVoid(eleReceiptData)) {
            eleRoot.setAttribute("AppendReceiptData", KohlsPOCConstant.NO);
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, eleReceiptData.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME));
            eleRoot.setAttribute(KohlsPOCConstant.A_OPERATOR_ID, eleReceiptData.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
            if (!YFCCommon.isVoid(eleReceiptData.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE))) {
                eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleReceiptData.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
            } else {
                eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
            }
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, strProcedureID);
            eleRoot.setAttribute(KohlsPOCConstant.A_TERMINAL_ID, eleReceiptData.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
            eleRoot.setAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER, eleReceiptData.getAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER));
            eleRoot.setAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA, eleReceiptData.getAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA));

            if (logger.isDebugEnabled()) {
                logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.invokeManageReceiptData - "
                        + KohlsXMLUtil.getXMLString(docInManageReceipt));
            }

            /* Invoke manageTransactionAuditForPOS API */
            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_RECEIPT_DATA_FOR_POS, docInManageReceipt);

        }

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeManageReceiptData");

    }

    /**
     * This method invokes manageStoredValueForPOS API to fetch the invoice and payment details of the order to be voided.
     *
     * @param env
     * @param eleOrder
     * @return
     */
    private void invokeManageStoredValueForPOS(YFSEnvironment env, Element eleOrder) throws Exception {
        logger.beginTimer("KohlsPostVoidStoreOrderSPS.invokeManageStoredValueForPOS");
        /* Initialize variables */
        Document docGetStoredValueLineListForPOS = null;
        Document docGetStoredValueLineListOut = null;
        Element eleStoredValueLine = null;
        Element eleStoredValueLineList = null;
        NodeList nlStoreValueLine = null;
        int iCount = 0;

            /* Prepare Input XML to getStoredValueLineListForPOS API */
        docGetStoredValueLineListForPOS = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_STORED_VALUE_LINE);
        eleStoredValueLine = docGetStoredValueLineListForPOS.getDocumentElement();
        eleStoredValueLine.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));

        if (logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.getStoredValueLineListForPOS - "
                    + KohlsXMLUtil.getXMLString(docGetStoredValueLineListForPOS));
        }
            /* Invoke getStoredValueLineListForPOS API */
        docGetStoredValueLineListOut = KOHLSBaseApi.invokeAPI(env,
                KohlsPOCConstant.API_GET_STORED_VALUE_LINE_LIST_FOR_POS, docGetStoredValueLineListForPOS);

        if (logger.isDebugEnabled()) {
            logger.debug("The output XML from KohlsPostVoidStoreOrderSPS.getStoredValueLineListForPOS - "
                    + KohlsXMLUtil.getXMLString(docGetStoredValueLineListOut));
        }

        if (!YFCCommon.isVoid(docGetStoredValueLineListOut)) {
            eleStoredValueLineList = docGetStoredValueLineListOut.getDocumentElement();
            nlStoreValueLine = eleStoredValueLineList.getElementsByTagName(KohlsPOCConstant.ELEM_STORED_VALUE_LINE);

            if (!YFCCommon.isVoid(nlStoreValueLine)) {
                iCount = nlStoreValueLine.getLength();
            }

                /* Loop through each Stored Value Line */
            for (int i = 0; i < iCount; i++) {
                Element eleTemp = (Element) nlStoreValueLine.item(i);
                String strKey = eleTemp.getAttribute("StoredValueLineKey");

                Document docManageStoredValue = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_STORED_VALUE_LINE);
                Element eleRoot = docManageStoredValue.getDocumentElement();
                eleRoot.setAttribute("StoredValueLineKey", strKey);
                eleRoot.setAttribute(KohlsPOCConstant.A_STATUS, "Void");

                if (logger.isDebugEnabled()) {
                    logger.debug("The input XML to KohlsPostVoidStoreOrderSPS.manageStoredValueLineListForPOS - " +
                            KohlsXMLUtil.getXMLString(docManageStoredValue));
                }
                KOHLSBaseApi.invokeAPI(env, "manageStoredValueLineForPOS", docManageStoredValue);
            }
        }

        logger.endTimer("KohlsPostVoidStoreOrderSPS.invokeManageStoredValueForPOS");
    }

}

