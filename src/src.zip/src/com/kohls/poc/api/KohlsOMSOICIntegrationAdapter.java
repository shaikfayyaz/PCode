package com.kohls.poc.api;
import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.TimeZone;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;	
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.is.co.log.Log;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;




/**
 * This class is used to integrate with GIV and OIC, based on commonCode value set in configuration.
 * Every Add or Delete Item from gravity for an omni bag order, will be routed with a create or cancel Reservation call to GIV/OIC. 
 * @author Yantriks
 *
 */
public class KohlsOMSOICIntegrationAdapter implements YIFCustomApi{
	
	private Properties props;
	private static String strOrderDate;
	private static String strIsOICorGIV="";
	private static final String A_ZERO="0";
	private static final String A_OIC_ITEM_ID = "itemID"; 
	private static final String A_OIC_UOM = "uom";
	private static final String A_OIC_RESERVATION_ID= "reservationID";
	private static final String A_RESERVATION_ID= "ReservationID";   
	private static final String A_UNIT_OF_MEASURE = "UnitOfMeasure";
	private static final String A_OIC_QTY = "qty" ;
	private static final String A_OIC_STORE_ID = "storeID" ;
	private static final String A_OIC_CHANNEL = "channel";
	private static final String A_OIC_LINE_ID = "lineID"; 
	private static final String A_PICK = "PICK" ;
	private static final String A_ORDER_LINE_TRAN_QUANTITY = "OrderLineTranQuantity" ;
	private static final String A_TRANSACTIONAL_UOM = "TransactionalUOM";
	private static final String E_ORDER_LINE_RESERVATIONS = "OrderLineReservations";
	private static final String E_ORDER_LINE_RESERVATION = "OrderLineReservation";
	private static final String A_EXTN_IS_OMNI = "ExtnIsOmni" ;
	private static final String SUCCESS = "Success";
	private static final String A_NODE= "Node";
	private static final String A_ACTUAL_DATE = "ActualDate";
	private static final String A_OIC_CREATE_RESERVATION_URL="OIC_CREATE_RESERVATION_INVENTORY_URL";
	private static final String A_OIC_CANCEL_RESERVATION_URL="OIC_CANCEL_RESERVATION_INVENTORY_URL";
	private static final String strOICCreateReservationUrl=YFSSystem.getProperty(A_OIC_CREATE_RESERVATION_URL);
	private static final String strOICCancelReservationUrl=YFSSystem.getProperty(A_OIC_CANCEL_RESERVATION_URL);
	private static final String A_REQ_START_DATE ="ReqStartDate";
	private static final String A_REQ_END_DATE ="ReqEndDate";
	private static final String A_EXPIRATION_DATE_TIME ="ExpirationDateTime";
	private static final String A_TOTAL_RESVD_QTY ="TotalReservedQty";
	private static final String A_AVAILABLE_QTY ="AvailableQty";
	private static final String A_QTY_TO_BE_RESERVED ="QtyToBeReserved";
	private static final String A_IS_OIC_ENABLED="IS_OIC_ENABLED";
	private static final String E_COMMON_CODE_LIST="CommonCodeList";

	private static YFCLogCategory logger;

	//Call to Get Access Tokens and Make OIC Calls
	private KohlsOMSOICIntegrationAccessToken kohlsOMSOICIntegrationAdapterAccessToken = new KohlsOMSOICIntegrationAccessToken();
	
	static {
		logger = YFCLogCategory.instance(KohlsOMSOICIntegrationAdapter.class.getName());
	}
	
	private static YIFApi api = null;
	static {
	try {
		api = YIFClientFactory.getInstance().getApi();
	} catch (YIFClientCreationException e) {
		logger.error(e);
	}
	}
	
	
	/**
	 * Make cancel Reservation call to OIC, with expected Input
	 * @param strOICAuthToken
	 * @param inDoc
	 * @throws TransformerException 
	 * @throws ParserConfigurationException 
	 * @throws Exception 
	 */
	public  String getReservationCancellationXML(String strOICAuthToken,Document inDoc) throws YFSException, ParserConfigurationException, TransformerException {
		if(logger.isDebugEnabled())
			logger.debug("Input to getReservationCancellationXML::"+KohlsXMLUtil.getXMLString(inDoc));
		if(!YFCCommon.isVoid(strOICCancelReservationUrl)){
		Document inDocForJSON=createCancelReservationXMLForJSON(inDoc);
		String xmlToJSONString="";
		if(!YFCCommon.isVoid(inDocForJSON.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0))){
			xmlToJSONString= createCancelReservationJSONForOIC(inDocForJSON);		
			String cancelReservedInventoryURL=strOICCancelReservationUrl;
			if(!YFCCommon.isVoid(cancelReservedInventoryURL))
			try {
				kohlsOMSOICIntegrationAdapterAccessToken.callOIC(xmlToJSONString,cancelReservedInventoryURL,strOICAuthToken);
				}catch (YFSException e) {
					throw e;
				} catch (Exception e) {
					logger.error(e);
				}else
					logger.error("Cancel Reservation URL Missing in properties file");
		}
		return xmlToJSONString; 
		}
		return "";
		    
	}
	
	
	/**
	 * Prepare expected JSON request for cancel reservation to OIC.
	 * @param inDocForJSON
	 * @return
	 */
	private static String createCancelReservationJSONForOIC(Document inDocForJSON) { 
		 JSONObject xmlJSONObj = null;
		 JSONObject xmlJSONObjItems = null;
		 String jsonPrettyPrintString="";
		 try{
		 xmlJSONObj = XML.toJSONObject(KohlsXMLUtil.getXMLString(inDocForJSON));
		 xmlJSONObjItems = (JSONObject) xmlJSONObj.get(KohlsPOCConstant.ELEM_ITEMS);
		 jsonPrettyPrintString=xmlJSONObjItems.get(KohlsPOCConstant.E_ITEM).toString();
		 if(logger.isDebugEnabled())  
			 logger.debug("jsonPrettyPrintString2::"+jsonPrettyPrintString);
		  } catch (JSONException je) {
			  if(logger.isDebugEnabled()) 
				  logger.debug(je.toString());
		  }
		 if(logger.isDebugEnabled()) 
			 logger.debug("Input JSON for OIC::"+jsonPrettyPrintString);
		 return jsonPrettyPrintString; 
	}

	
	/**
	 * Prepare XML structure which can further be converted to expected JSON format for cancel reservation call of OIC.
	 * @param outDoc1
	 * @return
	 * @throws TransformerException 
	 * @throws ParserConfigurationException 
	 */
	private static Document createCancelReservationXMLForJSON(Document outDoc1) throws ParserConfigurationException, TransformerException {
		if(logger.isDebugEnabled()) 
			logger.debug("Input XML for createCancelReservationXMLForJSON::"+KohlsXMLUtil.getXMLString(outDoc1));
		Document inputToJSON=KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEMS);
		
		if(!YFCObject.isNull(outDoc1) && !YFCCommon.isVoid(outDoc1)){
		NodeList orderLineList=SCXmlUtil.getXpathNodes(outDoc1.getDocumentElement(), "/Order/OrderLines/OrderLine");
		for(int i=0;i<orderLineList.getLength();i++){
			Element orderLineEle=(Element)orderLineList.item(i);
			Element itemEle=(Element)orderLineEle.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);
			Element inputItemEle=KohlsXMLUtil.createChild(inputToJSON.getDocumentElement(), KohlsPOCConstant.ELEM_ITEM);
			
			if(!YFCCommon.isVoid(itemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID)))				
			inputItemEle.setAttribute(A_OIC_ITEM_ID,itemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID));
			
			if(!YFCCommon.isVoid(itemEle.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE)))		
			inputItemEle.setAttribute(A_OIC_UOM,itemEle.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE));
			
			if(!YFCCommon.isVoid(outDoc1.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))					
			inputItemEle.setAttribute(A_OIC_RESERVATION_ID,outDoc1.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
			
			Element eleOrderLineTranQuantity=(Element)orderLineEle.getElementsByTagName(A_ORDER_LINE_TRAN_QUANTITY).item(0);
			inputItemEle.setAttribute(A_OIC_QTY,A_ZERO);
			
			if(!YFCCommon.isVoid(orderLineEle.getAttribute(KohlsPOCConstant.A_SHIP_NODE)))	
			inputItemEle.setAttribute(A_OIC_STORE_ID,orderLineEle.getAttribute(KohlsPOCConstant.A_SHIP_NODE));
			inputItemEle.setAttribute(A_OIC_CHANNEL,A_PICK);
			
			if(!YFCCommon.isVoid(orderLineEle.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO)))	
			inputItemEle.setAttribute(A_OIC_LINE_ID,orderLineEle.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
			}
		} 
		
		if(logger.isDebugEnabled())  
			logger.debug("Input XML for Reservation JSON::"+KohlsXMLUtil.getXMLString(inputToJSON));
		return inputToJSON;
	}


	/**
	 * Make Reservation call to OIC, with expected Input
	 * @param strOICAuthToken
	 * @param inDoc
	 * @return
	 * @throws TransformerException 
	 * @throws ParserConfigurationException 
	 * @throws Exception 
	 */
	public String getReserveInventoryXML(String strOICAuthToken,Document inDoc) throws YFSException, ParserConfigurationException, TransformerException {
		if(logger.isDebugEnabled()) 
			logger.debug("Inside getReserveInventoryXML:: ");
		String reserveInventoryURL="";
		String reservationOutput="";
		if(!YFCObject.isNull(inDoc) && !YFCCommon.isVoid(inDoc)){
			Document inDocForJSON=createReservationXMLForJSON(inDoc);
			if(!YFCObject.isNull(inDocForJSON) && !YFCCommon.isVoid(inDocForJSON)){
			String xmlToJSONString= createReservationJSONForOIC(inDocForJSON);
		  	reserveInventoryURL=strOICCreateReservationUrl;
		  //	reserveInventoryURL="https://ocf-oic-dev-usc1a.tst.kohls.com/oic/reserve/DEFAULT/240/N/?replicateReservation=false";
		  	//for testing
		  	if(!YFCCommon.isVoid(reserveInventoryURL)){
				try {
					reservationOutput=kohlsOMSOICIntegrationAdapterAccessToken.callOIC(xmlToJSONString,reserveInventoryURL,strOICAuthToken);
				} catch (YFSException e) {
					logger.error("getReserveInventoryXML YFSException -- at OIC");
					throw e;
				} catch (Exception e) {
					logger.error("getReserveInventoryXML Exception -- at OIC");
				}}
			else
		  		logger.debug("Create Reservation URL Missing in properties file");
			if(logger.isDebugEnabled())  
				logger.debug("Output of OIC call in getReserveInventoryXML::"+reservationOutput);
			} }
		return reservationOutput;
	}


	/**
	 * Prepare expected JSON request for create reservation to OIC.
	 * @param inDocForJSON
	 * @return
	 */
	private static String createReservationJSONForOIC(Document inDocForJSON) {
		if(logger.isDebugEnabled())
			logger.debug("Inside createReservationJSONForOIC:: ");
		 org.json.JSONObject xmlJSONObj = null;
		 org.json.JSONObject xmlJSONObj1 = null;
		 String jsonPrettyPrintString2="";
		 try{
		 xmlJSONObj = XML.toJSONObject(KohlsXMLUtil.getXMLString(inDocForJSON));
		 xmlJSONObj1 = (JSONObject) xmlJSONObj.get(KohlsPOCConstant.ELEM_ITEMS);
		 jsonPrettyPrintString2=xmlJSONObj1.get(KohlsPOCConstant.ELEM_ITEM).toString();
		 if(logger.isDebugEnabled()) 
			 logger.debug("jsonPrettyPrintString2::"+jsonPrettyPrintString2);
		    } catch (JSONException je) {
		        if(logger.isDebugEnabled())  logger.debug(je.toString());
		    }
	 if(logger.isDebugEnabled()) 
		 logger.debug("Input JSON for OIC::"+jsonPrettyPrintString2);
	 return jsonPrettyPrintString2; 
	}

	
	/**
	 * Prepare XML structure which can further be converted to expected JSON format for create reservation call of OIC.
	 * @param outDoc1
	 * @return
	 * @throws TransformerException 
	 * @throws ParserConfigurationException 
	 */
	private static Document createReservationXMLForJSON(Document outDoc1) throws ParserConfigurationException, TransformerException {
		if(logger.isDebugEnabled()) 
			logger.debug("Inside createReservationXMLForJSON::Input:: "+KohlsXMLUtil.getXMLString(outDoc1));
		NodeList orderLineList=SCXmlUtil.getXpathNodes(outDoc1.getDocumentElement(), "/Order/OrderLines/OrderLine");
		Document inputToJSON=KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEMS);
		for(int i=0;i<orderLineList.getLength();i++){
			Element orderLineEle=(Element)orderLineList.item(i);
			Element itemEle=(Element)orderLineEle.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);
			Element inputItemEle=KohlsXMLUtil.createChild(inputToJSON.getDocumentElement(), KohlsPOCConstant.ELEM_ITEM);
			if(!YFCCommon.isVoid(itemEle))				
			inputItemEle.setAttribute(A_OIC_ITEM_ID,itemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID));
			
			if(!YFCCommon.isVoid(outDoc1.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))		
			inputItemEle.setAttribute(A_OIC_RESERVATION_ID,outDoc1.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
			Element eleOrderLineTranQuantity=(Element)orderLineEle.getElementsByTagName(A_ORDER_LINE_TRAN_QUANTITY).item(0);
			
			if(!YFCCommon.isVoid(eleOrderLineTranQuantity.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY)))	
			inputItemEle.setAttribute(A_OIC_QTY,eleOrderLineTranQuantity.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY));
			
			if(!YFCCommon.isVoid(eleOrderLineTranQuantity.getAttribute(A_TRANSACTIONAL_UOM)))	
			inputItemEle.setAttribute(A_OIC_UOM,eleOrderLineTranQuantity.getAttribute(A_TRANSACTIONAL_UOM));
			
			if(!YFCCommon.isVoid(orderLineEle.getAttribute(KohlsPOCConstant.A_SHIP_NODE)))	
			inputItemEle.setAttribute(A_OIC_STORE_ID,orderLineEle.getAttribute(KohlsPOCConstant.A_SHIP_NODE));
			inputItemEle.setAttribute(A_OIC_CHANNEL,A_PICK);
			
			if(!YFCCommon.isVoid(orderLineEle.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO)))	
			inputItemEle.setAttribute(A_OIC_LINE_ID,orderLineEle.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
		}
		if(logger.isDebugEnabled()) 
			logger.debug("Input XML for Reservation JSON::"+KohlsXMLUtil.getXMLString(inputToJSON));
			return inputToJSON;
	}

	
	
	
	@Override
	public void setProperties(Properties sysProp) throws Exception {
		if (sysProp != null) {
			this.props = sysProp;
		}
		
	}
	
	/**
	 * Make reservation calls to OIC, get the reservation details and update Input with the reservation details.
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws Exception 
	 */
	public Document assignReservationToOrderLines(YFSEnvironment env,
 			Document inDoc) throws YFSException {
 		if(logger.isDebugEnabled()) 
 			logger.debug("Input of assignReservationToOrderLines::"+KohlsXMLUtil.getXMLString(inDoc));
 		Document outDoc=null;
 		String strClientAuth="";
 		String strOICReservationResponse="";
 		try {
 			if(!YFCCommon.isVoid(inDoc)){
 			strClientAuth=kohlsOMSOICIntegrationAdapterAccessToken.getKohlsOICAuth();
 			//Verify if Client Token exists
 			if(!YFCObject.isVoid(strClientAuth)){
 			strOICReservationResponse=getReserveInventoryXML(strClientAuth, inDoc);
 			if(logger.isDebugEnabled())  
 				logger.debug("Output from OIC reservation call in BeforeChangeOrerUE::"+strOICReservationResponse);
 			if(!YFCCommon.isStringVoid(strOICReservationResponse) && strOICReservationResponse.contains(SUCCESS)){
 				outDoc=appendReservationDetailsAtOrderLines(env,inDoc);
 			}}//Throw exception when client token is not available, when JWT jars are absent, system throws null token error
 			else{
 				logger.error("UNABLE TO ADD ITEM :: Token IS BLANK/NULL");
 				throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD/DELETE ITEM","UNABLE TO ADD/DELETE ITEM");
 			} 			
 			if(YFCCommon.isVoid(outDoc)){
 				outDoc=inDoc;
 			}
 			}
 		}catch(YFSException e){
 			throw e;
 		}
 		catch (JSONException | IOException e) {
 			logger.error(e);
 		}catch(IllegalArgumentException e){
 			logger.error(e);
 			throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM TO THE CART","UNABLE TO ADD ITEM TO THE CART");
 		}
 		catch (Exception e) {
 			//Handle Connect Exception, Unknown Host, IO Exception, Socket TimeOut Exception
 			logger.error("UNABLE TO ADD ITEM :: ConnectException/UnknownHostException/IOException/SocketTimeoutException at OIC", e);
			YFSException es = (YFSException) e;
			//if (e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.net.UnknownHostException || e.getCause() instanceof java.io.IOException || e.getCause() instanceof java.net.SocketTimeoutException) {
				throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD/DELETE ITEM","UNABLE TO ADD/DELETE ITEM");
		//	}
		}
 		if(logger.isDebugEnabled()) 
 			logger.debug("Input of assignReservationToOrderLines::"+KohlsXMLUtil.getXMLString(outDoc));
 		return inDoc;
 	}
 	

 	/** 
 	 * Append /OrderLineReservations/OrderLineReservation element for each 
 	 * Order/OrderLines/OrderLine in the input with the output from OIC.
 	 * @param inDoc
 	 * @return
 	 * @throws TransformerException 
 	 * @throws ParserConfigurationException 
 	 */
 	public Document appendReservationDetailsAtOrderLines(YFSEnvironment env, Document inDoc) throws YFSException, ParserConfigurationException, TransformerException{
 		if(logger.isDebugEnabled()) 
 			logger.debug("Input of appendReservationDetailsAtOrderLines::"+KohlsXMLUtil.getXMLString(inDoc));
		Element eleInDoc=inDoc.getDocumentElement();
		if(!YFCCommon.isVoid(eleInDoc)){
		NodeList orderLineList=SCXmlUtil.getXpathNodes(eleInDoc,"/Order/OrderLines/OrderLine[@DeliveryMethod='PICK' and @Action='CREATE']");
	//	NodeList orderLineList=inDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
 		for(int i=0;i<orderLineList.getLength();i++){
 			if(logger.isDebugEnabled()) 
 				logger.debug("Order Element in appendReservationDetailsAtOrderLines::"+KohlsXMLUtil.getElementXMLString(eleInDoc));
		  Element eleOrderLine=(Element)orderLineList.item(i);
		  Element eleOLItem=KohlsXMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_ITEM);
		  //Incase ItemID is absent at the orderLine, skip it for cancellation
		  if(!YFCCommon.isVoid(eleOrderLine) && !YFCCommon.isVoid(eleOLItem)){
			  
		  if(!YFCCommon.isVoid(eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
		  eleOrderLine.setAttribute(A_RESERVATION_ID, eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
		  Element eleOrderLineTranQuantity=KohlsXMLUtil.getChildElement(eleOrderLine, A_ORDER_LINE_TRAN_QUANTITY);
		  Element eleOLReservations=KohlsXMLUtil.createChild(eleOrderLine, E_ORDER_LINE_RESERVATIONS);
		  Element eleOLReservation=KohlsXMLUtil.createChild(eleOLReservations, E_ORDER_LINE_RESERVATION);
		
		  //Incase ItemID is absent at the orderLine, skip it for cancellation
		  if(YFCCommon.isVoid(eleOLItem.getAttribute(KohlsPOCConstant.A_ITEM_ID))){
			  continue;
		  }
		  eleOLReservation.setAttribute(KohlsPOCConstant.A_ITEM_ID,eleOLItem.getAttribute(KohlsPOCConstant.A_ITEM_ID) );
		  eleOLReservation.setAttribute(A_NODE,eleOrderLine.getAttribute(KohlsPOCConstant.A_SHIP_NODE) );
		  
		  if(!YFCCommon.isVoid(eleOrderLineTranQuantity)){	
			  
		  if(!YFCCommon.isVoid(eleOrderLineTranQuantity.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY)))
		  eleOLReservation.setAttribute(KohlsPOCConstant.A_QUANTITY,eleOrderLineTranQuantity.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY) );
		  
		  if(!YFCCommon.isVoid(eleOrderLineTranQuantity.getAttribute(A_TRANSACTIONAL_UOM)))
		  eleOLReservation.setAttribute(A_UNIT_OF_MEASURE,eleOrderLineTranQuantity.getAttribute(A_TRANSACTIONAL_UOM) );
		  }
		  if(!YFCCommon.isVoid(eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
		  eleOLReservation.setAttribute(A_RESERVATION_ID,eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO) );
		  
		  //Default product class to "Good" always
		  eleOLReservation.setAttribute(KohlsPOCConstant.A_PRODUCT_CLASS,"Good" );
		  }
		}
		}
 		if(logger.isDebugEnabled()) 
 			logger.debug("Output of appendReservationDetailsAtOrderLines::"+KohlsXMLUtil.getXMLString(inDoc));
 		return inDoc;
 	}

 	/** 
 	 * Verify the request is for OMNI Order Pick Line, if so get reservation from OIC and update reservation details at OrderLine.
 	 * @param inDoc
 	 * @throws TransformerException 
 	 * @throws ParserConfigurationException 
 	 * @throws Exception 
 	 */
 	public Document checkIfAddLineForPick(YFSEnvironment env,Document inDoc) throws YFSException, TransformerException, ParserConfigurationException {
 		//verify if the request is for omni add line scenario
 		if(logger.isDebugEnabled()) 
 			logger.debug("Input to checkIfAddLineForPick::"+KohlsXMLUtil.getXMLString(inDoc));
 		Element orderEle=inDoc.getDocumentElement();
 		Element eleOrderExtn=KohlsXMLUtil.getElementByXpath(orderEle.getOwnerDocument(),"/Order/Extn");
 		//Verify if Extn Is the Input
 		if(!YFCCommon.isVoid(eleOrderExtn)){
 			if(!YFCCommon.isVoid(eleOrderExtn.getAttribute(A_EXTN_IS_OMNI)) && eleOrderExtn.getAttribute(A_EXTN_IS_OMNI).equalsIgnoreCase("Y"))
			{
	    	if(logger.isDebugEnabled()) 
	    		logger.debug("It is Omni Order -- verify if Pick Line  ");	  
	    	String strOrderNo=orderEle.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
	    	String strOHK=orderEle.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
	    	if(YFCCommon.isVoid(strOrderNo) && YFCCommon.isVoid(strOHK)){
	    		inDoc=createOrderNoForOmni(inDoc);
	    	}
	    	NodeList orderLineList=SCXmlUtil.getXpathNodes(orderEle,"/Order/OrderLines/OrderLine[@DeliveryMethod='PICK' and @Action='CREATE']");
	 		if(orderLineList.getLength()>0) {
	    	//Request of  Add Line
			
			//Add Prime Line No's on orderLines
	 		if(logger.isDebugEnabled())
	 			logger.debug("Add PrimeLineNos");
	 		inDoc=addPrimeLineNo(env, inDoc);
			
	 		//set  dates for GIV reservation calls
	 		if(!YFCCommon.isVoid(strIsOICorGIV) && strIsOICorGIV.equalsIgnoreCase("N")){
	 		if(logger.isDebugEnabled())
	 			logger.debug("Add Dates in Input to use it for GIV Calls");
			inDoc=updateMissingDatesForGIVCalls(inDoc);
			}
	 		else{
			//verify server type only for OIC calls
			updateServerType(inDoc);
	 		}  
	 	}}
 		}if(logger.isDebugEnabled()) 
 			logger.debug("Input of checkIfAddLineForPick::"+KohlsXMLUtil.getXMLString(inDoc));
 		
 		return inDoc;
 	}




	/**
	 * This method will getCommonCodeList call and verify if OMS has to be integrated with OIC or with GIV.
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws ParserConfigurationException 
	 */
	public String integrateWithOICorGIV(YFSEnvironment env, Document inDoc) throws ParserConfigurationException {
		//call getCommonCodeList
		Document inDocGetCommonCodeList=KohlsXMLUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
		Element eleGetCommonCodeList=inDocGetCommonCodeList.getDocumentElement();
		eleGetCommonCodeList.setAttribute(KohlsPOCConstant.A_CODE_TYPE, A_IS_OIC_ENABLED);
	
		YFCDocument getCommonCodeListTemplate = YFCDocument.createDocument(E_COMMON_CODE_LIST);
		YFCElement eleCommonCode = getCommonCodeListTemplate.getDocumentElement()
				.createChild(KohlsPOCConstant.E_COMMON_CODE);
		eleCommonCode.setAttribute(KohlsPOCConstant.A_CODE_TYPE, "");
		eleCommonCode.setAttribute(KohlsPOCConstant.A_CODE_VALUE, "");
		env.setApiTemplate(KohlsPOCConstant.API_GET_COMMON_CODE_LIST, getCommonCodeListTemplate.getDocument());
		Document outDocGetCommonCodeList;
		try {
			outDocGetCommonCodeList = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_COMMON_CODE_LIST,inDocGetCommonCodeList);
			if(!YFCCommon.isVoid(outDocGetCommonCodeList)){
				strIsOICorGIV=SCXmlUtil.getXpathAttribute(outDocGetCommonCodeList.getDocumentElement(), "/CommonCodeList/CommonCode/@CodeValue");
			}
		} catch (YFSException e) {
			logger.error(e);
		} catch (RemoteException e) {
			logger.error(e);
		} catch (Exception e) {
			logger.error(e);
		}
		env.clearApiTemplate(KohlsPOCConstant.API_GET_COMMON_CODE_LIST);
		//Return Y if OIC enabled else return Y or Blank value
		return strIsOICorGIV;
	}


	/**
 	 * Verify the serverType for edge and invoke corp for reservation calls to OIC
 	 * @param inDoc
 	 */
	private void updateServerType(Document inDoc) {
		if(logger.isDebugEnabled()) 
			logger.debug("::: Inside updateServerType :::");
		//Verify if edge deployment
	    if(ServerTypeHelper.amIOnEdgeServer()){
		      if(logger.isDebugEnabled()) 
		    	  logger.debug("On Edge:: Make Corp calls to OIC");
		      Element eleAdditionalInfo =KohlsXMLUtil.createChild(inDoc.getDocumentElement(),KohlsXMLLiterals.E_YFCADDITIONALINFO);
		      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_MOTHERSHIP);        
	  }	}
 		
 	
 	/**
 	 *  Verify the request is for OMNI Order Pick Line, if so cancel reservation at OIC and remove reservation details at OrderLine.
 	 * @param inDoc
 	 * @throws RemoteException 
 	 * @throws ParserConfigurationException 
 	 * @throws TransformerException 
 	 * @throws Exception 
 	 */
 	public Document checkIfCancelLineForPick(YFSEnvironment env,Document inDoc) throws YFSException, RemoteException, ParserConfigurationException, TransformerException {
 		if(logger.isDebugEnabled()) 
 			logger.debug("Input of checkIfCancelLineForPick::"+KohlsXMLUtil.getXMLString(inDoc));
 		String strClientAuth="";
 		String strOICReservationResponse="";
 		boolean isReserved=false;
 		Element eleOrderExtn=KohlsXMLUtil.getElementByXpath(inDoc,"/Order/Extn");
 		//if(!YFCCommon.isVoid(eleOrderExtn) && !YFCCommon.isVoid(eleOrderExtn.getAttribute(A_EXTN_IS_OMNI)) && eleOrderExtn.getAttribute(A_EXTN_IS_OMNI).equalsIgnoreCase(KohlsPOCConstant.YES))
 		{  	if(logger.isDebugEnabled())
 	    	  logger.debug("It is Omni Order ");
 	    	NodeList orderLineList=SCXmlUtil.getXpathNodes(inDoc.getDocumentElement(),"/Order/OrderLines/OrderLine[@DeliveryMethod='PICK' and @Action='CANCEL' ]");
     		
 	    	if(orderLineList.getLength()==0){
 	    		//Consider it as MidVoid or Complete Void and get the Pick Line list and send cancelReservation call to GIV/OIC
 	    		inDoc=verifyAndCancelAllPickLinesForCompleteVoid(env, inDoc);
 	    	}
 	    	if(orderLineList.getLength()>0) {
     		  if(logger.isDebugEnabled()) logger.debug("It is Pick Line");
     		//Remove ReservationID from OrderLine
 			for(int i=0;i<orderLineList.getLength();i++){
 				Element eleOrderLine=(Element)orderLineList.item(i);
 				if(!YFCCommon.isVoid(eleOrderLine.getAttribute(A_RESERVATION_ID))){
 				eleOrderLine.setAttribute(A_RESERVATION_ID, "");
 				isReserved=true;
 				}}
     		//Request of  Add Line
 			if(logger.isDebugEnabled()) 
 				logger.debug("Inside removeReservationToOrderLines::");
 			
 			//Verify if the lines were reserved before
 			if(isReserved){
 			String strIsOICorGIV=integrateWithOICorGIV(env, inDoc);
 			try {
 			if(!YFCCommon.isVoid(strIsOICorGIV) && strIsOICorGIV.equalsIgnoreCase(KohlsPOCConstant.YES)){
 	 			strClientAuth=kohlsOMSOICIntegrationAdapterAccessToken.getKohlsOICAuth();
 	 			if(!YFCCommon.isVoid(strClientAuth))
 	 				strOICReservationResponse=getReservationCancellationXML(strClientAuth,inDoc);
 	 			 if(logger.isDebugEnabled())  
 	 				logger.debug("Output of checkIfCancelLineForPick in BeforeChangeOrderUE::"+strOICReservationResponse);
 	 		} else{
 	 			KOHLSBaseApi.invokeService(env, "KohlsOMSGIVCancelReservationSynService", inDoc);
 	 			if(logger.isDebugEnabled())  
 	 				logger.debug("Output of checkIfCancelLineForPick in BeforeChangeOrerUE:: KohlsOMSGIVCancelReservationSynService"+strOICReservationResponse);
 	 		}}catch (YFSException e) {
 	 			logger.error("Error in checkIfCancelLineForPick while making cancel Reservation calls");
				throw e;
			} catch (JSONException | IOException e) {
				logger.error(e);
 	 		}catch (Exception e) {
 	 			logger.error(e);
 	 		}}}
     		
     		else{
     			try {
					verifyAndCancelAllPickLinesForCompleteVoid(env, inDoc);
				} catch (YFSException e) {
					throw e;
				} catch (JSONException | IOException e) {
					logger.error(e);
	 	 		}catch (Exception e) {
	 	 			logger.error(e);
	 	 		}
     		}
     		
     		}
 		  if(logger.isDebugEnabled()) 
 			logger.debug("Output of checkIfCancelLineForPick::"+KohlsXMLUtil.getXMLString(inDoc));
 		
 		return inDoc;
 	}
 	
 	/** Assign Prime Line Numbers to all Order Lines in the Input	
 	 * @param env
 	 * @param inDoc
 	 * @return
 	 */	
 	public Document addPrimeLineNo(YFSEnvironment env, Document inDoc) {
 		if(logger.isDebugEnabled()) 
 			logger.debug("Input of addPrimeLineNo::"+KohlsXMLUtil.getXMLString(inDoc));
 		//Verify if it is a call from beforeCreateOrderUE
		Element eleOrder=inDoc.getDocumentElement();
		int maxLineNo=0;
		//Added for null pointer
		if (null!=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY)) {
		String sOHK=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		 if(YFCCommon.isVoid(sOHK)){
			maxLineNo=0;
		 }else{
		 maxLineNo=Integer.parseInt(getNumOrderLines(env,inDoc));
		 }
		NodeList orderLineList=inDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
		for(int i=0;i< orderLineList.getLength();i++){
			Element eleOrderLine=(Element)orderLineList.item(i);
		    eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, String.valueOf(++maxLineNo));
		}
		if(logger.isDebugEnabled()) 
			logger.debug("output of addPrimeLineNo::"+KohlsXMLUtil.getXMLString(inDoc));
		}
		return inDoc;
 	}
 	
 	
	/** This method calls getOrderList on Order details in the input to get the maximum 
	 * order lines existing on the order currently.
	 * @param env
	 * @param inDoc
	 * @return
	 */
	private String getNumOrderLines(YFSEnvironment env,Document inDoc) {
	   if(logger.isDebugEnabled())
		   logger.debug("Input of callGetOrderList::"+KohlsXMLUtil.getXMLString(inDoc));
	   Element eleOrder=inDoc.getDocumentElement(); 
	   String sOrderHeaderKey="";
	   String sOrderNo="";
	   String sEnterpriseCode="";
	   String strMaxLineNo="";
	   String sDocType="";
	   NodeList orderLineList;
	   if(!YFCCommon.isVoid(eleOrder)){
		   
	   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY)))
	    sOrderHeaderKey=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
	   
	   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
	    sOrderNo=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
	   
	   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE)))
	    sEnterpriseCode = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
	   
	   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE)))
	    sDocType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
	   
	   Document docGetOrderDetailsOut = null;
	   try {
		   Document docGetOrderDetailsIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
		   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
		   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sOrderNo);
		   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, sEnterpriseCode);
		   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, sDocType);
		   
				   
		   if(logger.isDebugEnabled())
			   logger.debug("Invoking getOrderList API with input xml: \n"+KohlsXMLUtil.getXMLString(docGetOrderDetailsIn));
		   if(!YFCCommon.isVoid(sOrderHeaderKey)){
			   docGetOrderDetailsOut = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ORDER_LIST,docGetOrderDetailsIn );
		   }
	   if(logger.isDebugEnabled())
		   logger.debug("getOrderList output xml: \n"+KohlsXMLUtil.getXMLString(docGetOrderDetailsOut));
	   if(!YFCCommon.isVoid(docGetOrderDetailsIn)){
	    orderLineList=docGetOrderDetailsOut.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
	    strMaxLineNo = String.valueOf(orderLineList.getLength());
	   } }
	    catch(Exception ex){
	    	logger.error(ex);
	   } }
	   if(logger.isDebugEnabled())  
		   logger.debug("output of callGetOrderList::Max Prime Line No"+strMaxLineNo);
	   return strMaxLineNo;
	}
	

	
	/**This method creates OrderNo for an order which has PICK line added as 
	 * first order line.
	 * @param inDoc
	 * @return
	 */
	private Document createOrderNoForOmni(Document inDoc) {	
		
		if(logger.isDebugEnabled()) 
			logger.debug("Input of createOrderNoForOmni::"+KohlsXMLUtil.getXMLString(inDoc));
		String strPosSequenceNo="";
		String strSellerOrganizationCode="";
		String strTerminalID="";
	 	Element eleOrder=inDoc.getDocumentElement();
		if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO)))
	 	 strPosSequenceNo=eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
		
		if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE)))
	 	strSellerOrganizationCode=eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
		
		if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID)))
	 	 strTerminalID=eleOrder.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
	    Element eleOrderDate=(Element)eleOrder.getElementsByTagName(KohlsPOCConstant.A_ORDER_DATE).item(0);
	    
	    if(!YFCCommon.isVoid(eleOrderDate) || YFCCommon.isVoid(eleOrderDate.getAttribute(A_ACTUAL_DATE)))
	    	strOrderDate=eleOrderDate.getAttribute(A_ACTUAL_DATE);
	    else{
	    	strOrderDate=new SimpleDateFormat(KohlsPOCConstant.HD_DATE_FORMAT).format(Calendar.getInstance().getTime()); 
	    }
	    String strFinalDate="";
	    try{
		    DateFormat originalFormat = new SimpleDateFormat(KohlsPOCConstant.INV_DATE_FORMAT, Locale.US);
		    DateFormat targetFormat = new SimpleDateFormat(KohlsPOCConstant.YY_MM_DD);
		    Date date = originalFormat.parse(strOrderDate);
		    String formattedDate = targetFormat.format(date);
		    strFinalDate=formattedDate.substring(0, 6);
		    if(logger.isDebugEnabled()) 
		    	logger.debug("formattedDate::"+formattedDate);
	    } catch (Exception e) {
	       logger.debug(e);
	   }
	   
	      //Added For PST-2587  - START
	    // teminal id 3 digits
	    strTerminalID=StringUtils.leftPad(strTerminalID, 3, "0");

	    //StoreNumber 4 digits
	    strSellerOrganizationCode=StringUtils.leftPad(strSellerOrganizationCode, 4, "0");

	    //PosSequenceNo 4 digits
	    strPosSequenceNo=StringUtils.leftPad(strPosSequenceNo, 4, "0");
		
	   //Added For PST-2587  - END	
	    //Form OrderNo   
	    String strOrderNo=strFinalDate+strSellerOrganizationCode+strTerminalID+strPosSequenceNo;
	    inDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOrderNo);
	    eleOrderDate.setAttribute(A_ACTUAL_DATE, strOrderDate);
	    if(logger.isDebugEnabled()) 
	    	{	logger.debug("Generated OrderNo::"+strOrderNo);
	    		logger.debug("Output of createOrderForOmni::"+KohlsXMLUtil.getXMLString(inDoc));
	    	}
	    return inDoc;
		}



	/**
	 * This method adds ExtnExpirationDateTime and ExtnRequestDateTime incase missing in the input.
	 * these dates are needed to get the reservation response from GIV.
	 * @param eleOrder
	 * @return 
	 */
	private Document updateMissingDatesForGIVCalls(Document inDoc) {
		logger.debug("Inside updateMissingDatesForGIVCalls::: ");
		Element eleOrder=inDoc.getDocumentElement();
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdfAmerica = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		TimeZone tzInAmerica = TimeZone.getTimeZone("CST");
		String sDateInAmerica = sdfAmerica.format(cal.getTime()); // Convert to String first
		cal.setTimeZone(tzInAmerica);
		
		Date dateInAmerica;
		String strSysDate="";
		String strReqEndDate="";
		String strExpirationDate="";
		try {
		//Compute ReqStartDate
		dateInAmerica = sdfAmerica.parse(sDateInAmerica);
		sdfAmerica.setTimeZone(tzInAmerica);
		strSysDate=sdfAmerica.format(dateInAmerica);
	
		//Compute ReqEndDate
		strReqEndDate="";
		//Make it 12  -- option1
		
		if(cal.get(Calendar.HOUR_OF_DAY)<8){
			cal.set(Calendar.HOUR_OF_DAY, 12);
			cal.set(Calendar.MINUTE, 00);
			cal.set(Calendar.SECOND, 00);
			strReqEndDate=sdfAmerica.format(cal.getTime());
		}
		//Make it next day 12 -- option2
		else if(cal.get(Calendar.HOUR_OF_DAY)>17){
			cal.add(Calendar.DATE, 1);
			cal.set(Calendar.HOUR_OF_DAY, 12);
			cal.set(Calendar.MINUTE, 00);
			cal.set(Calendar.SECOND, 00);
			strReqEndDate=sdfAmerica.format(cal.getTime());
		}
		//Add 4 hrs  -- option3
		else{
		cal.add(cal.HOUR_OF_DAY, 4);
		strReqEndDate=sdfAmerica.format(cal.getTime());
		}	
		strReqEndDate=sdfAmerica.format(cal.getTime());
		System.out.println("strReqEndDate::"+strReqEndDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Compute ExpirationDate
		cal.add(Calendar.DATE, 5);
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		strExpirationDate=sdfAmerica.format(cal.getTime());
		
	   //updateMissingDates to SysDates
		eleOrder.setAttribute(A_REQ_START_DATE,strSysDate);	
		eleOrder.setAttribute(A_REQ_END_DATE,strReqEndDate);	
		eleOrder.setAttribute(A_EXPIRATION_DATE_TIME,strExpirationDate);
		
	    logger.debug("updateMissingDatesForGIVCalls::"+KohlsXMLUtil.getXMLString(inDoc));
	    return inDoc;
	}
	
	
	/**
	 * This method adds ExtnExpirationDateTime and ExtnRequestDateTime incase missing in the input.
	 * these dates are needed to get the reservation response from GIV.
	 * @param eleOrder
	 * @return 
	 */
	public Document verifyGIVResponse(YFSEnvironment env,Document inDoc) throws YFSException{
		//Iterate through PromiseLines in GIV response
		logger.debug("Input to verifyGIVResponse:: GIV Response"+KohlsXMLUtil.getXMLString(inDoc));
		try{
		if(!YFCObject.isNull(inDoc) && !YFCCommon.isVoid(inDoc)){
			NodeList promiseLineList=SCXmlUtil.getXpathNodes(inDoc.getDocumentElement(), "/PromiseHeader/PromiseLines/PromiseLine/Reservations");
			for(int i=0;i<promiseLineList.getLength();i++){
				Element promiseLineEle=(Element)promiseLineList.item(i);
				float totalReservedQty=Float.parseFloat(promiseLineEle.getAttribute(A_TOTAL_RESVD_QTY));
				float availableQty=Float.parseFloat(promiseLineEle.getAttribute(A_AVAILABLE_QTY));
				float qtyToBeReserved=Float.parseFloat(promiseLineEle.getAttribute(A_QTY_TO_BE_RESERVED));
				if(totalReservedQty<qtyToBeReserved){
					//Inventory Reservation Not Done in GIV
					throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM TO THE CART","UNABLE TO ADD ITEM TO THE CART");
				}logger.debug("output to verifyGIVResponse:: GIV Response :: ALL GOOD");
		}}}catch (YFSException e) {
			logger.error(e.getMessage(), "00000","YFSException in KohlsOMSOICIntegrationAdapter.callHttpInterop");
			throw e;
		}catch (Exception e) {
			logger.error("Error in Getting Reservation Response >>> KohlsOMSOICIntegrationAdapter.verifyGIVResponse()");
			logger.error(e.getMessage(), "00000","Exception in KohlsOMSOICIntegrationAdapter.callHttpInterop");
	    }
		return inDoc;
	}
	
	/**
	 * This Method  will call service that has http call to GIV service and handles any kind of connection exceptions.
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws YFSException
	 */
	public Document callHttpInterop(YFSEnvironment env,Document inDoc) throws YFSException{
		logger.debug("OIC is Disabled:: Integrate with GIV");
			try {
			 inDoc =KOHLSBaseApi.invokeService(env, "KohlsCreateReservationFromGIVSyncService", inDoc);
		}catch (YFSException e) {
			logger.error(e.getMessage(), "00000","YFSException in KohlsOMSOICIntegrationAdapter.callHttpInterop");
			throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM TO THE CART","UNABLE TO ADD ITEM TO THE CART");
		}catch (Exception e) {
		//Handle Connect Exception, Unknown Host, IO Exception, Socket TimeOut Exception
			logger.error(e.getMessage(), "00000","Exception in KohlsOMSOICIntegrationAdapter.callHttpInterop");
			logger.error("UNABLE TO ADD ITEM :: ConnectException/UnknownHostException/IOException/SocketTimeoutException at GIV", e);
			YFSException es = (YFSException) e;
			if (e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.net.UnknownHostException || e.getCause() instanceof java.io.IOException || e.getCause() instanceof java.net.SocketTimeoutException) {
				throw new YFSException("UNABLE TO ADD/DELETE ITEM", "UNABLE TO ADD ITEM TO THE CART","UNABLE TO ADD ITEM TO THE CART");
			}}
			
 		return inDoc;
	}
	
	
	/**
	 * This Method will send Inventory demand update to GIV when OIC is enabled for reservations.
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws YFSException
	 * @throws RemoteException 
	 * @throws ParserConfigurationException 
	 */
	public Document sendInventoryDemandUpdate(YFSEnvironment env,Document inDoc) throws YFSException, RemoteException, ParserConfigurationException{
		String strIsOIC=integrateWithOICorGIV(env, inDoc);
		if(!YFCCommon.isVoid(strIsOIC) || strIsOIC.equalsIgnoreCase("Y")){
			 try {
				KOHLSBaseApi.invokeService(env, "KohlsOMSOICToGIVInvUpdate", inDoc);
			} catch (Exception e) {
				logger.error(e);
			}
		}	return inDoc;
	}	
	
	/**
	 * This method will identify complete void for KCC rejection and make cancel reservation calls to OIC/GIV.
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws YFSException
	 * @throws RemoteException
	 */
	public  Document verifyAndCancelAllPickLinesForCompleteVoid(YFSEnvironment env,Document inDoc) throws YFSException, RemoteException{
		if(!YFCCommon.isVoid(inDoc) && inDoc.getDocumentElement().getElementsByTagName("OrderLine").getLength()==0){
			if(logger.isDebugEnabled())
				   logger.debug("Input of verifyAndCancelAllPickLinesForCompleteVoid::"+KohlsXMLUtil.getXMLString(inDoc));
			   Element eleOrder=inDoc.getDocumentElement(); 
			   String sOrderHeaderKey="";
			   String sOrderNo="";
			   String sEnterpriseCode="";
			   String strMaxLineNo="";
			   String sDocType="";
			   NodeList orderLineList;
			   if(!YFCCommon.isVoid(eleOrder)){
				   
			   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY)))
			    sOrderHeaderKey=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			   
			   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO)))
			    sOrderNo=eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
			   
			   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE)))
			    sEnterpriseCode = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
			   
			   if(!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE)))
			    sDocType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
			   
			   Document docGetOrderDetailsOut = null;
			   try {
				   Document docGetOrderDetailsIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
				   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
				   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, sOrderNo);
				   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, sEnterpriseCode);
				   docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, sDocType);
				   if(logger.isDebugEnabled())
					   logger.debug("Invoking getOrderList API with input xml: \n"+KohlsXMLUtil.getXMLString(docGetOrderDetailsIn));
				   if(!YFCCommon.isVoid(sOrderHeaderKey)){
					   docGetOrderDetailsOut = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ORDER_LIST, inDoc);
				   }
			   if(logger.isDebugEnabled())
				   logger.debug("getOrderList output xml: \n"+KohlsXMLUtil.getXMLString(docGetOrderDetailsOut));
			   if(!YFCCommon.isVoid(docGetOrderDetailsIn)){
			    orderLineList=docGetOrderDetailsOut.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			    Element eleOrderLines=KohlsXMLUtil.createChild(inDoc.getDocumentElement(),KohlsPOCConstant.ELEM_ORDER_LINES);
			    for(int i=0;i<orderLineList.getLength();i++){
			    	Element eleOrderLine=(Element)orderLineList.item(i);
			    	String strDeliveryMethod=eleOrderLine.getAttribute(KohlsConstant.A_DELIVERY_METHOD);
			    	if(!YFCCommon.isVoid(strDeliveryMethod)&& strDeliveryMethod.equalsIgnoreCase(KohlsConstant.PICK)){
			    		Element eleTempNode =(Element) inDoc.importNode(eleOrderLine, true);
			    		eleOrderLines.appendChild(eleTempNode);
			     	}
			    } } }
			    catch(Exception ex){
			    	logger.error(ex);
			   } }
			   if(logger.isDebugEnabled())  
				   logger.debug("output of verifyAndCancelAllPickLinesForCompleteVoid::"+KohlsXMLUtil.getXMLString(inDoc));
			   
		}
		return inDoc;
		
	}
}
