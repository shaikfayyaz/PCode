package com.kohls.poc.api;


import java.util.Properties;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.util.webserviceUtil.WebServiceCaller;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPocAssignGeoTAXInfoWebService extends KOHLSBaseApi {
  
	private static final YFCLogCategory LOG_CAT = YFCLogCategory.instance(KohlsPocAssignGeoTAXInfoWebService.class);
	
	public String GET_ORG_LIST_FOR_TAXGEOCODE_TEMPLATE =
		      "<OrganizationList><Organization OrganizationKey=''><BillingPersonInfo AddressLine1='' City='' Company='' Country='' State='' Suffix='' TaxGeoCode='' Title='' UseCount='' VerificationStatus='' ZipCode='' DayPhone=''/><CorporatePersonInfo TaxGeoCode='' AddressLine1='' City='' Company='' Country='' State='' Suffix='' Title='' UseCount='' VerificationStatus='' ZipCode='' DayPhone=''/></Organization></OrganizationList>";
	
	private final YFSException yfe = new YFSException();
	private Properties sysProperties ;
	/**
	 *  getOrganizationList will be invoked 
	 * @param env
	 * @param inXML
	 * @return
	 */
	public Document prepareInDocForPocAssignGeoTAXInfoWS(YFSEnvironment env, Document  inXML){
		
		Document docGetOrganizationList =null;
		Document modifiedInputForTaxGeoWs = null;
		try{
			docGetOrganizationList = KohlsCommonUtil.invokeAPI(env, GET_ORG_LIST_FOR_TAXGEOCODE_TEMPLATE ,KohlsPOCConstant.API_GET_ORGANIZATION_LIST, inXML);
			//setting txn object
			env.setTxnObject("outDocOrganizationList",docGetOrganizationList);			
			// prepareinput for the InvokeWebService class
			modifiedInputForTaxGeoWs = modifyInputAssignGeoTAXWS(docGetOrganizationList) ;
		}
		catch(Exception ex){
			LOG_CAT.error("Exception in prepareInDocForPocAssignGeoTAXInfoWS" + ex);
			  throw new YFCException("Error thrown prepareInDocForPocAssignGeoTAXInfoWS " + ex);
			
		}
		return modifiedInputForTaxGeoWs;
	}
	
	public  Document modifyInputAssignGeoTAXWS(Document docGetOrganizationList) {
		
		 Document inDocAssignGeoTAXWS = null;
		 
		if(!YFCCommon.isVoid(docGetOrganizationList)){
			Element eleCopPersonInfo= (Element)docGetOrganizationList.getElementsByTagName("CorporatePersonInfo").item(0);	
				
			 try{
				 inDocAssignGeoTAXWS = XMLUtil.createDocument("ass:AssignGeoTAXInfoRequest");		 
		        Element eleInXMLAssignGeoTAXWS = inDocAssignGeoTAXWS.getDocumentElement();
				String strGeoCodeWSNS = null;
                String strGeoCodeWSNSValue = null;                
                if( null != sysProperties){
                  strGeoCodeWSNS = sysProperties.getProperty("geoCodeWSNS");
                  strGeoCodeWSNSValue = sysProperties.getProperty("geoCodeWSNSValue");
                  
                } 		        
		        if(!YFCCommon.isVoid(strGeoCodeWSNS) && !YFCCommon.isVoid(strGeoCodeWSNSValue)){
			        	LOG_CAT.debug("strGeoCodeWSNS ::" + strGeoCodeWSNS + "strGeoCodeWSNSValue ::"+strGeoCodeWSNSValue);
			        	eleInXMLAssignGeoTAXWS.setAttribute(strGeoCodeWSNS,strGeoCodeWSNSValue);	
			        }
			        else{
			        eleInXMLAssignGeoTAXWS.setAttribute("xmlns:ass", "http://www.pb.com/spectrum/services/AssignGeoTAXInfo");
		        }  
		        Element eleInputPort = KohlsXMLUtil.createChild(eleInXMLAssignGeoTAXWS, "ass:input_port");
		        Element eleAddress = KohlsXMLUtil.createChild(eleInputPort, "ass:Address");
		        Element eleAddressLine1 = KohlsXMLUtil.createChild(eleAddress, "ass:AddressLine1");
		        eleAddressLine1.setTextContent(eleCopPersonInfo.getAttribute("AddressLine1"));
		        Element eleCity = KohlsXMLUtil.createChild(eleAddress, "ass:City");
		        eleCity.setTextContent(eleCopPersonInfo.getAttribute(KohlsPOCConstant.ATTR_CITY));
		        Element eleState = KohlsXMLUtil.createChild(eleAddress, "ass:StateProvince");
		        eleState.setTextContent(eleCopPersonInfo.getAttribute(KohlsPOCConstant.ATTR_STATE));
		        Element eleZipCode = KohlsXMLUtil.createChild(eleAddress, "ass:PostalCode");
		        eleZipCode.setTextContent(eleCopPersonInfo.getAttribute(KohlsPOCConstant.A_ZIP_CODE));
		        Element eleCountry = KohlsXMLUtil.createChild(eleAddress, "ass:"+KohlsPOCConstant.ATTR_COUNTRY);
		        eleCountry.setTextContent(eleCopPersonInfo.getAttribute(KohlsPOCConstant.ATTR_COUNTRY));
		        
		        LOG_CAT.debug(KohlsXMLUtil.getXMLString(inDocAssignGeoTAXWS));
		 }
				 
		 catch(Exception ex){			 
			 throw new YFCException("Error thrown in modifyInputAssignGeoTAXWS " + ex);	
		  }
		}
	        
	        return inDocAssignGeoTAXWS;
	}
	
public void updateGeoTaxInfo(YFSEnvironment env, Document docresponse){
		
	Document docOrganizationList = (Document)env.getTxnObject("outDocOrganizationList");
	try {
			//Document docOrganizationList = KohlsXMLUtil.getDocument(getOrganizationList);
			if(!YFCCommon.isVoid(docOrganizationList)){
			String strGeoTaxKey = getGeoTaxKey(docresponse);
			Element eleOrganization = (Element)docOrganizationList.getElementsByTagName("Organization").item(0);
			Element eleBillingInfo = (Element)eleOrganization.getElementsByTagName("BillingPersonInfo").item(0);
			eleBillingInfo.setAttribute("TaxGeoCode", strGeoTaxKey);
			Element eleCorporatePersonInfo = (Element)eleOrganization.getElementsByTagName("CorporatePersonInfo").item(0);
			eleCorporatePersonInfo.setAttribute("TaxGeoCode", strGeoTaxKey);
			LOG_CAT.debug(KohlsXMLUtil.getElementXMLString(eleOrganization));
			
			//Invoke manageOrganizationHierchy
			 KohlsCommonUtil.invokeAPI(env, "manageOrganizationHierarchy" , KohlsXMLUtil.getDocumentForElement(eleOrganization));
			}
			
		} catch (YFSException ex) {
			// throw new YFCException("Error thrown while updating geoCode ::updateGeoTaxInfo " + ex);
			 throw new YFSException("INVALID_GEOCODE_RESPONSE","INVALID_GEOCODE_RESPONSE","INVALID_GEOCODE_RESPONSE");
		}
	  	catch (Exception ex) {
		 throw new YFCException("Error thrown while updating geoCode ::updateGeoTaxInfo " + ex);
	  }
		
	}
	
	/**
	 * this method will update GeoTAXKey
	 * @param env
	 * @param docresponse
	 */
	public String getGeoTaxKey(Document docresponse){
		NodeList ndlist =docresponse.getElementsByTagName("GeoTAXKey");
		LOG_CAT.debug(ndlist.getLength());
		Element eleGeoTaxKey = (Element)ndlist.item(0);
		
		 String taxKey = eleGeoTaxKey.getTextContent();
		 String UpdatedTaxKey ="";
		 if (taxKey.length() == 2) {
			 UpdatedTaxKey= taxKey;
			} else if (taxKey.length() > 2) {
				UpdatedTaxKey = taxKey.substring(taxKey.length() - 2);
			} else {
			  // whatever is appropriate in this case
			  throw new IllegalArgumentException("word has less than 2 characters!");
			}
		 LOG_CAT.debug("taxKey"+taxKey+"newWord"+UpdatedTaxKey);
		 return UpdatedTaxKey;
	}
	/**
	 * prepare input xml to call getOrganizationList
	 * @param env
	 * @param strShipNode
	 * @return
	 */
	public static Document prepareinputDocument(YFSEnvironment env,String strShipNode){
		Document inDocument = null;
		try{
		inDocument = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORGANIZATION);
	        Element eleOrganization = inDocument.getDocumentElement();
	        eleOrganization.setAttribute(KohlsPOCConstant.ATTR_ORGANIZATION_KEY, strShipNode);
	       
		}
		catch(Exception ex){
			 throw new YFCException("Error thrown while prepareinputDocument ::" + ex);
		}
	       LOG_CAT.debug("inDocument"+KohlsXMLUtil.getXMLString(inDocument)); 
		return inDocument;
	}
	
	  public void setProperties(Properties prop) throws Exception {
	    this.sysProperties = prop;    
	  }
	
	
}
