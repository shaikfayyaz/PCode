package com.kohls.poc.api;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsMPOCCreateInputForPSA extends KOHLSBaseApi {

	private static final YFCLogCategory loggerForPosInvoice = YFCLogCategory
			.instance(KohlsCreateInputForPSA.class.getName());
	private static String strOrderInvoiceKey = null;
	private String strPSASellerOrgCode = null;
	private static Document docGetOrderInvoiceDetailsInput = null;
	private  Map<String, Element> mTieredDiscount = new LinkedHashMap<String, Element>();
	Document docOrderListOutput = null;
	Document doc = null;
	Document docOriginalSale = null;
	Document docInputForOrigSale = null;
	Document docInputForgetOrderDetail = null; 
	NodeList ndlOriginalSaleOrder = null;
	NodeList ndlPSASaleOrder = null;
	Element eleInputForOrigSale = null;
	Element elePSAOrder = null;
	Element eleRootElement = null;
	Element eleOrderOfSale = null;
	String strOHkey = null; 
	String strClobData = null;
	String strNoUPCMsg="No UPC Found";
	String strCurrentPOSSeqNo = "";
	
	/**
	 * This function prepares an input document for DataCollect 
	 * Author Kohls
	 * @param env
	 * @param inputdoc
	 * @return docGetOrderInvoiceDetailsInput
	 * @exception Exception
	 * 
	 */
	public Document PSAToTibco(YFSEnvironment env, Document InputDoc)
			throws Exception {

		loggerForPosInvoice.beginTimer("PSAToTibco");

		try {

			docGetOrderInvoiceDetailsInput = YFCDocument.createDocument(
					KohlsPOCConstant.API_GET_ORDER_INVOICE_DETAILS).getDocument();
			Element eleInvoiceInput = docGetOrderInvoiceDetailsInput
					.getDocumentElement();
			Element eleOrder = InputDoc.getDocumentElement();
			String strOHKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

			NodeList ndChargeTransDetails = (NodeList) XPathUtil.getNodeList(
					InputDoc.getDocumentElement(),
					KohlsPOCConstant.X_CHARGE_TRANSACTION_DETAIL);
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("Nodelist::" +ndChargeTransDetails);
			for (int i = 0; i < ndChargeTransDetails.getLength(); i++) {
				Element EleChargeTransDetail = (Element) ndChargeTransDetails
						.item(i);
				if(loggerForPosInvoice.isDebugEnabled()){
					loggerForPosInvoice.debug("Current element in nodelist is::"
							+XMLUtil.getElementXMLString(EleChargeTransDetail));
				}
				if (!YFCCommon.isVoid(EleChargeTransDetail
						.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY))) {
					strOrderInvoiceKey = EleChargeTransDetail
							.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
					//loggerForPosInvoice.debug("strOrderInvoiceKey::"
					// +strOrderInvoiceKey);
					 loggerForPosInvoice.debug("strOrderInvoiceKey::"
					 +strOrderInvoiceKey);
					eleInvoiceInput.setAttribute(KohlsPOCConstant.E_INVOICE_KEY,
							strOrderInvoiceKey);
					//System.out
			//				.println("Input to first api call::"
			//						+ XMLUtil
				//							.getXMLString(docGetOrderInvoiceDetailsInput));
					if(loggerForPosInvoice.isDebugEnabled()){
						loggerForPosInvoice.debug("Input to first api call::"
								+docGetOrderInvoiceDetailsInput);
					}
				}
			}

	// API Calls to Request Collection and Execute Collection  -- Begin -- 6/23/16
			Document docRequestOut=null;
			loggerForPosInvoice.debug("Invoking First Execute Collection API");
			docRequestOut=callExecuteCollection(env,strOHKey);
					loggerForPosInvoice.debug("Invoking Second Request Collection API");
				docRequestOut=executeRequestCollection(env,strOHKey);
					
					if(!YFCCommon.isVoid(docRequestOut)){
						if(loggerForPosInvoice.isDebugEnabled()){
							loggerForPosInvoice.debug("docRequestOut="+XMLUtil.getXMLString(docRequestOut));
						}
					}
					
					// API Call to Request Collection and Execute Collection -- End -- 6/23/16

		} catch (Exception excp) {
			loggerForPosInvoice.error("PSAToTibco ex::" + excp);
			loggerForPosInvoice.error("Exception::" + excp);

		}
		return docGetOrderInvoiceDetailsInput;
	}


	public Document callExecuteCollection(YFSEnvironment env,String strInput)
	{
		loggerForPosInvoice.debug("Inside Execute Collection API");
		Document inputDoc = YFCDocument.createDocument(KohlsPOCConstant.ATTR_EXECUTE_COLLECTION).getDocument();
		try{
			
			loggerForPosInvoice.debug("Inside Execute Collection API");
		
		Element eleECRoot = inputDoc.getDocumentElement();
		eleECRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strInput);
		eleECRoot.setAttribute("IgnoreTransactionDependencies", "Y");
		//IgnoreTransactionDependencies="Y" 
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("Input to Execute Collection API ::"+XMLUtil.getXMLString(inputDoc));
		loggerForPosInvoice.debug("Input to Execute Collection API ::"+XMLUtil.getXMLString(inputDoc));
		}
		//KOHLSBaseApi.invokeAPI(env, "executeCollection", inputDoc);
		KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_EXECUTE_COLLECTION_PSA, inputDoc);
		}
		catch(Exception e) { loggerForPosInvoice.error("PSAToTibco ex::" + e); }
		return inputDoc;
	}

public Document executeRequestCollection(YFSEnvironment env , String strInput)
	{
	loggerForPosInvoice.debug("Inside Request Collection API");
	Document InputDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
		try
		{
			loggerForPosInvoice.debug("Inside Request Collection API");
		
			Element eleOrderRoot = InputDoc.getDocumentElement();
			eleOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strInput);
			eleOrderRoot.setAttribute("IgnoreTransactionDependencies", "Y");
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Input to Request Collection API ::"+XMLUtil.getXMLString(InputDoc));
			loggerForPosInvoice.debug("Input to Request Collection API ::"+XMLUtil.getXMLString(InputDoc));
			}
	//KOHLSBaseApi.invokeAPI(env, "requestCollection", InputDoc);
	KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_REQUEST_COLLECTION_PSA, InputDoc);
		
		}
		catch(Exception e){ loggerForPosInvoice.debug("PSAToTibco ex::" + e); }
		return InputDoc;
		
		
	}
	
	
	public Document CreateKohlsSalesForPSA(YFSEnvironment env, Document OriginalSaleDataDoc) {
       
        try {
        Element    elePSAOrder = OriginalSaleDataDoc.getDocumentElement();
            String strOHkey = elePSAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
            String OriginalSaleDataXML = XMLUtil.getXMLString(OriginalSaleDataDoc);
            
            
                        
            Document docInputForOrigSale = YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
            Element eleInputForOrigSale = docInputForOrigSale.getDocumentElement();
            eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
            eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA, OriginalSaleDataXML);
            eleInputForOrigSale.setAttribute(KohlsPOCConstant.E_RECEIPT_ID, strOHkey);
            
            return docInputForOrigSale;
        } catch (Exception e) {
            e.printStackTrace();
        }
    
        return OriginalSaleDataDoc;
    }

	
	/**
	 * This function updates the final output with the corresponding header level details 
	 * Author Kohls
	 * @param env
	 * @param docFinal
	 * @return docFinal
	 * @exception Exception
	 * 
	 */

	
	public Document replaceTotals(YFSEnvironment env, Document docFinal)
			throws Exception {

		loggerForPosInvoice.debug("Invoice Key is::" + strOrderInvoiceKey);
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("API input for getOrderInvoiceDetails is:::"
				+ XMLUtil.getXMLString(docGetOrderInvoiceDetailsInput));
		}
		try {

			Document docGetOrderInvDetailsOutTemplate = XMLUtil
					.getDocument(KohlsPOCConstant.TEMP_GET_ORDER_INVOICE_OUT_PSA);
		//	loggerForPosInvoice.debug("Output Template :: "+XMLUtil
		//			.getXMLString(docGetOrderInvDetailsOutTemplate));
	Document docGetOrderDetailsOutTemplate = XMLUtil
					.getDocument(KohlsPOCConstant.TEMP_GET_ORDER_DETAILS_OUT_PSA);
	if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Output Template :: "
					+ XMLUtil.getXMLString(docGetOrderDetailsOutTemplate));
			loggerForPosInvoice.debug("Output Template ::"
					+ XMLUtil.getXMLString(docGetOrderDetailsOutTemplate));
	}
			if (YFCCommon.isVoid(docGetOrderInvDetailsOutTemplate)) {

				YFSException yfsException = new YFSException();

				yfsException
						.setErrorDescription("Value of Output Template is null");

				throw yfsException;
			}
			
			/*
			 * String strGetOrderInvDetailsOutTemplate =
			 * "<InvoiceDetail><InvoiceHeader><Order><OverallTotals/></Order></InvoiceHeader></InvoiceDetail>"
			 * ; loggerForPosInvoice.debug("Output temp for invoice "+
			 * strGetOrderInvDetailsOutTemplate);
			 */

			Document docGetOrderInvDetails = KohlsCommonUtil.invokeAPI(env,
					docGetOrderInvDetailsOutTemplate, KohlsPOCConstant.GET_INVOICE_ORDER_DET,
					docGetOrderInvoiceDetailsInput);
		//	loggerForPosInvoice.debug("API output for getOrderInvoiceDetails is:::"
		//			+ XMLUtil.getXMLString(docGetOrderInvDetails));
			Element eleOverallTotals = (Element) docGetOrderInvDetails.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_INV_OVERALL_TOTALS)
					.item(0);

			Element eleInvoiceHeader = (Element)docFinal.getDocumentElement().getElementsByTagName(KohlsPOCConstant.XPATH_INVOICE_HEADER).item(0);

			Element eleOrder = (Element)docFinal.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_INV_ORDER).item(0);

			Element eleOrderExtn = (Element)docFinal.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_INV_ORDER_EXTN).item(0);

			// Begin Changes for Newly added Extn attributes at Order Level

			String strOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

			loggerForPosInvoice.debug("OrderHeaderKey is :::" + strOrderHeaderKey);
			loggerForPosInvoice.debug("OrderHeaderKey is :::"
					+ strOrderHeaderKey);

			// Preparing document for Input
			Document docGetOrderDetailsInput = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderInput = docGetOrderDetailsInput
					.getDocumentElement();

			eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);

			// getOrderDetails API Call
			Document docGetOrderDetails = KohlsCommonUtil.invokeAPI(env,
					docGetOrderDetailsOutTemplate, KohlsPOCConstant.API_GET_ORDER_DETAILS,
					docGetOrderDetailsInput);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("docGetOrderDetailsInput :::"
					+ XMLUtil.getXMLString(docGetOrderDetailsInput));
			loggerForPosInvoice.debug("docGetOrderDetailsInput :::"
					+ XMLUtil.getXMLString(docGetOrderDetailsInput));
			loggerForPosInvoice.debug("docGetOrderDetails :::"
					+ XMLUtil.getXMLString(docGetOrderDetails));
			loggerForPosInvoice.debug("docGetOrderDetails   :::"
					+ XMLUtil.getXMLString(docGetOrderDetails));
			}
			// Fix for 2777 -- Begin -- 5/8/16
			
			strPSASellerOrgCode = docGetOrderDetails.getDocumentElement().getAttribute("TransactionNo");
			
			if(!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
				
			// Extracting Seller Organization code from the Updated Transaction Number
			strPSASellerOrgCode = strPSASellerOrgCode.substring(12, 16);
			
			loggerForPosInvoice.debug("PSA seller Organization code is:::"+strPSASellerOrgCode);
			}
			//Fix for 2777 -- End -- 5/8/16
			
			
			Element eleOrderUpdatedExtn = (Element) ((NodeList) XPathUtil
					.getNodeList(docGetOrderDetails.getDocumentElement(),
							KohlsPOCConstant.XPATH_ORDER_EXTN)).item(0);


			Element elePersonInfoBillToExtn = (Element) ((NodeList) XPathUtil
					.getNodeList(docGetOrderDetails.getDocumentElement(),
							KohlsPOCConstant.X_ORD_PERSON_INFO_EXTN)).item(0);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("eleOrderUpdatedExtn :::"
					+ XMLUtil.getElementXMLString(eleOrderUpdatedExtn));

			loggerForPosInvoice.debug("eleOrderUpdatedExtn :::"
					+ XMLUtil.getElementXMLString(eleOrderUpdatedExtn));
			}
			// Fetching attributes for Kohls Cash Deactivation

			String strKohlsCashDeactivated = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD);
			String strCustLoyalCard = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_CUST_LOYAL_CARD);
			String strEmailAddress = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_EMAIL_ADDRESS);
			String strReasonCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE);
			String strCpnDeactivationCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_CODE);
			String strCpnEventCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_EVENT_CODE);
			String strCpnNumber = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_NUMBER);
			String strCpnPurchaseReturnAmount = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_RETURN_AMT);
			String strPsaResultCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_PSA_RESULT_CODE);
			  String strReturnTenderAmount =
			  eleOrderUpdatedExtn.getAttribute(KohlsXMLLiterals.A_EXTN_KCD_RETURN_TENDER_AMOUNT);
			 

			loggerForPosInvoice.debug("----Values for Kohls cash are ------");
			System.out.print("ExtnKohlsCashDeactivated"+strKohlsCashDeactivated);
			loggerForPosInvoice.debug("ExtnCustomerLoyalCard"+strCustLoyalCard);
			System.out.print("ExtnEmailAddress"+strEmailAddress);
			System.out.print("ExtnReasonCode"+strReasonCode);
			loggerForPosInvoice.debug("ExtnKCDCouponCode" + strCpnDeactivationCode);
			loggerForPosInvoice.debug("ExtnKCDCouponEventCode" + strCpnEventCode);
			loggerForPosInvoice.debug("ExtnKCDCouponNumber" + strCpnNumber);
			loggerForPosInvoice.debug("ExtnKCDCouponReturnAmount"
					+ strCpnPurchaseReturnAmount);
			loggerForPosInvoice.debug("ExtnKCDReturnTenderAmt"+strReturnTenderAmount);

			/*
			 * Following Attributes commented as not required String
			 * strStreetAddress = elePersonInfoBillTo
			 * .getAttribute("AddressLine1"); String strFirstName =
			 * elePersonInfoBillTo.getAttribute("FirstName"); String strLastName
			 * = elePersonInfoBillTo.getAttribute("LastName"); String strCity =
			 * elePersonInfoBillTo.getAttribute("City"); String strState =
			 * elePersonInfoBillTo.getAttribute("State"); String strZipCode =
			 * elePersonInfoBillTo.getAttribute("ZipCode"); String strPhoneno =
			 * elePersonInfoBillTo.getAttribute("DayPhone");
			 */
			
			// Fetching Attributes for Corporate Refund

			String strDriversLicense = elePersonInfoBillToExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_DRIVERS_LICENSE);

			Element eleInvoiceHeaderExtn = XMLUtil.createChild(
					eleInvoiceHeader, KohlsPOCConstant.A_EXTN);

		//	loggerForPosInvoice.debug("INV EXTn "
		//			+ XMLUtil.getElementXMLString(eleInvoiceHeaderExtn));

			if ((YFCCommon.isVoid(eleOverallTotals))
					|| (YFCCommon.isVoid(eleInvoiceHeader))
					|| (YFCCommon.isVoid(eleOrder))
					|| (YFCCommon.isVoid(eleInvoiceHeaderExtn))) {

				YFSException yfsException = new YFSException();

				yfsException
						.setErrorDescription("Value of Overall totals or InvoiceHeader or Order is null");

				throw yfsException;

			}

			String strGrandTotal = eleOverallTotals.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);

			String strGrandTax = eleOverallTotals.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);

			String strGrandDiscount = eleOverallTotals
					.getAttribute(KohlsPOCConstant.ATTR_GRAND_DISCOUNT);

			String strSellerOrganizationCode = eleOrder
					.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
			
			
			// Fix for 3558  -- Begin -- 8/26/16 
			
			String strLineSubTotal = eleOverallTotals.getAttribute("LineSubTotal");
			
			if(!YFCCommon.isStringVoid(strLineSubTotal))
			{
				eleInvoiceHeader.setAttribute("LineSubTotal", strLineSubTotal);
			}
			
			// Fix for 3558 -- End -- 8/26/16
			
			
		//	loggerForPosInvoice.debug("SellerOrganizationCode "
		//			+ strSellerOrganizationCode);

			eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, strGrandTotal);

			eleInvoiceHeader.setAttribute(KohlsPOCConstant.ATTR_TOTAL_DISCOUNT, strGrandDiscount);

			eleInvoiceHeader.setAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX, strGrandTax);

			eleInvoiceHeader.setAttribute(KohlsPOCConstant.ATTR_AMT_COLLECTED, strGrandTotal);
			eleInvoiceHeaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SHIP_NODE,
					strSellerOrganizationCode);

			// Setting Kohls Cash Related Attributes
			eleOrderExtn
					.setAttribute(KohlsPOCConstant.ATTR_EXTN_CUST_LOYAL_CARD, strCustLoyalCard);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD,
					strKohlsCashDeactivated);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_EMAIL_ADDRESS, strEmailAddress);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE, strReasonCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_CODE,
					strCpnDeactivationCode);
			eleOrderExtn
					.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_EVENT_CODE, strCpnEventCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_NUMBER, strCpnNumber);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_RETURN_AMT,
					strCpnPurchaseReturnAmount);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_PSA_RESULT_CODE, strPsaResultCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_RETURN_TENDER_AMT,strReturnTenderAmount);
			 

			/*
			 * Following attributes are commented as redundant in output
			 * 
			 * eleInvoiceHeaderExtn.setAttribute("FirstName", strFirstName);
			 * eleInvoiceHeaderExtn.setAttribute("LastName", strLastName);
			 * eleInvoiceHeaderExtn.setAttribute("AddressLine1",
			 * strStreetAddress); eleInvoiceHeaderExtn.setAttribute("DayPhone",
			 * strPhoneno); eleInvoiceHeaderExtn.setAttribute("City", strCity);
			 * eleInvoiceHeaderExtn.setAttribute("State", strState);
			 * eleInvoiceHeaderExtn.setAttribute("ZipCode", strZipCode);
			 */

			// Setting Corporate Refund Attributes
			eleInvoiceHeaderExtn.setAttribute(KohlsPOCConstant.ATTR_DRIVERS_LICENSE,
					strDriversLicense);

			
			// Method call to Append Sales orderline to Existing PSA order 
			docFinal = AppendSales(env, docFinal);
			
			// Appending Tiered Promotions at the Order Level for #3135 -- Begin -- 27/7/16 --
			
			 if(mTieredDiscount.size()>0){
				 loggerForPosInvoice.debug("Appending Tiered Promotions at the order Level");
				 Element eleTLDList = docFinal.createElement("TransactionLevelDiscountList");
				 eleOrder.appendChild(eleTLDList);
				 for(String key : mTieredDiscount.keySet()){
					 if(loggerForPosInvoice.isDebugEnabled()){
					 loggerForPosInvoice.debug("Importing key element"+XMLUtil.getElementXMLString(mTieredDiscount.get(key)));
					 }
					 XMLUtil.importElement(eleTLDList, mTieredDiscount.get(key));				
				 }
				 mTieredDiscount.clear();
			 }
			// Appending Tiered Promotions at the Order Level for #3135 -- End -- 27/7/16 --
			
		}

		catch (YFSException exception) {

			 loggerForPosInvoice.error(exception);
		//	loggerForPosInvoice.debug("exception" + exception);

		}

		return docFinal;

	}

	public Document AppendSales(YFSEnvironment env,Document inputDoc)
	{
		String strnegative="-";
		
		try
		{
			loggerForPosInvoice.debug("Inside Append Sale Method");
			elePSAOrder = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_ORDER);
			strOHkey = elePSAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			Element elePSAInvHeader = (Element) XPathUtil.getNode(inputDoc,KohlsPOCConstant.XPATH_INVOICE_HEADER);
			String strOIKey = elePSAInvHeader.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
			
			// Fetching CollectionDetails from API Output and Appending -- Begin -- 6/17/16
			
						Document docGetOrderInvDetailsInput = YFCDocument.createDocument(
								KohlsPOCConstant.E_GET_ORDER_INVOICE_DETAILS).getDocument();
						Element eleOrderInvoiceInput = docGetOrderInvDetailsInput 
								.getDocumentElement();

						eleOrderInvoiceInput.setAttribute(KohlsPOCConstant.E_INVOICE_KEY, strOIKey); 
						if(loggerForPosInvoice.isDebugEnabled()){
							loggerForPosInvoice.debug("API Input to getOrderInvoiceDetails :::"+XMLUtil.getXMLString(docGetOrderInvDetailsInput));			
						}
			// Invoking API with template -- 7/12/16
			Document docInvDetails = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT,
					KohlsPOCConstant.GET_INVOICE_ORDER_DET, docGetOrderInvDetailsInput);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("API Output to getOrderInvoiceDetails :::"+XMLUtil.getXMLString(docInvDetails));
			}
			Element eleCollectionDetails = (Element) XPathUtil.getNode(docInvDetails, KohlsPOCConstant.X_INV_COLLECTION_DETAILS);
			
			XMLUtil.removeChild(elePSAInvHeader,(Element) XPathUtil.getNode(inputDoc,KohlsPOCConstant.X_INV_COLLECTION_DETAILS));
			
			inputDoc.adoptNode(eleCollectionDetails);
			XMLUtil.appendChild(elePSAInvHeader, eleCollectionDetails);
			
			
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("Appended Invoice Header Element is ::"+XMLUtil.getElementXMLString(elePSAInvHeader));
			
			// Fetching CollectionDetails from API Output and Appending -- End -- 6/17/16
			
	
			// Prepare Input document for API call to fetch original Sales Data
			docInputForOrigSale =  YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			eleInputForOrigSale  = docInputForOrigSale.getDocumentElement();
			eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,strOHkey);
			
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("Document input to API call is::"+XMLUtil.getXMLString(docInputForOrigSale));
			// API call to fetch sales Data
			docOriginalSale = invokeService(env,KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS,docInputForOrigSale);
					 
			
			//Preparing input document for API call to fetch getOrderDetails
			
			docInputForgetOrderDetail =  YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
			eleInputForOrigSale  = docInputForgetOrderDetail.getDocumentElement();
			eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,strOHkey);
			
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("Document output of the API call is::"+XMLUtil.getXMLString(docOriginalSale));
			
			
			// Fetching ChargeTransactionDetails from API Output and Appending -- Begin -- 6/17/16
			
			Document docGetOrderDetailsOutput = KOHLSBaseApi.invokeAPI(env,KohlsPOCConstant.API_GET_ORDER_DETAILS, docInputForgetOrderDetail);
			
			// Changes for Corporate Refund Attributes -- Begin -- 6/22/16
			
			
			Element elePersonInfoBillTo = (Element) XPathUtil.getNode(docInvDetails, KohlsPOCConstant.X_INV_PERSON_INFO);
			
			if(!(YFCCommon.isVoid(elePersonInfoBillTo)))
			{
				NodeList ndlChargeTransactionDetails = XPathUtil.getNodeList(docGetOrderDetailsOutput, KohlsPOCConstant.X_CHARGE_TRANSACTION_DETAIL);
			
			
			for(int z=0;z<ndlChargeTransactionDetails.getLength();z++)
			{
				Element eleRoot = (Element) ndlChargeTransactionDetails.item(z);
				docGetOrderDetailsOutput.adoptNode(elePersonInfoBillTo);
				XMLUtil.importElement(eleRoot, elePersonInfoBillTo);
			}
			
			}
			// Changes for Corporate Refund Attributes -- End -- 6/22/16
			
			
			Element eleChargeTransactionDetails = (Element) XPathUtil.getNode(docGetOrderDetailsOutput, KohlsPOCConstant.X_CHARGE_TRANSACTION_DETAILS);
			
			Element eleChargeTransDetForPSA = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAILS);
			
			XMLUtil.removeChild(elePSAOrder, eleChargeTransDetForPSA);
			
			inputDoc.adoptNode(eleChargeTransactionDetails);
			XMLUtil.appendChild(elePSAOrder, eleChargeTransactionDetails);
			
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("Appended Order Element is ::"+XMLUtil.getElementXMLString(elePSAOrder));
			
			// Fetching ChargeTransactionDetails from API Output and Appending -- End -- 6/17/16
			
			// Parsing Clob Element into Document format 
			Element eleRootElement = docOriginalSale.getDocumentElement();
			
			 String strClobData = docOriginalSale.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);
			 
			 loggerForPosInvoice.debug("Clob object is:::"+strClobData);


			if (!strClobData.isEmpty()) {
				Document docClobData = XMLUtil.getDocument(strClobData);
				eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA,KohlsPOCConstant.BLANK);
				Element eleNewClob = docClobData.getDocumentElement();
				XMLUtil.importElement(eleRootElement, eleNewClob);
				
			}
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("After import root element is::"+XMLUtil.getElementXMLString(eleRootElement));
			
			//Fetching Order element from original Sales document
			eleOrderOfSale = (Element) XPathUtil.getNode(docOriginalSale ,KohlsPOCConstant.X_KOHLS_SALES_ORDER);
			
			
			// New Method Invocation For Appending Promotions And Taxes
			
			inputDoc = AppendPromotionAndTaxes(docOriginalSale,inputDoc);
			inputDoc = ConsolidateTaxAndTotalAmt(docOriginalSale,inputDoc);
			
			
			// Fetching Sales Order Data And Populating at InvoiceHeader level -- Begin -- 6/15/16
			
			
			Element elePSAextn = XMLUtil.getChildElement(elePSAOrder, KohlsPOCConstant.A_EXTN);
			
			String strPosSeqNo = elePSAextn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
			String strOrderDate = eleOrderOfSale.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
			String strTerminalId = eleOrderOfSale.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
			String strSellerOrgCode = eleOrderOfSale.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
			
			Element eleInvheaderExtn = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_EXTN);
			
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_ORDER_DATE,strOrderDate);
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_POS_SEQUEN_NO, strPosSeqNo);
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_TERMINAL_ID,strTerminalId);
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SELLER_ORG_CODE, strSellerOrgCode);
			
			// Adding Sales Data at Extn Level -- 6/25/16
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SHIP_NODE, strSellerOrgCode);
			
			// Fetching Sales Order Data And Populating at InvoiceHeader level -- End -- -- 6/15/16
			
			// Removing Clob Object from Sales Award Element -- Begin -- 6/15/16
			
			// Extracting Tiered Promo Discounts and Storing for #3135 -- Begin -- 27/7/16 --
			NodeList ndlOrderline = XPathUtil.getNodeList(docOriginalSale, KohlsPOCConstant.X_KOHLS_SALES_ORDERLINE);		
			
			if (ndlOrderline.getLength() != 0) {
				for (int i = 0; i < ndlOrderline.getLength(); i++) {

					DecimalFormat df = new DecimalFormat("0.00");
					Element eleOrderLine = (Element) ndlOrderline.item(i);
					
					if(loggerForPosInvoice.isDebugEnabled())
						loggerForPosInvoice.debug("Current OrderLine Element is ::"+XMLUtil.getElementXMLString(eleOrderLine));
					if (!YFCCommon.isVoid(eleOrderLine)) {
						String sOrderLineKey=eleOrderLine.getAttribute("OrderLineKey");
						 NodeList ndlAwards=XPathUtil.getNodeList(docOriginalSale.getDocumentElement(), 
								 "/KOHLSSalesForPsa/Order/OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/Awards/Award");

						if (!YFCCommon.isVoid(eleOrderLine.getAttribute(KohlsPOCConstant.A_GIFT_REG_ID))) {
							eleOrderLine.setAttribute("GiftRegistryID", eleOrderLine.getAttribute(KohlsPOCConstant.A_GIFT_REG_ID).trim());
						}else {
							eleOrderLine.setAttribute("GiftRegistryID","0");
						}
						if (ndlAwards != null) {
							for (int c = 0; c < ndlAwards.getLength(); c++) {
								Element eleAward = (Element) ndlAwards.item(c);
								String sAwardApplied = eleAward
										.getAttribute("AwardApplied");
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice
									.debug("Current Award Element is:::"
											+ XMLUtil
											.getElementXMLString(eleAward));
								Element eleExtn = XMLUtil.getChildElement(
										eleAward, KohlsPOCConstant.A_EXTN);
								
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice
									.debug("Current Extn element under Award is:::"
											+ XMLUtil
											.getElementXMLString(eleExtn));
								if (!YFCCommon.isVoid(eleExtn)) {
									String sExtnPromoScheme = eleExtn
											.getAttribute("ExtnPromoScheme");
									int iExtnPromoScheme = 0;
									if (!YFCCommon.isVoid(sExtnPromoScheme)) {
										iExtnPromoScheme = Integer
												.parseInt(sExtnPromoScheme);
									}
									String strExtnSaleHubData = eleExtn
											.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
									loggerForPosInvoice
											.debug("Extn element exists:Checking SalesHubData attribute");
									if (!YFCCommon.isVoid(strExtnSaleHubData)) {
										loggerForPosInvoice
												.debug("Inside Clob block : Parsing into document object");
										Document docSalesHubData = XMLUtil
												.getDocument(strExtnSaleHubData);
										eleExtn.setAttribute(
												KohlsPOCConstant.A_EXTN_SALES_HUB_DATA,
												KohlsPOCConstant.BLANK);
										Element eleDataSalesHub = docSalesHubData
												.getDocumentElement();
										loggerForPosInvoice
												.debug("Importing parsed Clob object into Extn element");
										XMLUtil.importElement(eleExtn,
												eleDataSalesHub);
										if (iExtnPromoScheme >= 400
												&& iExtnPromoScheme <= 500
												&& sAwardApplied
														.equalsIgnoreCase("Y")) {
											loggerForPosInvoice
													.debug("Inside Promo Scheme Block");
											String sPromoInterfaceId = eleDataSalesHub
													.getAttribute("PromoInterfaceId");
											String sDiscountPercent = eleDataSalesHub
													.getAttribute("DiscountPercent");
											if (!YFCCommon
													.isVoid(sDiscountPercent)) {
												sDiscountPercent = df
														.format(Double
																.parseDouble(sDiscountPercent) / 100.0);
												loggerForPosInvoice
														.debug("Inside not null block of Discount Percent");
											}
											String sTierAmtRchd = eleDataSalesHub
													.getAttribute("TierAmtRchd");
											String sTierQtyRchd = eleDataSalesHub
													.getAttribute("TierQtyRchd");
											String sAwardAmount = eleAward
													.getAttribute("AwardAmount");
											if (!mTieredDiscount
													.containsKey(sPromoInterfaceId)) {
												loggerForPosInvoice
														.debug("Updating mTieredDiscount hashmap with element and promoInterfaceId");
												Document docTLD = XMLUtil
														.createDocument("TransactionLevelDiscount");
												Element eleTLD = docTLD
														.getDocumentElement();
												eleTLD.setAttribute(
														"PromoInterfaceId",
														sPromoInterfaceId);
												eleTLD.setAttribute(
														"DiscountPercent",
														sDiscountPercent);
												eleTLD.setAttribute(
														"TierAmtRchd",
														sTierAmtRchd);
												eleTLD.setAttribute(
														"TierQtyRchd",
														sTierQtyRchd);
												eleTLD.setAttribute(
														"AwardAmount",
														sAwardAmount);
												eleTLD.setAttribute(
														"PromoScheme",
														sExtnPromoScheme);
												eleTLD.setAttribute(
														"DiscountTypeCode", "T");
												mTieredDiscount.put(
														sPromoInterfaceId,
														eleTLD);
												
												if(loggerForPosInvoice.isDebugEnabled())
													loggerForPosInvoice
													.debug(sPromoInterfaceId
															+ "Corresponding element is"
															+ XMLUtil
															.getElementXMLString(eleTLD));
											} else {
												loggerForPosInvoice
														.debug("Else Block for insertion in HashMap with promoInterfaceId");
												Element eleTLD = mTieredDiscount
														.get(sPromoInterfaceId);
												String sAwardAmt = eleTLD
														.getAttribute("AwardAmount");
												Double dOrigAwardAmt = 0.00;
												if (!YFCCommon
														.isVoid(sAwardAmt)) {
													dOrigAwardAmt = Double
															.parseDouble(sAwardAmt);
												}
												Double dAwardAmt = 0.00;
												if (!YFCCommon
														.isVoid(sAwardAmount)) {
													dAwardAmt = Double
															.parseDouble(sAwardAmount);
												}
												eleTLD.setAttribute(
														"AwardAmount",
														df.format(dOrigAwardAmt
																+ dAwardAmt));
												mTieredDiscount
														.remove(sPromoInterfaceId);
												mTieredDiscount.put(
														sPromoInterfaceId,
														eleTLD);
												
												if(loggerForPosInvoice.isDebugEnabled())
													loggerForPosInvoice
													.debug(sPromoInterfaceId
															+ "Corresponding element is"
															+ XMLUtil
															.getElementXMLString(eleTLD));
											}
										}

									}
								}
							}
						}
					}
				}

			}
			// Extracting Tiered Promo Discounts and Storing for # 3135 -- End -- 27/7/16 --
			 
			// Removing Clob Object from Sales Award Element -- End -- 6/15/16
			
			
			// Preparing NodeList of Sales and PSA Orderline to integrate 
			
			ndlOriginalSaleOrder =  (NodeList)docOriginalSale.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_KOHLS_SALES_ORDERLINE);
			
			ndlPSASaleOrder = (NodeList) inputDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_INV_ORDERLINE);
			
			// Fetching Temp NodeList of OrderLine elements in PSA document
	
			NodeList ndlTemp = (NodeList) inputDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_INV_ORDERLINE);
			// Fetching Parent element of Temp 
			
			Element eleTempParent = (Element)inputDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.X_INV_ORDERLINES).item(0);
		
			// Preparing Temp
			
			for(int b=0;b<ndlTemp.getLength();b++)
			{
				XMLUtil.removeChild(eleTempParent,(Element) ndlTemp.item(b));
			}
					
			// 	Comparing PrimeLineNo of Sales with PSA and Setting into Temp
			
			for(int i=0;i<ndlOriginalSaleOrder.getLength();i++)
			{
				Element eleCurrentElement = (Element) ndlOriginalSaleOrder.item(i);
				String strOrigPrimeLineNo = eleCurrentElement.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
				Element eleItemLevel = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.ELEM_ITEM);
				
				// Fix for 2969 -- begin
				
				Element eleCurrentExtn = XMLUtil.getChildElement(eleCurrentElement,"Extn");
				
				
				if(loggerForPosInvoice.isDebugEnabled())
					loggerForPosInvoice.debug("Current Extn Element is::"+XMLUtil.getElementXMLString(eleCurrentExtn));
				
				String strTaxInd = eleCurrentExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);
				
				strTaxInd = UpdateTaxIndType(strTaxInd);
				
				eleCurrentExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, strTaxInd);
				
				// Fix for 2969 -- End
				
				// Fix for UPC code at Sales OrderLine -- begin -- 6/15/16
				
				Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
				Element eleItemInput = docGetItemListInput.getDocumentElement();
				String strItemId = eleItemLevel
						.getAttribute(KohlsPOCConstant.A_ITEM_ID);
				String strUPCCode= eleItemLevel
						.getAttribute(KohlsPOCConstant.A_UPC_CODE);
				eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);
				
				Document docItemListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST, KohlsPOCConstant.API_GET_ITEM_LIST,docGetItemListInput);
				
				if(YFCCommon.isVoid(strUPCCode)|| strUPCCode.isEmpty() || strUPCCode == null) {
				
					String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput);
					if(YFCCommon.isVoid(upc_code)|| upc_code.isEmpty() || upc_code == null)
					{
						upc_code=strNoUPCMsg;
					}
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code );
				}
				else {
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
				}
				
				
				
				
				//Fix for UPC code at Sales OrderLine -- end -- 6/15/16
				
				
				// Setting LineTotal for Sales as negative -- Begin 
				Element eleLinePriceInfo = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.E_LINE_PRICE_INFO);
				Element eleLineOverrallTotals = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
				
				String strLineTotal1 = eleLinePriceInfo.getAttribute(KohlsPOCConstant.E_LINE_TOTAL);
				String strLineTotal2 = eleLineOverrallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL);
				strLineTotal2=strnegative.concat(strLineTotal2);
				 strLineTotal1 =strnegative.concat(strLineTotal1);
					eleLinePriceInfo.setAttribute(KohlsPOCConstant.E_LINE_TOTAL, strLineTotal1);
				eleLineOverrallTotals.setAttribute(KohlsPOCConstant.E_LINE_TOTAL,strLineTotal2);
				
				// Setting LineTotal for Sales as negative -- End 
				
			/*	//Setting Unit Price and Tax as negative -- Begin
				
				String strUnitPrice = eleLinePriceInfo.getAttribute("UnitPrice");
				String strTax = eleLineOverrallTotals.getAttribute("Tax");
				eleLinePriceInfo.setAttribute("UnitPrice", strnegative.concat(strUnitPrice));
				eleLineOverrallTotals.setAttribute("Tax", strnegative.concat(strTax));
				
				//Setting Unit Price and Tax as negative -- End
				
				//Setting ExtnSimplePromoPrice and ExtnNetPrice as negative -- Begin
				
				Element eleOrderLineExtn = XMLUtil.getChildElement(eleCurrentElement, "Extn");
				String strExtnSimplePromoPrice = eleOrderLineExtn.getAttribute("ExtnSimplePromoPrice");
				String strExtnNetPrice = eleOrderLineExtn.getAttribute("ExtnNetPrice");
				eleOrderLineExtn.setAttribute("ExtnSimplePromoPrice", strnegative.concat(strExtnSimplePromoPrice));
				eleOrderLineExtn.setAttribute("ExtnNetPrice", strnegative.concat(strExtnNetPrice));
				
				//Setting ExtnSimplePromoPrice and ExtnNetPrice as negative -- End
				
			*/	
				
				// Removing PLUResponseClob Object -- Begin
				
				Element eleCurrentElementExtn = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.A_EXTN);
				eleCurrentElementExtn.setAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE, KohlsPOCConstant.BLANK);
				
				// Removing PLUResponseClob Object -- End 
				
				// Fetching ExtnPLURetailAmt from Sale OrderLine Extn
				String strSalePLURetailAmt = eleCurrentElementExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT);
				
				
				if(loggerForPosInvoice.isDebugEnabled())
					loggerForPosInvoice.debug("Current sale element is::"+XMLUtil.getElementXMLString(eleCurrentElement));
				loggerForPosInvoice.debug("Current PrimeLine No is:::"+strOrigPrimeLineNo);
				
					for(int j=0;j<ndlPSASaleOrder.getLength();j++)
					{
						Element eleCurrentPSAElement = (Element) ndlPSASaleOrder.item(j);
						
						Element eleCurrentPSAElementExtn = XMLUtil.getChildElement(eleCurrentPSAElement, KohlsPOCConstant.A_EXTN);
						
						String strPSAPrimeLineNo = eleCurrentPSAElement.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
						
						// Fetching ExtnPLURetailAmt from PSA OrderLine Extn
						
						String strPSAPLURetailAmt = eleCurrentPSAElementExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT);
						
						
						if(loggerForPosInvoice.isDebugEnabled())
							loggerForPosInvoice.debug("Current PSA element is::"+XMLUtil.getElementXMLString(eleCurrentPSAElement));
						loggerForPosInvoice.debug("Current PrimeLine No of PSA element is:::"+strPSAPrimeLineNo );
						
							if(strOrigPrimeLineNo.equals(strPSAPrimeLineNo))
							{
								
									// Fix for 3557 -- Begin -- 8/25/16
								
								
								loggerForPosInvoice.debug("Inside Matching PrimeLine Number block ; now checking PLURetailAmounts");
								if((strSalePLURetailAmt.equalsIgnoreCase("0.00") && !strSalePLURetailAmt.equalsIgnoreCase(strPSAPLURetailAmt) && !YFCCommon.isStringVoid(strPSAPLURetailAmt)))
								{
									eleCurrentElementExtn.setAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, strPSAPLURetailAmt);
								}
								
								
									
									// Fix for 3557 -- End -- 8/25/16
									
									
								inputDoc.adoptNode(eleCurrentElement);
								XMLUtil.appendChild(eleTempParent, eleCurrentElement);
								XMLUtil.appendChild(eleTempParent, eleCurrentPSAElement);
								
							}
							else
							{
								/*inputDoc.adoptNode(eleCurrentElement);
								XMLUtil.appendChild(eleTempParent, eleCurrentElement);*/
								loggerForPosInvoice.debug("Inside else block: Shouldn't be here");
							
							}
						
					}
				
			}

			inputDoc = calculateTotalOrderLines(inputDoc);
			inputDoc = getNodeListToRemove(inputDoc);
			inputDoc = setExternalPayment(inputDoc);
			inputDoc = UpdateTotalChargedAmount(env,inputDoc);

			//Added PersonInfoBillTo - 6/28/2016 - Start
				/* Code fix required after new Tendering code -- Begin -- 1/8/16 --
			inputDoc = addPersonInfoBillTo(env,inputDoc);
				 Code fix required after new Tendering code -- End -- 1/8/16 -- */
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return inputDoc;
	}
	
	public Document UpdateTotalChargedAmount(YFSEnvironment env, Document inputDoc) {
	
		try{
			loggerForPosInvoice.debug("KohlsCreateInputForPSA.UpdateTotalChargedAmount - Start");
			String strnegative=KohlsPOCConstant.MINUS;
			String strTotalRefundedAmount = KohlsPOCConstant.DECIMAL_FORMAT;
			//Element elePersonInfoBillTo = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_PERSON_INFO).item(0);
			//Element elePaymentMethod = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_PAYMENT_METHOD).item(0);	
			/*if((!YFCCommon.isVoid(elePersonInfoBillTo)) && (!YFCCommon.isVoid(elePaymentMethod))){
			XMLUtil.appendChild(elePaymentMethod, elePersonInfoBillTo);
			}*/
				NodeList ndlCollectionDetails = XPathUtil.getNodeList(inputDoc.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail");
			
         if ( !YFCCommon.isVoid( ndlCollectionDetails ) )
         {
            int sCollDetailSize = ndlCollectionDetails.getLength();

            loggerForPosInvoice.debug( "KohlsCreateInputForPSA.UpdateTotalChargedAmount sCollDetailSize=" + sCollDetailSize );

            for ( int a = 0; a < sCollDetailSize; a++ )
            {
               Element eleCurrCollDetail = (Element) ndlCollectionDetails.item( a );
               if ( !YFCCommon.isVoid( eleCurrCollDetail ) )
               {
            	 
       			if(loggerForPosInvoice.isDebugEnabled())
                  loggerForPosInvoice.debug( "KohlsCreateInputForPSA.UpdateTotalChargedAmount eleCurrCollDEtail=" + XMLUtil.getElementXMLString( eleCurrCollDetail ) );
                  Element elePaymentMethod = (Element) eleCurrCollDetail.getElementsByTagName( "PaymentMethod" ).item( 0 );
                  /*
                   * if((!YFCCommon.isVoid(elePersonInfoBillTo)) && (!YFCCommon.isVoid(elePaymentMethod))){
                   * XMLUtil.appendChild(elePaymentMethod, elePersonInfoBillTo);
                   * }
                   */
                  if ( !YFCCommon.isVoid( elePaymentMethod ) )
                  {
                	  
                	  if(loggerForPosInvoice.isDebugEnabled())
                		  loggerForPosInvoice.debug( "KohlsCreateInputForPSA.UpdateTotalChargedAmount elePaymentMethod=" + XMLUtil.getElementXMLString( elePaymentMethod ) );
                     strTotalRefundedAmount = elePaymentMethod.getAttribute( "TotalRefundedAmount" );
                     loggerForPosInvoice.debug( "KohlsCreateInputForPSA.UpdateTotalChargedAmount. TotalRefundedAmount=" + strTotalRefundedAmount );
                     if ( !YFCCommon.isVoid( strTotalRefundedAmount ) )
                     {
                        strTotalRefundedAmount = strnegative.concat( strTotalRefundedAmount );
                        elePaymentMethod.setAttribute( KohlsPOCConstant.ATTR_TOTAL_CHARGED, strTotalRefundedAmount );
                     }
                  }
               }
            }
         }
			//Probable Changes for #4053 - POC Returns Team -- Looping through the CollectionDetails Missed -- End
		
			inputDoc=checkAndRemoveCollectionDetails(env,inputDoc);
			
			//Added for CorporateRefund 
				/* Code fix required after new Tendering code -- Begin -- 1/8/16 --
			inputDoc=changesForCorpRefund(env,inputDoc);
			
			Code fix required after new Tendering code -- End -- 1/8/16 -- */
			
			loggerForPosInvoice.debug("KohlsCreateInputForPSA.UpdateTotalChargedAmount - End");
		}catch(Exception e){
			loggerForPosInvoice.error(e.getMessage());
		}
	return inputDoc;
}


	public Document changesForCorpRefund(YFSEnvironment env, Document inputDoc) {
		
		try{
			loggerForPosInvoice.debug("KohlsCreateInputForPSA.changesForCorpRefund - Start");
		String strDayPhone = "0";
		Element elePayPersonInfoBillTo = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_PERSON_INFO).item(0);
		Element eleInvoiceHeaderExtn = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_EXTN).item(0);
		Element elePaymentMethod = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_PAYMENT_METHOD).item(0);
		if(!YFCCommon.isVoid(elePayPersonInfoBillTo)){
				strDayPhone=elePayPersonInfoBillTo.getAttribute(KohlsPOCConstant.ATTR_DAY_PHONE);
				loggerForPosInvoice.debug("KohlsCreateInputForPSA.addPersonInfoBillTo. DayPhone="+strDayPhone);
			if(!YFCCommon.isVoid(strDayPhone)){
					elePayPersonInfoBillTo.setAttribute(KohlsPOCConstant.ATTR_MOBILE_PHONE, strDayPhone);
			}
		}
		if(!YFCCommon.isVoid(eleInvoiceHeaderExtn)){
			if(!YFCCommon.isVoid(eleInvoiceHeaderExtn.getAttribute(KohlsPOCConstant.ATTR_DRIVERS_LICENSE))){
				elePaymentMethod.setAttribute(KohlsPOCConstant.A_PAYMENT_TYPE, KohlsPOCConstant.ATTR_CORPORATE_REFUND);
			}
		}
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("KohlsCreateInputForPSA.changesForCorpRefund input doc"+XMLUtil.getXMLString(inputDoc));
		}
		loggerForPosInvoice.debug("KohlsCreateInputForPSA.changesForCorpRefund - End");
		}catch(Exception e){
			loggerForPosInvoice.error(e.getMessage());
		}
		
		return inputDoc;
	}

public Document checkAndRemoveCollectionDetails(YFSEnvironment env, Document inputDoc) {
		
		try{
			loggerForPosInvoice.debug("KohlsCreateInputForPSA.checkAndRemoveCollectionDetails - Start");
		Element eleCollectionDetails = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_DETAILS).item(0);
		Element eleInvoiceHeader = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER).item(0);
		Element eleInvChargeTrans = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAILS).item(0);
		Element eleInvOrder = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER).item(0);
		
		String strTotalNo=KohlsPOCConstant.ZERO;
		strTotalNo=eleCollectionDetails.getAttribute("TotalLines");
		
		if(strTotalNo.equalsIgnoreCase(KohlsPOCConstant.ZERO)){
			XMLUtil.removeChild(eleInvoiceHeader, eleCollectionDetails);
		}
		else{
			XMLUtil.removeChild(eleInvOrder, eleInvChargeTrans);
			XMLUtil.createChild(eleInvOrder, "ChargeTransactionDetails");
		}
		
		}catch(Exception e){
			loggerForPosInvoice.error(e.getMessage());
		}
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("KohlsCreateInputForPSA.checkAndRemoveCollectionDetails InputDoc"+XMLUtil.getXMLString(inputDoc));
		}
		loggerForPosInvoice.debug("KohlsCreateInputForPSA.checkAndRemoveCollectionDetails - End");
		return inputDoc;
	}




	public Document calculateTotalOrderLines(Document docFinalXMLtoTibco)
	{
		String strExtnSimplePromoPrice = null;
		Element eleOrderLineExtn = null;
		Element eleOrderLine = null;
		Element eleLinePriceInfo = null;
		String strUnitPrice = null;
		try{
		loggerForPosInvoice.beginTimer("--- calculateTotalOrderLines ---");
			NodeList ndlOrderLine = ((NodeList) XPathUtil
					.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
							KohlsPOCConstant.X_INV_ORDERLINE));
			
			Integer totalNumberCount = ndlOrderLine.getLength();
			
			String totalNumber = totalNumberCount.toString();
			
			Element eleOrderLines =(Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),KohlsPOCConstant.X_INV_ORDERLINES);
			
			eleOrderLines.setAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS,totalNumber);
								
			if(!(YFCCommon.isVoid(ndlOrderLine))){
				for(int i=0;i<totalNumberCount;i++)
				{
					eleOrderLine = (Element) ndlOrderLine.item(i);
					// Code changes for Sale POS and PSA POC defect 3374 -- Begin -- 9/8/16
					
					eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.A_EXTN);
					
					strExtnSimplePromoPrice = eleOrderLineExtn.getAttribute("ExtnSimplePromoPrice");
					
					if(YFCCommon.isStringVoid(strExtnSimplePromoPrice))
						{
						loggerForPosInvoice.debug("Entering code block for Empty ExtnSimplePromoPrice : fetching and Appending");
							eleLinePriceInfo = XMLUtil.getChildElement(eleOrderLine, "LinePriceInfo");
							strUnitPrice = eleLinePriceInfo.getAttribute("UnitPrice");
							eleOrderLineExtn.setAttribute("ExtnSimplePromoPrice",strUnitPrice);
							
						}	
					// Code changes for Sale POS and PSA POC defect 3374 -- End -- 9/8/16
					
					Integer count = i+1;
					String strCurrValue = count.toString();
						eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_LINE_SEQ_NO,strCurrValue);
					if(count%2 == 0)
					{
						eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
					}
					else
					{
						eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.RETURN);
					}
										
			}
				// Fix for Original Terminal ID -- Begin -- 4/8/16

				loggerForPosInvoice
						.debug("Entering code block for Sale Terminal Id fix ");
				//Element eleTransAudit = (Element) XPathUtil
				//		.getNodeList(docFinalXMLtoTibco.getDocumentElement(),
				//				"/InvoiceDetail/InvoiceHeader/TransactionAudits/TransactionAudit")
				//		.item(0);
				
				Element eleTransAudit = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order");
								
				if (!YFCCommon.isVoid(eleTransAudit)) {
								
					//String strTransNumber = eleTransAudit
					//		.getAttribute("TransactionNumber");
							
							String strOrderNumber = eleTransAudit
							 .getAttribute("OrderNo");
							 			
						String strSubstring = "";
						//Changes for CPE-10054 - start
				        if(strOrderNumber.length() == 23) {
				          strSubstring = strOrderNumber.substring(17,19);
				        } else {
				          strSubstring = strOrderNumber.substring(11,13);
				        }
				        //Changes for CPE-10054 - end
							loggerForPosInvoice.debug("Sales Terminal Id is ::"
									+ strSubstring);
							Element eleInvExtn = (Element) XPathUtil.getNode(
									docFinalXMLtoTibco.getDocumentElement(),
									"/InvoiceDetail/InvoiceHeader/Extn");
							eleInvExtn.setAttribute("ExtnTerminalID", strSubstring);
					
							}
				
				// Fix for Original Terminal ID -- End -- 4/8/16
				
				if(!YFCCommon.isStringVoid(strPSASellerOrgCode))
				{
					Element eleOrder = 	(Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order");
					
					eleOrder.setAttribute("SellerOrganizationCode", strPSASellerOrgCode);
				}
					
		
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	loggerForPosInvoice.endTimer("--- calculateTotalOrderLines ---");
		return docFinalXMLtoTibco;
		}


	public Document AppendPromotionAndTaxes (Document docOrigSale , Document docPSA)
	{
		try
		{
			
			
			NodeList ndlSalesPromotion = XPathUtil.getNodeList(docOrigSale, KohlsPOCConstant.X_KOHLS_SALES_PROMOTION);
			
			
			// Updating type code for Sale Promotions
			
			for(int a=0;a<ndlSalesPromotion.getLength();a++)
			{
				Element eleCurrentPromotion = (Element) ndlSalesPromotion.item(a);
				eleCurrentPromotion.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.RETURN);
			}
			
			
			Element elePSAParentPromotion = (Element) XPathUtil.getNode(docPSA, KohlsPOCConstant.X_INV_PROMOTIONS);
			
			NodeList ndlPSAPromotion = XPathUtil.getNodeList(docPSA, KohlsPOCConstant.X_INV_PROMOTION);
			
			// Updating type code for PSA Promotions
			
			for(int b=0;b<ndlPSAPromotion.getLength();b++)
			{
			
			//defect 3403 changes start
			    String getPromotion=null;
				String IsPromotionApplied=null;
			//defect 3403 changes End
				Element eleCurrentPSAPromotion = (Element) ndlPSAPromotion.item(b);
				eleCurrentPSAPromotion.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
				
				//defect 3403 changes start
				//getPromotion.getAttribute("PromotionType");
				//IsPromotionApplied.getAttribute("PromotionApplied");
				getPromotion = (String) eleCurrentPSAPromotion.getAttribute("PromotionType");
				IsPromotionApplied = (String) eleCurrentPSAPromotion.getAttribute("PromotionApplied");
				
				if(getPromotion.equalsIgnoreCase("KOHLS_CASH_EARNED") && IsPromotionApplied.equalsIgnoreCase("N") )
				{
					//XMLUtil.removeChild(elePSAParentPromotion,ndlPSAPromotion);
					XMLUtil.removeChild(elePSAParentPromotion, eleCurrentPSAPromotion);
				}
				//PR-1048 - Start - Commenting
				/*else
				{
				eleCurrentPSAPromotion.setAttribute("PromotionApplied","Y");
				}*/
				//PR-1048 - End
				//defect 3403 changes End
			}
			
			for(int a=0;a<ndlSalesPromotion.getLength();a++)
			{
				XMLUtil.importElement(elePSAParentPromotion,(Element) ndlSalesPromotion.item(a));
			}
			
			
			Element eleOrigSaleOrder = (Element) XPathUtil.getNode(docOrigSale,KohlsPOCConstant.X_KOHLS_SALES_ORDER);
			
			Element eleOrigSaleOrderExtn = XMLUtil.getChildElement(eleOrigSaleOrder,KohlsPOCConstant.A_EXTN);
			
			 String strExtnTaxDetails=	eleOrigSaleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
			 Element eleTaxDetails = null;
			 if(!YFCCommon.isVoid(strExtnTaxDetails))
			 {
				 Document docExtnTaxDetails=XMLUtil.getDocument(strExtnTaxDetails);
				 eleOrigSaleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
				 eleTaxDetails = docExtnTaxDetails.getDocumentElement();
				 XMLUtil.importElement(eleOrigSaleOrder,eleTaxDetails);
			 }
			
			 NodeList ndlTaxDetail = XPathUtil.getNodeList(eleOrigSaleOrder,KohlsPOCConstant.X_KOHLS_SALES_TAX_DETAIL);
			 
			 Element elePSATaxDetailList = (Element) XPathUtil.getNode(docPSA, KohlsPOCConstant.X_INV_TAX_DETAIL_LIST);
			 
			 
			 // Updating Tax Indicator for Sales Tax
			 
			 if(!(YFCCommon.isVoid(ndlTaxDetail)))
					 {
				 		for(int c=0;c<ndlTaxDetail.getLength();c++)
				 		{
				 			Element eleCurrentTax = (Element) ndlTaxDetail.item(c);
				 			String strTaxInd = eleCurrentTax.getAttribute(KohlsPOCConstant.A_TAX_INDICATOR);
				 			strTaxInd = UpdateTaxIndType(strTaxInd);
				 			eleCurrentTax.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, strTaxInd);
				 			eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.RETURN);
				 		}
			
				 		}
			
			 NodeList ndlPSATaxDetail = XPathUtil.getNodeList(docPSA, KohlsPOCConstant.X_INV_TAX_DETAIL);
			 
			 
			 for(int d=0;d<ndlPSATaxDetail.getLength();d++)
			 {
				 Element eleCurrentTax = (Element) ndlPSATaxDetail.item(d);
				 eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
					 }
			 
			 
			 for(int c=0;c<ndlTaxDetail.getLength();c++)
			 {
				 XMLUtil.importElement(elePSATaxDetailList, (Element) ndlTaxDetail.item(c));
			 }
			 	
			 	
			 
		}
		catch(Exception e) {e.printStackTrace();}
		return docPSA;
		
	}
	
	public String UpdateTaxIndType(String strTaxInd)
	{
		if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_1)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_A;}
		else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_2)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_B;}
		else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_3)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_C;}
		else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_4)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_D;}
		else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_5)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_E;}
		else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_6)){strTaxInd = KohlsPOCConstant.ATTR_TAX_F;}
		else	{strTaxInd = KohlsPOCConstant.CONST_HASH;}
		
		return strTaxInd;
	}
	
	public Document ConsolidateTaxAndTotalAmt(Document docOrigSale , Document docPSA)
	{
		
		try {
			
			// Re-calculating Grand Tax Amount
			
			Element eleOrigSaleOvrTotal = (Element) XPathUtil.getNode(docOrigSale,KohlsPOCConstant.X_KOHLS_SALES_OVERALL_TOTALS);
			String strSalesGrandTax = eleOrigSaleOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
			
			Element elePSAOvrTotal = (Element) XPathUtil.getNode(docPSA,KohlsPOCConstant.X_INV_OVERALL_TOTALS);
			
			String strPSAGrandTax = elePSAOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
			
			Float calculatedValue = Float.parseFloat(strPSAGrandTax) - Float.parseFloat(strSalesGrandTax);
			
			//strPSAGrandTax = calculatedValue.toString();
			//rounding the values 06/23/016 - Start 
			strPSAGrandTax = String.format("%.2f", calculatedValue);
            //rounding the values 06/23/016 - End 
			
			elePSAOvrTotal.setAttribute(KohlsPOCConstant.ATTR_GRAND_TAX, strPSAGrandTax);
		
		
			// Re-calculating Total Amount
		
				String strTotalAmount = eleOrigSaleOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);
				
				Element elePSAInvHeader = (Element) XPathUtil.getNode(docPSA,KohlsPOCConstant.XPATH_INVOICE_HEADER);
				
				String strPSATotalAmnt = elePSAInvHeader.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
				
				Float calculatedValueTotalAmnt = Float.parseFloat(strPSATotalAmnt) - Float.parseFloat(strTotalAmount);
				
				//strPSATotalAmnt = calculatedValueTotalAmnt.toString();
				
				//rounding the values 06/23/016 - Start 
			    strPSATotalAmnt = String.format("%.2f", calculatedValueTotalAmnt);
                //rounding the values 06/23/016 - End 
				
				elePSAInvHeader.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, strPSATotalAmnt);
			
		
		} 
		catch (Exception e)
		
		{e.printStackTrace();}
		
		
		return docPSA;
	}

	
	/**
	 * This function iterates over an input document to fetch ChargeTransactionDetails and remove
	 * empty CreditCard Elements
	 *  Author Kohls
	 * @param docInput
	 * @return docInput
	 * @exception Exception
	 * 
	 */
	
	
	public Document getNodeListToRemove(Document docInput)
	{
		try
		{
			loggerForPosInvoice.beginTimer("---Inside getNodeListToRemove ---");
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Input to getNodeListToRemove is ::"+XMLUtil.getXMLString(docInput));
			}
			/***************************/
			//Added for PSA Credit Card -- To be removed soon-- Start
			//docInput = mockCreditDetailsFromSale(docInput);
			//Added for PSA Credit Card -- To be removed soon-- End
			/****************************/
			
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("API output of mockCreditDetailsFromSale is ::"+XMLUtil.getXMLString(docInput) );
				
			// Method Call to remove Empty CreditCardElement
			docInput = removeCreditCardEmptyElement(docInput,KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
			// Method Call to remove Duplicate Payment Elements
			docInput = removeDuplicatePayments(docInput);
	
			// Method Call to remove Empty CreditCardElement
			docInput = removeCreditCardEmptyElement(docInput,KohlsXMLLiterals.E_COLLECITON_DETAIL );
		
		}		
		catch(Exception e){e.printStackTrace();}
		loggerForPosInvoice.endTimer("--- getNodeListToRemove --- end");
		return docInput;
	}
	
	//Added for PSA Credit Card -- To be removed soon-- Start
	public Document mockCreditDetailsFromSale(Document docInput) {
		loggerForPosInvoice.debug("KohlsCreateInputForPSA.mockCreditDetailsFromSale -- Start");
			String strChargeTransKey=null;
			String strCollChargeTransKey=null;
			String strAuthTime = null;
			String strInternalRetCode = null;
			String strTransReqTime = null;
			
			try{	
				NodeList ndlChargeTransDetails = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);
				NodeList ndlCollectionDetails = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_COLLECTION_DETAIL);
				for (int i = 0; i < ndlChargeTransDetails.getLength(); i++) {
					Element eleCurrentElement = (Element) ndlChargeTransDetails.item(i);
					
					if(loggerForPosInvoice.isDebugEnabled())
						loggerForPosInvoice.debug("KohlsCreateInputForPSA.mockCreditDetailsFromSale eleCurrentElement="+XMLUtil.getElementXMLString(eleCurrentElement));
					strChargeTransKey=eleCurrentElement.getAttribute("ChargeTransactionKey");
				Element eleCreditCardParent = (Element) XPathUtil.getNode(eleCurrentElement, "CreditCardTransactions");
				Element eleCreditCard = (Element) XPathUtil.getNode(eleCurrentElement, "CreditCardTransactions/CreditCardTransaction");
					if(!YFCCommon.isVoid(eleCreditCard)){
						if(YFCCommon.isStringVoid(strAuthTime)){
						strAuthTime = eleCreditCard.getAttribute("AuthTime");
						}
						if(YFCCommon.isStringVoid(strTransReqTime)){
						strTransReqTime = eleCreditCard.getAttribute("TranRequestTime");
						}
						if(YFCCommon.isStringVoid(strInternalRetCode)){
						strInternalRetCode = eleCreditCard.getAttribute("InternalReturnCode");
						}
						loggerForPosInvoice.debug("Attribute values are:: AuthTime"+strAuthTime+"TranRequestTime"+strTransReqTime+"InternalReturnCode"+strInternalRetCode);
						
						for (int j = 0; j < ndlCollectionDetails.getLength(); j++) {
							Element eleCurrentCollElement = (Element) ndlCollectionDetails.item(j);
							
							if(loggerForPosInvoice.isDebugEnabled())
								loggerForPosInvoice.debug("KohlsCreateInputForPSA.mockCreditDetailsFromSale eleCurrentCollElement="+XMLUtil.getElementXMLString(eleCurrentCollElement));
							strCollChargeTransKey=eleCurrentCollElement.getAttribute("ChargeTransactionKey");
					loggerForPosInvoice.debug("KohlsCreateInputForPSA.mockCreditDetailsFromSale strChargeTransKey="+strChargeTransKey+" strCollChargeTransKey="+strCollChargeTransKey);
							if(strChargeTransKey.equalsIgnoreCase(strCollChargeTransKey)){
								
								if(loggerForPosInvoice.isDebugEnabled()){
									loggerForPosInvoice.debug("Before appending CreditCardTransactions::"+XMLUtil.getElementXMLString(eleCurrentCollElement));
									loggerForPosInvoice.debug("CreditCard Transactions to be appended::"+XMLUtil.getElementXMLString(eleCreditCardParent));
								}
								Element eleCreditCardClone = (Element) eleCreditCardParent.cloneNode(true);
								
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice.debug("Clone Object is :::"+XMLUtil.getElementXMLString(eleCreditCardClone));
								
								Element eleCreditCardchild = XMLUtil.getChildElement(eleCreditCardClone, "CreditCardTransaction");
								
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice.debug("Child Element of Clone Object is :::"+XMLUtil.getElementXMLString(eleCreditCardchild));
								if(!YFCCommon.isStringVoid(strAuthTime)){
									
									loggerForPosInvoice.debug("Inside not null of AuthTime");
									eleCreditCardchild.setAttribute("AuthTime", strAuthTime);
									eleCreditCardchild.setAttribute("TranRequestTime", strTransReqTime);
									eleCreditCardchild.setAttribute("InternalReturnCode", strInternalRetCode);
									XMLUtil.appendChild(eleCurrentCollElement, eleCreditCardClone);
								}
								
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice.debug("After appending CreditCardTransactions::"+XMLUtil.getElementXMLString(eleCurrentCollElement));
							}
					}	
				}		
				}		
			}catch(Exception e){
			loggerForPosInvoice.error("KohlsCreateInputForPSA.mockCreditDetailsFromSale error"+e);
			}	
			
			if(loggerForPosInvoice.isDebugEnabled()){
				loggerForPosInvoice.debug("KohlsCreateInputForPSA.mockCreditDetailsFromSale docInput="+XMLUtil.getXMLString(docInput));
				loggerForPosInvoice.debug("KohlsCreateInputForPSA.mockCreditDetailsFromSale -- End");
			}
			return docInput;
		}
	
	//Added for PSA Credit Card -- To be removed soon-- End

	public Document removeCreditCardEmptyElement(Document docInput , String str)
	{
		String strAuthTime =  null; 
		String strTranRequestTime = null;
		NodeList ndlistInput = null;
		//PR-992 - Start
		String strAuthAmount = null;
		//PR-992 - End
		try
		{
			if (str.equalsIgnoreCase(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS)){
				ndlistInput = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);
				loggerForPosInvoice.debug("Fetching nodelist of ChargeTransactionDetail");
				}
			else {
				ndlistInput = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_COLLECTION_DETAIL);
				loggerForPosInvoice.debug("Fetching nodelist of CollectionDetails");
			}
			
			
			loggerForPosInvoice.beginTimer("removeCreditCardEmptyElement");
			// Iterate over NodeList of ChargeTransactionDetails
		for(int i=0;i<ndlistInput.getLength();i++)
			{
					//Fetch Current ChargeTransactionDetail element
				Element eleCurrentElement = (Element) ndlistInput.item(i);
			
			Element eleCreditCardParent = (Element) XPathUtil.getNode(eleCurrentElement, KohlsPOCConstant.X_CREDIT_CARD_TRANS);
			
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("Current ChargeTransactionElement is::"+XMLUtil.getElementXMLString(eleCurrentElement));
			
			
				if (!YFCCommon.isVoid(eleCreditCardParent)) {
					
					if(loggerForPosInvoice.isDebugEnabled())
						loggerForPosInvoice.debug("Current CreditCard Transactions element is::"+XMLUtil.getElementXMLString(eleCreditCardParent));
					int countChild = eleCreditCardParent.getElementsByTagName("CreditCardTransaction").getLength();
					loggerForPosInvoice.debug("CreditCardTransaction nodelist count is :::"+countChild);
					
					if (countChild == 0) {
						loggerForPosInvoice.debug("No CreditCardTransaction element exists. Removing CreditCardTransactions");
						XMLUtil.removeChild(eleCurrentElement,
								eleCreditCardParent);
					} else {
						// [START] Defect: 4176 -- Commented the old and added new line
						//Element eleCreditCard = (Element) XPathUtil.getNode(eleCurrentElement, KohlsPOCConstant.X_CREDIT_CARD_TRAN);
						Element eleCreditCard = (Element) eleCurrentElement.getElementsByTagName("CreditCardTransaction").item(0);
						// [END] Defect: 4176
						strAuthTime = eleCreditCard.getAttribute("AuthTime");
						strTranRequestTime = eleCreditCard
								.getAttribute("TranRequestTime");
						loggerForPosInvoice.debug("AuthTime is "+strAuthTime);
						loggerForPosInvoice.debug("TranRequestTime is "+strTranRequestTime);
						//PR-992 - Start - Checking if there is any negative authorization amount and removing the same.
						strAuthAmount = XMLUtil.getAttribute(eleCreditCard, "AuthAmount");
						if (YFCCommon.isStringVoid(strAuthTime)
								|| YFCCommon.isStringVoid(strTranRequestTime) || 
								(!YFCCommon.isVoid(strAuthAmount) && strAuthAmount.contains(KohlsPOCConstant.MINUS))) {
						//PR-992 - End
							XMLUtil.removeChild(eleCurrentElement,
									eleCreditCardParent);
				}
			
			}
		
		}
			}
	}
		catch(Exception e){e.printStackTrace();}
		
		loggerForPosInvoice.endTimer("removeCreditCardEmptyElement");
		return docInput;
	}
	
	
	public Document removeDuplicatePayments(Document docInput)
	{
		String strPaymentKey = null;
		try
		{
			loggerForPosInvoice.beginTimer("removeDuplicatePayments");
			NodeList ndlChargeTransDetails = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);
			
			//Iterate over ChargeTransactionDetails NodeList
			for(int i=0;i<ndlChargeTransDetails.getLength();i++)
			{
				// Fetch Current ChargeTransactionDetail Element
				Element eleCurrent = (Element) ndlChargeTransDetails.item(i);
				
				if(loggerForPosInvoice.isDebugEnabled())
					loggerForPosInvoice.debug("Current ChargeTransactionElement ::"+XMLUtil.getElementXMLString(eleCurrent));
				Element elePaymentMethod = XMLUtil.getChildElement(eleCurrent, KohlsPOCConstant.E_PAYMENT_METHOD);
				if(!(YFCCommon.isVoid(elePaymentMethod)))
						{
							strPaymentKey = elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
							loggerForPosInvoice.debug("Payment Key is"+strPaymentKey);
						}
				if(!YFCCommon.isVoid(strPaymentKey))		
				{		
					for(int j=i+1;j<ndlChargeTransDetails.getLength();j++)
						{
							Element eleNextChargeTrans =  (Element) ndlChargeTransDetails.item(j);
							
							if(loggerForPosInvoice.isDebugEnabled())
								loggerForPosInvoice.debug("Comparing with the following chargeTransactionElement"+XMLUtil.getElementXMLString(eleNextChargeTrans));
							Element eleNextPaymentMethod = XMLUtil.getChildElement(eleNextChargeTrans, KohlsPOCConstant.E_PAYMENT_METHOD);
							if(!(YFCCommon.isVoid(eleNextPaymentMethod)))
							{		
								String strNextPaymentKey = eleNextPaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
									
									
									if(!(YFCCommon.isVoid(strNextPaymentKey)) && strPaymentKey.equals(strNextPaymentKey))
									{
										loggerForPosInvoice.debug("Removing duplicate child");
										XMLUtil.removeChild(eleNextChargeTrans, eleNextPaymentMethod);
									}
							}	
						}
				}	
			}
		}
		catch(Exception e){e.printStackTrace();}
		loggerForPosInvoice.endTimer("removeDuplicatePayments");
		return docInput;
		
	}
		
	
	public Document UpdatePSADataForKohlsSalesForPSA(YFSEnvironment env, Document PSADataDoc) {

		try {

			Element elePSAOrder = (Element) XPathUtil.getNode(PSADataDoc,"/Order");

			String strOHkey = elePSAOrder
					.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

			String PSADataXML = XMLUtil.getXMLString(PSADataDoc);

			Document docInputForPSAData = YFCDocument.createDocument(
					"KOHLSSalesForPsa").getDocument();

			Element eleInputForPSAData = docInputForPSAData
					.getDocumentElement();

			eleInputForPSAData.setAttribute("OrderHeaderKey", strOHkey);

			eleInputForPSAData.setAttribute("PSAData", PSADataXML);

			return docInputForPSAData;

		} catch (Exception e) {

			e.printStackTrace();

		}

		return PSADataDoc;

	}
		


	public Document setExternalPayment(Document inputDoc)
	 {
			String strCheck = null;
			String strCollectionDate = null;
			try {
				loggerForPosInvoice.beginTimer("setExternalPayment");
				NodeList ndlCollectionDetail = XPathUtil.getNodeList(inputDoc,
						KohlsPOCConstant.X_INV_COLLECTION_DETAIL);

				Element eleCollectionDetails = (Element) XPathUtil.getNode(inputDoc,
						KohlsPOCConstant.X_INV_COLLECTION_DETAILS);
				
				for (int i = 0; i < ndlCollectionDetail.getLength(); i++) {
					Element eleCurrentElement = (Element) ndlCollectionDetail
							.item(i);
					if (!YFCCommon.isVoid(eleCurrentElement)) {
						
						if(loggerForPosInvoice.isDebugEnabled())
							loggerForPosInvoice.debug("Current CollectionDetail Element ::"
									+ XMLUtil.getElementXMLString(eleCurrentElement));
						
						// New fix for CreditCardTransaction after Tendering Changes -- Begin -- 8/8/16
						
						 strCollectionDate = eleCurrentElement.getAttribute("CollectionDate");
						
						 loggerForPosInvoice.debug("Fetching ExecutionDate to be set ::"+strCollectionDate);
						 
						 
					if (!YFCCommon.isStringVoid(strCollectionDate)) {

						loggerForPosInvoice
								.debug("ExecutionDate exists , Explicitly setting it into CollectionDetails"
										+ strCollectionDate);
						eleCurrentElement.setAttribute("ExecutionDate",
								strCollectionDate);
					}
						
						// New fix for CreditCardTransaction after Tendering Changes -- End -- 8/8/16
						
						Element elePaymentMethod = (Element) XPathUtil.getNode(
								eleCurrentElement, "PaymentMethod");
						if (!YFCCommon.isVoid(elePaymentMethod)) {
							
							if(loggerForPosInvoice.isDebugEnabled())
								loggerForPosInvoice.debug("Current Payment Method Element ::"
										+ XMLUtil
										.getElementXMLString(elePaymentMethod));
							strCheck = elePaymentMethod.getAttribute("PaymentType");
							loggerForPosInvoice.debug("Payment Type is ::" + strCheck);
							if (strCheck.equalsIgnoreCase("CREDIT_CARD")
									|| strCheck.equalsIgnoreCase("DEBIT_CARD")
									|| strCheck.equalsIgnoreCase("KOHLS_CHARGE_CARD")) {
								loggerForPosInvoice.debug("Inside External Payment block");
								elePaymentMethod.setAttribute("IsExternalPayment","P");

							}
							if("KOHLS_CASH".equalsIgnoreCase(strCheck))
							{
								XMLUtil.removeChild(eleCollectionDetails, eleCurrentElement);
								String CollDetsize = eleCollectionDetails.getAttribute("TotalLines");
								Integer int1 = Integer.valueOf(CollDetsize);
								int1-- ;
								eleCollectionDetails.setAttribute("TotalLines", int1.toString());
							}

						}
					}
				}
			}
			catch(Exception e){loggerForPosInvoice.error(e);}
		loggerForPosInvoice.endTimer("setExternalPayment");
			return inputDoc;
		}
	
	//Fix for PR-149 - Start
	/**
	 * @param env
	 * @param docFinal 
	 * @param strOrderHeaderKey
	 * @return
	 * @throws Exception
	 * ComplexQuery Input for calling getOrderInvoiceList
	 * <OrderInvoice OrderHeaderKey="1116112403585922866901" >
		<ComplexQuery Operator="AND"> 
		       <And> 
		          <Or> 
		            <Exp Name="InvoiceType" Value="CREDIT_MEMO" InvoiceTypeQryType="EQ"/> 
		            <Exp Name="InvoiceType" Value="DEBIT_MEMO" InvoiceTypeQryType="EQ"/>     
		          </Or> 
		        </And> 
		</ComplexQuery>
		</OrderInvoice>
	 */
	public void consolidateInvoiceCollectionWithHeaderDetails(YFSEnvironment env, Document docFinal, String strOrderHeaderKey)
			throws Exception {

		loggerForPosInvoice.beginTimer("********------consolidatePaymentChargeDetails------********");

		try{
			loggerForPosInvoice.debug("OrderHeaderKey in consolidateCollectionDetails method input is : " +strOrderHeaderKey);
			if(!YFCCommon.isVoid(strOrderHeaderKey) && !YFCCommon.isVoid(docFinal)){

				Element eleFinal = docFinal.getDocumentElement();
				Element eleInvoiceHeaderOrg = XMLUtil.getChildElement(eleFinal, "InvoiceHeader");
				Element eleCollectionDetailsOrg = (Element) XMLUtil.getElementsByTagName(eleFinal, "CollectionDetails").get(0);
				
				if(loggerForPosInvoice.isDebugEnabled())
					loggerForPosInvoice.debug("The eleCollectionDetailsOrg Output : " +XMLUtil.getElementXMLString(eleCollectionDetailsOrg));
				//Create input for getOrderInvoiceList
				Document inGetOrderInvoiceList = XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_INP_CQ);
				inGetOrderInvoiceList.getDocumentElement().setAttribute("OrderHeaderKey", strOrderHeaderKey);

				//Calling getOrderInvoiceList API to get all the Invoices associated to the current PSA Order
				Document getOrderInvoiceListTemplate = XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_OUT_TEMP);
				Document outGetOrderInvoiceList = KOHLSBaseApi.invokeAPI(env,getOrderInvoiceListTemplate,"getOrderInvoiceList",inGetOrderInvoiceList);
				
				if(loggerForPosInvoice.isDebugEnabled())
					loggerForPosInvoice.debug("The outGetOrderInvoiceList Output : " +XMLUtil.getXMLString(outGetOrderInvoiceList));

				Double conAmountCollected = KohlsPOCConstant.ZERO_DBL;
				Double conLineSubTotal = KohlsPOCConstant.ZERO_DBL;
				Double conTotalAmount = KohlsPOCConstant.ZERO_DBL;
				Double conTotalTax = KohlsPOCConstant.ZERO_DBL;
				Double conTotalDiscount = KohlsPOCConstant.ZERO_DBL;
				DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
				//Calling getOrderInvoiceDetails for each Invoice and getting the associated, Payment Collection details and Invoice header details.
				NodeList nlOrderInvoiceList = outGetOrderInvoiceList.getElementsByTagName("OrderInvoice");
				Document docCollectionDetails = XMLUtil.createDocument("CollectionDetails");
				if(nlOrderInvoiceList.getLength()>0){
					for(int i=0; i<nlOrderInvoiceList.getLength(); i++){
						Element eleOrderInvoice = (Element) nlOrderInvoiceList.item(i);
						conAmountCollected = conAmountCollected + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "AmountCollected"));
						conLineSubTotal = conLineSubTotal + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "LineSubTotal"));
						conTotalAmount = conTotalAmount + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalAmount"));
						conTotalTax = conTotalTax + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalTax"));

						String srtOrderInvoiceKey = XMLUtil.getAttribute(eleOrderInvoice, "OrderInvoiceKey");
						Document getOrderInvoiceDetailsInp = XMLUtil.createDocument("GetOrderInvoiceDetails");
						getOrderInvoiceDetailsInp.getDocumentElement().setAttribute("InvoiceKey", srtOrderInvoiceKey);

						//Document docGetOrderInvoiceDetailsOutTemplate = XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT_TEMP);
						Document docGetOrderInvDetailsOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT,
								KohlsPOCConstant.GET_INVOICE_ORDER_DET, getOrderInvoiceDetailsInp);
						/*KohlsCommonUtil.invokeAPI(env,docGetOrderInvoiceDetailsOutTemplate, 
								KohlsPOCConstant.GET_INVOICE_ORDER_DET,getOrderInvoiceDetailsInp);*/
						
						if(loggerForPosInvoice.isDebugEnabled())
							loggerForPosInvoice.debug("docGetOrderInvDetailsOutput output value is : " +XMLUtil.getXMLString(docGetOrderInvDetailsOutput));
						Element eleInvoiceHeader = XMLUtil.getChildElement(docGetOrderInvDetailsOutput.getDocumentElement(), "InvoiceHeader");
						conTotalDiscount = conTotalDiscount + Double.parseDouble(XMLUtil.getAttribute(eleInvoiceHeader, "TotalDiscount"));
						NodeList nlCollectionDetailsList = docGetOrderInvDetailsOutput.getElementsByTagName("CollectionDetail");
						if(nlCollectionDetailsList.getLength()>0){
							for(int j=0; j<nlCollectionDetailsList.getLength(); j++){
								Element eleCollectionDetail = (Element) nlCollectionDetailsList.item(j);
								Element elePaymentMethod = XMLUtil.getChildElement(eleCollectionDetail, "PaymentMethod");
								if(!YFCCommon.isVoid(elePaymentMethod)){
									//Element elePaymentMethod = (Element) eleCollectionDetail.getElementsByTagName("PaymentMethod" ).item( 0 );
									//elePaymentMethod.setAttribute("TotalCharged", eleCollectionDetail.getAttribute("AmountCollected"));
									XMLUtil.setAttribute(elePaymentMethod, "TotalCharged", XMLUtil.getAttribute(eleCollectionDetail, "AmountCollected"));
									//Fix for PR-528, PR-558 - Start
									XMLUtil.importElement(docCollectionDetails.getDocumentElement(), eleCollectionDetail);
									//Fix for PR-528, PR-558 - End
								}
							}
						}
					}
				}
				//Fix for PR-439 - Start
				int iTotalLines = XMLUtil.getElementsCountByTagName(docCollectionDetails.getDocumentElement(), "CollectionDetail");
				XMLUtil.setAttribute(docCollectionDetails.getDocumentElement(), "TotalLines", String.valueOf(iTotalLines)); 
				//Fix for PR-439 - End
				eleInvoiceHeaderOrg.setAttribute("AmountCollected", twoDForm.format(conAmountCollected));
				eleInvoiceHeaderOrg.setAttribute("LineSubTotal", twoDForm.format(conLineSubTotal));
				eleInvoiceHeaderOrg.setAttribute("TotalAmount", twoDForm.format(conTotalAmount));
				eleInvoiceHeaderOrg.setAttribute("TotalTax", twoDForm.format(conTotalTax));
				eleInvoiceHeaderOrg.setAttribute("TotalDiscount", twoDForm.format(conTotalDiscount));
				if(loggerForPosInvoice.isDebugEnabled()){
				loggerForPosInvoice.debug("Consolidated CollectionDetails element : " +XMLUtil.getXMLString(docCollectionDetails));
				}
				if(!YFCCommon.isVoid(docCollectionDetails)){
					if(loggerForPosInvoice.isDebugEnabled()){
					loggerForPosInvoice.debug("The inDoc inside removing loop is : " + XMLUtil.getElementXMLString(eleFinal));
					}
					consolidateCollectionDetails(docCollectionDetails);
					XMLUtil.removeChild(eleInvoiceHeaderOrg, eleCollectionDetailsOrg);
					XMLUtil.importElement(eleInvoiceHeaderOrg, docCollectionDetails.getDocumentElement());
					if(loggerForPosInvoice.isDebugEnabled()){
					loggerForPosInvoice.debug("The inDoc inside after removing and attaching loop is : " + XMLUtil.getElementXMLString(eleFinal));
					}
					loggerForPosInvoice.debug("Successfully consolidated Payment Collection details");
				}

			}else{
				YFSException eYFS = new YFSException("OrderHeaderKey is Null", "OrderHeaderKey is Null", "OrderHeaderKey is Null");
				throw eYFS;
			}
		}
		catch(Exception e){
			loggerForPosInvoice.verbose(e);
			throw e;
		}
		loggerForPosInvoice.endTimer("********------consolidatePaymentChargeDetails------********");

	}
	/**
	 * CPE-2938 
	 * consolidate the Collections details by paymentMethod/PaymentType & CreditCardNo
	 * @param docInvoiceOut
	 */
	private void consolidateCollectionDetails(Document docInvoiceOut) {
		loggerForPosInvoice.beginTimer("KohlsCreateInputForPSA.consolidateCollectionDetails");
		if (loggerForPosInvoice.isDebugEnabled()) {
			loggerForPosInvoice.debug("Input xml to KohlsCreateInputForPSA.consolidateCollectionDetails is: "
					+ XMLUtil.getXMLString(docInvoiceOut));
		}
		HashMap<String, Element> mapPaymentMethodMap = new HashMap<String, Element>();
		Element eleCollectionDetails = (Element) docInvoiceOut
				.getElementsByTagName("CollectionDetails").item(0);
		NodeList nlCollectionDetail =
				docInvoiceOut.getElementsByTagName("CollectionDetail");
		for (int i = 0; i < nlCollectionDetail.getLength(); i++) {
			Element eleCollectionDetail = (Element) nlCollectionDetail.item(i);
			String sAmountCollected =
					eleCollectionDetail.getAttribute("AmountCollected");
			Element elePaymentMethod =
					XMLUtil.getChildElement(eleCollectionDetail, KohlsPOCConstant.E_PAYMENT_METHOD);
			String sTotalRefundedAmount =
					elePaymentMethod.getAttribute(KohlsPOCConstant.A_TOTAL_REFUNDED_AMOUNT);
			String sTotalRequestedAmount =
					eleCollectionDetail.getAttribute("RequestAmount");
			String sPaymentType = elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
			String sPaymentReference7 = elePaymentMethod.getAttribute("PaymentReference7");
			if(YFCCommon.isVoid(sPaymentReference7)){
			  eleCollectionDetails.removeChild(eleCollectionDetail);
			  i --;
			  continue;
			}
			String sTranNoForPayment = sPaymentReference7.substring(sPaymentReference7.length() - 4, sPaymentReference7.length());
			if(!sTranNoForPayment.equalsIgnoreCase(strCurrentPOSSeqNo)){
			  eleCollectionDetails.removeChild(eleCollectionDetail);
              i --;
			  continue;
			}
			if (!YFCCommon.isVoid(sAmountCollected) && !YFCCommon.isVoid(sTotalRefundedAmount)) {
				if (Double.compare(Double.parseDouble(sAmountCollected),
						Double.parseDouble(sTotalRefundedAmount)) == 0) {
					//If it is postvoided then remove the earlier collection details.
					if(mapPaymentMethodMap.containsKey(sPaymentType)){
						Element eleCollection = mapPaymentMethodMap.get(sPaymentType);
						Element elePayment =
								XMLUtil.getChildElement(eleCollection, KohlsPOCConstant.E_PAYMENT_METHOD);
						String sTotalVoidedRefundedAmount =
								elePayment.getAttribute(KohlsPOCConstant.A_TOTAL_REFUNDED_AMOUNT);
						
						if(Double.parseDouble(sTotalRefundedAmount) == Double.parseDouble(sTotalVoidedRefundedAmount)){
							mapPaymentMethodMap.remove(sPaymentType);
						}
					}
					continue;
				} else {
					eleCollectionDetails.removeChild(eleCollectionDetail);
					i--;
				}
			}
			if ("CREDIT_CARD".equals(sPaymentType)
					|| KohlsPOCConstant.KOHL_CHARGE_CARD.equals(sPaymentType)) {
				String sCreditCardNo = elePaymentMethod.getAttribute("CreditCardNo");
				sPaymentType = sPaymentType + "_" + sCreditCardNo;
			} else if ("DEBIT_CARD".equals(sPaymentType)) {
				String sDebitCardNo = elePaymentMethod.getAttribute("DebitCardNo");
				sPaymentType = sPaymentType + "_" + sDebitCardNo;
			}
			if (!mapPaymentMethodMap.containsKey(sPaymentType)) {
				eleCollectionDetail.setAttribute("AmountCollected",
						sTotalRefundedAmount);
				elePaymentMethod.setAttribute(KohlsPOCConstant.ATTR_TOTAL_CHARGED, KohlsPOCConstant.ZERO);
				eleCollectionDetail.appendChild(elePaymentMethod);
				mapPaymentMethodMap.put(sPaymentType, eleCollectionDetail);
			}
		}
		if (mapPaymentMethodMap.size() > 0) {
			for (String key : mapPaymentMethodMap.keySet()) {
				eleCollectionDetails.appendChild(mapPaymentMethodMap.get(key));
			}
		}
		if (loggerForPosInvoice.isDebugEnabled()) {
			loggerForPosInvoice.debug("Outout of KohlsCreateInputForPSA.consolidateCollectionDetails is: "
					+ XMLUtil.getXMLString(docInvoiceOut));
		}
		loggerForPosInvoice.endTimer("KohlsCreateInputForPSA.consolidateCollectionDetails");
	}
	  
	public Document consolidateInvoiceMessage(YFSEnvironment env, Document docFinal)
			throws Exception {

		loggerForPosInvoice.beginTimer("********------consolidateInvoiceMessage------********");
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("docFinal Input value is : " +XMLUtil.getXMLString(docFinal));
		}
		try {

			Document docGetOrderDetailsOutTemplate = XMLUtil.getDocument(KohlsPOCConstant.TEMP_GET_ORDER_DETAILS_OUT_PSA);
			Element eleOverallTotals = (Element) ((NodeList) XPathUtil.getNodeList(docFinal.getDocumentElement(),KohlsPOCConstant.X_INV_OVERALL_TOTALS)).item(0);
			Element eleInvoiceHeader = (Element) ((NodeList) XPathUtil.getNodeList(docFinal.getDocumentElement(),KohlsPOCConstant.XPATH_INVOICE_HEADER)).item(0);
			Element eleOrder = (Element) ((NodeList) XPathUtil.getNodeList(docFinal.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER)).item(0);
			Element eleOrderExtn = (Element) ((NodeList) XPathUtil.getNodeList(docFinal.getDocumentElement(),KohlsPOCConstant.X_INV_ORDER_EXTN)).item(0);

			// Begin Changes for Newly added Extn attributes at Order Level
			String strOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			loggerForPosInvoice.debug("OrderHeaderKey is::" + strOrderHeaderKey);
			
			strCurrentPOSSeqNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
			loggerForPosInvoice.debug("PosSequenceNo is::" + strCurrentPOSSeqNo);
			
			//Consolidating the Invoice Collection and updating InvooiceHeader details
			consolidateInvoiceCollectionWithHeaderDetails(env, docFinal, strOrderHeaderKey);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Output of consolidateInvoiceCollectionWithHeaderDetails is::" + XMLUtil.getXMLString(docFinal));
			}
			// Preparing document for Input
			Document docGetOrderDetailsInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderInput = docGetOrderDetailsInput.getDocumentElement();
			eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);

			// getOrderDetails API Call
			Document docGetOrderDetails = KohlsCommonUtil.invokeAPI(env,
					docGetOrderDetailsOutTemplate, KohlsPOCConstant.API_GET_ORDER_DETAILS,
					docGetOrderDetailsInput);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("docGetOrderDetails output  :::" + XMLUtil.getXMLString(docGetOrderDetails));
			}
			strPSASellerOrgCode = docGetOrderDetails.getDocumentElement().getAttribute("TransactionNo");
			if(!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
				// Extracting Seller Organization code from the Updated Transaction Number
				strPSASellerOrgCode = strPSASellerOrgCode.substring(12, 16);
				loggerForPosInvoice.debug("PSA seller Organization code is:::"+strPSASellerOrgCode);
			}

			Element eleOrderUpdatedExtn = (Element) ((NodeList) XPathUtil.getNodeList(docGetOrderDetails.getDocumentElement(),
					KohlsPOCConstant.XPATH_ORDER_EXTN)).item(0);
			Element elePersonInfoBillToExtn = (Element) ((NodeList) XPathUtil.getNodeList(docGetOrderDetails.getDocumentElement(),
					KohlsPOCConstant.X_ORD_PERSON_INFO_EXTN)).item(0);
			
			if(loggerForPosInvoice.isDebugEnabled())
				loggerForPosInvoice.debug("eleOrderUpdatedExtn :::" + XMLUtil.getElementXMLString(eleOrderUpdatedExtn));
			
			// Fetching attributes for Kohls Cash Deactivation

			String strKohlsCashDeactivated = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD);
			String strCustLoyalCard = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_CUST_LOYAL_CARD);
			String strEmailAddress = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_EMAIL_ADDRESS);
			String strReasonCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE);
			String strCpnDeactivationCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_CODE);
			String strCpnEventCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_EVENT_CODE);
			String strCpnNumber = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_NUMBER);
			String strCpnPurchaseReturnAmount = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_RETURN_AMT);
			String strPsaResultCode = eleOrderUpdatedExtn
					.getAttribute(KohlsPOCConstant.ATTR_EXTN_PSA_RESULT_CODE);
			String strReturnTenderAmount =
					eleOrderUpdatedExtn.getAttribute(KohlsXMLLiterals.A_EXTN_KCD_RETURN_TENDER_AMOUNT);
			
			
			if(loggerForPosInvoice.isDebugEnabled()){
				loggerForPosInvoice.debug("----Values for Kohls cash are ------");
				loggerForPosInvoice.debug("ExtnKohlsCashDeactivated"+strKohlsCashDeactivated);
				loggerForPosInvoice.debug("ExtnCustomerLoyalCard"+strCustLoyalCard);
				loggerForPosInvoice.debug("ExtnEmailAddress"+strEmailAddress);
				loggerForPosInvoice.debug("ExtnReasonCode"+strReasonCode);
				loggerForPosInvoice.debug("ExtnKCDCouponCode" + strCpnDeactivationCode);
				loggerForPosInvoice.debug("ExtnKCDCouponEventCode" + strCpnEventCode);
				loggerForPosInvoice.debug("ExtnKCDCouponNumber" + strCpnNumber);
				loggerForPosInvoice.debug("ExtnKCDCouponReturnAmount"+ strCpnPurchaseReturnAmount);
				loggerForPosInvoice.debug("ExtnKCDReturnTenderAmt"+strReturnTenderAmount);
			}

			// Fetching Attributes for Corporate Refund
			String strDriversLicense = elePersonInfoBillToExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_DRIVERS_LICENSE);
			Element eleInvoiceHeaderExtn = XMLUtil.createChild(eleInvoiceHeader, KohlsPOCConstant.A_EXTN);

			if ((YFCCommon.isVoid(eleOverallTotals))
					|| (YFCCommon.isVoid(eleInvoiceHeader))
					|| (YFCCommon.isVoid(eleOrder))
					|| (YFCCommon.isVoid(eleInvoiceHeaderExtn))) {

				YFSException yfsException = new YFSException();
				yfsException.setErrorDescription("Value of Overall totals or InvoiceHeader or Order is null");
				throw yfsException;
			}

			String strSellerOrganizationCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
			// Fix for 3558  -- Begin -- 8/26/16 
			String strLineSubTotal = eleOverallTotals.getAttribute("LineSubTotal");

			if(!YFCCommon.isStringVoid(strLineSubTotal))
			{
				eleInvoiceHeader.setAttribute("LineSubTotal", strLineSubTotal);
			}
			// Fix for 3558 -- End -- 8/26/16

			eleInvoiceHeaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SHIP_NODE, strSellerOrganizationCode);

			// Setting Kohls Cash Related Attributes
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_CUST_LOYAL_CARD, strCustLoyalCard);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD,strKohlsCashDeactivated);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_EMAIL_ADDRESS, strEmailAddress);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE, strReasonCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_CODE,strCpnDeactivationCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_EVENT_CODE, strCpnEventCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_NUMBER, strCpnNumber);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_RETURN_AMT,strCpnPurchaseReturnAmount);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_PSA_RESULT_CODE, strPsaResultCode);
			eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_RETURN_TENDER_AMT,strReturnTenderAmount);

			// Setting Corporate Refund Attributes
			eleInvoiceHeaderExtn.setAttribute(KohlsPOCConstant.ATTR_DRIVERS_LICENSE, strDriversLicense);


			// Method call to Append Sales orderline to Existing PSA order 
			docFinal = updateSales(env, docFinal);

			// Appending Tiered Promotions at the Order Level for #3135 -- Begin -- 27/7/16 --
			if(mTieredDiscount.size()>0){
				loggerForPosInvoice.debug("Appending Tiered Promotions at the order Level");
				//PR-961 - Start
				Element eleTLDList = null;
				if (loggerForPosInvoice.isDebugEnabled()) {
					loggerForPosInvoice.debug("eleOrder input Element value is : "+ XMLUtil.getElementXMLString(eleOrder));
				}
				eleTLDList = XMLUtil.getChildElement(eleOrder, "TransactionLevelDiscountList");

				if(YFCCommon.isVoid(eleTLDList) && !eleTLDList.hasAttributes()){
					//PR-961 - End
					eleTLDList = docFinal.createElement("TransactionLevelDiscountList");
					eleOrder.appendChild(eleTLDList);
					for(String key : mTieredDiscount.keySet()){
						if(loggerForPosInvoice.isDebugEnabled()){
							loggerForPosInvoice.debug("Importing key element"+XMLUtil.getElementXMLString(mTieredDiscount.get(key)));
						}
						XMLUtil.importElement(eleTLDList, mTieredDiscount.get(key));				
					}
					mTieredDiscount.clear();
				}
				if (loggerForPosInvoice.isDebugEnabled()) {
					loggerForPosInvoice.debug("eleOrder output Element value is : "+ XMLUtil.getElementXMLString(eleOrder));
				}
			}
			// Appending Tiered Promotions at the Order Level for #3135 -- End -- 27/7/16 --
			// PR-515 - Begin - Get TransactionTimeStamp for current PSA transaction
			
			String strOrderNo = eleOrder
					.getAttribute("OrderNo");
			String strPSATranNo = eleOrder
					.getAttribute("PosSequenceNo");
			
			Document inDoc = YFCDocument.createDocument("TransactionAudit")
								.getDocument();
			Element eleDoc = inDoc.getDocumentElement();
			eleDoc.setAttribute("OrderNumber", strOrderNo);
			eleDoc.setAttribute("OrganizationCode", strSellerOrganizationCode);
			eleDoc.setAttribute("ProcedureID", "213");
			eleDoc.setAttribute("POSSequenceNumber", strPSATranNo);

			if (loggerForPosInvoice.isDebugEnabled()) {
							loggerForPosInvoice
									.debug("Calling getTransactionAuditListForPOS API with input doc : "
											+ XMLUtil.getXMLString(inDoc));
						}
						Document psaTranDateDocOutput = KOHLSBaseApi
								.invokeAPI(
										env,
										XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
										"getTransactionAuditListForPOS", inDoc);
						NodeList nPSATranEleList = psaTranDateDocOutput
								.getElementsByTagName("TransactionAudit");

						String strPSADateTime = null;
						if (nPSATranEleList != null && nPSATranEleList.getLength() > 0) {
							Element elePSATranAudit = (Element) nPSATranEleList.item(0);
							strPSADateTime = elePSATranAudit.getAttribute("DateTime");
						}
						
			// Populating PSA DateTime at InvoiceHeader/Order Level
			        if(!YFCCommon.isStringVoid(strPSADateTime))
				{
				eleOrder.setAttribute("Modifyts", strPSADateTime);
				}
				else 
				{
					//PST-4874 changes
					loggerForPosInvoice.debug("Before DateTime Setting ::"+ServerTypeHelper.amIOnEdgeServer());
						
						Element CustomAttributeEle= (Element) eleOrder.getElementsByTagName(KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES).item(0);
						if(!YFCCommon.isVoid(CustomAttributeEle))
						 {
							strPSADateTime = CustomAttributeEle.getAttribute("Date5");
							  if(!YFCCommon.isStringVoid(strPSADateTime))
								{
								  eleOrder.setAttribute("Modifyts", strPSADateTime);
								}
						 }
						
					//End PST-4874 changes
					 loggerForPosInvoice.debug("Value of Transaction Time for PSA transaction is null");
				}
			// PR-515 - End
		}

		catch (YFSException exception) {
			loggerForPosInvoice.error(exception);
			throw exception;
		}
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("The Final document sent Tibco Queue : " +XMLUtil.getXMLString(docFinal));
		}
		loggerForPosInvoice.endTimer("********------consolidateInvoiceMessage------********");
		return docFinal;
	}

	public Document updateSales(YFSEnvironment env,Document inputDoc)
	{
		String strnegative="-";

		try
		{
			loggerForPosInvoice.debug("Inside updateSales Method");
			elePSAOrder = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_ORDER);
			strOHkey = elePSAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			Element elePSAInvHeader = (Element) XPathUtil.getNode(inputDoc,KohlsPOCConstant.XPATH_INVOICE_HEADER);
			String strOIKey = elePSAInvHeader.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Appended Invoice Header Element is ::"+XMLUtil.getElementXMLString(elePSAInvHeader));
			}
			// Fetching CollectionDetails from API Output and Appending -- End -- 6/17/16

			// Prepare Input document for API call to fetch original Sales Data
			docInputForOrigSale =  YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			eleInputForOrigSale  = docInputForOrigSale.getDocumentElement();
			eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,strOHkey);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Document input to API call is::"+XMLUtil.getXMLString(docInputForOrigSale));
			}
			// API call to fetch sales Data
			docOriginalSale = invokeService(env,KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS,docInputForOrigSale);

			//Preparing input document for API call to fetch getOrderDetails

			docInputForgetOrderDetail =  YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
			eleInputForOrigSale  = docInputForgetOrderDetail.getDocumentElement();
			eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,strOHkey);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Document output of the API call is::"+XMLUtil.getXMLString(docOriginalSale));
			}
			// Fetching ChargeTransactionDetails from API Output and Appending -- Begin -- 6/17/16

			Document docGetOrderDetailsOutput = KOHLSBaseApi.invokeAPI(env,KohlsPOCConstant.API_GET_ORDER_DETAILS, docInputForgetOrderDetail);

			// Changes for Corporate Refund Attributes -- Begin -- 6/22/16

			Element elePersonInfoBillTo = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_PERSON_INFO);
			if(!(YFCCommon.isVoid(elePersonInfoBillTo)))
			{
				NodeList ndlChargeTransactionDetails = XPathUtil.getNodeList(docGetOrderDetailsOutput, KohlsPOCConstant.X_CHARGE_TRANSACTION_DETAIL);
				for(int z=0;z<ndlChargeTransactionDetails.getLength();z++)
				{
					Element eleRoot = (Element) ndlChargeTransactionDetails.item(z);
					docGetOrderDetailsOutput.adoptNode(elePersonInfoBillTo);
					XMLUtil.importElement(eleRoot, elePersonInfoBillTo);
				}
			}
			// Changes for Corporate Refund Attributes -- End -- 6/22/16

			Element eleChargeTransactionDetails = (Element) XPathUtil.getNode(docGetOrderDetailsOutput, KohlsPOCConstant.X_CHARGE_TRANSACTION_DETAILS);
			Element eleChargeTransDetForPSA = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAILS);

			XMLUtil.removeChild(elePSAOrder, eleChargeTransDetForPSA);
			inputDoc.adoptNode(eleChargeTransactionDetails);
			XMLUtil.appendChild(elePSAOrder, eleChargeTransactionDetails);
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("Updated Order Element is ::"+XMLUtil.getElementXMLString(elePSAOrder));
			}
			// Fetching ChargeTransactionDetails from API Output and Appending -- End -- 6/17/16

			// Parsing Clob Element into Document format 
			Element eleRootElement = docOriginalSale.getDocumentElement();

			String strClobData = docOriginalSale.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);

			loggerForPosInvoice.debug("Clob object is:::"+strClobData);

			if (!strClobData.isEmpty()) {
				Document docClobData = XMLUtil.getDocument(strClobData);
				eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA,KohlsPOCConstant.BLANK);
				Element eleNewClob = docClobData.getDocumentElement();
				XMLUtil.importElement(eleRootElement, eleNewClob);

			}
			if(loggerForPosInvoice.isDebugEnabled()){
			loggerForPosInvoice.debug("After import root element is::"+XMLUtil.getElementXMLString(eleRootElement));
			}
			//Fetching Order element from original Sales document
			eleOrderOfSale = (Element) XPathUtil.getNode(docOriginalSale ,KohlsPOCConstant.X_KOHLS_SALES_ORDER);

			// New Method Invocation For Appending Promotions And Taxes

			inputDoc = AppendPromotionAndTaxes(docOriginalSale,inputDoc);
			//inputDoc = ConsolidateTaxAndTotalAmt(docOriginalSale,inputDoc);

			// Fetching Sales Order Data And Populating at InvoiceHeader level -- Begin -- 6/15/16

			Element elePSAextn = XMLUtil.getChildElement(elePSAOrder, KohlsPOCConstant.A_EXTN);

			String strPosSeqNo = elePSAextn.getAttribute(KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
			String strOrderDate = eleOrderOfSale.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
			String strTerminalId = eleOrderOfSale.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
			String strSellerOrgCode = eleOrderOfSale.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);

			Element eleInvheaderExtn = (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_EXTN);

			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_ORDER_DATE,strOrderDate);
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_POS_SEQUEN_NO, strPosSeqNo);
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_TERMINAL_ID,strTerminalId);
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SELLER_ORG_CODE, strSellerOrgCode);

			// Adding Sales Data at Extn Level -- 6/25/16
			eleInvheaderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SHIP_NODE, strSellerOrgCode);

			// Fetching Sales Order Data And Populating at InvoiceHeader level -- End -- -- 6/15/16

			// Removing Clob Object from Sales Award Element -- Begin -- 6/15/16

			// Extracting Tiered Promo Discounts and Storing for #3135 -- Begin -- 27/7/16 --
			NodeList ndlOrderline = XPathUtil.getNodeList(docOriginalSale, KohlsPOCConstant.X_KOHLS_SALES_ORDERLINE);		

			if (ndlOrderline.getLength() != 0) {
				for (int i = 0; i < ndlOrderline.getLength(); i++) {

					DecimalFormat df = new DecimalFormat("0.00");
					Element eleOrderLine = (Element) ndlOrderline.item(i);
					if(loggerForPosInvoice.isDebugEnabled()){
					loggerForPosInvoice.debug("Current OrderLine Element is ::"+XMLUtil.getElementXMLString(eleOrderLine));
					}
					if (!YFCCommon.isVoid(eleOrderLine)) {
						String sOrderLineKey=eleOrderLine.getAttribute("OrderLineKey");
						NodeList ndlAwards=XPathUtil.getNodeList(docOriginalSale.getDocumentElement(), 
								"/KOHLSSalesForPsa/Order/OrderLines/OrderLine[@OrderLineKey='"+sOrderLineKey+"']/Awards/Award");


						if (ndlAwards != null) {
							for (int c = 0; c < ndlAwards.getLength(); c++) {
								Element eleAward = (Element) ndlAwards.item(c);
								//reverted 2792 changes and changed the AwardApplied flag to default value.
								String sAwardApplied = eleAward
										.getAttribute("AwardApplied");
								
								
								if(loggerForPosInvoice.isDebugEnabled()){
									loggerForPosInvoice.debug("Current OrderLine Element is after flag replace ::"+XMLUtil.getElementXMLString(eleOrderLine));
									}
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice
									.debug("Current Award Element is:::"
											+ XMLUtil
											.getElementXMLString(eleAward));
								Element eleExtn = XMLUtil.getChildElement(
										eleAward, KohlsPOCConstant.A_EXTN);
								
								
								if(loggerForPosInvoice.isDebugEnabled())
									loggerForPosInvoice
									.debug("Current Extn element under Award is:::"
											+ XMLUtil
											.getElementXMLString(eleExtn));
								if (!YFCCommon.isVoid(eleExtn)) {
									String sExtnPromoScheme = eleExtn
											.getAttribute("ExtnPromoScheme");
									int iExtnPromoScheme = 0;
									if (!YFCCommon.isVoid(sExtnPromoScheme)) {
										iExtnPromoScheme = Integer
												.parseInt(sExtnPromoScheme);
									}
									String strExtnSaleHubData = eleExtn
											.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
									loggerForPosInvoice
									.debug("Extn element exists:Checking SalesHubData attribute");
									if (!YFCCommon.isVoid(strExtnSaleHubData)) {
										loggerForPosInvoice
										.debug("Inside Clob block : Parsing into document object");
										Document docSalesHubData = XMLUtil
												.getDocument(strExtnSaleHubData);
										eleExtn.setAttribute(
												KohlsPOCConstant.A_EXTN_SALES_HUB_DATA,
												KohlsPOCConstant.BLANK);
										Element eleDataSalesHub = docSalesHubData
												.getDocumentElement();
										loggerForPosInvoice
										.debug("Importing parsed Clob object into Extn element");
										XMLUtil.importElement(eleExtn,
												eleDataSalesHub);
										if (iExtnPromoScheme >= 400
												&& iExtnPromoScheme <= 500
												&&  sAwardApplied
												.equalsIgnoreCase("Y")) {
											loggerForPosInvoice
											.debug("Inside Promo Scheme Block");
											
											String sPromoInterfaceId = eleDataSalesHub
													.getAttribute("PromoInterfaceId");
											String sDiscountPercent = eleDataSalesHub
													.getAttribute("DiscountPercent");
											if (!YFCCommon
													.isVoid(sDiscountPercent)) {
												sDiscountPercent = df
														.format(Double
																.parseDouble(sDiscountPercent) / 100.0);
												loggerForPosInvoice
												.debug("Inside not null block of Discount Percent");
											}
											String sTierAmtRchd = eleDataSalesHub
													.getAttribute("TierAmtRchd");
											String sTierQtyRchd = eleDataSalesHub
													.getAttribute("TierQtyRchd");
											String sAwardAmount = eleAward
													.getAttribute("AwardAmount");
											if (!mTieredDiscount
													.containsKey(sPromoInterfaceId)) {
												loggerForPosInvoice
												.debug("Updating mTieredDiscount hashmap with element and promoInterfaceId");
												Document docTLD = XMLUtil
														.createDocument("TransactionLevelDiscount");
												Element eleTLD = docTLD
														.getDocumentElement();
												eleTLD.setAttribute(
														"PromoInterfaceId",
														sPromoInterfaceId);
												eleTLD.setAttribute(
														"DiscountPercent",
														sDiscountPercent);
												eleTLD.setAttribute(
														"TierAmtRchd",
														sTierAmtRchd);
												eleTLD.setAttribute(
														"TierQtyRchd",
														sTierQtyRchd);
												eleTLD.setAttribute(
														"AwardAmount",
														sAwardAmount);
												eleTLD.setAttribute(
														"PromoScheme",
														sExtnPromoScheme);
												eleTLD.setAttribute(
														"DiscountTypeCode", "T");
												mTieredDiscount.put(
														sPromoInterfaceId,
														eleTLD);
												// Adding logger condition check
												// as per PRF-208
												if (loggerForPosInvoice
														.isDebugEnabled())
													loggerForPosInvoice
															.debug(sPromoInterfaceId
																	+ "Corresponding element is"
																	+ XMLUtil
																			.getElementXMLString(eleTLD));
											} else {
												loggerForPosInvoice
												.debug("Else Block for insertion in HashMap with promoInterfaceId");
												Element eleTLD = mTieredDiscount
														.get(sPromoInterfaceId);
												String sAwardAmt = eleTLD
														.getAttribute("AwardAmount");
												Double dOrigAwardAmt = 0.00;
												if (!YFCCommon
														.isVoid(sAwardAmt)) {
													dOrigAwardAmt = Double
															.parseDouble(sAwardAmt);
												}
												Double dAwardAmt = 0.00;
												if (!YFCCommon
														.isVoid(sAwardAmount)) {
													dAwardAmt = Double
															.parseDouble(sAwardAmount);
												}
												eleTLD.setAttribute(
														"AwardAmount",
														df.format(dOrigAwardAmt
																+ dAwardAmt));
												mTieredDiscount
												.remove(sPromoInterfaceId);
												mTieredDiscount.put(
														sPromoInterfaceId,
														eleTLD);
												
												if(loggerForPosInvoice.isDebugEnabled())
													loggerForPosInvoice
													.debug(sPromoInterfaceId
															+ "Corresponding element is"
															+ XMLUtil
															.getElementXMLString(eleTLD));
											}
										}

									}
								}
							}
						}
					}
				}

			}
			// Extracting Tiered Promo Discounts and Storing for # 3135 -- End -- 27/7/16 --

			// Removing Clob Object from Sales Award Element -- End -- 6/15/16

			// Preparing NodeList of Sales and PSA Orderline to integrate 

			ndlOriginalSaleOrder =  ((NodeList) XPathUtil
					.getNodeList(docOriginalSale.getDocumentElement(),
							KohlsPOCConstant.X_KOHLS_SALES_ORDERLINE));

			ndlPSASaleOrder = ((NodeList) XPathUtil
					.getNodeList(inputDoc.getDocumentElement(),
							KohlsPOCConstant.X_INV_ORDERLINE));

			// Fetching Temp NodeList of OrderLine elements in PSA document

			NodeList ndlTemp = XPathUtil.getNodeList(
					inputDoc.getDocumentElement(),
					KohlsPOCConstant.X_INV_ORDERLINE);
			// Fetching Parent element of Temp 

			Element eleTempParent = (Element) XPathUtil.getNode(
					inputDoc.getDocumentElement(),
					KohlsPOCConstant.X_INV_ORDERLINES);

			// Preparing Temp

			for(int b=0;b<ndlTemp.getLength();b++)
			{
				XMLUtil.removeChild(eleTempParent,(Element) ndlTemp.item(b));
			}

			// 	Comparing PrimeLineNo of Sales with PSA and Setting into Temp

			for(int i=0;i<ndlOriginalSaleOrder.getLength();i++)
			{
				Element eleCurrentElement = (Element) ndlOriginalSaleOrder.item(i);
				String strOrigPrimeLineNo = eleCurrentElement.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
				Element eleItemLevel = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.ELEM_ITEM);

				// Fix for 2969 -- begin

				Element eleCurrentExtn = XMLUtil.getChildElement(eleCurrentElement,"Extn");
				if(loggerForPosInvoice.isDebugEnabled()){
				loggerForPosInvoice.debug("Current Extn Element is::"+XMLUtil.getElementXMLString(eleCurrentExtn));
				}
				String strTaxInd = eleCurrentExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);

				strTaxInd = UpdateTaxIndType(strTaxInd);

				eleCurrentExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, strTaxInd);

				// Fix for 2969 -- End

				// Fix for UPC code at Sales OrderLine -- begin -- 6/15/16

				Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
				Element eleItemInput = docGetItemListInput.getDocumentElement();
				String strItemId = eleItemLevel
						.getAttribute(KohlsPOCConstant.A_ITEM_ID);
				String strUPCCode= eleItemLevel
						.getAttribute(KohlsPOCConstant.A_UPC_CODE);
				eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);

				Document docItemListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST, KohlsPOCConstant.API_GET_ITEM_LIST,docGetItemListInput);

				if(YFCCommon.isVoid(strUPCCode)|| strUPCCode.isEmpty() || strUPCCode == null) {

					String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput);
					if(YFCCommon.isVoid(upc_code)|| upc_code.isEmpty() || upc_code == null)
					{
						upc_code=strNoUPCMsg;
					}
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code );
				}
				else {
					eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
				}

				//Fix for UPC code at Sales OrderLine -- end -- 6/15/16

				// Setting LineTotal for Sales as negative -- Begin 
				Element eleLinePriceInfo = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.E_LINE_PRICE_INFO);
				Element eleLineOverrallTotals = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);

				String strLineTotal1 = eleLinePriceInfo.getAttribute(KohlsPOCConstant.E_LINE_TOTAL);
				String strLineTotal2 = eleLineOverrallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL);
				strLineTotal2=strnegative.concat(strLineTotal2);
				strLineTotal1 =strnegative.concat(strLineTotal1);
				eleLinePriceInfo.setAttribute(KohlsPOCConstant.E_LINE_TOTAL, strLineTotal1);
				eleLineOverrallTotals.setAttribute(KohlsPOCConstant.E_LINE_TOTAL,strLineTotal2);

				// Removing PLUResponseClob Object -- Begin

				Element eleCurrentElementExtn = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.A_EXTN);
				eleCurrentElementExtn.setAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE, KohlsPOCConstant.BLANK);

				// Removing PLUResponseClob Object -- End 

				// Fetching ExtnPLURetailAmt from Sale OrderLine Extn
				String strSalePLURetailAmt = eleCurrentElementExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT);
				if(loggerForPosInvoice.isDebugEnabled()){
				loggerForPosInvoice.debug("Current sale element is::"+XMLUtil.getElementXMLString(eleCurrentElement));
				loggerForPosInvoice.debug("Current PrimeLine No is:::"+strOrigPrimeLineNo);
				}
				for(int j=0;j<ndlPSASaleOrder.getLength();j++)
				{
					Element eleCurrentPSAElement = (Element) ndlPSASaleOrder.item(j);

					Element eleCurrentPSAElementExtn = XMLUtil.getChildElement(eleCurrentPSAElement, KohlsPOCConstant.A_EXTN);

					String strPSAPrimeLineNo = eleCurrentPSAElement.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

					// Fetching ExtnPLURetailAmt from PSA OrderLine Extn

					String strPSAPLURetailAmt = eleCurrentPSAElementExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT);
					if(loggerForPosInvoice.isDebugEnabled()){
					loggerForPosInvoice.debug("Current PSA element is::"+XMLUtil.getElementXMLString(eleCurrentPSAElement));
					loggerForPosInvoice.debug("Current PrimeLine No of PSA element is:::"+strPSAPrimeLineNo );
					}
					if(strOrigPrimeLineNo.equals(strPSAPrimeLineNo))
					{
						// Fix for 3557 -- Begin -- 8/25/16
						loggerForPosInvoice.debug("Inside Matching PrimeLine Number block ; now checking PLURetailAmounts");
						if((strSalePLURetailAmt.equalsIgnoreCase("0.00") && !strSalePLURetailAmt.equalsIgnoreCase(strPSAPLURetailAmt) && !YFCCommon.isStringVoid(strPSAPLURetailAmt)))
						{
							eleCurrentElementExtn.setAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, strPSAPLURetailAmt);
						}
						// Fix for 3557 -- End -- 8/25/16

						inputDoc.adoptNode(eleCurrentElement);
						XMLUtil.appendChild(eleTempParent, eleCurrentElement);
						XMLUtil.appendChild(eleTempParent, eleCurrentPSAElement);
					}
					else
					{
						loggerForPosInvoice.debug("Inside else block: Shouldn't be here");
					}
				}
			}

			inputDoc = calculateTotalOrderLines(inputDoc);
			inputDoc = getNodeListToRemove(inputDoc);
			inputDoc = setExternalPaymentAndRemoveKCS(inputDoc);
			inputDoc= removeCollectionOrChargeTranDetails(env,inputDoc);
			
			//CPE-3766 - Start
			String strClobDataForKCInfor = docOriginalSale.getDocumentElement().getAttribute("PSAKCData");
			 Element eleFinalOrderExtn = (Element)inputDoc.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
			 if(!YFCCommon.isVoid(strClobDataForKCInfor) && !strClobDataForKCInfor.isEmpty())
			 {
				 updateKCRefundDetails(inputDoc,strClobDataForKCInfor);
				 inputDoc = calTaxAndTotal(inputDoc);
				 
			 }
			 //CPE-3766 - End
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return inputDoc;
	}
	
public Document removeCollectionOrChargeTranDetails(YFSEnvironment env, Document inputDoc) {
		
		try{
			loggerForPosInvoice.debug("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails - Start");
		Element eleCollectionDetails = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_DETAILS).item(0);
		Element eleInvoiceHeader = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER).item(0);
		Element eleInvChargeTrans = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAILS).item(0);
		Element eleInvOrder = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER).item(0);
		NodeList nlCollectionDetailsList = eleInvoiceHeader.getElementsByTagName("CollectionDetail");
		
		String strTotalNo=KohlsPOCConstant.ZERO;
		strTotalNo=eleCollectionDetails.getAttribute("TotalLines");
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("nlCollectionDetailsList.getLength() value : " +nlCollectionDetailsList.getLength() + "  " +XMLUtil.getElementXMLString(eleCollectionDetails));
		}
		if(nlCollectionDetailsList.getLength()==0){
			XMLUtil.removeChild(eleInvoiceHeader, eleCollectionDetails);
		}
		else{
			XMLUtil.removeChild(eleInvOrder, eleInvChargeTrans);
			XMLUtil.createChild(eleInvOrder, "ChargeTransactionDetails");
		}
		
		}catch(Exception e){
			loggerForPosInvoice.debug(e.getMessage());
		}
		if(loggerForPosInvoice.isDebugEnabled()){
		loggerForPosInvoice.debug("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails Output"+XMLUtil.getXMLString(inputDoc));
		}
		loggerForPosInvoice.endTimer("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails - End");
		return inputDoc;
	}

	//Fix for PR-149 - End
	//Fix for PR-439 - Start
	public Document setExternalPaymentAndRemoveKCS(Document inputDoc)
	{
		loggerForPosInvoice.beginTimer("setExternalPaymentAndRemoveKCS");
			String strCheck = null;
			String strCollectionDate = null;
			boolean bKCSMaximized = false;
			String strCreditCardName = null;
			try {
				Element eleInvoiceHeader = (Element) XPathUtil.getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER).item(0); 
				NodeList ndlCollectionDetail = XPathUtil.getNodeList(inputDoc,
						KohlsPOCConstant.X_INV_COLLECTION_DETAIL);
	
				Element eleCollectionDetails = (Element) XPathUtil.getNode(inputDoc,
						KohlsPOCConstant.X_INV_COLLECTION_DETAILS);
				
				for (int i = 0; i < ndlCollectionDetail.getLength(); i++) {
					Element eleCurrentElement = (Element) ndlCollectionDetail
							.item(i);
					if (!YFCCommon.isVoid(eleCurrentElement)) {
						if(loggerForPosInvoice.isDebugEnabled()){
						loggerForPosInvoice.debug("Current CollectionDetail Element ::"
								+ XMLUtil.getElementXMLString(eleCurrentElement));
						}
						// New fix for CreditCardTransaction after Tendering Changes -- Begin -- 8/8/16
						
						 strCollectionDate = eleCurrentElement.getAttribute("CollectionDate");
						
						 loggerForPosInvoice.debug("Fetching ExecutionDate to be set ::"+strCollectionDate);
						 
						 
					if (!YFCCommon.isStringVoid(strCollectionDate)) {
	
						loggerForPosInvoice
								.debug("ExecutionDate exists , Explicitly setting it into CollectionDetails"
										+ strCollectionDate);
						eleCurrentElement.setAttribute("ExecutionDate",
								strCollectionDate);
					}
						
						// New fix for CreditCardTransaction after Tendering Changes -- End -- 8/8/16
						
						Element elePaymentMethod = (Element) XPathUtil.getNode(
								eleCurrentElement, "PaymentMethod");
						if (!YFCCommon.isVoid(elePaymentMethod)) {
							if(loggerForPosInvoice.isDebugEnabled()){
							loggerForPosInvoice.debug("Current Payment Method Element ::"
											+ XMLUtil
													.getElementXMLString(elePaymentMethod));
							}
							strCheck = elePaymentMethod.getAttribute("PaymentType");
							loggerForPosInvoice.debug("Payment Type is ::" + strCheck);
							if (strCheck.equalsIgnoreCase("CREDIT_CARD")
									|| strCheck.equalsIgnoreCase("DEBIT_CARD")
									|| strCheck.equalsIgnoreCase("KOHLS_CHARGE_CARD")) {
								loggerForPosInvoice.debug("Inside External Payment block");
								elePaymentMethod.setAttribute("IsExternalPayment","P");
	
							}
							strCreditCardName = XMLUtil.getAttribute(elePaymentMethod,KohlsPOCConstant.CreditCardName);
							elePaymentMethod.setAttribute(KohlsPOCConstant.ExtraDetails5,strCreditCardName);
							if("KOHLS_CASH".equalsIgnoreCase(strCheck))
							{
								XMLUtil.removeChild(eleCollectionDetails, eleCurrentElement);
								String CollDetsize = eleCollectionDetails.getAttribute("TotalLines");
								Integer int1 = Integer.valueOf(CollDetsize);
								int1-- ;
								eleCollectionDetails.setAttribute("TotalLines", int1.toString());
								//Fix for PR-439 - Start
								bKCSMaximized = true;
								//Fix for PR-439 - End
							}
	
						}
					}
				}
				if(bKCSMaximized){
					/*XMLUtil.removeChild(eleInvoiceHeader, eleCollectionDetails);
					//inputDoc.getDocumentElement().removeChild("CollectionDetails");  
					Element newEleCollectionDetails = XMLUtil.createChild(eleInvoiceHeader, "CollectionDetails");
					newEleCollectionDetails.setAttribute("TotalLines", "0");*/
					// CPE-2433 start
                			swapChargeTransactionDetailForKCSMaximize(eleInvoiceHeader);
                			// CPE 2433 end
				}
			}
			catch(Exception e){loggerForPosInvoice.verbose(e);}
		loggerForPosInvoice.endTimer("setExternalPaymentAndRemoveKCS");
			return inputDoc;
		}

	//Fix for PR-439 - End
	
	/**
     * CPE-2433 changes. This method makes the first ChargeTransactionDetail
     * with the one which does not have PaymentMethod detail.This change is as
     * per TIBCO requirement to get status Z in COSA for KCS Maximize option in
     * ISS.
     * 
     * @param eleInvoiceHeader
     */
    private void swapChargeTransactionDetailForKCSMaximize(Element eleInvoiceHeader) {
        loggerForPosInvoice.debug("KohlsCreateInputForPSA.swapChargeTransactionDetailForKCSMaximize---Begin");
        Element expectedElement = null;
        Element firstElement = null;
        boolean swapChargeTransactionDetails = false;

        NodeList orderList = eleInvoiceHeader.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
        Element chargeTransactionDetails = null;
        if (orderList.getLength() > 0) {
            Element orderElement = (Element) orderList.item(0);
            String entryType = orderElement.getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE);
            if (KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE.equals(entryType)) {
                NodeList chargeTransactionDetailsnl = orderElement.getElementsByTagName(KohlsPOCConstant.E_CHARGE_TRANSACTION_DETAILS);
                if (chargeTransactionDetailsnl.getLength() > 0) {
                    chargeTransactionDetails = (Element) chargeTransactionDetailsnl.item(0);
                    List<Element> chargeTransactionDetailsList = XMLUtil.getElementsByTagName(orderElement,KohlsPOCConstant.E_CHARGE_TRANSACTION_DETAIL);
                    for (Element chargeTransactionDetail : chargeTransactionDetailsList) {
                        if (chargeTransactionDetailsList.indexOf(chargeTransactionDetail) == 0) {
                            loggerForPosInvoice.debug("Assigning the first element  :");
                            firstElement = chargeTransactionDetail;

                        }
                        NodeList paymentMethodList = chargeTransactionDetail.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);

                        if (paymentMethodList.getLength() == 0) {
                            expectedElement = chargeTransactionDetail;
                            if (chargeTransactionDetailsList.indexOf(chargeTransactionDetail) != 0) {
                                loggerForPosInvoice.debug("Assigned the expected element  :");
                                swapChargeTransactionDetails = true;
                            }
                            break;
                        }

                    }
                    if (swapChargeTransactionDetails) {
                        loggerForPosInvoice.debug("Swapped the charge transactiondetails..");
                        chargeTransactionDetails.insertBefore(expectedElement, firstElement);
                    }

                }
            }
        }
        loggerForPosInvoice.debug("KohlsCreateInputForPSA.swapChargeTransactionDetailForKCSMaximize---End");
    }
	
	
	 //CPE-3766 - Start
	 public Document updateKCRefundDetails(Document inputDoc,String strClobDataForKCInfor) throws Exception
     	 {
		 
			loggerForPosInvoice.beginTimer("KohlsCreateInputForPSA.updateKCRefundDetails");
			Document docClobKCData = XMLUtil.getDocument(strClobDataForKCInfor);
			if(loggerForPosInvoice.isDebugEnabled()){
			  loggerForPosInvoice.debug("docClobKCData is: "+ XMLUtil.getXMLString(docClobKCData));
			  loggerForPosInvoice.debug("inputDoc is: "+ XMLUtil.getXMLString(inputDoc));
			}
			
			Element eleProrateOLs= (Element)XPathUtil.getNodeList(docClobKCData,"/Order/ProRatedLines").item(0);
			Element eleProratedExtn = (Element)XPathUtil.getNodeList(docClobKCData,"/Order/Extn").item(0);
			String strExtnKCDeactivated = eleProratedExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD);
			NodeList nlKCOrderLine = eleProrateOLs.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			if(!YFCCommon.isVoid(nlKCOrderLine) && nlKCOrderLine.getLength()>0)
			{
				for(int i=0;i< nlKCOrderLine.getLength();i++){
				Element eleOrderLine = (Element)nlKCOrderLine.item(i);
				String strPrimeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

				NodeList nlInvoiceLine = XPathUtil.getNodeList(inputDoc.getDocumentElement(), 
						"/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine[@Type='Sale'][@PrimeLineNo='"+strPrimeLineNo+"']");
				
				if(!YFCCommon.isVoid(nlInvoiceLine) && nlInvoiceLine.getLength()>0)
				{
				 Element eleInvoiceLine	 = (Element)nlInvoiceLine.item(0);
				 Element eleAwards = XMLUtil.getChildElement(eleInvoiceLine,KohlsPOCConstant.E_AWARDS,true);
				 Element eleLineCharges = XMLUtil.getChildElement(eleInvoiceLine,KohlsPOCConstant.ELEM_LINE_CHARGES,true);
				 			 
				 NodeList nlAwardList = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);
				 if(!YFCCommon.isVoid(nlAwardList) && nlAwardList.getLength()>0){
					 for(int j = 0;j<nlAwardList.getLength();j++) {
						 Element eleAward = (Element)nlAwardList.item(j);
						 Element eleExtn = XMLUtil.getChildElement(eleAward,"Extn");
						 String strExtnSaleHubData = eleExtn
								 .getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
						 String strAwardID = XMLUtil.getAttribute(eleAward, KohlsPOCConstant.A_AWARD_ID);
						 if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(strAwardID)){
							 NodeList nlInvoiceAwardList = eleInvoiceLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);
							 if(!YFCCommon.isVoid(nlInvoiceAwardList) && nlInvoiceAwardList.getLength()>0){
								 for(int a = 0;a<nlInvoiceAwardList.getLength();a++) {
									 Element eleInvoiceAward = (Element)nlInvoiceAwardList.item(a);
									 String strInvoiceAwardID = XMLUtil.getAttribute(eleInvoiceAward, KohlsPOCConstant.A_AWARD_ID);
									 if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(strInvoiceAwardID)){
										 eleAwards.removeChild(eleInvoiceAward);
									 }
								 }
							 }
						 }
					if (!YFCCommon.isVoid(strExtnSaleHubData)) {
						Document docSalesHubData = XMLUtil
								.getDocument(strExtnSaleHubData);
						eleExtn.setAttribute(
								KohlsPOCConstant.A_EXTN_SALES_HUB_DATA,
								KohlsPOCConstant.BLANK);
						Element eleDataSalesHub = docSalesHubData
								.getDocumentElement();
						XMLUtil.importElement(eleExtn,
								eleDataSalesHub);
					}
					XMLUtil.importElement(eleAwards,eleAward);
					 }
						
					}
				 NodeList nlLineCharge = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
				 Double dKCUnEarnedForLine = 0.00D;
				 if(!YFCCommon.isVoid(nlLineCharge) && nlLineCharge.getLength()>0)
					{
					 for(int k=0;k< nlLineCharge.getLength();k++){
					     Element eleLineCharge = (Element)nlLineCharge.item(k);
					     String sChargeName = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
					     String sChargeCategory = XMLUtil.getAttribute(eleLineCharge, KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
					     if("KohlsCashUnearned".equalsIgnoreCase(sChargeName)){
					       dKCUnEarnedForLine = dKCUnEarnedForLine + Double.parseDouble(eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE));
					     }
					     if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(sChargeCategory)){
					    	 NodeList nlInvoiceLineCharge = eleInvoiceLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
					    	 if(!YFCCommon.isVoid(nlInvoiceLineCharge) && nlInvoiceLineCharge.getLength()>0){
					    		 for(int l = 0;l<nlInvoiceLineCharge.getLength();l++) {
					    			 Element eleInvoiceLineCharge = (Element)nlInvoiceLineCharge.item(l);
					    			 String sInvoiceChargeCategory = XMLUtil.getAttribute(eleInvoiceLineCharge, KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
					    			 if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(sInvoiceChargeCategory)){
					    				 eleLineCharges.removeChild(eleInvoiceLineCharge);
					    			 }
					    		 }
					    	 }
					     }
						 XMLUtil.importElement(eleLineCharges,eleLineCharge);
					 }
					}
				 
				 Element eleInvoiceOrderLineOverallTotals = (Element)eleInvoiceLine.getElementsByTagName(KohlsPOCConstant.E_LINE_OVERALL_TOTALS).item(0);
				 if(!YFCCommon.isVoid(eleInvoiceOrderLineOverallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX))) {
				   String sLineTotalWithoutTax = eleInvoiceOrderLineOverallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX);
				   Double dLineTotalWithoutTax = Double.parseDouble(sLineTotalWithoutTax);
				   eleInvoiceOrderLineOverallTotals.setAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX, new DecimalFormat("#0.00").format(dLineTotalWithoutTax - dKCUnEarnedForLine ));
				 }
				 /* NodeList nlPSAInvoiceLine = XPathUtil.getNodeList(inputDoc.getDocumentElement(), 
                 "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine[@Type='PSA'][@PrimeLineNo='"+strPrimeLineNo+"']");
                 Element elePSAInvoiceLine    = (Element)nlPSAInvoiceLine.item(0);*/
                 Element eleInvoiceLineTaxes = XMLUtil.getChildElement(eleInvoiceLine,KohlsPOCConstant.ELEM_LINE_TAXES);
                 if(!YFCCommon.isVoid(eleInvoiceLineTaxes)){
                   eleInvoiceLine.removeChild(eleInvoiceLineTaxes);
                 }
                 eleInvoiceLineTaxes =  XMLUtil.createChild(eleInvoiceLine,KohlsPOCConstant.ELEM_LINE_TAXES);
                 
                  NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
                 
                  double calculatedTaxValue = 0.0;
                 if(!YFCCommon.isVoid(nlLineTax) && nlLineTax.getLength()>0)
                 {   
                      if(!YFCCommon.isVoid(nlLineTax) && nlLineTax.getLength()>0)
                         {
                           for(int l=0;l< nlLineTax.getLength();l++){
                                  Element eleLnTax = (Element)nlLineTax.item(l);
                                  String strTax = eleLnTax.getAttribute("Tax");
                                  XMLUtil.importElement(eleInvoiceLineTaxes,eleLnTax);
                                  calculatedTaxValue = calculatedTaxValue + Float.parseFloat(strTax);
                         }
                     }
                 }
                 eleInvoiceOrderLineOverallTotals.setAttribute("Tax", new DecimalFormat("#0.00").format(calculatedTaxValue));
				}
			}
		}
		
		Element eleUpdatePromotion= (Element)XPathUtil.getNodeList(docClobKCData,"/Order/Promotions/Promotion").item(0);
		if(!YFCCommon.isVoid(eleUpdatePromotion)){
			Element eleFinalPromotions = (Element)XPathUtil.getNodeList(inputDoc.getDocumentElement(), 
					"/InvoiceDetail/InvoiceHeader/Order/Promotions").item(0);
			XMLUtil.importElement(eleFinalPromotions, eleUpdatePromotion);
		}
		
		
		if(!YFCCommon.isVoid(eleProratedExtn))
		{
			Element eleFinalOrderExtn = (Element)inputDoc.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
			eleFinalOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD, strExtnKCDeactivated);
		}
		
		if(loggerForPosInvoice.isDebugEnabled()){
          loggerForPosInvoice.debug("At the end of updateKCRefundDetails method, inputDoc is: "+ XMLUtil.getXMLString(inputDoc));
        }
		loggerForPosInvoice.endTimer("KohlsCreateInputForPSA.updateKCRefundDetails");
		return inputDoc;
	 }
	 
	 public Document calTaxAndTotal(Document inDoc){
	 
	 loggerForPosInvoice.beginTimer("KohlsCreateInputForPSA.calTaxAndTotal");
		 
		 try {
			 	Float calFinalTotalValue = null ;
			 	String strFinalGrandTotal="";
			 	String strFinalGrandTax="";
			 	double dTotalAmountWithOutTax = 0.00D;
			 	double dTotalTax = 0.00D;
			 	
			 	Element eleInvoiceHeader = (Element) ((NodeList) XPathUtil.getNodeList(
                    inDoc.getDocumentElement(),
                    KohlsPOCConstant.XPATH_INVOICE_HEADER)).item(0);
			 	NodeList nlOrderLine = inDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
			 	
			 	for (int i=0; i<nlOrderLine.getLength(); i++){
			 	  Element eleOrderLine = (Element)nlOrderLine.item(i);
			 	  String sType = eleOrderLine.getAttribute("Type");
			 	  if(YFCCommon.isVoid(sType)){
			 	    continue;
			 	  }
			 	  Element eleLineOverallTotals = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
			 	  String sLineTotalWithoutTax = eleLineOverallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX);
			 	  double dLineTotalWithoutTax = 0.00D;
			 	  if(!YFCCommon.isVoid(sLineTotalWithoutTax)){
			 	    dLineTotalWithoutTax = Double.parseDouble(sLineTotalWithoutTax);
			 	  }
			 	  double dTax = 0.00D;
			 	  NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
			 	  for (int j=0; j<nlLineTax.getLength(); j++){
			 	    Element eleLineTax = (Element)nlLineTax.item(j);
			 	    String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
			 	    if(!YFCCommon.isVoid(sTax)){
			 	     dTax = dTax + Double.parseDouble(sTax);
			 	    }
			 	  }
			 	  if("SALE".equalsIgnoreCase(sType)){
			 	   dTotalAmountWithOutTax = dTotalAmountWithOutTax - dLineTotalWithoutTax;
			 	   dTotalTax = dTotalTax - dTax;
			 	  } else {
			 	    dTotalAmountWithOutTax = dTotalAmountWithOutTax + dLineTotalWithoutTax;
	                dTotalTax = dTotalTax + dTax;
			 	  }
			 	}
			 	
			 	
			/*	Element elePSATaxDetail = (Element)XPathUtil.getNode(inDoc.getDocumentElement(), 
							"/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail[@Type='PSA']");
				
				Element eleSaleTaxDetail = (Element)XPathUtil.getNode(inDoc.getDocumentElement(), 
						"/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail[@Type='Sale']");
				

				Element eleOrderExtn = (Element) ((NodeList) XPathUtil.getNodeList(
						inDoc.getDocumentElement(),
						KohlsPOCConstant.X_INV_ORDER_EXTN)).item(0);
				
				if(!YFCCommon.isVoid(elePSATaxDetail) && !YFCCommon.isVoid(eleSaleTaxDetail)){
					String sSaleTotalAmount = eleSaleTaxDetail.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
					String sPSATotalAmount = elePSATaxDetail.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
					
					String sKCDeactivationAmt = eleOrderExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_KCD);
					String sPSATaxPercent = eleSaleTaxDetail.getAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE);
					String sSaleTaxAmount = eleSaleTaxDetail.getAttribute(KohlsPOCConstant.A_TAX_AMOUNT);
					String sPSATaxAmount = elePSATaxDetail.getAttribute(KohlsPOCConstant.A_TAX_AMOUNT);
									
					if(!YFCCommon.isVoid(sKCDeactivationAmt)){
						Float dKCTax = Float.parseFloat(sKCDeactivationAmt) * (((Float.parseFloat(sPSATaxPercent)) / 100));
						System.out.println("KC tax is - "+dKCTax);
						Float calTaxValue = Float.parseFloat(sSaleTaxAmount) - Float.parseFloat(sPSATaxAmount) - dKCTax;
						System.out.println("Final tax is - "+calTaxValue);
						Float calTotalValue = Float.parseFloat(sSaleTotalAmount) - Float.parseFloat(sPSATotalAmount) + calTaxValue;
						System.out.println("Final amoutn is - "+calTotalValue);
						calFinalTotalValue =  calTotalValue - Float.parseFloat(sKCDeactivationAmt);
						strFinalGrandTotal = String.format("-%.2f", calFinalTotalValue);
						strFinalGrandTax = String.format("-%.2f", calTaxValue);
						
						if(YFCLogUtil.isDebugEnabled()){
							loggerForPosInvoice.debug("KC tax :: "+dKCTax);
							loggerForPosInvoice.debug("Final PSA tax :: "+calTaxValue);
							loggerForPosInvoice.debug("strFinalGrandTotal :: "+strFinalGrandTotal);
							loggerForPosInvoice.debug("strFinalGrandTax :: "+strFinalGrandTax);	
						}
					} */
					
					
					eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, new DecimalFormat("#0.00").format(dTotalAmountWithOutTax + dTotalTax));
					eleInvoiceHeader.setAttribute(KohlsPOCConstant.ATTR_TOTAL_TAX, new DecimalFormat("#0.00").format(dTotalTax));
					
			} catch (Exception e) {
				loggerForPosInvoice.error("calTaxAndTotal error ::" + e);
			}
		 return inDoc;
		 
		 
	 }
	 //CPE-3766 - End

}
