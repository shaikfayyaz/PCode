package com.kohls.poc.api;

import java.io.File;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCustomSHPOrderPurge extends KOHLSBaseApi {
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsCustomSHPOrderPurge.class);
	
	public Document getOrderList(YFSEnvironment env, Document inDoc)
			throws Exception {

		Document docOutOrderList = XMLUtil.createDocument("OrderList");

		@SuppressWarnings("unchecked")
		List<Element> eleOrderList = XMLUtil.getElementsByTagName(
				inDoc.getDocumentElement(), "Order");

		if (eleOrderList != null && eleOrderList.size() > 0) {

			for (int i = 0; i < eleOrderList.size(); i++) {

				@SuppressWarnings("unchecked")
				List<Element> eleOrderLineList = XMLUtil.getElementsByTagName(
						eleOrderList.get(i), "OrderLine");

				String strOLHasCarryORCancelLine = "N";

				if (eleOrderLineList != null && eleOrderLineList.size() > 0) {
					for (int j = 0; j < eleOrderLineList.size(); j++) {

						if (XMLUtil.getAttribute(
										eleOrderLineList.get(j),
										"DeliveryMethod").equals("CARRY")) {
							strOLHasCarryORCancelLine = "Y";
							break;
						}

					}
				}

				if (strOLHasCarryORCancelLine.equals("N"))

				{
					Element eleOutOrder = XMLUtil.createElement(
							docOutOrderList, "Order", "");
					eleOutOrder.setAttribute("OrderHeaderKey", eleOrderList
							.get(i).getAttribute("OrderHeaderKey"));
				XMLUtil.appendChild(docOutOrderList.getDocumentElement(), eleOutOrder);
				}

			}

		}
		return docOutOrderList;

	}


}
