package com.kohls.poc.api;

import java.rmi.RemoteException;
import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;



public class KohlsPoCCosaNonSaleTypeAPI extends KOHLSBaseApi {
	
	private static final YFCLogCategory 
 	loggerForCosaNonSaleType = YFCLogCategory
		.instance(KohlsPoCCosaNonSaleTypeAPI.class.getName());
	
	private YIFApi api;
	
	public KohlsPoCCosaNonSaleTypeAPI() throws YIFClientCreationException {
	    api = YIFClientFactory.getInstance().getApi();

	  }

	private Element eleInvoiceDetail = null;
	
	public Document generateNonSaleTypeCosaFeedToSalesHub(YFSEnvironment env, Document inNonSaleTypeCosaFeed) throws YFSException {
		Document docNonSaleTypeCosaFeedOutput = null;
		
		try {
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.generateNonSaleTypeCosaFeedToSalesHub");
		
		docNonSaleTypeCosaFeedOutput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
		eleInvoiceDetail = docNonSaleTypeCosaFeedOutput.getDocumentElement();
		/*Element eleTillStatus = (Element)((NodeList)XPathUtil.getNodeList(inNonSaleTypeCosaFeed.getDocumentElement(), "/TillStatus")).item(0);
		Element eleTillStatus = inNonSaleTypeCosaFeed.getDocumentElement();
		Document docOutputAccList = getAccountListForPOS(env, eleTillStatus);
		//Element eleAccountList = (Element)(XPathUtil.getNodeList(docOutputAccList.getDocumentElement(), "/Accounts/Account")).item(0);*/
		Element eleAccountList = inNonSaleTypeCosaFeed.getDocumentElement();
		String sProcedureID = eleAccountList.getAttribute("ProcedureID");
		if(!YFCCommon.isVoid(eleAccountList))
		{
			
			Element eleSalesAuditDetails = XMLUtil.createChild(eleInvoiceDetail, KohlsPOCConstant.ATTR_SALES_AUDIT_DETAILS);
			Element eleCosaFeed = XMLUtil.createChild(eleSalesAuditDetails, KohlsPOCConstant.ATTR_COSA_FEED);
			
			//Add StoreProductAccout Details
			//Manoj 11/20: Adding StoreProductAccs Element -- start
			Element eleStorePdtAccs = XMLUtil.createChild(eleCosaFeed, KohlsPOCConstant.ATTR_STORE_PRODUCT_ACCS);	
			Element eleStorePdtAcc = XMLUtil.createChild(eleStorePdtAccs, KohlsPOCConstant.ATTR_STORE_PRODUCT_ACC);
			// Manoj 11/20 Adding StoreProductAccs Element -- End
			eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
			eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, eleAccountList.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
			//eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
			 /*Manoj 12/15: Workaround for defect 3043 is to use AccountableTerminalID field instead of 
			 TerminalID field.*/
			eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_ACCOUNTABLE_TERMINAL_ID));
			eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
			if("3".equals(sProcedureID)){
				eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_STATUS, "Open");
				eleInvoiceDetail.setAttribute("MessageType", "RegisterOpen");
			} else if ("5".equals(sProcedureID)) {
				eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_STATUS, "Close");
				eleInvoiceDetail.setAttribute("MessageType", "RegisterClose");
			}			
			eleStorePdtAcc.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID));
			
			//Add Account Total Details
			Element eleAccTotal = XMLUtil.createChild(eleCosaFeed, KohlsPOCConstant.ATTR_ACCOUNT_TOTALS);
			eleAccTotal.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME));
			eleAccTotal.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, eleAccountList.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM));
			
			//changes for defect 316
			Element eleAdditionalDataList = XMLUtil.getChildElement(eleAccountList,"AdditionalDataList");
			XMLUtil.importElement(eleCosaFeed,eleAdditionalDataList);
		}
		}
		catch(Exception exception)
		{
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.generateNonSaleTypeCosaFeedToSalesHub");
			exception.printStackTrace();
			 if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
		}
		}
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.generateNonSaleTypeCosaFeedToSalesHub");
		return docNonSaleTypeCosaFeedOutput;
	}
	
	private Document getAccountListForPOS(YFSEnvironment env, Element eleTillStatus)
	{
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.getAccountListForPOS");
		Document docGetAccountListOutput = null;
		try {
		Document docGetAccountListInput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_ACCOUNT).getDocument();
		Element eleAccount = docGetAccountListInput.getDocumentElement();
		eleAccount.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
		//eleAccount.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID, eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID));
		eleAccount.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleTillStatus.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
		eleAccount.setAttribute(KohlsPOCConstant.ATTR_ACCOUNTABLE_TERMINAL_ID, eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
		eleAccount.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
		if(eleTillStatus.getAttribute(KohlsPOCConstant.A_CURRENT_STATUS).equalsIgnoreCase(KohlsPOCConstant.OPEN))
		{
			eleAccount.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "3");
			eleInvoiceDetail.setAttribute("MessageType", "RegisterOpen");
		}
		else
		{
			eleAccount.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "5");
			eleInvoiceDetail.setAttribute("MessageType", "RegisterClose");			
		}
		
		
		if(loggerForCosaNonSaleType.isDebugEnabled())
			loggerForCosaNonSaleType.debug("getAccountListForPOS API input is: \n" +XMLUtil.getXMLString(docGetAccountListInput));
		
		 //Call getAccountListForPOS  API
		docGetAccountListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ACCOUNT_LIST_FOR_POS,docGetAccountListInput);
		
		
		if(loggerForCosaNonSaleType.isDebugEnabled())
			loggerForCosaNonSaleType.debug("getAccountListForPOS API output is: \n" +XMLUtil.getXMLString(docGetAccountListOutput));
		}
		catch(Exception exception)
		{
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.getAccountListForPOS");
			exception.printStackTrace();
			 if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
			 }
		}
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.getAccountListForPOS");
		return docGetAccountListOutput;
	}
	
	public Document sendAdminAuditDetailsToSalesHub(YFSEnvironment env, Document docAdminAudit) throws YFSException, RemoteException
	{
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.sendAdminAuditDetailsToSalesHub");
		Document docTillContentDtls = YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
		Element eleInvoiceDetail = docTillContentDtls.getDocumentElement();
		Element eleAdminAuditList = null;
		
		//Added for Gift Card Balance Inquiry and Kohls Cash Inquiry Data Collection -- Start
		
		String strProcedureID = docAdminAudit.getDocumentElement().getAttribute("ProcedureID");		
		// Sprint 8: Added check for Post Sale KCA [ProcedureID = '10102'] -- Start
		if(strProcedureID.equals(KohlsPOCConstant.POST_SALE_KCA_PROCEDUREID))
		{
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_POS_SALE_KCA_TEMPLATE);
			//	Sprint 8: Set message type for post sale KCA
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_POST_SALE_KCA);
		}
		// Sprint 8: Added check for Post Sale KCA [ProcedureID = '10102'] -- End
		
      else if ( KohlsPOCConstant.GCINQ_PROCID.equals( strProcedureID ) || KohlsPOCConstant.KCBALINQ_PROCID.equals( strProcedureID ))
      {
         eleAdminAuditList = getAdminAuditListForPOS( env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_GC_KC_TEMPLATE );
         if ( KohlsPOCConstant.GCINQ_PROCID.equals( strProcedureID ) && eleAdminAuditList != null )
         {
            Element adminAudit = SCXmlUtil.getChildElement( eleAdminAuditList, KohlsXMLLiterals.E_ADMIN_AUDIT );
            if ( adminAudit != null )
            {
               Element additionalDataList = SCXmlUtil.getChildElement( adminAudit, KohlsXMLLiterals.E_ADDITIONAL_DATA_LIST );
               if ( additionalDataList != null )
               {
                  ArrayList<Element> additionalData = SCXmlUtil.getChildren( additionalDataList, KohlsXMLLiterals.E_ADDITIONAL_DATA );
                  String strSaleWithGCInq = null;
                  boolean dataCollect = true;
                  if ( additionalData != null )
                  {
                     for ( Element currentAdditionalData : additionalData )
                     {
                        strSaleWithGCInq = currentAdditionalData.getAttribute( KohlsXMLLiterals.A_NAME );
                        if ( KohlsPOCConstant.SALE_WITH_GCINQ.equalsIgnoreCase( strSaleWithGCInq ) )
                        {
                           dataCollect = false;
                           break;
                        }
                     }
                  }
                  if ( dataCollect )
                  {
                     eleInvoiceDetail.setAttribute( KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_GC_BALANCE_INQUIRY );
                  }
               }
            }
         }
      else if ( KohlsPOCConstant.KCBALINQ_PROCID.equals( strProcedureID ) && eleAdminAuditList != null)
      {
         eleInvoiceDetail.setAttribute( KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_KC_BALANCE_INQUIRY );
      }
    }
		
		//Added for Gift Card Balance Inquiry  and Kohls Cash Inquiry Data Collection -- End
		//  Added check for Quick credit sale  [ProcedureID = '10110'] and Quick credit Non_sale [ProcedureID = '10112'] -- start
		else if(strProcedureID.equals("10110") || strProcedureID.equals("10112"))
		{
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_QC_OFFLINE_TEMPLATE);
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_QC_OFFLINE);
	         }
		//  Added check for Quick credit sale  [ProcedureID = '10110'] and Quick credit Non_sale [ProcedureID = '10112'] -- End
		
		//CPE-7261 Start - Added Separate MessageType for Reticket
		else if(strProcedureID.equals("10201"))
		{
			// this is for damage defective
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_QC_OFFLINE_TEMPLATE);
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE,KohlsPOCConstant.MESSAGE_TYPE_DAMAGE_RETICKET);
			
			// set the items accordingly for tibco
			updateAdminAuditListForDamageDefective(eleAdminAuditList);
	        }
		//CPE-7261- Added Separate MessageType for Damaged/Defective 
		else if(strProcedureID.equals("10203"))
		{
			// this is for damage defective
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_QC_OFFLINE_TEMPLATE);
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_DAMAGE_DEFECTIVE);
			
			// set the items accordingly for tibco
			updateAdminAuditListForDamageDefective(eleAdminAuditList);
	        }
		// CPE-7261 - Corrected for Reticket void
		else if(strProcedureID.equals("10202"))
		{
			// this is for Reticket void
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_QC_OFFLINE_TEMPLATE);
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_DAMAGE_RETICKET);
			
			// set the items accordingly for tibco
			updateAdminAuditListForDamageDefective(eleAdminAuditList);
	     }
			// CPE-7261 - Corrected for Reticket void
		else if(strProcedureID.equals("10204"))
		{
			// this is for DamageDefective void
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_QC_OFFLINE_TEMPLATE);
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_DAMAGE_DEFECTIVE);
			
			// set the items accordingly for tibco
			updateAdminAuditListForDamageDefective(eleAdminAuditList);
	     }
		
		//CPE-7261 End - Added Separate MessageType for Reticket
		//  Added check for Quick credit Registration sale  [Quick credit Registration Non_sale [ProcedureID = '502' and Quick credit Registration Non_sale [ProcedureID = '503'] -- End
		else if(strProcedureID.equals("502") || strProcedureID.equals("503"))
		{
			// this is for QC Registration IE DCOL
			eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_FOR_QC_REGISTRATION_TEMPLATE);
			eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_QC_REGISTRATION);
			eleAdminAuditList=removeCRLFChars(eleAdminAuditList);
	       }
		else 
		{
		
			 eleAdminAuditList = getAdminAuditListForPOS(env, docAdminAudit, KohlsPOCConstant.GET_ADMIN_AUDIT_TEMPLATE);
			 Element eleExtn = null;
			 
			 //Added for No Sale -- Start
			 if(strProcedureID.equals("105"))
				{

				
				 	eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_NO_SALE);
				 	
				}
			//Added for No Sale -- End
			 else 
			 {
				 if("112".equals(strProcedureID))
				 {
					 
					 String organizationCode = docAdminAudit.getDocumentElement().getAttribute("OrganizationCode");
					 String terminalID = docAdminAudit.getDocumentElement().getAttribute("TerminalID");
					 Document tillInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
					 Document docTillStatusOut = null;
				      tillInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
				    		  organizationCode);
				      if(!YFCCommon.isVoid(terminalID))
				      {
				    	  	tillInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_TERMINAL_ID,
					    		  terminalID);
				    	  	 docTillStatusOut = api.getCurrentTillStatusForPOS(env, tillInput);
				      }
				     
				     // log.debug("INput to api is" + SCXmlUtil.getString(tillInput));
				      //Document docNextTranOut = api.getNextTransactionNumberForPOS(env, tillInput);
				      
				      if (docTillStatusOut != null) {
				    	  
				    	  String terminalBusinessDay = docTillStatusOut.getDocumentElement().getAttribute("BusinessDay");
				    	  if(!YFCCommon.isVoid(terminalBusinessDay))
				    	  {
	
				    		  if(!YFCCommon.isVoid(XMLUtil.getChildElement(eleAdminAuditList, "AdminAudit")))
		    				  {
				    			  XMLUtil.setAttribute(XMLUtil.getChildElement(eleAdminAuditList, "AdminAudit"), "BusinessDay", terminalBusinessDay);
		    				  }			    		  
				    		  
				    	  }
			      }
			    	  
			     }

				 eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_TILL_CONTENT);
			 	
			 }
			 
		}
		
	
		eleInvoiceDetail.setAttribute("xmlns","http://www.sterlingcommerce.com/documentation");
		Element eleInvHeader=XMLUtil.createChild(eleInvoiceDetail, KohlsPOCConstant.ATTR_INVOICE_HEADER);
		XMLUtil.importElement(eleInvHeader,eleAdminAuditList);			
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.sendAdminAuditDetailsToSalesHub");
		return docTillContentDtls;
	}
	
	private void updateAdminAuditListForDamageDefective(Element adminAuditList) {
		// sample
		// <?xml version="1.0" encoding="UTF-8"?>
		//<AdminAuditList>
	    //<AdminAudit AdminAuditKey="201711080958292501599"
	    //    BusinessDay="2017-01-19" Createprogid="YFSSYS00004"
	    //    Createts="2017-11-08T09:58:29-06:00" Createuserid="2104795"
	    //    DateTime="2017-11-08T09:58:29-06:00" Lockid="0" ManagerID=""
	    //    Modifyprogid="YFSSYS00004" Modifyts="2017-11-08T09:58:29-06:00"
	    //    Modifyuserid="2104795" OperatorID="2104795"
	    //    OrganizationCode="9954" POSSequenceNumber="6387"
	    //    ProcedureID="10203" TerminalID="75" TillID="27"
	    //    TransactionNumber="1108170955329954756387" isHistory="N">
	    //    <AdditionalDataList>
	    //        <AdditionalData AdditionalDataKey="201711080958292501601"
	    //            Name="Item0" ParentKey="201711080958292501599"
	    //            ParentTable="POS_ADMIN_AUDIT" Value="&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?>&#xa;&lt;Item>&#xa;    &lt;Detail Class=&quot;80&quot; Dept=&quot;17&quot; IsCallbackItem=&quot;N&quot; KohlsPrice=&quot;22.00&quot;&#xa;        OrigPrice=&quot;22.00&quot; SKU=&quot;01717170&quot; Status=&quot;A&quot; SubClass=&quot;87&quot; UPC=&quot;768353551128&quot;/>&#xa;&lt;/Item>"/>
	    //        <AdditionalData AdditionalDataKey="201711080958292501602"
	    //            Name="Item1" ParentKey="201711080958292501599"
	    //            ParentTable="POS_ADMIN_AUDIT" Value="&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?>&#xa;&lt;Item>&#xa;    &lt;Detail Class=&quot;10&quot; Dept=&quot;427&quot; IsCallbackItem=&quot;N&quot; KohlsPrice=&quot;57.00&quot;&#xa;        OrigPrice=&quot;57.00&quot; SKU=&quot;42710255&quot; Status=&quot;A&quot; SubClass=&quot;10&quot; UPC=&quot;400427102552&quot;/>&#xa;&lt;/Item>"/>
	    //        <AdditionalData AdditionalDataKey="201711080958292501600"
	    //            Name="Summary" ParentKey="201711080958292501599"
	    //            ParentTable="POS_ADMIN_AUDIT" Value="&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?>&#xa;&lt;AuditTransaction>&#xa;    &lt;Summary Action=&quot;N&quot; RegBank=&quot;0001&quot; StartTime=&quot;2017-11-08T09:58:29&quot;/>&#xa;&lt;/AuditTransaction>"/>
	    //    </AdditionalDataList>
	    //</AdminAudit>
		//	</AdminAuditList>
		Element adminAudit = SCXmlUtil.getChildElement(adminAuditList, KohlsXMLLiterals.E_ADMIN_AUDIT);
		Element additionalDataList = SCXmlUtil.getChildElement(adminAudit, KohlsXMLLiterals.E_ADDITIONAL_DATA_LIST);
		ArrayList<Element> additionalData = SCXmlUtil.getChildren(additionalDataList, KohlsXMLLiterals.E_ADDITIONAL_DATA);
		if (additionalData != null) {
			for (Element currentAdditionalData : additionalData) {
				if (currentAdditionalData.getAttribute(KohlsXMLLiterals.A_NAME).indexOf(KohlsXMLLiterals.E_ITEM) >= 0) {
					// translate this into an item and add an additional attribute called LineItemSequenceNumber
					// the number should just be what's left after 'Item'
					String itemNumber = currentAdditionalData.getAttribute(KohlsXMLLiterals.A_NAME).substring(4);
					currentAdditionalData.setAttribute(KohlsXMLLiterals.A_NAME, KohlsXMLLiterals.E_ITEM);
					//currentAdditionalData.setAttribute(KohlsXMLLiterals.A_LINE_ITEM_SEQUENCE_NUMBER, itemNumber);
				}
			}
		}

	}
	
	// Fix for defect-5081 :  START // 
	
	public void getExtnElement(Element eleAdminAuditList,Element eleInvoiceDetail){
		
		
		if(loggerForCosaNonSaleType.isDebugEnabled()){
			
			loggerForCosaNonSaleType.debug("Input XML to KohlsPoCCosaNonSaleTypeAPI.getExtnElement and  eleAdminAuditList is : \n"+
				 XMLUtil.getElementXMLString(eleAdminAuditList));
		
			loggerForCosaNonSaleType.debug("Input XML from KohlsPoCCosaNonSaleTypeAPI.getExtnElement and eleInvoiceDetail is: \n"+
				 XMLUtil.getElementXMLString(eleInvoiceDetail));
		}
		
		/*
		 * <AdminAudit AdminAuditKey='' Amount='' AccountNumber='' BusinessDay='' CardEntryMethod='' Createprogid='' Createts='' Createuserid='' 
		 * DateTime='' Error='' ItemID='' Lockid='' ManagerID='' MaskedAccountNumber='' Modifyprogid='' Modifyts='' Modifyuserid='' 
		 * OperatorID='' OrganizationCode='' POSSequenceNumber='' Price='' ProcedureID='' Quantity='' ReasonCode='' TerminalID='' 
		 * TillID='' TransactionNumber=''>
		 * <AdditionalDataList>
		 * <AdditionalData Name='' Value=''/>
		 * </AdditionalDataList>
		 * </AdminAudit>
		 * 
		 */
		
		//Element eleAdminAuditList = (Element)((NodeList)XPathUtil.getNodeList(eleAdminAuditList.getDocumentElement(), "/TransactionAudit")).item(0);
		Element eleAdditionalDataList = null;
		String strName = null;
		String strValue = null;
		Element eleExtn = null;
		
		try {
			eleAdditionalDataList = (Element)((NodeList)XPathUtil.getNodeList(eleAdminAuditList, "/AdminAudit/AdditionalDataList")).item(0);
			//eleAdditionalDataList = XMLUtil.getChildElement(eleAdminAuditList,"AdditionalDataList");
			NodeList nlElements = eleAdditionalDataList.getElementsByTagName("AdditionalData");
			for(int i = 0; i < nlElements.getLength(); i++){
				 if(!YFCCommon.isVoid(nlElements.getLength())){
				
				 Element eleAdditionalData = (Element)nlElements.item(i);
				 strName = eleAdditionalData.getAttribute("Name");
				 				 
				 loggerForCosaNonSaleType.debug("Input XML to KohlsPoCCosaNonSaleTypeAPI.getExtnElement and is: \n"+
						 "AdditionalData :"+strName);
				
				 
				 //Fix for defect 316, 210, 211 adding ExtnRegBankNo and ExtnRegLocation in if condition
				 if(("ExtnRegisterBankNumber".equalsIgnoreCase(strName)) || !YFCCommon.isStringVoid(strName) || "ExtnRegisterLocation".equalsIgnoreCase(strName) || 
						 "ExtnRegBankNo".equalsIgnoreCase(strName) || "ExtnRegLocation".equalsIgnoreCase(strName)){
					 
					 strValue =  eleAdditionalData.getAttribute("Value");
					 Element eleOrder = (Element)((NodeList)XPathUtil.getNodeList(eleInvoiceDetail, "/InvoiceDetail/InvoiceHeader/Order")).item(0);
						Element eleOrderExtn = XMLUtil.getChildElement(eleOrder,"Extn",true);
						if(!YFCCommon.isVoid(eleOrderExtn)){
								//Fix for defect 316, 210, 211 - Start
							if(strName.equalsIgnoreCase("ExtnRegisterBankNumber") || strName.equalsIgnoreCase("ExtnRegBankNo")){
								eleOrderExtn.setAttribute("ExtnRegisterBankNumber",strValue);
							}
							else{
								eleOrderExtn.setAttribute("ExtnRegisterLocation",strValue);
							}
							//Fix for defect 316, 210, 211 - End
						}		
						
						
						if(loggerForCosaNonSaleType.isDebugEnabled())
							loggerForCosaNonSaleType.debug("Input XML to KohlsPoCCosaNonSaleTypeAPI.getExtnElement and is: \n"+ "eleOrder"+
								 XMLUtil.getElementXMLString(eleOrder));
				 }
						

				 }
				 
			}	 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	// Fix for defect-5081 :  END // 
		
		
	public Document sendReprintReceiptDetailsToSalesHub(YFSEnvironment env, Document docTransAudit)
	{
		Document docReprintReceiptDtls = null;
		try {
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.sendReprintReceiptDetailsToSalesHub");
			
			docReprintReceiptDtls = YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
			Element eleInvoiceDetail = docReprintReceiptDtls.getDocumentElement();
			Element eleInvHeader=XMLUtil.createChild(eleInvoiceDetail, KohlsPOCConstant.ATTR_INVOICE_HEADER);
			//Defect 213 - Begin
			Element eleOrder = XMLUtil.createChild(eleInvHeader, KohlsPOCConstant.ELEM_ORDER);
			Element eleOrderExtn = XMLUtil.createChild(eleOrder, KohlsPOCConstant.E_EXTN);
			//Defect 213 - End
			
			
			Element eleTransAuditRoot = (Element)((NodeList)XPathUtil.getNodeList(docTransAudit.getDocumentElement(), "/TransactionAudit")).item(0);
			if(!YFCCommon.isVoid(eleTransAuditRoot))
			{
				Document docGetTransAuditInput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT).getDocument();
				Element eleTransAdAuditInput = docGetTransAuditInput.getDocumentElement();
				eleTransAdAuditInput.setAttribute(KohlsPOCConstant.ATTR_TRANS_AUDIT_KEY, eleTransAuditRoot.getAttribute(KohlsPOCConstant.ATTR_TRANS_AUDIT_KEY));
				eleTransAdAuditInput.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, eleTransAuditRoot.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID));
				Document docGetTransAuditOutput = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE)
						,KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS,docGetTransAuditInput);
				
				//Defect 213 - Begin
				NodeList nlGetTransAuditOutput = docGetTransAuditOutput.getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
				Element eleTransAuditOutput = (Element)nlGetTransAuditOutput.item(0);
								
				//preparing input for getOrderList API
				if(!YFCCommon.isVoid(eleTransAuditOutput) && !YFCCommon.isVoid(eleTransAuditOutput.getAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER))){
				Document docGetOrderListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
				Element eleGetOrderList = docGetOrderListInput.getDocumentElement();
				eleGetOrderList.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleTransAuditOutput.getAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER));
				eleGetOrderList.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
				Document docGetOrderListOutput = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_LIST_TEMP_FOR_NON_SALE), KohlsPOCConstant.API_GET_ORDER_LIST, docGetOrderListInput);  //ExtnRegisterBankNumber   ExtnRegisterLocation
				NodeList nlExtn = docGetOrderListOutput.getElementsByTagName(KohlsPOCConstant.A_EXTN);
				Element eleExtn = (Element) nlExtn.item(0);				
				eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_REGISTER_BANK_NUMBER, eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_REGISTER_BANK_NUMBER));
				eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_REGISTER_LOCATION, eleExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_REGISTER_LOCATION));
				}
				//Defect 213 - End
									
				if(eleTransAdAuditInput.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID).equalsIgnoreCase(KohlsPOCConstant.RECEIPT_REPRINT_PROCEDURE_ID))
				{
					eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_RECEIPT_REPRINT);
				}
				else if (eleTransAdAuditInput.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID).equalsIgnoreCase(KohlsPOCConstant.REBATE_RECEIPT_REPRINT_PROCEDURE_ID))
				{
					eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_REBATE_RECEIPT_REPRINT);
				}
				else {
					eleInvoiceDetail.setAttribute(KohlsPOCConstant.ATTR_MESSAGE_TYPE, KohlsPOCConstant.MESSAGE_TYPE_GIFT_RECEIPT_REPRINT);					
				}
				eleInvoiceDetail.setAttribute("xmlns","http://www.sterlingcommerce.com/documentation");
				Element eleAdminAuditList = docGetTransAuditOutput.getDocumentElement();
				XMLUtil.importElement(eleInvHeader,eleAdminAuditList);		
			}
		}
		catch(Exception exception)
		{
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.sendReprintReceiptDetailsToSalesHub");
			exception.printStackTrace();
			 if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
			 }
		}
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.sendReprintReceiptDetailsToSalesHub");
		return docReprintReceiptDtls;
	}
	
	public Element getAdminAuditListForPOS(YFSEnvironment env, Document docAdminAudit, String sAdminAuditListTemplate)
	{	
		KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.getAdminAuditListForPOS");
		Element eleAdminAuditList = null;
		try {
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.beginXMLTransform");	
			Element eleAdminAudit = (Element)((NodeList)XPathUtil.getNodeList(docAdminAudit.getDocumentElement(), "/AdminAudit")).item(0);
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.beginXMLTransform");
				if(!YFCCommon.isVoid(eleAdminAudit))
				{
					KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.beginTimer("KohlsPoCCosaNonSaleTypeAPI.beginInputFormation");	
					Document docGetAdminAuditInput = YFCDocument.createDocument(KohlsPOCConstant.ELE_ADMIN_AUDIT).getDocument();
					Element eleAdminAuditInput = docGetAdminAuditInput.getDocumentElement();
					eleAdminAuditInput.setAttribute(KohlsPOCConstant.ATTR_ADMIN_AUDIT_KEY, eleAdminAudit.getAttribute(KohlsPOCConstant.ATTR_ADMIN_AUDIT_KEY));
					eleAdminAuditInput.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, eleAdminAudit.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID));
					KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.beginInputFormation");	
					KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.TemplateDocument");	
					Document docTemplate = XMLUtil.getDocument(sAdminAuditListTemplate);
					KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.TemplateDocument");	
					Document docGetAdminAuditOutput = KOHLSBaseApi.invokeAPI(env, docTemplate, KohlsPOCConstant.STR_GET_ADMIN_AUDIT_LIST_FOR_POS,docGetAdminAuditInput);
					eleAdminAuditList = docGetAdminAuditOutput.getDocumentElement();				
				}
			}
			catch(Exception exception)
			{
				KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.getAdminAuditListForPOS");
				exception.printStackTrace();
				 if (exception instanceof YFSException) {
					YFSException yfsException = (YFSException) exception;
					throw yfsException;
				 }
			}
			KohlsPoCCosaNonSaleTypeAPI.loggerForCosaNonSaleType.endTimer("KohlsPoCCosaNonSaleTypeAPI.getAdminAuditListForPOS");
			return eleAdminAuditList;
		}
	public Document captureOfflineTrans(YFSEnvironment env, Document docAdminAudit) throws Exception{


		Element eventEle = docAdminAudit.getDocumentElement();

		String tagNameFromEvent = eventEle.getTagName();
		String organizationCode = eventEle.getAttribute( KohlsPOCConstant.A_ORGANIZATION_CODE );
		String procedureID = eventEle.getAttribute( KohlsPOCConstant.ATTR_PROCEDURE_ID );
		String operationTS = eventEle.getAttribute( KohlsPOCConstant.ATTR_DATE_TIME );
		String businessDay = eventEle.getAttribute( KohlsPOCConstant.ATTR_BUSINESS_DAY );

		if ( loggerForCosaNonSaleType.isDebugEnabled() )
		{
			loggerForCosaNonSaleType.debug( ": tagName=" + tagNameFromEvent + ", organizationCode=" + organizationCode + ", Business Day=" + businessDay + ": Audit procedure ID is : " + procedureID );
		}

		Document inDoc = XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
		Element eleRoot = inDoc.getDocumentElement();
		eleRoot.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.ACTION_CREATE);
		eleRoot.setAttribute(KohlsPOCConstant.A_DATA_XML, XMLUtil.getXMLString(docAdminAudit));
		eleRoot.setAttribute(KohlsPOCConstant.A_OPERATION_ID, procedureID);
		eleRoot.setAttribute(KohlsPOCConstant.INXML_STORE_ID, organizationCode);
		eleRoot.setAttribute(KohlsPOCConstant.A_OPERATION_TS,operationTS);
		eleRoot.setAttribute(KohlsPOCConstant.A_IS_LOCAL,KohlsPOCConstant.YES);
		Document outDoc = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, inDoc);
		if ( loggerForCosaNonSaleType.isVerboseEnabled() )
		{
			loggerForCosaNonSaleType.verbose( ": The output XML for manageOfflineTransactionQForPOS API is :" + YFCDocument.getDocumentFor( outDoc ).getString() );
		}
		return outDoc;


	}
	
	
	/**
	This CRLF characters will have to be removed.
	@param eleAdminAuditList
	@return */ public Element removeCRLFChars(Element eleAdminAuditList) {
	/* Initialize variables */
	Element eleAdditionalDataList = null;
	Element eleAudit = null;
	int iCount = 0;
	NodeList nlAdditionalData = null;

	if(!YFCCommon.isVoid(eleAdminAuditList)) {

	  eleAudit = XMLUtil.getChildElement(eleAdminAuditList, KohlsPOCConstant.ELE_ADMIN_AUDIT);

	  if(!YFCCommon.isVoid(eleAudit)) {
	    eleAdditionalDataList = XMLUtil.getChildElement(eleAudit, KohlsXMLLiterals.E_ADDITIONAL_DATA_LIST);
	  }

	  if(!YFCCommon.isVoid(eleAdditionalDataList)) {
	    nlAdditionalData = eleAdditionalDataList.getElementsByTagName(KohlsXMLLiterals.E_ADDITIONAL_DATA);
	  }

	  if(!YFCCommon.isVoid(nlAdditionalData)) {
	    iCount = nlAdditionalData.getLength();
	  }

	  for(int i=0; i<iCount; i++) {
	    Element eleAdditionalData = (Element) nlAdditionalData.item(i);
	    String strValue = eleAdditionalData.getAttribute(KohlsPOCConstant.Value).replace("\n","").replace("\r","");
	    strValue = strValue.replace("&#xa;","");
	    eleAdditionalData.setAttribute(KohlsPOCConstant.Value, strValue);

	  }

	}
	return eleAdminAuditList;
	}
}

