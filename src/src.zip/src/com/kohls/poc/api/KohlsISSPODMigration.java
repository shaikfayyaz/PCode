package com.kohls.poc.api;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsDeploymentUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.shared.dbclasses.YFS_Sync_DB_ImportDBHome;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsISSPODMigration {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsISSPODMigration.class.getName());

	public Document inStorePODMigration(YFSEnvironment env, Document inDoc) throws Exception {
		log.info("Input to KohlsISSPODMigration service " + SCXmlUtil.getString(inDoc));
		Document outDoc = null;
		String actionName = null;
		try {
			Element inElm = inDoc.getDocumentElement();
			ArrayList<Element> elmSyncStoreList = SCXmlUtil.getChildren(inElm, KohlsPOCConstant.A_SYNC_STORE);			
			if (elmSyncStoreList.size() == 0) {
				 actionName = inElm.getAttribute(KohlsPOCConstant.ACTION);
			} else {
				for (Element syncStore : elmSyncStoreList) {
					 actionName = syncStore.getAttribute(KohlsPOCConstant.ACTION);
				}
			}			
			log.info("Action to be performed is " + actionName);
			KohlsDeploymentUtil cacheClear = new KohlsDeploymentUtil();
			if (actionName.equalsIgnoreCase(KohlsPOCConstant.REMOVE)
					|| actionName.equalsIgnoreCase(KohlsPOCConstant.A_ACTION_ADD)) {
				// Step - 1 - POD1, Step 4 - POD2 / PRE/POST
				outDoc = storeSyncSubscription(env, inDoc);
			} else if (actionName.equalsIgnoreCase(KohlsPOCConstant.A_CLEAR)) {
				// Step-2 - POD1
				outDoc = deleteSyncDBImportEntries(env, inElm.getAttribute(KohlsPOCConstant.ATTR_STORE_ID));
			} else if (actionName.equalsIgnoreCase(KohlsPOCConstant.DELETE)
					|| actionName.equalsIgnoreCase(KohlsPOCConstant.MODIFY)) {
				// Step-3 - POD1
				outDoc = modifyServerStatus(env, inDoc);
			} else if (actionName.equalsIgnoreCase(KohlsPOCConstant.MANAGE)) {
				outDoc = updatePodProfilesStatus(env, inDoc);
			}else if(YFCCommon.isVoid(actionName)){				
				outDoc = getServerStatus(env, inDoc);
			}
			// CLearing the cache
			cacheClear.callModifyCache(env);
		} catch (Exception e) {
			outDoc = SCXmlUtil.createDocument(KohlsPOCConstant.ATTR_STATUS);
			Element elm = outDoc.getDocumentElement();
			elm.setAttribute(KohlsPOCConstant.ErrorMessage, e.getMessage());
			return outDoc;
		}
		return outDoc;
	}

	// Delete and adds the stores
	// CORP POD1
	// <SyncStoreList><SyncStore Action="REMOVE" StoreId="101"/></SyncStoreList>
	// CORP - POD2
	// <SyncStoreList><SyncStore Action="ADD" StoreId="101"/></SyncStoreList>
	private Document storeSyncSubscription(YFSEnvironment env, Document inDoc) throws Exception {
		log.info("Input to ManageStoreSyncSubscriptionService " + SCXmlUtil.getString(inDoc));
		Document outputDocDate = KohlsCommonUtil.invokeService(env, KohlsPOCConstant.SERVICE_MANAGE_STORE_SYNC_SUBS,
				inDoc);
		log.info("Output from ManageStoreSyncSubscriptionService " + SCXmlUtil.getString(outputDocDate));
		return outputDocDate;
	}

	// Deletes store entry from yfs_sync_db_import - On Store & Corp - POD1
	// <SyncDBImport Action="CLEAR" StoreID="101"/>
	private Document deleteSyncDBImportEntries(YFSEnvironment env, String storeID) throws Exception {
		try {
			log.info("Removing the DB entries for the store " + storeID);
			YFSContext yctx = (YFSContext) env;
			PLTQueryBuilder query = new PLTQueryBuilder();
			query.appendString("SYNC_TARGET_ID", "=", storeID);
			log.info("Query being fired " + query.getReadableWhereClause());
			YFS_Sync_DB_ImportDBHome.getInstance().deleteWithWhere(yctx, query);
			return SCXmlUtil.createDocument(KohlsPOCConstant.SUCCESS);
		} catch (Exception e) {
			log.error("Exception while deleting the records sync import table, storeID " + storeID + e.getMessage());
			throw e;
		}
	}

	// Deletes the server status entry - Both on Store and Corp - POD1
	// <ServerStatus Action="Delete" ServerIp="isx0101h.st.ad.kohls.com" StoreID="101"/>
	//Force Offline- <ServerStatus Action="Modify" ForceSwitchingFlag="Y" ServerIp="isx9916h.st.ad.kohls.com"  StoreID="9916" ServerStatus="1002"/>
	//Remove Force offline - <ServerStatus Action="Modify" ForceSwitchingFlag="N" ServerIp="isx9916h.st.ad.kohls.com"  StoreID="9916" ServerStatus="1001"/>

	private Document modifyServerStatus(YFSEnvironment env, Document inDoc) throws Exception {
		log.info("Input to manageServerStatusForPOS " + SCXmlUtil.getString(inDoc));
		Document outputDocDate = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MANAGE_SERVER_STATUS_POS, inDoc);
		log.info("Output from manageServerStatusForPOS " + SCXmlUtil.getString(outputDocDate));
		return outputDocDate;
	}
	
	
	//Activate and Deactivate the profiles based on the input passed
	// PRE CORP - POD2
	/*
	 * <ManageInitialCommonCode Action="Manage"
	 * CommonCodeType="DATASYNC_PROFLE_FULL" > <ProfileList> <Profile
	 * Name="P_POD_MIGRATION" Status="ACTIVE"/> <Profile
	 * Name="P_CONFIGURATION_D" Status="ACTIVE"/> <Profile
	 * Name="P_INITIAL_ISS_D" Status="ACTIVE"/> <Profile Name="ALL_OTHERS"
	 * Status="INACTIVE"/> </ProfileList> </ManageInitialCommonCode>
	 */

	// POST CORP POD2
	/*
	 * <ManageInitialCommonCode Action="Manage"
	 * CommonCodeType="DATASYNC_PROFLE_FULL" > <ProfileList> <Profile
	 * Name="P_POD_MIGRATION" Status="INACTIVE"/> <Profile Name="ALL_OTHERS"
	 * Status="ACTIVE"/> </ProfileList> </ManageInitialCommonCode>
	 */
	private Document updatePodProfilesStatus(YFSEnvironment env, Document inDoc) throws Exception {
		log.info("Input to ManageInitialCommonCode " + SCXmlUtil.getString(inDoc));
		Document outputDocDate = KohlsCommonUtil.invokeService(env, KohlsPOCConstant.SERVICE_MANAGE_FULL_SYNC_COMMCODES,
				inDoc);
		log.info("Output from ManageInitialCommonCode " + SCXmlUtil.getString(outputDocDate));
		return outputDocDate;
	}
	
	
	// Get the server status on pod2
	//<ServerStatus ServerIp="isx9916h.st.ad.kohls.com"  StoreID="9916"/>	
	private Document getServerStatus(YFSEnvironment env, Document inDoc) throws Exception{
		log.info("Input to getServerStatusForPOS " + SCXmlUtil.getString(inDoc));
		Document statusOutDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SERVER_STATUS_POS,
				inDoc);
		log.info("Output from getServerStatusForPOS " + SCXmlUtil.getString(statusOutDoc));
		return statusOutDoc;
	}
}
