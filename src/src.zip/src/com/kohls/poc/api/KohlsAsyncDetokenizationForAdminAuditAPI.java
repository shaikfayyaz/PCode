package com.kohls.poc.api;

import java.util.Properties;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCInvokeDataSecurityPlatform;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsAsyncDetokenizationForAdminAuditAPI extends KOHLSBaseApi {

	/**
	 * This custom API is used to invoke createAsyncRequest API. The service
	 * name which is to be passed in the input of createAsyncRequest api is
	 * passed as argument to this custom api.
	 * 
	 */

	String sServiceName = "";
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory
				.instance(KohlsAsyncDetokenizationForAdminAuditAPI.class
						.getName());
	}
	private KohlsPoCInvokeDataSecurityPlatform invokeDataSecurity = new KohlsPoCInvokeDataSecurityPlatform();
	private KohlsReprocessRequestUtil requestUtilObj = new KohlsReprocessRequestUtil();
	private Properties props = null;
	/**
	 * sHostXC to save host details.
	 */
	private String sHostXC = null;
	/**
	 * dataElement to save dataElement value.
	 */
	private String dataElement = null;
	/**
	 * policyUser is to save userName.
	 */
	private String policyUser = null;

	public Document decryptyXml(YFSEnvironment env, Document inXml)
			throws Exception {
		logger.beginTimer("KohlsAsyncDetokenizationForAdminAuditAPI.encryptDecryptXML");
		
		
		if(logger.isDebugEnabled())
			logger.debug("Input XML to KohlsAsyncDetokenizationForAdminAuditAPI.decryptyXML is: "
				+ XMLUtil.getXMLString(inXml));

		String attribute = null;
		String attributePart1 = null;
		String attributePart2 = null;
		String[] delimitedSlash = null;
		String conversionType = null;
		String cryptingAttribute = null;
		String xPath = null;
		String attributeNo = null;
		/*
		 * Map<String, String> attributesDataMap = new HashMap<String,
		 * String>(); Element rootElement = inXml.getDocumentElement();
		 */
		int noOfAttributes = Integer.valueOf(this.props
				.getProperty(KohlsPOCConstant.NoOfAttributes));
		/*
		 * sHostXC = new String("nlg00601.tst.kohls.com:15911"); policyUser =
		 * new String("shdev");
		 */
		sHostXC = this
				.getPropertyValue(KohlsPOCConstant.PROTEGRITY_SERVER_HOST);
		policyUser = this.getPropertyValue(KohlsPOCConstant.POLICY_USER);
		logger.debug("The PROTEGRITY_SERVER_HOST is : " + sHostXC);
		logger.debug("The POLICY_USER is : " + policyUser);

		/*
		 * sHostXC = new String("localhost:15910"); policyUser = new
		 * String("shdev");
		 */
		logger.debug("The noOfAttributes value is : " + noOfAttributes);

		for (int m = 0; m < noOfAttributes; m++) {

			attributeNo = "Attribute" + (m + 1);
			logger.debug("The attribute No is : " + attributeNo);
			attributePart1 = this.props.getProperty(attributeNo + "_1");
			attributePart2 = this.props.getProperty(attributeNo + "_2");
			if (attributePart2 == null) {
				attributePart2 = " ";
			}
			// logger.debug("The attribute value is : " + attributePart1);
			attribute = attributePart1.concat(attributePart2).trim();
			logger.debug("The attribute to be encrypted is : " + attributePart2);
			delimitedSlash = attribute.split(KohlsPOCConstant.DelimitedSlash);
			logger.debug("the attribute is " + attribute);

			conversionType = delimitedSlash[0];
			logger.debug("the conversionType is " + conversionType);

			xPath = delimitedSlash[2];
			logger.debug("the xPath is " + xPath);

			cryptingAttribute = delimitedSlash[3];
			logger.debug("the cryptingAtribute is " + cryptingAttribute);

			dataElement = delimitedSlash[1];
			logger.debug("the dataElement is " + dataElement);

			if (!YFCCommon.isVoid(cryptingAttribute)) {
				// invokeDataSecurity.run(sHostXC, dataElement, policyUser);
				searchAndReplaceByGenericXPath(env, inXml, conversionType,
						cryptingAttribute, dataElement, xPath);

			}

		}
		
		if(logger.isDebugEnabled())
			logger.debug("Output XML from KohlsAsyncDetokenizationForAdminAuditAPI.encryptDecryptXML is: "
					+ XMLUtil.getXMLString(inXml));
		logger.endTimer("KohlsAsyncDetokenizationForAdminAuditAPI.encryptDecryptXML");
		return inXml;

	}

	public Document searchAndReplaceByGenericXPath(YFSEnvironment env,
			Document inDoc, String conversionType, String cryptingAttribute,
			String dataElement, String xPath) throws Exception {

		logger.beginTimer("KohlsAsyncDetokenizationForAdminAuditAPI.searchAndReplaceByGenericXPath");
		String cryptingAttributeValue = null;
		Element inElem = inDoc.getDocumentElement();
		
		
		if(logger.isDebugEnabled())
			logger.debug("the input to the API is "
					+ XMLUtil.getElementXMLString(inElem));
		sServiceName = this.props.getProperty(KohlsPOCConstant.SERVICE_NAME);
		logger.debug("sServiceName--> " + sServiceName);
		
		// Load the Collections for the first time call
//      if (YFCCommon.isVoid(requestUtilObj.propsFromCommonCode)) {
            requestUtilObj.loadPropsFromCommonCode(env,
                    KohlsPOCConstant.COMMON_CODE_FOR_REPROCESS, sServiceName);
            logger.debug("commonCodeProperties after loading ::"
                    + requestUtilObj.propsFromCommonCode);
//      }
		String strErrCount = null;
		Element baseElement = null;
		String name;
		String strVoidDuring ="";
		Boolean boolVoidDuring = false;
		Element eleAdminAudit = (Element) XPathUtil.getNode(
				inDoc.getDocumentElement(),
				"/InvoiceDetail/InvoiceHeader/AdminAuditList/AdminAudit");
		String adminAuditKey = XPathUtil
				.getString(inDoc.getDocumentElement(),
						"/InvoiceDetail/InvoiceHeader/AdminAuditList/AdminAudit/@AdminAuditKey");
		String procedureId = XPathUtil
				.getString(inDoc.getDocumentElement(),
						"/InvoiceDetail/InvoiceHeader/AdminAuditList/AdminAudit/@ProcedureID");
		Element couponEle = null;
		Element eleReprocessReq = requestUtilObj.getReprocessRecordFromDB(env, sServiceName,adminAuditKey);
		try {
			logger.debug("In the try block--->");
			NodeList baseElementList = ((NodeList) XPathUtil.getNodeList(
					inDoc.getDocumentElement(), xPath));
			for (int i = 0; i < baseElementList.getLength(); i++) {
				couponEle = (Element) baseElementList.item(i);
				name = couponEle.getAttribute("Name");
				if (name != null && name.equalsIgnoreCase("CouponNumber")) {
					break;
				}
				else if (name != null && name.equalsIgnoreCase("VoidDuring")) {
					strVoidDuring = couponEle.getAttribute("Value");
					if (strVoidDuring != null && strVoidDuring.equalsIgnoreCase("Y")) {
					         	boolVoidDuring = true;
							}
				}
			}
			for (int i = 0; i < baseElementList.getLength(); i++) {
				baseElement = (Element) baseElementList.item(i);
				
				
				if(logger.isDebugEnabled())
					logger.debug("the base element is "
							+ XMLUtil.getElementXMLString(baseElement));
				name = baseElement.getAttribute("Name");
				cryptingAttributeValue = baseElement
						.getAttribute(cryptingAttribute);
				logger.debug("the crypting attribute Value is "
						+ cryptingAttributeValue);
				// Load the Collections for the first time call
				if (!YFCCommon.isVoid(requestUtilObj.propsFromCommonCode)) {
					requestUtilObj.loadPropsFromCommonCode(env,
							KohlsPOCConstant.COMMON_CODE_FOR_REPROCESS, sServiceName);
					logger.debug("commonCodeProperties after loading ::"
							+ requestUtilObj.propsFromCommonCode);
				}
				if (name != null && name.equalsIgnoreCase("ExtnIsDetokenized")) {
					if (cryptingAttributeValue != null
							&& cryptingAttributeValue.equalsIgnoreCase("N")&& !boolVoidDuring) {
						// initializing the crypt
						invokeDataSecurity
								.run(sHostXC, policyUser);

						logger.debug("conversion type :: " + conversionType);
						String strDetokenize = invokeDataSecurity
								.returnDecryptedValueForDetokenization(couponEle
										.getAttribute(cryptingAttribute), dataElement);
						logger.debug("the value after decrypting is "
								+ strDetokenize);
						setCryptedValues(env, inDoc, strDetokenize, couponEle,
								cryptingAttribute, baseElement, adminAuditKey,
								procedureId);
						// Closing the Protegrity server session
						invokeDataSecurity.closeSession();
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			YFSException es = new YFSException();
			if (e.getClass().getName()
					.equalsIgnoreCase("com.protegrity.common.XCException")) {
				logger.debug("Setting the YFSException");
				es.setErrorCode("Protegrity Server Down");
				es.setErrorDescription("Unable to complete request (Protegrity), to Encrypt PII Data");
			}
			int maxErrCount = Integer.parseInt(requestUtilObj.propsFromCommonCode
					.get(sServiceName + ".MaxErrorCount"));
			logger.debug("sMaxErrorCount" + maxErrCount);
			if (!YFCCommon.isVoid(eleReprocessReq)) {
				strErrCount = requestUtilObj
						.getErrorCount(eleReprocessReq);
			}
			logger.debug("strErrCount is null or not-->" + strErrCount);
//			String version = this.getPropertyValue("VERSION");
//			if(YFCCommon.isVoid(version)){
//				version = "";
//			}
			String version = "";
			logger.debug("Version ::"+version);
			if (YFCCommon.isVoid(strErrCount)) {
				logger.debug("Inside If strErrCount is 0");
				logger.debug("Service Name :: " + sServiceName);
				strErrCount = "0";
				requestUtilObj.createReprocessRequest(env,sServiceName,
						inDoc);
				eleAdminAudit.setAttribute("ExtnMaxErrorCount", strErrCount);
			} else {
				logger.debug("strErrCount-->" + Integer.parseInt(strErrCount));
				if (Integer.parseInt(strErrCount) < maxErrCount) {
					logger.debug("Inside MaxErrorCount less than 5");
					eleAdminAudit
							.setAttribute("ExtnMaxErrorCount", strErrCount);
					if(Integer.parseInt(strErrCount)== (maxErrCount-1)){
						eleAdminAudit.setAttribute("ExtnMaxErrorCount",
								strErrCount);
						setDefaultValues(env, inDoc, couponEle, cryptingAttribute,
								baseElement);
					}
				}
				logger.debug("Throwing exception");
				throw e;
			}
		}
		logger.endTimer("KohlsAsyncDetokenizationForAdminAuditAPI.searchAndReplaceByGenericXPath");
		return inDoc;
	}




	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.yantra.interop.japi.YIFCustomApi#setProperties(java.util.Properties)
	 */
	public void setProperties(Properties prop) throws Exception {
		props = prop;
	}

	public static String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		// customer_overrides.properties does not return any value
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}

		return propValue;

	}

	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void setCryptedValues(YFSEnvironment env,Document inDoc, String strDetokenize,
			Element couponEle, String cryptingAttribute, Element baseElement,
			String adminAuditKey, String procedureId) throws DOMException {
		logger.beginTimer("KohlsAsyncDetokenizationForAdminAuditAPI.setCryptedValues");
		logger.debug("KohlsAsyncDetokenizationForAdminAuditAPI.setCryptedValues strDetokenize::"
				+ strDetokenize);
		String extnIsDetokenized;
		if (!YFCCommon.isVoid(strDetokenize)) {
			couponEle.setAttribute(cryptingAttribute, strDetokenize);
			baseElement.setAttribute(cryptingAttribute, "Y");
			extnIsDetokenized = "Y";
		} else {
			baseElement.setAttribute(cryptingAttribute, "N");
			extnIsDetokenized = "N";
		}
		invokeManageAdminAuditApi(env, strDetokenize, adminAuditKey,
				procedureId, extnIsDetokenized);
		try {
			KOHLSBaseApi.invokeService(env, "KohlsPoCDetokeniseAdminAuditToSH", inDoc);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Exception while invoking the service");
		}
		logger.endTimer("KohlsAsyncDetokenizationForAdminAuditAPI.setCryptedValues");
	}

	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void invokeManageAdminAuditApi(YFSEnvironment env,
			String strDetokenize, String adminAuditKey, String procedureId,
			String extnIsDetokenized) throws DOMException {
		logger.beginTimer("KohlsAsyncDetokenizationForAdminAuditAPI.invokeManageAdminAuditApi");
		Document docAdminAuditApiInput = YFCDocument.createDocument(
				KohlsPOCConstant.ELE_ADMIN_AUDIT).getDocument();
		Element eleAdminAudit = docAdminAuditApiInput.getDocumentElement();
		eleAdminAudit.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,
				procedureId);
		eleAdminAudit.setAttribute(KohlsPOCConstant.ATTR_ADMIN_AUDIT_KEY,
				adminAuditKey);
		Element eleAdditionalDataList = XMLUtil.createChild(eleAdminAudit,
				"AdditionalDataList");
		Element eleAdditionalData = XMLUtil.createChild(eleAdditionalDataList,
				"AdditionalData");
		eleAdditionalData.setAttribute("Name", "CouponNumber");
		eleAdditionalData.setAttribute("Value", strDetokenize);
		Element eleAdditionalData1 = XMLUtil.createChild(eleAdditionalDataList,
				"AdditionalData");
		eleAdditionalData1.setAttribute("Name", "ExtnIsDetokenized");
		eleAdditionalData1.setAttribute("Value", extnIsDetokenized);
		
		
		if(logger.isDebugEnabled())
			logger.debug("manageAdminAuditForPOS API input is: \n"
					+ XMLUtil.getXMLString(docAdminAuditApiInput));
		// Call getAccountListForPOS API
		Document docAdminAuditApiOutput = null;
		try {
			docAdminAuditApiOutput = KOHLSBaseApi.invokeAPI(env,
					"manageAdminAuditForPOS", docAdminAuditApiInput);
		} catch (Exception e) {
			logger.debug("Exception while invoking ManageAdminAuditAPI \n" + e);
		}
		
		if(logger.isDebugEnabled())
			logger.debug("manageAdminAuditForPOS API output is: \n"
					+ XMLUtil.getXMLString(docAdminAuditApiOutput));
		
		logger.endTimer("KohlsAsyncDetokenizationForAdminAuditAPI.invokeManageAdminAuditApi");
	}

	/**
	 * @param element
	 * @param attributesDataMap
	 * @param dataElement
	 * @param childNode
	 * @param encryptedVal
	 * @throws DOMException
	 */
	private void setDefaultValues(YFSEnvironment env,Document inDoc, Element couponEle, String cryptingAttribute,
			Element baseElement) throws DOMException {
		logger.beginTimer("KohlsAsyncDetokenizationForAdminAuditAPI.setCryptedValues");
		couponEle.setAttribute(cryptingAttribute, "");
		baseElement.setAttribute(cryptingAttribute, "N");
		try {
			KOHLSBaseApi.invokeService(env, "KohlsPoCDetokeniseAdminAuditToSH", inDoc);
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Exception while invoking the service");
		}
		logger.endTimer("KohlsAsyncDetokenizationForAdminAuditAPI.setCryptedValues");
	}

	public void throwError(YFSEnvironment env, Document inXML) {
		throw new YFSException(KohlsXMLUtil.getXMLString(inXML),
				"Protegrity Server Down",
				"Unable to complete request (Protegrity), to Encrypt PII Data");
	}

	public Document removeErrorCount(YFSEnvironment env, Document inXML) throws Exception {
		logger.debug("AdminAudit RemoveErrorCount - Start");
		Element eleAdminAudit = (Element) XPathUtil.getNode(
				inXML.getDocumentElement(),
				"/InvoiceDetail/InvoiceHeader/AdminAuditList/AdminAudit");
		if (!YFCCommon.isVoid(eleAdminAudit.getAttribute("ExtnMaxErrorCount"))) {
			eleAdminAudit.removeAttribute("ExtnMaxErrorCount");
		}	
		
		if(logger.isDebugEnabled()){
			logger.debug("inXML after removing errorcount ::"+XMLUtil.getXMLString(inXML));
			logger.debug("AdminAudit RemoveErrorCount - End");
		}
		return inXML;
	}
	
}
