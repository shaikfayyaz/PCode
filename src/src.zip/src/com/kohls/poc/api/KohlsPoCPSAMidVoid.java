
package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCPSAMidVoid {

	String strNoUPCMsg="No UPC Found";
	
	private static final YFCLogCategory loggerForPSAMidvoid = YFCLogCategory
			.instance(KohlsPoCPSAMidVoid.class.getName());

/*PSA DataCollect is triggered on on_success of change order.
PostVoid for EE and Sales is triggered on on_cancel of change order.
This code should be invoked after conditional checks of PSA mid void
at on_cancel of change order */
	

	/**
	 * This method prepares a xml document to be send to Tibco when a mid void 
	 * is performed on a PSA transaction
	 * Author Kohls
	 * @param env
	 * @param InputDoc
	 * @return InputDoc
	 * @exception Exception
	 * 
	 */
		
public Document PSAMidVoid(YFSEnvironment env , Document InputDoc)
{
		Document docKohlsSalesForPSA = null;
		Document Outputdoc = null;
		String strOrderInvKey = null;
	try
	{
		loggerForPSAMidvoid.beginTimer("PSAMidVoid --- Begin ");
		String strOHKey = InputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		
		Document docApiInput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
		Element eleRoot = docApiInput.getDocumentElement();
		eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("API input to getStoredData is ::"+XMLUtil.getXMLString(docApiInput));
		
		loggerForPSAMidvoid.debug("Invoking getStoredData ");
		docKohlsSalesForPSA = getStoredData(env, docApiInput);
		
		NodeList ndlChargeTransDet = XPathUtil.getNodeList(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/PSAData/Order/ChargeTransactionDetails/ChargeTransactionDetail");
		
		NodeList ndlSaleChargeTransDet = XPathUtil.getNodeList(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/Order/ChargeTransactionDetails/ChargeTransactionDetail");
		
		if (YFCCommon.isVoid(ndlChargeTransDet.item(0)))
		{
			strOrderInvKey = getInvoiceKeyOnElement(ndlSaleChargeTransDet);
			
		}
		else
		{
			strOrderInvKey = getInvoiceKeyOnElement(ndlChargeTransDet);
		}
		
		// Preparing API Input for API Call
		/* Added for Fix of PR-31 Defect#4244 Start */
		if(!YFCCommon.isVoid(strOHKey)){
		loggerForPSAMidvoid.debug("PSA Order Header Key Value ::"+strOHKey);
		Document docInput = YFCDocument.createDocument("GetOrderInvoiceDetails").getDocument();
		Element eledocInputRoot = docInput.getDocumentElement();
		
		if(!YFCCommon.isVoid(strOrderInvKey)){
		eledocInputRoot.setAttribute("InvoiceKey",strOrderInvKey);
				
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("API Input is ::"+XMLUtil.getXMLString(docInput));
		
		Document docOrderInvDetails = KOHLSBaseApi.invokeService(env, "GetOrderInvDetailsForMidVoid",docInput);
			loggerForPSAMidvoid.debug("Invoking AppendOrderLines method");
			Outputdoc = AppendOrderlines(docKohlsSalesForPSA,docOrderInvDetails);
		}
		else {
			Document docPOSInvoice = XMLUtil.createDocument("InvoiceDetail");
			Element eleInvoiceDetail = docPOSInvoice.getDocumentElement();
			Element eleInvoiceHeader = XMLUtil.createChild(eleInvoiceDetail,"InvoiceHeader");
			eleInvoiceHeader.setAttribute("InvoiceNo", "");
			eleInvoiceHeader.setAttribute("InvoiceKey", "");
			if(loggerForPSAMidvoid.isDebugEnabled()){
			loggerForPSAMidvoid.debug("docKohlsSalesForPSA XML is ::"+XMLUtil.getXMLString(docKohlsSalesForPSA));
			}
			Element eleOrder = (Element) XPathUtil.getNode(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/Order");
			eleInvoiceHeader.setAttribute("DateInvoiced", XMLUtil.getAttribute(eleOrder, "OrderDate"));
			eleInvoiceHeader.setAttribute("InvoiceType", "ORDER");
			Element eleOverallTotals = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELE_OVERALLTOTALS);
			eleInvoiceHeader.setAttribute("TotalAmount", eleOverallTotals.getAttribute("GrandTotal"));
			
			XMLUtil.importElement(eleInvoiceHeader, eleOrder);
			//loggerForPSAMidvoid.debug("eleInvoiceHeader XML is ::"+XMLUtil.getElementXMLString(eleInvoiceHeader));
			//loggerForPSAMidvoid.debug("docPOSInvoice XML is ::"+XMLUtil.getXMLString(docPOSInvoice));
			if(loggerForPSAMidvoid.isDebugEnabled()){			
			loggerForPSAMidvoid.debug("Invoking Sales AppendOrderLines method");
			}	
			Outputdoc = AppendSalesOrderlines(docKohlsSalesForPSA,docPOSInvoice);
		}
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("XML Returned by AppendOrderlines method :::"+XMLUtil.getXMLString(Outputdoc));
		
		Element elePsaOrder = (Element) XPathUtil.getNode(docKohlsSalesForPSA.getDocumentElement(), "/KOHLSSalesForPsa/PSAData/Order");
		
		if(YFCCommon.isVoid(elePsaOrder))
		{		
			
				loggerForPSAMidvoid.debug("Inside Receipted Void Flow");
				Outputdoc = updatePSAMidVoidDocument(Outputdoc);
			
		}
		
		
		loggerForPSAMidvoid.debug("Invoking updateUPCCode method");
		
		Outputdoc = updateUPCCode(env,Outputdoc);
		}
		else{
			loggerForPSAMidvoid.debug("PSA Mid void Order Header Key is blank ::"+strOrderInvKey);
			Outputdoc = YFCDocument.createDocument("Order").getDocument();
			Element eleOutputdoc = Outputdoc.getDocumentElement();			
			eleOutputdoc.setAttribute("Reason","Invalid Order");
		}
		/* Added for Fix of PR-31 Defect#4244 End */
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("Final XML is ::"+XMLUtil.getXMLString(Outputdoc));
		
		loggerForPSAMidvoid.beginTimer("PSAMidVoid --- End ");
	}
	catch(Exception e) {e.printStackTrace(); }
	return Outputdoc;
}


/*	This Method makes an API call to fetch clob objects of sale and psa  
 * 	orders and parses them into XML format
 */
public Document getStoredData(YFSEnvironment env , Document docInput)
{
	Document outputDoc = null;
	try
	{
		loggerForPSAMidvoid.beginTimer("FetchKohlsSalesForPSA --- Begin ");
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("API Input to GetKohlsSalesDetails :::"+XMLUtil.getXMLString(docInput));
		
		// API call to fetch data from db
		outputDoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInput);
		
		Element eleRootElement = outputDoc.getDocumentElement();
		
		// Fetching and parsing clob into string objects
		String strSalesClob =eleRootElement.getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);
		
		loggerForPSAMidvoid.debug("Clob Object for sales is :::"+strSalesClob);
		
		 String strPSAClob = eleRootElement.getAttribute("PSAData");
		 
		 loggerForPSAMidvoid.debug("Clob Object for PSA is :::"+strPSAClob);
		 
		if (!strSalesClob.isEmpty()) {
			Document docClobData = XMLUtil.getDocument(strSalesClob);
			eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA,KohlsPOCConstant.BLANK);
			Element eleNewClob = docClobData.getDocumentElement();
			XMLUtil.importElement(eleRootElement, eleNewClob);
			}
		
		if(!strPSAClob.isEmpty()) {
			Document docClobData = XMLUtil.getDocument(strPSAClob);
			eleRootElement.setAttribute("PSAData",KohlsPOCConstant.BLANK);
			Element elePSAData = XMLUtil.createChild(eleRootElement, "PSAData");
			Element eleNewClob = docClobData.getDocumentElement();
			XMLUtil.importElement(elePSAData, eleNewClob);
			
			
			if(loggerForPSAMidvoid.isDebugEnabled())
				loggerForPSAMidvoid.debug("After Appending :::"+ XMLUtil.getElementXMLString(elePSAData));
		}
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("After updated ; Document output :::"+ XMLUtil.getXMLString(outputDoc));
		
		loggerForPSAMidvoid.endTimer("FetchKohlsSalesForPSA --- End ");
		
	}
	catch(Exception e){ e.printStackTrace();}
	return outputDoc;
}


public Document AppendOrderlines(Document docSalesAndPsa,Document docInvoice)
{
	
	
	try
	{
		
		loggerForPSAMidvoid.debug("Inside Append OrderLines Method -- Begin ");
		
		Element eleSaleOrder = (Element) XPathUtil.getNode(docSalesAndPsa, KohlsPOCConstant.X_KOHLS_SALES_ORDER);
		//PR-943 changes start
		Element elePSADataSaleOrder = (Element) XPathUtil.getNode(docSalesAndPsa, KohlsPOCConstant.KOHLS_PSADATA_ORDER);
		//PR-943 changes end
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("Sales Element is ::"+XMLUtil.getElementXMLString(eleSaleOrder));
		
		
		String strSaleSellerOrgCode = eleSaleOrder.getAttribute("SellerOrganizationCode");
		String strSaleTerminalId = eleSaleOrder.getAttribute("TerminalID");
		
		//PR-943 changes start
		//String strSalePosSeqNo = eleSaleOrder.getAttribute("PosSequenceNo");
		String strSalePosSeqNo= null;
		if(!XMLUtil.isVoid(elePSADataSaleOrder)){
			strSalePosSeqNo = elePSADataSaleOrder.getAttribute("PosSequenceNo");
		}else{
			strSalePosSeqNo = eleSaleOrder.getAttribute("PosSequenceNo");
		}
		//PR-943 changes End
		String strSaleOrderDate = eleSaleOrder.getAttribute("OrderDate");
		//Start PR-626 fix
		String strPSASellerOrgCode = eleSaleOrder.getAttribute("TransactionNo");
		if(!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
		// Extracting Seller Organization code from the Updated Transaction Number
		strPSASellerOrgCode = strPSASellerOrgCode.substring(12, 16);
		
		loggerForPSAMidvoid.debug("PSA seller Organization code is:::"+strPSASellerOrgCode);
		}
		// End PR-626 fix
		
		
		

		NodeList ndlAwards = XPathUtil.getNodeList(docSalesAndPsa,KohlsPOCConstant.X_KOHLS_SALES_AWARD);
		 
		NodeList ndlPsaAwards = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OrderLines/OrderLine/Awards/Award");
		
		// Removing SalesHubData Clob object from Sales award
		
		 if (ndlAwards!=null){
			 for (int c=0;c<ndlAwards.getLength();c++){
				 Element eleAward=(Element)ndlAwards.item(c);
		
				 
				 Element eleExtn=XMLUtil.getChildElement(eleAward, KohlsPOCConstant.A_EXTN);
				 
				 
				 if(!YFCCommon.isVoid(eleExtn)){
					
					 String strExtnSaleHubData=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
					 
					 if(!YFCCommon.isVoid(strExtnSaleHubData)){
						
						 Document docSalesHubData=XMLUtil.getDocument(strExtnSaleHubData);
						 eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.BLANK);
						 Element eleDataSalesHub=docSalesHubData.getDocumentElement();
						
						 XMLUtil.importElement(eleExtn, eleDataSalesHub);
						 
					 }
				 }
			 }
		 } 
		 
		
		
		 // Removing SalesHubData Clob object from PSA award -- : Refactor Later
		 
		 
		 if (ndlPsaAwards!=null){
			 for (int c=0;c<ndlPsaAwards.getLength();c++){
				 Element eleAward=(Element)ndlPsaAwards.item(c);
		
				 //System.out.println("Inside PSA salesHubData Clob fix");
				 
				 Element eleExtn=XMLUtil.getChildElement(eleAward, KohlsPOCConstant.A_EXTN);
				 
				 
				 if(!YFCCommon.isVoid(eleExtn)){
					
					 //System.out.println("Extn element containing PSA salesHubData Clob exist");
					 String strExtnSaleHubData=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
					 
					 if(!YFCCommon.isVoid(strExtnSaleHubData)){
						
						 Document docSalesHubData=XMLUtil.getDocument(strExtnSaleHubData);
						 eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.BLANK);
						 Element eleDataSalesHub=docSalesHubData.getDocumentElement();
						
						 XMLUtil.importElement(eleExtn, eleDataSalesHub);
						 
						 //System.out.println("After appending"+XMLUtil.getElementXMLString(eleExtn));
						 
					 }
				 }
			 }
		 } 
		 
		 
		 
		 Element eleSaleOrderlines = (Element) XPathUtil.getNode(docSalesAndPsa,"/KOHLSSalesForPsa/Order/OrderLines");
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("Sale Orderlines element is :::"+XMLUtil.getElementXMLString(eleSaleOrderlines));
		
		NodeList ndlSaleOrderline = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/Order/OrderLines/OrderLine");
		
		
		
		for(int b=0;b<ndlSaleOrderline.getLength();b++)
		{
			
			Element eleCurrentElement = (Element)ndlSaleOrderline.item(b);
			// Fix for 2969 -- begin
			
			loggerForPSAMidvoid.debug("Fix for 2969 in PSA MID VOiD - Begin");
			Element eleCurrentExtn = XMLUtil.getChildElement(eleCurrentElement,"Extn");
			
			
			if(loggerForPSAMidvoid.isDebugEnabled())
				loggerForPSAMidvoid.debug("Current Extn Element is::"+XMLUtil.getElementXMLString(eleCurrentExtn));
			
			String strTaxInd = eleCurrentExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);
			
			strTaxInd = UpdateTaxIndType(strTaxInd);
			
			eleCurrentExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, strTaxInd);
			
			loggerForPSAMidvoid.debug("Fix for 2969 in PSA MID VOiD - End");
			
			// Fix for 2969 -- End
			
			XMLUtil.removeChild(eleSaleOrderlines,(Element) ndlSaleOrderline.item(b));
		
		}
		
		
		
		NodeList ndlPSAOrderline = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OrderLines/OrderLine");
		
		if(!YFCCommon.isVoid(ndlPSAOrderline.item(0)))
		{
		for(int i=0;i<ndlSaleOrderline.getLength();i++)
		{
			Element eleCurrentSaleOrderline = (Element) ndlSaleOrderline.item(i);
			eleSaleOrderlines.appendChild(eleCurrentSaleOrderline );
			eleSaleOrderlines.appendChild(ndlPSAOrderline.item(i));
		}
		}
		else 
		{
			for(int i=0;i<ndlSaleOrderline.getLength();i++)
			{
				Element eleCurrentSaleOrderline = (Element) ndlSaleOrderline.item(i);
				eleSaleOrderlines.appendChild(eleCurrentSaleOrderline );
			
			}
		}
		
		Element eleInvOrder = (Element) XPathUtil.getNode(docInvoice.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER);
		
		String strOrigPosSeqNo = eleInvOrder.getAttribute("PosSequenceNo");
		String strOrigOrderDate = eleInvOrder.getAttribute("OrderDate");
		String strOrigTerminalID = eleInvOrder.getAttribute("TerminalID");
		String strOrigSellerOrgCode = eleInvOrder.getAttribute("SellerOrganizationCode");
		
		Element eleInvExtn = (Element) XPathUtil.getNode(docInvoice.getDocumentElement(),KohlsPOCConstant.X_INV_EXTN);
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("Setting Sales Attributes at Extn level::"+XMLUtil.getElementXMLString(eleInvExtn));
		
		eleInvExtn.setAttribute("ExtnOrderDate",strOrigOrderDate);
		eleInvExtn.setAttribute("ExtnPosSequenceNo", strOrigPosSeqNo);
		eleInvExtn.setAttribute("ExtnSellerOrganisationCode",strOrigSellerOrgCode);
		eleInvExtn.setAttribute("ExtnTerminalID",strOrigTerminalID);
		eleInvExtn.setAttribute("ExtnShipNode",strOrigSellerOrgCode);
		//Start PR-626 fix
		eleInvOrder.setAttribute("SellerOrganizationCode", strPSASellerOrgCode);
		//End PR-626 fix
		eleInvOrder.setAttribute("TerminalID", strSaleTerminalId);
		eleInvOrder.setAttribute("PosSequenceNo", strSalePosSeqNo);
		eleInvOrder.setAttribute("OrderDate", strSaleOrderDate);
		
		
		
		docInvoice.adoptNode(eleSaleOrderlines);
		eleInvOrder.appendChild(eleSaleOrderlines);
		XMLUtil.createChild(eleInvOrder, "TaxDetailList");
		
		Integer noOfPromotions = eleInvOrder.getElementsByTagName("Promotion").getLength();
		loggerForPSAMidvoid.debug("No of Existing promotion element ::"+noOfPromotions);
		if(noOfPromotions.equals(0))
		{
			loggerForPSAMidvoid.debug("Creating Promotion child element ; Does not exist ");
			XMLUtil.createChild(eleInvOrder, "Promotions");
		}
		
		loggerForPSAMidvoid.debug("Invoking calculateTotalOrderLines ");
		
		docInvoice = calculateTotalOrderLines(docInvoice);
		
		loggerForPSAMidvoid.debug("Invoking ConsolidateTaxAndTotalAmt ");
		
		docInvoice = ConsolidateTaxAndTotalAmt(docSalesAndPsa,docInvoice);
		
		loggerForPSAMidvoid.debug("Invoking AppendPromotionAndTaxes ");
		
		docInvoice = AppendPromotionAndTaxes(docSalesAndPsa,docInvoice);
		
		loggerForPSAMidvoid.debug("Invoking setMessageType ");
		
		docInvoice = setMessageType(docInvoice);
		
		loggerForPSAMidvoid.debug("Invoking setExternalPayment ");
		docInvoice = setExternalPayment(docInvoice);
		
		
		loggerForPSAMidvoid.debug("Inside Append OrderLines Method -- End ");
		
	}
	catch(Exception e) {e.printStackTrace();}
	
	return docInvoice;
}

public Document AppendSalesOrderlines(Document docPOSSales,Document docInvoice)
{
	
	
	try
	{
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Inside Append Sales OrderLines Method -- Begin ");
		}
		Element eleSaleOrder = (Element) XPathUtil.getNode(docPOSSales, KohlsPOCConstant.X_KOHLS_SALES_ORDER);
		
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
			loggerForPSAMidvoid.debug("Sales Element is ::"+XMLUtil.getElementXMLString(eleSaleOrder));
		}
		
		String strSaleSellerOrgCode = eleSaleOrder.getAttribute("SellerOrganizationCode");
		String strSaleTerminalId = eleSaleOrder.getAttribute("TerminalID");
	
		String strSaleOrderDate = eleSaleOrder.getAttribute("OrderDate");
		
		//PR-943 changes start
		//String strSalePosSeqNo = eleSaleOrder.getAttribute("PosSequenceNo");
		String strSalePosSeqNo= null;
		Element elePSADataSaleOrder = (Element) XPathUtil.getNode(docPOSSales, KohlsPOCConstant.KOHLS_PSADATA_ORDER);
		if(!XMLUtil.isVoid(elePSADataSaleOrder)){
			strSalePosSeqNo = elePSADataSaleOrder.getAttribute("PosSequenceNo");
		}else{
			strSalePosSeqNo = eleSaleOrder.getAttribute("PosSequenceNo");
		}
				//PR-943 changes End
		
		//Start PR-626 fix
		String strPSASellerOrgCode = eleSaleOrder.getAttribute("TransactionNo");
		if(!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
		// Extracting Seller Organization code from the Updated Transaction Number
		strPSASellerOrgCode = strPSASellerOrgCode.substring(12, 16);
		
		}
		// End PR-626 fix
				
		NodeList ndlAwards = XPathUtil.getNodeList(docPOSSales,KohlsPOCConstant.X_KOHLS_SALES_AWARD);
		 
		//NodeList ndlPsaAwards = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OrderLines/OrderLine/Awards/Award");
		
		// Removing SalesHubData Clob object from Sales award
		
		 if (ndlAwards!=null){
			 for (int c=0;c<ndlAwards.getLength();c++){
				 Element eleAward=(Element)ndlAwards.item(c);
		
				 
				 Element eleExtn=XMLUtil.getChildElement(eleAward, KohlsPOCConstant.A_EXTN);
				 
				 
				 if(!YFCCommon.isVoid(eleExtn)){
					
					 String strExtnSaleHubData=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
					 
					 if(!YFCCommon.isVoid(strExtnSaleHubData)){
						
						 Document docSalesHubData=XMLUtil.getDocument(strExtnSaleHubData);
						 eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.BLANK);
						 Element eleDataSalesHub=docSalesHubData.getDocumentElement();
						
						 XMLUtil.importElement(eleExtn, eleDataSalesHub);
						 
					 }
				 }
			 }
		 } 
		 	
		
		 Element eleSaleOrderlines = (Element) XPathUtil.getNode(docPOSSales,"/KOHLSSalesForPsa/Order/OrderLines");
		
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
			loggerForPSAMidvoid.debug("Sale Orderlines element is :::"+XMLUtil.getElementXMLString(eleSaleOrderlines));
		}
		NodeList ndlSaleOrderline = XPathUtil.getNodeList(docPOSSales,"/KOHLSSalesForPsa/Order/OrderLines/OrderLine");
		
		
		
		for(int b=0;b<ndlSaleOrderline.getLength();b++)
		{
			
			Element eleCurrentElement = (Element)ndlSaleOrderline.item(b);
			// Fix for 2969 -- begin
			
			if(loggerForPSAMidvoid.isDebugEnabled()){
			loggerForPSAMidvoid.debug("Fix for 2969 in PSA MID VOiD - Begin");
			}
			Element eleCurrentExtn = XMLUtil.getChildElement(eleCurrentElement,"Extn");
			
			
			if(loggerForPSAMidvoid.isDebugEnabled()){
				loggerForPSAMidvoid.debug("Current Extn Element is::"+XMLUtil.getElementXMLString(eleCurrentExtn));
			}
			String strTaxInd = eleCurrentExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);
			
			strTaxInd = UpdateTaxIndType(strTaxInd);
			
			eleCurrentExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, strTaxInd);
			
			if(loggerForPSAMidvoid.isDebugEnabled()){
			loggerForPSAMidvoid.debug("Fix for 2969 in PSA MID VOiD - End");
			}
			// Fix for 2969 -- End
			
			XMLUtil.removeChild(eleSaleOrderlines,(Element) ndlSaleOrderline.item(b));
		
		}
		
		
		
		NodeList ndlPSAOrderline = XPathUtil.getNodeList(docPOSSales,"/KOHLSSalesForPsa/PSAData/Order/OrderLines/OrderLine");
		
		if(!YFCCommon.isVoid(ndlPSAOrderline.item(0)))
		{
		for(int i=0;i<ndlSaleOrderline.getLength();i++)
		{
			Element eleCurrentSaleOrderline = (Element) ndlSaleOrderline.item(i);
			eleSaleOrderlines.appendChild(eleCurrentSaleOrderline );
			eleSaleOrderlines.appendChild(ndlPSAOrderline.item(i));
		}
		}
		else 
		{
			for(int i=0;i<ndlSaleOrderline.getLength();i++)
			{
				Element eleCurrentSaleOrderline = (Element) ndlSaleOrderline.item(i);
				eleSaleOrderlines.appendChild(eleCurrentSaleOrderline );
			
			}
		}
		
		Element eleOrder = (Element) XPathUtil.getNode(docPOSSales.getDocumentElement(), KohlsPOCConstant.X_KOHLS_SALES_ORDER);
		Element eleInvOrder = (Element) XPathUtil.getNode(docInvoice.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER);
    	Element eleInvoiceHeader = XMLUtil.getChildElement(docInvoice.getDocumentElement(), KohlsPOCConstant.ELE_INVOICE_HEADER);
				
		if(loggerForPSAMidvoid.isDebugEnabled()){
			loggerForPSAMidvoid.debug("Order Element eleOrder is ::"+XMLUtil.getElementXMLString(eleOrder));
			loggerForPSAMidvoid.debug("Order Element eleInvOrder is ::"+XMLUtil.getElementXMLString(eleInvOrder));
		}
	
		String strOrigOrderDate = eleOrder.getAttribute("OrderDate");
		String strOrigSellerOrgCode = eleOrder.getAttribute("SellerOrganizationCode");
		String strOrderNo = eleOrder.getAttribute("OrderNo");
		String    strOriginalTerminalId = "";
		//Changes for CPE-10054 - start
		if(strOrderNo.length() == 23) {
		  strOriginalTerminalId = strOrderNo.substring(17,19);
		} else {
		  strOriginalTerminalId = strOrderNo.substring(11,13);
		}
		//Changes for CPE-10054 - end
		loggerForPSAMidvoid.debug("original terminal id is:::"+strOriginalTerminalId);
		
		Element eleInvExtn = XMLUtil.getChildElement(eleInvoiceHeader, KohlsPOCConstant.E_EXTN, true);
        Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN);
        if(loggerForPSAMidvoid.isDebugEnabled()){
            loggerForPSAMidvoid.debug("Setting Sales Attributes at Extn level::"+XMLUtil.getElementXMLString(eleInvExtn));
        }
        String strOrigPosSeqNo = eleOrderExtn.getAttribute("ExtnOrigPosSequenceNo");
        //String strOrigTerminalID = eleInvOrder.getAttribute("TerminalID");
		
		eleInvExtn.setAttribute("ExtnOrderDate",strOrigOrderDate);
		eleInvExtn.setAttribute("ExtnPosSequenceNo", strOrigPosSeqNo);
		eleInvExtn.setAttribute("ExtnSellerOrganisationCode",strOrigSellerOrgCode);
		eleInvExtn.setAttribute("ExtnTerminalID",strOriginalTerminalId);
		eleInvExtn.setAttribute("ExtnShipNode",strOrigSellerOrgCode);
		//Start PR-626 fix
		eleInvOrder.setAttribute("SellerOrganizationCode", strPSASellerOrgCode);
		//End PR-626 fix
		eleInvOrder.setAttribute("TerminalID", strSaleTerminalId);
		eleInvOrder.setAttribute("PosSequenceNo", strSalePosSeqNo);
		eleInvOrder.setAttribute("OrderDate", strSaleOrderDate);
		
		//docInvoice.adoptNode(eleSaleOrderlines);
		//eleInvOrder.appendChild(eleSaleOrderlines);
		XMLUtil.createChild(eleInvOrder, "TaxDetailList");
		
		/*Integer noOfPromotions = eleOrder.getElementsByTagName("Promotion").getLength();
		loggerForPSAMidvoid.debug("No of Existing promotion element ::"+noOfPromotions);
		if(noOfPromotions.equals(0))
		{
			loggerForPSAMidvoid.debug("Creating Promotion child element ; Does not exist ");
			XMLUtil.createChild(eleInvOrder, "Promotions");
		}*/
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Creating CollectionDetails child element with 0 lines ");
		}
	    Element eleCollectionDetails = XMLUtil.createChild(eleInvOrder, "CollectionDetails");
		eleCollectionDetails.setAttribute("TotalLines", "0");
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Invoking calculateTotalOrderLines ");
		}
		docInvoice = calculateTotalOrderLines(docInvoice);
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Invoking ConsolidateTaxAndTotalAmt ");
		}
		docInvoice = ConsolidateTaxAndTotalAmt(docPOSSales,docInvoice);
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Invoking AppendPromotionAndTaxes ");
		}
		docInvoice = AppendPromotionAndTaxes(docPOSSales,docInvoice);
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Invoking setMessageType ");
		}
		docInvoice = setMessageType(docInvoice);
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Invoking setExternalPayment ");
		}
		docInvoice = setExternalPayment(docInvoice);
		
		if(loggerForPSAMidvoid.isDebugEnabled()){
		loggerForPSAMidvoid.debug("Inside Append Sales OrderLines Method -- End ");
		}
	}
	catch(Exception e) {e.printStackTrace();}
	
	return docInvoice;
}
public Document AppendPromotionAndTaxes (Document docSalesAndPsa, Document docInvoice )
{
	try
	{
			loggerForPSAMidvoid.debug("Inside AppendPromotionAndTaxes Method -- Begin ");
			
			NodeList ndlSalesPromotion = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/Order/Promotions/Promotion");
		
			// Updating type code for Sale Promotions
			
			loggerForPSAMidvoid.debug("Setting Promotion type for sale");
			for(int a=0;a<ndlSalesPromotion.getLength();a++)
			{
				Element eleCurrentPromotion = (Element) ndlSalesPromotion.item(a);
				eleCurrentPromotion.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
			}
			
			
			NodeList ndlPSAPromotion = XPathUtil.getNodeList(docSalesAndPsa, "/KOHLSSalesForPsa/PSAData/Order/Promotions/Promotion");
			
			// Updating type code for PSA Promotions
			
			if(!YFCCommon.isVoid(ndlPSAPromotion)) {
			loggerForPSAMidvoid.debug("Setting Promotion type for PSA");
			for(int b=0;b<ndlPSAPromotion.getLength();b++)
			{
				Element eleCurrentPSAPromotion = (Element) ndlPSAPromotion.item(b);
				eleCurrentPSAPromotion.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.ATTR_PSA);
			}
					
		
		Element elePSAParentPromotion = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.X_INV_PROMOTIONS);
		
		
		
		
		for(int a=0;a<ndlSalesPromotion.getLength();a++)
		{
			docInvoice.adoptNode(ndlSalesPromotion.item(a));
			docInvoice.adoptNode(ndlPSAPromotion.item(a));
			XMLUtil.importElement(elePSAParentPromotion,(Element) ndlSalesPromotion.item(a));
			XMLUtil.importElement(elePSAParentPromotion,(Element) ndlPSAPromotion.item(a));
		}
		
			}
			else
			{
				Element elePSAParentPromotion = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.X_INV_PROMOTIONS);
				for(int a=0;a<ndlSalesPromotion.getLength();a++)
				{
					docInvoice.adoptNode(ndlSalesPromotion.item(a));
					//docInvoice.adoptNode(ndlPSAPromotion.item(a));
					XMLUtil.importElement(elePSAParentPromotion,(Element) ndlSalesPromotion.item(a));
					//XMLUtil.importElement(elePSAParentPromotion,(Element) ndlPSAPromotion.item(a));
				}
			}
		
		Element eleOrigSaleOrder = (Element) XPathUtil.getNode(docSalesAndPsa,KohlsPOCConstant.X_KOHLS_SALES_ORDER);
		
		Element eleOrigSaleOrderExtn = XMLUtil.getChildElement(eleOrigSaleOrder,KohlsPOCConstant.A_EXTN);
		
		 String strExtnTaxDetails=	eleOrigSaleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
		 Element eleTaxDetails = null;
		 if(!YFCCommon.isVoid(strExtnTaxDetails))
		 {
			 Document docExtnTaxDetails=XMLUtil.getDocument(strExtnTaxDetails);
			 eleOrigSaleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
			 eleTaxDetails = docExtnTaxDetails.getDocumentElement();
			 XMLUtil.importElement(eleOrigSaleOrder,eleTaxDetails);
		 }
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("Fixing Tax Clob Issue"+XMLUtil.getElementXMLString(eleOrigSaleOrder));
		 
		 NodeList ndlTaxDetail = XPathUtil.getNodeList(eleOrigSaleOrder,KohlsPOCConstant.X_KOHLS_SALES_TAX_DETAIL);
		 
		
		 loggerForPSAMidvoid.debug("Setting Tax indicator for Sales");
		 
		 // Updating Tax Indicator for Sales Tax
		 
		 if(!(YFCCommon.isVoid(ndlTaxDetail)))
				 {
			 		for(int c=0;c<ndlTaxDetail.getLength();c++)
			 		{
			 			Element eleCurrentTax = (Element) ndlTaxDetail.item(c);
			 			String strTaxInd = eleCurrentTax.getAttribute(KohlsPOCConstant.A_TAX_INDICATOR);
			 			strTaxInd = UpdateTaxIndType(strTaxInd);
			 			eleCurrentTax.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, strTaxInd);
			 			eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
			 		}
		
			 		}
		 
		 
		 
		 Element elePSATaxDetail = (Element) XPathUtil.getNode(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/Extn");
			
		 if(!YFCCommon.isVoid(elePSATaxDetail)) {
			//System.out.println("Tax Clob Element is ::"+XMLUtil.getElementXMLString(elePSATaxDetail));
			 String strExtnPSATaxDetails=	elePSATaxDetail.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
			 Element elePSATaxDetails = null;
			 if(!YFCCommon.isVoid(strExtnTaxDetails))
			 {
				 Document docExtnTaxDetails=XMLUtil.getDocument(strExtnPSATaxDetails);
				 elePSATaxDetail.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
				 elePSATaxDetails = docExtnTaxDetails.getDocumentElement();
				 XMLUtil.importElement(elePSATaxDetail,elePSATaxDetails);
				 
			 }
		 }
		 NodeList ndlPSATaxDetail = XPathUtil.getNodeList(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/Extn/TaxDetailList/TaxDetail");
		 
		 if(!YFCCommon.isVoid(ndlPSATaxDetail)) {
		 
		 loggerForPSAMidvoid.debug("Setting Tax Indicator for PSA");
		 
		 for(int d=0;d<ndlPSATaxDetail.getLength();d++)
		 {
			 Element eleCurrentTax = (Element) ndlPSATaxDetail.item(d);
			 eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.ATTR_PSA);
		}
		 
		 Element eleTaxDetailList = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.X_INV_TAX_DETAIL_LIST);
		 
		for(int c=0;c<ndlTaxDetail.getLength();c++)
		 {
			docInvoice.adoptNode(ndlTaxDetail.item(c));
			docInvoice.adoptNode(ndlPSATaxDetail.item(c));
			XMLUtil.importElement(eleTaxDetailList,(Element)ndlTaxDetail.item(c));
			XMLUtil.importElement(eleTaxDetailList,(Element)ndlPSATaxDetail.item(c));
			
		 }
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("After appending ::"+XMLUtil.getElementXMLString(eleTaxDetailList));
		 } 

		loggerForPSAMidvoid.debug("Inside AppendPromotionAndTaxes Method -- End ");
		 
	}
	catch(Exception e) {e.printStackTrace();}
	return docInvoice;
	
}

public String getInvoiceKeyOnElement (NodeList ndlInput)
{	
	String strKey = null;
	try
	{
		loggerForPSAMidvoid.debug("Inside getInvoiceKeyOnElement");
		
		for(int i=0;i<ndlInput.getLength();i++)
			{
				loggerForPSAMidvoid.debug("Inside iteration for nodelist");
				Element eleCurrent = (Element) ndlInput.item(i);
				
				if(loggerForPSAMidvoid.isDebugEnabled())
					loggerForPSAMidvoid.debug(XMLUtil.getElementXMLString(eleCurrent));
				String str = eleCurrent.getAttribute("OrderInvoiceKey");
				if(!YFCCommon.isStringVoid(str))
				{
					strKey = str;
					
				}
			}
		
		loggerForPSAMidvoid.debug("Inside getInvoiceKeyOnElement -- End");
	}	
	catch(Exception ex) { ex.printStackTrace(); }
	return strKey;
}

public Document calculateTotalOrderLines(Document docInput)
{
	
	try{
		
		loggerForPSAMidvoid.debug("Inside calculateTotalOrderLines Method -- Begin ");
		
		NodeList ndlOrderLine = ((NodeList) XPathUtil
				.getNodeList(docInput.getDocumentElement(),
						KohlsPOCConstant.X_INV_ORDERLINE));
		
		Integer totalNumberCount = ndlOrderLine.getLength();
		
		loggerForPSAMidvoid.debug("OrderLine count is ::"+totalNumberCount);
		
		String totalNumber = totalNumberCount.toString();
		
		Element eleOrderLines =(Element) XPathUtil.getNode(docInput.getDocumentElement(),KohlsPOCConstant.X_INV_ORDERLINES);
		
		eleOrderLines.setAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS,totalNumber);
							
		if(!(YFCCommon.isVoid(ndlOrderLine))){
			for(int i=0;i<totalNumberCount;i++)
			{
				Element eleOrderLine = (Element) ndlOrderLine.item(i);
				Integer count = i+1;
				String strCurrValue = count.toString();
					eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_LINE_SEQ_NO,strCurrValue);
					loggerForPSAMidvoid.debug("Setting Line Sequence Number :::" + strCurrValue);
						if(count%2 == 0)
					{
						eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.ATTR_PSA);
					}
					else
					{
						eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE,KohlsPOCConstant.SALE);
					}
									
		}
	
		}
		
		loggerForPSAMidvoid.debug("Inside calculateTotalOrderLines Method -- End ");
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	return docInput;
	}

public String UpdateTaxIndType(String strTaxInd)
{
	
	loggerForPSAMidvoid.debug("Inside UpdateTaxIndType -- begin");
	if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_1)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_A;}
	else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_2)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_B;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_3)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_C;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_4)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_D;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_5)) {strTaxInd = KohlsPOCConstant.ATTR_TAX_E;}
	else if(strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_6)){strTaxInd = KohlsPOCConstant.ATTR_TAX_F;}
	else	{strTaxInd = KohlsPOCConstant.CONST_HASH;}
	
	
	loggerForPSAMidvoid.debug("Tax indicator Returned"+strTaxInd);
	
	loggerForPSAMidvoid.debug("Inside UpdateTaxIndType -- End");
	
	return strTaxInd;
	
}

public Document ConsolidateTaxAndTotalAmt(Document docSalesAndPsa, Document docInvoice)
{
	
	try {
		
		
		loggerForPSAMidvoid.debug("Inside ConsolidateTaxAndTotalAmt Method -- Begin ");
		
		// Re-calculating Grand Tax Amount
		
		Element eleOrigSaleOvrTotal = (Element) XPathUtil.getNode(docSalesAndPsa,KohlsPOCConstant.X_KOHLS_SALES_OVERALL_TOTALS);
		String strSalesGrandTax = eleOrigSaleOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
		
		Element elePSAOvrTotal = (Element) XPathUtil.getNode(docSalesAndPsa,"/KOHLSSalesForPsa/PSAData/Order/OverallTotals");
		
		if(!YFCCommon.isVoid(elePSAOvrTotal))
			
		{
		
		String strPSAGrandTax = elePSAOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TAX);
		
		loggerForPSAMidvoid.debug("Sale and PSA Taxes are ::"+strSalesGrandTax+strPSAGrandTax);
		
		Float calculatedValue = Float.parseFloat(strPSAGrandTax) - Float.parseFloat(strSalesGrandTax);
		
	
		//rounding the values 06/23/016 - Start 
		strPSAGrandTax = String.format("%.2f", calculatedValue);
        //rounding the values 06/23/016 - End 
		
		elePSAOvrTotal.setAttribute(KohlsPOCConstant.ATTR_GRAND_TAX, strPSAGrandTax);
	
	
		// Re-calculating Total Amount
	
			String strTotalAmount = eleOrigSaleOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);
			
			Element elePSAInvHeader = (Element) XPathUtil.getNode(docInvoice,KohlsPOCConstant.XPATH_INVOICE_HEADER);
			
			String strPSATotalAmnt = elePSAOvrTotal.getAttribute(KohlsPOCConstant.ATTR_GRAND_TOTAL);
			
			loggerForPSAMidvoid.debug("Sale and PSA Taxes are ::"+strTotalAmount+strPSATotalAmnt);
			
			Float calculatedValueTotalAmnt = Float.parseFloat(strPSATotalAmnt) - Float.parseFloat(strTotalAmount);
			
			
			//rounding the values 06/23/016 - Start 
		    strPSATotalAmnt = String.format("%.2f", calculatedValueTotalAmnt);
            //rounding the values 06/23/016 - End 
			
			elePSAInvHeader.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, strPSATotalAmnt);
		
	
			loggerForPSAMidvoid.debug("Inside ConsolidateTaxAndTotalAmt Method -- End ");
		}		
			
	} 
	catch (Exception e)
	
	{e.printStackTrace();}
	
	
	return docInvoice;
}

public Document setMessageType(Document docInvoice)
{
	try
	{
		
		loggerForPSAMidvoid.debug("Inside setMessageType Method -- Begin ");
		Element eleOrder = (Element) XPathUtil.getNode(docInvoice, "/InvoiceDetail/InvoiceHeader/Order");
		Element eleInvDetails =	(Element) XPathUtil.getNode(docInvoice, "/InvoiceDetail");
		eleInvDetails.setAttribute("MessageType", "PSA_VoidDuring");
		eleInvDetails.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
		
		//Element eleOrderExtn = XMLUtil.createChild(eleOrder, "Extn");
		Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN, true);
		eleOrderExtn.setAttribute("ExtnIsVoidDuring","Y");
		
		loggerForPSAMidvoid.debug("Inside setMessageType Method -- End ");
	}
	catch(Exception e)
	{e.printStackTrace();
	}
	return docInvoice;
}

public Document updateUPCCode(YFSEnvironment env , Document docInvoice)
{
	try
	{
		loggerForPSAMidvoid.debug("Inside updateUPCCode Method -- Begin ");
		
		NodeList ndlOrderline = XPathUtil.getNodeList(docInvoice.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINE);
	
		for(int i=0;i<ndlOrderline.getLength();i++)
		{
		Element eleCurrentElement = (Element) ndlOrderline.item(i);
		//changes start for 6031
		if (YFCCommon.isVoid(eleCurrentElement.getAttribute(KohlsPOCConstant.A_GIFT_REG_ID))) {
			eleCurrentElement.setAttribute("GiftRegistryID", eleCurrentElement.getAttribute(KohlsPOCConstant.A_GIFT_REG_ID).trim());
		} 		
		//changes end for 6031
		Element eleItemLevel = XMLUtil.getChildElement(eleCurrentElement, KohlsPOCConstant.ELEM_ITEM);
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("Current Item is :::"+XMLUtil.getElementXMLString(eleItemLevel));
		
		Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
		Element eleItemInput = docGetItemListInput.getDocumentElement();
		String strItemId = eleItemLevel
				.getAttribute(KohlsPOCConstant.A_ITEM_ID);
		String strUPCCode= eleItemLevel
				.getAttribute(KohlsPOCConstant.A_UPC_CODE);
		eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemId);
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("API Input is ::"+XMLUtil.getXMLString(docGetItemListInput));
		
		Document docItemListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST, KohlsPOCConstant.API_GET_ITEM_LIST,docGetItemListInput);
		
		if(YFCCommon.isVoid(strUPCCode)|| strUPCCode.isEmpty() || strUPCCode == null) {
		
			String upc_code = KohlsPoCPnPUtil.getUpcCode(docItemListOutput);
			if(YFCCommon.isVoid(upc_code)|| upc_code.isEmpty() || upc_code == null)
			{
				upc_code=strNoUPCMsg;
			}
			eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, upc_code );
		}
		else {
			eleItemLevel.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
		}
			
		}
		
		loggerForPSAMidvoid.debug("Inside updateUPCCode Method -- End ");
		
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return docInvoice;
		
}


public Document checkAndInsertSalesData (YFSEnvironment env , Document docInput) 
 {
		Document docAPIOutput = null;
		Document docApiInputForGetOrderDet = null;
		Document docInsertAPIOutput = null;
		String strOHKey = null;
		try {
			loggerForPSAMidvoid
					.beginTimer(" --- checkAndInsertSalesData --- Begin ");

			strOHKey = docInput.getDocumentElement().getAttribute(
					"OrderHeaderKey");
			if(!YFCCommon.isStringVoid(strOHKey)){
			Document docApiInput = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			Element eleRoot = docApiInput.getDocumentElement();
			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);

			docAPIOutput = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docApiInput);

		}
 	}
		catch (Exception e) {
			loggerForPSAMidvoid.error(e);
		} finally {
			try {
				if (YFCCommon.isVoid(docAPIOutput)) {
					
					loggerForPSAMidvoid.debug("Inside Finally Block for API Execution");
					docApiInputForGetOrderDet = YFCDocument.createDocument(
							KohlsPOCConstant.ELEM_ORDER).getDocument();
					Element eleOrderRoot = docApiInputForGetOrderDet
							.getDocumentElement();
					eleOrderRoot.setAttribute(
							KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
					if(!YFCCommon.isStringVoid(strOHKey)){
						docInsertAPIOutput = KOHLSBaseApi.invokeService(env,
							"KohlsSaveSalesDetails", docApiInputForGetOrderDet);
					}
				}

			}

			catch (Exception e) {
				loggerForPSAMidvoid.error(e);
			}
			
		}
		loggerForPSAMidvoid
		.endTimer(" --- checkAndInsertSalesData --- End");
		return docInsertAPIOutput;
	}

public Document checkAndUpdatePsaData (YFSEnvironment env , Document docInput)
 {
		loggerForPSAMidvoid.beginTimer(" --- checkAndUpdatePsaData -- Begin");
		Document docAPIOutput = null;
		Document docInsertAPIOutput = null;
		Document docApiInputForGetOrderDet = null;
		String strOHKey = docInput.getDocumentElement().getAttribute(
				"OrderHeaderKey");
		try {
			
			loggerForPSAMidvoid.debug("Order Header Key:::"+strOHKey);
			
			Document docApiInput = YFCDocument.createDocument(
					KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();
			Element eleRoot = docApiInput.getDocumentElement();
			eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);

			docApiInputForGetOrderDet = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleOrderRoot = docApiInputForGetOrderDet
					.getDocumentElement();
			eleOrderRoot.setAttribute(
					KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHKey);
			
			
			
			docAPIOutput = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docApiInput);
			
		} catch (Exception e) {
			loggerForPSAMidvoid.error(e);
		} finally {
			try {
				loggerForPSAMidvoid.debug("Inside Finally Block for API Execution");
				if(!YFCCommon.isStringVoid(strOHKey)){
					if (YFCCommon.isVoid(docAPIOutput)) {
						docInsertAPIOutput = KOHLSBaseApi.invokeService(env,
								"KohlsSaveSalesDetails", docApiInputForGetOrderDet);
						loggerForPSAMidvoid.debug("Inside Finally Block for Creating API Data");
					} else {
						docInsertAPIOutput = KOHLSBaseApi.invokeService(env,
								"KohlsSavePsaDetails", docApiInputForGetOrderDet);
						loggerForPSAMidvoid.debug("Inside Finally Block for Change API Data");
					}
				}
			} catch (Exception e) {
				loggerForPSAMidvoid.error(e);
			}

		}
		loggerForPSAMidvoid.endTimer(" --- checkAndUpdatePsaData -- End");
		return docInsertAPIOutput;
		
	}

public Document updatePSAMidVoidDocument(Document inputDoc)
{ 
	Document OutputDoc = null;
	loggerForPSAMidvoid.beginTimer("Inside updatePSAMidVoidDocument -- Begin ");
	try
	{
		NodeList ndlOrderLine = XPathUtil.getNodeList(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine");
		
		Element eleOrderlines = (Element) XPathUtil.getNode(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/OrderLines");
		
		Element eleOrderline = (Element) XPathUtil.getNode(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine");
	
		eleOrderlines.removeChild(eleOrderline);
		
		
		if(loggerForPSAMidvoid.isDebugEnabled())
			loggerForPSAMidvoid.debug("After removal ::"+ XMLUtil.getElementXMLString(eleOrderlines));
		
		
		for(int i=0;i<ndlOrderLine.getLength();i++)
		{
			Element eleCurrent = (Element) ndlOrderLine.item(i);
			Node eleclone = eleCurrent.cloneNode(true);
			XMLUtil.appendChild(eleOrderlines, eleCurrent);
			XMLUtil.appendChild(eleOrderlines, (Element) eleclone);
			
			
			if(loggerForPSAMidvoid.isDebugEnabled())
				loggerForPSAMidvoid.debug("After appending ::"+XMLUtil.getElementXMLString(eleOrderlines));
			
		}
		NodeList ndlTaxDetailList = XPathUtil.getNodeList(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail");
		NodeList ndlTaxDetail = XPathUtil.getNodeList(inputDoc, "/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail");
		Element eleTaxDetailList = (Element) XPathUtil.getNode(inputDoc,"/InvoiceDetail/InvoiceHeader/Order/TaxDetailList");
		
		
		if(!YFCCommon.isVoid(ndlTaxDetailList.item(0)))
		{
			//System.out.println("Inside not void of taxdetail list");
			Element eleTaxDetail = (Element) XPathUtil.getNode(inputDoc,"/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail");
			eleTaxDetailList.removeChild(eleTaxDetail);
			
			if(loggerForPSAMidvoid.isDebugEnabled())
				loggerForPSAMidvoid.debug("After tax detail removal::"+XMLUtil.getElementXMLString(eleTaxDetailList));
	
		for(int i=0;i<ndlTaxDetail.getLength();i++)
		{
			Element eleCurrent = (Element) ndlTaxDetail.item(i);
			XMLUtil.appendChild(eleTaxDetailList, eleCurrent);
			Element eleClone = (Element) eleCurrent.cloneNode(true);
			eleClone.setAttribute("TaxIndicator", KohlsPOCConstant.ATTR_TAX_1);
			eleClone.setAttribute("Type", KohlsPOCConstant.ATTR_PSA);
			XMLUtil.appendChild(eleTaxDetailList, eleClone);
			
			if(loggerForPSAMidvoid.isDebugEnabled())
				loggerForPSAMidvoid.debug("After appending Tax ::"+XMLUtil.getElementXMLString(eleTaxDetailList));
		}
		}
		loggerForPSAMidvoid.endTimer("Inside updatePSAMidVoidDocument -- End ");
		inputDoc = calculateTotalOrderLines(inputDoc);
		OutputDoc = inputDoc;
			
	}
	catch(Exception e)
	{
		loggerForPSAMidvoid.error(e);
	}
		
	return OutputDoc;
}

public Document setExternalPayment(Document inputDoc)
{
		String strCheck = null;
		try {
			loggerForPSAMidvoid.beginTimer("setExternalPayment");
			NodeList ndlCollectionDetail = XPathUtil.getNodeList(inputDoc,
					KohlsPOCConstant.X_INV_COLLECTION_DETAIL);

			for (int i = 0; i < ndlCollectionDetail.getLength(); i++) {
				Element eleCurrentElement = (Element) ndlCollectionDetail
						.item(0);
				if (!YFCCommon.isVoid(eleCurrentElement)) {
					
					if(loggerForPSAMidvoid.isDebugEnabled())
						loggerForPSAMidvoid.debug("Current CollectionDetail Element ::"
								+ XMLUtil.getElementXMLString(eleCurrentElement));
					Element elePaymentMethod = (Element) XPathUtil.getNode(
							eleCurrentElement, "PaymentMethod");
					if (!YFCCommon.isVoid(elePaymentMethod)) {
						
						if(loggerForPSAMidvoid.isDebugEnabled())
							loggerForPSAMidvoid.debug("Current Payment Method Element ::"
									+ XMLUtil
									.getElementXMLString(elePaymentMethod));
						strCheck = elePaymentMethod.getAttribute("PaymentType");
						loggerForPSAMidvoid.debug("Payment Type is ::" + strCheck);
						if (strCheck.equalsIgnoreCase("CREDIT_CARD")
								|| strCheck.equalsIgnoreCase("DEBIT_CARD")) {
							loggerForPSAMidvoid.debug("Inside External Payment block");
							elePaymentMethod.setAttribute("IsExternalPayment","P");

						}

					}
				}
			}
		}
		catch(Exception e){e.printStackTrace();}
	loggerForPSAMidvoid.endTimer("setExternalPayment");
		return inputDoc;
	}

}
