package com.kohls.poc.api;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.ycp.bcsupport.YCPBCTemplateTrimmer;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author tkmaath
 *
 */
public class KohlsPublishInvoiceForPA extends KOHLSBaseApi {

  private static final YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPublishInvoiceForPA.class.getName());

  private static YFCDocument oTemplateDoc = null;

  private String strOrderInvoiceKey = null;
  private String strPSASellerOrgCode = null;
  private Document docGetOrderInvoiceDetailsInput = null;
  private Map<String, Element> mTieredDiscount = new LinkedHashMap<String, Element>();
  Document docOrderListOutput = null;
  Document doc = null;
  Document docOriginalSale = null;
  Document docInputForOrigSale = null;
  Document docInputForgetOrderDetail = null;
  NodeList ndlOriginalSaleOrder = null;
  NodeList ndlPSASaleOrder = null;
  Element eleInputForOrigSale = null;
  Element elePAOrder = null;
  Element eleRootElement = null;
  Element eleOrderOfSale = null;
  String strOHkey = null;
  String strClobData = null;
  String strNoUPCMsg = "No UPC Found";
  String sPAStatus = "";
  String endpoint = "";
  String sText12="", sText14="";
  /**
   * @param env
   * @param docFinal
   * @return
   * @throws Exception
   */
  public Document consolidateInvoiceMessage(YFSEnvironment env, Document docFinal)
      throws Exception {

    logger.beginTimer("KohlsPublishInvoiceForPA.consolidateInvoiceMessage");
    logger.debug("Invoice Key is::" + strOrderInvoiceKey);
    if (logger.isDebugEnabled()) {
      logger.debug("API input for getOrderInvoiceDetails is:::" + XMLUtil.getXMLString(docFinal));
      logger.debug("docFinal Input value is : " + XMLUtil.getXMLString(docFinal));
    }
    try {
      Element eleOrder = docFinal.getDocumentElement();

      Element eleAddtionalInfo =
          XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_YFCADDITIONALINFO);
      if (!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()) {
        endpoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
      }

      strPSASellerOrgCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);

      // Begin Changes for Newly added Extn attributes at Order Level
      String strOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      logger.debug("OrderHeaderKey is::" + strOrderHeaderKey);


      // Consolidating the Invoice Collection and updating InvooiceHeader
      // details
      Document docOrderInvoiceDetailInput =
          YFCDocument.createDocument("InvoiceDetail").getDocument();
      Element eleOrderInvoiceInput = docOrderInvoiceDetailInput.getDocumentElement();

      Element eleInvHeader = XMLUtil.createChild(eleOrderInvoiceInput, "InvoiceHeader");

      // Element eleOrderRoot = XMLUtil.createChild(eleOrderInvoiceInput, "Order");

      Element eleOrderRoot = (Element) docOrderInvoiceDetailInput.importNode(eleOrder, true);
      eleInvHeader.appendChild(eleOrderRoot);
      eleOrderRoot.setAttribute("OrderHeaderKey", strOrderHeaderKey);
      Document docPublishInvoiceDetail = new KohlsPocInvoiceToSalesHubAPI()
          .generateAndPublishPOSInvoiceToSalesHub(env, docOrderInvoiceDetailInput);

      consolidateInvoiceCollectionWithHeaderDetails(env, docPublishInvoiceDetail,
          strOrderHeaderKey);
      docFinal = (Document) docPublishInvoiceDetail.cloneNode(true);
      docFinal.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
          strOrderHeaderKey);

      if (logger.isDebugEnabled()) {
        logger.debug("Output of consolidateInvoiceCollectionWithHeaderDetails is::"
            + XMLUtil.getXMLString(docFinal));
      }
      // Preparing document for Input
      Document docGetOrderDetailsInput =
          YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
      Element eleOrderInput = docGetOrderDetailsInput.getDocumentElement();
      eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
      logger.debug("PA seller Organization code is:::" + strPSASellerOrgCode);
      Element eleCustAttribs = XMLUtil.getChildElement(eleOrder,"CustomAttributes");
      sText12 = eleCustAttribs.getAttribute("Text12");
      sText14 = eleCustAttribs.getAttribute("Text14");
      docFinal = updateSales(env, docFinal);


      // Trimmer Util
      TrimdocFinalAgainstXsdTemplate(docFinal);

      Element eleRoot = docFinal.getDocumentElement();

      eleRoot.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
      eleRoot.setAttribute("MessageType", "PriceAdjustment");

      String sDateInvoiced =
          new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(YFCDateUtils.getCurrentDate(true));
      Element eleInvoiceHeader = XMLUtil.getChildElement(eleRoot, "InvoiceHeader");
      eleInvoiceHeader.setAttribute("DateInvoiced", sDateInvoiced);

      Element eleOrderExtn = (Element) eleOrder.getElementsByTagName("Extn").item(0);
      String sEnvObj = (String) env.getTxnObject("ExtnPsaStatus");
      if (!YFCCommon.isVoid(sEnvObj)) {
        sPAStatus = sEnvObj;
      } else {
        sPAStatus = eleOrderExtn.getAttribute("ExtnPsaStatus");
      }
      if (sPAStatus.equalsIgnoreCase("PA_MIDVOID")) {
        eleRoot.setAttribute("MessageType", "PriceAdjustmentMidVoid");
      }

    }

    catch (YFSException exception) {
      logger.error(exception);
      throw exception;
    }
    if (logger.isDebugEnabled()) {
      logger.debug("The Final document sent Tibco Queue : " + XMLUtil.getXMLString(docFinal));
    }
    logger.endTimer("KohlsPublishInvoiceForPA.consolidateInvoiceMessage");
    return docFinal;
  }

  /*
   * This methods takes Tibco xsd as template and trims the docFinal before sending to Tibco This
   * will ensure no extra attributes are sent to SH via Tibco
   */
  private void TrimdocFinalAgainstXsdTemplate(Document docFinal)
      throws ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsPublishInvoiceForPA.TrimdocFinalAgainstXsdTemplate");
    // Document document1 = XMLUtil.createDocument(docFinal.getElementsByTagName("Order").item(0));
    if (YFCCommon.isVoid(oTemplateDoc)) {
      InputStream fileToReadFrom = KohlsPublishInvoiceForPA.class
          .getResourceAsStream(KohlsPOCConstant.SEND_INVOICE_DETAIL_TO_TIBCO);
      Document docTemplate = XMLUtil.getDocument(fileToReadFrom);
      oTemplateDoc = YFCDocument.getDocumentFor(docTemplate);
    }
    //RMVP-530 Add Text1 attribute for Sephora BI data collect in PA
    checkForText1Attribute(oTemplateDoc);
    // document2 = XMLUtil.createDocument(document2.getElementsByTagName("Order").item(0));
    YFCDocument oOutDoc = YFCDocument.getDocumentFor(docFinal);

    YCPBCTemplateTrimmer oTempTrim = new YCPBCTemplateTrimmer();

    oTempTrim.trimTheOutputBasedOnTemplate(oOutDoc.getDocumentElement(),
        oTemplateDoc.getDocumentElement(), false);

    if (logger.isDebugEnabled()) {
      logger.debug("OutputDoc after trimming is --->" + oOutDoc.getDocumentElement());
    }
    logger.endTimer("KohlsPublishInvoiceForPA.TrimdocFinalAgainstXsdTemplate");
  }

  /**
   *
   * @param oTemplateDoc
   */
  private void checkForText1Attribute(YFCDocument oTemplateDoc) {
    Document oTemplateDocDocument = oTemplateDoc.getDocument();
    NodeList nlcustomAttributes = oTemplateDocDocument.getElementsByTagName("CustomAttributes");
    if (nlcustomAttributes.getLength() > 0) {
      Element customAttributes = (Element) nlcustomAttributes.item(0);
      if (!customAttributes.hasAttribute("Text1")) {
        customAttributes.setAttribute("Text1", "");
      }
    }
  }

  public Document updateSales(YFSEnvironment env, Document inputDoc) throws Exception {
    logger.beginTimer("KohlsPublishInvoiceForPA.updateSales");

    try {
      logger.debug("Inside updateSales Method");
      elePAOrder = inputDoc.getDocumentElement();
      strOHkey = elePAOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);

      // Prepare Input document for API call to fetch original Sales Data
      Document docInputForOrigSale =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_KOHLS_SALES_FOR_PSA).getDocument();

      Element eleInputForOrigSale = docInputForOrigSale.getDocumentElement();
      eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
      if (logger.isDebugEnabled()) {
        logger.debug("Document input to API call is::" + XMLUtil.getXMLString(docInputForOrigSale));
      }

      // API call to fetch sales Data
      Document docOriginalSale =
          invokeService(env, KohlsPOCConstant.SER_GET_KOHLS_SALES_DETAILS, docInputForOrigSale);

      Element eleRootElement = docOriginalSale.getDocumentElement();
      eleRootElement.setAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA, KohlsPOCConstant.BLANK);
      // Preparing input document for API call to fetch getOrderDetails

      /*
       * docInputForgetOrderDetail =
       * YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
       * 
       * eleInputForOrigSale = docInputForgetOrderDetail.getDocumentElement();
       * eleInputForOrigSale.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOHkey);
       */

      if (logger.isDebugEnabled()) {
        logger
            .debug("Document output of the API call is::" + XMLUtil.getXMLString(docOriginalSale));
      }

      // Parsing Clob Element into Document format

      String strClobDataPA = docOriginalSale.getDocumentElement().getAttribute("PSAData");
     
      logger.debug("Clob object is:::" + strClobDataPA);

      if (!strClobDataPA.isEmpty()) {
        Document docClobData = XMLUtil.getDocument(strClobDataPA);
        Element eleNewClob = docClobData.getDocumentElement();
        XMLUtil.importElement(eleRootElement, eleNewClob);
      }
      Element eleCustomAttributes =null;
      
      if (logger.isDebugEnabled()) {
        logger
            .debug("After import root element is::" + XMLUtil.getElementXMLString(eleRootElement));
      }
      // Aj
      Element eleInvOrder = (Element)inputDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER).item(0);
      Element eleOrderPromotions = XMLUtil.getChildElement(eleInvOrder, KohlsPOCConstant.E_PROMOTIONS, true);
      
      //Map PA Custom Attributess
      Element eleInvCustomAttributes = XMLUtil.getChildElement(eleInvOrder,KohlsPOCConstant.CUST_ATTRIBUTES, true);
      eleInvCustomAttributes.setAttribute("Text12", sText12);
      eleInvCustomAttributes.setAttribute("Text14", sText14);
      
      Element eleInvOrderLines = (Element) inputDoc.getElementsByTagName("OrderLines").item(0);
      NodeList nlInvOrderline = XPathUtil.getNodeList(inputDoc, KohlsPOCConstant.X_INV_ORDERLINE);
      HashMap<String, Element> mapPromotionMap = new HashMap<String, Element>();
      if (nlInvOrderline.getLength() != 0) {
        for (int i = 0; i < nlInvOrderline.getLength(); i++) {

          Double dText12OfReturn = null;
          Double dExtnRetPriceOfReturn = null;
          boolean bCondition1 = false;
          boolean bCondition2 = false;
          boolean bCondition3 = false;
          boolean bCondition4 = false;
          DecimalFormat df = new DecimalFormat("0.00");
          Element eleInvOrderLine = (Element) nlInvOrderline.item(i);

          String sPrimeLineNo = eleInvOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
          Element eleExtn = (Element) eleInvOrderLine.getElementsByTagName("Extn").item(0);
          String sExtnRetPriceOfReturn = eleExtn.getAttribute("ExtnReturnPrice");
          String sExtnSkuStatusCode = eleExtn.getAttribute("ExtnSkuStatusCode");
          String sExtnIsPriceEntered = eleExtn.getAttribute("ExtnIsPriceEntered");
          Element eleCutomAttributes =
              (Element) eleInvOrderLine.getElementsByTagName("CustomAttributes").item(0);
          String sText12OfReturn = eleCutomAttributes.getAttribute("Text12");
          String sText11OfReturn = eleCutomAttributes.getAttribute("Text11");
          dText12OfReturn = 0.0;
          if (!YFCCommon.isVoid(sText12OfReturn))
            dText12OfReturn = Double.parseDouble(sText12OfReturn);
          dExtnRetPriceOfReturn = Double.parseDouble(sExtnRetPriceOfReturn);
          bCondition1 = dText12OfReturn > dExtnRetPriceOfReturn;
          bCondition2 = "Eligible".equalsIgnoreCase(sText11OfReturn);
          bCondition3 = "30".equalsIgnoreCase(sExtnSkuStatusCode);
          bCondition4 = "Y".equalsIgnoreCase(sExtnIsPriceEntered);

          if (bCondition3 || bCondition4) {
            eleInvOrderLines.removeChild(eleInvOrderLine);
            if (logger.isDebugEnabled()) {
              logger.debug("Else If condition  met----- " + XMLUtil.getXMLString(inputDoc));
            }
          } else if (bCondition1 && bCondition2) {
            eleInvOrderLine.setAttribute("Type", "Sale");
            // Removing promotions if any on the new line
            Element elePromotions =
                XMLUtil.getChildElement(eleInvOrderLine, KohlsPOCConstant.E_PROMOTIONS);
            if (!YFCCommon.isVoid(elePromotions)) {
              eleInvOrderLine.removeChild(elePromotions);
            }
            // fetch order line from docOriginalSale which has same
            // primelineno and appending the matching element to
            // Invoice Doc at OrderLines level
            Element eleOriginalOrderLine =
                SCXmlUtil.getXpathElement(docOriginalSale.getDocumentElement(),
                    "//KOHLSSalesForPsa/Order/OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNo
                        + "']");
            eleOriginalOrderLine.setAttribute("Type", "Return");

            if (logger.isDebugEnabled()) {
              logger.debug("if condition meets **** "
                  + XMLUtil.getXMLString(eleInvOrderLines.getOwnerDocument()));
            }

            // Changes for CAPE-4093 start
            // Element eleInvOrderLinePriceInfo = XMLUtil.getChildElement(eleInvOrderLine,
            // KohlsPOCConstant.E_LINE_PRICE_INFO);
            // String sInvOrderLineUnitPrice =
            // eleInvOrderLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
            String sExtnPLURetailAmt = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT);
            if (!YFCCommon.isVoid(sExtnPLURetailAmt)) {
              Element eleOriginalOrderLinePriceInfo =
                  XMLUtil.getChildElement(eleOriginalOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
              eleOriginalOrderLinePriceInfo.setAttribute(KohlsPOCConstant.A_LIST_PRICE,
                  sExtnPLURetailAmt);
            }
            // Changes for CAPE-4093 end


            // Changes for CAPE-4115 - start
            // this section of code will just the line charge on the order line. It is just for data
            // collect
            // purpose only. It has no impact on OMS pricing.
            NodeList nlOrigLineCharge =
                eleOriginalOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
            Element eleOrigLineCharges =
                XMLUtil.getChildElement(eleOriginalOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
            for (int j = 0; j < nlOrigLineCharge.getLength(); j++) {
              Element eleOrigLineCharge = (Element) nlOrigLineCharge.item(j);
              Element eleOrigLineChargeExtn =
                  XMLUtil.getChildElement(eleOrigLineCharge, KohlsPOCConstant.E_EXTN);
              String sExtnDiscountTypeCode = "";
              String sExtnDiscountReasonCode = "";
              String sTLDDiscountTypeCode = "";
              String sExtnDiscountPercent = "0.00";
              if (!YFCCommon.isVoid(eleOrigLineChargeExtn)) {
                sExtnDiscountTypeCode = eleOrigLineChargeExtn.getAttribute("ExtnDiscountTypeCode");
                sExtnDiscountReasonCode =
                    eleOrigLineChargeExtn.getAttribute("ExtnDiscountReasonCode");
                sExtnDiscountPercent = eleOrigLineChargeExtn.getAttribute("ExtnDiscountPercent");
              }
              // Changes for CAPE-4261, CAPE-4086 start
              String sChargePerLine =
                  eleOrigLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
              String sChargeName =
                  eleOrigLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
              
            //Changes for CAPE-4261 - start
              if ("D".equalsIgnoreCase(sExtnDiscountTypeCode)
                  || "K".equalsIgnoreCase(sExtnDiscountTypeCode)
                  || "R".equalsIgnoreCase(sExtnDiscountTypeCode)) {
                sTLDDiscountTypeCode = "D";
              } else if ("P".equalsIgnoreCase(sExtnDiscountTypeCode)
                  || "Q".equalsIgnoreCase(sExtnDiscountTypeCode)) {
                sTLDDiscountTypeCode = "P";
              } else if ("S".equalsIgnoreCase(sExtnDiscountTypeCode)) {
                sTLDDiscountTypeCode = "S";
              } else {
                sTLDDiscountTypeCode = "T";
              }
              //Changes for CAPE-4261 - end
              
              if (Double.parseDouble(sChargePerLine) > 0.00D 
                   && !(("G".equalsIgnoreCase(sExtnDiscountTypeCode) && "764".equalsIgnoreCase(sExtnDiscountReasonCode))
                    || ("E".equalsIgnoreCase(sExtnDiscountTypeCode) && "776".equalsIgnoreCase(sExtnDiscountReasonCode)))) {
                if (mapPromotionMap.containsKey(sChargeName)) {
                  Element elePromotion = mapPromotionMap.get(sChargeName);
                  String sOverrideAdjValue =
                      elePromotion.getAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
                  Double dOverrideAdjValue = Double.parseDouble(sOverrideAdjValue);
                  elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                      df.format(dOverrideAdjValue + Double.parseDouble(sChargePerLine)));
                } else {
                  Element elePromotion =
                      XMLUtil.createChild(eleOrderPromotions, KohlsPOCConstant.E_PROMOTION);
                  elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, sChargeName);
                  elePromotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                      sChargePerLine);
                  Element elePromotionExtn =
                      XMLUtil.createChild(elePromotion, KohlsPOCConstant.E_EXTN);
                  elePromotionExtn.setAttribute("ExtnDiscountTypeCode", sTLDDiscountTypeCode);
                  elePromotionExtn.setAttribute("ExtnDiscountReasonCode", sExtnDiscountReasonCode);
                  elePromotionExtn.setAttribute("ExtnDiscountPercent", sExtnDiscountPercent);
                  mapPromotionMap.put(sChargeName, elePromotion);
                }
              }
              // Changes for CAPE-4261, CAPE-4086 end
              if (!YFCCommon.isVoid(sExtnDiscountTypeCode)
                  && !YFCCommon.isVoid(sExtnDiscountReasonCode)
                  && (("H".equals(sExtnDiscountTypeCode) && "763".equals(sExtnDiscountReasonCode))
                      || ("F".equals(sExtnDiscountTypeCode)
                          && "775".equals(sExtnDiscountReasonCode)))) {
                Element eleOrigLineCharge_Temp = (Element) eleOrigLineCharge.cloneNode(true);
                Element eleOrigLineChargeExtn_Temp =
                    XMLUtil.getChildElement(eleOrigLineCharge_Temp, KohlsPOCConstant.E_EXTN);
                if ("H".equals(sExtnDiscountTypeCode) && "763".equals(sExtnDiscountReasonCode)) {
                  eleOrigLineChargeExtn_Temp.setAttribute("ExtnDiscountTypeCode", "G");
                  eleOrigLineChargeExtn_Temp.setAttribute("ExtnDiscountReasonCode", "764");
                } else {
                  eleOrigLineChargeExtn_Temp.setAttribute("ExtnDiscountTypeCode", "E");
                  eleOrigLineChargeExtn_Temp.setAttribute("ExtnDiscountReasonCode", "776");
                }
                XMLUtil.appendChild(eleOrigLineCharges, eleOrigLineCharge_Temp);
              }
            }
            // Changes for CAPE-4115 - end
            
            XMLUtil.importElement(eleInvOrderLines, eleOriginalOrderLine);

          } else {
            // removing the orderline element which is not matching
            // given criteria. These lines will not be sent to
            // Tibco.
            eleInvOrderLines.removeChild(eleInvOrderLine);
            if (logger.isDebugEnabled()) {
              logger.debug("If condition doesn't meet----- " + XMLUtil.getXMLString(inputDoc));
            }
          }

        }
      }
      // Mapping TaxDetails
      inputDoc = MapTaxIndicators(inputDoc);

      // Removing Promotions

      inputDoc = removeOrderPromotions(inputDoc);

      // inputDoc = calculateTotalOrderLines(inputDoc);
      inputDoc = getNodeListToRemove(inputDoc);
      // inputDoc = setExternalPaymentAndRemoveKCS(inputDoc);
      // inputDoc = removeCollectionOrChargeTranDetails(env, inputDoc);

    } catch (Exception e) {
      e.printStackTrace();
      throw e;
    } finally {
      logger.endTimer("KohlsPublishInvoiceForPA.updateSales");
    }
    return inputDoc;
  }

  /**
   * @param env
   * @param docFinal
   * @param strOrderHeaderKey
   * @return
   * @throws Exception ComplexQuery Input for calling getOrderInvoiceList
   *         <OrderInvoice OrderHeaderKey="1116112403585922866901" > <ComplexQuery Operator="AND">
   *         <And> <Or> <Exp Name="InvoiceType" Value="CREDIT_MEMO" InvoiceTypeQryType="EQ"/> <Exp
   *         Name="InvoiceType" Value="DEBIT_MEMO" InvoiceTypeQryType="EQ"/> </Or> </And>
   *         </ComplexQuery> </OrderInvoice>
   */
  public void consolidateInvoiceCollectionWithHeaderDetails(YFSEnvironment env, Document docFinal,
      String strOrderHeaderKey) throws Exception {

    logger.beginTimer("KohlsPublishInvoiceForPA.consolidateInvoiceCollectionWithHeaderDetails");

    try {
      logger.debug(
          "OrderHeaderKey in consolidateCollectionDetails method input is : " + strOrderHeaderKey);
      if (!YFCCommon.isVoid(strOrderHeaderKey) && !YFCCommon.isVoid(docFinal)) {

        Element eleFinal = docFinal.getDocumentElement();
        Element eleInvoiceHeaderOrg = XMLUtil.getChildElement(eleFinal, "InvoiceHeader");

        // Create input for getOrderInvoiceList
        Document inGetOrderInvoiceList =
            XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_INP_CQ);
        inGetOrderInvoiceList.getDocumentElement().setAttribute("OrderHeaderKey",
            strOrderHeaderKey);

        // Calling getOrderInvoiceList API to get all the Invoices
        // associated to the current PSA Order
        Document getOrderInvoiceListTemplate =
            XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_OUT_TEMP);
        Document outGetOrderInvoiceList = KOHLSBaseApi.invokeAPI(env, getOrderInvoiceListTemplate,
            "getOrderInvoiceList", inGetOrderInvoiceList);

        if (logger.isDebugEnabled())
          logger.debug("The outGetOrderInvoiceList Output : "
              + XMLUtil.getXMLString(outGetOrderInvoiceList));

        Double conAmountCollected = KohlsPOCConstant.ZERO_DBL;
        Double conLineSubTotal = KohlsPOCConstant.ZERO_DBL;
        Double conTotalAmount = KohlsPOCConstant.ZERO_DBL;
        Double conTotalTax = KohlsPOCConstant.ZERO_DBL;
        Double conTotalDiscount = KohlsPOCConstant.ZERO_DBL;
        DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
        // Calling getOrderInvoiceDetails for each Invoice and getting
        // the associated, Payment Collection details and Invoice header
        // details.
        NodeList nlOrderInvoiceList = outGetOrderInvoiceList.getElementsByTagName("OrderInvoice");

        Document docCollectionDetails = XMLUtil.createDocument("CollectionDetails");
        if (nlOrderInvoiceList.getLength() > 0) {
          for (int i = 0; i < nlOrderInvoiceList.getLength(); i++) {
            Element eleOrderInvoice = (Element) nlOrderInvoiceList.item(i);
            conAmountCollected = conAmountCollected
                + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "AmountCollected"));
            conTotalAmount = conTotalAmount
                + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalAmount"));
            conTotalTax =
                conTotalTax + Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalTax"));

            conLineSubTotal = conLineSubTotal
                + (Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalAmount"))
                    - Double.parseDouble(XMLUtil.getAttribute(eleOrderInvoice, "TotalTax")));

            String srtOrderInvoiceKey = XMLUtil.getAttribute(eleOrderInvoice, "OrderInvoiceKey");
            Document getOrderInvoiceDetailsInp = XMLUtil.createDocument("GetOrderInvoiceDetails");
            getOrderInvoiceDetailsInp.getDocumentElement().setAttribute("InvoiceKey",
                srtOrderInvoiceKey);

            // Document docGetOrderInvoiceDetailsOutTemplate =
            // XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT_TEMP);
            Document docGetOrderInvDetailsOutput =
                KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_INVOICE_DETAIL_OUTPUT,
                    KohlsPOCConstant.GET_INVOICE_ORDER_DET, getOrderInvoiceDetailsInp);
            /*
             * KohlsCommonUtil.invokeAPI(env, docGetOrderInvoiceDetailsOutTemplate, KohlsPOCConstant
             * .GET_INVOICE_ORDER_DET,getOrderInvoiceDetailsInp);
             */

            if (logger.isDebugEnabled())
              logger.debug("docGetOrderInvDetailsOutput output value is : "
                  + XMLUtil.getXMLString(docGetOrderInvDetailsOutput));
            Element eleInvoiceHeader = XMLUtil
                .getChildElement(docGetOrderInvDetailsOutput.getDocumentElement(), "InvoiceHeader");
            conTotalDiscount = conTotalDiscount
                + Double.parseDouble(XMLUtil.getAttribute(eleInvoiceHeader, "TotalDiscount"));
            NodeList nlCollectionDetailsList =
                docGetOrderInvDetailsOutput.getElementsByTagName("CollectionDetail");
            if (nlCollectionDetailsList.getLength() > 0) {
              for (int j = 0; j < nlCollectionDetailsList.getLength(); j++) {
                Element eleCollectionDetail = (Element) nlCollectionDetailsList.item(j);
                Element elePaymentMethod =
                    XMLUtil.getChildElement(eleCollectionDetail, "PaymentMethod");
                if (!YFCCommon.isVoid(elePaymentMethod)) {
                  String sPaymentType =
                      elePaymentMethod.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE);
                  if ("KOHLS_CASH".equalsIgnoreCase(sPaymentType)) {
                    Double dTotalRefundedAmount =
                        Double.parseDouble(elePaymentMethod.getAttribute("TotalRefundedAmount"));
                    conAmountCollected = conAmountCollected + dTotalRefundedAmount;
                    conTotalAmount = conTotalAmount + dTotalRefundedAmount;
                  }
                  XMLUtil.setAttribute(elePaymentMethod, "TotalCharged",
                      XMLUtil.getAttribute(eleCollectionDetail, "AmountCollected"));
                  // Fix for PR-528, PR-558 - Start
                  XMLUtil.importElement(docCollectionDetails.getDocumentElement(),
                      eleCollectionDetail);
                  // Fix for PR-528, PR-558 - End
                }
              }
            }
          }
        }
        // Fix for PR-439 - Start
        int iTotalLines = XMLUtil.getElementsCountByTagName(
            docCollectionDetails.getDocumentElement(), "CollectionDetail");
        XMLUtil.setAttribute(docCollectionDetails.getDocumentElement(), "TotalLines",
            String.valueOf(iTotalLines));
        // Fix for PR-439 - End
        eleInvoiceHeaderOrg.setAttribute("AmountCollected", twoDForm.format(conAmountCollected));
        eleInvoiceHeaderOrg.setAttribute("LineSubTotal", twoDForm.format(conLineSubTotal));
        eleInvoiceHeaderOrg.setAttribute("TotalAmount", twoDForm.format(conTotalAmount));
        eleInvoiceHeaderOrg.setAttribute("TotalTax", twoDForm.format(conTotalTax));
        eleInvoiceHeaderOrg.setAttribute("TotalDiscount", twoDForm.format(conTotalDiscount));
        // Updating the OverallTotals on the order
        Element eleOverallTotals =
            (Element) XPathUtil.getNode(docFinal, KohlsPOCConstant.X_INV_OVERALL_TOTALS);
        if (!YFCCommon.isVoid(eleOverallTotals)) {
          eleOverallTotals.setAttribute("GrandTax", twoDForm.format(Math.abs(conTotalTax)));
          eleOverallTotals.setAttribute("GrandTotal", twoDForm.format(Math.abs(conTotalAmount)));
          eleOverallTotals.setAttribute("LineSubTotal", twoDForm.format(Math.abs(conLineSubTotal)));
          eleOverallTotals.setAttribute("GrandCharges", "0.00");
        }
        if (logger.isDebugEnabled()) {
          logger.debug("Consolidated CollectionDetails element : "
              + XMLUtil.getXMLString(docCollectionDetails));
        }
        if (!YFCCommon.isVoid(docCollectionDetails)) {
          if (logger.isDebugEnabled()) {
            logger.debug(
                "The inDoc inside removing loop is : " + XMLUtil.getElementXMLString(eleFinal));
          }
          // XMLUtil.removeChild(eleInvoiceHeaderOrg, eleCollectionDetailsOrg);
          XMLUtil.importElement(eleInvoiceHeaderOrg, docCollectionDetails.getDocumentElement());
          if (logger.isDebugEnabled()) {
            logger.debug("The inDoc inside after removing and attaching loop is : "
                + XMLUtil.getElementXMLString(eleFinal));
          }
          logger.debug("Successfully consolidated Payment Collection details");
        }

      } else {
        YFSException eYFS = new YFSException("OrderHeaderKey is Null", "OrderHeaderKey is Null",
            "OrderHeaderKey is Null");
        throw eYFS;
      }
    } catch (Exception e) {
      logger.verbose(e);
      throw e;
    } finally {
      logger.endTimer("KohlsPublishInvoiceForPA.consolidateInvoiceCollectionWithHeaderDetails");
    }
  }

  /**
   * @param docOrigSale
   * @param docPSA
   * @return
   */
  public Document AppendPromotionAndTaxes(Document docOrigSale, Document docPSA) {
    logger.beginTimer("KohlsPublishInvoiceForPA.AppendPromotionAndTaxes");
    try {

      NodeList ndlSalesPromotion =
          XPathUtil.getNodeList(docOrigSale, KohlsPOCConstant.X_KOHLS_SALES_PROMOTION);

      // Updating type code for Sale Promotions

      for (int a = 0; a < ndlSalesPromotion.getLength(); a++) {
        Element eleCurrentPromotion = (Element) ndlSalesPromotion.item(a);
        eleCurrentPromotion.setAttribute(KohlsPOCConstant.A_TYPE, KohlsPOCConstant.SALE);
      }

      Element elePSAParentPromotion =
          (Element) XPathUtil.getNode(docPSA, KohlsPOCConstant.X_INV_PROMOTIONS);

      NodeList ndlPSAPromotion = XPathUtil.getNodeList(docPSA, KohlsPOCConstant.X_INV_PROMOTION);

      // Updating type code for PSA Promotions

      for (int b = 0; b < ndlPSAPromotion.getLength(); b++) {

        // defect 3403 changes start
        String getPromotion = null;
        String IsPromotionApplied = null;
        // defect 3403 changes End
        Element eleCurrentPSAPromotion = (Element) ndlPSAPromotion.item(b);
        eleCurrentPSAPromotion.setAttribute(KohlsPOCConstant.A_TYPE, "PA");

        // defect 3403 changes start
        // getPromotion.getAttribute("PromotionType");
        // IsPromotionApplied.getAttribute("PromotionApplied");
        getPromotion = (String) eleCurrentPSAPromotion.getAttribute("PromotionType");
        IsPromotionApplied = (String) eleCurrentPSAPromotion.getAttribute("PromotionApplied");

        if (getPromotion.equalsIgnoreCase("KOHLS_CASH_EARNED")
            && IsPromotionApplied.equalsIgnoreCase("N")) {
          // XMLUtil.removeChild(elePSAParentPromotion,ndlPSAPromotion);
          XMLUtil.removeChild(elePSAParentPromotion, eleCurrentPSAPromotion);
        } else {
          eleCurrentPSAPromotion.setAttribute("PromotionApplied", "Y");
        }
        // defect 3403 changes End
      }

      for (int a = 0; a < ndlSalesPromotion.getLength(); a++) {
        XMLUtil.importElement(elePSAParentPromotion, (Element) ndlSalesPromotion.item(a));
      }

      Element eleOrigSaleOrder =
          (Element) XPathUtil.getNode(docOrigSale, KohlsPOCConstant.X_KOHLS_SALES_ORDER);

      Element eleOrigSaleOrderExtn =
          XMLUtil.getChildElement(eleOrigSaleOrder, KohlsPOCConstant.A_EXTN);

      String strExtnTaxDetails =
          eleOrigSaleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
      Element eleTaxDetails = null;
      if (!YFCCommon.isVoid(strExtnTaxDetails)) {
        Document docExtnTaxDetails = XMLUtil.getDocument(strExtnTaxDetails);
        eleOrigSaleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
            KohlsPOCConstant.BLANK);
        eleTaxDetails = docExtnTaxDetails.getDocumentElement();
        XMLUtil.importElement(eleOrigSaleOrder, eleTaxDetails);
      }

      NodeList ndlTaxDetail =
          XPathUtil.getNodeList(eleOrigSaleOrder, KohlsPOCConstant.X_KOHLS_SALES_TAX_DETAIL);

      Element elePSATaxDetailList =
          (Element) XPathUtil.getNode(docPSA, KohlsPOCConstant.X_INV_TAX_DETAIL_LIST);

      // Updating Tax Indicator for Sales Tax

      if (!(YFCCommon.isVoid(ndlTaxDetail))) {
        for (int c = 0; c < ndlTaxDetail.getLength(); c++) {
          Element eleCurrentTax = (Element) ndlTaxDetail.item(c);
          String strTaxInd = eleCurrentTax.getAttribute(KohlsPOCConstant.A_TAX_INDICATOR);
          strTaxInd = UpdateTaxIndType(strTaxInd);
          eleCurrentTax.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, strTaxInd);
          eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE, KohlsPOCConstant.SALE);
        }

      }

      NodeList ndlPSATaxDetail = XPathUtil.getNodeList(docPSA, KohlsPOCConstant.X_INV_TAX_DETAIL);

      for (int d = 0; d < ndlPSATaxDetail.getLength(); d++) {
        Element eleCurrentTax = (Element) ndlPSATaxDetail.item(d);
        eleCurrentTax.setAttribute(KohlsPOCConstant.A_TYPE, "PA");
      }

      for (int c = 0; c < ndlTaxDetail.getLength(); c++) {
        XMLUtil.importElement(elePSATaxDetailList, (Element) ndlTaxDetail.item(c));
      }

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsPublishInvoiceForPA.AppendPromotionAndTaxes");
    }
    return docPSA;

  }

  /**
   * @param strTaxInd
   * @return
   */
  public String UpdateTaxIndType(String strTaxInd) {
    logger.beginTimer("KohlsPublishInvoiceForPA.UpdateTaxIndType");
    if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_1)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_A;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_2)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_B;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_3)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_C;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_4)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_D;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_5)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_E;
    } else if (strTaxInd.equalsIgnoreCase(KohlsPOCConstant.ATTR_TAX_6)) {
      strTaxInd = KohlsPOCConstant.ATTR_TAX_F;
    } else {
      strTaxInd = KohlsPOCConstant.CONST_HASH;
    }
    logger.endTimer("KohlsPublishInvoiceForPA.UpdateTaxIndType");
    return strTaxInd;
  }

  /**
   * @param docFinalXMLtoTibco
   * @return
   */
  public Document calculateTotalOrderLines(Document docFinalXMLtoTibco) {
    logger.beginTimer("KohlsPublishInvoiceForPA.calculateTotalOrderLines");
    String strExtnSimplePromoPrice = null;
    Element eleOrderLineExtn = null;
    Element eleOrderLine = null;
    Element eleLinePriceInfo = null;
    String strUnitPrice = null;
    try {
      logger.beginTimer("--- calculateTotalOrderLines ---");
      NodeList ndlOrderLine = ((NodeList) XPathUtil
          .getNodeList(docFinalXMLtoTibco.getDocumentElement(), KohlsPOCConstant.X_INV_ORDERLINE));

      Integer totalNumberCount = ndlOrderLine.getLength();

      String totalNumber = totalNumberCount.toString();

      Element eleOrderLines = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
          KohlsPOCConstant.X_INV_ORDERLINES);

      eleOrderLines.setAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS, totalNumber);

      if (!(YFCCommon.isVoid(ndlOrderLine))) {
        for (int i = 0; i < totalNumberCount; i++) {
          eleOrderLine = (Element) ndlOrderLine.item(i);
          // Code changes for Sale POS and PSA POC defect 3374 --
          // Begin -- 9/8/16

          eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.A_EXTN);

          strExtnSimplePromoPrice = eleOrderLineExtn.getAttribute("ExtnSimplePromoPrice");

          if (YFCCommon.isStringVoid(strExtnSimplePromoPrice)) {
            logger.debug(
                "Entering code block for Empty ExtnSimplePromoPrice : fetching and Appending");
            eleLinePriceInfo = XMLUtil.getChildElement(eleOrderLine, "LinePriceInfo");
            strUnitPrice = eleLinePriceInfo.getAttribute("UnitPrice");
            eleOrderLineExtn.setAttribute("ExtnSimplePromoPrice", strUnitPrice);

          }
          // Code changes for Sale POS and PSA POC defect 3374 -- End
          // -- 9/8/16

          Integer count = i + 1;
          String strCurrValue = count.toString();
          eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_LINE_SEQ_NO, strCurrValue);
          if (count % 2 == 0) {
            eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE, "PA");
          } else {
            eleOrderLine.setAttribute(KohlsPOCConstant.A_TYPE, "Return");
          }

        }
        // Fix for Original Terminal ID -- Begin -- 4/8/16

        logger.debug("Entering code block for Sale Terminal Id fix ");
        // Element eleTransAudit = (Element) XPathUtil
        // .getNodeList(docFinalXMLtoTibco.getDocumentElement(),
        // "/InvoiceDetail/InvoiceHeader/TransactionAudits/TransactionAudit")
        // .item(0);

        Element eleTransAudit = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/Order");

        if (!YFCCommon.isVoid(eleTransAudit)) {

          // String strTransNumber = eleTransAudit
          // .getAttribute("TransactionNumber");

          String strOrderNumber = eleTransAudit.getAttribute("OrderNo");

          String strSubstring = strOrderNumber.substring(11, 13);
          logger.debug("Sales Terminal Id is ::" + strSubstring);
          Element eleInvExtn = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
              "/InvoiceDetail/InvoiceHeader/Extn");
          eleInvExtn.setAttribute("ExtnTerminalID", strSubstring);

        }

        // Fix for Original Terminal ID -- End -- 4/8/16

        if (!YFCCommon.isStringVoid(strPSASellerOrgCode)) {
          Element eleOrder = (Element) XPathUtil.getNode(docFinalXMLtoTibco.getDocumentElement(),
              "/InvoiceDetail/InvoiceHeader/Order");

          eleOrder.setAttribute("SellerOrganizationCode", strPSASellerOrgCode);
        }

      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsPublishInvoiceForPA.calculateTotalOrderLines");
    }
    return docFinalXMLtoTibco;
  }

  /**
   * @param docInput
   * @return
   */
  public Document getNodeListToRemove(Document docInput) {
    logger.beginTimer("KohlsPublishInvoiceForPA.getNodeListToRemove");
    try {
      logger.beginTimer("---Inside getNodeListToRemove ---");
      if (logger.isDebugEnabled()) {
        logger.debug("Input to getNodeListToRemove is ::" + XMLUtil.getXMLString(docInput));
      }
      /***************************/
      // Added for PSA Credit Card -- To be removed soon-- Start
      // docInput = mockCreditDetailsFromSale(docInput);
      // Added for PSA Credit Card -- To be removed soon-- End
      /****************************/

      if (logger.isDebugEnabled())
        logger.debug(
            "API output of mockCreditDetailsFromSale is ::" + XMLUtil.getXMLString(docInput));

      // Method Call to remove Empty CreditCardElement
      docInput =
          removeCreditCardEmptyElement(docInput, KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
      // Method Call to remove Duplicate Payment Elements
      docInput = removeDuplicatePayments(docInput);

      // Method Call to remove Empty CreditCardElement
      // docInput = removeCreditCardEmptyElement(docInput, KohlsXMLLiterals.E_COLLECITON_DETAIL);

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsPublishInvoiceForPA.getNodeListToRemove");
    }
    return docInput;
  }

  /**
   * @param docInput
   * @param str
   * @return
   */
  public Document removeCreditCardEmptyElement(Document docInput, String str) {
    logger.beginTimer("KohlsPublishInvoiceForPA.removeCreditCardEmptyElement");
    String strAuthTime = null;
    String strTranRequestTime = null;
    NodeList ndlistInput = null;
    try {
      if (str.equalsIgnoreCase(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS)) {
        ndlistInput = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);
        logger.debug("Fetching nodelist of ChargeTransactionDetail");
      } else {
        ndlistInput = XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_COLLECTION_DETAIL);
        logger.debug("Fetching nodelist of CollectionDetails");
      }

      logger.beginTimer("removeCreditCardEmptyElement");
      // Iterate over NodeList of ChargeTransactionDetails
      for (int i = 0; i < ndlistInput.getLength(); i++) {
        // Fetch Current ChargeTransactionDetail element
        Element eleCurrentElement = (Element) ndlistInput.item(i);

        Element eleCreditCardParent =
            (Element) XPathUtil.getNode(eleCurrentElement, KohlsPOCConstant.X_CREDIT_CARD_TRANS);

        if (logger.isDebugEnabled())
          logger.debug("Current ChargeTransactionElement is::"
              + XMLUtil.getElementXMLString(eleCurrentElement));

        if (!YFCCommon.isVoid(eleCreditCardParent)) {

          if (logger.isDebugEnabled())
            logger.debug("Current CreditCard Transactions element is::"
                + XMLUtil.getElementXMLString(eleCreditCardParent));
          int countChild =
              eleCreditCardParent.getElementsByTagName("CreditCardTransaction").getLength();
          logger.debug("CreditCardTransaction nodelist count is :::" + countChild);

          if (countChild == 0) {
            logger
                .debug("No CreditCardTransaction element exists. Removing CreditCardTransactions");
            XMLUtil.removeChild(eleCurrentElement, eleCreditCardParent);
          } else {
            // [START] Defect: 4176 -- Commented the old and added
            // new line
            // Element eleCreditCard = (Element)
            // XPathUtil.getNode(eleCurrentElement,
            // KohlsPOCConstant.X_CREDIT_CARD_TRAN);
            Element eleCreditCard =
                (Element) eleCurrentElement.getElementsByTagName("CreditCardTransaction").item(0);
            // [END] Defect: 4176
            strAuthTime = eleCreditCard.getAttribute("AuthTime");
            strTranRequestTime = eleCreditCard.getAttribute("TranRequestTime");
            logger.debug("AuthTime is " + strAuthTime);
            logger.debug("TranRequestTime is " + strTranRequestTime);
            if (YFCCommon.isStringVoid(strAuthTime) || YFCCommon.isStringVoid(strTranRequestTime)) {
              XMLUtil.removeChild(eleCurrentElement, eleCreditCardParent);
            }

          }

        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    finally {
      logger.endTimer("KohlsPublishInvoiceForPA.removeCreditCardEmptyElement");
    }
    return docInput;
  }

  /**
   * @param docInput
   * @return
   */
  public Document removeDuplicatePayments(Document docInput) {
    logger.beginTimer("KohlsPublishInvoiceForPA.removeDuplicatePayments");
    String strPaymentKey = null;
    try {
      logger.beginTimer("removeDuplicatePayments");
      NodeList ndlChargeTransDetails =
          XPathUtil.getNodeList(docInput, KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAIL);

      // Iterate over ChargeTransactionDetails NodeList
      for (int i = 0; i < ndlChargeTransDetails.getLength(); i++) {
        // Fetch Current ChargeTransactionDetail Element
        Element eleCurrent = (Element) ndlChargeTransDetails.item(i);

        if (logger.isDebugEnabled())
          logger.debug(
              "Current ChargeTransactionElement ::" + XMLUtil.getElementXMLString(eleCurrent));
        Element elePaymentMethod =
            XMLUtil.getChildElement(eleCurrent, KohlsPOCConstant.E_PAYMENT_METHOD);
        if (!(YFCCommon.isVoid(elePaymentMethod))) {
          strPaymentKey = elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);
          logger.debug("Payment Key is" + strPaymentKey);
        }
        if (!YFCCommon.isVoid(strPaymentKey)) {
          for (int j = i + 1; j < ndlChargeTransDetails.getLength(); j++) {
            Element eleNextChargeTrans = (Element) ndlChargeTransDetails.item(j);

            if (logger.isDebugEnabled())
              logger.debug("Comparing with the following chargeTransactionElement"
                  + XMLUtil.getElementXMLString(eleNextChargeTrans));
            Element eleNextPaymentMethod =
                XMLUtil.getChildElement(eleNextChargeTrans, KohlsPOCConstant.E_PAYMENT_METHOD);
            if (!(YFCCommon.isVoid(eleNextPaymentMethod))) {
              String strNextPaymentKey =
                  eleNextPaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY);

              if (!(YFCCommon.isVoid(strNextPaymentKey))
                  && strPaymentKey.equals(strNextPaymentKey)) {
                logger.debug("Removing duplicate child");
                XMLUtil.removeChild(eleNextChargeTrans, eleNextPaymentMethod);
              }
            }
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      logger.endTimer("KohlsPublishInvoiceForPA.removeDuplicatePayments");
    }
    return docInput;

  }

  /**
   * @param env
   * @param inputDoc
   * @return
   */
  public Document removeCollectionOrChargeTranDetails(YFSEnvironment env, Document inputDoc) {
    logger.beginTimer("KohlsPublishInvoiceForPA.removeCollectionOrChargeTranDetails");
    try {
      logger.debug("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails - Start");
      Element eleCollectionDetails = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_COLLECTION_DETAILS)
          .item(0);
      Element eleInvoiceHeader = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER)
          .item(0);
      Element eleInvChargeTrans = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_CHARGE_TRANS_DETAILS)
          .item(0);
      Element eleInvOrder = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.X_INV_ORDER).item(0);
      NodeList nlCollectionDetailsList = eleInvoiceHeader.getElementsByTagName("CollectionDetail");

      String strTotalNo = KohlsPOCConstant.ZERO;
      strTotalNo = eleCollectionDetails.getAttribute("TotalLines");
      if (logger.isDebugEnabled()) {
        logger.debug(
            "nlCollectionDetailsList.getLength() value : " + nlCollectionDetailsList.getLength()
                + "  " + XMLUtil.getElementXMLString(eleCollectionDetails));
      }
      if (nlCollectionDetailsList.getLength() == 0) {
        XMLUtil.removeChild(eleInvoiceHeader, eleCollectionDetails);
      } else {
        XMLUtil.removeChild(eleInvOrder, eleInvChargeTrans);
        XMLUtil.createChild(eleInvOrder, "ChargeTransactionDetails");
      }

    } catch (Exception e) {
      logger.debug(e.getMessage());
    }
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsCreateInputForPSA.removeCollectionOrChargeTranDetails Output"
          + XMLUtil.getXMLString(inputDoc));
    }

    logger.beginTimer("KohlsPublishInvoiceForPA.removeCollectionOrChargeTranDetails");

    return inputDoc;
  }

  /**
   * @param inputDoc
   * @return
   */
  public Document setExternalPaymentAndRemoveKCS(Document inputDoc) {
    logger.beginTimer("KohlsPublishInvoiceForPA.setExternalPaymentAndRemoveKCS");
    String strCheck = null;
    String strCollectionDate = null;
    boolean bKCSMaximized = false;
    try {
      Element eleInvoiceHeader = (Element) XPathUtil
          .getNodeList(inputDoc.getDocumentElement(), KohlsPOCConstant.XPATH_INVOICE_HEADER)
          .item(0);
      NodeList ndlCollectionDetail =
          XPathUtil.getNodeList(inputDoc, KohlsPOCConstant.X_INV_COLLECTION_DETAIL);

      Element eleCollectionDetails =
          (Element) XPathUtil.getNode(inputDoc, KohlsPOCConstant.X_INV_COLLECTION_DETAILS);

      for (int i = 0; i < ndlCollectionDetail.getLength(); i++) {
        Element eleCurrentElement = (Element) ndlCollectionDetail.item(i);
        if (!YFCCommon.isVoid(eleCurrentElement)) {
          if (logger.isDebugEnabled()) {
            logger.debug("Current CollectionDetail Element ::"
                + XMLUtil.getElementXMLString(eleCurrentElement));
          }
          // New fix for CreditCardTransaction after Tendering Changes
          // -- Begin -- 8/8/16

          strCollectionDate = eleCurrentElement.getAttribute("CollectionDate");

          logger.debug("Fetching ExecutionDate to be set ::" + strCollectionDate);

          if (!YFCCommon.isStringVoid(strCollectionDate)) {

            logger.debug("ExecutionDate exists , Explicitly setting it into CollectionDetails"
                + strCollectionDate);
            eleCurrentElement.setAttribute("ExecutionDate", strCollectionDate);
          }

          // New fix for CreditCardTransaction after Tendering Changes
          // -- End -- 8/8/16

          Element elePaymentMethod =
              (Element) XPathUtil.getNode(eleCurrentElement, "PaymentMethod");
          if (!YFCCommon.isVoid(elePaymentMethod)) {
            if (logger.isDebugEnabled()) {
              logger.debug("Current Payment Method Element ::"
                  + XMLUtil.getElementXMLString(elePaymentMethod));
            }
            strCheck = elePaymentMethod.getAttribute("PaymentType");
            logger.debug("Payment Type is ::" + strCheck);
            if (strCheck.equalsIgnoreCase("CREDIT_CARD") || strCheck.equalsIgnoreCase("DEBIT_CARD")
                || strCheck.equalsIgnoreCase("KOHLS_CHARGE_CARD")) {
              logger.debug("Inside External Payment block");
              elePaymentMethod.setAttribute("IsExternalPayment", "P");

            }
            if ("KOHLS_CASH".equalsIgnoreCase(strCheck)) {
              XMLUtil.removeChild(eleCollectionDetails, eleCurrentElement);
              String CollDetsize = eleCollectionDetails.getAttribute("TotalLines");
              Integer int1 = Integer.valueOf(CollDetsize);
              int1--;
              eleCollectionDetails.setAttribute("TotalLines", int1.toString());
              // Fix for PR-439 - Start
              bKCSMaximized = true;
              // Fix for PR-439 - End
            }

          }
        }
      }

    } catch (Exception e) {
      logger.verbose(e);
    }
    logger.endTimer("KohlsPublishInvoiceForPA.setExternalPaymentAndRemoveKCS");
    return inputDoc;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param orderDetail
   * @return
   * @throws Exception
   * 
   *         This method adds the "TaxDetailsList" element on the order.
   */
  private Document MapTaxIndicators(Document orderDetail) throws Exception {
    logger.beginTimer("KohlsPublishInvoiceForPA.MapTaxIndicators");
    if (logger.isDebugEnabled()) {
      logger.debug("orderDetail xml is: " + XMLUtil.getXMLString(orderDetail));
    }
    Double dNetTax = 0.00;
    Double dSubTotal = 0.00;

    Document docTaxDetailsList = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element eleTaxDetailsRoot = docTaxDetailsList.getDocumentElement();

    HashMap<Double, String> mapTaxDetails_Return = new HashMap<Double, String>();
    HashMap<Double, String> mapTaxDetails_Sale = new HashMap<Double, String>();

    DecimalFormat df = new DecimalFormat("#0.00");

    String sTaxIndicatorRepo_Return = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    String sTaxIndicatorRepo_Sale = "123456789";

    Element eleOrderExtn =
        (Element) XPathUtil.getNode(orderDetail, "/InvoiceDetail/InvoiceHeader/Order/Extn");

    NodeList nlOrderLine = orderDetail.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    if (!YFCCommon.isVoid(nlOrderLine) && nlOrderLine.getLength() > 0) {
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        double dUnitPrice = 0.00D;
        double dTaxPercent = 0.00D;
        double dTax = 0.00D;
        double dKohlsCashUnearned = 0.00D;
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        if (logger.isDebugEnabled()) {
          logger.debug("OrderLine element is: " + XMLUtil.getElementXMLString(eleOrderLine));
        }
        String sType = eleOrderLine.getAttribute("Type");
        Element eleCustomAttributes =
            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
        if (YFCCommon.isVoid(eleCustomAttributes)) {
          continue;
        }
        Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
        String sExtnTaxbleAmount =
            eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);

        String sExtnReturnPrice =
            eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
        Double dExtnReturnPrice = 0.00;
        Double dTotalFeePerLine = 0.0;
        if (!YFCCommon.isVoid(sExtnReturnPrice)) {
        	Element eleOrderLineCharges = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES, true);
        	if(!YFCCommon.isVoid(eleOrderLineCharges)){
        		NodeList nlCharges  = eleOrderLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
        		if(!YFCCommon.isVoid(nlCharges) && nlCharges.getLength()>0){
        			for (int iCharge = 0; iCharge < nlCharges.getLength(); iCharge++) {
        				Element eleCharge = (Element) nlCharges.item(iCharge);
        				if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))){
        					Element eleChargeExtn = XMLUtil.getChildElement(eleCharge, KohlsPOCConstant.E_EXTN);
        					String strChargePerLine = XMLUtil.getAttribute(eleCharge, KohlsPOCConstant.A_CHARGE_PER_LINE);
        					String strExtnOrigChgPerLine = XMLUtil.getAttribute(eleChargeExtn, "ExtnOrigChgPerLine");
        					if(!YFCCommon.isVoid(strExtnOrigChgPerLine) && !YFCCommon.isVoid(strChargePerLine)){
        						//totalAdjFeePerLine = Double.parseDouble(strExtnOrigChgPerLine)- Double.parseDouble(strChargePerLine);
        						dTotalFeePerLine = dTotalFeePerLine +  Double.parseDouble(strChargePerLine);
        					}else if(YFCCommon.isVoid(eleChargeExtn)){
        						eleOrderLineCharges.removeChild(eleCharge);
        						iCharge--;
        					}
        				}
        			}
        		}
        	}
          dExtnReturnPrice = Double.parseDouble(sExtnReturnPrice);
          if ("Sale".equals(sType)) {
            dSubTotal = dSubTotal + dExtnReturnPrice + dTotalFeePerLine;
          } else {
            dSubTotal = dSubTotal - dExtnReturnPrice - dTotalFeePerLine;
          }
        }

        /*
         * NodeList nlLineCharge =
         * eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE); for(int j=0;
         * j<nlLineCharge.getLength(); j++){ Element eleLineCharge = (Element)nlLineCharge.item(j);
         * String sChargeCategory =
         * eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
         * if("KohlsCashUnearned".equalsIgnoreCase(sChargeCategory)){ dKohlsCashUnearned =
         * dKohlsCashUnearned +
         * Double.parseDouble(eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE)); } }
         */

        NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_TAX);
        for (int j = 0; j < nlLineTax.getLength(); j++) {
          Element eleLineTax = (Element) nlLineTax.item(j);
          String sTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
          String sTaxPercent = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT);
          Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, KohlsPOCConstant.E_EXTN);
          if (!YFCCommon.isVoid(eleLineTaxExtn)) {
            dTax = dTax + Double.parseDouble(sTax);
            if ("Sale".equals(sType)) {
              dNetTax = dNetTax + dTax;
            } else {
              dNetTax = dNetTax - dTax;
            }
          }
          if (!YFCCommon.isVoid(sTaxPercent)) {
            dTaxPercent = dTaxPercent + Double.parseDouble(sTaxPercent);
            if ("Sale".equals(sType)) {
              dTaxPercent = dTaxPercent / 100;
            }
          }
        }
        if (!YFCCommon.isVoid(sExtnTaxbleAmount)) {
          //dUnitPrice = dUnitPrice + Double.parseDouble(sExtnTaxbleAmount);
          dUnitPrice = dUnitPrice + Double.parseDouble(sExtnTaxbleAmount);
        }
        // setting map for Sale
        if ("Return".equals(sType)) {
          if (mapTaxDetails_Return.containsKey(dTaxPercent)) {
            String[] sTemp = mapTaxDetails_Return.get(dTaxPercent).split("_");
            double dTax_Temp = Double.parseDouble(sTemp[0]);
            double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
            String sTaxIndicator = sTemp[2];
            mapTaxDetails_Return.remove(dTaxPercent);
            mapTaxDetails_Return.put(dTaxPercent, df.format(dTax_Temp - dTax) + "_"
                + df.format(dTaxableAmount_Temp - dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          } else {
            String sTaxIndicator;
            if (0.00 == dTaxPercent) {
              sTaxIndicator = "#";
            } else {
              sTaxIndicator = String.valueOf(sTaxIndicatorRepo_Return.charAt(0));
              sTaxIndicatorRepo_Return = sTaxIndicatorRepo_Return.substring(1);
            }
            mapTaxDetails_Return.put(dTaxPercent,
                df.format(0 - dTax) + "_" + df.format(0 - dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          }
        } else {
          if (mapTaxDetails_Sale.containsKey(dTaxPercent)) {
            String[] sTemp = mapTaxDetails_Sale.get(dTaxPercent).split("_");
            double dTax_Temp = Double.parseDouble(sTemp[0]);
            double dTaxableAmount_Temp = Double.parseDouble(sTemp[1]);
            String sTaxIndicator = sTemp[2];
            mapTaxDetails_Sale.remove(dTaxPercent);
            mapTaxDetails_Sale.put(dTaxPercent, df.format(dTax_Temp + dTax) + "_"
                + df.format(dTaxableAmount_Temp + dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          } else {
            String sTaxIndicator;
            if (0.00 == dTaxPercent) {
              sTaxIndicator = "#";
            } else {
              sTaxIndicator = "T" + String.valueOf(sTaxIndicatorRepo_Sale.charAt(0));
              sTaxIndicatorRepo_Sale = sTaxIndicatorRepo_Sale.substring(1);
            }
            mapTaxDetails_Sale.put(dTaxPercent,
                df.format(dTax) + "_" + df.format(dUnitPrice) + "_" + sTaxIndicator);
            eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR, sTaxIndicator);
          }
        }

      }
    }

    // Forming Tax details for Sale
    if (mapTaxDetails_Sale.size() > 0) {
      for (Double dTaxPercent : mapTaxDetails_Sale.keySet()) {
        Element eleTaxDetail =
            XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE,
            String.valueOf(dTaxPercent));
        String sTemp[] = mapTaxDetails_Sale.get(dTaxPercent).split("_");
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
      }
    }

    // Forming Tax details for Return
    if (mapTaxDetails_Return.size() > 0) {
      for (Double dTaxPercent : mapTaxDetails_Return.keySet()) {
        Element eleTaxDetail =
            XMLUtil.createChild(eleTaxDetailsRoot, KohlsPOCConstant.E_TAX_DETAIL);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_EFFECTIVE_TAX_RATE,
            String.valueOf(dTaxPercent));
        String sTemp[] = mapTaxDetails_Return.get(dTaxPercent).split("_");
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, sTemp[0]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, sTemp[1]);
        eleTaxDetail.setAttribute(KohlsPOCConstant.A_TAX_INDICATOR, sTemp[2]);
      }
    }

    eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
        XMLUtil.getElementXMLString(eleTaxDetailsRoot));
    Element eleOrder =
        (Element) XPathUtil.getNode(orderDetail, "/InvoiceDetail/InvoiceHeader/Order");
    Element eleTaxDetailList =
        XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_TAX_DETAIL_LIST);
    if (!YFCCommon.isVoid(eleTaxDetailList)) {
      eleOrder.removeChild(eleTaxDetailList);
    }
    Element eleTaxDetailsRoot_Temp = (Element) orderDetail.importNode(eleTaxDetailsRoot, true);
    eleOrder.appendChild(eleTaxDetailsRoot_Temp);

    Element eleInvoiceHeader =
        (Element) XPathUtil.getNode(orderDetail, "/InvoiceDetail/InvoiceHeader");
    eleInvoiceHeader.setAttribute("TotalTax", new DecimalFormat("#0.00").format(dNetTax));
    eleInvoiceHeader.setAttribute("LineSubTotal", new DecimalFormat("#0.00").format(dSubTotal));

    if (logger.isDebugEnabled()) {
      logger.debug("End of taxDetailsList logicccc" + XMLUtil.getXMLString(orderDetail));
    }
    logger.endTimer("KohlsPublishInvoiceForPA.MapTaxIndicators");
    return orderDetail;
  }


  /**
   * @param docInvoiceDetails
   * @return
   */
  private Document removeOrderPromotions(Document docInvoiceDetails) {
    logger.beginTimer("KohlsPublishInvoiceForPA.removeOrderPromotions");
    Element elePromotions = XMLUtil.getChildElement(docInvoiceDetails.getDocumentElement(),
        KohlsPOCConstant.E_PROMOTIONS);
    if (!YFCCommon.isVoid(elePromotions)) {
      NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        if ("KOHLS_CASH_UNEARNED".equalsIgnoreCase(sPromotionType)
            || "KOHLS_CASH_REISSUE".equalsIgnoreCase(sPromotionType)) {
          continue;
        }
        elePromotions.removeChild(elePromotion);
      }
    }
    logger.endTimer("KohlsPublishInvoiceForPA.removeOrderPromotions");
    return docInvoiceDetails;
  }

  /**
   * @param env
   * @param inDoc
   * @return
   * @throws SAXException
   * @throws IOException
   * @throws Exception
   */
  public Document postVoid(YFSEnvironment env, Document inDoc)
      throws SAXException, IOException, Exception {
    logger.beginTimer("KohlsPublishInvoiceForPA.postVoid");

    Element eleAddtionalInfo =
        XMLUtil.getChildElement(inDoc.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
    if (!YFCCommon.isVoid(eleAddtionalInfo) && eleAddtionalInfo.hasAttributes()) {
      endpoint = XMLUtil.getAttribute(eleAddtionalInfo, KohlsXMLLiterals.A_ENDPOINT);
    }
    Element eleOrderInvoice;
    eleOrderInvoice = getOrderInvoice(env, inDoc);

    if (logger.isDebugEnabled()) {
      logger.debug("output of getOrderInvoice" + XMLUtil.getElementXMLString(eleOrderInvoice));
    }


    String sOrderNo = eleOrderInvoice.getAttribute("OrderNo");
    String sOHKey = eleOrderInvoice.getAttribute("OrderHeaderKey");
    String sModifyts = eleOrderInvoice.getAttribute("Modifyts");
    YFCDate date = new YFCDate();
    String sCreateTimeStamp = date.getString(null, true);

    Document docOutputInvDetail = null;
    // try {

    // Create the output document and set the required attributes.

    docOutputInvDetail =
        YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
    Element eleInvoiceDetail = docOutputInvDetail.getDocumentElement();
    eleInvoiceDetail.setAttribute("MessageType", "PriceAdjustmentPostVoid");
    eleInvoiceDetail.setAttribute("Postvoid", "Y");
    eleInvoiceDetail.setAttribute("Modifyts", sModifyts);
    eleInvoiceDetail.setAttribute("CreateTimeStamp", sCreateTimeStamp);
    Element eleInvHeader = XMLUtil.createChild(eleInvoiceDetail, "InvoiceHeader");


    // code added for defect:1531 on 05/02/2014.
    Element eleInOrder = inDoc.getDocumentElement();
    String sSellerOrgCode = eleInOrder.getAttribute("SellerOrganizationCode");
    Element elePromotions =
        (Element) (XPathUtil.getNodeList(eleInOrder, "/Order/Promotions").item(0));
    String sPromotionApplied = null;
    Element elePromotion = null;
    Element eleExtn = null;
    NodeList nlPromotion = XPathUtil.getNodeList(eleInOrder, "/Order/Promotions/Promotion");
    if (!YFCCommon.isVoid(nlPromotion)) {
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        elePromotion = (Element) nlPromotion.item(i);
        eleExtn = (Element) elePromotion.getElementsByTagName("Extn").item(0);
        String sExtnActivationBarCode = eleExtn.getAttribute("ExtnActivationBarCode");
        sPromotionApplied = elePromotion.getAttribute("PromotionApplied");
        String sPromotionType = elePromotion.getAttribute("PromotionType");
        if ("KOHLS_CASH_EARNED".equalsIgnoreCase(sPromotionType)
            && !YFCCommon.isVoid(sExtnActivationBarCode)) {
          sPromotionApplied = "Y";
          elePromotion.setAttribute("PromotionApplied", "Y");
        }
        if ("N".equalsIgnoreCase(sPromotionApplied)) {
          elePromotions.removeChild(elePromotion);
        }
      }
    }

    /*
     * invoke getTransactionAuditList API to get Transaction audits and append it to InvoiceDetail
     * node.
     */
    Document inTranDoc = YFCDocument.createDocument("TransactionAudit").getDocument();
    Element eleInput = inTranDoc.getDocumentElement();
    eleInput.setAttribute("OrderNumber", sOrderNo);
    eleInput.setAttribute("ProcedureID", "10103");
    eleInput.setAttribute("OrganizationCode", sSellerOrgCode);
    Document orderListDocOutput =
        invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
            "getTransactionAuditListForPOS", inTranDoc);
    NodeList nlElements = orderListDocOutput.getElementsByTagName("TransactionAudit");
    if (nlElements.getLength() > 0) {
      Element tranAudit = (Element) nlElements.item(0);
      tranAudit.setAttribute(KohlsPOCConstant.ATTR_MODIFYTS, sModifyts);
      Element eleTranAudits = XMLUtil.createChild(eleInvHeader, "TransactionAudits");
      XMLUtil.importElement(eleTranAudits, tranAudit);
    }
    Element eleOrder = (Element) eleInOrder.cloneNode(false);
    Element eleOrerExtn = XMLUtil.createChild(eleOrder, "Extn");
    Element eleOrigOrderExtn = (Element) eleInOrder.getElementsByTagName("Extn").item(0);
    eleOrerExtn.setAttribute("ExtnRegisterBankNumber",
        eleOrigOrderExtn.getAttribute("ExtnRegisterBankNumber"));
    XMLUtil.importElement(eleInvHeader, eleOrder);


    // }
    /*
     * catch (Exception e){ if (e instanceof YFSException) { YFSException yfsException =
     * (YFSException) e; throw yfsException; } else{ throw new YFSException(e.getMessage()); } }
     */
    logger.endTimer("KohlsPublishInvoiceForPA.postVoid");
    return docOutputInvDetail;
  }


  private Element getOrderInvoice(YFSEnvironment env, Document inDoc)
      throws SAXException, IOException, Exception {
    logger.beginTimer("KohlsPublishInvoiceForPA.getOrderInvoice");
    Element eleOrder = inDoc.getDocumentElement();

    String sOrderHeaderKey = eleOrder.getAttribute("OrderHeaderKey");
    Document docGetOrderInvoiceListInput = XMLUtil.createDocument("OrderInvoice");
    Element eleGetOrderInvoiceListInput = docGetOrderInvoiceListInput.getDocumentElement();

    addEndpointToElement(eleGetOrderInvoiceListInput);

    eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
    Document docGetOrderInvoiceListOutput =
        invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_TEMPLATE),
            KohlsPOCConstant.API_GET_ORDER_INVOICE_LIST, docGetOrderInvoiceListInput);
    Element eleGetOrderInvoiceListOutput = docGetOrderInvoiceListOutput.getDocumentElement();
    logger.endTimer("KohlsPublishInvoiceForPA.getOrderInvoice");
    return XMLUtil.getChildElement(eleGetOrderInvoiceListOutput, "OrderInvoice");
  }

  /**
   * check isEdge deployment and setting the document with endpoint
   */
  public void addEndpointToElement(Element finalEle) throws ParserConfigurationException

  {
    logger.debug("Before Adding edge ::" + ServerTypeHelper.amIOnEdgeServer());
    if (ServerTypeHelper.amIOnEdgeServer()) {
      Element eleAdditionalInfo =
          SCXmlUtil.createChild(finalEle, KohlsXMLLiterals.E_YFCADDITIONALINFO);
      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, endpoint);
    }
    logger.debug("Before Adding edge ::" + XMLUtil.getElementXMLString(finalEle));

  }
}
