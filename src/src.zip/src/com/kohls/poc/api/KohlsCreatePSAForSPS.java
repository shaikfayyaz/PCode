package com.kohls.poc.api;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

/**
 * This wrapper API handles Post Sale Adjustment (PSA) and Price Adjustment (PA) from SPS.
 */
public class KohlsCreatePSAForSPS {

    private static final YFCLogCategory log = YFCLogCategory.instance(KohlsCreatePSAForSPS.class.getName());


    /**
     * This in the point of invocation for SPS PSA. This method imports the OriginalOrder based on the OTR, applies the
     * PSA and creates the receiptData.
     *
     * @param env
     * @param inXML
     * @throws Exception
     */
    public void invoke(YFSEnvironment env, Document inXML) throws Exception {

        log.beginTimer("KohlsCreatePSAForSPS.invoke");
        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.invoke Method - " + KohlsXMLUtil.getXMLString(inXML));
        }

        /* Initialize variables */
        Element elePSAOrder = null;
        Element eleOrgOrder = null;
        String strOrderNo = null;
        String strOriginalOrderNo = null;
        String strIsVoidDuring = null;
        boolean bIsPOCOrder = false;

        /* Get the root element */
        Element eleRoot = inXML.getDocumentElement();
        String strIsPA = eleRoot.getAttribute("IsPA");

        /* Get the original order and PSA order */
        NodeList nlOrder = eleRoot.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);

        try {
        /* Loop through the input xml from SPS to retrieve the Original Order Details and PSA/PA details */
            if (!YFCCommon.isVoid(nlOrder)) {
                for (int i = 0; i < nlOrder.getLength(); i++) {
                    Element eleTemp = (Element) nlOrder.item(i);
                    if (KohlsPOCConstant.SALE.equalsIgnoreCase(KohlsXMLUtil.getAttribute(eleTemp, KohlsPOCConstant.A_TYPE))) {
                        elePSAOrder = eleTemp;
                    } else if (KohlsPOCConstant.RETURN.equalsIgnoreCase(KohlsXMLUtil.getAttribute(eleTemp, KohlsPOCConstant.A_TYPE))) {
                        eleOrgOrder = eleTemp;
                    }
                }
            }
            if (log.isDebugEnabled()) {
                log.debug("Original Sale :" + KohlsXMLUtil.getElementXMLString(eleOrgOrder)
                        + "\nPSA Sale :" + KohlsXMLUtil.getElementXMLString(elePSAOrder));
            }
            Element eleExtn = KohlsXMLUtil.getChildElement(elePSAOrder, KohlsPOCConstant.A_EXTN);

            /* Verify if the PSA/PA is a mid void scenario */
            if (!YFCCommon.isVoid(eleExtn)) {
                strIsVoidDuring = KohlsXMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
            }

            env.setTxnObject(KohlsPOCConstant.SOURCE_SYSTEM, "SPS");

            String strPSAStatus = eleExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
            /* Verify if the original sale order is a POC/SPS or POS order */
            if (!YFCCommon.isVoid(eleOrgOrder)) {

                String strOriginalSalesData = KohlsXMLUtil.getChildElement(eleOrgOrder, KohlsPOCConstant.A_EXTN).getAttribute(
                        KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);

                /* Invoke getOrderList to fetch order details from OMSr*/
                Document docGetOrderListOut = invokeGetOrderList(env, strOriginalSalesData);
                Element eleTemp = KohlsXMLUtil.getChildElement(docGetOrderListOut.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);

                /*If the order details are present for the ReceiptID, then the order is a SPS/POC order otherwise generate the orderNo */
                if (!YFCCommon.isVoid(eleTemp) && !YFCCommon.isVoid(elePSAOrder)) {
                    /* Get PSA Order No */
                    strOriginalOrderNo = eleTemp.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
                    strOrderNo = strOriginalOrderNo + KohlsPOCConstant.UNDERSCORE
                            + elePSAOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
                    bIsPOCOrder = true;
                } else {
                	KohlsTranslateOTRResponse translateOTR = new KohlsTranslateOTRResponse();
                    strOriginalOrderNo = translateOTR.getOrderNo(env, eleOrgOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE),
                            eleOrgOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE),
                            eleOrgOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID), eleOrgOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));
                    strOrderNo = strOriginalOrderNo + KohlsPOCConstant.UNDERSCORE
                            + elePSAOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);

                }

                /*Invoke importOrder to create POS order in OMS */
                eleOrgOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOrderNo);
                Element eleImportOrder = invokeImportOrder(env, eleOrgOrder);

                /* Invoke changeOrder APi and update the PSA status on the Original order as Completed
                so that POC will not be apply to PSA on the order again */
                if (!YFCCommon.isVoid(strPSAStatus) && !KohlsPOCConstant.PSA_VOIDED_STATUS.equals(strPSAStatus)
                        && !"PA_MIDVOID".equals(strPSAStatus) && bIsPOCOrder) {
                    Document docChangeOrder = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
                    Element eleStaging = docChangeOrder.getDocumentElement();
                    eleStaging.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOriginalOrderNo);
                    eleStaging.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.KOHLS_RETAIL);
                    eleStaging.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.SO_DOCUMENT_TYPE);
                    Element eleStagingExtn = KohlsXMLUtil.createChild(eleStaging, KohlsPOCConstant.E_EXTN);
                    if (!YFCCommon.isVoid(strIsPA) && KohlsPOCConstant.YES.equals(strIsPA)) {
                        eleStagingExtn.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, "PA_COMPLETED");
                    } else {
                        eleStagingExtn.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, KohlsPOCConstant.PSA_COMPLETED_STATUS);
                    }
                    invokeChangeOrder(env, eleStaging, KohlsPOCConstant.BLANK);
                }
                /* Apply PSA on the Order */
                elePSAOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOrderNo);

                /* The RecalculateLineTaxUE calculates and applies the negative tax based on the LineTax element stored in 'DELTA_TAX'
                env object. This object is generated by gravity, so below code replicates the generation on the DELTA_TAX. Also for PSA/PA
                the tax difference is stored as LineTax/@Tax in DELTA_TAX. Since LineTax/@Tax cannot be negative in sterling input.
                LineTax/@tax is used to store the negative tax amount */
                invokeSetDeltaTax(env, eleImportOrder, elePSAOrder);

                /* The original sale order details are stored in KOHLS_SALES_FOR_PSA table. The value stored in this table is later used
                during invoicing and for replacing the order changes during mid void */
                invokeKohlsSaleForPSA(env, eleImportOrder, eleImportOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY), strIsPA);

                /* Insert Record into transaction Audit table */
                invokeManageTransactionAuditForPOS(env, elePSAOrder, eleImportOrder.getAttribute("OriginalTotalAmount"),
                        strIsPA, strIsVoidDuring);

                /* This changeOrder invocation applies the PSA/PA changes to imported order. The changes in the LineCharges will
                cause a CREDIT_MEMO to be generated */
                invokeChangeOrder(env, elePSAOrder, strIsVoidDuring);

                /* Create receipt Data  */
                invokeManageReceiptDataForPOS(env, KohlsXMLUtil.getChildElement(eleRoot, KohlsPOCConstant.ELE_RECEIPT_DATA), elePSAOrder);
            }
        } catch (Exception e) {
            log.error(e);
            throw e;
        }
        log.endTimer("KohlsCreatePSAForSPS.invoke");

    }


    /**
     * This method invokes getOrderList API
     *
     * @param env
     * @param strReceiptID
     */
    private Document invokeGetOrderList(YFSEnvironment env, String strReceiptID) throws Exception {

        log.beginTimer("KohlsCreatePSAForSPS.invokeGetOrderList");

        /* Initialize the variables */
        String strTemplate = "<OrderList><Order OrderNo=''/></OrderList>";

        /* Prepare input XML for getOrderList API */
        Document docGetOrderListIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleGetOrder = docGetOrderListIn.getDocumentElement();

        eleGetOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.SO_DOCUMENT_TYPE);
        eleGetOrder.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.KOHLS_RETAIL);
        Element eleExtn = KohlsXMLUtil.createChild(eleGetOrder, KohlsPOCConstant.E_EXTN);
        eleExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID, strReceiptID);

        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.getOrderList API - " + KohlsXMLUtil.getXMLString(docGetOrderListIn));
        }

        /* Invoke getOrderList API */
        Document docGetOrderListOut = KOHLSBaseApi.invokeAPI(env, KohlsXMLUtil.getDocument(strTemplate),
                KohlsPOCConstant.API_GET_ORDER_LIST, docGetOrderListIn);

        if (log.isDebugEnabled()) {
            log.debug("Output XML from KohlsCreatePSAForSPS.getOrderList API - " + KohlsXMLUtil.getXMLString(docGetOrderListOut));
        }
        log.endTimer("KohlsCreatePSAForSPS.invokeGetOrderList");
        return docGetOrderListOut;
    }

    /**
     * This method invokes importOrder API
     *
     * @param env
     * @param eleOrder
     */
    private Element invokeImportOrder(YFSEnvironment env, Element eleOrder) throws Exception {
        log.beginTimer("KohlsCreatePSAForSPS.invokeImportOrder");

        /* Initialize the variables */
        NodeList nlOrderLines = null;
        int iCount = 0;

        Element eleOrderLines = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);

        if (!YFCCommon.isVoid(eleOrderLines)) {
            nlOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
        }

        if (!YFCCommon.isVoid(nlOrderLines)) {
            iCount = nlOrderLines.getLength();
        }

        /* Loop through each order line and set the pipeline id */
        for (int i = 0; i < iCount; i++) {
            Element eleOrderLine = (Element) nlOrderLines.item(i);
            eleOrderLine.setAttribute("PipelineId", "POS_Simple_Sales_Pipeline");
            eleOrderLine.setAttribute("PipelineOwnerKey", "DEFAULT");
        }

        /* Prepare the input document for importOrder API */
        Document docImportOrder = KohlsXMLUtil.getDocumentForElement(eleOrder);

        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.importOrder API - " + KohlsXMLUtil.getXMLString(docImportOrder));
        }

        /* Invoke importOrder API */
        Document docImportOrderOut = KOHLSBaseApi.invokeAPI(env, "/global/template/api/POC/sps/MPOC_importOrder_PA_PSA.xml", KohlsPOCConstant.IMPORT_ORDER_API, docImportOrder);

        if (log.isDebugEnabled()) {
            log.debug("Output XML from KohlsCreatePSAForSPS.importOrder API - " + KohlsXMLUtil.getXMLString(docImportOrderOut));
        }

        log.endTimer("KohlsCreatePSAForSPS.invokeImportOrder");
        return docImportOrderOut.getDocumentElement();

    }

    /**
     * This method invokes changeOrder API
     *
     * @param env
     * @param eleOrder
     */
    private void invokeChangeOrder(YFSEnvironment env, Element eleOrder, String strIsVoidDuring) throws Exception {

        log.beginTimer("KohlsCreatePSAForSPS.invokeChangeOrder");
        /* Initialize the variables */
        Document docMidVoidChangeOrder = null;
        Boolean bIsChangeOrder = false;

        /* Prepare the input document for importOrder API */
        eleOrder.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);

        /*For a midvoid scenario, Invoices are published when the Extn/@ExtnPsaStatus is 'VOIDED'. The promotions if present
        * need to be applied and then removed to be data collected properly.*/
        if (!YFCCommon.isVoid(strIsVoidDuring) && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {
            Element elePromotions = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
            if (!YFCCommon.isVoid(elePromotions)) {
                docMidVoidChangeOrder = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
                Element eleMidVoidRoot = docMidVoidChangeOrder.getDocumentElement();
                eleMidVoidRoot.setAttribute(KohlsPOCConstant.SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
                eleMidVoidRoot.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
                eleMidVoidRoot.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.SO_DOCUMENT_TYPE);
                eleMidVoidRoot.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.KOHLS_RETAIL);
                Element eleMidRootExtn = KohlsXMLUtil.createChild(eleMidVoidRoot, KohlsPOCConstant.E_EXTN);
                eleMidRootExtn.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, KohlsPOCConstant.PSA_VOIDED_STATUS);
                NodeList nlPromotions = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
                Element eleMidVoidPromotions = KohlsXMLUtil.createChild(eleMidVoidRoot, KohlsPOCConstant.E_PROMOTIONS);
                int iCount = 0;
                if (!YFCCommon.isVoid(nlPromotions)) {
                    iCount = nlPromotions.getLength();
                }
                for (int i = 0; i < iCount; i++) {
                    Element elePromotion = (Element) nlPromotions.item(i);
                    if (KohlsPOCConstant.REMOVE.equals(elePromotion.getAttribute(KohlsPOCConstant.ACTION))) {
                        KohlsXMLUtil.importElement(eleMidVoidPromotions, elePromotion);
                        elePromotion.removeAttribute(KohlsPOCConstant.ACTION);
                        bIsChangeOrder = true;
                    }
                }
                KohlsXMLUtil.appendChild(eleMidVoidRoot, eleMidVoidPromotions);
            }

            if (bIsChangeOrder) {
                KohlsXMLUtil.removeAttribute(KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN),
                        KohlsPOCConstant.EXTN_PSA_STATUS);
            }
        }
        Document docChangeOrder = KohlsXMLUtil.getDocumentForElement(eleOrder);

        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.changeOrder API - " + KohlsXMLUtil.getXMLString(docChangeOrder));
        }

        /* Invoke changeOrder API */
        Document docChangeOrderOut = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, docChangeOrder);

        if (log.isDebugEnabled()) {
            log.debug("Output XML from KohlsCreatePSAForSPS.changeOrder API - " + KohlsXMLUtil.getXMLString(docChangeOrderOut));
        }

        /* If the xml is a mid void xml, then changeOrder is invoked again to remove the Promotions and move the imported order
        * status to VOIDED */
        if (bIsChangeOrder) {
            if (log.isDebugEnabled()) {
                log.debug("Input XML to KohlsCreatePSAForSPS.changeOrder API - " + KohlsXMLUtil.getXMLString(docMidVoidChangeOrder));
            }

            /* Invoke changeOrder API */
            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, docMidVoidChangeOrder);
        }
        log.endTimer("KohlsCreatePSAForSPS.invokeChangeOrder");
    }

    /**
     * The RecalculateLineTaxUE calculates and applies the negative tax based on the LineTax element stored in 'DELTA_TAX'
     * env object. This object is generated by gravity, so below code replicates the generation on the DELTA_TAX. Also for PSA/PA
     * the tax difference is stored as LineTax/@Tax in DELTA_TAX. Since LineTax/@Tax cannot be negative in sterling input.
     * LineTax/@tax is used to store the negative tax amount
     *
     * @param env
     * @param eleImportOrder
     * @param elePSAOrder
     */
    private void invokeSetDeltaTax(YFSEnvironment env, Element eleImportOrder, Element elePSAOrder) {

        log.beginTimer("KohlsCreatePSAForSPS.invokeSetDeltaTax");
        /* Initialize Variables */
        Element eleOrderLines = null;
        NodeList nlOrderLines = null;
        NodeList nlPSAOrderLines = null;
        Map<String, String> orderLineMap = new HashMap<>();
        Map<String, List<Element>> lineTaxMap = new HashMap<>();
        int iCount = 0;

         /* Loop through the import order and map the primelineNos with orderlinekeys generated during importOrder */
        if (!YFCCommon.isVoid(eleImportOrder)) {
            eleOrderLines = KohlsXMLUtil.getChildElement(eleImportOrder, KohlsPOCConstant.ELEM_ORDER_LINES);
        }

        if (!YFCCommon.isVoid(eleOrderLines)) {
            nlOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
        }

        if (!YFCCommon.isVoid(nlOrderLines)) {
            iCount = nlOrderLines.getLength();
        }

        /* Create a  the primelineno-orderlinekey map */
        for (int i = 0; i < iCount; i++) {
            Element eleOrderLine = (Element) nlOrderLines.item(i);
            String strOrderLineKey = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
            orderLineMap.put(eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO), strOrderLineKey);
        }

        /* Loop through a PSA OrderLines */
        eleOrderLines = KohlsXMLUtil.getChildElement(elePSAOrder, KohlsPOCConstant.ELEM_ORDER_LINES);

        if (!YFCCommon.isVoid(eleOrderLines)) {
            nlPSAOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
        }

        if (!YFCCommon.isVoid(nlPSAOrderLines)) {
            iCount = nlPSAOrderLines.getLength();
        }

            /* Add the orderline key to map */
        for (int i = 0; i < iCount; i++) {
            Element eleOrderLine = (Element) nlPSAOrderLines.item(i);
            String strOrderLineKey = orderLineMap.get(eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
            Element eleLineTaxes = KohlsXMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);
            NodeList nlLineTax = eleLineTaxes.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
            int taxCount = 0;

            if (!YFCCommon.isVoid(nlLineTax)) {
                taxCount = nlLineTax.getLength();
            }

            Element eleNewLineTaxes = KohlsXMLUtil.createChild(eleOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);
            eleNewLineTaxes.setAttribute("XMLDiff_changed", KohlsPOCConstant.YES);

            for (int j = 0; j < taxCount; j++) {
                Element eleLineTax = (Element) nlLineTax.item(j);
                String strTax = eleLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, eleLineTax.getAttribute(KohlsPOCConstant.SMALL_TAX));
                KohlsXMLUtil.importElement(eleNewLineTaxes, eleLineTax);
                eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, strTax);
            }

            List<Element> newList = new ArrayList<>();
            newList.add(eleNewLineTaxes);
            lineTaxMap.put(strOrderLineKey, newList);
        }

        env.setTxnObject(KohlsPOCConstant.TXN_DELTATAX, lineTaxMap);
        log.endTimer("KohlsCreatePSAForSPS.invokeSetDeltaTax");
    }

    /**
     * This method invokes KohlsSaveSalesDetails Service
     *
     * @param env
     * @param eleOrder
     * @param strOrderHeaderKey
     */
    private void invokeKohlsSaleForPSA(YFSEnvironment env, Element eleOrder, String strOrderHeaderKey, String strIsPA) throws Exception {

        log.beginTimer("KohlsCreatePSAForSPS.invokeKohlsSaleForPSA");
        Document docKohlsSaleForPSA = KohlsXMLUtil.createDocument("KOHLSSalesForPsa");
        Element eleKOHLSSalesForPsa = docKohlsSaleForPSA.getDocumentElement();
        String strOrder = KohlsXMLUtil.getElementXMLString(eleOrder);
        eleKOHLSSalesForPsa.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
        eleKOHLSSalesForPsa.setAttribute(KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID, strOrderHeaderKey);
        eleKOHLSSalesForPsa.setAttribute("OriginalSaleData", strOrder);
        if(!YFCCommon.isVoid(strIsPA) && KohlsPOCConstant.YES.equals(strIsPA)) {
            eleKOHLSSalesForPsa.setAttribute("PSAData", strOrder);
        }

        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.KohlsPoCUpdateOrigSaleData Service - " + KohlsXMLUtil.getXMLString(docKohlsSaleForPSA));
        }

        /* Invoke KohlsPoCUpdateOrigSaleData API */
        KOHLSBaseApi.invokeService(env, "KohlsPoCUpdateOrigSaleData", docKohlsSaleForPSA);
        log.endTimer("KohlsCreatePSAForSPS.invokeKohlsSaleForPSA");
    }

    /**
     * This method will be used to publish Receipt data to downstream systems.
     * manageReceiptDataForPOS :
     *
     * @param env
     * @param eleOrder
     * @param eleReceiptData
     * @throws Exception
     */
    private void invokeManageReceiptDataForPOS(YFSEnvironment env, Element eleReceiptData, Element eleOrder) throws Exception {

        log.beginTimer("KohlsCreatePSAForSPS.invokeManageReceiptDataForPOS");
        /* Prepare the input document for manageReceiptDataForPOS API */
        if (!YFCCommon.isVoid(eleReceiptData) && !YFCCommon.isVoid(eleOrder)) {
            if (!YFCCommon.isVoid(eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE)))
                eleReceiptData.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
                        eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
        }
        Document docManageReceiptData = KohlsXMLUtil.getDocumentForElement(eleReceiptData);

        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.manageReceiptDataForPOS API - " +
                    KohlsXMLUtil.getXMLString(docManageReceiptData));
        }

        /* Invoke manageReceiptDataForPOS API */
        KOHLSBaseApi.invokeAPI(env, "manageReceiptDataForPOS", docManageReceiptData);
        log.endTimer("KohlsCreatePSAForSPS.invokeManageReceiptDataForPOS");
    }

    /**
     * This method will create Input and call manageTransactionAuditForPOS, to publish audit information to downstream systems.
     * manageTransactionAuditForPOS input xml :
     *
     * @param env
     * @param eleOrder
     * @param strOrgAmt
     * @throws Exception
     */
    private static void invokeManageTransactionAuditForPOS(YFSEnvironment env, Element eleOrder, String strOrgAmt,
                                                           String strIsPA, String strIsVoidDuring) throws Exception {

        log.beginTimer("KohlsCreatePSAForSPS.invokeManageTransactionAuditForPOS");

        /* Prepare input to manageTransactionAuditForPOS API */
        Document docManageTranAudit = KohlsXMLUtil.createDocument("TransactionAudit");
        Element eleRoot = docManageTranAudit.getDocumentElement();

        if (!YFCCommon.isVoid(eleOrder)) {
            String strTotAmt = eleOrder.getAttribute(KohlsPOCConstant.A_TOATL_AMOUNT);
            eleRoot.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY, eleOrder.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
            eleRoot.setAttribute(KohlsPOCConstant.A_DATE_TIME, eleOrder.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
            eleRoot.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
            eleRoot.setAttribute("ManagerID", eleOrder.getAttribute("ManagerID"));
            eleRoot.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,
                    eleOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));

            eleRoot.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));

            if (!YFCCommon.isVoid(strOrgAmt) && !YFCCommon.isVoid(strTotAmt)) {
                double iAmt = Double.parseDouble(strOrgAmt) - Double.parseDouble(strTotAmt);
                eleRoot.setAttribute(KohlsPOCConstant.A_ORDER_TOTAL, Double.toString(iAmt));
            }
            eleRoot.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
                    eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
            eleRoot.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER, eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));

            //ProcedureId will always be 213
            if (!YFCCommon.isVoid(strIsPA) && KohlsPOCConstant.YES.equals(strIsPA) && !YFCCommon.isVoid(strIsVoidDuring)
                    && KohlsPOCConstant.YES.equals(strIsVoidDuring)) {
                eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "PA MidVoid");
            } else if (!YFCCommon.isVoid(strIsPA) && KohlsPOCConstant.YES.equals(strIsPA)) {
                eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "Price Adjustment");
            } else {
                eleRoot.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, KohlsPOCConstant.POST_SALE_ADJUSTMENT);
            }
            eleRoot.setAttribute(KohlsPOCConstant.A_TERMINAL_ID, eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID));
            eleRoot.setAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER,
                    eleOrder.getAttribute(KohlsPOCConstant.E_TRANSACTION_NO));
        }
        if (log.isDebugEnabled()) {
            log.debug("Input XML to KohlsCreatePSAForSPS.manageTransactionAuditForPOS API - " +
                    KohlsXMLUtil.getXMLString(docManageTranAudit));
        }

        /* Invoke manageReceiptDataForPOS API */
        KOHLSBaseApi.invokeAPI(env, "manageTransactionAuditForPOS", docManageTranAudit);
        log.endTimer("KohlsCreatePSAForSPS.invokeManageTransactionAuditForPOS");
    }
}
