package com.kohls.poc.api;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCashOfficeSalesHubFeed extends KOHLSBaseApi {
	
	private static final YFCLogCategory 
 	loggerForCashOffice = YFCLogCategory
		.instance(KohlsCashOfficeSalesHubFeed.class.getName());
	
	private  String strOrganizationCode=null;
	private  String strBusinessDay=null;
	private  String strTranNo = null;
	//store level hard totals feeds to sales hub
	public Document generateCashOfficeSalesHub(YFSEnvironment env, Document inDoc) throws Exception {
		Document outDoc = null;
			loggerForCashOffice.beginTimer("KohlsPocCosaFeedAPI.generateCashOfficeSalesHub");
			
			if(loggerForCashOffice.isDebugEnabled())
				loggerForCashOffice.debug("Input to KohlsPocCosaFeedAPI.generateCashOfficeSalesHub method is -- \n"+XMLUtil.getXMLString(inDoc));
			Element eleinputDoc = inDoc.getDocumentElement();
				if(!YFCCommon.isVoid(eleinputDoc.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE))&&
					!YFCCommon.isVoid(eleinputDoc.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY))){
					strOrganizationCode = eleinputDoc.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
					strBusinessDay = eleinputDoc.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY);
					strTranNo = eleinputDoc.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM);
				}
				else {
					throw new YFSException ("OrganizationCode or BusinessDay or TransactionNumber is Blank");
				 }			
				outDoc= YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
				Element eleInvoiceDetail = outDoc.getDocumentElement();
				eleInvoiceDetail.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
				eleInvoiceDetail.setAttribute("MessageType", "CashOffice");
				Element eleCashOffice = XMLUtil.createChild(eleInvoiceDetail, KohlsPOCConstant.ATTR_CASH_OFFICE);
				eleCashOffice.setAttribute("Store", strOrganizationCode);
				// changed the TransactioNumber to TransactionNumber 29/10 : Sathya
				eleCashOffice.setAttribute("TransactionNumber", strTranNo);	
				Document inputDocTillStatus= YFCDocument.createDocument(KohlsPOCConstant.E_TILL_STATUS).getDocument();
				Element eleInputTillStatus = inputDocTillStatus.getDocumentElement();
				eleInputTillStatus.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
				eleInputTillStatus.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,  strOrganizationCode);
				Element eleOrderBy = XMLUtil.createChild (eleInputTillStatus, KohlsPOCConstant.E_ORDER_BY);
				Element eleAttributeTerminal = XMLUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
				eleAttributeTerminal.setAttribute("Name","TerminalID");
				eleAttributeTerminal.setAttribute("Desc", "N");
				Element eleAttributeTill = XMLUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
				eleAttributeTill.setAttribute("Name", "TillID");
				eleAttributeTill.setAttribute("Desc", "N");
				Document outputDocTillStatusList = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_TILL_STATUS_LIST_TEMPLATE),
						KohlsPOCConstant.API_GET_TILL_STATUS_LIST_FOR_POS,inputDocTillStatus);
				NodeList nlTillStatusList = XPathUtil.getNodeList(outputDocTillStatusList, "TillStatusList/TillStatus");
				KohlsPocCosaFeedAPI pocCosa=new KohlsPocCosaFeedAPI();
				if(!YFCCommon.isVoid(nlTillStatusList)){
				 for(int i = 0; i< nlTillStatusList.getLength(); i++)
				 {
					 Element eleTillStatus= (Element)nlTillStatusList.item(i);
					
					 Document inDocHardTotals=XMLUtil.newDocument();
					 XMLUtil.importElement(inDocHardTotals, eleTillStatus);
					 Document outDocHardTotals=pocCosa.generateCosaFeedToSalesHub(env,inDocHardTotals);
					 //Added condtion to check blank StoreProdAcc element 11/10:Sathya
					 NodeList nStoreProductAccs = XPathUtil.getNodeList(outDocHardTotals, "InvoiceDetail/SalesAuditDetails/CosaFeed/StoreProductAccs");
					 Element StoreProductAccs= (Element)nStoreProductAccs.item(0);
					 if(!StoreProductAccs.getAttribute("isBlankStoreProdAcc").equals("Y")){
						 Element eleRegister = XMLUtil.createChild(eleCashOffice, KohlsPOCConstant.ATTR_REGISTER);
						 eleRegister.setAttribute("RegisterID", eleTillStatus.getAttribute("TerminalID"));
						 NodeList nSalesAudit = XPathUtil.getNodeList(outDocHardTotals, "InvoiceDetail/SalesAuditDetails");
						 Element eleSalesAudit= (Element)nSalesAudit.item(0); 
						 NodeList salesAuditChildList = eleSalesAudit.getChildNodes();
						 for(int j = 0; j< salesAuditChildList.getLength(); j++)				 
						 {
							 Element salesAuditEle=(Element)salesAuditChildList.item(j);
							 XMLUtil.importElement(eleRegister,salesAuditEle);					 
						 }	
					 }
				 }
				}
			if(!eleCashOffice.hasChildNodes()){
				eleInvoiceDetail.setAttribute("isBlankStore", "Y");
			}
			
			if(loggerForCashOffice.isDebugEnabled())
				loggerForCashOffice.debug("Output of KohlsPocCosaFeedAPI.generateCashOfficeSalesHub method is -- \n"+XMLUtil.getXMLString(outDoc));
			loggerForCashOffice.endTimer("KohlsPocCosaFeedAPI.generateCashOfficeSalesHub");
			return outDoc;
		}		
	}
