package com.kohls.poc.api;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCLocale;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPocCosaFeedAPI extends KOHLSBaseApi {

  private static final YFCLogCategory loggerForCosaFeed =
      YFCLogCategory.instance(KohlsPocCosaFeedAPI.class.getName());

  private String strOrganizationCode = null;
  private String strBusinessDay = null;
  private String strTerminalID = null;
  private String strTillID = null;
  private String strStoreProdKey = null;

  @SuppressWarnings("deprecation")
  public Document generateCosaFeedToSalesHub(YFSEnvironment env, Document inDoc)
      throws YFSException {
    Document docOutputSalesAudit = null;
    // Document docRootDoc = YFCDocument.createDocument("RootElement").getDocument();
    try {
      loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.generateCosaFeedToSalesHub");

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed
            .debug("Input Xml to KohlsPocCosaFeedAPI.generateCosaFeedToSalesHub method is: "
                + XMLUtil.getXMLString(inDoc));
      Element eleAccount = inDoc.getDocumentElement();
      getInputAttributes(env, eleAccount);

      // calling getStoreProductAccListForPOS api
      Document docOutputForStorePdtAccOutput = getStorePdtAcc(env);
      NodeList nlStoreProductList =
          XPathUtil.getNodeList(docOutputForStorePdtAccOutput, "StoreProductAccs/StoreProductAcc");
      Element eleStoreProductAcc = (Element) nlStoreProductList.item(0);

      // Temporary code fix for 3690 - POC Returns Team - Start

      if (!YFCCommon.isVoid(eleStoreProductAcc)) {
        String strReturnTransactionsCount =
            eleStoreProductAcc.getAttribute(KohlsXMLLiterals.ATTR_RETURN_TRANSACTIONS_COUNT);
        
         strStoreProdKey =
                eleStoreProductAcc.getAttribute(KohlsPOCConstant.A_STORE_PROD_KEY);
         eleStoreProductAcc.removeAttribute(KohlsPOCConstant.A_STORE_PROD_KEY);
        if (!YFCCommon.isStringVoid(strReturnTransactionsCount)) {
          eleStoreProductAcc.setAttribute(KohlsXMLLiterals.ATTR_UNITS_RETURN_COUNT,
              strReturnTransactionsCount);
        }
      }
      // Temporary code fix for 3690 - POC Returns Team - End

      // Manoj 12.05: Commented for defect 3363 - Begin
      // Get TransactionNumber and DateTime by calling getAccountListForPOS APi
      /*
       * Document docAccountListForPOS = getAccountListForPOS(env, "5"); Element eleAccountList =
       * (Element)((NodeList)XPathUtil.getNodeList(docAccountListForPOS.getDocumentElement(),
       * "/Accounts/Account")).item(0);
       */
      // Manoj 12.05: Commented for defect 3363 - End
      String strTransactionNumber = null;
      String strDateTime = null;
      // Sudina 12/12: Changes made for defect 1771 --- Start
      String strOperatorID = null;
      // Sudina 12/12: Changes made for defect 1771 --- End
      if (!YFCCommon.isVoid(eleAccount)) {
        if (YFCCommon.isVoid(eleAccount.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM))) {
          loggerForCosaFeed.debug(
              "Transaction No does not exist in the input message. Fetching it by calling manageAccountForPOS api");
          Document docAccountListForPOS = getAccountListForPOS(env, "5");
          eleAccount = (Element) ((NodeList) XPathUtil
              .getNodeList(docAccountListForPOS.getDocumentElement(), "/Accounts/Account")).item(0);
        }
        strTransactionNumber = eleAccount.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM);
        strDateTime = eleAccount.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME);
        // Manoj 12/15: Fix for defect 3060: Add 1 sec to Date time - Begin
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        YFCDate dDate = new YFCDate(strDateTime, "yyyy-MM-dd'T'HH:mm:ss", false);
        YFCDateUtils.addSeconds(dDate, 1);
        strDateTime = sdf.format(dDate) + strDateTime.substring(strDateTime.length() - 6);
        // Manoj 12/15: Fix for defect 3060: Add 1 sec to Date time - End

        // Sudina 12/12: Changes made for defect 1771 --- Start
        strOperatorID = eleAccount.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID);
        // Sudina 12/12: Changes made for defect 1771 --- End
      }

      // Sudina 11/20: Changes made for defect 1649 --- Start
      Document docStorePdtAccs =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_STORE_PRODUCT_MIX_ACCS).getDocument();
      Element eleStPdtAccs = docStorePdtAccs.getDocumentElement();
      Document docOutputForStorePdtMixAccDtls = getStorePdtMixAccDtls(env);
      NodeList nlStorePdtMixAccList = XPathUtil
          .getNodeList(docOutputForStorePdtMixAccDtls.getDocumentElement(), "StoreProductMixAcc");
      XMLUtil.importElement(eleStPdtAccs, (Element) nlStorePdtMixAccList.item(0));
      // Sudina 11/20: Changes made for defect 1649 --- End

      // Calling getAccountTotalListForPOS to get Actual Totals
      Document docOutputForActualAccountTotalList =
          getAccountTotalList(env, KohlsPOCConstant.STRING_ACTUAL);
      Element eleActualAccountTotalList = docOutputForActualAccountTotalList.getDocumentElement();
      eleActualAccountTotalList.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, strDateTime);
      eleActualAccountTotalList.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, strTransactionNumber);
      // Sudina 12/12: Changes made for defect 1771 --- Start
      eleActualAccountTotalList.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, strOperatorID);
      // Sudina 12/12: Changes made for defect 1771 --- End
      // Calling getAccountTotalListForPOS to get Expected Totals
      Document docOutputForExpectedAccountTotalList =
          getAccountTotalList(env, KohlsPOCConstant.STRING_EXPECTED);
      Element eleExpectedAccountTotalList =
          docOutputForExpectedAccountTotalList.getDocumentElement();
      eleExpectedAccountTotalList.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, strDateTime);
      eleExpectedAccountTotalList.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM,
          strTransactionNumber);
      // Sudina 12/12: Changes made for defect 1771 --- Start
      eleExpectedAccountTotalList.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, strOperatorID);
      // Sudina 12/12: Changes made for defect 1771 --- End

      // Sudina - 08/05/15: Calling getStoreFinancialAccListForPOS - Start
      Document docOutputStoreFinAcctList = getStoreFinancialAccListForPOS(env);
      Element eleStoreFinancialAccs = (Element) docOutputStoreFinAcctList
          .getElementsByTagName(KohlsPOCConstant.ELE_STORE_FINANCIAL_ACCS).item(0);
      // Sudina - 08/05/15: Calling getStoreFinancialAccListForPOS - End

      // Create Output for Sales Audit
      docOutputSalesAudit =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
      Element eleInvoiceDetail = docOutputSalesAudit.getDocumentElement();
      eleInvoiceDetail.setAttribute("MessageType", "HardTotals");
      eleInvoiceDetail.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
      Element eleSalesAuditDetails =
          XMLUtil.createChild(eleInvoiceDetail, KohlsPOCConstant.ATTR_SALES_AUDIT_DETAILS);
      Element eleCosaFeed =
          XMLUtil.createChild(eleSalesAuditDetails, KohlsPOCConstant.ATTR_COSA_FEED);
      Element eleStoreProductAccs =
          XMLUtil.createChild(eleCosaFeed, KohlsPOCConstant.ATTR_STORE_PRODUCT_ACCS);

      // Sudina : Changes for CR 625 - Start

      if (YFCCommon.isVoid(eleStoreProductAcc)) {
        eleStoreProductAcc =
            XMLUtil.createChild(eleStoreProductAccs, KohlsPOCConstant.ATTR_STORE_PRODUCT_ACC);
        eleStoreProductAcc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
        eleStoreProductAcc.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, strOrganizationCode);
      } else {
        XMLUtil.importElement(eleStoreProductAccs, eleStoreProductAcc);
      }

      // Sudina : Changes for CR 625 - End

      // Sudina 11/20: Changes made for defect 1649 --- Start
      XMLUtil.importElement(eleCosaFeed, eleStPdtAccs);
      // Sudina 11/20: Changes made for defect 1649 --- End

      XMLUtil.importElement(eleCosaFeed, eleActualAccountTotalList);
      Element eleHardTotals =
          XMLUtil.createChild(eleSalesAuditDetails, KohlsPOCConstant.ATTR_HARD_TOTALS);

      // Sudina : Changes for CR 625 - Start

      Element acctTotal = (Element) ((NodeList) XPathUtil
          .getNodeList(docOutputForExpectedAccountTotalList, "AccountTotals/AccountTotal")).item(0);
      if (YFCCommon.isVoid(acctTotal)) {
        acctTotal =
            XMLUtil.createChild(eleExpectedAccountTotalList, KohlsPOCConstant.ATTR_ACCOUNT_TOTAL);
        acctTotal.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
        acctTotal.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
      }

      // Sudina : Changes for CR 625 - End
      XMLUtil.importElement(eleHardTotals, eleExpectedAccountTotalList);

      // Sudina - 08/05/15: Calling getStoreFinancialAccListForPOS - Start
      XMLUtil.importElement(eleHardTotals, eleStoreFinancialAccs);
      // Sudina - 08/05/15: Calling getStoreFinancialAccListForPOS - End

      // XMLUtil.importElement(eleRootElement,eleInvoiceDetail);

      // changes for defect 316
      Element eleAdditionalDataList = XMLUtil.getChildElement(eleAccount, "AdditionalDataList");
      XMLUtil.importElement(eleCosaFeed, eleAdditionalDataList);
    } catch (Exception exception) {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.generateCosaFeedToSalesHub");
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    
    try
    {
    		if(!YFCCommon.isVoid(strStoreProdKey))
    		{
    			updatePublishedFlag(env,  strStoreProdKey);
    		}
    }
    catch(Exception e)
    {
    		loggerForCosaFeed.error(e.getMessage());
    		loggerForCosaFeed.debug("Inside KohlsPocCosaFeedAPI..updating HT Published flag... don't stop and proceed further");
    }

    if (loggerForCosaFeed.isDebugEnabled())
      loggerForCosaFeed.debug("Output of KohlsPocCosaFeedAPI.generateCosaFeedToSalesHub is :\n"
          + XMLUtil.getXMLString(docOutputSalesAudit));
    	  loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.generateCosaFeedToSalesHub");
    return docOutputSalesAudit;

  }
  
  private void updatePublishedFlag(YFSEnvironment env, String strStoreProdKey) throws Exception
  {
	  loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.updatePublishedFlag");
	  Document storeProdAccDoc = SCXmlUtil.createDocument(KohlsPOCConstant.ATTR_STORE_PRODUCT_ACCS);
	  storeProdAccDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_STORE_PROD_KEY, strStoreProdKey);
	  Element extnEle = SCXmlUtil.createChild(storeProdAccDoc.getDocumentElement(), KohlsPOCConstant.A_EXTN);
	  extnEle.setAttribute(KohlsPOCConstant.EXTN_IS_HT_PUBLISHED, KohlsPOCConstant.YES);
	  invokeAPI(env, KohlsPOCConstant.API_MANAGE_STOREPRODACC_FOR_POS, storeProdAccDoc);
	  loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.updatePublishedFlag"); 
  }	

  private void getInputAttributes(YFSEnvironment env, Element eleTillStatus) {
    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getInputAttributes");
    if (!YFCCommon.isVoid(eleTillStatus.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE))
        && !YFCCommon.isVoid(eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY))) {
      /*
       * Manoj 12/15: Workaround for defect 3043 is to use AccountableTerminalID field instead of
       * TerminalID field.
       */
      // strTerminalID = eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
      strTerminalID = eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_ACCOUNTABLE_TERMINAL_ID);
      if (YFCCommon.isVoid(strTerminalID)) {
        strTerminalID = eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
      }
      strTillID = eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_TILL_ID);
      strOrganizationCode = eleTillStatus.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
      strBusinessDay = eleTillStatus.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY);
      loggerForCosaFeed.debug("TerminalID=" + strTerminalID + ", TillID=" + strTillID + ", StoreNo="
          + strOrganizationCode + ", Business Day=" + strBusinessDay);
    } else {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getInputAttributes");
      throw new YFSException("OrganizationCode or BusinessDay is Blank");
    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getInputAttributes");
  }

  // Sudina 11/20: Changes made for defect 1649 --- Start
  private Document getStorePdtMixAccDtls(YFSEnvironment env) {
    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getStorePdtMixAccDtls");
    Document docStorePdtMixAccDtOutput = null;
    try {
      Document docInputForStorePdtMixAcc =
          YFCDocument.createDocument(KohlsPOCConstant.ELE_STORE_PRODUCT_MIX_ACC).getDocument();
      Element eleStorePdtMixAccInput = docInputForStorePdtMixAcc.getDocumentElement();
      eleStorePdtMixAccInput.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
      eleStorePdtMixAccInput.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, strOrganizationCode);
      eleStorePdtMixAccInput.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
      eleStorePdtMixAccInput.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, strTillID);
      // Sudina 01/28: changed API call to getStoreProductMixAccListForPOS- changes for Defect #
      // 1738

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug("getStoreProductMixAccListForPOS API input is: \n"
            + XMLUtil.getXMLString(docInputForStorePdtMixAcc));
      // Call getStoreProductMixAccListForPOS API
      docStorePdtMixAccDtOutput = KOHLSBaseApi.invokeAPI(env,
          KohlsPOCConstant.GET_STORE_PRODUCT_MIX_ACCS_TEMPLATE,
          KohlsPOCConstant.API_GET_STORE_PRODUCT_MIX_ACC_LIST_FOR_POS, docInputForStorePdtMixAcc);
      // Added Null Check
      if (docStorePdtMixAccDtOutput == null || YFCCommon.isVoid(docStorePdtMixAccDtOutput)) {
        docStorePdtMixAccDtOutput = XMLUtil.createDocument("StoreProductMixAcc");
      }

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug("getStoreProductMixAccListForPOS API output is: \n"
            + XMLUtil.getXMLString(docStorePdtMixAccDtOutput));
    } catch (Exception exception) {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getStorePdtMixAccDtls");
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getStorePdtMixAccDtls");
    return docStorePdtMixAccDtOutput;
  }
  // Sudina 11/20: Changes made for defect 1649 --- End

  private Document getStorePdtAcc(YFSEnvironment env) {
    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getStorePdtAcc");
    Document docOutput = null;
    try {
      // Create input xml for getStoreProductAccListForPOS API

      Document docInputForStorePdtAcc =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_STORE_PRODUCT_ACC).getDocument();
      Element eleStorePdtAccInput = docInputForStorePdtAcc.getDocumentElement();
      // Sudina 09/05: commented the terminal ID in the input to getStoreProductAccListForPOS API as
      // One store can have multiple terminals and the COSA feed is fetched at store level.
      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, strTillID);
      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
      eleStorePdtAccInput.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, strOrganizationCode);

      // Call getStoreProductAccListForPOS API
      docOutput = invokeAPI(env, KohlsPOCConstant.GET_STORE_PRODUCT_ACCS_TEMPLATE,
          KohlsPOCConstant.API_GET_STORE_PRODUCT_ACC_LIST_FOR_POS, docInputForStorePdtAcc);
    } catch (Exception exception) {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getStorePdtAcc");
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getStorePdtAcc");
    return docOutput;
  }

  private Document getAccountTotalList(YFSEnvironment env, String entryType) {
    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getAccountTotalList");
    Document docAccountOutput = null;
    try {
      // Create input xml for getAccountTotalListForPOS API
      Document docInputForAccountTotalList =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_ACCOUNT_TOTAL).getDocument();
      Element eleTillStatusTotal = docInputForAccountTotalList.getDocumentElement();
      // Manoj 11/13: Uncommented TerminalID for defect 1635
      eleTillStatusTotal.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
      eleTillStatusTotal.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, strTillID);
      eleTillStatusTotal.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
      eleTillStatusTotal.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
      eleTillStatusTotal.setAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE, entryType);

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug("getAccountListForPOS API input is: \n"
            + XMLUtil.getXMLString(docInputForAccountTotalList));
      // Call getAccountTotalListForPOS API
      docAccountOutput = KOHLSBaseApi.invokeAPI(env,
          KohlsPOCConstant.API_GET_ACCOUNT_TOTAL_LIST_FOR_POS, docInputForAccountTotalList);

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug(
            "getAccountTotalListForPOS API output is: \n" + XMLUtil.getXMLString(docAccountOutput));
    } catch (Exception exception) {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getAccountTotalList");
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }

    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getAccountTotalList");
    return docAccountOutput;
  }

  private Document getAccountListForPOS(YFSEnvironment env, String sProcedureID) {
    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getAccountListForPOS");
    Document docAccountOutput = null;
    try {
      // Create input xml for getAccountTotalListForPOS API
      Document docGetAccountListIn =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_ACCOUNT).getDocument();
      Element eleTillStatus = docGetAccountListIn.getDocumentElement();
      eleTillStatus.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
      eleTillStatus.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
      eleTillStatus.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, sProcedureID);
      eleTillStatus.setAttribute("AccountableTerminalID", strTerminalID);
      eleTillStatus.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, strTillID);

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug(
            "getAccountListForPOS API input is: \n" + XMLUtil.getXMLString(docGetAccountListIn));
      // Call getAccountListForPOS API
      docAccountOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ACCOUNT_LIST_FOR_POS,
          docGetAccountListIn);

      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug(
            "getAccountListForPOS API output is: \n" + XMLUtil.getXMLString(docAccountOutput));
    } catch (Exception exception) {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getAccountListForPOS");
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }

    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getAccountListForPOS");
    return docAccountOutput;
  }

  // Sudina - 08/05/15: Calling getStoreFinancialAccListForPOS - Start

  private Document getStoreFinancialAccListForPOS(YFSEnvironment env) {
    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getStoreFinancialAccListForPOS");
    Document docStoreFinAcctListOutput = null;
    double dReturnAmount = 0.0;
    double dSaleAmount = 0.0;;
    int iReturnTenderCount = 0;
    int iSaleTenderCount = 0;
    double dCashGivenToCustomer = 0.0;;
    double dDebitSalesAmount = 0.0;
    int iDebitSalesTenderCount = 0;
    String sTotalValue = "";

    HashMap<String, String> mapPaymentDetils = new HashMap<String, String>();
    try {
      // Create input xml for getStoreFinancialAccListForPOS API
      Document docStoreFinAcctListInput =
          YFCDocument.createDocument(KohlsPOCConstant.ELE_STORE_FINANCIAL_ACC).getDocument();
      Element eleStoreFinAcc = docStoreFinAcctListInput.getDocumentElement();
      eleStoreFinAcc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, strBusinessDay);
      eleStoreFinAcc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
      eleStoreFinAcc.setAttribute(KohlsPOCConstant.ATTR_TILL_ID, strTillID);
      eleStoreFinAcc.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, strOrganizationCode);

      if (loggerForCosaFeed.isDebugEnabled()) {
        loggerForCosaFeed.debug("getStoreFinancialAccListForPOS API input is: \n"
            + XMLUtil.getXMLString(docStoreFinAcctListInput));
      }
      // Call getStoreFinancialAccListForPOS API
      docStoreFinAcctListOutput = KOHLSBaseApi.invokeAPI(env,
          KohlsPOCConstant.GET_STORE_FINANCIAL_ACC_LIST_FOR_POS_TEMPLATE,
          KohlsPOCConstant.API_GET_STORE_FINANCIAL_ACC_LIST_FOR_POS, docStoreFinAcctListInput);

      if (loggerForCosaFeed.isDebugEnabled()) {
        loggerForCosaFeed.debug("eleStrFinTenderAccs-----> \n"
            + XMLUtil.getElementXMLString(docStoreFinAcctListOutput.getDocumentElement()));
      }

      NodeList nlStoreFinancialAcc =
          docStoreFinAcctListOutput.getElementsByTagName("StoreFinancialAcc");
      for (int j = 0; j < nlStoreFinancialAcc.getLength(); j++) {
        Element eleStrFinTenderAccs = (Element) nlStoreFinancialAcc.item(j);
        NodeList ndlStoreFin = eleStrFinTenderAccs.getElementsByTagName("StrFinTenderAcc");
        for (int i = 0; i < ndlStoreFin.getLength(); i++) {
          Element eleStrFinTenderAcc = (Element) ndlStoreFin.item(i);
          if (loggerForCosaFeed.isDebugEnabled()) {
            loggerForCosaFeed.debug(
                "eleStrFinTenderAcc------> \n" + XMLUtil.getElementXMLString(eleStrFinTenderAcc));
          }
          if(!YFCCommon.isVoid(eleStrFinTenderAcc.getAttribute("PaymentType"))){
            dCashGivenToCustomer=getAttributeValue(eleStrFinTenderAcc.getAttribute("CashGivenToCustomer"));
            dDebitSalesAmount=getAttributeValue(eleStrFinTenderAcc.getAttribute("DebitSalesAmount"));
            iDebitSalesTenderCount=getIntegerValue(eleStrFinTenderAcc.getAttribute("DebitSalesTenderCount"));
            dReturnAmount=getAttributeValue(eleStrFinTenderAcc.getAttribute("ReturnAmount"));
            iReturnTenderCount=getIntegerValue(eleStrFinTenderAcc.getAttribute("ReturnTenderCount"));
            dSaleAmount=getAttributeValue(eleStrFinTenderAcc.getAttribute("SalesAmount"));
            iSaleTenderCount=getIntegerValue(eleStrFinTenderAcc.getAttribute("SalesTenderCount"));

            if (mapPaymentDetils.containsKey(eleStrFinTenderAcc.getAttribute("PaymentType"))) {
              String sAmount =
                  (String) mapPaymentDetils.get(eleStrFinTenderAcc.getAttribute("PaymentType"));
              String sTempAmount[] = sAmount.split("_");

              double dTempdCashGivenToCustomer =
                  Double.parseDouble(sTempAmount[0]) + dCashGivenToCustomer;

              double dTempDebitSalesAmount = Double.parseDouble(sTempAmount[1]) + dDebitSalesAmount;

              int iTempDebitSalesTenderCount =
                  Integer.parseInt(sTempAmount[2]) + iDebitSalesTenderCount;

              double dTempReturnAmount = Double.parseDouble(sTempAmount[3]) + dReturnAmount;

              int iTempRetTenderCount = Integer.parseInt(sTempAmount[4]) + iReturnTenderCount;

              double dTempSalesAmount = Double.parseDouble(sTempAmount[5]) + dSaleAmount;

              int iTempSaleTenderCount = Integer.parseInt(sTempAmount[6]) + iSaleTenderCount;

              String sConcatAmount = String.valueOf(dTempdCashGivenToCustomer) + "_"
                  + String.valueOf(dTempDebitSalesAmount) + "_"
                  + String.valueOf(iTempDebitSalesTenderCount) + "_"
                  + String.valueOf(dTempReturnAmount) + "_" + String.valueOf(iTempRetTenderCount)
                  + "_" + String.valueOf(dTempSalesAmount) + "_"
                  + String.valueOf(iTempSaleTenderCount);

              if (loggerForCosaFeed.isDebugEnabled()) {
                loggerForCosaFeed
                    .debug("Updating the vlues for the Payment type  \n" + sConcatAmount);
                // loggerForCosaFeed.debug("sOtherValue------> \n" +sOtherValue);
              }
              mapPaymentDetils.put(eleStrFinTenderAcc.getAttribute("PaymentType"), sConcatAmount);
            } else {
              String sAmountValue = dReturnAmount + "_" + iReturnTenderCount + "_" + dSaleAmount + "_"
                  + iSaleTenderCount;
              String sOtherValue =
                  dCashGivenToCustomer + "_" + dDebitSalesAmount + "_" + iDebitSalesTenderCount;
              if (loggerForCosaFeed.isDebugEnabled()) {
                loggerForCosaFeed.debug("sAmountValue------> \n" + sAmountValue);
                loggerForCosaFeed.debug("sOtherValue------> \n" + sOtherValue);
              }
              sTotalValue = sOtherValue + "_" + sAmountValue;
              if (loggerForCosaFeed.isDebugEnabled()) {
                loggerForCosaFeed.debug("Adding new value for the payment type  \n" + sTotalValue);
                // loggerForCosaFeed.debug("sOtherValue------> \n" +sOtherValue);
              }
              mapPaymentDetils.put(eleStrFinTenderAcc.getAttribute("PaymentType"), sTotalValue);
              // docInputXML1.getDocumentElement().removeChild(eleStrFin);
            }
          }
        }
      }

      docStoreFinAcctListOutput = consolidateStoreFinAcc(mapPaymentDetils);
      if (loggerForCosaFeed.isDebugEnabled())
        loggerForCosaFeed.debug("getStoreFinancialAccListForPOS API output is: \n"
            + XMLUtil.getXMLString(docStoreFinAcctListOutput));
    } catch (Exception exception) {
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getStoreFinancialAccListForPOS");
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }

    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getStoreFinancialAccListForPOS");
    return docStoreFinAcctListOutput;
  }
  // Sudina - 08/05/15: Calling getStoreFinancialAccListForPOS - End

  /**
   * Create By Sandya *
   * 
   * @param docStoreFinAcctListOutput
   * @param mapPaymentDetils
   * @return
   * @throws ParserConfigurationException
   */
  private Document consolidateStoreFinAcc(HashMap<String, String> mapPaymentDetils)
      throws ParserConfigurationException {

    loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.consolidateStoreFinAcc");

    Document docStoreFinAcctListOutput = XMLUtil.createDocument("StoreFinancialAccs");
    Element eleStoreFinancialAccs = docStoreFinAcctListOutput.getDocumentElement();

    Element eleStoreFinancialAcc = XMLUtil.createChild(eleStoreFinancialAccs, "StoreFinancialAcc");
    Element eleStrFinTenderAccs = XMLUtil.createChild(eleStoreFinancialAcc, "StrFinTenderAccs");
    
    for (Map.Entry<String, String> entry : mapPaymentDetils.entrySet()) {
    	String key = entry.getKey();
    	Object oPaymentDetails = entry.getValue();
    	 Element eleStrFinTenderAcc = SCXmlUtil.createChild(eleStrFinTenderAccs, "StrFinTenderAcc");
    	    
    	String arrPaymentType[] = String.valueOf(oPaymentDetails).split("_");
    	eleStrFinTenderAcc.setAttribute("CashGivenToCustomer", arrPaymentType[0]);
        eleStrFinTenderAcc.setAttribute("DebitSalesAmount", arrPaymentType[1]);
        eleStrFinTenderAcc.setAttribute("DebitSalesTenderCount", arrPaymentType[2]);
        eleStrFinTenderAcc.setAttribute("ReturnAmount", arrPaymentType[3]);
        eleStrFinTenderAcc.setAttribute("SalesAmount", arrPaymentType[5]);
        eleStrFinTenderAcc.setAttribute("ReturnTenderCount", arrPaymentType[4]);
        eleStrFinTenderAcc.setAttribute("SalesTenderCount", arrPaymentType[6]);
        eleStrFinTenderAcc.setAttribute("PaymentType", entry.getKey());
        if (loggerForCosaFeed.isDebugEnabled()) {
          loggerForCosaFeed.debug("eleStoreFinancialAcc updated values  \n"
              + XMLUtil.getElementXMLString(eleStrFinTenderAcc));
          // loggerForCosaFeed.debug("sOtherValue------> \n" +sOtherValue);
        }
    	
    }
   

    if (loggerForCosaFeed.isDebugEnabled()) {
      loggerForCosaFeed
          .debug("Final Output XML --->  \n" + XMLUtil.getXMLString(docStoreFinAcctListOutput));
      // loggerForCosaFeed.debug("sOtherValue------> \n" +sOtherValue);
    }
    loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.consolidateStoreFinAcc");
    return docStoreFinAcctListOutput;
  }
  
  private double getAttributeValue(String sValue)
  {
	  loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getAttributeValue");
	  double dAmount;
	  loggerForCosaFeed
      .debug("Value is  --->  \n" +sValue);
	  if (YFCCommon.isVoid(sValue)) {
		  dAmount = 0.0;
        } else {
        	dAmount =
              Double.parseDouble(sValue);
        }
	  loggerForCosaFeed
      .debug("Return  Amount" + dAmount);
	  loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getAttributeValue");
	  return dAmount;
  }
  
  private int getIntegerValue(String sValue)
  {
      loggerForCosaFeed.beginTimer("KohlsPocCosaFeedAPI.getIntegerValue");
      int iAmount;
      loggerForCosaFeed
      .debug("Value is  --->  \n" +sValue);
      if (YFCCommon.isVoid(sValue)) {
          iAmount = 0;
        } else {
            iAmount =
              Integer.parseInt(sValue);
        }
      loggerForCosaFeed
      .debug("Return  Amount" + iAmount);
      loggerForCosaFeed.endTimer("KohlsPocCosaFeedAPI.getIntegerValue");
      return iAmount;
  }
}
