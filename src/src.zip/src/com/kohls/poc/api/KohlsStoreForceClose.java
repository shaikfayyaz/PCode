package com.kohls.poc.api;

import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsDeploymentUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.dbclasses.YFS_OrganizationDBHome;
import com.yantra.shared.dbi.YFS_Organization;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.core.YCPContext;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;


public class KohlsStoreForceClose extends KOHLSBaseApi{
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsStoreForceClose.class.getName());
	public static String actionName = "";
	private static Statement stmt = null;
	private static YIFApi oApi = null;

	/*Input accepted are
	 * 1. <AutoStoreClose > 
	 		<Store Action="CLOSE" StoreID="9916"/> 
	 		<Store Action="CLOSE" StoreID="9902"/>
	 	</AutoStoreClose>
	 
	2. <AutoStoreClose>
			<Store Action='OPEN' StoreID="9916"/>
		</AutoStoreClose>	 
	
	3. 
		<AutoStoreClose>
			<Store Action='STATUS' StoreID="9916"/>
		</AutoStoreClose>
	 */
	public Document autoStoreCloseStoreList(YFSEnvironment env, Document doc) throws Exception {
		try {
			YFSContext ctx = (YFSContext) env;
			String type = "";
			log.info("Input to autoClose is " + SCXmlUtil.getString(doc));
			ArrayList<String> storeCloseList = new ArrayList<String>();
			Document outDoc = null;
			Element eleStoreList = doc.getDocumentElement();
			NodeList storeNodeList = eleStoreList.getElementsByTagName(KohlsPOCConstant.A_STORE_APE);
			for (int i = 0; i < storeNodeList.getLength(); i++) {
				Element storenumberElm = ((Element) storeNodeList.item(i));
				String StoreID = storenumberElm.getAttribute(KohlsPOCConstant.A_STORE_ID);
				if (storenumberElm.getAttribute(KohlsPOCConstant.A_ACTION).equalsIgnoreCase(KohlsPOCConstant.CLOSE)) {
					storeCloseList.add(StoreID);
					log.info("Store close is for " + StoreID);
					type = KohlsPOCConstant.CLOSE;
				} else if (storenumberElm.getAttribute(KohlsPOCConstant.A_ACTION).equalsIgnoreCase(KohlsPOCConstant.OPEN)) {					
					//String storeBusinessDate = businessDateFromCorp(env, StoreID);						
					Date currDate = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
					String storeBusinessDate = sdf.format(currDate);						
					outDoc = posAccountingTableCount(env, storeBusinessDate, StoreID);
				} else if (storenumberElm.getAttribute(KohlsPOCConstant.A_ACTION).equalsIgnoreCase(KohlsPOCConstant.ATTR_STATUS)){
					log.info("Store number passed is " + storenumberElm.getAttribute(KohlsPOCConstant.A_STORE_ID));
					KohlsDeploymentUtil util = new KohlsDeploymentUtil();
					Document outDocBusDate = util.getBusinessDate(env,
							storenumberElm.getAttribute(KohlsPOCConstant.A_STORE_ID));
					outDoc = getTillStatusForStore(ctx, storenumberElm.getAttribute(KohlsPOCConstant.A_STORE_ID));	
					NodeList busDateNodes = outDocBusDate.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);						
					int numOfStores = Integer
							.parseInt(outDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
					log.info("Total Number Of Till Records is "
							+ outDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
					if (numOfStores != 0) {
						NodeList nodeListCommonCode = outDoc.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS);						
						for (int ik = 0; ik < nodeListCommonCode.getLength(); ik++) {
							Element eleRemove = ((Element) nodeListCommonCode.item(ik));
							eleRemove.removeAttribute(KohlsPOCConstant.ATTR_TILL_ID);
							eleRemove.removeAttribute(KohlsPOCConstant.A_ACCOUNT_TYPE);
							eleRemove.removeAttribute(KohlsPOCConstant.A_TILL_STAT_KEY);
							eleRemove.removeAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER);
							eleRemove.removeAttribute(KohlsPOCConstant.A_TERMINAL_TYPE);
						}
						NodeList tillNodeslist = outDoc.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS);
						for (int it = 0; it < busDateNodes.getLength(); it++) {
							Node n = (Node) outDoc.importNode(busDateNodes.item(it), true);
							tillNodeslist.item(it).getParentNode().appendChild(n);
						}
						outDoc.getDocumentElement().removeAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS);
						outDoc.renameNode(outDoc.getDocumentElement(), KohlsPOCConstant.E_TILL_STATUS_LIST,
								KohlsPOCConstant.ATTR_STATUS);
						log.debug("Status output doc " + SCXmlUtil.getString(outDoc));
					}else{	
						outDocBusDate.getDocumentElement().removeAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS);
						outDocBusDate.renameNode(outDocBusDate.getDocumentElement(), KohlsPOCConstant.E_ACC_PERIOD_LIST,
								KohlsPOCConstant.ATTR_STATUS);							
						log.debug("Status output doc " + SCXmlUtil.getString(outDocBusDate));
						outDoc = outDocBusDate;							
					}				
				}
			}
			if (type.equalsIgnoreCase(KohlsPOCConstant.CLOSE)) {
				for (String sd : storeCloseList) {
					log.info("Store id is " + sd.toString());
					boolean orgMsg = checkForOrg(env, sd);
					if (orgMsg) {
						Document msg = checkAndCloseOpentTills(ctx, sd.toString().trim());
						NodeList nod = msg.getElementsByTagName(KohlsPOCConstant.A_STORE_APE);
						Element eleCommonCode = ((Element) nod.item(0));	
						String msgOutput = eleCommonCode.getAttribute(KohlsPOCConstant.MESSAGE);			
						if (YFCCommon.isVoid(outDoc)) {
							outDoc = storeCloseForAccountingForPOS(ctx, sd);
							NodeList nod2 = outDoc.getElementsByTagName(KohlsPOCConstant.A_STORE_APE);
							Element eleCommonCode2 = ((Element) nod2.item(0));
							eleCommonCode2.setAttribute(KohlsPOCConstant.MESSAGE, msgOutput);							
						} else {
							Document closeMsg2 = storeCloseForAccountingForPOS(ctx, sd);
							NodeList nod3 = closeMsg2.getElementsByTagName(KohlsPOCConstant.A_STORE_APE);
							Element eleCommonCode3 = ((Element) nod3.item(0));
							eleCommonCode3.setAttribute(KohlsPOCConstant.MESSAGE, msgOutput);							
							responseMsg(outDoc, closeMsg2);
						}
					} else {
						Document respDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
						Element respElm = respDoc.getDocumentElement();
						Element resChild = SCXmlUtil.createChild(respElm, KohlsPOCConstant.A_STORE_APE);
						resChild.setAttribute(KohlsPOCConstant.A_STORE_ID, sd);
						resChild.setAttribute(KohlsPOCConstant.MESSAGE, "Organization doesn't exists");
						if (YFCCommon.isVoid(outDoc)) {
							outDoc = respDoc;
						} else {
							responseMsg(outDoc, respDoc);
						}
					}
				}
			}
			log.info("Response api tester" + SCXmlUtil.getString(outDoc));
			return outDoc;
		} catch (Exception e) {
			return SCXmlUtil.createDocument(e.getMessage());
		}
	}

	//Constructing the response message
	private Document responseMsg(Document in1, Document in2) throws Exception{
		log.info("Constructing the output message \n " + SCXmlUtil.getString(in1) + "\n" + SCXmlUtil.getString(in2));
		NodeList nodes5 = in1.getElementsByTagName(KohlsPOCConstant.A_STORE_APE);
		NodeList nodes6 = in2.getElementsByTagName(KohlsPOCConstant.A_STORE_APE);
		for (int i = 0; i < nodes6.getLength(); i++) {
			Node n = (Node) in1.importNode(nodes6.item(i), true);
			nodes5.item(i).getParentNode().appendChild(n);
		}
		return in1;
	}
	

	// Checking the org exists or not
	private boolean checkForOrg(YFSEnvironment env, String OrgCode) throws Exception {
		try {
			log.info("Checking for organization presence");
			YCPContext ctx = (YCPContext) env;
			PLTQueryBuilder pltQueryBuilder = new PLTQueryBuilder(false);
			StringBuffer sb = new StringBuffer();
			pltQueryBuilder.append(sb.append("WHERE ORGANIZATION_CODE = '" + OrgCode + "'"));
			log.debug("getReadableWhereClause " + pltQueryBuilder.getReadableWhereClause());
			YFS_Organization orgCodeFromDB = YFS_OrganizationDBHome.getInstance().selectWithWhere(ctx, pltQueryBuilder);
			if (YFCCommon.isVoid(orgCodeFromDB)) {
				log.info(OrgCode + " organization not present");
				return false;
			} else {
				log.info(OrgCode + " organizationp resent");
				return true;
			}
		} catch (Exception e) {
			log.error("Checking the organization is having issues");
			throw  e;
		}
	}

	//Get the till status
	public Document getTillStatusForStore(YFSContext ctx, String storeNo) throws Exception {
		Document inputDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
		inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ORG_CODE, storeNo);
		inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_CURRENT_STATUS, KohlsPOCConstant.OPEN);
		log.info("Input to getTillStatusListForPOS API " + KohlsXMLUtil.getXMLString(inputDoc));
		Document outputDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.GET_TILL_STAT_LIST_POS_TEMPLATE,
				KohlsPOCConstant.API_GET_TILL_STATUS_LIST_FOR_POS, inputDoc);
		log.info("Output getTillStatusListForPOS API " + KohlsXMLUtil.getXMLString(outputDoc));
		return outputDoc;
	}
	
	/* select OrganizationCode from POS_TILL_STATUS where CURRENT_STATUS='Open';
	 * getTillStatusListForPOS <TillStatus OrganizationCode="9905"
	 * CurrentStatus="Open" CurrentTill="Y" />
	 */
	public Document checkAndCloseOpentTills(YFSContext ctx, String storeNo) throws Exception {
		try {
			Document outputDoc = getTillStatusForStore(ctx, storeNo);			
			int numOfRegisters = Integer
					.parseInt(outputDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
			log.info("Total number of store registers is " + numOfRegisters);
			if (numOfRegisters != 0) {
				Element eleStoreList = outputDoc.getDocumentElement();
				NodeList nodeList = eleStoreList.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS);
				Document multiApiInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_MULTI_API);
				Element multiElm = multiApiInput.getDocumentElement();
				for (int i = 0; i < nodeList.getLength(); i++) {
					Element eleCommonCode = ((Element) nodeList.item(i));
					Element elmApi = SCXmlUtil.createChild(multiElm, KohlsPOCConstant.E_API);
					elmApi.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.API_FORCE_CLOSE_TILL_FOR_ACC_POS);
					Element elmInput = SCXmlUtil.createChild(elmApi, KohlsPOCConstant.E_INPUT);
					Element elmTillDoc = SCXmlUtil.createChild(elmInput, KohlsPOCConstant.E_FORCE_CLOSE_TILl_ACC_POS);
					elmTillDoc.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
							eleCommonCode.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
					elmTillDoc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY,
							eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
					elmTillDoc.setAttribute(KohlsPOCConstant.ATTR_DRAWER_ID,
							eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_DRAWER_ID));
					elmTillDoc.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
					elmTillDoc.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, KohlsPOCConstant.ADMIN);
					elmTillDoc.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,
							eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID));
					elmTillDoc.setAttribute(KohlsPOCConstant.ATTR_TILL_ID,
							eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_TILL_ID));
					elmTillDoc.setAttribute(KohlsPOCConstant.A_VOID_ORDER, KohlsPOCConstant.YES);
				}
				return forceCloseTillForAccountingForPOS(ctx, multiApiInput, storeNo);
			} else {
				log.info("None of the registers are opened for this store " + storeNo);
				Document noRegDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
				Element errRegElm = noRegDoc.getDocumentElement();
				Element errRegChild = SCXmlUtil.createChild(errRegElm, KohlsPOCConstant.A_STORE_APE);
				errRegChild.setAttribute(KohlsPOCConstant.A_STORE_ID, storeNo);
				errRegChild.setAttribute(KohlsPOCConstant.MESSAGE, "No registers open");
				return noRegDoc;
			}
		} catch (Exception ee) {
			log.error("fireQueryForOpenStores - result " + ee.getMessage());
			Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
			Element errElm = errDoc.getDocumentElement();
			Element errChild = SCXmlUtil.createChild(errElm, KohlsPOCConstant.A_STORE_APE);
			errChild.setAttribute(KohlsPOCConstant.A_STORE_ID, storeNo);
			errChild.setAttribute(KohlsPOCConstant.MESSAGE, ee.getMessage());
			return errDoc;
		}
	}
	
	/*
	 * <ForceCloseTillForAccountingForPOS BusinessDay="2017-09-28" DrawerID="1" IgnoreOrdering="Y"
	 *      OperatorID="admin" OrganizationCode="9905" TerminalID="25" TillID="1" VoidOrder="Y">
	 * </ForceCloseTillForAccountingForPOS>
	 */
	//may or may not require if it is already closed
	public Document forceCloseTillForAccountingForPOS(YFSContext ctx, Document inputDocTillAcc, String storeNo)
			throws Exception {
		try {
			log.info("forceCloseTillForAccountingForPOS is inProgress");
			log.info("Input to forceCloseTillForAccountingForPOS API is " + SCXmlUtil.getString(inputDocTillAcc));
			Document outputDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_MULTIAPI, inputDocTillAcc);
			log.info("Output to forceCloseTillForAccountingForPOS API is " + SCXmlUtil.getString(outputDoc));
			Document accDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
			Element errAccElm = accDoc.getDocumentElement();
			Element errAccChild = SCXmlUtil.createChild(errAccElm, KohlsPOCConstant.A_STORE_APE);
			errAccChild.setAttribute(KohlsPOCConstant.A_STORE_ID, storeNo);
			errAccChild.setAttribute(KohlsPOCConstant.MESSAGE, "Closed open tills");
			return accDoc;
		} catch (Exception e) {
			log.error("forceCloseTillForAccountingForPOS - result " + e.getMessage());
			Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
			Element errElm = errDoc.getDocumentElement();
			Element errChild = SCXmlUtil.createChild(errElm, KohlsPOCConstant.A_STORE_APE);
			errChild.setAttribute(KohlsPOCConstant.A_STORE_ID, storeNo);
			errChild.setAttribute(KohlsPOCConstant.MESSAGE, e.getMessage());
			return errDoc;
		}
	}
		
	 /*
	 * <StoreCloseForAccountingForPOS CloseType="auto"
	 * ContextOrganizationCode="9905" IgnoreOrdering="Y" OperatorID="admin"
	 * OrganizationCode="9905"/>
	 */
	public Document storeCloseForAccountingForPOS(YFSContext ctx, String sd) throws Exception {
		log.info("storeCloseForAccountingForPOS is inProgress");
		try {
			Document storeCloseInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_STORE_CLOSE_ACC_POS);
			Element storeCloseElm = storeCloseInput.getDocumentElement();
			log.info("Store number is " + sd.toString().trim());
			storeCloseElm.setAttribute(KohlsPOCConstant.A_CLOSE_TYPE, KohlsPOCConstant.AUTO);
			storeCloseElm.setAttribute(KohlsPOCConstant.CTX_ORG_CODE, sd.toString().trim());
			storeCloseElm.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
			storeCloseElm.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, KohlsPOCConstant.ADMIN);
			storeCloseElm.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, sd.toString().trim());
			log.debug("Input to StoreCloseForAccountingForPOS API " + SCXmlUtil.getString(storeCloseInput));
			Document outputAccDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_STORE_CLOSE_ACC_POS, storeCloseInput);
			log.debug("Output from StoreCloseForAccountingForPOS API " + SCXmlUtil.getString(outputAccDoc));

			Element eleCommonCodeList = outputAccDoc.getDocumentElement();
			NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);
			log.debug("nodeListCommonCode length  is " + nodeListCommonCode.getLength());
			Document respDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
			Element respElm = respDoc.getDocumentElement();
			Element resChild = SCXmlUtil.createChild(respElm, KohlsPOCConstant.A_STORE_APE);
			Element eleCommonCode = ((Element) nodeListCommonCode.item(0));
			resChild.setAttribute(KohlsPOCConstant.A_STORE_ID, sd);
			resChild.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY,
					eleCommonCode.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
			resChild.setAttribute(KohlsPOCConstant.ATTR_STATUS,
					eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_STATUS));
			log.debug("Returning doc for StoreCloseForAccountingForPOS " +SCXmlUtil.getString(respDoc));
			return respDoc;
		} catch (Exception ie) {
			Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
			Element errElm = errDoc.getDocumentElement();
			Element errChild = SCXmlUtil.createChild(errElm, KohlsPOCConstant.A_STORE_APE);
			errChild.setAttribute(KohlsPOCConstant.MESSAGE, ie.getMessage());
			errChild.setAttribute(KohlsPOCConstant.A_STORE_ID, sd);
			return errDoc;
		}
	}

	
	//<Store StorId='9916' BusinessDay='2017-10-12' Status='Open'/>	  
	/*
	 *     <StoreOpenForAccountingForPOS BusinessDay="2017-10-02" ContextOrganizationCode="9905" 
	 *     IgnoreOrdering="Y" OpenType="manual" OperatorID="admin" OrganizationCode="9905"/>
	 */
	// Close the Store accounting period
	public Document storeOpenForAccountingForPOS(YFSEnvironment env, String businessDate, String StoreID) throws Exception {
		try {
			YFSContext ctx = (YFSContext) env;
			log.debug("Store open is inProgress" );
			Document openAccInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_STORE_OPEN_ACC_POS);
			Element elmOpenAccDoc = openAccInput.getDocumentElement();
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, businessDate);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.CTX_ORG_CODE, StoreID);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.A_OPEN_TYPE, KohlsPOCConstant.MANUAL);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, KohlsPOCConstant.ADMIN);
			elmOpenAccDoc.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, StoreID);
			log.debug("storeOpenForAccountingForPOS API input is " + SCXmlUtil.getString(openAccInput));
			Document outputAccDoc = KohlsCommonUtil.invokeAPI(ctx, KohlsPOCConstant.API_STORE_OPEN_ACC_POS,
					openAccInput);
			log.debug("storeOpenForAccountingForPOS API output is " + SCXmlUtil.getString(outputAccDoc));
			Element eleCommonCodeList = outputAccDoc.getDocumentElement();
			NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);
			log.info(nodeListCommonCode.getLength());
			Document respDoc = SCXmlUtil.createDocument(KohlsPOCConstant.A_STORE_APE);
			Element respElm = respDoc.getDocumentElement();
			Element eleCommonCode = ((Element) nodeListCommonCode.item(0));
			respElm.setAttribute(KohlsPOCConstant.A_STORE_ID, StoreID);
			respElm.setAttribute(KohlsPOCConstant.A_OPEN_TIME, eleCommonCode.getAttribute(KohlsPOCConstant.A_OPEN_TIME));
			respElm.setAttribute(KohlsPOCConstant.A_BUSINESS_DAY,
					eleCommonCode.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY));
			respElm.setAttribute(KohlsPOCConstant.ATTR_STATUS,
					eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_STATUS));
			log.debug(SCXmlUtil.getString(respDoc));
			return respDoc;
		} catch (Exception e) {
			Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.A_STORE_APE);
			errDoc.getDocumentElement().setAttribute(KohlsPOCConstant.MESSAGE, e.getMessage());
			errDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_STORE_ID, StoreID);
			return errDoc;
		}
	}

	// Checking the POS_ACCOUNTING_PERIOD has any entries
	public Document posAccountingTableCount(YFSEnvironment env, String storeBusinessDate, String StoreID)
			throws Exception {
		YCPContext ctx = (YCPContext) env;
		PLTQueryBuilder selectStatement = new PLTQueryBuilder(false);
		selectStatement.append("SELECT" + " ORGANIZATION_CODE FROM POS_ACCOUNTING_PERIOD");
		try {
			stmt = ctx.getConnection().createStatement();
			log.debug("Query being fired " + selectStatement.getReadableWhereClause());
			ResultSet rs = stmt.executeQuery(selectStatement.getReadableWhereClause(false));
			if (rs.next()) {
				log.info("Accounting period table is not empty and organization code is "
						+ rs.getString("ORGANIZATION_CODE").trim());
				rs.close();
			} else {
				log.info("Accounting period table is empty for new Store " + StoreID);
				rs.close();
			}
			Document respDoc = storeOpenForAccountingForPOS(env, storeBusinessDate, StoreID);
			return respDoc;
		} catch (Exception ex) {
			Document errDoc = SCXmlUtil.createDocument(KohlsPOCConstant.A_STORE_APE);
			errDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_STORE_ID, StoreID);
			errDoc.getDocumentElement().setAttribute(KohlsPOCConstant.MESSAGE, ex.getMessage());
			return errDoc;
		} finally {
			log.info("posAccountingTableCount closing DB connection");
			YFSDBHome.closeStatement(stmt);
			if (!stmt.isClosed()) {
				stmt.close();
			}
		}
	}
	
	// Get the business date from CORP
	public String businessDateFromCorp(YFSEnvironment env, String StoreID) throws Exception {
		Date currDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		String frmtCurrDate = sdf.format(currDate);		
		Document accPeriodInput = SCXmlUtil.createDocument(KohlsPOCConstant.A_ACC_PERIOD);
		Element accPeriodInputElm = accPeriodInput.getDocumentElement();
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_ORG_CODE, StoreID);
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_STATUS, KohlsPOCConstant.OPEN);
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_PERIOD, KohlsPOCConstant.YES);
		log.info("Input to inputDocDate " + KohlsXMLUtil.getXMLString(accPeriodInput));
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		Document businessDateTemplate = factory.newDocumentBuilder()
				.parse(new InputSource(new StringReader(KohlsPOCConstant.ACC_PERIOD_OUTPUT_TEMPL)));
		Element eleAdditionalInfo = SCXmlUtil.createChild(accPeriodInput.getDocumentElement(),
				KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
		eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
		log.info("getAccountingPeriodListForPOS input to MotherShip is " + XMLUtil.getXMLString(accPeriodInput));
		Document outputDocDate = callApi(env, accPeriodInput, businessDateTemplate, KohlsPOCConstant.V_MOTHERSHIP,
				KohlsPOCConstant.API_GET_ACC_PERIOD_LIST_POS);
		log.info("Output from Corp is " + XMLUtil.getXMLString(outputDocDate));

		Element eleCommonCodeList = outputDocDate.getDocumentElement();
		NodeList nodeListCommonCode = eleCommonCodeList.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);
		Element eleCommonCode = ((Element) nodeListCommonCode.item(0));
		int noOfRecords = Integer
				.parseInt(outputDocDate.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
		String storeOpenDate = "";		
		if (noOfRecords == 0) {
			accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_STATUS, "Close");
			accPeriodInputElm.removeAttribute(KohlsPOCConstant.A_CURRENT_PERIOD);
			log.info("Retrying to get the Close dates " + SCXmlUtil.getString(accPeriodInput));
			Document outputCloseDocDate = callApi(env, accPeriodInput, businessDateTemplate,
					KohlsPOCConstant.V_MOTHERSHIP, KohlsPOCConstant.API_GET_ACC_PERIOD_LIST_POS);
			log.info("Retrying to get the Close dates " + SCXmlUtil.getString(outputCloseDocDate));

			Element eleCloseDocDate = outputCloseDocDate.getDocumentElement();
			NodeList nodeListCloseDocDate = eleCloseDocDate.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);
			int noOfCloseRecords = Integer
					.parseInt(outputCloseDocDate.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_NUM_OF_RECORDS));
			if (noOfCloseRecords == 0) {				
				storeOpenDate = frmtCurrDate;	
				log.info("Setting system date, as no entries in accounting table for this store " + storeOpenDate);
			} else {
				ArrayList<String> busDates = new ArrayList<String>();
				for (int i = 0; i < nodeListCloseDocDate.getLength(); i++) {
					Element eleCloseDocDate1 = ((Element) nodeListCloseDocDate.item(i));
					busDates.add((eleCloseDocDate1.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY)));
				}
				storeOpenDate = Collections.max(busDates);
				log.info("Setting the close max date " + storeOpenDate);
			}
			
		} else {
			storeOpenDate = eleCommonCode.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
		}
		log.info("No of records and business date " + noOfRecords + ", " + storeOpenDate);
		
		String currSysDate = YFCDate.getYFCDate(frmtCurrDate).toString().substring(0, 8);
		String busDateFromCorp = YFCDate.getYFCDate(storeOpenDate).toString().substring(0, 8);
		if (Long.parseLong(currSysDate) > Long.parseLong(busDateFromCorp)) {
			log.info("Current system date is higher than Business date " + currSysDate + "  : "
					+ busDateFromCorp);	
			return frmtCurrDate;
		} else {
			log.info("Business date is higher than System date " + busDateFromCorp + "  : " + currSysDate);
			return storeOpenDate;
		}		
	}
	
	public Document callApi(YFSEnvironment env, Document inXML, Document outDoc, String sEndpoint, String sApiName)
			throws Exception {
		try {
			Document tempOutput = null;
			String envString = "<env userId='gravity' progId='gravity'/>";
			oApi = getDefaultAPI((YFSContext) env, sEndpoint);
			log.info("callApi is inProgress");
			YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
			tempOutput = oApi.invoke(newEnv, sApiName, inXML);
			log.info("callApi output is " + SCXmlUtil.getString(tempOutput));
			NodeList nodeListCommonCode = tempOutput.getElementsByTagName(KohlsPOCConstant.E_ERROR);
			if (nodeListCommonCode.getLength() > 0) {  // remote call failure
				throw new YFCException("Exception in remote call " + SCXmlUtil.getString(tempOutput));
			}			
			return tempOutput;
		} catch (Exception e) {
			log.error("Error in callApi " + e.getMessage() + e.getStackTrace());
			throw new YFCException("Exception in callApi");
		}
	}
	
	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			log.info("YIFClient using endpoint definition");
			Map<String, String> omap = new HashMap<String, String>();
			try {
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_USERID,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_USERID));
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_PASSWD,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_PASSWD));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}
		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode(KohlsPOCConstant.EDGE_SERVER_ERROR_CODE);
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), KohlsPOCConstant.EDGE_SER_NOT_CONFIGURED));
		throw oEx;
	}
	
	//Check the current store status 
	private boolean checkStoreOpenStatus(YFSEnvironment env, String StoreID) throws Exception{
		Document getStoreOpenInDoc = SCXmlUtil.createDocument(KohlsPOCConstant.A_ACC_PERIOD);
		Element accPeriodInputElm = getStoreOpenInDoc.getDocumentElement();
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_ORG_CODE, StoreID);
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_STATUS, KohlsPOCConstant.OPEN);
		accPeriodInputElm.setAttribute(KohlsPOCConstant.A_CURRENT_PERIOD, KohlsPOCConstant.YES);
		log.info("Input to accounting period list " + SCXmlUtil.getString(getStoreOpenInDoc));
		Document getStoreOpenOutDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_ACC_PERIOD_LIST_POS, getStoreOpenInDoc);
		log.info("Output of accounting period list " + SCXmlUtil.getString(getStoreOpenOutDoc));
		Element elmStoreOpenOutDoc = getStoreOpenOutDoc.getDocumentElement();
		NodeList nodeListStoreAccDetails = elmStoreOpenOutDoc.getElementsByTagName(KohlsPOCConstant.A_ACC_PERIOD);
		Element elmStoreAccDetails = ((Element) nodeListStoreAccDetails.item(0));		
		log.info("Store status is " + elmStoreAccDetails.getAttribute(KohlsPOCConstant.A_STATUS));
		if ( elmStoreAccDetails.getAttribute(KohlsPOCConstant.A_STATUS).equalsIgnoreCase(KohlsPOCConstant.OPEN)){
			return true;
		}else{
			return false;
		}	
	}
}
