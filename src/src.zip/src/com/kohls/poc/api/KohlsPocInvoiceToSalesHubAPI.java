package com.kohls.poc.api;

// Java Imports
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.FactoryConfigurationError;






import org.w3c.dom.DOMException;
// import org.apache.tools.ant.types.resources.selectors.None;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.util.barcode.KohlsCommonBarcodeUtils;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCEmvCardUtils;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.shared.dbclasses.YFS_Invoice_CollectionDBHome;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.wsauth.repackaged.apache.commons.codec.binary.Base64;
import com.sterlingcommerce.baseutil.SCXmlUtil;


/**************************************************************************
 * File : KohlsPoc KohlsPocInvoiceToSalesHubAPI.java Author : IBM Created : July 3 2013 Modified :
 * July 3 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 14/06/2013 IBM First Cut.
 ***************************************************************************** 
 * 
 * Copyright @ 2013. This document has been prepared and written by IBM Global Services on behalf of
 * Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the various attributes with respect to Payment Tender, Void
 * transactions,suspended transactions, sign in authentication details. It creates a document with
 * these attibutes and post the message to Sales Hub.
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/


public class KohlsPocInvoiceToSalesHubAPI implements YIFCustomApi  {
  private static final YFCLogCategory loggerForPosInvoice =
      YFCLogCategory.instance(KohlsPocInvoiceToSalesHubAPI.class.getName());

  private String strOrderHeaderKey = null;
  private String strOrganizationCode = null;
  private String strEnterpriseCode = null;
  private String strOrderNo = null;
  private boolean bIsVoidDuring = false;
  private String strOrderDocType = null;
  private String strOrderPurpose = null;
  private String strOrderProcID = null;
  private Map<String, Element> mTieredDiscount = new LinkedHashMap<String, Element>();
  private static Statement stmt = null;
  private HashMap<String,Double> promotionIDToAwardAmountMap = new HashMap<String, Double>();
  private HashMap<String,String> taxIndicatorToTaxAmountMap = new HashMap<String, String>();

  /**
   * This function generates the document to be sent to Sales Hub
   * 
   * @param env
   * @param inputPublishInvoiceDetail
   * @return docOutputPublishPOSInvoice
   * @exception Exception
   * 
   */
  public Document generateAndPublishPOSInvoiceToSalesHub(YFSEnvironment env,
      Document inputPublishInvoiceDetail) throws YFSException {

    loggerForPosInvoice
        .beginTimer("KohlsPocInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub");
    // Document docOutputPublishPOSInvoice = null;
    // Element eleOrderLineDetails = null;
    Document docVoidTenderChargeTransactionDetails = null;
    Element eleInvoiceHeader = null;
    Element eleAdminAuditList = null;
    

    try {

      if (loggerForPosInvoice.isDebugEnabled())
        loggerForPosInvoice.debug(
            "Input XML to KohlsPocInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub is: \n"
                + XMLUtil.getXMLString(inputPublishInvoiceDetail));

      // Fetch getOrderList API
      Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(env, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
      Document docGetOrderListDetails = this.getOrderListDetails(env, inputPublishInvoiceDetail,omni2ConfigMap);
      
//OMNI2 begin - Stamp ExtnReceiptID under /InvoiceDetail/InvoiceHeader/Order/Extn
      String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);
      
      if(KohlsPOCConstant.YES.equals(omni2Enabled)) {
	      Element invDtl = inputPublishInvoiceDetail.getDocumentElement();
	      Element invHdr = (Element)invDtl.getElementsByTagName(KohlsXMLLiterals.E_INVOICE_HEADER).item(0);
	      Element orderDetail = (Element)docGetOrderListDetails.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
	      Element ordExtn = (Element)orderDetail.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
	      Element invHdrExtn = (Element)invHdr.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
	      if((KohlsPOCConstant.CONSTANT_ORDER).equals(invHdr.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE)) && (KohlsPOCConstant.YES.equals (ordExtn.getAttribute(KohlsConstant.A_EXTN_IS_OMNI)))){
	  		String sEFC = invHdrExtn.getAttribute(KohlsXMLLiterals.A_EXTN_SHIP_NODE);
	  		String sOCF = invHdrExtn.getAttribute(KohlsXMLLiterals.A_EXTN_OCF);
	  		//update Sale Date for Pick Invoice as Pick Node BusinessDay
	  		getSaleDateForPickInvoice(env, inputPublishInvoiceDetail,orderDetail, sEFC);
	  		
	  		ordExtn.setAttribute(KohlsXMLLiterals.A_EXTN_RECEIPT_ID, getReceiptId(sEFC, docGetOrderListDetails, sOCF));
	  		updateRequestId(inputPublishInvoiceDetail);
	    	  
	      }
	      if((KohlsPOCConstant.A_IN_STORE).equals(invHdr.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE)) && (KohlsPOCConstant.YES.equals (ordExtn.getAttribute(KohlsConstant.A_EXTN_IS_OMNI)))){
	    	  updateCollectionDetails(env,inputPublishInvoiceDetail);
	      }
	      
	      //Process Omni Returns as POC Returns with extra flag as isOmniReturn as Y
	      if((KohlsPOCConstant.ATTR_RETURN).equals(invHdr.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE))  ){
	    	  updateIsOmniReturnFlag(env,orderDetail);
	      }
	      
      }
    //OMNI2 end - Stamp ExtnReceiptID under /InvoiceDetail/InvoiceHeader/Order/Extn

      /*
       * // EMV Changes : Sprint 10 : START // NodeList eleEmv =
       * (NodeList)XPathUtil.getNodeList(docGetOrderListDetails. getDocumentElement(),
       * "/OrderList/Order/PaymentMethods/PaymentMethod");
       * 
       * for(int i = 0; i < eleEmv.getLength(); i++){ Element
       * eleEmvPaymentMethod=(Element)eleEmv.item(i); checkForEMVData(eleEmvPaymentMethod);
       * loggerForPosInvoice. debug("The checkForEMVData input after decrypting : "
       * +XMLUtil.getElementXMLString(eleEmvPaymentMethod)); }
       * 
       * // EMV Changes : Sprint 10 : END //
       */

      
      // Iteration 3
      	Element eleOrder = (Element) ((NodeList) XPathUtil
          .getNodeList(docGetOrderListDetails.getDocumentElement(), "/OrderList/Order")).item(0);
		  String strPurpose = eleOrder.getAttribute("Purpose");
		  
		// un-commenting as part of PST-5779
		 Element elePersonInfoExtn =
		          (Element) ((NodeList) XPathUtil.getNodeList(docGetOrderListDetails.getDocumentElement(),
		              "/OrderList/Order/PersonInfoBillTo/Extn")).item(0);
		  if(!YFCCommon.isVoid(elePersonInfoExtn)){
			  if(!YFCCommon.isVoid(elePersonInfoExtn.getAttribute("ExtnDriversLicense"))){
				  String sDriverLicense=convertDL(elePersonInfoExtn.getAttribute("ExtnDriversLicense"));
				  elePersonInfoExtn.setAttribute("ExtnDriversLicense", sDriverLicense);
			  }
		  } 

		  Element eleOrderExtn =
				  (Element) ((NodeList) XPathUtil.getNodeList(docGetOrderListDetails.getDocumentElement(),
						  "/OrderList/Order/Extn")).item(0);
		// un-commenting as part of PST-5779
		   if(!YFCCommon.isVoid(eleOrderExtn)){
			  if(!YFCCommon.isVoid(eleOrderExtn.getAttribute(KohlsConstant.EXTN_DL_FOR_SYS))){
				  //Start PST-6571 sending ExtnDLNumberFormat as non converted value
				  String sExtnDLForSys=eleOrderExtn.getAttribute(KohlsConstant.EXTN_DL_FOR_SYS);
				  eleOrderExtn.setAttribute(KohlsConstant.EXTN_DL_NUMBER_FORMAT, sExtnDLForSys);
				  String sDriverLicense=convertDL(sExtnDLForSys);
				  //End PST-6571 sending ExtnDLNumberFormat as non converted value
				  eleOrderExtn.setAttribute(KohlsConstant.EXTN_DL_FOR_SYS, sDriverLicense);
			  }
			// below is NOT the right section to code for PST-4614. commenting it out. 
		    /**  if(!YFCCommon.isVoid(eleOrderExtn.getAttribute("ExtnDLNumberFormat")))
			  {
				  String sDriverLicense=convertDL(eleOrderExtn.getAttribute("ExtnDLNumberFormat"));
				  eleOrderExtn.setAttribute("ExtnDLNumberFormat", sDriverLicense);
			  } **/
		  } 
	  
	  
	  
      // loggerForPosInvoice.debug("Order Element before return
      // chnages"+XMLUtil.getElementXMLString(eleOrder));

      loggerForPosInvoice.debug("KohlsPocInvoiceToSalesHubAPI document type is "
          + eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE) + "and bIsVoidDuringflag is"
          + bIsVoidDuring);
      // For POC returns
      if (eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE)
          .equalsIgnoreCase(KohlsPOCConstant.RET_DOC_TYPE)) {
        if (bIsVoidDuring) {
          inputPublishInvoiceDetail.getDocumentElement().setAttribute(KohlsPOCConstant.MES_TYPE,
              "ReturnVoidDuring");
        } else {

          inputPublishInvoiceDetail.getDocumentElement().setAttribute(KohlsPOCConstant.MES_TYPE,
              KohlsPOCConstant.RETURN);
        }

      } else {
        eleAdminAuditList = this.getAdminAuditList(env, eleOrder);
      }

      // Start - Change for Tax Details - 10/18
      String strExtnTaxDetails = eleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
      Element eleTaxDetails = null;
      if (!YFCCommon.isVoid(strExtnTaxDetails)) {
        Document docExtnTaxDetails = XMLUtil.getDocument(strExtnTaxDetails);
        eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, KohlsPOCConstant.BLANK);
        eleTaxDetails = docExtnTaxDetails.getDocumentElement();
        // docGetOrderListDetails.importNode(eleTaxDetails, true);
        XMLUtil.importElement(eleOrder, eleTaxDetails);
      }
      
      Element eleIDScanDetails = null;
      if(!YFCCommon.isVoid(eleOrderExtn.getAttribute("ExtnIDScanDetails")))
	  {
				 Document docExtnIDScanDetils=XMLUtil.getDocument(eleOrderExtn.getAttribute("ExtnIDScanDetails"));
				 eleOrderExtn.setAttribute("ExtnIDScanDetails", KohlsPOCConstant.BLANK);
				 eleIDScanDetails = docExtnIDScanDetils.getDocumentElement();
				 XMLUtil.importElement(eleOrder,eleIDScanDetails);
			 }
      eleInvoiceHeader = (Element) ((NodeList) XPathUtil.getNodeList(
          inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader")).item(0);
      Element eleInvoiceOrder = (Element) ((NodeList) XPathUtil.getNodeList(
          inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order"))
              .item(0);
      eleInvoiceHeader.removeChild(eleInvoiceOrder);
      updateCouponInquiryDetails(eleOrder);

      XMLUtil.importElement(eleInvoiceHeader, eleOrder);
      Element eleInvOrder = (Element) ((NodeList) XPathUtil.getNodeList(
          inputPublishInvoiceDetail.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/Order"))
              .item(0);


      // End - Change for Tax Details - 10/18

      // Element eleOrderOverallTotals =
      // (Element)((NodeList)XPathUtil.getNodeList(docGetOrderListDetails.getDocumentElement(),
      // "/OrderList/Order/OverallTotals")).item(0);
      // Element eleOrderPromotions =
      // (Element)((NodeList)XPathUtil.getNodeList(docGetOrderListDetails.getDocumentElement(),
      // "/OrderList/Order/Promotions")).item(0);

      // Fetch orderline details

      // eleOrderLineDetails = this.getOrderLineDetails(env,
      // docGetOrderListDetails);

      // Append order line details to PublishPOSOrderInvoice XML


      // Element eleAppendedTags = XMLUtil.importElement(eleInvOrder,
      // eleOrderExtn);
      // Start - Change for Tax Details - 10/18
      // eleAppendedTags = XMLUtil.importElement(eleInvOrder,
      // eleTaxDetails);
      // End - Change for Tax Details - 10/18
      // eleAppendedTags = XMLUtil.importElement(eleInvOrder,
      // eleOrderOverallTotals);
      // eleAppendedTags = XMLUtil.importElement(eleInvOrder,
      // eleOrderLineDetails);
      // eleAppendedTags = XMLUtil.importElement(eleInvOrder,
      // eleOrderPromotions);

      /*
       * //[Manoj 10/04]: Adding PosSequenceNo on Sales Hub Out xml Element eleOrder =
       * (Element)((NodeList)XPathUtil.getNodeList(docGetOrderListDetails. getDocumentElement(),
       * "/OrderList/Order")).item(0); eleInvOrder.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO,
       * eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO));
       * eleInvOrder.setAttribute("CustomerRewardsNo", eleOrder.getAttribute("CustomerRewardsNo"));
       */

      // [Sudina 02/12/2014]: Added Createts attribute for defect #1353
      // eleInvOrder.setAttribute(KohlsPOCConstant.A_CREATE_TS,
      // eleOrder.getAttribute(KohlsPOCConstant.A_CREATE_TS));

      // Fetch Digital Signature Capture Details

      Document docDigSignCapDetails =
          this.getDigitalSignatureCaptureDetails(env, docGetOrderListDetails);
      NodeList ndListDigSignCap =
          docDigSignCapDetails.getElementsByTagName(KohlsPOCConstant.ATTR_SIGN_CAP_LIST);
      Element eleSignCapDetails = (Element) ndListDigSignCap.item(0);
      XMLUtil.importElement(eleInvoiceHeader, eleSignCapDetails);

      Element elePaymentMethods = (Element) ((NodeList) XPathUtil.getNodeList(
          inputPublishInvoiceDetail.getDocumentElement(),
          "/InvoiceDetail/InvoiceHeader/Order/PaymentMethods")).item(0);
      eleInvOrder.removeChild(elePaymentMethods);

      // Fetch Charge Transaction Details for void transaction
      docVoidTenderChargeTransactionDetails = this.getVoidTenderChargeTransactionDetails(env, strPurpose);
      NodeList ndListVTCTDetails = docVoidTenderChargeTransactionDetails
          .getElementsByTagName(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS);
      Element eleVoidTenderChargeTransactionDetails = (Element) ndListVTCTDetails.item(0);
      XMLUtil.importElement(eleInvOrder, eleVoidTenderChargeTransactionDetails);

      /*
       * //Fetch Voided transaction details for the order in input xml Document
       * docVoidTransactionDetails = this.getVoidTransactionAuditDetails(env); NodeList
       * ndListVoidTransDetails = docVoidTransactionDetails.getElementsByTagName(KohlsPOCConstant.
       * 
       * ATTR_TRANSACTION_AUDITS); Element eleVoidTransAuditDetails = (Element)
       * ndListVoidTransDetails.item(0); XMLUtil.importElement(eleInvoiceHeader,
       * eleVoidTransAuditDetails);
       */

      /*
       * //Fetch Suspended transaction details Document docSuspendedTransDetails =
       * this.getSuspendedTransactionAuditDetails(env); Element eleSuspendTransactrionDetails =
       * 
       * (Element) ((NodeList) docSuspendedTransDetails.getElementsByTagName(KohlsPOCConstant.
                                                                                                                                                                             
       * ATTR_TRANSACTION_AUDITS)).item(0); Element eleAuditSuspendTransDetail = (Element)
       * eleSuspendTransactrionDetails.getElementsByTagName(
       * KohlsPOCConstant.ATTR_TRANSACTION_AUDIT).item(0); Element eleInvTransAudits = (Element)
       * eleInvoiceHeader.getElementsByTagName(KohlsPOCConstant. ATTR_TRANSACTION_AUDITS).item(0);
       * XMLUtil.importElement(eleInvTransAudits, eleAuditSuspendTransDetail);
       */

      // Fetch transaction specific details
      // Element eleInvTransAudits = XMLUtil.createChild(eleInvoiceHeader,
      // "TransactionAudits");
      Document docTransAuditList = this.getCreateTransactionDetails(env);
      Element eleTransAuditDetails = (Element) ((NodeList) docTransAuditList
          .getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDITS)).item(0);
      XMLUtil.importElement(eleInvoiceHeader, eleTransAuditDetails);
	  
	  /*Import AdminAuditList if present*/
      if(!YFCCommon.isVoid(eleAdminAuditList)) {

        Element eleAdminAudit = XMLUtil.getChildElement(eleAdminAuditList, KohlsPOCConstant.ELE_ADMIN_AUDIT);
         XMLUtil.importElement(eleInvoiceHeader, eleAdminAuditList);
      }

      inputPublishInvoiceDetail = addAuthIDForCollectionDetails(env, inputPublishInvoiceDetail, strPurpose);
      updateSplitAmountInfo(inputPublishInvoiceDetail);

      // PST-843 changes start
      inputPublishInvoiceDetail = setDateInvoicedForSaleSyncedToCorp(env, inputPublishInvoiceDetail,
          eleInvoiceHeader, eleInvoiceOrder);
      // PST-843 changes end
      // Manoj 10/23: calculating and adding the Tiered promos at order
      // header level
      if (mTieredDiscount.size() > 0) {
        if (loggerForPosInvoice.isVerboseEnabled()) {
          loggerForPosInvoice
              .verbose("Tierd Discount found on the Order. Appending them at the Order level");
        }
        Element eleTLDList =
            inputPublishInvoiceDetail.createElement("TransactionLevelDiscountList");
        eleInvOrder.appendChild(eleTLDList);
        for (String key : mTieredDiscount.keySet()) {
          XMLUtil.importElement(eleTLDList, mTieredDiscount.get(key));
        }
        mTieredDiscount.clear();
      }
      
      //OMNI2 Changes - Start
      Element orderDetail = (Element)docGetOrderListDetails.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
      Element ordExtn = (Element)orderDetail.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
      if(KohlsPOCConstant.YES.equals(omni2Enabled) && KohlsPOCConstant.YES.equals (ordExtn.getAttribute(KohlsConstant.A_EXTN_IS_OMNI))) {
    	  if(loggerForPosInvoice.isDebugEnabled()) {
    		  loggerForPosInvoice.debug("inputPublishInvoiceDetail before Promotion and TaxDetailList update: "+XMLUtil.getXMLString(inputPublishInvoiceDetail));
    	  }
    	  
    	  //OMNI2 - Update the Order level Promotions values only for the lines that is invoiced.
    	  inputPublishInvoiceDetail = updateOrderLevelPromotions(inputPublishInvoiceDetail);
    	  //OMNI2 - Update the TaxDetailList values only for the lines that is invoiced.
    	  inputPublishInvoiceDetail = updateTaxDetailList(inputPublishInvoiceDetail);
    	  
    	  if(loggerForPosInvoice.isDebugEnabled()) {
    		  loggerForPosInvoice.debug("inputPublishInvoiceDetail after Promotion and TaxDetailList update: "+XMLUtil.getXMLString(inputPublishInvoiceDetail));
    	  }
    	  
    	  //OMNI2 - Updating the Invoice's DateInvoiced attribute to current timestamp for OMNI2 pick invoices.
    	  inputPublishInvoiceDetail = updateDateInvoiced(inputPublishInvoiceDetail);
      }
      //OMNI2 Changes - End
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }



    if (YFCCommon
        .isVoid(inputPublishInvoiceDetail.getDocumentElement().getAttribute("MessageType"))) {
            
                                                                                         
     
                                                        

      // Manoj - Defect 1915 begin: Set Message type - Begin
      if (bIsVoidDuring) {
        inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "VoidDuring");
      } else {
        inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "Sale");

      }
      // Manoj - Defect 1915 begin: Set Message type - End
    }

    
    //Added for CPE-5563 Start
    
    inputPublishInvoiceDetail=updateKCPaymentCorrectionDetails(env, inputPublishInvoiceDetail);
  
    if (loggerForPosInvoice.isDebugEnabled())
      loggerForPosInvoice.debug(
          "Output XML from KohlsPocInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub is: \n"
              + XMLUtil.getXMLString(inputPublishInvoiceDetail));

    loggerForPosInvoice
        .endTimer("KohlsPocInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub");
    return inputPublishInvoiceDetail;
  }
  
  
  
  /**
   * Verify if sales Order was omni Order
   * @param env
   * @param orderDetail
   */
  private void updateIsOmniReturnFlag(YFSEnvironment env, Element orderEle) {
	  boolean isOmnniReturn=false;
	  if(!YFCCommon.isVoid(orderEle)) {
		     NodeList eleDerviedFromOrderList=SCXmlUtil.getXpathNodes(orderEle,"//Order/OrderLines/OrderLine/DerivedFromOrder");
		     if(eleDerviedFromOrderList.getLength()>0) {
		    	  for(int i=0; i<eleDerviedFromOrderList.getLength(); i++) {
		    		  Element eleDerviedFromOrder=(Element)eleDerviedFromOrderList.item(i);
		    		  String strIsOmniOrderReturn=SCXmlUtil.getXpathAttribute(eleDerviedFromOrder,"//DerivedFromOrder/Extn/@ExtnIsOmni");
		    		  if(!YFCCommon.isVoid(strIsOmniOrderReturn) && strIsOmniOrderReturn.equalsIgnoreCase("Y")) {
		    			  isOmnniReturn=true;
		    			  break;
		    		  }
		    	  }
		     }
		   if(isOmnniReturn) {
		     NodeList referenceList=SCXmlUtil.getXpathNodes(orderEle,"//Order/References");
				 Element  eleReferences= SCXmlUtil.getXpathElement(orderEle,"//Order/References");
			    if(referenceList.getLength()==0) 
					eleReferences = XMLUtil.createChild(orderEle, KohlsPOCConstant.A_REFERENCES);			 
			    Element eleReference = XMLUtil.createChild(eleReferences, KohlsPOCConstant.A_REFERENCE);
			    eleReference.setAttribute(KohlsPOCConstant.Name, "IsOmniReturn");
			    eleReference.setAttribute(KohlsPOCConstant.Value,"Y");
	}
	}	
	  }
	



/**
   *This method is called only for OMNI2 orders. It updates the PICK Invoice's DateInvoiced attribute to current timestamp, so that invoice time is after open register time.
   *
   * @param inputPublishInvoiceDetail
   * @return
   */
  private Document updateDateInvoiced(Document inputPublishInvoiceDetail) {

	  Element invHeaderEle = (Element) inputPublishInvoiceDetail.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELE_INVOICE_HEADER).item(0);
	  String invoiceType = invHeaderEle.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE);
	  if(KohlsPOCConstant.CONSTANT_ORDER.equalsIgnoreCase(invoiceType)) {
		  SimpleDateFormat timeStampFormatter = new SimpleDateFormat(KohlsPOCConstant.A_TIME_FORMAT);
		  invHeaderEle.setAttribute(KohlsPOCConstant.A_DATE_INVOICED, timeStampFormatter.format(new Date()));
	  }
	  return inputPublishInvoiceDetail;
  }


/**
   * This method is called only for OMNI2 orders. It will update the Order level Promotion's @OverrideAdjustmentValue 
   * to the sum of  OrderLine --> Award --> @AwardAmt having the same PromotionId, for the orderlines that are invoiced in one invoice.
   * 
 * @param inputPublishInvoiceDetail
 * @return
 * @throws Exception
 */
private Document updateOrderLevelPromotions(Document inputPublishInvoiceDetail) throws Exception {
	  loggerForPosInvoice.beginTimer("Enter updateOrderLevelPromotions");

	  NodeList nlOrderPromotions = XPathUtil.getNodeList(inputPublishInvoiceDetail, "/InvoiceDetail/InvoiceHeader/Order/Promotions/Promotion");
	  int promoLength = nlOrderPromotions.getLength();

	  for(int count = 0; count < promoLength; count++) {
		  Element promotion = (Element) nlOrderPromotions.item(count);
		  String orderPromotionID = promotion.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
		  String promotionAmt = promotion.getAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
		  if(loggerForPosInvoice.isDebugEnabled()) {
			  loggerForPosInvoice.debug("orderPromotionID :"+orderPromotionID);
			  loggerForPosInvoice.debug("promotionAmt :"+promotionAmt);
			  loggerForPosInvoice.debug("promotionIDToAwardAmountMap :"+promotionIDToAwardAmountMap);
		  }

		  if(promotionIDToAwardAmountMap.containsKey(orderPromotionID)) {
			  double orderLineAwardAmtSum =  promotionIDToAwardAmountMap.get(orderPromotionID);
			  promotion.setAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, Double.toString(orderLineAwardAmtSum));
			  if(loggerForPosInvoice.isDebugEnabled()) {
				  loggerForPosInvoice.debug("Setting promotion amount to :"+orderLineAwardAmtSum);
			  }
		  }
	  }
	  loggerForPosInvoice.endTimer("Exit updateOrderLevelPromotions");
	  return inputPublishInvoiceDetail;
  }

/** This method is called only for OMNI2 orders. It will update the 
 * TaxDetailList --> TaxDetail @TotalAmount to the sum of  OrderLine --> LineOverallTotals --> @LineTotalWithoutTax 
 * TaxDetailList --> TaxDetail @TaxAmount to the sum of  OrderLine --> LineOverallTotals --> @Tax 
 * for the orderlines that are invoiced in one invoice.
   * 
 * @param inputPublishInvoiceDetail
 * @return
 * @throws Exception
 */
private Document updateTaxDetailList(Document inputPublishInvoiceDetail) throws Exception {
	loggerForPosInvoice.beginTimer("Enter updateTaxDetailList");

	if(loggerForPosInvoice.isDebugEnabled()) {
		loggerForPosInvoice.debug("taxIndicatorToTaxAmountMap : "+taxIndicatorToTaxAmountMap);
	}

	Element taxDetailList = (Element) inputPublishInvoiceDetail.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_TAX_DETAIL_LIST).item(0);
	NodeList taxDetailNodeList = taxDetailList.getElementsByTagName(KohlsPOCConstant.E_TAX_DETAIL);
	Element newTaxDetailList = inputPublishInvoiceDetail.createElement(KohlsPOCConstant.E_TAX_DETAIL_LIST);
	int taxDetailUpdateCount = taxDetailNodeList.getLength();

	for(int count=0;count<taxDetailUpdateCount;count++) {
		Element taxDetail = (Element) taxDetailNodeList.item(count);
		String taxInd = taxDetail.getAttribute(KohlsPOCConstant.A_TAX_INDICATOR);
		if(taxIndicatorToTaxAmountMap.containsKey(taxInd)) {
			String value = taxIndicatorToTaxAmountMap.get(taxInd);
			String[] tokens = value.split(KohlsPOCConstant.UNDERSCORE);
			taxDetail.setAttribute(KohlsPOCConstant.A_TAX_AMOUNT, tokens[0]);
			taxDetail.setAttribute(KohlsPOCConstant.A_TOATL_AMOUNT, tokens[1]);
			Node importedNode = inputPublishInvoiceDetail.importNode(taxDetail, true);
			newTaxDetailList.appendChild(importedNode);
		}
	}
	Node parentNode = taxDetailList.getParentNode();
	parentNode.removeChild(taxDetailList);
	parentNode.appendChild(newTaxDetailList);

	loggerForPosInvoice.endTimer("Exit updateTaxDetailList");
	return inputPublishInvoiceDetail;
}

/**
   * @param env
   * @param inputPublishInvoiceDetail
   * @throws DOMException
   */
  public Document updateKCPaymentCorrectionDetails(YFSEnvironment env,
  		Document inputPublishInvoiceDetail) throws DOMException {
  	   loggerForPosInvoice
         .beginTimer("KohlsPocInvoiceToSalesHubAPI.updateKCPaymentCorrectionDetails");
  

        if (loggerForPosInvoice.isDebugEnabled())                   
         loggerForPosInvoice.debug(
             "Input XML to KohlsPocInvoiceToSalesHubAPI.updateKCPaymentCorrectionDetails is: \n"
                 + XMLUtil.getXMLString(inputPublishInvoiceDetail));

  	
  	//CPE 5563 - Start
    // strOrderProcID.equals("133") && strOrderProcID.equals("137")
        if(strOrderDocType.equalsIgnoreCase("9090.ex") && strOrderPurpose.equals("KCPaymentCorrection")){                                         
      	
      	 if(!bIsVoidDuring){
      		 int count=1;
      		String strPrevDate=getYesterdayDateString(count);
      	  //Form getCommonCodeList Input
      	 try {
      		 //Get Previous Date
      		strPrevDate=getYesterdayDateString(count);   		
      		Document outDoc= KohlsCommonUtil.getCommonCodeList(env, "HOLIDAY_LIST","DEFAULT");
  			NodeList holidayList=outDoc.getElementsByTagName(KohlsPOCConstant.E_COMMON_CODE);
  			//verify if entry exists in common Code table
  			//Verify if previous date is holiday
  			if(outDoc.getDocumentElement().hasChildNodes()){					
  				for(int i=0;i<holidayList.getLength();i++){
  					Element eleCommonCode=(Element)holidayList.item(i);
  					String strHolidayDate=eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_VALUE);
  					if(strHolidayDate.equalsIgnoreCase(strPrevDate)){
  						strPrevDate=getYesterdayDateString(count+1);
						i=0;  						
  				}	}
  			}
  			//Stamp payment correction Date
  			Element eleOrder=(Element)inputPublishInvoiceDetail.getElementsByTagName("Order").item(0);
  			inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "KCPaymentCorrection");
  			eleOrder.setAttribute("KCPaymentCorrectionDate", strPrevDate);
  			}
      	 catch (Exception e) {
      		//Stamp payment correction Date
   			Element eleOrder=(Element)inputPublishInvoiceDetail.getElementsByTagName("Order").item(0);
   			inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "KCPaymentCorrection");
   			eleOrder.setAttribute("KCPaymentCorrectionDate", strPrevDate);
   			 if (e instanceof YFSException) {
	              YFSException yfsException = (YFSException) e;
	              loggerForPosInvoice.error("CommonCodeList Not Configured Properly- HOLIDAY_LIST, Please verify");
   			 }
   			 else{	
   				 loggerForPosInvoice.error("Error while getting previous date of calendar, Please verify");
   			 	}
   			 	loggerForPosInvoice.error("Date is defaulted to Previous Day");
      	 	} } 
      	 else{ //For VoidDuring just stamp MessageType
  			 inputPublishInvoiceDetail.getDocumentElement().setAttribute("MessageType", "KCPaymentCorrectionVoidDuring");
      	 }    
       }
        //CPE 5563 - End
        return inputPublishInvoiceDetail;
   }
  

  // Added to send the AuthorizationID alone

  private void checkForEMVData(Element elePayment) {
    // EMV Changes : START //

    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.checkForEMVData -- Start");


    Hashtable<String, String> hpEmvtbl = new Hashtable<String, String>();
    String keysstr = null;
    String valuStr = null;
    String streleEMVExtnEMVResponsetag1 = null;
    String strExtnEmvResponseTags = null;


    Element eleEMVExtn = XMLUtil.getChildElement(elePayment, "Extn");

    if (!YFCCommon.isVoid(eleEMVExtn)) {

      // Element eleEMVExtnEMVResponsetag =
      // XMLUtil.getChildElement(eleEMVExtn,"ExtnEmvResponseTags");
      strExtnEmvResponseTags = eleEMVExtn.getAttribute("ExtnEmvResponseTags");
      loggerForPosInvoice
          .debug("KohlsPocInvoiceToSalesHubAPI.checkForEMVData -- strExtnEmvResponseTags"
              + strExtnEmvResponseTags);
      if (!YFCCommon.isVoid(strExtnEmvResponseTags))

      {

        // streleEMVExtnEMVResponsetag1 =
        // eleEMVExtnEMVResponsetag.getTextContent();
        // XMLUtil.removeChild(eleEMVExtn,"ExtnEmvResponseTags");

        eleEMVExtn.removeAttribute("ExtnEmvResponseTags");
        // eleEMVExtn.createChild(Element
        // extnNew,"ExtnEmvResponseTags");
        Element extnNew = XMLUtil.createChild(eleEMVExtn, "ExtnEmvResponseTags");
        // Toshiba method which decrypts the string and returns a
        // HashMap
        hpEmvtbl = NRSCEmvCardUtils.nrscParseEmvData(strExtnEmvResponseTags);

        // temporary logic to print the logs - start

        Set set = hpEmvtbl.entrySet();
        Iterator it = set.iterator();
        while (it.hasNext()) {
          Map.Entry entry = (Map.Entry) it.next();
          loggerForPosInvoice.debug(entry.getKey() + " : " + entry.getValue());
        }
        // temporary logic to print the logs - end

        extnNew.setAttribute("EMV_TAG_50", hpEmvtbl.get("EMV_TAG_50"));
        extnNew.setAttribute("EMV_CHIP_INDICATOR", hpEmvtbl.get("EMV_CHIP_INDICATOR"));
        extnNew.setAttribute("EMV_CVM", hpEmvtbl.get("EMV_CVM"));
        extnNew.setAttribute("EMV_MODE", hpEmvtbl.get("EMV_MODE"));
        extnNew.setAttribute("EMV_TAG_5F34", hpEmvtbl.get("EMV_TAG_5F34"));
        extnNew.setAttribute("EMV_TAG_95", hpEmvtbl.get("EMV_TAG_95"));
        extnNew.setAttribute("EMV_TAG_9B", hpEmvtbl.get("EMV_TAG_9B"));
        extnNew.setAttribute("EMV_TAG_4F", hpEmvtbl.get("EMV_TAG_4F"));
        extnNew.setAttribute("EMV_TAG_9F10", hpEmvtbl.get("EMV_TAG_9F10"));
        extnNew.setAttribute("EMV_TAG_8A", hpEmvtbl.get("EMV_TAG_8A"));


        if (loggerForPosInvoice.isDebugEnabled()) {
          loggerForPosInvoice
              .debug("The EMV Extn attributes are : " + XMLUtil.getElementXMLString(extnNew));
          loggerForPosInvoice
              .debug("The EMV Extn attributes are : " + XMLUtil.getElementXMLString(elePayment));
        }
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.checkForEMVData -- End");
  }

  // EMV Changes : END //


  protected Element checkForEMVDataForSPS(Element elePayment) {
    // EMV Changes : START //

    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.checkForEMVDataForSPS -- Start");

    String keysstr = null;
    String valuStr = null;
    String strDecodedValue = null;
    String strEmvResponseTags = null;


    Element eleExtn = XMLUtil.getChildElement(elePayment, "Extn");

    if (!YFCCommon.isVoid(eleExtn)) {

      strEmvResponseTags = eleExtn.getAttribute("ExtnEmvResponseTags");
      loggerForPosInvoice
              .debug("KohlsPocInvoiceToSalesHubAPI.checkForEMVDataForSPS -- strEmvResponseTags"
                      + strEmvResponseTags);
      if (!YFCCommon.isVoid(strEmvResponseTags)) {

        XMLUtil.removeAttribute(eleExtn, "ExtnEmvResponseTags");

        Element extnNew = XMLUtil.createChild(eleExtn, "ExtnEmvResponseTags");
        // Invoke Base64 Decoder
        try {
          strDecodedValue = new String(Base64.decodeBase64(strEmvResponseTags), "UTF-8");
		  loggerForPosInvoice.debug("Decoded Value ::::" + strDecodedValue);
        } catch (UnsupportedEncodingException e) {
          throw new YFSException(e.getMessage());
        }

        String [] strEmvTag = strDecodedValue.split(",");

        // temporary logic to print the logs - start

        if(!YFCCommon.isVoid(strEmvTag)) {

          for(String entry : strEmvTag) {
            String [] str = entry.split(":");
            loggerForPosInvoice.debug(str[0] + " : " + str[1]);
            keysstr = str[0];
            valuStr = str[1];

            if(!YFCCommon.isVoid(keysstr)) {
              extnNew.setAttribute(keysstr.trim(), valuStr);
            }

          }
        }
        // temporary logic to print the logs - end

        if (loggerForPosInvoice.isDebugEnabled()) {
          loggerForPosInvoice
                  .debug("The EMV Extn attributes are : " + XMLUtil.getElementXMLString(extnNew));
          loggerForPosInvoice
                  .debug("The EMV Payment attributes are : " + XMLUtil.getElementXMLString(elePayment));
        }
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.checkForEMVDataForSPS -- End");
    return elePayment;
  }

  public Document addAuthIDForCollectionDetails(YFSEnvironment env, Document invoiceInputDoc, String strPurpose)
      throws Exception {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.addAuthIDForCollectionDetails");
    NodeList eleCollectionList =
        (NodeList) XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail");

    // EMV changes Sprint 10 : START //
    // NodeList eleEmv =
    // (NodeList)XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(),
    // "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail")

    for (int i = 0; i < eleCollectionList.getLength(); i++) {

      Element eleCollection = (Element) eleCollectionList.item(i);
      Element elePaymentMethod = (Element) XMLUtil.getChildElement(eleCollection, "PaymentMethod");
      Element personInfoBillTo = XMLUtil.getChildElement(elePaymentMethod, "PersonInfoBillTo");
      if(!YFCCommon.isVoid(personInfoBillTo))
      {
    	  	Element billToExtn = XMLUtil.getChildElement(personInfoBillTo, "Extn");
    	  	if(!YFCCommon.isVoid(billToExtn))
    	  	{
    	  		if(!YFCCommon.isVoid(billToExtn.getAttribute("ExtnDriversLicense"))){
  				  String sDriverLicense=convertDL(billToExtn.getAttribute("ExtnDriversLicense"));
  				  // This is the only place which needs to be converted and that goes under corporate refund section of invoice xml 
  				  billToExtn.setAttribute("ExtnDriversLicense", sDriverLicense);
  			  }
    	  	}
      }
	  if("SPS".equals(strPurpose)) {
        checkForEMVDataForSPS(elePaymentMethod);
      } else {
        checkForEMVData(elePaymentMethod);
      }    
	  }


    // EMV changes Sprint 10 : END //


    Document docOutputPymtExtnList = null;
    for (int i = 0; i < eleCollectionList.getLength(); i++) {
      Element eleCollection = (Element) eleCollectionList.item(i);
      if (!YFCCommon.isVoid(eleCollection.getAttribute("AuthorizationID"))) {
        String sAuthID = eleCollection.getAttribute("AuthorizationID");
        String[] authIDSplits = sAuthID.split("=");
        eleCollection.setAttribute("AuthorizationID", authIDSplits[0]);
      }
      // Sudina - Start - Defect # 2407
      Element eleCreditCardTransactions = (Element) eleCollection
          .getElementsByTagName(KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTIONS).item(0);
      NodeList ndListCreditCardTransList =
          eleCollection.getElementsByTagName(KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTION);
      if (ndListCreditCardTransList.getLength() == 0
          && !YFCCommon.isVoid(eleCollection.getAttribute("CallForAuthorizationStatus"))
          && eleCollection.getAttribute("CallForAuthorizationStatus").equalsIgnoreCase("CLOSED")) {
        // paymentKeys.add(eleCollection.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY));
        // If the Payment extension is null then call
        // KohlsPoCGetPaymentExtnList service
        if (YFCCommon.isVoid(docOutputPymtExtnList)) {
          Element eleOrder =
              (Element) ((NodeList) XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(),
                  "/InvoiceDetail/InvoiceHeader/Order")).item(0);
          Document docInputForPaymentExtnList = YFCDocument
              .createDocument(KohlsPOCConstant.ELEM_KOHLS_PAYMENT_EXTENSION).getDocument();
          docInputForPaymentExtnList.getDocumentElement().setAttribute(
              KohlsPOCConstant.ATTR_ORD_HDR_KEY,
              eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
          docOutputPymtExtnList =
        		  KOHLSBaseApi.invokeService(env, "KohlsPoCGetPaymentExtnList", docInputForPaymentExtnList);
        }
        String sPaymentKey = eleCollection.getAttribute("PaymentKey");
        Element elePymtExtn = (Element) ((NodeList) XPathUtil.getNodeList(
            docOutputPymtExtnList.getDocumentElement(),
            "/KohlsPaymentExtensionList/KohlsPaymentExtension[@PaymentKey='" + sPaymentKey + "']"))
                .item(0);
        // Set the attributes from elePymtExt to eleCreditCardTran
        String strExtnPaymentData = elePymtExtn.getAttribute("ExtnPaymentData");
        if (!YFCCommon.isVoid(strExtnPaymentData)) {
          Document docExtnPaymentData = XMLUtil.getDocument(strExtnPaymentData);
          XMLUtil.importElement(eleCreditCardTransactions, docExtnPaymentData.getDocumentElement());
        }
      }
      // Sudina - End - Defect # 2407
    }

    /*
     * if(paymentKeys.size() > 0) { // Call Service getKohlsPaymentExtensionList() Element eleOrder
     * = (Element)((NodeList)XPathUtil.getNodeList(invoiceInputDoc. getDocumentElement(),
     * "/OrderList/Order")).item(0); Document docInputForPaymentExtnList =
     * YFCDocument.createDocument(KohlsPOCConstant. ELEM_KOHLS_PAYMENT_EXTENSION).getDocument();
     * docInputForPaymentExtnList.getDocumentElement().setAttribute(
     * KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
     * try { Document docOutputPymtExtnList = invokeService(env, "KohlsPoCGetPaymentExtnList",
     * docInputForPaymentExtnList); while(paymentKeys.iterator().hasNext()) { String pymtKey =
     * paymentKeys.iterator().next().toString(); NodeList ndColList = (NodeList)
     * XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(),
     * "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail"); for(int i = 0; i <
     * ndColList.getLength(); i++){ Element eleColDtl=(Element)ndColList.item(i);
     * if(eleColDtl.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY).equals( pymtKey)) { Element
     * eleCtCardTrans = XMLUtil.createChild(eleColDtl,
     * KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTIONS);
     * 
     * NodeList ndListPymtExtn = (NodeList)
     * XPathUtil.getNodeList(docOutputPymtExtnList.getDocumentElement(),
     * "/KohlsPaymentExtensionList/KohlsPaymentExtension"); for(int j=0; j<
     * ndListPymtExtn.getLength(); j++) { Element elePymtExtn = (Element)ndListPymtExtn.item(j);
     * if(elePymtExtn.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY).equals (pymtKey)) { //Set the
     * attributes from elePymtExt to eleCreditCardTran String
     * strExtnPaymentData=elePymtExtn.getAttribute("ExtnPaymentData");
     * if(!YFCCommon.isVoid(strExtnPaymentData)) { Document
     * docExtnPaymentData=XMLUtil.getDocument(strExtnPaymentData); Element
     * eleCreditCardTran=docExtnPaymentData.getDocumentElement();
     * XMLUtil.importElement(eleCtCardTrans,eleCreditCardTran); } break; } } break; } } } } catch
     * (Exception e) { e.printStackTrace(); }
     * 
     * }
     */
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.addAuthIDForCollectionDetails");
    return invoiceInputDoc;
  }

  /**
   * This function fetches the order details to be posted to Sales Hub.
   * 
   * @param env
   * @param inputDoc
   * @return docOutputPublishPOSInvoice
   * @exception Exception
   * 
   */
  // Seetha comment Removed YFS and YFC exception and added Exception
  private Document getOrderListDetails(YFSEnvironment env, Document inVoiceInputDoc,Map<String, String> omni2ConfigMap)
      throws YFSException {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getOrderListDetails");
    Document docOrderListOutput = null;
    loggerForPosInvoice.debug(
        "KohlsPocInvoiceToSalesHubAPI.generateAndPublishPOSInvoiceToSalesHub -- Calling getOrderLineDetails");
    try {

      setOrderLevelDetails(env, inVoiceInputDoc);

      // Create Input XML for getOrderList API

      Document docInputForGetOrderList =
          YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER).getDocument();
      Element eleOrderInput = docInputForGetOrderList.getDocumentElement();
      eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
      eleOrderInput.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, strEnterpriseCode);

      // Call getOrderList API
      docOrderListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ORDER_LIST_OUTPUT,
          KohlsPOCConstant.API_GET_ORDER_LIST, docInputForGetOrderList);
      // MAD-101 start
      Element eleOrder = null;
      if (!YFCCommon.isVoid(docOrderListOutput)) {
        eleOrder = (Element) ((NodeList) XPathUtil
            .getNodeList(docOrderListOutput.getDocumentElement(), "/OrderList/Order")).item(0);
      }
      // MAD-101 End
      // Check if transaction is Void During or Sale
      Element eleOrderExtn = (Element) ((NodeList) XPathUtil
          .getNodeList(docOrderListOutput.getDocumentElement(), "/OrderList/Order/Extn")).item(0);
      
    //OMNI2 begin - Filter Pick vs Carry lines Invoice
      Element invDtl = inVoiceInputDoc.getDocumentElement();
      Element invHdr = (Element)invDtl.getElementsByTagName(KohlsXMLLiterals.E_INVOICE_HEADER).item(0);      
     
      Element eleOrdExtn = (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
      String extnIsOmni = eleOrdExtn.getAttribute(KohlsConstant.A_EXTN_IS_OMNI);
      
		String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);
      
      if(KohlsPOCConstant.YES.equals(extnIsOmni)  && KohlsPOCConstant.YES.equals(omni2Enabled)) {
	      if(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE).equals(KohlsPOCConstant.SO_DOCUMENT_TYPE) && invHdr.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE).equals(KohlsPOCConstant.A_IN_STORE)) {
	    	  String filter = "PICK";
	    	  docOrderListOutput = filteringForCarryInvoice(filter, docOrderListOutput);
	      }
	      else if(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE).equals(KohlsPOCConstant.SO_DOCUMENT_TYPE) && invHdr.getAttribute(KohlsPOCConstant.A_INVOICE_TYPE).equals(KohlsPOCConstant.CONSTANT_ORDER)) {	    	  
	    	  Element lineDetails =    (Element) XPathUtil.getNode(inVoiceInputDoc.getDocumentElement(), "/InvoiceDetail/InvoiceHeader/LineDetails");
	          ArrayList<String> orderLineKeysWithPick = new ArrayList<String>();
	    	  NodeList ndLineDtlList =  lineDetails.getElementsByTagName(KohlsXMLLiterals.E_LINE_DETAIL);
	    	  int lineDetailcount = ndLineDtlList.getLength();
    		  for(int count = 0; count < lineDetailcount ; count++ ) {
    			  Element eleLineDetail = (Element) ndLineDtlList.item(count);
    				  orderLineKeysWithPick.add(eleLineDetail.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));
    		  }
	    	  
	    	  docOrderListOutput = filteringForPickInvoice(docOrderListOutput, orderLineKeysWithPick);
	      }
	      NodeList ndTotalOrderLines = (NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
	              "/OrderList/Order/OrderLines/OrderLine");
		  Element eleOrderLines = (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES).item(0);
		  eleOrderLines.setAttribute(KohlsPOCConstant.ATTR_TOT_NO_RECORDS, String.valueOf(ndTotalOrderLines.getLength()));
      }
      
      
    //OMNI2 end - Filter Pick vs Carry lines Invoice - End
      
      // MAD-101 start
      stampPosSequenceNumber(eleOrder, eleOrderExtn);
      // MAD-101 End
      String sExtnIsVoidDuring = eleOrderExtn.getAttribute("ExtnIsVoidDuring");

      if (!YFCCommon.isVoid(sExtnIsVoidDuring) && "Y".equalsIgnoreCase(sExtnIsVoidDuring)) {
        bIsVoidDuring = true;
      }
      String strOrderReference = "";
      String strItemDesc="";
      NodeList ndListOrderLine =
          (NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
              "/OrderList/Order/OrderLines/OrderLine");
      if (ndListOrderLine.getLength() != 0) {
        for (int i = 0; i < ndListOrderLine.getLength(); i++) {
          DecimalFormat df = new DecimalFormat("0.00");
          Element eleOrderLine = (Element) ndListOrderLine.item(i);
          if (!YFCCommon.isVoid(eleOrderLine)) {

            // Start of PST-971
            Element orderLineExtn =
                (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
            
            //OMNI2 Changes - Start
            if(KohlsPOCConstant.YES.equals(extnIsOmni)  && KohlsPOCConstant.YES.equals(omni2Enabled)) {
            	DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
            	String taxStr = null;
            	String lineTotalWothoutTaxStr  = null;
            	Element lineOverallTotals = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_OVERALL_TOTALS).item(0);
            	if(!YFCCommon.isVoid(lineOverallTotals)) {
            		lineTotalWothoutTaxStr = lineOverallTotals.getAttribute(KohlsPOCConstant.E_LINE_TOTAL_WITHOUT_TAX);
            		taxStr = lineOverallTotals.getAttribute(KohlsPOCConstant.ATTR_TAX);
            	}
            	String extnTaxIndicator = orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_INDICATOR);
            	if(!YFCCommon.isVoid(extnTaxIndicator) && !YFCCommon.isVoid(!YFCCommon.isVoid(lineTotalWothoutTaxStr)) && !YFCCommon.isVoid(taxStr)) {
            		if(taxIndicatorToTaxAmountMap.containsKey(extnTaxIndicator)) {
            			String value = taxIndicatorToTaxAmountMap.get(extnTaxIndicator);
            			String[] tokens = value.split(KohlsPOCConstant.UNDERSCORE);
            			BigDecimal tax = new BigDecimal(tokens[0]).add(new BigDecimal(taxStr));
            			taxStr = twoDForm.format(tax);
            			BigDecimal lineTotalWothoutTax = new BigDecimal(tokens[1]).add(new BigDecimal(lineTotalWothoutTaxStr));
            			lineTotalWothoutTaxStr =  twoDForm.format(lineTotalWothoutTax);
            			taxIndicatorToTaxAmountMap.put(extnTaxIndicator, taxStr+KohlsPOCConstant.UNDERSCORE+lineTotalWothoutTaxStr);
            		}else {
            			taxIndicatorToTaxAmountMap.put(extnTaxIndicator, taxStr+KohlsPOCConstant.UNDERSCORE+lineTotalWothoutTaxStr);
            		}
            	}
            }
            //OMNI2 Changes - End
            
            String sExtnNetPrice =
                    orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE);

                if (YFCCommon.isVoid(sExtnNetPrice)) {
                  orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, "0.0");
                }

            if (!YFCObject.isVoid(orderLineExtn)) {
              if (orderLineExtn.hasAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE)) {

                String extnSimplePromoPrice =
                    orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE);

                if (YFCCommon.isVoid(extnSimplePromoPrice)) {
                  orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
                }
              } else {
                orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
              }
            } else {
              Element extnOrderLine = docOrderListOutput.createElement(KohlsPOCConstant.A_EXTN);
              extnOrderLine.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");
              eleOrderLine.appendChild(extnOrderLine);
            }
            // End of PST-971                  

            String sOrderLineKey = eleOrderLine.getAttribute("OrderLineKey");
            Element eleItem = XMLUtil.getFirstElementByName(eleOrderLine, "Item");


            if (loggerForPosInvoice.isDebugEnabled())
              loggerForPosInvoice
                  .debug(" Item node List is : " + XMLUtil.getElementXMLString(eleItem));

            String strItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
            if(!YFCCommon.isVoid(eleItem.getAttribute(KohlsPOCConstant.A_ITEM_DESC)))
            {
             strItemDesc= eleItem.getAttribute(KohlsPOCConstant.A_ITEM_DESC);
            }
           
        	
        	if(YFCCommon.isVoid((orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS ))))
        	{
        		
        		orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS , "");
        		
        	}
        
            if(strItemID.endsWith("000") ||(!YFCCommon.isVoid( strItemDesc) && strItemDesc.equalsIgnoreCase("Not on File")) )
            {
            	String sDeptId= strItemID.substring(0,3);
        		String sSubClass = strItemID.substring(4,6);
        		
            	if(YFCCommon.isVoid((orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT ))))
            	{
            		
            		orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT , sDeptId);
            		
            	}
            	if(YFCCommon.isVoid((orderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS))))
            	{
            		
            		orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS, sSubClass);
            		
            	}
            	
            }
         
            String strUPCCode = eleItem.getAttribute(KohlsPOCConstant.ATTR_UPC_CODE);
            String strUnitCost = eleItem.getAttribute(KohlsPOCConstant.ATTR_UNIT_COST);
            String strTaxPdtCode = eleItem.getAttribute(KohlsPOCConstant.ATTR_TAX_PRODUCT_CODE);
            loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getItemList");
            Document docItemListOutput = KohlsPoCPnPUtil.getItemListOutPut(env, strItemID);
            loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getItemList");

            loggerForPosInvoice.debug("strUPCCode: " + strUPCCode);

            // Start of code changes for PST-588
            Element eleItemOutput = null;
            if (docItemListOutput != null
                && !strItemID.equalsIgnoreCase(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM)) {
              loggerForPosInvoice.debug("Not a Void Transaction item");
              eleItemOutput = (Element) ((NodeList) XPathUtil
                  .getNodeList(docItemListOutput.getDocumentElement(), "/ItemList/Item")).item(0);
              // Manoj:Fix for defect 2875 - Begin
              if (!YFCCommon.isVoid(strUPCCode)) {
                eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE, strUPCCode);
              } else {
            	  String sUPCCode= KohlsPoCPnPUtil.getUpcCode(docItemListOutput);
            	  if(YFCCommon.isVoid(strUPCCode)){
            		// Calling same method that translateBarcode API uses to convert SKU to UPC
            	    // to maintain consistency.
            	    sUPCCode = KohlsCommonBarcodeUtils.createUPCFromSKU(strItemID);
            	  }
            	  eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_UPC_CODE,
            			  sUPCCode);
              }
              // Manoj:Fix for defect 2875 - End
              eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_UNIT_COST, strUnitCost);
              eleItemOutput.setAttribute(KohlsPOCConstant.ATTR_TAX_PRODUCT_CODE, strTaxPdtCode);
              // Extract and Append ExtnSalesHubData
              // Start the Clob Column logic
              // Manoj 10/30: Added logic to identify the item as DummySKU

              Element eleItemExtn = (Element) XPathUtil
                  .getNode(docItemListOutput.getDocumentElement(), "/ItemList/Item/Extn");
              String sExtnDept = eleItemExtn.getAttribute("ExtnDept");
              String sExtnSubClass = eleItemExtn.getAttribute("ExtnSubClass");
              String sDummySKUNo = KohlsPoCPnPUtil.prepadString(sExtnDept, 3, "0")
                  + KohlsPoCPnPUtil.prepadString(sExtnSubClass, 2, "0") + "000";
              if (strItemID.equalsIgnoreCase(sDummySKUNo)) {
                loggerForPosInvoice.debug("dummy sku no is: " + sDummySKUNo);
                eleOrderLine.setAttribute("IsDummySKU", "Y");
              }
              //CPE-4316 Begin
              try {
	              String extnCallbackTypeCode = eleItemExtn.getAttribute("ExtnCallbackTypeCode");
	              String extnCallbackStart = eleItemExtn.getAttribute("ExtnCallbackStartDate");
	              String extnCallbackEnd = eleItemExtn.getAttribute("ExtnCallbackEndDate");
	              if (!YFCCommon.isVoid(extnCallbackTypeCode)) {
	            	  Calendar currDate = Calendar.getInstance();
	                  Calendar cExtnCallbackStart = DatatypeConverter.parseDateTime( extnCallbackStart );
	                  Calendar cExtnCallbackEnd = DatatypeConverter.parseDateTime( extnCallbackEnd );
	                  if ( extnCallbackTypeCode.equalsIgnoreCase( "2" ) && currDate.after( cExtnCallbackStart ) && currDate.before( cExtnCallbackEnd ) )
	                  {
	                	  orderLineExtn.setAttribute("ExtnCallBackInd", "Y");
	                  }
	              }
              } catch (Exception callbackException) {
            	  loggerForPosInvoice.debug("Error in Callback Type: " + callbackException);
              }
              
              //CPE-4316 End
              // Manoj 10/30: end of logic
              XMLUtil.removeChild(eleOrderLine, eleItem);
              XMLUtil.importElement(eleOrderLine, eleItemOutput);
            }
            // End of code changes for PST-588


                                                           
                                                                                                                                                                        
                                                                                                                     
                                                 
                                                                                                                                                                      
                                                                                                             
                                                                                                  
                                                                                                                                                            
                                                                                                                                                                            
                                                                                                
                                                                                                                                                                                                
                                                                                               
                                                                                                                                                                                 
                                                         
                                                                                                                     
                                                                                      
                                                                                                
                                                                                      
                                                                  
               

            // Extract and Append ExtnSalesHubData
            // Start the Clob Column logic
            NodeList nlAwardList = XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
                "/OrderList/Order/OrderLines/OrderLine[@OrderLineKey='" + sOrderLineKey
                    + "']/Awards/Award");

            if (nlAwardList != null) {
              for (int j = 0; j < nlAwardList.getLength(); j++) {
                Element eleAward = (Element) nlAwardList.item(j);
                String sAwardApplied = eleAward.getAttribute("AwardApplied");
                
                //OMNI2 Changes - Start
                String awardPromotionId = eleAward.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
                String awardAmount = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT);

                if(KohlsPOCConstant.YES.equals(extnIsOmni)  && KohlsPOCConstant.YES.equals(omni2Enabled)) {
                	if(!YFCCommon.isVoid(awardPromotionId)) {
                		if(promotionIDToAwardAmountMap.containsKey(awardPromotionId)) {
                			double value  = promotionIDToAwardAmountMap.get(awardPromotionId);
                			promotionIDToAwardAmountMap.put(awardPromotionId, value+Double.parseDouble(awardAmount));
                		}else {
                			promotionIDToAwardAmountMap.put(awardPromotionId, Double.parseDouble(awardAmount));
                		}
                	}
                }
                //OMNI2 Changes - End
                
                Element eleExtn = XMLUtil.getChildElement(eleAward, "Extn");
                if (!YFCCommon.isVoid(eleExtn)) {
                  loggerForPosInvoice.verbose("*******Inside ExtnElemet****");
                  String strExtnSalHubData = eleExtn.getAttribute("ExtnSalesHubData");
                  String sExtnPromoScheme = eleExtn.getAttribute("ExtnPromoScheme");
                  int iExtnPromoScheme = 0;
                  if (!YFCCommon.isVoid(sExtnPromoScheme)) {
                    iExtnPromoScheme = Integer.parseInt(sExtnPromoScheme);
                  }
                  if (!YFCCommon.isVoid(strExtnSalHubData)) {
                    Document docSalesHubData = XMLUtil.getDocument(strExtnSalHubData);
                    eleExtn.setAttribute("ExtnSalesHubData", "");
                    Element eleDataSalesHub = docSalesHubData.getDocumentElement();
                    XMLUtil.importElement(eleExtn, eleDataSalesHub);
                    // Manoj 10/24 : identifying the Tierd
                    // Promos and appending at the Order
                    // level
                    if (iExtnPromoScheme >= 400 && iExtnPromoScheme <= 500
                        && sAwardApplied.equalsIgnoreCase("Y")) {
                      String sPromoInterfaceId = eleDataSalesHub.getAttribute("PromoInterfaceId");
                      String sDiscountPercent = eleDataSalesHub.getAttribute("DiscountPercent");
                      if (!YFCCommon.isVoid(sDiscountPercent)) {
                        sDiscountPercent = df.format(Double.parseDouble(sDiscountPercent) / 100.0);
                      }
                      String sTierAmtRchd = eleDataSalesHub.getAttribute("TierAmtRchd");
                      String sTierQtyRchd = eleDataSalesHub.getAttribute("TierQtyRchd");
                      String sAwardAmount = eleAward.getAttribute("AwardAmount");
                      if (!mTieredDiscount.containsKey(sPromoInterfaceId)) {
                        Document docTLD = XMLUtil.createDocument("TransactionLevelDiscount");
                        Element eleTLD = docTLD.getDocumentElement();
                        eleTLD.setAttribute("PromoInterfaceId", sPromoInterfaceId);
                        eleTLD.setAttribute("DiscountPercent", sDiscountPercent);
                        eleTLD.setAttribute("TierAmtRchd", sTierAmtRchd);
                        eleTLD.setAttribute("TierQtyRchd", sTierQtyRchd);
                        eleTLD.setAttribute("AwardAmount", sAwardAmount);
                        eleTLD.setAttribute("PromoScheme", sExtnPromoScheme);
                        eleTLD.setAttribute("DiscountTypeCode", "T");
                        mTieredDiscount.put(sPromoInterfaceId, eleTLD);
                      } else {
                        Element eleTLD = mTieredDiscount.get(sPromoInterfaceId);
                        String sAwardAmt = eleTLD.getAttribute("AwardAmount");
                        Double dOrigAwardAmt = 0.00;
                        if (!YFCCommon.isVoid(sAwardAmt)) {
                          dOrigAwardAmt = Double.parseDouble(sAwardAmt);
                        }
                        Double dAwardAmt = 0.00;
                        if (!YFCCommon.isVoid(sAwardAmount)) {
                          dAwardAmt = Double.parseDouble(sAwardAmount);
                        }
                        eleTLD.setAttribute("AwardAmount", df.format(dOrigAwardAmt + dAwardAmt));
                        mTieredDiscount.remove(sPromoInterfaceId);
                        mTieredDiscount.put(sPromoInterfaceId, eleTLD);
                      }
                    }
                  }

                }
              }
            }
            Element eleAdditionalAttr = (Element) XPathUtil.getNode(
                docItemListOutput.getDocumentElement(),
                "/ItemList/Item/AdditionalAttributeList/AdditionalAttribute[@Name='POSStoredValueCategory']");
            if (!YFCCommon.isVoid(eleAdditionalAttr)) {
              String strValue = eleAdditionalAttr.getAttribute(KohlsPOCConstant.A_VALUE);
              if (strValue.equalsIgnoreCase(KohlsPOCConstant.STRING_RETAILER)
                  || strValue.equalsIgnoreCase(KohlsPOCConstant.STRING_BLACKHAWK)) {
                // Form input xml for
                // getStoredValueLineListForPOS API

                Document docStoredValueLineListInput = YFCDocument
                    .createDocument(KohlsPOCConstant.ELEM_STORED_VALUE_LINE).getDocument();
                Element eleStoredValueLineListInput =
                    docStoredValueLineListInput.getDocumentElement();
                eleStoredValueLineListInput.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY,
                    sOrderLineKey);

                // Invoke getStoredValueLineListForPOS API
                // Manoj: Updaed for defect 2873 - Begin
                Document docStoredValueLineListOutput = KOHLSBaseApi.invokeAPI(env,
                    XMLUtil.getDocument(KohlsPOCConstant.GET_STORED_VALUE_LINE_LIST_TEMPLATE),
                    KohlsPOCConstant.API_GET_STORED_VALUE_LINE_LIST_FOR_POS,
                    docStoredValueLineListInput);
                // Manoj: Updaed for defect 2873 - End
                Element eleStoredValueLine = (Element) ((NodeList) XPathUtil.getNodeList(
                    docStoredValueLineListOutput.getDocumentElement(),
                    "/StoredValueLineList/StoredValueLine")).item(0);
                XMLUtil.importElement(eleOrderLine, eleStoredValueLine);
              }

            }
            // Code Changes for 09/30 Gift Card Changes -- End

            // Start Sprint-1 POC Return-- 2017 Release

            /*
             * if (YFCCommon.equalsIgnoreCase(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE),
             * KohlsPOCConstant.RET_DOC_TYPE)) {
             * 
             * Element custAttributesEle = XMLUtil.getChildElement(eleOrderLine,
             * KohlsPOCConstant.CUST_ATTRIBUTES); Element extnEle =
             * XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
             * extnEle.setAttribute(KohlsPOCConstant.EXTN_SO_NO,
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT6));
             * extnEle.setAttribute(KohlsPOCConstant.EXTN_SO_STORE,
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT7));
             * extnEle.setAttribute(KohlsPOCConstant.EXTN_SO_TERMINAL_NO,
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT8));
             * extnEle.setAttribute(KohlsPOCConstant.EXTN_SO_TRAN_NO,
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT9));
             * extnEle.setAttribute(KohlsPOCConstant.EXTN_SO_TRAN_DATE,
             * custAttributesEle.getAttribute(KohlsPOCConstant.DATE2));
             * extnEle.setAttribute(KohlsPOCConstant.EXTN_SO_LINE_NO,
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT10)); //
             * tempLineEle.removeChild(custAttributesEle); strOrderReference =
             * KohlsPOCConstant.TENDER + "-" +
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT7) + "-" +
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT8) + "-" +
             * custAttributesEle.getAttribute(KohlsPOCConstant.TEXT9); }
             */

          }
        }

      }
      if (YFCCommon.equalsIgnoreCase(eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE),
          KohlsPOCConstant.RET_DOC_TYPE)) {
        Element eleReferences = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.A_REFERENCES);

        NodeList ndlReference =
		          (NodeList) XPathUtil.getNodeList(eleReferences,
		              "Reference");
		      if (ndlReference.getLength() != 0) {
		        for (int i = 0; i < ndlReference.getLength(); i++) {
		          Element eleReference  = (Element) ndlReference.item(i);
		         
		      	
		          String temp="";
					
		          String sRefValue =eleReference.getAttribute("Value");
		        if(!YFCCommon.isVoid(sRefValue)){
		          
		          if(sRefValue.contains("KohlsCharge"))
	    			{
	    				
		        	  sRefValue =sRefValue.replace("KohlsCharge", "04");
	    				eleReference.setAttribute(KohlsPOCConstant.Value, sRefValue);
	    				
	    			}
		       
		          
		        String arrTempRefName[]= sRefValue.split("-");
		 	
		 		if(arrTempRefName.length>0)
		 		{
		 			
		 			for(int m=0;m<arrTempRefName.length;m++)
		 			{
		 				String tempRefVal =arrTempRefName[m];
		 				String newValue = null;
		 				if(tempRefVal.contains("_"))

			 			{
			 					if(tempRefVal.endsWith("_"))
			 					{
			 						
			 						newValue=tempRefVal.substring(0,tempRefVal.lastIndexOf("_"));
			 						sRefValue = sRefValue.replace(tempRefVal, newValue);
			 					}
			 			}
		 				
		 			}
		 		}
			
					
					eleReference.setAttribute("Value", sRefValue);
						

		        }
		        }

		      }
        
        NodeList invoicePaymentMethodsNL =
            eleOrder.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);

        for (int i = 0; i < invoicePaymentMethodsNL.getLength(); i++) {
          Element tempEle = (Element) invoicePaymentMethodsNL.item(i);

          Double refundAmt = Double.parseDouble(tempEle.getAttribute("TotalRefundedAmount"));
          if (refundAmt > 0.0) {
            Element eleReference = XMLUtil.createChild(eleReferences, KohlsPOCConstant.A_REFERENCE);
            eleReference.setAttribute(KohlsPOCConstant.Name, strOrderReference);
            eleReference.setAttribute(KohlsPOCConstant.Value,
                tempEle.getAttribute(KohlsPOCConstant.A_PAYMENT_TYPE) + "-"
                    + tempEle.getAttribute("DisplayPaymentReference1") + "-"
                    + tempEle.getAttribute("TotalRefundedAmount"));

          }

        }

        updateEReceiptEmailDetails(eleOrder);
        	
      }
    } catch (Exception exception) {
    	loggerForPosInvoice.error("Error While fetching the order details to be posted to Sales Hub \n",exception);
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getOrderListDetails");
    return docOrderListOutput;
  }

  /**
   * This function fetches the order line details from getOrderList output
   * 
   * @param env
   * @param inputDoc
   * @return eleOrderLines
   * @exception None
   * 
   */

  private Element getOrderLineDetails(YFSEnvironment env, Document docOrderListInput) {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getOrderLineDetails");
    KohlsPocInvoiceToSalesHubAPI.loggerForPosInvoice
        .debug("KohlsPocInvoiceToSalesHubAPI.getOrderLineDetails--- BEGIN");
    Element eleOrderLines = null;

    // Fetch the orderline information from getOrderList output
    NodeList ndOrderLines =
        docOrderListInput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES);
    eleOrderLines = (Element) ndOrderLines.item(0);

    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getOrderLineDetails");
    return eleOrderLines;
  }


  /**
   * This function fetches all the payment keys for the given order
   * 
	 	 * @param env
	 	 * @param inputDoc
	 	 * @return arListPaymentKeys
	 	 * @exception
   * 
   */

  private ArrayList getPaymentKeys(YFSEnvironment env, Document orderListDoc) throws YFSException {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getPaymentKeys");
    KohlsPocInvoiceToSalesHubAPI.loggerForPosInvoice
        .debug("KohlsPocInvoiceToSalesHubAPI.getPaymentKeys--- BEGIN");
    ArrayList arListPaymentKeys = new ArrayList();
    try {

      Element eleOrder =
          (Element) ((NodeList) orderListDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER))
              .item(0);
      NodeList ndPaymentMethod = eleOrder.getElementsByTagName(KohlsPOCConstant.E_PAYMENT_METHOD);
      for (int i = 0; i < ndPaymentMethod.getLength(); i++) {
        Element elePaymentMethod = (Element) ndPaymentMethod.item(i);
        arListPaymentKeys.add(elePaymentMethod.getAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY));
      }
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getPaymentKeys");
    return arListPaymentKeys;
  }



  /**
   * This function returns the charge transactions details for a void transaction if any.
   * 
	  * @param env
	  * @return docVoidChargeTransDetailsOutput
	  * @exception
   */


  private Document getVoidTenderChargeTransactionDetails(YFSEnvironment env, String strPurpose) throws YFSException {
    loggerForPosInvoice
        .beginTimer("KohlsPocInvoiceToSalesHubAPI.getVoidTenderChargeTransactionDetails");
    Document docVoidChargeTransDetailsOutput=null;
    String finalAuthID="";

    try {
      // Invoke getChargeTransactionList API
      Document docVoidChargeTransOutput =
          getChargeTransactionDetails(env, this.strOrderHeaderKey, this.strOrganizationCode);

      // EMV changes Sprint 10 : START //
       docVoidChargeTransDetailsOutput = YFCDocument
              .createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAILS).getDocument();
      Element eleChargeTransDtls = docVoidChargeTransDetailsOutput.getDocumentElement();

      NodeList ndChargeTransDtl =
          (NodeList) XPathUtil.getNodeList(docVoidChargeTransOutput.getDocumentElement(),
              "/ChargeTransactionDetails/ChargeTransactionDetail");
      for (int i = 0; i < ndChargeTransDtl.getLength(); i++) {
        Element eleChargeTransDetail = (Element) ndChargeTransDtl.item(i);
        Element elePaymentMethod =
            (Element) XMLUtil.getChildElement(eleChargeTransDetail, "PaymentMethod");
      //OMNI2 Begin - Fix to not import CTRs with AuthorizationIDs starting with 0000
        String authID = eleChargeTransDetail.getAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID);
        if(!YFCCommon.isVoid(authID) && authID.length()>4)
        {
        finalAuthID = authID.substring(0, 4);
        }
        if(!"0000".equals(finalAuthID)) {
        //Added to handle multiple void tenders for SPS orders and Omni/POC orders
        XMLUtil.importElement(eleChargeTransDtls, eleChargeTransDetail);
        }
        //OMNI2 End - Fix to not import CTRs with AuthorizationIDs starting with 0000
        //OMNI2 - Adding finalAuthID if condition to block importing CTRs for OMNI orders with AuthIds starting from 0000
        if("SPS".equals(strPurpose) && !"0000".equals(finalAuthID)) {
          checkForEMVDataForSPS(elePaymentMethod);
        } else if(!"0000".equals(finalAuthID)) {
          checkForEMVData(elePaymentMethod);
        }
      }
      // EMV changes Sprint 10 : END //

    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice
        .endTimer("KohlsPocInvoiceToSalesHubAPI.getVoidTenderChargeTransactionDetails");
    
    return docVoidChargeTransDetailsOutput;
  }

  public Document getChargeTransactionDetails(YFSEnvironment env, String strOrderHeaderKey,
      String strOrganizationCode) throws Exception {
    // Create input XML for getChargeTransactionList API
    Document docInputForGetChargeTransactionList =
        YFCDocument.createDocument(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_DETAIL).getDocument();
    Element eleChargeTransactionInput =
        (Element) docInputForGetChargeTransactionList.getDocumentElement();
    eleChargeTransactionInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
    eleChargeTransactionInput.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
        strOrganizationCode);
    // Defect #1454 : Void transaction value changed from V to S - Start
    eleChargeTransactionInput.setAttribute(KohlsPOCConstant.ATTR_VOID_TRANSACTION,
        KohlsPOCConstant.STATIC_CONSTANT_SUBMITTED);
    // Defect #1454 : Void transaction value changed from V to S - End

    // Invoke getChargeTransactionList API
    Document docVoidChargeTransOutput =
        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_VOID_CHARGE_TRANSACTION_OUTPUT,
            KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, docInputForGetChargeTransactionList);
    return docVoidChargeTransOutput;
  }


  /**
   * This function returns the digital signature cap details.
   * 
	  * @param env
	  * @param inputDoc
	  * @return docDigSignCaptureOutput
	  * @exception
   */

  private Document getDigitalSignatureCaptureDetails(YFSEnvironment env, Document inputDoc)
      throws YFSException {

    loggerForPosInvoice
        .beginTimer("KohlsPocInvoiceToSalesHubAPI.getDigitalSignatureCaptureDetails");

    Document docDigSignCaptureOutput =
        YFCDocument.createDocument(KohlsPOCConstant.ATTR_SIGN_CAP_LIST).getDocument();
    Element eleSignCapList = docDigSignCaptureOutput.getDocumentElement();
    ArrayList arListPaymentKeysListforDigSign = new ArrayList();
    try {
      arListPaymentKeysListforDigSign = this.getPaymentKeys(env, inputDoc);
      if (arListPaymentKeysListforDigSign.size() != 0) {
        for (int i = 0; i < arListPaymentKeysListforDigSign.size(); i++) {

          // Create input for getSigCapListForPOS API
          Document docInputForGetSignCapDetails =
              (Document) YFCDocument.createDocument(KohlsPOCConstant.ATTR_SIGN_CAP).getDocument();
          Element eleSignCap = (Element) docInputForGetSignCapDetails.getDocumentElement();
          // eleSignCap.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
          // strOrganizationCode);
          // eleSignCap.setAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY,
          // (String) arListPaymentKeysListforDigSign.get(i));

          // suraj - Added for TenderSignature Issue - Start
          String strPaymentKey = (String) arListPaymentKeysListforDigSign.get(i);
          Element eleOrder = (Element) ((NodeList) XPathUtil
              .getNodeList(inputDoc.getDocumentElement(), "/OrderList/Order")).item(0);
          String strOrgCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);

          eleSignCap.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrgCode);
          eleSignCap.setAttribute(KohlsPOCConstant.ATTR_PAYMENT_KEY, strPaymentKey);
          eleSignCap.setAttribute(KohlsPOCConstant.ATTR_PARENT_TABLE_KEY, strPaymentKey);
          eleSignCap.setAttribute(KohlsPOCConstant.ATTR_PARENT_TABLE, KohlsPOCConstant.YFS_PAYMENT);
          // suraj - Added for TenderSignature Issue - End

          // Invoke getSigCapListForPOS API
          Document docOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_SIGN_CAP_LIST_FOR_POS,
              docInputForGetSignCapDetails);
          eleSignCap =
              (Element) ((NodeList) docOutput.getElementsByTagName(KohlsPOCConstant.ATTR_SIGN_CAP))
                  .item(0);
          Element eleSignCapOutput = XMLUtil.importElement(eleSignCapList, eleSignCap);
        }
      }
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getDigitalSignatureCaptureDetails");
    return docDigSignCaptureOutput;
  }

  /**
   * This function returns Audit Details for Void Transaction.
   * 
	  * @param env
	  * @return docChargeTransactionDetailsOutput
	  * @exception
   */


  private Document getVoidTransactionAuditDetails(YFSEnvironment env) throws YFSException {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getVoidTransactionAuditDetails");
    Document docVoidTransDtls = null;
    try {

      Document docTransAuditOutput = setTransAuditDetails(env,
          KohlsPOCConstant.STATIC_CONSTANT_VOIDED_TRANSACTION_PROCEDURE_ID);
      docVoidTransDtls =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDITS).getDocument();
      if (!YFCDocument.isNull(docTransAuditOutput)) {
        Element eleFinalVoidTransDtls = docVoidTransDtls.getDocumentElement();
        NodeList ndListTransDetails = (NodeList) docTransAuditOutput
            .getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
        if (ndListTransDetails.getLength() != 0) {
          for (int i = 0; i < ndListTransDetails.getLength(); i++) {
            Element eleVoidTransElement = (Element) ndListTransDetails.item(i);
            String strAmount =
                (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_AMOUNT);
            String strTerminalID =
                (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
            String strTransNum =
                (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM);
            String strTransAuditKey =
                (String) eleVoidTransElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_AUDIT_KEY);

            Element eleTransOutputElement =
                XMLUtil.createChild(eleFinalVoidTransDtls, KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, strOrderNo);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,
                KohlsPOCConstant.STATIC_CONSTANT_VOIDED_TRANSACTION_PROCEDURE_ID);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
                strOrganizationCode);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_AMOUNT, strAmount);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, strTransNum);
            eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TRANS_AUDIT_KEY,
                strTransAuditKey);
          }
        }
      }
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getVoidTransactionAuditDetails");
    return docVoidTransDtls;
  }

  /**
   * This function returns Audit Details for Suspended transactions.
   * 
	  * @param env
	  * @return docSuspendedTransAuditDetails
	  * @exception
   */

  private Document getSuspendedTransactionAuditDetails(YFSEnvironment env) throws YFSException {
    loggerForPosInvoice
        .beginTimer("KohlsPocInvoiceToSalesHubAPI.getSuspendedTransactionAuditDetails");
    Document docSuspendedTransAuditDetails = null;
    try {

      Document docSuspendedAuditOutput = setTransAuditDetails(env,
          KohlsPOCConstant.STATIC_CONSTANT_SUSPENDED_TRANSACTION_PROCEDURE_ID);
      docSuspendedTransAuditDetails =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDITS).getDocument();
      Element eleSuspendTransAudit = docSuspendedTransAuditDetails.getDocumentElement();
      NodeList ndListTransDetails = (NodeList) docSuspendedAuditOutput
          .getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);

      if (ndListTransDetails.getLength() != 0) {
        for (int i = 0; i < ndListTransDetails.getLength(); i++) {
          Element eleSuspendTransElement = (Element) ndListTransDetails.item(i);
          String strTerminalID =
              (String) eleSuspendTransElement.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
          String strTransNum =
              (String) eleSuspendTransElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM);
          String strDateTime =
              (String) eleSuspendTransElement.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME);

          Element eleTransOutputElement =
              XMLUtil.createChild(eleSuspendTransAudit, KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
          // Element eleTransOutputElement =
          // docSuspendedTransAuditDetails.createElement(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
          eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, strTerminalID);
          eleTransOutputElement.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
              strOrganizationCode);
          eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, strTransNum);
          eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_DATE_TIME, strDateTime);
          eleTransOutputElement.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,
              KohlsPOCConstant.STATIC_CONSTANT_SUSPENDED_TRANSACTION_PROCEDURE_ID);
        }
      }
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice
        .endTimer("KohlsPocInvoiceToSalesHubAPI.getSuspendedTransactionAuditDetails");

    return docSuspendedTransAuditDetails;
  }

  /**
   * This function returns Audit Details for Create/SignIn transactions.
   * 
	  * @param env
	  * @return docTransSpecDetail
	  * @exception
   */


  private Document getCreateTransactionDetails(YFSEnvironment env) throws YFSException {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getCreateTransactionDetails");
    Document docTransSpecDetail = null;
    try {

      docTransSpecDetail = setTransAuditDetails(env,
          KohlsPOCConstant.STATIC_CONSTANT_CREATE_TRANSACTION_PROCEDURE_ID);
      /*
       * 
       * docTransSpecDetail = YFCDocument.createDocument(KohlsPOCConstant.
       * ATTR_TRANSACTION_AUDITS).getDocument(); Element eleTransSpecAuditOutput =
       * docTransSpecDetail.getDocumentElement(); NodeList ndListTransDetails = (NodeList)
       * 
       * docTransSpecificAuditOutput.getElementsByTagName(KohlsPOCConstant .ATTR_TRANSACTION_AUDIT);
       * int numberOfRecords = ndListTransDetails.getLength();
       * 
       * if (numberOfRecords!= 0){ for (int i = 0; i< numberOfRecords; i++) { Element
       * eleTransSpecificElement = (Element) ndListTransDetails.item(i); String strTerminalID =
       * eleTransSpecificElement.getAttribute(KohlsPOCConstant. ATTR_TERMINAL_ID); String
       * strTransNum = eleTransSpecificElement.getAttribute(KohlsPOCConstant. ATTR_TRANS_NUM);
       * String strTransAuditKey = eleTransSpecificElement.getAttribute(KohlsPOCConstant.
       * ATTR_TRANS_AUDIT_KEY); String strBusinessDay =
       * eleTransSpecificElement.getAttribute(KohlsPOCConstant. ATTR_BUSINESS_DAY);
       * 
       * //Create input XML for getTransactionAuditDetailsForPOS API Document docTransSpecAuditInput
       * = YFCDocument.createDocument(KohlsPOCConstant. ATTR_TRANSACTION_AUDIT).getDocument();
       * Element eleTransSpecAudit = docTransSpecAuditInput.getDocumentElement();
       * eleTransSpecAudit.setAttribute(KohlsPOCConstant. A_ORGANIZATION_CODE, strOrganizationCode);
       * eleTransSpecAudit.setAttribute(KohlsPOCConstant. ATTR_TRANS_AUDIT_KEY, strTransAuditKey);
       * 
       * //Invoke getTransactionAuditDetailsForPOS API Document docTransSpecAuditOutput =
       * KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_DETAILS_FOR_POS,
       * docTransSpecAuditInput); Element eleTranSpecAuditOutput = (Element) ((NodeList)
       * docTransSpecAuditOutput.getElementsByTagName(KohlsPOCConstant.
       * ATTR_TRANSACTION_AUDIT)).item(0); String strDateTime =
       * eleTranSpecAuditOutput.getAttribute(KohlsPOCConstant. ATTR_DATE_TIME);
       * 
       * Element eleTransOutputElement = XMLUtil.createChild(eleTransSpecAuditOutput,
       * KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
       * eleTransOutputElement.setAttribute(KohlsPOCConstant. ATTR_TERMINAL_ID, strTerminalID);
       * eleTransOutputElement.setAttribute(KohlsPOCConstant. ATTR_TRANS_NUM, strTransNum);
       * eleTransOutputElement.setAttribute(KohlsPOCConstant. ATTR_DATE_TIME, strDateTime);
       * eleTransOutputElement.setAttribute(KohlsPOCConstant. ATTR_PROCEDURE_ID,
       * KohlsPOCConstant.STATIC_CONSTANT_CREATE_TRANSACTION_PROCEDURE_ID) ;
       * eleTransOutputElement.setAttribute(KohlsPOCConstant. A_ORGANIZATION_CODE,
       * strOrganizationCode); eleTransOutputElement.setAttribute(KohlsPOCConstant.
       * ATTR_BUSINESS_DAY, strBusinessDay);
       * 
       * //Fetch Sign In Authentication Details docTransSpecDetail = setSignInDetails(env,
       * docTransSpecDetail, eleTransSpecificElement); } }
       */
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getCreateTransactionDetails");

    return docTransSpecDetail;
  }


  /**
   * This function returns SignIn Authentication Details.
   * 
	  * @param env
	  * @return docTransSpecDtlOutput
	  * @exception
   */

  private Document setSignInDetails(YFSEnvironment env, Document docTransSpecDtlOutput,
      Element eleAuditTransaction) throws YFSException {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.setSignInDetails");
    try {
      String strOperatorID = eleAuditTransaction.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID);
      String strDateTime = eleAuditTransaction.getAttribute(KohlsPOCConstant.ATTR_DATE_TIME);
      String strProcedureID = eleAuditTransaction.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID);

      Element eleTransAudits = (Element) ((NodeList) XPathUtil
          .getNodeList(docTransSpecDtlOutput.getDocumentElement(), "/TransactionAudits")).item(0);
      Element eleTransAudit =
          XMLUtil.createChild(eleTransAudits, KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);
      eleTransAudit.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID, strOperatorID);
      eleTransAudit.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, strProcedureID);
      eleTransAudit.setAttribute(KohlsPOCConstant.ATTR_AUTH_START_DATE, strDateTime);
      eleTransAudit.setAttribute(KohlsPOCConstant.ATTR_AUTH_END_DATE, strDateTime);
      eleTransAudit.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strOrganizationCode);
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.setSignInDetails");
    return docTransSpecDtlOutput;
  }


  /**
   * This function sets order level static variables.
   * 
   * @param env
   * @param docInvDtlInput
   */

  private void setOrderLevelDetails(YFSEnvironment env, Document docInvDtlInput) {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.setOrderLevelDetails");
    Element eleOrder =
        (Element) ((NodeList) docInvDtlInput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER))
            .item(0);

    if (!YFCDocument.isVoid(eleOrder)) {
      strOrderHeaderKey = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      strEnterpriseCode = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
      strOrganizationCode = eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
      strOrderNo = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
      strOrderDocType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
      strOrderPurpose = eleOrder.getAttribute("Purpose");
      strOrderProcID=eleOrder.getAttribute("ProcedureID");

    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.setOrderLevelDetails");
  }


  /**
   * This function retrieves audit level information for various procedure IDs.
   * 
   * @param env
   * @param String procedureID
   * @return docSignInAuthAuditOutput
   */

  private Document setTransAuditDetails(YFSEnvironment env, String procedureID) {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.setTransAuditDetails");
    Document docSignInAuthAuditOutput = null;
    try {
      Document docTransAuditDetails =
          YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT).getDocument();
      Element eleTransactionAuditDetails = docTransAuditDetails.getDocumentElement();
      eleTransactionAuditDetails.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, strOrderNo);
      eleTransactionAuditDetails.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
          strOrganizationCode);
      eleTransactionAuditDetails.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, procedureID);

      docSignInAuthAuditOutput = KOHLSBaseApi.invokeAPI(env,
          XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),
          KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS, docTransAuditDetails);
    } catch (Exception exception) {
      exception.printStackTrace();
      if (exception instanceof YFSException) {
        YFSException yfsException = (YFSException) exception;
        throw yfsException;
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.setTransAuditDetails");
    return docSignInAuthAuditOutput;
  }

  /**
   * This method generates the Sales Hub message for Void During transactions.
   * 
   * @param env
   * @param inputDocument
   * @return
   * @throws Exception
   */
  public Document generateSuspendedXMLToSalesHub(YFSEnvironment env, Document inputDocument)
      throws Exception {
    Document docVoidDuringDtls = null;
    Document outputDocument = null;
    loggerForPosInvoice
        .beginTimer("KohlsPocInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub");


    if (loggerForPosInvoice.isDebugEnabled())
      loggerForPosInvoice.debug(
          "Input XML to KohlsPocInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub is: \n"
              + XMLUtil.getXMLString(inputDocument));

    Element eleInputOrder =
        (Element) ((NodeList) XPathUtil.getNodeList(inputDocument.getDocumentElement(), "/Order"))
            .item(0);
    docVoidDuringDtls =
        YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();
    Element eleInvDtl = docVoidDuringDtls.getDocumentElement();
    eleInvDtl.setAttribute("xmlns", "http://www.sterlingcommerce.com/documentation");
    Element eleInvHdr = XMLUtil.createChild(eleInvDtl, KohlsPOCConstant.ATTR_INVOICE_HEADER);
    Element eleOrder = XMLUtil.createChild(eleInvHdr, KohlsPOCConstant.ELEM_ORDER);
    eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
        eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));
    eleOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
        eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
    eleOrder.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE,
        eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE));
    eleOrder.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE,
        eleInputOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
    eleOrder.setAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE,
        eleInputOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
    outputDocument = generateAndPublishPOSInvoiceToSalesHub(env, docVoidDuringDtls);
    Element eleOrderOut =
        (Element) ((NodeList) XPathUtil.getNodeList(outputDocument.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/Order")).item(0);
    Element eleOrderExtn =
        (Element) ((NodeList) XPathUtil.getNodeList(outputDocument.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/Order/Extn")).item(0);
    Element eleInvoiceHeader = (Element) ((NodeList) XPathUtil
        .getNodeList(outputDocument.getDocumentElement(), "/InvoiceDetail/InvoiceHeader")).item(0);
    Element eleOverallTotals =
        (Element) ((NodeList) XPathUtil.getNodeList(outputDocument.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/Order/OverallTotals")).item(0);
    eleInvoiceHeader.setAttribute("TotalAmount", eleOverallTotals.getAttribute("GrandTotal"));
    eleInvoiceHeader.setAttribute("DateInvoiced", eleOrderOut.getAttribute("Modifyts"));
    eleInvoiceHeader.setAttribute("AmountCollected", eleOverallTotals.getAttribute("GrandTotal"));
    eleInvoiceHeader.setAttribute("TotalDiscount", eleOrderExtn.getAttribute("ExtnTotalSavings"));
    outputDocument.getDocumentElement().setAttribute("MessageType", "Suspend");

    if (loggerForPosInvoice.isDebugEnabled())
      loggerForPosInvoice.debug("KohlsPocInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub"
          + XMLUtil.getXMLString(outputDocument));
    loggerForPosInvoice
        .endTimer("KohlsPocInvoiceToSalesHubAPI.generateVoidDuringDetailsToSalesHub");
    return outputDocument;
  }

  /**
   * Method to get the actual order confirm timestamp for the sale confirmed in ISS.PST-843.
   * 
   * @param env
   * @param inputPublishInvoiceDetail
   * @param eleInvoiceHeader
   * @param eleInvoiceOrder
   * @throws Exception
   * 
   */
  private Document setDateInvoicedForSaleSyncedToCorp(YFSEnvironment env,
      Document inputPublishInvoiceDetail, Element eleInvoiceHeader, Element eleInvoiceOrder)
      throws Exception {
    loggerForPosInvoice
        .beginTimer("KohlsPocInvoiceToSalesHubAPI.setDateInvoicedForSaleSyncedToCorp");
    String entryType = eleInvoiceOrder.getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE);
    String storeId = "";
    loggerForPosInvoice.debug("EntryType for ISS order  :" + entryType);

    if (KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE.equals(entryType)) {

      Element inputTransactionAuditElement = (Element) ((NodeList) XPathUtil.getNodeList(
          inputPublishInvoiceDetail.getDocumentElement(), KohlsPOCConstant.TRANSACTION_AUDIT_XPATH))
              .item(0);
      if (!YFCCommon.isVoid(inputTransactionAuditElement)) {
        loggerForPosInvoice.debug(
            "Get the values for input to getOfflineTrxQ from transaction audit of invoice XML");
        Document inputOfflineTrxQDoc =
            XMLUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
        Element inputOfflineTrxQElement = inputOfflineTrxQDoc.getDocumentElement();
        inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.V_N);
        inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.ATTR_STORE_ID,
            inputTransactionAuditElement.getAttribute(KohlsPOCConstant.A_ORG_CODE));
        storeId = inputTransactionAuditElement.getAttribute(KohlsPOCConstant.A_ORG_CODE);
        inputOfflineTrxQElement.setAttribute(KohlsPOCConstant.A_UNIQUE_ID,
            inputTransactionAuditElement.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM));
        Element complexQueryElement =
            inputOfflineTrxQDoc.createElement(KohlsPOCConstant.E_COMPLEX_QUERY);
        complexQueryElement.setAttribute(KohlsPOCConstant.A_OPERATOR, KohlsPOCConstant.AND);
        inputOfflineTrxQElement.appendChild(complexQueryElement);
        Element orElement = inputOfflineTrxQDoc.createElement(KohlsPOCConstant.E_OR);
        complexQueryElement.appendChild(orElement);
        Element expElement = inputOfflineTrxQDoc.createElement(KohlsPOCConstant.E_EXP);
        expElement.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_OPERATION_ID);
        expElement.setAttribute(KohlsPOCConstant.A_VALUE,
            KohlsPOCConstant.API_LOAD_OFFLINE_ORDER_FOR_POS);
        orElement.appendChild(expElement);
        Element expElement1 = inputOfflineTrxQDoc.createElement(KohlsPOCConstant.E_EXP);
        expElement1.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_OPERATION_ID);
        expElement1.setAttribute(KohlsPOCConstant.A_VALUE, KohlsPOCConstant.UNIQUE_ID_MULTI_API);
        orElement.appendChild(expElement1);
        String getOfflineTrxQTemplate = KohlsPOCConstant.GET_OFFLINE_TRANSACTION_QLIST_TEMPLATE;
        Document getOfflineTrxQs = KOHLSBaseApi.invokeAPI(env, getOfflineTrxQTemplate,
            KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS, inputOfflineTrxQDoc);
        if (!YFCCommon.isVoid(getOfflineTrxQs)) {
          NodeList offlineTrxQList = XPathUtil.getNodeList(getOfflineTrxQs.getDocumentElement(),
              KohlsPOCConstant.OFFLINE_TRX_Q_XPATH);
          if (offlineTrxQList.getLength() > 0) {
            Element offlineTrxQElement = (Element) offlineTrxQList.item(0);
            String operationTs = offlineTrxQElement.getAttribute(KohlsPOCConstant.A_OPERATION_TS);
            loggerForPosInvoice
                .debug("The operation ts from the pos offline entry   :" + operationTs);
            eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_DATE_INVOICED, operationTs);
          }
        }

      }

      // locale changes start
      //Commented for CPE-2281
       // setDateBasedonStoreTimezone(env, eleInvHeader,sSellerOrgCode);

    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.setDateInvoicedForSaleSyncedToCorp");
    return inputPublishInvoiceDetail;
  }

  /**
   * @param env
   * @param eleInvoiceHeader
   * @param storeId
   * @throws FactoryConfigurationError
   * @throws Exception
   */
  private void setDateBasedonStoreTimezone(YFSEnvironment env, Element eleInvoiceHeader,
      String storeId) throws FactoryConfigurationError, Exception {
    loggerForPosInvoice.debug("KohlsPocInvoiceToSalesHubAPI.setDateBasedonStoreTimezone--Begin");
    Element orderElement = null;
    NodeList orderList = eleInvoiceHeader.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
    if (orderList.getLength() > 0) {
      orderElement = (Element) orderList.item(0);

    }
    String orderDate = orderElement.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
    loggerForPosInvoice.debug("The order date is   :" + orderDate);
    String dateInvoiced = eleInvoiceHeader.getAttribute(KohlsPOCConstant.A_DATE_INVOICED);
    loggerForPosInvoice.debug("The dateInvoiced date is   :" + dateInvoiced);
    String localeCode = KohlsPoCCommonAPIUtil.getLocaleCode(env, storeId);
    loggerForPosInvoice.debug("LocalCode is   :" + localeCode);

    if (!KohlsPOCConstant.LOCALE_CODE_CST.equals(localeCode)) {
      loggerForPosInvoice.debug("The store is not in CST");
      String timezone = KohlsPoCCommonAPIUtil.getTimeZoneID(env, localeCode);
      loggerForPosInvoice.debug("Timezone is  :" + timezone);
      String orderDateBasedOnTimeZone = KohlsPoCCommonAPIUtil.convert(orderDate, timezone);
      loggerForPosInvoice.debug("orderDateBasedOnTimeZone is  :" + orderDateBasedOnTimeZone);
      orderElement.setAttribute(KohlsPOCConstant.A_ORDER_DATE, orderDateBasedOnTimeZone);
      String dateInvoiceBasedOnTimeZone = KohlsPoCCommonAPIUtil.convert(dateInvoiced, timezone);
      loggerForPosInvoice.debug("dateInvoiceBasedOnTimeZone is    :" + dateInvoiceBasedOnTimeZone);
      eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_DATE_INVOICED, dateInvoiceBasedOnTimeZone);

    }
    loggerForPosInvoice.debug("KohlsPocInvoiceToSalesHubAPI.setDateBasedonStoreTimezone--End");
  }

  /**
   * Method to stamp POSSequenceNumber to PosSequenceNo field.
   * 
   * @param orderElement
   * @param eleOrderExtn
   */
  private void stampPosSequenceNumber(Element orderElement, Element eleOrderExtn) {
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      String extnSuspendSeqNum = eleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_SUSPEND_SEQ_NUM);
      loggerForPosInvoice.debug("The extn suspend sequence number is   :" + extnSuspendSeqNum);
      if (!YFCCommon.isVoid(extnSuspendSeqNum)) {
        loggerForPosInvoice.debug("This transaction is a resumed transaction");
        String POSSequenceNumber =
            orderElement.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
        loggerForPosInvoice
            .debug("The POSSequenceNumber for resumed transaction is  :" + POSSequenceNumber);
        orderElement.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO, POSSequenceNumber);

      }
      orderElement.removeAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER);

    }
  }

  private void updateCouponInquiryDetails(Element eleOd) throws Exception {

    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.updateCouponInquiryDetails");

    NodeList nlOrderPromotion =
        XPathUtil.getNodeList(eleOd, "/OrderList/Order/Promotions/Promotion");
    if (!YFCCommon.isVoid(nlOrderPromotion)) {
      for (int i = 0; i < nlOrderPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlOrderPromotion.item(i);
        String strPromotionType = elePromotion.getAttribute("PromotionType");
        if (!YFCCommon.isVoid(strPromotionType)
            && strPromotionType.equalsIgnoreCase("KOHLS_CASH_UNEARNED")) {
          Element eleExtnPromotion = XMLUtil.getChildElement(elePromotion, "Extn");
          String strExtnPromoResponse = eleExtnPromotion.getAttribute("ExtnPromotionResponse");
          if (!YFCCommon.isVoid(strExtnPromoResponse) && !strExtnPromoResponse.isEmpty()) {
            Document doc = XMLUtil.getDocument(strExtnPromoResponse);
            Element elePromoRes = doc.getDocumentElement();

            if (!YFCCommon.isVoid(elePromoRes)
                && elePromoRes.getNodeName().equalsIgnoreCase("KohlsCouponInquiryResponse")) {
              XMLUtil.importElement(elePromotion, elePromoRes);
              eleExtnPromotion.removeAttribute("ExtnPromotionResponse");
            }
          }
          //PST-3298,3296,3419 - Start
          Element eleKohlsCouponInquiryResponse = XMLUtil.getChildElement(elePromotion, "KohlsCouponInquiryResponse");
          if(!YFCCommon.isVoid(eleKohlsCouponInquiryResponse)) {
        	  	 String couponBalance = XMLUtil.getAttribute(eleKohlsCouponInquiryResponse, KohlsPOCConstant.A_COUPON_BALANCE);
              String strExtnCouponAmount = XMLUtil.getAttribute(eleExtnPromotion, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
              String strExtnQualifyingAmount = XMLUtil.getAttribute(eleExtnPromotion, KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT);
              if(YFCCommon.isVoid(couponBalance) || couponBalance.contains(KohlsPOCConstant.MINUS)){
            	  XMLUtil.setAttribute(eleKohlsCouponInquiryResponse, KohlsPOCConstant.A_COUPON_BALANCE,KohlsPOCConstant.DECIMAL_FORMAT);
              }
              if(YFCCommon.isVoid(strExtnCouponAmount) || strExtnCouponAmount.contains(KohlsPOCConstant.MINUS)){
            	  XMLUtil.setAttribute(eleExtnPromotion, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,KohlsPOCConstant.DECIMAL_FORMAT);
              }
              if(YFCCommon.isVoid(strExtnQualifyingAmount) || strExtnQualifyingAmount.contains(KohlsPOCConstant.MINUS)){
            	  XMLUtil.setAttribute(eleExtnPromotion, KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT,KohlsPOCConstant.DECIMAL_FORMAT);
              }
          }
          //PST-3298,3296,3419 - End
        }
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.updateCouponInquiryDetails");
  }

  // CAPE-125 DataCollect for Split Amount - MRR - Start

  public void updateSplitAmountInfo(Document invoiceInputDoc) throws Exception {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.updateSplitAmountInfo");

    NodeList eleCollectionList =
        (NodeList) XPathUtil.getNodeList(invoiceInputDoc.getDocumentElement(),
            "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail");

    for (int i = 0; i < eleCollectionList.getLength(); i++) {

      Element eleCollection = (Element) eleCollectionList.item(i);
      Element elePaymentMethod = (Element) XMLUtil.getChildElement(eleCollection, "PaymentMethod");
      Element eleExtn = (Element) elePaymentMethod.getElementsByTagName("Extn").item(0);
      String strExtnPaymentDetails = eleExtn.getAttribute("ExtnPaymentDetails");
      if (!YFCCommon.isVoid(strExtnPaymentDetails)) {
        Document docPaymentList = XMLUtil.getDocument(strExtnPaymentDetails);
        Element elePaymentList = docPaymentList.getDocumentElement();
        XMLUtil.importElement(elePaymentMethod, elePaymentList);
        eleExtn.removeAttribute("ExtnPaymentDetails");
      }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.updateSplitAmountInfo");
  }


  /**
   * This function updates the EReceipt Email for return Orders.
   * 
   * @param eleOrder
   */

  void updateEReceiptEmailDetails( Element eleOrder) 
  {
    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.updateEReceiptEmailDetails");
    
    Element eleCustAttr = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.CUST_ATTRIBUTES,true);
    String strEReceiptFlag = eleCustAttr.getAttribute(KohlsPOCConstant.ATTR_BOOLEAN_1);
    Element eleOrderExtn = XMLUtil.getChildElement(eleOrder,KohlsPOCConstant.E_EXTN);
    
    if(!YFCDocument.isVoid(eleOrderExtn)) {
     String strEmail = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_ERECEIPT_EMAIL_ID);
      
     if(YFCCommon.isVoid(strEReceiptFlag) || YFCCommon.isVoid(strEmail)){
    	eleCustAttr.setAttribute(KohlsPOCConstant.ATTR_BOOLEAN_1,KohlsPOCConstant.NO);
     }
    }
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.updateEReceiptEmailDetails");
  }
@Override
public void setProperties(Properties arg0) throws Exception {
	// TODO Auto-generated method stub
	
}

 /**
   * This method invokes getAdminAuditListForPOS API
   * @param env
   * @param eleOrder
   * @return
   */
  private Element getAdminAuditList(YFSEnvironment env, Element eleOrder) {

    loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.getAdminAuditList");

  /*Initiliaze variables*/
    Document outAdminAudit = null;
    Document inAdminAudit = null;

  /* Prepare input to getAdminAuditList */
    inAdminAudit = YFCDocument
            .createDocument(KohlsPOCConstant.ELE_ADMIN_AUDIT).getDocument();
    Element eleAdminAudit = inAdminAudit.getDocumentElement();
    eleAdminAudit.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, eleOrder.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO));
    eleAdminAudit.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));

    if(loggerForPosInvoice.isDebugEnabled()) {
      loggerForPosInvoice.debug("Input XML to getAdminAuditList : \n" + XMLUtil.getXMLString(inAdminAudit));
    }

    try {
      outAdminAudit = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ADMIN_AUDIT_LIST_FOR_POS_FOR_SALE),  KohlsPOCConstant.STR_GET_ADMIN_AUDIT_LIST_FOR_POS, inAdminAudit);

      if(loggerForPosInvoice.isDebugEnabled()) {
        loggerForPosInvoice.debug("Output XML of getAdminAuditList : \n" + XMLUtil.getXMLString(outAdminAudit));
      }

    } catch (Exception e) {
      throw new YFSException(e.getMessage());
    }

    Element eleAdminAuditList = null;
    //Remove CRLF characters
    if(!YFCCommon.isVoid(outAdminAudit)) {

      eleAdminAuditList = removeCRLFChars(outAdminAudit.getDocumentElement());
    }

    if(loggerForPosInvoice.isDebugEnabled()) {
      loggerForPosInvoice.debug("Linearized Output XML of getAdminAuditList : \n" + XMLUtil.getElementXMLString(eleAdminAuditList));
    }

    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.getAdminAuditList");

    return eleAdminAuditList;
  }

  /**
   * This CRLF characters will have to be removed.
   * @param eleAdminAuditList
   * @return
   */
  public Element removeCRLFChars(Element eleAdminAuditList) {

    /* Initialize variables */
    Element eleAdditionalDataList = null;
    Element eleAudit = null;
    int iCount = 0;
    NodeList nlAdditionalData = null;

    if(!YFCCommon.isVoid(eleAdminAuditList)) {

      eleAudit = XMLUtil.getChildElement(eleAdminAuditList, KohlsPOCConstant.ELE_ADMIN_AUDIT);

      if(!YFCCommon.isVoid(eleAudit)) {
        eleAdditionalDataList = XMLUtil.getChildElement(eleAudit, KohlsXMLLiterals.E_ADDITIONAL_DATA_LIST);
      }

      if(!YFCCommon.isVoid(eleAdditionalDataList)) {
        nlAdditionalData = eleAdditionalDataList.getElementsByTagName(KohlsXMLLiterals.E_ADDITIONAL_DATA);
      }

      if(!YFCCommon.isVoid(nlAdditionalData)) {
        iCount = nlAdditionalData.getLength();
      }

      for(int i=0; i<iCount; i++) {
        Element eleAdditionalData = (Element) nlAdditionalData.item(i);
        String strValue = eleAdditionalData.getAttribute(KohlsPOCConstant.Value).replace("\n","").replace("\r","");
        strValue = strValue.replace("&#xa;","");
        eleAdditionalData.setAttribute(KohlsPOCConstant.Value, strValue);

      }

    }
    return eleAdminAuditList;
  }
  
  
  private Date yesterday(int prevDate) {
	    final Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DATE, -prevDate);
	    return cal.getTime();
	}

private String getYesterdayDateString(int prevDate ) {
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    return dateFormat.format(yesterday(prevDate));
}

public String convertDL(String strDrivingLic) {
	loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.convertDL");
	if (loggerForPosInvoice.isDebugEnabled()) {
		loggerForPosInvoice.debug("input DL --:" + strDrivingLic);
	}
    strDrivingLic = strDrivingLic.toUpperCase();

    String retDL = "";

    char[] dlArray = strDrivingLic.toCharArray();

    for (int i = 0; i < dlArray.length; i++) {
      char currentChar = dlArray[i];
	  if (Character.isDigit(currentChar)) {
		retDL += currentChar;
	  } 
      else {
        switch (currentChar) {
          case 'A': {
            retDL += "21";
            break;
          }
          case 'B': {
            retDL += "22";
            break;
          }
          case 'C': {
            retDL += "23";
            break;
          }
          case 'D': {
            retDL += "31";
            break;
          }
          case 'E': {
            retDL += "32";
            break;
          }
          case 'F': {
            retDL += "33";
            break;
          }
          case 'G': {
            retDL += "41";
            break;
          }
          case 'H': {
            retDL += "42";
            break;
          }
          case 'I': {
            retDL += "43";
            break;
          }
          case 'J': {
            retDL += "51";
            break;
          }
          case 'K': {
            retDL += "52";
            break;
          }
          case 'L': {
            retDL += "53";
            break;
          }
          case 'M': {
            retDL += "61";
            break;
          }
          case 'N': {
            retDL += "62";
            break;
          }
          case 'O': {
            retDL += "63";
            break;
          }
          case 'P': {
            retDL += "71";
            break;
          }
          case 'Q': {
            retDL += "11";
            break;
          }
          case 'R': {
            retDL += "72";
            break;
          }
          case 'S': {
            retDL += "73";
            break;
          }
          case 'T': {
            retDL += "81";
            break;
          }
          case 'U': {
            retDL += "82";
            break;
          }
          case 'V': {
            retDL += "83";
            break;
          }
          case 'W': {
            retDL += "91";
            break;
          }
          case 'X': {
            retDL += "92";
            break;
          }
          case 'Y': {
            retDL += "93";
            break;
          }
          case 'Z': {
            retDL += "12";
            break;
          }
          case '*': {
            retDL += "0";
            break;
          }
        }
      }
    }
	if (loggerForPosInvoice.isDebugEnabled()) {
		loggerForPosInvoice.debug("output  DL/Customer ID --: before trimming" + retDL);
	}
    int retDLLength = retDL.length();
    retDLLength = retDLLength > 24 ? 24 : retDLLength;
    retDL = retDL.substring(0, retDLLength);
	if (loggerForPosInvoice.isDebugEnabled()) {
		loggerForPosInvoice.debug("output  DL/Customer ID --: after trimming" + retDL);
	}
    loggerForPosInvoice.endTimer("KohlsPocInvoiceToSalesHubAPI.convertDL");
    return retDL;
  }
/**
 * This function filters PICK or CARRY order line details from getOrderList output based on the DeliveryMethod
 * 
 * @param env
 * @param inputDoc
 * @return eleOrderLines
 * @exception None
 * 
 */
public Document filteringForCarryInvoice(String filter, Document docOrderListOutput) throws Exception {
	  NodeList ndListOrderLine =
	          (NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
	              "/OrderList/Order/OrderLines/OrderLine[@DeliveryMethod='" + filter + "']");
	  

	  int ndLength = ndListOrderLine.getLength();
	        for (int lineCount = 0; lineCount < ndLength; lineCount++) {
	          Element eleOrderLine = (Element) ndListOrderLine.item(lineCount);
	          eleOrderLine.getParentNode().removeChild(eleOrderLine);
	        }
	      
	      return docOrderListOutput;
	}


/**
 * This function filters PICK or CARRY order line details from getOrderList output based on the DeliveryMethod
 * 
 * @param docOrderListOutput
 * @return docOrderListOutput
* @throws Exception 
 * 
 */
 public Document filteringForPickInvoice(Document docOrderListOutput,
		ArrayList<String> orderLineKeysWithPick) throws Exception {
	  NodeList ndListOrderLine =
	          (NodeList) XPathUtil.getNodeList(docOrderListOutput.getDocumentElement(),
	              "/OrderList/Order/OrderLines/OrderLine");
	  int ndLength = ndListOrderLine.getLength();
       for (int lineCount = 0; lineCount < ndLength; lineCount++) {
       	Element eleOrderLine = (Element) ndListOrderLine.item(lineCount);
       	String gOLOrderLineKey = eleOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY);
       	if(!orderLineKeysWithPick.contains(gOLOrderLineKey)) {
       		eleOrderLine.getParentNode().removeChild(eleOrderLine);
       	}
       }
	return docOrderListOutput;
}
 
 private String getReceiptId(String sEFC, Document docGetOrderDetials, String sExtnOCF){
		String sShipNode;
		// getOrderReleaseDetails
		Element elemNotes = (Element) docGetOrderDetials.getElementsByTagName(
				KohlsXMLLiterals.E_NOTES).item(0);
		NodeList nlNote = elemNotes
				.getElementsByTagName(KohlsXMLLiterals.E_NOTE);
		for (int i = 0; i < nlNote.getLength(); i++) {
			Element elemNote = (Element) nlNote.item(i);
			// check for delivery method PICK
			if (KohlsConstant.BPS.equals(sExtnOCF)) {
				sShipNode = KohlsConstant.PREENC + KohlsConstant.BPS + "_" + sEFC; // BOPUS

				if (elemNote.getAttribute(KohlsXMLLiterals.A_REASON_CODE).equals(
						sShipNode)) {
					String sNote = elemNote.getAttribute(KohlsXMLLiterals.A_NOTE_TEXT);
					//sNote = sNote.replaceAll("[^0-9\\+]", "");
					return sNote;
				}
			}
		}
		return null;
	}
 
 /**
  * 
  * This method is used for Omni Orders only , while publishing Pick Invoice to downstream make sure to 
  * have Order/References/Reference/OmniPickStoreBusinessDay- 
  * should have Business Day of of Pick Store as set in SBC
  * @param env
  * @param inputPublishInvoiceDetail
  * @param docGetOrderListDetails
  * @param sShipNode
  * @throws Exception
  */
 private void getSaleDateForPickInvoice(YFSEnvironment env, Document inputPublishInvoiceDetail,Element orderEle, String sShipNode) throws Exception{
	 
	 loggerForPosInvoice
     .beginTimer("KohlsPocInvoiceToSalesHubAPI.getSaleDateForPickInvoice");
	 
	 	String strStoreBusinessDay=KohlsDateUtil.getCurrentDateTime("yyyy-MM-dd");  
	 	String strIsStoreOpen="Close";
		
		// call getCurrentAccountingperiodforpos
 		Document inDocGetCurrentAccountingperiodforpos = SCXmlUtil.createDocument("AccountingPeriod");  
		Element eleGetCurrentAccountingperiodforpos =
				inDocGetCurrentAccountingperiodforpos.getDocumentElement();
		eleGetCurrentAccountingperiodforpos.setAttribute("OrganizationCode", sShipNode);
		if(loggerForPosInvoice.isDebugEnabled()) {
			loggerForPosInvoice.debug("Input of getCurrentAccountingPeriodForPOS: "+XMLUtil.getXMLString(inDocGetCurrentAccountingperiodforpos));
		}
		
		Document outDocGetCurrentAccountingperiodforpos =
				KOHLSBaseApi.invokeAPI(env, "getCurrentAccountingPeriodForPOS", inDocGetCurrentAccountingperiodforpos);   

		if (!YFCCommon.isVoid(outDocGetCurrentAccountingperiodforpos)) {
			loggerForPosInvoice.debug("Pick ShipNode - getCurrentAccountingPeriodForPOS: "+XMLUtil.getXMLString(outDocGetCurrentAccountingperiodforpos));
			if(!YFCCommon.isVoid(outDocGetCurrentAccountingperiodforpos.getDocumentElement())){
				if(!YFCCommon.isVoid(outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("Status")))
						strIsStoreOpen = outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("Status");
				if(!YFCCommon.isVoid(outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("BusinessDay")))
					strStoreBusinessDay=outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("BusinessDay");
		}
		//Added for unOperated Store     
		if (!YFCCommon.isVoid(strIsStoreOpen) && strIsStoreOpen.equals("Open") || strIsStoreOpen.length()==0 || strIsStoreOpen.equals("Reconciled")) {
			// Element eleOrder=(Element)docGetOrderListDetails.getElementsByTagName("Order").item(0);
			 if(!YFCCommon.isVoid(orderEle)) {
	 			 NodeList referenceList=SCXmlUtil.getXpathNodes(orderEle,"//Order/References");
				 Element  eleReferences= SCXmlUtil.getXpathElement(orderEle,"//Order/References");
			    if(referenceList.getLength()==0) 
					eleReferences = XMLUtil.createChild(orderEle, KohlsPOCConstant.A_REFERENCES);			 
			    Element eleReference = XMLUtil.createChild(eleReferences, KohlsPOCConstant.A_REFERENCE);
		        eleReference.setAttribute(KohlsPOCConstant.Name, "OmniPickStoreBusinessDay");
	            eleReference.setAttribute(KohlsPOCConstant.Value,strStoreBusinessDay);
		}	
		}
		
		if(loggerForPosInvoice.isDebugEnabled()) {
			loggerForPosInvoice.debug("BusinessDay on Pick Invoice at Order/References is: "+strStoreBusinessDay);
			loggerForPosInvoice.debug("Order Element post PickInvoice updates on Reference:: "+SCXmlUtil.getString(orderEle));
		}
		
		
	loggerForPosInvoice
	     .endTimer("KohlsPocInvoiceToSalesHubAPI.getSaleDateForPickInvoice");
 } }
 
 private void updateRequestId(Document inputPublishInvoiceDetail) {
	 Element eleInvDtl = inputPublishInvoiceDetail.getDocumentElement();
	 Element eleInvHdr = XMLUtil.getChildElement(eleInvDtl, KohlsXMLLiterals.E_INVOICE_HEADER);
	 Element eleCollectionDtls = XMLUtil.getChildElement(eleInvHdr, KohlsXMLLiterals.E_COLLECTION_DETAILS);
	 NodeList nlCollectionDtls = eleCollectionDtls.getElementsByTagName(KohlsXMLLiterals.E_COLLECTION_DETAIL);
	 List<Element> collectionDtls = KohlsCommonUtil.getListFromNodeList(nlCollectionDtls);

	 for(Element eleCollectionDtl : collectionDtls) {
		 Element eleCreditCardTransactions = XMLUtil.getChildElement(eleCollectionDtl, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTIONS);
		 Element creditCardTransaction = XMLUtil.getChildElement(eleCreditCardTransactions, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTION); 
		 String strRequestId = creditCardTransaction.getAttribute(KohlsPOCConstant.A_REQUEST_ID);
		 if(!YFCCommon.isVoid(strRequestId)) {
			 List<String> strList = Arrays.asList(strRequestId.split(":"));
			 String authRefFull = strList.get(0);
			 String authRef = authRefFull.substring(authRefFull.indexOf("'")+1, authRefFull.length()-1);
			 creditCardTransaction.setAttribute(KohlsPOCConstant.A_AUTH_REF, authRef);
			 String authCode= creditCardTransaction.getAttribute(KohlsXMLLiterals.A_AUTH_CODE);
			 String strAuthId = eleCollectionDtl.getAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID);
			 Element elePaymentMethod =(Element)eleCollectionDtl.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD).item(0);
		     String creditCardType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
		     String totalAuthorized = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_TOTAL_AUTHORIZED);
		      double dbltotalAuthorized = 0;
		      if(!YFCCommon.isVoid(totalAuthorized))
		      {
		    	  dbltotalAuthorized = Double.parseDouble(totalAuthorized);
		    	  if(dbltotalAuthorized<0)
		    	  {
		    		  dbltotalAuthorized = Math.abs(dbltotalAuthorized);
		    		  elePaymentMethod.setAttribute(KohlsXMLLiterals.A_TOTAL_AUTHORIZED, String.valueOf(dbltotalAuthorized));
		    	  }
		      }
	   	  	  if(!YFCCommon.isVoid(creditCardTransaction) && "08".equals(creditCardType))
	   	  	  {
	  			if(!YFCCommon.isVoid(authCode)&& !authCode.equals(strAuthId))
	  			{
	  				eleCollectionDtl.setAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID, authCode);
	  			}
	   	  	  }
		 }
	 }

 }

private void updateCollectionDetails(YFSEnvironment env,Document inputPublishInvoiceDetail) throws Exception {
	 Element eleInvDtl = inputPublishInvoiceDetail.getDocumentElement();
	 Element eleInvHdr = (Element)eleInvDtl.getElementsByTagName(KohlsPOCConstant.ATTR_INVOICE_HEADER).item(0);
	 Element eleInvOrder = (Element)eleInvDtl.getElementsByTagName(KohlsPOCConstant.E_ORDER).item(0);
	 Document docInGetChgTranList = YFCDocument.createDocument(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL).getDocument();
	 String orderHeaderkey= eleInvOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);
     Element eleChgTranDtl = docInGetChgTranList.getDocumentElement();
     eleChgTranDtl.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, orderHeaderkey);
     eleChgTranDtl.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE, KohlsPOCConstant.CHARGE_TYPE_CHARGE);
	 List<String> voidChargeTranList = new ArrayList<String>();
	 List<Element> nonvoidChargeTranList = new ArrayList<Element>();
	 Document docOutGetChgTranList = KOHLSBaseApi.invokeAPI(env,KohlsPOCConstant.API_GET_CHARGE_TRANSACTION_LIST, docInGetChgTranList);
	 NodeList ndlstChargeTransaction = SCXmlUtil.getXpathNodes(docOutGetChgTranList.getDocumentElement(),
				KohlsPOCConstant.XPATH_CHARGE_TYPE_CHARGE);
		int nodeLength = ndlstChargeTransaction.getLength();
		for (int count = 0; count < nodeLength; count++) {
			Element eleChargeTransactionDetail = (Element) ndlstChargeTransaction.item(count);
			String voidTransaction = eleChargeTransactionDetail.getAttribute(KohlsPOCConstant.ATTR_VOID_TRANSACTION);
			String chargeTransactionKey = eleChargeTransactionDetail.getAttribute(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_KEY);
			if("V".equals(voidTransaction) || "S".equals(voidTransaction))
			{
				voidChargeTranList.add(chargeTransactionKey);
			}
			else if (YFCCommon.isVoid(voidTransaction))
			{
				nonvoidChargeTranList.add(eleChargeTransactionDetail);
			}
		}
     Element eleCollectionDtls = XMLUtil.getChildElement(eleInvHdr, KohlsXMLLiterals.E_COLLECTION_DETAILS);
     NodeList nlCollectionDtls = eleCollectionDtls.getElementsByTagName(KohlsXMLLiterals.E_COLLECTION_DETAIL);
     List<Element> collectionDtls = KohlsCommonUtil.getListFromNodeList(nlCollectionDtls);
     
     for(Element eleCollectionDtl : collectionDtls) {
    	 String ctrKey = eleCollectionDtl.getAttribute(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_KEY);
    	 Element elePaymentMethod =(Element)eleCollectionDtl.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD).item(0);
    	 Element eleCreditCardTrans = XMLUtil.getChildElement(eleCollectionDtl, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTIONS);
	      Element eleCreditCardTran = XMLUtil.getChildElement(eleCreditCardTrans, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTION);
	      String creditCardType = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE);
	      String totalAuthorized = elePaymentMethod.getAttribute(KohlsXMLLiterals.A_TOTAL_AUTHORIZED);
	      double dbltotalAuthorized = 0;
	      if(!YFCCommon.isVoid(totalAuthorized))
	      {
	    	  dbltotalAuthorized = Double.parseDouble(totalAuthorized);
	    	  if(dbltotalAuthorized<0)
	    	  {
	    		  dbltotalAuthorized = Math.abs(dbltotalAuthorized);
	    		  elePaymentMethod.setAttribute(KohlsXMLLiterals.A_TOTAL_AUTHORIZED, String.valueOf(dbltotalAuthorized));
	    	  }
	      }
   	  	  String amountCollected = eleCollectionDtl.getAttribute(KohlsXMLLiterals.A_AMOUNT_COLLECTED);
   	  	  String strAuthId = eleCollectionDtl.getAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID);
   	  	  eleCollectionDtl.setAttribute(KohlsXMLLiterals.A_CREDIT_AMOUNT, amountCollected);
	      String strDistributedAmt = "-"+amountCollected;
	      eleCollectionDtl.setAttribute(KohlsPOCConstant.A_DISTRIBUTED_AMT, strDistributedAmt);
	      eleCollectionDtl.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, amountCollected);
	     
   	  	  if(!YFCCommon.isVoid(eleCreditCardTran)&& !"08".equals(creditCardType) && (!voidChargeTranList.isEmpty() && voidChargeTranList.contains(ctrKey)))
   	  	  {
		      String strUpdatedAuthId = strAuthId.substring(4);
		      eleCollectionDtl.setAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID, strUpdatedAuthId);
		      eleCreditCardTran.setAttribute(KohlsPOCConstant.A_TRAN_AMT, amountCollected);
		      eleCreditCardTran.setAttribute(KohlsXMLLiterals.A_AUTH_AMOUNT, amountCollected);
   	  	  }
   	  	  else if(!YFCCommon.isVoid(eleCreditCardTran)&& "08".equals(creditCardType) && (!voidChargeTranList.isEmpty() && voidChargeTranList.contains(ctrKey)))
   	  	  {
   	  		  Element eleChargeTransactionFromList = nonvoidChargeTranList.get(0);
   	  		  Element eleCreditCardTransFromList = XMLUtil.getChildElement(eleChargeTransactionFromList, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTIONS);
   	  		  Element eleCreditCardTranFromList = XMLUtil.getChildElement(eleCreditCardTransFromList, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTION);
   	  		  String newChargeTranKey = eleChargeTransactionFromList.getAttribute(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_KEY);
   	  		  eleCollectionDtl.setAttribute(KohlsPOCConstant.ATTR_CHARGE_TRANSACTION_KEY, newChargeTranKey);
   	  		  String chargeType = eleChargeTransactionFromList.getAttribute(KohlsXMLLiterals.A_CHARGE_TYPE);
   	  		  String status = eleChargeTransactionFromList.getAttribute(KohlsPOCConstant.ATTR_STATUS);
   	  		  if(KohlsXMLLiterals.CONST_CHARGE.equals(chargeType) && ("CLOSED".equals(status) || "CHECKED".equals(status)))
   	  		  {
   	  			eleCreditCardTrans.removeChild(eleCreditCardTran);
   	  			XMLUtil.importElement(eleCreditCardTrans, eleCreditCardTranFromList);
   	  			Element eleUpdatedCreditCardTrans = XMLUtil.getChildElement(eleCollectionDtl, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTIONS);
   	  			Element eleUpdatedCreditCardTran = XMLUtil.getChildElement(eleUpdatedCreditCardTrans, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTION);
   	  			eleUpdatedCreditCardTran.setAttribute(KohlsPOCConstant.A_TRAN_AMT, amountCollected);
   	  			eleUpdatedCreditCardTran.setAttribute(KohlsXMLLiterals.A_AUTH_AMOUNT, amountCollected);
   	  			String authCode= eleUpdatedCreditCardTran.getAttribute(KohlsXMLLiterals.A_AUTH_CODE);
   	  			if(!YFCCommon.isVoid(authCode)&& !authCode.equals(strAuthId))
   	  			{
   	  				eleCollectionDtl.setAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID, authCode);
   	  			}
   	  		  }
   	  		  else
   	  		  {
   	  			throw new YFSException("ChargeTransaction Status is OPEN for CTR Key:  " + newChargeTranKey +". Agent would pick this record once CTR is CLOSED or CHECKED");
   	  		  } 
   	  	  }
   	  	else if(!YFCCommon.isVoid(eleCreditCardTran)&& "08".equals(creditCardType) && !voidChargeTranList.contains(ctrKey))
   	  	{	
   	  		Element eleUpdatedCreditCardTrans = XMLUtil.getChildElement(eleCollectionDtl, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTIONS);
 			Element eleUpdatedCreditCardTran = XMLUtil.getChildElement(eleUpdatedCreditCardTrans, KohlsXMLLiterals.E_CREDIT_CARD_TRANSACTION);
 			eleUpdatedCreditCardTran.setAttribute(KohlsPOCConstant.A_TRAN_AMT, amountCollected);
 			eleUpdatedCreditCardTran.setAttribute(KohlsXMLLiterals.A_AUTH_AMOUNT, amountCollected);
 			String authCode= eleUpdatedCreditCardTran.getAttribute(KohlsXMLLiterals.A_AUTH_CODE);
 			if(!YFCCommon.isVoid(authCode)&& !authCode.equals(strAuthId))
 			{
 				eleCollectionDtl.setAttribute(KohlsXMLLiterals.A_AUTHORIZATION_ID, authCode);
 			}
   	  	}   
     }
}	

/**
 * Verify and filter the unApplied promotions on Order and orderLines
 * @param env
 * @param inDocPublishInvoiceDetail
 * @return
 * @throws YFSException
 */
public Document updatePromotionsAppliedOnOrder(YFSEnvironment env,
			Document inDocPublishInvoiceDetail) throws YFSException {
		// CPE-13148
		loggerForPosInvoice.beginTimer("KohlsPocInvoiceToSalesHubAPI.updatePromotionsAppliedOnOrder");
		if (loggerForPosInvoice.isDebugEnabled()) {
			loggerForPosInvoice.debug("Input XML to KohlsPocInvoiceToSalesHubAPI.updatePromotionsAppliedOnOrder is: \n"
					+ XMLUtil.getXMLString(inDocPublishInvoiceDetail));
		}
		NodeList nlOrderLineAwards = SCXmlUtil.getXpathNodes(inDocPublishInvoiceDetail.getDocumentElement(),
				"/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine/Awards/Award");
		int orderLineAwardLength = nlOrderLineAwards.getLength();
		try {
			String strIsOmniOrder = SCXmlUtil.getXpathAttribute(inDocPublishInvoiceDetail.getDocumentElement(),
					"/InvoiceDetail/InvoiceHeader/Order/Extn/@ExtnIsOmni");
			if (!YFCCommon.isVoid(strIsOmniOrder) && KohlsPOCConstant.YES.equalsIgnoreCase(strIsOmniOrder)) {
				Element eleOrder = SCXmlUtil.getXpathElement(inDocPublishInvoiceDetail.getDocumentElement(),
						"/InvoiceDetail/InvoiceHeader/Order");
				Element elePromotions = SCXmlUtil.getChildElement(eleOrder, "Promotions");
				ArrayList<String> orderLinePromotionIds = new ArrayList<String>();
				for (int count = 0; count < orderLineAwardLength; count++) {
					Element eleOrderLineAward = (Element) nlOrderLineAwards.item(count);
					String strOLPromotionId = eleOrderLineAward.getAttribute("PromotionId");
					if (!YFCCommon.isVoid(strOLPromotionId) && !orderLinePromotionIds.contains(strOLPromotionId)) {
						orderLinePromotionIds.add(strOLPromotionId);
					}
				}
				if (loggerForPosInvoice.isDebugEnabled()) {
					loggerForPosInvoice.debug("Old Promotions xml:" + SCXmlUtil.getString(elePromotions));
				}

				NodeList nlOrderPromotions = SCXmlUtil.getXpathNodes(inDocPublishInvoiceDetail.getDocumentElement(),
						"/InvoiceDetail/InvoiceHeader/Order/Promotions/Promotion[Extn/@ExtnDiscLevelCode='TLD']");
				int orderPromotionCount = nlOrderPromotions.getLength();
				for (int count = 0; count < orderPromotionCount; count++) {
					Element eleOrderPromotion = (Element) nlOrderPromotions.item(count);
					String strOrderPromotionId = eleOrderPromotion.getAttribute("PromotionId");
					if (!YFCCommon.isVoid(strOrderPromotionId)
							&& !orderLinePromotionIds.contains(strOrderPromotionId)) {
						Element eleRemovePromotion = SCXmlUtil.getXpathElement(
								inDocPublishInvoiceDetail.getDocumentElement(),
								"/InvoiceDetail/InvoiceHeader/Order/Promotions/Promotion[@PromotionId='"
										+ strOrderPromotionId + "']");
						if (loggerForPosInvoice.isDebugEnabled()) {
							loggerForPosInvoice.debug("Remove Promotions xml:" + SCXmlUtil.getString(eleRemovePromotion));
						}
						elePromotions.removeChild(eleOrderPromotion);
					}
				}
				if (loggerForPosInvoice.isDebugEnabled()) {
					loggerForPosInvoice.debug("New Promotions xml:" + SCXmlUtil.getString(elePromotions));
				}
			}
			if (loggerForPosInvoice.isDebugEnabled()) {
			 loggerForPosInvoice.debug("Filtered xml:" + SCXmlUtil.getString(inDocPublishInvoiceDetail));
			}

		} catch (Exception exception) {
			if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
			}
		}
		return inDocPublishInvoiceDetail;
	}
}
