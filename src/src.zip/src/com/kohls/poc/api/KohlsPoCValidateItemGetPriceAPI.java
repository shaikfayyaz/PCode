package com.kohls.poc.api;

import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.returns.api.KohlsPoCProcessNonReceiptOrder;
import com.kohls.poc.returns.api.KohlsPoCTVSReturnOrderReprice;
import com.kohls.poc.returns.api.KohlsPoCValidateItemForReturn;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCValidateItemGetPriceAPI implements YIFCustomApi {
	private static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCValidateItemGetPriceAPI.class.getName());

	/**
	 * @param env
	 * @param docInXML
	 * @return
	 * @throws Exception
	 */
	public Document validateItemGetPrice(YFSEnvironment env, Document docInXML)
			throws Exception {
		logger.beginTimer("KohlsPoCValidateItemGetPriceAPI.validateItemGetPrice");
		if (logger.isDebugEnabled()) {
			logger.debug("Input xml to KohlsPoCValidateItemGetPriceAPI is: "
					+ XMLUtil.getXMLString(docInXML));

		}
		
		Element eleInputRoot = docInXML.getDocumentElement();
		Element eleIputExtn = (Element) eleInputRoot.getElementsByTagName(
				KohlsPOCConstant.A_EXTN).item(0);
		eleIputExtn.setAttribute(KohlsPOCConstant.EXTN_POC_FEATURE, "");
		Element eleInputLine = (Element) eleInputRoot.getElementsByTagName(
				KohlsPOCConstant.ELEM_ORDER_LINE).item(0);
		eleInputLine.setAttribute("GiftFlagInd", KohlsPOCConstant.NO);
		String strItemid = eleInputLine.getAttribute(KohlsPOCConstant.A_BAR_CODE_DATA_LOWER);

		Document docValidateOutput = validateItem(env,docInXML);

		if (logger.isDebugEnabled()) {
			logger.debug("Output xml to KohlsPoCValidateItemForReturn is: "
					+ XMLUtil.getXMLString(docValidateOutput));

		}
		Element eleRootValidateItem = docValidateOutput.getDocumentElement();
		Element elevalidateItemOrderLine = ((Element) eleRootValidateItem
				.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE).item(0));
		Element eleOrderlineExtn = (Element) elevalidateItemOrderLine.getElementsByTagName("Extn").item(0);
		Element eleOrderlineItemDetails = (Element) elevalidateItemOrderLine.getElementsByTagName("ItemDetails").item(0);
		if(!YFCCommon.isVoid(eleOrderlineItemDetails)){
			NodeList nlAdditionalAttribute = eleOrderlineItemDetails.getElementsByTagName("AdditionalAttribute");
			for (int i=0; i<nlAdditionalAttribute.getLength(); i++) {
				Element eleAdditionalAttribute = (Element)nlAdditionalAttribute.item(i);
				String sName = eleAdditionalAttribute.getAttribute("Name");
				if("POCMerchandiseDescription".equalsIgnoreCase(sName)) {
					XMLUtil.getChildElement(eleOrderlineItemDetails, "PrimaryInformation", true).setAttribute("ShortDescription", eleAdditionalAttribute.getAttribute("Value"));
				}
			}
		}
		String sExtnStyle="";
		String sExtnDept="";
		if(!YFCCommon.isVoid(eleOrderlineExtn)){
			sExtnStyle = eleOrderlineExtn.getAttribute("ExtnStyle");
			sExtnDept = eleOrderlineExtn.getAttribute("ExtnDept");
		}
		if (YFCCommon.isVoid(elevalidateItemOrderLine
				.getAttribute(KohlsPOCConstant.A_SPL_SKU_TYPE))) {
			Document docCommonCodeRecycle = getCommonCodeListForRecycleSKU(env);
			NodeList ndlstCommonCodeList = docCommonCodeRecycle
					.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
			String sCode;
			if(strItemid.endsWith("000")){
				elevalidateItemOrderLine.setAttribute("PricePrompt", "Y");
			}
			for (int i = 0; i < ndlstCommonCodeList.getLength(); i++) {

				Element eleCommonCode = (Element) ndlstCommonCodeList.item(i);
				sCode = eleCommonCode
						.getAttribute(KohlsXMLLiterals.A_CODE_SHORT_DESCRIPTION);
				if (sCode.equalsIgnoreCase(strItemid)) {
					elevalidateItemOrderLine.setAttribute(KohlsPOCConstant.A_SPL_SKU_TYPE,
							KohlsPOCConstant.CODE_TYPE_RECYCLEFEESKUS);
					break;
				}

			}
		}
		NodeList nlErrors = (NodeList) eleRootValidateItem
				.getElementsByTagName(KohlsPOCConstant.E_ERROR_LIST);
		Element eleErrors =null;
		if (!YFCCommon.isVoid(nlErrors) && nlErrors.getLength() > 0) {
			eleErrors = (Element)nlErrors.item(0);
			Element eleItem = ((Element) eleRootValidateItem
					.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0));
			eleItem.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemid);
			XMLUtil.createChild(eleItem, KohlsPOCConstant.A_EXTN);
			XMLUtil.createChild(elevalidateItemOrderLine, KohlsPOCConstant.A_EXTN);
			return docValidateOutput;

		}
		Document docTVSPriceOutput = null;
		

		elevalidateItemOrderLine.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_ACTION_ADD);
		XMLUtil.createChild(elevalidateItemOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
		try {
			docTVSPriceOutput = callTVS(env, docValidateOutput);
			Element eleTVSRoot = docTVSPriceOutput.getDocumentElement();
			Element eleTVSOrderLine = ((Element) eleTVSRoot
					.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE).item(0));
			//XMLUtil.importElement(eleTVSOrderLine, eleOrderlineItemDetails);
			Element eleTVSOrderlineExtn = (Element) eleTVSOrderLine.getElementsByTagName("Extn").item(0);
			eleTVSOrderlineExtn.setAttribute("ExtnStyle",sExtnStyle);
		    eleTVSOrderlineExtn.setAttribute("ExtnDept",sExtnDept);
			if(!YFCCommon.isVoid(eleErrors)){
				eleTVSOrderLine.appendChild(XMLUtil.importElement(docTVSPriceOutput, eleErrors));
			}
			
			Element eleTVSExtn = (Element) eleTVSRoot.getElementsByTagName(
					KohlsPOCConstant.A_EXTN).item(0);
			eleTVSRoot.removeChild(eleTVSExtn);
		} catch (YFSException e) {

			throw new YFSException("TVS_ERROR","TVS_ERROR","TVS Not Avaialable");

		}
		logger.endTimer("KohlsPoCValidateItemGetPriceAPI.validateItemGetPrice");
		return docTVSPriceOutput;
	}

	/**
	 * @param env
	 * @return commonCodeList with code type RECYCLE_FEES
	 * @throws Exception
	 */
	protected Document getCommonCodeListForRecycleSKU(YFSEnvironment env)
			throws Exception {
		logger.beginTimer("KohlsPoCValidateItemGetPriceAPI.getCommonCodeListForRecycleSKU");
		Document docInputgetCommonCodeList = XMLUtil
				.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
		Element eleCommonCode = docInputgetCommonCodeList.getDocumentElement();
		eleCommonCode
				.setAttribute(KohlsXMLLiterals.A_CODE_TYPE, "RECYCLE_FEES");
		Document docCommonCodeListOuput = KOHLSBaseApi.invokeAPI(env,
				KohlsPOCConstant.API_GET_COMMON_CODE_LIST,
				docInputgetCommonCodeList);
		logger.endTimer("KohlsPoCValidateItemGetPriceAPI.getCommonCodeListForRecycleSKU");
		return docCommonCodeListOuput;
	}

	protected Document validateItem(YFSEnvironment env, Document docInXML) throws Exception{
	  logger.beginTimer("KohlsPoCValidateItemGetPriceAPI.validateItem");
		KohlsPoCValidateItemForReturn objValidateItem = new KohlsPoCValidateItemForReturn();
		Document docValidateOutput = objValidateItem.validateItemForReturn(env,
				docInXML);
		logger.endTimer("KohlsPoCValidateItemGetPriceAPI.validateItem");
		return docValidateOutput;
	}
	protected Document callTVS(YFSEnvironment env, Document docValidateOutput) throws Exception{
	  logger.beginTimer("KohlsPoCValidateItemGetPriceAPI.callTVS");
		KohlsPoCTVSReturnOrderReprice objGetPrice = new KohlsPoCTVSReturnOrderReprice();
		Element eleOrderLine = (Element) docValidateOutput.getDocumentElement().getElementsByTagName("OrderLine").item(0);
		Element linePrcEle = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
		docValidateOutput.getDocumentElement().setAttribute("TaxExemptFlag","N");
		Document docTVSRequest =
				objGetPrice.constructTVSRequest(env, eleOrderLine, docValidateOutput, "0.00");

		Document docTVSResponse = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE, docTVSRequest);
		if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCTVSReturnOrderReprice.orderReprice:\t Response from TVS:\n"
					+ XMLUtil.getXMLString(docTVSResponse));
		}
		Element tvsResponseEle = docTVSResponse.getDocumentElement();
		// Checking for SOAP fault
		if (!YFCCommon.isVoid(tvsResponseEle)
				&& tvsResponseEle.getTagName().equalsIgnoreCase("Errors")) {
			Element eleError = (Element) tvsResponseEle.getElementsByTagName("Error").item(0);
			if(eleError.getAttribute("ErrorCode").equalsIgnoreCase("PROMPT_FOR_PRICE")){
				Element extnEle =
						XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE, "0.00");
				linePrcEle.setAttribute(KohlsPOCConstant.A_LIST_PRICE, "0.00");
				linePrcEle.setAttribute(KohlsPOCConstant.A_UNIT_PRICE,"0.00");
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT, "0.00");
				eleOrderLine.setAttribute("PricePrompt", "Y");
			}else{
				throw new YFSException("TVS_ERROR","TVS_ERROR",eleError.getAttribute("ErrorCode"));
			}
		} else {

			Element itemElement =
					(Element) KohlsXPathUtil.getNode(tvsResponseEle, "//itemList/item");
			KohlsPoCPnPUtil.consolidateLineTaxes(itemElement);
			Element extnEle =
					XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE,
					KohlsPoCPnPUtil.getDouble(
							XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SELLING_PRICE)));
			linePrcEle.setAttribute(KohlsPOCConstant.A_LIST_PRICE,
					XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SELLING_PRICE));
			linePrcEle.setAttribute(KohlsPOCConstant.A_UNIT_PRICE,
					XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SELLING_PRICE));
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT,
					XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_PLU_PRICE));
			String sSkuStatus = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.ATTR_SKU_STATUS);
			if(!YFCCommon.isVoid(sSkuStatus)) {
			  XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE, KohlsPoCPnPUtil.getStatusCodeFromTVS(sSkuStatus));
			}

		}
		logger.endTimer("KohlsPoCValidateItemGetPriceAPI.callTVS");
		return docValidateOutput;
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
