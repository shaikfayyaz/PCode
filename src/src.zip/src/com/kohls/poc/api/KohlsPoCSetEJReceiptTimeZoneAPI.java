package com.kohls.poc.api;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


public class KohlsPoCSetEJReceiptTimeZoneAPI extends KOHLSBaseApi {
	
	private static final YFCLogCategory 
 	logger = YFCLogCategory
		.instance(KohlsPoCSetEJReceiptTimeZoneAPI.class.getName());


	
	public Document generateTimeZoneForReceiptedTransactions(YFSEnvironment env, Document inTransactionReceiptData) throws YFSException {
		
		try {
		KohlsPoCSetEJReceiptTimeZoneAPI.logger.beginTimer("KohlsPoCSetEJReceiptTimeZoneAPI.generateTimeZoneForReceiptedTransactions");
		logger.verbose("Input to generateTimeZoneForReceiptedTransactions:: "+SCXmlUtil.getString(inTransactionReceiptData));
		
		//Verify for TransactionType
		Element eleTransactionType=SCXmlUtil.getFirstChildElement(inTransactionReceiptData.getDocumentElement());	
		logger.verbose("eleTransactionType::"+SCXmlUtil.getString(eleTransactionType));
		String strTransactionType=eleTransactionType.getNodeName();
		
		//Verify for TransactionType
		if(strTransactionType.equalsIgnoreCase(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT))
			generateLocaleTimeZoneForSale(env, inTransactionReceiptData);
		else if  (strTransactionType.equalsIgnoreCase(KohlsPOCConstant.ATTR_ACCOUNT))
			generateLocaleTimeZoneForAccount(env, inTransactionReceiptData);
		else if(strTransactionType.equalsIgnoreCase("Order"))   //Needs to be tested for Kohls Charge Card Transaction
			generateLocalTimeZoneForTransaction(env, inTransactionReceiptData);
		else if(strTransactionType.equalsIgnoreCase(KohlsPOCConstant.ELE_ADMIN_AUDIT) )
			generateLocaleTimeZoneForAdminAudit(env, inTransactionReceiptData);
		else  // Like Order and others
			generateLocalTimeZoneForTransaction(env, inTransactionReceiptData);
		}
		catch(Exception exception)
		{
			KohlsPoCSetEJReceiptTimeZoneAPI.logger.endTimer("KohlsPoCSetEJReceiptTimeZoneAP.generateTimeZoneForReceiptedTransactions.Failure");
			exception.printStackTrace();
			 if (exception instanceof YFSException) {
				YFSException yfsException = (YFSException) exception;
				throw yfsException;
		}
		}
		KohlsPoCSetEJReceiptTimeZoneAPI.logger.endTimer("KohlsPoCSetEJReceiptTimeZoneAP.generateTimeZoneForReceiptedTransactions.Success");
		return inTransactionReceiptData;
	}

	
	private void generateLocaleTimeZoneForAdminAudit(YFSEnvironment env,
			Document inTransactionReceiptData) {
		
		/**
		 * 1. form Input for manageAdminAuditForPOS  --
		 * append     <AdditionalDataList>
							<AdditionalData AdditionalDataKey="" Name="StoreTimeZoneEJ" ParentKey="" ParentTable="" Value="America/Los_Angeles"/>
	 				</AdditionalDataList>
		 * 2. call manageAdminAuditForPOS
		 * 
		 */
	
		Document docOrgListOutput;
		try {
			
			logger.verbose("****************** generateLocaleTimeZoneForAdminAudit ******* START ***************** ");
			
			Document inAdminAudit=XMLUtil.createDocument(KohlsXMLUtil.getElementByXpath(inTransactionReceiptData, "//Transaction/AdminAudit"));
			logger.verbose("Input to getAdminAuditListForPOS :: "+SCXmlUtil.getString(inAdminAudit));
			Document docGetAdminAuditListForPOS  = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ADMIN_AUDIT_LIST_FOR_POS,inAdminAudit);
			
			//Verify if StoreTimeZoneForEJ is stamped before
			boolean isExists=storeTimeZoneForEJIsExists(docGetAdminAuditListForPOS);
			
			if(!isExists){
			Element eleTransaction=inTransactionReceiptData.getDocumentElement();
			Element eleTransactionAccount=KohlsXMLUtil.getElementByXpath(inTransactionReceiptData, "//Transaction/AdminAudit");
			Element eleAdditionalDataList=KohlsXMLUtil.createChild(eleTransactionAccount,KohlsPOCConstant.ELE_ADDITIONAL_DATA_LIST);
			Element eleAdditionalData=KohlsXMLUtil.createChild(eleAdditionalDataList, KohlsPOCConstant.ELE_ADDITIONAL_DATA);
			eleAdditionalData.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_STORE_TIME_ZONE_FOR_EJ);
				
			docOrgListOutput = getOrganizationLocaleForEJ(env,eleTransaction);
			String strTimeZone="";
			if(!YFCObject.isVoid(docOrgListOutput)){
				strTimeZone = getLocaleTimeZoneForEJ(env, docOrgListOutput);
				if(!YFCObject.isVoid(strTimeZone)){
					//Set StoreTimeZone on AdminAudit AddtionalData
					logger.verbose("checking element"+ strTimeZone);
					eleAdditionalData.setAttribute(KohlsPOCConstant.Value, strTimeZone);
					inAdminAudit=XMLUtil.createDocument(KohlsXMLUtil.getElementByXpath(inTransactionReceiptData, "//Transaction/AdminAudit"));
					logger.verbose("Input to manageAdminAuditForPOS:: "+SCXmlUtil.getString(inAdminAudit));
					Document docManageAccountForPOSOutput = KOHLSBaseApi.invokeAPI(env,KohlsPOCConstant.API_MANAGE_ADMIN_AUDIT_FOR_POS,inAdminAudit);
					logger.verbose("****************** generateLocaleTimeZoneForAdminAudit ******* END ***************** ");
				}
			}
			}
		} catch (DOMException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	
	private void generateLocalTimeZoneForTransaction(YFSEnvironment env,
			Document inTransactionReceiptData) throws ParserConfigurationException, TransformerException {
		
		/**
		 * 1. form Input for getReceiptDataListForPOS
		 * 2. call getReceiptDataListForPOS
		 * 3. set TimeZoneInReceiptData
		 * 4. form Input for manageReceiptDataForPOS
		 */
		try {
		Element eleSaleTypeTransaction=inTransactionReceiptData.getDocumentElement();
		
		Document docTransactionAuditInput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT).getDocument();
		Element eleTransactionAudit=docTransactionAuditInput.getDocumentElement();
		
		eleTransactionAudit.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE) );
		eleTransactionAudit.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID) );
		String strOrderNo=eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER);
		if(!YFCObject.isVoid(strOrderNo))
			eleTransactionAudit.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER) );
		else 
			eleTransactionAudit.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER,eleSaleTypeTransaction.getAttribute("OrderNo"));
		
		
		//Call getReceiptDagetTransactionAuditListForPOStaListForPOS  API
		Document docTransactionAuditListOutput;
		String strTransAuditTemplate="<TransactionAudits><TransactionAudit Amount=\"\" BusinessDay=\"\" DateTime=\"\" DocumentType=\"\" InsideTransaction=\"\" ManagerID=\"\" OperatorID=\"\" OrderNumber=\"\" OrderTotal=\"\" OrganizationCode=\"\" OriginalTerminalID=\"\" OriginalTransactionNumber=\"\" POSSequenceNumber=\"\"ProcedureID=\"\" Quantity=\"\" Reason=\"\" TerminalID=\"\" TransAuditKey=\"\" TransactionNumber=\"\"><OrderState OrderData=\"\" OrderDetails=\"\"></TransactionAudit></TransactionAudits>";

		//Document transAuditTemplateDoc=KohlsXMLUtil.getDocument(strTransAuditTemplate);
		docTransactionAuditListOutput = KOHLSBaseApi.invokeAPI(env, strTransAuditTemplate,  KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS, docTransactionAuditInput);
	
		logger.verbose("output of  getTransactionAuditListForPOS::"+SCXmlUtil.getString(docTransactionAuditListOutput));
		String OrderDataAttr=(KohlsXMLUtil.getElementByXpath(docTransactionAuditListOutput, "//TransactionAudits/TransactionAudit/OrderState")).getAttribute(KohlsPOCConstant.ATTR_ORDER_DATA);
		String OrderDetailsAttr=(KohlsXMLUtil.getElementByXpath(docTransactionAuditListOutput, "//TransactionAudits/TransactionAudit/OrderState")).getAttribute("OrderDetails");
		logger.verbose("Fetched OrderData Attribute-->"+OrderDataAttr);
		
		//Verify if output consists of OrderData and StoreTimeZoneForEJ is stamped before
		if(!YFCObject.isVoid(OrderDataAttr) && !OrderDataAttr.contains("StoreTimeZoneForEJ")){
		logger.verbose("After Escape Util-->"+StringEscapeUtils.unescapeXml(OrderDataAttr));
		String modifiedreceiptDataAttr = StringEscapeUtils.unescapeXml(OrderDataAttr);
		
		Document docOrgListOutput = getOrganizationLocaleForEJ(env,
				eleSaleTypeTransaction);
		String strTimeZone="";
		
		if(!YFCObject.isVoid(docOrgListOutput)){
		 strTimeZone = getLocaleTimeZoneForEJ(env, docOrgListOutput);
		
		 if (!YFCObject.isVoid(strTimeZone)){
			//Set StoreTimeZOne on ReceiptData	
			String replaceString = "<Order StoreTimeZoneForEJ=\""+ strTimeZone +"\" ";
			String modString = modifiedreceiptDataAttr.replaceFirst("<Order ",replaceString );
		    KohlsXMLUtil.getElementByXpath(docTransactionAuditListOutput, "//TransactionAudits/TransactionAudit/OrderState").setAttribute(KohlsPOCConstant.ATTR_ORDER_DATA,modString);
			Document transactionDataIn = XMLUtil.createDocument(KohlsXMLUtil.getElementByXpath(docTransactionAuditListOutput, "//TransactionAudits/TransactionAudit"));		
	
	
			logger.verbose("Input for manageTransactionAuditForPOS:: "+SCXmlUtil.getString(transactionDataIn));
			//Call manageTransactionAuditForPOS  API - <Locale  LocaleCode="en_US_PST"/>
			Document docManageTransactionAuditOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_TRANSACTION_AUDIT_FOR_POS,transactionDataIn);
			logger.verbose("output of  docManageReceiptOutput::"+SCXmlUtil.getString(docManageTransactionAuditOutput));
		 		}
			}
		}} catch (Exception e) {		
			e.printStackTrace();
		}
	}


	
	private void generateLocaleTimeZoneForAccount(YFSEnvironment env,
			Document inTransactionReceiptData) {
		
		/**
		 * 1. form Input for manageAccountForPOS  --
		 * append     <AdditionalDataList>
							<AdditionalData AdditionalDataKey="" Name="StoreTimeZoneEJ" ParentKey="" ParentTable="" Value="America/Los_Angeles"/>
	 				</AdditionalDataList>
		 * 2. call manageAccountForPOS
		 * 
		 */		
		Document docOrgListOutput;
		try {
			
			logger.verbose("****************** generateLocaleTimeZoneForAccount ******* START ***************** ");
			//Call getAccountListForPOS and verify if AddtionalData exists with StoreTimeZONEForEJ  -getAccountListForPOS 
			
			
			Document inAccountList=XMLUtil.createDocument(KohlsXMLUtil.getElementByXpath(inTransactionReceiptData, "//Transaction/Account"));
			logger.verbose("Input to getAccountListForPOS :: "+SCXmlUtil.getString(inAccountList));
			Document docGetAccountListForPOSOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ACCOUNT_LIST_FOR_POS,inAccountList);
			boolean isExists=storeTimeZoneForEJIsExists(docGetAccountListForPOSOutput);
		
			if(!isExists){
			Element eleTransaction=inTransactionReceiptData.getDocumentElement();
			Element eleTransactionAccount=KohlsXMLUtil.getElementByXpath(inTransactionReceiptData, "//Transaction/Account");
			Element eleAdditionalDataList=KohlsXMLUtil.createChild(eleTransactionAccount,KohlsPOCConstant.ELE_ADDITIONAL_DATA_LIST);
			Element eleAdditionalData=KohlsXMLUtil.createChild(eleAdditionalDataList, KohlsPOCConstant.ELE_ADDITIONAL_DATA);
			eleAdditionalData.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_STORE_TIME_ZONE_FOR_EJ);
			docOrgListOutput = getOrganizationLocaleForEJ(env,eleTransaction);
			String strTimeZone="";
			
			if(!YFCObject.isVoid(docOrgListOutput)){
				strTimeZone = getLocaleTimeZoneForEJ(env, docOrgListOutput);
				if (!YFCObject.isVoid(strTimeZone)){
					//Set StoreTimeZone on Account AddtionalData
					logger.verbose("checking element"+ strTimeZone);
					eleAdditionalData.setAttribute(KohlsPOCConstant.Value, strTimeZone);
					Document inAccount=XMLUtil.createDocument(KohlsXMLUtil.getElementByXpath(inTransactionReceiptData, "//Transaction/Account"));
					logger.verbose("Input to manageAccountForPOS:: "+SCXmlUtil.getString(inAccount));
					Document docManageAccountForPOSOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_ACCOUNT_FOR_POS,inAccount);
					logger.verbose("output of  manageAccountForPOS::"+SCXmlUtil.getString(docManageAccountForPOSOutput));
					
					logger.verbose("****************** generateLocaleTimeZoneForAccount ******* END ***************** ");
				}
			
			}}} catch (DOMException e) {
			
			e.printStackTrace();
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
		
		

	private boolean storeTimeZoneForEJIsExists(
			Document docGetAccountListForPOSOutput) throws TransformerException {
		
		Element eleSetTimeZoneForEJ=KohlsXMLUtil.getElementByXpath(docGetAccountListForPOSOutput, "//AdditionalData[@Name='StoreTimeZoneForEJ']");
		if(YFCObject.isVoid(eleSetTimeZoneForEJ))
			return false;
		else
			return true;
		
	}


	/**
	 * @param env
	 * @param inTransactionReceiptData
	 * @throws DOMException
	 * @throws Exception
	 * @throws TransformerException
	 * @throws ParserConfigurationException
	 */
	private void generateLocaleTimeZoneForSale(YFSEnvironment env,
			Document inTransactionReceiptData) throws DOMException, Exception,
			TransformerException, ParserConfigurationException {
		
		/**
		 * 1. form Input for getReceiptDataListForPOS
		 * 2. call getReceiptDataListForPOS
		 * 3. set TimeZoneInReceiptData
		 * 4. form Input for manageReceiptDataForPOS
		 */
		try {
			Element eleSaleTypeTransaction=inTransactionReceiptData.getDocumentElement();
			
			Document docReceiptDataInput = YFCDocument.createDocument(KohlsPOCConstant.ELE_RECEIPT_DATA).getDocument();
			Element eleReceiptData=docReceiptDataInput.getDocumentElement();
			eleReceiptData.setAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_OPERATOR_ID) );
			eleReceiptData.setAttribute(KohlsPOCConstant.A_ORG_CODE,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.A_ORG_CODE) );
			eleReceiptData.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID) );
			eleReceiptData.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID) );
			eleReceiptData.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM) );
			
			
			 //Call getReceiptDataListForPOS  API
			Document docReceiptDataOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_RECEIPT_DATA_LIST_FOR_POS,docReceiptDataInput);
			
			//verify if Receipt Details Exists
			if(docReceiptDataOutput.getElementsByTagName("ReceiptData").getLength()>0){
			logger.verbose("output of  getReceiptDataListForPOS::"+SCXmlUtil.getString(docReceiptDataOutput));
			String receiptDataAttr=(KohlsXMLUtil.getElementByXpath(docReceiptDataOutput, "//ReceiptDataList/ReceiptData")).getAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA);
			logger.verbose("Fetched OrderData Attribute-->"+receiptDataAttr);
			logger.verbose("After Escape Util-->"+StringEscapeUtils.unescapeXml(receiptDataAttr));
			String modifiedreceiptDataAttr = StringEscapeUtils.unescapeXml(receiptDataAttr);
			
			//verify if StoreTimeZoneForEJ was stamped before
			if(!receiptDataAttr.contains("StoreTimeZoneForEJ")){
			Document docOrgListOutput = getOrganizationLocaleForEJ(env,
					eleSaleTypeTransaction);
			String strTimeZone="";
			
			if(!YFCObject.isVoid(docOrgListOutput)){
				strTimeZone = getLocaleTimeZoneForEJ(env, docOrgListOutput);
				if (!YFCObject.isVoid(strTimeZone)){
			
			//Set StoreTimeZOne on ReceiptData
			logger.verbose("checking element"+ strTimeZone);
			String replaceString = "<POSReceipt StoreTimeZoneForEJ=\""+ strTimeZone +"\" ";
			
			String modString = modifiedreceiptDataAttr.replaceFirst("<POSReceipt ",replaceString );
			logger.verbose("appended1"+modifiedreceiptDataAttr);
			logger.verbose("appended"+modString);
			
			KohlsXMLUtil.getElementByXpath(docReceiptDataOutput, "//ReceiptDataList/ReceiptData").setAttribute(KohlsPOCConstant.ELE_RECEIPT_DATA,modString);
			Document receiptDataIn = XMLUtil.createDocument(KohlsXMLUtil.getElementByXpath(docReceiptDataOutput, "//ReceiptDataList/ReceiptData"));
			logger.verbose("setting"+strTimeZone);

			//Call manageReceiptData  API - <Locale  LocaleCode="en_US_PST"/>
			logger.verbose("Input for manageReceiptDataForPOS::"+SCXmlUtil.getString(receiptDataIn));
			Document docManageReceiptOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MANAGE_RECEIPT_DATA_FOR_POS,receiptDataIn);
			logger.verbose("output of  docManageReceiptOutput::"+SCXmlUtil.getString(docManageReceiptOutput));
				}
			
		}}}			
			else{
				//ReceiptDetails does not exist, update Transaction Audit
				generateLocalTimeZoneForTransaction(env, inTransactionReceiptData);
				}}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param env
	 * @param docOrgListOutput
	 * @return
	 * @throws DOMException
	 * @throws Exception
	 * @throws TransformerException
	 */
	private String getLocaleTimeZoneForEJ(YFSEnvironment env,
			Document docOrgListOutput) throws DOMException, Exception,
			TransformerException {
		//GetLocaleList
		Document docGetLocaleListInput = YFCDocument.createDocument(KohlsPOCConstant.ATTR_LOCALE).getDocument();
		Element eleGetLocaleListInput=docGetLocaleListInput.getDocumentElement();		
		eleGetLocaleListInput.setAttribute(KohlsPOCConstant.ATTR_EJ_LOCALE_CODE,SCXmlUtil.getXpathAttribute(docOrgListOutput.getDocumentElement(), "/OrganizationList/Organization/@LocaleCode" ));
		//String strOrgLocaleCode=SCXmlUtil.getXpathAttribute(eleGetLocaleListInput.getDocumentElement(), "/OrganizationList/Organization/@LocaleCode");
		
		//Call GetLocaleList  API - <Locale  LocaleCode="en_US_PST"/>
		Document docLocaleListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_LOCALE_LIST,docGetLocaleListInput);
		logger.verbose("output of  getLocaleList::"+SCXmlUtil.getString(docLocaleListOutput));
		
		String strTimeZone=(KohlsXMLUtil.getElementByXpath(docLocaleListOutput, "//LocaleList/Locale")).getAttribute(KohlsPOCConstant.ATTR_TIME_ZONE);
		return strTimeZone;
	}

	/**
	 * @param env
	 * @param eleSaleTypeTransaction
	 * @return
	 * @throws DOMException
	 * @throws Exception
	 */
	private Document getOrganizationLocaleForEJ(YFSEnvironment env,
			Element eleSaleTypeTransaction) throws DOMException, Exception {
	
		Document docOrgListOutput = null;
		try {
			//<Organization MaximumRecords="5000" OrganizationCode="9951"/>  - getOrganizationListForPOS
			Document docGetOrgCodeListInput = YFCDocument.createDocument(KohlsPOCConstant.ELE_ORGANIZATION).getDocument();
			Element eleGetOrgCodeListInput=docGetOrgCodeListInput.getDocumentElement();		
			eleGetOrgCodeListInput.setAttribute(KohlsPOCConstant.A_ORG_CODE,eleSaleTypeTransaction.getAttribute(KohlsPOCConstant.A_ORG_CODE) );
			
			 //Call getOrganizationListForPOS  API
			docOrgListOutput = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_ORGANIZATION_LIST,docGetOrgCodeListInput);
			logger.verbose("output of  getOrganizationListForPOS::"+SCXmlUtil.getString(docOrgListOutput));
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return docOrgListOutput;
	}
}
