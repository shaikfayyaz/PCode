package com.kohls.poc.api;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.custom.dbi.KOHLS_Saf_Resp_Records;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.dbclasses.KOHLS_Saf_Resp_RecordsDBHome;
import com.yantra.shared.dbclasses.POS_PSI_SafDBHome;
import com.yantra.shared.dbi.POS_PSI_Saf;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dblayer.PLTQueryOperator;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsUpdateSAFRecords  {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsUpdateSAFRecords.class);

	/**
	 * @param env
	 * @param inDoc - Input document will be records.
	 * This methods will iterate for Record and create an entry in custom 
	 * table with the records to process.
	 * @return
	 * @throws Exception
	 */
	public Document updateProcessedSOrder(YFSEnvironment env, Document inDoc)
			throws Exception {

		logger.beginTimer("KohlsUpdateSAFRecords.KohlsUpdateSAFRecords");
		if (logger.isDebugEnabled()){
			logger.debug("Input Xml to KohlsUpdateSAFRecords.KohlsUpdateSAFRecords is: "
					+ XMLUtil.getXMLString(inDoc));
		}
		Document docOutUpdateSafRecord = null;
		Element recordsElement = inDoc.getDocumentElement();
		String sStoreID = XMLUtil.getChildElement(recordsElement, KohlsPOCConstant.STORE_ID).getTextContent();
		String sDeviceID = XMLUtil.getChildElement(recordsElement, KohlsPOCConstant.DEVICE_ID_PINPAD).getTextContent();
		String sSAFStatusRule = getSAFStatusRule(env, "SAF_INELIGIBLE_STATUS", sStoreID, "DEFERRED,ELIGIBLE,IN_PROCESS");
		NodeList nlRecord = inDoc.getElementsByTagName(KohlsPOCConstant.ELEM_RECORD);
		Element eleRecords = XMLUtil.getChildElement(recordsElement, KohlsPOCConstant.E_RECORDS);
		for (int i = 0; i < nlRecord.getLength(); i++) {
			Element eleRecord = (Element) nlRecord.item(i);
			String sTranNo = XMLUtil.getChildElement(eleRecord,KohlsPOCConstant.INVOICE).getTextContent();
			String sSAFStatus = XMLUtil.getChildElement(eleRecord, KohlsPOCConstant.SAF_STATUS).getTextContent();
			String sSAFNum = XMLUtil.getChildElement(eleRecord, KohlsPOCConstant.SAF_NUM).getTextContent();
			if(sSAFStatusRule.contains(sSAFStatus)) {
			   logger.info("SAF Response Record for Store-DeviceID-TranNo-SafNum "+sStoreID+"-"+sDeviceID+"-"+sTranNo+"-"+sSAFNum+" is not persisted as SAF Status is: "+sSAFStatus);
			  XMLUtil.removeChild(eleRecords, eleRecord);
			  i--;
			  continue;
			}
			try{
			    // Check if record exists.
			    int noOfSAFRecords = getNumberOfRecordsInSAFTable(env, sDeviceID, sTranNo, sSAFNum, sStoreID);
			   if(noOfSAFRecords > 0) {
				   logger.info("SAF Response Record for Store-DeviceID-TranNo-SafNum "+sStoreID+"-"+sDeviceID+"-"+sTranNo+"-"+sSAFNum+" already present. So skipping insert.");
	              XMLUtil.removeChild(eleRecords, eleRecord);
				  i--;
				  continue;
	            } else {
	            	
	            	int psisafrecords = getNumberofRecordsinPSISAFTable(env, sDeviceID,sSAFNum);
	            	  if(psisafrecords==0)
	            	  {
	            		  logger.info("SAF Response Record for DeviceID-SafNum "+sDeviceID+"-"+sSAFNum+" does NOT have corresponding entry in POS_PSI_SAF table. So skipping insert.");
	            		  XMLUtil.removeChild(eleRecords, eleRecord);
	    				  i--;
	    				  continue;
	            	  }
	            	  logger.info("SAF Response Record for Store-DeviceID-TranNo-SafNum "+sStoreID+"-"+sDeviceID+"-"+sTranNo+"-"+sSAFNum+" is not present. So inserting it.");
	              Document docInUpdateSafRecord = XMLUtil.createDocument(KohlsPOCConstant.E_SAF_REC);
	              Element eleInUpdateSafRecord = docInUpdateSafRecord.getDocumentElement();
	              eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.E_SAF_NUM,
	                          XMLUtil.getChildElement(eleRecord,KohlsPOCConstant.SAF_NUM).getTextContent());
	              eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.E_SAF_STATUS,
	                          XMLUtil.getChildElement(eleRecord, KohlsPOCConstant.SAF_STATUS).getTextContent());
	              eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.E_INVOICE,
	                          sTranNo);
	              eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.STOREID, sStoreID);
	              eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.DEVICE_ID_ATTR, sDeviceID);

	              String compressSAFResponse = getCompressPropertyValue();
	              Document responseDoc = XMLUtil.createDocument("RESPONSE");
	              SCXmlUtil.importElement(responseDoc.getDocumentElement(), eleRecord);
	              String recordXmlString = XMLUtil.getElementXMLString(responseDoc.getDocumentElement());	            
	              if(!YFCCommon.isVoid(compressSAFResponse) && "N".equalsIgnoreCase(compressSAFResponse))
	 			  {
	            	  	eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.ATTR_SAF_RECORD, recordXmlString);
	 			  }
	              else
	              {
	            	    //Compress the Record
	            	  	String compressedRecord = compressRecordXML(recordXmlString);
	            	  	eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.ATTR_SAF_RECORD,compressedRecord);
	              }
	              String sPurgeDate = getPurgeDate(env);
	              if(!YFCCommon.isVoid( sPurgeDate ))
	              {
	                 eleInUpdateSafRecord.setAttribute(KohlsPOCConstant.PURGE_DATE,  sPurgeDate);
	              }
	           
	              if (logger.isDebugEnabled()){
	                  logger.debug("Create XML to createKohlsProcessdSafRecords API is: "
	                          + XMLUtil.getXMLString(docInUpdateSafRecord));
	              }
	              docOutUpdateSafRecord = createSAFRecord(env, docInUpdateSafRecord);
	              if (logger.isDebugEnabled()){
	                logger.debug("outPut XML  to createKohlsProcessdSafRecords API is: "+ XMLUtil.getXMLString(docOutUpdateSafRecord));
	              }
	            }
			} catch(Exception e){
				logger.error("Error while creating ProcessdSafRecords API is: ", e);
				throw new YFSException(e.getMessage());
			}
		}
		logger.endTimer("KohlsUpdateSAFRecords.KohlsUpdateSAFRecords");
		return inDoc;
	}

	/**
	 * @return
	 */
	public String getCompressPropertyValue() {
		 
		 logger.beginTimer("KohlsUpdateSAFRecords.getCompresPropertyValue");
		 String compressProperty = YFSSystem.getProperty("compress.saf.response");
		 logger.beginTimer("KohlsUpdateSAFRecords.getCompresPropertyValue");
		 return compressProperty;
	}

	/**
    * @param env,This method will create records in the custom table 
    * @return
    * @throws Exception
    */
	public Document createSAFRecord(YFSEnvironment env,
			Document docInUpdateSafRecord) throws Exception {
		logger.beginTimer("KohlsUpdateSAFRecords.createSAFRecord");
		Document docOut = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.API_CREATE_KOHLS_PROCESSED_SAF_RECORDS, docInUpdateSafRecord);
		logger.endTimer("KohlsUpdateSAFRecords.createSAFRecord");
		return docOut;
	}


   
   /**
    * @param env,This method will return the purge date
    * @return
    * @throws Exception
    */
   public String getPurgeDate( YFSEnvironment env ) throws Exception {
      logger.beginTimer( "KohlsUpdateSAFRecords.getPurgeDate" );     
      String sNoOfDays =   KohlsPoCCommonAPIUtil.getRuleValue(env,KohlsPOCConstant.KOHLS_PURGE_CLIENT_SAF,KohlsPOCConstant.A_KOHLS_RETAIL,"5");
      SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd" );
      // Getting current date
      Calendar cal = Calendar.getInstance();
      // Displaying current date in the desired format
      if ( logger.isDebugEnabled() )
      {
         logger.debug( "Current Date: " + sdf.format( cal.getTime() ) );
      }
      // Number of Days to add
      if ( !YFCCommon.isVoid( sNoOfDays ) )
      {
         cal.add( Calendar.DAY_OF_MONTH, Integer.parseInt( sNoOfDays ) );
      }
      // Date after adding the days to the current date
      String newDate = sdf.format( cal.getTime() );
      logger.endTimer( "KohlsUpdateSAFRecords.getPurgeDate" );
      return newDate;
   }
   
   /**
   * Create By mrjoshi * 
   * @param env
   * @param ruleId
   * @param callingOrg
   * @param defaultValue
   * @return
   * @throws Exception
   */
  public String getSAFStatusRule(YFSEnvironment env, String ruleId, String callingOrg, String defaultValue) throws Exception {
     logger.beginTimer( "KohlsUpdateSAFRecords.getSAFStatusRule" );
     String ruleValue = KohlsPoCCommonAPIUtil.getRuleValue(env, ruleId, callingOrg, "PROCESSED,NOT_PROCESSED,DECLINED");
     logger.endTimer( "KohlsUpdateSAFRecords.getSAFStatusRule" );
     return ruleValue;     
   }
  
  /**
   * Create By mrjoshi * 
   * @param env
   * @param sDeviceID
   * @param tranNo
   * @param safNum
   * @return
 * @throws Exception 
   */
  public int getNumberOfRecordsInSAFTable(YFSEnvironment env, String sDeviceID, String tranNo, String safNum,String storeNo) throws Exception {
    logger.beginTimer( "KohlsUpdateSAFRecords.getNumberOfRecordsInSAFTable" );
    PLTQueryBuilder query = new PLTQueryBuilder( true );
    query.appendString( "DEVICE_ID", PLTQueryOperator.EQUALS, sDeviceID );
    query.appendString( "AND STORE_ID", PLTQueryOperator.EQUALS, storeNo );
    query.appendString( "AND INVOICE", PLTQueryOperator.EQUALS, tranNo );
    query.appendString( "AND SAF_NUM", PLTQueryOperator.EQUALS, safNum );
    YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
    // setting colony id for fact lookup
    ctx.getPoolResolver().addFact("ColonyId", "STORE_GRP_01");
    List<KOHLS_Saf_Resp_Records> safRecords = KOHLS_Saf_Resp_RecordsDBHome.getInstance().listWithWhere(ctx, query, 1);
    logger.endTimer( "KohlsUpdateSAFRecords.getNumberOfRecordsInSAFTable" );
    return safRecords.size();
  }
  
  /**
   * Create By mrjoshi * 
   * @param stringToRecord
   * @return
   * @throws UnsupportedEncodingException 
   */
  public String compressRecordXML(String stringToRecord) throws UnsupportedEncodingException {
    logger.beginTimer( "KohlsUpdateSAFRecords.compressRecordXML" );
    String compressedString = KohlsReprocessRequestUtil.compressXML(stringToRecord);
    logger.endTimer( "KohlsUpdateSAFRecords.compressRecordXML" );
    return compressedString;
  }
  
  /**
   * Created By Sayeesh * 
   * @param env
   * @param sDeviceID
   * @param safNum
   * @return
 * @throws Exception 
   */
  public int getNumberofRecordsinPSISAFTable(YFSEnvironment env,String deviceId, String safNum) throws Exception {
	    logger.beginTimer( "KohlsUpdateSAFRecords.getNumberofRecordsinPSISAFTable" );
	    PLTQueryBuilder query = new PLTQueryBuilder( true );
	    query.appendString( "DEVICE_ID", PLTQueryOperator.EQUALS, deviceId );
	    query.appendString( "AND SAF_NUM", PLTQueryOperator.EQUALS, safNum );	    
	    YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
	    ctx.getPoolResolver().addFact("ColonyId", "STORE_GRP_01");
	    List<POS_PSI_Saf> safRecords = POS_PSI_SafDBHome.getInstance().listWithWhere(ctx, query, 1);
	    logger.endTimer( "KohlsUpdateSAFRecords.getNumberofRecordsinPSISAFTable" );
	    return safRecords.size();
	  }
  
}
