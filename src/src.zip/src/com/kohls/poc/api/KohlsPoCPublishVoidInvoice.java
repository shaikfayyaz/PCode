package com.kohls.poc.api;



import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.print.attribute.standard.PrinterState;
import javax.xml.parsers.FactoryConfigurationError;

import javax.xml.parsers.ParserConfigurationException;



import com.kohls.poc.util.KohlsPoCCommonAPIUtil;

import org.w3c.dom.Document;

import org.w3c.dom.Element;

import org.w3c.dom.NodeList;

import org.xml.sax.SAXException;



import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;

import com.kohls.common.util.XMLUtil;

import com.kohls.common.util.XPathUtil;

import com.kohls.poc.constant.KohlsPOCConstant;

import com.yantra.yfc.core.YFCObject;

import com.yantra.yfc.dom.YFCDocument;

import com.yantra.yfc.log.YFCLogCategory;

import com.yantra.yfc.util.YFCCommon;

import com.yantra.yfc.util.YFCDate;

import com.yantra.yfs.japi.YFSEnvironment;

import com.yantra.yfs.japi.YFSException;



/**

 * @author mrjoshi This class prepares the Sales hub xml for Post Void scenario.

 */

public class KohlsPoCPublishVoidInvoice extends KOHLSBaseApi {

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCPublishVoidInvoice.class);



	/**

	 * This method takes ORDER_CHANGE.ON_CANCEL event xml as input and calls

	 * getOrderList and getTransactionAuditList apis to form the output for SalesHub

	 * with necessary attributes.

	 * 

	 * @param env

	 * @param inDoc

	 * @return docOutputInvDetail

	 * @throws SAXException

	 * @throws IOException

	 * @throws Exception

	 */

	/**

	 * @param env

	 * @param inDoc

	 * @return

	 * @throws SAXException

	 * @throws IOException

	 * @throws Exception

	 */

	public Document postVoid(YFSEnvironment env, Document inDoc) throws SAXException, IOException, Exception {

		logger.verbose("***Started Verbose for KohlsPoCPublishVoidInvoice****");

		// MAD337 Start

		Element inElement = inDoc.getDocumentElement();

		String voidTransactionNumber = inElement.getAttribute("VoidTransactionNo");

		Element eleOrderInvoice = null;

		String sProcedureID = "204";
		String modifyProgId = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_MODIFYPROGID);
		
		//call getOrderInvoiceForOrder to get the Invoice details for Offline transaction
		if (KohlsPOCConstant.CONSTANT_LOAD_OFFLINE_TRANSACTION.equalsIgnoreCase(modifyProgId) 
				|| KohlsPOCConstant.A_GRAVITY.equalsIgnoreCase(modifyProgId)) {
				eleOrderInvoice = getOrderInvoiceForOrder(env, inDoc);
			}
		 else {
			eleOrderInvoice = getOrderInvoice(env, inDoc);
		} 

		// MAD 337 End

		String sOrderNo = eleOrderInvoice.getAttribute("OrderNo");

		String sOHKey = eleOrderInvoice.getAttribute("OrderHeaderKey");

		String sModifyts = eleOrderInvoice.getAttribute("Modifyts");

		YFCDate date = new YFCDate();

		String sCreateTimeStamp = date.getString(null, true);

		Document docOutputInvDetail = null;

		KohlsPocInvoiceToSalesHubAPI kohlsPocInvoiceToSalesHubAPI = new KohlsPocInvoiceToSalesHubAPI();
		


		// try {



		// Create the output document and set the required attributes.



		docOutputInvDetail = YFCDocument.createDocument(KohlsPOCConstant.ATTR_INVOICE_DETAIL).getDocument();

		Element eleInvoiceDetail = docOutputInvDetail.getDocumentElement();

		eleInvoiceDetail.setAttribute("MessageType", "PostVoid");

		eleInvoiceDetail.setAttribute("Postvoid", "Y");

		eleInvoiceDetail.setAttribute("Modifyts", sModifyts);

		eleInvoiceDetail.setAttribute("CreateTimeStamp", sCreateTimeStamp);

		Element eleInvHeader = XMLUtil.createChild(eleInvoiceDetail, "InvoiceHeader");



		/*

		 * invoke getOrderList API to get PromotionType and other order details and

		 * append it to InvoiceDetail node.

		 */



		Document inOrdList = XMLUtil.createDocument("Order");

		inOrdList.getDocumentElement().setAttribute("OrderHeaderKey", sOHKey);

		Document outOrdList = invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_PROMOTION_TEMPLATE),

				"getOrderList", inOrdList);

		Element eleOutOrder = (Element) (XPathUtil.getNodeList(outOrdList.getDocumentElement(), "/OrderList/Order")

				.item(0));



		String sSellerOrgCode = eleOutOrder.getAttribute("SellerOrganizationCode");

		eleOutOrder.removeAttribute("SellerOrganizationCode");


		// Added for PA - start
		Element eleOrderExtn = XMLUtil.getChildElement(eleOutOrder, "Extn");
		String sExtnPOCFeature = eleOrderExtn.getAttribute("ExtnPOCFeature");
		if (!YFCCommon.isVoid(sExtnPOCFeature)) {
			if ("PriceAdjustment".equals(sExtnPOCFeature)) {
				sProcedureID = "10104";
				eleInvoiceDetail.setAttribute("MessageType", "PriceAdjustmentPostVoid");
				eleOrderExtn.removeAttribute("ExtnPsaStatus");
			} else if ("ReceiptedReturn".equalsIgnoreCase(sExtnPOCFeature)
					|| "NonReceiptedReturn".equalsIgnoreCase(sExtnPOCFeature)) {
				eleInvoiceDetail.setAttribute("MessageType", "ReturnPostVoid");
			}
		}
		// Added for PA - end

		// code added for defect:1531 on 05/02/2014.
		Element elePromotions = (Element) (XPathUtil

				.getNodeList(outOrdList.getDocumentElement(), "/OrderList/Order/Promotions").item(0));

		String sPromotionApplied = null;

		Element elePromotion = null;

		Element eleExtn = null;

		NodeList nlPromotion = XPathUtil.getNodeList(outOrdList.getDocumentElement(),

				"/OrderList/Order/Promotions/Promotion");

		if (!YFCCommon.isVoid(nlPromotion)) {

			for (int i = 0; i < nlPromotion.getLength(); i++) {

				elePromotion = (Element) nlPromotion.item(i);

				eleExtn = (Element) elePromotion.getElementsByTagName("Extn").item(0);

				String sExtnActivationBarCode = eleExtn.getAttribute("ExtnActivationBarCode");

				sPromotionApplied = elePromotion.getAttribute("PromotionApplied");

				String sPromotionType = elePromotion.getAttribute("PromotionType");

				if ("KOHLS_CASH_EARNED".equalsIgnoreCase(sPromotionType)

						|| "KOHLS_CASH_REISSUE".equalsIgnoreCase(sPromotionType)) {
					if (!YFCCommon.isVoid(sExtnActivationBarCode)) {
						sPromotionApplied = "Y";

						elePromotion.setAttribute("PromotionApplied", "Y");

					}

				}
				if ("N".equalsIgnoreCase(sPromotionApplied)) {

					elePromotions.removeChild(elePromotion);

				}

			}

		}



		/*

		 * invoke getTransactionAuditList API to get Transaction audits and append it to







		 * InvoiceDetail node. For KCC Payment void after, retreive it from Admin Audit

		 * with 117

		 * 


		 */

		NodeList nlElements = null;

		if ("9090.ex".equalsIgnoreCase(XMLUtil.getAttribute(eleOutOrder, "DocumentType"))) {
		   // getting the previous day to stamp on oms xml
		   String strPurpose = eleOutOrder.getAttribute("Purpose");
         if ( "KCPaymentCorrection".equalsIgnoreCase( strPurpose ) )
         {
            String strPrevDate = getPreviousBusinessday( env );
            eleOutOrder.setAttribute( "KCPaymentCorrectionDate", strPrevDate );
         }

			String transNo = XMLUtil.getAttribute(eleOutOrder, "TransactionNo");

			nlElements = getAdminAuditForKCCPayment(env, transNo, sSellerOrgCode, "117");



		} else {

		Document inTranDoc = YFCDocument.createDocument("TransactionAudit").getDocument();

		Element eleInput = inTranDoc.getDocumentElement();

		eleInput.setAttribute("OrderNumber", sOrderNo);

		// Changes for PA - begin
		// eleInput.setAttribute("ProcedureID","204");

		eleInput.setAttribute("ProcedureID", sProcedureID);
		// Changes for PA - end
		eleInput.setAttribute("OrganizationCode", sSellerOrgCode);

		Document orderListDocOutput = invokeAPI(env,





				XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE), "getTransactionAuditListForPOS",
				inTranDoc);
		
        // To Update OriginalTransactionNumber if we had PSA mid void before post void of sale-----Start
        String extnPsaStatus = eleOrderExtn.getAttribute( KohlsPOCConstant.EXTN_PSA_STATUS );
        logger.debug( KohlsPOCConstant.EXTN_PSA_STATUS + " = " + extnPsaStatus );
        Document saleOrderListDocOutput = null;
        String saleTransactionNumber = null;
        if ( ( KohlsPOCConstant.PSA_VOIDED_STATUS.equalsIgnoreCase( extnPsaStatus ) ) )
        {

           // Procedure id 201 is sale procedure id.
           eleInput.setAttribute( KohlsPOCConstant.ATTR_PROCEDURE_ID, KohlsPOCConstant.STATIC_CONSTANT_CREATE_TRANSACTION_PROCEDURE_ID );
           saleOrderListDocOutput = invokeAPI( env, XMLUtil.getDocument( KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE ), KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS, inTranDoc );
           logger.debug( "inTranDoc = " + XMLUtil.getXMLString( inTranDoc ) );
           NodeList saleTransactionAuditNodeList = saleOrderListDocOutput.getElementsByTagName( KohlsPOCConstant.ATTR_TRANSACTION_AUDIT );
           if ( saleTransactionAuditNodeList.getLength() > 0 )
           {
              Element saleTransactionAuditElement = (Element) saleTransactionAuditNodeList.item( 0 );
              saleTransactionNumber = saleTransactionAuditElement.getAttribute( KohlsPOCConstant.ATTR_TRANS_NUM );

           }
           nlElements = orderListDocOutput.getElementsByTagName( KohlsPOCConstant.ATTR_TRANSACTION_AUDIT );
           if ( nlElements.getLength() > 0 && !YFCCommon.isVoid( saleTransactionNumber ) )
           {
              /*
               * Updating OriginalTransactionNumber in Post Void Transaction audit with saleTransactionNumber
               * when it has PSA mid void transaction number
               */
              Element updatePVTransactionAudit = (Element) nlElements.item( 0 );
              updatePVTransactionAudit.setAttribute( KohlsPOCConstant.ATTR_ORIGINAL_TRANS_NUM, saleTransactionNumber );
              logger.debug( "updatePVTransactionAudit" + updatePVTransactionAudit );
              logger.debug( "saleTransactionNumber " + saleTransactionNumber );
           }
           else
           {
              nlElements = orderListDocOutput.getElementsByTagName( KohlsPOCConstant.ATTR_TRANSACTION_AUDIT );
           }
           logger.debug( "orderListDocOutput = " + XMLUtil.getXMLString( orderListDocOutput ) );

        }
        else
        {
           nlElements = orderListDocOutput.getElementsByTagName( KohlsPOCConstant.ATTR_TRANSACTION_AUDIT );
        }
        // To Update OriginalTransactionNumber if we had PSA mid void before post void of sale-----End

		if (KohlsPOCConstant.CONSTANT_LOAD_OFFLINE_TRANSACTION.equalsIgnoreCase(modifyProgId)

				&& nlElements.getLength() == 0) {

			logger.debug("Transaction Audit is Empty for post Void");








			nlElements = getTransactionAuditForVoid(env, sOrderNo, sSellerOrgCode, nlElements, voidTransactionNumber);

		}
		
		}

		if (nlElements.getLength() > 0) {

			Element eleTranAudits = null;

			if ("9090.ex".equalsIgnoreCase(XMLUtil.getAttribute(eleOutOrder, "DocumentType"))) {

				Element adminAudit = (Element) nlElements.item(0);

				eleTranAudits = XMLUtil.createChild(eleInvHeader, "TransactionAudits");

				Element eleTranAudit = XMLUtil.createChild(eleTranAudits, "TransactionAudit");

				eleTranAudit.setAttribute(KohlsPOCConstant.ATTR_MODIFYTS,

						eleOutOrder.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));

				translateToTransactionAudit(adminAudit, eleTranAudit, sOrderNo);

			} else {

			Element tranAudit = (Element) nlElements.item(0);

			tranAudit.setAttribute(KohlsPOCConstant.ATTR_MODIFYTS,

					eleOutOrder.getAttribute(KohlsPOCConstant.ATTR_MODIFYTS));

			eleTranAudits = XMLUtil.createChild(eleInvHeader, "TransactionAudits");

			XMLUtil.importElement(eleTranAudits, tranAudit);

        }



			// Fetch tender transaction information



			Document chargeTransDetailsDoc = kohlsPocInvoiceToSalesHubAPI.getChargeTransactionDetails(env, sOHKey,

					sSellerOrgCode);

			// Manoj 08/11: Updated logic for defect 2689 - Begin

			List<Element> chargeTransDetailsEleList = XMLUtil.getElementsByTagName(

					chargeTransDetailsDoc.getDocumentElement(), KohlsPOCConstant.E_CHARGE_TRANSACTION_DETAIL);

			for (Element chargeTransDetailsEle : chargeTransDetailsEleList) {

				// String offlineStatus =

				// XMLUtil.getAttribute(chargeTransDetailsEle,

				// KohlsPOCConstant.A_OFFLINE_STATUS);

				Element paymentMethodEle = XMLUtil.getChildElement(chargeTransDetailsEle,

						KohlsPOCConstant.E_PAYMENT_METHOD);

				String sPaymentTypeGroup = XMLUtil.getAttribute(paymentMethodEle, "PaymentTypeGroup");

				List<Element> creditCardTransList = XMLUtil.getElementsByTagName(chargeTransDetailsEle,

						KohlsPOCConstant.ELEM_CREDIT_CARD_TRANSACTION);



				if (creditCardTransList.size() > 0) {

					Element creditCardTransEle = creditCardTransList.get(0);

					String sInternalReturnCode = creditCardTransEle.getAttribute("InternalReturnCode");

					if (!("STORED_VALUE_CARD".equalsIgnoreCase(sPaymentTypeGroup)

							&& "Force Voided".equalsIgnoreCase(sInternalReturnCode))) {

						XMLUtil.removeChild(chargeTransDetailsDoc.getDocumentElement(), chargeTransDetailsEle);

					}

				} else {

					XMLUtil.removeChild(chargeTransDetailsDoc.getDocumentElement(), chargeTransDetailsEle);

				}

			}

			// Manoj 08/11: Updated logic for defect 2689 - End

			if (chargeTransDetailsDoc.getDocumentElement().hasChildNodes()) {

				XMLUtil.importElement(eleOutOrder, chargeTransDetailsDoc.getDocumentElement());

			}



			XMLUtil.importElement(eleInvHeader, eleOutOrder);



			logger.verbose("**Ended Verbose for KohlsPoCPublishVoidInvoice****");

		} else {
			String strAttempt = inElement.getAttribute("Attempt");
			int iAttempt = 0;
			if(!YFCCommon.isVoid(strAttempt)) {
				iAttempt = Integer.parseInt(strAttempt);
			}

			if(iAttempt < 10) {
				inElement.setAttribute("Attempt", Integer.toString(iAttempt + 1));
				invokeService(env, "CreateKohlsPoCPostSendVoidInvoiceToSHSyncQ", inDoc);
			} else {
				YFSException e = new YFSException();
				e.setErrorDescription("Transaction Audit is not present for Post Void");
				throw e;
			}
        }

		// }

		/*

		 * catch (Exception e){ if (e instanceof YFSException) { YFSException

		 * yfsException = (YFSException) e; throw yfsException; } else{ throw new

		 * YFSException(e.getMessage()); } }

		 */



		// Start of PST-1821

		// Commented for CPE-2281
		// setDateBasedonStoreTimezone(env, eleInvHeader,sSellerOrgCode);

		// End of PST-1821



		// Start of PST-971

		docOutputInvDetail = setExtnSimplePromoPriceforOrderLines(docOutputInvDetail);

		// End of PST-971



		return docOutputInvDetail;

	}



	private Document setExtnSimplePromoPriceforOrderLines(Document doc) {



		Element rootElement = doc.getDocumentElement();

		List orderLineNodeList = XMLUtil.getElementsByTagName(rootElement, KohlsPOCConstant.ELEM_ORDER_LINE);



		if (null != orderLineNodeList && orderLineNodeList.size() > 0) {



			for (int i = 0; i < orderLineNodeList.size(); i++) {



				Element orderLine = (Element) orderLineNodeList.get(i);

				Element orderLineExtn = (Element) orderLine.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);



				if (!YFCObject.isVoid(orderLineExtn)) {

					if (orderLineExtn.hasAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE)) {



						String extnSimplePromoPrice = orderLineExtn

								.getAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE);



						if (YFCCommon.isVoid(extnSimplePromoPrice)) {

							orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");

						}

					} else {

						orderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");

					}

				} else {

					Element extnOrderLine = doc.createElement(KohlsPOCConstant.A_EXTN);

					extnOrderLine.setAttribute(KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, "0");

					orderLine.appendChild(extnOrderLine);

				}

			}

		}



		return doc;

	}



	private void setDateBasedonStoreTimezone(YFSEnvironment env, Element eleInvoiceHeader, String storeId)

			throws FactoryConfigurationError, Exception {

		logger.debug("KohlsPoCPublishVoidInvoice.setDateBasedonStoreTimezone--Begin");

		Element orderElement = null;

		NodeList orderList = eleInvoiceHeader.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);

		if (!YFCCommon.isVoid(orderList) && orderList.getLength() > 0) {

			orderElement = (Element) orderList.item(0);



		}

		if (!YFCCommon.isVoid(orderElement) && orderElement.hasAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE)

				&& orderElement.getAttribute(KohlsPOCConstant.ATTR_ENTRY_TYPE)

						.equalsIgnoreCase(KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE)) {

			String orderDate = "";

			String dateInvoiced = "";

			if (orderElement.hasAttribute(KohlsPOCConstant.A_ORDER_DATE)) {

				orderDate = orderElement.getAttribute(KohlsPOCConstant.A_ORDER_DATE);

				logger.debug("The order date is   :" + orderDate);

			}



			if (eleInvoiceHeader.hasAttribute(KohlsPOCConstant.A_DATE_INVOICED)) {

				dateInvoiced = eleInvoiceHeader.getAttribute(KohlsPOCConstant.A_DATE_INVOICED);

				logger.debug("The dateInvoiced date is   :" + dateInvoiced);

			}

			String localeCode = KohlsPoCCommonAPIUtil.getLocaleCode(env, storeId);

			logger.debug("LocalCode is   :" + localeCode);


			logger.debug("storeId is   :" + storeId);

			if (!KohlsPOCConstant.LOCALE_CODE_CST.equals(localeCode)) {

				logger.debug("The store is not in CST");

				String timezone = KohlsPoCCommonAPIUtil.getTimeZoneID(env, localeCode);

				logger.debug("Timezone is  :" + timezone);

				if (!YFCCommon.isVoid(orderDate)) {

					String orderDateBasedOnTimeZone = KohlsPoCCommonAPIUtil.convert(orderDate, timezone);

					logger.debug("orderDateBasedOnTimeZone is  :" + orderDateBasedOnTimeZone);

					orderElement.setAttribute(KohlsPOCConstant.A_ORDER_DATE, orderDateBasedOnTimeZone);

				}

				if (!YFCCommon.isVoid(dateInvoiced)) {

					String dateInvoiceBasedOnTimeZone = KohlsPoCCommonAPIUtil.convert(dateInvoiced, timezone);

					logger.debug("dateInvoiceBasedOnTimeZone is    :" + dateInvoiceBasedOnTimeZone);

					eleInvoiceHeader.setAttribute(KohlsPOCConstant.A_DATE_INVOICED, dateInvoiceBasedOnTimeZone);

				}

			}

		}

		logger.debug("KohlsPoCPublishVoidInvoice.setDateBasedonStoreTimezone--End");

	}



	/**

	 * @param env

	 * @param modifyProgId
	 * @param sOrderNo

	 * @param sSellerOrgCode

	 * @param nlElements

	 * @return

	 * @throws Exception

	 * @throws ParserConfigurationException

	 * @throws SAXException

	 * @throws IOException

	 */

	private NodeList getTransactionAuditForVoid(YFSEnvironment env, String sOrderNo, String sSellerOrgCode,

			NodeList nlElements, String voidTransactionNumber)

			throws Exception, ParserConfigurationException, SAXException, IOException {

		logger.debug("getTransactionAudit for Procedure id 201");

		Document inVoidTranDoc = YFCDocument.createDocument(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT).getDocument();

		Element eleVoidInput = inVoidTranDoc.getDocumentElement();

		eleVoidInput.setAttribute(KohlsPOCConstant.ATTR_ORDER_NUMBER, sOrderNo);

		eleVoidInput.setAttribute(KohlsPOCConstant.ATTR_PROCEDURE_ID, "201");

		eleVoidInput.setAttribute(KohlsPOCConstant.A_ORG_CODE, sSellerOrgCode);

		Document voidAuditListDocOutput = invokeAPI(env,

				XMLUtil.getDocument(KohlsPOCConstant.GET_TRANSACTION_AUDIT_TEMPLATE),

				KohlsPOCConstant.API_GET_TRANSACTION_AUDIT_LIST_FOR_POS, inVoidTranDoc);

		nlElements = voidAuditListDocOutput.getElementsByTagName(KohlsPOCConstant.ATTR_TRANSACTION_AUDIT);

		if (nlElements.getLength() > 0) {

			Element voidTranAudit = (Element) nlElements.item(0);

			voidTranAudit.setAttribute("OriginalTransactionNumber",

					voidTranAudit.getAttribute(KohlsPOCConstant.ATTR_TRANS_NUM));

			logger.debug("The Void transaction number is  :" + voidTransactionNumber);

			voidTranAudit.setAttribute(KohlsPOCConstant.ATTR_TRANS_NUM, voidTransactionNumber);



		}

		return nlElements;

	}



	/**

	 * This method calls the getOrderInvoiceList api to get the Modifyts timestamp

	 * on the invoice and returns the OrderInvoice element.

	 * 

	 * @param env

	 * @param inDoc

	 * @return Element

	 * @throws SAXException

	 * @throws IOException

	 * @throws Exception

	 */

	private Element getOrderInvoice(YFSEnvironment env, Document inDoc) throws SAXException, IOException, Exception {

		Element eleOrder = inDoc.getDocumentElement();



		String sOrderHeaderKey = eleOrder.getAttribute("OrderHeaderKey");

		Document docGetOrderInvoiceListInput = XMLUtil.createDocument("OrderInvoice");

		Element eleGetOrderInvoiceListInput = docGetOrderInvoiceListInput.getDocumentElement();

		eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);

		Document docGetOrderInvoiceListOutput = invokeAPI(env,

				XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_TEMPLATE),

				KohlsPOCConstant.API_GET_ORDER_INVOICE_LIST, docGetOrderInvoiceListInput);

		Element eleGetOrderInvoiceListOutput = docGetOrderInvoiceListOutput.getDocumentElement();

		return XMLUtil.getChildElement(eleGetOrderInvoiceListOutput, "OrderInvoice");

	}

	
	/**
	 * This method is added to get the OrderInvoiceList in Post Void scenarios
        during order sync to Corp from ISS , when the OrderHeaderKey is not synced to invoice table.
	 * @param env
	 * @param inDoc
	 * @return Element
	 * @throws SAXException
	 * @throws IOException
	 * @throws Exception
	 */
			private Element getOrderInvoiceForOrder(YFSEnvironment env, Document inDoc) 
					throws SAXException, IOException, Exception
					 {
				logger.beginTimer("Begin KohlsPoCPublishVoidInvoice. getOrderInvoiceForOrder");
				Element eleOrderInvoiceElement = null;
				Element eleOrder = inDoc.getDocumentElement();
				String strOrderNo = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
				if(!YFCCommon.isVoid(strOrderNo)) {
					Document docGetOrderInvoiceListOutput = null;
					Element eleGetOrderInvoiceListOutput = null;
					Document docGetOrderInvoiceListInput = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_INVOICE);
					Element eleGetOrderInvoiceListInput = docGetOrderInvoiceListInput.getDocumentElement();
					eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, strOrderNo);
					eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleOrder.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
					eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
					logger.debug("eleGetOrderInvoiceListInput = " + XMLUtil.getXMLString(docGetOrderInvoiceListInput) );
					 docGetOrderInvoiceListOutput = invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_TEMPLATE),
				            KohlsPOCConstant.API_GET_ORDER_INVOICE_LIST, docGetOrderInvoiceListInput);
					 eleGetOrderInvoiceListOutput = docGetOrderInvoiceListOutput.getDocumentElement();
					eleOrderInvoiceElement = XMLUtil.getChildElement(eleGetOrderInvoiceListOutput, KohlsPOCConstant.E_ORDER_INVOICE);
					if (!YFCCommon.isVoid(eleOrderInvoiceElement)){
						eleOrderInvoiceElement.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
						logger.debug("eleGetOrderInvoiceListOutput = " + XMLUtil.getXMLString(docGetOrderInvoiceListOutput) );
					}
				}//End if(!YFCCommon.isVoid(strOrderNo)) 
				
				logger.endTimer("End KohlsPoCPublishVoidInvoice. getOrderInvoiceForOrder");
				return eleOrderInvoiceElement;
			}

	/**

	 * Create By TKMACJT *

	 * 

	 * @param adminAudit

	 * @param eleTranAudit

	 * @param sOrderNo

	 *            *

	 * @return

	 * 

	 */



	void translateToTransactionAudit(Element adminAudit, Element eleTranAudit, String sOrderNo) {



		XMLUtil.setAttribute(eleTranAudit, "BusinessDay", XMLUtil.getAttribute(adminAudit, "BusinessDay"));

		XMLUtil.setAttribute(eleTranAudit, "DateTime", XMLUtil.getAttribute(adminAudit, "DateTime"));

		XMLUtil.setAttribute(eleTranAudit, "ManagerID", XMLUtil.getAttribute(adminAudit, "ManagerID"));

		XMLUtil.setAttribute(eleTranAudit, "OperatorID", XMLUtil.getAttribute(adminAudit, "OperatorID"));

		XMLUtil.setAttribute(eleTranAudit, "OrderNumber", sOrderNo);

		XMLUtil.setAttribute(eleTranAudit, "OrderTotal", XMLUtil.getAttribute(adminAudit, "Amount"));

		XMLUtil.setAttribute(eleTranAudit, "OrganizationCode", XMLUtil.getAttribute(adminAudit, "OrganizationCode"));

		XMLUtil.setAttribute(eleTranAudit, "POSSequenceNumber", XMLUtil.getAttribute(adminAudit, "POSSequenceNumber"));

		XMLUtil.setAttribute(eleTranAudit, "ProcedureID", "204");

		XMLUtil.setAttribute(eleTranAudit, "TerminalID", XMLUtil.getAttribute(adminAudit, "TerminalID"));

		XMLUtil.setAttribute(eleTranAudit, "TransAuditKey", XMLUtil.getAttribute(adminAudit, "AdminAuditKey"));

		XMLUtil.setAttribute(eleTranAudit, "TransactionNumber", XMLUtil.getAttribute(adminAudit, "TransactionNumber"));

		XMLUtil.setAttribute(eleTranAudit, "isHistory", XMLUtil.getAttribute(adminAudit, "isHistory"));

		XMLUtil.setAttribute(eleTranAudit, "OriginalTransactionNumber", sOrderNo);



	}



	/**

	 * Create By TKMACJT *

	 * 

	 * @param env

	 * @param sOrderNo

	 * @param sSellerOrgCode

	 * @return

	 * @throws ParserConfigurationException

	 * @throws SAXException

	 * @throws IOException

	 * @throws Exception

	 */

	private NodeList getAdminAuditForKCCPayment(YFSEnvironment env, String transNo, String sSellerOrgCode,

			String procedureID) throws ParserConfigurationException, SAXException, IOException, Exception {

		Document adminAuditInDoc = YFCDocument.createDocument("AdminAudit").getDocument();

		Element eleInput = adminAuditInDoc.getDocumentElement();

		eleInput.setAttribute("TransactionNumber", transNo);

		eleInput.setAttribute("ProcedureID", procedureID);

		eleInput.setAttribute("OrganizationCode", sSellerOrgCode);

		Document docTemplate = XMLUtil.getDocument(KohlsXMLLiterals.GET_ADMIN_AUDIT_FOR_KCC_PAYMENT_POST_VOID);

		Document orderListDocOutput = KOHLSBaseApi.invokeAPI(env, docTemplate,

				KohlsPOCConstant.STR_GET_ADMIN_AUDIT_LIST_FOR_POS, adminAuditInDoc);

		return orderListDocOutput.getElementsByTagName("AdminAudit");

		// return orderListDocOutput;

	}

   /*****
    * @param env
    * @return
    */
   private String getPreviousBusinessday( YFSEnvironment env )
   {
      String strPrevDate = "";
      try
      {
         int count = 1;
         strPrevDate = getYesterdayDateString( count );
         Document outDoc = KohlsCommonUtil.getCommonCodeList( env, "HOLIDAY_LIST", "DEFAULT" );
         NodeList holidayList = outDoc.getElementsByTagName( KohlsPOCConstant.E_COMMON_CODE );
         // verify if entry exists in common Code table
         // Verify if previous date is holiday
         if ( outDoc.getDocumentElement().hasChildNodes() )
         {
            for ( int i = 0; i < holidayList.getLength(); i++ )
            {
               Element eleCommonCode = (Element) holidayList.item( i );
               String strHolidayDate = eleCommonCode.getAttribute( KohlsPOCConstant.A_CODE_VALUE );
               if ( strHolidayDate.equalsIgnoreCase( strPrevDate ) )
               {
                  strPrevDate = getYesterdayDateString( count + 1 );
                  i = 0;
               }
            }
         }
      }
      catch ( Exception e )
      {
         logger.error( "getYesterday  :" + e );
      }
      return strPrevDate;
   }

   /****
    * @param prevDate
    * @return
    */
   private Date yesterday( int prevDate )
   {
      final Calendar cal = Calendar.getInstance();
      cal.add( Calendar.DATE, -prevDate );
      return cal.getTime();
   }

   /****
    * @param prevDate
    * @return
    */
   private String getYesterdayDateString( int prevDate )
   {
      DateFormat dateFormat = new SimpleDateFormat( "yyyy-MM-dd" );
      return dateFormat.format( yesterday( prevDate ) );
   }


}
