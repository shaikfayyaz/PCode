package com.kohls.poc.api;

import java.io.IOException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
// import com.kohls.poc.returns.api.KohlsPoCValidateItemForReturn;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.nrsc.kohls.receipt.ReceiptUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException; 

public class KohlsOmniOMSrCreateReturnForOMSe extends KOHLSBaseApi implements YIFCustomApi {

  public static final String A_ZERO = "0";
  public static final String A_OIC_ITEM_ID = "itemID";
  public static final String A_OIC_UOM = "uom";
  public static final String A_OIC_RESERVATION_ID = "reservationID";
  public static final String A_RESERVATION_ID = "ReservationID";
  public static final String A_UNIT_OF_MEASURE = "UnitOfMeasure";
  public static final String A_PICK = "PICK";
  public static final String A_ORDER_LINE_TRAN_QUANTITY = "OrderLineTranQuantity";
  public static final String A_TRANSACTIONAL_UOM = "TransactionalUOM";
  public static final String E_ORDER_LINE_RESERVATIONS = "OrderLineReservations";
  public static final String E_ORDER_LINE_RESERVATION = "OrderLineReservation";
  public static final String A_EXTN_IS_OMNI = "ExtnIsOmni";
  public static final String SUCCESS = "Success";
  public static final String A_NODE = "Node";
  public static final String A_ACTUAL_DATE = "ActualDate";
  public static final String A_TOTAL_RESVD_QTY = "TotalReservedQty";
  public static final String A_AVAILABLE_QTY = "AvailableQty";
  public static final String E_COMMON_CODE_LIST = "CommonCodeList";

  public static YFCLogCategory logger =
      YFCLogCategory.instance(KohlsOmniOMSrCreateReturnForOMSe.class.getName());;

  String sOrigStoreNo = "";
  String sOrigTerminalID = "";
  String sOrigTranNo = "";
  String sOrigOrderDate = "";
  String sOrigReceiptID = "";

  String sCurrentStore = "";
  String sCurrentTerminalID = "";
  String sCurrentTillID = "";
  String sCurrentBusinessDay = "";
  String sCurrentDrawerID = "";
  String sOperatorID = "";
  String sRSOTRAmount="";

  String sSalesOrderHeaderKey = "";
  String sReturnOrderHeaderKey = "";
  String sExtnEReceiptEmailID = "";

  boolean bKCUnearnedOnOrder = false;
  boolean bIsAPISuccess = true;
  
  boolean isLCSResponseError = false;
  boolean isCreateReturn = false;


  public Document createReturnOrdersForOmniOMSe(YFSEnvironment env, Document inDoc)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.createReturnOrdersForOmniOMSe");

    if (logger.isDebugEnabled()) {
      logger.debug("Inside createReturnOrdersForOmniOMSe:: " + SCXmlUtil.getString(inDoc));
    }

    Document inDocCallGetRSResponse = null, outDocCallGetRSResponse = null,
       inDocCallCreateReturnOrder = null, outDocGetKohlsCashApi = null,
        inDocChangeOrderOnReturnOrder = null, outDocCallGetPSARefundTender = null;
    Document inDocGetKohlsCashApi = null;
    Document inDocCallGetPSARefundTendersForOrder = null;
    Document inDocCallCOnfirmDraftOrder = null;
    Document outDocCreateReturnOrder = null;

    String sErrorMessage = "";
    String sErrorCode = "";

    try {

      env.setTxnObject("SkipManagePSIOrderCall", true);

      sCurrentStore = inDoc.getDocumentElement().getAttribute("ReturnStore");

      sCurrentTerminalID = getRuleValue(env, "OMNI_RTN_TERM_ID", "95");

      sOperatorID = getRuleValue(env, "OMNI_RTN_ASSOC_ID", "0000000");

      Element eleInOrderRoot = inDoc.getDocumentElement();

      if (!YFCCommon.isVoid(eleInOrderRoot)) {
        sExtnEReceiptEmailID = eleInOrderRoot.getAttribute("CustomerEMailID");
      }

      sSalesOrderHeaderKey = inDoc.getDocumentElement().getAttribute("OrderHeaderKey");

      loadCurrentTillDetails(env);

      inDocCallGetRSResponse = prepareInputForGetOrderDetailsWithRSResponse(inDoc);
      //OMNI2 set txn object for PickInvoice AutoReturn
      env.setTxnObject("AUTO_RETURN_DOC", inDoc);
      
      env.setTxnObject("IS_AUTO_RETURN", "Y");
      
      outDocCallGetRSResponse = callGetOrderDetailsWithRSResponse(env, inDocCallGetRSResponse);

      Element eleRSOrderRoot = outDocCallGetRSResponse.getDocumentElement();
      Element eleRSOrderExtn = SCXmlUtil.getChildElement(eleRSOrderRoot, "Extn");
      String sExtnOTRResponse = eleRSOrderExtn.getAttribute("ExtnOTRResponse");
      String sExtnOTRResponseType = eleRSOrderExtn.getAttribute("ExtnOTRResponseType");
      if (!"000000".equals(sExtnOTRResponse)) {
        String sErrorDesc = ("Invalid OTR response code (" + sExtnOTRResponse
            + ") (" + sExtnOTRResponseType +"). Return order cannot be created");
        throw new YFSException(sErrorDesc, "ERROR_0001", sErrorDesc);
      }
      inDocCallCreateReturnOrder =
          prepareInputForCreateReturnDraftOrder(env,outDocCallGetRSResponse, inDoc);
      Document outDocCallCreateReturnOrder = callCreateReturnOrder(env, inDocCallCreateReturnOrder);

      sReturnOrderHeaderKey =
          outDocCallCreateReturnOrder.getDocumentElement().getAttribute("OrderHeaderKey");

      inDocChangeOrderOnReturnOrder = prepareInputForChangeReturnOrderToAddLines(env, inDoc,
          outDocCallGetRSResponse, outDocCallCreateReturnOrder);

      callChangeOrderOnReturnOrder(env, inDocChangeOrderOnReturnOrder);

      String sReturnReason = inDoc.getDocumentElement().getAttribute("ReturnReason");

      inDocGetKohlsCashApi = prepareInputForGetKohlsCashApi(outDocCallCreateReturnOrder);

      Document docGetRefundBeforeKCUnearn = getRefundBeforeKCUnearn(env, inDocGetKohlsCashApi);
       

      if (!YFCCommon.isVoid(sReturnReason) && "ExpiredPickup".equalsIgnoreCase(sReturnReason)) {
        outDocGetKohlsCashApi = callGetKohlsCashApi(env, docGetRefundBeforeKCUnearn, outDocCallGetRSResponse, sCurrentStore);
        bKCUnearnedOnOrder = verifyKohlsCashUnEarn(outDocGetKohlsCashApi);
      } else {
        outDocGetKohlsCashApi = docGetRefundBeforeKCUnearn;
      }
      
      if(!isLCSResponseError) {
    	  inDocCallGetPSARefundTendersForOrder =
    	          prepareInputForGetPSARefundTendersForOrder(outDocGetKohlsCashApi);

    	      outDocCallGetPSARefundTender =
    	          callGetPSARefundTendersForOrder(env, inDocCallGetPSARefundTendersForOrder);

    	      Document outDocMerge = prepareInputForGerConfirmedPSARefundTender(
    	          outDocCallGetPSARefundTender, inDocCallGetPSARefundTendersForOrder);
    	      
    	      //OMNI2 - Add amount to next Payment Method if KMC payment's SvcNo is blank - BEGIN
    	      outDocMerge = transferKMCAmountIfBlankSvcNo(outDocMerge);
    	      //OMNI2 - Add amount to next Payment Method if KMC payment's SvcNo is blank - END

    	      Document docConfirmRefundTender = callGetConfirmedPSARefundTender(env, outDocMerge);

    	      Element eleRKCPromotion = null;
    	      try {
    	        eleRKCPromotion = (Element) SCXmlUtil
    	            .getXpathNodes(docConfirmRefundTender.getDocumentElement(),
    	                "/Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_REISSUE' and @PromotionApplied='Y']")
    	            .item(0);
    	      } catch (Exception ex) {
    	        ex.printStackTrace();
    	        throw new YFSException("Error occured while evaluating RKC Promotion");
    	      }

    	      if (!YFCCommon.isVoid(eleRKCPromotion) && !YFCCommon.isVoid(sExtnEReceiptEmailID)) {
    	        Document docRKCInput = SCXmlUtil.createDocument("Order");
    	        docRKCInput.getDocumentElement().setAttribute("OrderHeaderKey", sReturnOrderHeaderKey);
    	        Element eleRKCOrderExtn = SCXmlUtil.createChild(docRKCInput.getDocumentElement(), "Extn");
    	        eleRKCOrderExtn.setAttribute("ExtnEReceiptEmailID", sExtnEReceiptEmailID);
    	        Document outDocActivateRKC =
    	            invokeService(env, "KohlsPoCActivateRKCForReturns", docRKCInput);

    	        Element eleDKCOutRoot = outDocActivateRKC.getDocumentElement();
    	        String sCouponNo = eleDKCOutRoot.getAttribute(KohlsPOCConstant.ATTR_COUPON_NUMBER);
    	        if (YFCCommon.isVoid(sCouponNo)) {
    	          String sErrorDesc = ("RKC Not Activated . Return order cannot be created");
    	          throw new YFSException(sErrorDesc, "ERROR_0002", sErrorDesc);
    	        }
    	      }
      }
      

      inDocCallCOnfirmDraftOrder = prepareInputForConfirmDraftOrder();

      callConfirmDraftOrder(env, inDocCallCOnfirmDraftOrder);

    } catch (YFSException ex) {
      ex.printStackTrace();
      sErrorMessage = ex.getErrorDescription();
      sErrorCode = ex.getErrorCode();
      bIsAPISuccess = false;
      throw ex;
    } catch (Exception ex) {
      ex.printStackTrace();
      sErrorMessage = ex.getMessage();
      bIsAPISuccess = false;
    } finally {
      logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.createReturnOrdersForOmniOMSe");
      outDocCreateReturnOrder = SCXmlUtil.createDocument("Order");
      if (bIsAPISuccess) {
        outDocCreateReturnOrder.getDocumentElement().setAttribute("ReturnOrderHeaderKey",
            sReturnOrderHeaderKey);
        outDocCreateReturnOrder.getDocumentElement().setAttribute("APISuccess", "Y");
      } else {
        // Start of getOrderList api call

        Document outDocGetOrderList = null;
        Document docGetOrderListInput = null;
        // preparing input for getOrderList API
        if (!YFCCommon.isVoid(sReturnOrderHeaderKey)) {

          docGetOrderListInput = SCXmlUtil.createDocument((KohlsPOCConstant.ELEM_ORDER));
          Element eleGetOrderList = docGetOrderListInput.getDocumentElement();
          eleGetOrderList.setAttribute("OrderHeaderKey", sReturnOrderHeaderKey);
          eleGetOrderList.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
          String sGetOrderListTemplate = "<OrderList><Order OrderHeaderKey='' DraftOrderFlag=''/></OrderList>"; 
          Document docGetOrderListOutput = KOHLSBaseApi.invokeAPI(env,
              XMLUtil.getDocument(sGetOrderListTemplate),
              KohlsPOCConstant.API_GET_ORDER_LIST, docGetOrderListInput);
          if (!YFCCommon.isVoid(docGetOrderListOutput)) {
            if (logger.isDebugEnabled()) {
              logger.debug("Output of getOrderList during omni auto returns exception flow is::"
                  + SCXmlUtil.getString(outDocGetOrderList));
            }
            Element eleOrder = (Element) ((NodeList) XPathUtil
                .getNodeList(docGetOrderListOutput.getDocumentElement(), "/OrderList/Order"))
                    .item(0);
            String sDOF = eleOrder.getAttribute("DraftOrderFlag");

            if (!YFCCommon.isVoid(sDOF) && sDOF.equalsIgnoreCase("Y")) {
              callVoidTxnForDraftReturnOrder(env);
            }
          }
        }

        outDocCreateReturnOrder.getDocumentElement().setAttribute("ReturnOrderHeaderKey",
            KohlsPOCConstant.A_BLANK);
        outDocCreateReturnOrder.getDocumentElement().setAttribute("APISuccess", "N");
        outDocCreateReturnOrder.getDocumentElement().setAttribute("ErrorMessage", sErrorMessage);
        outDocCreateReturnOrder.getDocumentElement().setAttribute("ErrorCode", sErrorCode);
        return outDocCreateReturnOrder;
      }
    }

    // Return OHK and response
    return outDocCreateReturnOrder;
  }

private Document transferKMCAmountIfBlankSvcNo(Document outDocMerge) throws Exception{
	Element eleKMCPmntMethod = (Element) XPathUtil.getNode(outDocMerge, "/Order/PaymentMethods/PaymentMethod[@PaymentType='KMC']");
    boolean transferKMCAmt = false;
    double kmcAmount=0;
    if(!YFCCommon.isVoid(eleKMCPmntMethod)){
  	  Element eleKMCPmntMethodExtn = (Element) eleKMCPmntMethod.getElementsByTagName(KohlsXMLLiterals.E_EXTN).item(0);
  	  String amount = eleKMCPmntMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT);
  	  if(YFCCommon.isVoid(eleKMCPmntMethodExtn))
  	  {
  		  if(!YFCCommon.isVoid(amount)) {
  			  kmcAmount= Double.parseDouble(amount);
  			  transferKMCAmt = true;
  		  }
  	  }
  	  else
  	  {
  	  Document extnPmntDtlsListDoc = XMLUtil.getDocument(eleKMCPmntMethodExtn.getAttribute("ExtnPaymentDetails"));
		  Element extnPmntDtls = (Element) extnPmntDtlsListDoc.getDocumentElement().getElementsByTagName("KohlsPayment").item(0);
		  String svcNoFromExtn = extnPmntDtls.getAttribute(KohlsXMLLiterals.A_SVC_NO);
		   if(YFCCommon.isVoid(svcNoFromExtn))
		   {
			   if(!YFCCommon.isVoid(amount)) {
				   kmcAmount= Double.parseDouble(amount);
				   transferKMCAmt = true;
			   }
		   }
  	  } 
    }
    if(transferKMCAmt) {
  	  NodeList nlKMCPmntMethod = (NodeList) XPathUtil.getNodeList(outDocMerge, "/Order/PaymentMethods/PaymentMethod");
	      int pmntMethLength = nlKMCPmntMethod.getLength();
	      if(pmntMethLength > 1) {
	    	  for(int paymtdCnt = 0; paymtdCnt < pmntMethLength; paymtdCnt++) {
	    		  Element pmtMethod =  (Element) nlKMCPmntMethod.item(paymtdCnt);
	    		  String paymentType = pmtMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
	    		  if(!KohlsXMLLiterals.ATTR_KMC.equals(paymentType)) {
	    			  String strCurrPmntAmount = pmtMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT);
	    			  double currPmntAmount = Double.parseDouble(strCurrPmntAmount);
	    			  double sumPmtAmount = currPmntAmount + kmcAmount;
	    			  pmtMethod.setAttribute(KohlsXMLLiterals.A_AMOUNT, String.valueOf(sumPmtAmount));
	    			  break;
	    		  }
	    	  }
	      }
    }
	return outDocMerge;
}

/**
   * cancel the draft return order
   ** 
   * @return
   ** @throws Exception
   ****/
  public void callVoidTxnForDraftReturnOrder(YFSEnvironment env) throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callVoidTxnForDraftReturnOrder");
    // Document outDocCancelDraftReturnOrder = null;

    String sErrorDesc = ("RKC Not Activated . Return order cannot be created");
    // void the return draftorder before sending failure response to omse
    logger.debug(
        "#####  void during of omni auto return transaction as RKC is offline.Calling voidTransactionForPOS API.");
    
    try {
      Document voidTxnInputDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
      Element eleOrd = voidTxnInputDoc.getDocumentElement();
      eleOrd.setAttribute("Action", KohlsPOCConstant.ACTION_CANCEL);
      eleOrd.setAttribute("ProcedureID", KohlsPOCConstant.ATTR_VOID_TRANSACTION);
      eleOrd.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sReturnOrderHeaderKey);
      eleOrd.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, sCurrentStore);;
      eleOrd.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, sCurrentTerminalID);
      eleOrd.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
      eleOrd.setAttribute("PostVoidConfirmedFlag", KohlsPOCConstant.V_N);

      if (logger.isDebugEnabled()) {
        logger.debug(
            "InputDocument For voidTransactionForPOS to cancel draft order of auto omni return:"
                + SCXmlUtil.getString(voidTxnInputDoc));
      }

      invokeAPI(env, "voidTransactionForPOS", voidTxnInputDoc);
    } catch (Exception e) {
      logger.debug("Error while doing voidTransactionForPOS of an omni draft order ");
      e.printStackTrace();
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callVoidTxnForDraftReturnOrder");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param sRuleID
   * @param sDefaultValue
   * @return
   * @throws Exception
   */
  private String getRuleValue(YFSEnvironment env, String sRuleID, String sDefaultValue)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.getRuleValue");
    String sRuleValue = "";
    Document docGetRulesListIn = SCXmlUtil.createDocument("Rules");
    Element eleRuleInput = docGetRulesListIn.getDocumentElement();
    eleRuleInput.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, sCurrentStore);
    eleRuleInput.setAttribute(KohlsPOCConstant.A_RULE_ID, sRuleID);
    Document docGetRuleListOut =
        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, docGetRulesListIn);
    if (docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).getLength() > 0) {
      Element eleRule =
          (Element) docGetRuleListOut.getElementsByTagName(KohlsPOCConstant.E_RULE).item(0);
      sRuleValue = eleRule.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
      if (YFCCommon.isVoid(sRuleValue)) {
        sRuleValue = sDefaultValue;
      }
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.getRuleValue");
    return sRuleValue;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param inDocGetKohlsCashApi
   * @return
   */
  private Document getRefundBeforeKCUnearn(YFSEnvironment env, Document inDocGetKohlsCashApi)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.getRefundBeforeKCUnearn");
    logger.debug("Inside getRefundBeforeKCUnearn:: " + SCXmlUtil.getString(inDocGetKohlsCashApi));

    Document outDocCreateReturnOrder =
        invokeService(env, "KohlsPoCCallSysRepublic", inDocGetKohlsCashApi);

    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.getRefundBeforeKCUnearn");
    return outDocCreateReturnOrder;
  }

  /**
   * Create By mrjoshi *
   */
  private void loadCurrentTillDetails(YFSEnvironment env) throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.loadCurrentTillDetails");

    Document docGetCurrentTillStatusListForPOS_Input = SCXmlUtil.createDocument("TillStatus");
    docGetCurrentTillStatusListForPOS_Input.getDocumentElement().setAttribute("OrganizationCode",
        sCurrentStore);
    docGetCurrentTillStatusListForPOS_Input.getDocumentElement().setAttribute("TerminalID",
        sCurrentTerminalID);

    Document docGetCurrentTillStatusListForPOS_Output =
        invokeAPI(env, "getCurrentTillStatusForPOS", docGetCurrentTillStatusListForPOS_Input);

    // Added to open store and register
    

    String strCurrentStatus = "Close";
    if (!YFCCommon.isVoid(docGetCurrentTillStatusListForPOS_Output)) {
	      Element eleTillStatus = docGetCurrentTillStatusListForPOS_Output.getDocumentElement();
	      logger.debug("TillStatus Element is:: " + SCXmlUtil.getString(eleTillStatus));
	      if (!YFCCommon.isVoid(eleTillStatus)) {
	        strCurrentStatus = eleTillStatus.getAttribute("CurrentStatus");
	        logger.debug("CurrentTill Status is ::" + strCurrentStatus);
	      }
	      
	    //Added for unOperated Till 
	    if (!("Open".equalsIgnoreCase(strCurrentStatus)) || strCurrentStatus.length()==0) {
	    	verifyAndOpenStoreNRegister(env, docGetCurrentTillStatusListForPOS_Output);
	    }
	    else {
	    	Element eleGetCurrentTillStatusListForPOSRoot =
		          docGetCurrentTillStatusListForPOS_Output.getDocumentElement();
		      sCurrentBusinessDay = eleGetCurrentTillStatusListForPOSRoot.getAttribute("BusinessDay");
		      sCurrentTillID = eleGetCurrentTillStatusListForPOSRoot.getAttribute("TillID");
		      sCurrentDrawerID = eleGetCurrentTillStatusListForPOSRoot.getAttribute("DrawerID");
		    
	    }
    } else {
	//Added for unoperated till
           verifyAndOpenStoreNRegister(env, docGetCurrentTillStatusListForPOS_Output);
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.loadCurrentTillDetails");
  
  }

  /**
   * This method verifies if the store and Register are open or not, if not open them and proceed
   * further.
   * 
   * @param docGetCurrentTillStatusListForPOS_Output
   * @throws Exception
   */
  private void verifyAndOpenStoreNRegister(YFSEnvironment env,
      Document docGetCurrentTillStatusListForPOS_Output) throws Exception {

    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.verifyAndOpenStoreNRegister");
    if (logger.isDebugEnabled() && !YFCCommon.isVoid(docGetCurrentTillStatusListForPOS_Output)) {
      logger.debug("Inside verifyAndOpenStoreNRegister:: "
          + SCXmlUtil.getString(docGetCurrentTillStatusListForPOS_Output));
    }
    
   
      // Verify for store Open
      verifyNOpenStore(env, docGetCurrentTillStatusListForPOS_Output);

      // Open Till, call OpenTillForAccountingForPOS
      Document inDocOpenTillForAccountingForPOS =
          SCXmlUtil.createDocument("OpenTillForAccountingForPOS");
      Element eleStoreOpenForAccountingForPOS =
          inDocOpenTillForAccountingForPOS.getDocumentElement();
      eleStoreOpenForAccountingForPOS.setAttribute("TerminalID", sCurrentTerminalID);
      eleStoreOpenForAccountingForPOS.setAttribute("OperatorID", sOperatorID);
      eleStoreOpenForAccountingForPOS.setAttribute("OrganizationCode", sCurrentStore);
      eleStoreOpenForAccountingForPOS.setAttribute("TerminalType", "kohls");
      eleStoreOpenForAccountingForPOS.setAttribute("DrawerID", "1");
      Document outDocOpenTillForAccountingForPOS =
          invokeAPI(env, "openTillForAccountingForPOS", inDocOpenTillForAccountingForPOS);
      if (!YFCCommon.isVoid(outDocOpenTillForAccountingForPOS)) {
        //Element eleTillStatusOut = outDocOpenTillForAccountingForPOS.getDocumentElement();
        Element eleTillStatusOut = (Element)outDocOpenTillForAccountingForPOS.getElementsByTagName("TillStatus").item(0);
        if (!YFCCommon.isVoid(eleTillStatusOut)) {
          sCurrentBusinessDay = eleTillStatusOut.getAttribute("BusinessDay");
          sCurrentTillID = eleTillStatusOut.getAttribute("TillID");
          sCurrentDrawerID = eleTillStatusOut.getAttribute("DrawerID");
        }
      }
    
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.verifyAndOpenStoreNRegister");
  
  }


  /**
   * verify and open store
   * 
   * @param docGetCurrentTillStatusListForPOS_Output
   * @return
   * @throws Exception
   */
  private void verifyNOpenStore(YFSEnvironment env,
      Document docGetCurrentTillStatusListForPOS_Output) throws Exception {
    // <AccountingPeriod OrganizationCode="Required"/>
    // <AccountingPeriod AccountingPeriodKey="" BusinessDay="" CloseDateTime="" CurrentPeriod=""
    // OpenDateTime="" OrganizationCode="" Status="Open"
    // SyncID=""/>

    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.verifyNOpenStore");
    if (logger.isDebugEnabled() && !YFCCommon.isVoid(docGetCurrentTillStatusListForPOS_Output)) {
      logger.debug("Inside verifyNOpenStore:: "
          + SCXmlUtil.getString(docGetCurrentTillStatusListForPOS_Output));
    }
    String strIsStoreOpen = "Close";
    // call getCurrentAccountingperiodforpos
    Document inDocGetCurrentAccountingperiodforpos = SCXmlUtil.createDocument("AccountingPeriod");
    Element eleGetCurrentAccountingperiodforpos =
        inDocGetCurrentAccountingperiodforpos.getDocumentElement();
    eleGetCurrentAccountingperiodforpos.setAttribute("OrganizationCode", sCurrentStore);
    Document outDocGetCurrentAccountingperiodforpos =
        invokeAPI(env, "getCurrentAccountingPeriodForPOS", inDocGetCurrentAccountingperiodforpos);

    if (!YFCCommon.isVoid(outDocGetCurrentAccountingperiodforpos)) {
      strIsStoreOpen =
          outDocGetCurrentAccountingperiodforpos.getDocumentElement().getAttribute("Status");
    }

    //Added for unOperated Store     
    if (!YFCCommon.isVoid(strIsStoreOpen) && !strIsStoreOpen.equals("Open") || strIsStoreOpen.length()==0) {
      // call StoreOpenForAccountingForPOS
      Document inDocStoreOpenForAccountingForPOS =
          SCXmlUtil.createDocument("StoreOpenForAccountingForPOS");
      Element eleStoreOpenForAccountingForPOS =
          inDocStoreOpenForAccountingForPOS.getDocumentElement();
      eleStoreOpenForAccountingForPOS.setAttribute("BusinessDay",
          KohlsDateUtil.getCurrentDateTime("yyyy-MM-dd"));
      eleStoreOpenForAccountingForPOS.setAttribute("OperatorID", sOperatorID);// TBD
      eleStoreOpenForAccountingForPOS.setAttribute("OrganizationCode", sCurrentStore);

      Document onDocStoreOpenForAccountingForPOS =
          invokeAPI(env, "storeOpenForAccountingForPOS", inDocStoreOpenForAccountingForPOS);
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.verifyNOpenStore");
  }

  /**
   * 2) Call createOrder API. This API creates the draft return order in OMS.
   * 
   * @param env
   * @param inDocCallCreateReturnOrder
   * @return
   * @throws YFSException
   * @throws RemoteException
   */
  public Document callCreateReturnOrder(YFSEnvironment env, Document inDocCallCreateReturnOrder)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callCreateReturnOrder");
    logger
        .debug("Inside callCreateReturnOrder:: " + SCXmlUtil.getString(inDocCallCreateReturnOrder));

    Document outDocCreateReturnOrder =
        invokeAPI(env, "createReturnOrderForPOS", inDocCallCreateReturnOrder);
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callCreateReturnOrder");
    return outDocCreateReturnOrder;
  }


  /**
   * 7)Call confirmDraftOrder api
   * 
   * @param env
   * @param inDocCallCOnfirmDraftOrder
   * @return
   * @throws YFSException
   * @throws RemoteException
   */
  public Document callConfirmDraftOrder(YFSEnvironment env, Document inDocCallCOnfirmDraftOrder)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callConfirmDraftOrder");
    logger
        .debug("Inside callConfirmDraftOrder:: " + SCXmlUtil.getString(inDocCallCOnfirmDraftOrder));
    Document outDoc = invokeAPI(env, "confirmDraftOrder", inDocCallCOnfirmDraftOrder);

    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callConfirmDraftOrder");
    return outDoc;
  }


  public Document prepareInputForConfirmDraftOrder() {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForConfirmDraftOrder");
    Document inDocConfirmDraftOrder = SCXmlUtil.createDocument("ConfirmDraftOrder");
    Element eleOrder = inDocConfirmDraftOrder.getDocumentElement();
    eleOrder.setAttribute("OrderHeaderKey", sReturnOrderHeaderKey);
    eleOrder.setAttribute("DocumentType", "0003");
    eleOrder.setAttribute("SelectMethod", "WAIT");
    logger
        .debug("prepareInputForConfirmDraftOrder:: " + SCXmlUtil.getString(inDocConfirmDraftOrder));
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForConfirmDraftOrder");
    return inDocConfirmDraftOrder;
  }


  /**
   * 6)call getConfirmedPSARefundTender api to record the payment and kohls cash unearned options.
   * 
   * @param env
   * @param outDocMerge
   * @return
   * @throws Exception
   */
  public Document callGetConfirmedPSARefundTender(YFSEnvironment env, Document outDocMerge)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetConfirmedPSARefundTender");
    logger.debug("Inside callGetConfirmedPSARefundTender::" + SCXmlUtil.getString(outDocMerge));

    // String templatePath = "global/template/api/getConfirmedPSARefundTender_output.xml";
    Document docConfirmRefundTender = invokeService(env, "KohlsPSARefund", outDocMerge);
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetConfirmedPSARefundTender");
    return docConfirmRefundTender;
  }


  /**
   * Merge input and output xml from step 7
   * 
   * @param inDoc
   * @param inDocPayments
   * @return
   */
  public Document prepareInputForGerConfirmedPSARefundTender(Document outDocCallGetPSARefundTender,
      Document inDocCallGetPSARefundTendersForOrder) {
    logger
        .beginTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGerConfirmedPSARefundTender");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

    Element elePSATenderRoot = inDocCallGetPSARefundTendersForOrder.getDocumentElement();
    elePSATenderRoot.setAttribute("BusinessDay", sCurrentBusinessDay);
    elePSATenderRoot.setAttribute("OperatorID", sOperatorID);
    elePSATenderRoot.setAttribute("StoreID", sCurrentStore);
    elePSATenderRoot.setAttribute("TerminalID", sCurrentTerminalID);
    elePSATenderRoot.setAttribute("TillID", sCurrentTillID);

    NodeList nlRSPaymentMethod = outDocCallGetPSARefundTender.getElementsByTagName("PaymentMethod");

    if (!YFCCommon.isVoid(SCXmlUtil.getChildElement(
        inDocCallGetPSARefundTendersForOrder.getDocumentElement(), "PaymentMethods"))) {
      inDocCallGetPSARefundTendersForOrder.getDocumentElement().removeChild(
          SCXmlUtil.getChildElement(inDocCallGetPSARefundTendersForOrder.getDocumentElement(),
              "PaymentMethods"));
    }
    Element eleRefundPaymnentMethods = SCXmlUtil
        .createChild(inDocCallGetPSARefundTendersForOrder.getDocumentElement(), "PaymentMethods");
    for (int i = 0; i < nlRSPaymentMethod.getLength(); i++) {
      Element eleRSPaymentMethod = (Element) nlRSPaymentMethod.item(i);
      Element eleRSKohlsPaymentList =
          SCXmlUtil.getChildElement(eleRSPaymentMethod, "KohlsPaymentList");

      Element eleRefundPaymentMethod =
          SCXmlUtil.createChild(eleRefundPaymnentMethods, "PaymentMethod");
      eleRefundPaymentMethod.setAttribute("Amount",
          eleRSPaymentMethod.getAttribute("RefundAmount"));
      eleRefundPaymentMethod.setAttribute("BusinessDay", sCurrentBusinessDay);
      eleRefundPaymentMethod.setAttribute("OperatorID", sOperatorID);
      eleRefundPaymentMethod.setAttribute("PaymentReference1",
          sdf.format(Calendar.getInstance().getTime()));
      eleRefundPaymentMethod.setAttribute("StoreID", sCurrentStore);
      eleRefundPaymentMethod.setAttribute("TerminalID", sCurrentTerminalID);
      eleRefundPaymentMethod.setAttribute("TillID", sCurrentTillID);
      
      //OMNI2 - Dont set PaymentType if its KMC
      String paymentType = eleRSPaymentMethod.getAttribute("PaymentType");
      
      if("CREDIT_CARD".equalsIgnoreCase(paymentType) || "DEBIT_CARD".equalsIgnoreCase(paymentType)) {
    	  logger.debug("Inside If condition of CreditCard and DebitCard Check:" + paymentType);
    	  eleRefundPaymentMethod.setAttribute("PaymentType",paymentType);
      }
      else {
    	  logger.debug("Inside Else condition:" + paymentType);
    	  eleRefundPaymentMethod.setAttribute("PaymentType",
    	          eleRSPaymentMethod.getAttribute("RefundTenderType"));
      }
      
      if("VISA".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "05");
      }
      if("MASTERCARD".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "06");
      }
      if("DISCOVER".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "07");
      }
      if("AMEX".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "08");
      }
      if("KOHLS_CHARGE_CARD".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "04");
      }
      if("CASH".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "00");
      }
      if("KMC".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "02");
      }
      if(("GIFT_CARD".equals(eleRSPaymentMethod.getAttribute("RefundTenderType"))) || ("GIFT".equals(eleRSPaymentMethod.getAttribute("RefundTenderType")))) {
    	  eleRefundPaymentMethod.setAttribute("CreditCardType", "13");
      }
      if (!YFCCommon.isVoid(eleRSPaymentMethod.getAttribute("CreditCardNo"))) {
        eleRefundPaymentMethod.setAttribute("CreditCardNo",
            eleRSPaymentMethod.getAttribute("CreditCardNo"));
      }
      if (!YFCCommon.isVoid(eleRSPaymentMethod.getAttribute("CreditCardExpDate"))) {
        eleRefundPaymentMethod.setAttribute("ExpirationDate",
            eleRSPaymentMethod.getAttribute("ExpirationDate"));
      }
      if (!YFCCommon.isVoid(eleRSPaymentMethod.getAttribute("EntryMethod"))) {
        eleRefundPaymentMethod.setAttribute("EntryMethod",
            eleRSPaymentMethod.getAttribute("EntryMethod"));
      }
      if (!YFCCommon.isVoid(eleRSKohlsPaymentList)) {
        Element eleRefundPaymentExtn =
            SCXmlUtil.getChildElement(eleRefundPaymentMethod, "Extn", true);
        eleRefundPaymentExtn.setAttribute("ExtnPaymentDetails",
            SCXmlUtil.getString(eleRSKohlsPaymentList));
      }
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGerConfirmedPSARefundTender");
    return inDocCallGetPSARefundTendersForOrder;
  }

  /**
   * 4)Call getPSARefundTendersForOrder to determine the refund tender for the order. Please note,
   * the Kohls Cash unearn decision made in step 6 needs to be passed in the input xml while
   * determining the refund tender.
   * 
   * @param env
   * @param inDocCallGetPSARefundTendersForOrder
   * @return
   * @throws Exception
   */
  public Document callGetPSARefundTendersForOrder(YFSEnvironment env,
      Document inDocCallGetPSARefundTendersForOrder) throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetPSARefundTendersForOrder");
    String templatePath = "global/template/api/getPSARefundTendersForOrder_output.xml";
    Document outDoc = invokeService(env, "KohlsPSATendering", inDocCallGetPSARefundTendersForOrder);
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetPSARefundTendersForOrder");
    return outDoc;
  }


  public Document prepareInputForGetPSARefundTendersForOrder(Document outDocGetKohlsCashApi) {
    logger
        .beginTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGetPSARefundTendersForOrder");
    Element eleOrder = outDocGetKohlsCashApi.getDocumentElement();
    Element eleExtn = SCXmlUtil.getChildElement(eleOrder, "Extn", true);
    eleExtn.setAttribute("ExtnPOCFeature", "ReceiptedReturn");
    if (YFCCommon.isVoid(SCXmlUtil.getChildElement(eleOrder, "PaymentMethods"))) {
      SCXmlUtil.createChild(eleOrder, "PaymentMethods");
    }
    if (bKCUnearnedOnOrder) {
      Element eleKCUnearnedPromotion = SCXmlUtil.getXpathElement(eleOrder,
          "/Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_UNEARNED']");
      Element elePromotionExtn = SCXmlUtil.getChildElement(eleKCUnearnedPromotion, "Extn");
      Element eleMaximizeRefund =
          SCXmlUtil.getChildElement(eleKCUnearnedPromotion, "MaximizeRefund");
      Element eleMaximizeKohlsCash =
          SCXmlUtil.getChildElement(eleKCUnearnedPromotion, "MaximizeKohlsCash");
      if (!YFCCommon.isVoid(eleMaximizeRefund)) {
        eleOrder.setAttribute("RefundAmount", eleMaximizeRefund.getAttribute("RefundAmount"));
        elePromotionExtn.setAttribute("ExtnKCOptionSelected", "MaximizeRefund");
      } else {
        eleOrder.setAttribute("RefundAmount", eleMaximizeKohlsCash.getAttribute("RefundAmount"));
        elePromotionExtn.setAttribute("ExtnKCOptionSelected", "MaximizeKohlsCash");
      }
    }
    logger.debug("prepareInputForGetPSARefundTendersForOrder:: "
        + SCXmlUtil.getString(outDocGetKohlsCashApi));
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGetPSARefundTendersForOrder");
    return outDocGetKohlsCashApi;
  }

  /**
   * If KohlsCash is unearned in the output xml, then a decision needs to be made to select the
   * appropriate option (MaximizeKohlsCash or MaximizeRefund)
   * 
   * @param outDocGetKohlsCashApi
   * @return
   */
  public boolean verifyKohlsCashUnEarn(Document outDocGetKohlsCashApi) {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.verifyKohlsCashUnEarn");
    boolean bKCUnearnedOnOrder = false;
    Element elePromotion = SCXmlUtil.getXpathElement(outDocGetKohlsCashApi.getDocumentElement(),
        "/Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_UNEARNED' and @PromotionApplied='Y']");
    if (!YFCCommon.isVoid(elePromotion)) {
      bKCUnearnedOnOrder = true;
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.verifyKohlsCashUnEarn");
    return bKCUnearnedOnOrder;
  }

  /**
   * 5) Call getKohlsCashApi API. This api determines the Kohls cash to be unearned.
   * 
   * @param inDocGetKohlsCashApi
 * @param sCurrentStore2 
 * @param outDocCallGetRSResponse 
   * @return
   * @throws Exception
   */
  public Document callGetKohlsCashApi(YFSEnvironment env, Document inDocGetKohlsCashApi, Document outDocCallGetRSResponse, String sCurrentStore2)
      throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetKohlsCashApi");
    logger.debug("Inside callGetKohlsCashApi::" + SCXmlUtil.getString(inDocGetKohlsCashApi));
    Document outDoc = null;
    //OMNI2 Check if Loyalty is present, then call KohlsPoCCallToLCSWrapper service, else call existing KohlsCashDeactivation service
    Document docLCSInput = chkLoyaltyAndPrepareInputToLCSWrapper(outDocCallGetRSResponse, sReturnOrderHeaderKey, sCurrentStore2);
    
    String loyaltyStore = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, sCurrentStore2, KohlsPOCConstant.EMPTY); 
    logger.info("Performing Kohls Cash Unearn for StoreType: "+loyaltyStore);
    if(!loyaltyStore.contains("V2")) {
      NodeList eleLCSOrder = docLCSInput.getDocumentElement().getElementsByTagName(KohlsXMLLiterals.E_LOYALTY);
      if(eleLCSOrder.getLength() > 0) {
        try {
            outDoc = KohlsCommonUtil.invokeService(env, "KohlsPoCCallToLCSWrapper", docLCSInput);
            String strOutDoc = outDoc.getDocumentElement().getNodeName();
            if("NONE".equals(strOutDoc)) {
                logger.error("KohlsPoCCallToLCSWrapper service inside callGetKohlsCashApi method, returns NONE doc, so returning the docLCSInput");
               return docLCSInput;
            }
        }catch (Exception excp) {
              logger.error("KohlsPoCCallToLCSWrapper service inside callGetKohlsCashApi method, either caught exception, so returning the docLCSInput");
            return docLCSInput;
        }
        
      }else {
        outDoc =
            KohlsCommonUtil.invokeService(env, "KohlsCashDeactivation", inDocGetKohlsCashApi);
      }
    } else {
      outDoc = KohlsCommonUtil.invokeService(env, "KohlsCashRefundDeductions", docLCSInput);
      outDoc.getDocumentElement().setAttribute("OrderHeaderKey", sReturnOrderHeaderKey);
    }
    
    
    // Document outDoc=api.invoke(env, "getKohlsCashApi", inDocGetKohlsCashApi);
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetKohlsCashApi");
    return outDoc;
  }

  /**
   * prepare Input For GetKohlsCashApi
   * 
   * @param outDoccallGetRSResponse
   * @return
   */
  public Document prepareInputForGetKohlsCashApi(Document outDocCallCreateReturnOrder) {
    // <Order DisplayLocalizedFieldInLocale="en_US" IgnoreOrdering="Y"
    // OrderHeaderKey="1117082518513870298106">
    // <Extn ExtnPOCFeature="ReceiptedReturn"/>
    // </Order>
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGetKohlsCashApi");
    Document inDocForGetKohlsCashApi = SCXmlUtil.createDocument("Order");
    Element eleOrder = inDocForGetKohlsCashApi.getDocumentElement();
    eleOrder.setAttribute("OrderHeaderKey",
        outDocCallCreateReturnOrder.getDocumentElement().getAttribute("OrderHeaderKey"));
    eleOrder.setAttribute("DocumentType", "0003");

    Element eleOrderExtn = SCXmlUtil.createChild(eleOrder, "Extn");
    eleOrderExtn.setAttribute("ExtnPOCFeature", "ReceiptedReturn");

    logger
        .debug("prepareInputForGetKohlsCashApi:: " + SCXmlUtil.getString(inDocForGetKohlsCashApi));
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGetKohlsCashApi");
    return inDocForGetKohlsCashApi;
  }

  /**
   * 3) call changeOrder API with that line. This API adds the line to draft return order created in
   * step 2.
   * 
   * @param inDocChangeOrderOnReturnOrder
   * @param inDocChangeOrderOnReturnOrder2
   * @throws Exception
   */
  public void callChangeOrderOnReturnOrder(YFSEnvironment env,
      Document inDocChangeOrderOnReturnOrder2) throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callChangeOrderOnReturnOrder");
    // String templatePath="global/template/api/changeOrder_output.xml";
    logger.debug("Inside callChangeOrderOnReturnOrder::"
        + SCXmlUtil.getString(inDocChangeOrderOnReturnOrder2));
    Document docChangeOrderTemplate = SCXmlUtil.createFromString("<Order OrderHeaderKey=''/>");
     //CPE-11894 - Begin BusinessDay Missing on Return invoices
    Element eleOrder = inDocChangeOrderOnReturnOrder2.getDocumentElement();
    eleOrder.setAttribute("BusinessDay", sCurrentBusinessDay);
    //CPE-11894 - Ends
    //Filter blank Awards - CPE11421
    NodeList ndListOrderLine =
    		(NodeList) XPathUtil.getNodeList(inDocChangeOrderOnReturnOrder2.getDocumentElement(),
    		"//Award[not(@AwardId)]");
    		int ndLength = ndListOrderLine.getLength();
    		for (int lineCount = 0; lineCount < ndLength; lineCount++) {
    		Element eleOrderLine = (Element) ndListOrderLine.item(lineCount);
    		eleOrderLine.getParentNode().removeChild(eleOrderLine);
    		}
    //Stamp Order References CPE-11421		
   Document inDoc=addOrderReferences(inDocChangeOrderOnReturnOrder2.getDocumentElement(), sRSOTRAmount);
    
    logger.debug(" After removing blank Awards and Appending Order References with OTR response::"+ SCXmlUtil.getString(inDocChangeOrderOnReturnOrder2));
    invokeAPI(env, docChangeOrderTemplate, "changeOrder", inDocChangeOrderOnReturnOrder2);
    // api.invoke(env, "changeOrder", inDocChangeOrderOnReturnOrder2);
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callChangeOrderOnReturnOrder");
  }

  /**
   * Match the line to be returned with OrderLine from Step 1
   * 
   * @param outDoccallGetRSResponse
   * @param inDocCallCreateReturnOrder
   * @return
   * @throws Exception 
   */
  public Document prepareInputForChangeReturnOrderToAddLines(YFSEnvironment env, Document inDoc,
      Document outDoccallGetRSResponse, Document inDocCallCreateReturnOrder) throws Exception {
    logger
        .beginTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForChangeReturnOrderToAddLines");
    logger
        .debug("Input to prepareInputForChangeReturnOrderToAddLines::inDocCallCreateReturnOrder:: "
            + SCXmlUtil.getString(inDocCallCreateReturnOrder));
    logger.debug("Input to prepareInputForChangeReturnOrderToAddLines::outDoccallGetRSResponse:: "
        + SCXmlUtil.getString(outDoccallGetRSResponse));
    Element eleChangeOrder = inDocCallCreateReturnOrder.getDocumentElement();
    eleChangeOrder.setAttribute("Override", "Y");
    eleChangeOrder.setAttribute("SelectMethod", "WAIT");
    eleChangeOrder.setAttribute("ValidatePromotionAward", "N");
    Element eleChangeOrderExtn = SCXmlUtil.getChildElement(eleChangeOrder, "Extn", true);
    eleChangeOrderExtn.setAttribute("ExtnPOCFeature", "ReceiptedReturn");
    Element eleOrderLines = SCXmlUtil.createChild(eleChangeOrder, "OrderLines");
    NodeList orderLineInDocList =
        SCXmlUtil.getXpathNodes(inDoc.getDocumentElement(), "/Order/OrderLines/OrderLine");
    for (int i = 0; i < orderLineInDocList.getLength(); i++) {
      Element eleReceiptOL = (Element) orderLineInDocList.item(i);
      logger.debug("eleReceiptOL::" + SCXmlUtil.getString(eleReceiptOL));
      String strOrderLineKey = eleReceiptOL.getAttribute("OrderLineKey");
      String strPrimeLineNo = eleReceiptOL.getAttribute("PrimeLineNo");

      Element eleRSOrderLine =
          SCXmlUtil.getXpathElement(outDoccallGetRSResponse.getDocumentElement(),
              "/Order/OrderLines/OrderLine[@OrderLineKey='" + strOrderLineKey + "']");
      if (!YFCCommon.isVoid(eleRSOrderLine)) {
        Element eleChangeOrderLine = SCXmlUtil.createChild(eleOrderLines, "OrderLine");
        eleChangeOrderLine.setAttribute("Action", "CREATE");
        eleChangeOrderLine.setAttribute("DeliveryMethod", "CARRY");
        eleChangeOrderLine.setAttribute("GiftFlag", "N");
        eleChangeOrderLine.setAttribute("OrderedQty", "1");
        String sItemID = SCXmlUtil.getChildElement(eleRSOrderLine, "Item").getAttribute("ItemID");
        eleChangeOrderLine.setAttribute("BarcodeData", sItemID);
        if (!YFCCommon.isVoid(eleRSOrderLine.getAttribute("OrderLineKey"))) {
          Element eleDerivedFrom = SCXmlUtil.createChild(eleChangeOrderLine, "DerivedFrom");
          eleDerivedFrom.setAttribute("OrderHeaderKey",
              eleRSOrderLine.getAttribute("OrderHeaderKey"));
          eleDerivedFrom.setAttribute("OrderLineKey", eleRSOrderLine.getAttribute("OrderLineKey"));
        }
        eleChangeOrderLine.appendChild(eleChangeOrderLine.getOwnerDocument()
            .importNode(SCXmlUtil.getChildElement(eleRSOrderLine, "Item"), true));
        eleChangeOrderLine.appendChild(eleChangeOrderLine.getOwnerDocument()
            .importNode(SCXmlUtil.getChildElement(eleRSOrderLine, "LineCharges"), true));
        eleChangeOrderLine.appendChild(eleChangeOrderLine.getOwnerDocument()
            .importNode(SCXmlUtil.getChildElement(eleRSOrderLine, "Awards"), true));
        eleChangeOrderLine.appendChild(eleChangeOrderLine.getOwnerDocument()
            .importNode(SCXmlUtil.getChildElement(eleRSOrderLine, "Promotions"), true));
        eleChangeOrderLine.appendChild(eleChangeOrderLine.getOwnerDocument()
            .importNode(SCXmlUtil.getChildElement(eleRSOrderLine, "Extn"), true));

        Element eleRSLinePriceInfo = SCXmlUtil.getChildElement(eleRSOrderLine, "LinePriceInfo");
        Element eleChangeOrderLinePriceInfo =
            SCXmlUtil.createChild(eleChangeOrderLine, "LinePriceInfo");
        eleChangeOrderLinePriceInfo.setAttribute("UnitPrice",
            eleRSLinePriceInfo.getAttribute("UnitPrice"));
        eleChangeOrderLinePriceInfo.setAttribute("ListPrice",
            eleRSLinePriceInfo.getAttribute("ListPrice"));
        eleChangeOrderLinePriceInfo.setAttribute("RetailPrice",
            eleRSLinePriceInfo.getAttribute("RetailPrice"));
        eleChangeOrderLinePriceInfo.setAttribute("TaxableFlag",
            eleRSLinePriceInfo.getAttribute("TaxableFlag"));
        
        NodeList nlLineCharge = eleChangeOrderLine.getElementsByTagName("LineCharge");
        for (int j = 0; j < nlLineCharge.getLength(); j++){
          Element eleLineCharge = (Element) nlLineCharge.item(j);
          if(!YFCCommon.isVoid(eleLineCharge.getAttribute("InvoicedChargeAmount"))){
            eleLineCharge.removeAttribute("InvoicedChargeAmount");
          }
          if(!YFCCommon.isVoid(eleLineCharge.getAttribute("InvoicedChargePerLine"))){
            eleLineCharge.removeAttribute("InvoicedChargePerLine");
          }
        }

        NodeList nlRSLineTax = eleRSOrderLine.getElementsByTagName("LineTax");
        Element eleChangeOrderLineTaxes = SCXmlUtil.createChild(eleChangeOrderLine, "LineTaxes");
        for (int j = 0; j < nlRSLineTax.getLength(); j++) {
          Element eleRSLineTax = (Element) nlRSLineTax.item(j);
          Element eleChangeOrderLineTax = SCXmlUtil.createChild(eleChangeOrderLineTaxes, "LineTax");
          eleChangeOrderLineTax.setAttribute("Tax", eleRSLineTax.getAttribute("Tax"));
          eleChangeOrderLineTax.setAttribute("TaxName", eleRSLineTax.getAttribute("TaxName"));
          eleChangeOrderLineTax.setAttribute("ChargeCategory",
              eleRSLineTax.getAttribute("ChargeCategory"));
          eleChangeOrderLineTax.setAttribute("ChargeName", eleRSLineTax.getAttribute("ChargeName"));
          eleChangeOrderLineTax.setAttribute("TaxPercentage",String.valueOf(Double.parseDouble(eleRSLineTax.getAttribute("TaxPercentage")) * 100));
        }
        
       
        

        Element eleCustomAttributes =
            SCXmlUtil.getChildElement(eleChangeOrderLine, "CustomAttributes", true);
        
        // START : CPE-10803 : add text 13 for Auto return orders. 
        Element eleRSOLCustAttributes = SCXmlUtil.getChildElement(eleRSOrderLine, KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
        if(!YFCCommon.isVoid(eleRSOLCustAttributes))
        {
        		String multiChannelOrdNumber = eleRSOLCustAttributes.getAttribute(KohlsXMLLiterals.A_TEXT_13);
        		if(!YFCCommon.isVoid(multiChannelOrdNumber))
        		{
        			eleCustomAttributes.setAttribute("Text13",multiChannelOrdNumber);
        		}
        }
        // END : CPE-10803 : add text 13 for Auto return orders. 
        
        eleCustomAttributes.setAttribute("Text6",
            outDoccallGetRSResponse.getDocumentElement().getAttribute("OrderNo"));
        eleCustomAttributes.setAttribute("Text7", sOrigStoreNo);
        eleCustomAttributes.setAttribute("Text8", sOrigTerminalID);
        eleCustomAttributes.setAttribute("Text9", sOrigTranNo);
        eleCustomAttributes.setAttribute("Text10", eleRSOrderLine.getAttribute("PrimeLineNo"));
        eleCustomAttributes.setAttribute("Date2", sOrigOrderDate);
        Element eleRSOrderLineExtn = SCXmlUtil.getChildElement(eleRSOrderLine, KohlsXMLLiterals.E_EXTN);
       if (eleRSOrderLineExtn.hasAttribute(KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE)) {
         eleCustomAttributes.setAttribute("Text11", eleRSOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE));
       } else {
         logger.error("@@@ OriginalSaleTypeCode will be blank in data collect for auto return transaction");
       }
        
        updateItemInfoOnOrderLine(env, eleChangeOrderLine);
        
        logger.debug("eleTempOL::" + SCXmlUtil.getString(eleRSOrderLine));
      }
      // eleOrderLines.appendChild(eleTempOL);


      // Node importedNode = document.importNode(node, true);
      // parent.appendChild(importedNode);
    }

    logger.debug("prepareInputForChangeReturnOrderToAddLines:: "
        + SCXmlUtil.getString(inDocCallCreateReturnOrder));
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForChangeReturnOrderToAddLines");
    return inDocCallCreateReturnOrder;
  }


  /**
   * Create By mrjoshi * 
   * @param env
   * @param eleChangeOrderLine
   * @throws Exception 
   */
  private void updateItemInfoOnOrderLine(YFSEnvironment yfsEnv, Element eleChangeOrderLine) throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.updateItemInfoOnOrderLine");
    Element EleItem = (Element) (eleChangeOrderLine.getElementsByTagName("Item").item(0));
    Element extnEle = XMLUtil.getChildElement(eleChangeOrderLine, "Extn", true);
    Document getItemListInput = XMLUtil.getDocument("<Item OrganizationCode='DEFAULT' ItemID='"
        + XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID) + "' />");
    Document getItemListTemplate = XMLUtil.getDocument(
        "<ItemList><Item ItemID='' ><ClassificationCodes TaxProductCode='' /> <Extn ExtnEmpDiscCode='' ExtnDept='' ExtnSubClass='' ExtnClass=''/></Item></ItemList>");
    Document getItemListOutput =
        KOHLSBaseApi.invokeAPI(yfsEnv, getItemListTemplate, "getItemList", getItemListInput);
    NodeList nItemList = getItemListOutput.getElementsByTagName("Item");
    if (!YFCCommon.isVoid(nItemList)) {
      Element eleItemOut = ((Element) nItemList.item(0));
      if (!YFCCommon.isVoid(eleItemOut)) {
        String sTaxCode = ((Element) eleItemOut.getElementsByTagName("ClassificationCodes").item(0))
            .getAttribute(KohlsPOCConstant.A_TAX_PRODUCT_CODE);
        extnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE, sTaxCode);
        Element eleItemExtn = (Element) eleItemOut.getElementsByTagName("Extn").item(0);
        String sEmpDiscCode = eleItemExtn.getAttribute("ExtnEmpDiscCode");
        String sDept = eleItemExtn.getAttribute("ExtnDept");
        String sClass = eleItemExtn.getAttribute("ExtnClass");
        String sSubClass = eleItemExtn.getAttribute("ExtnSubClass");
        extnEle.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT, sDept);
        extnEle.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_CLASS, sClass);
        extnEle.setAttribute(KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS, sSubClass);
        Element eleOrderLineReferences = SCXmlUtil.getChildElement(eleChangeOrderLine, "References", true);
        Element eleEmpDiscCodeReference = (Element)XPathUtil.getNode(eleOrderLineReferences, "//Reference[@Name='ExtnEmpDiscCode']");
        if(YFCCommon.isVoid(eleEmpDiscCodeReference)) {
          eleEmpDiscCodeReference = SCXmlUtil.createChild(eleOrderLineReferences, "Reference");
          eleEmpDiscCodeReference.setAttribute("Name", "ExtnEmpDiscCode");
          eleEmpDiscCodeReference.setAttribute("Value", sEmpDiscCode);
        }
      } else {
        logger.error("Item " + XMLUtil.getAttribute(EleItem, KohlsPOCConstant.A_ITEM_ID)
            + " is not present in OMS. This is the case of Item Not On File.");
        throw new YFSException("Item Not Found in OMS");
      }
    }
    if(logger.isDebugEnabled()) {
      logger.debug("Output of method updateItemInfoOnOrderLine is: "+SCXmlUtil.getString(eleChangeOrderLine));
    }
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.updateItemInfoOnOrderLine");
    
  }

  public Document prepareInputForCreateReturnDraftOrder(YFSEnvironment env,Document callGetRSResponse,
      Document inDoc) {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForCreateReturnDraftOrder");
    Document inDocCreateReturnDraftOrder = SCXmlUtil.createDocument("Order");
    Element eleOrder = inDocCreateReturnDraftOrder.getDocumentElement();
    // eleOrder.setAttribute("Date", "2017-08-25T18:51:38-05:00");
    // eleOrder.setAttribute("CurrentTerminal", "75");
    // eleOrder.setAttribute("DisplayLocalizedFieldInLocale", "en_US");
    eleOrder.setAttribute("DocumentType", "0003");
    // eleOrder.setAttribute("OrderDate", "2017-08-25T18:51:38-05:00");
    eleOrder.setAttribute("EnterpriseCode", "KOHLS-RETAIL");
    eleOrder.setAttribute("DraftOrderFlag", "Y");
    eleOrder.setAttribute("EntryType", "STORE");
    eleOrder.setAttribute("IgnoreOrdering", "Y");
    eleOrder.setAttribute("OperatorID", sOperatorID);
    // eleOrder.setAttribute("OrderNo", SCXmlUtil.getAttribute(inDoc.getDocumentElement(),
    // "/Order/Extn/@ExtnReceiptID"));
    // eleOrder.setAttribute("POSSequenceNumber", "4821");
    // eleOrder.setAttribute("PosSequenceNo", "4821");
    eleOrder.setAttribute("ProcedureID", "createReturnOrder");
    eleOrder.setAttribute("ProcessPaymentOnReturnOrder", "Y");
    eleOrder.setAttribute("SellerOrganizationCode", sCurrentStore);
    eleOrder.setAttribute("TerminalID", sCurrentTerminalID);
    eleOrder.setAttribute("TerminalType", "kohls");
    eleOrder.setAttribute("TillID", sCurrentTillID);
    // eleOrder.setAttribute("TransactionNo", "");


    Element elePersonInfoBillTo = SCXmlUtil.createChild(eleOrder, "PersonInfoBillTo");
    elePersonInfoBillTo.setAttribute("AddressLine1", "EMPTY ADDRESS");

    Element eleOrderExtn = SCXmlUtil.createChild(eleOrder, "Extn");
    Element eleRSOrderExtn =
        XMLUtil.getChildElement(callGetRSResponse.getDocumentElement(), "Extn");
    if (!YFCCommon.isVoid(eleRSOrderExtn)) {
      if (!YFCCommon.isVoid(eleRSOrderExtn.getAttribute("ExtnDeductibleOffers"))) {
        eleOrderExtn.setAttribute("ExtnDeductibleOffers",
            eleRSOrderExtn.getAttribute("ExtnDeductibleOffers"));
      }
      eleOrderExtn.setAttribute("ExtnOTRResponse", "000000F0");
      if (!YFCCommon.isVoid(eleRSOrderExtn.getAttribute("ExtnCustomerAssociateNo"))) {
        eleOrderExtn.setAttribute("ExtnCustomerAssociateNo",
            eleRSOrderExtn.getAttribute("ExtnCustomerAssociateNo"));
      } else {
        eleOrderExtn.setAttribute("ExtnCustomerAssociateNo", "");
      }
      eleOrderExtn.setAttribute("ExtnOTRResponseType", "Approval");
      eleOrderExtn.setAttribute("ExtnPOCFeature", "ReceiptedReturn");
      eleOrderExtn.setAttribute("ExtnRegisterBankNumber", "0001");
      if (!YFCCommon.isVoid(sExtnEReceiptEmailID)) {
        eleOrderExtn.setAttribute("ExtnEReceiptEmailID", sExtnEReceiptEmailID);
      }
    }
    String sReturnReasonCode = inDoc.getDocumentElement().getAttribute("ReturnReason");
    eleOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE ,sReturnReasonCode);

    Element eleRSPriceInfo =
        SCXmlUtil.getChildElement(callGetRSResponse.getDocumentElement(), "PriceInfo");
     sRSOTRAmount = eleRSPriceInfo.getAttribute("TotalAmount");
    if (YFCCommon.isVoid(sRSOTRAmount)) {
      sRSOTRAmount = "0.00";
    }

    isCreateReturn=true;
    Document referencesDoc=addOrderReferences(eleOrder, sRSOTRAmount);
    env.setTxnObject("referencesDoc", referencesDoc);

    if (!YFCCommon
        .isVoid(SCXmlUtil.getChildElement(callGetRSResponse.getDocumentElement(), "Promotions"))) {
      Element elePromotionsTemp = (Element) inDocCreateReturnDraftOrder.importNode(
          SCXmlUtil.getChildElement(callGetRSResponse.getDocumentElement(), "Promotions"), true);
      eleOrder.appendChild(elePromotionsTemp);
      NodeList nlPromotion = elePromotionsTemp.getElementsByTagName("Promotion");
      for (int i = 0; i < nlPromotion.getLength(); i++) {
        Element elePromotion = (Element) nlPromotion.item(i);
        String sPromotionType = elePromotion.getAttribute("PromotionType");
        if (!"KOHLS_CASH_REISSUE".equals(sPromotionType)) {
          elePromotionsTemp.removeChild(elePromotion);
        }
      }
    }

    logger.debug("prepareInputForCreateReturnDraftOrder:: "
        + SCXmlUtil.getString(inDocCreateReturnDraftOrder));
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForCreateReturnDraftOrder");
    return inDocCreateReturnDraftOrder;
  }

/**
 * @param eleOrder
 * @param sRSOTRAmount
 * @throws DOMException
 */
private Document addOrderReferences(Element eleOrder, String sRSOTRAmount) throws DOMException {
	Document referencesDoc = null;
	Element eleOrderReferences=null;
	if(isCreateReturn)
	{	 referencesDoc=SCXmlUtil.createDocument("References");
		 eleOrderReferences = referencesDoc.getDocumentElement();
		 isCreateReturn=false;
	}
	else
	{ eleOrderReferences=SCXmlUtil.createChild(eleOrder, "References") ;}
	
    Element eleOrderReference = SCXmlUtil.createChild(eleOrderReferences, "Reference");
    eleOrderReference.setAttribute("Name",
        "OTR-R-" + sOrigStoreNo + "-" + sOrigTerminalID + "-" + sOrigTranNo + "-" + sOrigOrderDate);
    eleOrderReference.setAttribute("Value",
        "000000F0-Approval-" + sRSOTRAmount + "-" + sOrigReceiptID + "_K--");
    
    return referencesDoc;
}

  /**
   * 1) Call getOrderDetailsWithRSResponse api with the original receipt id. This API calls the RS
   * and merges the RS reasponse with OMS getOrderList api and provides the hybrid xml.
   * 
   * @param env
   * @param inDocCallGetRSResponse
   * @return
   * @throws Exception
   */
  public Document callGetOrderDetailsWithRSResponse(YFSEnvironment env,
      Document inDocCallGetRSResponse) throws Exception {
    logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetOrderDetailsWithRSResponse");
    if (logger.isDebugEnabled()) {
      logger.debug("Inside callGetOrderDetailsWithRSResponse:: "
          + SCXmlUtil.getString(inDocCallGetRSResponse));
    }
    Document outDocCallGetRSResponse =
        invokeService(env, "GetOrderDetailsWithRSResponse", inDocCallGetRSResponse);
    logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.callGetOrderDetailsWithRSResponse");
    return outDocCallGetRSResponse;

  }



  /**
   * Input format
   * 
   * < Order OrderHeaderKey="" OrderNo="">
   * <Extn ExtnReceiptID=""/> <OrderLines> <OrderLine OrderLineKey = "" DeliveryMethod=""> <Extn
   * ExtnReturnPrice=""/> <LineCharges> <LineCharge chargeCategory="KOHLS_CASH" chargePerLine=""/>
   * </LineCharges> </OrderLine> </OrderLinies> </Order>
   * 
   * @param inDoc
   * @return
   */
  public Document prepareInputForGetOrderDetailsWithRSResponse(Document inDoc) throws Exception {
    logger.beginTimer(
        "KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGetOrderDetailsWithRSResponse");
    Element eleInDoc = inDoc.getDocumentElement();
    sOrigReceiptID = SCXmlUtil.getXpathAttribute(eleInDoc, "/Order/Extn/@ExtnReceiptID");
    Document inDocGetOrderDetailsWithRSResponse = SCXmlUtil.createDocument("Order");
    Element eleOrder = inDocGetOrderDetailsWithRSResponse.getDocumentElement();
    eleOrder.setAttribute("CurrentStore", sCurrentStore);
    eleOrder.setAttribute("CurrentTerminal", sCurrentTerminalID);
    eleOrder.setAttribute("DocumentType", "0001");
    eleOrder.setAttribute("EnterpriseCode", "KOHLS-RETAIL");
    eleOrder.setAttribute("GiftReceiptInd", "false");
    eleOrder.setAttribute("GiftRegistryId", "");
    eleOrder.setAttribute("IsMultiReceipted", "N");
    eleOrder.setAttribute("ItemID", "");
    eleOrder.setAttribute("LineSequenceNbr", "-1");
    eleOrder.setAttribute("OperatorId", sOperatorID);
    eleOrder.setAttribute("POCFeature", "KOHLS_RETURNS");
    eleOrder.setAttribute("OrderNo", sOrigReceiptID);

    String originalSaleTransactionNo = ReceiptUtil.getTransactionIdFromReceiptID(
        SCXmlUtil.getXpathAttribute(eleInDoc, "/Order/Extn/@ExtnReceiptID"));
    sOrigStoreNo = originalSaleTransactionNo.substring(12, 16);
    //Start of fix for PST-2545
    sOrigStoreNo = sOrigStoreNo.replaceFirst("^0*", "");
    //End of fix for PST-2545
    sOrigTerminalID = originalSaleTransactionNo.substring(16, 18);
    sOrigTranNo = originalSaleTransactionNo.substring(18, 22);
    sOrigOrderDate = originalSaleTransactionNo.substring(0, 12);
    DateFormat inputFormatter = new SimpleDateFormat("MMddyyHHmmss");
    DateFormat outputFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
    sOrigOrderDate = outputFormatter.format(inputFormatter.parse(sOrigOrderDate));
    eleOrder.setAttribute("StoreNumber", sOrigStoreNo);
    eleOrder.setAttribute("TerminalID", sOrigTerminalID);
    eleOrder.setAttribute("TransactionNbr", sOrigTranNo);
    eleOrder.setAttribute("TransactionTmst", sOrigOrderDate);

    logger.debug("prepareInputForGetOrderDetailsWithRSResponse:: "
        + SCXmlUtil.getString(inDocGetOrderDetailsWithRSResponse));
    logger
        .endTimer("KohlsOmniOMSrCreateReturnForOMSe.prepareInputForGetOrderDetailsWithRSResponse");
    return inDocGetOrderDetailsWithRSResponse;
  }

  @Override
  public void setProperties(Properties arg0) throws Exception {
    // TODO Auto-generated method stub

  }
  /**
   * 
   * @param outDocCallGetRSResponse
   * @param sReturnOrderHeaderKey
   * @param sCurrentStore2
   * @return
   */
  private Document chkLoyaltyAndPrepareInputToLCSWrapper(Document outDocCallGetRSResponse, String sReturnOrderHeaderKey, String sCurrentStore2) {
	  logger.beginTimer("KohlsOmniOMSrCreateReturnForOMSe.chkLoyaltyAndPrepareInputToLCSWrapper");
	  logger.debug("Inside chkLoyaltyAndPrepareInputToLCSWrapper method");
	  Document docLCSInput = SCXmlUtil.createDocument("Order");
	  try {
		  Element eleRSresponseOrder = (Element) outDocCallGetRSResponse.getDocumentElement();
			NodeList nlDeductibleOffers = eleRSresponseOrder.getElementsByTagName(KohlsXMLLiterals.E_DEDUCTIBLE_OFFER);
			int offerLength = nlDeductibleOffers.getLength();
			Element eleOrder = docLCSInput.getDocumentElement();
			Element eleOrderPriceInfo = (Element) eleRSresponseOrder
					.getElementsByTagName(KohlsXMLLiterals.E_PRICE_INFO).item(0);
			eleOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sReturnOrderHeaderKey);
			eleOrder.setAttribute(KohlsXMLLiterals.E_SOURCE, "ReturnLCS");
			eleOrder.setAttribute(KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT,
					eleOrderPriceInfo.getAttribute(KohlsXMLLiterals.A_TOTAL_AMOUNT));
			eleOrder.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, sCurrentStore2);
			Element extn = docLCSInput.createElement(KohlsXMLLiterals.E_EXTN);
			extn.setAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE, "ReceiptedReturn");
			eleOrder.appendChild(extn);
			Element eleLoyaltyList = docLCSInput.createElement(KohlsXMLLiterals.E_LOYALTY_LIST);
			eleOrder.appendChild(eleLoyaltyList);
			for(int offerCount = 0; offerCount < offerLength; offerCount++ ) 
			{
				Element eleLoyaltyDetails = null;
				Element eleDeductibleOffer = (Element) nlDeductibleOffers.item(offerCount);
				Element eleLoyaltyCustomerDetails = (Element) eleDeductibleOffer
						.getElementsByTagName(KohlsXMLLiterals.E_LOYALTY_CUSTOMER_DETAILS).item(0);
				if(!YFCCommon.isVoid(eleLoyaltyCustomerDetails))
				{
				eleLoyaltyDetails = (Element)eleLoyaltyCustomerDetails.getElementsByTagName(KohlsXMLLiterals.A_LOYALTY_NUMBER).item(0);
				}
				if (!YFCCommon.isVoid(eleLoyaltyDetails) && !YFCCommon.isVoid(eleLoyaltyDetails.getTextContent())) {
					Element eleLoyalty = docLCSInput.createElement(KohlsXMLLiterals.E_LOYALTY);
					eleLoyalty.setAttribute(KohlsXMLLiterals.A_EVERYDAY_EARN_KCC, eleLoyaltyCustomerDetails
							.getElementsByTagName(KohlsXMLLiterals.A_EVERY_KC_EARN_AMT).item(0).getTextContent());
					eleLoyalty.setAttribute(KohlsXMLLiterals.A_EVERYDAY_EARN_NON_KCC, eleLoyaltyCustomerDetails
							.getElementsByTagName(KohlsXMLLiterals.A_EVERY_NON_KC_EARN_AMT).item(0).getTextContent());
					eleLoyalty.setAttribute(KohlsXMLLiterals.A_LOYALTY_NUMBER, eleLoyaltyCustomerDetails
							.getElementsByTagName(KohlsXMLLiterals.A_LOYALTY_NUMBER).item(0).getTextContent());
					eleLoyalty.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,
							eleRSresponseOrder.getAttribute(KohlsXMLLiterals.A_POS_SEQ_NO));
					eleLoyalty.setAttribute(KohlsXMLLiterals.A_STORE_ID, sCurrentStore2);
					eleLoyalty.setAttribute(KohlsXMLLiterals.A_REGISTER_ID,
							eleRSresponseOrder.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
					Element eleEligAmt = (Element) eleDeductibleOffer
							.getElementsByTagName(KohlsXMLLiterals.E_ELIGIBLE_AMOUNT).item(0); 
					Element eleIndividualOfferId = (Element) eleDeductibleOffer
							.getElementsByTagName(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID).item(0);
					
					if(!YFCCommon.isVoid(eleEligAmt)) {
						String eligibleAmount = eleEligAmt.getTextContent();
						eleLoyalty.setAttribute(KohlsXMLLiterals.E_ELIGIBLE_AMOUNT, eligibleAmount);
					}
					if(!YFCCommon.isVoid(eleIndividualOfferId)) {
						String individualOfferId = eleIndividualOfferId.getTextContent();
						eleLoyalty.setAttribute(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID, individualOfferId);
					}
					
					eleLoyaltyList.appendChild(eleLoyalty);
			  }
		  }
		if(logger.isDebugEnabled()) {
			logger.debug("Input prepared for LCS wrapper service - " + XMLUtil.getXMLString(docLCSInput));
		}
	  }catch(Exception excp) {
		  logger.error("Catch block of chkLoyaltyAndPrepareInputToLCSWrapper: LCS unarming failed" + excp);
	  }
		
	logger.endTimer("KohlsOmniOMSrCreateReturnForOMSe.chkLoyaltyAndPrepareInputToLCSWrapper");
	return docLCSInput;
}
}
