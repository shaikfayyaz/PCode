package com.kohls.poc.api;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * MAD-337 This class is invoked only for Post void scenarios during Order Sync from ISS to CORP.
 * 
 */
public class KohlsPoCGetOrderInvoiceForPostVoid extends KOHLSBaseApi {
  private static final YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCGetOrderInvoiceForPostVoid.class);

  /**
   * This method is used to get the OrderInvoicekey and stamp the key in loadoffline transaction
   * event xml for Sale.
   * 
   * @param env
   * @param inDoc
   * @return
   * @throws Exception
   */

  public Document getOrderInvoiceForPostVoid(YFSEnvironment env, Document inDoc) throws Exception {
    String invoiceKey = "";
    Element inElement = inDoc.getDocumentElement();
    String orderNo = inElement.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
    Document docGetOrderInvoiceListInput = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER_INVOICE);
    Element eleGetOrderInvoiceListInput = docGetOrderInvoiceListInput.getDocumentElement();
    eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, orderNo);
    eleGetOrderInvoiceListInput.setAttribute(KohlsPOCConstant.A_INVOICE_TYPE,
        KohlsPOCConstant.CONSTANT_ORDER);
    Document docGetOrderInvoiceListOutput =
        invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GET_ORDER_INVOICE_LIST_TEMPLATE),
            KohlsPOCConstant.API_GET_ORDER_INVOICE_LIST, docGetOrderInvoiceListInput);
    if (!YFCCommon.isVoid(docGetOrderInvoiceListOutput)) {
      Element eleGetOrderInvoiceListOutput = docGetOrderInvoiceListOutput.getDocumentElement();
      Element orderInvoiceElement =
          XMLUtil.getChildElement(eleGetOrderInvoiceListOutput, KohlsPOCConstant.E_ORDER_INVOICE);
      if (!YFCCommon.isVoid(orderInvoiceElement)) {
        invoiceKey = orderInvoiceElement.getAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY);
        logger.debug("The order invoice key for post void scenario is   :" + invoiceKey);

      }
    }
    inElement.setAttribute(KohlsPOCConstant.ATTR_ORDER_INVOICE_KEY, invoiceKey);
    return inDoc;

  }
}
