package com.kohls.poc.pricing.ue;

import com.kohls.common.util.KOHLSBaseApi;

import java.io.File;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import com.kohls.common.util.XMLUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;

import org.w3c.dom.Document;


public class Utilityfileparser extends KOHLSBaseApi {
	private static YFCLogCategory logger;
	private Properties props;
	static {
		logger = YFCLogCategory.instance(Utilityfileparser.class.getName());
	}
	public Document readTVSResponseFromServer(YFSEnvironment yfsEnv,  Document inDoc) throws Exception {
		 logger.debug("inside  readTVSResponseFromServer");
		String strPath = props.getProperty("XML_PATH");
		logger.debug("**** Utilityfileparser.readTVSResponseFromServer****"+strPath);
		
		  DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		     Document doc = (docBuilder.parse (strPath));
			logger.debug("doc file"+XMLUtil.getXMLString(doc));
	
		    return doc;
	  }
		  
		  
	public void setProperties(Properties arg0) throws Exception  {
		this.props  =  arg0;
		}	  
		  }

	 
	  
	  
