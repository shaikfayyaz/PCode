package com.kohls.poc.pricing.ue;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.ue.YFSOrderRepricingUE;

public class KohlsPoCRepriceKCC extends KOHLSBaseApi implements YFSOrderRepricingUE{
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCRepriceKCC.class);

	public Document orderReprice(YFSEnvironment env, Document inDoc) {
		
		
		if(logger.isVerboseEnabled())
		logger.verbose("Input XML to the method KohlsPoCRepriceKCC.orderReprice is: \n"+ XMLUtil.getXMLString(inDoc));

		Element orderEle = inDoc.getDocumentElement();

		String posSeqNo = XMLUtil.getAttribute(orderEle,
				KohlsPOCConstant.A_POS_SEQUENCE_NO);
		logger.debug("seq no KCC:" + posSeqNo);
		if (null != posSeqNo) {
			Element eleExtn = XMLUtil.getChildElement(orderEle,
					KohlsPOCConstant.E_EXTN);
			XMLUtil.setAttribute(eleExtn,
					KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO, posSeqNo);
		}
		
		
		if(logger.isVerboseEnabled())
			logger.verbose("Returned XML to the method KohlsPoCRepriceKCC.orderReprice is: \n"+ XMLUtil.getXMLString(inDoc));
		
		return inDoc;
	}

}
