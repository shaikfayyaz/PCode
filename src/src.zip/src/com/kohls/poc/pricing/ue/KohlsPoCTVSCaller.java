package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.yantra.yfs.japi.YFSException;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;


/**************************************************************************
 * File : KohlsPoCTVSCaller.java
 * Author : IBM
 * Created : July 15 2015
 * Modified : July 15 2015
 * Version : 0.1
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 15/07/2015 IBM First Cut.
 *****************************************************************************
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 *
 * This class is used to construct TVS Request XML using Order Input Doc, Kohls Cash Response
 * and other Order and Order Line Promotions.
 *
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/
public class KohlsPoCTVSCaller{

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCTVSCaller.class.getName());
	}

	DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);


	public Element adjustmentOffers1=null;

	/**constructTVSRequestDocumentPsa() method used for construct the TVS Request XML from Gravity Inputs.
	 *
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param orderPromoObj
	 * @param linePromoObj
	 * @param createtsList
	 * @return tvsRequestDoc
	 * @throws Exception
	 */
	public Document constructTVSRequestDocumentPsa(YFSEnvironment yfsEnv, Element tempOrderEle,KohlsPoCTVSOrderPromotionsCaller orderPromoObj,KohlsPoCTVSOrderLinePromotionCaller linePromoObj,List<String> createtsList,String tvsStoreNum) throws Exception {

		logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestDocumentPsa");
		this.logger.debug("Method Name : constructTVSRequestDocumentPsa   and   Status : Start ");

		Document tvsRequestDocPSA = XMLUtil.createDocument(KohlsPOCConstant.ADJUSTMENT_REQUEST);
		Element priceRequestEle = tvsRequestDocPSA.getDocumentElement();
		//changed for compile issue
		priceRequestEle.setAttribute("xmlns", "http://kohls.com/tvs/psa");
		priceRequestEle.setAttribute("xmlns:ns2", "http://kohls.com/psa");

		Element transactionEle = XMLUtil.createChild(priceRequestEle, KohlsPOCConstant.ORIGINAL_TRANSACTION);

		String transId = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
		Element eleTransactionId = XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
		XMLUtil.setNodeValue(eleTransactionId, transId); // setting transaction id element

		Element transactionTime = XMLUtil.createChild(transactionEle, KohlsPOCConstant.TRANSACTION_TIME);
		String transTime = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORDER_DATE);
		XMLUtil.setNodeValue(transactionTime, transTime);

		Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
		XMLUtil.setNodeValue(eleStoreNum, tvsStoreNum);

		Element storeAddressEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
		Element eleShipNdPerInfo = null;
		NodeList nlOrderLine = (NodeList) XPathUtil.getNodeList(tempOrderEle, "/Order/OrderLines/OrderLine");
		if(!YFCCommon.isVoid(nlOrderLine)){
			eleShipNdPerInfo = (Element) ((NodeList) XPathUtil.getNodeList(tempOrderEle, "/Order/OrderLines/OrderLine/Shipnode/ShipNodePersonInfo")).item(0);
		}
		if(!YFCCommon.isVoid(eleShipNdPerInfo)){
			Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
			XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
			Element eleCountry = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
			XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
			Element elePostal = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
			XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
			Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
			XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
			Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
			XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
		}


		Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
		Element lidOfferExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.LID_OFFER_EXEMPT);
      this.constructLidOfferExemptPSA(promotionsEle, lidOfferExempt,tempOrderEle);

		//Create TVS request for Items and LLDs inside ItemList
				Element orderLinesEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.ELEM_ORDER_LINES);
				if (!YFCCommon.isVoid(orderLinesEle)) {
				Element itemListEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
					Map<String, Element> orderLineHM = linePromoObj.getOrderLineHM();
					for (final Map.Entry<String, Element> entry : orderLineHM.entrySet()) {
						this.logger.debug("call to construct item level request constructTVSRequestDocForItemPSA()");
						this.constructTVSRequestDocForItemPSA(entry, itemListEle, yfsEnv,linePromoObj,createtsList,promotionsEle);
					}
				}

				//Added for Manual TLD
			XMLUtil.createChild(transactionEle,  KohlsPOCConstant.ELEM_OFFERS);

            Element tempMaualTldList = XMLUtil.createChild(transactionEle, "manualTLDList");

             // forming exclusion rules for TVS request
            this.logger.debug("call to construct exclusion rules constructTVSRequestFromExclusionRules()");
            KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(yfsEnv, transactionEle);

            Element adjustments = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ADJUSTMENS);
            adjustmentOffers1 = XMLUtil.createChild(adjustments, KohlsPOCConstant.ADJUSTMENT_OFFERS);
				//Create TVS request for Order Level Promotions
				if (!YFCCommon.isVoid(promotionsEle)) {
					promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
				Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();
				int offerID = 0;
				for (final Map.Entry<String, Element> entry : orderTLDHM.entrySet()) {
				//Added offersEle as an argument for defect 5350 fix
				//Added lidOfferExempt as an argument for PSA
				//Added adjustmentsEle as an arugument for PSA adjustment
					this.logger.debug("call to construct order level promotions constructTVSRequestDocForTLDPSA()");
					offerID = offerID ++;
					this.constructTVSRequestDocForTLDPSA(entry, transactionEle,tempOrderEle, yfsEnv,createtsList,orderPromoObj,tempMaualTldList, offerID);
				}

				this.logger.debug("call to construct lidOfferExempt constructLidOfferExemptPSA()");


				//Adding taxExempt in TVS request
				String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle,KohlsPOCConstant.TAX_EXEMPT_FLAG);
				String strTaxExemptCert = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);

				if(!YFCCommon.isVoid(strTaxExemptCert) || strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES)){
					Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
					XMLUtil.setNodeValue(eleTaxExempt,KohlsPOCConstant.YES );
				}
				else{
					Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
					XMLUtil.setNodeValue(eleTaxExempt,KohlsPOCConstant.NO);
				}

				Element exclusionsElement = XMLUtil.getChildElement( transactionEle, KohlsPOCConstant.ELE_EXCLUSIONS);

            List<Element> manualTLDList = XMLUtil.getElementsByTagName(tempMaualTldList, KohlsPOCConstant.ELE_MANUAL_TLD);
            boolean sendExclusions = KohlsPoCPnPUtil.getExclusionsFlag();
	            for(Element manualTLD : manualTLDList){
	            	 if(sendExclusions) {
	            		 transactionEle.insertBefore(manualTLD,exclusionsElement);
	            	 }else{
	            		 transactionEle.insertBefore(manualTLD,adjustments);
	            	 }
	            }
	           
            //removing tempMaualTldList
            XMLUtil.removeChild( transactionEle, tempMaualTldList);

            if(logger.isDebugEnabled()){
				this.logger.debug("TVS Request ::: "+tvsRequestDocPSA);
            }
				this.logger.debug("Method Name : constructTVSRequestDocumentPsa   and   Status :End");
				logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestDocumentPsa");

		}
		return tvsRequestDocPSA;
	}


	/**
	 * Method to set lidOfferExempt tag true or false.
	 * @param promotionsEle
	 * @param lidOfferExempt
	 */
	@SuppressWarnings("unchecked")
	private void constructLidOfferExemptPSA(Element promotionsEle,Element lidOfferExempt,Element tempOrderEle){
		logger.beginTimer("KohlsPoCTVSCaller.constructLidOfferExemptPSA");
		List <Element> orderPromotionList = XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
		XMLUtil.setNodeValue(lidOfferExempt,KohlsPOCConstant.NO);

		String promotionType = KohlsPOCConstant.BLANK;

		for(Element promotion : orderPromotionList){
			promotionType = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_PROMOTION_TYPE);

			String promotionId = XMLUtil.getAttribute(promotion,KohlsPOCConstant.PROMOTIONID);

                        Element extnEle = XMLUtil.getChildElement(promotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

			String extnPromotionFlag = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
			String isPsaPromotion = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION);

			boolean lidValidationPrecedence = validatePrecedencelid(promotionId,tempOrderEle);

			if (((KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType))||
					(KohlsPOCConstant.KOHLSCASH.equalsIgnoreCase(promotionType))||
                           (lidValidationPrecedence == true)) && (!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion))){
				XMLUtil.setNodeValue(lidOfferExempt,KohlsPOCConstant.YES);
				break;
			}
		}
		logger.endTimer("KohlsPoCTVSCaller.constructLidOfferExemptPSA");
	}


	/**
	 *
	 * @param promotionId
	 * @param tempOrderEle
	 * @return
	 */
	private boolean validatePrecedencelid(String promotionId, Element tempOrderEle){
		logger.beginTimer("KohlsPoCTVSCaller.validatePrecedencelid");
		List <Element> orderLineList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
		String precedence = KohlsPOCConstant.BLANK;

		for(Element orderLine : orderLineList){
			NodeList awardList = orderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);

			for(int iterator=0 ; iterator<awardList.getLength(); iterator++){

				Element awardElement = (Element) awardList.item(iterator);
				String awardPromotionId = XMLUtil.getAttribute(awardElement, KohlsPOCConstant.A_PROMOTION_ID);

				if(awardPromotionId.equalsIgnoreCase(promotionId)){
					Element awardExtn = XMLUtil.getChildElement(awardElement,KohlsPOCConstant.A_EXTN);
					String salesHubClob = XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);

					if(!YFCCommon.isVoid(salesHubClob)){
						Element salesHubDataEle = null;
						try {
							salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
						} catch (ParserConfigurationException e) {
							logger.error("ParserConfigurationException at KohlsPoCTVSCaller.validatePrecedencelid");
						} catch (SAXException e) {
							logger.error("SAXException at KohlsPoCTVSCaller.validatePrecedencelid");
						} catch (IOException e) {
							logger.error("IOException at KohlsPoCTVSCaller.validatePrecedencelid");
						}

						if(!YFCCommon.isVoid(salesHubDataEle)){
							precedence = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_PRECEDENCE);
						}
						if(precedence.equalsIgnoreCase(KohlsPOCConstant.THIRTY_SIX) || precedence.equalsIgnoreCase("37") ){
							return true;
						}
					}
				}
			}
		}
		logger.endTimer("KohlsPoCTVSCaller.validatePrecedencelid");
		return false;
	}


	/**This is the main method used for construct the TVS Request XML using Gravity Inputs.
	 *
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param orderPromoObj
	 * @param linePromoObj
	 * @param createtsList
	 * @return tvsRequestDoc
	 * @throws Exception
	 */
	public Document constructTVSRequestDocument(YFSEnvironment yfsEnv, Element tempOrderEle,KohlsPoCTVSOrderPromotionsCaller orderPromoObj,KohlsPoCTVSOrderLinePromotionCaller linePromoObj,List<String> createtsList,String tvsStoreNum) throws Exception {

	logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestDocument");
	this.logger.debug("Method Name : constructTVSRequestDocument   and   Status : Start ");

	/*String shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
	//Appending zero when store number length is less than 4
	shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);*/

	Document tvsRequestDoc = XMLUtil.createDocument("priceRequest");
	Element priceRequestEle = tvsRequestDoc.getDocumentElement();
	Element transactionEle = XMLUtil.createChild(priceRequestEle, "transaction");

	//Start of XML Sequencing Change

		//Sudina: TVS phase 2 changes for taxware  - Start

		// Adding transactionId as POSSeqNo to the input request
	String transId = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
	Element eleTransactionId = XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID);
	XMLUtil.setNodeValue(eleTransactionId, transId);
	Element eleStoreNum = XMLUtil.createChild(transactionEle, KohlsPOCConstant.STORE_NUM);
	XMLUtil.setNodeValue(eleStoreNum, tvsStoreNum);


	// transactionEle.setAttribute(KohlsPOCConstant.STORE_NUM, shipNode);

	//Sudina: TVS phase 2 changes for taxware  - Start

	// Adding transactionId as POSSeqNo to the input request
	// String transId = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
	// transactionEle.setAttribute(KohlsPOCConstant.SMALL_ATTR_TRANSACTION_ID, transId);

// Adding storeAddress details to TVS request
	Element storeAddressEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.SMALL_ELEM_STORE_ADDRESS);
	if(logger.isDebugEnabled()){
	logger.debug("Element tempOrderEle: "+ XMLUtil.getElementXMLString(tempOrderEle));
	}
	Element eleShipNdPerInfo = null;
	Element eleOrderLine = KohlsXPathUtil.getElementByXpath( tempOrderEle.getOwnerDocument(), "OrderLines/OrderLine[@Shipnode='"+tvsStoreNum+"']" );
	//NodeList nlOrderLine = (NodeList) XPathUtil.get(tempOrderEle, "/Order/OrderLines/OrderLine");
	if(!YFCCommon.isVoid(eleOrderLine)){

		eleShipNdPerInfo = XMLUtil.getFirstElementByName(eleOrderLine, "Shipnode/ShipNodePersonInfo");
	//	System.out.println("Element ShipNodePersonInfo: "+ XMLUtil.getElementXMLString(eleShipNdPerInfo));
	}
	
	//CPE- 4819 start
	Element eleContactPerInfo = null;

	//Send segment info to TVS from Text2 Field
		Element eleCustomer = XMLUtil.createChild(transactionEle, KohlsPOCConstant.CUSTOMER);
		Element eleSegments = XMLUtil.createChild(eleCustomer, KohlsPOCConstant.SEGMENTS);

		Element eleCustomAttributes = null;
		eleCustomAttributes = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
		if(!YFCCommon.isVoid(eleCustomAttributes)) {
			String strText2 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT2);
			String segmentIds[];
			if(!YFCCommon.isVoid(strText2)) {
				segmentIds = strText2.split(KohlsPOCConstant.COMMA);
				for (String segmentId : segmentIds) {
					Element eleSegment = XMLUtil.createChild(eleSegments, KohlsPOCConstant.SEGMENT);
					XMLUtil.setNodeValue(eleSegment, segmentId);
				}
			}
		}
	
	
	//OMNI2 Begin - Add ShipTo ShipFrom and OriginAddr if ExtnisOmni=Y
		String extnIsOmni = "";
		Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(yfsEnv, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);

		String codeShortDesc = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);
		Element orderExtn = (Element) tempOrderEle.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
		if(!YFCCommon.isVoid(orderExtn)) {
			extnIsOmni = orderExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI);
		}
		List<Element> organizationList = null;
		if (KohlsPOCConstant.YES.equals(extnIsOmni) && KohlsPOCConstant.YES.equals(codeShortDesc)) {
			Set<String> shipNodes = new HashSet<String>(); 
			List<Element> orderLineList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
			for (Element orderLine : orderLineList) {
				shipNodes.add(XMLUtil.getAttribute(orderLine, KohlsPOCConstant.A_SHIP_NODE));
			}
			Document getOrgnList = callGetOrganizationList(yfsEnv,shipNodes);
			Element orgnList = getOrgnList.getDocumentElement();
			organizationList = XMLUtil.getElementsByTagName(orgnList,KohlsPOCConstant.ELEM_ORGANIZATION);
		}
		//OMNI2 End - Add ShipTo ShipFrom and OriginAddr if ExtnIsOmni=Y	
		
		Document getOrganizationHierarchyInput = XMLUtil.getDocument("<Organization OrganizationCode='" + tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE) 
				+ "' OrganizationKey='" + tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE) + "' ></Organization>");
		Document getOrganizationHierarchyTemplate = XMLUtil.getDocument("<Organization OrganizationName=''><ContactPersonInfo/><Node><ShipNodePersonInfo/></Node></Organization>");
		Document getOrganizationListOutput = KOHLSBaseApi.invokeAPI(yfsEnv,getOrganizationHierarchyTemplate,"getOrganizationHierarchy",getOrganizationHierarchyInput);
		
		eleContactPerInfo=((Element)getOrganizationListOutput.getElementsByTagName("ContactPersonInfo").item(0));

	
	//If contact info present set the address details in request
			if (!YFCCommon.isVoid(eleContactPerInfo)) {
				Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
				XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_CITY));
				Element eleCountry = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
				XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
				Element elePostal = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
				XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.A_ZIP_CODE));
				Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
				XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_STATE));
				Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
				XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
			}
	//If contact info not present check if shipnodeinfo present
		else{
			
			if(!YFCCommon.isVoid(eleShipNdPerInfo))
			{
				Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
				XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
				Element eleCountry = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
				XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
				Element elePostal = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
				XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
				Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
				XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
			//	Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
			//	XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
				String sGeoCode = XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE);
				if(YFCCommon.isVoid(sGeoCode)){
					YFSException yfsException = new YFSException();
					yfsException.setErrorCode(KohlsPOCConstant.INVALIDGEOCODE);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALIDGEOCODE));
					throw yfsException;
					
				}else {
					Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
					XMLUtil.setNodeValue(eleGeo, sGeoCode);
				}
		//		storeAddressEle.setAttribute(KohlsPOCConstant.SMALL_ATTR_CITY_NAME, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
		//		storeAddressEle.setAttribute(KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
		//		storeAddressEle.setAttribute(KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
		//		storeAddressEle.setAttribute(KohlsPOCConstant.SMALL_ATTR_STATE_PROV, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
		//		storeAddressEle.setAttribute(KohlsPOCConstant.SMALL_ATTR_GEO_CODE, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
			}
			//Temporary default attributes for defect 1094 - Start
			else
			{		
				eleShipNdPerInfo=((Element)getOrganizationListOutput.getElementsByTagName("ShipNodePersonInfo").item(0));
				Element eleCity = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_CITY_NAME);
				XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
				Element eleCountry = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_COUNTRY_CODE);
				XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
				Element elePostal = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_POSTAL_CODE);
				XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
				Element eleState = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_STATE_PROV);
				XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
				Element eleGeo = XMLUtil.createChild(storeAddressEle, KohlsPOCConstant.SMALL_ATTR_GEO_CODE);
				XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
			 }
		}
	//CPE- 4819 End
	//Temporary default attributes for defect 1094 - End
	
	//Sudina: TVS phase 2 changes for taxware  - End
		//Create TVS request for Order Level Promotions - //PST-4465 - Moving this from below- Start
		Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
		//PST-4465 - Moving this from below - End
		//Create TVS request for Items and LLDs
		Element orderLinesEle = XMLUtil.getChildElement(tempOrderEle, "OrderLines");
		if (!YFCCommon.isVoid(orderLinesEle)) {
		Element itemListEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_ITEM_LIST);
			Map<String, Element> orderLineHM = linePromoObj.getOrderLineHM();
			for (final Map.Entry<String, Element> entry : orderLineHM.entrySet()) {
				this.constructTVSRequestDocForItem(entry, itemListEle, yfsEnv,linePromoObj,createtsList,extnIsOmni, codeShortDesc,promotionsEle);
			}
		}
		
		//Added for defect 5350 fix -- start
		Element offersEle = XMLUtil.createChild(transactionEle,  KohlsPOCConstant.ELEM_OFFERS);
		
				//Create TVS request for Order Level Promotions - PST-4465 - Commenting below line
				//Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
				
				if (!YFCCommon.isVoid(promotionsEle)) {
					promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
				Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();
				for (final Map.Entry<String, Element> entry : orderTLDHM.entrySet()) {
				//Added offersEle as an argument for defect 5350 fix 
					this.constructTVSRequestDocForTLD(entry, transactionEle,tempOrderEle, yfsEnv,createtsList,orderPromoObj,offersEle);
				}
				}
				
		
				// Suresh : Added for Nike Exclusions Sprint 5 : Start

				// retrieving exclusion rules and forming TVS request
				KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(yfsEnv, transactionEle);
				
				// Suresh : Added for Nike Exclusions Sprint 5 : End
	
	//Adding taxExempt in TVS request
	String strTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle,KohlsPOCConstant.TAX_EXEMPT_FLAG);
	String strTaxExemptCert = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);
	
	if(!YFCCommon.isVoid(strTaxExemptCert) || strTaxExemptFlag.equalsIgnoreCase(KohlsPOCConstant.YES))
	{
		Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
		XMLUtil.setNodeValue(eleTaxExempt,KohlsPOCConstant.YES );
//		transactionEle.setAttribute(KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.YES);
	}
	else
	{
		Element eleTaxExempt = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
		XMLUtil.setNodeValue(eleTaxExempt,KohlsPOCConstant.NO);
//		transactionEle.setAttribute(KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.NO);
	}
	
	//Changes for date ranges R3 Sprint 4 CR2996 - Start
	String noofTLDToBEApplied = "1";
	Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.A_EXTN);
	String extnAssociateID = XMLUtil.getAttribute(eleOrderExtn,KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
	if(!YFCCommon.isVoid(extnAssociateID)){
		String transTime = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORDER_DATE);
		noofTLDToBEApplied = KohlsPoCPnPUtil.getNoOfTLDsToBeAppliedWithDateRange(yfsEnv,transTime);
		}
	Element eleNoOfTLDs = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ALLOWED_TLD_COUNT);
	XMLUtil.setNodeValue(eleNoOfTLDs,noofTLDToBEApplied);
	//Changes for date ranges R3 Sprint 4 CR2996 - End 
	
	//OMNI2 Begin - Add ShipTo ShipFrom and OriginAddr if ExtnIsOmni="Y"
	if (KohlsPOCConstant.YES.equals(extnIsOmni) && KohlsPOCConstant.YES.equals(codeShortDesc)) {
	addAddressElement(organizationList, transactionEle);
	}
	//OMNI2 End - Add ShipTo ShipFrom and OriginAddr if ExtnIsOmni="Y"
	
			logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestDocument");
			this.logger.debug("Method Name : constructTVSRequestDocument   and   Status :End");	
		
			return tvsRequestDoc;
	
		}
	
	/**
	 * This method is responsible for adding address element to TVS cartPrice request
	 * 
	 * @param organizationList
	 * @param transactionEle
	 */
	private void addAddressElement(List<Element> organizationList, Element transactionEle) {
			Element addrBook = XMLUtil.createChild(transactionEle, KohlsPOCConstant.A_ADDR_BOOK);
			for(Element organization: organizationList) {
				Element eleContactPerInfo = ((Element)organization.getElementsByTagName(KohlsPOCConstant.A_CONTACT_INFO).item(0));
				Element eleShipNdPerInfo=((Element)organization.getElementsByTagName(KohlsPOCConstant.SHP_NODE_PER_INFO).item(0));
				Element addr = XMLUtil.createChild(addrBook, KohlsPOCConstant.A_NS_ADDR);
				
				if (!YFCCommon.isVoid(eleContactPerInfo)) {
					
					Element id = XMLUtil.createChild(addr,KohlsPOCConstant.A_NS_ID);
					XMLUtil.setNodeValue(id, XMLUtil.getAttribute(organization, KohlsPOCConstant.A_ORGANIZATION_CODE));
					Element eleCity = XMLUtil.createChild(addr, KohlsPOCConstant.A_NS_CITY);
					XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_CITY));
					Element eleCountry = XMLUtil.createChild(addr, KohlsPOCConstant.A_NS_CNTY_CODE);
					XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
					Element elePostal = XMLUtil.createChild(addr,KohlsPOCConstant. A_NS_POST_CODE);
					XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.A_ZIP_CODE));
					Element eleState = XMLUtil.createChild(addr,KohlsPOCConstant.A_NS_STATE_PRVNCE);
					XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_STATE));
					Element eleGeo = XMLUtil.createChild(addr, KohlsPOCConstant.A_NS_GEO_CODE);
					XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleContactPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
					//Added For CPE-11854 OMNI2 START
					Element eleStoreNo = XMLUtil.createChild(addr,KohlsPOCConstant.A_NS_STORE_NUMBER);
					XMLUtil.setNodeValue(eleStoreNo, XMLUtil.getAttribute(organization, KohlsPOCConstant.A_ORGANIZATION_CODE));
					//Added For CPE-11854 OMNI2 END
				}
				else
				{		
					Element id = XMLUtil.createChild(addr,KohlsPOCConstant.A_NS_ID);
					XMLUtil.setNodeValue(id, XMLUtil.getAttribute(organization, KohlsPOCConstant.A_ORGANIZATION_CODE));
					Element eleCity = XMLUtil.createChild(addr, KohlsPOCConstant.A_NS_CITY);
					XMLUtil.setNodeValue(eleCity, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_CITY));
					Element eleCountry = XMLUtil.createChild(addr,  KohlsPOCConstant.A_NS_CNTY_CODE);
					XMLUtil.setNodeValue(eleCountry, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_COUNTRY));
					Element elePostal = XMLUtil.createChild(addr, KohlsPOCConstant. A_NS_POST_CODE);
					XMLUtil.setNodeValue(elePostal, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.A_ZIP_CODE));
					Element eleState = XMLUtil.createChild(addr, KohlsPOCConstant.A_NS_STATE_PRVNCE);
					XMLUtil.setNodeValue(eleState, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_STATE));
					Element eleGeo = XMLUtil.createChild(addr, KohlsPOCConstant.A_NS_GEO_CODE);
					XMLUtil.setNodeValue(eleGeo, XMLUtil.getAttribute(eleShipNdPerInfo, KohlsPOCConstant.ATTR_TAX_GEO_CODE));
					//Added For CPE-11854 OMNI2 START
					Element eleStoreNo = XMLUtil.createChild(addr,KohlsPOCConstant.A_NS_STORE_NUMBER);
					XMLUtil.setNodeValue(eleStoreNo, XMLUtil.getAttribute(organization, KohlsPOCConstant.A_ORGANIZATION_CODE));
					//Added For CPE-11854 OMNI2 END
				 }
				}
	}


	/** This Method invokes getOrganizationList through complexQuery for all ShipNodes at OrderLineLevel if ExtnOmni="Y"
	 * 
	 * @param entry
	 * @param transactionEle
	 * @param yfsEnv
	 * @param shipNodes
	 * @throws Exception
	 * 
	 */
	private Document callGetOrganizationList(YFSEnvironment env, Set<String> shipNodes) throws Exception {
		logger.beginTimer("GetOrganizationList.constructComplexQuery");
	
		Document getOrgnListInput = KohlsXMLUtil.newDocument();
		Element orgn = getOrgnListInput.createElement(KohlsPOCConstant.ELEM_ORGANIZATION);
		getOrgnListInput.appendChild(orgn);
		Element complexQry = getOrgnListInput.createElement(KohlsPOCConstant.E_COMPLEX_QUERY);
		orgn.appendChild(complexQry);
		complexQry.setAttribute(KohlsPOCConstant.A_OPERATOR, "OR");
		
		Element or = getOrgnListInput.createElement(KohlsPOCConstant.E_OR);
		complexQry.appendChild(or);
		
		Iterator it = shipNodes.iterator();
		while(it.hasNext()) {
			Element exp = getOrgnListInput.createElement(KohlsPOCConstant.E_EXP);
			or.appendChild(exp);
			exp.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_ORG_CODE);
			exp.setAttribute(KohlsPOCConstant.A_QRY_TYPE, KohlsXMLLiterals.QRY_TYPE_EQ);
			exp.setAttribute(KohlsPOCConstant.A_VALUE, (String) it.next());
		}
		
		Document getOrganizationHierarchyTemplate = XMLUtil.getDocument("<OrganizationList><Organization OrganizationCode=''><ContactPersonInfo/><Node><ShipNodePersonInfo/></Node></Organization></OrganizationList>");
		Document getOrganizationListOutput = KOHLSBaseApi.invokeAPI(env,getOrganizationHierarchyTemplate,"getOrganizationList",getOrgnListInput);
		
		return getOrganizationListOutput;
	}
	
	
	/** This Method is used to construct the TVS Request for Item, Manaul LLd, Price Override
	 * 
	 * @param entry
	 * @param transactionEle
	 * @param yfsEnv
	 * @param linePromoObj
	 * @param createtsList
	 * @throws Exception
	 * 
	 */
	//PST-4465 - Adding Promotions Element in the parameter
private void constructTVSRequestDocForItem(Entry<String, Element> entry,Element itemListEle,YFSEnvironment 
		yfsEnv,KohlsPoCTVSOrderLinePromotionCaller linePromoObj,List<String> createtsList, String extnIsOmni, String codeShortDesc,Element promotionsEle )throws Exception {

	logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestDocForItem");
	
	String primeLineNo = entry.getKey();
	Element orderLineEle =  entry.getValue();
	
	//String empDiscCodeStr = null;
	Element ordLineItemEle = XMLUtil.getChildElement(orderLineEle, "Item");
	String createTS = XMLUtil.getAttribute(ordLineItemEle,KohlsPOCConstant.A_CREATE_TS);
	Element extnEle = XMLUtil.getChildElement(orderLineEle, "Extn");
	//String extnEmpDiscCode = XMLUtil.getAttribute(extnEle,"ExtnEmpDiscCode");
	//String extnPricePromptInd = XMLUtil.getAttribute(extnEle,"ExtnPricePromptInd");
	
	//Fix for PR-424, 793 - Start
	String isMidVoidOrder = "N";
	isMidVoidOrder = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_MID_VOID_ORDER);
	String isPostVoidOrder = "N";
	isPostVoidOrder = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_MID_POST_ORDER);
	//Fix for PR-424, 793 - End
	String itemIdStr = ordLineItemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID);
	
	String extnIsPriceEntered = XMLUtil.getAttribute(extnEle,
			KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);

	Element linePriceInfoEle = XMLUtil.getChildElement(orderLineEle, "LinePriceInfo");
	String unitPriceStr = XMLUtil.getAttribute(linePriceInfoEle,"UnitPrice");
	
	Element itemEle = XMLUtil.createChild(itemListEle, KohlsPOCConstant.ELEM_SMALL_ITEM); 
	Element eleSku = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SKU);
	XMLUtil.setNodeValue(eleSku, itemIdStr);
	Element eleId = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_ID);
	XMLUtil.setNodeValue(eleId, primeLineNo);
	//Element eleTaxCodeIndicator = XMLUtil.createChild(itemEle, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
	//XMLUtil.setNodeValue(eleTaxCodeIndicator, extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE));
	String sTaxCode = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE);
	
	//Fix for Defect 1774 --- Start
		if(YFCCommon.isVoid(sTaxCode)){
			sTaxCode = XMLUtil.getAttribute(ordLineItemEle,KohlsPOCConstant.A_TAX_PRODUCT_CODE);
		} 	
	//Fix for defect 1774 --- End
	
	if(!YFCCommon.isVoid(sTaxCode) && sTaxCode.matches(".*\\d.*")){
		logger.debug("sTaxCode value ::"+sTaxCode);
		Element eleTaxCodeIndicator = XMLUtil.createChild(itemEle, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
		XMLUtil.setNodeValue(eleTaxCodeIndicator,sTaxCode);
	}else {
		logger.debug("else TaxcodeIndicator ::::"+sTaxCode);
		YFSException yfsException = new YFSException();
		yfsException.setErrorCode(KohlsPOCConstant.TAXCODEINDICATORERR);
		yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TAXCODEINDICATORERR));
		throw yfsException;
		
	}
	
	Element eleTaxExempt = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
	String strTaxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
	 if( !YFCCommon.isVoid(strTaxableFlag) && (strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.NO)
			   || strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.OVERRIDE_TAX_O )))
	{
		   XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
		//itemEle.setAttribute(KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.YES);
	}
	else
	{	// Defect fix for 798
		  XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);
		//itemEle.setAttribute(KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.NO);
	}
	    
	   //  Sudina - Change for TVS phase 2 - taxware - End
	    if(extnIsPriceEntered.equalsIgnoreCase(KohlsPOCConstant.YES))
	    {
	    	Element eleRegPrice = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_REGULAR_PRICE);
	    	XMLUtil.setNodeValue(eleRegPrice, unitPriceStr);
	    	//itemEle.setAttribute(KohlsPOCConstant.ATTR_REGULAR_PRICE, unitPriceStr);
	    }
	    //Fix for PR-424 - Start - Adding 0.01 check for PR-528 - Start
	    else if((!YFCCommon.isVoid(isMidVoidOrder)&& KohlsPOCConstant.YES.equalsIgnoreCase(isMidVoidOrder)) || 
	    		(!YFCCommon.isVoid(isPostVoidOrder)&& KohlsPOCConstant.YES.equalsIgnoreCase(isPostVoidOrder)) )
	    {
	    	//PST-4465 - Start
	    	String sExtnSellingPrice = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE);
	    	double regularPrice = KohlsPOCConstant.ZERO_DBL;
	    	Element eleRegPrice = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_REGULAR_PRICE);
	    	if(YFCCommon.isVoid(unitPriceStr) || unitPriceStr.equalsIgnoreCase(KohlsPOCConstant.ZERO_STR) ||
	    			unitPriceStr.equalsIgnoreCase(KohlsPOCConstant.STRING_ONE_CENT)){
		    	regularPrice = calcRegularPriceForPSAVoid(entry,promotionsEle,sExtnSellingPrice); //call to find item regular price  
	    		XMLUtil.setNodeValue(eleRegPrice, twoDForm.format(Math.abs(regularPrice)));
	    		logger.debug("Regular Price is null. Hence setting Selling price for PSA MidVoid. Value is :" 
	    				+XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE));
	    	}else{
	    		regularPrice = calcRegularPriceForPSAVoid(entry,promotionsEle,unitPriceStr);
	    		XMLUtil.setNodeValue(eleRegPrice, twoDForm.format(Math.abs(regularPrice)));
	    		logger.debug("Regular Price is valid. Hence setting unitPriceStr price for PSA MidVoid. Value is :" 
	    				+unitPriceStr);
	    	}
	    }
	    //PST-4465 - End
	    //Fix for PR-424 - End - Adding 0.01 check for PR-528 - End


	   //replacing XPathUtil with XMLUtil - Start
	    
	    List <Element> ndReference = XMLUtil.getElementsByTagName(orderLineEle, KohlsPOCConstant.A_REFERENCE);
	    Element eleEmpDiscCode =null;
	    if(!YFCCommon.isVoid(ndReference) && !ndReference.isEmpty())
		{
			for(Element eleReference : ndReference)
			{	
				if(!YFCCommon.isVoid(eleReference) && ("ExtnEmpDiscCode".equals(eleReference.getAttribute("Name"))))
				{

		    		eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
		    		if(!YFCCommon.isVoid(eleReference.getAttribute(KohlsPOCConstant.A_VALUE))){
						XMLUtil.setNodeValue(eleEmpDiscCode, eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
					}
					else{
						XMLUtil.setNodeValue(eleEmpDiscCode, "S");
					}
				}
			}
			//Start of PST-1269
			eleEmpDiscCode = XMLUtil.getChildElement(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
			if(eleEmpDiscCode==null){
				eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
				XMLUtil.setNodeValue(eleEmpDiscCode, "S");
			}
			//End of PST-1269
			
		} else {
			//1774 - Recycle fee items do not have references element. so getting it from getItemList
			logger.debug("References is empty, calling GetItemList api");
			eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
			Document docGetItemListInput = XMLUtil.createDocument("Item");
			Element eleItemIn = docGetItemListInput.getDocumentElement();
			eleItemIn.setAttribute("ItemID", itemIdStr);
			String sGetItemListTemplate = "<ItemList><Item ItemID=''><Extn ExtnClass='' ExtnDept='' "
					+ "ExtnEmpDiscCode='' ExtnMerchandiseTaxCode='' ExtnSubClass=''/>"
					+ "<ClassificationCodes TaxProductCode=''/></Item></ItemList>";
			// invoking getItemList API
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
				logger.debug("Invoking getItemList API with input as:\n"+
				XMLUtil.getXMLString(docGetItemListInput));
			}
			
			Document docGetItemListOutput = KOHLSBaseApi.invokeAPI(yfsEnv,XMLUtil.getDocument(sGetItemListTemplate),
					KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);
			
			Element eleItemOut = (Element)docGetItemListOutput.getElementsByTagName("Item").item(0);
			if(!(YFCCommon.isVoid(eleItemOut))){
				Element eleItemExtn = XMLUtil.getChildElement(eleItemOut, "Extn");
				String sDiscCode =  eleItemExtn.getAttribute("ExtnEmpDiscCode");
				logger.info("eleEmpDiscCode "+sDiscCode);
				
				//Start of PST-1269
				if(!YFCCommon.isVoid(sDiscCode))
					XMLUtil.setNodeValue(eleEmpDiscCode, sDiscCode);	
				else
					XMLUtil.setNodeValue(eleEmpDiscCode, "S");
				//End of PST-1269
			}
		}
		//replacing XPathUtil with XMLUtil - End
	
//    itemEle.setAttribute(KohlsPOCConstant.ATTR_SKU, itemIdStr);	
//    itemEle.setAttribute(KohlsPOCConstant.ATTR_ID, primeLineNo);
//    //  Sudina - Change for TVS phase 2 - taxware - Start
//    itemEle.setAttribute(KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR, extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE));
//	String strTaxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
//	   if(!YFCCommon.isVoid(strTaxableFlag) && (strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.NO)|| strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.OVERRIDE_TAX_O)))
//	{
//		itemEle.setAttribute(KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.YES);
//	}
//	else
//	{
//		itemEle.setAttribute(KohlsPOCConstant.ATTR_TAX_EXEMPT, KohlsPOCConstant.NO);
//	}
    //  Sudina - Change for TVS phase 2 - taxware - End
//    if(extnIsPriceEntered.equalsIgnoreCase(KohlsPOCConstant.YES))
//    {
//    itemEle.setAttribute(KohlsPOCConstant.ATTR_REGULAR_PRICE, unitPriceStr);
//    }
//    Element eleReference = (Element)KohlsXPathUtil.getNode(orderLineEle, "./References/Reference[@Name='ExtnEmpDiscCode']");
//	 
//	if(!YFCCommon.isVoid(eleReference)){
//		 itemEle.setAttribute(KohlsPOCConstant.ATTR_EMP_DISC_CODE, eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
//	 }
		Element eleScanTime = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SCAN_TIME);
    	
    if(!YFCCommon.isStringVoid(createTS)){
    	XMLUtil.setNodeValue(eleScanTime, createTS);
//    	itemEle.setAttribute(KohlsPOCConstant.ATTR_SCAN_TIME, createTS);
    }
    else {
		YFCDate date = new YFCDate();
		String sCreateTimeStamp = date.getString(null, true);
		XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
//		itemEle.setAttribute(KohlsPOCConstant.ATTR_SCAN_TIME,sCreateTimeStamp);
    }
    //Element promotionsEle = XMLUtil.getChildElement(orderLineEle, "Promotions");
    NodeList nlPromotions = orderLineEle.getElementsByTagName("Promotion");
   // if(!YFCCommon.isVoid(promotionsEle))	    {
    	//List <Element> orderLinePromotionList = XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
    	if (nlPromotions.getLength() > KohlsPOCConstant.ZERO_INT) {
    		for(int i=0; i<nlPromotions.getLength(); i++){
    			
    			//Map<String, Element> orderLineLLDHM = linePromoObj.getOrderLineLLDHM();
				//for (final Map.Entry<String, Element> promoEntry : orderLineLLDHM.entrySet()) {
				//String orderLinPromId = promoEntry.getKey();
				//Element promotionEle =  promoEntry.getValue();
    			Element elePromotion = (Element) nlPromotions.item(i);
    			//System.out.println("Order Line Promotion elementi XML is: \n"+XMLUtil.getElementXMLString(elePromotion));

    			Element eleTemp = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_TEMP);
    			String sID = eleTemp.getAttribute(KohlsPOCConstant.A_ID);
    			String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(elePromotion, createtsList);	
				Element extnPromoEle = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);	
				XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
				Element manualLIDEle = XMLUtil.createChild(itemEle, KohlsPOCConstant.ELE_MANUAL_LID);
				String promotionType = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_TYPE);
				String overrideAdjustmentValue = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
				//manualLIDEle.setAttribute(KohlsPOCConstant.ATTR_ID, sID);
				Element eleID = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_ID);
				XMLUtil.setNodeValue(eleID, sID);
				if(promotionType.equalsIgnoreCase("AMOUNT_OFF"))
				{
					Element eleDollarOff = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_DOLLAR_OFF);
					XMLUtil.setNodeValue(eleDollarOff, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					// manualLIDEle.setAttribute(KohlsPOCConstant.ATTR_DOLLAR_OFF, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				}
				else if(promotionType.equalsIgnoreCase("PERCENT_OFF"))
				{	
				//Added for setting ExtnDiscountPercent -- start
					String extnDiscountPercent = XMLUtil.getAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
					if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
						overrideAdjustmentValue = extnDiscountPercent;
					} else {
						XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					}
				//Added for setting ExtnDiscountPercent -- end
//					manualLIDEle.setAttribute(KohlsPOCConstant.ATTR_PERCENT_OFF, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					Element elePercentOff = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_PERCENT_OFF);
					XMLUtil.setNodeValue(elePercentOff, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				}
				else if(promotionType.equalsIgnoreCase("PRICE_OVERRIDE"))
				{
//					manualLIDEle.setAttribute(KohlsPOCConstant.ATTR_CORRECTED_PRICE, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					Element eleCorrectedPrice = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_CORRECTED_PRICE);
					XMLUtil.setNodeValue(eleCorrectedPrice, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				}
    		}
			//}
    	}
    	
    			//OMNI2 Begin - Add ShipTo ShipFrom and OriginAddr if extnIsOmni=Y
    			if( KohlsPOCConstant.YES.equals(extnIsOmni) &&  KohlsPOCConstant.YES.equals(codeShortDesc)) {
    				String shipNode = orderLineEle.getAttribute(KohlsPOCConstant.ATTR_SHIP_NODE);
    				
    				Element shipToAddress = XMLUtil.createChild(itemEle, KohlsPOCConstant.A_SHIP_TO_ADDR);
    				XMLUtil.setNodeValue(shipToAddress, shipNode);
    				Element shipFromAddress = XMLUtil.createChild(itemEle, KohlsPOCConstant.A_SHIP_FROM_ADDR);
    				XMLUtil.setNodeValue(shipFromAddress, shipNode);
    				Element originAddress = XMLUtil.createChild(itemEle, KohlsPOCConstant.A_ORIGIN_ADDR);
    				XMLUtil.setNodeValue(originAddress, shipNode);
    				
    			}
    			//OMNI2 End - Add ShipTo ShipFrom and OriginAddr if extnIsOmni=Y

    	logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestDocForItem");

	}


//PST-4465 - Start
private double calcRegularPriceForPSAVoid(Entry<String, Element> entry,
		Element promotionsEle, String sUnitPrice) {

	logger.beginTimer("KohlsPoCTVSCaller.calcRegularPriceForPSAVoid");
	Element orderLineEle =  entry.getValue();
	Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
	double totalAwards = KohlsPOCConstant.ZERO_DBL;
	double regularPrice = KohlsPOCConstant.ZERO_DBL;
	String awardAmount = KohlsPOCConstant.BLANK;
	List <Element> AwardsList = XMLUtil.getElementsByTagName(orderLineEle, KohlsPOCConstant.E_AWARDS);
	Element awards = AwardsList.get(0);
	List<Element> awardList =  XMLUtil.getElementsByTagName(awards, KohlsPOCConstant.E_AWARD);

	if (AwardsList.size() > KohlsPOCConstant.ZERO_INT) {
		for(Element awardEle: awardList){

			String awardpromotionId = XMLUtil.getAttribute(awardEle, KohlsPOCConstant.PROMOTIONID);
			Element awardExtn = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.A_EXTN);
			awardAmount = XMLUtil.getAttribute(awardExtn, "ExtnNetDelta");
			if(!YFCCommon.isVoid(awardAmount) && (awardpromotionId.equalsIgnoreCase("760Q_00001") || 
					awardpromotionId.equalsIgnoreCase("760K_00001"))){
				totalAwards += Math.abs(Double.valueOf(awardAmount));
			}
		}
	}

	regularPrice = Math.abs(Double.valueOf(sUnitPrice)) - totalAwards; 
	String tempRegularPrice = twoDForm.format(regularPrice);  

	regularPrice = Double.valueOf(tempRegularPrice);

	logger.endTimer("KohlsPoCTVSCaller.calcRegularPriceForPSAVoid");
	return regularPrice;
}
//PST-4465 - End

/**
 * This Method is used to construct the PSA TVS Request for Item, Manaul LLd, Price Override
 * @param entry
 * @param itemListEle
 * @param yfsEnv
 * @param linePromoObj
 * @param createtsList
 * @throws Exception
 */
private void constructTVSRequestDocForItemPSA(Entry<String, Element> entry,Element itemListEle,YFSEnvironment
		yfsEnv,KohlsPoCTVSOrderLinePromotionCaller linePromoObj,List<String> createtsList,Element promotionsEle)throws Exception {

	logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestDocForItemPSA");

	String primeLineNo = entry.getKey();
	Element orderLineEle =  entry.getValue();
	Element ordLineItemEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_ITEM);
	String createTS = XMLUtil.getAttribute(ordLineItemEle,KohlsPOCConstant.A_CREATE_TS);
	Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
	//Element itemDetailsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_ITEM_DETAILS);
	//Element itemDetailsExtnEle = XMLUtil.getChildElement(itemDetailsEle, KohlsPOCConstant.A_EXTN);

	String itemIdStr = ordLineItemEle.getAttribute(KohlsPOCConstant.A_ITEM_ID);

	//String extnIsPriceEntered = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);

	double regularPrice = calcAwardsAdjustmentsPSANew(entry,promotionsEle); //call to find item regular price

	Element linePriceInfoEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
	//String unitPriceStr = XMLUtil.getAttribute(linePriceInfoEle,"UnitPrice");

	Element itemEle = XMLUtil.createChild(itemListEle, KohlsPOCConstant.ELEM_SMALL_ITEM);
	Element eleSku = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SKU);
	XMLUtil.setNodeValue(eleSku, itemIdStr);
	Element eleId = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_ID);
	XMLUtil.setNodeValue(eleId, primeLineNo);

	//creating merchandise element under item element
	Element EleMerchandise = XMLUtil.createChild(itemEle, KohlsPOCConstant.MERCHANDISE_HIRARCHY);

	String department = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.EXTN_ITEM_DEPT);
	String majorClass = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.EXTN_ITEM_CLASS);
	String subClass = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.EXTN_ITEM_SUB_CLASS);
	String vendorStyle = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.EXTN_VENDOR_STYLE_NO);


	Element deptElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.DEPARTMENT);
	XMLUtil.setNodeValue(deptElement, department);

	Element majorClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.MAJOR_CLASS);
	XMLUtil.setNodeValue(majorClassElement, majorClass);

	Element subClassElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.SUB_CLASS);
	XMLUtil.setNodeValue(subClassElement, subClass);

	Element vendorStyleElement = XMLUtil.createChild(EleMerchandise, KohlsPOCConstant.VENDOR_STYLE);
   if(YFCCommon.isVoid(vendorStyle)){
      vendorStyle = "10";
   }
   XMLUtil.setNodeValue(vendorStyleElement, vendorStyle);

   Element eleTaxCodeIndicator = XMLUtil.createChild(itemEle, KohlsPOCConstant.SMALL_TAX_CODE_INDICATOR);
   XMLUtil.setNodeValue(eleTaxCodeIndicator, extnEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE));
   Element eleTaxExempt = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_TAX_EXEMPT);
   String strTaxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
   if(!YFCCommon.isVoid(strTaxableFlag) && (strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.NO)|| strTaxableFlag.equalsIgnoreCase(KohlsPOCConstant.OVERRIDE_TAX_O))){
         XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.YES);
   }
   else{
        XMLUtil.setNodeValue(eleTaxExempt, KohlsPOCConstant.NO);

   }

 //creating regular price element
   Element eleRegPrice = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_REGULAR_PRICE);
   String regPrice = regularPrice+"";
   XMLUtil.setNodeValue(eleRegPrice, regPrice);

	String SKUStatusCode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_SKU_STATUS_CODE);
	Element regularPriceStatusElement = XMLUtil.createChild(itemEle, KohlsPOCConstant.REGULAR_PRICE_STATUS);
	XMLUtil.setNodeValue(regularPriceStatusElement, SKUStatusCode);

	String isDiscountable = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.EXTN_IS_DISCOUNTABLE);
	logger.debug("isDiscountable state before conversion is :"+isDiscountable);

	if(KohlsPOCConstant.YES.equalsIgnoreCase(isDiscountable)){
		isDiscountable = KohlsPOCConstant.NO;
	}
	else if(KohlsPOCConstant.NO.equalsIgnoreCase(isDiscountable)){
		isDiscountable = KohlsPOCConstant.YES;
	}

	//PSA changes
	/*Element discountableFlag = XMLUtil.createChild(itemEle,KohlsPOCConstant.NON_DISCOUNTABLE_FLAG);
	XMLUtil.setNodeValue(discountableFlag, isDiscountable);*/

	Element eleEmpDiscCode=null;
	String sDiscCode=KohlsPOCConstant.CONST_S;
    Element eleReference = (Element)KohlsXPathUtil.getNode(orderLineEle, "./References/Reference[@Name='ExtnEmpDiscCode']");

	if(!YFCCommon.isVoid(eleReference)){
		eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
    	if(!YFCCommon.isVoid(eleReference.getAttribute(KohlsPOCConstant.A_VALUE))){
			XMLUtil.setNodeValue(eleEmpDiscCode, eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
		}
		else{
			XMLUtil.setNodeValue(eleEmpDiscCode, KohlsPOCConstant.CONST_S);
		}
	 }else {
			//1774 - Recycle fee items do not have references element. so getting it from getItemList
		 	logger.debug("References is empty, calling GetItemList api");
		 	eleEmpDiscCode = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
		 	Document docGetItemListInput = XMLUtil.createDocument("Item");
			Element eleItemIn = docGetItemListInput.getDocumentElement();
			eleItemIn.setAttribute("ItemID", itemIdStr);
			String sGetItemListTemplate = "<ItemList><Item ItemID=''><Extn ExtnClass='' ExtnDept='' "
					+ "ExtnEmpDiscCode='' ExtnMerchandiseTaxCode='' ExtnSubClass=''/>"
					+ "<ClassificationCodes TaxProductCode=''/></Item></ItemList>";
			// invoking getItemList API
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
				logger.debug("Invoking getItemList API with input as:\n"+
				XMLUtil.getXMLString(docGetItemListInput));
	 }
			Document docGetItemListOutput = KOHLSBaseApi.invokeAPI(yfsEnv,XMLUtil.getDocument(sGetItemListTemplate),
					KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);
			Element eleItemOut = (Element)docGetItemListOutput.getElementsByTagName("Item").item(0);
			if(!(YFCCommon.isVoid(eleItemOut))){
				Element eleItemExtn = XMLUtil.getChildElement(eleItemOut, "Extn");
				sDiscCode =  eleItemExtn.getAttribute("ExtnEmpDiscCode");
				logger.debug("eleEmpDiscCode "+sDiscCode);
			XMLUtil.setNodeValue(eleEmpDiscCode, sDiscCode);	
			}
	 }
		 

	//PSA changes
   Element eleScanTime = XMLUtil.createChild(itemEle, KohlsPOCConstant.ATTR_SCAN_TIME);

    if(!YFCCommon.isStringVoid(createTS)){
      XMLUtil.setNodeValue(eleScanTime, createTS);
    }
    else {
      YFCDate date = new YFCDate();
      String sCreateTimeStamp = date.getString(null, true);
      XMLUtil.setNodeValue(eleScanTime, sCreateTimeStamp);
    }

    /*NodeList nlPromotions = orderLineEle.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    	if (nlPromotions.getLength() > KohlsPOCConstant.ZERO_INT) {
    		for(int i=0; i<nlPromotions.getLength(); i++){
    			Element elePromotion = (Element) nlPromotions.item(i);
    			Element eleTemp = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_TEMP);
    			String sID = eleTemp.getAttribute(KohlsPOCConstant.A_ID);
    			String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(elePromotion, createtsList);
				Element extnPromoEle = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
				XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
				Element manualLIDEle = XMLUtil.createChild(itemEle, KohlsPOCConstant.ELE_MANUAL_LID);
				String promotionType = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_TYPE);
				String overrideAdjustmentValue = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
				Element eleID = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_ID);
				XMLUtil.setNodeValue(eleID, sID);
				if(promotionType.equalsIgnoreCase(KohlsPOCConstant.AMOUNT_OFF))
				{
					Element eleDollarOff = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_DOLLAR_OFF);
					XMLUtil.setNodeValue(eleDollarOff, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				}
				else if(promotionType.equalsIgnoreCase(KohlsPOCConstant.PERCENT_OFF))
				{
				//Added for setting ExtnDiscountPercent -- start
					String extnDiscountPercent = XMLUtil.getAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
					if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
						overrideAdjustmentValue = extnDiscountPercent;
					} else {
						XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					}
				//Added for setting ExtnDiscountPercent -- end
					Element elePercentOff = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_PERCENT_OFF);
					XMLUtil.setNodeValue(elePercentOff, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				}
				else if(promotionType.equalsIgnoreCase(KohlsPOCConstant.PRICE_OVERRIDE))
				{
					Element eleCorrectedPrice = XMLUtil.createChild(manualLIDEle, KohlsPOCConstant.ATTR_CORRECTED_PRICE);
					XMLUtil.setNodeValue(eleCorrectedPrice, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				}
    		}

    	}*/

    	logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestDocForItemPSA");

	}



/**
 * calcAwardsAdjustmentsPSA is the method to find regular price of Item by excluding awards amounts of various categories
 *
 * For each orderLine level award
 * Check the promotion Id and get the promotion type based on promotion id
 * if any one of the promotion category in PERCENT_OFF|| SENIOR_DISCOUNT || ASSOCIATE_DISCOUNT ||(OFFER && precedence = ?38? or ?39?) || (LEGACY_COUPON && precedence = ?40?)
 * Then consider the Award amount given for the order line and accumulate to totalAwards.
 *
 * @param entry
 * @return total awards given for the orderLine
 */
private double calcAwardsAdjustmentsPSA(Entry<String, Element> entry,Element promotionsEle){

   logger.beginTimer("KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");

   Element orderLineEle =  entry.getValue();
   Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
   String extnNetPrice = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.A_EXTN_NET_PRICE);
   double totalAwards = KohlsPOCConstant.ZERO_DBL;
   double regularPrice = KohlsPOCConstant.ZERO_DBL;
   String awardAmount = KohlsPOCConstant.BLANK;
   List <Element> AwardsList = XMLUtil.getElementsByTagName(orderLineEle, KohlsPOCConstant.E_AWARDS);

   Element awards = AwardsList.get(0);

   List<Element> awardList =  XMLUtil.getElementsByTagName(awards, KohlsPOCConstant.E_AWARD);

   if (AwardsList.size() > KohlsPOCConstant.ZERO_INT) {
      for(Element awardEle: awardList){

         String awardpromotionId = XMLUtil.getAttribute(awardEle, KohlsPOCConstant.PROMOTIONID);
         Element awardExtn = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.A_EXTN);
         String extnPromotionFlag = null;
         String extnDiscountPercent = null; //CPE-6061
         String isPSAPromotion = null;
         String discountType = KohlsPOCConstant.BLANK;
         String precedence = KohlsPOCConstant.BLANK;
         String sDiscountTypeReason = KohlsPOCConstant.BLANK;
         List <Element> orderPromotionList = XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
         String promoId;

         for(Element promotion : orderPromotionList){
            promoId = XMLUtil.getAttribute(promotion, KohlsPOCConstant.PROMOTIONID);

            if(promoId.equalsIgnoreCase(awardpromotionId)){
               Element promotionExtn = XMLUtil.getChildElement(promotion, KohlsPOCConstant.A_EXTN);
               extnPromotionFlag = XMLUtil.getAttribute(promotionExtn,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG); // check whether offer applied or new
               extnDiscountPercent = XMLUtil.getAttribute(promotionExtn,KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT); // check Discount percentage for CPE-6061
               isPSAPromotion = XMLUtil.getAttribute(promotionExtn,KohlsPOCConstant.ISPSAPROMOTION);  // check psa promotion applied or new
               sDiscountTypeReason = XMLUtil.getAttribute(awardExtn,"ExtnDiscountReasonCode")+XMLUtil.getAttribute(awardExtn,"ExtnDiscountTypeCode");
               discountType = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_PROMOTION_TYPE);
               break;
            }
         }

		  if(extnPromotionFlag!=null && isPSAPromotion!=null){
			if((extnPromotionFlag.equalsIgnoreCase(KohlsPOCConstant.BLANK) && isPSAPromotion.equalsIgnoreCase(KohlsPOCConstant.BLANK))
				  || (extnPromotionFlag.equalsIgnoreCase(KohlsPOCConstant.YES) && isPSAPromotion.equalsIgnoreCase(KohlsPOCConstant.YES))) {
			  //Changes for defect 3129- Start
				awardAmount = XMLUtil.getAttribute(awardExtn, "ExtnNetDelta");
				//Changes for defect 3129- End
			   if(!YFCCommon.isVoid(awardAmount)){
				  totalAwards += Math.abs(Double.valueOf(awardAmount));
				  continue;
			   }
		   }
		 }


         if(discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER)||discountType.equalsIgnoreCase(KohlsPOCConstant.LEGACY_COUPON)){
            String salesHubClob = XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);

            if(!YFCCommon.isVoid(salesHubClob)){
               Element salesHubDataEle = null;
               try {
                  salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
               } catch (ParserConfigurationException e) {
                  logger.error("ParserConfigurationException at KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
               } catch (SAXException e) {
                  logger.error("SAXException at KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
               } catch (IOException e) {
                  logger.error("IOException at KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
               }

               if(!YFCCommon.isVoid(salesHubDataEle)){
                  precedence = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_PRECEDENCE);
               }
            }
         }
//PST-2918 - Adding precedence 38, 39 check for TLD %Off Offer
         if(!YFCCommon.isVoid(discountType)){
             if(discountType.equalsIgnoreCase(KohlsPOCConstant.PERCENT_OFF)||
                   discountType.equalsIgnoreCase(KohlsPOCConstant.SENIOR_DISCOUNT) ||
                            discountType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)||
                             (discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER) && (!YFCCommon.isVoid(extnDiscountPercent) 
                             		|| precedence.equalsIgnoreCase("38") || precedence.equalsIgnoreCase("39")))||
                               (discountType.equalsIgnoreCase(KohlsPOCConstant.LEGACY_COUPON)&& precedence.equalsIgnoreCase("40")) ||
                               (sDiscountTypeReason.equalsIgnoreCase("760Q")) || (sDiscountTypeReason.equalsIgnoreCase("761I"))) {
 
            	//Changes for defect 3129- Start
            	awardAmount = XMLUtil.getAttribute(awardExtn, "ExtnNetDelta");
            	//Changes for defect 3129- End
               if(!YFCCommon.isVoid(awardAmount)){
                  totalAwards += Math.abs(Double.valueOf(awardAmount));
                  }
               }
            }
         }
      }
	if(YFCCommon.isVoid(extnNetPrice) || extnNetPrice.equalsIgnoreCase(KohlsPOCConstant.EMPTY))
	{
		   extnNetPrice="0.0";
	}

      regularPrice = Math.abs(Double.valueOf(extnNetPrice)) + totalAwards;

      DecimalFormat df = new DecimalFormat("0.00");
      String tempRegularPrice = df.format(regularPrice);

      regularPrice = Double.valueOf(tempRegularPrice);

      logger.endTimer("KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
      this.logger.debug("Method Name : calcAwardsAdjustmentsPSA   and   Status : End ");
      return regularPrice;
}

/** This method is used construct the TVS Request for TLD.
 *
 * @param entry
 * @param transactionEle
 * @param tempOrderEle
 * @param yfsEnv 
 * @param createtsList
 * @param orderPromoObj
 */
//Added offersEle as an argument for defect 5350 fix 
private void constructTVSRequestDocForTLD(Entry<String, Element> entry,Element transactionEle,Element tempOrderEle,YFSEnvironment yfsEnv,List<String> createtsList,KohlsPoCTVSOrderPromotionsCaller orderPromoObj,Element offersEle) throws Exception
{
	
	logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestDocForTLD");
	
	String ordPromotionID = entry.getKey();
	Element promotionEle =  entry.getValue();
	String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
	
	
	 // Suresh : Added for TLD pushdown : Start	
	if(logger.isDebugEnabled()){
		logger.debug("promotionEle ::"+XMLUtil.getElementXMLString(promotionEle));
		logger.debug("CreatetsList ::"+createtsList);
	}
	 

	Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);    
	//Fix for PR-688 - Start
	String isPSAPromotionFlag = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.ISPSAPROMOTION);
	//Fix for PR-688 - End
    String sequenceNumber = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE);
	logger.debug("sequenceNumber  ::"+sequenceNumber);
	if(YFCCommon.isVoid(sequenceNumber) || sequenceNumber.equals("")){
		logger.debug("sequenceNumber set with createts");
        sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(promotionEle, createtsList);   
		logger.debug("sequenceNumber  ::"+sequenceNumber);		
        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
    }

	 // Suresh : Added for TLD pushdown : End
	String extnOffLineMode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
	String isMgrOverrideProvided = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_MANAGER_OVERRIDE_PROVIDED);
	logger.debug("isMgrOverrideProvided  ::"+isMgrOverrideProvided);		
	
		if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType))
		{
			Element manualTLDEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
//			XMLUtil.setAttribute(manualTLDEle,KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);		
//			manualTLDEle.setAttribute(KohlsPOCConstant.ATTR_ID, ordPromotionID);
			Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
			XMLUtil.setNodeValue(elePromoId,ordPromotionID);
			Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
			XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
		
			
		String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
		
		if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
			overrideAdjustmentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT);
			//MidVoid Changes
			if(!YFCCommon.isStringVoid( overrideAdjustmentValue )){
				overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
			}
			Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
			XMLUtil.setNodeValue(eleMarkDownValue,overrideAdjustmentValue);
			Element eleDiscountType = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
			XMLUtil.setNodeValue(eleDiscountType, KohlsPOCConstant.MANUAL_DOLLAR_OFF);
//			XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_DOLLAR_OFF);
			

		} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
			overrideAdjustmentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
			//MidVoid Changes
			if(!YFCCommon.isStringVoid( overrideAdjustmentValue )){
				overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue) / KohlsPOCConstant.HUNDRED_INT));
			}
			Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
			XMLUtil.setNodeValue(eleMarkDownValue,overrideAdjustmentValue);
			Element eleDiscountType = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
			XMLUtil.setNodeValue(eleDiscountType, KohlsPOCConstant.MANUAL_PERCENT_OFF);
//			XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_PERCENT_OFF);
			
		}
//		XMLUtil.setAttribute(manualTLDEle,  KohlsPOCConstant.ATTR_MARK_DOWN_VALUE, overrideAdjustmentValue);
//		XMLUtil.setAttribute(manualTLDEle,  KohlsPOCConstant.ATT_GIFT, KohlsPOCConstant.NO);
//		XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR, "None");
		Element eleGift = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATT_GIFT);
		XMLUtil.setNodeValue(eleGift,KohlsPOCConstant.NO);
		Element eleIEIndicator = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR);
		XMLUtil.setNodeValue(eleIEIndicator,"None");
		}
		
		else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
			
			Element manualTLDEle = XMLUtil.createChild(transactionEle,KohlsPOCConstant.ELE_MANUAL_TLD);
			Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
			XMLUtil.setNodeValue(elePromoId,ordPromotionID);
			Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
			XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
//			XMLUtil.setAttribute(manualTLDEle,KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);		
//			
//			manualTLDEle.setAttribute(KohlsPOCConstant.ATTR_ID, ordPromotionID);
			
			extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
			Element SeniorCitizenResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));

			List<Element> rulesEleList = XMLUtil.getElementsByTagName(SeniorCitizenResposneEle, KohlsPOCConstant.E_RULE);
			String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE;
			String ruleValue = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,tempOrderEle,ruleId);
			String percentValue = null;
			if(!YFCCommon.isVoid(ruleValue) || !rulesEleList.isEmpty()){
				percentValue = String.valueOf(Double.valueOf(ruleValue)/KohlsPOCConstant.HUNDRED_INT);
			} else {
				percentValue = String.valueOf(Double.valueOf(KohlsPOCConstant.DEFAULT_SENIOR_DISCOUNT_PERCENT)/KohlsPOCConstant.HUNDRED_INT);
			}
			Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
			XMLUtil.setNodeValue(eleMarkDownValue,percentValue);
			Element eleDiscountType = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
			XMLUtil.setNodeValue(eleDiscountType,KohlsPOCConstant.SENIOR_CITIZEN_DISCOUNT);
//			XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE, percentValue);
//			XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE, KohlsPOCConstant.SENIOR_CITIZEN_DISCOUNT);
		
		}
		else if(KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType) || KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType) )
		{
			//Fix for PR-688 - Start
			if(!("V".equalsIgnoreCase(isPSAPromotionFlag))){
			//Fix for PR-688 - End
			if(!KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode))
			{
				Element manualTLDEle = XMLUtil.createChild(transactionEle,KohlsPOCConstant.ELE_MANUAL_TLD);
				
//				XMLUtil.setAttribute(manualTLDEle,KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);						
//				manualTLDEle.setAttribute(KohlsPOCConstant.ATTR_ID, ordPromotionID);
				Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
				XMLUtil.setNodeValue(elePromoId,ordPromotionID);
				Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
				XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
				constructTVSRequestFromKohlsCashResponse(promotionEle,manualTLDEle,createtsList);
			}else{
				if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType))
				{
					Element manualTLDEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
		//			XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);
		//
		//			manualTLDEle.setAttribute(KohlsPOCConstant.ATTR_ID, ordPromotionID);
					Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
					XMLUtil.setNodeValue(elePromoId,ordPromotionID);
					Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
					XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
					constructTVSRequestFromOfflineKohlsCashResponse(promotionEle,manualTLDEle,createtsList);
				}
			}
		}//Closing If block for PR-688
		}
		//Fix for PR-688 - Adding condition to check If KCS Is redeemed in PSA and same is not sent to TVS in case of PSA Post voide
		else if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)&&(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)) && !("V".equalsIgnoreCase(isPSAPromotionFlag)))
		{
			Element manualTLDEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
//			XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);		
//			
//			manualTLDEle.setAttribute(KohlsPOCConstant.ATTR_ID, ordPromotionID);
			Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
			XMLUtil.setNodeValue(elePromoId,ordPromotionID);
			Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
			XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
			constructTVSRequestFromOfflineKohlsCashResponse(promotionEle,manualTLDEle,createtsList);
			}
		else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))
				{
					Element manualTLDEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
//					XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);		
//			
//					manualTLDEle.setAttribute(KohlsPOCConstant.ATTR_ID, ordPromotionID);
					Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
					XMLUtil.setNodeValue(elePromoId,ordPromotionID);
					Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
					XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
					constructTVSRequestFromAssociateResponse(yfsEnv,ordPromotionID, tempOrderEle,manualTLDEle,createtsList,orderPromoObj);
				}
		else if(KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType))
		{
		//Commented below stmt for defect 5350 fix
			//Element offersEle = XMLUtil.createChild(transactionEle,  KohlsPOCConstant.ELEM_OFFERS);
			String promotionID = promotionEle.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
//			offerEle.setAttribute(KohlsPOCConstant.ATTR_OFFER_ID, promotionID.substring(0,5));
//			offerEle.setAttribute(KohlsPOCConstant.ATTR_OVERRIDE_FLAG, KohlsPOCConstant.NO);
//			offerEle.setAttribute(KohlsPOCConstant.ATTR_SCAN_ORDER, sequenceNumber);
			//PST-4465 - Start - Excluding 760Q and 760K POS TLD Offers during Mid and Post Void of PSA
			if(!YFCCommon.isVoid(promotionID) && !(promotionID.equalsIgnoreCase("760Q_00001") || 
					promotionID.equalsIgnoreCase("760K_00001"))){
				//PST-4465 - End
				Element offerEle = XMLUtil.createChild(offersEle, KohlsPOCConstant.ELEM_OFFER);
				Element eleOfferId = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_OFFER_ID);	
				if(KohlsPoCPnPUtil.isSUPC(promotionID)){
					XMLUtil.setNodeValue(eleOfferId,promotionID);
				}else{
					XMLUtil.setNodeValue(eleOfferId,promotionID.substring(0,5));
				}
				Element eleScanOrder = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
				XMLUtil.setNodeValue(eleScanOrder, sequenceNumber);
				Element eleOverrideFlag = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_OVERRIDE_FLAG);
				if(isMgrOverrideProvided == null || isMgrOverrideProvided.isEmpty()){
					logger.debug("Setting No for Manager Override  ::");
					XMLUtil.setNodeValue(eleOverrideFlag,KohlsPOCConstant.NO);
				}else{
					logger.debug("Setting isMgrOverrideProvided  ::"+isMgrOverrideProvided);
					XMLUtil.setNodeValue(eleOverrideFlag,isMgrOverrideProvided);
				}
			}	
			
			
		}
	}
	
		/**
	 * This method constructs the TVS request for KohlsCash Response for LEGACY and KOHLSCASH
	 * @param promotionEle
	 * @param manualTLDEle
	 * @param createtsList
	 * @throws ParserConfigurationException indicates a serious configuration error
	 * @throws SAXException encapsulates a general SAX error or warning
	 * @throws IOException indicates that an I/O exception of some sort has occurred
	 */ 	
	private void constructTVSRequestFromKohlsCashResponse(Element promotionEle, Element manualTLDEle, List<String> createtsList) throws ParserConfigurationException, SAXException, IOException {
		logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestFromKohlsCashResponse");

		this.logger.debug("Method Name : constructTVSRequestFromKohlsCashResponse   and   Status : Start ");

		
		String promotionType = XMLUtil.getAttribute(promotionEle, "PromotionType");
		
		
		Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN);
		String extnOffLineMode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);

		Element tempEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP,Boolean.TRUE);
		Element kohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
		List<Element> dataEleList = XMLUtil.getElementsByTagName(kohlsCashResposneEle, KohlsPOCConstant.E_DATA);
		
		Element eleMarkDownValue=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
		
		Element eleDiscountType=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
		
		Element eleLegacyFlag=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_LEGACY_FLAG);
		
		Element eleGift=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATT_GIFT);
		if(dataEleList.size() > KohlsPOCConstant.ZERO_INT && null != dataEleList.get(KohlsPOCConstant.ZERO_INT)){
			Element dataElement = dataEleList.get(KohlsPOCConstant.ZERO_INT);
			String legacyDoller = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
			String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
			String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
			String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
			String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
			String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
			String includeExcludeFlag = dataElement.getAttribute(KohlsPOCConstant.A_INCLUDE_ENCLUDE_FLAG);
			if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
				 // Suresh : Added for TLD pushdown : Start
				/*String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(promotionEle, createtsList);				
				XMLUtil.setAttribute(manualTLDEle,KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);				
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);*/
				 // Suresh : Added for TLD pushdown : End
				
				if(!YFCCommon.isStringVoid(legacyDoller)){
				XMLUtil.setNodeValue(eleMarkDownValue,legacyDoller);
				XMLUtil.setNodeValue(eleDiscountType,KohlsPOCConstant.MANUAL_DOLLAR_OFF);
					// Start: Defect 3284 Fix : Suresh, 
					// setting legacyDollar (Actual amount) to ExtnCouponAmount,used to form description
					extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,legacyDoller);
					// End :  Defect 3284 Fix : Suresh
					
					
				}else if(!YFCCommon.isStringVoid(legacyPercent)){
					legacyPercent = String.valueOf(Math.abs(Double.valueOf(legacyPercent)/KohlsPOCConstant.HUNDRED_INT));
					XMLUtil.setNodeValue(eleMarkDownValue,legacyPercent);
					//Fix for defect 910 - Start
					XMLUtil.setNodeValue(eleDiscountType,KohlsPOCConstant.MANUAL_PERCENT_OFF);
					//Fix for defect 910 - End
					extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT,legacyPercent);

				}
				XMLUtil.setNodeValue(eleLegacyFlag, KohlsPOCConstant.YES);
				XMLUtil.setNodeValue(eleGift,KohlsPOCConstant.NO);
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.NO);
			}else if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)&&(!KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)))
			{
			if(KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
					&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
					&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL){
				 // Suresh : Added for TLD pushdown : Start
				/*String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(promotionEle, createtsList);
				XMLUtil.setAttribute(manualTLDEle,KohlsPOCConstant.A_SCANNED_SEQUENCE,sequenceNumber );
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);*/
				 // Suresh : Added for TLD pushdown : End
				
				
				XMLUtil.setNodeValue(eleMarkDownValue,couponBalance);
				XMLUtil.setNodeValue(eleDiscountType, KohlsPOCConstant.MANUAL_DOLLAR_OFF);
				XMLUtil.setNodeValue(eleLegacyFlag,KohlsPOCConstant.YES);
				XMLUtil.setNodeValue(eleGift,KohlsPOCConstant.YES);
				
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.YES);
				
				// Start: Defect 3284 Fix : Suresh, 
				// setting couponBalance (Actual amount) to ExtnCouponAmount,used to form description
				extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,couponBalance);
				// End :  Defect 3284 Fix : Suresh
			}
			}
			


			List<Element> eventDeptEleList = XMLUtil.getElementsByTagName(kohlsCashResposneEle, KohlsPOCConstant.E_EVENT_DEPARTMENT);

			if(!YFCCommon.isVoid(manualTLDEle)){
				//Fix for defect 808 - Start
				Element eleIEIndicator = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR);
				if(eventDeptEleList.size() > KohlsPOCConstant.ZERO_INT){
					if(KohlsPOCConstant.ZERO.equalsIgnoreCase(includeExcludeFlag)){
						//XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR, KohlsPOCConstant.EXCLUDE);
						XMLUtil.setNodeValue(eleIEIndicator,KohlsPOCConstant.EXCLUDE);
					}else if(KohlsPOCConstant.STRING_ONE.equalsIgnoreCase(includeExcludeFlag)){
						//XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR, KohlsPOCConstant.INCLUDE);
						XMLUtil.setNodeValue(eleIEIndicator,KohlsPOCConstant.INCLUDE);
					}
					Element departmentsEle = XMLUtil.createChild(manualTLDEle,"departments");
					for(Element eventDept :  eventDeptEleList){
						Element deptEle = XMLUtil.createChild(departmentsEle,"dept");
						XMLUtil.setNodeValue(deptEle,XMLUtil.getAttribute(eventDept, KohlsPOCConstant.A_EVENT_DEPARTMENT));
						//departmentsEle.setAttribute("dept", XMLUtil.getAttribute(eventDept, KohlsPOCConstant.A_EVENT_DEPARTMENT));
					}
					// Defect fix: 2632 , if Departmentlist is empty, IEIndicator should be set as None
				}else{
					//XMLUtil.setAttribute(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR, "None");
					XMLUtil.setNodeValue(eleIEIndicator,"None");
				}
			}
			//Fix for defect 808 - End

		}
		this.logger.debug("Method Name : constructTVSRequestFromKohlsCashResponse   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructTVSRequestFromKohlsCashResponse");

	}

	
	/**
	 * This method constructs the TVS request for KohlsCash Offline Mode
	 * @param Element promotionEle
	 * @param Element manualTLDEle
	 * @param List<String> createtsList
	 */ 
	private void constructTVSRequestFromOfflineKohlsCashResponse(
			Element promotionEle, Element manualTLDEle,
			List<String> createtsList) {
		logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestFromOfflineKohlsCashResponse");
		this.logger.debug("Method Name : constructTVSRequestFromOfflineKohlsCashResponse   and   Status : Start ");
		Element tempEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP,Boolean.TRUE);

		Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
		String extnCouponAmount = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);

		 // Suresh : Added for TLD pushdown : Start
		
		Element eleMarkDownValue=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
		
		Element eleDiscountType=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
		
		Element eleLegacyFlag=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_LEGACY_FLAG);
		
		Element eleGift=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATT_GIFT);
		
		Element eleIEIndicator=XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR);
		
		/*String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(manualTLDEle, createtsList);		
		XMLUtil.setAttribute(manualTLDEle,KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);		
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);*/
		 // Suresh : Added for TLD pushdown : End

			XMLUtil.setNodeValue(eleMarkDownValue,extnCouponAmount)		;
			XMLUtil.setNodeValue(eleDiscountType,KohlsPOCConstant.MANUAL_DOLLAR_OFF);
			XMLUtil.setNodeValue(eleLegacyFlag,KohlsPOCConstant.YES);
			XMLUtil.setNodeValue(eleGift,KohlsPOCConstant.YES);
			XMLUtil.setNodeValue(eleIEIndicator,"None");


		// Fix for Defect 2496 , changed IE Indicator to None, to control <Departments/> in the APE request
		//XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_IE_INDICATOR, KohlsPOCConstant.EXCLUDE);
		XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.YES);
		
		this.logger.debug("Method Name : constructTVSRequestFromOfflineKohlsCashResponse   and   Status : End ");
		logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestFromOfflineKohlsCashResponse");


	}
	
	/**
	 * This Method is used to construct Associate related TVS Request
	 * 
	 * @param yfsEnv
	 * @param ordPromotionID
	 * @param tempOrderEle
	 * @param manualTLDEle
	 * @param createtsList
	 * @param orderPromoObj
	 * @throws Exception
	 */
	private void constructTVSRequestFromAssociateResponse(YFSEnvironment yfsEnv,String ordPromotionID,Element tempOrderEle, Element manualTLDEle, List<String> createtsList,KohlsPoCTVSOrderPromotionsCaller orderPromoObj) throws Exception {
		logger.beginTimer("KohlsPoCAPECaller.constructTVSRequestFromAssociateResponse");
		
		Element eleMarkDownValue=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
		Element eleSecondaryMarkDownValue=XMLUtil.createChild(manualTLDEle,KohlsPOCConstant.ATTR_SECONDARY_MARK_DOWN_VALUE);
		Element eleDiscountType=XMLUtil.createChild(manualTLDEle,"discountType");
		
		
				// call the KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle) to get the business date value.
				String markdown = KohlsPOCConstant.EMPTY;
				String secondaryMarkdownValue = KohlsPOCConstant.EMPTY;
				String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;				
				
				//Changes for PR-103 -- Start - POC Returns Team
				/*
				 * Issue: Associate Discount trying to BusinessDay by using TillStatus, 
				 * but in case of POS, those SellerOrganizationCode is invalid or Till is still not opened for that
				 * Organization. See Similar defect HPQC #2979
				 * Fix: Use OrderDate instead of BusinessDay to extract the required values
				 */
				String strDiscountValueFromUtil = KohlsPOCConstant.BLANK;
				Element eleOrderExtn = (Element) tempOrderEle.getElementsByTagName("Extn").item(0);
				if(!YFCCommon.isVoid(eleOrderExtn)){
					if(YFCLogUtil.isDebugEnabled()){
						logger.debug("KohlsPoCTVSCaller.constructTVSRequestFromAssociateResponse Order Extn="+XMLUtil.getElementXMLString(eleOrderExtn));
					}
					String strExtnPsaStatus = eleOrderExtn.getAttribute("ExtnPsaStatus");
					//If PSA, use PSA function
					if((!YFCCommon.isStringVoid(strExtnPsaStatus)) && (strExtnPsaStatus.equals("IN_PROGRESS"))){
						strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydatePSA(yfsEnv,tempOrderEle,ruleId).trim();
					}
				}
				//If its Still Blank then its not PSA, Its Sale
				if(strDiscountValueFromUtil.equals(KohlsPOCConstant.BLANK)){
					strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,tempOrderEle,ruleId).trim();
				}
				//Changes for PR-103 -- End - POC Returns Team
				String [] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
				int length1 = delimitedComma[0].length() - 1;
				int length2 = delimitedComma[1].length() - 1;
				markdown= String.valueOf(Double.valueOf(delimitedComma[0].substring(0,length1)) / KohlsPOCConstant.HUNDRED_INT);
				secondaryMarkdownValue= String.valueOf(Double.valueOf(delimitedComma[1].substring(0,length2)) / KohlsPOCConstant.HUNDRED_INT);
				XMLUtil.setNodeValue(eleMarkDownValue,markdown);
				XMLUtil.setNodeValue(eleSecondaryMarkDownValue,secondaryMarkdownValue);
				XMLUtil.setNodeValue(eleDiscountType,KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE);
				orderPromoObj.setOrderAssociateHM(ordPromotionID,markdown,secondaryMarkdownValue);
				logger.endTimer("KohlsPoCTVSCaller.constructTVSRequestFromAssociateResponse");
	}


/**
 * This method is used construct the TVS Request for TLD of PSA.
 *
 * @param entry
 * @param transactionEle
 * @param tempOrderEle
 * @param yfsEnv
 * @param createtsList
 * @param orderPromoObj
 */
@SuppressWarnings("rawtypes")
private void constructTVSRequestDocForTLDPSA(Entry<String, Element> entry,Element transactionEle,Element tempOrderEle,YFSEnvironment yfsEnv,List<String> createtsList,KohlsPoCTVSOrderPromotionsCaller orderPromoObj,Element tempMaualTldList, int offerID) throws Exception
{

	logger.beginTimer("KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");

	String ordPromotionID = entry.getKey();
	Element promotionEle =  entry.getValue();

	String promotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.PROMOTIONID);

	Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

	String extnPromotionFlag = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
	String isPsaPromotion = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION);
	Map<String,Map> promoDiscMap = new HashMap<String,Map>();

	if(!YFCCommon.isVoid(extnPromotionFlag) && YFCCommon.isVoid(isPsaPromotion)){
		 generatePromoDiscMap(tempOrderEle,promotionId,promoDiscMap);
	}

	String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
	if(logger.isDebugEnabled()){
	logger.debug("promotionEle ::"+XMLUtil.getElementXMLString(promotionEle));
	logger.debug("CreatetsList ::"+createtsList);
	}

    String sequenceNumber = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE);
	logger.debug("sequenceNumber  ::"+sequenceNumber);
	if(YFCCommon.isVoid(sequenceNumber) || sequenceNumber.equals(KohlsPOCConstant.BLANK)){
		logger.debug("sequenceNumber set with createts");
        sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(promotionEle, createtsList);
		logger.debug("sequenceNumber  ::"+sequenceNumber);
        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
    }



	String extnOffLineMode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
	String isMgrOverrideProvided = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_MANAGER_OVERRIDE_PROVIDED);
	logger.debug("isMgrOverrideProvided  ::"+isMgrOverrideProvided);

		//Fix for defect 4086 - Adding Quick_Credit in the condition check
		if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)
				|| KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){

			Element manualTLDEle = null;
			//order/promotions/extn/@ExtnPromotionFlag and @isPsaPromotion are the deciding parameter between new promotion or existing promotion
			// if ExtnPromotionFlag=="Y" && isPsaPromotion == "Y" then its PSA FLOW
			// if ExtnPromotionFlag=="" && isPsaPromotion == "" then its PSA FLOW

			if((!YFCCommon.isStringVoid(extnPromotionFlag) && !YFCCommon.isStringVoid(isPsaPromotion))
					|| (YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion))){
			   Element adjustment = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ADJUSTMENS,true);
            manualTLDEle = XMLUtil.createChild(adjustment, KohlsPOCConstant.ADJUSTMENTMANUALTLD);
            XMLUtil.setAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION, KohlsPOCConstant.YES);
            XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG,KohlsPOCConstant.YES);
			}
			//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
			//Fix for defect 4086 - Adding Quick_Credit in the condition check
			if(KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){
				if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)){
				 //manualTLDEle = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD,true);
               manualTLDEle = XMLUtil.createChild(tempMaualTldList, KohlsPOCConstant.ELE_MANUAL_TLD);
				}
			}
			if(null!=manualTLDEle){
				Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
				XMLUtil.setNodeValue(elePromoId,ordPromotionID);
				Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
				XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);

		String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;

		if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
			overrideAdjustmentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT);
			if(!YFCCommon.isStringVoid(overrideAdjustmentValue)){
            overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
         }
			Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
			XMLUtil.setNodeValue(eleMarkDownValue,overrideAdjustmentValue);
			Element eleDiscountType = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
			XMLUtil.setNodeValue(eleDiscountType, KohlsPOCConstant.MANUAL_DOLLAR_OFF);


		} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
			overrideAdjustmentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
			if(!YFCCommon.isStringVoid(overrideAdjustmentValue)){
            overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue) / KohlsPOCConstant.HUNDRED_INT));
         }
			Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
			XMLUtil.setNodeValue(eleMarkDownValue,overrideAdjustmentValue);
			Element eleDiscountType = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
			XMLUtil.setNodeValue(eleDiscountType, KohlsPOCConstant.MANUAL_PERCENT_OFF);

			}
			Element eleGift = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATT_GIFT);
			XMLUtil.setNodeValue(eleGift,KohlsPOCConstant.NO);
			Element eleIEIndicator = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.A_IE_INDICATOR);
			XMLUtil.setNodeValue(eleIEIndicator,"None");
		  }

	   }

		else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
			Element manualTLDEle = null;

			// if ExtnPromotionFlag=="Y" && isPsaPromotion == "Y" then its PSA FLOW
			// if ExtnPromotionFlag=="" && isPsaPromotion == "" then its PSA FLOW
			if((!YFCCommon.isStringVoid(extnPromotionFlag) && !YFCCommon.isStringVoid(isPsaPromotion))
					|| (YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion))){
			   Element adjustment = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ADJUSTMENS,true);
            manualTLDEle = XMLUtil.createChild(adjustment, KohlsPOCConstant.ADJUSTMENTMANUALTLD);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			}
			//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
			else if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)){
			 //manualTLDEle = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD,true);
            manualTLDEle = XMLUtil.createChild(tempMaualTldList, KohlsPOCConstant.ELE_MANUAL_TLD);
			}

			Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
			XMLUtil.setNodeValue(elePromoId,ordPromotionID);
			Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
			XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);

			extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
			Element SeniorCitizenResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));

			List<Element> rulesEleList = XMLUtil.getElementsByTagName(SeniorCitizenResposneEle, KohlsPOCConstant.E_RULE);
			String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE;
			//Begin--Changes for 2979
			String ruleValue = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydatePSA(yfsEnv,tempOrderEle,ruleId);
			//End-- Changes for 2979
			String percentValue = null;
			

			//Changes for 3111- Start
			percentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
			  if(!YFCCommon.isStringVoid(percentValue)){
			    percentValue = String.valueOf(Math.abs(Double.valueOf(percentValue) / KohlsPOCConstant.HUNDRED_INT));
			    }
			           
			  else if(!YFCCommon.isVoid(ruleValue) || !rulesEleList.isEmpty()){
				  //Changes for 3111- End
				percentValue = String.valueOf(Double.valueOf(ruleValue)/KohlsPOCConstant.HUNDRED_INT);
			} else {
				percentValue = String.valueOf(Double.valueOf(KohlsPOCConstant.DEFAULT_SENIOR_DISCOUNT_PERCENT)/KohlsPOCConstant.HUNDRED_INT);
			}
			Element eleMarkDownValue = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_MARK_DOWN_VALUE);
			XMLUtil.setNodeValue(eleMarkDownValue,percentValue);
			Element eleDiscountType = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_DISCOUNT_TYPE);
			XMLUtil.setNodeValue(eleDiscountType,KohlsPOCConstant.SENIOR_CITIZEN_DISCOUNT);

		}
		//Changes for defect 2704-- Start
		else if( KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType) || (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType) && !KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)))
		//Changes for defect 2704-- End
			{
				Element manualTLDEle = null;
				// if ExtnPromotionFlag=="Y" && isPsaPromotion == "Y" then its PSA FLOW
				// if ExtnPromotionFlag=="" && isPsaPromotion == "" then its PSA FLOW
				//Fix for PR-688 - Adding Check for excluding KCS Redemption in PSA PostVoid
				if((!YFCCommon.isStringVoid(extnPromotionFlag) && !YFCCommon.isStringVoid(isPsaPromotion) && !"V".equalsIgnoreCase(isPsaPromotion))
						|| (YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion))){
				   Element adjustment = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ADJUSTMENS,true);
               manualTLDEle = XMLUtil.createChild(adjustment, KohlsPOCConstant.ADJUSTMENTMANUALTLD);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION, KohlsPOCConstant.YES);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
				}

				//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
				if(KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType)){
					boolean legacyPromotionCategory = validateLegacyPromotionCategory(promotionId,tempOrderEle);
					//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
					if(legacyPromotionCategory == true){
						if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)){
							//manualTLDEle = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD,true);
                     manualTLDEle = XMLUtil.createChild(tempMaualTldList, KohlsPOCConstant.ELE_MANUAL_TLD);
						}
					}
				}

				if(null!=manualTLDEle){
					Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
					XMLUtil.setNodeValue(elePromoId,ordPromotionID);
					Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
					XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
					constructTVSRequestFromKohlsCashResponse(promotionEle,manualTLDEle,createtsList);
				}
			}

		else if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)&&(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)))
		{
			Element manualTLDEle = null;

			// if ExtnPromotionFlag=="Y" && isPsaPromotion == "Y" then its PSA FLOW
			// if ExtnPromotionFlag=="" && isPsaPromotion == "" then its PSA FLOW
			//Fix for PR-688 - Adding Check for excluding KCS Redemption in PSA PostVoid
			if((!YFCCommon.isStringVoid(extnPromotionFlag) && !YFCCommon.isStringVoid(isPsaPromotion) && !"V".equalsIgnoreCase(isPsaPromotion))
					|| (YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)))
			{
            Element adjustment = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ADJUSTMENS,true);
            manualTLDEle = XMLUtil.createChild(adjustment, KohlsPOCConstant.ADJUSTMENTMANUALTLD);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			}
			/*//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
			else if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)){
				manualTLDEle = XMLUtil.createChild(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD);
			}*/
			Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
			XMLUtil.setNodeValue(elePromoId,ordPromotionID);
			Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
			XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
			constructTVSRequestFromOfflineKohlsCashResponse(promotionEle,manualTLDEle,createtsList);
		}
		else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))
		{
			Element manualTLDEle = null;
			// if ExtnPromotionFlag=="Y" && isPsaPromotion == "Y" then its PSA FLOW
			// if ExtnPromotionFlag=="" && isPsaPromotion == "" then its PSA FLOW
			if((!YFCCommon.isStringVoid(extnPromotionFlag) && !YFCCommon.isStringVoid(isPsaPromotion))
					|| (YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)))
			{
			   Element adjustment = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ADJUSTMENS,true);
            manualTLDEle = XMLUtil.createChild(adjustment, KohlsPOCConstant.ADJUSTMENTMANUALTLD);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			}
			//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
			else if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)){
			   //manualTLDEle = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ELE_MANUAL_TLD,true);
            manualTLDEle = XMLUtil.createChild(tempMaualTldList, KohlsPOCConstant.ELE_MANUAL_TLD);
			}
				Element elePromoId = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_ID);
				XMLUtil.setNodeValue(elePromoId,ordPromotionID);
				Element eleScanOrder = XMLUtil.createChild(manualTLDEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
				XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);
				constructTVSRequestFromAssociateResponse(yfsEnv,ordPromotionID, tempOrderEle,manualTLDEle,createtsList,orderPromoObj);
		}

		else if(KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType))
		{
			// if ExtnPromotionFlag=="Y" && isPsaPromotion == "Y" then its PSA FLOW
			// if ExtnPromotionFlag=="" && isPsaPromotion == "" then its PSA FLOW
			if((!YFCCommon.isStringVoid(extnPromotionFlag) && !YFCCommon.isStringVoid(isPsaPromotion))
					|| (YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)))
			{
				String promotionID = promotionEle.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
				if(!YFCCommon.isVoid(promotionID)){
				   Element adjustment = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ADJUSTMENS,true);
              // Element adjustmentOffers = XMLUtil.createChild(adjustment, KohlsPOCConstant.ADJUSTMENT_OFFERS);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION, KohlsPOCConstant.YES);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG,KohlsPOCConstant.YES);

					Element offerEle = XMLUtil.createChild(adjustmentOffers1,"offer");
					Element eleOfferId = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_OFFER_ID);
					if(KohlsPoCPnPUtil.isSUPC(promotionID)){
						XMLUtil.setNodeValue(eleOfferId,promotionID);
					}else{
						XMLUtil.setNodeValue(eleOfferId,promotionID.substring(0,5));
						//XMLUtil.setNodeValue(eleOfferId,ordPromotionID);
					}
					//XMLUtil.setNodeValue(eleOfferId, String.valueOf(ordPromotionID));
					Element eleScanOrder = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
					XMLUtil.setNodeValue(eleScanOrder, sequenceNumber);
					Element eleOverrideFlag = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_OVERRIDE_FLAG);
					if(isMgrOverrideProvided == null || isMgrOverrideProvided.isEmpty()){
						logger.debug("Setting No for Manager Override  ::");
						XMLUtil.setNodeValue(eleOverrideFlag,KohlsPOCConstant.NO);
					}
					else{
						logger.debug("Setting isMgrOverrideProvided  ::"+isMgrOverrideProvided);
						XMLUtil.setNodeValue(eleOverrideFlag,isMgrOverrideProvided);
					}
				}
			}
			//if ExtnPromotionFlag=="Y" && isPsaPromotion == "" then its not PSA FLOW
			else if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPsaPromotion)){
				String promotionID = promotionEle.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
				Element elePromotionExtn = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN);
				String sDiscountPercent = elePromotionExtn.getAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
				if(YFCCommon.isVoid(sDiscountPercent)) {
					sDiscountPercent = "0";
				} 
				String tempPromoID = promotionID;
				if(KohlsPoCPnPUtil.isSUPC(promotionID)){
					tempPromoID = extnEle.getAttribute("ExtnOfferCouponNo");
				}else{
					tempPromoID = promotionID.substring(0,5);
				} 
				if(!YFCCommon.isVoid(promotionID)){

					if(promoDiscMap.containsKey(KohlsPOCConstant.THIRTY_EIGHT)){

						Map precedence38 = promoDiscMap.get(KohlsPOCConstant.THIRTY_EIGHT);
						Iterator entries = precedence38.entrySet().iterator();
						//PR-1048 - Start Offer Fix
						List<String> listawardID = new ArrayList<String>();
						//PR-1048 - End
						while (entries.hasNext()) {

						  Entry thisEntry = (Entry) entries.next();
						  String itemId = (String)thisEntry.getKey();

						  List<Element> awardList = (List<Element>) thisEntry.getValue();
						  //Added for Multiple existingOffers elements - POC Returns Team - Start
						 //List<String> listawardID = new ArrayList<String>();

						  for(Element award : awardList)
						  {
							  if(!(listawardID.contains(ordPromotionID))){
						   Element offersEle = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ELEM_OFFERS,true);
	                  Element offerEle = XMLUtil.createChild(offersEle, KohlsPOCConstant.EXISTING_OFFER);
	                     //PSA changes
	                  Element eleOfferId = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_ID);
	                  listawardID.add(ordPromotionID);
							XMLUtil.setNodeValue(eleOfferId,ordPromotionID);

					
							Element eleScanOrder = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
							XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);

							Element eleTransLimit = XMLUtil.createChild(offerEle, KohlsPOCConstant.TRAN_LIMIT);
							XMLUtil.setNodeValue(eleTransLimit,KohlsPOCConstant.STRING_ONE);

							Element eleAppCode = XMLUtil.createChild(offerEle, KohlsPOCConstant.APPLICATION_CODE);
							XMLUtil.setNodeValue(eleAppCode,KohlsPOCConstant.PR);

							Element eleOfferType = XMLUtil.createChild(offerEle, KohlsPOCConstant.OFFER_TYPE);
							XMLUtil.setNodeValue(eleOfferType,KohlsPOCConstant.TR);

							Element eleSchemeCode = XMLUtil.createChild(offerEle, KohlsPOCConstant.SCHEME_CODE);
							XMLUtil.setNodeValue(eleSchemeCode,KohlsPOCConstant.STRING_THOUSAND_NINE);

							Element eleBuyCriteria = XMLUtil.createChild(offerEle, KohlsPOCConstant.BUY_CRITERIA);

							Element eleBuycriteriaType = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.CRITERIA_TYPE);
							XMLUtil.setNodeValue(eleBuycriteriaType,KohlsPOCConstant.A_BUY_DOLLAR);

							Element eleBuyDollar = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.BUY_DOLLOR);
							XMLUtil.setNodeValue(eleBuyDollar,KohlsPOCConstant.STRING_ONE_CENT);

							/*Element eleBuyCriteriaGetPercent = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.GET_PERCENT);
							XMLUtil.setNodeValue(eleBuyCriteriaGetPercent,KohlsPOCConstant.BLANK);*/

							/*Element eleBuyCriteriaMdseSet = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.MDE_SET);

							Element elebyCriMdeSetSku =  XMLUtil.createChild(eleBuyCriteriaMdseSet, KohlsPOCConstant.SKU_SMALL);
							XMLUtil.setNodeValue(elebyCriMdeSetSku,itemId);*/

							Element eleGetCriteria = XMLUtil.createChild(offerEle, KohlsPOCConstant.GET_CRITERIA);

							Element eleGetcriteriaType = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.CRITERIA_TYPE);
							XMLUtil.setNodeValue(eleGetcriteriaType,KohlsPOCConstant.GET_PERCENT_OFF);

							/*Element eleGetCrieteriaBuyDollar = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.BUY_DOLLOR);
							XMLUtil.setNodeValue(eleGetCrieteriaBuyDollar,KohlsPOCConstant.BLANK);*/

							Element extn = XMLUtil.getChildElement(award, KohlsPOCConstant.E_EXTN);
							String salesHubData = XMLUtil.getAttribute(extn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
							String percentOff = KohlsPOCConstant.BLANK;

							if(!YFCCommon.isVoid(salesHubData)){
								Element salesHubDataEle = null;
								try {
									salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubData);
								} catch (ParserConfigurationException e) {
									logger.error("ParserConfigurationException at KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");
								} catch (SAXException e) {
									logger.error("SAXException at KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");
								} catch (IOException e) {
									logger.error("IOException at KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");
								}

								if(!YFCCommon.isVoid(salesHubDataEle)){
									percentOff = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT_SH);
								}
							}

							Element eleGetCriteriaGetPercent = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.GET_PERCENT);
							if(!YFCCommon.isVoid(percentOff)) {
								XMLUtil.setNodeValue(eleGetCriteriaGetPercent,percentOff);
							} else {
								XMLUtil.setNodeValue(eleGetCriteriaGetPercent, sDiscountPercent);
							}

							/*Element eleGetCriteriaMdseSet = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.MDE_SET);

							Element eleGetCriMdeSetSku =  XMLUtil.createChild(eleGetCriteriaMdseSet, KohlsPOCConstant.SKU_SMALL);
							XMLUtil.setNodeValue(eleGetCriMdeSetSku,itemId);*/

						  }
						}
					}
					}
					
				

					if(promoDiscMap.containsKey(KohlsPOCConstant.THIRTY_NINE))
					{
						Map precedence39 = promoDiscMap.get(KohlsPOCConstant.THIRTY_NINE);
						Iterator entries = precedence39.entrySet().iterator();
						//PR-1048 - Start
						List<String> listawardID = new ArrayList<String>();
						//PR-1048 - End
						while (entries.hasNext()) {

						  Entry thisEntry = (Entry) entries.next();
						  String itemId = (String)thisEntry.getKey();

						  List<Element> awardList = (List<Element>) thisEntry.getValue();
						  //List<String> listawardID = new ArrayList<String>();
						  for(Element award : awardList)
						  {
							  if(!(listawardID.contains(ordPromotionID))){
						   Element offersEle = XMLUtil.getChildElement(transactionEle, KohlsPOCConstant.ELEM_OFFERS,true);
	                  Element offerEle = XMLUtil.createChild(offersEle, KohlsPOCConstant.EXISTING_OFFER);

	                  Element eleOfferId = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_ID);
	                  String tmpExtnOfferCouponNo = extnEle.getAttribute( "ExtnOfferCouponNo" );
	                  if( KohlsPoCPnPUtil.isSUPC( promotionID ) && ( !YFCCommon.isVoid( tmpExtnOfferCouponNo ) ) ) {
	                     listawardID.add( tmpExtnOfferCouponNo );
                        XMLUtil.setNodeValue( eleOfferId, tmpExtnOfferCouponNo );
	                     
	                  } else {
	                     /*listawardID.add( promotionID.substring( 0,5 ) );
	                     XMLUtil.setNodeValue( eleOfferId,promotionID.substring( 0,5 ) );*/
	                	  listawardID.add(ordPromotionID);
		                     XMLUtil.setNodeValue( eleOfferId,ordPromotionID);
	                  } 
	                  		XMLUtil.setNodeValue(eleOfferId,ordPromotionID);
	                  		
							Element eleScanOrder = XMLUtil.createChild(offerEle, KohlsPOCConstant.ATTR_SCAN_ORDER);
							XMLUtil.setNodeValue(eleScanOrder,sequenceNumber);

							Element eleTransLimit = XMLUtil.createChild(offerEle, KohlsPOCConstant.TRAN_LIMIT);
							XMLUtil.setNodeValue(eleTransLimit,KohlsPOCConstant.STRING_ONE);

							Element eleAppCode = XMLUtil.createChild(offerEle, KohlsPOCConstant.APPLICATION_CODE);
							XMLUtil.setNodeValue(eleAppCode,KohlsPOCConstant.PR);

							Element eleOfferType = XMLUtil.createChild(offerEle, KohlsPOCConstant.OFFER_TYPE);
							XMLUtil.setNodeValue(eleOfferType,"SP");

							Element eleSchemeCode = XMLUtil.createChild(offerEle, KohlsPOCConstant.SCHEME_CODE);
							XMLUtil.setNodeValue(eleSchemeCode,KohlsPOCConstant.ONE_THOUSAND_EIGHT);

							/*Element eleBuyCriteria = XMLUtil.createChild(offerEle, KohlsPOCConstant.BUY_CRITERIA);

							Element eleBuycriteriaType = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.CRITERIA_TYPE);
							XMLUtil.setNodeValue(eleBuycriteriaType,KohlsPOCConstant.A_BUY_DOLLAR);

							Element eleBuyDollar = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.BUY_DOLLOR);
							XMLUtil.setNodeValue(eleBuyDollar,KohlsPOCConstant.STRING_ONE_CENT);*/

							/*Element eleBuyCriteriaGetPercent = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.GET_PERCENT);
							XMLUtil.setNodeValue(eleBuyCriteriaGetPercent,KohlsPOCConstant.BLANK);*/

							/*Element eleBuyCriteriaMdseSet = XMLUtil.createChild(eleBuyCriteria, KohlsPOCConstant.MDE_SET);

							Element elebyCriMdeSetSku =  XMLUtil.createChild(eleBuyCriteriaMdseSet, KohlsPOCConstant.SKU_SMALL);
							XMLUtil.setNodeValue(elebyCriMdeSetSku,itemId);*/

							Element eleGetCriteria = XMLUtil.createChild(offerEle, KohlsPOCConstant.GET_CRITERIA);

							Element eleGetcriteriaType = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.CRITERIA_TYPE);
							XMLUtil.setNodeValue(eleGetcriteriaType,KohlsPOCConstant.GET_PERCENT_OFF);

							/*Element eleGetCrieteriaBuyDollar = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.BUY_DOLLOR);
							XMLUtil.setNodeValue(eleGetCrieteriaBuyDollar,KohlsPOCConstant.BLANK);*/

							Element extn = XMLUtil.getChildElement(award, KohlsPOCConstant.E_EXTN);
							String salesHubData = XMLUtil.getAttribute(extn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
							String percentOff = KohlsPOCConstant.BLANK;

							if(!YFCCommon.isVoid(salesHubData)){
								Element salesHubDataEle = null;
								try {
									salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubData);
								} catch (ParserConfigurationException e) {
									logger.error("ParserConfigurationException at KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");
								} catch (SAXException e) {
									logger.error("SAXException at KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");
								} catch (IOException e) {
									logger.error("IOException at KohlsPoCTVSCaller.constructTVSRequestDocForTLDPSA");
								}

								if(!YFCCommon.isVoid(salesHubDataEle)){
									percentOff = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT_SH);
								}
							}

							Element eleGetCriteriaGetPercent = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.GET_PERCENT);
							if(!YFCCommon.isVoid(percentOff)) {
								XMLUtil.setNodeValue(eleGetCriteriaGetPercent,percentOff);
							} else {
								XMLUtil.setNodeValue(eleGetCriteriaGetPercent, sDiscountPercent);
							}

							/*Element eleGetCriteriaMdseSet = XMLUtil.createChild(eleGetCriteria, KohlsPOCConstant.MDE_SET);

							Element eleGetCriMdeSetSku =  XMLUtil.createChild(eleGetCriteriaMdseSet, KohlsPOCConstant.SKU_SMALL);
							XMLUtil.setNodeValue(eleGetCriMdeSetSku,itemId);*/

					}

				}
			}
		 }
	  }
	}
	}
		//Added for Multiple existingOffers elements - POC Returns Team - End
		this.logger.debug("Method Name : constructTVSRequestDocForTLDPSA   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructTVSRequestDocForTLDPSA");

	}


/**
 * validateLegacyPromotionCategory() to check whether any of the promotion applied awards in orderlines contains precedence number 40
 * @param promotionId
 * @param tempOrderEle
 * @return
 */
private boolean validateLegacyPromotionCategory(String promotionId,Element orderElement){

logger.beginTimer(" KohlsPoCTVSCaller.validateLegacyPromotionCategory");
this.logger.debug("Method Name : validateLegacyPromotionCategory   and   Status : Start ");

List <Element> orderLineList = XMLUtil.getElementsByTagName(orderElement, KohlsPOCConstant.E_ORDER_LINE);

	for(Element orderLine : orderLineList){

		NodeList awardList = orderLine.getElementsByTagName("Award");

		for(int iterator=0 ; iterator<awardList.getLength(); iterator++){

			Element awardElement = (Element) awardList.item(iterator);
			String awardPromotionId = XMLUtil.getAttribute(awardElement, "PromotionId");

			if(awardPromotionId.equalsIgnoreCase(promotionId)){

			Element awardExtn = XMLUtil.getChildElement(awardElement,"Extn");
			String precedence = "";

			String salesHubClob = XMLUtil.getAttribute(awardExtn, "ExtnSalesHubData");

			if(!YFCCommon.isVoid(salesHubClob)){
				Element salesHubDataEle = null;
				try {
					salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
				} catch (ParserConfigurationException e) {
					logger.error("ParserConfigurationException at KohlsPoCTVSCaller.validateLegacyPromotionCategory");
				} catch (SAXException e) {
					logger.error("SAXException at KohlsPoCTVSCaller.validateLegacyPromotionCategory");
				} catch (IOException e) {
					logger.error("IOException at KohlsPoCTVSCaller.validateLegacyPromotionCategory");
				}

				if(!YFCCommon.isVoid(salesHubDataEle)){
					precedence = XMLUtil.getAttribute(salesHubDataEle, "Precedence");
				}
			}
			if(precedence.equalsIgnoreCase("40")){
				return true;
			}
		}
	 }
  }
  logger.endTimer("KohlsPoCTVSCaller.validateLegacyPromotionCategory");
  this.logger.debug("Method Name : validateLegacyPromotionCategory   and   Status : end ");
  return false;
}



/**
 *
 * @param orderElement
 * @param PromotionId
 * @param promoDiscMap
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
private static void generatePromoDiscMap(Element orderElement,String PromotionId,Map promoDiscMap){

	logger.beginTimer("KohlsPoCAPECaller.generatePromoDiscMap");
	Map<String,List<Element>> precedenceMap38 = new HashMap<String,List<Element>>();
	Map<String,List<Element>> precedenceMap39 = new HashMap<String,List<Element>>();

	List <Element> orderLineList = XMLUtil.getElementsByTagName(orderElement, KohlsPOCConstant.E_ORDER_LINE);

	for(Element orderLine : orderLineList){

		Element item = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_ITEM);
		String itemId = XMLUtil.getAttribute(item,KohlsPOCConstant.A_ITEM_ID);

		NodeList awardList = orderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);

		for(int iterator=0 ; iterator<awardList.getLength(); iterator++){

			Element awardElement = (Element) awardList.item(iterator);
			String awardPromotionId = XMLUtil.getAttribute(awardElement, KohlsPOCConstant.PROMOTIONID);

			if(awardPromotionId.equalsIgnoreCase(PromotionId)){

			Element awardExtn = XMLUtil.getChildElement(awardElement,KohlsPOCConstant.E_EXTN);
			String precedence = "";

			String salesHubClob = XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
			String sDiscountTypeReason = "";
			if(!YFCCommon.isVoid(XMLUtil.getAttribute(awardExtn,"ExtnDiscountReasonCode")) && !YFCCommon.isVoid(XMLUtil.getAttribute(awardExtn,"ExtnDiscountTypeCode"))) {
				sDiscountTypeReason = XMLUtil.getAttribute(awardExtn,"ExtnDiscountReasonCode")+XMLUtil.getAttribute(awardExtn,"ExtnDiscountTypeCode");
			}
			if(!YFCCommon.isVoid(salesHubClob)){
				Element salesHubDataEle = null;
				try {
					salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
				} catch (ParserConfigurationException e) {
					logger.error("ParserConfigurationException at KohlsPoCTVSCaller.generatePromoDiscMap");
				} catch (SAXException e) {
					logger.error("SAXException at KohlsPoCTVSCaller.generatePromoDiscMap");
				} catch (IOException e) {
					logger.error("IOException at KohlsPoCTVSCaller.generatePromoDiscMap");
				}

				if(!YFCCommon.isVoid(salesHubDataEle)){
					precedence = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_PRECEDENCE);
				}
			}
			if(precedence.equalsIgnoreCase(KohlsPOCConstant.THIRTY_EIGHT) || "761I".equalsIgnoreCase(sDiscountTypeReason)){
				if(precedenceMap38.containsKey(itemId)){
					precedenceMap38.get(itemId).add(awardElement);
				}
				else{
					List<Element> tempList = new ArrayList();
					tempList.add(awardElement);
					precedenceMap38.put(itemId, tempList);
				}
			}
			else if(precedence.equalsIgnoreCase(KohlsPOCConstant.THIRTY_NINE) || "760Q".equalsIgnoreCase(sDiscountTypeReason)){
				if(precedenceMap39.containsKey(itemId)){
					precedenceMap39.get(itemId).add(awardElement);
				}
				else{
					List<Element> tempList = new ArrayList();
					tempList.add(awardElement);
					precedenceMap39.put(itemId, tempList);
				}
			}
		}
	  }
	}
	promoDiscMap.put(KohlsPOCConstant.THIRTY_EIGHT, precedenceMap38);
	promoDiscMap.put(KohlsPOCConstant.THIRTY_NINE, precedenceMap39);
	logger.endTimer("KohlsPoCAPECaller.generatePromoDiscMap");
}

//PST-3220 - Start
private double calcAwardsAdjustmentsPSANew(Entry<String, Element> entry,Element promotionsEle){

	   logger.beginTimer("KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");

	   Element orderLineEle =  entry.getValue();
	   Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
	   String extnReturnReceiptPrice = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.A_EXTN_RETURN_PRICE);
	   String extnTaxableAmount = XMLUtil.getAttribute(extnEle,KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
	   double totalAwards = KohlsPOCConstant.ZERO_DBL;
	   double regularPrice = KohlsPOCConstant.ZERO_DBL;
	   String awardAmount = KohlsPOCConstant.BLANK;
	   List <Element> AwardsList = XMLUtil.getElementsByTagName(orderLineEle, KohlsPOCConstant.E_AWARDS);

	   Element awards = AwardsList.get(0);

	   List<Element> awardList =  XMLUtil.getElementsByTagName(awards, KohlsPOCConstant.E_AWARD);

	   if (AwardsList.size() > KohlsPOCConstant.ZERO_INT) {
	      for(Element awardEle: awardList){

	         String awardpromotionId = XMLUtil.getAttribute(awardEle, KohlsPOCConstant.PROMOTIONID);
	         Element awardExtn = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.A_EXTN);
	         String extnPromotionFlag = null;
	         String extnDiscountPercent = null; //CPE-6061
	         String isPSAPromotion = null;
	         String discountType = KohlsPOCConstant.BLANK;
	         String precedence = KohlsPOCConstant.BLANK;
	         String sDiscountTypeReason = KohlsPOCConstant.BLANK;
	         List <Element> orderPromotionList = XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
	         String promoId;
	         //PST-3220 - Start
	         String sExtnPromoSchema = KohlsPOCConstant.BLANK;
	         //PST-3220 - End
	         
	         for(Element promotion : orderPromotionList){
	            promoId = XMLUtil.getAttribute(promotion, KohlsPOCConstant.PROMOTIONID);

	            if(promoId.equalsIgnoreCase(awardpromotionId) && !awardpromotionId.contains("FEE_")){
	               Element promotionExtn = XMLUtil.getChildElement(promotion, KohlsPOCConstant.A_EXTN);
	               extnPromotionFlag = XMLUtil.getAttribute(promotionExtn,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG); // check whether offer applied or new
	               extnDiscountPercent = XMLUtil.getAttribute(promotionExtn,KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT); // check Discount percentage for CPE-6061
	               isPSAPromotion = XMLUtil.getAttribute(promotionExtn,KohlsPOCConstant.ISPSAPROMOTION);  // check psa promotion applied or new
	               sDiscountTypeReason = XMLUtil.getAttribute(awardExtn,"ExtnDiscountReasonCode")+XMLUtil.getAttribute(awardExtn,"ExtnDiscountTypeCode");
	               discountType = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_PROMOTION_TYPE);
	               break;
	            }
	         }
	         
	         if(extnPromotionFlag!=null && isPSAPromotion!=null){
	 			if((extnPromotionFlag.equalsIgnoreCase(KohlsPOCConstant.BLANK) && isPSAPromotion.equalsIgnoreCase(KohlsPOCConstant.BLANK))
	 				  || (extnPromotionFlag.equalsIgnoreCase(KohlsPOCConstant.YES) && isPSAPromotion.equalsIgnoreCase(KohlsPOCConstant.YES))) {
	 			  //Changes for defect 3129- Start
	 				awardAmount = XMLUtil.getAttribute(awardExtn, "ExtnNetDelta");
	 				//Changes for defect 3129- End
	 			   if(!YFCCommon.isVoid(awardAmount)){
	 				  totalAwards += Math.abs(Double.valueOf(awardAmount));
	 				  continue;
	 			   }
	 		   }
	 		 }



	         if(discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER)||discountType.equalsIgnoreCase(KohlsPOCConstant.LEGACY_COUPON)){
	            String salesHubClob = XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);

	            if(!YFCCommon.isVoid(salesHubClob)){
	               Element salesHubDataEle = null;
	               try {
	                  salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
	               } catch (ParserConfigurationException e) {
	                  logger.error("ParserConfigurationException at KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
	               } catch (SAXException e) {
	                  logger.error("SAXException at KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
	               } catch (IOException e) {
	                  logger.error("IOException at KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
	               }

	               if(!YFCCommon.isVoid(salesHubDataEle)){
	                  precedence = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_PRECEDENCE);
	               }
	            }
	         }
	         
	         if(!YFCCommon.isVoid(discountType)){
	            if(discountType.equalsIgnoreCase(KohlsPOCConstant.PERCENT_OFF)||
	            		discountType.equalsIgnoreCase(KohlsPOCConstant.SENIOR_DISCOUNT) ||
	                           discountType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)||
	                            (discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER) && !YFCCommon.isVoid(extnDiscountPercent) 
	                                && ("38".equalsIgnoreCase(precedence) || "39".equalsIgnoreCase(precedence)) )||
	                              (discountType.equalsIgnoreCase(KohlsPOCConstant.LEGACY_COUPON)&& precedence.equalsIgnoreCase("40")) ||
	                              (sDiscountTypeReason.equalsIgnoreCase("760Q") ||sDiscountTypeReason.equalsIgnoreCase("761I"))) {
	 
	            	//Changes for defect 3129- Start
	            	awardAmount = XMLUtil.getAttribute(awardExtn, "ExtnNetDelta");
	            	//Changes for defect 3129- End
	               if(!YFCCommon.isVoid(awardAmount)){
	                  totalAwards += Math.abs(Double.valueOf(awardAmount));
	                  }
	               }
	            }
	         }
	      }
		if(YFCCommon.isVoid(extnTaxableAmount) || extnTaxableAmount.equalsIgnoreCase(KohlsPOCConstant.EMPTY))
		{
			extnTaxableAmount="0.0";
		}

	      regularPrice = Double.parseDouble(extnReturnReceiptPrice) + totalAwards;

	      DecimalFormat df = new DecimalFormat("0.00");
	      String tempRegularPrice = df.format(regularPrice);

	      regularPrice = Double.valueOf(tempRegularPrice);
	      
	      logger.endTimer("KohlsPoCTVSCaller.calcAwardsAdjustmentsPSA");
	      this.logger.debug("Method Name : calcAwardsAdjustmentsPSA   and   Status : End ");
	      return regularPrice;
	}
//PST-3220-End

}
