package com.kohls.poc.pricing.ue;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

public class KohlsPoCTVSGenerateExtnPromoSequence {
	
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCTVSGenerateExtnPromoSequence.class.getName());
	}

	/**
	 * @param orderEle
	 * @param tvsResponseEle
	 * @throws Exception
	 */
	/*Changes for defect 1100 - Changing the logic to get the offerId from offerList element of the 
	TVS response and stamp the respective Promo Sequence for the respective promotions.*/
	public static void generateExtnPromoSequence(Element orderEle, Element tvsResponseEle) throws Exception {

		logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.generateExtnPromoSequence");

		HashMap<String, Element> sortedModifierHashMap = getSortedModifierMap(tvsResponseEle);
		HashMap<String, Element> promotionsHashMap = new LinkedHashMap<String, Element>();
		HashMap<String, String> sortedOfferHashMap = getSortedOfferMap(tvsResponseEle);
		NodeList nlOfferList = null;
		nlOfferList = tvsResponseEle.getElementsByTagName("offerList");

		Element promotionsEle = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_PROMOTIONS);

		if (!YFCCommon.isVoid(promotionsEle)) {

			List<Element> orderPromotionList = XMLUtil
					.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);

			if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) {

				for (Element promotionEle : orderPromotionList) {
					String promotionType = XMLUtil.getAttribute( promotionEle, "PromotionType");
                                  if(KohlsPOCConstant.KOHLS_CASH_AWARD.equals(promotionType)){
                                         continue;
                                  }

					String promoID =  XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
					Element tempEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP);
					String tempGuid = XMLUtil.getAttribute(tempEle, KohlsPOCConstant.A_ID);
					/*String offerParentId = " ";
					if(nlOfferList.getLength()>0){
					Element eleOffer = (Element)((NodeList) XPathUtil.getNodeList(tvsResponseEle, "/priceResponse/transaction/offerList/offer[@id='"+tempGuid+"']")).item(0);

					if(!YFCCommon.isVoid(eleOffer)){

							offerParentId = eleOffer.getAttribute("offerId");

							logger.debug("Modifier discount id corresponds to an offer id: "+offerParentId);

							}
					}*/
					//Defect 3949 - Start
					if(!YFCCommon.isVoid(promoID) && !(promoID==null) && !(tempGuid==null)){
					//Defect 3949 - End						
						tempGuid = tempGuid.concat("#").concat(promoID.substring(0, 5));
						if(logger.isDebugEnabled()){
							logger.debug("The concatenated value and hte tempGuid are : " +promoID.substring(0, 5) +"and" + tempGuid);
						}
					}

					promotionsHashMap.put(tempGuid, promotionEle);

				}
			}

		}

		int extnPromoSequence = 0;
		//int extnPromoSequenceFormissedOffers = promotionsHashMap.size();
		//logger.debug("The extnPromoSequence and extnPromoSequenceFormissedOffers value are :" +extnPromoSequence +"and" + extnPromoSequenceFormissedOffers);
		for (Map.Entry<String, Element> modifierEntry : sortedModifierHashMap.entrySet()) {
			String modifierParentGuid = modifierEntry.getKey();
			
			//Added for setting Precedence Number as part of Sprint-8 - Start
			Element modifirEle = modifierEntry.getValue();			
			String precedenceStr = XMLUtil.getAttribute(modifirEle, KohlsPOCConstant.ATTR_PRECEDENCE);
			logger.debug("The modifierParentGuid and precedenceStr values are :" +modifierParentGuid +"and" +precedenceStr );
		}
		Iterator itrbfrRemoving = promotionsHashMap.keySet().iterator();
		while (itrbfrRemoving.hasNext()) {
			String guid = (String) itrbfrRemoving.next();

			logger.debug("Left over Guid before removing:" + guid);

		}
		for (Map.Entry<String, Element> modifierEntry : sortedModifierHashMap.entrySet()) {
			String modifierParentGuid = modifierEntry.getKey();
			
			//Added for setting Precedence Number as part of Sprint-8 - Start
			Element modifirEle = modifierEntry.getValue();			
			String precedenceStr = XMLUtil.getAttribute(modifirEle, KohlsPOCConstant.ATTR_PRECEDENCE);			
			//Added for setting Precedence Number as part of Sprint-8 - End

			for (Iterator<Map.Entry<String, Element>> it = promotionsHashMap.entrySet().iterator(); it.hasNext();) {
				Map.Entry<String, Element> promotionEntry = it.next();
				String promotionGuid = promotionEntry.getKey();
				String delimtTempId = " ";
				String delitPromoId = " ";
				Element eleOffer = null;
				if(promotionGuid.contains("#")){
					String[] promoGuiddelimt = promotionGuid.split("#");
					delimtTempId = promoGuiddelimt[0];
					delitPromoId = promoGuiddelimt[1];
				}
				String offerParentId = " ";
				if(nlOfferList.getLength()>0){
					if(!YFCCommon.isVoid(delimtTempId) || !YFCCommon.isVoid(delitPromoId)){
						//eleOffer = (Element)((NodeList) XPathUtil.getNodeList(tvsResponseEle, "/priceResponse/transaction/offerList/offer[@offerId='"+delitPromoId+"']")).item(0);
						// replacing XPathUtil with XMLUtil- Start
						List <Element> ndOffers = XMLUtil.getElementsByTagName(tvsResponseEle,"offer");
						if(!YFCCommon.isVoid(ndOffers))
						{
						   for(Element eleOffer1 : ndOffers)
						   {
						   
						      if(!YFCCommon.isVoid(delitPromoId) && (delitPromoId.equals("offerId"))){
							  logger.debug("The eleOffer is null from delitPromoId. So checking eleOffer from delimtTempId");
							  //eleOffer = (Element)((NodeList) XPathUtil.getNodeList(tvsResponseEle, "/priceResponse/transaction/offerList/offer[@offerId='"+delimtTempId+"']")).item(0);
//							  List <Element> ndLOffers = XMLUtil.getElementsByTagName(tvsResponseEle, KohlsPOCConstant.ELEM_OFFER);
							  if(YFCCommon.isVoid(eleOffer1))
								{
									   if(delimtTempId.equals("offerId"))
									   {
										   eleOffer = eleOffer1;
										   logger.debug("delimtTempId is equals to offerId"); 
										   break;
									   }	   
								}
						      }
						  }
						}
					// replacing XPathUtil with XMLUtil -End
					}else{
						// replacing XPathUtil with XMLUtil - Start
						//eleOffer = (Element)((NodeList) XPathUtil.getNodeList(tvsResponseEle, "/priceResponse/transaction/offerList/offer[@offerId='"+promotionGuid+"']")).item(0);
						List <Element> ndiOffers = XMLUtil.getElementsByTagName(tvsResponseEle,"offer");
						if(!YFCCommon.isVoid(ndiOffers))
						{
						   for(Element eleiOffer : ndiOffers)
						   {
							   if(promotionGuid.equals("offerId"))
							   {
								   eleOffer = eleiOffer;
								   logger.debug("promotionGuid is equals to offerId"); 
								   break;
							   }
						   }
						}
						
						// replacing XPathUtil with XMLUtil - End
						logger.debug("The eleOffer is from promotionGuid "); // +promotionGuid + XMLUtil.getElementXMLString(eleOffer));
					}

				if(!YFCCommon.isVoid(eleOffer)){

						offerParentId = eleOffer.getAttribute("id");

						logger.debug("Modifier discount id corresponds to an offer id: "+offerParentId);

						}
				}
				if(logger.isDebugEnabled()){
					logger.debug("The modifierParentGuid, promotionGuid, delimtTempId, delitPromoId, offerParentId" + modifierParentGuid +"and" +promotionGuid +"and" +delimtTempId + "and" + delitPromoId + "and" + offerParentId);
				}
				if (modifierParentGuid.equals(promotionGuid) || modifierParentGuid.equals(delimtTempId) || modifierParentGuid.equals(delitPromoId) || modifierParentGuid.equals(offerParentId)) {
					++extnPromoSequence;
					if(logger.isDebugEnabled()){
						logger.debug("Inside value modifierParentGuid, promotionGuid, delimtTempId, delitPromoId" + modifierParentGuid +"and" +promotionGuid +"and" +delimtTempId + "and" + delitPromoId);
						logger.debug("The extnPromoSequence value: "+ extnPromoSequence);
					}
					Element promo = (Element) promotionsHashMap.get(promotionGuid);
					Element extnPromo = XMLUtil.getChildElement(promo, KohlsPOCConstant.E_EXTN);
					XMLUtil.setAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE,
							String.valueOf(extnPromoSequence));
					if(logger.isDebugEnabled()){
						logger.debug("the promoSeq value is :"+XMLUtil.getAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE));		
					}
					//Added for setting Precedence Number as part of Sprint-8 - Start
					XMLUtil.setAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PRECEDENCE_NUMBER,precedenceStr);
					//Added for setting Precedence Number as part of Sprint-8 - End
							
					it.remove();
					//promotionsHashMap.remove(promotionGuid);
				}
			}

		}

		Iterator itr = promotionsHashMap.keySet().iterator();
		while (itr.hasNext()) {
			String guid = (String) itr.next();

			logger.debug("Left over Guid:" + guid);

		}

		HashMap<String, Element> sortedPromotionsMap = sortByScannedSequence(promotionsHashMap);
		Iterator<Map.Entry<String, Element>> sortedPromotionsIterator = sortedPromotionsMap.entrySet().iterator();
		while (sortedPromotionsIterator.hasNext()) {
			Map.Entry<String, Element> entry = sortedPromotionsIterator.next();
			Element promoElement = (Element) entry.getValue();
			Element extnPromo = XMLUtil.getChildElement(promoElement, KohlsPOCConstant.E_EXTN);
			XMLUtil.setAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE, String.valueOf(++extnPromoSequence));
			if(logger.isDebugEnabled()){
				logger.debug("The element getting stamped here is:" +XMLUtil.getAttribute(promoElement, KohlsPOCConstant.A_PROMOTION_ID));
			}
		}
		if(logger.isDebugEnabled()){
			logger.debug("Final Order XML with extnPromosequence:" + "\n" + XMLUtil.getElementXMLString(orderEle));
		}

		logger.endTimer("KohlsPoCGenerateExtnPromoSequence.generateExtnPromoSequence");

	}
	
	
	/**
    * @param orderEle
    * @param tvsResponseEle
    * @throws Exception
    */
   public static void generateExtnPromoSequencePSA(Element orderEle, Element tvsResponseEle) {

      logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.generateExtnPromoSequencePSA");

      HashMap<String, Element> sortedModifierHashMap = getSortedModifierMap(tvsResponseEle);
      //getting sorted modifier hashmap based on precendence value
      HashMap<String, Element> promotionsHashMap = new LinkedHashMap<String, Element>();

      Element promotionsEle = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_PROMOTIONS);

      if (!YFCCommon.isVoid(promotionsEle)) {

         List<Element> orderPromotionList = XMLUtil
               .getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);

         if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) {

            for (Element promotionEle : orderPromotionList) {
               
               String promotionType = XMLUtil.getAttribute( promotionEle, "PromotionType");
               
               Element tempEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP);

               String tempGuid = XMLUtil.getAttribute(tempEle, KohlsPOCConstant.A_ID);
               if(logger.isDebugEnabled()){
            	   logger.debug("The promotion Element for scan sequence ::" + XMLUtil.getElementXMLString(promotionEle));
               }
               if(!(KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(promotionType) 
                   || KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(promotionType))){
                  promotionsHashMap.put(tempGuid, promotionEle);
                  logger.debug(promotionType +" has been added to promotionsHashMap" );
               }

            }
         }

      }

      int extnPromoSequence = 0;
      for (Map.Entry<String, Element> modifierEntry : sortedModifierHashMap.entrySet()) {
         String modifierParentGuid = modifierEntry.getKey();
         
         //Added for setting Precedence Number as part of Sprint-8 - Start
         Element modifirEle = modifierEntry.getValue();        
         String precedenceStr = XMLUtil.getAttribute(modifirEle, KohlsPOCConstant.ATTR_PRECEDENCE);         
         //Added for setting Precedence Number as part of Sprint-8 - End

         for (Iterator<Map.Entry<String, Element>> it = promotionsHashMap.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String, Element> promotionEntry = it.next();
            String promotionGuid = promotionEntry.getKey();
            if (modifierParentGuid.equals(promotionGuid)) {
               ++extnPromoSequence;
               Element promo = (Element) promotionsHashMap.get(promotionGuid);
               Element extnPromo = XMLUtil.getChildElement(promo, KohlsPOCConstant.E_EXTN);
               XMLUtil.setAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE,
                     String.valueOf(extnPromoSequence));
                     
                     //Added for setting Precedence Number as part of Sprint-8 - Start
               XMLUtil.setAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PRECEDENCE_NUMBER,precedenceStr);
               //Added for setting Precedence Number as part of Sprint-8 - End
                     
               it.remove();
            }
         }

      }
      //to updated orderEle
      if(logger.isDebugEnabled()){
    	  logger.debug("After setting applied promotions:  Order XML :" + "\n" + XMLUtil.getElementXMLString(orderEle));
      }
      Iterator itr = promotionsHashMap.keySet().iterator();
      while (itr.hasNext()) {
         String guid = (String) itr.next();

         logger.debug("Left over Guid:" + guid);

      }

      HashMap<String, Element> sortedPromotionsMap = sortByScannedSequence(promotionsHashMap);
      Iterator<Map.Entry<String, Element>> sortedPromotionsIterator = sortedPromotionsMap.entrySet().iterator();
      while (sortedPromotionsIterator.hasNext()) {
         Map.Entry<String, Element> entry = sortedPromotionsIterator.next();
         Element promoElement = (Element) entry.getValue();
         Element extnPromo = XMLUtil.getChildElement(promoElement, KohlsPOCConstant.E_EXTN);
         XMLUtil.setAttribute(extnPromo, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE, String.valueOf(++extnPromoSequence));
      }
      if(logger.isDebugEnabled()){
    	  logger.debug("Final Order XML with extnPromosequence:" + "\n" + XMLUtil.getElementXMLString(orderEle));
      }

      logger.endTimer("KohlsPoCGenerateExtnPromoSequence.generateExtnPromoSequencePSA");

   }
	
	
	

	private static HashMap<String, Element> getSortedModifierMap(Element tvsResponseEle) {

		logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.getSortedModifierMap");
		if(logger.isDebugEnabled()){
			logger.debug("tvs response:" + "\n" + XMLUtil.getElementXMLString(tvsResponseEle));
		}
		List<Element> modifierList = XMLUtil.getElementsByTagName(tvsResponseEle, KohlsPOCConstant.ELEM_MODIFIER);

		Element modifier = null;

		HashMap<String, Element> hm = new LinkedHashMap<String, Element>();

		if (null != modifierList && modifierList.size() > 0) {

			for (int i = 0; i < modifierList.size(); i++) {

				modifier = (Element) modifierList.get(i);

				if (!YFCCommon.isVoid(modifier)) {

					String parentDiscountGuid = XMLUtil.getAttribute(modifier, KohlsPOCConstant.ATTR_PARENT_DISCOUNT_ID);

					if (!hm.containsKey(parentDiscountGuid)) {
						hm.put(parentDiscountGuid, modifier);
					}
				}

			}
		}

		Iterator itr = hm.keySet().iterator();
		while (itr.hasNext()) {
			String guid = (String) itr.next();
			Element modifierEle = hm.get(guid);
			if(logger.isDebugEnabled()){
				logger.debug(guid);
				logger.debug(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PRECEDENCE));
			}

		}

		logger.debug("Now sorted");
		HashMap<String, Element> sortedModifierMap = sortByValues(hm);

		Iterator itrAfter = sortedModifierMap.keySet().iterator();
		while (itrAfter.hasNext()) {
			String guid = (String) itrAfter.next();
			Element modifierEle = sortedModifierMap.get(guid);
			if(logger.isDebugEnabled()){
				logger.debug(guid+" Descending value");
				logger.debug(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PRECEDENCE)+"Descending order");
			}
		}

		logger.endTimer("KohlsPoCGenerateExtnPromoSequence.getSortedModifierMap");

		return sortedModifierMap;
	}

	private static HashMap sortByValues(HashMap map) {
		logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.sortByValues");
		List list = new LinkedList(map.entrySet());
		// Defined Custom Comparator here
		Collections.sort(list, new Comparator<Map.Entry<String, Element>>() {
			public int compare(Map.Entry<String, Element> o1, Map.Entry<String, Element> o2) {

				Element objValue1 = (Element) ((o1)).getValue();

				Integer precedence1 = Integer.parseInt(XMLUtil.getAttribute(objValue1, KohlsPOCConstant.ATTR_PRECEDENCE));

				Element objValue2 = (Element) ((o2)).getValue();

				Integer precedence2 = Integer.parseInt(XMLUtil.getAttribute(objValue2, KohlsPOCConstant.ATTR_PRECEDENCE));

				return ((precedence1)).compareTo(precedence2);

			}
		});

		// Here I am copying the sorted list in HashMap
		// using LinkedHashMap to preserve the insertion order
		HashMap sortedHashMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		logger.endTimer("KohlsPoCGenerateExtnPromoSequence.sortByValues");
		return sortedHashMap;
	}

	private static HashMap sortByScannedSequence(HashMap map) {

		logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.sortByScannedSequence");

		List list = new LinkedList(map.entrySet());
		// Defined Custom Comparator here
		Collections.sort(list, new Comparator<Map.Entry<String, Element>>() {
			public int compare(Map.Entry<String, Element> o1, Map.Entry<String, Element> o2) {

				Element objValue1 = (Element) ((o1)).getValue();

				Element objValue1Extn = XMLUtil.getChildElement(objValue1, KohlsPOCConstant.A_EXTN);

				Element objValue2 = (Element) ((o2)).getValue();

				Element objValue2Extn = XMLUtil.getChildElement(objValue2, KohlsPOCConstant.A_EXTN);

				Integer extnScannedSeq1 = Integer.parseInt(XMLUtil.getAttribute(objValue1Extn,
						KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE));

				Integer extnScannedSeq2 = Integer.parseInt(XMLUtil.getAttribute(objValue2Extn,
						KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE));

				return ((extnScannedSeq1)).compareTo(extnScannedSeq2);

			}
		});

		// Here we are copying the sorted list in HashMap
		// using LinkedHashMap to preserve the insertion order
		HashMap sortedHashMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		logger.endTimer("KohlsPoCGenerateExtnPromoSequence.sortByScannedSequence");

		return sortedHashMap;
	}

	
	private static HashMap sortByValuesDescending(HashMap map) {
		logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.sortByValues");
		List list = new LinkedList(map.entrySet());
		// Defined Custom Comparator here
		Collections.sort(list, new Comparator<Map.Entry<String, Element>>() {
			public int compare(Map.Entry<String, Element> o1, Map.Entry<String, Element> o2) {

				Element objValue1 = (Element) ((o1)).getValue();

				Integer precedence1 = Integer.parseInt(XMLUtil.getAttribute(objValue1, KohlsPOCConstant.ATTR_PRECEDENCE));

				Element objValue2 = (Element) ((o2)).getValue();

				Integer precedence2 = Integer.parseInt(XMLUtil.getAttribute(objValue2, KohlsPOCConstant.ATTR_PRECEDENCE));

				return ((precedence2)).compareTo(precedence1);

			}
		});

		// Here I am copying the sorted list in HashMap
		// using LinkedHashMap to preserve the insertion order
		HashMap sortedHashMap = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry entry = (Map.Entry) it.next();
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		logger.endTimer("KohlsPoCGenerateExtnPromoSequence.sortByValues");
		return sortedHashMap;
	}
	
	
	
	private static HashMap<String, String> getSortedOfferMap(Element tvsResponseEle) {

		logger.beginTimer("KohlsPoCGenerateExtnPromoSequence.getSortedOfferMap");

		if(logger.isDebugEnabled()){
			logger.debug("tvs response:" + "\n" + XMLUtil.getElementXMLString(tvsResponseEle));
		}

		List<Element> offerList = XMLUtil.getElementsByTagName(tvsResponseEle, KohlsPOCConstant.ELEM_OFFER);

		Element offer = null;

		HashMap<String, String> hm = new LinkedHashMap<String, String>();

		if (null != offerList && offerList.size() > 0) {

			for (int i = 0; i < offerList.size(); i++) {

				offer = (Element) offerList.get(i);

				if (!YFCCommon.isVoid(offer)) {

					String parentDiscountGuid = XMLUtil.getAttribute(offer, KohlsPOCConstant.ATTR_ID);
					String offerId = XMLUtil.getAttribute(offer, KohlsPOCConstant.ATTR_OFFER_ID);

					if (!hm.containsKey(parentDiscountGuid)) {
						hm.put(parentDiscountGuid, offerId);
					}
				}

			}
		}

		Iterator itr = hm.keySet().iterator();
		while (itr.hasNext()) {
			String guid = (String) itr.next();
			String modifierEle = hm.get(guid);
			logger.debug(guid);
			//logger.debug(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PRECEDENCE));

		}

		logger.debug("Now sorted");
		/*HashMap<String, String> sortedModifierMap = sortByValues(hm);

		Iterator itrAfter = sortedModifierMap.keySet().iterator();
		while (itrAfter.hasNext()) {
			String guid = (String) itrAfter.next();
			Element modifierEle = sortedModifierMap.get(guid);
			logger.debug(guid+" Descending value");
			logger.debug(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PRECEDENCE)+"Descending order");

		}*/

		logger.endTimer("KohlsPoCGenerateExtnPromoSequence.getSortedModifierMap");

		return hm;
	}


}
