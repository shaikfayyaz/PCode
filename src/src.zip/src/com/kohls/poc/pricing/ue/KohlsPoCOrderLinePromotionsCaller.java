package com.kohls.poc.pricing.ue;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoCOrderLinePromotionsCaller.java 
 * Author : IBM 
 * Created : August 27 2013 
 * Modified : August 27 2013 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * PLU call made for getting Pricing & Promo Response and Rebate Response.
 * Voided and Non Voided Items are differenciated and seperate LinkedHashMap is maintained for 
 * All the Promo information are kept in different LinkedHashMap
 * All the Order Line keys are kept in seperate LinkedHashMap which will be used for TaxWare
 * For Manual LID and Price Over Ride different LinkedHashMap is used
 * 
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/


public class KohlsPoCOrderLinePromotionsCaller {

	private Map<String, Element> orderLineHM;
	private Map<String, Element> orderLineVoidedHM;	
	private Map<String, String> itemIdHM;
	private Map<String, String> orderLineKeyHM;
	private Map<String, Element> pluPromoRecordHM;
	private Map<String, Element> orderLineManualLidHM;
	private Map<String, Element> orderLinePromotionOverrideHM;
	private String newItemId;
	private Element newOrderLineEle;

	/**
	 * While creating the instance of the class all the member variables are initialized with the new Object.
	 * To avoid sorting, LinkedHashMap is used.
	 *
	 */
	public KohlsPoCOrderLinePromotionsCaller() {
		this.orderLineHM = new LinkedHashMap<String, Element>();
		this.orderLineVoidedHM = new LinkedHashMap<String, Element>();		
		this.itemIdHM = new LinkedHashMap<String, String>();
		this.orderLineKeyHM = new LinkedHashMap<String, String>();
		this.pluPromoRecordHM = new LinkedHashMap<String, Element>();
		this.orderLineManualLidHM = new LinkedHashMap<String, Element>();
		this.orderLinePromotionOverrideHM = new LinkedHashMap<String, Element>();
	}

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCOrderLinePromotionsCaller.class.getName());
	}

	/**
	 * This method is called by KohlsPoCOrderRepriceUE for handling the Order Line Level Promotions
	 * If it is a new Item, PLU call is made and PLU romo Respose is stored in a CLOB column.
	 * If scanned item is a duplicate one, existing item PLU Promo Response and Rebate Resposne is copied into the newly scanned item
	 * 
	 *    
	 * @param orderLineList
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param createtsList
	 * @throws Exception
	 */

	public  String updateUeDocumentForPromo ( List<Element> orderLineList, YFSEnvironment yfsEnv, Element tempOrderEle, List<String> createtsList)
	throws Exception {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.updateUeDocumentForPromo");

		this.logger.debug("Method Name : updateUeDocumentForPromo   and   Status  ");

		String extnRequestDateTime = KohlsPoCPnPUtil.getExtnRequestTime(tempOrderEle);
		String voidTaxWare = KohlsPOCConstant.NO;


		//New item and existing items are differentiated   
		for (Element orderLine : orderLineList) {
			String status = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.A_MAX_LINE_STATUS);
			String orderedQty = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);

			Element extnElement = XMLUtil.getChildElement(orderLine,
					KohlsPOCConstant.E_EXTN);
			Element itemElement = XMLUtil.getChildElement(orderLine,
					KohlsPOCConstant.E_ITEM);
			String itemId = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.A_ITEM_ID);
			String extnPluPromoResponseFlag = XMLUtil.getAttribute(
					extnElement, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE_FLAG);

			// change for Fixing call to Taxware on void 
			if(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(itemId)){
				voidTaxWare = KohlsPOCConstant.YES;
				//OrderLine/Extn/@ExtnPluPromoResponseFlag is not present consider, it is a new item  
			}else if (YFCCommon.isStringVoid(extnPluPromoResponseFlag)) {	
				this.newItemId = itemId;
				this.newOrderLineEle = orderLine;

			} else if (extnPluPromoResponseFlag.equals(KohlsPOCConstant.YES)) {
				logger.debug("outside condition  orderedQty :"+orderedQty);
	            if(!YFCCommon.isVoid(orderedQty) && Double.parseDouble(orderedQty)>0.0){
	            		logger.debug("inside if condition  orderedQty :"+orderedQty);
					KohlsPoCPnPUtil.resetOrderLineDetails(orderLine);
					//KohlsPoCPnPUtil.resetOrderLineDetailsForAPEPLU(orderLine);
				}
				
				Element pluPromoResponseEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement
						.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE));
				this.insertGuidAttributeiInPromo(pluPromoResponseEle);
				extnElement.setAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE, XMLUtil
						.getElementXMLString(pluPromoResponseEle));
				String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
						orderLine, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);

				// voided items are kept in a seperate Linked HashMap , which is used copy the PLU Response and  Rebate Response 
				// Manoj 03/20: Fix for Defect 3924 - Begin - Changing the condition to compare the quantities in Double than in String)
				//if (KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(orderedQty)) {
				if (0.00D == Double.parseDouble(orderedQty)) {
					this.orderLineVoidedHM.put(guidStr, orderLine);
				} 
				// Manoj 03/20: Fix for Defect 3924 - End
				else {
					this.orderLineHM.put(guidStr, orderLine);
					String orderLineKey = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
					this.orderLineKeyHM.put(orderLineKey, guidStr);
				}

				String isSuspendedOrderLine = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.CONDITION_VARIABLE_TWO);
				if (!KohlsPOCConstant.YES.equalsIgnoreCase(isSuspendedOrderLine)) {
					this.itemIdHM.put(itemId, guidStr);
				}
			}

			Element promotionsEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_PROMOTIONS);

			if (!YFCCommon.isVoid(promotionsEle)) {
				promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
			}

			//For Price Override and Manual LID
			List<Element> linePromotionList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_PROMOTION);

			if (linePromotionList.size() > KohlsPOCConstant.ZERO_INT && !KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(orderedQty)) {

				for (Element linePromotionEle : linePromotionList) {

					String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
							linePromotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
					String promotionType = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
					String createts = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_CREATE_TS);

					if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)) {
						this.orderLineManualLidHM.put(guidStr, linePromotionEle);
					} else if (KohlsPOCConstant.PRICE_OVERRIDE.equalsIgnoreCase(promotionType)) {
						this.orderLinePromotionOverrideHM.put(guidStr, linePromotionEle);
					}

					createtsList.add(createts);

				}
			}
		}

		//If scanned item is duplicate one, existing item PLU Promo Response and Rebate Response is reused.

		if (this.itemIdHM.containsKey(this.newItemId)) {
			String uuidStr = this.itemIdHM.get(this.newItemId);
			Element existingOrderLine = this.orderLineHM.get(uuidStr);

			//Fetch from Voided OrderLine LinkedHashMap
			if (YFCCommon.isVoid(existingOrderLine)) {
				existingOrderLine = this.orderLineVoidedHM.get(uuidStr);
			}

			Element extnElement = XMLUtil.getChildElement(
					existingOrderLine, KohlsPOCConstant.E_EXTN);
			Element pluPromoResponseEle = 
				KohlsPoCPnPUtil.createElementFromXMLString(extnElement
						.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE));

			// Verify Price Override Indicator is Y
			this.verifyPricePromptIndicator(pluPromoResponseEle); 
			this.addPLUResponseInTempDoc(pluPromoResponseEle);
			this.addRebateResponseDoc(existingOrderLine);	

			//If it is a new Item , PLU call is invoked.
		} else if (!YFCCommon.isStringVoid(this.newItemId)) {
			try{
				String shipNode = XMLUtil.getAttribute(this.newOrderLineEle, KohlsPOCConstant.ATTR_SHIP_NODE);
				// Appending zero when store number length is less than 4
				shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
				KohlsPoCPLURequestCreator pluRequestForPRomo = new KohlsPoCPLURequestCreator(KohlsPOCConstant.SKU, shipNode);
				Document pluRequestDocument = pluRequestForPRomo.constructPLURequestDocument(this.newItemId, extnRequestDateTime);
				
				
				if(logger.isDebugEnabled())
					this.logger.debug(XMLUtil.getXMLString(pluRequestDocument));

				Document pluResponseDoc = null;
				pluResponseDoc = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_PLU_WEB_SERVICE, pluRequestDocument);
				Element pluPromoResponseEle = pluResponseDoc.getDocumentElement();
				
				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getElementXMLString(pluPromoResponseEle));

				
				KohlsPoCPnPUtil.validatePluResponse(pluPromoResponseEle);
				this.insertGroupPricingPromoElement(pluPromoResponseEle);
				this.verifyCallBackIndicator(pluPromoResponseEle);
				this.verifyPricePromptIndicator(pluPromoResponseEle);
				this.addPLUResponseInTempDoc(pluPromoResponseEle); 
				this.verifyRebateDiscount(yfsEnv, pluPromoResponseEle, pluRequestDocument);
			}catch(Exception e){
				e.printStackTrace();
				if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

					YFSException yfsException = new YFSException();
					YFSException es = (YFSException) e;

					// Connect Exception
					if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
						yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
						yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
					}

					// IO Exception
					else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
						yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
						yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
					}

					// Other Exceptions
					else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
						yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
						yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
					}
					else{
						throw es;
					}
					throw yfsException;
				}
				else{
					throw e;
				}			
			}
		}
		this.logger.debug("Method Name : updateUeDocumentForPromo   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.updateUeDocumentForPromo");

		return voidTaxWare;
	}

	/**
	 * Adding the Rebate response in the OrderLine/Awards/Award/Extn/@ExtnRebateResponse as a CLOB
	 * @param existingOrderLine
	 * @throws Exception
	 */
	private void addRebateResponseDoc(Element existingOrderLine) throws Exception {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.addRebateResponseDoc");

		this.logger.debug("Method Name : addRebateResponseDoc   and   Status  ");
		List<Element> awardEleList = XMLUtil.getElementsByTagName(
				existingOrderLine, KohlsPOCConstant.E_AWARD);
		if (awardEleList.size() > KohlsPOCConstant.ZERO_INT) {

			for (Element awardEle : awardEleList) {
				String rebateResponse = KohlsPOCConstant.EMPTY;
				Element extnEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN);

				if (!YFCCommon.isVoid(extnEle)) {
					rebateResponse = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_REBATE_RESPONSE);
				}

				if (!YFCCommon.isStringVoid(rebateResponse)) {
					Element rebateResponseEle = KohlsPoCPnPUtil.createElementFromXMLString(rebateResponse);
					this.createAwardElementforRebate(rebateResponseEle, this.newOrderLineEle);
				}
			}
		}
		this.logger.debug("Method Name : addRebateResponseDoc   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.addRebateResponseDoc");

	}

	/**
	 * PLU Response has the Rebate Promo ( Promo Scheme Code is 0700), Rebate web service call is made. 
	 * Response is stored in the OrderLine level Award element as a CLOB
	 * @param yfsEnv
	 * @param pluPromoResponseEle
	 * @param pluRequestDocument
	 * @throws Exception
	 */
	private void verifyRebateDiscount(YFSEnvironment yfsEnv, Element pluPromoResponseEle, Document pluRequestDocument) throws Exception {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.verifyRebateDiscount");


		this.logger.debug("Method Name : verifyRebateDiscount   and   Status  ");
		try{
			Element rebateRequestEle = pluRequestDocument.getDocumentElement();

			final List<Element> promoList = XMLUtil.getElementsByTagName(pluPromoResponseEle, KohlsPOCConstant.E_PROMO);
			if (promoList.size() > KohlsPOCConstant.ZERO_INT 
			) {

				final List<Element> recordList = XMLUtil.getElementsByTagName(promoList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);

				if (recordList.size() > KohlsPOCConstant.ZERO_INT) {

					for (Element recordEle : recordList) {

						String promoSchemeCode = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE);

						if (Integer.valueOf(KohlsPOCConstant.PROMO_REBATE).equals(Integer.valueOf(promoSchemeCode))) {

							List<Element> parametersEleList = 	XMLUtil.getElementsByTagName(rebateRequestEle, KohlsPOCConstant.E_PARAMETERS);
							XMLUtil.setAttribute(parametersEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_LOOKUPTYPE, KohlsPOCConstant.FORM);
							XMLUtil.setAttribute(parametersEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_KEY, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_ID));
							
							
							if(logger.isDebugEnabled())
								this.logger.debug(XMLUtil.getElementXMLString(rebateRequestEle));
		
							
							Document rebateResponseDoc = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_PLU_WEB_SERVICE, XMLUtil.getDocumentForElement(rebateRequestEle));
							
							
							if(logger.isDebugEnabled())
								this.logger.debug(XMLUtil.getXMLString(rebateResponseDoc));

							Element rebateResponseEle = rebateResponseDoc.getDocumentElement();

						

							KohlsPoCPnPUtil.validatePluResponse(rebateResponseEle);

							List<Element> formEleList = XMLUtil.getElementsByTagName(rebateResponseEle, KohlsPOCConstant.FORM);

							if(formEleList.size() > KohlsPOCConstant.ZERO_INT){
								rebateResponseEle = formEleList.get(KohlsPOCConstant.ZERO_INT);
							}

							this.createAwardElementforRebate(rebateResponseEle, this.newOrderLineEle);

						}
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

				YFSException yfsException = new YFSException();
				YFSException es = (YFSException) e;

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
					yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
				}

				// IO Exception
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
					yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
				}

				// Other Exceptions
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
					yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
				}	
				else{
					throw es;
				}
				throw yfsException;
			}
			else{
				throw e;
			}			
		}
		this.logger.debug("Method Name : verifyRebateDiscount   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.verifyRebateDiscount");

	}

	/**
	 * This method is helpful for create the Award Element with the Rebate Response CLOB column
	 * @param rebateResponseDoc
	 * @param orderLineEle
	 */
	private void createAwardElementforRebate(Element rebateResponseEle, Element orderLineEle) {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.createAwardElementforRebate");

		this.logger.debug("Method Name : createAwardElementforRebate   and   Status  ");
		Element awardsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, Boolean.TRUE);
		Element awardEle = XMLUtil.createChild(awardsEle, KohlsPOCConstant.E_AWARD);
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, KohlsPOCConstant.REBATE_ITEM);
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
		Element extnEle = XMLUtil.createChild(awardEle, KohlsPOCConstant.E_EXTN);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_REBATE_RESPONSE, XMLUtil
				.getElementXMLString(rebateResponseEle));
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMO_SCHEME,KohlsPOCConstant.PROMO_REBATE);		
		this.logger.debug("Method Name : createAwardElementforRebate   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.createAwardElementforRebate");


	}

	/**
	 * Inserting the Guid in the Promo Element.
	 * Ex : <Temp Guid=""/>
	 * @param pluPromoResponseEle
	 */
	public void insertGuidAttributeiInPromo(Element pluPromoResponseEle) {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.insertGuidAttributeiInPromo");

		this.logger.debug("Method Name : insertGuidAttributeiInPromo   and   Status  ");
		List<Element> promoEleList = XMLUtil.getElementsByTagName(
				pluPromoResponseEle, KohlsPOCConstant.E_PROMO);
		if (promoEleList.size() > KohlsPOCConstant.ZERO_INT) {
			Element promoEle = promoEleList.get(KohlsPOCConstant.ZERO_INT);

			if (null != promoEle) {
				List<Element> recordList = XMLUtil.getElementsByTagName(
						promoEle, KohlsPOCConstant.E_RECORD);

				if (recordList.size() > KohlsPOCConstant.ZERO_INT) {
					this.insertGuidInRecordElements(recordList, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
				}
			}
		}
		this.logger.debug("Method Name : insertGuidAttributeiInPromo   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.insertGuidAttributeiInPromo");

	}

	/**
	 * Inserting the Guid in the 'Record' element.
	 * Ex :  <Temp Guid=""/>
	 * @param elementList
	 * @param childName
	 * @param attributeName
	 */
	private void insertGuidInRecordElements(List<Element> elementList,
			String childName,  String attributeName) {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.insertGuidInRecordElements");

		if (null != elementList) {

			for (Element element : elementList) {
				String uuidStr = UUID.randomUUID().toString();
				Element childElement = XMLUtil.getChildElement(element, childName, Boolean.TRUE);
				XMLUtil.setAttribute(childElement, attributeName, uuidStr);
				this.pluPromoRecordHM.put(uuidStr, element);
			}
		}
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.insertGuidInRecordElements");

	}


	/**
	 * If conditions satisfy the eligibility for PricePromptIndicator 
	 * throws the user exist exception with the 'PLUPRICEREQ' value.
	 *  
	 * @param pluPromoResponseEle
	 * @throws YFSUserExitException
	 */
	private void verifyPricePromptIndicator(
			Element pluPromoResponseEle) throws YFSException {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.verifyPricePromptIndicator");

		this.logger.debug("Method Name : verifyPricePromptIndicator   and   Status  ");
		List<Element> pluFileList = XMLUtil.getElementsByTagName(
				pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT) {
			Element recordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);

			if (null != recordEle) {
				String priceOverrideInd = recordEle.getAttribute(KohlsPOCConstant.A_PRMPT_FOR_PRIC_IND);
				String multiPricePointIndicator =  recordEle.getAttribute(KohlsPOCConstant.A_MLT_PRPT_IND);
				String unitRetailAmt = recordEle.getAttribute(KohlsPOCConstant.A_UNT_RTL_AMT);

					if (KohlsPOCConstant.YES.equalsIgnoreCase(priceOverrideInd) || KohlsPOCConstant.YES.equalsIgnoreCase(multiPricePointIndicator)) {
						
						
						/* Commenting the below code block, as OrderLine/@ExtnIsPriceEntered is being used to determine if the price is entered , instead of 
						 * OrderLine/LinePriceInfo/@UnitPrice
						 * 
						 */
						
						
						/*Element linePriceInfonewOrderLine = XMLUtil.getChildElement(this.newOrderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
	
						if (null != linePriceInfonewOrderLine) {
							String unitPrice = XMLUtil.getAttribute(linePriceInfonewOrderLine,
									KohlsPOCConstant.A_UNIT_PRICE);
	
							if (YFCCommon.isStringVoid(unitPrice) || KohlsPOCConstant.ZERO_DBL == Double.valueOf(unitPrice).doubleValue()) {
								YFSException yfsException = new YFSException();
								yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
								yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUPRICEREQ));
								throw yfsException;
							} else {
								String updatedunitPrice = String.valueOf(Double.parseDouble(unitPrice) * KohlsPOCConstant.HUNDRED_INT);
								XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_UNT_RTL_AMT, updatedunitPrice);
							}
						}*/
						
						// Start :Defect Fix : 1055 
						
						Element extnEle = XMLUtil.getChildElement(this.newOrderLineEle, KohlsPOCConstant.E_EXTN);
						
						if(null != extnEle){						
							// Retrieving OrderLine/Extn/@ExtnIsPriceEntered
							String extnIsPriceEntered = XMLUtil.getAttribute(extnEle,
									KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);
							
							// if @ExtnIsPriceEntered is blank or N, throw PriceReq exception.
							
							if (YFCCommon.isStringVoid(extnIsPriceEntered) || KohlsPOCConstant.NO.equalsIgnoreCase(extnIsPriceEntered)) {
								YFSException yfsException = new YFSException();
								yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
								yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUPRICEREQ));
								throw yfsException;
							}
	
						}
						
						// End :Defect Fix : 1055 
					}
			}
		}
		this.logger.debug("Method Name : verifyPricePromptIndicator   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.verifyPricePromptIndicator");

	}

	/**
	 * Add the PLU Promo Response in the OrderLine/Extn/@ExtnPromoResponse as a CLOB
	 * @param pluPromoResponseEle
	 */
	private void addPLUResponseInTempDoc(Element pluPromoResponseEle) {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.addPLUResponseInTempDoc");

		this.logger.debug("Method Name : addPLUResponseInTempDoc   and   Status  ");
		this.insertGuidAttributeiInPromo(pluPromoResponseEle);
		Element extnEle = XMLUtil.getChildElement(this.newOrderLineEle,
				KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE, XMLUtil
				.getElementXMLString(pluPromoResponseEle));
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE_FLAG, KohlsPOCConstant.YES);
		String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(this.newOrderLineEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);

		//logger.debug(XMLUtil.getElementXMLString(newOrderLineEle));


		this.orderLineHM.put(guidStr, this.newOrderLineEle);
		String orderLineKey = XMLUtil.getAttribute(this.newOrderLineEle, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
		this.orderLineKeyHM.put(orderLineKey, guidStr);
		this.logger.debug("Method Name : addPLUResponseInTempDoc   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.addPLUResponseInTempDoc");

	}

	/**
	 * If the GroupPricingPromo (Promo Scheme Code : 0350) create a Record element under PLU Response Promo Element
	 * with the necessary attributes
	 * @param pluPromoResponseEle
	 */
	public void insertGroupPricingPromoElement(Element pluPromoResponseEle) {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.insertGroupPricingPromoElement");

		this.logger.debug("Method Name : insertGroupPricingPromoElement   and   Status  ");
		final List<Element> pluFileList = XMLUtil.getElementsByTagName(pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT && null != pluFileList.get(KohlsPOCConstant.ZERO_INT)) {
			Element pluFileRecordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
			String groupPriceID = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_PRIC_ID);

			if(!YFCCommon.isStringVoid(groupPriceID)){
				String groupRetailAmount = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_AMT);
				String groupRetailQty = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_QTY);

				if (!YFCCommon.isStringVoid(groupRetailAmount) && (Double.valueOf(groupRetailAmount).doubleValue() > KohlsPOCConstant.ZERO_DBL)
						|| !YFCCommon.isStringVoid(groupRetailQty) && (Double.valueOf(groupRetailQty).doubleValue() > KohlsPOCConstant.ZERO_DBL)) {
					Element parentEle = (Element) pluFileList.get(KohlsPOCConstant.ZERO_INT).getParentNode();
					Element promoEle = XMLUtil.getChildElement(parentEle, KohlsPOCConstant.E_PROMO, Boolean.TRUE);
					Element recordEle = XMLUtil.createChild(promoEle, KohlsPOCConstant.E_RECORD);
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE, KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO);
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_ID, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_PRIC_ID));
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_AMT));
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_QTY));

				}
			}		
		}
		this.logger.debug("Method Name : insertGroupPricingPromoElement   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.insertGroupPricingPromoElement");

	}

	/**
	 *  If the CallBack Indicator conditions is statisfied.
	 *  Throws the User Exit Exception with "PLUCALLBACK"
	 * @param pluPromoResponseEle
	 * @throws YFSUserExitException
	 */
	private void verifyCallBackIndicator(Element pluPromoResponseEle) throws YFSException {
		logger.beginTimer("KohlsPoCOrderLinePromotionsCaller.verifyCallBackIndicator");

		this.logger.debug("Method Name : verifyCallBackIndicator   and   Status  ");
		List<Element> pluFileList = XMLUtil.getElementsByTagName(
				pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT) {
			Element recordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
			String callBackIndicator = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_CALL_BACK);

			if (KohlsPOCConstant.YES.equalsIgnoreCase(callBackIndicator)) {
				YFSException yfsException = new YFSException();
				yfsException.setErrorCode(KohlsPOCConstant.PLUCALLBACK);
				yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUCALLBACK));
				throw yfsException;
			}
		}
		this.logger.debug("Method Name : verifyCallBackIndicator   and   Status  ");
		logger.endTimer("KohlsPoCOrderLinePromotionsCaller.verifyCallBackIndicator");

	}

	/**
	 * 
	 * @return orderLineHM
	 */
	public Map<String, Element> getOrderLineHM() {
		return this.orderLineHM;
	}

	/**
	 * 
	 * @return orderLineKeyHM
	 */
	public Map<String, String> getOrderLineKeyHM() {
		return this.orderLineKeyHM;
	}

	/**
	 * 
	 * @return pluPromoRecordHM
	 */
	public Map<String, Element> getPluPromoRecordHM() {
		return this.pluPromoRecordHM;
	}

	/**
	 * 
	 * @return orderLineManualLidHM
	 */
	public Map<String, Element> getOrderLineManualLidHM() {
		return this.orderLineManualLidHM;
	}

	/**
	 * 
	 * @return orderLinePromotionOverrideHM
	 */
	public Map<String, Element> getOrderLinePromotionOverrideHM() {
		return this.orderLinePromotionOverrideHM;
	}
	
	public void cleanUp(){
		this.orderLineHM = null;
		this.orderLineVoidedHM = null;		
		this.itemIdHM = null;
		this.orderLineKeyHM = null;
		this.pluPromoRecordHM = null;
		this.orderLineManualLidHM = null;
		this.orderLinePromotionOverrideHM = null;
	}
}
