package com.kohls.poc.pricing.ue;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.kohlscash.ue.KohlsPoCKohlsCashInquiryRequestCreator;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoCTVSOrderPromotionsCaller.java
 * Author : IBM
 * Created : July 15 2015
 * Modified : July 15 2015
 * Version : 0.1
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 15/07/2015 IBM First Cut.
 *****************************************************************************
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2015. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 * KohlsCashInquiry service call made for getting Kohls Cash,Legacy Copon Response.
 * Order Level Promotins Offer, Kohls Cash, Manual TLD are handled.
 * Put the TLD Promotions in one LinkedHashMap
 *
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/


public class KohlsPoCTVSOrderPromotionsCaller {
	
	private Map<String, String> orderAssociateHM;
	String promotionIdForDesc =  null;
	private Map<String, Element> orderTLDHM;
	private String newPromotionId;
	private Element newPromotionEle;
	private String newOrdPromotionID;
	private Map<String, Element> voidResetAwardMap;
	private Map<String, Element> LIDAwardMap;
	private Map<String, Element> promoDiscAwardMap;
	private Map<String, Integer> awardSequenceMap;
	
	public KohlsPoCTVSOrderPromotionsCaller() {
		this.orderAssociateHM = new LinkedHashMap<String, String>();
		this.orderTLDHM = new LinkedHashMap<String, Element>();
		this.voidResetAwardMap = new LinkedHashMap<String, Element>();
		this.LIDAwardMap = new LinkedHashMap<String, Element>();
		this.promoDiscAwardMap = new LinkedHashMap<String, Element>();
		this.awardSequenceMap = new HashMap<String, Integer>();
	}
	
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCTVSOrderPromotionsCaller.class.getName());
	}
	
	
	/**
	 *  This method is helpful for handling the Order Level Promotions
	 *
	 *
	 * @param orderPromotionList
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param createtsList
	 * @throws Exception
	 */
	public void updateUeDocumentForTLD (List<Element> orderPromotionList, YFSEnvironment yfsEnv,Element tempOrderEle, List<String> createtsList)
			throws Exception {
		
		logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.updateUeDocumentForTLD");
		logger.debug("Method Name : updateUeDocumentForTLD   and   Status  ");
		
		String shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
		//String extnRequestDateTime = KohlsPoCPnPUtil.getExtnRequestTime(tempOrderEle);
		
		
		int i = KohlsPOCConstant.TLD_ID;
		int j = KohlsPOCConstant.ONE_INT;
		for (Element promotionEle : orderPromotionList)
		{

            String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
			if(KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase(promotionType)){
				
				continue;
			} 

			String ordPromotionID = (String)(Integer.toString(i+j));
			
			j=j+1;
			Element extnElement = XMLUtil.getChildElement(promotionEle,	KohlsPOCConstant.E_EXTN);
			String extnPromotionFlag = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
			
			
			String promotionId = KohlsPoCPnPUtil.getPromotionIdForAPE(XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID));
			if(logger.isDebugEnabled()){
			logger.debug("ordPromotionID of Promotion "+XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID));
			}
			promotionIdForDesc = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
			promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
			logger.debug("promotionType of Promotion "+promotionType);
			String createts = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_CREATE_TS);
			String action = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_ACTION);
			String extnOffLineMode = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
			
			Element tempEle =  XMLUtil.createChild(promotionEle, KohlsPOCConstant.E_TEMP);
			XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, ordPromotionID);
			if(KohlsPoCPnPUtil.isSUPC(promotionId)){
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, promotionId);
			}
			if (YFCCommon.isStringVoid(extnPromotionFlag) &&
						!(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))) {
				//PRF-303 cleaned up the code  
				this.newPromotionId = promotionId;
				this.newPromotionEle = promotionEle;
				
				// Added for 5358 defect fix
				XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
				
				nonAssociateDiscountFlow(promotionType, ordPromotionID, yfsEnv, tempOrderEle, extnOffLineMode);
			} else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))
			{
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
				this.orderTLDHM.put(ordPromotionID, promotionEle);
				
			} else if (!KohlsPOCConstant.REMOVE.equalsIgnoreCase(action) && !(YFCCommon.isStringVoid(extnPromotionFlag))) {
				/*String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
						promotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);*/
				//Fix for 1795 and 1793
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
				if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
					this.orderTLDHM.put(ordPromotionID, promotionEle);
				} else if (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)|| KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType)) {

					if(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)){
						//setPromotionDescriptionForKohlsCashOffline(promotionIdForDesc,promotionEle);
						this.orderTLDHM.put(ordPromotionID, promotionEle);
					}else{
						//Element kohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
						//setPromotionDescriptionForKohlsCash(promotionIdForDesc, kohlsCashResposneEle, promotionEle);
						this.orderTLDHM.put(ordPromotionID, promotionEle);
					}

				} else if (KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType)) {
					//It sets default promotion description for the Coupons (Offers) Fix for 1795 and 1793
					//Element pluOfferResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
					//setDefaultPromotionDescription(promotionIdForDesc,pluOfferResposneEle,promotionEle);
					this.orderTLDHM.put(promotionId, promotionEle);
				}else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
				this.orderTLDHM.put(ordPromotionID, promotionEle);
				}
				createtsList.add(createts);
			}
		}
		
		logger.debug("Method Name : updateUeDocumentForTLD   and   Status  ");
		logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.updateUeDocumentForTLD");

	}
	
	protected void nonAssociateDiscountFlow(String promotionType, String ordPromotionID, YFSEnvironment yfsEnv,Element tempOrderEle, String extnOffLineMode) throws Exception {

		switch (promotionType) {
		case KohlsPOCConstant.AMOUNT_OFF:
			amountOff(promotionType, ordPromotionID);
			break;
		case KohlsPOCConstant.QUICK_CREDIT_DISCOUNT:
			quickCreditDiscont(promotionType, ordPromotionID);
			break;
		case KohlsPOCConstant.PERCENT_OFF:
			percentOff(promotionType, ordPromotionID);
			break;
		case KohlsPOCConstant.SENIOR_DISCOUNT:
			seniorDiscount(yfsEnv, tempOrderEle, ordPromotionID);
			break;
		default:
			kohlsCashAndOfferFlow(yfsEnv, tempOrderEle, ordPromotionID, extnOffLineMode, promotionType);
			break;
		}
		
	}
	
	private void kohlsCashAndOfferFlow(YFSEnvironment yfsEnv, Element tempOrderEle, String ordPromotionID,
			String extnOffLineMode, String promotionType) throws Exception {

		String shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		// Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);

		if (KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)) {
			logger.debug("Offline Mode KohlsCash call..");
			updateNewOffLineKohlsCashDetails(newPromotionEle, ordPromotionID);

		} else {
			// TODO there should be a better way to check if KC service call is
			// down
			boolean checkKcServiceStatus = Boolean.FALSE;
			try {
				// PRF-303 changes
				// Check if gravity sends the promotionType as OFFER or check if KC logic
				if (KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType)) {
					applyOffer();
				}else {
					// Check is the scan item is KC by internal logic
					Document kohlsCashinputDoc = createkohlsCashInquiryRequest()
							.constructKohlsCashInquiryDocument(yfsEnv, tempOrderEle, newPromotionEle, shipNode);
					if (logger.isDebugEnabled()) {
						logger.debug(XMLUtil.getXMLString(kohlsCashinputDoc));
					}
					// Calling KohlsCash Web Service
					Document KohlsCashResponse = executeKohlsCashService(yfsEnv, kohlsCashinputDoc);
					if (logger.isDebugEnabled()) {
						logger.debug(XMLUtil.getXMLString(KohlsCashResponse));
					}
					Element kohlsCashResponseEle = KohlsCashResponse.getDocumentElement();
					Element dataEle = (Element) XMLUtil
							.getElementsByTagName(kohlsCashResponseEle, KohlsPOCConstant.E_DATA)
							.get(KohlsPOCConstant.ZERO_INT);
					String status = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_TYPE);
					checkKcServiceStatus = Boolean.TRUE;

					if (!YFCCommon.isStringVoid(status) && !KohlsPOCConstant.NONE.equalsIgnoreCase(status)) {
						validateKohlsCashResponse(kohlsCashResponseEle);
						updateNewKohlsCashDetails(newPromotionEle, kohlsCashResponseEle, status, newPromotionId);
					} else {
						//Just to be sure if status comes out as non KC
						applyOffer();
					}

					logger.debug("Kohls Cash Response Formated");
					if (logger.isDebugEnabled()) {
						logger.debug(XMLUtil.getXMLString(KohlsCashResponse));
					}

				}

			} catch (YFSException e) {
				// Fix for defect 1027 - Start
				if (!checkKcServiceStatus) {
					XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.OFFER);
					this.orderTLDHM.put(newPromotionId, newPromotionEle);
					e.setErrorCode(KohlsPOCConstant.KOHLS_CASH_DOWN);
					e.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.CONST_KC_OFFLINE));
					throw e;
				} else {
					throw e;
				}
			}
		}
	}

	protected KohlsPoCKohlsCashInquiryRequestCreator createkohlsCashInquiryRequest() {
		return new KohlsPoCKohlsCashInquiryRequestCreator();
	}
	
	private void applyOffer() {
		logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.applyOffer");
		XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.OFFER);
		// Changed for Defect #644 - Start
		Element tempEleNew = XMLUtil.getChildElement(newPromotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
		if (tempEleNew != null) {
			XMLUtil.setAttribute(tempEleNew, KohlsPOCConstant.A_ID, newPromotionId);
		}
		// Changed for Defect #644 - End
		this.orderTLDHM.put(newPromotionId, newPromotionEle);
		logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.applyOffer");
	}
	
	private void seniorDiscount(YFSEnvironment yfsEnv,Element tempOrderEle, String ordPromotionID) throws Exception{

		logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.seniorDiscount");
		logger.debug("Entering Senior Discount Processing..");

		// Changes for Sprint 9.1 - Start

		// call the KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv,
		// tempOrderEle) to get the business date value.
		String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE;

		Document seniorDiscountAPIoutDoc = KohlsPoCPnPUtil.getRuleListForPOSCaller(yfsEnv, tempOrderEle, ruleId);
		Element seniorDiscountAPIoutDocEle = seniorDiscountAPIoutDoc.getDocumentElement();

		String strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv, tempOrderEle,
				ruleId);
		logger.debug("The strDiscountValueFromUtil value is: " + strDiscountValueFromUtil);
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		String extnDiscountPercent = twoDForm.format(Double.valueOf(strDiscountValueFromUtil));
		logger.debug("The extnDiscountPercent formated value is: " + extnDiscountPercent);
		Element extnEle = XMLUtil.getChildElement(newPromotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, extnDiscountPercent);

		// Added for TLD description for sprint-8 -- Start

		String snrDis = KohlsPOCConstant.SENIOR_DISC;
		String[] args = { snrDis };
		String promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROPE_KEY, args);

		// Added for TLD description for sprint-8 -- End

		XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_DESCRIPTION, promotionDesc);
		XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.SENIOR_DISCOUNT);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE,
				XMLUtil.getElementXMLString(seniorDiscountAPIoutDocEle));
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

		this.orderTLDHM.put(ordPromotionID, newPromotionEle);
		logger.debug("Exiting Senior Discount Processing..");
		logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.seniorDiscount");

	}
	
	private void quickCreditDiscont(String promotionType, String ordPromotionID) {
		// Same logic as percent off
		percentOff(promotionType, ordPromotionID);
	}

	private void amountOff(String promotionType, String ordPromotionID) {
		// Same logic as percent off
		percentOff(promotionType, ordPromotionID);
	}

	private void percentOff(String promotionType, String ordPromotionID) {

		logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.percentOff/amountOff/quickCreditDiscont");
		Element extnEle = XMLUtil.getChildElement(newPromotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

		String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
		String overrideMaxAdjustment = XMLUtil.getAttribute(newPromotionEle,
				KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);

		if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
			overrideAdjustmentValue = overrideMaxAdjustment;
		} else {
			overrideAdjustmentValue = XMLUtil.getAttribute(newPromotionEle,
					KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
		}

		String promotionDesc = KohlsPOCConstant.EMPTY;
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);

		if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT, overrideAdjustmentValue);
			// Added for TLD Description for Sprint-8 --- Start

			String tldDolar = KohlsPOCConstant.TLD_DOLLAR_DESCRIPTION;
			String[] args = { tldDolar };

			// Added for TLD Description for Sprint-8 --- End
			promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_ORDER_PROP_KEY, args);
		} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)
				|| KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT,
					twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));

			String[] args = { String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue).intValue())) };
			// Fix for defect 2322 and 2333 - Start
			if (KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
				promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.QUICK_CREDIT_TLD_ORDER_PROP_KEY,
						args);
			} else {
				promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_ORDER_PROP_KEY, args);
			}
			// Fix for defect 2322 and 2333 - End

		}

		XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_DESCRIPTION, promotionDesc);

		// Fix for defect 1974 End

		this.orderTLDHM.put(ordPromotionID, newPromotionEle);
		logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.percentOff/amountOff/quickCreditDiscont");

	}
			
		
		private void updateNewOffLineKohlsCashDetails(Element promotionEle,String ordPromotionID) {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewOffLineKohlsCashDetails");

			Element extnEle = XMLUtil.getChildElement(promotionEle,
					KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			
			setPromotionDescriptionForKohlsCashOffline(promotionIdForDesc,promotionEle);
			this.orderTLDHM.put(ordPromotionID, promotionEle);
			
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewOffLineKohlsCashDetails");

		}
		
		private void setPromotionDescriptionForKohlsCashOffline(String promotionIdForDesc, Element promotionEle) {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.setPromotionDescriptionForKohlsCashOffline");

			this.logger.debug("Method Name : setPromotionDescriptionForKohlsCashOffline   and   Status  ");
			
			DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
			String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
			
			Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
			String extnCouponAmount = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
			
			/* Modified the condition, if extnCouponAmount is present and greater than 0.0 setting the value to overrideAdjustmentValue */   
			if(!YFCCommon.isStringVoid(extnCouponAmount) && Double.valueOf(extnCouponAmount).doubleValue() > KohlsPOCConstant.ZERO_DBL){
				overrideAdjustmentValue = extnCouponAmount;			
			}else{
				if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
					overrideAdjustmentValue = overrideMaxAdjustment;
				} else {
					overrideAdjustmentValue = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
				}
				overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,overrideAdjustmentValue);
			}
			
			//Added for TLD Description for Sprint-8 -- Start
			//String[] args2 = {promotionIdForDesc,twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue)))};
			String promotionDesc =  promotionIdForDesc.substring((promotionIdForDesc.length())-KohlsPOCConstant.FIVE_INT);
			String[] args2 = {promotionDesc};
			//Added for TLD Description for Sprint-8 -- End
			String promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
			
			XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
			
			this.logger.debug("Method Name : setPromotionDescriptionForKohlsCashOffline   and   Status  ");
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.setPromotionDescriptionForKohlsCashOffline");

		}
		
		/**
		 *
		 * @param kohlsCashResponseEle
		 * @throws YFSUserExitException
		 */
		private void validateKohlsCashResponse(Element kohlsCashResponseEle) throws YFSException {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.validateKohlsCashResponse");

			this.logger.debug("Method Name : validateKohlsCashResponse   and   Status  ");

			Element dataEle = (Element) XMLUtil.getElementsByTagName(kohlsCashResponseEle, KohlsPOCConstant.E_DATA).get(KohlsPOCConstant.ZERO_INT);

			if (null != dataEle) {
				String authResponseCode = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
				String couponBalance = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_BALANCE);
				String couponType = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_TYPE);
				String couponStatus = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_STATUS);
				String errorMessageToDisplay = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_ERROR_MESSAGE_TO_DISPLAY);
				String historyData = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_HISTORY_DATA);

				// For Kohl's cash Auth
				if (null != couponType && !YFCCommon.isStringVoid(couponType) && KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType)) {
					if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_PRE_REDEMPTION.equalsIgnoreCase(couponStatus)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV_YET, errorMessageToDisplay);
					} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus)) {

						String couponBalanceErrorMessage = null;
						String couponBalancePostRedeem = null;
						if(!YFCCommon.isStringVoid(couponBalance)) {
							DecimalFormat twoDCouponBalance = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
							couponBalancePostRedeem = twoDCouponBalance.format(Double.valueOf(couponBalance));
							couponBalanceErrorMessage = KohlsPOCConstant.BALANCE +  KohlsPOCConstant.DOLLAR_SYMPOL + couponBalancePostRedeem;
						}

						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_EXPIRED, errorMessageToDisplay + KohlsPOCConstant.SPACE + couponBalanceErrorMessage);
					} else if (!YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)) {
						if (!YFCCommon.isStringVoid(authResponseCode) && (KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode)
								&& (Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL))) {

						} else if (null != authResponseCode && (KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode)
								&& (Double.valueOf(couponBalance).doubleValue() <= KohlsPOCConstant.ZERO_DBL))) {
							KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NO_BALANCE, historyData);
						} else if (null != authResponseCode && KohlsPOCConstant.EIGHT.equalsIgnoreCase(authResponseCode)) {
							KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_DUP_REC_FND, errorMessageToDisplay);
						} else if (null != authResponseCode && KohlsPOCConstant.SEVEN.equalsIgnoreCase(authResponseCode)) {
							KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV, errorMessageToDisplay);
						} else if (null != authResponseCode && (KohlsPOCConstant.NINE.equalsIgnoreCase(authResponseCode) || (KohlsPOCConstant.TWO.equalsIgnoreCase(authResponseCode)))) {
							KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_OFFLINE, errorMessageToDisplay);
						}
					}

				} else if (null != couponType && !YFCCommon.isStringVoid(couponType) && KohlsPOCConstant.CONST_KOHLS_CASH_NO_AUTH.equalsIgnoreCase(couponType))
				{
					if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_PRE_REDEMPTION.equalsIgnoreCase(couponStatus)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV_YET, errorMessageToDisplay);
					} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_EXPIRED, errorMessageToDisplay);
					} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_OFFLINE, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KC_OFFLINE_NO_AUTH));
					}
				} else if (null != couponType && !YFCCommon.isStringVoid(couponType) && KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType))	{
					if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_PRE_REDEMPTION.equalsIgnoreCase(couponStatus)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV_YET, errorMessageToDisplay);
					} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_EXPIRED, errorMessageToDisplay);
					} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){

					}
				}

			}
			this.logger.debug("Method Name : validateKohlsCashResponse   and   Status  ");
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.validateKohlsCashResponse");


		}
		
		/**
		 *
		 * @param kohlsCashResponseEle
		 * @param status
		 */
		private void updateNewKohlsCashDetails(Element promotionEle, Element kohlsCashResponseEle, String status,String ordPromotionID) {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewKohlsCashDetails");


			this.logger.debug("Method Name : updateNewKohlsCashDetails   and   Status  ");

			if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(status)){
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.LEGACY_COUPON);
			}else{
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
			}

			Element extnEle = XMLUtil.getChildElement(promotionEle,
					KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil
					.getElementXMLString(kohlsCashResponseEle));

			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			
			setPromotionDescriptionForKohlsCash(promotionIdForDesc, kohlsCashResponseEle,promotionEle);
			//Changed for Defect #644 - Start
			Element tempEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE); 
			if(tempEle != null){
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, ordPromotionID);
			}
			//Changed for Defect #644 - End
			this.orderTLDHM.put(ordPromotionID, promotionEle);
			
			this.logger.debug("Method Name : updateNewKohlsCashDetails   and   Status  ");
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewKohlsCashDetails");

		}

		private void setPromotionDescriptionForKohlsCash(String promotionIdForDesc, Element kohlsCashResposneEle, Element promotionEle) {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.setPromotionDescriptionForKohlsCash");

			this.logger.debug("Method Name : setPromotionDescriptionForKohlsCash   and   Status  ");
			DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			
					//Added for TLD Description for Sprint-8 -- Start
					String promotionDesc =  promotionIdForDesc.substring((promotionIdForDesc.length())-KohlsPOCConstant.FIVE_INT);
					//Added for TLD Description for Sprint-8 -- End
			
			List<Element> dataEleList = XMLUtil.getElementsByTagName(kohlsCashResposneEle, KohlsPOCConstant.E_DATA);
			String promotionDescription = KohlsPOCConstant.EMPTY;
			if(dataEleList.size() > KohlsPOCConstant.ZERO_INT && null != dataEleList.get(KohlsPOCConstant.ZERO_INT)){
				Element dataElement = dataEleList.get(KohlsPOCConstant.ZERO_INT);
				String legacyDoller = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
				String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
				String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
				String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
				String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
				String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
				//String includeExcludeFlag = dataElement.getAttribute(KohlsPOCConstant.A_INCLUDE_ENCLUDE_FLAG);
				
				if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
					if(!YFCCommon.isStringVoid(legacyDoller)){
						//Added for TLD Description for Sprint-8 -- Start
						//String[] args2 = {promotionIdForDesc,twoDForm.format(Math.abs(Double.valueOf(legacyDoller)))};
						String[] args2 = {promotionDesc};
						//Added for TLD Description for Sprint-8 -- End
						promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_ORDER_PROP_KEY, args2);
					}else if(!YFCCommon.isStringVoid(legacyPercent)){
						//legacyPercent = String.valueOf(Math.abs(Double.valueOf(legacyPercent)/KohlsPOCConstant.HUNDRED_INT));
						
						// Defect Fix :2632 Removed division by 100, as this is getting directly shown to gravity for forming description.
						legacyPercent = String.valueOf(Math.abs(Double.valueOf(legacyPercent).intValue()));
						
						//Added for TLD Description for Sprint-8 -- Start
						//String[] args2 = {promotionIdForDesc,legacyPercent};
						String[] args2 = {legacyPercent,promotionDesc};
						//Added for TLD Description for Sprint-8 -- End
						promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_ORDER_PROP_KEY, args2);
					}
				}else if(KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
						&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
						&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL){
					
				        // Event Name changes - start 
					Element dataEle = (Element)XMLUtil.getElementsByTagName(kohlsCashResposneEle,KohlsPOCConstant.E_DATA).get(KohlsPOCConstant.ZERO_INT);
					if (!YFCCommon.isVoid( XMLUtil.getAttribute(dataEle, KohlsPOCConstant.KC_EVENT_NAME)))
					{
					
					promotionDescription = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.KC_EVENT_NAME);
					logger.debug("promotionDescription is::"+promotionDescription);
					}
					
					else
					{
						String[] args2 = {promotionDesc};
						promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
						logger.debug("PromotionDescription if Event Name Empty"+promotionDescription);
					}
					// Event Name changes - end
				}	
				
			}
			XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
			
			this.logger.debug("Method Name : setPromotionDescriptionForKohlsCash   and   Status  ");
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.setPromotionDescriptionForKohlsCash");

		}
		
	/**
	 *
	 * @return orderManualTldHM
	 */
	public Map<String, Element> getOrderTLDHM() {
		return this.orderTLDHM;
	}

	
	
	/**
	 *
	 * @param customerAssociateNo
	 */
	public void setOrderAssociateHM(String uuidStr,String markDownValue,String secondaryMarkDown) {
		this.orderAssociateHM.put(uuidStr+"_soft", markDownValue);
		this.orderAssociateHM.put(uuidStr+"_hard", secondaryMarkDown);

	}


	/**
	 *
	 * @return
	 */
	public Map<String, String> getOrderAssociateHM() {
		return this.orderAssociateHM;
	}
	
		
		public void cleanUp(){
			this.orderTLDHM = null;
			
		}
	
	//new method for creating Promotion Element for Associate Discount -- start
		
		public void createPromotionElemForAssDisc(YFSEnvironment yfsEnv , Element tempOrderEle)
		{
			//Added for 3945 defect fix --- Start
			Element promotionsEle =  XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
			String assocatePromotion = KohlsPOCConstant.NO;
			
			if (!YFCCommon.isVoid(promotionsEle))
			{
				List<Element> orderPromtionList = XMLUtil
						.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
				if (orderPromtionList.size() > KohlsPOCConstant.ZERO_INT) 
				{
					for (Element promotionEle : orderPromtionList) 
					{
						String promotonType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
						String promoID = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
						
						
						if(!promotonType.equals(KohlsPOCConstant.ASSOCIATE_DISCOUNT))
							continue;
						else {
							if(promoID.equals(KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE))
							{
								XMLUtil.removeChild(promotionsEle, promotionEle);
							}
							else
							{
								assocatePromotion = KohlsPOCConstant.YES;
																
								
							}
						}
							
					}
			}
				
				
				
				if(assocatePromotion.equals(KohlsPOCConstant.NO))
				{
					Element promotonEle = XMLUtil.createChild(promotionsEle,KohlsPOCConstant.E_PROMOTION);
					XMLUtil.setAttribute(promotonEle, "IsInternal", KohlsPOCConstant.YES);
					XMLUtil.setAttribute(promotonEle, "PromotionGroup", "MANUAL");
					
					
					XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT);
					//Added for defect 4656 fix - Start
					
					String markdown = KohlsPOCConstant.EMPTY;
					String secondaryMarkdownValue = KohlsPOCConstant.EMPTY;
					String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;
					// call new method by sending the business date, rule id, enterprise code and set the extnDiscountPercent attribute
					String strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,tempOrderEle,ruleId).trim();
					String [] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
					int length1 = delimitedComma[0].length() - 1;
					markdown= String.valueOf(delimitedComma[0].substring(0,length1));
					
					String[] args = {markdown};
					XMLUtil.setAttribute(promotonEle,  KohlsPOCConstant.A_DESCRIPTION,
							KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args));
					//Added for defect 4656 fix - End
					
					
					
					
					
				}
				
			}
		}
		
		//new method for creating Promotion Element for Associate Discount -- End
	
		private void setDefaultPromotionDescription(String promotionIdForDesc, Element pluOfferResposneEle, Element promotionEle) {
			logger.beginTimer("KohlsPoCOrderPromotionsCaller.setDefaultPromotionDescription");

			List<Element> xstOfferSectEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_SECT);

			String promotionDescription = KohlsPOCConstant.EMPTY;
			String cusDesc = KohlsPOCConstant.EMPTY;
			if (xstOfferSectEleList.size() > KohlsPOCConstant.ZERO_INT){
				cusDesc =  ((Element) xstOfferSectEleList.get(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_CUSTFACG_SHRT_DESC);

				String[] args2 = {cusDesc,promotionIdForDesc};
				promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_ORDER, args2);

			}
			XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
			logger.endTimer("KohlsPoCOrderPromotionsCaller.setDefaultPromotionDescription");

		}
		
			
	
	/**
	 *  updateUeDocumentForTLDPSA() method is to handle the Order Level Promotions for PSA
	 *  
	 * @param orderPromotionList
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param createtsList
	 * @throws Exception
	 */
	public void updateUeDocumentForTLDPSA (List<Element> orderPromotionList, YFSEnvironment yfsEnv,Element tempOrderEle, List<String> createtsList)
			throws Exception {
		
		logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.updateUeDocumentForTLDPSA");
		logger.debug("Method Name : updateUeDocumentForTLDPSA   and   Status  ");
		
		String shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
		
		int i = KohlsPOCConstant.TLD_ID;
		int j=KohlsPOCConstant.ONE_INT;
		for (Element promotionEle : orderPromotionList)
		{
			String ordPromotionID = (String)(Integer.toString(i+j));
			
			j=j+1;
			Element extnElement = XMLUtil.getChildElement(promotionEle,	KohlsPOCConstant.E_EXTN);
			String extnPromotionFlag = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
			String isPSAPromotion = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.ISPSAPROMOTION);
			String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
			
			String promotionId = KohlsPOCConstant.BLANK;
         
         if(!KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase(promotionType) && !("TAXWARE_FEE".equalsIgnoreCase(promotionType))){
            promotionId = KohlsPoCPnPUtil.getPromotionIdForAPE(XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID));
            
         }
         	if(logger.isDebugEnabled()){
			logger.debug("ordPromotionID of Promotion "+XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID));
         	}
			promotionIdForDesc = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
			
			logger.debug("promotionType of Promotion "+promotionType);
			String createts = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_CREATE_TS);
			String action = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_ACTION);
			String extnOffLineMode = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
			
			Element tempEle =  XMLUtil.createChild(promotionEle, KohlsPOCConstant.E_TEMP);
			XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, ordPromotionID);
			
			if (YFCCommon.isStringVoid(extnPromotionFlag) && !(KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(promotionType) 
			    || KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(promotionType)) &&	!(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType)) 
			    && !("TAXWARE_FEE".equalsIgnoreCase(promotionType))) {
					this.newPromotionId = promotionId;
					this.newPromotionEle = promotionEle;
					this.newOrdPromotionID = ordPromotionID;
					if(promotionId.contains("760Q") || promotionId.contains("761I")){
						XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
					}else{
						XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
					}
					
				
					//String promotionType = XMLUtil.getAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
					//Fix for defect 4086 - Adding Quick_Credit check
					if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)
							|| KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
					Element extnEle = XMLUtil.getChildElement(newPromotionEle,
							KohlsPOCConstant.E_EXTN,Boolean.TRUE);	

					if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPSAPromotion)){
						XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
					}
					
					String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
					String overrideMaxAdjustment = XMLUtil.getAttribute(newPromotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
					
					if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
						overrideAdjustmentValue = overrideMaxAdjustment;
					} else {
						overrideAdjustmentValue = XMLUtil.getAttribute(newPromotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
					}
					
					String promotionDesc  = KohlsPOCConstant.EMPTY;
					DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					
					if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT, overrideAdjustmentValue);
						
						String tldDolar = KohlsPOCConstant.TLD_DOLLAR_DESCRIPTION;
						String[] args = {tldDolar};
						
						promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_ORDER_PROP_KEY, args);
					} 
					//Fix for defect 4086 - Adding Quick_Credit check
					else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					
						String[] args = {String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue).intValue()))};
						//Fix for defect 4086 - Start
						//promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_ORDER_PROP_KEY, args);
						if(KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){
							promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.QUICK_CREDIT_TLD_ORDER_PROP_KEY, args);
						}else{
							promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_ORDER_PROP_KEY, args);
						}
						//Fix for defect 4086 - End
					}
					
					XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
					
					this.orderTLDHM.put(ordPromotionID, newPromotionEle);
				}
				
				else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
	
					logger.debug("Entering Senior Discount Processing..");
	
					String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE;
					
					Document seniorDiscountAPIoutDoc = KohlsPoCPnPUtil.getRuleListForPOSCaller(yfsEnv, tempOrderEle, ruleId);
					Element seniorDiscountAPIoutDocEle = seniorDiscountAPIoutDoc.getDocumentElement();
					//Begin- Changes for 2979
					String strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydatePSA(yfsEnv,tempOrderEle,ruleId);
					//End- Changes for 2979
					logger.debug("The strDiscountValueFromUtil value is: "+strDiscountValueFromUtil);
					DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					String extnDiscountPercent = twoDForm.format(Double.valueOf(strDiscountValueFromUtil));
					logger.debug("The extnDiscountPercent formated value is: "+extnDiscountPercent);
					Element extnEle = XMLUtil.getChildElement(newPromotionEle,
							KohlsPOCConstant.E_EXTN,Boolean.TRUE);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, extnDiscountPercent);
					
					String snrDis = KohlsPOCConstant.SENIOR_DISC;
					String[] args = {snrDis};				
					String promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROPE_KEY, args);
					
					XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
					XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE,KohlsPOCConstant.SENIOR_DISCOUNT);
					XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil
							.getElementXMLString(seniorDiscountAPIoutDocEle));
					if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPSAPromotion)){
						XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
					}
					
					this.orderTLDHM.put(ordPromotionID, newPromotionEle);
					logger.debug("Exiting Senior Discount Processing..");
				}
				else {
	
					Element extn = XMLUtil.getChildElement(newPromotionEle, KohlsPOCConstant.E_EXTN);
					XMLUtil.getElementXMLString(extn);
					
					if(!KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase(promotionType)){
						
						if(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)){
							logger.debug("Offline Mode KohlsCash call..");
							updateNewOffLineKohlsCashDetailsPSA(newPromotionEle,ordPromotionID);
						}
						else {
							// TODO there should be a better way to check if KC service call is
							// down
							boolean checkKcServiceStatus = Boolean.FALSE;
							try {
								// PRF-303 changes
								// Check if gravity sends the promotionType as OFFER or check if KC logic
								if (KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType)) {
									applyOffer();
								} else {
									// Check is the scan item is KC by internal logic
									Document kohlsCashinputDoc = createkohlsCashInquiryRequest()
											.constructKohlsCashInquiryDocument(yfsEnv, tempOrderEle, newPromotionEle, shipNode);
									if (logger.isDebugEnabled()) {
										logger.debug(XMLUtil.getXMLString(kohlsCashinputDoc));
									}
									// Calling KohlsCash Web Service
									Document KohlsCashResponse = executeKohlsCashService(yfsEnv,
											kohlsCashinputDoc);
									if (logger.isDebugEnabled()) {
										logger.debug(XMLUtil.getXMLString(KohlsCashResponse));
									}
									Element kohlsCashResponseEle = KohlsCashResponse.getDocumentElement();
									Element dataEle = (Element) XMLUtil
											.getElementsByTagName(kohlsCashResponseEle, KohlsPOCConstant.E_DATA)
											.get(KohlsPOCConstant.ZERO_INT);
									String status = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_TYPE);
									checkKcServiceStatus = Boolean.TRUE;

									if (!YFCCommon.isStringVoid(status) && !KohlsPOCConstant.NONE.equalsIgnoreCase(status)) {
										validateKohlsCashResponse(kohlsCashResponseEle);
										updateNewKohlsCashDetailsPSA(newPromotionEle,kohlsCashResponseEle, status, newPromotionId);
									} else {
										//Just to be sure if status comes out as non KC
										applyOffer();
									}

									logger.debug("Kohls Cash Response Formated");
									if (logger.isDebugEnabled()) {
										logger.debug(XMLUtil.getXMLString(KohlsCashResponse));
									}

								}

							} catch (YFSException e) {
								// Fix for defect 1027 - Start
								if (!checkKcServiceStatus) {
									XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.OFFER);
									this.orderTLDHM.put(newPromotionId, newPromotionEle);
									e.setErrorCode(KohlsPOCConstant.KOHLS_CASH_DOWN);
									e.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.CONST_KC_OFFLINE));
									throw e;
								} else {
									throw e;
								}
							}
						}
               }
				}
			
			} else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))
			{
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
				this.orderTLDHM.put(ordPromotionID, promotionEle);
				
			} else if (!KohlsPOCConstant.REMOVE.equalsIgnoreCase(action) && !(YFCCommon.isStringVoid(extnPromotionFlag)) 
					&& !("TAXWARE_FEE".equalsIgnoreCase(promotionType)) && !(KohlsPOCConstant.KOHLS_CASH_UNEARNED.equalsIgnoreCase(promotionType) 
		                || KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(promotionType))) {
				
				if(!YFCCommon.isVoid(promotionId) && (promotionId.contains("760Q") || promotionId.contains("761I"))){
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
				}else{
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
				}
				//Fix for defect 4086 - Adding Quick_Credit check
				if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)
						|| KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
					this.orderTLDHM.put(ordPromotionID, promotionEle);
				} else if (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)|| KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType)) {

					if(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)){
						//setPromotionDescriptionForKohlsCashOffline(promotionIdForDesc,promotionEle);
						this.orderTLDHM.put(ordPromotionID, promotionEle);
					}else{
						//Element kohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
						//setPromotionDescriptionForKohlsCash(promotionIdForDesc, kohlsCashResposneEle, promotionEle);
						this.orderTLDHM.put(ordPromotionID, promotionEle);
					}

				} else if (KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType)) {
					//It sets default promotion description for the Coupons (Offers) Fix for 1795 and 1793
					//Element pluOfferResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
					//setDefaultPromotionDescription(promotionIdForDesc,pluOfferResposneEle,promotionEle);
					
					/**
					 * PST-2223 changes start 
					 */
					String tmpExtnOfferCouponNo = extnElement.getAttribute( "ExtnOfferCouponNo" );
	                 
					if(KohlsPoCPnPUtil.isSUPC( promotionId ) && ( !YFCCommon.isVoid( tmpExtnOfferCouponNo ) )){
						promotionId=tmpExtnOfferCouponNo;
						this.orderTLDHM.put(promotionId, promotionEle);
					}else{
						if(!YFCCommon.isStringVoid(isPSAPromotion)){
							this.orderTLDHM.put(promotionId, promotionEle);
						}else{
						this.orderTLDHM.put(ordPromotionID, promotionEle);
						}
					}
					//PST-2223 changes end
				}else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
				this.orderTLDHM.put(ordPromotionID, promotionEle);
				}
				createtsList.add(createts);
			}
		}
		
		logger.debug("Method Name : updateUeDocumentForTLD   and   Status  ");
		logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.updateUeDocumentForTLDPSA");

	}

	protected Document executeKohlsCashService(YFSEnvironment yfsEnv,
			Document kohlsCashinputDoc) throws Exception {
		KohlsCashManager kcm = new KohlsCashManager(yfsEnv);
		
		Element tempOrderEle = kohlsCashinputDoc.getDocumentElement();
		Element headerEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_HEADER);
		
		String organizationCode = XMLUtil.getAttribute(headerEle, KohlsPOCConstant.A_STORE_APE);
		
		boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(organizationCode);
		
		if(logger.isDebugEnabled())
			logger.debug("######Rule value for OMS KC in KohlsPoCTVSOrderPromotionsCaller.executeKohlsCashService: " + omsKCEnabled);
		
		if(omsKCEnabled) {
			if(logger.isDebugEnabled())
				logger.debug("OMS KC input: " + kohlsCashinputDoc);
			
			kcm.loadEvents(organizationCode);
			//Use KCM
			return kcm.kohlsCashInquiry(kohlsCashinputDoc);
		}
		else {
			if(logger.isDebugEnabled())
				logger.debug("KCS input: " + kohlsCashinputDoc);
			
			//Use KCS
			return KOHLSBaseApi.invokeService(yfsEnv,
					KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_INQUIRY_WEB_SERVICE, kohlsCashinputDoc);
		}
	}

		/**
		 * 
		 * @param promotionEle
		 * @param ordPromotionID
		 */
		private void updateNewOffLineKohlsCashDetailsPSA(Element promotionEle,String ordPromotionID) {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewOffLineKohlsCashDetailsPSA");

			Element extnEle = XMLUtil.getChildElement(promotionEle,
					KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
			
			
			String extnPromotionFlag = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
			String isPSAPromotion = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION);
			
			//To set A_EXTN_PROMOTION_FLAG only for sales. It will skipped for PSA.
			//To classify Sales & PSA - Refer to com.kohls.poc.pricing.ue.constructTVSRequestDocForTLDPSA()
			if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPSAPromotion)){
				XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			}
			
			setPromotionDescriptionForKohlsCashOffline(promotionIdForDesc,promotionEle);
			this.orderTLDHM.put(ordPromotionID, promotionEle);
			
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewOffLineKohlsCashDetailsPSA");
		}

		
		/**
		 *
		 * @param kohlsCashResponseEle
		 * @param status
		 */
		private void updateNewKohlsCashDetailsPSA(Element promotionEle, Element kohlsCashResponseEle, String status,String ordPromotionID) {
			logger.beginTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewKohlsCashDetailsPSA");

			this.logger.debug("Method Name : updateNewKohlsCashDetails   and   Status  ");

			if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(status)){
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.LEGACY_COUPON);
			}else{
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
			}

			Element extnEle = XMLUtil.getChildElement(promotionEle,
					KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil
					.getElementXMLString(kohlsCashResponseEle));

			String extnPromotionFlag = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
			String isPSAPromotion = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.ISPSAPROMOTION);
			
			//only for sales it will be set
			if(!YFCCommon.isStringVoid(extnPromotionFlag) && YFCCommon.isStringVoid(isPSAPromotion)){
				XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
			}
			
			setPromotionDescriptionForKohlsCash(promotionIdForDesc, kohlsCashResponseEle,promotionEle);
			Element tempEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE); 
			if(tempEle != null){
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, ordPromotionID);
			}
			this.orderTLDHM.put(ordPromotionID, promotionEle);
			
			this.logger.debug("Method Name : updateNewKohlsCashDetails   and   Status  ");
			logger.endTimer("KohlsPoCTVSOrderPromotionsCaller.updateNewKohlsCashDetailsPSA");

		}

		public Map<String, Element> getvoidResetAwardMap() {
			return voidResetAwardMap;
		}

		public void setvoidResetAwardMap(String awardId, Element Promotion) {
			if(!voidResetAwardMap.containsKey(awardId)){
				this.voidResetAwardMap.put(awardId, Promotion);
			}
		}
		public Map<String, Element> getPromoDiscAwardMap() {
			return promoDiscAwardMap;
		}
		public void setPromoDiscAwardMap(String awardId, Element award) {
			this.promoDiscAwardMap.put(awardId, award);
		}
		public Map<String, Element> getLIDAwardMap() {
			return LIDAwardMap;
		}
		public void setLIDAwardMap(String awardId, Element award){
			 this.LIDAwardMap.put(awardId, award);
		}
		public Map<String, Integer> getAwardSequenceMap() {
			return awardSequenceMap;
		}
		public void setAwardSequenceMap(String itemId, int sequence) {
			this.awardSequenceMap.put(itemId, sequence);
		}
}
