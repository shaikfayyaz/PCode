package com.kohls.poc.pricing.ue;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.data.kohlscash.KohlsCashManager;
import com.kohls.poc.kohlscash.ue.KohlsPoCKohlsCashInquiryRequestCreator;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoCOrderPromotionsCaller.java
 * Author : IBM
 * Created : August 27 2013
 * Modified : August 27 2013
 * Version : 0.1
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 27/08/2013 IBM First Cut.
 *****************************************************************************
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 * PLU call made for getting Kohls Cash and Offer Response.
 * Order Level Promotins Offer, Kohls Cash, Manual TLD are handled.
 * Based on the Promotion Type, promotion element is put in their corresponding LinkedHashMap
 *
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/


public class KohlsPoCOrderPromotionsCaller {

	private Map<String, Element> orderCouponHM;
	private Map<String, Element> orderKohlsCashHM;
	private Map<String, Element> orderManualTldHM;
	private Map<String, Element> orderSeniorCitizenHM;
	private String newPromotionId;
	private Element newPromotionEle;
	private Map<String, String> orderAssociateHM;
	private Map<String, Element> orderOfflineKohlsCashHM;
	private String newPromotionIdForDesc;
	
	//Added for 3945 defect fix --- Start
	private Map<String, Element> orderAssociateDisHM;
	private Map<String, Element> orderAssoDisHM;
	//Added for 3945 defect fix --- End


	public KohlsPoCOrderPromotionsCaller() {
		this.orderCouponHM = new LinkedHashMap<String, Element>();
		this.orderKohlsCashHM = new LinkedHashMap<String, Element>();
		this.orderManualTldHM = new LinkedHashMap<String, Element>();
		this.orderSeniorCitizenHM = new LinkedHashMap<String, Element>();
		this.orderAssociateHM = new LinkedHashMap<String, String>();
		this.orderOfflineKohlsCashHM = new LinkedHashMap<String, Element>();
		//Added for 3945 defect fix --- Start
		this.orderAssociateDisHM = new LinkedHashMap<String, Element>();
		this.orderAssoDisHM = new LinkedHashMap<String, Element>();
		//Added for 3945 defect fix --- End
	}

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCOrderPromotionsCaller.class.getName());
	}

	/**
	 *  This method is helpful for handling the Order Level Promotions
	 *
	 *
	 * @param orderPromotionList
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param createtsList
	 * @throws Exception
	 */
	public void updateUeDocumentForOffer (List<Element> orderPromotionList, YFSEnvironment yfsEnv,Element tempOrderEle, List<String> createtsList)
			throws Exception {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.updateUeDocumentForOffer");

		logger.debug("Method Name : updateUeDocumentForOffer   and   Status  ");

		String shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
		String extnRequestDateTime = KohlsPoCPnPUtil.getExtnRequestTime(tempOrderEle);

		//All the Promotions are iterated and which Promotion does not have 'ExtnPromotionFlag'
		//it is treated a New Promtion Element.
		for (Element promotionEle : orderPromotionList) {

			Element extnElement = XMLUtil.getChildElement(promotionEle,	KohlsPOCConstant.E_EXTN);
			String promotionId = KohlsPoCPnPUtil.getPromotionIdForAPE(XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID));
			String promotionIdForDesc = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
			String extnPromotionFlag = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
			String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
			String action = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_ACTION);
			String createts = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_CREATE_TS);
			String extnOffLineMode = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);

			//Manoj 06/17 - Fix for defect 4656 - start
			if (YFCCommon.isStringVoid(extnPromotionFlag) &&
					!(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))) {
			//Manoj 06/17 - Fix for defect 4656 - End
				this.newPromotionId = promotionId;
				this.newPromotionEle = promotionEle;
				this.newPromotionIdForDesc = promotionIdForDesc;
			} else if (!KohlsPOCConstant.REMOVE.equalsIgnoreCase(action)) {
				//Added for 3945 defect fix --- Start
				 if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType) )
				 {
					 XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO); 
				 }
				 else
				 {
				//Added for 3945 defect fix --- End
				String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
						promotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
				//Fix for 1795 and 1793
				XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
				if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
					this.orderManualTldHM.put(guidStr, promotionEle);
				} else if (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)|| KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType)) {

					if(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)){
						setPromotionDescriptionForKohlsCashOffline(promotionIdForDesc,promotionEle);
						this.orderOfflineKohlsCashHM.put(guidStr, promotionEle);
					}else{
						Element kohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
						setPromotionDescriptionForKohlsCash(promotionIdForDesc, kohlsCashResposneEle, promotionEle);
						this.orderKohlsCashHM.put(guidStr, promotionEle);
					}

				} else if (KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType)) {
					//It sets default promotion description for the Coupons (Offers) Fix for 1795 and 1793
					Element pluOfferResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnElement.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
					setDefaultPromotionDescription(promotionIdForDesc,pluOfferResposneEle,promotionEle);
					
					// Suresh:  17-Dec Offer start and End Date : Start //
					
					setOfferStartAndEndDates(pluOfferResposneEle,promotionEle);
					
					// Suresh:  17-Dec Offer start and End Date : End //
					
					this.orderCouponHM.put(guidStr, promotionEle);
				}else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
					this.orderSeniorCitizenHM.put(guidStr, promotionEle);
				}
				
				//Added for 3945 defect fix --- Start
				 }
				//Added for 3945 defect fix --- End
				
				createtsList.add(createts);
			}

		}

		if ( !YFCCommon.isStringVoid(newPromotionId)) {
			String promotionType = XMLUtil.getAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);

			if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
				String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
						newPromotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
				Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
						KohlsPOCConstant.E_EXTN,Boolean.TRUE);
				XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
				
				
				//Fix for defect 1974 Start
				
				String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
				String overrideMaxAdjustment = XMLUtil.getAttribute(this.newPromotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
				
				if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
					overrideAdjustmentValue = overrideMaxAdjustment;
				} else {
					overrideAdjustmentValue = XMLUtil.getAttribute(this.newPromotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
				}
				
				String promotionDesc  = KohlsPOCConstant.EMPTY;
				DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
				
				if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT, overrideAdjustmentValue);
					//Added for TLD Description for Sprint-8 --- Start
					//String[] args = {twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue)))};
					String tldDolar = KohlsPOCConstant.TLD_DOLLAR_DESCRIPTION;
					String[] args = {tldDolar};
					//Added for TLD Description for Sprint-8 --- End
					promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_ORDER_PROP_KEY, args);
				} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
				
					String[] args = {String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue).intValue()))};
					//promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_ORDER_PROP_KEY, args);
					//Fix for defect 2322 and 2333 - Start
					if(KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){
						promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.QUICK_CREDIT_TLD_ORDER_PROP_KEY, args);
					}else{
						promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_ORDER_PROP_KEY, args);
					}
					//Fix for defect 2322 and 2333 - End
				}
				
				XMLUtil.setAttribute(this.newPromotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
				
				//Fix for defect 1974 End
				
				this.orderManualTldHM.put(guidStr, newPromotionEle);
			} else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){

				logger.debug("Entering Senior Discount Processing..");

				// Changes for Sprint 9.1 - Start
				//String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_PERCENT;
				// call the KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle) to get the business date value.
				String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE;
				
				Document seniorDiscountAPIoutDoc = KohlsPoCPnPUtil.getRuleListForPOSCaller(yfsEnv, tempOrderEle, ruleId);
				Element seniorDiscountAPIoutDocEle = seniorDiscountAPIoutDoc.getDocumentElement();
				
				//adding the logic in pnputil class
				/*Document getTillStatusListForPOSoutDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle);
				Element getTillStatusListForPOSoutDocEle = (Element) ((NodeList) getTillStatusListForPOSoutDoc
						.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS)).item(0);
				String strBusinessDay=getTillStatusListForPOSoutDocEle.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
				logger.debug("The Business Day is: "+strBusinessDay);
				String [] delimited = strBusinessDay.split(KohlsPOCConstant.MINUS);
				String strBusinessDate=delimited[1].concat(delimited[2]).concat((delimited[0].substring(2, 4)));
				String strOrganizationCode = tempOrderEle.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);
				logger.debug("The Business Date value is: "+strBusinessDate);
				logger.debug("The Enterprise Code value is: "+strOrganizationCode);*/
				// call new method by sending the business date, rule id, enterprise code and set the extnDiscountPercent attribute - Bala.
				
				String strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,tempOrderEle,ruleId);
				logger.debug("The strDiscountValueFromUtil value is: "+strDiscountValueFromUtil);
				DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
				String extnDiscountPercent = twoDForm.format(Double.valueOf(strDiscountValueFromUtil));
				logger.debug("The extnDiscountPercent formated value is: "+extnDiscountPercent);
				Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
						KohlsPOCConstant.E_EXTN,Boolean.TRUE);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, extnDiscountPercent);
				
				//Changes for Sprint 9.1 - End
				

				//  Commenting for Sprint 9.1 Changes - Start
				/*Document seniorDiscountAPIoutDoc = KohlsPoCPnPUtil.getRuleListForPOSCaller(yfsEnv, tempOrderEle, ruleId);

				Element seniorDiscountAPIoutDocEle = seniorDiscountAPIoutDoc.getDocumentElement();
				
				

				logger.debug("Senior Discount API Output Element..");

				logger.debug(XMLUtil.getElementXMLString(seniorDiscountAPIoutDocEle));
				
				// Fix for defect 1974 Start
				String ruleValue = KohlsPoCPnPUtil.ruleIDComparisonCaller(seniorDiscountAPIoutDocEle, ruleId);
				List<Element> rulesEleList = XMLUtil.getElementsByTagName(seniorDiscountAPIoutDocEle, KohlsPOCConstant.E_RULE);
				String percentValue = KohlsPOCConstant.EMPTY;
				
				Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
						KohlsPOCConstant.E_EXTN,Boolean.TRUE);
				
				DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
				
				String extnDiscountPercent =  KohlsPOCConstant.EMPTY;
				
				if(!YFCCommon.isVoid(ruleValue)){
					extnDiscountPercent = twoDForm.format(Double.valueOf(ruleValue));
				} else {
					extnDiscountPercent = twoDForm.format(Double.valueOf(KohlsPOCConstant.DEFAULT_SENIOR_DISCOUNT_PERCENT));
				}
				


				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, extnDiscountPercent);*/
				//  Commenting for Sprint 9.1 Changes - End
				
				//Added for TLD description for sprint-8 -- Start
				//String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
				String snrDis = KohlsPOCConstant.SENIOR_DISC;
				String[] args = {snrDis};
				
				//Commented below line for TLD Description for Sprint-8
				//String promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROP_KEY, args);
				String promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROPE_KEY, args);
				//Added for TLD description for sprint-8 -- End

				XMLUtil.setAttribute(this.newPromotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
				
				//Fix for defect 1974 End

				this.updateSeniorCitizenDetail(seniorDiscountAPIoutDocEle);

				logger.debug("Exiting Senior Discount Processing..");
			}else {

				Element extn = XMLUtil.getChildElement(newPromotionEle, KohlsPOCConstant.E_EXTN);
				XMLUtil.getElementXMLString(extn);
				String extnOffLineMode = XMLUtil.getAttribute(extn, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);

				if(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)){

					logger.debug("Offline Mode KohlsCash call..");
					updateNewOffLineKohlsCashDetails(newPromotionEle);

				} else {
					Element kohlsCashResponseEle = null;
					boolean checkKcServiceStatus = Boolean.FALSE;
					try{
						Document kohlsCashinputDoc = new KohlsPoCKohlsCashInquiryRequestCreator().constructKohlsCashInquiryDocument(yfsEnv, tempOrderEle,newPromotionEle, shipNode);
						
						//Calling KohlsCash Web Service
						//Document 
						
						KohlsCashManager kcm = new KohlsCashManager(yfsEnv);
						Document KohlsCashResponse = null;
						
						boolean omsKCEnabled = kcm.isOMSKohlsCashEnabled(shipNode);
						
						if(logger.isDebugEnabled())
	        				logger.debug("######Rule value for OMS KC in KohlsPoCOrderPromotionsCaller.updateUeDocumentForOffer: " + omsKCEnabled);
						
						if(omsKCEnabled) {
							if(logger.isDebugEnabled())
								logger.debug("OMS KC input: " + XMLUtil.getXMLString(kohlsCashinputDoc));
							
							kcm.loadEvents(shipNode);
							//Use KCM
							KohlsCashResponse = kcm.kohlsCashInquiry(kohlsCashinputDoc);
							
							if(logger.isDebugEnabled())
								logger.debug("OMS KC output: " + XMLUtil.getXMLString(KohlsCashResponse));
						}
						else {
							if(logger.isDebugEnabled())
								logger.debug("KCS input: " + XMLUtil.getXMLString(kohlsCashinputDoc));
							
							//Use KCS
							KohlsCashResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_INQUIRY_WEB_SERVICE, kohlsCashinputDoc);
							
							if(logger.isDebugEnabled())
								logger.debug("KCS output: " + XMLUtil.getXMLString(KohlsCashResponse));
						}
						
						kohlsCashResponseEle = KohlsCashResponse.getDocumentElement();
						
						//Process the pluKohlsCashResponse and get the status value
						Element dataEle = (Element)XMLUtil.getElementsByTagName(kohlsCashResponseEle,KohlsPOCConstant.E_DATA).get(KohlsPOCConstant.ZERO_INT);
						String status = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_TYPE);

						checkKcServiceStatus = Boolean.TRUE;
						
						if (!YFCCommon.isStringVoid(status) && !KohlsPOCConstant.NONE.equalsIgnoreCase(status)) {
							validateKohlsCashResponse(kohlsCashResponseEle);
							updateNewKohlsCashDetails(kohlsCashResponseEle, status);
						}else {
							pluLookUpCall(yfsEnv, tempOrderEle, shipNode, extnRequestDateTime);
								
							}
						
						if(logger.isDebugEnabled()){
							logger.debug("Kohls Cash Response Formated");
							logger.debug(XMLUtil.getXMLString(KohlsCashResponse));
						}

					}catch(YFSException e){
						if(!checkKcServiceStatus){
							try{
								pluLookUpCall(yfsEnv, tempOrderEle, shipNode, extnRequestDateTime);
							}catch(YFSException ex) {
								if(ex.getErrorCode().equalsIgnoreCase(KohlsPOCConstant.PLUOFFRNOTFOUND)){
									ex.setErrorCode(KohlsPOCConstant.KOHLS_CASH_DOWN);
									ex.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.CONST_KC_OFFLINE));
									
								}else if(ex.getErrorCode().equalsIgnoreCase(KohlsPOCConstant.OLUSERVDOWN))
								{
									ex.setErrorCode(KohlsPOCConstant.KOHLS_CASH_DOWN);
									ex.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.CONST_KC_OFFLINE));
								}
									throw ex;
								
							}
						}else{
							throw e;
						}
					}
				}
			}
		}
		this.logger.debug("Method Name : updateUeDocumentForOffer   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.updateUeDocumentForOffer");

	}


	private void setDefaultPromotionDescription(String promotionIdForDesc, Element pluOfferResposneEle, Element promotionEle) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.setDefaultPromotionDescription");

		List<Element> xstOfferSectEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_SECT);

		String promotionDescription = KohlsPOCConstant.EMPTY;
		String cusDesc = KohlsPOCConstant.EMPTY;
		if (xstOfferSectEleList.size() > KohlsPOCConstant.ZERO_INT){
			cusDesc =  ((Element) xstOfferSectEleList.get(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_CUSTFACG_SHRT_DESC);

			String[] args2 = {cusDesc,promotionIdForDesc};
			promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_ORDER, args2);

		}
		XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
		logger.endTimer("KohlsPoCOrderPromotionsCaller.setDefaultPromotionDescription");

	}


	private void updateNewOffLineKohlsCashDetails(Element newPromotionEle) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.updateNewOffLineKohlsCashDetails");

		Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
				KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(this.newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
		String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
				this.newPromotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
		setPromotionDescriptionForKohlsCashOffline(this.newPromotionIdForDesc,this.newPromotionEle);
		this.orderOfflineKohlsCashHM.put(guidStr, this.newPromotionEle);
		this.newPromotionEle = null;
		this.newPromotionId = null;
		logger.endTimer("KohlsPoCOrderPromotionsCaller.updateNewOffLineKohlsCashDetails");

	}


	/**
	 * This method is created for handling the Manager Override
	 *
	 * @param pluOfferResponseEle
	 * @param tempOrderEle
	 * @param yfsEnv
	 * @param extnRequestDateTime
	 * @throws Exception
	 */
	private void verifyManagerOverride(Element pluOfferResponseEle, YFSEnvironment yfsEnv, Element tempOrderEle)
			throws Exception {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.verifyManagerOverride");

		this.logger.debug("Method Name : verifyManagerOverride   and   Status  ");

		String businessDate = KohlsPOCConstant.EMPTY;
		//For fetching the Business Date
		Document businessDateDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle);
		Element getTillStatusListForPOSOutEle = businessDateDoc.getDocumentElement();

		List<Element> tillStatusList = XMLUtil.getElementsByTagName(getTillStatusListForPOSOutEle, KohlsPOCConstant.E_TILL_STATUS);

		if(tillStatusList.size() > KohlsPOCConstant.ZERO_INT){
			Element tillStatusElement =  tillStatusList.get(KohlsPOCConstant.ZERO_INT);
			businessDate = XMLUtil.getAttribute(tillStatusElement, KohlsPOCConstant.A_BUSINESS_DAY);
		}

		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YY);

		if (YFCCommon.isStringVoid(businessDate)) {
			Calendar cal = Calendar.getInstance();
			businessDate = sdf.format(cal.getTime());
		} else {
			businessDate = KohlsPoCPnPUtil.convertDate(businessDate,KohlsPOCConstant.HD_DATE_FORMAT);
		}

		List<Element> offerSelectedList = XMLUtil.getElementsByTagName(
				pluOfferResponseEle, KohlsPOCConstant.E_XST_OFR_SECT);

		if (offerSelectedList .size() > KohlsPOCConstant.ZERO_INT) {
			String effEndDateStr = offerSelectedList.get(KohlsPOCConstant.ZERO_INT).getAttribute(
					KohlsPOCConstant.A_EFF_END_DTE);
			String effBeginDateStr = offerSelectedList.get(KohlsPOCConstant.ZERO_INT)
					.getAttribute(KohlsPOCConstant.A_EFF_BEG_DTE);
			String supervisorOverrideDateStr = offerSelectedList.get(KohlsPOCConstant.ZERO_INT)
					.getAttribute(KohlsPOCConstant.A_REDMN_SUPVR_OVRRID_DTE);
			
			String cusDesc = offerSelectedList.get(KohlsPOCConstant.ZERO_INT)
			.getAttribute(KohlsPOCConstant.A_CUSTFACG_SHRT_DESC);
			
			 
			// Suresh: Start : Added to display offer description in the case of PLUMGROVRID/PLUOFFREXPD/PLUOFFRNOTSTRT
			String[] args2 = {cusDesc};
			// Suresh: End : Added to display offer description in the case of PLUMGROVRID/PLUOFFREXPD/PLUOFFRNOTSTRT
			
			
			Date effEndDate = null;
			Date currentDate = null;
			Date supervisorOverrideDate = null;
			Date effBeginDate = null;
			try {
				effEndDate = sdf.parse(effEndDateStr);
				effBeginDate = sdf.parse(effBeginDateStr);
				supervisorOverrideDate = sdf
						.parse(supervisorOverrideDateStr);
				currentDate = sdf.parse(businessDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}


			if (currentDate.after(effEndDate)
					&& currentDate.before(supervisorOverrideDate)) {
				YFSException yfsException = new YFSException();
				yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
				yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID,args2));
				throw yfsException;
			} else if (currentDate.after(effEndDate) && currentDate.after(supervisorOverrideDate)) {
				YFSException yfsException = new YFSException();
				yfsException.setErrorCode(KohlsPOCConstant.PLUOFFREXPD);
				yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUOFFREXPD,args2));
				throw yfsException;
			} else if (currentDate.before(effBeginDate)) {		
				YFSException yfsException = new YFSException();
				yfsException.setErrorCode(KohlsPOCConstant.PLUOFFRNOTSTRT);
				yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUOFFRNOTSTRT,args2));
				throw yfsException;
			} else if(currentDate.after(effEndDate)
					&& currentDate.equals(supervisorOverrideDate)){		
				YFSException yfsException = new YFSException();
				yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
				yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID,args2));
				throw yfsException;
			}
		}
		this.logger.debug("Method Name : verifyManagerOverride   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.verifyManagerOverride");

	}

	/**
	 *  This method is helpful for adding Plu Offer Response in the Order/PRomotions/Promotion/Extn/@ExtnPromotionResponse
	 *
	 * @param pluOfferResponseEle
	 */

	private void updateNewOfferDetails(Element pluOfferResponseEle) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.updateNewOfferDetails");

		this.logger.debug("Method Name : updateNewOfferDetails   and   Status  ");

		XMLUtil.setAttribute(this.newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.OFFER);
		Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
				KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil
				.getElementXMLString(pluOfferResponseEle));

		//logger.debug(XMLUtil.getElementXMLString(newPromotionEle));

		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
		String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
				this.newPromotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
		//Fix for 1795 and 1793
		setDefaultPromotionDescription(this.newPromotionIdForDesc, pluOfferResponseEle, this.newPromotionEle);
		this.orderCouponHM.put(guidStr, this.newPromotionEle);
		this.newPromotionEle = null;
		this.newPromotionId = null;
		this.logger.debug("Method Name : updateNewOfferDetails   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.updateNewOfferDetails");


	}

	/**
	 *
	 * @return
	 */
	public Map<String, Element> getOrderCouponHM() {
		return this.orderCouponHM;
	}

	/**
	 *
	 * @param kohlsCashResponseEle
	 * @throws YFSUserExitException
	 */
	private void validateKohlsCashResponse(Element kohlsCashResponseEle) throws YFSException {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.validateKohlsCashResponse");

		this.logger.debug("Method Name : validateKohlsCashResponse   and   Status  ");

		Element dataEle = (Element) XMLUtil.getElementsByTagName(kohlsCashResponseEle, KohlsPOCConstant.E_DATA).get(KohlsPOCConstant.ZERO_INT);

		if (null != dataEle) {
			String authResponseCode = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
			String couponBalance = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_BALANCE);
			String couponType = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_TYPE);
			String couponStatus = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_COUPON_STATUS);
			String errorMessageToDisplay = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_ERROR_MESSAGE_TO_DISPLAY);
			String historyData = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.A_HISTORY_DATA);

			// For Kohl's cash Auth
			if (null != couponType && !YFCCommon.isStringVoid(couponType) && KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType)) {
				if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_PRE_REDEMPTION.equalsIgnoreCase(couponStatus)) {
					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV_YET, errorMessageToDisplay);
				} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus)) {

					String couponBalanceErrorMessage = null;
					String couponBalancePostRedeem = null;
					if(!YFCCommon.isStringVoid(couponBalance)) {
						DecimalFormat twoDCouponBalance = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
						couponBalancePostRedeem = twoDCouponBalance.format(Double.valueOf(couponBalance));
						couponBalanceErrorMessage = KohlsPOCConstant.BALANCE +  KohlsPOCConstant.DOLLAR_SYMPOL + couponBalancePostRedeem;
					}

					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_EXPIRED, errorMessageToDisplay + KohlsPOCConstant.SPACE + couponBalanceErrorMessage);
				} else if (!YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)) {
					if (!YFCCommon.isStringVoid(authResponseCode) && (KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode)
							&& (Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL))) {

					} else if (null != authResponseCode && (KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode)
							&& (Double.valueOf(couponBalance).doubleValue() <= KohlsPOCConstant.ZERO_DBL))) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NO_BALANCE, historyData);
					} else if (null != authResponseCode && KohlsPOCConstant.EIGHT.equalsIgnoreCase(authResponseCode)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_DUP_REC_FND, errorMessageToDisplay);
					} else if (null != authResponseCode && KohlsPOCConstant.SEVEN.equalsIgnoreCase(authResponseCode)) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV, errorMessageToDisplay);
					} else if (null != authResponseCode && (KohlsPOCConstant.NINE.equalsIgnoreCase(authResponseCode) || (KohlsPOCConstant.TWO.equalsIgnoreCase(authResponseCode)))) {
						KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_OFFLINE, errorMessageToDisplay);
					}
				}

			} else if (null != couponType && !YFCCommon.isStringVoid(couponType) && KohlsPOCConstant.CONST_KOHLS_CASH_NO_AUTH.equalsIgnoreCase(couponType))
			{
				if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_PRE_REDEMPTION.equalsIgnoreCase(couponStatus)) {
					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV_YET, errorMessageToDisplay);
				} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus)) {
					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_EXPIRED, errorMessageToDisplay);
				} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)) {
					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_OFFLINE, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KC_OFFLINE_NO_AUTH));
				}
			} else if (null != couponType && !YFCCommon.isStringVoid(couponType) && KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType))	{
				if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_PRE_REDEMPTION.equalsIgnoreCase(couponStatus)) {
					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_NOT_ACTV_YET, errorMessageToDisplay);
				} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.CONST_POST_REDEMPTION.equalsIgnoreCase(couponStatus)) {
					KohlsPoCPnPUtil.yfsException(KohlsPOCConstant.CONST_KC_EXPIRED, errorMessageToDisplay);
				} else if (null != couponStatus && !YFCCommon.isStringVoid(couponStatus) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){

				}
			}

		}
		this.logger.debug("Method Name : validateKohlsCashResponse   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.validateKohlsCashResponse");


	}

	/**
	 *
	 * @param kohlsCashResponseEle
	 * @param status
	 */
	private void updateNewKohlsCashDetails(Element kohlsCashResponseEle, String status) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.updateNewKohlsCashDetails");


		this.logger.debug("Method Name : updateNewKohlsCashDetails   and   Status  ");

		if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(status)){
			XMLUtil.setAttribute(this.newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.LEGACY_COUPON);
		}else{
			XMLUtil.setAttribute(this.newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.KOHLS_CASH);
		}

		Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
				KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil
				.getElementXMLString(kohlsCashResponseEle));

		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
		String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
				this.newPromotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
		setPromotionDescriptionForKohlsCash(this.newPromotionIdForDesc, kohlsCashResponseEle, this.newPromotionEle);
		this.orderKohlsCashHM.put(guidStr, this.newPromotionEle);
		this.newPromotionEle = null;
		this.newPromotionId = null;
		this.logger.debug("Method Name : updateNewKohlsCashDetails   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.updateNewKohlsCashDetails");

	}

	//Move this method to Kohls Activation Class


	/**
	 * @return orderKohlsCashHM
	 */
	public Map<String, Element> getOrderKohlsCashHM() {
		return this.orderKohlsCashHM;
	}

	/**
	 *
	 * @return orderManualTldHM
	 */
	public Map<String, Element> getOrderManualTldHM() {
		return this.orderManualTldHM;
	}

	/**
	 *
	 * @return orderSeniorCitizenHM
	 */
	public Map<String, Element> getOrderSeniorDiscountHM(){
		return this.orderSeniorCitizenHM;
	}

	public Map<String, Element> getOrderOfflineKohlsCashHM(){
		return this.orderOfflineKohlsCashHM;
	}

	/**
	 *
	 * @param seniorDiscountAPIoutDocEle
	 */
	private void updateSeniorCitizenDetail(Element seniorDiscountAPIoutDocEle) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.updateSeniorCitizenDetail");

		this.logger.debug("Method Name : updateSeniorCitizenDetail   and   Status  ");
		XMLUtil.setAttribute(newPromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE,KohlsPOCConstant.SENIOR_DISCOUNT);
		Element extnEle = XMLUtil.getChildElement(this.newPromotionEle,
				KohlsPOCConstant.E_EXTN,Boolean.TRUE);
		XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE, XMLUtil
				.getElementXMLString(seniorDiscountAPIoutDocEle));


		XMLUtil.setAttribute(extnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
		String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(
				newPromotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
		orderSeniorCitizenHM.put(guidStr, newPromotionEle);
		newPromotionEle = null;
		newPromotionId = null;
		this.logger.debug("Method Name : updateSeniorCitizenDetail   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.updateSeniorCitizenDetail");


	}




	/**
	 *
	 * @param customerAssociateNo
	 */
	public void setOrderAssociateHM(String uuidStr,String markDownValue,String secondaryMarkDown) {
		this.orderAssociateHM.put(uuidStr+"_soft", markDownValue);
		this.orderAssociateHM.put(uuidStr+"_hard", secondaryMarkDown);

	}


	/**
	 *
	 * @return
	 */
	public Map<String, String> getOrderAssociateHM() {
		return this.orderAssociateHM;
	}
	
	public void pluLookUpCall(YFSEnvironment yfsEnv, Element tempOrderEle, String shipNode, String extnRequestDateTime){
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.pluLookUpCall");

		try{
			KohlsPoCPLURequestCreator pluRequestForOffer = new KohlsPoCPLURequestCreator(KohlsPOCConstant.OFFER,shipNode);
			Document pluRequestDocument =
					pluRequestForOffer.constructPLURequestDocument(newPromotionId,extnRequestDateTime);
			Element extnElement = XMLUtil.getChildElement(
					newPromotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);

				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getXMLString(pluRequestDocument));
			   Document pluOfferResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_PLU_WEB_SERVICE, pluRequestDocument);
				Element pluOfferResponseEle = pluOfferResponse.getDocumentElement();
				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getXMLString(pluOfferResponse));
			
				
					
				
				
				KohlsPoCPnPUtil.validatePluResponse(pluOfferResponseEle);
				String isMgrOverrideProvided = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.A_EXTN_MANAGER_OVERRIDE_PROVIDED);

				if (!KohlsPOCConstant.YES.equalsIgnoreCase(isMgrOverrideProvided)) {
					verifyManagerOverride(pluOfferResponseEle,yfsEnv,tempOrderEle);
				}
				
				// Suresh :  Dec19 Setting offer start and End dates : Start
				
				setOfferStartAndEndDates(pluOfferResponseEle, newPromotionEle);
				
				// Suresh :  Dec19 Setting offer start and End dates : Start

				updateNewOfferDetails(pluOfferResponseEle);
			}catch(Exception e){
				e.printStackTrace();
				if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

					YFSException yfsException = new YFSException();
					YFSException es = (YFSException) e;

					// Connect Exception
					if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
						yfsException.setErrorCode(KohlsPOCConstant.OLUSERVDOWN);
						yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OLUSERVDOWN));
					}

					// IO Exception
					else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
						yfsException.setErrorCode(KohlsPOCConstant.OLUSERVDOWN);
						yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OLUSERVDOWN));
					}

					// Other Exceptions
					else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
						yfsException.setErrorCode(KohlsPOCConstant.OLUSERVDOWN);
						yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OLUSERVDOWN));
					}	
					else{
						throw es;
					}
					throw yfsException;
				}
//				else{
//					throw e;							
//				}
			}
			logger.endTimer("KohlsPoCOrderPromotionsCaller.pluLookUpCall");

		}//end of method call.
	
	private void setPromotionDescriptionForKohlsCash(String promotionIdForDesc, Element kohlsCashResposneEle, Element promotionEle) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.setPromotionDescriptionForKohlsCash");

		this.logger.debug("Method Name : setPromotionDescriptionForKohlsCash   and   Status  ");
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		
				//Added for TLD Description for Sprint-8 -- Start
				String promotionDesc =  promotionIdForDesc.substring((promotionIdForDesc.length())-KohlsPOCConstant.FIVE_INT);
				//Added for TLD Description for Sprint-8 -- End
		
		List<Element> dataEleList = XMLUtil.getElementsByTagName(kohlsCashResposneEle, KohlsPOCConstant.E_DATA);
		String promotionDescription = KohlsPOCConstant.EMPTY;
		if(dataEleList.size() > KohlsPOCConstant.ZERO_INT && null != dataEleList.get(KohlsPOCConstant.ZERO_INT)){
			Element dataElement = dataEleList.get(KohlsPOCConstant.ZERO_INT);
			String legacyDoller = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
			String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
			String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
			String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
			String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
			String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
			//String includeExcludeFlag = dataElement.getAttribute(KohlsPOCConstant.A_INCLUDE_ENCLUDE_FLAG);
			
			if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
				if(!YFCCommon.isStringVoid(legacyDoller)){
					//Added for TLD Description for Sprint-8 -- Start
					//String[] args2 = {promotionIdForDesc,twoDForm.format(Math.abs(Double.valueOf(legacyDoller)))};
					String[] args2 = {promotionDesc};
					//Added for TLD Description for Sprint-8 -- End
					promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_ORDER_PROP_KEY, args2);
				}else if(!YFCCommon.isStringVoid(legacyPercent)){
					//legacyPercent = String.valueOf(Math.abs(Double.valueOf(legacyPercent)/KohlsPOCConstant.HUNDRED_INT));
					
					// Defect Fix :2632 Removed division by 100, as this is getting directly shown to gravity for forming description.
					legacyPercent = String.valueOf(Math.abs(Double.valueOf(legacyPercent).intValue()));
					
					//Added for TLD Description for Sprint-8 -- Start
					//String[] args2 = {promotionIdForDesc,legacyPercent};
					String[] args2 = {legacyPercent,promotionDesc};
					//Added for TLD Description for Sprint-8 -- End
					promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_ORDER_PROP_KEY, args2);
				}
			}else if(KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
					&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
					&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL){
				
				//Added for TLD Description for Sprint-8 -- Start
				//String[] args2 = {promotionIdForDesc,twoDForm.format(Math.abs(Double.valueOf(couponBalance)))};
				String[] args2 = {promotionDesc};
				//Added for TLD Description for Sprint-8 -- End
				promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
			}	
			
		}
		XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
		
		this.logger.debug("Method Name : setPromotionDescriptionForKohlsCash   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.setPromotionDescriptionForKohlsCash");

	}

	private void setPromotionDescriptionForKohlsCashOffline(String promotionIdForDesc, Element promotionEle) {
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.setPromotionDescriptionForKohlsCashOffline");

		this.logger.debug("Method Name : setPromotionDescriptionForKohlsCashOffline   and   Status  ");
		
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
		String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
		
		Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
		String extnCouponAmount = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
		
		/* Modified the condition, if extnCouponAmount is present and greater than 0.0 setting the value to overrideAdjustmentValue */   
		if(!YFCCommon.isStringVoid(extnCouponAmount) && Double.valueOf(extnCouponAmount).doubleValue() > KohlsPOCConstant.ZERO_DBL){
			overrideAdjustmentValue = extnCouponAmount;			
		}else{
			if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
				overrideAdjustmentValue = overrideMaxAdjustment;
			} else {
				overrideAdjustmentValue = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
			}
			overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,overrideAdjustmentValue);
		}
		
		//Added for TLD Description for Sprint-8 -- Start
		//String[] args2 = {promotionIdForDesc,twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue)))};
		String promotionDesc =  promotionIdForDesc.substring((promotionIdForDesc.length())-KohlsPOCConstant.FIVE_INT);
		String[] args2 = {promotionDesc};
		//Added for TLD Description for Sprint-8 -- End
		String promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
		
		XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
		
		this.logger.debug("Method Name : setPromotionDescriptionForKohlsCashOffline   and   Status  ");
		logger.endTimer("KohlsPoCOrderPromotionsCaller.setPromotionDescriptionForKohlsCashOffline");

	}
	
	public void cleanUp(){
		this.orderCouponHM = null;
		this.orderKohlsCashHM = null;
		this.orderManualTldHM = null;
		this.orderSeniorCitizenHM = null;
		this.orderAssociateHM = null;
		this.orderOfflineKohlsCashHM = null;
	}
	
	
	/**
	 * 
	 * Method Name : setOfferStartAndEndDates Description : This method sets
	 * Offer Start Date  and End Date  
	 * 
	 * @param pluOfferResposneEle
	 *            recordEle holds the PLU response
	 * @param promotionOrAwardEle
	 *           
	 * 
	 */

	public static void setOfferStartAndEndDates(Element pluOfferResposneEle, Element promotionOrAwardEle) throws ParseException {
		
		logger.beginTimer("KohlsPoCOrderPromotionsCaller.setOfferStartAndEndDates");

		Element promotionOrAwardExtnEle = XMLUtil.getChildElement(promotionOrAwardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);		
		
		List<Element> xstOfferSectEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_SECT);

		
		String extnOfferStartDate = KohlsPOCConstant.EMPTY;
		String extnOfferEndDate = KohlsPOCConstant.EMPTY;
		//Added for setting Offer Redeem Supervisor Override Date
				String extnOfferRedmnSupvrOvrridDate = KohlsPOCConstant.EMPTY;
		
		
		if (xstOfferSectEleList.size() > KohlsPOCConstant.ZERO_INT){
			String offerStartDate = ((Element) xstOfferSectEleList.get(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_EFF_BEG_DTE );
			String offerEndDate = ((Element) xstOfferSectEleList.get(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_EFF_END_DTE );
			//Added for setting Offer Redeem Supervisor Override Date
			String offerRedmnSupvrOvrridDate = ((Element) xstOfferSectEleList.get(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_REDMN_SUPVR_OVRRID_DTE );
			
			if(!YFCCommon.isVoid(offerStartDate)){
				extnOfferStartDate = offerStartDate;
			}
			
			if(!YFCCommon.isVoid(offerEndDate)){
				extnOfferEndDate = offerEndDate;
			}
			
			//Added for setting Offer Redeem Supervisor Override Date
			if(!YFCCommon.isVoid(offerRedmnSupvrOvrridDate)){
				extnOfferRedmnSupvrOvrridDate = offerRedmnSupvrOvrridDate;
			}
			
		}
		
		XMLUtil.setAttribute(promotionOrAwardExtnEle, KohlsPOCConstant.E_EXTN_START_DATE,extnOfferStartDate);
		XMLUtil.setAttribute(promotionOrAwardExtnEle, KohlsPOCConstant.E_EXTN_END_DATE,extnOfferEndDate);
		//Added for setting Offer Redeem Supervisor Override Date
				XMLUtil.setAttribute(promotionOrAwardExtnEle, KohlsPOCConstant.A_EXTN_REDMN_SUPVR_OVRRID_DATE,extnOfferRedmnSupvrOvrridDate);
		
		logger.endTimer("KohlsPoCOrderPromotionsCaller.setOfferStartAndEndDates");
		
	}
	
	//Added for 3945 defect fix --- Start
	public void setOrderAssociateDisHM(String uuidStr,Element promoEle) {
		this.orderAssociateDisHM.put(uuidStr, promoEle);
	}
	
	public Map<String, Element> getOrderAssociateDisHM() {
		return this.orderAssociateDisHM;
	}
	public void setOrderAssoDisHM(String uuidStr,Element promoEle,String assoType) {
		this.orderAssoDisHM.put(uuidStr+assoType, promoEle);
	}
	public Map<String, Element> getOrderAssoDisHM() {
		return this.orderAssoDisHM;
	}
	//Added for 3945 defect fix --- End
	
	
}
