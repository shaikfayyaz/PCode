package com.kohls.poc.pricing.ue;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.api.KohlsOMSOICIntegrationAdapter;
// import com.kohls.poc.api.KohlsItemExclusionDefinition;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.returns.api.KohlsPoCPAVoid;
import com.kohls.poc.returns.ue.KohlsBeforeCreateReturnOrderUE;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.ycp.bcsupport.YCPBCTemplateTrimmer;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSBeforeChangeOrderUE;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;

/**************************************************************************
 * File : KohlsPoCBeforeChangeOrderUE.java Author : IBM Created : Sept 28 2015 Modified : Version :
 * 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 28/08/2013 IBM First Cut.
 * 
 ***************************************************************************** 
 * TO DO : *************************************************************************** Copyright @
 * 2013. This document has been prepared and written by IBM Global Services on behalf of Kohls, and
 * is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file can be implemented as UserExit YFSBeforeChangeOrderUE. In this file, If
 * Order/OrderLines/OrderLine/@Action="Create" then
 * Order/OrderDates/OrderDate[@DateTypeID='PRICING_DATE']/@ActualDate will be copied to
 * Order/OrderLines/OrderLine/@PricingDate
 * 
 * @author Manoj Joshi
 * @version 0.1
 *****************************************************************************/
public class KohlsPoCBeforeChangeOrderUE extends KOHLSBaseApi implements YFSBeforeChangeOrderUE {
  private static YFCLogCategory logger;
  HashMap<String, String> recycleFeeSkuMap = new HashMap<String, String>();
  SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
  static {
    logger = YFCLogCategory.instance(KohlsPoCBeforeChangeOrderUE.class.getName());

  }
  private static YFCDocument oTemplateDoc = null;
  public static final String GetTaxDetailsTemplateForPSAMidVoid = "<Order EnterpriseCode='' MaxOrderStatus='' OrderHeaderKey='' OrderNo='' SellerOrganizationCode='' "
  		+ "Override='' POCFeature='' POSSequenceNumber='' PosSequenceNo='' Status='' ><Extn ExtnPsaStatus='' ExtnRequestDateTime=''/><Promotions>"
  		+ "<Promotion Description='' PromotionApplied='' PromotionGroup='' PromotionId='' PromotionType=''><Extn ExtnIsPsaPromotion=''/>"
  		+ "</Promotion></Promotions><OrderLines><OrderLine OrderLineKey='' PrimeLineNo='' ><LineTaxes><LineTax/></LineTaxes></OrderLine></OrderLines></Order>";
  
  private static YIFApi api = null;
	static {
	try {
		api = YIFClientFactory.getInstance().getApi();
	} catch (YIFClientCreationException e) {
		e.printStackTrace();
	}
}

  @Override
  public Document beforeChangeOrder(YFSEnvironment env, Document inXML)
      throws YFSUserExitException {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.beforeChangeOrder");

    validateReturnCreation(env,inXML);
    Document docIfPSA = checkifChangeOrderisForPSA(env, inXML);

    checkifChangeOrderForVoid(env, inXML);

    // Changes for #1617 - POC Returns Team - Start
    Document docIfEE = checkifChangeOrderisForEE(env, inXML);
    Element eleOrderRoot = inXML.getDocumentElement();

    String sDocumentType = eleOrderRoot.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
    String sExtnPsaStatus="";
    String sPOCFeature = "";
    // Changes for #1617 - POC Returns Team - End
    // overrideTaxableFlagForReturnOrder(inXML);
    // Added for POC Returns
    Element eleOrderExtn = XMLUtil.getChildElement(eleOrderRoot, KohlsPOCConstant.A_EXTN);
    
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      sPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
      // CAPE-2254 Check for KC Unearn promotion for Returns - begin
      if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase(sDocumentType)
          && !YFCCommon.isVoid(sPOCFeature)) {
        String sExtnDeductibleOffer = eleOrderExtn.getAttribute("ExtnDeductibleOffers");
        Element elePromotion = null;
        try {
          elePromotion = (Element) XPathUtil.getNode(eleOrderRoot,
              "/Order/Promotions/Promotion[@PromotionType='KOHLS_CASH_REISSUE']");
        } catch (Exception e1) {
          throw new YFSUserExitException(e1.getMessage());
        }
        if (!YFCCommon.isVoid(sExtnDeductibleOffer)) {
          try {
            KohlsBeforeCreateReturnOrderUE obj = new KohlsBeforeCreateReturnOrderUE();
            obj.setPromotionsForRO(env, inXML);
          } catch (Exception e) {
            logger.debug("Error in setting KC Unearn promotions");
            throw new YFSException(e.getMessage());
          }
        }
      }
       sExtnPsaStatus = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
      if (!YFCCommon.isVoid(sPOCFeature) && !YFCCommon.isVoid(sExtnPsaStatus)
          && "PriceAdjustment".equals(sPOCFeature)
          && ("PA_VOID".equals(sExtnPsaStatus) || "PA_MIDVOID".equals(sExtnPsaStatus))) {
        logger.debug("This is PA MidVoid or PA Post void xml. So returning the modified data");

        return docIfPSA;
      }
     
    }
    String sIgnoreRepricingUE = eleOrderRoot.getAttribute("IgnoreRepricingUE");
    if (!YFCCommon.isVoid(sIgnoreRepricingUE) && "Y".equalsIgnoreCase(sIgnoreRepricingUE)) {
      // setting env object to skip the Repricing UE call.
      env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
    }
    
    NodeList nlOrderLine = eleOrderRoot.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    if (nlOrderLine.getLength() > 0) {
      String sOrderHeaderKey = eleOrderRoot.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
      String sOrderNo = eleOrderRoot.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
      String sEnterpriseCode = eleOrderRoot.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);
      Document docGetOrderDetailsOut = null;
      String sPricingDate = "";
      String sResponseType = "";
      try {
        Document docGetOrderDetailsIn = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,
            sOrderHeaderKey);
        docGetOrderDetailsIn.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORDER_NO,
            sOrderNo);
        docGetOrderDetailsIn.getDocumentElement()
            .setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, sEnterpriseCode);
        String sGetOrderDetailsTemplate = "";
        // Template for Instore return
        if (KohlsPOCConstant.RECEIPTED_RET.equals(sPOCFeature)) {
          sGetOrderDetailsTemplate =
              "<Order OrderHeaderKey=''><Extn ExtnOTRResponseType='' ExtnOTRResponse=''/><OrderLines><OrderLine OrderLineKey=''><CustomAttributes Text10='' Date2='' /></OrderLine></OrderLines><OrderDates><OrderDate DateTypeId='' ActualDate=''/></OrderDates></Order>";
        } else {
          sGetOrderDetailsTemplate =
              "<Order OrderHeaderKey=''><Extn ExtnOTRResponseType='' ExtnOTRResponse=''/><OrderDates><OrderDate DateTypeId='' ActualDate=''/></OrderDates></Order>";
        }
        logger.debug("Invoking getOrderDetails API with input xml: \n"
            + XMLUtil.getXMLString(docGetOrderDetailsIn));
        docGetOrderDetailsOut = invokeAPI(env, XMLUtil.getDocument(sGetOrderDetailsTemplate),
            "getOrderDetails", docGetOrderDetailsIn);
        if (!YFCCommon.isVoid(docGetOrderDetailsOut)) {
          sPricingDate = XPathUtil.getString(docGetOrderDetailsOut.getDocumentElement(),
              "/Order/OrderDates/OrderDate[@DateTypeId='PRICING_DATE']/@ActualDate");

          logger.debug("Pricing Date is: " + sPricingDate);

          // Start CAPE - 2751 -- Murali K
          if (!YFCCommon.isVoid(sPOCFeature)
              && KohlsPOCConstant.RECEIPTED_RET.equals(sPOCFeature)) {
            sResponseType = XPathUtil.getString(docGetOrderDetailsOut.getDocumentElement(),
                "/Order/Extn/@ExtnOTRResponse");
            if (KohlsPOCConstant.A_OTR_RESPONSE_1F0.equals(sResponseType)
                && ServerTypeHelper.amIOnEdgeServer()) {
              logger.debug("********* Processing NonSyncOrderLine in ISS **************");
              processNonSyncOrderLine(env, eleOrderRoot,
                  docGetOrderDetailsOut.getDocumentElement());
            }
          }
          // End CAPE 2751 - Murali K
        }
      } catch (Exception e) {
        e.printStackTrace();
        throw new YFSException(e.getMessage(), "00000", e.getMessage());
      }

      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        Element eleCustomAttributes =
                XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
          if(!YFCCommon.isVoid( eleCustomAttributes))
          {
        String sDate2 = eleCustomAttributes.getAttribute("Date2");
        if(!YFCCommon.isVoid(sDate2))
        {
      	 
      	  sDate2= sDate2.substring(0, 19);
      	  {
      		  eleCustomAttributes.setAttribute("Date2", sDate2);
      		  logger.debug("Modified Date is : " + eleCustomAttributes.getAttribute("Date2"));
      	      
      	  }
      			  
        }
          }
        
        Element eleCurrentLinePriceInfo =
            XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_LINE_PRICE_INFO);
        if (!YFCCommon.isVoid(eleCurrentLinePriceInfo)) {
          String sUnitPrice = eleCurrentLinePriceInfo.getAttribute(KohlsXMLLiterals.A_UNIT_PRICE);
          if (!YFCCommon.isVoid(sUnitPrice)) {

            if (sUnitPrice.indexOf(",") != -1) {
              sUnitPrice = sUnitPrice.replace(",", "");
              eleCurrentLinePriceInfo.setAttribute(KohlsXMLLiterals.A_UNIT_PRICE, sUnitPrice);
            }
          }


        }

        // Added for defect 1774 - Begin
        String sAction = eleOrderLine.getAttribute(KohlsPOCConstant.A_ACTION);
        logger.debug("Orderline Action is: " + sAction);
        if (!YFCCommon.isVoid(sAction) && KohlsPOCConstant.A_CREATE.equalsIgnoreCase(sAction)) {
          if (sDocumentType.equalsIgnoreCase(KohlsPOCConstant.RO_DOCUMENT_TYPE)) {
            // Skipping loading of hashmap for POC Return
            if (recycleFeeSkuMap.isEmpty() && !YFCCommon.isVoid(sPOCFeature)) {
              loadRecycleFeeSkyHashMap(env);
            }
            Element eleItem = ((Element) eleOrderLine.getElementsByTagName("Item").item(0));

            String sItemid = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);

            logger.debug("Orderline - Item being returned is : " + sItemid);

            // Skipping RecycleFee check for POC Return
            if (recycleFeeSkuMap.containsKey(sItemid) && YFCCommon.isVoid(sPOCFeature)) {
              logger.debug("Item being returned is RecycleFee. So setting OrderedQty = 0");
              eleOrderLine.setAttribute("DerivedFromOrderHeaderKey", "");
              eleOrderLine.setAttribute("DerivedFromOrderLineKey", "");
              eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY, "0.00");
            }

            if (!"".equalsIgnoreCase(sPOCFeature)) {
              try {
                // MJ 04/24 - Setting Text10 into env object so that it can be retrieved
                // in repricing UE for TVS call to get the CurrentSellingPrice
                String sText7 = "";
                String sText8 = "";
                String sMultiOrderNbr = "";
                checkForExclusionItem(env, eleOrderLine);
                if (!KohlsPOCConstant.RS_BAD_DATA_CODE.contains(sResponseType)) {
                  manageAwards(eleOrderLine);
                }
                if (!YFCCommon.isVoid(eleCustomAttributes)) {
                  String sText10 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT10);
                  String sText9 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
                  sText7 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
                  sText8 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
                  if (!YFCCommon.isVoid(sText10)) {
                	env.setTxnObject("LINE_GETTING_ADDED", sText7+"_"+sText8+"_"+sText9+"_"+sText10);
                	env.setTxnObject("TRANSACTION_GETTING_ADDED", sText7+"_"+sText8+"_"+sText9);
                  }
                 
                  sMultiOrderNbr = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT13);
                }
                // set ExtnNetPrice in case of offline - F9, 1F1, 1F0
                if (KohlsPOCConstant.RS_BAD_DATA_CODE.contains(sResponseType)) {
                  if(YFCCommon.isVoid(sMultiOrderNbr)){
                	  calculateTaxForECom(eleOrderLine, false);
                  }                 
                }
                /* Added for Tax Calculation for ECommOrders - END */
              } catch (Exception e) {
                throw new YFSUserExitException(e.getMessage());
              }
            }
          }
          // Added for defect 1774 - End



          eleOrderLine.setAttribute("PricingDate", sPricingDate);

        } else if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase(sDocumentType)) {
          try {
            handleVoidDuringWithoutItem(env, inXML);
          } catch (Exception e) {
            e.printStackTrace();
            throw new YFSUserExitException(e.getMessage());

          }

        }
      }
    }
    // MJ 01/23: Added for CAPE 1568 - Begin
    else if (KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase(sDocumentType)) {
      env.setTxnObject("SkipManagePSIOrderCall", true);
    }
    // MJ 01/23: Added for CAPE 1568 - End

    
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.beforeChangeOrder");
    return inXML;
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @return
   * @throws Exception
   */
  private ArrayList<String> getECOMStoreList(YFSEnvironment env) throws Exception {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.getECOMStoreList");
    Document docCommonCodeIn = XMLUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
    Element eleCommonCodeIn = docCommonCodeIn.getDocumentElement();
    eleCommonCodeIn.setAttribute(KohlsPOCConstant.A_CODE_TYPE,
        KohlsPOCConstant.COMMON_CODE_TYPE_EComStores);
    Document docCommonCodeTemplate =
        XMLUtil.getDocument(KohlsPOCConstant.TEMPLATE_GET_COMMON_CODE_LIST);
    Document docCommonCodeOut = invokeAPI(env, docCommonCodeTemplate,
        KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docCommonCodeIn);
    ArrayList<String> lstEcomStoreList = new ArrayList<String>();
    if (!YFCCommon.isVoid(docCommonCodeOut)) {
      NodeList nlCommonCode = docCommonCodeOut.getElementsByTagName(KohlsPOCConstant.E_COMMON_CODE);
      if (nlCommonCode.getLength() > 0) {
        for (int j = 0; j < nlCommonCode.getLength(); j++) {
          Element eleCommonCode = (Element) nlCommonCode.item(j);
          String sECOMStoreID = eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_VALUE);
          lstEcomStoreList.add(sECOMStoreID);
        }
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.getECOMStoreList");
    return lstEcomStoreList;
  }

  /**
   * This method links RO to SO for unsynched orders. Create By Murali *
   * 
   * @param env
   * @param eleInOrder
   * @param eleReturnOrderDetails
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  private void processNonSyncOrderLine(YFSEnvironment env, Element eleInOrder,
      Element eleReturnOrderDetails) throws Exception {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.processNonSyncOrderLine");

    Set setPrimeLineNo = new HashSet();
    Element eleInOrderLine = (Element) XPathUtil.getNode(eleInOrder, "/Order/OrderLines/OrderLine");
    Element eleCustAttributes =
        (Element) XPathUtil.getNode(eleInOrder, "/Order/OrderLines/OrderLine/CustomAttributes");

    NodeList nLOrderLines =
        eleReturnOrderDetails.getElementsByTagName(KohlsXMLLiterals.E_ORDER_lINE);
    if (nLOrderLines.getLength() > 0) {
      for (int i = 0; i < nLOrderLines.getLength(); i++) {
        Element tempOrderLineEle = (Element) nLOrderLines.item(i);
        Element eleTempCustAttributes =
            XMLUtil.getChildElement(tempOrderLineEle, KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES);
        if (!YFCCommon.isVoid(eleTempCustAttributes)) {
          if (!YFCCommon.isVoid(eleTempCustAttributes.getAttribute(KohlsPOCConstant.TEXT10))) {
            setPrimeLineNo.add(eleTempCustAttributes.getAttribute(KohlsPOCConstant.TEXT10));
          }
        }
      }
    }

    // creating inDoc for getOrderList API call for saleOrder.
    Document inDocGetOrderList = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
    Element eleInDoc = inDocGetOrderList.getDocumentElement();
    String sellerOrgCode = eleCustAttributes.getAttribute(KohlsPOCConstant.TEXT7);
    String terminalID = eleCustAttributes.getAttribute(KohlsPOCConstant.TEXT8);
    String posSeqNo = eleCustAttributes.getAttribute(KohlsPOCConstant.TEXT9);
    
    Document ourDocGetOrderList = null;
    //If any of these 3 attributes are null then dont call getOrderList api. Just prepare
    //empty <OrderList/> xml
    if(YFCCommon.isVoid(sellerOrgCode) || YFCCommon.isVoid(terminalID) || YFCCommon.isVoid(posSeqNo)) {
      ourDocGetOrderList = XMLUtil.getDocument("<OrderList/>");
    } else {
      eleInDoc.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, sellerOrgCode);
      eleInDoc.setAttribute(KohlsXMLLiterals.A_TERMINAL_ID, terminalID);
      eleInDoc.setAttribute(KohlsXMLLiterals.A_POS_SEQ_NO, posSeqNo);
      
          // To select only unsynched orders
      eleInDoc.setAttribute("Status", "1100.100");
      eleInDoc.setAttribute("StatusQryType", "NE");

      Element eleAdditionalInfo =
          SCXmlUtil.createChild(eleInDoc, KohlsXMLLiterals.E_YFCADDITIONALINFO);
      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, "LOCAL");

      // creating template for getOrderList API call for saleOrder.
      Document temDocGetOrderList = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDERLIST);
      Element eleOrderGetOrderList =
          XMLUtil.createChild(temDocGetOrderList.getDocumentElement(), KohlsXMLLiterals.E_ORDER);
      eleOrderGetOrderList.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, "");

      Element eleOrderLines =
          XMLUtil.createChild(eleOrderGetOrderList, KohlsXMLLiterals.E_ORDER_LINES);
      Element eleOrderLine = XMLUtil.createChild(eleOrderLines, KohlsXMLLiterals.E_ORDER_LINE);

      eleOrderLine.setAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO, "");
      eleOrderLine.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, "");

      Element eleItem = XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_ITEM);
      eleItem.setAttribute(KohlsXMLLiterals.A_ITEM_ID, "");
      // Element eleLinePriceInfo =
      // XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_LINE_PRICE_INFO);

      // Element eleAwards = XMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_AWARDS);
      // Element eleAward = XMLUtil.createChild(eleAwards, KohlsXMLLiterals.E_AWARD);

      // Element eleYfcAdditionalInfo =
      // XMLUtil.createChild(eleOrderGetOrderList, KohlsXMLLiterals.E_YFCADDITIONALINFO);

      if (logger.isDebugEnabled()) {
        logger.debug("Input to getOrderList API :: " + XMLUtil.getXMLString(inDocGetOrderList));
        logger.debug("template  to getOrderList API :: " + XMLUtil.getXMLString(temDocGetOrderList));
      }

      // Invoking getOrderList API -- to get SalesOrder details
       ourDocGetOrderList = KohlsCommonUtil.invokeAPI(env, temDocGetOrderList,
          KohlsPOCConstant.API_GET_ORDER_LIST, inDocGetOrderList);

      if (logger.isDebugEnabled()) {
        logger.debug("Output of  getOrderList API :: " + XMLUtil.getXMLString(ourDocGetOrderList));
      }
    }
    
    if (!YFCCommon.isVoid(ourDocGetOrderList)) {
      Element eleOutOrder =
          XMLUtil.getChildElement(ourDocGetOrderList.getDocumentElement(), KohlsXMLLiterals.E_ORDER);

      if (!YFCCommon.isVoid(eleOutOrder)) {
        String strItemID = XMLUtil.getChildElement(eleInOrderLine, KohlsXMLLiterals.E_ITEM)
            .getAttribute(KohlsXMLLiterals.A_ITEM_ID);

        NodeList nSaleLOrderLines = eleOutOrder.getElementsByTagName(KohlsXMLLiterals.E_ORDER_lINE);
        if (nSaleLOrderLines.getLength() > 0) {
          for (int i = 0; i < nSaleLOrderLines.getLength(); i++) {
            Element tempSaleOrderLineEle = (Element) nSaleLOrderLines.item(i);
            Element tempSaleOrderLineItem =
                XMLUtil.getChildElement(tempSaleOrderLineEle, KohlsXMLLiterals.E_ITEM);
            if (!YFCCommon.isVoid(tempSaleOrderLineItem)) {
              if (strItemID.equals(tempSaleOrderLineItem.getAttribute(KohlsXMLLiterals.A_ITEM_ID))
                  && !tempSaleOrderLineEle.getAttribute(KohlsPOCConstant.IS_RETURNED_ITEM)
                      .equals(KohlsPOCConstant.YES)) {
                if (setPrimeLineNo
                    .contains(tempSaleOrderLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO))) {
                  continue;
                } else {
                  // Element eleDerivedFrom = XMLUtil.createChild(eleInOrderLine, "DerivedFrom");
                  // eleDerivedFrom.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
                  // eleOutOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
                  // eleDerivedFrom.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY,
                  // tempSaleOrderLineEle.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY));

           eleInOrderLine.setAttribute(KohlsPOCConstant.DERIVED_FROM_EXTERNAL_ORDER, "N");
                  eleInOrderLine.setAttribute(KohlsXMLLiterals.A_DERIVED_FROM_ORDER_HEADER_KEY,
                      eleOutOrder.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
                  eleInOrderLine.setAttribute(KohlsXMLLiterals.A_DERIVED_FROM_ORDER_LINE_KEY,
                      tempSaleOrderLineEle.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY)); 
                  /*
                   * XMLUtil.getChildElement(eleInOrderLine, KohlsXMLLiterals.E_CUSTOM_ATTRIBUTES)
                   * .setAttribute(KohlsPOCConstant.TEXT10,
                   * tempSaleOrderLineEle.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO));
                   */
                  break;
                }
              }
            }
          }
        }
        // }
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.processNonSyncOrderLine");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param inXML
   * @return
   */
  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param inXML
   * @return
   */
  public Document checkIfChangeOrderisForPAVoid(YFSEnvironment env, Document inXML) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.checkIfChangeOrderisForPAVoid");

    Element eleOrderRoot = inXML.getDocumentElement();
    Document docOutPAVoid = null;
    // Added for POC Returns
    Element eleOrderExtn = XMLUtil.getChildElement(eleOrderRoot, KohlsPOCConstant.A_EXTN);
    if (!YFCCommon.isVoid(eleOrderExtn)) {
    }
    String sIgnoreRepricingUE = eleOrderRoot.getAttribute("IgnoreRepricingUE");
    if (!YFCCommon.isVoid(sIgnoreRepricingUE) && "Y".equalsIgnoreCase(sIgnoreRepricingUE)) {
      // setting env object to skip the Repricing UE call.
      env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
    }
    if (!YFCCommon.isVoid(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS)))
      if (!YFCCommon.isVoid(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS))) {
        if (eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS).equals("PA_MIDVOID")
            || eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS).equals("PA_VOID")) {
          KohlsPoCPAVoid paVoid = new KohlsPoCPAVoid();
          try {
            if (logger.isDebugEnabled()) {
              logger.debug("KohlsPoCBeforeChangeOrderUE.beforeChangeOrder --Input void  "
                  + XMLUtil.getElementXMLString(eleOrderRoot));
            }
            docOutPAVoid = paVoid.updateVoidDetails(env, inXML);
            if (logger.isDebugEnabled()) {
              logger.debug("KohlsPoCBeforeChangeOrderUE.beforeChangeOrder --outPut void  "
                  + XMLUtil.getXMLString(docOutPAVoid));
            }
          } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
        }
      }
    if (!YFCCommon.isVoid(docOutPAVoid)) {
      logger.endTimer("KohlsPoCBeforeChangeOrderUE.checkIfChangeOrderisForPAVoid");
      return docOutPAVoid;
    } else {
      logger.endTimer("KohlsPoCBeforeChangeOrderUE.checkIfChangeOrderisForPAVoid");
      return inXML;
    }

  }

  // This method overrides the taxbable flag coming from gravity for return order.

  /**
   * Create By mrjoshi *
   * 
   * @param inXML
   */
  private void overrideTaxableFlagForReturnOrder(Document inXML) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.overrideTaxableFlagForReturnOrder");
    Element eleOrder = inXML.getDocumentElement();
    String sDocumentType = eleOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
    Element eleOrderLine =
        (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE).item(0);
    if (!YFCCommon.isVoid(eleOrderLine)) {
      String sAction = eleOrderLine.getAttribute(KohlsPOCConstant.A_ACTION);
      if (!YFCCommon.isVoid(sAction) && !YFCCommon.isVoid(sDocumentType)
          && KohlsPOCConstant.A_CREATE.equalsIgnoreCase(sAction)
          && KohlsPOCConstant.RO_DOCUMENT_TYPE.equalsIgnoreCase(sDocumentType)) {
        Element eleLinePriceInfo =
            (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
        if (!YFCCommon.isVoid(eleLinePriceInfo)) {
          NodeList nlLineTax = eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX);
          if (nlLineTax.getLength() > 0) {
            eleLinePriceInfo.setAttribute(KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.YES);
          } else {
            eleLinePriceInfo.setAttribute(KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.NO);
          }
        }
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.overrideTaxableFlagForReturnOrder");
  }

  // Changes for #3862 -- POC Returns Team - Start
  /**
   * @param env
   * @param inXML
   * 
   *        This method saves the Updated ShipNode into a Txn Object
   */
  private void saveOrganizationCodeForPSA(YFSEnvironment env, Document inXML) {
    try {
      logger.beginTimer("KohlsPoCBeforeChangeOrderUE.saveOrganizationCodeForPSA");
      Element eleOrder = inXML.getDocumentElement();
      String strOrganizationCode = eleOrder.getAttribute(KohlsXMLLiterals.ATTR_ORGANIZATION_CODE);
      if (!YFCCommon.isStringVoid(strOrganizationCode)) {
        logger.debug("KohlsPoCBeforeChangeOrderUE.saveOrganizationCodeForPSA  PSA Store is"
            + strOrganizationCode);
        env.setTxnObject(KohlsXMLLiterals.ATTR_ORGANIZATION_CODE, strOrganizationCode);
      }
      logger.endTimer("KohlsPoCBeforeChangeOrderUE.saveOrganizationCodeForPSA");
    } catch (Exception e) {
      logger.error(e);
    }

  }
  // Changes for #3862 -- POC Returns Team - End

  // Changes for #1617 - POC Returns Team - Start
  /**
   * Create By mrjoshi *
   * 
   * @param env
   * @param inDoc
   * @return
   */
  public Document checkifChangeOrderisForEE(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForEE");
    Element eleOrder = inDoc.getDocumentElement();
    if (!YFCCommon.isVoid(eleOrder)) {
      String strIsEvenExchangeOrder = eleOrder.getAttribute("IsEvenExchangeOrder");
      if (!YFCCommon.isStringVoid(strIsEvenExchangeOrder)
          && strIsEvenExchangeOrder.equalsIgnoreCase("Y")) {
        env.setTxnObject("IsEvenExchangeOrder", "Y");
      }

    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForEE");
    return inDoc;
  }

  // Changes for #1617 - POC Returns Team - End
  /**
   * 
   * @param env
   * @param inDoc
 * @throws YFSUserExitException 
   */

  public Document checkifChangeOrderisForPSA(YFSEnvironment env, Document inDoc) throws YFSUserExitException {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForPSA");

    Element eleSPSOrderRoot = inDoc.getDocumentElement();
    // Start : Changes for SPS project to skip repricing call
    String sExtnPOCFeature = "";
    String sExtnPSAStatus = "";
    Element eleOrderExtn = XMLUtil.getChildElement(eleSPSOrderRoot, KohlsPOCConstant.E_EXTN);
    if(!YFCCommon.isVoid(eleOrderExtn)) {
      sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
      sExtnPSAStatus=eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
    }
    String sEvenExchange=eleSPSOrderRoot.getAttribute( KohlsPOCConstant.A_RETURN_OHK_FOR_EXCHANGE );
    String sSPSIgnoreRepricingUE = eleSPSOrderRoot.getAttribute("IgnoreRepricingUE");
    if (  KohlsPOCConstant.SO_DOCUMENT_TYPE.equalsIgnoreCase( eleSPSOrderRoot.getAttribute( KohlsPOCConstant.ATTR_DOC_TYPE ) ) )
    {

       logger.debug( "KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForPSA-->If block calling" );
       if ( YFCCommon.isVoid( sExtnPOCFeature ) && !("Y".equalsIgnoreCase(sSPSIgnoreRepricingUE)) 
    		   && YFCCommon.isVoid( sEvenExchange ) )
       {
          logger.debug( "KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForPSA-->calling" );
          setRequestProcess( eleSPSOrderRoot );
          
       }
    }
    if(YFCCommon.isVoid(sExtnPOCFeature)) {
      
      if (!YFCCommon.isVoid(sSPSIgnoreRepricingUE) && "Y".equalsIgnoreCase(sSPSIgnoreRepricingUE)) {
        // setting env object to skip the Repricing UE call.
        env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
      }
    }
    // End : Changes for SPS project to skip repricing call
    
    
	//Start: Changes for OMNI Bag Start
	  try {
	    	KohlsOMSOICIntegrationAdapter kohlsOMSOICIntegrationAdapter=new KohlsOMSOICIntegrationAdapter();
	    	String strIsOICEnabled=kohlsOMSOICIntegrationAdapter.integrateWithOICorGIV(env,inDoc);
	    	
	    	if(!YFCCommon.isVoid(strIsOICEnabled) && strIsOICEnabled.equalsIgnoreCase("Y")){
	    		logger.debug("OIC is Enabled:: Integrate with OIC");
	    		api.executeFlow(env, "KohlsOMSOICIntegrationSyncService", inDoc);
	    	}else
	    	{   logger.debug("OIC is Disabled:: Integrate with GIV");
	    		api.executeFlow(env, "KohlsOMSGIVCreateReservationSyncService", inDoc);
	    	}
	    	}
	  	catch (YFSException e) {
	    		logger.error("Error YFSException AT KohlsPoCBeforeChangeOrderUE::beforeCreateOrder");
			throw new YFSException(e.getMessage());
		} 
	  catch (Exception e) {
	    	logger.error("Error Generic Exception AT KohlsPoCBeforeChangeOrderUE::beforeCreateOrder");
			throw new YFSUserExitException(e.getMessage());
		}
  //End: Changes for OMNI Bag End
	  
	  if(!YFCCommon.isVoid(eleSPSOrderRoot.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY))) {
		  eleSPSOrderRoot.removeAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
	  }

    // PR-919, 767, 851 - Start - Handling ChangeOrder Input, when called because of Manual/Auto
    // Store Close.
    inDoc = addPSADetailsForStoreCloseMidVoid(env, inDoc);
    // PR-919, 767, 851 - End
    // Changes for #3862 - POC Returns Team - Start
    saveOrganizationCodeForPSA(env, inDoc);
    // Changes for #3862 - POC Returns Team - End
    // Add method for PR-990 - Begin
    validateIfEmpDiscCodeExists(env, inDoc);
    // Add method for PR-990 - End

    if (logger.isDebugEnabled())
      logger.debug(
          "KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForPSA -- Organization Code TXN OBJ "
              + env.getTxnObject(KohlsXMLLiterals.ATTR_ORGANIZATION_CODE));
    Element eleExtn = (Element) inDoc.getElementsByTagName("Extn").item(0);
    if (!YFCCommon.isVoid(eleExtn)) {
      if (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnPOCFeature"))) {
        if (eleExtn.getAttribute("ExtnPOCFeature").equals("PriceAdjustment")) {
          Document docOutPAOrder = checkIfChangeOrderisForPAVoid(env, inDoc);
          return docOutPAOrder;
        }
      }
    }
    Element elePromotions = (Element) inDoc.getElementsByTagName("Promotions").item(0);
    if (!YFCCommon.isVoid(elePromotions)) {
      String isPSAPromotion = elePromotions.getAttribute("IsPSAChangeOrder");
      //PLYT-1477 - Start
      String strExtnPSAstatus = "";
      //Element eleOrderExtn = XMLUtil.getChildElement(eleSPSOrderRoot, "Extn");
      if(!YFCCommon.isVoid(eleOrderExtn)) {
        strExtnPSAstatus  = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
      }
      String pocFeature = XMLUtil.getAttribute(eleSPSOrderRoot, KohlsPOCConstant.POC_FEATURE);
      if (!YFCCommon.isStringVoid(isPSAPromotion) && isPSAPromotion.equals("Y") && 
    		  !(KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equalsIgnoreCase(strExtnPSAstatus)) && 
    		  !(KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equalsIgnoreCase(pocFeature))) {
        env.setTxnObject("IsPSAChangeOrder", "Y");
      } 
      //PLYT-1477 - End
      else {
    	  inDoc = checkifChangeOrderForVoid(env, inDoc);
    	  try {
    	       if(sExtnPSAStatus.equalsIgnoreCase("VOIDED") && ServerTypeHelper.amIOnEdgeServer()){
    	    	   Document docCurrentTaxes = getOrderDetailsForPSAMidVoid(env, inDoc.getDocumentElement(),
    	    		          GetTaxDetailsTemplateForPSAMidVoid);
    	    	   adjustDeltaTax(env, inDoc, docCurrentTaxes);
    	    	 
    	       }
    	      } catch (Exception e) {
    	        logger.error("Error while calling adjusttax in KohlsPoCTVSOrderRepriceUE.orderRepricePSA");
    	      }
    	  
      }
      String isPSASyncToCorp = XMLUtil.getAttribute(eleSPSOrderRoot, KohlsPOCConstant.IsPSASyncToCorp);
      if(!YFCCommon.isVoid(isPSASyncToCorp) && KohlsPOCConstant.YES.equalsIgnoreCase(isPSASyncToCorp)){
    	  inDoc = resetAwards(env, inDoc);
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.checkifChangeOrderisForPSA");
    return inDoc;
  }
  
  /**
   * 
   * @param input
   * @param output
   * @return
   * @throws Exception
   */
  public void adjustDeltaTax(YFSEnvironment env, Document input, Document tempOutputDoc)
      throws Exception {
	logger.beginTimer("KohlsPoCBeforeChangeOrderUE.adjustDeltaTax");
	if (logger.isDebugEnabled()) {
        logger.debug("PSA Midvoid Unsynced order : Input doc "
            + XMLUtil.getElementXMLString(input.getDocumentElement()));
        logger.debug("PSA Midvoid Unsynced order : Temp doc "
                + XMLUtil.getElementXMLString(tempOutputDoc.getDocumentElement()));
      }
    List<Element> ueInputOrdLine =
        XMLUtil.getElementsByTagName(input.getDocumentElement(), "OrderLine");
    Map<String, List<Element>> deltaTaxMap = new HashMap<String, List<Element>>();
    for (Element OrderLinele : ueInputOrdLine) {
      String strPrimeLineNo = XMLUtil.getAttribute(OrderLinele, "PrimeLineNo");
      List<Element> eleInpTaxList = XMLUtil.getElementsByTagName(OrderLinele, "LineTax");
      String orderLineKey = XMLUtil.getAttribute(OrderLinele, "OrderLineKey");
      for (Element LineTaxele : eleInpTaxList) {
        Double inputTax = Double.parseDouble(XMLUtil.getAttribute(LineTaxele, "Tax"));
        if (logger.isDebugEnabled()) {
          logger.debug("The Sale inputDoc tax is :" + inputTax.toString());
        }
        String TaxName = XMLUtil.getAttribute(LineTaxele, "TaxName");
        
        Element outTaxEle = (Element) KohlsXPathUtil.getNode(tempOutputDoc.getDocumentElement(),
            "/Order/OrderLines/OrderLine[@PrimeLineNo='" + strPrimeLineNo
                + "']/LineTaxes/LineTax[@TaxName='" + TaxName + "']");
        if (logger.isDebugEnabled()) {
        	logger.debug("PSA Midvoid Unsynced order : Before updating taxes " + orderLineKey + " ::: "
                + XMLUtil.getElementXMLString(outTaxEle));
          }
        if (null != outTaxEle) {

          Double outTax = Double.valueOf((XMLUtil.getAttribute(outTaxEle, "Tax")));
          if (logger.isDebugEnabled()) {
            logger.debug("The PSA response tax is :" + outTax.toString());
          }
          Double diffTax = inputTax - outTax;

          DecimalFormat df = new DecimalFormat("0.00");
          String tempFormatted = df.format(diffTax);
          diffTax = Double.valueOf(tempFormatted);
          if (logger.isDebugEnabled()) {
            logger.debug("The difference in tax is :" + diffTax.toString());
          }
          XMLUtil.setAttribute(outTaxEle, "tax", diffTax.toString());
          XMLUtil.setAttribute(outTaxEle, "Tax", diffTax.toString());
        }
      }
      Element outLineTaxesEle = (Element) KohlsXPathUtil.getNode(tempOutputDoc.getDocumentElement(),
    		  "/Order/OrderLines/OrderLine[@PrimeLineNo='" + strPrimeLineNo + "']/LineTaxes");
      List<Element> tempList = new ArrayList<Element>();
      tempList.add(outLineTaxesEle);

      if (logger.isDebugEnabled()) {
        logger.debug("PSA Midvoid Unsynced order : After updating taxes " + orderLineKey + " ::: "
            + XMLUtil.getElementXMLString(outLineTaxesEle));
      }
      deltaTaxMap.put(orderLineKey, tempList);
    }
    if (logger.isDebugEnabled()) {
        logger.debug("PSA Midvoid Unsynced order : Delta tax map is ::: "
            + deltaTaxMap);
      }
    env.setTxnObject("DeltaTax", deltaTaxMap);
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.adjustDeltaTax");
  }

/**
   *  This method is responsible for checking if return is already created for line.If yes then throw exception.
   * @param env
   * @param inDoc
   */
  private void  validateReturnCreation(YFSEnvironment env, Document inDoc)
  {
	  
	  logger.beginTimer("KohlsPoCBeforeChangeOrderUE.validateReturnCreation");
	  String template= "<OrderLineList><OrderLine MaxLineStatus=''></OrderLine></OrderLineList>";
	  try
	  {
	  String documentType = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
	  if("0003".equals(documentType))
	  {
		  Element eleOrderLine = (Element)inDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE).item(0);
		  if(!YFCCommon.isVoid(eleOrderLine))
		  {
			  String derivedOrderLineKey= eleOrderLine.getAttribute(KohlsPOCConstant.A_DERIVED_FROM_ORDER_LINE_KEY);
			  if(!YFCCommon.isVoid(derivedOrderLineKey))
			  {
				  Document getOrderLineListInputDoc = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ORDER_LINE).getDocument();
					Element eleInput = getOrderLineListInputDoc.getDocumentElement();
					eleInput.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY, derivedOrderLineKey);
					Document docGetOrderLineListTemplate = XMLUtil.getDocument(template);
					Document orderLineListDocOutput = KOHLSBaseApi.invokeAPI(env, docGetOrderLineListTemplate, "getOrderLineList",getOrderLineListInputDoc);
					if (logger.isDebugEnabled())
					{
						  logger.debug("outputFromGetOrderLineList" + XMLUtil.getXMLString(orderLineListDocOutput));
					}
					Element eleOrderLineFromOutput = (Element)orderLineListDocOutput.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE).item(0);
					String maxLineStatus = eleOrderLineFromOutput.getAttribute(KohlsPOCConstant.A_MAX_LINE_STATUS);
					if("3700.02".equals(maxLineStatus) || "3700.11".equals(maxLineStatus) || "3700.01".equals(maxLineStatus))
					{
						YFSException yfsException = new YFSException();								
						yfsException.setErrorCode("YFS_ALREADY_RETURNED");
						yfsException.setErrorDescription("Item already returned.\nScan a different receipt or perform a lookup.");
						throw yfsException;
					}
					else if ("3350.035".equals(maxLineStatus))
					{
						YFSException yfsException = new YFSException();								
						yfsException.setErrorCode("YFS_NOT_ELIGIBLE_RETURNS");
						yfsException.setErrorDescription("Item not eligible for return.\nScan a different receipt or perform a lookup.");
						throw yfsException;
					}
			  }
		  }
	  }
	  }
	  catch(Exception ex)
	  {
		  throw new YFSException(ex.getMessage());
	  }
	  
	  logger.endTimer("KohlsPoCBeforeChangeOrderUE.validateReturnCreation");
  }

  private Document resetAwards(YFSEnvironment env, Document inDoc) {
	  logger.beginTimer("KohlsPoCBeforeChangeOrderUE.resetAwards");
	  if (logger.isDebugEnabled())
		  logger.debug("input inDoc for resetAwards" + XMLUtil.getXMLString(inDoc));

	  Element eleOrder = inDoc.getDocumentElement();
	  String sOrderHeaderKey = XMLUtil.getAttribute(eleOrder, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
	  String sOrderNo = XMLUtil.getAttribute(eleOrder, "OrderNumber");
	  if(!YFCCommon.isVoid(sOrderHeaderKey)){
		  String sEnterpriseCode = XMLUtil.getAttribute(eleOrder, KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
		  Document docGetOrderDetailsOut = null;
		  try {
			  Document docGetOrderDetailsIn = XMLUtil.createDocument(KohlsPOCConstant.E_ORDER);
			  Element eleGetOrderDetailsIn = docGetOrderDetailsIn.getDocumentElement();
			  //eleGetOrderDetailsIn.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
			  eleGetOrderDetailsIn.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
			  eleGetOrderDetailsIn.setAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE, sEnterpriseCode);

			  if (logger.isDebugEnabled())
				  logger.debug("Invoking getOrderDetails API with input xml: \n" + XMLUtil.getXMLString(docGetOrderDetailsIn));

			  docGetOrderDetailsOut = invokeAPI(env, KohlsPOCConstant.GET_ORDER_DETAILS_FOR_PSA_SYNC_TEMPLATE,
					  KohlsPOCConstant.API_GET_ORDER_DETAILS, docGetOrderDetailsIn);

			  if (logger.isDebugEnabled())
				  logger.debug("getOrderDetails output xml: \n" + XMLUtil.getXMLString(docGetOrderDetailsOut));

			  if(!YFCCommon.isVoid(docGetOrderDetailsOut)){
				  Element eleGetOrderDetailsOut = docGetOrderDetailsOut.getDocumentElement();
				  List<Element> inputOrderLineList = XMLUtil.getElementsByTagName(inDoc.getDocumentElement(), KohlsPOCConstant.E_ORDER_LINE);
				  if (inputOrderLineList.size() > KohlsPOCConstant.ZERO_INT) {
					  for (Element inputOrderLine : inputOrderLineList) {
						  String strInputOrdLinePrimeLineNo = XMLUtil.getAttribute(inputOrderLine, KohlsPOCConstant.ATTR_PRIME_LINE_NO);
						  Element inputOrderLineAwards = XMLUtil.getChildElement(inputOrderLine, KohlsPOCConstant.E_AWARDS);
						  List<Element> orderLineList = XMLUtil.getElementsByTagName(eleGetOrderDetailsOut, KohlsPOCConstant.E_ORDER_LINE);
						  if (orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
							  for (Element orderLine : orderLineList) {
								  String strPrimeLineNo = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_PRIME_LINE_NO);
								  if(!YFCCommon.isVoid(strInputOrdLinePrimeLineNo) && !YFCCommon.isVoid(strPrimeLineNo) &&
										  strInputOrdLinePrimeLineNo.equalsIgnoreCase(strPrimeLineNo)){
									  List<Element> awardEleList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_AWARD);
									  if (awardEleList.size() > KohlsPOCConstant.ZERO_INT) {
										  for (Element awardEle : awardEleList) {
											  XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.REMOVE);
											  Element eleOrderLineAward = (Element)inDoc.importNode(awardEle, true);
											  inputOrderLineAwards.appendChild(eleOrderLineAward);
										  }
									  }  
								  }
							  }
						  }
					  }
				  }
				  if (logger.isDebugEnabled()){
					  logger.debug("getOrderDetails output after resetting Awards : \n" + XMLUtil.getXMLString(docGetOrderDetailsOut));
					  logger.debug("changeOrder input after resetting Awards : \n" + XMLUtil.getXMLString(inDoc));
				  }
			  }

		  } catch (Exception e) {
			  e.printStackTrace();
			  logger.error(e.getMessage(), "00000",
					  "Error in KohlsPoCBeforeChangeOrderUE.resetAwards");
		  }

	  }

	  logger.endTimer("KohlsPoCBeforeChangeOrderUE.resetAwards");
	  return inDoc;
}

  /**
   * checkifChangeOrderForVoid decides the order is mid void or post void and sets the env object
   * appropriately
   * 
   * @param env
   * @param inDoc
   */
  public Document checkifChangeOrderForVoid(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.checkifChangeOrderForVoid");

    if (logger.isDebugEnabled())
      logger.debug("input inDoc for MidVoid/PostVoid" + XMLUtil.getXMLString(inDoc));

    Element tempOrderEle = inDoc.getDocumentElement();
    if (!YFCCommon.isVoid(tempOrderEle)) {
      String pocFeature = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.POC_FEATURE);
      logger.debug("The PocFeature :" + pocFeature);
      if (pocFeature.equalsIgnoreCase(KohlsPOCConstant.MID_VOID_SCENARIO)) {
    	  inDoc = getOriginalSaleOrder(env,inDoc);
    	  env.setTxnObject(KohlsPOCConstant.IS_MID_VOID_ORDER, KohlsPOCConstant.YES);
      } else if (pocFeature.equalsIgnoreCase(KohlsPOCConstant.POST_VOID_SCENARIO)) {
        env.setTxnObject(KohlsPOCConstant.IS_MID_POST_ORDER, KohlsPOCConstant.YES);
        // Fix for PR-688 - Start
        inDoc = getOriginalSaleOrder(env,inDoc);
        Element elePromotions =
            XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
        if (!YFCCommon.isVoid(elePromotions)) {
          NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
          if (!YFCCommon.isVoid(nlPromotion) && nlPromotion.getLength() > 0) {
            for (int i = 0; i < nlPromotion.getLength(); i++) {
              Element elePromotion = (Element) nlPromotion.item(i);
              String sPromotionType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
              if (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(sPromotionType)) {
                XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_ACTION, "MODIFY");
                XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, "N");
                Element eleExtn = XMLUtil.createChild(elePromotion, KohlsPOCConstant.A_EXTN);
                String sExtnActivationBarCode =
                    elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
                XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_ACTIVATION_BAR_CODE,
                    sExtnActivationBarCode);
                XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.ISPSAPROMOTION, "V");
                if (logger.isDebugEnabled()) {
                  logger.debug("KCS PSA promotions :" + XMLUtil.getElementXMLString(elePromotion));
                }
              }
              if (KohlsPOCConstant.OFFER.equalsIgnoreCase(sPromotionType) && KohlsPoCPnPUtil
                  .isSUPC(elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_ID))) {
                try {
                  KOHLSBaseApi.invokeService(env, "KohlsPSAMarkSUPCUnUsed", inDoc);
                } catch (Exception e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
                }
              }
            }
          }
        }
        // Fix for PR-688 - End
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.checkifChangeOrderForVoid");
	return inDoc;
  }

  /**
   * Loads the hashmap with recyle fee skus. sets the env object appropriately
   * 
   * @param env
   * @param inDoc
   */
  private void loadRecycleFeeSkyHashMap(YFSEnvironment env) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.loadRecycleFeeSkyHashMap");
    try {

      Document docCommonCodeIn = XMLUtil.createDocument(KohlsPOCConstant.E_COMMON_CODE);
      Element eleCommonCodeIn = docCommonCodeIn.getDocumentElement();
      eleCommonCodeIn.setAttribute(KohlsPOCConstant.A_CODE_TYPE, "RECYCLE_FEE_SKUS");
      Document docCommonCodeTemplate = XMLUtil
          .getDocument("<CommonCodeList><CommonCode CodeName='' CodeValue=''/></CommonCodeList>");
      Document docCommonCodeOut =
          invokeAPI(env, docCommonCodeTemplate, "getCommonCodeList", docCommonCodeIn);
      if (!YFCCommon.isVoid(docCommonCodeOut)) {
        NodeList nlCommonCode = docCommonCodeOut.getElementsByTagName("CommonCode");
        if (nlCommonCode.getLength() > 0) {
          for (int j = 0; j < nlCommonCode.getLength(); j++) {
            Element eleCommonCode = (Element) nlCommonCode.item(j);
            String sRecycleFeeSku = eleCommonCode.getAttribute(KohlsPOCConstant.ATTR_CODE_NAME);
            String sCodeValue = eleCommonCode.getAttribute(KohlsPOCConstant.A_CODE_VALUE);
            recycleFeeSkuMap.put(sRecycleFeeSku, sCodeValue);
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new YFSException(e.getMessage());
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.loadRecycleFeeSkyHashMap");
  }

  // PR-919, 767, 851 - Start
  /**
   * In case of Manual or Auto Store close, Order/ExtnIsVoidDuring=Y. In case of PSA Orders,
   * changeOrder input is added with PSA promotions, that needs to be removed, instead of Voiding
   * the complete order.
   * 
   * @param env
   * @param inDoc
   */
  private Document addPSADetailsForStoreCloseMidVoid(YFSEnvironment env, Document inXML) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.addPSADetailsForStoreCloseMidVoid");

    Element eleOrder = inXML.getDocumentElement();
    Element eleExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.A_EXTN);
    Element elePromotions = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
    String strExtnIsVoidDuring =
        XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
    String strExtnPsaStatus = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.EXTN_PSA_STATUS);
    String strPOCFeature = XMLUtil.getAttribute(eleOrder, KohlsPOCConstant.POC_FEATURE);
    if (!YFCCommon.isVoid(strExtnIsVoidDuring)
        && KohlsPOCConstant.YES.equalsIgnoreCase(strExtnIsVoidDuring)
        && YFCCommon.isVoid(elePromotions) && YFCCommon.isVoid(strExtnPsaStatus)
        && YFCCommon.isVoid(strPOCFeature)) {
      Document docGetOrderDetailsOut = getOrderDetailsForPSAMidVoid(env, eleOrder,
          KohlsPOCConstant.GetOrderDetailsTemplateForPSAMidVoid);
      if (!YFCCommon.isVoid(docGetOrderDetailsOut)) {
        Element eleNewOrder = docGetOrderDetailsOut.getDocumentElement();
        Element eleNewOrderExtn = XMLUtil.getChildElement(eleNewOrder, KohlsPOCConstant.E_EXTN);
        String strNewExtnPSAStatus =
            XMLUtil.getAttribute(eleNewOrderExtn, KohlsPOCConstant.EXTN_PSA_STATUS);
        String strMaxOrderStatus =
            XMLUtil.getAttribute(eleNewOrder, KohlsPOCConstant.MAX_ORDER_STATUS);
        if (strMaxOrderStatus.equalsIgnoreCase(KohlsPOCConstant.STORE_ORDER_INVOICED_STATUS)
            && (strNewExtnPSAStatus.equalsIgnoreCase(KohlsPOCConstant.EXTN_PSA_IN_PROGRESS)
                || strNewExtnPSAStatus.equalsIgnoreCase(KohlsPOCConstant.EXTN_PSA_STARTED))) {
          String strNewOrganizationCode =
              XMLUtil.getAttribute(eleNewOrder, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
          XMLUtil.setAttribute(eleNewOrder, KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.YES);
          XMLUtil.setAttribute(eleNewOrder, KohlsPOCConstant.POC_FEATURE,
              KohlsPOCConstant.MID_VOID_SCENARIO);
          XMLUtil.setAttribute(eleNewOrder, KohlsPOCConstant.A_ORGANIZATION_CODE,
              strNewOrganizationCode);
          XMLUtil.setAttribute(eleNewOrderExtn, KohlsPOCConstant.EXTN_PSA_STATUS, "VOIDED");
          // Setting PSA Sytem Void Indicator in Order/CustomAttributes
          Element eleNewOrderCustomAttributes =
              XMLUtil.createChild(eleNewOrder, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
          XMLUtil.setAttribute(eleNewOrderCustomAttributes, "Text20",
              "System Initiated PSA MidVoid");
          // Removing Unwanted attributes for further process
          XMLUtil.removeAttribute(eleNewOrder, KohlsPOCConstant.MAX_ORDER_STATUS);
          XMLUtil.removeAttribute(eleNewOrder, KohlsPOCConstant.A_STATUS);
          XMLUtil.removeAttribute(eleNewOrderExtn, KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
          // Removing PSA Promotions for MidVoid - Start
          Element eleNewOrderPromotions =
              XMLUtil.getChildElement(eleNewOrder, KohlsPOCConstant.E_PROMOTIONS);
          if (!YFCCommon.isVoid(eleNewOrderPromotions)) {
            NodeList nlNewPromotion =
                eleNewOrderPromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
            if (!YFCCommon.isVoid(nlNewPromotion) && nlNewPromotion.getLength() > 0) {
              for (int i = 0; i < nlNewPromotion.getLength(); i++) {
                Element eleNewPromotion = (Element) nlNewPromotion.item(i);
                Element eleNewPromotionExtn =
                    XMLUtil.getChildElement(eleNewPromotion, KohlsPOCConstant.E_EXTN);
                String strExtnIsPsaPromotion =
                    XMLUtil.getAttribute(eleNewPromotionExtn, KohlsPOCConstant.ISPSAPROMOTION);
                if (KohlsPOCConstant.YES.equalsIgnoreCase(strExtnIsPsaPromotion)) {
                  XMLUtil.setAttribute(eleNewPromotion, KohlsPOCConstant.A_ACTION,
                      KohlsPOCConstant.REMOVE);
                } else {
                  eleNewOrderPromotions.removeChild(eleNewPromotion);
                  i--;
                }
              }
              if (logger.isDebugEnabled())
                logger.debug("PSA MidVoid output xml is modified: \n"
                    + XMLUtil.getXMLString(docGetOrderDetailsOut));
              return docGetOrderDetailsOut;
            }
          }
          // Removing PSA Promotions for MidVid - End

        }
      }

    }
    if (logger.isDebugEnabled())
      logger.debug("ChangeOrder Input xml is not modified: \n" + XMLUtil.getXMLString(inXML));
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.addPSADetailsForStoreCloseMidVoid");
    return inXML;
  }

  /**
   * Calls GetOrderDetails with below template -
   * <Order EnterpriseCode='' OrderHeaderKey='' OrderNo='' MaxOrderStatus='' SellerOrganizationCode=
   * '' Override='' POCFeature='' POSSequenceNumber='' PosSequenceNo='' Status=''> <Extn
   * ExtnPsaStatus='' ExtnRequestDateTime=''/> <Promotions> <Promotion Description=''
   * PromotionApplied='' PromotionGroup='' PromotionId='' PromotionType=''> <Extn ExtnIsPsaPromotion
   * =''/> </Promotion> </Promotions> </Order> sets the env object appropriately
   * 
   * @param env
   * @param inDoc
   */
  private Document getOrderDetailsForPSAMidVoid(YFSEnvironment env, Element eleOrder,
      String outputTemplate) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.getOrderDetailsForPSAMidVoid");

    String sOrderHeaderKey = eleOrder.getAttribute("OrderHeaderKey");
    String sOrderNo = eleOrder.getAttribute("OrderNo");
    String sEnterpriseCode = eleOrder.getAttribute("EnterpriseCode");
    Document docGetOrderDetailsOut = null;
    try {
      Document docGetOrderDetailsIn = XMLUtil.createDocument("Order");
      docGetOrderDetailsIn.getDocumentElement().setAttribute("OrderHeaderKey", sOrderHeaderKey);
      docGetOrderDetailsIn.getDocumentElement().setAttribute("OrderNo", sOrderNo);
      docGetOrderDetailsIn.getDocumentElement().setAttribute("EnterpriseCode", sEnterpriseCode);

      if (logger.isDebugEnabled())
        logger.debug("Invoking getOrderDetails API with input xml: \n"
            + XMLUtil.getXMLString(docGetOrderDetailsIn));
      if (!YFCCommon.isVoid(sOrderHeaderKey)) {
        docGetOrderDetailsOut = invokeAPI(env, XMLUtil.getDocument(outputTemplate),
            "getOrderDetails", docGetOrderDetailsIn);
      }
      if (logger.isDebugEnabled())
        logger.debug("getOrderDetails For PSA MidVoid output xml: \n"
            + XMLUtil.getXMLString(docGetOrderDetailsOut));
    } catch (Exception e) {
      e.printStackTrace();
      throw new YFSException(e.getMessage(), "00000",
          "Error in KohlsPoCBeforeChangeOrderUE.beforeChangeOrder");
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.getOrderDetailsForPSAMidVoid");
    return docGetOrderDetailsOut;
  }

  // PR-919, 767, 851 - End
  // PR-990 - Begin
  /**
   * @param env
   * @param inDoc
   */
  public Document validateIfEmpDiscCodeExists(YFSEnvironment env, Document inDoc) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.validateMissingEmpDiscCode for Even Exchange");
    Element eleEEOrder = inDoc.getDocumentElement();
    if (!YFCCommon.isVoid(eleEEOrder)) {
      String sDocType = eleEEOrder.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
      if (!YFCCommon.isVoid(sDocType)) {
        if ((KohlsPOCConstant.SO_DOCUMENT_TYPE).equalsIgnoreCase(sDocType)
            || (KohlsPOCConstant.RO_DOCUMENT_TYPE).equalsIgnoreCase(sDocType)) {
          NodeList orderLineList =
              eleEEOrder.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
          if (!YFCCommon.isVoid(orderLineList)) {
            int iOrderLines = orderLineList.getLength();
            if (iOrderLines > 0) {
              for (int k = 0; k < iOrderLines; k++) {
                Element eOrderLine = (Element) orderLineList.item(k);
                if (!YFCCommon.isVoid(eOrderLine)) {
                  Element eleCustAttributes =
                      XMLUtil.getChildElement(eOrderLine, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
                  //PST-3114 Changes start
                  Element eleItem =
                          XMLUtil.getChildElement(eOrderLine, KohlsPOCConstant.E_ITEM);
                  //PST-3114 changes end
                  if (!YFCCommon.isVoid(eleCustAttributes)) {
                    String sText4 = eleCustAttributes.getAttribute(KohlsPOCConstant.A_TEXT4);
                    if ((KohlsPOCConstant.EE_ORDERLINE).equalsIgnoreCase(sText4)) {
                      String sAction = eOrderLine.getAttribute(KohlsPOCConstant.A_ACTION);
                      if (logger.isDebugEnabled()) {
                        logger.debug("Orderline Action is: " + sAction);
                      }
                      if ((KohlsPOCConstant.A_CREATE).equalsIgnoreCase(sAction)) {
                        NodeList nlReferences =
                            eOrderLine.getElementsByTagName(KohlsPOCConstant.Reference);
                        if (!YFCCommon.isVoid(nlReferences)) {
                          boolean isEmpCode = false;
                          int iReferences = nlReferences.getLength();
                          if (iReferences > 0) {
                            for (int j = 0; j < iReferences; j++) {
                              Element eleReference = (Element) nlReferences.item(j);
                              if (logger.isDebugEnabled()) {
                                logger.debug("eleReference is: "
                                    + XMLUtil.getElementXMLString(eleReference));
                              }
                              String sName = eleReference.getAttribute(KohlsPOCConstant.A_NAME);
                              if ((KohlsPOCConstant.EMP_DISC_CODE).equalsIgnoreCase(sName)) {
                                isEmpCode = true;
                                if (logger.isDebugEnabled()) {
                                  logger.debug("ExtnEmpDiscCode exists - Value of isEmpCode is: "
                                      + isEmpCode);
                                }
                              }
                            }
                            // call getItemList API
                            // to get missing
                            // attributes
                            if (logger.isDebugEnabled()) {
                              logger.debug("Value of isEmpCode outside of for loop " + isEmpCode);
                            }
                            if (!isEmpCode) {
                              if (logger.isDebugEnabled()) {
                                logger
                                    .debug("Call getItemList API to get ExtnEmpDiscCode atribute");
                              }
                              //PST-3114 changes adding loop and reading values from eleItem
                              if(!YFCCommon.isVoid(eleItem)){
	                              String sItemid = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
	                              String sUOM =
	                            		  eleItem.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE);
	                              String sOrg =
	                                  eOrderLine.getAttribute(KohlsPOCConstant.ATTR_ENTERPRISE_CODE);
	                              try {
	                                Document docItemListIn =
	                                    XMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);
	                                docItemListIn.getDocumentElement()
	                                    .setAttribute(KohlsPOCConstant.A_ITEM_ID, sItemid);
	                                docItemListIn.getDocumentElement()
	                                    .setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, sUOM);
	                                docItemListIn.getDocumentElement().setAttribute(
	                                    KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, sOrg);
	                                docItemListIn.getDocumentElement().setAttribute(
	                                    KohlsPOCConstant.A_MAXIMUM_RECORDS,
	                                    KohlsPOCConstant.V_MAXIMUM_RECORDS);
	
	                                String sGetItemListTemplate =
	                                    KohlsPOCConstant.GetItemListAPITemplateForEE;
	                                if (logger.isDebugEnabled()) {
	                                  logger.debug("Invoking getItemList API with input xml: \n"
	                                      + XMLUtil.getXMLString(docItemListIn));
	                                }
	                                Document docGetItemListOut =
	                                    invokeAPI(env, XMLUtil.getDocument(sGetItemListTemplate),
	                                        KohlsPOCConstant.API_GET_ITEM_LIST, docItemListIn);
	                                if (!YFCCommon.isVoid(docGetItemListOut)) {
	                                  Element eleItemExtn =
	                                      (Element) XPathUtil.getNode(docGetItemListOut,
	                                          KohlsPOCConstant.XPATH_ITEMLIST_EXTN);
	                                  String sEmpDiscCode =
	                                      eleItemExtn.getAttribute(KohlsPOCConstant.EMP_DISC_CODE);
	                                  if (logger.isDebugEnabled()) {
	                                    logger.debug("Output of getItemList is: "
	                                        + XMLUtil.getXMLString(docGetItemListOut));
	                                  }
	
	                                  if (!YFCCommon.isStringVoid(sEmpDiscCode)) {
	                                    Element eleReferenceList = XMLUtil.getChildElement(eOrderLine,
	                                        KohlsPOCConstant.A_REFERENCES);
	                                    Element eleNewReference =
	                                        inDoc.createElement(KohlsPOCConstant.Reference);
	                                    eleNewReference.setAttribute(KohlsPOCConstant.A_NAME,
	                                        KohlsPOCConstant.EMP_DISC_CODE);
	                                    eleNewReference.setAttribute(KohlsPOCConstant.A_VALUE,
	                                        sEmpDiscCode);
	                                    if (logger.isDebugEnabled()) {
	                                      logger.debug("New reference element is:"
	                                          + XMLUtil.getElementXMLString(eleNewReference));
	                                    }
	                                    eleReferenceList.appendChild(eleNewReference);
	                                  }
	                                }
	
	                              } catch (Exception e) {
	                                logger.debug(
	                                    "Error while calling getItemList API in KohlsPoCBeforeChangeOrderUE for EE");
	                                e.printStackTrace();
	                              }
	
	                            }
                            }

                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.validateMissingEmpDiscCode");
    return inDoc;
  }

  // PR-990 - End
  /**
   * This method checks if the item returned is Exlcusion item or not
   * 
   * @param env
   * @param eleOrderLine
   */
  private void checkForExclusionItem(YFSEnvironment env, Element eleOrderLine) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.checkForExclusionItem");
    // Logic for checking if item returned is exclusion or not
    boolean hasExclusionsBeenModified = false;
    Date activeDate = null;
    try {
      hasExclusionsBeenModified = KohlsPoCCommonAPIUtil.hasExclusionsBeenModified(env);
    } catch (Exception e1) {
      e1.printStackTrace();
    }
    if (KohlsPoCCommonAPIUtil.exclusionsMap.isEmpty() || hasExclusionsBeenModified) {
      try {
        KohlsPoCCommonAPIUtil.buildExclusionsMap(env);
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    Element orderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_EXTN);
    String extnClass = orderLineExtn.getAttribute("ExtnItemClass");
    String extnSubClass = orderLineExtn.getAttribute("ExtnItemSubClass");
    String extnDept = orderLineExtn.getAttribute("ExtnItemDept");
    try {
      if (KohlsPoCCommonAPIUtil.exclusionsMap.containsKey(extnDept)) {
        activeDate = sdf.parse(KohlsPoCCommonAPIUtil.exclusionsMap.get(extnDept));
      } else if (KohlsPoCCommonAPIUtil.exclusionsMap.containsKey(extnDept + "-" + extnClass)) {
        activeDate = sdf.parse(KohlsPoCCommonAPIUtil.exclusionsMap.get(extnDept + "-" + extnClass));
      } else if (KohlsPoCCommonAPIUtil.exclusionsMap
          .containsKey(extnDept + "-" + extnClass + "-" + extnSubClass)) {
        activeDate = sdf.parse(KohlsPoCCommonAPIUtil.exclusionsMap
            .get(extnDept + "-" + extnClass + "-" + extnSubClass));
      }
      if (!YFCCommon.isVoid(activeDate) && YFCDateUtils.getCurrentDate(false).after(activeDate)) {
        orderLineExtn.setAttribute("ExtnIsExclusionItem", "Y");
        Element eleAwards = (Element) orderLineExtn.getElementsByTagName("Awards").item(0);
        if (!YFCCommon.isVoid(eleAwards)) {
          orderLineExtn.removeChild(eleAwards);
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.checkForExclusionItem");
  }

  /**
   * This method identifies whether or not its change Order to add SKU_VOID_TRAN_ZERO_ITEM and if
   * yes, then adds original sale transaction info at OrderLine/CustomAttributes
   * 
   * @param env
   * @param inXML
   * @throws Exception
   */
  private void handleVoidDuringWithoutItem(YFSEnvironment env, Document inXML) throws Exception {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.handleVoidDuringWithoutItem");
    NodeList nlOrderLine = inXML.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE);
    if (nlOrderLine.getLength() == 1) {
      Element eleItem = (Element) ((Element) nlOrderLine.item(0))
          .getElementsByTagName(KohlsPOCConstant.E_ITEM).item(0);
      if (!YFCCommon.isVoid(eleItem)) {
        String sItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
        if (sItemID.equalsIgnoreCase(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM)) {
          logger.debug(
              "This is the case of Void During without item. Copying the OTR information onto the order line");
          Document docGetOrderDetailsTemplate = XMLUtil.getDocument(
              "<Order OrderHeaderKey='' OrderNo=''><References><Reference Name='' Value=''/></References></Order>");
          Document docGetOrderDetailsOut = invokeAPI(env, docGetOrderDetailsTemplate,
              KohlsPOCConstant.API_GET_ORDER_DETAILS, inXML);
          if (!YFCCommon.isVoid(docGetOrderDetailsOut)) {
            NodeList nlReference =
                docGetOrderDetailsOut.getElementsByTagName(KohlsPOCConstant.Reference);
            if (!YFCCommon.isVoid(nlReference)) {
              String sOTRDetails = "";
              for (int i = 0; i < nlReference.getLength(); i++) {
                Element eleReference = (Element) nlReference.item(i);
                String sName = eleReference.getAttribute(KohlsPOCConstant.A_NAME);
                if (sName.contains("OTR")) {
                  sOTRDetails = sName;
                  logger.debug("Found the OTR Details. Breaking the loop.: " + sOTRDetails);
                  break;
                }
              }
              if (!YFCCommon.isVoid(sOTRDetails)) {
                String temp[] = sOTRDetails.split("-");
                if (temp.length > 7) {
                  String sOrigStore = temp[2];
                  String sOrigTerminalId = temp[3];
                  String sOrigTranNo = temp[4];
                  String sOrigTranDate = temp[5] + "-" + temp[6] + "-" + temp[7];
                  Element eleOrderLine = (Element) nlOrderLine.item(0);
                  Element eleCustomAttributes =
                      inXML.createElement(KohlsPOCConstant.CUST_ATTRIBUTES);
                  eleOrderLine.appendChild(eleCustomAttributes);
                  eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT7, sOrigStore);
                  eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT8, sOrigTerminalId);
                  eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT9, sOrigTranNo);
                  eleCustomAttributes.setAttribute(KohlsPOCConstant.TEXT10, "1");
                  eleCustomAttributes.setAttribute(KohlsPOCConstant.DATE2, sOrigTranDate);
                }
              }
            }
          }
        }
      } else {
        logger.debug("XML does not contain Void During with out sku item.");
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.handleVoidDuringWithoutItem");
  }

  /**
   * Create By mrjoshi * this method removes the unapplied awards from the input and also creates
   * the "Price" award if does not exist
   * 
   * @param eleOrderLine
   * @throws Exception
   */
  public void manageAwards(Element eleOrderLine) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.manageAwards");
    Element eleAwards =
        (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_AWARDS).item(0);
    NodeList nlAward = eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD);
    if (!YFCCommon.isVoid(nlAward) && nlAward.getLength() > 0) {
      int iAwardSeq = 0;
      boolean bPriceAwardCreated = false;
      Element elePriceAward = null;
      Element eleNewPriceAward = null;
      try {
        elePriceAward =
            (Element) ((NodeList) XPathUtil.getNodeList(eleAwards, "//Award[@Description='Price']"))
                .item(0);
      } catch (Exception e) {
        e.printStackTrace();
        throw new YFSException(e.getMessage());
      }
      // For POC order, "Price" award does not exist. So creating one.
      if (YFCCommon.isVoid(elePriceAward)) {
        eleNewPriceAward = eleAwards.getOwnerDocument().createElement(KohlsPOCConstant.E_AWARD);
        Element eleLinePriceInfo =
            (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
        String sUnitPrice = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_AWARD_AMOUNT, "-" + sUnitPrice);
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_DESCRIPTION, KohlsPOCConstant.CONST_PRICE);
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,
            KohlsPOCConstant.NO);
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER_LINE,
            KohlsPOCConstant.NO);
        eleNewPriceAward.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, "");
        Element eleExtn =
            eleNewPriceAward.getOwnerDocument().createElement(KohlsPOCConstant.E_EXTN);
        eleNewPriceAward.appendChild(eleExtn);
        // eleExtn.setAttribute(KohlsPOCConstant.EXTN_AWARD_RECEIPT_DESC,
        // KohlsPOCConstant.CONST_PRICE.toUpperCase());
        eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, KohlsPOCConstant.STRING_ONE);
        eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_DELTA, "-" + sUnitPrice);
        eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETRN_DELTA, "-" + sUnitPrice);
        iAwardSeq = iAwardSeq + 1;
        bPriceAwardCreated = true;

        for (int i = 0; i < nlAward.getLength(); i++) {
          Element eleAward = (Element) nlAward.item(i);
          Double dAwardAmount = 0.00;
          String sDescription = eleAward.getAttribute(KohlsPOCConstant.A_DESCRIPTION);
          if(eleAward.getAttribute("PromotionId").contains("FEE")){
        	  continue;
          }
          if (!"price".equalsIgnoreCase(sDescription)) {
            String sAwardAmount = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT);
            if (!YFCCommon.isVoid(sAwardAmount)) {
              dAwardAmount = Double.parseDouble(sAwardAmount);
            }
            eleAward.setAttribute(KohlsPOCConstant.A_AWARD_AMOUNT,
                new DecimalFormat("#0.00").format(Math.abs(dAwardAmount)));
          }
          String sAwardApplied = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_APPLIED);
          if (!YFCCommon.isVoid(sAwardApplied)
              && sAwardApplied.equalsIgnoreCase(KohlsPOCConstant.NO)) {
            eleAwards.removeChild(eleAward);
            continue;
          }
          // When Price award is created, then update the award sequence for other awards.
          // Update for CAPE 1087 - begin
          if (bPriceAwardCreated && !sDescription.equalsIgnoreCase(KohlsPOCConstant.CONST_PRICE)
              && eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_AWARD).getLength() > 0) {
            // Update for CAPE 1087 - end
            iAwardSeq++;
            Element eleAwardExtn =
                (Element) eleAward.getElementsByTagName(KohlsPOCConstant.E_EXTN).item(0);
            eleAwardExtn.setAttribute(KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE,
                Integer.toString(iAwardSeq));
          }
        }
        if (nlAward.getLength() > 0 && bPriceAwardCreated) {
          eleAwards.appendChild(eleNewPriceAward);
        }
      } else {
        for (int i = 0; i < nlAward.getLength(); i++) {
          Element eleAward = (Element) nlAward.item(i);
          Double dAwardAmount = 0.00;
          String sDescription = eleAward.getAttribute(KohlsPOCConstant.A_DESCRIPTION);
          // if (!"price".equalsIgnoreCase(sDescription)) {
          String sAwardAmount = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_AMOUNT);
          if (!YFCCommon.isVoid(sAwardAmount)) {
            dAwardAmount = Double.parseDouble(sAwardAmount);
          }
          if (dAwardAmount > 0) {
            eleAward.setAttribute(KohlsPOCConstant.A_AWARD_AMOUNT, "-" + sAwardAmount);
          } else {
            if(!sDescription.contains(KohlsPOCConstant.SMALL_ATTR_FEE)){
            	eleAward.setAttribute(KohlsPOCConstant.A_AWARD_AMOUNT,
                new DecimalFormat("#0.00").format(Math.abs(dAwardAmount)));
            }
          }
          // }
          String sAwardApplied = eleAward.getAttribute(KohlsPOCConstant.A_AWARD_APPLIED);
          if (!YFCCommon.isVoid(sAwardApplied)
              && sAwardApplied.equalsIgnoreCase(KohlsPOCConstant.NO)) {
            eleAwards.removeChild(eleAward);
            continue;
          }
        }
      }
    }
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.manageAwards");
  }

  /* Added for Tax Calculation for ECommOrders - START */
  /**
   * This method calculates the tax for ECommOrders
   * 
   * @param eleOrderLine
   * 
   */
  private void calculateTaxForECom(Element eleOrderLine, boolean bIsEComStore) {
    logger.beginTimer("KohlsPoCBeforeChangeOrderUE.calculateTaxForECom");
    double dUnitPrice = KohlsPOCConstant.ZERO_DBL;
    double dTaxAmt = KohlsPOCConstant.ZERO_DBL;
    double dTaxPercent = KohlsPOCConstant.ZERO_DBL;
    DecimalFormat df = new DecimalFormat("#0.00");
    Element eleLinePriceInfo =
        (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
    if (!YFCCommon.isVoid(eleLinePriceInfo)) {
      String sUnitPrice = XMLUtil.getAttribute(eleLinePriceInfo, KohlsPOCConstant.A_UNIT_PRICE);
      if (!YFCCommon.isVoid(sUnitPrice)) {
        dUnitPrice = Double.parseDouble(sUnitPrice);

        Element eleLineCharges =
            (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGES).item(0);

        NodeList nlLineCharge =
            eleLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);

        if (nlLineCharge.getLength() > 0) {
          for (int l = 0; l < nlLineCharge.getLength(); l++) {
            Element eleLineCharge = (Element) nlLineCharge.item(l);
            String sChargeCategory = eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_CATEGORY);

            if (KohlsPOCConstant.KOHLS_CASH_DISCOUNT.equals(sChargeCategory)) {
              String sChargePerLine =
                  eleLineCharge.getAttribute(KohlsXMLLiterals.A_CHARGE_PER_LINE);
              dUnitPrice = dUnitPrice - Double.parseDouble(sChargePerLine);
            }
          }
        }

        // Setting Extn Attributes for OrderLine:
        Element eleOrderLineExtn =
            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN, true);
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT,
            df.format(dUnitPrice));
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, df.format(dUnitPrice));
        eleOrderLineExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE, df.format(dUnitPrice));

        /*
         * String sTaxpercent = XMLUtil.getAttribute(eleLinePriceInfo,
         * KohlsPOCConstant.ATTR_TAX_PERCENT); if (!YFCCommon.isVoid(sUnitPrice) &&
         * !YFCCommon.isVoid(sTaxpercent)) { // dUnitPrice = Double.parseDouble(sUnitPrice);
         * dTaxPercent = Double.parseDouble(sTaxpercent); dTaxAmt = (dUnitPrice / 100) *
         * dTaxPercent; }
         */
      }
    }

    /*
     * if (bIsEComStore && (dTaxAmt > 0 || dTaxPercent==0)) { Element lineTaxesEle =
     * XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES); Element eleLineTax =
     * null; if (!YFCCommon.isVoid(lineTaxesEle)) {
     * 
     * eleLineTax = XMLUtil.createChild(lineTaxesEle, KohlsPOCConstant.ELEM_LINE_TAX);
     * 
     * } else { Element eleLineTaxes = XMLUtil.createChild(eleOrderLine,
     * KohlsPOCConstant.ELEM_LINE_TAXES); eleLineTax = XMLUtil.createChild(eleLineTaxes,
     * KohlsPOCConstant.ELEM_LINE_TAX); }
     * eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
     * eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
     * eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
     * eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, df.format(dTaxPercent));
     * eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, df.format(dTaxAmt));
     * eleLinePriceInfo.setAttribute(KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.YES); }
     */
    logger.endTimer("KohlsPoCBeforeChangeOrderUE.calculateTaxForECom");
  }
  /* Added for Tax Calculation for ECommOrders - END */

  private Document getOriginalSaleOrder(YFSEnvironment env, Document docInputXml)   {
	  logger.beginTimer("KohlsPoCBeforeChangeOrderUE.getOriginalSaleOrder");
	  Document docOutOrderDetails = null;
	  Document docCompleteInputXml = null;
	  if (!YFCCommon.isVoid(docInputXml)) {
		  Element eleOrder = docInputXml.getDocumentElement();
		  String strOriginalOHK = eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
		  String strPOSSequenceNumber = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER);
		  String strPosSequenceNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
		  Element eleOrderExtn = (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
		  Element eleOrderCustomAttr = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
		  String sPSAStatus = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
		  String sPSADateTime = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_REQUEST_DATE_TIME);
		  String sText19="", sText12="", sText14="";
		  if(!YFCCommon.isVoid(eleOrderCustomAttr)){
		   	sText19 = eleOrderCustomAttr.getAttribute("Text19");
		   	sText12 = eleOrderCustomAttr.getAttribute("Text12");
		   	sText14 = eleOrderCustomAttr.getAttribute("Text14");
		  }
		  Document docInputGetOrginalOrder;
		try {
			docInputGetOrginalOrder = XMLUtil.getDocument("<KOHLSSalesForPsa OrderHeaderKey='" + strOriginalOHK + "'/>");
			docOutOrderDetails =
					  KOHLSBaseApi.invokeService(env, "GetKohlsSalesDetails", docInputGetOrginalOrder);
			  logger.endTimer("KohlsPoCBeforeChangeOrderUE.getOriginalSaleOrder");
			  String sOrder = docOutOrderDetails.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORIG_SALE_DATA);
			  docOutOrderDetails =  XMLUtil.getDocument(sOrder);
			  Element eleOverallTotals = XMLUtil.getChildElement(docOutOrderDetails.getDocumentElement(),KohlsPOCConstant.ELE_OVERALLTOTALS);
			  //reusing PA logic for PSA
			  KohlsPoCPAVoid paVoid = new KohlsPoCPAVoid();
			  
			  docCompleteInputXml = paVoid.getPAOrderDeatils(env,docInputXml);
			  docCompleteInputXml = paVoid.updatePAOrderDetailsAfterVoid(env, docOutOrderDetails, docCompleteInputXml);
			  Element eleCompleteInputXmlOrder = docCompleteInputXml.getDocumentElement();
			  Element eleInPromotions = XMLUtil.getChildElement(eleCompleteInputXmlOrder, KohlsPOCConstant.E_PROMOTIONS);
			  if(YFCCommon.isVoid(eleInPromotions)){
				  eleInPromotions = XMLUtil.createChild(eleCompleteInputXmlOrder, KohlsPOCConstant.E_PROMOTIONS);
			  }
			  Element elePromotions = XMLUtil.getChildElement(docInputXml.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS);
			  NodeList nlPromotion = (NodeList)elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
			  for(int i=0;i<nlPromotion.getLength();i++){

				  Element elePromotion = XMLUtil.importElement(eleInPromotions, (Element)nlPromotion.item(i));
				  eleInPromotions.appendChild(elePromotion);
			  }
			  
			  Element eleExtn = XMLUtil.getChildElement(eleCompleteInputXmlOrder,KohlsPOCConstant.E_EXTN);
			  Element eleCustAttribs = XMLUtil.getChildElement(eleCompleteInputXmlOrder,KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
			  if(YFCCommon.isVoid(eleCustAttribs)){
				  eleCustAttribs = XMLUtil.createChild(eleCompleteInputXmlOrder, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
			  }
			  eleExtn.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS,sPSAStatus);
			  eleExtn.setAttribute(KohlsPOCConstant.EXTN_REQUEST_DATE_TIME,sPSADateTime);
			  eleCustAttribs.setAttribute("Text19", sText19);
			  eleCustAttribs.setAttribute("Text14", sText14);
			  eleCompleteInputXmlOrder.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER,strPOSSequenceNumber);
			  eleCompleteInputXmlOrder.setAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO,strPosSequenceNo);
			  eleCompleteInputXmlOrder.setAttribute(KohlsPOCConstant.A_Select_Method,KohlsPOCConstant.SELECT_METHOD_WAIT);
			  env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.TRUE);
			  env.setTxnObject(KohlsPOCConstant.EXTN_POC_FEATURE,KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT);
			  Element eleTotals = XMLUtil.importElement( eleCompleteInputXmlOrder,eleOverallTotals);
			  eleCompleteInputXmlOrder.appendChild(eleTotals);
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Error while getting orginal XML --->"  + e.getMessage());
		}
	  }


	  logger.endTimer("KohlsPoCBeforeChangeOrderUE.getOriginalSaleOrder");
	  return docCompleteInputXml;
  }
  private void setRequestProcess(Element eleOrder)
  {
        logger.beginTimer("KohlsPoCBeforeChangeOrderUE.setRequestProcess");
        NodeList ndlPaymentMethod = eleOrder.getElementsByTagName( KohlsPOCConstant.E_PAYMENT_METHOD );
        for ( int i = 0; i < ndlPaymentMethod.getLength(); i++ )
        {
           Element elePaymentMethod = (Element) ndlPaymentMethod.item( i );
           NodeList ndlPaymentDetails = elePaymentMethod.getElementsByTagName( KohlsPOCConstant.ATTR_PAYMENT_DETAILS );
           for ( int j = 0; j < ndlPaymentDetails.getLength(); j++ )
           {

              logger.debug( "KohlsPoCBeforeChangeOrderUE.setRequestProcess -->Setting the attribute" );
              Element elePaymentDetails = (Element) ndlPaymentDetails.item( j );
              elePaymentDetails.setAttribute( KohlsPOCConstant.ATTR_REQ_PROCESSED, "Y" );
           }

        }
     
        logger.endTimer("KohlsPoCBeforeChangeOrderUE.setRequestProcess");
  }
 
}
