package com.kohls.poc.pricing.ue;

import com.kohls.common.util.*;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang.math.NumberUtils;

/**
 * This class sets the attributes required for PICK Lines for OMNIBag. This class has four invocation points one on
 * BeforeCreateOrderUE, on BeforeChangeOrderUE, ON_SUCCESS of DRAFT_ORDER_CONFIRMATION and on Load_OFFLINE_TRANSACTION Event.
 * During the invocation from BeforeChangeOrderUE and BeforeCreateOrderUE, setBipassAttributes method is invoked.  During
 * the invocation from DRAFT_ORDER_CONFIRMATION and on Load_OFFLINE_TRANSACTION, setKohlsCashAndBOGOAttributes is invoked.
 */

public class KohlsPoCSetAttributesForBipass extends KOHLSBaseApi {

    private static YFCLogCategory logger;
    static {
        logger = YFCLogCategory.instance(KohlsPoCSetAttributesForBipass.class.getName());
    }

    /**
     * This method stamps the order mapping attributes for PICK lines in OMNIBag.
     * @param env
     * @param inDoc
     */

    public Document setBipassAttributes (YFSEnvironment env, Document inDoc) throws YFSException {

        /* Initialize the variables */
        Element eleOrder = null;
        Element eleOrderLines = null;
        Element eleOrderLine = null;
        NodeList nlOrderLines = null;
        int iOrderLineLen = 0;

        if(logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPoCSetAttributesForBipass.setBipassAttributes : \n"
                    + XMLUtil.getXMLString(inDoc));
        }
        try {
            /* Get the Order/@EntryType */
            eleOrder = inDoc.getDocumentElement();

            if(!YFCCommon.isVoid(eleOrder))
                eleOrderLines = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);

            if(!YFCCommon.isVoid(eleOrderLines))
                nlOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);


            if(!YFCCommon.isVoid(nlOrderLines)) {
                iOrderLineLen = nlOrderLines.getLength();
            }

            for(int i=0; i<iOrderLineLen; i++) {
                eleOrderLine = (Element) nlOrderLines.item(i);

                /* Stamp Order Mapping Attributes for PICK Lines */
                if (KohlsConstant.ACTION_CREATE.equals(eleOrderLine.getAttribute(KohlsConstant.A_ACTION))) {
                    updateBipaasLineDetails(env, eleOrderLine);
                }
            }
        } catch (Exception e) {
            throw new YFSException(e.getMessage());
        }

        if(logger.isDebugEnabled()) {
            logger.debug("The output XML to KohlsPoCSetAttributesForBipass.setBipassAttributes : \n"
                    + XMLUtil.getXMLString(inDoc));
        }

        return inDoc;
    }

    /**
     * This method stamps the order mapping attributes for PICK lines in OMNIBag.
     * @param env
     * @param eleOrderLine
     */
    void updateBipaasLineDetails(YFSEnvironment env, Element eleOrderLine) throws Exception {


        /* Initialize Variable */
        Element extnOrderLine = null;
        Element eleItem = null;
        String strShipNode = null;

        /* Stamp Order\OrderLines\OrderLine\@FulfillmentType as 'STORE_PICKUP' for BIPAAS Lines */
        if (XMLUtil.isVoid(eleOrderLine.getAttribute(KohlsXMLLiterals.A_FULFILLMENT_TYPE))) {
            eleOrderLine.setAttribute(KohlsXMLLiterals.A_FULFILLMENT_TYPE, KohlsConstant.STORE_PICKUP);
        }

        /* Stamp Order\OrderLines\OrderLine\Extn\@ExtnOCF as BPS for BIPAAS Lines */
        extnOrderLine = XMLUtil.getChildElement(eleOrderLine, KohlsConstant.E_EXTN);

        if (!XMLUtil.isVoid(extnOrderLine)) {
            extnOrderLine.setAttribute(KohlsXMLLiterals.A_EXTN_OCF, KohlsConstant.BPS);
        } else {
            extnOrderLine = SCXmlUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_EXTN);
            extnOrderLine.setAttribute(KohlsXMLLiterals.A_EXTN_OCF, KohlsConstant.BPS);
        }

        /* Stamp Order\OrderLines\OrderLine\Item\@ItemProductClass as 'Good' for BIPAAS lines */
        eleItem = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_ITEM);

        if(!XMLUtil.isVoid(eleItem) && XMLUtil.isVoid(XMLUtil.getAttribute(eleItem,
                KohlsPOCConstant.A_ITEM_PRODUCT_CLASS))) {
            eleItem.setAttribute(KohlsPOCConstant.A_ITEM_PRODUCT_CLASS, KohlsConstant.PRODUCT_CLASS_GOOD);
        }

        if(!XMLUtil.isVoid(eleItem) && XMLUtil.isVoid(XMLUtil.getAttribute(eleItem,
                KohlsPOCConstant.A_PRODUCT_CLASS))) {
            eleItem.setAttribute(KohlsPOCConstant.A_PRODUCT_CLASS, KohlsConstant.PRODUCT_CLASS_GOOD);
        }

        /* Stamp Order/OrderLines/OrderLine/@PackListType and
        Order/OrderLines/OrderLine/Extn/@ExtnIsHazardous for normal order */
        String strIsHazard = extnOrderLine.getAttribute(KohlsXMLLiterals.A_EXTN_IS_HAZARDOUS);
        if(YFCCommon.isVoid(strIsHazard)) {
            eleOrderLine =  stampPackListType(env, eleOrderLine, eleItem, extnOrderLine);
        }

        /* Stamp StoreInfo at Order/OrderLines/OrderLine/PersonInfoShipTo */
        strShipNode = eleOrderLine.getAttribute(KohlsPOCConstant.A_SHIP_NODE);
        eleOrderLine = stampStoreInfo(env, eleOrderLine, strShipNode);

    }


    /**
     * This method stamps /Order/OrderLines/OrderLine/@PackListType as '<shipnode>_JEW' for Jewlery items and
     * Order/OrderLines/OrderLine/Extn/@ExtnIsHazardous as 'Y' if IS_HAZMAT is 'Y' in YFS_ITEM table for that particular
     * item.
     * @param env
     * @param eleOrderLine
     * @param eleItem
     * @param extnOrderLine
     * @return
     * @throws YFSException
     */

    private Element stampPackListType(YFSEnvironment env, Element eleOrderLine, Element eleItem, Element extnOrderLine)
            throws YFSException {

        String strItemID = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
        String sUOM = eleItem.getAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE);
        String strShipNode = eleOrderLine.getAttribute(KohlsPOCConstant.A_SHIP_NODE);

        try {
            /*Invoke getItemList API */
            Document docGetItemListOut = invokeGetItemList(env, strItemID, sUOM);

            /* Get ExtnDept and IsHazmat */
            Element eleItemOut = KohlsXMLUtil.getChildElement(docGetItemListOut.getDocumentElement(),
                    KohlsPOCConstant.E_ITEM);
            String strDept = null;
            String strHazard = null;
            if (!YFCCommon.isVoid(eleItemOut)) {
                Element eleTemp = KohlsXMLUtil.getChildElement(eleItemOut, KohlsPOCConstant.A_PRIMARY_INFORMATION);
                strHazard = eleTemp.getAttribute(KohlsXMLLiterals.A_IS_HAZMAT);
                eleTemp = KohlsXMLUtil.getChildElement(eleItemOut, KohlsPOCConstant.E_EXTN);
                strDept = eleTemp.getAttribute(KohlsXMLLiterals.A_EXTN_DEPT);
            }

            /* Invoke getCommonCodeList API to retrieve list of Jewelry Dept */
            String strValue = KohlsUtil.getCommonCodeValue(env, KohlsPOCConstant.JEWELRY_DEPT);
            String[] strCodeValue = null;

            if (!YFCCommon.isVoid(strValue)) {
                strCodeValue = strValue.split(KohlsPOCConstant.COMMA);
            }

            /* Stamp PackListType if Jewelry Item is present */
            if (!YFCCommon.isVoid(strDept) && !YFCCommon.isVoid(strCodeValue) &&
                    Arrays.asList(strCodeValue).contains(strDept)) {
                eleOrderLine.setAttribute(KohlsXMLLiterals.A_PACK_LIST_TYPE, strShipNode + KohlsConstant.KOHLS_PACK_LIST_J);
            }

            /* Stamp ExtnIsHazardous */
            if (!YFCCommon.isVoid(strHazard) && KohlsPOCConstant.YES.equalsIgnoreCase(strHazard)) {
                extnOrderLine.setAttribute(KohlsXMLLiterals.A_EXTN_IS_HAZARDOUS, KohlsPOCConstant.YES);
            } else {
                extnOrderLine.setAttribute(KohlsXMLLiterals.A_EXTN_IS_HAZARDOUS, KohlsPOCConstant.NO);
            }
        } catch (YIFClientCreationException e) {
            throw new YFSException(e.getMessage());
        } catch (RemoteException e) {
            throw new YFSException(e.getMessage());
        } catch (YFSException e) {
            throw new YFSException(e.getMessage());
        }

        return eleOrderLine;
    }

    /**
     * This method invokes getItemList API
     * @param env
     * @param strItemID
     * @param sUOM
     * @return
     */
    private Document invokeGetItemList(YFSEnvironment env, String strItemID, String sUOM) {

       /* Initialize Variables */
        Document docItemListIn = null;
        Document docGetItemListOut = null;

        try {
             /* Create input document for getItemList API */
            docItemListIn = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);

            docItemListIn.getDocumentElement().setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemID);
            docItemListIn.getDocumentElement().setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, sUOM);
            docItemListIn.getDocumentElement().setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE,
                    KohlsPOCConstant.ATTR_DEFAULT_ORGANIZATION_KEY);

            /*Invoke getItemList API */
            Document docGetItemListtemplate = XMLUtil.getDocument(KohlsPOCConstant.GetItemListAPITemplateForOmni);

            if (logger.isDebugEnabled()) {
                logger.debug("Invoking getItemList API with input xml: \n" + XMLUtil.getXMLString(docItemListIn));
            }

            docGetItemListOut = KOHLSBaseApi.invokeAPI(env, docGetItemListtemplate, KohlsConstants.GET_ITEMLIST,
                    docItemListIn);

        } catch (SAXException e) {
            throw new YFSException(e.getMessage());
        } catch (ParserConfigurationException e) {
            throw new YFSException(e.getMessage());
        } catch (IOException e) {
            throw new YFSException(e.getMessage());
        } catch (Exception e) {
            throw new YFSException(e.getMessage());
        }
        return docGetItemListOut;
    }

    /**
     * This method invokes getOrganizationList API to retrieve the store address and save the
     * store address as OrderLine/PersonInfoShipTo.
     * @param env
     * @param eleOrderLine
     * @param strShipNode
     * @return
     */
    private Element stampStoreInfo(YFSEnvironment env, Element eleOrderLine, String strShipNode) {

        /* Initialize variables */
        Document docGetOrgIn = null;
        Document docGetOrgOut = null;
        Element eleOrgIn = null;
        Element eleShipNodePersonInfo = null;
        Element elePersonInfoShipTo = null;

        try {

            /* Prepare input XML to getOrganizationHierarchy API */
            docGetOrgIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORGANIZATION);
            eleOrgIn = docGetOrgIn.getDocumentElement();
            eleOrgIn.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, strShipNode);

            /* Invoke getOrganizationHierarchy API */
            if (logger.isDebugEnabled()) {
                logger.debug("The input XML to getOrganizationList : \n" + XMLUtil.getXMLString(docGetOrgIn));
            }

            /* Invoke getOrganizationHierarchy API */
            docGetOrgOut = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GetOrganizationListAPITemplateForOmni,
                    KohlsPOCConstant.API_GET_ORGANIZATION_LIST, docGetOrgIn);

            if (logger.isDebugEnabled()) {
                logger.debug("The output XML from getOrganizationList : \n" + XMLUtil.getXMLString(docGetOrgOut));
            }

            if(!YFCCommon.isVoid(docGetOrgOut)) {
                eleShipNodePersonInfo = KohlsXMLUtil.getElementByXpath(docGetOrgOut, KohlsPOCConstant.A_SHIPNODE_PERSONINFO_XPATH);
            }

            /* Stamp the OrderLine/PersonInfoShipTo with address details from getOrganizationList */
            if(!YFCCommon.isVoid(eleShipNodePersonInfo)) {
                elePersonInfoShipTo = KohlsXMLUtil.createChild(eleOrderLine, KohlsXMLLiterals.E_PERSON_INFO_SHIP_TO);
                stampPersonInfo(elePersonInfoShipTo, eleShipNodePersonInfo);
            }

            KohlsXMLUtil.appendChild(eleOrderLine, elePersonInfoShipTo);
        } catch (ParserConfigurationException e) {
            throw new YFSException(e.getMessage());
        } catch (SAXException e) {
            throw new YFSException(e.getMessage());
        } catch (IOException e) {
            throw new YFSException(e.getMessage());
        } catch (Exception e) {
            throw new YFSException(e.getMessage());
        }
        return eleOrderLine;
    }

    /**
     * This method stamps the Address, State, City and ZIpCode details to PersonInfoShipTo Element
     * @param elePersonInfoShipTo
     * @param eleShipNodePersonInfo
     */
    private void stampPersonInfo(Element elePersonInfoShipTo, Element eleShipNodePersonInfo) {
        elePersonInfoShipTo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_1,
                eleShipNodePersonInfo.getAttribute(KohlsXMLLiterals.A_ADD_LINE_1));
        elePersonInfoShipTo.setAttribute(KohlsXMLLiterals.A_CITY,
                eleShipNodePersonInfo.getAttribute(KohlsXMLLiterals.A_CITY));
        elePersonInfoShipTo.setAttribute(KohlsXMLLiterals.A_STATE,
                eleShipNodePersonInfo.getAttribute(KohlsXMLLiterals.A_STATE));
        elePersonInfoShipTo.setAttribute(KohlsXMLLiterals.A_COUNTRY,
                eleShipNodePersonInfo.getAttribute(KohlsXMLLiterals.A_COUNTRY));
        elePersonInfoShipTo.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,
                eleShipNodePersonInfo.getAttribute(KohlsXMLLiterals.A_ZIP_CODE));
    }

    /**
     * This method is invoked on ON_SUCCESS of confirmDraftOrder Event to set the BOGO and Kohls Cash Attributes.
     * @param env
     * @param inDoc
     * @return
     */
    public Document setKohlsCashAndBOGOAttributes(YFSEnvironment env, Document inDoc) {

        /* Initialize Variables */
        Document docChangeOrderIn = null;
        Element eleChangeOrderRoot = null;
        Element eleChangeOrderLines = null;
        Element elePersonInfoBillTo = null;
        String strFirstName = null;
        String strLastName = null;
        Element eleInRoot = null;
        boolean isOmniPickEnabled = false;

        if(logger.isDebugEnabled()) {
            logger.debug("The input XML to KohlsPoCSetAttributesForBipass.setKohlsCashAndBOGOAttributes : \n"
                    + XMLUtil.getXMLString(inDoc));
        }

        try {
             /* Prepare ChangeOrder Input Document */
            docChangeOrderIn = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
            eleChangeOrderRoot = docChangeOrderIn.getDocumentElement();

            /* Get the Order/OrderLines/OrderLine from input document */
            eleInRoot = inDoc.getDocumentElement();
            List<Element> listOrderLines = KohlsXMLUtil.getElementListByXpath(inDoc, KohlsPOCConstant.ORDER_LINES_DELMETHOD_XPATH);

            /* Get the First Name and Last Name from Order/PersonInfoBillTo */
            elePersonInfoBillTo = KohlsXMLUtil.getChildElement(eleInRoot, KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
            strFirstName = elePersonInfoBillTo.getAttribute(KohlsXMLLiterals.A_FIRST_NAME);
            strLastName = elePersonInfoBillTo.getAttribute(KohlsXMLLiterals.A_LAST_NAME);

            /* Stamp Order attributes for changeOrder */
            eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,
                    eleInRoot.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY));
            eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_SELECT_METHOD, KohlsPOCConstant.SELECT_METHOD_WAIT);
            eleChangeOrderLines = KohlsXMLUtil.createChild(eleChangeOrderRoot, KohlsPOCConstant.ELEM_ORDER_LINES);

            /* Loop through each order-line */
            for(Element eleOrderLine : listOrderLines) {
                String strExtnBogoGPID = null;
                Element eleExtn = null;
                Element eleChangeOrderLine = null;
                Element eleChangePersonInfo = null;
                Element elePersonInfoShipTo = null;

               /* if Order Line is PICK then check for BOGO and Kohls Cash */
                eleExtn = KohlsXMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);

                    /* Check if OrderLine/Extn */
                if (!YFCCommon.isVoid(eleExtn)) {
                    strExtnBogoGPID = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_BOGO_GPID);
                }

                eleChangeOrderLine = KohlsXMLUtil.createChild(eleChangeOrderLines, KohlsPOCConstant.E_ORDER_LINE);
                eleChangeOrderLine.setAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY,
                        eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY));

                    /* if the item is a BOGO is item then add the attributes */
                if (!YFCCommon.isVoid(strExtnBogoGPID) && !KohlsPOCConstant.ZERO.equals(strExtnBogoGPID)) {
                    stampBOGOAttributes(eleOrderLine, eleChangeOrderLine, strExtnBogoGPID,
                            docChangeOrderIn);

                }
                isOmniPickEnabled = true;

                elePersonInfoShipTo = KohlsXMLUtil.getChildElement(eleOrderLine,KohlsXMLLiterals.E_PERSON_INFO_SHIP_TO);
                String strPersonInfoKey = elePersonInfoShipTo.getAttribute(KohlsXMLLiterals.A_PERSONINFOKEY);

                /* Stamp OrderLine/PersonInfoShipTo/@FirstName and OrderLine/PersonInfoShipTo/@LastName */
                eleChangeOrderLine.setAttribute(KohlsXMLLiterals.A_SHIP_TO_KEY, strPersonInfoKey);
                eleChangePersonInfo = KohlsXMLUtil.createChild(eleChangeOrderLine, KohlsXMLLiterals.E_PERSON_INFO_SHIP_TO);
                eleChangePersonInfo.setAttribute(KohlsXMLLiterals.A_PERSONINFOKEY, strPersonInfoKey);
                eleChangePersonInfo.setAttribute(KohlsXMLLiterals.A_FIRST_NAME, strFirstName);
                eleChangePersonInfo.setAttribute(KohlsXMLLiterals.A_LAST_NAME, strLastName);
                stampPersonInfo(eleChangePersonInfo, elePersonInfoShipTo);
                KohlsXMLUtil.appendChild(eleChangeOrderLine, eleChangePersonInfo);
            }

            /* If the order is a omnibag order then stamp KOhls Cash */
            if(isOmniPickEnabled) {
                stampKohlsCashAttributes(eleInRoot, eleChangeOrderRoot, docChangeOrderIn);
            }

            /* Invoke Changeorder api */
            if(isOmniPickEnabled) {
                if(logger.isDebugEnabled()) {
                    logger.debug("The input XML to KohlsPoCSetAttributesForBipass.changeOrder : \n"
                            + XMLUtil.getXMLString(docChangeOrderIn));
                }
                KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API, docChangeOrderIn);
            }
        } catch (Exception e) {
            throw new YFSException(e.getMessage());
        }
        return inDoc;
    }

    /**
     * This method stamps BOGO Attributes (ExtnBOGOProration, ExtnBOGOReceiptMarkDown, ExtnBOGOReturnTax and ExtnBOGOSeq)
     * at Order/OrderLines/OrderLine/Extn. These attributes will be stamped only on CORP order ie if the order is
     * created at ISS, then these attributes will not stamped.
     *
     * @param eleOrderLine
     * @param eleChangeOrderLine
     * @param strExtnBogoGPID
     */

    private void stampBOGOAttributes(Element eleOrderLine, Element eleChangeOrderLine, String strExtnBogoGPID,
                                     Document docChangeOrderIn) {
        /* Initialize the variables */
        Element eleChangeOrderExtn = null;
        NodeList nlAwards = null;
        boolean isBogoApplied = true;
        int iAwardCount = 0;

        Element eleAwards = KohlsXMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_AWARDS);
        eleChangeOrderExtn = KohlsXMLUtil.createElement(docChangeOrderIn, KohlsPOCConstant.E_EXTN, KohlsPOCConstant.BLANK);

        /* Check if Award Elements are present */
        if (!YFCCommon.isVoid(eleAwards)) {
            nlAwards = eleAwards.getElementsByTagName(KohlsPOCConstant.E_AWARD);
        }

        if (!YFCCommon.isVoid(nlAwards)) {
            iAwardCount = nlAwards.getLength();
        }

        /*Loop through each Award Element to get the Net Delta for BOGO */
        for (int j = 0; j < iAwardCount; j++) {
            Element eleAward = (Element) nlAwards.item(j);

            if (KohlsPOCConstant.REMOVE.equalsIgnoreCase(eleAward.getAttribute(KohlsPOCConstant.ACTION))) {
                continue;
            }
            if(eleAward.getAttribute(KohlsPOCConstant.A_DESCRIPTION).contains(KohlsPOCConstant.BUY_BOGO_DESC)) {
                Element eleAwardExtn = KohlsXMLUtil.getChildElement(eleAward, KohlsPOCConstant.E_EXTN);

                    /* If Award/Extn is present then get the ExtnNetDelta*/
                if (!YFCCommon.isVoid(eleAwardExtn)) {
                    String strNetDelta = eleAwardExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_DELTA)
                            .replace(KohlsPOCConstant.MINUS, KohlsPOCConstant.BLANK);

                /* If NetDelta is 0, then BOGO is not applied */
                    if (0 == Double.parseDouble(strNetDelta)) {
                        isBogoApplied = false;
                    } else {
                        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_BOGO_PRORATION, strNetDelta);
                        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_BOGO_RECEIPT_MARK_DOWN, strNetDelta);
                    }
                }
            }

        }
        /* End of Award loop */
        if (isBogoApplied) {
            eleChangeOrderExtn.setAttribute(KohlsPOCConstant.A_EXTN_BOGO_RETURN_TAX,KohlsXMLLiterals.CONST_DECIMAL_ZERO);
            eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_BOGO_SEQ, strExtnBogoGPID);
            KohlsXMLUtil.appendChild(eleChangeOrderLine, eleChangeOrderExtn);
        }
    }

    /**
     * This method stamps Kohls Cash Attributes on Kohls Cash Activation at /Order/Extn.
     *  @param eleOrder
     * @param eleChangeOrderRoot
     */
    private void stampKohlsCashAttributes(Element eleOrder, Element eleChangeOrderRoot, Document docChangeOrderIn)
            throws IOException, SAXException, ParserConfigurationException {

        /* Initialize Variables */
        Element elePromotions = null;
        Element eleReferences = null;
        Element eleExtn = null;
        Element eleKohlsCashTableList = null;
        boolean isKCUsed = false;

        eleExtn = KohlsXMLUtil.createElement(docChangeOrderIn, KohlsPOCConstant.E_EXTN, KohlsPOCConstant.BLANK);

        /* Create KohlsCashTableList Element */
        eleKohlsCashTableList = KohlsXMLUtil.createElement(docChangeOrderIn, KohlsXMLLiterals.E_KOHLS_CASH_TABLE_LIST,
                KohlsPOCConstant.BLANK);

        /* Get the Order/Promotions */
        elePromotions = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);

        /* Get the Order/References */
        eleReferences = KohlsXMLUtil.getChildElement(eleOrder, KohlsPOCConstant.A_REFERENCES);

        /* Invoke stampKohlsCashActivation to stamp Kohls Cash Activation Details */		
        isKCUsed = stampKohlsCashActivation(eleReferences, eleExtn, isKCUsed);

        /* Invoke stampKohlsCashRedemption to stamp Kohls Cash Redemption Details */
        isKCUsed = stampKohlsCashRedemption(elePromotions, eleExtn, eleKohlsCashTableList, isKCUsed);

        if(isKCUsed) {
            KohlsXMLUtil.appendChild(eleChangeOrderRoot, eleExtn);
        }
    }

    /**
     * This method stamps the KOhls Cash Activation Details
     * @param eleReferences
     * @param eleExtn
     * @param isKCUsed
     * @return
     */
    private boolean stampKohlsCashActivation(Element eleReferences, Element eleExtn, boolean isKCUsed) {

        /* Initialize Variables */
        NodeList nlReferences = null;
        int iRefCount = 0;

        if(!YFCCommon.isVoid(eleReferences)) {
            nlReferences = eleReferences.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
        }

        if(!YFCCommon.isVoid(nlReferences)) {
            iRefCount = nlReferences.getLength();
        }

        /* Loop through each Reference and get 'KOHLS_CASH_EARNED */
        for(int i = 0; i < iRefCount; i++) {
            Element eleReference = (Element) nlReferences.item(i);
            String strAttrName = eleReference.getAttribute(KohlsPOCConstant.Name);
            String strAttrValue = eleReference.getAttribute(KohlsPOCConstant.Value);

			if (YFCCommon.isVoid(strAttrValue) && (KohlsPOCConstant.A_KCA_EXTN_COUPON_AMT.equals(strAttrName)
					|| KohlsPOCConstant.A_KCA_EXTN_QUALIFYING_AMT.equals(strAttrName))) {
				strAttrValue = "0.00";
				if (logger.isDebugEnabled()) {
				logger.debug("Values strAttrName=" + strAttrName + ", strAttrValue=" + strAttrValue);
				}
			}
            if(KohlsPOCConstant.A_KCA_EXTN_ACTIVATION_BARCODE.equals(strAttrName)) {
                eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCE_COUPON_NO, strAttrValue);
                eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCE_COUPON_ALGORITHM, strAttrValue);
                isKCUsed = true;
            } else if(KohlsPOCConstant.A_KCA_EXTN_COUPON_EVENTID.equals(strAttrName)) {
                eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCE_COUPON_EVENT_ID, strAttrValue);
            } else if(KohlsPOCConstant.A_KCA_EXTN_COUPON_AMT.equals(strAttrName)) {
            	//PST-8619 set the KohlsCashCouponAmount to 0.0 incase of non numeric value
            	if(NumberUtils.isNumber(strAttrValue))
            		eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCE_COUPON_BALANCE, strAttrValue);
            	else
            		eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCE_COUPON_BALANCE, "0.00");            		
            } else if(KohlsPOCConstant.A_KCA_EXTN_QUALIFYING_AMT.equals(strAttrName)) {
                eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCE_COUPON_AMT, strAttrValue);
            }
			
        }
        return isKCUsed;
    }

    /**
     * This method stamps the KOhls Cash Redemption Details
     * @param elePromotions
     * @param eleExtn
     * @param eleKohlsCashTableList
     * @param isKCUsed
     * @return
     */
    private boolean stampKohlsCashRedemption(Element elePromotions, Element eleExtn, Element eleKohlsCashTableList, boolean isKCUsed) {

        /* Initialize Variables */
        NodeList nlPromotions = null;
        int iPromoCount = 0;

        if(!YFCCommon.isVoid(elePromotions)) {
            nlPromotions = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
        }

        if(!YFCCommon.isVoid(nlPromotions)) {
            iPromoCount = nlPromotions.getLength();
        }
         /* Loop through ech Promotion and get 'KOHLS_CASH*/
        for(int i = 0; i < iPromoCount; i++) {
            Element elePromotion = (Element) nlPromotions.item(i);
            String strPromoType = elePromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
            Element elePromoExtn = KohlsXMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
            String strPromotionId = elePromotion.getAttribute(KohlsXMLLiterals.A_PROMOTION_ID);
            String strPromoSeq = elePromoExtn.getAttribute(KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE);

            if(KohlsPOCConstant.KOHLS_CASH.equals(strPromoType)) {
                /* If Promotion type is 'KOHLS_CASH' for Kohls Cash Redemption then continue */
                Element eleKohlsCashTable = KohlsXMLUtil.createChild(eleKohlsCashTableList,
                        KohlsXMLLiterals.E_KOHLS_CASH_TABLE);
                String strOverrideAdjValue = elePromotion.getAttribute(KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE)
                        .replace(KohlsPOCConstant.MINUS, KohlsPOCConstant.BLANK);
                eleKohlsCashTable.setAttribute(KohlsXMLLiterals.A_KOHLS_CASH_AMOUNT,strOverrideAdjValue);
                eleKohlsCashTable.setAttribute(KohlsConstant.KOHLS_CASH_EVENT_ID,strPromotionId.substring(0,5));
                eleKohlsCashTable.setAttribute(KohlsXMLLiterals.A_KOHLS_CASH_ID, strPromotionId);
                eleKohlsCashTable.setAttribute(KohlsXMLLiterals.A_KOHLS_CASH_SEQ, strPromoSeq);

                isKCUsed = true;
                KohlsXMLUtil.appendChild(eleKohlsCashTableList, eleKohlsCashTable);
            }

        }
        if(isKCUsed) {
            KohlsXMLUtil.appendChild(eleExtn, eleKohlsCashTableList);
        }

        return isKCUsed;
    }
}
