package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCXMLDiff;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoCPrepareUEResponse.java 
 * Author : IBM 
 * Created : August 27 2013 
 * Modified : August 27 2013 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * 
 * This Class is used to update the UE output doucument  by using the APE Response.
 * 
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/
public class KohlsPoCPrepareUEResponse {

	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPoCOrderRepriceUE.class.getName());
	}

	/**
	 * 
	 *  This main method is used to update the UE output document using APE Response.
	 *  Award and LineChange element are created using APE Response/../Modifier' information.
	 *  Using 'Guid' in the Order Document, corresponding item , modifier  in APE Response is find out.
	 * 
	 * 
	 * @param apeResponseEle
	 * @param orderEle
	 * @param promoObj
	 * @param offerAndKohlsCashObj
	 * @throws Exception 
	 */
	public void updateUeDocumentFromApeResponse(Element apeResponseEle, Element orderEle, KohlsPoCOrderLinePromotionsCaller promoObj, KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj) throws Exception   {

		logger.beginTimer("KohlsPoCPrepareUEResponse.updateUeDocumentFromApeResponse");

		//Added for defect 3945 fix -- Start
		double assTLDImpVal = KohlsPOCConstant.ZERO_DBL;
		double softTLDImpVal = KohlsPOCConstant.ZERO_DBL;
		double hardTLDImpVal = KohlsPOCConstant.ZERO_DBL;
		String uidStr = null;
		String isSoftDisItemAvail = KohlsPOCConstant.NO;
		//Added for defect 3945 fix -- End
		
		
		//Updating Order Level Promotion/@OverrideAdjustmentValue
		List <Element> apeTldList = XMLUtil.getElementsByTagName(
				apeResponseEle, KohlsPOCConstant.E_TLD);
		if (apeTldList.size() > KohlsPOCConstant.ZERO_INT) {	
			for (Element tldEle : apeTldList) {
				String guidStr = XMLUtil.getAttribute(
						tldEle, KohlsPOCConstant.E_GUID);
				String tldImpactValue = XMLUtil.getAttribute(tldEle, KohlsPOCConstant.A_TLD_IMPACT);
				
				//Added for 3945 defect fix --- Start
				Map<String, Element> orderAssociateDisHM = offerAndKohlsCashObj.getOrderAssociateDisHM();
				if (orderAssociateDisHM.containsKey(guidStr)) {
					Element promotionEle = orderAssociateDisHM.get(guidStr);
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
					assTLDImpVal = Math.abs(Double.valueOf(tldImpactValue).doubleValue());
					uidStr = guidStr;
				}
				//Added for 3945 defect fix --- End
								

				Map<String, Element> orderKohlsCashHM = offerAndKohlsCashObj.getOrderKohlsCashHM();
				if (orderKohlsCashHM.containsKey(guidStr)) {
					Element promotionEle = orderKohlsCashHM.get(guidStr);
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
				}

				Map<String, Element> orderManualTldHM = offerAndKohlsCashObj.getOrderManualTldHM();
				if (orderManualTldHM.containsKey(guidStr)) {
					Element promotionEle = orderManualTldHM.get(guidStr);
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
				}

				Map<String, Element> orderSeniorCitizenHM = offerAndKohlsCashObj.getOrderSeniorDiscountHM();
				if (orderSeniorCitizenHM.containsKey(guidStr)) {
					Element promotionEle = orderSeniorCitizenHM.get(guidStr);
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
				}

				Map<String, Element> orderOfflineKohlsCashHM = offerAndKohlsCashObj.getOrderOfflineKohlsCashHM();
				if (orderOfflineKohlsCashHM.containsKey(guidStr)) {
					Element promotionEle = orderOfflineKohlsCashHM.get(guidStr);
					XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
				}

			}

		}

		//Added for defect 3945 fix -- Start
		if(assTLDImpVal!=KohlsPOCConstant.ZERO_DBL)
		{
			logger.debug("assTLDImpVal condition ::::" + assTLDImpVal);
			
			List <Element> apeItemList = XMLUtil.getElementsByTagName(
					apeResponseEle, KohlsPOCConstant.E_ITEM);
			if (apeItemList.size() > KohlsPOCConstant.ZERO_INT) {
				logger.debug("apeItemList condition ::::" );
				for (Element itemApeEle : apeItemList) {
					String guidApe = XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.E_GUID);
					Map<String, Element> orderLineHM = promoObj.getOrderLineHM();
					if (orderLineHM.containsKey(guidApe)) {
						logger.debug("orderLineHM condition ::::" );
						Element orderLineEle = orderLineHM.get(guidApe);
						Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
						Element pluPromoResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE));
						Element pluFileRecordEle = null;
						List<Element> pluFileList = XMLUtil.getElementsByTagName(
								pluPromoResposneEle, KohlsPOCConstant.E_PLU_FILE);
						if (pluFileList.size() > KohlsPOCConstant.ZERO_INT){
							logger.debug("pluFileList condition ::::" );
							pluFileRecordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
							String empDiscCode = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_EMP_DISC_CDE);
							
							String netPriceDelta = null;
							List<Element> modifierEleList = XMLUtil.getElementsByTagName(
									itemApeEle, KohlsPOCConstant.E_MODIFIER);
							if (modifierEleList.size() > KohlsPOCConstant.ZERO_INT && !YFCCommon.isVoid(pluFileRecordEle)){
								logger.debug("modifierEleList condition ::::" );

								for (Element modifierEle : modifierEleList) {
									String guidStr = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.E_PARENT_DISCOUNT_GUID);
									if(guidStr.equals(uidStr))
									{
										logger.debug("guidStr_uidStr condition ::::" );
										netPriceDelta = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_NET_PRICE_DELTA) ;
										logger.debug("netPriceDelta ::::" + netPriceDelta);
									}
									
								}
							}
							
							if(empDiscCode.equals(KohlsPOCConstant.CONST_H))
							{
								
								hardTLDImpVal = hardTLDImpVal+ Math.abs(Double.valueOf(netPriceDelta).doubleValue());
								logger.debug("hardTLDImpVal ::::" + hardTLDImpVal);
							}
							
							else if(empDiscCode.equals(KohlsPOCConstant.CONST_S))
							{
								isSoftDisItemAvail = KohlsPOCConstant.YES;	
								logger.debug("isSoftDisItemAvail in condition ::::" + isSoftDisItemAvail);
							}
						}
					}
				}
				
				softTLDImpVal = assTLDImpVal-hardTLDImpVal;
				logger.debug("isSoftDisItemAvail ::::" + isSoftDisItemAvail);
			}
			
		}
		//Added for defect 3945 fix -- End
		
		
		List <Element> apeItemList = XMLUtil.getElementsByTagName(
				apeResponseEle, KohlsPOCConstant.E_ITEM);
		double totalSaving = KohlsPOCConstant.ZERO_DBL;

		if (apeItemList.size() > KohlsPOCConstant.ZERO_INT) {	
			List<String> activePromotionGuidList = new ArrayList<String>();
			for (Element itemApeEle : apeItemList) {
				String guidApe = XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.E_GUID);
				Map<String, Element> orderLineHM = promoObj.getOrderLineHM();
				if (orderLineHM.containsKey(guidApe)) {

					double totalDiscount = KohlsPOCConstant.ZERO_DBL;
					double promoChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double offerChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double tldPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double tldAmountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double orderLineUnitPriceDbl = KohlsPOCConstant.ZERO_DBL;
					double nonClearanceAmtDbl = KohlsPOCConstant.ZERO_DBL;
					double legacyDollarChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double legacyPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double kohlsCashChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double lidPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double lidAmountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double priceOverrideChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double seniorCitizenChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double associateDiscountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double priceOverrideIncChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					boolean isPromoApplied = false;
					boolean isOfferApplied = false;
					boolean isTldPercentApplied = false;
					boolean isTldAmountApplied = false;
					boolean isLegacyDollarApplied = false;
					boolean isLegacyPercentApplied = false;
					boolean isKohlsCashApplied = false;
					boolean isLidPercentApplied = false;
					boolean isLidAmountApplied = false;
					boolean isPriceOverrideApplied = false;
					boolean isSeniorCitizenApplied = false;
					boolean isAssociateDiscountApplied = false;
					boolean isPriceOverrideIncreasedApplied = false;					


					Element orderLineEle = orderLineHM.get(guidApe);
					Element linePrcEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO, Boolean.TRUE);

					String orderLineUnitPrice = XMLUtil.getAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE);

					if (YFCCommon.isStringVoid(orderLineUnitPrice) || KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(orderLineUnitPrice)){
						XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE, XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_REGULAR_PRICE));
					}

					Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

					// Update the orderLineEle based on the APE Response Mapping Doc
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_RETURN_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_RETURN_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_TAXABLE_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_SELLING_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_SIMPLE_PROMO_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_NET_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_NET_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_RECPTT_RTN_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_RECEIPT_RETURN_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BOGO_GPID, XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_BOGO_GRP_CODE));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PWP_GROUP_ID, XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_PWP_GWP_GROUP_CODE));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BUY_ITEM, XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_BUY_ITEM));
					
					// Suresh : Added for Nike Exclusions Sprint 5 : Start
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM, XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.E_EXCLUSION_ITEM));
					// Suresh : Added for Nike Exclusions Sprint 5 : End
					
					Element awardsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, Boolean.TRUE);
					Element lineChargesEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES, Boolean.TRUE);


					Element pluPromoResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE));
					Element pluFileRecordEle = null;
					List<Element> pluFileList = XMLUtil.getElementsByTagName(
							pluPromoResposneEle, KohlsPOCConstant.E_PLU_FILE);
					DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);

					if (pluFileList.size() > KohlsPOCConstant.ZERO_INT){
						pluFileRecordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_PRODUCT_CODE, pluFileRecordEle.getAttribute(KohlsPOCConstant.A_TAX_PRD_CDE));

						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_MDX_TAX_CODE, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_MDSE_TX_CDE));

						Double unitRetailAmt = Double.valueOf(XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_UNT_RTL_AMT)) / KohlsPOCConstant.HUNDRED_INT;
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT,twoDForm.format(unitRetailAmt));
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_ITEM_DEPT, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_DEPT_NBR));
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_ITEM_CLASS, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_MAJ_CL_NBR));
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_ITEM_SUB_CLASS, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_SUB_CL_NBR));

						// Defect 1909
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PRICE_POINT_IND, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_PRMPT_FOR_PRIC_IND));

						// Defect 1910
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_CALL_BACK_IND, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_CALL_BACK));


					}

					Element itemEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_ITEM, Boolean.TRUE);

					String isDiscountable = pluFileRecordEle.getAttribute(KohlsPOCConstant.A_DISC_ELIG_IND);
					if(KohlsPOCConstant.YES.equalsIgnoreCase(isDiscountable))
					{
						isDiscountable = KohlsPOCConstant.NO;
					}
					else
					{
						isDiscountable = KohlsPOCConstant.YES;
					}	
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_DISCOUNTABLE, isDiscountable);
					String skuStatusCode = pluFileRecordEle.getAttribute(KohlsPOCConstant.A_LOC_SKU_STAT_CDE);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE, skuStatusCode);
					String nonClearanceAmt = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_LAST_NCLR_RTL_AMT);

					orderLineUnitPriceDbl = Double.valueOf(XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_REGULAR_PRICE));


					if (!YFCCommon.isVoid(nonClearanceAmt)) {
						nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt) / KohlsPOCConstant.HUNDRED_INT;
						nonClearanceAmt = twoDForm.format(nonClearanceAmtDbl);
						nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt);
					}					
					else{
						//Default the clearance amount to the value of unit price if it is null or zero from plu
						nonClearanceAmt = XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_REGULAR_PRICE);
						nonClearanceAmtDbl = orderLineUnitPriceDbl;
					}
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_NON_CLEARANCE_AMT, nonClearanceAmt);

					int awardSequence = KohlsPOCConstant.ZERO_INT;

					List<Element> modifierEleList = XMLUtil.getElementsByTagName(
							itemApeEle, KohlsPOCConstant.E_MODIFIER);
					if (modifierEleList.size() > KohlsPOCConstant.ZERO_INT && !YFCCommon.isVoid(pluFileRecordEle)){

						for (Element modifierEle : modifierEleList) {
							boolean isItemLevelPromo = Boolean.FALSE;
							String guidStr = XMLUtil.getAttribute(
									modifierEle, KohlsPOCConstant.E_PARENT_DISCOUNT_GUID); 

							Element awardEle = XMLUtil.createChild(awardsEle, KohlsPOCConstant.E_AWARD);
							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());

							String modifierActiveStatus = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_MODIFIER_ACTIVE);

							if (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
							} else{
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.NO);
							}

							String taxablePriceDelta =  XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TAXABLE_PRICE_DELTA);
							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, KohlsPoCPnPUtil.getDouble(taxablePriceDelta));



							Element awardExtEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TAX_DELTA, 
									KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TAXABLE_PRICE_DELTA)));
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_NET_DELTA, 
									KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_NET_PRICE_DELTA)));
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_ACT_DELTA, 
									KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_ACTIVATION_ACHIEVED)));
							// Changes for R3 - RKC - Start
							if(!YFCCommon.isVoid(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA_APE)))
							{
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_RETRN_DELTA, 
									KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA_APE)));
							logger.debug("ExtnRetrnDelta value for APE store is:: "+XMLUtil.getAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_RETRN_DELTA));
							}
							// Changes for R3 - RKC - End
							if(!YFCCommon.isVoid(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_PERCENT_ACHIEVED))) {
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_PER_DELTA, XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_PERCENT_ACHIEVED));
							}
							String tierLevelAchieved = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_LEVEL_ACHIEVED);
							if(!YFCCommon.isVoid(tierLevelAchieved)){
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_LVL_ACHVD, XMLUtil.getAttribute(modifierEle, tierLevelAchieved));
							}

							//Sudina : Backlog 197 Receipt Enhancements - start
							XMLUtil.setAttribute(awardExtEle,KohlsPOCConstant.ATTR_EXTN_SALE_PRICE,XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_SIMPLE_PROMO_PRICE));
							//Sudina : Backlog 197 Receipt Enhancements - End
							
							//Adding Award Sequence Number
							awardSequence = awardSequence + KohlsPOCConstant.ONE_INT;
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, String.valueOf(awardSequence));


//							String upc = pluFileRecordEle.getAttribute(KohlsPOCConstant.A_UPC);
//							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_UPC_CODE, upc);
//							String skuNumber = pluFileRecordEle.getAttribute(KohlsPOCConstant.A_SKU_NBR);
//							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ITEM_ID, skuNumber);
							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, "");

							// Start: Sales Hub Clob Code 

							Document salesHubDoc = null;
							Element eleData = null;
							KohlsPoCPrepareSalesHubClob prepareSalesHubClobObj = null;

							// Code modification for allowing clob to be formed for AWARD_APPLIED TO 'Y' OR 'N'
							if((KohlsPOCConstant.YES.equalsIgnoreCase(XMLUtil.getAttribute(awardEle,KohlsPOCConstant.A_AWARD_APPLIED)) ) || (KohlsPOCConstant.NO.equalsIgnoreCase(XMLUtil.getAttribute(awardEle,KohlsPOCConstant.A_AWARD_APPLIED))) ){
								salesHubDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DATA);
								eleData = salesHubDoc.getDocumentElement();
								// Creating an instance of KohlsPocPrepareSalesHubClob

								prepareSalesHubClobObj = new KohlsPoCPrepareSalesHubClob(eleData, awardExtEle);

							}

							// End: Sales Hub Clob Code 

							//Using to update create Related Award 
							Map<String, Element> pluPromoRecordHM = promoObj.getPluPromoRecordHM();
							if (pluPromoRecordHM.containsKey(guidStr)) {
								isItemLevelPromo = Boolean.TRUE;
								Element recordEle = pluPromoRecordHM.get(guidStr);
								String regularPrice = XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_REGULAR_PRICE);
								//Manoj 10/08 - Updated for defect 5626 - Begin
								String promoSchemeCode = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE);
								if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))
										|| Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) {
									String sTierPctAchieved = modifierEle.getAttribute(KohlsPOCConstant.A_TIER_PERCENT_ACHIEVED);
									String sTierActAchieved = modifierEle.getAttribute(KohlsPOCConstant.A_TIER_ACTIVATION_ACHIEVED);
									if (!YFCCommon.isVoid(sTierPctAchieved) && !YFCCommon.isVoid(sTierActAchieved)){
										int iDiscountPercentage = Double.valueOf(sTierPctAchieved).intValue() * KohlsPOCConstant.THOUSAND_INT;
										int iBuy = Double.valueOf(sTierActAchieved).intValue();
										if(Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
											iBuy = iBuy * KohlsPOCConstant.HUNDRED_INT;	
										}
										if(iBuy > 0 && iDiscountPercentage > 0) {
											recordEle.setAttribute(KohlsPOCConstant.A_DISC_PCT, String.valueOf(iDiscountPercentage));
											if(Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
												recordEle.setAttribute(KohlsPOCConstant.A_BUY_AMT, String.valueOf(iBuy));
											} else {
												recordEle.setAttribute(KohlsPOCConstant.A_BUY_QTY, String.valueOf(iBuy));
											}
										}
									}
								}
								//Manoj 10/08 - Updated for defect 5626 - End
									
								// Suresh :  Dec19 Setting promo start and End dates : Start
								
								this.setPromoStartAndEndDates(recordEle,awardEle);
								
								// Suresh :  Dec19 Setting promo start and End dates : Start

								this.addPromoAwardDescription(pluFileRecordEle, recordEle, awardEle, regularPrice);

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER_LINE, KohlsPOCConstant.YES);

								if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
									isPromoApplied = true;
									promoChargePerLineDbl = promoChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
								}

								//Sales Hub Clob	
								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

									// passing only the required objects to populate data, rest are sent as null.
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											modifierEle,  extnEle,  recordEle,  pluFileRecordEle,null,KohlsPOCConstant.PROMO);
								}

							}

							// Using to create Manual LID  Related Award 
							Map<String, Element> orderLineManualLidHM = promoObj.getOrderLineManualLidHM();
							if (orderLineManualLidHM.containsKey(guidStr)) { // AMOUNT_OFF, PERCENT_OFF

								Element promotionEle = orderLineManualLidHM.get(guidStr);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER_LINE, KohlsPOCConstant.YES);
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								String orderLinePromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								String description = null;
								String promotionDesc = null;

								if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {

									String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);

									if (YFCCommon.isStringVoid(overrideMaxAdjustment)) {
										overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
									}


									description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_LID_LINE_PROP_KEY);

									promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_LID_PROMO_DESC_PROP_KEY);

									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										isLidAmountApplied = true;
										lidAmountChargePerLineDbl = lidAmountChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}

								} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)) {

									Element prmotionExtnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
									String extnDiscountPercent = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

									if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
										String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
										description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_LID_LINE_PROP_KEY, args);

										promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_LID_PROMO_DESC_PROP_KEY, args);
										eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
									}

									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										isLidPercentApplied = true;
										lidPercentChargePerLineDbl = lidPercentChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}

								}

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderLinePromotionId); 

								//	 SALES HUB
								// Modification on 11-09 
								if (!XMLUtil.isVoid(prepareSalesHubClobObj)) {
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											modifierEle,  extnEle,  null,  pluFileRecordEle,null,promotionType) ;
									// End: 
								}	


							}

							// Using to create Price Override Related Award 							
							Map<String, Element> orderLinePromotionOverrideHM = promoObj.getOrderLinePromotionOverrideHM();
							if (orderLinePromotionOverrideHM.containsKey(guidStr)) { // KOHLS_OVERRIDE 700

								Element promotionEle = orderLinePromotionOverrideHM.get(guidStr);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER_LINE, KohlsPOCConstant.YES);
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								String orderLinePromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
								String description = KohlsPOCConstant.EMPTY;

								if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
									if(Double.valueOf(taxablePriceDelta).doubleValue() > KohlsPOCConstant.ZERO_DBL){
										description = KohlsPOCConstant.DOLLAR_MARKUP_DESC ;
										isPriceOverrideIncreasedApplied = true;
										priceOverrideIncChargePerLineDbl = priceOverrideIncChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}else{
										description = KohlsPOCConstant.DOLLAR_MARKDOWN_DESC ;
										isPriceOverrideApplied = true;
										priceOverrideChargePerLineDbl = priceOverrideChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}
								}
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderLinePromotionId); 

								// Sales Hub
								if (!XMLUtil.isVoid(prepareSalesHubClobObj)) {
									// Modified for Price Override
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											modifierEle,  extnEle,  null,  pluFileRecordEle,null,promotionType);
								}

							}

							// Using to create Offer Related Award 	
							Map<String, Element> orderPromotionHM = offerAndKohlsCashObj.getOrderCouponHM();
							// Gets few attributes from PLU Offer Response if it is not present in PLU Promo
							if (orderPromotionHM.containsKey(guidStr)) {
								Element promotionEle = orderPromotionHM.get(guidStr);
								// For Sales Hub
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								Element extnOfferEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN);
								String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);

								//Defect #911 Fix
								if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
									activePromotionGuidList.add(guidStr);
								}else if(!activePromotionGuidList.contains(guidStr)){
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
								}

								Element pluOfferResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnOfferEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
								List<Element> xstOfferEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR);

								List<Element> xstOfferSectEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_SECT);

								String description = null;
								String promotionDescription = null;
								String cusDesc = KohlsPOCConstant.EMPTY;
								if (xstOfferSectEleList.size() > KohlsPOCConstant.ZERO_INT){
									cusDesc =  ((Element) xstOfferSectEleList.get(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_CUSTFACG_SHRT_DESC);

									String[] args = {String.valueOf(cusDesc)};
									description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_LINE, args);

									String[] args2 = {cusDesc,orderPromotionId};
									promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_ORDER, args2);



									// Suresh :  Dec19 Setting offer start and End dates : Start
									KohlsPoCOrderPromotionsCaller.setOfferStartAndEndDates(pluOfferResposneEle, awardEle);
									// Suresh :  Dec19 Setting offer start and End dates : End 
									
								}
								//Get Offer Percentage  
								String percentOffValue = KohlsPOCConstant.EMPTY;
								List<Element> xstOfferBwpList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_BWP);
								if (xstOfferBwpList.size() > KohlsPOCConstant.ZERO_INT) {
									for (Element xstOfferBwpEle : xstOfferBwpList) {
										String bwpSelectionTypeCode =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_SELN_TYP_CDE);
										String tierLelNum =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_TIER_LVL_NBR);
										if(!YFCCommon.isStringVoid(tierLelNum) && !YFCCommon.isStringVoid(tierLevelAchieved) ){
											if (tierLelNum.equalsIgnoreCase(tierLevelAchieved) && KohlsPOCConstant.GET.equalsIgnoreCase(bwpSelectionTypeCode)) {
												percentOffValue =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT);
											}
										}
									}
								}

								if (!YFCCommon.isStringVoid(percentOffValue) && Double.valueOf(percentOffValue).doubleValue() > KohlsPOCConstant.ZERO_DBL) {

									String[] args = {cusDesc,percentOffValue};
									description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_PERCENT_LINE, args);

									String[] args2 = {cusDesc,orderPromotionId,percentOffValue};
									promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_PERCENT_ORDER, args2);

								} 

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId); 
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
								XMLUtil.setAttribute(extnOfferEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
								if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()){
									isOfferApplied = true;
									offerChargePerLineDbl = offerChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
								}

								//								 Sales Hub Clob
								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
									prepareSalesHubClobObj.prepareSalesHubData(pluOfferResposneEle,
											modifierEle, extnEle,  null,pluFileRecordEle, null,promotionType);
								}// End:



							}

							// Using to create Kohls Cash Related Award 							
							Map<String, Element> orderKohlsCashHM = offerAndKohlsCashObj.getOrderKohlsCashHM();
							if (orderKohlsCashHM.containsKey(guidStr)) {
								Element promotionEle = orderKohlsCashHM.get(guidStr);
								// For Sales Hub
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);

								Element extnKohlsResponseEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN);
								Element extnKohlsCashResposneEle =  null;
								extnKohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnKohlsResponseEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
								String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								
								//Added as part of TLD description changes for Sprint-8 --- Start
								String promotionIdForDesc =  orderPromotionId.substring((orderPromotionId.length())-KohlsPOCConstant.FIVE_INT);
								//Added as part of TLD description changes for Sprint-8 --- End
								
								List<Element> dataEleList = XMLUtil.getElementsByTagName(extnKohlsCashResposneEle, KohlsPOCConstant.E_DATA);
								if (dataEleList.size() > KohlsPOCConstant.ZERO_INT && null != dataEleList.get(KohlsPOCConstant.ZERO_INT)){
									Element dataElement = dataEleList.get(KohlsPOCConstant.ZERO_INT);
									String legacyDollar = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
									String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
									String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
									String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
									String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
									String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
									String authApprovalNum = dataElement.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);
									String description = null;
									String promotionDescription = KohlsPOCConstant.EMPTY;

									if(YFCCommon.isStringVoid(couponBalance)){
										couponBalance = KohlsPOCConstant.ZERO_STR;
									}

									double absTaxablePriceDelta = Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

									String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
									String extnCouponAmount = XMLUtil.getAttribute(extnKohlsResponseEle,KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
									


									if (KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
										if (!YFCCommon.isStringVoid(legacyDollar)) {

											legacyDollarChargePerLineDbl = legacyDollarChargePerLineDbl + absTaxablePriceDelta;
											isLegacyDollarApplied = Boolean.TRUE;

											if(!YFCCommon.isStringVoid(overrideMaxAdjustment)){
											
												String[] args = {twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))};
																								
												description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_LINE_PROP_KEY, args);
												
												// Start: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
											}
											
										//	String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))};
											
											if(!YFCCommon.isStringVoid(extnCouponAmount)){
												
												//Added as part of TLD description changes for Sprint-8 --- Start
												//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(extnCouponAmount)))};
												String[] args2 = {promotionIdForDesc};
												//Added as part of TLD description changes for Sprint-8 --- End
												
												// End: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
												promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_ORDER_PROP_KEY, args2);
											}

										} else if (!YFCCommon.isStringVoid(legacyPercent)) {

											String extnDiscountPercent = XMLUtil.getAttribute(extnKohlsResponseEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

											legacyPercentChargePerLineDbl = legacyPercentChargePerLineDbl + absTaxablePriceDelta;
											isLegacyPercentApplied = Boolean.TRUE;
											extnDiscountPercent = String.valueOf(Double.valueOf(Double.valueOf(extnDiscountPercent) * KohlsPOCConstant.HUNDRED_INT).intValue());

											
											String[] args = {extnDiscountPercent};
											
											
											
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_LINE_PROP_KEY, args);

											//Added as part of TLD description changes for Sprint-8 --- Start
											//String[] args2 = {orderPromotionId,extnDiscountPercent};
											String[] args2 = {extnDiscountPercent,promotionIdForDesc};
											//Added as part of TLD description changes for Sprint-8 --- End
											
											
											promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_ORDER_PROP_KEY, args2);

											//											// Added code to fix DiscountPercent for SalesHubClob Legacy Percent
											if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
												eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
											}
										}
									} else if (KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
											&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
											&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL) {

										kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + absTaxablePriceDelta;
										isKohlsCashApplied = Boolean.TRUE;

										if(!YFCCommon.isStringVoid(overrideMaxAdjustment)){
										
										
											String[] args = {String.valueOf(twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment))))};
																						
											
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_LINE_PROP_KEY, args);
											
											// Start: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
										}
											//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))};
											
											if(!YFCCommon.isStringVoid(extnCouponAmount)){
												
												//Added as part of TLD description changes for Sprint-8 --- Start
												//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(extnCouponAmount)))};
												String[] args2 = {promotionIdForDesc};
												//Added as part of TLD description changes for Sprint-8 --- End
												
												// End: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
										
											promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
										}
									}

									if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
										activePromotionGuidList.add(guidStr);
									}else if(!activePromotionGuidList.contains(guidStr)){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
									}

									XMLUtil.setAttribute(extnKohlsResponseEle, KohlsPOCConstant.A_EXTN_AUTH_RESPONSE_CODE, authResponseCode);
									XMLUtil.setAttribute(extnKohlsResponseEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE, couponBalance);
									XMLUtil.setAttribute(extnKohlsResponseEle, KohlsPOCConstant.A_EXTN_AUTH_APPROVAL_NUMBER, authApprovalNum);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId);
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT)); 

								}

								// Sales Hub
								if (!XMLUtil.isVoid(prepareSalesHubClobObj)) {
									prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
											null,pluFileRecordEle,null, promotionType) ;
									// End: 
								}	

							}


							// Using to create Manual TLD Related Award 							
							Map<String, Element> orderManualTldHM = offerAndKohlsCashObj.getOrderManualTldHM();
							if (orderManualTldHM.containsKey(guidStr)) {
								Element promotionEle = orderManualTldHM.get(guidStr);
								Element prmotionExtnEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
								Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
								if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
									activePromotionGuidList.add(guidStr);
								}else if(!activePromotionGuidList.contains(guidStr)){								
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
								}													

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								String description = KohlsPOCConstant.EMPTY;
								String promotionDesc  = KohlsPOCConstant.EMPTY;
								if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
									String overrideAdjustmentValue = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
									
									
									
									String[] args = {twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue)))};
									
									// Start: Defect 3284 Fix : Sathya, retrieving Manual Discount for promotion description
									String extnDiscount=XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT);
									
									//Added as part of TLD description changes for Sprint-8 --- Start
									//String[] args2 = {twoDForm.format(Math.abs(Double.valueOf(extnDiscount)))};
									String tldDolar = KohlsPOCConstant.TLD_DOLLAR_DESCRIPTION;
									String[] args2 = {tldDolar};
									//Added as part of TLD description changes for Sprint-8 --- End
									
									promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_ORDER_PROP_KEY, args2);
									// End: Defect 3284 Fix : Sathya, retrieving Manual Discount for promotion description
									
									description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_LINE_PROP_KEY, args);
	
									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										isTldAmountApplied = true;
										tldAmountChargePerLineDbl = tldAmountChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}
									
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);

								} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
									String extnDiscountPercent = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

									if (!YFCCommon.isStringVoid(extnDiscountPercent)) {

										String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
										//description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_LINE_PROP_KEY, args);
										//Fix for defect 2322 and 2333 - Start
										if(KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.QUICK_CREDIT_TLD_ORDER_PROP_KEY, args);
										}else{
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_LINE_PROP_KEY, args);
										}
										//Fix for defect 2322 and 2333 - End

										eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))) );
									}

									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										isTldPercentApplied = true;
										tldPercentChargePerLineDbl = tldPercentChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}
								}

								XMLUtil.setAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId); 
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT)); 

								//Sales Hub

								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
									prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
											null,pluFileRecordEle,null,promotionType) ;
								}	



							}

							// Using to create Senior Discount Related Award 							
							Map<String, Element> orderSeniorCitizenHM = offerAndKohlsCashObj.getOrderSeniorDiscountHM();
							if(orderSeniorCitizenHM.containsKey(guidStr)){
								Element promotionEle = orderSeniorCitizenHM.get(guidStr);
								if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
									activePromotionGuidList.add(guidStr);
								}else if(!activePromotionGuidList.contains(guidStr)){								
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
								}
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								Element extnPromotionEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
								String extnDiscountPercent = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
								
								
								
								String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
								
								
								
								String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROP_KEY, args);
								XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_DESCRIPTION,description);
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
								seniorCitizenChargePerLineDbl = seniorCitizenChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
								isSeniorCitizenApplied = Boolean.TRUE;

								// Added code to fix DiscountPercent for SalesHubClob Senior Discount
								if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
									eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
								}

								// Sales Hub
								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

									prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
											null,pluFileRecordEle,null,promotionType) ;
								}

							}

							Map<String, Element> orderOfflineKohlsCashHM = offerAndKohlsCashObj.getOrderOfflineKohlsCashHM();
							if(orderOfflineKohlsCashHM.containsKey(guidStr)){
								Element promotionEle = orderOfflineKohlsCashHM.get(guidStr);
								Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
								String promotionDescription =KohlsPOCConstant.EMPTY;
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								
								//Added for TLD Description for Sprint-8 --- Start
								String promotionIdForDesc =  orderPromotionId.substring((orderPromotionId.length())-KohlsPOCConstant.FIVE_INT);
								//Added for TLD Description for Sprint-8 --- End
								
								Element extnPromotionEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);

								kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

								double  absTaxablePriceDelta = Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

								String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);

								overrideMaxAdjustment = twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)));

								String[] args = {overrideMaxAdjustment};
								String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_LINE_PROP_KEY, args);
								// Start: Defect 3284 Fix : Sathya, retrieving ExtnCouponAmount for promotion description
								//String[] args2 = {orderPromotionId,overrideMaxAdjustment};
								String extnCouponAmount = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
								
								if(!YFCCommon.isStringVoid(extnCouponAmount)){
									
									//Added for TLD Description for Sprint-8 --- Start
									//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(extnCouponAmount)))};
									String[] args2 = {promotionIdForDesc};
									//Added for TLD Description for Sprint-8 --- End
									
									promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
								}
								// End: Defect 3284 Fix : Sathya, retrieving ExtnCouponAmount for promotion description
								if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
									activePromotionGuidList.add(guidStr);
								}else if(!activePromotionGuidList.contains(guidStr)){
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
								}

								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_DESCRIPTION,description);
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);

								//Logic for Calulating Coupon Balance
								//String extnCouponAmount = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
								String couponBalance = String.valueOf(Double.valueOf(extnCouponAmount) - Double.valueOf(overrideMaxAdjustment));
								XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,couponBalance);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT)); 


								isKohlsCashApplied = Boolean.TRUE;

								// Sales Hub
								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

									prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
											null,pluFileRecordEle,null,promotionType) ;
								}

							}

							// Using to create Associate  Related Award

							String empDiscCode = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_EMP_DISC_CDE);
							Map<String, String>  orderAssociateHM= offerAndKohlsCashObj.getOrderAssociateHM();							
							if(orderAssociateHM.containsKey(guidStr+KohlsPOCConstant.CONST_SOFT)||orderAssociateHM.containsKey(guidStr+KohlsPOCConstant.CONST_HARD)){
								//String discount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(guidStr)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
								
								//Added for defect 3945 fix -- Start
								
								String promotionID = null;
								String description = null;
								String discount = null;								
								String extnSeqNo = null;								
								
								String softDiscount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(guidStr+KohlsPOCConstant.CONST_SOFT)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
								String hardDiscount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(guidStr+KohlsPOCConstant.CONST_HARD)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
								
								Map<String, Element>  orderAssociateDisHM = offerAndKohlsCashObj.getOrderAssociateDisHM();	
								Element promotonEle = orderAssociateDisHM.get(guidStr);
								
								if (!YFCCommon.isVoid(promotonEle))
								{
									Element extnPromotionEle = XMLUtil.getChildElement(promotonEle,KohlsPOCConstant.E_EXTN);
									if (!YFCCommon.isVoid(extnPromotionEle))
									{
										extnSeqNo = XMLUtil.getAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE);
									}
								
									if(softDiscount.equals(hardDiscount))
									{
										promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE;
										XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
										discount = softDiscount;
										String[] args = {discount};
										description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);										
										XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_DESCRIPTION, description);
										if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
											XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											
											activePromotionGuidList.add(guidStr);
										}else if(!activePromotionGuidList.contains(guidStr)){								
											XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
										}
										Element extnPromotonEle = XMLUtil.getChildElement(promotonEle,KohlsPOCConstant.E_EXTN);
										if (!YFCCommon.isVoid(extnPromotonEle))
										{
										
										XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
										XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
										}
										offerAndKohlsCashObj.setOrderAssoDisHM(guidStr,promotonEle,KohlsPOCConstant.CONST_SOFT);
									}
									else if(!softDiscount.equals(hardDiscount))
									{
										
										if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_S)) && (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)))
										{
											promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE;
											XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
											discount = softDiscount;
											String[] args = {discount};
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);	
											XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_DESCRIPTION, description);
											String isSoftAssPromo = KohlsPOCConstant.NO;
											if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
												XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
												
												activePromotionGuidList.add(guidStr);
											}else if(!activePromotionGuidList.contains(guidStr)){								
												XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
											}
											Element extnPromotonEle = XMLUtil.getChildElement(promotonEle,KohlsPOCConstant.E_EXTN);
											if (!YFCCommon.isVoid(extnPromotonEle))
											{
											
											XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
											XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
											}
											XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(String.valueOf(softTLDImpVal)));
											offerAndKohlsCashObj.setOrderAssoDisHM(guidStr,promotonEle,KohlsPOCConstant.CONST_SOFT);	
										}
										else if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_H)) && (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)))
										{
											//create new promotion
											promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE;
											discount = hardDiscount;
											String[] args = {discount};
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);
											
											String isHardAssPromo = KohlsPOCConstant.NO;
											
											
												Element promotionsEle =  XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_PROMOTIONS);
																							
												if (!YFCCommon.isVoid(promotionsEle))
												{
													Element extnPromotonEle = XMLUtil.getChildElement(promotonEle,KohlsPOCConstant.E_EXTN);
													if(!YFCCommon.isVoid(extnPromotonEle))
													{
														String promotionFlag = XMLUtil.getAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
															logger.debug("promotionFlag ::::" + promotionFlag);
														if(YFCCommon.isStringVoid(promotionFlag) && !(isSoftDisItemAvail.equals(KohlsPOCConstant.YES)))
														{
															logger.debug(":::: Condition true ::::");
															//remove existing promotion element -- Start
															List<Element> orderPromotionList = XMLUtil
																	.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
															if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) 
															{
																for (Element promotionEle : orderPromotionList) 
																{
																	String promotonType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
																	String promoID = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
																	
																	//Changed the constant in below line
																	if(promotonType.equals(KohlsPOCConstant.ASSOCIATE_DISCOUNT))
																	{
																			XMLUtil.removeChild(promotionsEle, promotionEle);
																		}
																}
															}
																		//remove existing promotion element -- End
															
															
														}
													}
													
													Element newPromotion = XMLUtil.createChild(promotionsEle,KohlsPOCConstant.E_PROMOTION);
													XMLUtil.setAttribute(newPromotion, "IsInternal", KohlsPOCConstant.YES);
													XMLUtil.setAttribute(newPromotion, "PromotionGroup", "MANUAL");
													XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT);
													Element extnPromoEle = XMLUtil.getChildElement(newPromotion,KohlsPOCConstant.E_EXTN,Boolean.TRUE);								
													XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, extnSeqNo);
													Element tempEle = XMLUtil.getChildElement(newPromotion,KohlsPOCConstant.E_TEMP,Boolean.TRUE);
													XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_GUID, guidStr);
													
													XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
													XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_DESCRIPTION, description);
													
													if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
														XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
														
														activePromotionGuidList.add(guidStr);
													}else if(!activePromotionGuidList.contains(guidStr)){								
														XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
													}
													
													XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(String.valueOf(hardTLDImpVal)));
													
													
													if (!YFCCommon.isVoid(extnPromoEle))
													{
													
													XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
													XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
													}
													
													
													offerAndKohlsCashObj.setOrderAssoDisHM(guidStr,newPromotion,KohlsPOCConstant.CONST_HARD);
												}
											
										}
										
									}
									
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID, promotionID);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
									
								associateDiscountChargePerLineDbl =  associateDiscountChargePerLineDbl+ Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
								isAssociateDiscountApplied = Boolean.TRUE;
								
							  }
								
								//Added for defect 3945 fix -- End
								
								//Commented below code for defect 3945 fix -- start
								/*String discount = null;
								if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_S))){
									discount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(guidStr+KohlsPOCConstant.CONST_SOFT)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
								}
								else{
									discount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(guidStr+KohlsPOCConstant.CONST_HARD)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
								}

								associateDiscountChargePerLineDbl =  associateDiscountChargePerLineDbl+ Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
								String[] args = {discount};
								String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
								isAssociateDiscountApplied = Boolean.TRUE;
								
								//Added for 3945 defect fix --- Start
								Map<String, Element>  orderAssociateDisHM = offerAndKohlsCashObj.getOrderAssociateDisHM();	
								Element promotonEle = orderAssociateDisHM.get(guidStr);
								if (!YFCCommon.isVoid(promotonEle))
								{
								if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
									XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
									activePromotionGuidList.add(guidStr);
								}else if(!activePromotionGuidList.contains(guidStr)){								
									XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
								}
								XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_DESCRIPTION, description);
								//setting below attributes in Award element -- Start
								String orderPromotionId = XMLUtil.getAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_ID);									
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
								XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
								//setting below attributes in Award element -- End
								
								Element extnPromotonEle = XMLUtil.getChildElement(promotonEle,KohlsPOCConstant.E_EXTN);
								if (!YFCCommon.isVoid(extnPromotonEle))
								{
								
								XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
								XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
								}
								
								
								}*/
								//Added for 3945 defect fix --- End
								//Commented below code for defect 3945 fix -- End

								// Sales Hub
								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

									prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
											null,pluFileRecordEle,null,KohlsPOCConstant.ASSOCIATE_DISCOUNT,discount) ;
								}

							}

							if(!XMLUtil.isVoid(awardExtEle) && !XMLUtil.isVoid(salesHubDoc)){
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(salesHubDoc));
							}	

							//Fix for 1833, 1816 and 1817
							if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
								if(Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) == KohlsPOCConstant.ZERO_DBL){
									if(isItemLevelPromo){
										XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.YES);
									}else{
										XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.NO);
									} 
								}else{
									XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.YES);
								}
							}
							
							NodeList nlAward = orderLineEle.getElementsByTagName("Award");
							/*NodeList nlAward = ((NodeList)XPathUtil.getNodeList(orderEle, "/Order/OrderLines/OrderLine[@OrderLineKey='"
											+orderLineEle.getAttribute("OrderLineKey")+"']/Awards/Award[Action='Remove']"));*/
							if(nlAward.getLength()>0){
								logger.beginTimer("KohlsPoCPrepareUEResponse.XMLDiff");
								for(int x=0; x<nlAward.getLength(); x++){
									Element eleAward_temp = (Element) nlAward.item(x);
									String sAction = eleAward_temp.getAttribute(KohlsPOCConstant.A_ACTION);
									if(!YFCCommon.isVoid(sAction) && sAction.equalsIgnoreCase(KohlsPOCConstant.REMOVE)){
										//Defect 1118 - Start
										Element eleExtnAward_temp = XMLUtil.getChildElement(eleAward_temp, KohlsPOCConstant.E_EXTN);
										String sOldAwardSequence = XMLUtil.getAttribute(eleExtnAward_temp, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE);
										Element awardExtnEle =  XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN);
										String sCurrentAwardSequence = XMLUtil.getAttribute(awardExtnEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE);
										if(YFCCommon.isVoid(sOldAwardSequence)){
											sOldAwardSequence="";
										}
										if(YFCCommon.isVoid(sCurrentAwardSequence)){
											sCurrentAwardSequence="";
										}
										//Defect 1118 - End
										
										String sOldAwardAmount = eleAward_temp.getAttribute("AwardAmount");
										if(YFCCommon.isVoid(sOldAwardAmount)){
											sOldAwardAmount="";
										}
										String sOldAwardApplied = eleAward_temp.getAttribute("AwardApplied");
										if(YFCCommon.isVoid(sOldAwardApplied)){
											sOldAwardApplied="";
										}
										String sOldDescription = eleAward_temp.getAttribute("Description");
										if(YFCCommon.isVoid(sOldDescription)){
											sOldDescription="";
										}
										String sOldPromotionId = eleAward_temp.getAttribute("PromotionId");
										if(YFCCommon.isVoid(sOldPromotionId)){
											sOldPromotionId="";
										}
										
										String sCurrentAwardAmount = awardEle.getAttribute("AwardAmount");
										if(YFCCommon.isVoid(sCurrentAwardAmount)){
											sCurrentAwardAmount="";
										}
										String sCurrentAwardApplied = awardEle.getAttribute("AwardApplied");
										if(YFCCommon.isVoid(sCurrentAwardApplied)){
											sCurrentAwardApplied="";
										}
										String sCurrentDescription = awardEle.getAttribute("Description");
										if(YFCCommon.isVoid(sCurrentDescription)){
											sCurrentDescription="";
										}
										String sCurrentPromotionId = awardEle.getAttribute("PromotionId");
										if(YFCCommon.isVoid(sCurrentPromotionId)){
											sCurrentPromotionId="";
										}
										//Defect 1118 - added awardSequence check
										if(sOldAwardAmount.equalsIgnoreCase(sCurrentAwardAmount) && sOldAwardApplied.equalsIgnoreCase(sCurrentAwardApplied)
												&& sOldDescription.equalsIgnoreCase(sCurrentDescription) && sOldPromotionId.equalsIgnoreCase(sCurrentPromotionId)
												&& sOldAwardSequence.equalsIgnoreCase(sCurrentAwardSequence)){
												awardsEle.removeChild(eleAward_temp);
												awardsEle.removeChild(awardEle);
												break;
										}
									}
								}
								logger.endTimer("KohlsPoCPrepareUEResponse.XMLDiff");
							}
						}




						//Based on the Flag value Line Change Element is created.
						if (isPromoApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.SKU, lineChargeEle, promoChargePerLineDbl);
						}
						if (isOfferApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.OFFER, lineChargeEle, Math.abs(offerChargePerLineDbl));
						}
						if (isTldAmountApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.TLD_AMOUNT_OFF, lineChargeEle, Math.abs(tldAmountChargePerLineDbl));
						}
						if (isTldPercentApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.TLD_PERCENT_OFF, lineChargeEle, Math.abs(tldPercentChargePerLineDbl));
						}
						if (isLegacyDollarApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LEGACY_DOLLAR, lineChargeEle, Math.abs(legacyDollarChargePerLineDbl));
						}
						if (isLegacyPercentApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LEGACY_PERCENT, lineChargeEle, Math.abs(legacyPercentChargePerLineDbl));
						}
						if (isKohlsCashApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.KOHLS_CASH_DESC, lineChargeEle, Math.abs(kohlsCashChargePerLineDbl));
						}

						if (isLidAmountApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LID_AMOUNT_OFF, lineChargeEle, Math.abs(lidAmountChargePerLineDbl));
						}
						if (isLidPercentApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LID_PERCENT_OFF, lineChargeEle, Math.abs(lidPercentChargePerLineDbl));
						}

						if (isPriceOverrideApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.PRICE_OVERRIDE, lineChargeEle, Math.abs(priceOverrideChargePerLineDbl));
						}

						if (isPriceOverrideIncreasedApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.PRICE_OVERRIDE_INCREASED, lineChargeEle, Math.abs(priceOverrideIncChargePerLineDbl));
						}

						if(isSeniorCitizenApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							setLineChargeValues(KohlsPOCConstant.SENIOR_CITIZEN,lineChargeEle,Math.abs(seniorCitizenChargePerLineDbl));
						}

						// AssociateDiscount
						if(isAssociateDiscountApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							setLineChargeValues(KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE,lineChargeEle,Math.abs(associateDiscountChargePerLineDbl));
						}

					}


					//					Rebate Information for Sales Hub
					List<Element> awardEleList = XMLUtil.getElementsByTagName(awardsEle, KohlsPOCConstant.E_AWARD);
					if (!YFCCommon.isVoid(awardEleList) && awardEleList.size() > KohlsPOCConstant.ZERO_INT){
						for(Element awardEle : awardEleList){
							Element awardExtEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN);
							String rebateResponseStr = XMLUtil.getAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_REBATE_RESPONSE);
							if(!YFCCommon.isStringVoid(rebateResponseStr)){
								Element rebateResponseEle = KohlsPoCPnPUtil.createElementFromXMLString(rebateResponseStr);
								List<Element> recordEleList= XMLUtil.getElementsByTagName(rebateResponseEle, KohlsPOCConstant.E_RECORD);
								if(recordEleList.size() > KohlsPOCConstant.ZERO_INT){
									String rebateInfcId =  recordEleList.get(KohlsPOCConstant.ZERO_INT).getAttribute(KohlsPOCConstant.A_SYS_OF_REC_ID);
									Document salesHubDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DATA);
									Element eleData = salesHubDoc.getDocumentElement();
									// Creating an instance of KohlsPocPrepareSalesHubClob

									KohlsPoCPrepareSalesHubClob prepareSalesHubClobObj = new KohlsPoCPrepareSalesHubClob(eleData, awardExtEle);
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											null,  extnEle,  null,  pluFileRecordEle,rebateInfcId,KohlsPOCConstant.REBATE);


									XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(salesHubDoc));
								}
							}
						}
					}


					double clearanceAmtCalc = KohlsPOCConstant.ZERO_DBL;

					// Suresh : Defect fix 3423, if LOC_SKU_STAT_CDE is 30, we need to calculate TotalSavings : Start
					
					if(!(YFCCommon.isVoid(skuStatusCode)) && ("30".equals(skuStatusCode))){
						
						if(nonClearanceAmtDbl > orderLineUnitPriceDbl){
							clearanceAmtCalc = nonClearanceAmtDbl - orderLineUnitPriceDbl;
						}
						
					}
					
					// Suresh : Defect fix 3423, if LOC_SKU_STAT_CDE is 30, we need to calculate TotalSavings : End
					
					
					
					

					totalDiscount = clearanceAmtCalc + promoChargePerLineDbl + offerChargePerLineDbl+ tldAmountChargePerLineDbl + tldPercentChargePerLineDbl
							+ legacyDollarChargePerLineDbl + legacyPercentChargePerLineDbl + kohlsCashChargePerLineDbl + lidPercentChargePerLineDbl
							+ lidAmountChargePerLineDbl + priceOverrideChargePerLineDbl + seniorCitizenChargePerLineDbl + associateDiscountChargePerLineDbl;
							//-priceOverrideIncChargePerLineDbl;

					/*if(totalDiscount < Double.valueOf(KohlsPOCConstant.ZERO_DBL))
					{
						totalDiscount = KohlsPOCConstant.ZERO_DBL;
					}*/
					totalSaving = totalSaving + totalDiscount ;

					KohlsPoCPnPUtil.addTaxableAmountInTempElement(orderLineEle);
				}

			}

		}



		Element extnOrder = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TOTAL_SAVINGS, String.valueOf(totalSaving));
		
		
		KohlsPoCGenerateExtnPromoSequence.generateExtnPromoSequence(orderEle, apeResponseEle);
		
		logger.endTimer("KohlsPoCPrepareUEResponse.updateUeDocumentFromApeResponse");
	}



	/**
	 * 
	 * Based on the LookUpType parameter value , Chargecategory and ChargeName 
	 * 
	 * @param lookUpTye
	 * @param lineChargeEle
	 * @param chargePerLine
	 */

	private void setLineChargeValues(String lookUpTye, Element lineChargeEle, double chargePerLine) {

		logger.beginTimer("KohlsPoCPrepareUEResponse.setLineChargeValues");
		chargePerLine = Math.abs(chargePerLine);
		XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_CHARGE_PER_LINE, KohlsPoCPnPUtil.getDouble(String.valueOf(chargePerLine)));
		XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_BILLABLE, KohlsPOCConstant.YES);
		XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.YES);

		if (KohlsPOCConstant.SKU.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.PROMO_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.PROMO_DISCOUNT);
		} else if (KohlsPOCConstant.OFFER.equals(lookUpTye) || KohlsPOCConstant.OFFER_DISCOUNT.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.OFFER_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.OFFER_DISCOUNT);
		} else if (KohlsPOCConstant.TLD_AMOUNT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_TLD);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.TLD_AMOUNT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.TLD_PERCENT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_TLD);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.TLD_PERCENT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.LEGACY_DOLLAR.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.KOHLS_CASH_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LEGACY_DOLLAR);
		} else if (KohlsPOCConstant.LEGACY_PERCENT.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.KOHLS_CASH_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LEGACY_PERCENT);
		} else if (KohlsPOCConstant.KOHLS_CASH_DESC.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.KOHLS_CASH_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.KOHLS_CASH_DESC);
		} else if (KohlsPOCConstant.LID_AMOUNT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_LID);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LID_AMOUNT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.LID_PERCENT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_LID);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LID_PERCENT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.PRICE_OVERRIDE.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.PRICE_OVER_RIDE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.PRICE_OVER_RIDE_LINE_CHARGE);
		} else if (KohlsPOCConstant.PRICE_OVERRIDE_INCREASED.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.PRICE_OVER_RIDE_INCREASE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.PRICE_OVER_RIDE_INCREASE_LINE_CHARGE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.NO);
		} else if(KohlsPOCConstant.SENIOR_CITIZEN.equals(lookUpTye)){
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.SENIOR_CITIZEN);
		} else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE.equals(lookUpTye)){
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.ASSOCIATE_DISCOUNT_CHARGE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.ASSOCIATE);
		}


		logger.endTimer("KohlsPoCPrepareUEResponse.setLineChargeValues");
	}

	/**
	 * Promo Related award description are constructed  and added in the Award Element
	 * 
	 * @param pluFileRecordEle
	 * @param recordEle
	 * @param awardEle
	 * @param regularPrice
	 * @param bogoSetId
	 */
	private void addPromoAwardDescription(Element pluFileRecordEle, Element recordEle, Element awardEle, String regularPrice) {	
		logger.beginTimer("KohlsPoCPrepareUEResponse.addPromoAwardDescription");
		String promoSchemeCode = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE);
		String rcpttxt = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_RCPT_CMMT_TXT);

		StringBuffer descriptionStrBfr = new StringBuffer();
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);

		//Award Description for 'Gift with Purchase' , 'Gold star' are handled by Toshiba //Group Pricing Sub-Line
		if (Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode)) || Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PROMO).equals(Integer.valueOf(promoSchemeCode))) { 
			String groupRetailAmt = twoDForm.format(Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT)) / KohlsPOCConstant.HUNDRED_INT);
			descriptionStrBfr.append(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO))
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.FOR_$)
			.append(groupRetailAmt);
			//The word - Eligible is appended by Toshiba for awards applied = 'N'. //Tier Buy Doller Get % Promotion Sub-line 
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) {
			String discountPercentage = String.valueOf(Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_PCT)).intValue() / KohlsPOCConstant.THOUSAND_INT);
			descriptionStrBfr.append(rcpttxt)
			.append(KohlsPOCConstant.SPACE)
			.append(discountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.	 
			//Tier Buy Qty Get % Promotion Sub-line
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) { 
			String discountPercentage = String.valueOf(Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_PCT)).intValue() / KohlsPOCConstant.THOUSAND_INT);
			descriptionStrBfr.append(rcpttxt)
			.append(KohlsPOCConstant.SPACE)
			.append(discountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.	 //BOGO Buy Qty Get Price Point Promotion Sub-line  
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PRICE_POINT).equals(Integer.valueOf(promoSchemeCode))) {
			String discountAmount = twoDForm.format(Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT)) / KohlsPOCConstant.HUNDRED_INT);
			//For Bogo grouping, BOGO set ID# fetched from APE REsponse : Transaction\ItemList\Item\BogoGrpCode

			descriptionStrBfr.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO))		
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(discountAmount);

			//				The word - Eligible is appended by Toshiba for awards applied = 'N'.//BOGO Buy Qty Get % Promotion Sub-line	 
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) { 
			String discountPercentage = String.valueOf(Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_PCT)).intValue() / KohlsPOCConstant.THOUSAND_INT);
			//For Bogo grouping, BOGO set ID# fetched from APE REsponse : Transaction\ItemList\Item\BogoGrpCode
			descriptionStrBfr.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO))	
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(discountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.
			//BOGO Buy Qty Get Free Promotion Sub-line
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_GET_FREE).equals(Integer.valueOf(promoSchemeCode))) {
			//For Bogo grouping, BOGO set ID# fetched from APE REsponse : Transaction\ItemList\Item\BogoGrpCode
			descriptionStrBfr.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO))
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.FREE);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.	 
		} else if (Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_HUNDRED).equals(Integer.valueOf(promoSchemeCode)) || 
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_HUNDRED_ONE).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED_ONE).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED_THREE).equals(Integer.valueOf(promoSchemeCode)) 

				) {
			descriptionStrBfr.append(KohlsPOCConstant.PROMO_DISCOUNT_DESC);
		}

		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, descriptionStrBfr.toString());
		logger.endTimer("KohlsPoCPrepareUEResponse.addPromoAwardDescription");
	}
	
	/**
	 * 
	 * Method Name : setPromoStartAndEndDates Description : This method sets
	 * Promo Start Date Time and End Date time on Awards/Award/Extn 
	 * 
	 * @param recordEle
	 *            recordEle holds the PLU response
	 * @param awardEle
	 *            awardEle of OrderLines/OrderLine/Awards/Award
	 * 
	 */
	private void setPromoStartAndEndDates(Element recordEle,Element awardEle) {
		
		logger.endTimer("KohlsPoCPrepareUEResponse.setPromoStartAndEndDates");
		
		String actualStartDate = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_STRT_DATE);
		String actualStartTime = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_STRT_TIME);
		
		String actualEndDate = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_END_DATE);
		String actualEndTime = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_END_TIME);
		
		Element awardExtEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		
		String extnActualStartDateTime = KohlsPOCConstant.EMPTY;
		String extnActualEndDateTime = KohlsPOCConstant.EMPTY;
		
		
		if(!YFCCommon.isVoid(actualStartDate)){
			extnActualStartDateTime = actualStartDate;
			if(!YFCCommon.isVoid(actualStartTime)){
				extnActualStartDateTime = extnActualStartDateTime.concat(" ").concat(actualStartTime);
			}
		}
		
		if(!YFCCommon.isVoid(actualEndDate)){
			extnActualEndDateTime = actualEndDate;
			if(!YFCCommon.isVoid(actualEndTime)){
				extnActualEndDateTime = extnActualEndDateTime.concat(" ").concat(actualEndTime);
			}
			
		}
		XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.E_EXTN_START_DATE, extnActualStartDateTime);
		XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.E_EXTN_END_DATE, extnActualEndDateTime);
		
		logger.endTimer("KohlsPoCPrepareUEResponse.setPromoStartAndEndDates");
		
	}


}
