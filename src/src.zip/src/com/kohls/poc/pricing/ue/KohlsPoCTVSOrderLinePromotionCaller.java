package com.kohls.poc.pricing.ue;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : KohlsPoCTVSOrderLinePromotionsCaller.java 
 * Author : IBM 
 * Created : July 15 2015 
 * Modified : July 15 2015 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 15/07/2015 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2015. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * PLU call made for getting Rebate Response.
 * Voided and Non Voided Items are differenciated and seperate LinkedHashMap is maintained for 
 * All the Promo information are kept in different LinkedHashMap
 * All the Order Line keys are kept in seperate LinkedHashMap which will be used for TaxWare
 * For Manual LID and Price Over Ride using same LinkedHashMap is used
 * 
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCTVSOrderLinePromotionCaller {
	
	private Map<String, Element> orderLineHM;
	private Map<String, Element> orderLineVoidedHM;	
	private Map<String, String> itemIdHM;
	private Map<String, String> orderLineKeyHM;
	private Map<String, Element> orderLineLLDHM;
	//PST-1895 - Start
	private Map<String, Element> cacheRebateHM;
	//PST-1895 - ENd
	
	public KohlsPoCTVSOrderLinePromotionCaller() {
		this.orderLineHM = new LinkedHashMap<String, Element>();
		this.orderLineVoidedHM = new LinkedHashMap<String, Element>();		
		this.itemIdHM = new LinkedHashMap<String, String>();
		this.orderLineKeyHM = new LinkedHashMap<String, String>();
		this.orderLineLLDHM = new LinkedHashMap<String, Element>();
		//PST-1895 - Start
		this.cacheRebateHM = new LinkedHashMap<String, Element>();
		//PST-1895 - ENd
		
	}
	
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCOrderLinePromotionsCaller.class.getName());
	}
	
	
	
	/**
	 * This method is called by KohlsPoCTVSOrderRepriceUE for handling the Order Line Level Promotions
	 * If it is a Item, putting details in LinkedHashMap.
	 *     
	 * @param orderLineList
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param createtsList
	 * @throws Exception
	 * 
	 */
	
	public  String updateUeDocumentForPromo ( List<Element> orderLineList, YFSEnvironment yfsEnv, Element tempOrderEle, List<String> createtsList)
			throws Exception {
				logger.beginTimer("KohlsTVSPoCOrderLinePromotionsCaller.updateUeDocumentForPromo");

				this.logger.debug("Method Name : updateUeDocumentForPromo   and   Status  ");
				
				String extnRequestDateTime = KohlsPoCPnPUtil.getExtnRequestTime(tempOrderEle);
				String voidTaxWare = KohlsPOCConstant.NO;
				int i=KohlsPOCConstant.LLD_ID;
				int j=KohlsPOCConstant.ONE_INT;
				//PST-3294 - Start
				String extnIsPriceEntered = "";
				String unitPriceStr = "";
				//PST-3294 - End
				//PST-4465 - Start
				Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
				String sExtnPsaStatus = XMLUtil.getAttribute(eleOrderExtn, KohlsPOCConstant.EXTN_PSA_STATUS);
				//PST-4465- End
				for (Element orderLine : orderLineList) {
					String orderedQty = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);
					Element itemElement = XMLUtil.getChildElement(orderLine,KohlsPOCConstant.E_ITEM);
					String itemId = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.A_ITEM_ID);
					
					String primeLineNo = XMLUtil.getAttribute(orderLine, "PrimeLineNo");
					
					if(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(itemId)){
						voidTaxWare = KohlsPOCConstant.YES;
						 
					}
										
					if (0.00D == Double.parseDouble(orderedQty)) {
						orderLine = setAwardAppliedN(orderLine);
						this.orderLineVoidedHM.put(primeLineNo, orderLine);
					}
					
					else {
						//Added below stmt for resetting Awards and LineCharges 
						//New method for defect 1078, PST-4465 - Added ExtnPsaStatus parameter
						KohlsPoCPnPUtil.resetOrderLineDetailsForTVS(orderLine, sExtnPsaStatus);  
						Element tempEle =  XMLUtil.createChild(orderLine, KohlsPOCConstant.E_TEMP);
						XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, primeLineNo);
						
						
						
						this.orderLineHM.put(primeLineNo, orderLine);
						String orderLineKey = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
						this.orderLineKeyHM.put(orderLineKey, primeLineNo);
					}

					String isSuspendedOrderLine = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.CONDITION_VARIABLE_TWO); 
					if (!KohlsPOCConstant.YES.equalsIgnoreCase(isSuspendedOrderLine)) {
						this.itemIdHM.put(itemId, primeLineNo);
					}
					Element promotionsEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_PROMOTIONS);

					if (!YFCCommon.isVoid(promotionsEle)) {
						promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
					}

					//For Price Override and Manual LID
					List<Element> linePromotionList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_PROMOTION);
					//PST-3294 - Start
					Element extnEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_EXTN);
					Element linePriceInfoEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
					//PST-3294 - End
					if (linePromotionList.size() > KohlsPOCConstant.ZERO_INT &&  0.00D < Double.parseDouble(orderedQty)) {
						for (Element linePromotionEle : linePromotionList) {
							//PST-3294 - Start
							String promotionType = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
							if(promotionType.equalsIgnoreCase(KohlsPOCConstant.PRICE_OVERRIDE)){
								extnIsPriceEntered = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);
								unitPriceStr = XMLUtil.getAttribute(linePriceInfoEle,KohlsPOCConstant.A_UNIT_PRICE);
								if(extnIsPriceEntered.equalsIgnoreCase(KohlsPOCConstant.YES) && 
										unitPriceStr.equalsIgnoreCase(KohlsPOCConstant.ZERO_STR)){
									throw new YFSException(KohlsPOCConstant.PC_For_ZeroPricePrompt_Message,KohlsPOCConstant.PC_For_ZeroPricePrompt_Error_Code,
											KohlsPOCConstant.PC_For_ZeroPricePrompt_Error_Desc);
								}if(!extnIsPriceEntered.equalsIgnoreCase(KohlsPOCConstant.YES) && 
										unitPriceStr.equalsIgnoreCase(KohlsPOCConstant.ZERO_STR)){
									throw new YFSException(KohlsPOCConstant.PC_For_FreeItem__Message,KohlsPOCConstant.PC_For_FreeItem_Error_Code,
											KohlsPOCConstant.PC_For_FreeItem_Error_Desc);
								}
							}
							//PST-3294 - End
							String orderLinPromId = (String)(Integer.toString(i+j));
							logger.debug("orderLinPromId for LIDs"+orderLinPromId);
							j=j+1;							
							String createts = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_CREATE_TS);
							Element tempEle =  XMLUtil.createChild(linePromotionEle, KohlsPOCConstant.E_TEMP);
							XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, orderLinPromId);
							orderLineLLDHM.put(orderLinPromId, linePromotionEle);
							createtsList.add(createts);

						}
					}
				}
				
				
	//logger.debug("TVSOrderLinePromotionCaller -- voidTaxWare"+voidTaxWare);
	logger.endTimer("KohlsTVSPoCOrderLinePromotionsCaller.updateUeDocumentForPromo");
	return voidTaxWare;
	
	}
	
	/**
	 * 
	 * @return orderLineHM
	 */
	public Map<String, Element> getOrderLineHM() {
		return this.orderLineHM;
	}

	/**
	 * 
	 * @return orderLineKeyHM
	 */
	public Map<String, String> getOrderLineKeyHM() {
		return this.orderLineKeyHM;
	}

	/**
	 * 
	 * @return orderLineManualLidHM
	 */
	public Map<String, Element> getOrderLineLLDHM() {
		return this.orderLineLLDHM;
	}

	//PST-1895 - Start
	/**
	 * 
	 * @return orderLineManualLidHM
	 */
	public Map<String, Element> getCacheRebateHM() {
		return this.cacheRebateHM;
	}
	//PST-1895 - ENd
	
	public void cleanUp(){
		this.orderLineHM = null;
		this.orderLineVoidedHM = null;		
		this.itemIdHM = null;
		this.orderLineKeyHM = null;		
		this.orderLineLLDHM = null;
		//PST-1895 - Start
		this.cacheRebateHM = null;
		//PST-1895 - ENd
	}
	
	
	/**
	 * PLU Response has the Rebate Promo ( Promo Scheme Code is 0700), Rebate web service call is made. 
	 * Response is stored in the OrderLine level Award element as a CLOB
	 * @param yfsEnv
	 * @param rebateId
	 * @param orderLineEle
	 * @throws Exception
	 */
	//Adding Req Date and ShipNode for defect 1078
	public void verifyRebateDiscount(YFSEnvironment yfsEnv, String rebateId, Element orderLineEle, String extnRequestDateTime, String shipNode) throws Exception {		logger.beginTimer("KohlsPoCTVSOrderLinePromotionsCaller.verifyRebateDiscount");
		this.logger.debug("Method Name : verifyRebateDiscount   and   Status  ");
		
		try{
		
			Document rebatePluInputDoc = XMLUtil.createDocument(KohlsPOCConstant.PLU_MESSAGE);
			Element rebatePluInputEle = rebatePluInputDoc.getDocumentElement();
			XMLUtil.setAttribute(rebatePluInputEle, KohlsPOCConstant.A_TYPE_PLU, KohlsPOCConstant.PLU);
			XMLUtil.setAttribute(rebatePluInputEle, KohlsPOCConstant.A_CONTENT, KohlsPOCConstant.PLU);
			XMLUtil.setAttribute(rebatePluInputEle, KohlsPOCConstant.A_TYPE_REQUEST, KohlsPOCConstant.REQUEST);
			XMLUtil.setAttribute(rebatePluInputEle, KohlsPOCConstant.A_FRAME, "");

			Element componentEle = XMLUtil.createChild(rebatePluInputEle,
			KohlsPOCConstant.E_COMPONENT);
			Element parametersEle = XMLUtil.createChild(componentEle,
			KohlsPOCConstant.E_PARAMETERS);
			
			XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_LOOKUPTYPE, KohlsPOCConstant.FORM);
			XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_KEY, rebateId);
			//Fix for defect 1078 - Start
			//Manoj 01/28: Pre-padding the store no for PLU call. - Start
			XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_STORE, KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode));
			//Manoj 01/28: Pre-padding the store no for PLU call. - End
			XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_TRAN_DATE_TIME, extnRequestDateTime);
			//Fix for defect 1078 - End
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			this.logger.debug(XMLUtil.getElementXMLString(rebatePluInputEle));
			
			this.logger.debug(XMLUtil.getXMLString(rebatePluInputDoc));
			}
			//Performance improvement changes - End
			Document rebatePLUResponseDoc = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_PLU_WEB_SERVICE,rebatePluInputDoc);
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			this.logger.debug(XMLUtil.getXMLString(rebatePLUResponseDoc));
			}
			//Performance improvement changes - End
			Element rebatePLUResponseEle = rebatePLUResponseDoc.getDocumentElement();

			KohlsPoCPnPUtil.validatePluResponse(rebatePLUResponseEle);
			
			List<Element> formEleList = XMLUtil.getElementsByTagName(rebatePLUResponseEle, KohlsPOCConstant.FORM);

			if(formEleList.size() > KohlsPOCConstant.ZERO_INT){
				rebatePLUResponseEle = formEleList.get(KohlsPOCConstant.ZERO_INT);
			}

			this.createAwardElementforRebate(rebatePLUResponseEle, orderLineEle);
			
			
		}
			catch(Exception e){
			e.printStackTrace();
			if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

				YFSException yfsException = new YFSException();
				YFSException es = (YFSException) e;

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
					yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
				}

				// IO Exception
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
					yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
				}

				// Other Exceptions
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
					yfsException.setErrorCode(KohlsPOCConstant.PLUSERVDOWN);
					yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
				}	
				else{
					throw es;
				}
				throw yfsException;
			}
			else{
				throw e;
			}			
		}
		this.logger.debug("Method Name : verifyRebateDiscount   and   Status  ");
		logger.endTimer("KohlsPoCTVSOrderLinePromotionsCaller.verifyRebateDiscount");

	}

	/**
	 * This method is helpful for create the Award Element with the Rebate Response CLOB column
	 * @param rebateResponseDoc
	 * @param orderLineEle
	 */
	 // Changing this method to public for defect 1078
	public void createAwardElementforRebate(Element rebateResponseEle, Element orderLineEle) {
		logger.beginTimer("KohlsPoCTVSOrderLinePromotionsCaller.createAwardElementforRebate");

		this.logger.debug("Method Name : createAwardElementforRebate   and   Status  ");
		Element awardsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, Boolean.TRUE);
		Element awardEle = XMLUtil.createChild(awardsEle, KohlsPOCConstant.E_AWARD);
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, KohlsPOCConstant.REBATE_ITEM);
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
		Element extnEle = XMLUtil.createChild(awardEle, KohlsPOCConstant.E_EXTN);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_REBATE_RESPONSE, XMLUtil
				.getElementXMLString(rebateResponseEle));
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMO_SCHEME,KohlsPOCConstant.PROMO_REBATE);		
		this.logger.debug("Method Name : createAwardElementforRebate   and   Status  ");
		logger.endTimer("KohlsPoCTVSOrderLinePromotionsCaller.createAwardElementforRebate");


	}
	
	/**
	 * This method is helpful to create the Award Element by stamping rebate id 
	 * in the ExtnRebateReference attribute for Release 2 
	 * @param rebateResponseDoc
	 * @param orderLineEle
	 */
	 // Creating new method for stamping rebate id in the ExtnRebateReference attribute for Relase 2.
	public void createAwardElementforRebateItem(YFSEnvironment env,
			NodeList rebatesEleList,Element orderEle, Element orderLineEle) {
		
		try {
			if (!YFCCommon.isVoid(rebatesEleList) && rebatesEleList.getLength() > KohlsPOCConstant.ZERO_INT) {
				Element itemElement = XMLUtil.getChildElement(orderLineEle,KohlsPOCConstant.E_ITEM);
				String sItemID = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.A_ITEM_ID);
				logger.debug("Calling callRebateDefnApi for the item id : " +sItemID + " and primiline no " +orderLineEle.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO));
				callRebateDefnApi(env,sItemID,rebatesEleList,orderLineEle);
				//PST-1895 - Start - Commenting
				/*String sOrderHeaderKey = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
				if(!YFCCommon.isStringVoid(sOrderHeaderKey)){
					
					Element itemElement = XMLUtil.getChildElement(orderLineEle,KohlsPOCConstant.E_ITEM);
					String sItemID = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.A_ITEM_ID);
					
					 Document inputDocForGetOrderList = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
					          
				      Element yfcEleGetOrder = inputDocForGetOrderList.getDocumentElement();
				      yfcEleGetOrder.setAttribute(KohlsPOCConstant.A_DRAFT_ORDER_FLAG,"Y");
				      yfcEleGetOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY,sOrderHeaderKey); 
				      Document tempGetOrderList = XMLUtil.getDocument(KohlsXMLLiterals.TEMP_GET_ORDER_LIST_REBATE);
				      Document getOrderListOutput = KohlsCommonUtil.invokeAPI(env,tempGetOrderList, 
				    		  KohlsConstant.API_GET_ORDER_LIST, inputDocForGetOrderList);
				      
						
				        if( null != getOrderListOutput){
				        	Element eleOrder = getOrderListOutput.getDocumentElement();
				        	NodeList nOrderLineList = eleOrder.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
				    		if(nOrderLineList.getLength()>0){
					        	for (int k=0; k< nOrderLineList.getLength(); k++) {
					    			Element eleOrderLine = (Element) nOrderLineList.item(k);
					    			Element eleItem = XMLUtil.getChildElement(eleOrderLine,KohlsPOCConstant.E_ITEM);
					    			String itemId= eleItem.getAttribute(KohlsXMLLiterals.A_ItemID);
				    				NodeList awardList = eleOrderLine.getElementsByTagName(KohlsXMLLiterals.E_AWARD);
				    				if(itemId.equalsIgnoreCase(sItemID)){
				    					if(awardList.getLength()>0){
				    					for (int j=0; j< awardList.getLength(); j++) {
							    			Element eleawards = (Element) awardList.item(j);
							    			Element EleextnEle = XMLUtil.getChildElement(eleawards, KohlsPOCConstant.A_EXTN, Boolean.TRUE);
								    			String sExtnRebateReferenceNo = EleextnEle.getAttribute(KohlsPOCConstant.A_EXTN_REBATE_REFERENCE_NO);
								    			for(int i=0; i<rebatesEleList.getLength();i++){		
								    				Element rebatesEle = ((Element) rebatesEleList.item(i));
								    				String rebateID = XMLUtil.getAttribute(rebatesEle, "id");
								    				if(!YFCCommon.isStringVoid(rebateID))
								    				{
								    					//Fix for defect 1078 - Start
								    					String extnRequestDateTime = KohlsPoCPnPUtil.getExtnRequestTime(orderEle);
								    					String shipNode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
								    					if (YFCCommon.isStringVoid(extnRequestDateTime)) {
								    						extnRequestDateTime = KohlsPoCPnPUtil.getCurrentDateString();
								    					}
								    					//internal rebateId list defect - Start
								    					String[] rebateList = rebateID.split("\n");
								    					logger.debug("The rebateList list value is:" +rebateList);;
								    					
								    				}	
								    				logger.debug("rebateID ::"+rebateID);
								    				logger.debug("sExtnRebateReferenceNo ::"+sExtnRebateReferenceNo);
								    				if(rebateID.equals(sExtnRebateReferenceNo)){
								    					createRebateAwardToOrderLine(orderLineEle,rebatesEle);
							    				}
					    					}
					    					}
					    				} 
				    					break;
					    			}else{
					    				logger.debug("::::: Item not matching loopp List exists::");
					    				callRebateDefnApi(env,rebatesEleList,orderLineEle);
					    			}
					    		}
				    		}else{
			    				logger.debug("else loop as different item orderList empty ::");
			    				callRebateDefnApi(env,rebatesEleList,orderLineEle);
			    				
		    				  }
				        }

				        }*/
				//PST-1895 - ENd - Commenting
				logger.debug("orderLineEle ::: "+XMLUtil.getElementXMLString(orderLineEle));
				logger.debug("Method Name : createAwardElementforRebate   and   Status  ");
				logger.debug("KohlsPoCTVSOrderLinePromotionsCaller.createAwardElementforRebateItem");
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		

		}
	/**
	 * calling pos getPOSRebateDefn api to get the effective end date
	 * @param rebatesEleList
	 * @param orderLineEle
	 * @throws IllegalArgumentException
	 * @throws Exception
	 */
	//PST-1895 - Start - changes done in the existing method
	private void callRebateDefnApi (YFSEnvironment env, String itemId, NodeList rebatesEleList,Element orderLineEle) 
			throws IllegalArgumentException, Exception{
		logger.beginTimer("KohlsTVSPoCOrderLinePromotionsCaller.callRebateDefnApi");
		String strItemRebatePair = "";
		for(int i=0; i<rebatesEleList.getLength();i++){		
			Element rebatesEle = ((Element) rebatesEleList.item(i));
			logger.debug("Processing rebates"+XMLUtil.getElementXMLString(rebatesEle));
			String rebateID = XMLUtil.getAttribute(rebatesEle, "id");
			if(!YFCCommon.isVoid(rebateID)){
				strItemRebatePair = itemId.concat(rebateID);
				logger.debug("strItemRebatePair :: "+strItemRebatePair);
				Map<String, Element> cachedRebateHM = this.getCacheRebateHM();
				if (cachedRebateHM.containsKey(strItemRebatePair)) {
					createRebateAwardToOrderLine(orderLineEle,rebatesEle);
					logger.debug("createRebateAwardToOrderLine is from Cache :: "+strItemRebatePair);
				}else{
			 Document inputDocForRebateDefn = XMLUtil.createDocument(KohlsXMLLiterals.ELE_REBATE_DEFN);
		     Element eleRebateDefn = inputDocForRebateDefn.getDocumentElement();
		     eleRebateDefn.setAttribute(KohlsXMLLiterals.A_REBATE_REFERENCE,rebateID);
		    Document rebateDoc = KohlsCommonUtil.invokeAPI(env, 
		    		 KohlsXMLLiterals.API_GET_POS_REBATE_DEFN, inputDocForRebateDefn);
		     Element rebateDefnEle = (Element) rebateDoc.getElementsByTagName(
						"RebateDefn").item(0);
		    if(!YFCCommon.isVoid(rebateDefnEle)){
		    String rebateReference = rebateDefnEle.getAttribute(KohlsXMLLiterals.A_REBATE_REFERENCE);
			if(rebateID.equalsIgnoreCase(rebateReference)){
			Date effectiveEndDate = getEffectiveDate(rebateDoc);
			Date currentDate = new Date();
			String sStartDate = XMLUtil.getAttribute(rebatesEle, KohlsPOCConstant.START_DATE);
			Date startDate = getDateFromString( sStartDate, KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss );
			logger.debug("currentDate :: "+currentDate);
			logger.debug("startDate ::"+startDate);
			logger.debug("effectiveEndDate ::"+effectiveEndDate);
				if(isRebateInRange(currentDate,startDate,effectiveEndDate)){
					logger.debug("inside loop as current date is inbetween start and effective date");
						createRebateAwardToOrderLine(orderLineEle,rebatesEle);
						cacheRebateHM.put(strItemRebatePair, rebatesEle);
						logger.debug("Rebate is updated in cacheRebateHM for the first time "+strItemRebatePair);
					}
				}
			}
				}
			}else{
				logger.error("Rebate ID is null from TVS, for the item " +itemId);
			}
		}
		logger.endTimer("KohlsTVSPoCOrderLinePromotionsCaller.callRebateDefnApi");
	}
	//PST-1895 - ENd
	/**
	 * Creating  award Element to the orderLine
	 * @param orderLineEle
	 * @param rebatesEle
	 */
	private static void createRebateAwardToOrderLine(Element orderLineEle,Element rebatesEle){
		Element awardsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, Boolean.TRUE);
		Element awardEle = XMLUtil.createChild(awardsEle, KohlsPOCConstant.E_AWARD);
		
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, KohlsPOCConstant.REBATE_ITEM);
		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
		
		Element extnEle = XMLUtil.createChild(awardEle, KohlsPOCConstant.E_EXTN);
		
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_REBATE_REFERENCE_NO,
				XMLUtil.getAttribute(rebatesEle, "id"));
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMO_SCHEME,KohlsPOCConstant.PROMO_REBATE);
	   //Getting attributes for rebates start date and end date - Start 
	    XMLUtil.setAttribute(extnEle, KohlsPOCConstant.E_EXTN_START_DATE, 
	    		XMLUtil.getAttribute(rebatesEle, KohlsPOCConstant.START_DATE));
	    XMLUtil.setAttribute(extnEle, KohlsPOCConstant.E_EXTN_END_DATE,
	    		XMLUtil.getAttribute(rebatesEle, KohlsPOCConstant.END_DATE));
	   //Getting attributes for rebates start date and end date - End	
	    
	}
	/**
	 * Method to check if current date is falling between rebate effective end date and start date from TVS response. 
	 * @param orderDate
	 * @param startDate
	 * @param effectiveEndDate
	 * @return
	 */
	private static boolean isRebateInRange( Date orderDate, Date startDate, Date effectiveEndDate )
	   {
	      if ( orderDate == null )
	      {
	         return false;
	      }

	      if ( startDate == null )
	      {
	         return !orderDate.after( effectiveEndDate );
	      }else
	      {
	          if ( orderDate.before( startDate ) )
	          {
	             return false;
	          }
	          else if ( orderDate.after( effectiveEndDate ) )
	          {
	             return false;
	          }
	          else
	          {
	             return true;
	          }
	       }
	   }
	
	/**
	 * gets the date Format from the string 
	 * @param date
	 * @param pattern
	 * @return
	 */
	 public static Date getDateFromString( String date, String pattern )
	   {
	      SimpleDateFormat rebateDateFormat;
	      try
	      {
	         rebateDateFormat = new SimpleDateFormat( pattern );
	      }
	      catch ( Exception e )
	      {
	         rebateDateFormat = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss" );
	         logger.debug( "ERROR::"+e );
	      }

	      try
	      {
	         return rebateDateFormat.parse( date );
	      }
	      catch ( ParseException e )
	      {
	         logger.debug( "ERROR ::"+e );
	      }
	      return null;
	   }
	
	/**
	 * To get the latest Effective end date from Blob xml of rebate list 
	 * @param docInXML
	 * @return
	 * @throws IllegalArgumentException
	 * @throws Exception
	 */
	public static Date getEffectiveDate(Document docInXML)
			throws IllegalArgumentException, Exception {
		
		Element eleRebateDefn = (Element) docInXML.getElementsByTagName(
				"RebateDefn").item(0);
		Date effEndDate = null;
		if(null != eleRebateDefn){
			String rebateData = eleRebateDefn.getAttribute("RebateData");
	        Document rebateDataDoc = XMLUtil.getDocument(rebateData);
	        Element recordEle = (Element) rebateDataDoc.getElementsByTagName(
					"XST_REBT_FM").item(0);
	        Iterator<Element> eleRecords = getChildren( recordEle ).iterator();

	         if ( eleRecords != null )
	         {
	            while ( eleRecords.hasNext() )
	            {
	               Element eleRecord = eleRecords.next();
	               String strEffectiveEndDate = eleRecord.getAttribute( "EFF_END_DTE" ).trim();
	               effEndDate = getDateFromString( strEffectiveEndDate, "MMddyyHHmmss" );
	            }
	         }
	    	logger.debug("effEndDate  ::"+effEndDate);
		}
		return effEndDate;
		
	}
	
	public static Iterable<Element> getChildren(Element target) {
		List list = new ArrayList();
		if (target == null) {
			return list;
		}

		for (Node n = target.getFirstChild(); n != null; n = n.getNextSibling()) {
			if (n.getNodeType() != 1)
				continue;
			list.add((Element) n);
		}

		return list;
	}

	public  String updateUeDocumentForPromoPSA( List<Element> orderLineList, YFSEnvironment yfsEnv, Element tempOrderEle, List<String> createtsList,KohlsPoCTVSOrderPromotionsCaller orderPromoObj)
			throws Exception {
				logger.beginTimer("KohlsTVSPoCOrderLinePromotionsCaller.updateUeDocumentForPromoPSA");
				this.logger.debug("Method Name : updateUeDocumentForPromoPSA   and   Status  ");

				String voidTaxWare = KohlsPOCConstant.NO;
				int i=KohlsPOCConstant.LLD_ID;
				int j=KohlsPOCConstant.ONE_INT;

				for (Element orderLine : orderLineList) {
					String orderedQty = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDERED_QTY);
					Element itemElement = XMLUtil.getChildElement(orderLine,KohlsPOCConstant.E_ITEM);
					String itemId = XMLUtil.getAttribute(itemElement, KohlsPOCConstant.A_ITEM_ID);

					String primeLineNo = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_PRIME_LINE_NO);

					if(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(itemId)){
						voidTaxWare = KohlsPOCConstant.YES;
					}

					//Added below stmt for resetting Awards and LineCharges
					KohlsPoCPnPUtil.resetOrderLineDetailsForTVSPSA(orderLine,tempOrderEle,orderPromoObj);

					if (0.00D == Double.parseDouble(orderedQty)) {
						this.orderLineVoidedHM.put(primeLineNo, orderLine);
					}

					else {
						Element tempEle =  XMLUtil.createChild(orderLine, KohlsPOCConstant.E_TEMP);
						XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, primeLineNo);

						this.orderLineHM.put(primeLineNo, orderLine);
						String orderLineKey = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
						this.orderLineKeyHM.put(orderLineKey, primeLineNo);
					}

					String isSuspendedOrderLine = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.CONDITION_VARIABLE_TWO);
					if (!KohlsPOCConstant.YES.equalsIgnoreCase(isSuspendedOrderLine)) {
						this.itemIdHM.put(itemId, primeLineNo);
					}
					Element promotionsEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_PROMOTIONS);

					if (!YFCCommon.isVoid(promotionsEle)) {
						promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.NO);
					}

				}


	//logger.debug("TVSOrderLinePromotionCaller -- voidTaxWare"+voidTaxWare);
	logger.endTimer("KohlsTVSPoCOrderLinePromotionsCaller.updateUeDocumentForPromoPSA");
	return voidTaxWare;
	}
	
	
   public static Element setAwardAppliedN(Element orderLine) {
		logger.beginTimer("KohlsPoCPnPUtil.setAwardAppliedN");

		List<Element> awardEleList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_AWARD);

		if (awardEleList.size() > KohlsPOCConstant.ZERO_INT) {

			for (Element awardEle : awardEleList) {
				
				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.RESET);
				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.V_N);
				//CPE-1944 - fix to set AwardsAmount=0
				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, KohlsPOCConstant.ZERO_STR);
				
				
			}
		}

		logger.endTimer("KohlsPoCPnPUtil.setAwardAppliedN");
		return orderLine;

	}
	}
