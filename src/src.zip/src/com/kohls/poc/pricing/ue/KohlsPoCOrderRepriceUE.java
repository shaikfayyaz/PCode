package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.kohlscash.ue.KohlsPoCKohlsCashRedemptionRequestCreator;
import com.kohls.poc.payments.ue.KohlsPoCCollectionUEHelper;
import com.kohls.poc.util.KohlsPoCXMLDiff;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSOrderRepricingUE;

/**************************************************************************
 * File : KohlsPoCOrderRepriceUE.java 
 * Author : IBM 
 * Created : August 27 2013 
 * Modified : August 27 2013 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This class is invoked when changeOrder,createOrder,repriceOrder API gets called.
 * Order level and Order line promotions are handled by invoking their related method. 
 * 
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCOrderRepriceUE extends KOHLSBaseApi implements YFSOrderRepricingUE{

	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPoCOrderRepriceUE.class.getName());
	}

	/**
	 * This main method is the entry point for handling the Pricing and Promotions
	 * 
	 * @return Document tempDoc
	 * @param  YFSEnvironment yfsEnv
	 * @param  Document inDoc
	 * @throws YFSUserExitException
	 */
	public Document orderReprice( YFSEnvironment yfsEnv,  Document inDoc) throws YFSUserExitException {	
	    
	    logger.beginTimer("KohlsPoCOrderRepriceUE.orderReprice");
	    Document docOrigInpXML = (Document) inDoc.cloneNode(true);
		Document tempDoc = null;
		Element tempOrderEle = null;
		KohlsPoCOrderLinePromotionsCaller promoObj =  new KohlsPoCOrderLinePromotionsCaller();
		KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj = new KohlsPoCOrderPromotionsCaller();
		// void TaxWare will store the boolean Yes/No to allow taxware call to happen
		String voidTaxWare = KohlsPOCConstant.NO;

		//This List holds all the existing Promotion Element's 'CreateTS' attribute value.
		List<String> createtsList = new ArrayList<String>();
		try {
			
			if(logger.isVerboseEnabled())
				logger.verbose("Input XML to the method KohlsPoCOrderRepriceUE.orderReprice is: \n"+ XMLUtil.getXMLString(inDoc));
			
			//10/14 Manoj: Disabled as part of Performance tuning. - Begin
			//tempOrderEle = KohlsPoCPnPUtil.createElementFromXMLString(XMLUtil.getXMLString(inDoc));
			//10/14 Manoj: Disabled as part of Performance tuning. - End
			tempOrderEle = inDoc.getDocumentElement();

			Element eleExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
			String strSeqNo = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);
			
			//If the UE in doc has DraftOrderFlag='N', returns UE out Document as '<Order/>'
			//If repriceorder API is invoking this UE , return inDoc 
			//If Transaction Object 'IgnoreRepricingUE' value is 'true' , change the 'IgnoreRepricingUE' value as 'false' and return the inDoc
			String draftOrderFlag = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_DRAFT_ORDER_FLAG);

			String isNewOrderFlag = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_IS_NEW_ORDER);
			if((null != isNewOrderFlag && KohlsPOCConstant.YES.equalsIgnoreCase(isNewOrderFlag)) || YFCCommon.isStringVoid(strSeqNo)) {
				String posSeqNo = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO) ;
				logger.debug("seq no:"+posSeqNo);
				//Element extnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
				XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO, posSeqNo);

			}

			if (KohlsPOCConstant.NO.equalsIgnoreCase(draftOrderFlag)) {

				/* check for max_order_status */
				String maxOrderStat = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.MAX_ORDER_STATUS);
				if(KohlsPOCConstant.CONST_CANCEL.equalsIgnoreCase(maxOrderStat)) {
					List <Element> promotionList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_PROMOTION);
					if(promotionList.size() > KohlsPOCConstant.ZERO_INT) {
						for (Element promotionElement : promotionList) {
							String promotionApplied = XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_PROMOTION_APPLIED);
							String promotionType = XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_PROMOTION_TYPE);
							if ( KohlsPOCConstant.YES.equalsIgnoreCase(promotionApplied) &&  KohlsPOCConstant.KOHLSCASH.equalsIgnoreCase(promotionType)) {
								Element extnEle = XMLUtil.getChildElement(promotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
								String extnOfflineMode = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);	
								if(YFCCommon.isStringVoid(extnOfflineMode)) {
									KohlsPoCKohlsCashRedemptionRequestCreator  inputRequestCreator = new KohlsPoCKohlsCashRedemptionRequestCreator();
									Document kohlsCashReq = inputRequestCreator.createKohlsCashRedeemInput(tempOrderEle,yfsEnv,promotionElement);
									Document kohlsCashResp = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_REDEMPTION_WEB_SERVICE, kohlsCashReq);
									
									if(logger.isDebugEnabled())
										logger.debug(XMLUtil.getXMLString(kohlsCashResp));
								}

							} 
						}
					}

				}
				return XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);

			} else if (!YFCCommon.isVoid(yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE))) {
				String ignoreRepricingUE = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE);

				if (KohlsPOCConstant.TRUE.equalsIgnoreCase(ignoreRepricingUE)) {
					yfsEnv.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
					return inDoc;
				}
			}


			Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);

			if (!YFCCommon.isVoid(promotionsEle)) {
				promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
				List <Element> orderPromotionList = XMLUtil
						.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);

				if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) {

					//Code to bypass UE implementation logic when Kohls Cash is activated
					for (Element promotionEle : orderPromotionList) {
						String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);

						if (KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase(promotionType)) {
							XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
							return XMLUtil.getDocumentForElement(tempOrderEle);
						}
					}
					//Order Level Promotions are handled in this method  
					offerAndKohlsCashObj.updateUeDocumentForOffer(orderPromotionList, yfsEnv, tempOrderEle, createtsList);
				}
			}
			
			
			if(logger.isDebugEnabled())
				this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));

			// Order Line Level Promotions are handled in this method 
			List <Element> orderLineList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);


			if (orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
				voidTaxWare = promoObj.updateUeDocumentForPromo(orderLineList, yfsEnv, tempOrderEle, createtsList);
			}
			
			
			if(logger.isDebugEnabled())
				this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));

			//During Suspend , Order Level Promotion is not present , APE service is not invoked
			if (!promoObj.getOrderLineHM().isEmpty()) {

				//APE Request call is made with the help of Order and Order Line leval pricing and  promotions info
				Document  apeRequestDoc = new KohlsPoCAPECaller().constructApeRequestDocument(tempOrderEle, promoObj, offerAndKohlsCashObj, createtsList, yfsEnv);
				
				
				if(logger.isDebugEnabled())
					this.logger.debug(XMLUtil.getXMLString(apeRequestDoc));

				Document apeResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_APE_WEB_SERVICE, apeRequestDoc);
				Element apeResponseEle = apeResponse.getDocumentElement();
				
				
				if(logger.isDebugEnabled())
					this.logger.debug(XMLUtil.getXMLString(apeResponse));

				// Checking for SOAP fault
				if (apeResponseEle.getTagName().equalsIgnoreCase("Errors")) {
					KohlsPoCPnPUtil.validateApeResponse(apeResponseEle);
				}
				
				
				if(logger.isDebugEnabled()){
					logger.debug("APE Response Document Formatted : ");
					logger.debug(XMLUtil.getXMLString(apeResponse));
				}
				//UE Output document is updated by the APE Response information
				new KohlsPoCPrepareUEResponse().updateUeDocumentFromApeResponse(apeResponseEle, tempOrderEle, promoObj, offerAndKohlsCashObj);

			} else{
				
				Element extnOrder = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
				XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TOTAL_SAVINGS, KohlsPOCConstant.ZERO_STR);
			}	
			
			
			if(logger.isDebugEnabled())
				this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));

		} catch (YFSUserExitException e) {
			this.logger.error(e);
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			YFSUserExitException uee = new YFSUserExitException();
			if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {				
				YFSException es = (YFSException) e;

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT") || 
						es.getErrorCode().equalsIgnoreCase("EXTN_IO") ||
						es.getErrorCode().equalsIgnoreCase("EXTN_OTHER") || 
						es.getErrorCode().equalsIgnoreCase("SOAP_EXCEPTION") ) {
					uee.setErrorCode(KohlsPOCConstant.APESERVDOWN);
					uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.APESERVDOWN));
				}else
				{
					uee.setErrorCode(es.getErrorCode());
					uee.setErrorDescription(es.getErrorDescription());
					//Fix for defect 5443 - Start
					throw es;
					//Fix for defect 5443 - End
				}
				throw uee;
			}
			else{
				this.logger.error(e);
				uee.setErrorCode("Unknow Error");
				uee.setErrorDescription(e.getMessage());
				throw uee;
			}

		}
		//Call for Taxware
		// Fix for Taxware call, when item is voided
		try{
			if(KohlsPOCConstant.NO.equalsIgnoreCase(voidTaxWare)){
				Document taxWareResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_TAX_WEB_SERVICE_UTIL, XMLUtil.getDocumentForElement(tempOrderEle));
				List <Element> taxwareOrderLineList = XMLUtil.getElementsByTagName(
						taxWareResponse.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINE);
				if (taxwareOrderLineList.size() > KohlsPOCConstant.ZERO_INT) {
					this.updateForUeDocumentFromTaxWare(taxwareOrderLineList, promoObj.getOrderLineKeyHM(), promoObj.getOrderLineHM(),tempOrderEle);
				}
			}
			
			
			if(logger.isDebugEnabled())
				this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
			
			removeTempElementFromTempDocument(promoObj,offerAndKohlsCashObj);
			tempOrderEle.setAttribute(KohlsPOCConstant.VALIDATE_PROMOTION_AWARD, KohlsPOCConstant.NO);
			
			if(logger.isDebugEnabled())
				this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
			
			tempDoc =  XMLUtil.getDocumentForElement(tempOrderEle);
			
			
			if(logger.isDebugEnabled())
				this.logger.debug("Method Name : orderReprice   and   Status : End ");
		}
		// Changed YFSUserExitException to YFSException as Taxware Service is throwing YFSException
		catch(YFSException UE)
		{
			logger.error("The exception caught is: " +UE.getErrorCode());
			logger.error("The exception error descriptpoin is: " +UE.getErrorDescription());
			if(UE.getErrorCode().equalsIgnoreCase(KohlsPOCConstant.INVALIDGEOCODE)){
				throw UE;
			}
			else{
				YFSUserExitException uee = new YFSUserExitException();
				uee.setErrorCode(UE.getErrorCode());
				uee.setErrorDescription(UE.getErrorDescription());
				throw uee;
			}
			
		}
		catch (Exception e)
		{
			this.logger.error(e);
			e.printStackTrace();
			throw new YFSUserExitException(e.getMessage());
		}
		
		// Manoj 11/30: Added to return only changedOrderLines - Begin
		//String sUseXmlDiff = docOrigInpXML.getDocumentElement().getAttribute("UseXMLDiffInOutput");
		//if(!YFCCommon.isVoid(sUseXmlDiff) && sUseXmlDiff.equalsIgnoreCase("Y")){
			logger.beginTimer("KohlsOrderReprice.DiffXML");
			KohlsPoCXMLDiff xd = new KohlsPoCXMLDiff();
			try {
				Element eleInputOrderLines = (Element) docOrigInpXML.getElementsByTagName("OrderLines").item(0);
				Element eleOutOrderLines = (Element) tempDoc.getElementsByTagName("OrderLines").item(0);
				
				NodeList nlOrderLines = docOrigInpXML.getElementsByTagName("OrderLine");
				if(nlOrderLines.getLength()>0){
					for(int i=0; i<nlOrderLines.getLength(); i++){
						Element eleOrderLine = (Element) nlOrderLines.item(i);
						String sPrimeLineNo=eleOrderLine.getAttribute("PrimeLineNo");
						Element eleLineCharges = XMLUtil.getChildElement(eleOrderLine,"LineCharges");
						eleOrderLine.removeChild(eleLineCharges);
						Element eleLineCharges_new = XMLUtil.createChild(eleOrderLine, "LineCharges");
						if(!YFCCommon.isVoid(eleLineCharges)){
							eleLineCharges.setAttribute("Reset", "Y");
							NodeList nlLineCharge = eleLineCharges.getElementsByTagName("LineCharge");
							
							Element eleUEOutOrderLine = (Element)((NodeList)XPathUtil.getNode(tempDoc.getDocumentElement(), 
									"/Order/OrderLines/OrderLine[@PrimeLineNo='"+sPrimeLineNo+"']")).item(0);
							Element eleUEOutLineCharges = null;
							eleUEOutLineCharges = XMLUtil.getChildElement(eleUEOutOrderLine, "LineCharges");
//							if (YFCCommon.isVoid(eleUEOutLineCharges)){
//								eleUEOutLineCharges = XMLUtil.createChild(eleUEOutOrderLine, "LineCharges");
//							}
							NodeList nlUEOutLineCharges = null;
							if(!YFCCommon.isVoid(eleUEOutLineCharges)){
								nlUEOutLineCharges =  eleUEOutLineCharges.getElementsByTagName("LineCharge");
							}
							
							
							logger.debug("PrimeLineNo processing is: "+sPrimeLineNo);
							boolean bMatchFound;
							if(nlLineCharge.getLength()>0) {
								for (int l=0; l<nlLineCharge.getLength(); l++){
									Element eleLineCharge = (Element) nlLineCharge.item(l);
									String sChargeName = eleLineCharge.getAttribute("ChargeName");
									logger.debug("ChargeName processing is: "+sChargeName);
									Element eleLineCharge_New = XMLUtil.createChild(eleLineCharges_new, "LineCharge");
									XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_CHARGE_PER_LINE,eleLineCharge.getAttribute("ChargePerLine"));
									XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_IS_BILLABLE, KohlsPOCConstant.YES);
									XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.YES);
									XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, eleLineCharge.getAttribute("ChargeCategory"));
									XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.ATTR_CHARGE_NAME, sChargeName);
									//eleLineCharges.removeChild(eleLineCharge);
									
									bMatchFound = false;
									//logger.debug("nlUEOutLineCharges length is: "+nlUEOutLineCharges.getLength());
									if(!YFCCommon.isVoid(nlUEOutLineCharges) && nlUEOutLineCharges.getLength()>0){
										for (int m=0; m<nlUEOutLineCharges.getLength(); m++){
											Element eleUEOutLineCharge = (Element) nlUEOutLineCharges.item(m);
											String sUEOutChargeName = eleUEOutLineCharge.getAttribute("ChargeName");
											logger.debug("UE Out ChargeName is: "+sUEOutChargeName);
											if(sUEOutChargeName.equalsIgnoreCase(sChargeName)){
												bMatchFound = true;
												logger.debug("Match found for chargeName.");
												break;
											}
										}
									}
									if (!bMatchFound){
										logger.debug("Match not found for chargeName. So resetting the LineCharges on O/P xml");
//										if(!YFCCommon.isVoid(eleUEOutLineCharges)){
//											eleUEOutLineCharges.setAttribute("Reset", "Y");
//										}
										break;
									}
								}
							}
						}
						Element elePromotions = XMLUtil.getChildElement(eleOrderLine,"Promotions");
						if(!YFCCommon.isVoid(elePromotions)){
							elePromotions.setAttribute("Reset", "Y");
						}	
						/*NodeList nlLineTax = eleOrderLine.getElementsByTagName("LineTax");
						if(nlLineTax.getLength()>0){
							for (int j=0; j<nlLineTax.getLength(); j++){
								Element eleLineTax = (Element) nlLineTax.item(j);
								eleLineTax.removeAttribute("ChargeNameKey");
								eleLineTax.removeAttribute("InvoicedTax");
								eleLineTax.removeAttribute("Reference_2");
								eleLineTax.removeAttribute("Reference_1");
								eleLineTax.removeAttribute("Reference_3");
								eleLineTax.removeAttribute("RemainingTax");
								eleLineTax.removeAttribute("ChargeNameKey");
								Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, "Extn");
								XMLUtil.removeChild(eleLineTax, eleLineTaxExtn);
							}
						}
						NodeList nlOutLineTax = ((NodeList)XPathUtil.getNodeList(tempDoc.getDocumentElement(), 
								 "/Order/OrderLines/OrderLine[@PrimeLineNo='"+sPrimeLineNo+"']/LineTaxes/LineTax"));	
						if(nlOutLineTax.getLength()>0){
							for (int k=0; k<nlOutLineTax.getLength(); k++){
								Element eleOutLineTax = (Element) nlOutLineTax.item(k);
								eleOutLineTax.removeAttribute("Reference_1");
								String sTaxPercentage = eleOutLineTax.getAttribute("TaxPercentage");
								if("0.0".equalsIgnoreCase(sTaxPercentage)){
									eleOutLineTax.setAttribute("TaxPercentage", KohlsPoCPnPUtil.getDouble(sTaxPercentage));
								}							
							}
						}*/
					}
				}
				//logger.debug("UE Input XML going for Diff is: \n"+ XMLUtil.getElementXMLString(eleInputOrderLines));
				
				//logger.debug("UE Output XML going for Diff is: \n"+ XMLUtil.getElementXMLString(eleOutOrderLines));
				
				Document diffXML = xd.diffXML(XMLUtil.createDocument(eleInputOrderLines), XMLUtil.createDocument(eleOutOrderLines));
				//logger.debug("Diff XML is: \n"+XMLUtil.getXMLString(diffXML));
				Element changedOrderLines = (Element) diffXML.getDocumentElement().getElementsByTagName("OrderLines").item(0);
				if (!YFCCommon.isVoid(changedOrderLines)){
					tempDoc.getDocumentElement().removeChild(eleOutOrderLines);
					Element eleOrderLinesOut = (Element) tempDoc.importNode(changedOrderLines, true);
					tempDoc.getDocumentElement().appendChild(eleOrderLinesOut);
					//logger.debug("Modified XML is: \n"+XMLUtil.getXMLString(tempDoc));
				} else {
					logger.debug("XMLDiff returned null XML. So returning full xml");
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new YFSUserExitException(e.getMessage());
			}
			logger.endTimer("KohlsOrderReprice.DiffXML");
		//}
		// Manoj 11/30: Added to return only changedOrderLines - End
		logger.endTimer("KohlsPoCOrderRepriceUE.orderReprice");
		return tempDoc;
	}

	/**
	 * This method is used to remove all the <Temp/> elements before sending the UE Out Doc
	 * 
	 * @param promoObj
	 * @param offerAndKohlsCashObj
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	private void removeTempElementFromTempDocument(KohlsPoCOrderLinePromotionsCaller promoObj, KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj) throws IOException, SAXException, ParserConfigurationException {
		this.logger.debug("Method Name : removeTempElementFromTempDocument   and   Status : Start ");
		KohlsPoCPnPUtil.removeTempElement(promoObj.getOrderLineHM());
		KohlsPoCPnPUtil.removeTempElement(offerAndKohlsCashObj.getOrderCouponHM());
		KohlsPoCPnPUtil.removeTempElement(offerAndKohlsCashObj.getOrderManualTldHM());
		KohlsPoCPnPUtil.removeTempElement(offerAndKohlsCashObj.getOrderKohlsCashHM());
		KohlsPoCPnPUtil.removeTempElement(offerAndKohlsCashObj.getOrderSeniorDiscountHM());
		KohlsPoCPnPUtil.removeTempElement(promoObj.getOrderLineManualLidHM());
		KohlsPoCPnPUtil.removeTempElement(promoObj.getOrderLinePromotionOverrideHM());
		
		//Added for 3945 defect fix --- Start
		KohlsPoCPnPUtil.removeTempElement(offerAndKohlsCashObj.getOrderAssoDisHM());
		//Added for 3945 defect fix --- End
		
		this.logger.debug("Method Name : removeTempElementFromTempDocument   and   Status : End ");
	}


	/**
	 * Updating the UE out document using Taxware details
	 * 
	 * @param taxwareOrderLineList
	 * @param orderLineKeyHM
	 * @param orderLineHM
	 * @param tempOrderEle 
	 */
	private void updateForUeDocumentFromTaxWare(List<Element> taxwareOrderLineList, Map<String, String> orderLineKeyHM, Map<String, Element> orderLineHM, Element tempOrderEle) throws ParserConfigurationException, SAXException, IOException, Exception {
		this.logger.debug("Method Name : updateForUeDocumentFromTaxWare   and   Status : Start ");
		
		Set<Double> set = new TreeSet<Double>( Collections.reverseOrder() ) ;
		Map<String,Element> taxDetailsMap = new HashMap<String,Element>();
		//Fix for CR 5462 - Start
		boolean nullifyTaxPercentage = false;
		String sTaxExemptionCert = tempOrderEle.getAttribute("TaxExemptionCertificate");
		Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, "Extn");
		String sExtnTaxExemptCustFlag = eleOrderExtn.getAttribute("ExtnTaxExemptCustFlag");
		//Fix for CR 5462 - End
		
		for (Element taxwareOLEle : taxwareOrderLineList) {
			String orderLineKey = XMLUtil.getAttribute(taxwareOLEle, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
			String guid = orderLineKeyHM.get(orderLineKey);
			//Sprint 9.1 : START - Defect 4354//
			String strExtnRecycleFeeID = null;
			//Sprint 9.1 : END - Defect 4354//
			if (null !=  guid && orderLineHM.containsKey(guid)) {
				Element orderLineEle = orderLineHM.get(guid);
				
				Element lineTaxesEle = XMLUtil.getChildElement(taxwareOLEle, KohlsPOCConstant.ELEM_LINE_TAXES);
				//Sprint 9.1 : START //
				Element eleExtn =  XMLUtil.getChildElement(taxwareOLEle, KohlsPOCConstant.A_EXTN);
				if(!YFCCommon.isVoid(eleExtn)){
				strExtnRecycleFeeID = eleExtn.getAttribute("ExtnRecycleFeeID");
				}
				//Sprint 9.1 : END //									
				
			
				if (!YFCCommon.isVoid(lineTaxesEle)) {
					Element lineTaxesEle1 = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
					
					//Fix for CR 5462 - Start 
					Element linePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
					String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
					if(!YFCCommon.isVoid(sTaxExemptionCert)
							|| (!YFCCommon.isVoid(taxableFlag) && ("N".equalsIgnoreCase(taxableFlag)|| "O".equalsIgnoreCase(taxableFlag)))
							|| (!YFCCommon.isVoid(sExtnTaxExemptCustFlag) && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag)))
					{
						if(!YFCCommon.isVoid(sTaxExemptionCert)){
							logger.debug("Order has the Tax Exempt certificate, hence setting the tax percentage as 0");
						} else if((!YFCCommon.isVoid(sExtnTaxExemptCustFlag) && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))){
							logger.debug("Order has Tax exempt customer, hence setting the tax percentage as 0");
						} else {
							logger.debug("OrderLine has TaxableFlag=N, hence setting the tax percentage as 0");
						}
						nullifyTaxPercentage = true;
					}
					updateTaxableFlag(orderLineEle,lineTaxesEle,nullifyTaxPercentage);
					//updateTaxableFlag(orderLineEle,lineTaxesEle);
					//Fix for CR 5462 - End
					
					Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
					KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(lineTaxesEle,tempEle,set);
					
				
					// Sprint 9.1 :START //
					if(!YFCCommon.isVoid(strExtnRecycleFeeID)){
					
					Element eleOrderLineExtn = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
					eleOrderLineExtn.setAttribute("ExtnRecycleFeeCode", strExtnRecycleFeeID);
					orderLineEle.appendChild(eleOrderLineExtn);
					}
					// Sprint 9.1 : END //
					XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
					XMLUtil.importElement(orderLineEle, lineTaxesEle);
					NodeList nlLineTax = orderLineEle.getElementsByTagName("LineTax");
					if(nlLineTax.getLength()>0){
						for(int i=0; i<nlLineTax.getLength(); i++){
							Element eleLineTax = (Element) nlLineTax.item(i);
							String sTaxName = eleLineTax.getAttribute("TaxName");
							NodeList nlTaxwareLineTax = lineTaxesEle.getElementsByTagName("LineTax");
							for (int j=0; j<nlTaxwareLineTax.getLength(); j++){
								Element eleTaxwareLineTax = (Element) nlTaxwareLineTax.item(j);
								String sTaxwareTaxName = eleTaxwareLineTax.getAttribute("TaxName");
								if(sTaxwareTaxName.equals(sTaxName)){
									eleLineTax.setAttribute("Tax", eleTaxwareLineTax.getAttribute("Tax"));
									eleLineTax.setAttribute("TaxName", sTaxwareTaxName);
									String sTaxPercentage = eleTaxwareLineTax.getAttribute("TaxPercentage");
									if("0.0".equalsIgnoreCase(sTaxPercentage)){
										eleLineTax.setAttribute("TaxPercentage", KohlsPoCPnPUtil.getDouble(sTaxPercentage));
									} else {
										eleLineTax.setAttribute("TaxPercentage", sTaxPercentage);
									}
									break;
								}
							}
						}
					} else {
						XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
						XMLUtil.importElement(orderLineEle, lineTaxesEle);
					}
					
				}
			}
		}
		
		/**
		 * Below statement used form the CLOB xml
		 * <TaxIndicators> 
		 * 	<TaxIndicator EffectiveTaxRate="" TaxAmount="" TaxRateIndicator="" TotalAmount=""/> 
		 * </TaxIndicators>
		 */ 
		
		Document taxIndicatorsDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
	    Element taxDetailListEle = taxIndicatorsDoc.getDocumentElement();
		Iterator ite = orderLineHM.keySet().iterator();
		
		while(ite.hasNext()){
			String guid = (String) ite.next();
			Element orderLineEle = orderLineHM.get(guid);
			Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
			Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);
			
			Element linePriceInfoEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
			String taxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
			
			Element extnOrderEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
			String extnAgencyName = extnOrderEle.getAttribute(KohlsPOCConstant.A_AGENCY_NAME);
			// Fix for defect 26757 - Start
			if(KohlsPOCConstant.YES.equalsIgnoreCase(taxableFlag) || !YFCCommon.isVoid(extnAgencyName))
			// Fix for defect 26757 - End
			{
				String extnTaxIndicator = KohlsPoCPnPUtil.updateTaxDetails(set,taxDetailsMap,tempEle,taxDetailListEle);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR, extnTaxIndicator);
			}else{
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR, KohlsPOCConstant.CONST_HASH);
			}
		}
		
		Element orderExtnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
		orderExtnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS, XMLUtil
				.getElementXMLString(taxDetailListEle));
		
		this.logger.debug("Method Name : updateForUeDocumentFromTaxWare   and   Status : End ");
	}



	/**updateTaxableFlag : This method is used to updated taxable flag based on the merchandise tax code and the tax attribute of LineTax from Taxware response
	 * @param orderLineEle
	 * @param lineTaxesEle
	 * @param nullifyTaxPercentage 
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	//Fix for CR 5462 - Start
	private void updateTaxableFlag(Element orderLineEle, Element lineTaxesEle, boolean nullifyTaxPercentage) 
	//Fix for CR 5462 - End
	throws ParserConfigurationException, SAXException, IOException {
		this.logger.debug("Method Name : updateTaxableFlag   and   Status : Start ");

		// Retrieve MDSE_TX_CDE from PluPromo response

		Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);
		Element pluPromoResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE));
		List<Element> pluFileList = XMLUtil.getElementsByTagName(pluPromoResposneEle, KohlsPOCConstant.E_PLU_FILE);

		String mdseTaxCode = KohlsPOCConstant.EMPTY;
		Element pluFileRecordEle = null;

		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT && !YFCCommon.isVoid(pluFileList.get(KohlsPOCConstant.ZERO_INT))) {
			pluFileRecordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
			mdseTaxCode = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_MDSE_TX_CDE);
		}

		boolean isTaxNonZero = Boolean.FALSE;
		List<Element> lineTaxEleList = XMLUtil.getElementsByTagName(lineTaxesEle, KohlsPOCConstant.E_LINE_TAX);

		// Iterate through the list of linetax and check for Tax attribute value. If any of the LineTax's Tax attribute value is greater than zero
		// set isTaxNonZero as True 
		for(Element lineTaxEle  : lineTaxEleList){
			String tax = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX);
			if(Double.valueOf(tax) > KohlsPOCConstant.ZERO_DBL){
				isTaxNonZero = Boolean.TRUE;
				break;
			}
			//Fix for CR 5462 - Start
			if(nullifyTaxPercentage){
				XMLUtil.setAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT,KohlsPOCConstant.ZERO_STR);
			}
			//Fix for CR 5462 - End
		}

		Element linePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
		String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);

		logger.debug("mdseTaxCode"+mdseTaxCode);
		//logger.debug("Double.valueOf(mdseTaxCode):"+Double.valueOf(mdseTaxCode));
		logger.debug("TaxableFlag:"+taxableFlag);
		logger.debug("istaxNonZero:"+isTaxNonZero);

		// If isTaxNonZero is false and MDSE_TX_CDE ==0 OR isTaxNonZero is false and TaxableFlag is N or O, set taxable flag as N , else Y

		if((!isTaxNonZero && !YFCCommon.isStringVoid(mdseTaxCode) && (Double.valueOf(mdseTaxCode) ==  KohlsPOCConstant.ZERO_DBL)) ||
				(!isTaxNonZero && !YFCCommon.isStringVoid(taxableFlag) && ((KohlsPOCConstant.NO.equalsIgnoreCase(taxableFlag)) || (KohlsPOCConstant.OVERRIDE_TAX_O.equalsIgnoreCase(taxableFlag))))){
			XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG,KohlsPOCConstant.NO);
			//Manoj : Fix for defect 5479 - Start
			for(Element lineTaxEle  : lineTaxEleList){
					XMLUtil.setAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT,KohlsPOCConstant.ZERO_STR);				
			}
			//Manoj : Fix for defect 5479 - End

		}else{
			XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG,KohlsPOCConstant.YES);
		}

		logger.debug("Taxable Flag at linepriceInfo is:"+linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG));
		logger.debug("Method Name : updateTaxableFlag   and   Status : End ");
	}
}
