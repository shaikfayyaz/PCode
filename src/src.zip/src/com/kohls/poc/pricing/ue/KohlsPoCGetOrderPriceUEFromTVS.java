package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ypm.japi.ue.YPMGetOrderPriceUE;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;

/*******************************************************************************
 * File : KohlsPoCGetOrderPriceUEFromTVS.java Author : IBM Created : July 14,
 * 2015 Modified : Version : 0.1
 * ****************************************************************************
 * HISTORY
 * ****************************************************************************
 * V0.1 28/08/2013 IBM First Cut. V0.2 30/08/2013 Populated following attributes
 * ****************************************************************************
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 *           Services on behalf of Kohls, and is copyright of Kohls
 * 
 * ****************************************************************************
 * ****************************************************************************
 * This file fetches the price and promo details for a given item from TVS
 * 
 * @author Sudina Pullanhiyodan
 * @version 0.1
 ******************************************************************************/

public class KohlsPoCGetOrderPriceUEFromTVS extends KOHLSBaseApi implements
		YPMGetOrderPriceUE {

	private static YFCLogCategory logger;
	
	private Properties props;

	private Double listPrice = KohlsPOCConstant.ZERO_DBL;
	// Changes for ExtendedPrice - Start
	private	Double extendedPrice = KohlsPOCConstant.ZERO_DBL ;
	// Changes for ExtendedPrice - End

	static {
		logger = YFCLogCategory.instance(KohlsPoCGetOrderPriceUEFromTVS.class
				.getName());
	}

	/**
	 * This method receives UE input document and after processing returns back
	 * the UE output
	 * 
	 * @return Document
	 * @param YFSEnvironment
	 *            yfsEnv
	 * @param Document
	 *            inDoc
	 * @throws YFSUserExitException
	 */

	public Document getOrderPrice(YFSEnvironment env, Document inputDoc)throws YFSUserExitException
	{
		String strItemId = null;
		Document docOrderPriceUEOutput = null;
		KohlsPoCTVSOrderPromotionsCaller offerAndKohlsCashObj =  new KohlsPoCTVSOrderPromotionsCaller();
		KohlsPoCTVSOrderLinePromotionCaller promoObj = new KohlsPoCTVSOrderLinePromotionCaller();
		
		logger.beginTimer("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice");
		
		
		if(logger.isDebugEnabled())
			this.logger.debug("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice : Input to getOrderPrice method \n"+XMLUtil.getXMLString(inputDoc));
		
		try {
				//Element eleOrder = (Element) ((NodeList) XPathUtil.getNodeList(inputDoc.getDocumentElement(), "/Order")).item(0);
				//Element eleOrderLine = (Element) ((NodeList) XPathUtil.getNodeList(inputDoc.getDocumentElement(), "/Order/OrderLines/OrderLine")).item(0);
			 	Element eleOrder = inputDoc.getDocumentElement();
			 	List <Element> eleOrderLineList = XMLUtil.getElementsByTagName(inputDoc.getDocumentElement(), "OrderLine");
			 	Element eleOrderLine = (Element) eleOrderLineList.get(0);
				if (!YFCCommon.isVoid(eleOrderLine)) 
				{ 
					strItemId = XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.A_ITEM_ID);
					
					// When an item is added and removed from gravity, Cart is
					// still active but no items.
					// But when this order has to be voided, it shud have
					// atleast one item. Hence internally
					// SKU_VOID_TRAN_ZERO_ITEM is added as item
					
					if(!YFCCommon.isVoid(strItemId) && !(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(strItemId)))
					{
						// Create request XML for TVS call
						Document docTVSRequest = constructTVSRequest(env,inputDoc);
						
						// webservice call to TVS system
						Document docTVSResponse = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE, docTVSRequest);
						
						
						if(logger.isDebugEnabled())
							this.logger.debug("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice:\t Response from TVS:\n"+ XMLUtil.getXMLString(docTVSResponse));
						
						Element tvsResponseEle = docTVSResponse.getDocumentElement();
						
						// Checking for SOAP fault
						if (tvsResponseEle.getTagName().equalsIgnoreCase("Errors")) {
							YFSException yfsException = new YFSException();
							String errorCodeStr = XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorCode");
							if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr)) {
								yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
							}
							else
							{
								yfsException.setErrorCode(errorCodeStr);
							}
							yfsException.setErrorDescription(XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorDescription"));
							logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice");
							throw yfsException;
						
						}
						else
						{
							List <Element> apeItemList = XMLUtil.getElementsByTagName(docTVSResponse.getDocumentElement(), KohlsPOCConstant.ELEM_SMALL_ITEM);
							if (apeItemList.size() > KohlsPOCConstant.ZERO_INT) {
								promoObj.getOrderLineHM().put(KohlsPOCConstant.STRING_ONE, eleOrderLine);
								// Update the Response doc for the user exit
								new KohlsPoCTVSPrepareUEResponse().updateUeDocumentFromTVSResponse(env, docTVSResponse.getDocumentElement(), eleOrder, offerAndKohlsCashObj,promoObj);
								convertSalesHubDataAsElement(eleOrder);
								removeAttributes(eleOrder);
								docOrderPriceUEOutput = constructOrderPriceUEOuput(env,docTVSResponse,eleOrder);
//								Element orirginalOrderLine = (Element) KohlsXPathUtil.getNode(eleOrder,"//Order/OrderLines/OrderLine");
//								Element tempOrderLine = (Element) KohlsXPathUtil
//								.getNode(docOrderPriceUEOutput.getDocumentElement(),
//										"//Order/OrderLines/OrderLine");
								List <Element> originalOrderLineList = XMLUtil.getElementsByTagName(eleOrder, "OrderLine");
							 	Element orirginalOrderLine = (Element) originalOrderLineList.get(0);
							 	List <Element> tempOrderLineList = XMLUtil.getElementsByTagName(docOrderPriceUEOutput.getDocumentElement(), "OrderLine");
								Element tempOrderLine = (Element) tempOrderLineList.get(0);
								XMLUtil.setAttribute(orirginalOrderLine,KohlsPOCConstant.A_LINE_TOTAL, tempOrderLine.getAttribute(KohlsPOCConstant.A_LINE_TOTAL));
								// Setting UPCCode
								try {
//										Element eleItem = (Element) KohlsXPathUtil.getNode(eleOrder,"//Order/OrderLines/OrderLine/Item");
										List <Element> eleItemList = XMLUtil.getElementsByTagName(eleOrder, "Item");
										Element eleItem = (Element) eleItemList.get(0);
										XMLUtil.setAttribute(eleItem, KohlsPOCConstant.A_UPC_CODE, KohlsPoCPnPUtil.getUpcCode(env,strItemId));
						} catch (Exception e) {
							logger.error("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice : No UPC Code");
							logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice");
							e.printStackTrace();
						}
								// Call to post the price verifyc call message
								// to Sales Hub
								KohlsCommonUtil.api.executeFlow(env, "KohlsPoCGenerateAndStorePVMessage", XMLUtil.getDocumentForElement(eleOrder));
								// Response to Gravity
							}
						}
					}
				}
			}
		catch (YFSUserExitException ueException) {
			logger.error(ueException);
			ueException.printStackTrace();
			logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice");
			throw ueException;
		}catch (Exception e) {
			e.printStackTrace();
			YFSException uee = new YFSException();
			if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {				
			
			this.logger.debug("Error class Name"+ e.getClass().getName());
				
				YFSException es = (YFSException) e;

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
					uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
					uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
				}

				// IO Exception
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
					uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
					uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
				}

				// Other Exceptions
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
					uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
					uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
				}
				else if (es.getErrorCode().equalsIgnoreCase("SOAP_EXCEPTION")) {
					uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
					uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
				}
				
				else
				{
					uee.setErrorCode(es.getErrorCode());
					uee.setErrorDescription(es.getErrorDescription());
					throw uee;
				}
				throw uee;
			}
			else{
				this.logger.error(e);
				uee.setErrorCode("Unknow Error");
				uee.setErrorDescription(e.getMessage());
				throw uee;
			}

		}
		logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice");
		return docOrderPriceUEOutput;
}

	/**
	 * This method constructs TVS request
	 * 
	 * @return Document
	 * @param Element
	 *            eleOrderFromInput
	 * @param YFSEnvironment
	 *            environment
	 */

	Document constructTVSRequest(YFSEnvironment environment,
			Document inXML) {
		logger.beginTimer("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest");
		
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest : Input to  constructTVSRequest method \n"
						+ XMLUtil.getXMLString(inXML));
		
		Document docTVSReq = null;
		//String tvsStoreNum = null;
		try {
		//Uncommenting for defect 3078 - Start
		KohlsPoCPnPUtil.updateExtnAttrsOnOrderLineFromItem(environment, inXML);
		//Uncommenting for defect 3078 - End
		Element eleOrderFromInput = inXML.getDocumentElement();
		docTVSReq = YFCDocument.createDocument(
				KohlsPOCConstant.PRICE_REQUEST).getDocument();
		Element eleTransaction = XMLUtil.createChild(docTVSReq
				.getDocumentElement(), KohlsPOCConstant.ATTR_TRANSACTION);
		
		String strStoreNum = "";
		if (YFCCommon.isVoid(eleOrderFromInput
						.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE))) {
			strStoreNum = KohlsPoCPnPUtil
			.prepadStoreNoWithZeros(eleOrderFromInput
					.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE));
		} else {
			strStoreNum = KohlsPoCPnPUtil
					.prepadStoreNoWithZeros(eleOrderFromInput
							.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
		}
		
		/*tvsStoreNum = props.getProperty(strStoreNum);
		
		if(YFCCommon.isVoid(tvsStoreNum)){
			tvsStoreNum	= strStoreNum;
		}*/
		
		
		Element eleStoreNum = XMLUtil.createChild(eleTransaction, KohlsPOCConstant.STORE_NUM);
		//XMLUtil.setNodeValue(eleStoreNum, tvsStoreNum);
		XMLUtil.setNodeValue(eleStoreNum, strStoreNum);
		
		Element eleItemList = XMLUtil.createChild(eleTransaction,
				KohlsPOCConstant.ATTR_ITEM_LIST);
		Element eleItem = XMLUtil.createChild(eleItemList,
				KohlsPOCConstant.ELEM_SMALL_ITEM);

		
			/*Element eleExtn = (Element) ((NodeList) XPathUtil.getNodeList(
					eleOrderFromInput, "/Order/OrderLines/OrderLine/Extn"))
					.item(0);
			Element eleOrderLine = (Element) ((NodeList) XPathUtil.getNodeList(
					eleOrderFromInput, "/Order/OrderLines/OrderLine")).item(0);*/
			List <Element> eleOrderLineList = XMLUtil.getElementsByTagName(eleOrderFromInput, "OrderLine");
			Element eleOrderLine = (Element) eleOrderLineList.get(0);
		

			// XML sequencing : START

			
			Element eleSku= XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_SKU);
			String strItemID = eleOrderLine.getAttribute(KohlsPOCConstant.A_ITEM_ID);
			XMLUtil.setNodeValue(eleSku, strItemID);
			
			Element eleId= XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_ID);
			XMLUtil.setNodeValue(eleId, KohlsPOCConstant.STRING_ONE);
			

			
			// XML sequencing : END
			
			//eleTransaction
			//		.setAttribute(KohlsPOCConstant.STORE_NUM, strStoreNum);
			//eleItem.setAttribute(KohlsPOCConstant.ATTR_ID,
			//		KohlsPOCConstant.STRING_ONE);
			//eleItem.setAttribute(KohlsPOCConstant.ATTR_SKU, eleOrderLine
			//		.getAttribute(KohlsPOCConstant.A_ITEM_ID));
		/*	Element eleReference = (Element) KohlsXPathUtil
					.getNode(eleOrderFromInput,
							"//Order/OrderLines/OrderLine/References/Reference[@Name='ExtnEmpDiscCode']"); */
			List<Element> eleReferenceList = XMLUtil.getElementsByTagName(
					eleOrderLine, KohlsPOCConstant.A_REFERENCE);
			if (!YFCCommon.isVoid(eleReferenceList)) {
				for (Element eleReference : eleReferenceList) {
					if (!YFCCommon.isVoid(eleReference)
							&& ("ExtnEmpDiscCode".equals(eleReference
									.getAttribute("Name")))) {
						break;
					}
				}
			}
			//String strvalue = "";
			
			Element eleEmpDiscCode= XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
			XMLUtil.setNodeValue(eleEmpDiscCode, "S");
		
			/*if (!YFCCommon.isVoid(eleReference)) {
			eleItem.setAttribute(KohlsPOCConstant.ATTR_EMP_DISC_CODE,
						eleReference.getAttribute(KohlsPOCConstant.A_VALUE));
				strvalue = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
				
				eleEmpDiscCode= XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_EMP_DISC_CODE);
				XMLUtil.setNodeValue(eleEmpDiscCode, strvalue);
			}*/
			YFCDate date = new YFCDate();
/*			eleItem.setAttribute(KohlsPOCConstant.ATTR_SCAN_TIME, date
					.getString(null, true));*/
			String strDate = date.getString(null, true);
			
			Element eleScanTime= XMLUtil.createChild(eleItem, KohlsPOCConstant.ATTR_SCAN_TIME);
			XMLUtil.setNodeValue(eleScanTime, strDate);
			
			
			// Add exclusionlist if any to the request document
			KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules(environment,
					eleTransaction);
			
			if(logger.isDebugEnabled())
				logger.debug("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest: Transaction element after fetching exclusion list --- :"
							+ XMLUtil.getElementXMLString(eleTransaction));

		} catch (Exception exp) {
			logger
					.error("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest: \n"
							+ exp);
			logger
					.endTimer("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest");
			exp.printStackTrace();
		}
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest : Request for for TVS call \n"
						+ XMLUtil.getXMLString(docTVSReq));
		logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.constructTVSRequest");
		return docTVSReq;
	}

	/**
	 * 
	 * This method constructs UE output document
	 * 
	 * @return Document
	 * @param Document
	 *            docTVSRes
	 * @param Element
	 *            eleInputOrder
	 * @throws ParserConfigurationException
	 *             indicates a serious configuration error
	 * @throws SAXException
	 *             Encapsulate a general SAX error or warning
	 * @throws IOException
	 *             indicates an I/O exception of some sort has occurred
	 * @throws ParseException
	 *             indicates that an error has been reached unexpectedly while
	 *             parsing
	 */

	Document constructOrderPriceUEOuput(YFSEnvironment env, Document docTVSRes,
			Element eleInputOrder) throws ParserConfigurationException,
			SAXException, IOException, ParseException {
		logger
				.beginTimer("KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput");
		
		
		if(logger.isDebugEnabled())
			logger
				.debug("KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput : eleInputOrder is \n"
						+ XMLUtil.getElementXMLString(eleInputOrder)
						+ "\n KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput docTVSRes is \n"
						+ XMLUtil.getXMLString(docTVSRes));

		String lineTotalString = null;
		Map<String, Element> promosHM = new LinkedHashMap<String, Element>();
		double total = KohlsPOCConstant.ZERO_DBL;
		Document docUEOutput = XMLUtil
				.createDocument(KohlsPOCConstant.ELEM_ORDER);
		Element eleOrderOutput = docUEOutput.getDocumentElement();

		XMLUtil.setAttribute(eleOrderOutput,
				KohlsPOCConstant.A_APPLY_ONLY_ITEM_LEVEL_PRICING_RULES,
				KohlsPOCConstant.YES);
		XMLUtil.setAttribute(eleOrderOutput, KohlsPOCConstant.A_CURRENCY,
				eleInputOrder.getAttribute(KohlsPOCConstant.A_CURRENCY));
		XMLUtil.setAttribute(eleOrderOutput,
				KohlsPOCConstant.A_ENABLE_MANAGER_OVERRIDES,
				KohlsPOCConstant.NO);
		XMLUtil.setAttribute(eleOrderOutput,
				KohlsPOCConstant.A_ENTERPRISE_CODE, eleInputOrder
						.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE));
		XMLUtil.setAttribute(eleOrderOutput,
				KohlsPOCConstant.A_ORGANIZATION_CODE, eleInputOrder
						.getAttribute(KohlsPOCConstant.A_ORG_CODE));
		if (YFCCommon.isVoid(eleOrderOutput.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE))) {
			// org code empty, try using seller org code
			eleOrderOutput.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE, eleInputOrder
						.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
		}

	String enterpriseCode = "";
	        
	if( null != eleInputOrder){
	  enterpriseCode = eleInputOrder.getAttribute("EnterpriseCode");   
	}

		Element eleTVSResponse = docTVSRes.getDocumentElement();

		// Forming a hashmap of promos

		List<Element> listPromoList = XMLUtil.getElementsByTagName(
				eleTVSResponse, KohlsPOCConstant.ELEM_PROMO);
		if (null != listPromoList
				&& listPromoList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element elePromo : listPromoList) {
				promosHM.put(elePromo.getAttribute(KohlsPOCConstant.ATTR_ID),
						elePromo);
			}
		}

		List<Element> eleTVSResItemList = XMLUtil.getElementsByTagName(
				eleTVSResponse, KohlsPOCConstant.ELEM_SMALL_ITEM);

		Element eleorderLinesOutput = XMLUtil.createChild(eleOrderOutput,
				KohlsPOCConstant.ELEM_ORDER_LINES);
	
		for (Element eleItem : eleTVSResItemList) {
			Element eleordLineOutput = XMLUtil.createChild(eleorderLinesOutput,
					KohlsPOCConstant.ELEM_ORDER_LINE);
			String bogoSetId = XMLUtil.getAttribute(eleItem,
					KohlsPOCConstant.A_BOGO_GRP_CODE);
			
			// Manoj 11/16: Changes for defect 638 - Begin
			/*XMLUtil.setAttribute(eleordLineOutput, KohlsPOCConstant.A_ITEM_ID,
					eleItem.getAttribute(KohlsPOCConstant.ATTR_SKU));*/
			Element eleInItem = (Element)eleInputOrder.getElementsByTagName("Item").item(0);
			XMLUtil.setAttribute(eleordLineOutput, KohlsPOCConstant.A_ITEM_ID,
					eleInItem.getAttribute("ItemID"));
			// Manoj 11/16: Changes for defect 638 - End
			DecimalFormat twoDlistPrice = new DecimalFormat(
					KohlsPOCConstant.DECIMAL_FORMAT);
			listPrice = Double.parseDouble(eleItem
					.getAttribute(KohlsPOCConstant.ATTR_REGULAR_PRICE));
			logger
					.debug("KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput : List Price from Response------------"
							+ listPrice);
			String listPriceString = twoDlistPrice.format(listPrice);
			
			XMLUtil.setAttribute(eleordLineOutput,
					KohlsPOCConstant.A_LIST_PRICE, listPriceString);
			// Changes for ExtendedPrice - Start
			extendedPrice = Double.parseDouble(eleItem.getAttribute(KohlsPOCConstant.ATTR_REGULAR_PRICE));
		        String strextendedPrice = twoDlistPrice.format(extendedPrice) ;
			logger.debug("ExtendedPrice is :: "+strextendedPrice) ;
			XMLUtil.setAttribute(eleordLineOutput, KohlsPOCConstant.A_EXTENDED_PRICE,strextendedPrice);
			// Changes for ExtendedPrice - End
			Element extnEle = XMLUtil.getChildElement(eleordLineOutput,
					KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(extnEle,
					KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM, XMLUtil
							.getAttribute(eleItem,
									KohlsPOCConstant.ATTR_EXCLUSION_ITEM));
									
												//TODO:CR485
			KohlsPoCCommonAPIUtil.setRestrictedReturnIndicator(env,eleordLineOutput,enterpriseCode);

			List<Element> eleModifierList = XMLUtil.getElementsByTagName(
					eleItem, KohlsPOCConstant.ELEM_MODIFIER);
			double taxPrice = KohlsPOCConstant.ZERO_DBL;
			if (null != eleModifierList
					&& eleModifierList.size() > KohlsPOCConstant.ZERO_INT) {
				int count = KohlsPOCConstant.ZERO_INT;
				for (Element eleModifier : eleModifierList) {
					String strDisGUID = XMLUtil.getAttribute(eleModifier,
							KohlsPOCConstant.ATTR_PARENT_DISCOUNT_ID);
					if (promosHM.containsKey(strDisGUID)) {
						Element elePromo = promosHM.get(strDisGUID);
						count++;
						Element eleLineAdjustments = XMLUtil.createChild(
								eleordLineOutput,
								KohlsPOCConstant.E_LINE_ADJUSTMENTS);
						Element eleLineAdjustment = XMLUtil.createChild(
								eleLineAdjustments,
								KohlsPOCConstant.E_ADJUSTMENT);
						XMLUtil.setAttribute(eleLineAdjustment,
								KohlsPOCConstant.ATTR_ADJUSTMENT_ID, String
										.valueOf(count));
						String taxPriceDelta = XMLUtil.getAttribute(
								eleModifier,
								KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA);
						taxPrice = Double.valueOf(taxPriceDelta);
						DecimalFormat twoDtaxPrice = new DecimalFormat(
								KohlsPOCConstant.DECIMAL_FORMAT);
						String taxPriceString = twoDtaxPrice.format(taxPrice);
						XMLUtil.setAttribute(eleLineAdjustment,
								KohlsPOCConstant.A_ADJUSTMENT_PER_UNIT,
								taxPriceString);
						//Changes for AdjustmentApplied attribute - Start 
						XMLUtil.setAttribute(eleLineAdjustment,
								KohlsPOCConstant.A_ADJUSTMENT_APPLIED,
								taxPriceString);
						//Changes for AdjustmentApplied attribute - End
						total = total + taxPrice;
						addDescription(elePromo, bogoSetId, eleLineAdjustment);
						
						if(logger.isDebugEnabled())
							logger.debug("KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput : Promo element after adding description -------"
										+ XMLUtil.getElementXMLString(elePromo));
					}
				}

			}

			DecimalFormat twoDlineAdj = new DecimalFormat(
					KohlsPOCConstant.DECIMAL_FORMAT);
			String totalString = twoDlineAdj.format(total);
			XMLUtil.setAttribute(eleordLineOutput,
					KohlsPOCConstant.A_LINE_ADJUSTMENT, totalString);
			double modifiedTotal = KohlsPOCConstant.ZERO_DBL;
			if (!String.valueOf(total).equalsIgnoreCase(
					String.valueOf(KohlsPOCConstant.ZERO_DBL))
					&& String.valueOf(total).startsWith(KohlsPOCConstant.MINUS)) {
				modifiedTotal = Double.valueOf(Math.abs(total));

			} else {
				modifiedTotal = total;
			}

			double lineTotal = (Double.valueOf(listPrice) - modifiedTotal);
			logger
					.debug("KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput : calculated Line Total"
							+ lineTotal);
			DecimalFormat twoDlnTotal = new DecimalFormat(
					KohlsPOCConstant.DECIMAL_FORMAT);
			lineTotalString = twoDlnTotal.format(lineTotal);
			XMLUtil.setAttribute(eleordLineOutput,
					KohlsPOCConstant.A_LINE_TOTAL, lineTotalString);
			XMLUtil.setAttribute(eleordLineOutput,
					KohlsPOCConstant.A_LINE_PRICE, lineTotalString);
		}
		XMLUtil.setAttribute(eleOrderOutput,
				KohlsPOCConstant.A_LINE_PRICE_TOTAL, lineTotalString);

		double modifiedOrderTotal = KohlsPOCConstant.ZERO_DBL;
		if (!String.valueOf(total).equalsIgnoreCase(
				String.valueOf(KohlsPOCConstant.ZERO_DBL))
				&& String.valueOf(total).startsWith(KohlsPOCConstant.MINUS)) {
			modifiedOrderTotal = Double.valueOf(Math.abs(total));
		} else {
			modifiedOrderTotal = total;
		}
		double orderTotal = (Double.valueOf(listPrice) - modifiedOrderTotal);
		DecimalFormat twoDoorderTotal = new DecimalFormat(
				KohlsPOCConstant.DECIMAL_FORMAT);
		String twoDorderTotal = twoDoorderTotal.format(orderTotal);
		XMLUtil.setAttribute(eleOrderOutput, KohlsPOCConstant.A_ORDER_TOTAL,
				String.valueOf(twoDorderTotal));
		XMLUtil.setAttribute(eleOrderOutput, KohlsPOCConstant.A_SUB_TOTAL,
				String.valueOf(twoDorderTotal));
		
		if(logger.isDebugEnabled())
			logger.debug("Exiting constructUEOutputDocument method..\n Output Doc to GetOrderPrice UE"
						+ XMLUtil.getXMLString(docUEOutput));
		logger
				.endTimer("KohlsPoCGetOrderPriceUEFromTVS.constructOrderPriceUEOuput");
		return docUEOutput;
	}

	/**
	 * This method constructs and sets the value for promo description
	 * 
	 * @return
	 * @param Element
	 *            elePromo
	 * @param String
	 *            bogoSetId
	 * @param Element
	 *            eleLineAdjustment
	 */

	private void addDescription(Element elePromo, String bogoSetId,
			Element eleLineAdjustment) {
		logger.beginTimer("KohlsPoCGetOrderPriceUEFromTVS.addDescription");
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.addDescription : Promo Element is \n"
						+ XMLUtil.getElementXMLString(elePromo));

		String promoSchemeCode = XMLUtil.getAttribute(elePromo,
				KohlsPOCConstant.ATTR_PROMO_SCHEME_CODE);
		String rcpttxt = XMLUtil.getAttribute(elePromo,
				KohlsPOCConstant.ATTR_RECEIPT_CMT_TEXT);
		String strDiscountAmount = "0.00";
		String strDiscountPercentage = "0.00";

		/*
		 * If bogo group code is not empty and is "0" , set it to "" else set
		 * bogoSetId as ( <bogo group id> )and
		 */
		if (!YFCCommon.isStringVoid(bogoSetId)) {
			if (KohlsPOCConstant.ZERO.equalsIgnoreCase(bogoSetId)) {
				bogoSetId = KohlsPOCConstant.EMPTY;
			} else {
				bogoSetId = KohlsPOCConstant.LEFT_BRACKET + bogoSetId
						+ KohlsPOCConstant.RIGHT_BRACKET;
			}
		}

		StringBuffer descriptionStrBfr = new StringBuffer();

		if (!XMLUtil.isVoid((XMLUtil.getAttribute(elePromo,
				KohlsPOCConstant.ATTR_DISCOUNT_AMT)))) {
			strDiscountAmount = XMLUtil.getAttribute(elePromo,
					KohlsPOCConstant.ATTR_DISCOUNT_AMT);
		}
		if (!XMLUtil.isVoid((XMLUtil.getAttribute(elePromo,
				KohlsPOCConstant.ATTR_DISCOUNT_PERCENT)))) {

			//Fix for defect 652 - Start
			strDiscountPercentage = XMLUtil.getAttribute(elePromo, KohlsPOCConstant.ATTR_DISCOUNT_PERCENT);
			int intDiscountPercentage = Double.valueOf(strDiscountPercentage).intValue() ;
			
			if(intDiscountPercentage>999){
				logger.debug("Discount Percent is divided by 1000, since its calculated from tierPercentage :"+strDiscountPercentage);
				strDiscountPercentage = intDiscountPercentage/KohlsPOCConstant.THOUSAND_INT +"";
			}
			//Fix for defect 652 - End
		}

		/*
		 * Award Description for 'Gift with Purchase' , 'Gold star' are handled
		 * by Toshiba
		 */
		if (Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(
				Integer.valueOf(promoSchemeCode))
				|| Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PROMO).equals(
						Integer.valueOf(promoSchemeCode))) { // Group Pricing
			// Sub-Line
			String groupRetailAmt = String.valueOf(Double
					.valueOf(strDiscountAmount));
			descriptionStrBfr.append(
					XMLUtil.getAttribute(elePromo,
							KohlsPOCConstant.ATTR_INC_BUY_QTY)).append(
					KohlsPOCConstant.SPACE).append(KohlsPOCConstant.FOR_$)
					.append(groupRetailAmt);

		} else if (Integer.valueOf(
				KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(
				Integer.valueOf(promoSchemeCode))) { // Tier Buy Doller Get
			// % Promotion Sub-line
			String discountPercentage = String.valueOf(Integer
					.valueOf(strDiscountPercentage));
			descriptionStrBfr.append(rcpttxt).append(KohlsPOCConstant.SPACE)
					.append(discountPercentage).append(
							KohlsPOCConstant.PERCENT_SYMBOL);

		} else if (Integer.valueOf(
				KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(
				Integer.valueOf(promoSchemeCode))) { // Tier Buy Qty Get
			// % Promotion Sub-line
			String discountPercentage = String.valueOf(Integer
					.valueOf(strDiscountPercentage));
					/// KohlsPOCConstant.THOUSAND_INT);
			descriptionStrBfr.append(rcpttxt).append(KohlsPOCConstant.SPACE)
					.append(discountPercentage).append(
							KohlsPOCConstant.PERCENT_SYMBOL);

		} else if (Integer.valueOf(
				KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PRICE_POINT).equals(
				Integer.valueOf(promoSchemeCode))) { // BOGO Buy Qty Get
			// Price Point Promotion
			// Sub-line
			String discountAmount = String.valueOf(Double
					.valueOf(strDiscountAmount));

			descriptionStrBfr.append(bogoSetId).append(KohlsPOCConstant.SPACE)
					.append(KohlsPOCConstant.BUY_BOGO_DESC).append(
							KohlsPOCConstant.SPACE).append(
							XMLUtil.getAttribute(elePromo,
									KohlsPOCConstant.ATTR_INC_BUY_QTY)).append(
							KohlsPOCConstant.SPACE).append(
							KohlsPOCConstant.GET_1).append(
							KohlsPOCConstant.SPACE).append(discountAmount);

		} else if (Integer.valueOf(
				KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PERCENT_OFF).equals(
				Integer.valueOf(promoSchemeCode))) { // BOGO Buy Qty Get %
			// Promotion Sub-line
			String discountPercentage = String.valueOf(Integer
					.valueOf(strDiscountPercentage));
//					/ KohlsPOCConstant.THOUSAND_INT);
			descriptionStrBfr.append(bogoSetId).append(KohlsPOCConstant.SPACE)
					.append(KohlsPOCConstant.BUY_BOGO_DESC).append(
							KohlsPOCConstant.SPACE).append(
							XMLUtil.getAttribute(elePromo,
									KohlsPOCConstant.ATTR_INC_BUY_QTY)).append(
							KohlsPOCConstant.SPACE).append(
							KohlsPOCConstant.GET_1).append(
							KohlsPOCConstant.SPACE).append(discountPercentage)
					.append(KohlsPOCConstant.PERCENT_SYMBOL);

		} else if (Integer
				.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_GET_FREE).equals(
						Integer.valueOf(promoSchemeCode))) { // BOGO Buy Qty
			// Get Free
			// Promotion
			// Sub-line
			descriptionStrBfr.append(bogoSetId).append(KohlsPOCConstant.SPACE)
					.append(KohlsPOCConstant.BUY_BOGO_DESC).append(
							KohlsPOCConstant.SPACE).append(
							XMLUtil.getAttribute(elePromo,
									KohlsPOCConstant.ATTR_INC_BUY_QTY)).append(
							KohlsPOCConstant.SPACE).append(
							KohlsPOCConstant.GET_1).append(
							KohlsPOCConstant.SPACE).append(
							KohlsPOCConstant.FREE);

		}
		else if (Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_HUNDRED).equals(Integer.valueOf(promoSchemeCode)) || 
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_HUNDRED_ONE).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED_ONE).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED_THREE).equals(Integer.valueOf(promoSchemeCode)) 

				) {
			descriptionStrBfr.append(KohlsPOCConstant.PROMO_DISCOUNT_DESC);
		}
		
		XMLUtil.setAttribute(eleLineAdjustment, KohlsPOCConstant.A_DESCRIPTION,
				descriptionStrBfr.toString());
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.addDescription : LineAdjustment Element is \n"
						+ XMLUtil.getElementXMLString(eleLineAdjustment));
		logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.addDescription");
	}

	/**
	 * This method converts the Sales Hub Data string to element
	 * 
	 * @return
	 * @param Element
	 *            tempOrderEle
	 * @throws ParserConfigurationException
	 *             indicates a serious configuration error
	 * @throws SAXException
	 *             Encapsulate a general SAX error or warning
	 * @throws IOException
	 *             indicates an I/O exception of some sort has occurred
	 */
//XMLDiff changes - adding Exception in the throw list
	public void convertSalesHubDataAsElement(Element tempOrderEle)
			throws Exception,ParserConfigurationException, SAXException, IOException {
		logger
				.beginTimer("KohlsPoCGetOrderPriceUEFromTVS.convertSalesHubDataAsElement");
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.convertSalesHubDataAsElement : tempOrderEle Element is \n"
						+ XMLUtil.getElementXMLString(tempOrderEle));

		Element orderLinesEle = XMLUtil.getChildElement(tempOrderEle,
				KohlsPOCConstant.ELEM_ORDER_LINES);
		List<Element> awardList = XMLUtil.getElementsByTagName(orderLinesEle,
				KohlsPOCConstant.E_AWARD);
		if (awardList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element awardEle : awardList) {
				Element eleExtn = XMLUtil.getChildElement(awardEle,
						KohlsPOCConstant.E_EXTN);
				String strExtnSalHubData = eleExtn
						.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
				//Fix for defect 2274 - Start
				logger.debug("The strExtnSalHubData value is :" +strExtnSalHubData);
				if(!YFCCommon.isVoid(strExtnSalHubData)){
						Element salesHubDataEle = KohlsPoCPnPUtil
							.createElementFromXMLString(strExtnSalHubData);
						eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA,
							KohlsPOCConstant.EMPTY);
						XMLUtil.importElement(eleExtn, salesHubDataEle);
				}
				//Fix for defect 2274 - End
			}
		}
		logger
				.endTimer("KohlsPoCGetOrderPriceUEFromTVS.convertSalesHubDataAsElement");
	}

	/**
	 * This method removes few attributes from order Element
	 * 
	 * @return
	 * @param Element
	 *            tempOrderEle
	 */
	public void removeAttributes(Element tempOrderEle) {
		logger.beginTimer("KohlsPoCGetOrderPriceUEFromTVS.removeAttributes");
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.removeAttributes Start : tempOrderEle Element is \n"
						+ XMLUtil.getElementXMLString(tempOrderEle));

		List<Element> orderLineList = XMLUtil.getElementsByTagName(
				tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
		tempOrderEle
				.removeAttribute(KohlsPOCConstant.A_APPLY_ONLY_ITEM_LEVEL_PRICING_RULES);
		tempOrderEle.removeAttribute(KohlsPOCConstant.A_CURRENCY);
		tempOrderEle
				.removeAttribute(KohlsPOCConstant.A_ENABLE_MANAGER_OVERRIDES);
		tempOrderEle.removeAttribute(KohlsPOCConstant.A_IGNORE_ORDERING);
		tempOrderEle.removeAttribute(KohlsPOCConstant.A_LINE_PRICE_TOTAL);
		tempOrderEle.removeAttribute(KohlsPOCConstant.A_ORDER_TOTAL);
		tempOrderEle.removeAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
		tempOrderEle.removeAttribute(KohlsPOCConstant.A_SUB_TOTAL);
		if (orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element orderLineElement : orderLineList) {
				Element eleItem = XMLUtil.getChildElement(orderLineElement,
						KohlsPOCConstant.ELEM_ITEM);
				eleItem.removeAttribute(KohlsPOCConstant.A_PRODUCT_CLASS);
				Element eleExtn = XMLUtil.getChildElement(orderLineElement,
						KohlsPOCConstant.E_EXTN);
				orderLineElement.removeChild(XMLUtil.getChildElement(
						orderLineElement, KohlsPOCConstant.E_TEMP));
				List<Element> awardList = XMLUtil.getElementsByTagName(
						orderLineElement, KohlsPOCConstant.E_AWARD);
				for (Element awardElement : awardList) {
					awardElement.removeAttribute(KohlsPOCConstant.A_ITEM_ID);
					awardElement.removeAttribute(KohlsPOCConstant.A_UPC_CODE);
				}
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_ITEM_ID);
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_LINE_ADJUSTMENT);
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_LINE_PRICE);
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_ORDER_TOTAL);
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_LIST_PRICE);
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_QUANTITY);
				XMLUtil.removeAttribute(orderLineElement,
						KohlsPOCConstant.A_UNIT_OF_MEASURE);
			}
		}
		
		if(logger.isDebugEnabled())
			logger.debug("KohlsPoCGetOrderPriceUEFromTVS.removeAttributes End : tempOrderEle Element is \n"
						+ XMLUtil.getElementXMLString(tempOrderEle));
		logger.endTimer("KohlsPoCGetOrderPriceUEFromTVS.removeAttributes End ");
	}
		public void setProperties(Properties arg0) throws Exception  {
	this.props  =  arg0;
	}

}
