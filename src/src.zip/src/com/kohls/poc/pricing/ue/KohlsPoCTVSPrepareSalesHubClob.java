package com.kohls.poc.pricing.ue;

import java.text.DecimalFormat;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

/**************************************************************************
 * File : KohlsPoCTVSPrepareSalesHubClob.java Author : IBM 
 * Created : July 17 2015
 * Modified : July 17 2015 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 17/07/2015 IBM First Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2015. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * 
 * This class is used to construct Sales Hub Clob related attributes..
 * 
 */

public class KohlsPoCTVSPrepareSalesHubClob {

	// logger
		private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCTVSPrepareSalesHubClob.class.getName());

		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);


		public Element awardExtn;
		public Element eleData;

		// Constructor to initialise the attributes to be set

		public KohlsPoCTVSPrepareSalesHubClob(Element eleData, Element awardExtn) {		
			super();
			logger.beginTimer("KohlsPoCTVSPrepareSalesHubClob.constructor");
			this.awardExtn = awardExtn;

			this.eleData = eleData;

			this.eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_PROMO_INTERFACE_ID, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_GROUP_PRICE_ID, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_GROUP_RTL_AMOUNT, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_GROUP_RTL_QTY, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_MULTI_PRICE_IND, KohlsPOCConstant.EMPTY);

			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_ID, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_ID, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BUY_ITEM, KohlsPOCConstant.EMPTY);

			this.eleData.setAttribute(KohlsPOCConstant.A_OFFER_RCHD_QTY, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_OFFER_RCHD_AMT, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_DISC_LVL_CODE, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_TIER_QTY_RCHD, KohlsPOCConstant.ZERO_STR);
			this.eleData.setAttribute(KohlsPOCConstant.A_TIER_AMT_RCHD, KohlsPOCConstant.ZERO_STR);

			this.eleData.setAttribute(KohlsPOCConstant.A_PRECEDENCE, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_REBATE_INTFC_ID, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_PROMO_INTERFACE_SUB_ID, KohlsPOCConstant.EMPTY);
			
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_QTY_SH, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_AMT_SH, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_TOL_AMT_SH, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BUY_CRITERIA_TYPE, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_QTY_SH, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_DOL_OFF_AMT_SH, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT_SH, KohlsPOCConstant.EMPTY);
			this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_PRPT_AMT_SH, KohlsPOCConstant.EMPTY);	
			
			this.eleData.setAttribute(KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.EMPTY);
			
			logger.endTimer("KohlsPoCTVSPrepareSalesHubClob.constructor");

		}
		
		/*public void prepareSalesHubData(Element pluOfferResponseEle, Element modifierEle, Element extnEle,
				Element recordEle, Element pluFileRecordEle, String rebateInterfaceId, String promotionType){
			logger.beginTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");
			prepareSalesHubData(pluOfferResponseEle, modifierEle, extnEle,
					recordEle, pluFileRecordEle, rebateInterfaceId, promotionType,null);
			logger.endTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");
		}
*/
		//new meth
		public void prepareSalesHubData(Element tvsOfferResponseEle, Element modifierEle, Element extnEle,
				Element tvsPromoEle, String rebateInterfaceId, String promotionType){
			logger.beginTimer("KohlsPoCTVSPrepareSalesHubClob.prepareSalesHubData");
			prepareSalesHubData(tvsOfferResponseEle, modifierEle, extnEle,
					tvsPromoEle, rebateInterfaceId, promotionType,null);
			logger.endTimer("KohlsPoCTVSPrepareSalesHubClob.prepareSalesHubData");
		}
		
		
		/**
		 * * Method Name : prepareSalesHubData Description : This method constructs
		 * attributes required to form Sales Hub Clob
		 * 
		 * @param pluOfferResponseEle
		 *            -
		 * @param modifierEle
		 * @param extnEle
		 * @param recordEle
		 * @param promotionType
		 */
		public void prepareSalesHubData(Element tvsOfferResponseEle, Element modifierEle, Element extnEle,
				Element tvsPromoEle, String rebateInterfaceId, String promotionType,String associateDiscount) {

			logger.beginTimer("KohlsPoCTVSPrepareSalesHubClob.prepareSalesHubData");

			logger.debug("#Method prepareSalesHubData: # Argument PromotionType value: " + promotionType);

			logger.debug("#Method prepareSalesHubData: # Argument rebateInterfaceId value: " + rebateInterfaceId);

			try 
			{

				if (null != tvsOfferResponseEle) {
					if(logger.isDebugEnabled()){
					logger.debug("#Method prepareSalesHubData: #Argument pluOfferResponseEle value: " + XMLUtil.getElementXMLString(tvsOfferResponseEle));
					}
				}

				if (null != modifierEle) {
					if(logger.isDebugEnabled()){
					logger.debug("#Method prepareSalesHubData: #Argument modifierEle value: " + XMLUtil.getElementXMLString(modifierEle));
					}
				}

				if (null != extnEle){
					if(logger.isDebugEnabled()){
					logger.debug("#Method prepareSalesHubData: #Argument extnEle value: " + XMLUtil.getElementXMLString(extnEle));
					}
				}

				if (null != tvsPromoEle){
					if(logger.isDebugEnabled()){
					logger.debug("#Method prepareSalesHubData: #Argument recordEle value: " + XMLUtil.getElementXMLString(tvsPromoEle));
					}
				}

				String promoSchemeCode = XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME);

				if(YFCCommon.isStringVoid(promoSchemeCode)){
					if(!YFCCommon.isVoid(tvsPromoEle)){
						promoSchemeCode = XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_PROMO_SCHEME_CODE);
						//XMLDiff changes - Start
						XMLUtil.setAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME, promoSchemeCode);
						//XMLDiff changes - End
					}else{
						promoSchemeCode = KohlsPOCConstant.EMPTY;
					}
				}

				//Commenting for Performance improvement - XMLDiff
				//XMLUtil.setAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME, promoSchemeCode);
				
			

				logger.debug("#Method prepareSalesHubData: #promoSchemeCode value:" + promoSchemeCode);
				
				
				
				if(!XMLUtil.isVoid(rebateInterfaceId)){
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_REBATE_INTFC_ID, rebateInterfaceId);
				}
				logger.debug("#Method prepareSalesHubData: #rebateInterfaceId value:" + rebateInterfaceId);
				
				

				if (!XMLUtil.isVoid(promotionType)) {
					if (promotionType.equalsIgnoreCase(KohlsPOCConstant.AMOUNT_OFF)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_AMOUNT_OFF);
					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.PERCENT_OFF)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_PERCENT_OFF);

					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.KOHLS_CASH)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.KOHLS_CASH_DESC);
					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.SENIOR_DISCOUNT)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE);
					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.PROMO)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.E_PROMO);
					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.OFFER)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.E_OFFER);
					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE);
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(associateDiscount))));
					} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.REBATE)) {
						// DiscountType
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_REBATE);
					} // Added for Price Override
					else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.PRICE_OVERRIDE)){
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.PRICE_OVER_RIDE);
					}
				}

				// DiscountPercent - Populates only for Promo and not for offer
				// Rectified Discount Percent, as it should be divided by 1000 from Promo response
				if (!promotionType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)) {
					if(!XMLUtil.isVoid(XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_DISCOUNT_PERCENT))){
						double discountPercentDbl = Double.valueOf(XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_DISCOUNT_PERCENT)) / KohlsPOCConstant.THOUSAND_INT;
						logger.debug("#Method prepareSalesHubData: #discountPercent value:" + discountPercentDbl);
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(discountPercentDbl))));
					}else if(YFCCommon.isStringVoid(XMLUtil.getAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT))){
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT,
								KohlsPOCConstant.ZERO_STR);
					}
				}

				// PromoInterfaceId and PromoInterfaceSubId - Populates only for Promo and not for offer
				
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_PROMO_INTERFACE_ID,
						XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_PROMO_INTERFACE_ID));
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_PROMO_INTERFACE_SUB_ID,
						XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_PROMO_INTERFACE_SUB_ID));

		
				// Only when the promoSchemeCode is 0350
				if (!XMLUtil.isVoid(promoSchemeCode)
						&& Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode))) {

					// GroupPriceID
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GROUP_PRICE_ID,
							XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_PROMO_INTERFACE_ID));
				}

				// when the promoSchemeCode is 0350 or 0300
				if (!XMLUtil.isVoid(promoSchemeCode)
						&& (Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode)) || Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PROMO).equals(Integer.valueOf(promoSchemeCode)))) {

					DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					//Sudina - Defect fix for 693 - Start
					//String groupRetailAmt = twoDForm.format(Double.valueOf(XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_DISCOUNT_AMT)) / KohlsPOCConstant.HUNDRED_INT);
					String groupRetailAmt = twoDForm.format(Double.valueOf(XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_DISCOUNT_AMT)));
					//Sudina - Defect fix for 693 - End
					
					// GroupRtlAmount
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GROUP_RTL_AMOUNT,	groupRetailAmt);

					// GroupRtlQty
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GROUP_RTL_QTY,
							XMLUtil.getAttribute(tvsPromoEle, KohlsPOCConstant.ATTR_INC_BUY_QTY));

				}

				//for Offer
				String buyQty = "";
				String buyAmt = "";

				if (!XMLUtil.isVoid(tvsOfferResponseEle)) {
				//commented below for 5360 fix -- start
/*NodeList nlOffer = tvsOfferResponseEle.getElementsByTagName("offer");
					if(!XMLUtil.isVoid(nlOffer) && nlOffer.getLength()>0){
						for (int i=0; i < nlOffer.getLength(); i++){
							Element eleOffer = (Element)nlOffer.item(i);*/
							//commented below for 5360 fix -- end
							Element eleOffer = tvsOfferResponseEle;
							String bwpSelectionTypeCode = eleOffer.getAttribute("benefitWithPurchaseSelectionTypeCode");
							String tierLelNum =  eleOffer.getAttribute("tierLevelNumber");
							String tierLevelAchieved = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_LEVEL_ACHIEVED);
							
							if(YFCCommon.isStringVoid(tierLevelAchieved)){
								tierLevelAchieved = KohlsPOCConstant.ZERO;
							}
							
							if(!YFCCommon.isStringVoid(tierLelNum) && !YFCCommon.isStringVoid(tierLevelAchieved) ){
								if (tierLelNum.equalsIgnoreCase(tierLevelAchieved) && KohlsPOCConstant.GET.equalsIgnoreCase(bwpSelectionTypeCode)) {
									
									String bwpGetID = XMLUtil.getAttribute(eleOffer, "offerSectionBenefitWithPurchaseIdentifier");
									String getQty = XMLUtil.getAttribute(eleOffer, "getQuantity");
									String getDoller = XMLUtil.getAttribute(eleOffer, "getDollarOffAmount");
									String getPricePoint =  XMLUtil.getAttribute(eleOffer, "pricePoint");
									String getPercentOff =  XMLUtil.getAttribute(eleOffer, "benefitWithPurchaseGetPercentOffPercent");
									
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_ID, bwpGetID);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_QTY_SH, getQty);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_DOL_OFF_AMT_SH, getDoller);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT_SH, getPercentOff);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_PRPT_AMT_SH, getPricePoint);
									
									//Setting ExtnGetCriteriaType for Offers in AwardExtn--Start
									if (!YFCCommon.isStringVoid(getQty)  && KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(getPricePoint)) {
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PRICE_POINT);
										XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_PRICE_POINT);
									} else if (!YFCCommon.isStringVoid(getDoller)) {
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_DOLLAR_OFF);
										XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_DOLLAR_OFF);
									} else if (!YFCCommon.isStringVoid(getPercentOff)) {
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PERCENT_OFF);
										XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_PERCENT_OFF);
										//CPE-604 : Start : To populate disc percent for TLDs.
										XMLUtil.setAttribute(awardExtn, KohlsPOCConstant.A_DISCOUNT_PERCENT, getPercentOff);
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT, getPercentOff);
										//CPE-604 : End
									} else {
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PRICE_POINT);
										XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_PRICE_POINT);
									}
									//Setting ExtnGetCriteriaType for Offers in AwardExtn--End
								}
								
								if (tierLelNum.equalsIgnoreCase(tierLevelAchieved) &&KohlsPOCConstant.BUY.equalsIgnoreCase(bwpSelectionTypeCode)) {
									buyQty = XMLUtil.getAttribute(tvsOfferResponseEle, "buyQuantityToGiveBenefit");
									buyAmt = XMLUtil.getAttribute(tvsOfferResponseEle, "buyAmount");
									
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_ID, XMLUtil.getAttribute(tvsOfferResponseEle, "offerSectionBenefitWithPurchaseIdentifier"));
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_QTY_SH, buyQty);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_AMT_SH, buyAmt);
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_TOL_AMT_SH, XMLUtil.getAttribute(tvsOfferResponseEle, "toleranceAmount"));
									
									if (!YFCCommon.isStringVoid(buyQty)) {
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BUY_CRITERIA_TYPE, KohlsPOCConstant.A_BUY_QUANTITY);
									} else if (!YFCCommon.isStringVoid(buyAmt)) {
										XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BUY_CRITERIA_TYPE, KohlsPOCConstant.A_BUY_DOLLAR);
									}
								}
								
							}
						}
					//}
					//}
					
				
					
				

				/*
				 * Offer -
				 * {A_BWP_GET_ID,A_BWP_BUY_ID}---------------{XST_OFR_BWP/@OFR_SECT_BWP_ID
				 * based on XST_OFR_BWP/@BWP_SELN_TYP_CDE} {A_DISC_LVL_CODE
				 * -------------------------{XST_OFR[0]/@DISC_LVL_CDE}
				 * {A_OFFER_RCHD_AMT--------{Modifier/@TierActivationAchieved when
				 * PromoSchemeCode=1009 and buyQty>0}
				 * {A_OFFER_RCHD_QTY--------{Modifier/@TierActivationAchieved when
				 * PromoSchemeCode=1009 and buyAmt>0}
				 */

				// BuyItem - Irrespective of offer/promo will get populated.
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BUY_ITEM,
						XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_BUY_ITEM));
				
				
				
				if (!XMLUtil.isVoid(tvsOfferResponseEle)) {
					
					//promoSchemeCode
					String attrPromoSchemeCode = XMLUtil.getAttribute(tvsOfferResponseEle,KohlsPOCConstant.ATTR_PROMO_SCHEME_CODE);
					// ExtnPromoScheme from PLU Offer response
					XMLUtil.setAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME, attrPromoSchemeCode);
					
					if (!XMLUtil.isVoid(modifierEle)) {
						if (!XMLUtil.isVoid(buyQty) && !XMLUtil.isVoid(attrPromoSchemeCode)
								&& KohlsPOCConstant.CONST_TIER_OFFER_SCHME_CODE.equals(attrPromoSchemeCode) && Integer.parseInt(buyQty) > KohlsPOCConstant.ZERO_INT) {

							XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_OFFER_RCHD_QTY,
									XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED));
						}
					if (!XMLUtil.isVoid(buyAmt) && !XMLUtil.isVoid(attrPromoSchemeCode)
								&& KohlsPOCConstant.CONST_TIER_OFFER_SCHME_CODE.equals(attrPromoSchemeCode) && Double.parseDouble(buyAmt) > KohlsPOCConstant.ZERO_DBL) {
							
							XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_OFFER_RCHD_AMT,
									XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED));
						}
					}
					
					//Added for setting DiscLvlCode value
					String discLvlCode = XMLUtil.getAttribute(tvsOfferResponseEle, KohlsPOCConstant.ATTR_DISC_LVL_CODE);
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISC_LVL_CODE,KohlsPoCPnPUtil.getDiscLevelCodeFromTVS(discLvlCode));
					
									
				}
				
				if (!XMLUtil.isVoid(modifierEle)) {
					if(!YFCCommon.isVoid(promoSchemeCode))
					{
						
						if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
							XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_TIER_QTY_RCHD,
									XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED));
						}
						
						if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
							XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_TIER_AMT_RCHD,
									XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED));
						}
					}
					
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_PRECEDENCE,
							XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PRECEDENCE));

				}
				if(logger.isDebugEnabled()){
				logger.debug("#Method prepareSalesHubData: #SalesHubClobData value: " + XMLUtil.getElementXMLString(eleData));			
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				logger.error(e);
			}

			logger.endTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");
		}
}
