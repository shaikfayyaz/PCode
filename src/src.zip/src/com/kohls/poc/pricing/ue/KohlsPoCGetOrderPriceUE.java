package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.ypm.japi.ue.YPMGetOrderPriceUE;

/**************************************************************************
 * File : KohlsPoCGetOrderPriceUE.java Author : IBM 
 * Created : August 28 2013
 * Modified :
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY 
 ***************************************************************************** 
 * V0.1 28/08/2013 IBM First Cut.
 * V0.2 30/08/2013 Populated following attributes
 * Order/@OrderTotal = list price - sum of all Adjustmentperunits for all lines
 * Order/@Subtotal - same as OrderTotal
 * Orderline/@LineTotal = List price - adjustment perunit for the current line.

 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the price and promo details for a given item
 * 
 * @author Baijayanta
 * @version 0.2
 *****************************************************************************/

public class KohlsPoCGetOrderPriceUE extends KOHLSBaseApi implements YPMGetOrderPriceUE {
	
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCGetOrderPriceUE.class.getName());
	}
	
	private String itemId = null;
	
	private Double listPrice = KohlsPOCConstant.ZERO_DBL;
    
	private Element orderLineEle = null;
	private Element pluPromoResponseEle = null;
	//private Map<String, Element> orderLineHM = null;
	//private Map<String, Element> pluPromoRecordHM = null;
	KohlsPoCOrderLinePromotionsCaller promoObj = null;
	KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj = null;
	
	public KohlsPoCGetOrderPriceUE() {
		promoObj =  new KohlsPoCOrderLinePromotionsCaller();
		offerAndKohlsCashObj = new KohlsPoCOrderPromotionsCaller();
		//orderLineHM = new HashMap<String, Element>();
		//pluPromoRecordHM = new HashMap<String, Element>();
	}
	
	/**
	 * This method receives UE input document and after processing returns back the UE output
	 * @return Document
	 * @param YFSEnvironment yfsEnv
	 * @param Document inDoc
	 * @throws YFSUserExitException
	 */
	
	public Document getInputDoc(YFSEnvironment yfsEnv, Document inDoc)throws YFSUserExitException {
		logger.beginTimer("KohlsPoCGetOrderPriceUE.getInputDoc");
		
		
		if(logger.isDebugEnabled()){
			logger.debug("Entering checkInputDoc method..");
			logger.debug(XMLUtil.getXMLString(inDoc));
		}
		Document ueOutDoc = null;
		try {
			Element tempOrderEle = inDoc.getDocumentElement();

			String shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ORG_CODE);

			// Appending zero when store number length is less than 4
			shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
			String extnRequestDateTime = KohlsPoCPnPUtil.getCurrentDateString();
			
			List <Element> orderLineList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
			if (orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
				for ( Element orderLine : orderLineList) {
					itemId = XMLUtil.getAttribute(orderLine, KohlsPOCConstant.A_ITEM_ID);
					orderLineEle = orderLine;
					
					if(logger.isDebugEnabled())
						logger.debug("Orderline Ele:" + XMLUtil.getElementXMLString(orderLineEle));
					
					
					// Start:  Defect fix:  Returning the indoc, in case of orderLine/Item if null
					
					 Element eleItem=XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_ITEM);
					 if(YFCCommon.isVoid(eleItem)){
						 return inDoc;
					 }
					 
					 // End:  Defect fix:  Returning the indoc, in case of orderLine/Item if null
				}
			}
			// To avoid Dummy SKU getting passed to PLU and APE
			if (null != itemId && !(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(itemId))) {

				KohlsPoCPLURequestCreator pluRequestForPRomo = new KohlsPoCPLURequestCreator(KohlsPOCConstant.SKU,shipNode);
				/* create PLU request */ 
				Document pluRequestDocument = pluRequestForPRomo.constructPLURequestDocument(itemId,extnRequestDateTime);
				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getXMLString(pluRequestDocument));
				/* make PLU web service call to get PLU response */
				Document pluPromoResponseDoc = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_PLU_WEB_SERVICE, pluRequestDocument);
				pluPromoResponseEle = pluPromoResponseDoc.getDocumentElement();
				
				verifyPricePromptIndicator(pluPromoResponseEle);
				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getXMLString(pluPromoResponseDoc));
				promoObj.insertGroupPricingPromoElement(pluPromoResponseEle);
				
				if(logger.isDebugEnabled())
					logger.debug("PLUPromoRespEle :"+XMLUtil.getElementXMLString(pluPromoResponseEle));
				//promoObj.insertGuidAttributeiInPromo(pluPromoResponseEle);
				//String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(orderLineEle, KohlsPOCConstant.E_TEMP,KohlsPOCConstant.A_GUID);
				//promoObj.getOrderLineHM().put(guidStr, orderLineEle);
				addPLUResponseInTempDoc(pluPromoResponseEle,orderLineEle);
				setPriceValue();
				KohlsPoCAPECaller apeCaller = new KohlsPoCAPECaller();
				/*create APE request */
				Document  apeRequestDoc = apeCaller.constructApeRequestForPriceVerify(tempOrderEle,promoObj.getOrderLineHM(),pluPromoResponseEle, yfsEnv);
				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getXMLString(apeRequestDoc));
				/*make APE web service call to get APE response */
				Document apeResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_APE_WEB_SERVICE, apeRequestDoc);
				
				Element apeResponseEle = apeResponse.getDocumentElement();
				
				if(logger.isDebugEnabled())
					logger.debug(XMLUtil.getXMLString(apeResponse));
				
				Element oriTempOrderEle= KohlsPoCPnPUtil.createElementFromXMLString(XMLUtil.getElementXMLString(tempOrderEle));
				List <Element> apeItemList = XMLUtil.getElementsByTagName(apeResponseEle, KohlsPOCConstant.E_ITEM);
					if (apeItemList.size() > KohlsPOCConstant.ZERO_INT) {
						prepareDocumentForSalesHub(apeResponseEle,tempOrderEle,promoObj,offerAndKohlsCashObj,apeItemList,yfsEnv);
						
						if(logger.isDebugEnabled())
							logger.debug("XMLUtil.getDocumentForElement(tempOrderEle)"+XMLUtil.getXMLString(XMLUtil.getDocumentForElement(tempOrderEle)));
						KohlsPoCPnPUtil.removeTempElement(promoObj.getOrderLineHM());
						removeAttributes(tempOrderEle);
						KohlsCommonUtil.api.executeFlow(yfsEnv, "KohlsPoCGenerateAndStorePVMessage", XMLUtil.getDocumentForElement(tempOrderEle));
						ueOutDoc = constructUEOutputDocumentForPriceVerify(apeItemList, oriTempOrderEle);
						
						if(logger.isDebugEnabled())
							logger.debug("ueOutDoc:"+XMLUtil.getXMLString(ueOutDoc));
					}
					
					if(logger.isDebugEnabled())
						logger.debug(XMLUtil.getXMLString(ueOutDoc));
			
		}else{
			return inDoc;
		}
		
		} catch (YFSUserExitException ueException) {
			logger.error(ueException);
			ueException.printStackTrace();
			throw ueException;
		}catch (YFSException ex){
			logger.error(ex);
			ex.printStackTrace();
			throw ex;
		}catch (Exception exp) {
			exp.printStackTrace();
		}
		logger.debug("Exiting checkInputDoc method...");
		logger.endTimer("KohlsPoCGetOrderPriceUE.getInputDoc");

		return ueOutDoc;
		
	}
	
	private void removeAttributes(Element tempOrderEle)  {
		 List<Element> orderLineList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_APPLY_ONLY_ITEM_LEVEL_PRICING_RULES);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_CURRENCY);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_ENABLE_MANAGER_OVERRIDES);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_IGNORE_ORDERING);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_LINE_PRICE_TOTAL);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_ORDER_TOTAL);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
		 tempOrderEle.removeAttribute(KohlsPOCConstant.A_SUB_TOTAL);
		 if (orderLineList.size() > KohlsPOCConstant.ZERO_INT){
			 for(Element orderLineElement : orderLineList){
				 Element eleItem=XMLUtil.getChildElement(orderLineElement, KohlsPOCConstant.ELEM_ITEM);
				 eleItem.removeAttribute(KohlsPOCConstant. A_PRODUCT_CLASS);
				 Element eleExtn=XMLUtil.getChildElement(orderLineElement, KohlsPOCConstant.E_EXTN);
				 
			   List<Element> awardList=XMLUtil.getElementsByTagName(orderLineElement, "Award");
			     for(Element awardElement : awardList){
			    	 awardElement.removeAttribute(KohlsPOCConstant.A_ITEM_ID );
			    	 awardElement.removeAttribute(KohlsPOCConstant.A_UPC_CODE);
			    	//Element elementExtn=XMLUtil.getChildElement(awardElement, "Extn"); 
			    	//Element eleData=XMLUtil.getChildElement(elementExtn, "Data"); 
			    	//elementExtn.removeChild(eleData);
			     }
				 XMLUtil.removeAttribute(eleExtn, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE);
				 XMLUtil.removeAttribute(orderLineElement, KohlsPOCConstant.A_ITEM_ID);
				 XMLUtil.removeAttribute(orderLineElement, KohlsPOCConstant.A_LINE_ADJUSTMENT);
				 XMLUtil.removeAttribute(orderLineElement,KohlsPOCConstant.A_LINE_PRICE );
				 XMLUtil.removeAttribute(orderLineElement, KohlsPOCConstant.A_ORDER_TOTAL);
				 XMLUtil.removeAttribute(orderLineElement,KohlsPOCConstant.A_LIST_PRICE);
				 XMLUtil.removeAttribute(orderLineElement,KohlsPOCConstant.A_QUANTITY);
				 XMLUtil.removeAttribute(orderLineElement,KohlsPOCConstant.A_UNIT_OF_MEASURE);
				}
		 }
		
	}

	private void prepareDocumentForSalesHub(Element apeResponseEle,
			Element tempOrderEle, KohlsPoCOrderLinePromotionsCaller promoObj2,
			KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj2, List<Element> apeItemList,YFSEnvironment yfsEnv) throws Exception {
		new KohlsPoCPrepareUEResponse().updateUeDocumentFromApeResponse(apeResponseEle, tempOrderEle, promoObj, offerAndKohlsCashObj);
		constructUEOutputDocument(apeItemList, tempOrderEle,yfsEnv);
		convertSalesHubDataAsElement(tempOrderEle);
	}

	private void convertSalesHubDataAsElement(Element tempOrderEle) throws ParserConfigurationException, SAXException, IOException {
		 Element orderLinesEle  = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.ELEM_ORDER_LINES);
		 List<Element> awardList = XMLUtil.getElementsByTagName(orderLinesEle, KohlsPOCConstant.E_AWARD);
		 if (awardList.size() > KohlsPOCConstant.ZERO_INT){
			 for(Element awardEle : awardList){
				 Element eleExtn=XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN); 
				 String strExtnSalHubData=eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);
				 Element  salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(strExtnSalHubData);
				 eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, KohlsPOCConstant.EMPTY);
				 XMLUtil.importElement(eleExtn, salesHubDataEle);
			 }
		 }
	}

	/**
	 * This method sets the value for lineprice and listprice
	 * @return 
	 */
	
	private void setPriceValue() {
		logger.beginTimer("KohlsPoCGetOrderPriceUE.setPriceValue");

		logger.debug("Entering setPriceValue method..");
		double dListPrice = KohlsPOCConstant.ZERO_DBL;
		Element linePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
		String orderLineUnitPrice = XMLUtil.getAttribute(linePriceInfo,KohlsPOCConstant.A_UNIT_PRICE);
		final List<Element> pluFileList = XMLUtil.getElementsByTagName(pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
		Element pluFileRecordEle = null;
		if(pluFileList.size() > KohlsPOCConstant.ZERO_INT && null != pluFileList.get(KohlsPOCConstant.ZERO_INT)){
			pluFileRecordEle = XMLUtil.getChildElement((Element)pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
			
			dListPrice = (Double.valueOf(XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_UNT_RTL_AMT))/KohlsPOCConstant.HUNDRED_INT);
			logger.debug("dlistPrice:"+dListPrice);
			listPrice = dListPrice;
			
	    }
		logger.debug("Exiting setPriceValue method..");
		logger.endTimer("KohlsPoCGetOrderPriceUE.setPriceValue");
	}	
	
	
	
		
	private void insertGroupPricingPromoElement(Element pluPromoResponseEle) {
		logger.beginTimer("KohlsPoCGetOrderPriceUE.insertGroupPricingPromoElement");

		this.logger.debug("Method Name : insertGroupPricingPromoElement   and   Status : Start ");
		final List<Element> pluFileList = XMLUtil.getElementsByTagName(pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT && null != pluFileList.get(KohlsPOCConstant.ZERO_INT)) {
			Element pluFileRecordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
			String groupPriceID = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_PRIC_ID);
			if(!YFCCommon.isStringVoid(groupPriceID)){
				String groupRetailAmount = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_AMT);

				if (!YFCCommon.isStringVoid(groupRetailAmount) && (Double.valueOf(groupRetailAmount).doubleValue() > KohlsPOCConstant.ZERO_DBL)) {
					Element parentEle = (Element) pluFileList.get(KohlsPOCConstant.ZERO_INT).getParentNode();
					Element promoEle = XMLUtil.getChildElement(parentEle, KohlsPOCConstant.E_PROMO, Boolean.TRUE);
					Element recordEle = XMLUtil.createChild(promoEle, KohlsPOCConstant.E_RECORD);
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE, KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO);
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_ID, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_PRIC_ID));
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_AMT));
					XMLUtil.setAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_GP_RTL_QTY));

				}
			}
		}
		this.logger.debug("Method Name : insertGroupPricingPromoElement   and   Status : End ");
		logger.endTimer("KohlsPoCGetOrderPriceUE.insertGroupPricingPromoElement");

	}
	
	
		
	/**
	 * 
	 * This method constructs UE output document
	 * @return Document
	 * @param  List<Element> apeItemList
	 * @param  Element orderEle
	 * @throws ParserConfigurationException indicates a serious configuration error
	 * @throws SAXException Encapsulate a general SAX error or warning
	 * @throws IOException indicates an I/O exception of some sort has occurred
	 * @throws ParseException indicates that an error has been reached unexpectedly while parsing
	 */
	
	private void constructUEOutputDocument(List<Element> apeItemList, Element orderEle,YFSEnvironment yfsEnv) throws ParserConfigurationException, SAXException, IOException, ParseException {
		
		logger.debug("Entering constructUEOutputDocument method..");
		String modifiedlistPrice = KohlsPOCConstant.EMPTY;
		
		//final Document ueRespDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
		double total = KohlsPOCConstant.ZERO_DBL;
		//Element orderEle =  ueRespDoc.getDocumentElement();
		String shipNode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_ORG_CODE);
		String currency = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_CURRENCY);
		String enterPriseCode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_ENTERPRISE_CODE);
		XMLUtil.setAttribute(orderEle,KohlsPOCConstant.A_APPLY_ONLY_ITEM_LEVEL_PRICING_RULES, KohlsPOCConstant.YES);
		XMLUtil.setAttribute(orderEle,KohlsPOCConstant.A_CURRENCY, currency);
		XMLUtil.setAttribute(orderEle,KohlsPOCConstant.A_ENABLE_MANAGER_OVERRIDES, KohlsPOCConstant.NO);
		XMLUtil.setAttribute(orderEle,KohlsPOCConstant.A_ENTERPRISE_CODE, enterPriseCode);
		//DecimalFormat twoDlinePrice = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);        
		XMLUtil.setAttribute(orderEle,KohlsPOCConstant.A_ORGANIZATION_CODE, shipNode);
		//String twoDlineTotal = KohlsPOCConstant.EMPTY;
		String lineTotalString = KohlsPOCConstant.EMPTY;
		Element ueOutputorderLines = XMLUtil.getChildElement(orderEle,KohlsPOCConstant.ELEM_ORDER_LINES,Boolean.TRUE);
		for ( Element itemApeEle : apeItemList) {
			Element ueOutputorderLine = XMLUtil.getChildElement(ueOutputorderLines,KohlsPOCConstant.ELEM_ORDER_LINE,Boolean.TRUE);
			//String bogoSetId = XMLUtil.getAttribute(itemApeEle,KohlsPOCConstant.A_BOGO_GRP_CODE);
			XMLUtil.setAttribute(ueOutputorderLine,KohlsPOCConstant.A_ITEM_ID, itemId);
			DecimalFormat twoDlistPrice = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			String listPriceString = twoDlistPrice.format(listPrice);
		
			XMLUtil.setAttribute(ueOutputorderLine, KohlsPOCConstant.A_LIST_PRICE,listPriceString);

			try {
				Element itemEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_ITEM);
				XMLUtil.setAttribute(itemEle, KohlsPOCConstant.A_UPC_CODE, KohlsPoCPnPUtil.getUpcCode(yfsEnv,itemId));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			DecimalFormat twoDlineAdj = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			String totalString = twoDlineAdj.format(total);
			XMLUtil.setAttribute(ueOutputorderLine,KohlsPOCConstant.A_LINE_ADJUSTMENT, totalString);
			double modifiedTotal = KohlsPOCConstant.ZERO_DBL;
			if ( !String.valueOf(total).equalsIgnoreCase(String.valueOf(KohlsPOCConstant.ZERO_DBL)) && String.valueOf(total).startsWith(KohlsPOCConstant.MINUS)) {
				//modifiedTotal = total * KohlsPOCConstant.MINUS_ONE ;
				modifiedTotal = Double.valueOf(Math.abs(total));
				
			} else {
				modifiedTotal = total;
			}
			
			double lineTotal = (Double.valueOf(listPrice)- modifiedTotal);
			logger.debug(lineTotal);
			DecimalFormat twoDlnTotal = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			lineTotalString = twoDlnTotal.format(lineTotal);
			XMLUtil.setAttribute(ueOutputorderLine, KohlsPOCConstant.A_LINE_TOTAL, lineTotalString);
			logger.debug(XMLUtil.getAttribute(ueOutputorderLine, KohlsPOCConstant.A_LINE_TOTAL));
			XMLUtil.setAttribute(ueOutputorderLine, KohlsPOCConstant.A_LINE_PRICE,lineTotalString);
		    
			 
			 
		}
		
		
		
		 XMLUtil.setAttribute(orderEle,KohlsPOCConstant.A_LINE_PRICE_TOTAL, lineTotalString);
		  
		 double modifiedOrderTotal = KohlsPOCConstant.ZERO_DBL;
		 if ( !String.valueOf(total).equalsIgnoreCase(String.valueOf(KohlsPOCConstant.ZERO_DBL)) && String.valueOf(total).startsWith(KohlsPOCConstant.MINUS)) {
			// modifiedOrderTotal = total * KohlsPOCConstant.MINUS_ONE ;
			modifiedOrderTotal = Double.valueOf(Math.abs(total));
		 } else {
			 modifiedOrderTotal = total;
		 }
		 double orderTotal = (Double.valueOf(listPrice)- modifiedOrderTotal);
		 DecimalFormat twoDoorderTotal = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		 String twoDorderTotal = twoDoorderTotal.format(orderTotal);
		 XMLUtil.setAttribute(orderEle, KohlsPOCConstant.A_ORDER_TOTAL, String.valueOf(twoDorderTotal));
		 logger.debug(XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_ORDER_TOTAL));
		 XMLUtil.setAttribute(orderEle, KohlsPOCConstant.A_SUB_TOTAL, String.valueOf(twoDorderTotal));
		 logger.debug(XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_SUB_TOTAL));
		 logger.debug("Exiting constructUEOutputDocument method..");
		
		 //return ueRespDoc;

	}
	
	/**
	 *  This method constructs and sets the value for promo description
	 *  @return
	 *  @param Element recordEle
	 *  @param String bogoSetId
	 *  @param Element ueOutAdjustment
	 */
	private void addDescription(Element recordEle, String bogoSetId, Element ueOutAdjustment) {
		logger.beginTimer("KohlsPoCGetOrderPriceUE.addDescription");

		logger.debug("Entering addDescription method..");
		String promoSchemeCode = XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_PROMO_SCHM_CDE);
		String rcpttxt = XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_RCPT_CMMT_TXT);
		
		/* If bogo group code is not empty and is "0" , set it to ""
		 * else set bogoSetId as ( <bogo group id> )and */
		if(!YFCCommon.isStringVoid(bogoSetId)){
			if(KohlsPOCConstant.ZERO.equalsIgnoreCase(bogoSetId)){
				bogoSetId=KohlsPOCConstant.EMPTY;
			}else{
				bogoSetId = KohlsPOCConstant.LEFT_BRACKET + bogoSetId + KohlsPOCConstant.RIGHT_BRACKET;
			}
		}
		
			
		StringBuffer descriptionStrBfr = new StringBuffer();
		
		/* Award Description for 'Gift with Purchase' , 'Gold star' are handled by Toshiba */
		if(Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode))|| Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PROMO).equals(Integer.valueOf(promoSchemeCode))){ //Group Pricing Sub-Line
			String groupRetailAmt = String.valueOf(Integer.valueOf(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_AMT))/KohlsPOCConstant.HUNDRED_INT);
				descriptionStrBfr.append(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_BUY_QTY_PROMO))
				.append(KohlsPOCConstant.SPACE)
				.append(KohlsPOCConstant.FOR_$)
				.append(groupRetailAmt);
				
				
		
		}else if(Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){ //Tier Buy Doller Get % Promotion Sub-line 
			String discountPercentage = String.valueOf(Integer.valueOf(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_PCT))/KohlsPOCConstant.THOUSAND_INT);
			 descriptionStrBfr.append(rcpttxt)
			.append(KohlsPOCConstant.SPACE)
			.append(discountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			 
			 
			 
		}else if(Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){ //Tier Buy Qty Get % Promotion Sub-line 
			String discountPercentage = String.valueOf(Integer.valueOf(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_PCT))/KohlsPOCConstant.THOUSAND_INT);
			 descriptionStrBfr.append(rcpttxt)
			.append(KohlsPOCConstant.SPACE)
			.append(discountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			 
		
		}else if(Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PRICE_POINT).equals(Integer.valueOf(promoSchemeCode))){ //BOGO Buy Qty Get Price Point Promotion Sub-line 
			String discountAmount = String.valueOf(Integer.valueOf(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_AMT))/KohlsPOCConstant.HUNDRED_INT);
			 	
				 descriptionStrBfr.append(bogoSetId)
				.append(KohlsPOCConstant.SPACE)
				.append(KohlsPOCConstant.BUY_BOGO_DESC)
				.append(KohlsPOCConstant.SPACE)
				.append(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_BUY_QTY_PROMO))		
				.append(KohlsPOCConstant.SPACE)
				.append(KohlsPOCConstant.GET_1 )
				.append(KohlsPOCConstant.SPACE)
				.append(discountAmount);
				 
		 	 
		}else if(Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){ //BOGO Buy Qty Get % Promotion Sub-line
			String discountPercentage = String.valueOf(Integer.valueOf(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_PCT))/KohlsPOCConstant.THOUSAND_INT);
			 descriptionStrBfr.append(bogoSetId)
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_BUY_QTY_PROMO))	
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(discountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
		
			
		}else if(Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_GET_FREE).equals(Integer.valueOf(promoSchemeCode))){ //BOGO Buy Qty Get Free Promotion Sub-line
			 descriptionStrBfr.append(bogoSetId)
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_BUY_QTY_PROMO))
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.FREE);	;
		
			
		}
		XMLUtil.setAttribute(ueOutAdjustment, KohlsPOCConstant.A_DESCRIPTION, descriptionStrBfr.toString());
		logger.debug("Exiting addDescription method..");
		logger.endTimer("KohlsPoCGetOrderPriceUE.addDescription");

	}
	public Document getOrderPrice(YFSEnvironment arg0, Document arg1)
			throws YFSUserExitException {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * If conditions satisfy the eligibility for PricePromptIndicator 
	 * throws the user exist exception with the 'PLUPRICEREQ' value.
	 *  
	 * @param pluPromoResponseEle
	 * @throws YFSUserExitException
	 */
	private void verifyPricePromptIndicator(
			Element pluPromoResponseEle) throws YFSException {
			logger.beginTimer("KohlsPoCGetOrderPriceUE.verifyPricePromptIndicator");
		this.logger.debug("Method Name : verifyPricePromptIndicator   and   Status : Start ");
		List<Element> pluFileList = XMLUtil.getElementsByTagName(
				pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT) {

			Element recordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);

			if (null != recordEle) {
				String priceOverrideInd = recordEle.getAttribute(KohlsPOCConstant.A_PRMPT_FOR_PRIC_IND);
				String multiPricePointIndicator =  recordEle.getAttribute(KohlsPOCConstant.A_MLT_PRPT_IND);
				String unitRetailAmt = recordEle.getAttribute(KohlsPOCConstant.A_UNT_RTL_AMT);

				if (KohlsPOCConstant.YES.equalsIgnoreCase(priceOverrideInd) || KohlsPOCConstant.YES.equalsIgnoreCase(multiPricePointIndicator)) {
					Element linePriceInfonewOrderLine = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);

					if (null != linePriceInfonewOrderLine) {
						String unitPrice = XMLUtil.getAttribute(linePriceInfonewOrderLine,
								KohlsPOCConstant.A_UNIT_PRICE);

						if (YFCCommon.isStringVoid(unitPrice) || KohlsPOCConstant.ZERO_DBL == Double.valueOf(unitPrice).doubleValue()) {
							YFSException yfsException = new YFSException();
							yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
							yfsException.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PRICEVERIFYPLUPRICEREQ));
							throw yfsException;
						}
					}
				}
			}
		}
		this.logger.debug("Method Name : verifyPricePromptIndicator   and   Status : End ");
		logger.endTimer("KohlsPoCGetOrderPriceUE.verifyPricePromptIndicator");

	}
	
	
	private void addPLUResponseInTempDoc(Element pluPromoResponseEle,Element orderLineEle) {
		this.logger.debug("Method Name : addPLUResponseInTempDoc   and   Status : Start ");
		promoObj.insertGuidAttributeiInPromo(pluPromoResponseEle);
		promoObj.insertGroupPricingPromoElement(pluPromoResponseEle);
		Element extnEle = XMLUtil.getChildElement(orderLineEle,
				KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE, XMLUtil
				.getElementXMLString(pluPromoResponseEle));
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE_FLAG, KohlsPOCConstant.YES);
		String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(orderLineEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);

		//logger.debug(XMLUtil.getElementXMLString(newOrderLineEle));


		promoObj.getOrderLineHM().put(guidStr, orderLineEle);
		this.logger.debug("Method Name : addPLUResponseInTempDoc   and   Status : End ");

	}
	
	/**
	 * 
	 * This method constructs UE output document
	 * @return Document
	 * @param  List<Element> apeItemList
	 * @param  Element orderEle
	 * @throws ParserConfigurationException indicates a serious configuration error
	 * @throws SAXException Encapsulate a general SAX error or warning
	 * @throws IOException indicates an I/O exception of some sort has occurred
	 * @throws ParseException indicates that an error has been reached unexpectedly while parsing
	 */
	
	private Document constructUEOutputDocumentForPriceVerify(List<Element> apeItemList, Element orderEle) throws ParserConfigurationException, SAXException, IOException, ParseException {
		
		logger.debug("Entering constructUEOutputDocument method..");
		String modifiedlistPrice = KohlsPOCConstant.EMPTY;
		
		final Document ueRespDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
		double total = KohlsPOCConstant.ZERO_DBL;
		Element ueRespDocEle =  ueRespDoc.getDocumentElement();
		String shipNode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_ORG_CODE);
		String currency = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_CURRENCY);
		String enterPriseCode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_ENTERPRISE_CODE);
		XMLUtil.setAttribute(ueRespDocEle,KohlsPOCConstant.A_APPLY_ONLY_ITEM_LEVEL_PRICING_RULES, KohlsPOCConstant.YES);
		XMLUtil.setAttribute(ueRespDocEle,KohlsPOCConstant.A_CURRENCY, currency);
		XMLUtil.setAttribute(ueRespDocEle,KohlsPOCConstant.A_ENABLE_MANAGER_OVERRIDES, KohlsPOCConstant.NO);
		XMLUtil.setAttribute(ueRespDocEle,KohlsPOCConstant.A_ENTERPRISE_CODE, enterPriseCode);
		//DecimalFormat twoDlinePrice = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);        
		XMLUtil.setAttribute(ueRespDocEle,KohlsPOCConstant.A_ORGANIZATION_CODE, shipNode);
		String twoDlineTotal = KohlsPOCConstant.EMPTY;
		String lineTotalString = KohlsPOCConstant.EMPTY;
		Element ueOutputorderLines = XMLUtil.createChild(ueRespDocEle,KohlsPOCConstant.ELEM_ORDER_LINES);
		for ( Element itemApeEle : apeItemList) {
			Element ueOutputorderLine = XMLUtil.createChild(ueOutputorderLines,KohlsPOCConstant.ELEM_ORDER_LINE);
			String bogoSetId = XMLUtil.getAttribute(itemApeEle,KohlsPOCConstant.A_BOGO_GRP_CODE);
			XMLUtil.setAttribute(ueOutputorderLine,KohlsPOCConstant.A_ITEM_ID, itemId);
			DecimalFormat twoDlistPrice = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			String listPriceString = twoDlistPrice.format(listPrice);
		
			XMLUtil.setAttribute(ueOutputorderLine, KohlsPOCConstant.A_LIST_PRICE,listPriceString);
			
			
			// Suresh : Added for Nike Exclusions Sprint 5 : Start
			
			Element extnEle = XMLUtil.getChildElement(ueOutputorderLine,
					KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM, XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.E_EXCLUSION_ITEM));
			// Suresh : Added for Nike Exclusions Sprint 5 : End
		
			
			List<Element> modifierEleList = XMLUtil.getElementsByTagName(itemApeEle, KohlsPOCConstant.E_MODIFIER);
			double taxPrice = KohlsPOCConstant.ZERO_DBL;
			if(null != modifierEleList && modifierEleList.size() > KohlsPOCConstant.ZERO_INT){
			  int count = KohlsPOCConstant.ZERO_INT;
			  for ( Element modifierEle : modifierEleList) {
						String modifierActive = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_MODIFIER_ACTIVE);
						String guidStr = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.E_PARENT_DISCOUNT_GUID);
						/* check for guid in pluPromoRecordHM hashmap */
						if(promoObj.getPluPromoRecordHM().containsKey(guidStr)) {
								 count++ ;
								 Element ueOutputLineAdjustments = XMLUtil.createChild(ueOutputorderLine,KohlsPOCConstant.E_LINE_ADJUSTMENTS);
								 Element ueOutputAdjustment = XMLUtil.createChild(ueOutputLineAdjustments,KohlsPOCConstant.E_ADJUSTMENT);
								 XMLUtil.setAttribute(ueOutputAdjustment, KohlsPOCConstant.A_ADJUSTMENT_ID, String.valueOf(count));
								 String taxPriceDelta = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TAXABLE_PRICE_DELTA);
								 taxPrice = Double.valueOf(taxPriceDelta);
								 DecimalFormat twoDtaxPrice = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
								 String taxPriceString = twoDtaxPrice.format(taxPrice);
								 XMLUtil.setAttribute(ueOutputAdjustment, KohlsPOCConstant.A_ADJUSTMENT_PER_UNIT,taxPriceString);
								 total = total + taxPrice;
								 Element recordEle = promoObj.getPluPromoRecordHM().get(guidStr);
								 addDescription(recordEle,bogoSetId,ueOutputAdjustment);
							
						}
			  
			  	}
			 
			}
			//XMLUtil.setAttribute(ueOutputorderLine,KohlsPOCConstant.A_LINE_ADJUSTMENT, String.valueOf(total));
			DecimalFormat twoDlineAdj = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			String totalString = twoDlineAdj.format(total);
			XMLUtil.setAttribute(ueOutputorderLine,KohlsPOCConstant.A_LINE_ADJUSTMENT, totalString);
			double modifiedTotal = KohlsPOCConstant.ZERO_DBL;
			if ( !String.valueOf(total).equalsIgnoreCase(String.valueOf(KohlsPOCConstant.ZERO_DBL)) && String.valueOf(total).startsWith(KohlsPOCConstant.MINUS)) {
				//modifiedTotal = total * KohlsPOCConstant.MINUS_ONE ;
				modifiedTotal = Double.valueOf(Math.abs(total));
				
			} else {
				modifiedTotal = total;
			}
			
			double lineTotal = (Double.valueOf(listPrice)- modifiedTotal);
			logger.debug(lineTotal);
			DecimalFormat twoDlnTotal = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			lineTotalString = twoDlnTotal.format(lineTotal);
			XMLUtil.setAttribute(ueOutputorderLine, KohlsPOCConstant.A_LINE_TOTAL, lineTotalString);
			logger.debug(XMLUtil.getAttribute(ueOutputorderLine, KohlsPOCConstant.A_LINE_TOTAL));
			XMLUtil.setAttribute(ueOutputorderLine, KohlsPOCConstant.A_LINE_PRICE,lineTotalString);
		    
			 
			 
		}
		
		
		
		 XMLUtil.setAttribute(ueRespDocEle,KohlsPOCConstant.A_LINE_PRICE_TOTAL, lineTotalString);
		  
		 double modifiedOrderTotal = KohlsPOCConstant.ZERO_DBL;
		 if ( !String.valueOf(total).equalsIgnoreCase(String.valueOf(KohlsPOCConstant.ZERO_DBL)) && String.valueOf(total).startsWith(KohlsPOCConstant.MINUS)) {
			// modifiedOrderTotal = total * KohlsPOCConstant.MINUS_ONE ;
			modifiedOrderTotal = Double.valueOf(Math.abs(total));
		 } else {
			 modifiedOrderTotal = total;
		 }
		 double orderTotal = (Double.valueOf(listPrice)- modifiedOrderTotal);
		 DecimalFormat twoDoorderTotal = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		 String twoDorderTotal = twoDoorderTotal.format(orderTotal);
		 XMLUtil.setAttribute(ueRespDocEle, KohlsPOCConstant.A_ORDER_TOTAL, String.valueOf(twoDorderTotal));
		 logger.debug(XMLUtil.getAttribute(ueRespDocEle, KohlsPOCConstant.A_ORDER_TOTAL));
		 XMLUtil.setAttribute(ueRespDocEle, KohlsPOCConstant.A_SUB_TOTAL, String.valueOf(twoDorderTotal));
		 logger.debug(XMLUtil.getAttribute(ueRespDocEle, KohlsPOCConstant.A_SUB_TOTAL));
		 logger.debug("Exiting constructUEOutputDocument method..");
		
		 return ueRespDoc;

	}
	
}

