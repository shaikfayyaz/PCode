package com.kohls.poc.pricing.ue;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.returns.api.KohlsPOCPriceAdjustment;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCRepriceUEWrapper {
  private static YFCLogCategory logger;
  private Properties props;
  HashMap<String, Element> mapOLPromotionToBeReset = new HashMap<String, Element>();
  static {
    logger = YFCLogCategory.instance(KohlsPoCTVSOrderRepriceUE.class.getName());
  }

  public Document orderReprice(YFSEnvironment yfsEnv, Document inDoc) throws Exception {
    logger.beginTimer("KohlsPoCRepriceUEWrapper.orderReprice");
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCRepriceUEWrapper.orderReprice  ---- \n Input to orderReprice"
          + XMLUtil.getXMLString(inDoc));
    }

    Element eleOrderExtn =
        XMLUtil.getChildElement(inDoc.getDocumentElement(), KohlsPOCConstant.E_EXTN);
    Element eleOrderCustAttribs = 
    		 XMLUtil.getChildElement(inDoc.getDocumentElement(), KohlsPOCConstant.CUST_ATTRIBUTES);
    String sExtnPsaStatus = "";
    if (!YFCCommon.isVoid(eleOrderExtn)) {
      sExtnPsaStatus = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
    }

    yfsEnv.setTxnObject(KohlsPOCConstant.EXTN_POC_FEATURE, KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT);
    Document outDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    int eligibleLineCounter = 0;

    if (!YFCCommon.isVoid(yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE))) {
      String ignoreRepricingUE = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE);

      if (KohlsPOCConstant.TRUE.equalsIgnoreCase(ignoreRepricingUE)) {
        yfsEnv.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
        if (!YFCCommon.isVoid(sExtnPsaStatus) && ("PA_MIDVOID".equalsIgnoreCase(sExtnPsaStatus)
            || "PA_VOID".equalsIgnoreCase(sExtnPsaStatus))) {
          return inDoc;
        } else {
          return outDoc;
        }
      }
    }
    Document dOrderInputClone = (Document) inDoc.cloneNode(true);

    Element eleOrderInputClone = dOrderInputClone.getDocumentElement();
    KohlsPoCTVSOrderRepriceUE oTVSReprice = new KohlsPoCTVSOrderRepriceUE();

    // CAPE-79 -- Associate discount for PA -- Start

    eleOrderInputClone
        .removeChild(XMLUtil.getChildElement(eleOrderInputClone, KohlsPOCConstant.E_PROMOTIONS));
    XMLUtil.createChild(eleOrderInputClone, KohlsPOCConstant.E_PROMOTIONS);

    // CAPE-79 -- Associate discount for PA -- End
    /*
     * if(!YFCCommon.isVoid(eleAssocPromo)) XMLUtil.importElement(elePromotions, eleAssocPromo);
     */
    eleOrderInputClone.setAttribute(KohlsPOCConstant.A_DRAFT_ORDER_FLAG, KohlsPOCConstant.YES);
    Element eorderLines =
        XMLUtil.getChildElement(eleOrderInputClone, KohlsPOCConstant.ELEM_ORDER_LINES);
    List<Element> orderLineEleList =
        XMLUtil.getElementsByTagName(eleOrderInputClone, KohlsPOCConstant.ELEM_ORDER_LINE);
    for (int i = 0; i < orderLineEleList.size(); i++) {
      Element eleOrderLine = orderLineEleList.get(i);
      Element eleCustomAttr =
          (Element) eleOrderLine.getElementsByTagName("CustomAttributes").item(0);

      if (!eleCustomAttr.getAttribute("Text11").equalsIgnoreCase("Eligible")) {

        XMLUtil.removeChild(eorderLines, eleOrderLine);
        // i--;

      } else {
        eligibleLineCounter++;
      }
    }

    if (eligibleLineCounter == 0) {
      return inDoc;
    }

    if (logger.isDebugEnabled()) {
      logger.debug(
          "KohlsPoCRepriceUEWrapper.orderReprice calling KohlsPoCTVSOrderRepriceUE class----- \n Input to orderReprice"
              + XMLUtil.getXMLString(eleOrderInputClone.getOwnerDocument()));
    }
    Document dEligibleClone = (Document) eleOrderInputClone.getOwnerDocument().cloneNode(true);
    eleOrderInputClone = this.removeLinePromotionAndCharges(eleOrderInputClone);
    Document docTVSoutput = oTVSReprice.orderReprice(yfsEnv, eleOrderInputClone.getOwnerDocument());
    if (logger.isDebugEnabled()) {
      logger.debug(
          "KohlsPoCRepriceUEWrapper.orderReprice calling KohlsPoCTVSOrderRepriceUE class----- \n Response from orderReprice"
              + XMLUtil.getXMLString(docTVSoutput));
    }
    // CAPE-79 -- Associate discount for PA -- Start
    Element eleTvsOutOrderPromotions =
        XMLUtil.getChildElement(docTVSoutput.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS);
    Element eleTvsOutOrderPromotion =
        XMLUtil.getChildElement(eleTvsOutOrderPromotions, KohlsPOCConstant.E_PROMOTION);

    if (!YFCCommon.isVoid(eleTvsOutOrderPromotion)) {
      Element eleInOrderPromotions = XMLUtil.getChildElement(dEligibleClone.getDocumentElement(),
          KohlsPOCConstant.E_PROMOTIONS);
      NodeList inOrderPromotions = null;
      /*
       * List<Element> inOrderPromotinsList = XMLUtil.getElementsByTagName(eleInOrderPromotions,
       * KohlsPOCConstant.E_PROMOTION);
       */
      inOrderPromotions = eleInOrderPromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
      for (int i = 0; i < inOrderPromotions.getLength(); i++) {
        Element elePromo = (Element) inOrderPromotions.item(i);
        if (XMLUtil.getAttribute(elePromo, KohlsPOCConstant.A_PROMOTION_TYPE)
            .equals((KohlsPOCConstant.ASSOCIATE_DISCOUNT))) {
          eleInOrderPromotions.removeChild(elePromo);
          break;
        }
      }
      XMLUtil.importElement(eleInOrderPromotions, eleTvsOutOrderPromotion);

    }

    // CAPE-79 -- Associate discount for PA -- End

    KohlsPOCPriceAdjustment opriceAdj = new KohlsPOCPriceAdjustment();

    logger
        .debug("KohlsPoCRepriceUEWrapper.orderReprice calling KohlsPOCPriceAdjustment class----- ");

    outDoc = opriceAdj.processPriceAdjustedItems(yfsEnv, dEligibleClone, docTVSoutput,
        mapOLPromotionToBeReset);

    if (logger.isDebugEnabled()) {
      logger.debug(
          "KohlsPoCRepriceUEWrapper.orderReprice calling KohlsPoCTVSOrderRepriceUE class----- \n Response from KohlsPOCPriceAdjustment"
              + XMLUtil.getXMLString(outDoc));
    }
    /* Added for Kohl's Cash promotion - Start */
    double dQualifyingAmt = KohlsPOCConstant.ZERO_DBL;
    double dTotalRKCAmt = KohlsPOCConstant.ZERO_DBL;
    String sRuleValue = null;
    double dRuleValue = 0.00;
    DecimalFormat df = new DecimalFormat("#0.00");
    /* Added for Kohl's Cash promotion - End */
    /*
     * Element eleOrigOrder = inDoc.getDocumentElement(); Element eleOrigOrderLines = (Element)
     * eleOrigOrder.getElementsByTagName("OrderLines").item(0); NodeList nlOrderLines =
     * eleOrigOrder.getElementsByTagName(KohlsPOCConstant.E_ORDER_LINE); Element eleTVSoutput =
     * outDoc.getDocumentElement();
     */
    Element eleOutRoot = outDoc.getDocumentElement();
    Element eleInRoot = inDoc.getDocumentElement();
    Element eleOutOrderLines =
        XMLUtil.getChildElement(eleOutRoot, KohlsPOCConstant.ELEM_ORDER_LINES);
    ArrayList<String> arrayPAQualifiedLines = new ArrayList<String>();
    NodeList nlOutOrderLine = eleOutRoot.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    for (int i = 0; i < nlOutOrderLine.getLength(); i++) {
      Element eleOutOrderLine = (Element) nlOutOrderLine.item(i);

      String sOutPrimeLineNumber =
          eleOutOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
      Element eOrigOrderLine = (Element) XPathUtil.getNode(eleInRoot,
          "//OrderLines/OrderLine[@PrimeLineNo='" + sOutPrimeLineNumber + "']");
      //CPE-23 changes forAdj Tax Fee
      String sMultOrderNmbr = XMLUtil.getAttribute(eleOrderCustAttribs,KohlsPOCConstant.TEXT13);
      if(YFCCommon.isVoid(sMultOrderNmbr)){
    	  updateAdjTaxFee(i, eleOutOrderLine, eOrigOrderLine);
      }
      
      Element eleOutCustomAttributes =
          XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.CUST_ATTRIBUTES);
      Element eleOutOrderLineExtn =
          XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.E_EXTN);
      String sExtnIsPriceEntered =
          eleOutOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);
      double dOrigReturnPrice = 0.00;
      double dCurrentReturnPrice = 0.00;
      if (!YFCCommon.isVoid(sExtnIsPriceEntered) && "Y".equalsIgnoreCase(sExtnIsPriceEntered)) {
        continue;
      }
      String sSkuStatusCode =
          eleOutOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE);
      if (!YFCCommon.isVoid(sSkuStatusCode) && "30".equalsIgnoreCase(sSkuStatusCode)) {
        continue;
      }
      if (!YFCCommon.isVoid(eleOutCustomAttributes) && !YFCCommon.isVoid(eleOutOrderLineExtn)) {
        String sText12 = eleOutCustomAttributes.getAttribute("Text12");
        String sExtnReturnPrice =
            eleOutOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
        if (!YFCCommon.isVoid(sText12) && !YFCCommon.isVoid(sExtnReturnPrice)) {
          dOrigReturnPrice = Double.parseDouble(sText12);
          dCurrentReturnPrice = Double.parseDouble(sExtnReturnPrice);
          if (Double.compare(dCurrentReturnPrice, dOrigReturnPrice) == 0) {
            eleOutOrderLines.removeChild(eleOutOrderLine);
            i--;
            continue;
          } else if (Double.compare(dCurrentReturnPrice, dOrigReturnPrice) < 0) {
            dQualifyingAmt = dQualifyingAmt + dOrigReturnPrice;
            arrayPAQualifiedLines
                .add(eleOutOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY));
          } else {
            // removing the unadjusted price related attributes so that
            // Price remains same in case of current price is higher. We dont want to
            // Reduce the credit_memo amount
            Element eleCurrentLinePriceInfo =
                XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
            Element eleCurrentLineCharges =
                XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
            Element eleCurrentLineTaxes =
                XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);
            if (!YFCCommon.isVoid(eleCurrentLinePriceInfo)) {
              eleOutOrderLine.removeChild(eleCurrentLinePriceInfo);
            }
            if (!YFCCommon.isVoid(eleCurrentLineCharges)) {
              eleOutOrderLine.removeChild(eleCurrentLineCharges);
            }
            if (!YFCCommon.isVoid(eleCurrentLineTaxes)) {
              eleOutOrderLine.removeChild(eleCurrentLineTaxes);
            }
            Element eleOrigLinePriceInfo =
                XMLUtil.getChildElement(eOrigOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
            Element eleOrigLineCharges =
                XMLUtil.getChildElement(eOrigOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
            Element eleOrigLineTaxes =
                XMLUtil.getChildElement(eOrigOrderLine, KohlsPOCConstant.ELEM_LINE_TAXES);

            if (!YFCCommon.isVoid(eleOrigLinePriceInfo)) {
              Element eleOrigLinePriceInfo_Temp =
                  (Element) outDoc.importNode(eleOrigLinePriceInfo, true);
              eleOutOrderLine.appendChild(eleOrigLinePriceInfo_Temp);
            }
            if (!YFCCommon.isVoid(eleOrigLineCharges)) {
              Element eleOrigLineCharges_Temp =
                  (Element) outDoc.importNode(eleOrigLineCharges, true);
              eleOutOrderLine.appendChild(eleOrigLineCharges_Temp);
            }
            if (!YFCCommon.isVoid(eleOrigLineTaxes)) {
              Element eleOrigLineTaxes_Temp = (Element) outDoc.importNode(eleOrigLineTaxes, true);
              eleOutOrderLine.appendChild(eleOrigLineTaxes_Temp);
            }
          }
        }
      }

      /*
       * if (!YFCCommon.isVoid(eTempOrderLine)) { eLine = (Element) inDoc.importNode(eTempOrderLine,
       * true); eleOrigOrderLines.replaceChild(eLine, eleOrderLine); }
       */
      /* Added for Kohl's Cash promotion - Start */
      if (!YFCCommon.isVoid(eOrigOrderLine)) {
        Element eleOrigLineCharges = (Element) XMLUtil.getFirstElementByName(eOrigOrderLine,
            KohlsPOCConstant.ELEM_LINE_CHARGES);
        if (!YFCCommon.isVoid(eleOrigLineCharges)) {
          NodeList nlOrigLineCharge =
              eleOrigLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
          if (nlOrigLineCharge.getLength() > 0) {
            for (int l = 0; l < nlOrigLineCharge.getLength(); l++) {
              Element eleOrigLineCharge = (Element) nlOrigLineCharge.item(l);
              String sChargeCategory =
                  eleOrigLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
              if (KohlsPOCConstant.KOHLS_CASH_DISCOUNT.equals(sChargeCategory)
                  && Double.compare(dCurrentReturnPrice, dOrigReturnPrice) < 0) {
                String sChargePerLine =
                    eleOrigLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
                dTotalRKCAmt = dTotalRKCAmt + Double.parseDouble(sChargePerLine);
              }
            }
          }
        }
      }
      /* Added for Kohl's Cash promotion - End */
    }

    // Storing the PA Qualified lines to Env
    yfsEnv.setTxnObject("PA_QALIFIED_LINES", arrayPAQualifiedLines);

    checkAndAdjustLineChargeForAssocDiscount(outDoc);

    /* Added for Kohl's Cash promotion - Start */
    NodeList nlPromotion = eleInRoot.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    if (nlPromotion.getLength() > 0) {
      for (int k = 0; k < nlPromotion.getLength(); k++) {
        Element elePromotion = (Element) nlPromotion.item(k);
        String promotionType =
            XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_TYPE);
        Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN);
        if (KohlsPOCConstant.KOHLS_CASH_REISSUE.equals(promotionType)) {
          Document docRuleListForPOS = this.callGetRuleListForPOS(yfsEnv);
          if (!YFCCommon.isVoid(docRuleListForPOS)) {
            NodeList nlRuleListFosOS = docRuleListForPOS.getElementsByTagName("Rule");
            Element eleRule = (Element) nlRuleListFosOS.item(0);
            if (!YFCCommon.isVoid(eleRule)) {
              sRuleValue = eleRule.getAttribute("RuleValue");
              if (!YFCCommon.isVoid(sRuleValue)) {
                dRuleValue = Double.parseDouble(sRuleValue);
              }
            }
          }
          if (dTotalRKCAmt > 0) {
            if (dTotalRKCAmt < dRuleValue) {
              XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                  df.format(dRuleValue));
            } else {
              XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
                  df.format(dTotalRKCAmt));
            }
            XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, "Y");
          } else {
            XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, "N");
          }
          XMLUtil.setAttribute(elePromotionExtn, KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT,
              df.format(dTotalRKCAmt));
          XMLUtil.setAttribute(elePromotionExtn, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,
              df.format(dTotalRKCAmt));
          Element eleOutOrderPromotions =
              XMLUtil.getChildElement(eleOutRoot, KohlsPOCConstant.E_PROMOTIONS);
          if (YFCCommon.isVoid(eleOutOrderPromotions)) {
            eleOutOrderPromotions = XMLUtil.createChild(eleOutRoot, KohlsPOCConstant.E_PROMOTIONS);
          }
          XMLUtil.importElement(eleOutOrderPromotions, elePromotion);
        }
      }
    }

    String sPaTax = getAdjustedTax(outDoc);

    Element eleNote = (Element) XPathUtil.getNode(inDoc.getDocumentElement(),
        "//Notes/Note[@NoteText='" + "PriceAdjustment" + "']");

    if (!YFCCommon.isVoid(eleNote) && !YFCCommon.isVoid(sPaTax)) {

      if (logger.isDebugEnabled()) {
        logger.debug("Noted conatains ---> " + XMLUtil.getElementXMLString(eleNote));
      }

      eleNote.setAttribute("NoteText", "PriceAdjustment" + '_' + sPaTax);
    }
    /* Added for Kohl's Cash promotion - End */
    logger.endTimer("KohlsPoCRepriceUEWrapper.orderReprice");
    return outDoc;
  }

  /**This method updates the Adj Tax Fee at line award level for CPE-23
   * @param i
   * @param eleOutOrderLine
   * @param eOrigOrderLine
   * @throws Exception
   * @throws NumberFormatException
   */
  private void updateAdjTaxFee(int i, Element eleOutOrderLine,Element eOrigOrderLine) 
		  throws Exception, NumberFormatException {
	  logger.beginTimer("KohlsPoCRepriceUEWrapper.updateAdjTaxFee");
	  try{
		  DecimalFormat df = new DecimalFormat("#0.00");
		  Element eleOutAwards = XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.E_AWARDS);
		  Element eleOrigAwards = XMLUtil.getChildElement(eOrigOrderLine, KohlsPOCConstant.E_AWARDS);
		  NodeList nlOutAwards = eleOutAwards.getElementsByTagName(KohlsPOCConstant.E_AWARD);
		  if(nlOutAwards.getLength()>0){
			  for (int t = 0; t < nlOutAwards.getLength(); t++) {
				  Element eleOutAward = (Element) nlOutAwards.item(t);
				  Element eleOutAwardExtn = XMLUtil.getChildElement(eleOutAward, KohlsPOCConstant.E_EXTN);
				  String awardPromoID = XMLUtil.getAttribute(eleOutAward, KohlsPOCConstant.A_PROMOTION_ID);
				  String awardChargeCategory = XMLUtil.getAttribute(eleOutAward, KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
				  if(!YFCCommon.isVoid(awardChargeCategory) && KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(awardChargeCategory)){
					  Element eleOrigAward = (Element) XPathUtil.getNode(eleOrigAwards,
							  "//Award[@PromotionId='" + awardPromoID + "']");
					  String strOrigAwardAmt = XMLUtil.getAttribute(eleOrigAward, KohlsPOCConstant.A_AWARD_AMOUNT);
					  String stOutAwardAmt = XMLUtil.getAttribute(eleOutAward, KohlsPOCConstant.A_AWARD_AMOUNT);
					  if(YFCCommon.isVoid(strOrigAwardAmt)){strOrigAwardAmt = KohlsPOCConstant.ZERO_STR;}
					  if(YFCCommon.isVoid(stOutAwardAmt)){strOrigAwardAmt = KohlsPOCConstant.ZERO_STR;}

					  double dAdjTaxFeeAmt = Math.abs(Double.valueOf(strOrigAwardAmt)) - Math.abs(Double.valueOf(stOutAwardAmt));
					  XMLUtil.setAttribute(eleOutAwardExtn, KohlsPOCConstant.A_EXTN_TAX_DELTA, String.valueOf(df.format(dAdjTaxFeeAmt)));
					  //XMLUtil.setAttribute(eleOutAward, KohlsPOCConstant.A_AWARD_AMOUNT, KohlsPOCConstant.MINUS+String.valueOf(df.format(dAdjTaxFeeAmt)));
				  }
			  }
		  }
		  Element eleOutOrderLineExtn = XMLUtil.getChildElement(eleOutOrderLine, KohlsPOCConstant.E_EXTN);
		  String strTaxableAmount = XMLUtil.getAttribute(eleOutOrderLineExtn, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT);
		  String strExtnBogoGPID = XMLUtil.getAttribute(eleOutOrderLineExtn, KohlsPOCConstant.A_EXTN_BOGO_GPID);
		  String strExtnBuyItem = XMLUtil.getAttribute(eleOutOrderLineExtn, KohlsPOCConstant.A_EXTN_BUY_ITEM);
		  if(!YFCCommon.isVoid(strTaxableAmount) && !YFCCommon.isVoid(strExtnBogoGPID) && 
				  Double.valueOf(strTaxableAmount)==0 && "1".equalsIgnoreCase(strExtnBogoGPID) 
				  && KohlsPOCConstant.NO.equalsIgnoreCase(strExtnBuyItem)){
			  DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
			  Element eleOutLineTax = (Element)eleOutOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
			  Element eleOrigLineTax = (Element)eOrigOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
			  if(!YFCCommon.isVoid(eleOrigLineTax)){
				  String strOrigTaxPercentage = XMLUtil.getAttribute(eleOrigLineTax, KohlsPOCConstant.ATTR_TAX_PERCENT);
				  if(!YFCCommon.isVoid(strOrigTaxPercentage)){
					  double dTaxPercentage = Double.valueOf(strOrigTaxPercentage) * 100;
					  eleOutLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT,twoDForm.format(dTaxPercentage));
				  }
			  }

		  }
	  }catch (Exception e){
		  logger.debug("Exception while calculating ADJ Tax Fee for PA from KohlsPoCRepriceUEWrapper.updateAdjTaxFee");
	  }
	  logger.endTimer("KohlsPoCRepriceUEWrapper.updateAdjTaxFee");
  }

  /**
   * Create By mrjoshi *
   * 
   * @param outDoc
   * @throws Exception 
   */
  private void checkAndAdjustLineChargeForAssocDiscount(Document outDoc) throws Exception {
    logger.beginTimer("KohlsPoCRepriceUEWrapper.checkAndAdjustLineChargeForAssocDiscount");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "checkAndAdjustLineChargeForAssocDiscount input xml is: " + XMLUtil.getXMLString(outDoc));
    }
    DecimalFormat df = new DecimalFormat("#0.00");
    double dReturnPriceRefundAmt = 0.00D;
    double dSterlingReturnPrice = 0.00D;
    NodeList nlOrderLine = outDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    for (int i = 0; i < nlOrderLine.getLength(); i++) {
      Element eleOrderLine = (Element) nlOrderLine.item(i);
      Element eleCustomAttributes =
          XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
      String sText12 = eleCustomAttributes.getAttribute("Text12");
      Double dText12 = 0.00D;
      if (!YFCCommon.isVoid(sText12)) {
        dText12 = Double.parseDouble(sText12);
      }
      Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_EXTN);
      String sReturnPriceAmt = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
      if (!YFCCommon.isVoid(sReturnPriceAmt) && Double.parseDouble(sReturnPriceAmt) < dText12) {
        dReturnPriceRefundAmt = dReturnPriceRefundAmt + (dText12 - Double.parseDouble(sReturnPriceAmt));
        Element eleLinePriceInfo =
            XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
        String sUnitPrice = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
        if (!YFCCommon.isVoid(sUnitPrice)) {
          dSterlingReturnPrice = dSterlingReturnPrice + (dText12 - Double.parseDouble(sUnitPrice));
          NodeList nlLineCharge =
              eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
          for (int j = 0; j < nlLineCharge.getLength(); j++) {
            Element eleLineCharge = (Element) nlLineCharge.item(j);
            String sChargeName = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
            String sChargePerLine = eleLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
            String sChargeCategory = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);
            if ("PriceOverrideIncreaseAmount".equalsIgnoreCase(sChargeName)) {
              dSterlingReturnPrice = dSterlingReturnPrice - Double.parseDouble(sChargePerLine);
            } else if(!KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(sChargeCategory)) {
              dSterlingReturnPrice = dSterlingReturnPrice + Double.parseDouble(sChargePerLine);
            }
          }
        }
      }
    }

    logger.debug("dReturnPriceRefundAmt is: " + df.format(dReturnPriceRefundAmt)
        + " and dSterlingReturnPrice is: " + df.format(dSterlingReturnPrice));

    if (Double.parseDouble(df.format(dReturnPriceRefundAmt - dSterlingReturnPrice)) > 0) {
      logger.debug("Refund amt doesnt add up. So adjust the amt");
      for (int i = 0; i < nlOrderLine.getLength(); i++) {
        Element eleOrderLine = (Element) nlOrderLine.item(i);
        Element eleAssocDiscLineCharge = (Element)XPathUtil.getNode(eleOrderLine, "//LineCharges/LineCharge[@ChargeName='AssociateDiscount']");
        if(!YFCCommon.isVoid(eleAssocDiscLineCharge)){
          eleAssocDiscLineCharge.setAttribute("ChargePerLine", df.format(Double.parseDouble(eleAssocDiscLineCharge.getAttribute("ChargePerLine"))
        		  +(dReturnPriceRefundAmt - dSterlingReturnPrice)));
          break;
        }
      }
    }
    else if (Double.parseDouble(df.format(dSterlingReturnPrice - dReturnPriceRefundAmt)) > 0) {
        logger.debug("Refund amt doesnt add up. So adjust the amt");
        for (int i = 0; i < nlOrderLine.getLength(); i++) {
          Element eleOrderLine = (Element) nlOrderLine.item(i);
          Element eleAssocDiscLineCharge = (Element)XPathUtil.getNode(eleOrderLine, "//LineCharges/LineCharge[@ChargeName='AssociateDiscount']");
          if(!YFCCommon.isVoid(eleAssocDiscLineCharge)){
            eleAssocDiscLineCharge.setAttribute("ChargePerLine", df.format(Double.parseDouble(eleAssocDiscLineCharge.getAttribute("ChargePerLine"))
            		- (dSterlingReturnPrice - dReturnPriceRefundAmt)));
            break;
          }
        }
      }
    if(logger.isDebugEnabled()){
      logger.debug("After adjustment outDoc is: "+XMLUtil.getXMLString(outDoc));
    }
    logger.endTimer("KohlsPoCRepriceUEWrapper.checkAndAdjustLineChargeForAssocDiscount");
  }

  /**
   * @param outDoc
   * @return
   */
  public String getAdjustedTax(Document outDoc) {

    logger.beginTimer("KohlsPoCRepriceUEWrapper.getAdjustedTax");
    double dTax = 0.0;
    NodeList ndlOrdderLine = outDoc.getElementsByTagName("OrderLine");

    for (int i = 0; i < ndlOrdderLine.getLength(); i++) {
      Element eleOrderLine = (Element) ndlOrdderLine.item(i);
      NodeList ndlLineTax = eleOrderLine.getElementsByTagName("LineTax");
      for (int k = 0; k < ndlLineTax.getLength(); k++) {

        Element eleLineTax = (Element) ndlLineTax.item(k);
        if (!YFCCommon.isVoid(eleLineTax)) {

          if (eleLineTax.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY).equals("Price")) {
            Element eleLineTaxExtn = (Element) eleLineTax.getElementsByTagName("Extn").item(0);
            // CAPE-2324 TaxExempt line is not able to PA
            if (!YFCCommon.isVoid(eleLineTaxExtn)) {
              String sOrignalTax = eleLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
              if(YFCCommon.isVoid(sOrignalTax)){
            	  sOrignalTax = KohlsPOCConstant.ZERO_STR;
              }
              double dtempTax = Double.parseDouble(sOrignalTax)
                  - Double.parseDouble(eleLineTax.getAttribute("Tax"));

              dTax = dTax + dtempTax;
            }
          }
        }
      }
    }
    logger.debug("Final tax to be return from getAdjustedTax method=" + String.valueOf(dTax));

    logger.endTimer("KohlsPoCRepriceUEWrapper.getAdjustedTax");
    return String.valueOf(dTax);
  }

  /**
   * 
   * @param arg0 the properties variable
   * @throws Exception the exception
   */
  public void setProperties(Properties arg0) throws Exception {
    this.props = arg0;
  }

  //
  /* Addded for getting RKC adjustment value - START */
  /**
   * Calling ruleList api to get rule List for RKC_ADJ_VALUE
   * 
   * @param env
   * @return
   * @throws DOMException
   * @throws Exception
   */
  private Document callGetRuleListForPOS(YFSEnvironment env) throws DOMException, Exception {
    // TODO Auto-generated method stub
    logger.beginTimer("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS");
    Document docRuleListForPOSOutput = null;

    Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
    Element eleInput = docInput.getDocumentElement();
    eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, "KOHLS-RETAIL");
    Element eleRuleMetadata = docInput.createElement("RuleMetadata");
    eleRuleMetadata.setAttribute("GroupName", "RKC_ADJ_VALUE");
    eleInput.appendChild(eleRuleMetadata);

    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS docInput="
          + XMLUtil.getXMLString(docInput));
    }
    docRuleListForPOSOutput =
        KOHLSBaseApi.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);

    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS docRuleListForPOSOutput="
          + XMLUtil.getXMLString(docRuleListForPOSOutput));
    }
    logger.endTimer("KohlsPoCTVSReturnOrderReprice.callGetRuleListForPOS");
    return docRuleListForPOSOutput;
  }

  /* Addded for getting RKC adjustment value - END */

  /**
   * Removes OrderLine promotions,awards.lineCharges
   * 
   * @param dEligibleClone
   * @return Element
   */
  public Element removeLinePromotionAndCharges(Element eleOrderInputClone) {

    List<Element> orderLineList =
        XMLUtil.getElementsByTagName(eleOrderInputClone, KohlsPOCConstant.E_ORDER_LINE);

    // Element eleAssocPromo = null;

    for (int i = 0; i < orderLineList.size(); i++) {
      Element eleOrderLine = orderLineList.get(i);
      String sPrimeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
      Element eleOrderLinePromotions =
          XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_PROMOTIONS);
      if (!YFCCommon.isVoid(eleOrderLinePromotions)) {
        eleOrderLine.removeChild(eleOrderLinePromotions);
        mapOLPromotionToBeReset.put(sPrimeLineNo, eleOrderLinePromotions);
      }

      /*
       * Element eleOrderLineAwards = XMLUtil.getChildElement(eleOrderLine,
       * KohlsPOCConstant.E_AWARDS);
       * 
       * if (!YFCCommon.isVoid(eleOrderLineAwards)) { eleOrderLine.removeChild(eleOrderLineAwards);
       * }
       */

      /*
       * Element eleOrderLineCharges = XMLUtil.getChildElement(eleOrderLine,
       * KohlsPOCConstant.ELEM_LINE_CHARGES);
       * 
       * if (!YFCCommon.isVoid(eleOrderLineCharges)) {
       * eleOrderLine.removeChild(eleOrderLineCharges); }
       */

      Element eleLinePriceInfo =
          XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);

      if (!YFCCommon.isVoid(eleLinePriceInfo)) {
        eleLinePriceInfo.removeAttribute("InvoicedLineTotal");
        eleLinePriceInfo.removeAttribute("LineTotal");
        eleLinePriceInfo.removeAttribute("UnitPrice");
      }

    }

    return eleOrderInputClone;
  }

}
