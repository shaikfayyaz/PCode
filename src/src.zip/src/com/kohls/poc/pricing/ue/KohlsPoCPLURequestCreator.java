package com.kohls.poc.pricing.ue;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

/**************************************************************************
 * File : KohlsPoCPLURequestCreator.java 
 * Author : IBM 
 * Created : August 27 2013 
 * Modified : August 27 2013 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Class is used to construct the PLU Request
 * 
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/
public class KohlsPoCPLURequestCreator {
	
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPoCPLURequestCreator.class.getName());
	}
	
	private String lookupType;
	private String shipNode;
	
	/**
	 * 
	 * @param lookupType
	 * @param shipNode
	 */
	public KohlsPoCPLURequestCreator(String lookupType, String shipNode){
		this.lookupType = lookupType;
		this.shipNode = shipNode;
	}
	
	/**
	 * This method is used to Construct the PLU Request.
	 * 
	 * PLU Promo, Offer and Rebate using this PLU Request creation method.
	 * 
	 * @param key
	 * @param extnRequestDateTime
	 * @return
	 * @throws ParserConfigurationException
	 */
	public Document constructPLURequestDocument(String key, String extnRequestDateTime)
	throws ParserConfigurationException {
		this.logger.debug("Method Name : constructPLURequestDocument   and   Status : Start ");
		Document pluInputDoc = XMLUtil.createDocument(KohlsPOCConstant.PLU_MESSAGE);
		Element pluInputEle = pluInputDoc.getDocumentElement();
		XMLUtil.setAttribute(pluInputEle, KohlsPOCConstant.A_TYPE_PLU, KohlsPOCConstant.PLU);
		XMLUtil.setAttribute(pluInputEle, KohlsPOCConstant.A_CONTENT, KohlsPOCConstant.PLU);
		XMLUtil.setAttribute(pluInputEle, KohlsPOCConstant.A_TYPE_REQUEST, KohlsPOCConstant.REQUEST);
		XMLUtil.setAttribute(pluInputEle, KohlsPOCConstant.A_FRAME, "");

		Element componentEle = XMLUtil.createChild(pluInputEle,
		KohlsPOCConstant.E_COMPONENT);
		Element parametersEle = XMLUtil.createChild(componentEle,
		KohlsPOCConstant.E_PARAMETERS);
		XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_STORE, this.shipNode);
		
		
		if (YFCCommon.isStringVoid(extnRequestDateTime)) {
			extnRequestDateTime = KohlsPoCPnPUtil.getCurrentDateString();
		}
		
		XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_TRAN_DATE_TIME, extnRequestDateTime);
		XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_LOOKUPTYPE, this.lookupType);
		
		if (KohlsPOCConstant.SKU.equals(this.lookupType)) {
			XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_KEY, key);
		} else if (KohlsPOCConstant.OFFER.equals(this.lookupType)) {
			XMLUtil.setAttribute(parametersEle, KohlsPOCConstant.A_KEY, key);
		}

		XMLUtil.getXMLString(pluInputDoc);
		this.logger.debug("Method Name : constructPLURequestDocument   and   Status : End ");
		return pluInputDoc;

	}

	
}
