package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
/**************************************************************************
 * File : KohlsPoCTVSPrepareUEResponse.java 
 * Author : IBM 
 * Created : July 17 2015 
 * Modified : July 17 2015 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 17/07/2015 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2015. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * 
 * This Class is used to update the UE output doucument  by using the TVS Response.
 * 
 * @author IBM India Pvt 
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCTVSPrepareUEResponse {

	private Map<String, Element> promoHM;
	private double assTLDImpVal = KohlsPOCConstant.ZERO_DBL;
	private double softTLDImpVal = KohlsPOCConstant.ZERO_DBL;
	private double hardTLDImpVal = KohlsPOCConstant.ZERO_DBL;
	private double dConsolidatedTax = KohlsPOCConstant.ZERO_DBL;
	

	public KohlsPoCTVSPrepareUEResponse() {
		this.promoHM = new LinkedHashMap<String, Element>();
	}
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPoCTVSPrepareUEResponse.class.getName());
	}
	
	public void updateUeDocumentFromTVSResponse(YFSEnvironment yfsEnv,Element tvsResponseEle, 
			Element orderEle,  KohlsPoCTVSOrderPromotionsCaller orderPromoObj, KohlsPoCTVSOrderLinePromotionCaller 
			linePromoObj) throws Exception, ParserConfigurationException, SAXException, IOException, ParseException   {

		logger.beginTimer("KohlsPoCTVSPrepareUEResponse.updateUeDocumentFromTVSResponse");
		
		//OMNI2 BOGO changes - Start
		Element extnOrderEle = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		String isOmni = extnOrderEle.getAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI);
		Map<String, String> omni2ConfigMap = KohlsCommonUtil.callCommmonCodeList(yfsEnv, KohlsPOCConstant.A_COMMON_CODE_TYPE_PAYMENT_CONFIG);
		String omni2Enabled = omni2ConfigMap.get(KohlsPOCConstant.A_OMNI2_ENABLED_COMMON_CODE_VALUE);
		//OMNI2 BOGO changes - End
		//OMNI2 PWP/GWP changes - Start
		if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
		validatePWPGWPOfferForOmni(tvsResponseEle);
		}
		//OMNI2 PWP/GWP changes - Start
		

		//Added for defect 3945 fix -- Start
		List<String> appliedOffersList = new ArrayList<String>();
		String isSoftDisItemAvail = KohlsPOCConstant.NO;
		//Added for defect 3945 fix -- End
		List<String> activePromotionGuidList = new ArrayList<String>();
		//for promo 
		NodeList tvsPromoList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_PROMO);	
		if (!YFCCommon.isVoid(tvsPromoList) && tvsPromoList.getLength() > KohlsPOCConstant.ZERO_INT) {
			for(int i=0; i<tvsPromoList.getLength();i++){
				Element promoTVSEle = ((Element)tvsPromoList.item(i));
				String promoIDStr = XMLUtil.getAttribute(promoTVSEle, KohlsPOCConstant.ATTR_ID);
				this.promoHM.put(promoIDStr, promoTVSEle);
			}
		}

		NodeList tvsItemList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM);	
		double totalSaving = KohlsPOCConstant.ZERO_DBL;
		
		if (!YFCCommon.isVoid(tvsItemList) && tvsItemList.getLength() > KohlsPOCConstant.ZERO_INT) {
			for(int i=0; i<tvsItemList.getLength();i++){
				Element itemTVSEle = ((Element)tvsItemList.item(i));
				//PRF-470 - performance change - start
				consolidateLineTaxes(itemTVSEle);
				//PRF-470 - performance change - end
				String itemUniID = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_ID);
				/*//Fix for defect 1078 - Start
				String rebateID = "";
				rebateID = XMLUtil.getAttribute(itemTVSEle, "rebates");
				//Fix for defect 1078 - End*/
				Map<String, Element> orderLineHM = linePromoObj.getOrderLineHM();
				if (orderLineHM.containsKey(itemUniID)) {

					double totalDiscount = KohlsPOCConstant.ZERO_DBL;
					double lidPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double lidAmountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double tldPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double tldAmountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double seniorCitizenChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double priceOverrideChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double priceOverrideIncChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double legacyDollarChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double legacyPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double kohlsCashChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double associateDiscountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double offerChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					double orderLineUnitPriceDbl = KohlsPOCConstant.ZERO_DBL;
					double nonClearanceAmtDbl = KohlsPOCConstant.ZERO_DBL;
					double promoChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
					boolean isPromoApplied = false;
					boolean isLidPercentApplied = false;
					boolean isLidAmountApplied = false;
					boolean isTldPercentApplied = false;
					boolean isTldAmountApplied = false;
					boolean isLegacyDollarApplied = false;
					boolean isLegacyPercentApplied = false;
					boolean isSeniorCitizenApplied = false;
					boolean isPriceOverrideApplied = false;
					boolean isKohlsCashApplied = false;
					boolean isOfferApplied = false;
					boolean isAssociateDiscountApplied = false;
					boolean isPriceOverrideIncreasedApplied = false;

					Element orderLineEle = orderLineHM.get(itemUniID );
					logger.debug("Processing the TVS response for PrimeLineNo: "+itemUniID);
					 
					
					// Start PRF-403 (Part - I)
					//Updating Order Level Promotion/@OverrideAdjustmentValue
					//Added for defect 3945 fix -- Start
					
					String empDscCode = getEmpDscCode(orderLineEle);
					NodeList modifierEleList = itemTVSEle.getElementsByTagName(KohlsPOCConstant.ELEM_MODIFIER);
					String netPriceDelta = getNetPriceDelta(tvsResponseEle, orderPromoObj, modifierEleList);

					// Defect Fix for 5287 - Start
					if (!YFCCommon.isVoid(empDscCode) && !YFCCommon.isVoid(netPriceDelta))
					// Defect Fix for 5287 - End
					{
						if (KohlsPOCConstant.CONST_H.equals(empDscCode)) {

							hardTLDImpVal = hardTLDImpVal + Math.abs(Double.valueOf(netPriceDelta).doubleValue());
							logger.debug("hardTLDImpVal ::::" + hardTLDImpVal);
						}

						else if (KohlsPOCConstant.CONST_S.equals(empDscCode)) {
							isSoftDisItemAvail = KohlsPOCConstant.YES;
							logger.debug("isSoftDisItemAvail in condition ::::" + isSoftDisItemAvail);
						}
					}
					
					//Added for defect 3945 fix -- End
					// End PRF-403 (Part - I)

					Element linePrcEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO, Boolean.TRUE);
					//Added for UPCCode -- start
					Element itmEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_ITEM);
					String upcStr = XMLUtil.getAttribute(itmEle,KohlsPOCConstant.A_UPC_CODE);
					Element eleTaxes = XMLUtil.getChildElement(itemTVSEle, KohlsPOCConstant.ELEM_LINE_TAXES);
					Element eleTVSLineTax = XMLUtil.getChildElement(eleTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
					Element eltaxExtn = XMLUtil.getChildElement(eleTVSLineTax, KohlsPOCConstant.E_EXTN);
					double dTVSLineTax=0 ;
					if(!YFCCommon.isVoid(eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX))){
						dTVSLineTax = Double.parseDouble(eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX));
					}
					//Added for UPCCode -- end
					String orderLineUnitPrice = XMLUtil.getAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE);
					//PST-989 - Fix for setting the UnitPrice whenever the call is made to TVS, when ExtnIsPriceEntered is null
					Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
					String strExtnIsPriceEntered = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);
					if (YFCCommon.isStringVoid(orderLineUnitPrice) || KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(orderLineUnitPrice) 
							|| YFCCommon.isVoid(strExtnIsPriceEntered)){
						XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_REGULAR_PRICE));
					}
					//Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
					/*String empDiscCode = XMLUtil.getAttribute(extnEle, "ExtnEmpDiscCode");*/

					// Update the orderLineEle based on the TVS Response Mapping Doc
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_RETURN_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_RETURN_PRICE)));
					if(dTVSLineTax > 0	){
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(eltaxExtn, KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT)));
					}else{
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE)));
					}
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SELLING_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SIMPLE_PROMO_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_NET_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_NET_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_RECPTT_RTN_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_RECEIPT_RETURN_PRICE)));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BOGO_GPID, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_BOGO_GRP_CODE));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PWP_GROUP_ID, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_PWP_GWP_GROUP_CODE));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BUY_ITEM, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_BUY_ITEM));
					//Sudina - Added for defect 694/695 - Start
					DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
					//Changes for defect 1371 - Start
					//Performance improvement changes - Start
					if(logger.isDebugEnabled()){
					logger.debug("The itemTVSEle value is :" + XMLUtil.getElementXMLString(itemTVSEle));
					}
					//Performance improvement changes - End
					if(!YFCCommon.isVoid(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_PLU_PRICE)))
					{
						logger.debug("The plu price value is :" +XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_PLU_PRICE));
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT,twoDForm.format(Double.valueOf(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_PLU_PRICE))));
					}else{
						logger.debug("The plu price value is empty");
					}
					//Changes for defect 1371 - End
					//Sudina - Added for defect 694/695 - End

					// Suresh : Added for Nike Exclusions Sprint 5 : Start
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_EXCLUSION_ITEM));
					// Suresh : Added for Nike Exclusions Sprint 5 : End

					Element awardsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, Boolean.TRUE);
					Element lineChargesEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES, Boolean.TRUE);

					//DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);

					String isDiscountable = itemTVSEle.getAttribute(KohlsPOCConstant.ATTR_DISC_ELG_IND);
					if(KohlsPOCConstant.YES.equalsIgnoreCase(isDiscountable))
					{
						isDiscountable = KohlsPOCConstant.YES;
					}
					else
					{
						isDiscountable = KohlsPOCConstant.NO;
					}	
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_DISCOUNTABLE, isDiscountable);
					String skuStatusText = itemTVSEle.getAttribute(KohlsPOCConstant.ATTR_SKU_STATUS);
					String skuStatusCode = KohlsPoCPnPUtil.getStatusCodeFromTVS(skuStatusText);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE, skuStatusCode);
					String nonClearanceAmt = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_LAST_NON_CLR_PRI);
					orderLineUnitPriceDbl = Double.valueOf(XMLUtil.getAttribute(itemTVSEle,KohlsPOCConstant.ATTR_REGULAR_PRICE));

					if (!YFCCommon.isVoid(nonClearanceAmt)) {
						//Fix for defect 713 - Start
						//nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt) / KohlsPOCConstant.HUNDRED_INT;
						nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt);
						//Fix for defect 713 - End
						nonClearanceAmt = twoDForm.format(nonClearanceAmtDbl);
						nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt);
					}					
					else{
						//Default the clearance amount to the value of unit price if it is null or zero from TVS
						nonClearanceAmt = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_REGULAR_PRICE);
						nonClearanceAmtDbl = orderLineUnitPriceDbl;
					}
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_NON_CLEARANCE_AMT, nonClearanceAmt);

					//rebate -- start
					//Fix for defect 3079 - Start
					NodeList rebatesEleList = itemTVSEle.getElementsByTagName("rebate");
					
					//Fix for defect 3079 - End
					if (!YFCCommon.isVoid(rebatesEleList) && rebatesEleList.getLength() > KohlsPOCConstant.ZERO_INT){
						logger.debug("Processing rebates");
						linePromoObj.createAwardElementforRebateItem(yfsEnv,rebatesEleList,orderEle,orderLineEle);

					/*if(!YFCCommon.isStringVoid(rebateID))
					{
						//Fix for defect 1078 - Start
						String extnRequestDateTime = KohlsPoCPnPUtil.getExtnRequestTime(orderEle);
						String shipNode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
						if (YFCCommon.isStringVoid(extnRequestDateTime)) {
							extnRequestDateTime = KohlsPoCPnPUtil.getCurrentDateString();
						}
						//internal rebateId list defect - Start
						String[] rebateList = rebateID.split("\n");
						logger.debug("The rebateList list value is:" +rebateList);;
						for(int i=1; i<rebateList.length; i++){
							logger.debug("The rebateItem value is :" +rebateList[i].trim());
							if(rebateList[i].trim().length()>0){
								linePromoObj.createAwardElementforRebateItem(rebateList[i].trim(),orderLineEle);
							}
							
						}*/
						//internal rebateId list defect - Start
						//Fix for defect 1078 - End
					}

					//rebate -- end

					int awardSequence = KohlsPOCConstant.ZERO_INT;
					if(!YFCCommon.isVoid(modifierEleList) && modifierEleList.getLength() > KohlsPOCConstant.ZERO_INT){
						logger.debug("Processing Modifiers");
						for(int j=0; j<modifierEleList.getLength(); j++){
							String appliedSUPCCode = KohlsPOCConstant.EMPTY;
							boolean isItemLevelPromo = Boolean.FALSE;
							Element modifierEle = (Element)modifierEleList.item(j);
							String idStr = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PARENT_DISCOUNT_ID); 
							String modifierActiveStatus = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_MODIFIER_ACTIVE);
							logger.debug("Parent Discount ID is: "+idStr);
							logger.debug("Modifier Active status: "+modifierActiveStatus);
							

							logger.debug("Checking if this discount ID corresponds to offers or not");
							NodeList nlOfferList = tvsResponseEle.getElementsByTagName("offerList");
							if (!YFCCommon.isVoid(nlOfferList) && nlOfferList.getLength() > KohlsPOCConstant.ZERO_INT){
								//replacing XPathUtil with XMLUtil - Start
								//Element eleOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle, 
									//	"/priceResponse/transaction/offerList/offer[@id='"+idStr+"']")).item(0);
								NodeList ndOffers = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_OFFER);
								if(!YFCCommon.isVoid(ndOffers) && ndOffers.getLength() > KohlsPOCConstant.ZERO_INT)
								{
									for(int k=0; k<ndOffers.getLength(); k++)
									{
										Element eleOffer = (Element)ndOffers.item(k);
										if(!YFCCommon.isVoid(eleOffer) && (idStr.equals(eleOffer.getAttribute(KohlsPOCConstant.ATTR_ID)))){
											
											//CPE-2719 - TVS resp for SUPC will have PromotionId in appliedSUPCCOde attr. - start
											appliedSUPCCode = eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE);
											if(!YFCCommon.isVoid(appliedSUPCCode))
											{
												idStr = appliedSUPCCode;
											} // //CPE-2719 - End
											else {
												idStr = eleOffer.getAttribute("offerId");
											}
											logger.debug("Modifier discount id corresponds to an offer id: "+idStr);
											
											//Defect #1475 - Start
											
											if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
												logger.debug("Adding id the offer id"+idStr);
												appliedOffersList.add(idStr);
											}
											//Defect #1475 - End
										}
									}
								}
								//replacing XPathUtil with XMLUtil - End
							}

							Element awardEle = XMLUtil.createChild(awardsEle, KohlsPOCConstant.E_AWARD);
							//Commented below to set AwardId as blank
							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
							//XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID,"");

							
							if (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
							} else{
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.NO);
							}

							String taxablePriceDelta =  XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA);
							//Changes for defect 3302 - Start
							//OMNI2 BOGO changes - Start
							String returnPriceDelta = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA);
							if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, KohlsPoCPnPUtil.getDouble(returnPriceDelta));
							}else {
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, KohlsPoCPnPUtil.getDouble(taxablePriceDelta));
							}
							//OMNI2 BOGO changes - End
							Element awardExtEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TAX_DELTA, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA)));
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_NET_DELTA, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_NET_PRICE_DELTA)));
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_ACT_DELTA, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED)));
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_PER_DELTA, XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_PERCENT_ACHIEVED));
							String tierLevelAchieved = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_LEVEL_ACHIEVED);
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_LVL_ACHVD, tierLevelAchieved);
							String stierActivationAchieved = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED);
							
							// Changes for R3 - RKC - Start
							if(!YFCCommon.isVoid(returnPriceDelta))
							{
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_RETRN_DELTA, twoDForm.format(Math.abs(Double.valueOf(returnPriceDelta))));
							logger.debug("ExtnRetrnDelta value for TVS store is:: "+XMLUtil.getAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_RETRN_DELTA));
							}
							// Changes for R3 - RKC - End
							//Changes for defect 3302 - End
							//Sudina : Backlog 197 Receipt Enhancements - Start
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.ATTR_EXTN_SALE_PRICE,XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SIMPLE_PROMO_PRICE));
							//Sudina : Backlog 197 Receipt Enhancements - End

							//Adding Award Sequence Number
							awardSequence = awardSequence + KohlsPOCConstant.ONE_INT;
							XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, String.valueOf(awardSequence));
							//Added for UPCCode -- start
							if(!YFCCommon.isVoid(upcStr))
							{
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_UPC_CODE,upcStr);
							}
							else
							{
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_UPC_CODE,"");
							}
							//Added for UPCCode -- end

							XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ITEM_ID, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SKU));

							// Start: Sales Hub Clob Code 

							Document salesHubDoc = null;
							Element eleData = null;
							KohlsPoCTVSPrepareSalesHubClob prepareSalesHubClobObj = null;

							// Code modification for allowing clob to be formed for AWARD_APPLIED TO 'Y' OR 'N'
							if((KohlsPOCConstant.YES.equalsIgnoreCase(XMLUtil.getAttribute(awardEle,KohlsPOCConstant.A_AWARD_APPLIED)) ) || (KohlsPOCConstant.NO.equalsIgnoreCase(XMLUtil.getAttribute(awardEle,KohlsPOCConstant.A_AWARD_APPLIED))) ){
								salesHubDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DATA);
								eleData = salesHubDoc.getDocumentElement();
								// Creating an instance of KohlsPocPrepareSalesHubClob

								prepareSalesHubClobObj = new KohlsPoCTVSPrepareSalesHubClob(eleData, awardExtEle);
								//Defect fix 939 - Start
								//Performance improvement changes - Start
								if(logger.isDebugEnabled()){
								logger.debug("The eleData Element value is: "+XMLUtil.getElementXMLString(eleData));
								}
								//Performance improvement changes - End
								//Defect fix 939 - End
							}

							// End: Sales Hub Clob Code 

							//Using to update create Related Award
							Map<String, Element> promoHM = this.getPromoHM();
							if (promoHM.containsKey(idStr)) {
								logger.debug("promoHM contains the idStr "+idStr);
								isItemLevelPromo = Boolean.TRUE;

								Element promoEle = promoHM.get(idStr);
								//String regularPrice = XMLUtil.getAttribute(itemApeEle, KohlsPOCConstant.A_REGULAR_PRICE);

								//Updated for defect 5626 - Begin
								String promoSchemeCode = XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_PROMO_SCHEME_CODE);
								if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))
										|| Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) {
									String sTierPctAchieved = modifierEle.getAttribute(KohlsPOCConstant.ATTR_TIER_PERCENT_ACHIEVED);
									String sTierActAchieved = modifierEle.getAttribute(KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED);
									if (!YFCCommon.isVoid(sTierPctAchieved) && !YFCCommon.isVoid(sTierActAchieved)){
										int iDiscountPercentage = Double.valueOf(sTierPctAchieved).intValue() * KohlsPOCConstant.THOUSAND_INT;
										int iBuy = Double.valueOf(sTierActAchieved).intValue();
										if(Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
											iBuy = iBuy * KohlsPOCConstant.HUNDRED_INT;	
										}
										if(iBuy > 0 && iDiscountPercentage > 0) {
											promoEle.setAttribute(KohlsPOCConstant.ATTR_DISCOUNT_PERCENT, String.valueOf(iDiscountPercentage));
											if(Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
												promoEle.setAttribute(KohlsPOCConstant.ATTR_INC_BUY_AMT, String.valueOf(iBuy));
											} else {
												promoEle.setAttribute(KohlsPOCConstant.ATTR_INC_BUY_QTY, String.valueOf(iBuy));
											}
										}
									}
								}
								//Updated for defect 5626 - End

								this.addPromoAwardDescription(promoEle, awardEle);

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER_LINE, KohlsPOCConstant.YES);

								if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
									isPromoApplied = true;
									//OMNI2 BOGO changes - Start
									//XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BUY_ITEM, "N");

									if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
										promoChargePerLineDbl = promoChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
									}
									else {
										promoChargePerLineDbl = promoChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}
									//OMNI2 BOGO changes - End
								}

								//Sales Hub Clob	
								if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

									// passing only the required objects to populate data, rest are sent as null.
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											modifierEle,  extnEle,  promoEle,null,KohlsPOCConstant.PROMO);


								}

							}

							// Using to create Manual LID  Related Award 
							Map<String, Element> orderLineLLDHM = linePromoObj.getOrderLineLLDHM();
							if (orderLineLLDHM.containsKey(idStr)) {
								logger.debug("orderLineLLDHM contains idStr "+idStr);
								Element promotionEle = orderLineLLDHM.get(idStr);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER_LINE, KohlsPOCConstant.YES);
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								String orderLinePromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
								String description = null;
								String promotionDesc = null;

								if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {

									String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);

									if (YFCCommon.isStringVoid(overrideMaxAdjustment)) {
										overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
									}


									description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_LID_LINE_PROP_KEY);

									promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_LID_PROMO_DESC_PROP_KEY);
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);

									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										isLidAmountApplied = true;
										//OMNI2 BOGO changes - Start
										if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
											lidAmountChargePerLineDbl = lidAmountChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
										}
										else {
											lidAmountChargePerLineDbl = lidAmountChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
										}
										//OMNI2 BOGO changes - End
									}

								} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)) {

									Element prmotionExtnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
									String extnDiscountPercent = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

									if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
										String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
										description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_LID_LINE_PROP_KEY, args);

										promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_LID_PROMO_DESC_PROP_KEY, args);
										eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
									}

									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										isLidPercentApplied = true;
										//OMNI2 BOGO changes - Start
										if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
											lidPercentChargePerLineDbl = lidPercentChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
										}
										else {
											lidPercentChargePerLineDbl = lidPercentChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
										}
										//OMNI2 BOGO changes - End
									}

								}
								else if (KohlsPOCConstant.PRICE_OVERRIDE.equalsIgnoreCase(promotionType))
								{
									String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
										if(Double.valueOf(taxablePriceDelta).doubleValue() > KohlsPOCConstant.ZERO_DBL){
											description = KohlsPOCConstant.DOLLAR_MARKUP_DESC ;
											isPriceOverrideIncreasedApplied = true;
											//OMNI2 BOGO changes - Start
											if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
												priceOverrideIncChargePerLineDbl = priceOverrideIncChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
											}
											else {
												priceOverrideIncChargePerLineDbl = priceOverrideIncChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
											}
											//OMNI2 BOGO changes - End
										}else{
											description = KohlsPOCConstant.DOLLAR_MARKDOWN_DESC ;
											isPriceOverrideApplied = true;
											//OMNI2 BOGO changes - Start
											if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
												priceOverrideChargePerLineDbl = priceOverrideChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
											}
											else {
												priceOverrideChargePerLineDbl = priceOverrideChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
											}
											//OMNI2 BOGO changes - End
										}
									}
								}

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);								
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderLinePromotionId);
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);

								//6061 - Fix to retain EXTN_DISCOUNT_TYPE_CODE and EXTN_DISCOUNT_REASON_CODE values Start                    
								if (!YFCCommon.isVoid(orderLinePromotionId)){
									if(orderLinePromotionId.contains("760Q")){
										Element extnAwardEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
										XMLUtil.setAttribute(extnAwardEle, KohlsPOCConstant.A_EXTN_DISCOUNT_REASON_CODE, KohlsPOCConstant.V_EXTN_DISCOUNT_REASON_CODE_VALUE_760);
										XMLUtil.setAttribute(extnAwardEle, KohlsPOCConstant.A_EXTN_DISCOUNT_TYPE_CODE, KohlsPOCConstant.V_EXTN_DISCOUNT_TYPE_CODE_VALUE_760);
									}
								if(orderLinePromotionId.contains("761I")){									
									Element extnAwardEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
									XMLUtil.setAttribute(extnAwardEle, KohlsPOCConstant.A_EXTN_DISCOUNT_REASON_CODE, KohlsPOCConstant.V_EXTN_DISCOUNT_REASON_CODE_VALUE_761);
									XMLUtil.setAttribute(extnAwardEle, KohlsPOCConstant.A_EXTN_DISCOUNT_TYPE_CODE, KohlsPOCConstant.V_EXTN_DISCOUNT_TYPE_CODE_VALUE_761);
								}
								}
								
								//6061 - Fix to retain EXTN_DISCOUNT_TYPE_CODE and EXTN_DISCOUNT_REASON_CODE values End
								//	 SALES HUB
								// Modification on 11-09 
								if (!XMLUtil.isVoid(prepareSalesHubClobObj)) {
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											modifierEle,  extnEle,  null, null,promotionType) ;
									// End: 
								}	

							}

							Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();
							if (orderTLDHM.containsKey(idStr)) {
								logger.debug("orderTLDHM contains idStr "+idStr);
								Element promotionEle = orderTLDHM.get(idStr);
								String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
								Element extnPromoEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);	
								//Fix for 655 - Start
								String extnOffLineMode = " ";
								extnOffLineMode = XMLUtil.getAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
								logger.debug("The extnOffLineMode value is"+extnOffLineMode);
								//Fix for 655 - End
								if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || 
										KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
									Element prmotionExtnEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
									XMLUtil.setAttribute(prmotionExtnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
									Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
									if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
										activePromotionGuidList.add(idStr);
									}else if(!activePromotionGuidList.contains(idStr)){								
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
									}													

									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
									//String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
									String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
									String description = KohlsPOCConstant.EMPTY;
									String promotionDesc  = KohlsPOCConstant.EMPTY;
									if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
										String overrideAdjustmentValue = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);



										String[] args = {twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue)))};

										// Start: Defect 3284 Fix : Sathya, retrieving Manual Discount for promotion description
										String extnDiscount=XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT);

										//Added as part of TLD description changes for Sprint-8 --- Start
										//String[] args2 = {twoDForm.format(Math.abs(Double.valueOf(extnDiscount)))};
										String tldDolar = KohlsPOCConstant.TLD_DOLLAR_DESCRIPTION;
										String[] args2 = {tldDolar};
										//Added as part of TLD description changes for Sprint-8 --- End

										promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_ORDER_PROP_KEY, args2);
										// End: Defect 3284 Fix : Sathya, retrieving Manual Discount for promotion description

										description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_LINE_PROP_KEY, args);

										if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
											isTldAmountApplied = true;
											//OMNI2 BOGO changes - Start
											if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
												tldAmountChargePerLineDbl = tldAmountChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
											}
											else {
												tldAmountChargePerLineDbl = tldAmountChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
											}
											//OMNI2 BOGO changes - End
										}

										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);

									} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
										String extnDiscountPercent = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

										if (!YFCCommon.isStringVoid(extnDiscountPercent)) {

											String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
											//Fix for defect 2322 and 2333 - Start
											if(KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){
												description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.QUICK_CREDIT_TLD_ORDER_PROP_KEY, args);
											}else{
												description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_LINE_PROP_KEY, args);
											}
											//Fix for defect 2322 and 2333 - End

											eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))) );
										}

										if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
											isTldPercentApplied = true;
											//OMNI2 BOGO changes - Start
											if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
												tldPercentChargePerLineDbl = tldPercentChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
											}
											else {
												tldPercentChargePerLineDbl = tldPercentChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
											}
											//OMNI2 BOGO changes - End
										}
									}

									XMLUtil.setAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId); 
									//logger.debug("The Gift attribute stamped is line 699: "+XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT));

									XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT)); 

									//Sales Hub

									if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
										prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
												null,null,promotionType) ;
									}	

								}

								else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
									if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
										activePromotionGuidList.add(idStr);
									}else if(!activePromotionGuidList.contains(idStr)){								
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
									}
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
									String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
									Element extnPromotionEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
									String extnDiscountPercent = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
									XMLUtil.setAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

									String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};



									String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROP_KEY, args);
									XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_DESCRIPTION,description);
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
									//OMNI2 BOGO changes - Start
									if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
										seniorCitizenChargePerLineDbl = seniorCitizenChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
									}
									else {
										seniorCitizenChargePerLineDbl = seniorCitizenChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}
									//OMNI2 BOGO changes - End
									isSeniorCitizenApplied = Boolean.TRUE;

									// Added code to fix DiscountPercent for SalesHubClob Senior Discount
									if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
										eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
									}

									// Sales Hub
									if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

										prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
												null,null,promotionType) ;
									}

								}

								else if(KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType) || KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType) )
								{
									if(!KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode))
									{

										Element extnKohlsCashResposneEle =  null;
										extnKohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnPromoEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
										String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);

										//Added as part of TLD description changes for Sprint-8 --- Start
										String promotionIdForDesc =  orderPromotionId.substring((orderPromotionId.length())-KohlsPOCConstant.FIVE_INT);
										//Added as part of TLD description changes for Sprint-8 --- End

										NodeList dataEleList = extnKohlsCashResposneEle.getElementsByTagName(KohlsPOCConstant.E_DATA);
										if(!YFCCommon.isVoid(dataEleList) && dataEleList.getLength() > KohlsPOCConstant.ZERO_INT){
											Element dataElement = (Element)dataEleList.item(KohlsPOCConstant.ZERO_INT);
											String legacyDollar = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
											String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
											String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
											String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
											String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
											String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
											String authApprovalNum = dataElement.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);
											String description = null;
											String promotionDescription = KohlsPOCConstant.EMPTY;

											if(YFCCommon.isStringVoid(couponBalance)){
												couponBalance = KohlsPOCConstant.ZERO_STR;
											}

											double absTaxablePriceDelta = Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

											String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
											String extnCouponAmount = XMLUtil.getAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);



											if (KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
												if (!YFCCommon.isStringVoid(legacyDollar)) {

													isLegacyDollarApplied = Boolean.TRUE;
													//OMNI2 BOGO changes - Start
													if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
														legacyDollarChargePerLineDbl = legacyDollarChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
													}
													else {
														legacyDollarChargePerLineDbl = legacyDollarChargePerLineDbl + absTaxablePriceDelta;
													}
													//OMNI2 BOGO changes - End

													if(!YFCCommon.isStringVoid(overrideMaxAdjustment)){
														//FIx for Defect #5432
														String[] args = {twoDForm.format(Math.abs(Double.valueOf(legacyDollar)))};

														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_LINE_PROP_KEY, args);

														// Start: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
													}

													//	String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))};

													if(!YFCCommon.isStringVoid(extnCouponAmount)){

														//Added as part of TLD description changes for Sprint-8 --- Start
														//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(extnCouponAmount)))};
														String[] args2 = {promotionIdForDesc};
														//Added as part of TLD description changes for Sprint-8 --- End

														// End: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
														promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_ORDER_PROP_KEY, args2);
													}

												} else if (!YFCCommon.isStringVoid(legacyPercent)) {

													String extnDiscountPercent = XMLUtil.getAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
													//OMNI2 BOGO changes - Start
													if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
														legacyPercentChargePerLineDbl = legacyPercentChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
													}
													else {
														legacyPercentChargePerLineDbl = legacyPercentChargePerLineDbl + absTaxablePriceDelta;
													}
													//OMNI2 BOGO changes - End
													isLegacyPercentApplied = Boolean.TRUE;
													extnDiscountPercent = String.valueOf(Double.valueOf(Double.valueOf(extnDiscountPercent) * KohlsPOCConstant.HUNDRED_INT).intValue());


													String[] args = {extnDiscountPercent};



													description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_LINE_PROP_KEY, args);

													//Added as part of TLD description changes for Sprint-8 --- Start
													//String[] args2 = {orderPromotionId,extnDiscountPercent};
													String[] args2 = {extnDiscountPercent,promotionIdForDesc};
													//Added as part of TLD description changes for Sprint-8 --- End


													promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_ORDER_PROP_KEY, args2);

													// Added code to fix DiscountPercent for SalesHubClob Legacy Percent
													if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
														eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
													}
												}
											} else if (KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
													&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
													&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL) {
												//OMNI2 BOGO changes - Start
												if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
													kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
												}
												else {
													kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + absTaxablePriceDelta;
												}
												//OMNI2 BOGO changes - End
												isKohlsCashApplied = Boolean.TRUE;
												//logger.debug("Insidde line 862: The coupon balance and OMA values are "+ couponBalance +" and " +overrideMaxAdjustment);
												if(!YFCCommon.isStringVoid(overrideMaxAdjustment)){

													//Fix for defect 655 - Start
													//logger.debug("Insidde line 866: The coupon balance and OMA values are "+ couponBalance +" and " +overrideMaxAdjustment);
													couponBalance = String.valueOf(Double.valueOf(couponBalance) - Double.valueOf(twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))));
													//logger.debug("Insidde line 868: The coupon balance and OMA values are "+ couponBalance +" and " +overrideMaxAdjustment);
													//Fix for defect 655 - End
													// Changes for Event Name -- Start
													
													Element dataEle = (Element)extnKohlsCashResposneEle.getElementsByTagName(KohlsPOCConstant.E_DATA).item(KohlsPOCConstant.ZERO_INT);
													if (!YFCCommon.isVoid( XMLUtil.getAttribute(dataEle, KohlsPOCConstant.KC_EVENT_NAME)))
													{
													
														description = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.KC_EVENT_NAME);
													        logger.debug("Award Description is::"+promotionDescription);
													}
													
													else
													{
														String[] args = {String.valueOf(twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment))))};
														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_LINE_PROP_KEY, args);	
														logger.debug("Award Description if Event Name Empty"+description);
													}
													// Changes for Event Name -- End

													// Start: Defect 3284 Fix : Suresh, retrieving ExtnCouponAmount for promotion description
												}
												//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))};

												if(!YFCCommon.isStringVoid(extnCouponAmount)){

													// Changes for Event Name -- Start
													Element dataEle = (Element)extnKohlsCashResposneEle.getElementsByTagName(KohlsPOCConstant.E_DATA).item(KohlsPOCConstant.ZERO_INT);
													if (!YFCCommon.isVoid( XMLUtil.getAttribute(dataEle, KohlsPOCConstant.KC_EVENT_NAME)))
													{
													
													promotionDescription = XMLUtil.getAttribute(dataEle, KohlsPOCConstant.KC_EVENT_NAME);
													logger.debug("promoDescription is"+promotionDescription);
													}
													
													else
													{
														String[] args2 = {promotionIdForDesc};
														promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
														logger.debug("PromoDescription if Event Name Empty"+promotionDescription);
													}
													
													// Changes for Event Name -- End
												}
											}

											if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
												activePromotionGuidList.add(idStr);
											}else if(!activePromotionGuidList.contains(idStr)){
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
											}
											//Defect fix for 939 - Start
											Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
											//Defect fix for 939 - End
											XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_AUTH_RESPONSE_CODE, authResponseCode);
											XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE, couponBalance);
											XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_AUTH_APPROVAL_NUMBER, authApprovalNum);
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId);
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
											XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
											//Defect fix for 939 - Start
											logger.debug("The Gift attribute stamped is line 892: "+XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT));
											XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT)); 
											//Defect fix for 939 - End
											//logger.debug("Insidde line 913: The coupon balance and OMA values are "+ couponBalance +" and " +overrideMaxAdjustment);
										}

										// Sales Hub
										if (!XMLUtil.isVoid(prepareSalesHubClobObj)) {
											prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
													null,null, promotionType) ;
											// End: 
										}	


									
								}
								else if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)&&(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)))
								{

									String promotionDescription =KohlsPOCConstant.EMPTY;
									//String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
									String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);

									//Added for TLD Description for Sprint-8 --- Start
									String promotionIdForDesc =  orderPromotionId.substring((orderPromotionId.length())-KohlsPOCConstant.FIVE_INT);
									//Added for TLD Description for Sprint-8 --- End

									Element extnPromotionEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
									XMLUtil.setAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
									//OMNI2 BOGO changes - Start
									if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
										kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
									}
									else {
										kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
									}
									//OMNI2 BOGO changes - End
									double  absTaxablePriceDelta = Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

									String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);

									overrideMaxAdjustment = twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)));

									String[] args = {overrideMaxAdjustment};
									String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_LINE_PROP_KEY, args);
									// Start: Defect 3284 Fix : Sathya, retrieving ExtnCouponAmount for promotion description
									//String[] args2 = {orderPromotionId,overrideMaxAdjustment};
									String extnCouponAmount = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);

									if(!YFCCommon.isStringVoid(extnCouponAmount)){

										//Added for TLD Description for Sprint-8 --- Start
										//String[] args2 = {orderPromotionId,twoDForm.format(Math.abs(Double.valueOf(extnCouponAmount)))};
										String[] args2 = {promotionIdForDesc};
										//Added for TLD Description for Sprint-8 --- End

										promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
									}
									// End: Defect 3284 Fix : Sathya, retrieving ExtnCouponAmount for promotion description
									if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
										activePromotionGuidList.add(idStr);
									}else if(!activePromotionGuidList.contains(idStr)){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
									}

									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_DESCRIPTION,description);
									XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);

									//Logic for Calulating Coupon Balance
									//String extnCouponAmount = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);
									String couponBalance = String.valueOf(Double.valueOf(extnCouponAmount) - Double.valueOf(twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)))));;
									XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,couponBalance);
									XMLUtil.setAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
									//XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT)); 

									isKohlsCashApplied = Boolean.TRUE;

									// Sales Hub
									if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

										prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
												null,null,promotionType) ;
									}
								}
								}
								else if(KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType))
								{
									
									String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
									//PST-4465 - Start
									if((KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) 
											> KohlsPOCConstant.ZERO_DBL) || (orderPromotionId.contains("760K") || orderPromotionId.contains("761I") 
											|| orderPromotionId.contains("760Q"))){
									//PST-4465 - End
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
										activePromotionGuidList.add(idStr);
									}else if(!activePromotionGuidList.contains(idStr)){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
									}
									Element eleGetOffer = null;
									Element eleBuyOffer = null;
									//Replace id with offerId for 5350 defect -- start
									//replacing XPathUtil with XMLUtil - Start
									
									//Element eleOfferListForThisOffer = (Element)(XPathUtil.getNode(tvsResponseEle, 
										//	"/priceResponse/transaction/offerList/offer[@offerId='"+idStr+"']"));

									NodeList ndOffers = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_OFFER);
									Element eleOfferListForThisOffer = null;
									if(!YFCCommon.isVoid(ndOffers) && ndOffers.getLength() > KohlsPOCConstant.ZERO_INT)
									{
										for(int k=0; k<ndOffers.getLength(); k++)
										{
											Element eleOffer = ((Element)ndOffers.item(k));
										
											//CPE-2719 - TVS resp for SUPC will have PromotionId in appliedSUPCCOde attr. - start  
											
											if(!YFCCommon.isVoid(eleOffer) &&
												(!YFCCommon.isStringVoid(eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE)) && 
														(idStr.equals(eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE))))){
												
												eleOfferListForThisOffer = eleOffer;
												//Performance improvement changes - Start
												if(logger.isDebugEnabled()){
												logger.debug("eleOfferListForThisOffer"+XMLUtil.getElementXMLString(eleOfferListForThisOffer));
												}
												//Performance improvement changes - End
												
												if("GET".equals(eleOffer.getAttribute("benefitWithPurchaseSelectionTypeCode")))
												{
													eleGetOffer = eleOffer;
												}
												if("BUY".equals(eleOffer.getAttribute("benefitWithPurchaseSelectionTypeCode")))
												{
													eleBuyOffer = eleOffer;
												}
											}else if(!YFCCommon.isVoid(eleOffer) && idStr.equals(eleOffer.getAttribute(KohlsPOCConstant.ATTR_OFFER_ID))){
												eleOfferListForThisOffer = eleOffer;
												//Performance improvement changes - Start
												if(logger.isDebugEnabled()){
												logger.debug("eleOfferListForThisOffer"+XMLUtil.getElementXMLString(eleOfferListForThisOffer));
												}
												//Performance improvement changes - End
												
												if("GET".equals(eleOffer.getAttribute("benefitWithPurchaseSelectionTypeCode")))
												{
													eleGetOffer = eleOffer;
												}
												if("BUY".equals(eleOffer.getAttribute("benefitWithPurchaseSelectionTypeCode")))
												{
													eleBuyOffer = eleOffer;
												}
											}
										}// CPE-2719 End
									
										//replacing XPathUtil with XMLUtil - End
									/*if(nlOfferList.getLength()>0){
										eleGetOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle, 
												"/priceResponse/transaction/offerList/offer[@offerId='"+idStr+"'][@benefitWithPurchaseSelectionTypeCode='GET']")).item(0);

										//	 logger.debug("eleGetOffer"+XMLUtil.getElementXMLString(eleGetOffer));
										eleBuyOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle, 
												"/priceResponse/transaction/offerList/offer[@offerId='"+idStr+"'][@benefitWithPurchaseSelectionTypeCode='BUY']")).item(0);
*/
										//Replace id with offerId for 5350 defect -- end

										//logger.debug("eleBuyOffer"+ XMLUtil.getElementXMLString(eleBuyOffer));
									}
									Element extnOfferEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
									//logger.debug("extnOfferEle"+XMLUtil.getElementXMLString(extnOfferEle));
									//Element offerResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnOfferEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));

									String description = null;
									String promotionDescription = null;
									String cusDesc = KohlsPOCConstant.EMPTY;
									String discLvlCode = null;
									String sGetTierLvlNum = null;
									if(!YFCCommon.isVoid(eleBuyOffer)){
										if(!YFCCommon.isVoid(eleBuyOffer.getAttribute("customerFacingShortDescription"))){
											cusDesc = eleBuyOffer.getAttribute("customerFacingShortDescription");	
											logger.debug("customerdescription at eleBuyer"+cusDesc);											
										}
										discLvlCode = eleBuyOffer.getAttribute("discountLevelCode");
									} 
									if(!YFCCommon.isVoid(eleGetOffer)){
										if(!YFCCommon.isVoid(eleGetOffer.getAttribute("customerFacingShortDescription"))){

											cusDesc = eleGetOffer.getAttribute("customerFacingShortDescription");
											logger.debug("the eleGetOffer customer description"+cusDesc); 												
										}
										sGetTierLvlNum =  eleGetOffer.getAttribute("tierLevelNumber");
										discLvlCode = eleGetOffer.getAttribute("discountLevelCode");
									}
									String[] args = {String.valueOf(cusDesc)};
									logger.debug("the arguments is "+String.valueOf(cusDesc));
									description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_LINE, args);
									logger.debug("the description is "+String.valueOf(description));

									String[] args2 = {cusDesc,orderPromotionId};
									promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_ORDER, args2);
									logger.debug("the promotionDescription is "+promotionDescription);

									//Get Offer Percentage  
									String percentOffValue = KohlsPOCConstant.EMPTY;
									//String bwpSelectionTypeCode =  XMLUtil.getAttribute(offerResposneEle, "benefitWithPurchaseSelectionTypeCode");
									//String tierLelNum =  XMLUtil.getAttribute(offerResposneEle, "tierLevelNumber");
									if(!YFCCommon.isVoid(sGetTierLvlNum)){
										if (sGetTierLvlNum.equalsIgnoreCase(tierLevelAchieved) || sGetTierLvlNum.equalsIgnoreCase(stierActivationAchieved)) {
											percentOffValue =  eleGetOffer.getAttribute("benefitWithPurchaseGetPercentOffPercent");
											//MJ 12/27 added for CPE-4384 - start
											if (!YFCCommon.isStringVoid(percentOffValue) && Double.valueOf(percentOffValue).doubleValue() > KohlsPOCConstant.ZERO_DBL) {
											XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(percentOffValue)));
											}
											//MJ 12/27 added for CPE-4384 - end
										}
									}
										
									if (!YFCCommon.isStringVoid(percentOffValue) && Double.valueOf(percentOffValue).doubleValue() > KohlsPOCConstant.ZERO_DBL) {

										String[] args3 = {cusDesc,percentOffValue};
										description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_PERCENT_LINE, args3);
										logger.debug("Percentage line"+description);
										String[] args4 = {cusDesc,orderPromotionId,percentOffValue};
										promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_PERCENT_ORDER, args4);
										logger.debug("promotionDescription line"+promotionDescription);

									} 
									//Code changes for 604
										String discountPercentage = KohlsPOCConstant.EMPTY;
										if(!YFCCommon.isVoid(eleGetOffer.getAttribute("benefitWithPurchaseGetPercentOffPercent"))){
											discountPercentage =  eleGetOffer.getAttribute("benefitWithPurchaseGetPercentOffPercent");
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DISCOUNT_PERCENT, discountPercentage); 
										}
										else{
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DISCOUNT_PERCENT,KohlsPOCConstant.ZERO); 	
										}
										logger.debug("discountPercentage line"+discountPercentage);
									//End of code changes for 604
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId); 
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
									XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
									XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
									//Added for setting ExtnDiscLevelCode
									//XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_DISC_LVL_CODE,discLvlCode);

									XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_DISC_LVL_CODE,KohlsPoCPnPUtil.getDiscLevelCodeFromTVS(discLvlCode));
									//Fix for Defect 3715 and 3722 - Start
									if(XMLUtil.getAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_DISC_LVL_CODE).equalsIgnoreCase("TLD") && !YFCCommon.isVoid(eleGetOffer)){
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,KohlsPoCPnPUtil.getTLDImpactValue(tvsResponseEle,eleGetOffer.getAttribute("id")));
									}else{
										logger.debug("The Offer applied is LID. So no adjustment override value set");
									}
									//Fix for Defect 3715 and 3722 - End
									XMLUtil.setAttribute(extnOfferEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
									//CPE-2449 to add 5 and 15 digit offer ids for supc in EJ - start
									String supcOfferID = eleGetOffer.getAttribute(KohlsPOCConstant.ATTR_OFFER_ID);
									if(!YFCCommon.isStringVoid(appliedSUPCCode)){
										XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTNOFFERCOUPONNO, supcOfferID );
									}
									//CPE-2449 to add 5 and 15 digit offer ids for supc in EJ - end
									if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()){
										isOfferApplied = true;
										//OMNI2 BOGO changes - Start
										if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
											offerChargePerLineDbl = offerChargePerLineDbl + Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
										}
										else {
											offerChargePerLineDbl = offerChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
										}
										//OMNI2 BOGO changes - End
									}
									//Added 'if' for 5360 defect fix 
									if(!YFCCommon.isVoid(eleGetOffer))
									{
										//Sales Hub Clob -- for GetOffer
										if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
											prepareSalesHubClobObj.prepareSalesHubData(eleGetOffer,
													modifierEle, extnEle,  null,null,promotionType);
										}// End:
									}


									//Added 'if' for 5360 defect fix
									if(!YFCCommon.isVoid(eleBuyOffer))
									{
										//Sales Hub Clob -- for BuyOffer
										if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
											prepareSalesHubClobObj.prepareSalesHubData(eleBuyOffer,
													modifierEle, extnEle,  null,null,promotionType);
										}// End:
									}



								}
								else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))
								{
									String empDiscCode = null;
									
									//replacing XPathUtil with XMLUtil - Start
									/*Element eleReference = (Element)KohlsXPathUtil.getNode(orderLineEle, "./References/Reference[@Name='ExtnEmpDiscCode']");
									if(!YFCCommon.isVoid(eleReference))
									{
										empDiscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
									}*/
									
									NodeList ndReference = orderLineEle.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
									if(!YFCCommon.isVoid(ndReference) && ndReference.getLength() > KohlsPOCConstant.ZERO_INT)
									{
										for(int k=0; k<ndReference.getLength(); k++)
										{	
											Element eleReference = ((Element)ndReference.item(k));
											if(!YFCCommon.isVoid(eleReference) && ("ExtnEmpDiscCode".equals(eleReference.getAttribute("Name"))))
											{
												empDiscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
												break;
											}
										}
									}
									//replacing XPathUtil with XMLUtil - End
									
									Map<String, String>  orderAssociateHM= orderPromoObj.getOrderAssociateHM();							
									if(orderAssociateHM.containsKey(idStr+KohlsPOCConstant.CONST_SOFT)||orderAssociateHM.containsKey(idStr+KohlsPOCConstant.CONST_HARD)){
										//String discount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(guidStr)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;

										//Added for defect 3945 fix -- Start

										String promotionID = null;
										String description = null;
										String discount = null;								
										String extnSeqNo = null;								

										String softDiscount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(idStr+KohlsPOCConstant.CONST_SOFT)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
										String hardDiscount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(idStr+KohlsPOCConstant.CONST_HARD)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;


										if (!YFCCommon.isVoid(promotionEle))
										{
											Element extnPromotionEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
											if (!YFCCommon.isVoid(extnPromotionEle))
											{
												extnSeqNo = XMLUtil.getAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE);
											}

											if(softDiscount.equals(hardDiscount))
											{
												promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE;
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
												discount = softDiscount;
												String[] args = {discount};
												description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);										
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION, description);
												//logger.debug("hardDiscount, modifierActiveStatu, taxablePriceDelta, value is line 1137"+hardDiscount+"and" +softDiscount+"and"+modifierActiveStatus+ "and"+taxablePriceDelta);
												if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);

													activePromotionGuidList.add(idStr);
												}else if(!activePromotionGuidList.contains(idStr)){								
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
												}
												Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
												if (!YFCCommon.isVoid(extnPromotonEle))
												{

													XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
													XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
												}

											}
											else if(!softDiscount.equals(hardDiscount))
											{

												if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_S)) && (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)))
												{
													promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE;
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
													discount = softDiscount;
													String[] args = {discount};
													description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);	
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION, description);
													String isSoftAssPromo = KohlsPOCConstant.NO;
													//logger.debug("hardDiscount, modifierActiveStatu, taxablePriceDelta, value is line 1165"+hardDiscount+"and" +softDiscount+"and"+modifierActiveStatus+ "and"+taxablePriceDelta);
													if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);

														activePromotionGuidList.add(idStr);
													}else if(!activePromotionGuidList.contains(idStr)){								
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
													}
													Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
													if (!YFCCommon.isVoid(extnPromotonEle))
													{

														XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
														XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
													}
													//CPE-3978  we should not mark as zero to promtion adjustment value
													if ( softTLDImpVal != KohlsPOCConstant.ZERO_DBL ) 
													{
													   XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(String.valueOf(softTLDImpVal)));
													}

												}
												else if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_H)) && (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)))
												{
													//create new promotion
													promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE;
													discount = hardDiscount;
													String[] args = {discount};
													description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);

													String isHardAssPromo = KohlsPOCConstant.NO;


													Element promotionsEle =  XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_PROMOTIONS);

													if (!YFCCommon.isVoid(promotionsEle))
													{
														Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
														if(!YFCCommon.isVoid(extnPromotonEle))
														{
															String promotionFlag = XMLUtil.getAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
															logger.debug("promotionFlag ::::" + promotionFlag);
															//Fix for defect 3949 - Changing if condition
															if(YFCCommon.isStringVoid(promotionFlag) /*&& !(isSoftDisItemAvail.equals(KohlsPOCConstant.YES))*/)
															{
																logger.debug(":::: Condition true ::::");
																//remove existing promotion element -- Start
																NodeList orderPromotionList = promotionsEle.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
																if(!YFCCommon.isVoid(orderPromotionList) && orderPromotionList.getLength() > KohlsPOCConstant.ZERO_INT)
																{
																	for(int k=0; k<orderPromotionList.getLength(); k++)
																	{
																		Element promtionEle = ((Element)orderPromotionList.item(k));
																		String promotonType = XMLUtil.getAttribute(promtionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
																		String promoID = XMLUtil.getAttribute(promtionEle, KohlsPOCConstant.A_PROMOTION_ID);

																		if(promotonType.equals(KohlsPOCConstant.ASSOCIATE_DISCOUNT) && !YFCCommon.isVoid(promoID) && 
																				promoID.equalsIgnoreCase(KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE))
																		{
																			XMLUtil.removeChild(promotionsEle, promtionEle);
																		}
																	}
																}
																//remove existing promotion element -- End


															}
														}

														Element newPromotion = XMLUtil.createChild(promotionsEle,KohlsPOCConstant.E_PROMOTION);
														XMLUtil.setAttribute(newPromotion, "IsInternal", KohlsPOCConstant.YES);
														XMLUtil.setAttribute(newPromotion, "PromotionGroup", "MANUAL");
														XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT);
														Element extnPromEle = XMLUtil.getChildElement(newPromotion,KohlsPOCConstant.E_EXTN,Boolean.TRUE);								
														XMLUtil.setAttribute(extnPromEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, extnSeqNo);


														XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
														XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_DESCRIPTION, description);

														if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
															XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);

															activePromotionGuidList.add(idStr);
														}else if(!activePromotionGuidList.contains(idStr)){								
															XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
														}

														XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(String.valueOf(hardTLDImpVal)));


														if (!YFCCommon.isVoid(extnPromoEle))
														{

															XMLUtil.setAttribute(extnPromEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
															XMLUtil.setAttribute(extnPromEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));	
														}
														//logger.debug("The tempEle element after adding temp is : " +XMLUtil.getElementXMLString(tempEle));
														//logger.debug("The new promo element before adding temp is : " +XMLUtil.getElementXMLString(newPromotion));
														//Fix for defect 3949 - Start
														if(YFCCommon.isVoid(XMLUtil.getChildElement(newPromotion, "Temp"))){
														Element tempEle = XMLUtil.getChildElement(newPromotion, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
														XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_ID, idStr);
														/*XMLUtil.importElement(newPromotion,tempEle);*/
														if(logger.isDebugEnabled()){
														logger.debug("The new promo element after adding temp is : " +XMLUtil.getElementXMLString(newPromotion));
														}
														}
														//Fix for defect 3949 - End

													}
													if(logger.isDebugEnabled()){
													//logger.debug("The promo element value of second line is: " +XMLUtil.getElementXMLString(promotionEle));
													logger.debug("The promotionsEle value is outsideeee loop: " +XMLUtil.getElementXMLString(promotionsEle));
													}
												}

											}

											XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID, promotionID);
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
											XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
											//OMNI2 BOGO changes - Start
											if(KohlsPOCConstant.YES.equalsIgnoreCase(isOmni) && KohlsPOCConstant.YES.equalsIgnoreCase(omni2Enabled)) {
												associateDiscountChargePerLineDbl =  associateDiscountChargePerLineDbl+ Math.abs(Double.valueOf(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_RETURN_PRICE_DELTA)).doubleValue());
											}
											else {
												associateDiscountChargePerLineDbl =  associateDiscountChargePerLineDbl+ Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
											}
											//OMNI2 BOGO changes - End
											isAssociateDiscountApplied = Boolean.TRUE;

										}


										//Added for 3945 defect fix --- End


										// Sales Hub
										if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

											prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
													null,null,KohlsPOCConstant.ASSOCIATE_DISCOUNT,discount) ;
										}




									}


								}


							}

							if(!XMLUtil.isVoid(awardExtEle) && !XMLUtil.isVoid(salesHubDoc)){
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(salesHubDoc));
							}

							//Fix for 1833, 1816 and 1817
							if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
								if(Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) == KohlsPOCConstant.ZERO_DBL){
									if(isItemLevelPromo){
										XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.YES);
									}else{
										XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.NO);
									} 
								}else{
									XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.YES);
								}
							}


							//XMLDiff changes - Start

							NodeList nlAward = orderLineEle.getElementsByTagName("Award");
							/*NodeList nlAward = ((NodeList)XPathUtil.getNodeList(orderEle, "/Order/OrderLines/OrderLine[@OrderLineKey='"
												+orderLineEle.getAttribute("OrderLineKey")+"']/Awards/Award[Action='Remove']"));*/
							if (!YFCCommon.isVoid(nlAward) && nlAward.getLength() > KohlsPOCConstant.ZERO_INT) {
								for (int x = 0; x < nlAward.getLength(); x++) {
									Element eleAward_temp = (Element) nlAward.item(x);
									if (checkAwardsDiff(awardsEle, awardEle, eleAward_temp)) {
										break;
									}

								}
							}

							//XMLDiff changes - End
						}



						//Based on the Flag value Line Change Element is created.
						if (isPromoApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.SKU, lineChargeEle, promoChargePerLineDbl);
						}
						if (isOfferApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.OFFER, lineChargeEle, Math.abs(offerChargePerLineDbl));
						}
						if (isTldAmountApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.TLD_AMOUNT_OFF, lineChargeEle, Math.abs(tldAmountChargePerLineDbl));
						}
						if (isTldPercentApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.TLD_PERCENT_OFF, lineChargeEle, Math.abs(tldPercentChargePerLineDbl));
						}
						if (isLegacyDollarApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LEGACY_DOLLAR, lineChargeEle, Math.abs(legacyDollarChargePerLineDbl));
						}
						if (isLegacyPercentApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LEGACY_PERCENT, lineChargeEle, Math.abs(legacyPercentChargePerLineDbl));
						}
						if (isKohlsCashApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.KOHLS_CASH_DESC, lineChargeEle, Math.abs(kohlsCashChargePerLineDbl));
						}

						if (isLidAmountApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LID_AMOUNT_OFF, lineChargeEle, Math.abs(lidAmountChargePerLineDbl));
						}
						if (isLidPercentApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.LID_PERCENT_OFF, lineChargeEle, Math.abs(lidPercentChargePerLineDbl));
						}

						if (isPriceOverrideApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.PRICE_OVERRIDE, lineChargeEle, Math.abs(priceOverrideChargePerLineDbl));
						}

						if (isPriceOverrideIncreasedApplied) {
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							this.setLineChargeValues(KohlsPOCConstant.PRICE_OVERRIDE_INCREASED, lineChargeEle, Math.abs(priceOverrideIncChargePerLineDbl));
						}

						if(isSeniorCitizenApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							setLineChargeValues(KohlsPOCConstant.SENIOR_CITIZEN,lineChargeEle,Math.abs(seniorCitizenChargePerLineDbl));
						}

						// AssociateDiscount
						if(isAssociateDiscountApplied){
							Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
							setLineChargeValues(KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE,lineChargeEle,Math.abs(associateDiscountChargePerLineDbl));
						}

						
					}
					
					//Defect #1475 - start
					
					NodeList offerList = tvsResponseEle.getElementsByTagName("offer");
					
					if(!YFCCommon.isVoid(offerList) && offerList.getLength()>0){
						Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();		
						for(int j=0; j<offerList.getLength(); j++){	
							Element eleOffer = ((Element)offerList.item(j));
							String offerID = eleOffer.getAttribute("offerId");
							//CPE-2179 - Start
							String appliedSUPCCode = eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE);
							String notAppliedSupcCode = eleOffer.getAttribute("notAppliedSupcCode");
							if((!YFCCommon.isStringVoid(notAppliedSupcCode)) && (!YFCCommon.isStringVoid(appliedSUPCCode))){
								YFSException yfsException = new YFSException();								
								yfsException.setErrorCode("OFFER_DUPLICATION");
								yfsException.setErrorDescription("The Kohl's Coupon has already been added.");
								logger.error("Duplicate offers found with same offer id,not added:"+notAppliedSupcCode+",duplicate with "+appliedSUPCCode
									+":::::: exception details:"+yfsException.getMessage());
								throw yfsException;
							}
							else if(!YFCCommon.isStringVoid(appliedSUPCCode)){
								offerID = appliedSUPCCode;
							}
							else if(!YFCCommon.isStringVoid(notAppliedSupcCode)) {
								offerID = notAppliedSupcCode;
							}
							//CPE-2179 - End
							if(!appliedOffersList.contains(offerID))
							{
								logger.debug("======= Applied Offer list does not contain offer ID :"+offerID);
									Iterator it = orderTLDHM.entrySet().iterator();
									while (it.hasNext())
									{ 
										Map.Entry pair = (Map.Entry)it.next();
										Element elePromotion = (Element)pair.getValue();
										Element tempEle = (Element)(elePromotion.getElementsByTagName("Temp")).item(0);
										if(offerID.equalsIgnoreCase(tempEle.getAttribute("Id")))
										{
											logger.debug("======= Id from tempEle matches offer ID :"+offerID);
											String orderPromotionId = XMLUtil.getAttribute(elePromotion, KohlsPOCConstant.A_PROMOTION_ID);
											Element extnPromotionEle = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
	                                        XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
											String cusDesc = eleOffer.getAttribute("customerFacingShortDescription");
											String[] args2 = {cusDesc,orderPromotionId};
											String promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_ORDER, args2);
											XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
											appliedOffersList.add(offerID);
										}
									}
									
								
								
							}
						}
					}
					
					//Defect #1475 - End 

					//rebate -- start
					NodeList awardEleList = awardsEle.getElementsByTagName(KohlsPOCConstant.E_AWARD);
					if (!YFCCommon.isVoid(awardEleList) && awardEleList.getLength() > KohlsPOCConstant.ZERO_INT){
						for(int j=0; j<awardEleList.getLength(); j++){
							Element awardEle = ((Element)awardEleList.item(j));
							Element awardExtEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN);
							String rebateResponseStr = XMLUtil.getAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_REBATE_RESPONSE);
							if(!YFCCommon.isStringVoid(rebateResponseStr)){
								Element rebateResponseEle = KohlsPoCPnPUtil.createElementFromXMLString(rebateResponseStr);
								NodeList recordEleList= rebateResponseEle.getElementsByTagName(KohlsPOCConstant.E_RECORD);
								if (!YFCCommon.isVoid(recordEleList) && recordEleList.getLength() > KohlsPOCConstant.ZERO_INT){	
									String rebateInfcId =  ((Element)recordEleList.item(KohlsPOCConstant.ZERO_INT)).getAttribute(KohlsPOCConstant.A_SYS_OF_REC_ID);
									Document salesHubDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DATA);
									Element eleData = salesHubDoc.getDocumentElement();
									// Creating an instance of KohlsPocPrepareSalesHubClob

									KohlsPoCTVSPrepareSalesHubClob prepareSalesHubClobObj = new KohlsPoCTVSPrepareSalesHubClob(eleData, awardExtEle);
									prepareSalesHubClobObj.prepareSalesHubData(null, 
											null,  extnEle,  null, rebateInfcId,KohlsPOCConstant.REBATE);

									/*prepareSalesHubData(Element tvsOfferResponseEle, Element modifierEle, Element extnEle,
													Element tvsPromoEle, String rebateInterfaceId, String promotionType)
									 */

									XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(salesHubDoc));
								}
							}
						}
					}
					//rebate -- end


					double clearanceAmtCalc = KohlsPOCConstant.ZERO_DBL;

					// Suresh : Defect fix 3423, if LOC_SKU_STAT_CDE is 30, we need to calculate TotalSavings : Start

					if(!(YFCCommon.isVoid(skuStatusCode)) && ("30".equals(skuStatusCode))){

						if(nonClearanceAmtDbl > orderLineUnitPriceDbl){
							clearanceAmtCalc = nonClearanceAmtDbl - orderLineUnitPriceDbl;
						}

					}

					// Suresh : Defect fix 3423, if LOC_SKU_STAT_CDE is 30, we need to calculate TotalSavings : End


					totalDiscount = clearanceAmtCalc + promoChargePerLineDbl + offerChargePerLineDbl+ tldAmountChargePerLineDbl + tldPercentChargePerLineDbl
							+ legacyDollarChargePerLineDbl + legacyPercentChargePerLineDbl + kohlsCashChargePerLineDbl + lidPercentChargePerLineDbl
							+ lidAmountChargePerLineDbl + priceOverrideChargePerLineDbl + seniorCitizenChargePerLineDbl + associateDiscountChargePerLineDbl;

					totalSaving = totalSaving + totalDiscount ;

					KohlsPoCPnPUtil.addTaxableAmountInTempElement(orderLineEle);




				}

			}
			
			// Start PRF-403 (Part - II)
			// Fix for defect 3949 - Start 
			if (KohlsPOCConstant.YES.equalsIgnoreCase(isSoftDisItemAvail)) {
				softTLDImpVal = assTLDImpVal - hardTLDImpVal;
			}
			// Fix for defect 3949 - End
			//End PRF-403 (Part - II)

		}

		Element extnOrder = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TOTAL_SAVINGS, String.valueOf(totalSaving));

		KohlsPoCTVSGenerateExtnPromoSequence.generateExtnPromoSequence(orderEle, tvsResponseEle);

		logger.endTimer("KohlsPoCTVSPrepareUEResponse.updateUeDocumentFromTVSResponse");
	}
	
	
	/**
	 * This method will verify if its an omni order then it will restrict addition of any PWP/GWP offer to it.
	 * @param tvsResponseEle
	 */
	private void validatePWPGWPOfferForOmni(Element tvsResponseEle) {
		logger.beginTimer("KohlsPoCTVSPrepareUEResponse.validatePWPGWPOfferForOmni");
		NodeList tvsOfferList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_OFFER);
		if ( !YFCCommon.isVoid(tvsOfferList) &&  KohlsPOCConstant.ZERO_INT<tvsOfferList.getLength() ) {
			for(int i=0; i<tvsOfferList.getLength();i++){
				Element offerTVSEle = ((Element)tvsOfferList.item(i));
				if(!YFCCommon.isVoid(offerTVSEle)){
				String strPwpGwp=offerTVSEle.getAttribute( KohlsPOCConstant.ATTR_PROMO_SCHEME_CODE);
				if (!YFCCommon.isVoid(strPwpGwp) && strPwpGwp.equals(KohlsPOCConstant.SIMPLE_PROMO_THOUSAND_TEN)) {
					YFSException yfsException = new YFSException();								
					yfsException.setErrorCode("YFS_PWP_GWP_NA");
					yfsException.setErrorDescription("This Kohls Coupon cannot be Added as Cart Contains Omni Items");
					throw yfsException;
				}	
				}
			}}
		logger.endTimer("KohlsPoCTVSPrepareUEResponse.validatePWPGWPOfferForOmni");
		}
		
	
	  
	
	protected String getEmpDscCode(Element orderLineEle) {
		
		String empDscCode = null;
		
		if (!YFCCommon.isVoid(orderLineEle)){
			NodeList ndReference = orderLineEle.getElementsByTagName(KohlsPOCConstant.A_REFERENCE);
			if (!YFCCommon.isVoid(ndReference) && ndReference.getLength() > KohlsPOCConstant.ZERO_INT) {
				for (int j = 0; j < ndReference.getLength(); j++) {
					Element eleReference = (Element) ndReference.item(j);
	
					if (!YFCCommon.isVoid(eleReference) && ("ExtnEmpDiscCode".equals(eleReference.getAttribute("Name")))) {
						empDscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
						break;
					}
				}
			}
		}
		
		return empDscCode;

	}
	
	protected String getNetPriceDelta(Element tvsResponseEle, KohlsPoCTVSOrderPromotionsCaller orderPromoObj,
			NodeList modifierEleList) {

		// Fix for defect 940 - Start
		NodeList tvsTldList = tvsResponseEle.getElementsByTagName("tld");
		String uidStr = null;
		String netPriceDelta = null;

		if (!YFCCommon.isVoid(tvsTldList) && tvsTldList.getLength() > KohlsPOCConstant.ZERO_INT) {
			for (int j = 0; j < tvsTldList.getLength(); j++) {
				Element tvsTldEle = ((Element) tvsTldList.item(j));
				String tldID = XMLUtil.getAttribute(tvsTldEle, "id");
				String tldImpactValue = XMLUtil.getAttribute(tvsTldEle, "TLDImpact");
				Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();
				if (orderTLDHM.containsKey(tldID)) {
					Element promotionEle = orderTLDHM.get(tldID);
					String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
					if (!KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType)) {
						logger.debug("The override adjustment value is stamped for TLD offers susscessfully is : "
								+ KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
						XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,
								KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
					}
					if (KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType)) {
						assTLDImpVal = Math.abs(Double.valueOf(tldImpactValue).doubleValue());
						uidStr = tldID;
					}
				}
				// Fix for defect 3949 - Start
				if (!YFCCommon.isVoid(modifierEleList) && modifierEleList.getLength() > KohlsPOCConstant.ZERO_INT) {
					logger.debug("modifierEleList condition value is ::::");
					for (int i = 0; i < modifierEleList.getLength(); i++) {
						Element modifierEle = ((Element) modifierEleList.item(i));
						String idStr = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PARENT_DISCOUNT_ID);
						if (idStr.equals(uidStr)) {
							logger.debug("tldID_uidStr condition ::::");
							// Fix for defect 1040 - Start
							netPriceDelta = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_NET_PRICE_DELTA);
							// Fix for defect 1040 - End
							logger.debug("netPriceDelta ::::" + tldImpactValue);
						}
					}
				}
				// Fix for defect 3949 - End
			}
		}
		// Fix for defect 940 - End
		return netPriceDelta;
	}

	protected boolean checkAwardsDiff(Element awardsEle, Element awardEle, Element eleAward_temp) {

		logger.beginTimer("KohlsPoCTVSPrepareUEResponse.checkAwardsDiff");

		String sAction = eleAward_temp.getAttribute(KohlsPOCConstant.A_ACTION);

		if (!YFCCommon.isVoid(sAction) && sAction.equalsIgnoreCase(KohlsPOCConstant.REMOVE)) {
			// Defect 1118 - Start
			Element eleExtnAward_temp = XMLUtil.getChildElement(eleAward_temp, "Extn");
			String sOldAwardSequence = XMLUtil.getAttribute(eleExtnAward_temp, "ExtnAwardSequence");
			Element awardExtnEle = XMLUtil.getChildElement(awardEle, "Extn");
			String sCurrentAwardSequence = XMLUtil.getAttribute(awardExtnEle, "ExtnAwardSequence");
			if (YFCCommon.isVoid(sOldAwardSequence)) {
				sOldAwardSequence = "";
			}
			if (YFCCommon.isVoid(sCurrentAwardSequence)) {
				sCurrentAwardSequence = "";
			}
			// Defect 1118 - End
			// Fix for defect 2292 - Start
			String sOldextnNetDelta = eleExtnAward_temp.getAttribute(KohlsPOCConstant.A_EXTN_NET_DELTA);
			String sCurrentextnNetDelta = awardExtnEle.getAttribute(KohlsPOCConstant.A_EXTN_NET_DELTA);
			if (YFCCommon.isVoid(sOldextnNetDelta)) {
				sOldextnNetDelta = "";
			}
			if (YFCCommon.isVoid(sCurrentextnNetDelta)) {
				sCurrentextnNetDelta = "";
			}
			// Fix for defect 2292 - End
			String sOldAwardAmount = eleAward_temp.getAttribute("AwardAmount");
			if (YFCCommon.isVoid(sOldAwardAmount)) {
				sOldAwardAmount = "";
			}
			String sOldAwardApplied = eleAward_temp.getAttribute("AwardApplied");
			if (YFCCommon.isVoid(sOldAwardApplied)) {
				sOldAwardApplied = "";
			}
			String sOldDescription = eleAward_temp.getAttribute("Description");
			if (YFCCommon.isVoid(sOldDescription)) {
				sOldDescription = "";
			}
			String sOldPromotionId = eleAward_temp.getAttribute("PromotionId");
			if (YFCCommon.isVoid(sOldPromotionId)) {
				sOldPromotionId = "";
			}

			String sCurrentAwardAmount = awardEle.getAttribute("AwardAmount");
			if (YFCCommon.isVoid(sCurrentAwardAmount)) {
				sCurrentAwardAmount = "";
			}
			String sCurrentAwardApplied = awardEle.getAttribute("AwardApplied");
			if (YFCCommon.isVoid(sCurrentAwardApplied)) {
				sCurrentAwardApplied = "";
			}
			String sCurrentDescription = awardEle.getAttribute("Description");
			if (YFCCommon.isVoid(sCurrentDescription)) {
				sCurrentDescription = "";
			}
			String sCurrentPromotionId = awardEle.getAttribute("PromotionId");
			if (YFCCommon.isVoid(sCurrentPromotionId)) {
				sCurrentPromotionId = "";
			}
			// Defect 1118 - added awardSequence check
			// Defect 2292 - added ExtnNetDelta check
			if (sOldextnNetDelta.equalsIgnoreCase(sCurrentextnNetDelta)
					&& sOldAwardAmount.equalsIgnoreCase(sCurrentAwardAmount)
					&& sOldAwardApplied.equalsIgnoreCase(sCurrentAwardApplied)
					&& sOldDescription.equalsIgnoreCase(sCurrentDescription)
					&& sOldPromotionId.equalsIgnoreCase(sCurrentPromotionId)
					&& sOldAwardSequence.equalsIgnoreCase(sCurrentAwardSequence)) {
				awardsEle.removeChild(eleAward_temp);
				awardsEle.removeChild(awardEle);
				if (logger.isDebugEnabled()) {
					logger.debug("Removing duplicate award to avoid DB write: " + XMLUtil.getElementXMLString(awardEle));
				}
				return true;
			}
		}
		logger.endTimer("KohlsPoCTVSPrepareUEResponse.checkAwardsDiff");
		return false;

	}



	/**
	 * 
	 * Based on the LookUpType parameter value , Chargecategory and ChargeName 
	 * 
	 * @param lookUpTye
	 * @param lineChargeEle
	 * @param chargePerLine
	 */

	private void setLineChargeValues(String lookUpTye, Element lineChargeEle, double chargePerLine) {

		logger.beginTimer("KohlsPoCTVSPrepareUEResponse.setLineChargeValues");
		chargePerLine = Math.abs(chargePerLine);
		XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_CHARGE_PER_LINE, KohlsPoCPnPUtil.getDouble(String.valueOf(chargePerLine)));
		XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_BILLABLE, KohlsPOCConstant.YES);
		XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.YES);

		if (KohlsPOCConstant.SKU.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.PROMO_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.PROMO_DISCOUNT);
		} else if (KohlsPOCConstant.OFFER.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.OFFER_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.OFFER_DISCOUNT);
		} else if (KohlsPOCConstant.TLD_AMOUNT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_TLD);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.TLD_AMOUNT_OFF_LINE_CHARGE);
		} 
		//Fix for defect 4086 - Adding condition check for Quick Credit Discount
		else if (KohlsPOCConstant.TLD_PERCENT_OFF.equals(lookUpTye) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_TLD);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.TLD_PERCENT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.LEGACY_DOLLAR.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.KOHLS_CASH_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LEGACY_DOLLAR);
		} else if (KohlsPOCConstant.LEGACY_PERCENT.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.KOHLS_CASH_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LEGACY_PERCENT);
		} else if (KohlsPOCConstant.KOHLS_CASH_DESC.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.KOHLS_CASH_DISCOUNT);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.KOHLS_CASH_DESC);
		} else if (KohlsPOCConstant.LID_AMOUNT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_LID);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LID_AMOUNT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.LID_PERCENT_OFF.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_LID);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.LID_PERCENT_OFF_LINE_CHARGE);
		} else if (KohlsPOCConstant.PRICE_OVERRIDE.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.PRICE_OVER_RIDE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.PRICE_OVER_RIDE_LINE_CHARGE);
		} else if (KohlsPOCConstant.PRICE_OVERRIDE_INCREASED.equals(lookUpTye)) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.PRICE_OVER_RIDE_INCREASE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.PRICE_OVER_RIDE_INCREASE_LINE_CHARGE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.NO);
		} else if(KohlsPOCConstant.SENIOR_CITIZEN.equals(lookUpTye)){
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.SENIOR_CITIZEN);
		} else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE.equals(lookUpTye)){
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.ASSOCIATE_DISCOUNT_CHARGE);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.ASSOCIATE);
		}
		/*//Fix for defect 4086 - Start
		else if (KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equals(lookUpTye) ) {
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.MANUAL_TLD);
			XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, "TLDQCPercentOff");
		}
		//Fix for defect 4086 - End */



		logger.endTimer("KohlsPoCTVSPrepareUEResponse.setLineChargeValues");
	}



	/**
	 * 
	 * @return pluPromoRecordHM
	 */
	public Map<String, Element> getPromoHM() {
		return this.promoHM;
	}

	/**
	 * Promo Related award description are constructed  and added in the Award Element
	 * 
	 * @param pluFileRecordEle
	 * @param recordEle
	 * @param awardEle
	 * @param regularPrice
	 * @param bogoSetId
	 */
	private void addPromoAwardDescription(Element promoEle, Element awardEle) {	
		logger.beginTimer("KohlsPoCTVSPrepareUEResponse.addPromoAwardDescription");
		String promoSchemeCode = XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_PROMO_SCHEME_CODE);
		String rcpttxt = XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_RECEIPT_CMT_TEXT);
		String strDiscountAmount = "0.00";
		String strDiscountPercentage = "0";

		StringBuffer descriptionStrBfr = new StringBuffer();
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		if(!XMLUtil.isVoid((XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_DISCOUNT_AMT)))){
			strDiscountAmount = XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_DISCOUNT_AMT);
		}
		if(!XMLUtil.isVoid((XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_DISCOUNT_PERCENT)))){

			//Fix for defect 652 - Start
			strDiscountPercentage = XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_DISCOUNT_PERCENT);
			int intDiscountPercentage = Double.valueOf(strDiscountPercentage).intValue() ;

			if(intDiscountPercentage>999){
				logger.debug("Discount Percent is divided by 1000, since its calculated from tierPercentage :"+strDiscountPercentage);
				strDiscountPercentage = intDiscountPercentage/KohlsPOCConstant.THOUSAND_INT +"";
			}
			//Fix for defect 652 - End
		}
		logger.debug("Discount Percent is :"+strDiscountPercentage);


		//Award Description for 'Gift with Purchase' , 'Gold star' are handled by Toshiba //Group Pricing Sub-Line
		if (Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode)) || Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PROMO).equals(Integer.valueOf(promoSchemeCode))) { 
			//Fix for defect 621 - Start
			String groupRetailAmt = twoDForm.format((Double.valueOf(strDiscountAmount)));
			//Fix for defect 621 - End
			descriptionStrBfr.append(XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_INC_BUY_QTY))
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.FOR_$)
			.append(groupRetailAmt);
			//The word - Eligible is appended by Toshiba for awards applied = 'N'. //Tier Buy Doller Get % Promotion Sub-line 
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) {
			//String discountPercentage = String.valueOf(Double.valueOf(strDiscountPercentage).intValue() / KohlsPOCConstant.THOUSAND_INT);
			descriptionStrBfr.append(rcpttxt)
			.append(KohlsPOCConstant.SPACE)
			.append(strDiscountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.	 
			//Tier Buy Qty Get % Promotion Sub-line
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) { 
			//String discountPercentage = String.valueOf(Double.valueOf(strDiscountPercentage).intValue() / KohlsPOCConstant.THOUSAND_INT);
			descriptionStrBfr.append(rcpttxt)
			.append(KohlsPOCConstant.SPACE)
			.append(strDiscountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.	 //BOGO Buy Qty Get Price Point Promotion Sub-line  
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PRICE_POINT).equals(Integer.valueOf(promoSchemeCode))) {
			//Fix for defect 621 - Start
			String discountAmount = twoDForm.format(Double.valueOf(strDiscountAmount));
			//Fix for defect 621 - End
			//For Bogo grouping, BOGO set ID# fetched from APE REsponse : Transaction\ItemList\Item\BogoGrpCode

			descriptionStrBfr.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_INC_BUY_QTY))		
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(discountAmount);

			//				The word - Eligible is appended by Toshiba for awards applied = 'N'.//BOGO Buy Qty Get % Promotion Sub-line	 
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_FOR_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))) { 
			//String discountPercentage = String.valueOf(Double.valueOf(strDiscountPercentage).intValue() / KohlsPOCConstant.THOUSAND_INT);
			//For Bogo grouping, BOGO set ID# fetched from APE REsponse : Transaction\ItemList\Item\BogoGrpCode
			descriptionStrBfr.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_INC_BUY_QTY))	
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(strDiscountPercentage)
			.append(KohlsPOCConstant.PERCENT_SYMBOL);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.
			//BOGO Buy Qty Get Free Promotion Sub-line
		} else if (Integer.valueOf(KohlsPOCConstant.PROMO_BOGO_GET_ONE_GET_FREE).equals(Integer.valueOf(promoSchemeCode))) {
			//For Bogo grouping, BOGO set ID# fetched from APE REsponse : Transaction\ItemList\Item\BogoGrpCode
			descriptionStrBfr.append(KohlsPOCConstant.BUY_BOGO_DESC)
			.append(KohlsPOCConstant.SPACE)
			.append(XMLUtil.getAttribute(promoEle, KohlsPOCConstant.ATTR_INC_BUY_QTY))
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.GET_1)
			.append(KohlsPOCConstant.SPACE)
			.append(KohlsPOCConstant.FREE);
			//			The word - Eligible is appended by Toshiba for awards applied = 'N'.	 
		} else if (Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_HUNDRED).equals(Integer.valueOf(promoSchemeCode)) || 
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_HUNDRED_ONE).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED_ONE).equals(Integer.valueOf(promoSchemeCode)) ||
				Integer.valueOf(KohlsPOCConstant.SIMPLE_PROMO_TWO_HUNDRED_THREE).equals(Integer.valueOf(promoSchemeCode)) 

				) {
			descriptionStrBfr.append(KohlsPOCConstant.PROMO_DISCOUNT_DESC);
		}

		XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, descriptionStrBfr.toString());
		logger.debug("Award Description is: "+descriptionStrBfr.toString());
		logger.endTimer("KohlsPoCTVSPrepareUEResponse.addPromoAwardDescription");
	}

	/**
	 * The updateUeDocumentFromTVSResponsePSA API will update the order & order line elements according to the TVS response for PSA
	 *
	 * @param yfsEnv
	 * @param tvsResponseEle
	 * @param orderEle
	 * @param orderPromoObj
	 * @param linePromoObj
	 * @throws Exception
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParseException
	 */
	public void updateUeDocumentFromTVSResponsePSA(YFSEnvironment yfsEnv,Element tvsResponseEle,
			Element orderEle,  KohlsPoCTVSOrderPromotionsCaller orderPromoObj, KohlsPoCTVSOrderLinePromotionCaller
			linePromoObj) throws Exception, ParserConfigurationException, SAXException, IOException, ParseException  {

		logger.beginTimer("KohlsPoCTVSPrepareUEResponse.updateUeDocumentFromTVSResponse");

		double assTLDImpVal = KohlsPOCConstant.ZERO_DBL;
		double softTLDImpVal = KohlsPOCConstant.ZERO_DBL;
		double hardTLDImpVal = KohlsPOCConstant.ZERO_DBL;
		String uidStr = null;
		String isSoftDisItemAvail = KohlsPOCConstant.NO;

		//Updating Order Level Promotion/@OverrideAdjustmentValue
		NodeList tvsItmList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM);

		if (!YFCCommon.isVoid(tvsItmList) && tvsItmList.getLength() > KohlsPOCConstant.ZERO_INT) {
			logger.debug("apeItemList condition ::::" );
			double dNetPrcDelta = 0.0;
			
			for(int i=0; i<tvsItmList.getLength(); i++){
				Element itemTVSEle = ((Element)tvsItmList.item(i));
				String itemIdTVS = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_ID);
				Map<String, Element> orderLineHM = linePromoObj.getOrderLineHM();
				logger.debug("orderLineHM condition ::::" );
				Element orderLineEle = orderLineHM.get(itemIdTVS);
				String empDscCode = null;

				Element eleReference = (Element)KohlsXPathUtil.getNode(orderLineEle, "./References/Reference[@Name='ExtnEmpDiscCode']");
				if(!YFCCommon.isVoid(eleReference)){
					empDscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
				}


				String netPriceDelta = null;

				NodeList tvsTldList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.TLD);
				if (!YFCCommon.isVoid(tvsTldList) && tvsTldList.getLength() > KohlsPOCConstant.ZERO_INT) {
					
					for(int j=0; j<tvsTldList.getLength(); j++){
						
						Element tvsTldEle = ((Element)tvsTldList.item(j));
						String tldID = XMLUtil.getAttribute(tvsTldEle, "id");
						String tldImpactValue = XMLUtil.getAttribute(tvsTldEle, KohlsPOCConstant.TLD_IMPACT);
						Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();
						if(orderTLDHM.containsKey(tldID)){
							Element promotionEle = orderTLDHM.get(tldID);
							String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);

							if(!KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType))
							{
								XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(tldImpactValue));
							}
							if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType)){
								assTLDImpVal = Math.abs(Double.valueOf(tldImpactValue).doubleValue());
								uidStr = tldID;
							}
						}

						if(tldID.equals(uidStr)){
							logger.debug("tldID_uidStr condition ::::" );
							netPriceDelta = tldImpactValue ;
							logger.debug("netPriceDelta ::::" + tldImpactValue);
						}

					}
				}

				if (!YFCCommon.isVoid(empDscCode)
						&& !YFCCommon.isVoid(netPriceDelta)){
					if(empDscCode.equals(KohlsPOCConstant.CONST_H)){
						hardTLDImpVal = hardTLDImpVal+ Math.abs(Double.valueOf(netPriceDelta).doubleValue());
						logger.debug("hardTLDImpVal ::::" + hardTLDImpVal);
					}

					else if(empDscCode.equals(KohlsPOCConstant.CONST_S)){
						isSoftDisItemAvail = KohlsPOCConstant.YES;
						logger.debug("isSoftDisItemAvail in condition ::::" + isSoftDisItemAvail);
					}
				}

			 }
		 }

			softTLDImpVal = assTLDImpVal-hardTLDImpVal;
			logger.debug("isSoftDisItemAvail ::::" + isSoftDisItemAvail);

			List<String> activePromotionGuidList = new ArrayList<String>();
			NodeList tvsItemList = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM);

			double totalSaving = KohlsPOCConstant.ZERO_DBL;
			if (!YFCCommon.isVoid(tvsItemList) && tvsItemList.getLength() > KohlsPOCConstant.ZERO_INT) {

				for(int i=0; i<tvsItemList.getLength(); i++){
					Element itemTVSEle = ((Element)tvsItemList.item(i));
					String itemUniID = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_ID);

					Map<String, Element> orderLineHM = linePromoObj.getOrderLineHM();
					if (orderLineHM.containsKey(itemUniID)) {

						double totalDiscount = KohlsPOCConstant.ZERO_DBL;
						double tldPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double tldAmountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double seniorCitizenChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double legacyDollarChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double legacyPercentChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double kohlsCashChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double associateDiscountChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double offerChargePerLineDbl = KohlsPOCConstant.ZERO_DBL;
						double orderLineUnitPriceDbl = KohlsPOCConstant.ZERO_DBL;
						double nonClearanceAmtDbl = KohlsPOCConstant.ZERO_DBL;
						boolean isTldPercentApplied = false;
						boolean isTldAmountApplied = false;
						boolean isLegacyDollarApplied = false;
						boolean isLegacyPercentApplied = false;
						boolean isSeniorCitizenApplied = false;
						boolean isKohlsCashApplied = false;
						boolean isOfferApplied = false;
						boolean isAssociateDiscountApplied = false;

						//getting the orderline item from the order line hashmap
						Element orderLineEle = orderLineHM.get(itemUniID );
						logger.debug("Processing the TVS response for PrimeLineNo: "+itemUniID);
						Element eleOrigLinePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
						String strOrigTaxableFlag = XMLUtil.getAttribute(eleOrigLinePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG);
						orderLineEle.removeChild(XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO));
						Element linePrcEle = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
						Element eleTaxes = XMLUtil.getChildElement(itemTVSEle, KohlsPOCConstant.ELEM_LINE_TAXES);
						Element eleTVSLineTax = XMLUtil.getChildElement(eleTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
						Element eltaxExtn = XMLUtil.getChildElement(eleTVSLineTax, KohlsPOCConstant.E_EXTN);
						double dTVSLineTax=0 ;
						if(!YFCCommon.isVoid(eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX))){
							dTVSLineTax = Double.parseDouble(eleTVSLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX));
						}DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
						//Added for UPCCode -- start
						Element itmEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_ITEM);
						String upcStr = XMLUtil.getAttribute(itmEle,KohlsPOCConstant.A_UPC_CODE);
						orderLineEle.appendChild(linePrcEle);
						//setting updated unit price under orderLine Element
						String orderLineUnitPrice = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_RETURN_PRICE);
						String totalTax = "0";
						Element eleLineTaxes = XMLUtil.getChildElement(itemTVSEle, KohlsPOCConstant.ELEM_LINE_TAXES);
						if(!YFCCommon.isVoid(eleLineTaxes)){
							Element eleLineTax = XMLUtil.getChildElement(eleLineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
							if(!YFCCommon.isVoid(eleLineTax)){
								totalTax =eleLineTax.getAttribute("LineTotalTax");
							}
						}
						
						String orderLineTaxablePrice = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE);
						double dTotalLine = Double.parseDouble(orderLineTaxablePrice)+Double.parseDouble(totalTax);
						
						XMLUtil.setAttribute(linePrcEle, "InvoicedLineTotal",twoDForm.format(dTotalLine));
						XMLUtil.setAttribute(linePrcEle,KohlsPOCConstant.E_LINE_TOTAL,twoDForm.format(dTotalLine));
						XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_TAXABLE_FLAG, strOrigTaxableFlag);
						//updating the extn element attributes under orderLine Element
						Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_RETURN_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_RETURN_PRICE)));
						if(dTVSLineTax > 0){
							XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(eltaxExtn, KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT)));
						}else{
							XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAXABLE_AMOUNT, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE)));
						}
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SELLING_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SELLING_PRICE)));
						/* -- Commenting following changes as part of Defects #3061 , #3062 , #3063 -- Begin --- 25/7/16
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SIMPLE_PROMO_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SIMPLE_PROMO_PRICE)));
						/-- Commenting following changes as part of Defects #3061 , #3062 , #3063 -- End --- 25/7/16 */
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_NET_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_NET_PRICE)));
						//XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_RECPTT_RTN_PRICE, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_RECEIPT_RETURN_PRICE)));
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BOGO_GPID, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_BOGO_GRP_CODE));
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PWP_GROUP_ID, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_PWP_GWP_GROUP_CODE));
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_BUY_ITEM, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_BUY_ITEM));

						
						/* Commenting as part of Defects #3061 , #3062 , #3063 -- Begin --- 25/7/16
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_RETAIL_AMT,twoDForm.format(Double.valueOf(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_REGULAR_PRICE))));
						//Commenting as part of Defects #3061 , #3062 , #3063 -- Begin --- 25/7/16 */
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_EXCLUSION_ITEM, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_EXCLUSION_ITEM));

                                                //Commented as a part of SubTotal Fix
						/*Element linePriceEle = XMLUtil.getChildElement(orderLineEle, "LinePriceInfo", Boolean.TRUE);
						XMLUtil.setAttribute(linePriceEle, "UnitPrice", KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_NET_PRICE)));*/

						String isDiscountable = itemTVSEle.getAttribute(KohlsPOCConstant.ATTR_DISC_ELG_IND);
						if(KohlsPOCConstant.YES.equalsIgnoreCase(isDiscountable)){
							isDiscountable = KohlsPOCConstant.YES;
						}
						else{
							isDiscountable = KohlsPOCConstant.NO;
						}
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_DISCOUNTABLE, isDiscountable);

						String skuStatusText = itemTVSEle.getAttribute(KohlsPOCConstant.ATTR_SKU_STATUS);
						String skuStatusCode = KohlsPoCPnPUtil.getStatusCodeFromTVS(skuStatusText);
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SKU_STATUS_CODE, skuStatusCode);

						String nonClearanceAmt = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_LAST_NON_CLR_PRI);
						orderLineUnitPriceDbl = Double.valueOf(XMLUtil.getAttribute(itemTVSEle,KohlsPOCConstant.ATTR_REGULAR_PRICE));
						if (!YFCCommon.isVoid(nonClearanceAmt)) {
							nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt);
							nonClearanceAmt = twoDForm.format(nonClearanceAmtDbl);
							nonClearanceAmtDbl = Double.valueOf(nonClearanceAmt);
						}
						else{
							nonClearanceAmt = XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_REGULAR_PRICE);
							nonClearanceAmtDbl = orderLineUnitPriceDbl;
						}
						XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_NON_CLEARANCE_AMT, nonClearanceAmt);

						//update awards element under orderlines
						Element awardsEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, Boolean.TRUE);

						//update line charges elements under orderlines
						Element lineChargesEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES, Boolean.TRUE);
						orderLineEle.removeChild(lineChargesEle);
						lineChargesEle = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);
						lineChargesEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
						NodeList modifierEleList = itemTVSEle.getElementsByTagName(KohlsPOCConstant.ELEM_MODIFIER);
						int awardSequence = KohlsPOCConstant.ZERO_INT;

						if(orderPromoObj.getAwardSequenceMap().containsKey(itemUniID)){
							awardSequence = orderPromoObj.getAwardSequenceMap().get(itemUniID);
						}

						logger.debug("Award Sequence to be start with"+ awardSequence);

						if (!YFCCommon.isVoid(modifierEleList) && modifierEleList.getLength() > KohlsPOCConstant.ZERO_INT){
							logger.debug("Processing Modifiers for PSA");

							//For Every Modifier
							for(int j=0; j<modifierEleList.getLength(); j++){
								boolean isItemLevelPromo = Boolean.FALSE;
								Element modifierEle = ((Element)modifierEleList.item(j));
								String idStr = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_PARENT_DISCOUNT_ID);

								logger.debug("Parent Discount ID is: "+idStr);
								logger.debug("Checking if this discount ID corresponds to offers or not");

								NodeList nlOfferList = tvsResponseEle.getElementsByTagName("offerList");

								if (!YFCCommon.isVoid(nlOfferList) && nlOfferList.getLength() > KohlsPOCConstant.ZERO_INT) {
									Element eleOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle,
											"/adjustmentResponse/transaction/offerList/offer[@id='"+idStr+"']")).item(0);
									if(!YFCCommon.isVoid(eleOffer)){										
										String appliedSUPCCode = eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE);
										String notAppliedSupcCode = eleOffer.getAttribute(KohlsPOCConstant.A_NOTAPPLIEDSUPCCODE);
										if((!YFCCommon.isStringVoid(notAppliedSupcCode)) && (!YFCCommon.isStringVoid(appliedSUPCCode))){
											YFSException yfsException = new YFSException();								
											yfsException.setErrorCode("OFFER_DUPLICATION");
											yfsException.setErrorDescription("The Kohl's Coupon has already been added.");
											logger.error("Duplicate offers found with same offer id,not added:"+notAppliedSupcCode+",duplicate with "+appliedSUPCCode
													+":::::: exception details:"+yfsException.getMessage());
											throw yfsException;
										}
									}
									
									if(!YFCCommon.isVoid(eleOffer)){
										if(!YFCCommon.isVoid(eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE)))
										{
											idStr = eleOffer.getAttribute(KohlsPOCConstant.A_APPLIEDSUPCCODE);
										}else {
											idStr = eleOffer.getAttribute("offerId");
										}
										logger.debug("Modifier discount id corresponds to an offer id: "+idStr);
									}
								}


								//Creating and updating awards and awards Extn Elements according to each modifier

								Element awardEle = XMLUtil.createChild(awardsEle, KohlsPOCConstant.E_AWARD);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());

								String modifierActiveStatus = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_MODIFIER_ACTIVE);
								logger.debug("Modifier Active status: "+modifierActiveStatus);

								if (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
								} else{
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.NO);
								}

								String taxablePriceDelta =  XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA);
								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, KohlsPoCPnPUtil.getDouble(taxablePriceDelta));

								Element awardExtEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TAX_DELTA, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TAXABLE_PRICE_DELTA)));
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_NET_DELTA, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_NET_PRICE_DELTA)));
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_ACT_DELTA, KohlsPoCPnPUtil.getDouble(XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_ACTIVATION_ACHIEVED)));
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_PER_DELTA, XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_PERCENT_ACHIEVED));

								String tierLevelAchieved = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.ATTR_TIER_LEVEL_ACHIEVED);
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TIER_LVL_ACHVD, tierLevelAchieved);
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.ATTR_EXTN_SALE_PRICE,XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SIMPLE_PROMO_PRICE));

								awardSequence = awardSequence + KohlsPOCConstant.ONE_INT;
								XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, String.valueOf(awardSequence));

								if(!YFCCommon.isVoid(upcStr)){
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_UPC_CODE,upcStr);
								}
								else{
									XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_UPC_CODE,"");
								}

								XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ITEM_ID, XMLUtil.getAttribute(itemTVSEle, KohlsPOCConstant.ATTR_SKU));

								Document salesHubDoc = null;
								Element eleData = null;
								KohlsPoCTVSPrepareSalesHubClob prepareSalesHubClobObj = null;

								// Code modification for allowing clob to be formed for AWARD_APPLIED TO 'Y' OR 'N'
								if((KohlsPOCConstant.YES.equalsIgnoreCase(XMLUtil.getAttribute(awardEle,KohlsPOCConstant.A_AWARD_APPLIED)) )
										|| (KohlsPOCConstant.NO.equalsIgnoreCase(XMLUtil.getAttribute(awardEle,KohlsPOCConstant.A_AWARD_APPLIED))) ){
									salesHubDoc = XMLUtil.createDocument(KohlsPOCConstant.E_DATA);
									eleData = salesHubDoc.getDocumentElement();
									// Creating an instance of KohlsPocPrepareSalesHubClob

									prepareSalesHubClobObj = new KohlsPoCTVSPrepareSalesHubClob(eleData, awardExtEle);
									//Performance improvement changes - Start
									if(logger.isDebugEnabled()){
									logger.debug("The eleData Element value is: "+XMLUtil.getElementXMLString(eleData));
								}
									//Performance improvement changes - End
								}

								//Order Level Promotions are handled here TLD
								//Will be constructing promotion description and description
								//Will be calculating category based charges

								Map<String, Element> orderTLDHM = orderPromoObj.getOrderTLDHM();
								if (orderTLDHM.containsKey(idStr)) {
									logger.debug("orderTLDHM contains idStr "+idStr);

									Element promotionEle = orderTLDHM.get(idStr);
									String promotionType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
									Element extnPromoEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
									//Changes for defect 2704-- Start
									String extnOffLineMode = XMLUtil.getAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
									//Changes for defect 2704-- End

									//According to the promotion type block by block designed.
									//Promotion types Amount Off, Percent Off, Senior DIscount,
									//finding descriptoion of award element
									//finding description of award/extn element
									//calculating discount applied
									//after applying coupon finding coupon value
									//updating description, discount, coupon value remaining

									if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)
											|| KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) 
											|| KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {

										Element prmotionExtnEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);

										XMLUtil.setAttribute(prmotionExtnEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

										Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);

										if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											activePromotionGuidList.add(idStr);
										}else if(!activePromotionGuidList.contains(idStr)){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
										}

										XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);

										String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
										String description = KohlsPOCConstant.EMPTY;
										String promotionDesc  = KohlsPOCConstant.EMPTY;

										if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {

											String overrideAdjustmentValue = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
											String[] args = {twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue)))};
											String extnDiscount=XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT);

											String tldDolar = KohlsPOCConstant.TLD_DOLLAR_DESCRIPTION;
											String[] args2 = {tldDolar};

											promotionDesc = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_ORDER_PROP_KEY, args2);
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.DOLLAR_TLD_LINE_PROP_KEY, args);

											if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {
												isTldAmountApplied = true;
												tldAmountChargePerLineDbl = tldAmountChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
											}
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDesc);
											// CPE-6061 - Start
											if(KohlsPoCPnPUtil.isSaleTLDPromotion(promotionEle)){
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											}
											// CPE-6061 - End
										}

										 else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) 
												 	|| KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
												String extnDiscountPercent = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

												if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
													String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};
													if(KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)){
														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.QUICK_CREDIT_TLD_ORDER_PROP_KEY, args);
													}else{
														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PERCENT_TLD_LINE_PROP_KEY, args);
													}

													eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))) );
												}
												if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()) {




													isTldPercentApplied = true;

													tldPercentChargePerLineDbl = tldPercentChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
												}
												// CPE-6061 - Start
												if(!YFCCommon.isVoid(orderPromotionId) && (orderPromotionId.contains("760Q") || orderPromotionId.contains("734Q"))){
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
												}
												// CPE-6061 - End
											}


											XMLUtil.setAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
											XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId);
											// CPE-6061 - Start
											if(!YFCCommon.isVoid(orderPromotionId) && (orderPromotionId.contains("760Q"))){
												XMLUtil.setAttribute(awardExtEle, "ExtnDiscountTypeCode", "Q");
												XMLUtil.setAttribute(awardExtEle, "ExtnDiscountReasonCode", "760");
											}
											// CPE-6061 - End
											logger.debug("The Gift attribute stamped is : "+XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT));

											XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT));

										//the below call to preapreSalesHubData will create a xml doc element with all SalesHubData attributes.
											//Finally the xml doc element will be put inside Award/Extn/ExtnSalesHubData as values

											if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
												prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,null,null,promotionType) ;
											}

										}

									//finding descriptoion of award element
									//finding description of award/extn element
									//calculating discount applied
									//after applying coupon finding coupon value
									//updating description, discount, coupon value remaining

									else if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){

										Element extnPromotionEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
										XMLUtil.setAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);


										if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											activePromotionGuidList.add(idStr);
										}else if(!activePromotionGuidList.contains(idStr)){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
										}

										XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
										XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);

										String extnDiscountPercent = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);
										String[] args = {String.valueOf(Math.abs(Double.valueOf(extnDiscountPercent).intValue()))};

										String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SENIOR_DISCOUNT_PROP_KEY, args);

										String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
										XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_DESCRIPTION,description);
										XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
										seniorCitizenChargePerLineDbl = seniorCitizenChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
										isSeniorCitizenApplied = Boolean.TRUE;

										// Added code to fix DiscountPercent for SalesHubClob Senior Discount
										if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
											eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
										}

										// Sales Hub call to updated salesHubData xml doc data. Later this salesHubClob object will be placed under award/Extn/ExtnSalesHubData as value
										if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
											prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
													null,null,promotionType) ;

										}
									}

									//finding descriptoion of award element
									//finding description of award/extn element
									//calculating discount applied
									//after applying coupon finding coupon value
									//updating description, discount, coupon value remaining

									//Changes for defect 2704-- Start
									else if(KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase(promotionType) || (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)&& !KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)) )
										//Changes for defect 2704-- End
									{
										if(!KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode))
										{
											Element extnKohlsCashResposneEle =  null;
											extnKohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnPromoEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
											String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
											String promotionIdForDesc =  orderPromotionId.substring((orderPromotionId.length())-KohlsPOCConstant.FIVE_INT);

											NodeList dataEleList = extnKohlsCashResposneEle.getElementsByTagName(KohlsPOCConstant.E_DATA);
											if(!YFCCommon.isVoid(dataEleList) && dataEleList.getLength() > KohlsPOCConstant.ZERO_INT){
												Element dataElement = (Element)dataEleList.item(KohlsPOCConstant.ZERO_INT);
												String legacyDollar = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
												String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
												String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
												String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
												String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
												String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
												String authApprovalNum = dataElement.getAttribute(KohlsPOCConstant.A_AUTH_APPROVAL_NUM);
												String description = null;
												String promotionDescription = KohlsPOCConstant.EMPTY;

												if(YFCCommon.isStringVoid(couponBalance)){
													couponBalance = KohlsPOCConstant.ZERO_STR;
												}

												double absTaxablePriceDelta = Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

												String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
												String extnCouponAmount = XMLUtil.getAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);

												if (KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
													if (!YFCCommon.isStringVoid(legacyDollar)) {

														legacyDollarChargePerLineDbl = legacyDollarChargePerLineDbl + absTaxablePriceDelta;
														isLegacyDollarApplied = Boolean.TRUE;

														if(!YFCCommon.isStringVoid(overrideMaxAdjustment)){
															String[] args = {twoDForm.format(Math.abs(Double.valueOf(legacyDollar)))};

															description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_LINE_PROP_KEY, args);
														}
														if(!YFCCommon.isStringVoid(extnCouponAmount)){
															String[] args2 = {promotionIdForDesc};
															promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_$_OFF_ORDER_PROP_KEY, args2);
														}
													}

													else if (!YFCCommon.isStringVoid(legacyPercent)) {

														String extnDiscountPercent = XMLUtil.getAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

														legacyPercentChargePerLineDbl = legacyPercentChargePerLineDbl + absTaxablePriceDelta;
														isLegacyPercentApplied = Boolean.TRUE;
														extnDiscountPercent = String.valueOf(Double.valueOf(Double.valueOf(extnDiscountPercent) * KohlsPOCConstant.HUNDRED_INT).intValue());

														String[] args = {extnDiscountPercent};

														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_LINE_PROP_KEY, args);

														String[] args2 = {extnDiscountPercent,promotionIdForDesc};

														promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.LEGCY_PERCENT_OFF_ORDER_PROP_KEY, args2);

														if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
															eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(extnDiscountPercent))));
														}
													}
												}
												else if (KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
														&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
														&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL) {

													kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + absTaxablePriceDelta;
													isKohlsCashApplied = Boolean.TRUE;

													if(!YFCCommon.isStringVoid(overrideMaxAdjustment)){
														String[] args = {String.valueOf(twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment))))};
														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_LINE_PROP_KEY, args);
													}

													if(!YFCCommon.isStringVoid(extnCouponAmount)){
														String[] args2 = {promotionIdForDesc};
														promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
													}
												}

												if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
													activePromotionGuidList.add(idStr);
												}else if(!activePromotionGuidList.contains(idStr)){
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
												}


												Element tempEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_TEMP, Boolean.TRUE);
												XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_AUTH_RESPONSE_CODE, authResponseCode);
												XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE, couponBalance);
												XMLUtil.setAttribute(extnPromoEle, KohlsPOCConstant.A_EXTN_AUTH_APPROVAL_NUMBER, authApprovalNum);
												XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
												XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
												XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId);
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);
												XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

												logger.debug("The Gift attribute stamped is : "+XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT));
												XMLUtil.setAttribute(eleData, KohlsPOCConstant.ATTR_GIFT, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT));
											}

											if (!XMLUtil.isVoid(prepareSalesHubClobObj)) {
												prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
														null,null, promotionType) ;
											}

										}
									}

									//finding descriptoion of award element
									//finding description of award/extn element
									//calculating discount applied
									//after applying coupon finding coupon value
									//updating description, discount, coupon value remaining

									else if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promotionType)&&(KohlsPOCConstant.YES.equalsIgnoreCase(extnOffLineMode)))
									{
										String promotionDescription =KohlsPOCConstant.EMPTY;

										String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
										String promotionIdForDesc =  orderPromotionId.substring((orderPromotionId.length())-KohlsPOCConstant.FIVE_INT);

										Element extnPromotionEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
										XMLUtil.setAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

										kohlsCashChargePerLineDbl = kohlsCashChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

										double  absTaxablePriceDelta = Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());

										String overrideMaxAdjustment = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);

										overrideMaxAdjustment = twoDForm.format(Math.abs(Double.valueOf(overrideMaxAdjustment)));

										String[] args = {overrideMaxAdjustment};
										String description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_LINE_PROP_KEY, args);

										String extnCouponAmount = XMLUtil.getAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);

										if(!YFCCommon.isStringVoid(extnCouponAmount)){

											String[] args2 = {promotionIdForDesc};
											promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.KOHLS_CASH_ORDER_PROP_KEY, args2);
										}

										if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											activePromotionGuidList.add(idStr);
										}else if(!activePromotionGuidList.contains(idStr)){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
										}

										XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);
										XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_DESCRIPTION,description);
										XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID,orderPromotionId);
										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);

										String couponBalance = String.valueOf(Double.valueOf(extnCouponAmount) - Double.valueOf(overrideMaxAdjustment));
										XMLUtil.setAttribute(extnPromotionEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,couponBalance);
										XMLUtil.setAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);

										isKohlsCashApplied = Boolean.TRUE;

										// Sales Hub
										if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

											prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
													null,null,promotionType) ;
										}
									}

									//finding descriptoion of award element
									//finding description of award/extn element
									//calculating discount applied by offer
									//after applying coupon finding coupon value
									//updating description, discount, coupon value remaining
									else if(KohlsPOCConstant.OFFER.equalsIgnoreCase(promotionType))
									{
										String orderPromotionId = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);

										if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											activePromotionGuidList.add(idStr);
										}else if(!activePromotionGuidList.contains(idStr)){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
										}

										Element eleGetOffer = null;
										Element eleBuyOffer = null;

										Element eleOfferListForThisOffer = (Element)(XPathUtil.getNode(tvsResponseEle,
												"/adjustmentResponse/transaction/offerList/offer[@offerId='"+idStr+"']"));
										//Performance improvement changes - Start
										//if(logger.isDebugEnabled()){
										//logger.debug("eleOfferListForThisOffer"+XMLUtil.getElementXMLString(eleOfferListForThisOffer));
										//}
										//Performance improvement changes - End
										if(nlOfferList.getLength()>0){
											eleGetOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle,
													"/adjustmentResponse/transaction/offerList/offer[@offerId='"+idStr+"'][@benefitWithPurchaseSelectionTypeCode='GET']")).item(0);

											eleBuyOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle,
													"/adjustmentResponse/transaction/offerList/offer[@offerId='"+idStr+"'][@benefitWithPurchaseSelectionTypeCode='BUY']")).item(0);
										}
										
										if(KohlsPoCPnPUtil.isSUPC(idStr)){
											eleOfferListForThisOffer = (Element)(XPathUtil.getNode(tvsResponseEle,
													"/adjustmentResponse/transaction/offerList/offer[@appliedSupcCode='"+idStr+"']"));											if(nlOfferList.getLength()>0){
													eleGetOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle,
													"/adjustmentResponse/transaction/offerList/offer[@appliedSupcCode='"+idStr+"'][@benefitWithPurchaseSelectionTypeCode='GET']")).item(0);
	 
											eleBuyOffer = (Element)((NodeList)XPathUtil.getNodeList(tvsResponseEle,
													"/adjustmentResponse/transaction/offerList/offer[@appliedSupcCode='"+idStr+"'][@benefitWithPurchaseSelectionTypeCode='BUY']")).item(0);
											}
										}

										Element extnOfferEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.A_EXTN);
										String description = null;
										String promotionDescription = null;
										String cusDesc = KohlsPOCConstant.EMPTY;
										String discLvlCode = null;
										String sGetTierLvlNum = null;

										if(!YFCCommon.isVoid(eleBuyOffer)){
											if(!YFCCommon.isVoid(eleBuyOffer.getAttribute("customerFacingShortDescription"))){
												cusDesc = eleBuyOffer.getAttribute("customerFacingShortDescription");
												logger.debug("customerdescription at eleBuyer"+cusDesc);
											}
											discLvlCode = eleBuyOffer.getAttribute("discountLevelCode");
										}
										if(!YFCCommon.isVoid(eleGetOffer)){
											if(!YFCCommon.isVoid(eleGetOffer.getAttribute("customerFacingShortDescription"))){

												cusDesc = eleGetOffer.getAttribute("customerFacingShortDescription");
												logger.debug("the eleGetOffer customer description"+cusDesc);
											}
											sGetTierLvlNum =  eleGetOffer.getAttribute("tierLevelNumber");
											discLvlCode = eleGetOffer.getAttribute("discountLevelCode");
										}

										String[] args = {String.valueOf(cusDesc)};
										if(!YFCCommon.isStringVoid(cusDesc)){
										logger.debug("the arguments is "+String.valueOf(cusDesc));
										}
										if(!YFCCommon.isVoid(args)){
										description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_LINE, args);
										logger.debug("the description is "+String.valueOf(description));
										}
										if(!YFCCommon.isStringVoid(cusDesc) && !YFCCommon.isStringVoid(orderPromotionId)){
										String[] args2 = {cusDesc,orderPromotionId};
										promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_ORDER, args2);
										logger.debug("the promotionDescription is "+promotionDescription);
										}

										//Get Offer Percentage
										String percentOffValue = KohlsPOCConstant.EMPTY;
										//eleGetOffer.getAttribute(KohlsPOCConstant.ATTR_OFFER_ID);
										if(!YFCCommon.isVoid(sGetTierLvlNum)){
											if (sGetTierLvlNum.equalsIgnoreCase(tierLevelAchieved)) {
												percentOffValue =  eleGetOffer.getAttribute("benefitWithPurchaseGetPercentOffPercent");
											}
										}

										if (!YFCCommon.isStringVoid(percentOffValue) && Double.valueOf(percentOffValue).doubleValue() > KohlsPOCConstant.ZERO_DBL) {
											String[] args3 = {cusDesc,percentOffValue};
											description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_PERCENT_LINE, args3);
											logger.debug("Percentage line"+description);
											String[] args4 = {cusDesc,orderPromotionId,percentOffValue};
											promotionDescription = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_PERCENT_ORDER, args4);
											logger.debug("promotionDescription line"+promotionDescription);
										}

										XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_PROMOTION_ID, orderPromotionId);
										XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
										XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);

										XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION,promotionDescription);

										XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
										XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_DISC_LVL_CODE,KohlsPoCPnPUtil.getDiscLevelCodeFromTVS(discLvlCode));
										
										//PST-2549 - Start
										String strIsSaleOfferNotApplied = KohlsPOCConstant.NO;
										if(!YFCCommon.isVoid(eleGetOffer)){
										strIsSaleOfferNotApplied = XMLUtil.getAttribute(eleGetOffer, "IsSaleOfferNotApplied");
										String strOfferID = XMLUtil.getAttribute(eleGetOffer,KohlsPOCConstant.ATTR_OFFER_ID);
										XMLUtil.setAttribute(extnPromoEle,KohlsPOCConstant.A_EXTNCOUPONNO,strOfferID);	
										}
										// Fix for PR-652 Begin
										
										if(XMLUtil.getAttribute(extnPromoEle,KohlsPOCConstant.A_EXTN_DISC_LVL_CODE).equalsIgnoreCase("TLD") && !YFCCommon.isVoid(eleGetOffer)){
											String strTLDValue = KohlsPoCPnPUtil.getTLDImpactValue(tvsResponseEle,eleGetOffer.getAttribute("id"));
											/*if(!YFCCommon.isVoid(strTLDValue) && strTLDValue.equalsIgnoreCase("-0.00") && !YFCCommon.isVoid(strIsSaleOfferNotApplied) && 
													KohlsPOCConstant.YES.equalsIgnoreCase(strIsSaleOfferNotApplied)){
												logger.debug("The Offer applied is Sale TLD. So complete adjustment override value set. "
														+ "The strTLDValue and strIsSaleOfferNotApplied are : "+ strTLDValue+","+strIsSaleOfferNotApplied);
											}else{
												XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,strTLDValue);
												logger.debug("The Offer is applied and adjustment override value is set");
											}*/
											if(!YFCCommon.isVoid(strIsSaleOfferNotApplied) && KohlsPOCConstant.YES.equalsIgnoreCase(strIsSaleOfferNotApplied)){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											logger.debug("The Offer applied is Sale TLD. So Promotion is applied and value set as Y. ");
											}
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE,strTLDValue);
											logger.debug("The Offer is applied and adjustment override value is set");
											logger.debug("The Offer applied is Sale TLD. So complete adjustment override value set. "
													+ "The strTLDValue and strIsSaleOfferNotApplied are : "+ strTLDValue+","+strIsSaleOfferNotApplied);
										//PST-2549 - End
										}else{
											logger.debug("The Offer applied is LID. So no adjustment override value set");
										}
										
										// Fix for PR-652 End
										
										XMLUtil.setAttribute(extnOfferEle, KohlsPOCConstant.A_EXTN_COUPON_BALANCE,KohlsPOCConstant.ZERO_STR);

										if (null != taxablePriceDelta && !taxablePriceDelta.isEmpty()){
											isOfferApplied = true;
											offerChargePerLineDbl = offerChargePerLineDbl + Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
										}

										if(!YFCCommon.isVoid(eleGetOffer)){
											//Sales Hub Clob -- for GetOffer
											if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
												prepareSalesHubClobObj.prepareSalesHubData(eleGetOffer,
														modifierEle, extnEle,  null,null,promotionType);
											}// End:
										}

										if(!YFCCommon.isVoid(eleBuyOffer)){
											//Sales Hub Clob -- for BuyOffer
											if(!XMLUtil.isVoid(prepareSalesHubClobObj)){
												prepareSalesHubClobObj.prepareSalesHubData(eleBuyOffer,
														modifierEle, extnEle,  null,null,promotionType);
											}// End:
										}
										
										// CPE-6061 - Start
										if(!YFCCommon.isVoid(orderPromotionId) && (orderPromotionId.contains("760K") || orderPromotionId.contains("761I") 
												|| orderPromotionId.contains("760Q"))){
											XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
											if(orderPromotionId.contains("760K")){
											XMLUtil.setAttribute(awardExtEle, "ExtnDiscountTypeCode", "K");
											XMLUtil.setAttribute(awardExtEle, "ExtnDiscountReasonCode", "760");
											}
											if(orderPromotionId.contains("761I")){
												XMLUtil.setAttribute(awardExtEle, "ExtnDiscountTypeCode", "I");
												XMLUtil.setAttribute(awardExtEle, "ExtnDiscountReasonCode", "761");
												}
											if(orderPromotionId.contains("760Q")){
												XMLUtil.setAttribute(awardExtEle, "ExtnDiscountTypeCode", "Q");
												XMLUtil.setAttribute(awardExtEle, "ExtnDiscountReasonCode", "760");
												}
										}
										// CPE-6061 - End
									}

									else if(KohlsPOCConstant.ASSOCIATE_DISCOUNT.equalsIgnoreCase(promotionType))
									{
										String empDiscCode = null;
										Element eleReference = (Element)KohlsXPathUtil.getNode(orderLineEle, "./References/Reference[@Name='ExtnEmpDiscCode']");
										if(!YFCCommon.isVoid(eleReference))
										{
											empDiscCode = eleReference.getAttribute(KohlsPOCConstant.A_VALUE);
										}

										Map<String, String>  orderAssociateHM= orderPromoObj.getOrderAssociateHM();

										if(orderAssociateHM.containsKey(idStr+KohlsPOCConstant.CONST_SOFT)||orderAssociateHM.containsKey(idStr+KohlsPOCConstant.CONST_HARD))
										{
											String promotionID = null;
											String description = null;
											String discount = null;
											String extnSeqNo = null;

											String softDiscount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(idStr+KohlsPOCConstant.CONST_SOFT)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;
											String hardDiscount = String.valueOf(Double.valueOf(Double.valueOf(orderAssociateHM.get(idStr+KohlsPOCConstant.CONST_HARD)) * KohlsPOCConstant.HUNDRED_INT).intValue()) ;

											if (!YFCCommon.isVoid(promotionEle))
											{
												Element extnPromotionEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
												if (!YFCCommon.isVoid(extnPromotionEle))
												{
													extnSeqNo = XMLUtil.getAttribute(extnPromotionEle,KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE);
												}

												if(softDiscount.equals(hardDiscount))
												{
													promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE;
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
													discount = softDiscount;
													String[] args = {discount};
													description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);
													XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION, description);
													logger.debug("hardDiscount, modifierActiveStatu, taxablePriceDelta, value is "+hardDiscount+"and" +softDiscount+"and"+modifierActiveStatus+ "and"+taxablePriceDelta);

													if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
														activePromotionGuidList.add(idStr);
													}else if(!activePromotionGuidList.contains(idStr)){
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
													}

													Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
													if (!YFCCommon.isVoid(extnPromotonEle))
													{
														XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
														XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));
													}
												}
												else if(!softDiscount.equals(hardDiscount))
												{
													//empDiscCode category "S"
													if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_S)) && (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)))
													{
														promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_SOFT_LINE;
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
														discount = softDiscount;
														String[] args = {discount};
														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION, description);
														String isSoftAssPromo = KohlsPOCConstant.NO;

														logger.debug("hardDiscount, modifierActiveStatu, taxablePriceDelta, value is"+hardDiscount+"and" +softDiscount+"and"+modifierActiveStatus+ "and"+taxablePriceDelta);
														if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
															XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);

															activePromotionGuidList.add(idStr);
														}else if(!activePromotionGuidList.contains(idStr)){
															XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
														}

														Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);
														if (!YFCCommon.isVoid(extnPromotonEle)){
															XMLUtil.setAttribute(extnPromotonEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
															XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));
														}
														XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(String.valueOf(softTLDImpVal)));
													}

													//empDiscCode category "H".
													else if((!YFCCommon.isStringVoid(empDiscCode)) && (empDiscCode.equalsIgnoreCase(KohlsPOCConstant.CONST_H)) && (KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)))
													{
														promotionID = KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE;
														discount = hardDiscount;
														String[] args = {discount};
														description = KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args);

														String isHardAssPromo = KohlsPOCConstant.NO;

														Element promotionsEle =  XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_PROMOTIONS);

														if (!YFCCommon.isVoid(promotionsEle))
														{
															Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);

															if(!YFCCommon.isVoid(extnPromotonEle))
															{
																String promotionFlag = XMLUtil.getAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
																logger.debug("promotionFlag ::::" + promotionFlag);
																if(YFCCommon.isStringVoid(promotionFlag) && !(isSoftDisItemAvail.equals(KohlsPOCConstant.YES)))
																{
																	logger.debug(":::: Condition true ::::");

																	NodeList orderPromotionList = promotionsEle.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);

																	if (!YFCCommon.isVoid(orderPromotionList) && orderPromotionList.getLength() > KohlsPOCConstant.ZERO_INT) {
																		for(int k=0; k<orderPromotionList.getLength();k++)
																		{
																			Element promtionEle = (Element)orderPromotionList.item(k);
																			String promotonType = XMLUtil.getAttribute(promtionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
																			String promoID = XMLUtil.getAttribute(promtionEle, KohlsPOCConstant.A_PROMOTION_ID);

																			if(promotonType.equals(KohlsPOCConstant.ASSOCIATE_DISCOUNT))
																			{
																				XMLUtil.removeChild(promotionsEle, promtionEle);
																			}
																		}
																	}
																}
															}

															//if discount is Hard discount given to emp disc code H then create new promotion element and add extn element.
															//update the extn promo flag in the order extn level

															Element newPromotion = XMLUtil.createChild(promotionsEle,KohlsPOCConstant.E_PROMOTION);
															XMLUtil.setAttribute(newPromotion, "IsInternal", KohlsPOCConstant.YES);
															XMLUtil.setAttribute(newPromotion, "PromotionGroup", "MANUAL");
															XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT);
															Element extnPromEle = XMLUtil.getChildElement(newPromotion,KohlsPOCConstant.E_EXTN,Boolean.TRUE);
															XMLUtil.setAttribute(extnPromEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, extnSeqNo);

															XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_ID, promotionID);
															XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_DESCRIPTION, description);

															if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus) && Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) > KohlsPOCConstant.ZERO_DBL){
																XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);

																activePromotionGuidList.add(idStr);
															}else if(!activePromotionGuidList.contains(idStr)){
																XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
															}
															//CPE-3978  we should not mark as zero to promotion adjustment value
		                                       if( hardTLDImpVal != KohlsPOCConstant.ZERO_DBL )
		                                       {
		                                          XMLUtil.setAttribute(newPromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, KohlsPoCPnPUtil.convertToNegative(String.valueOf(hardTLDImpVal)));
		                                       }

															if (!YFCCommon.isVoid(extnPromoEle)){
																XMLUtil.setAttribute(extnPromEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
																XMLUtil.setAttribute(extnPromEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Double.valueOf(discount)));
															}
														}
													}

												}

												XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_PROMOTION_ID, promotionID);
												XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, description);
												XMLUtil.setAttribute(awardEle,KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER,KohlsPOCConstant.YES);

												associateDiscountChargePerLineDbl =  associateDiscountChargePerLineDbl+ Math.abs(Double.valueOf(taxablePriceDelta).doubleValue());
												isAssociateDiscountApplied = Boolean.TRUE;
											}
											//form sales hub data
											if(!XMLUtil.isVoid(prepareSalesHubClobObj)){

												prepareSalesHubClobObj.prepareSalesHubData(null,  modifierEle,  extnEle,
														null,null,KohlsPOCConstant.ASSOCIATE_DISCOUNT,discount) ;
											}
										}
									}
								}

								//embedding sales hub data inside awards element
								if(!XMLUtil.isVoid(awardExtEle) && !XMLUtil.isVoid(salesHubDoc)){
									XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA, XMLUtil.getXMLString(salesHubDoc));
								}

								if(KohlsPOCConstant.YES.equalsIgnoreCase(modifierActiveStatus)){
									if(Math.abs(Double.valueOf(taxablePriceDelta).doubleValue()) == KohlsPOCConstant.ZERO_DBL){
											XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.NO);
									}else{
										XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_IS_INTERNAL, KohlsPOCConstant.YES);
									}
								}

								NodeList nlAward = orderLineEle.getElementsByTagName("Award");

								if(!YFCCommon.isVoid(nlAward) && nlAward.getLength() > KohlsPOCConstant.ZERO_INT){
									logger.beginTimer("KohlsPoCTVSPrepareUEResponse.XMLDiff");
									for(int x=0; x<nlAward.getLength(); x++){
										Element eleAward_temp = (Element) nlAward.item(x);
										String sAction = eleAward_temp.getAttribute(KohlsPOCConstant.A_ACTION);

										if(!YFCCommon.isVoid(sAction) && sAction.equalsIgnoreCase(KohlsPOCConstant.REMOVE)){
											String sOldAwardAmount = eleAward_temp.getAttribute("AwardAmount");

											if(YFCCommon.isVoid(sOldAwardAmount)){
												sOldAwardAmount="";
											}

											String sOldAwardApplied = eleAward_temp.getAttribute("AwardApplied");
											if(YFCCommon.isVoid(sOldAwardApplied)){
												sOldAwardApplied="";
											}
											String sOldDescription = eleAward_temp.getAttribute("Description");
											if(YFCCommon.isVoid(sOldDescription)){
												sOldDescription="";
											}
											String sOldPromotionId = eleAward_temp.getAttribute("PromotionId");
											if(YFCCommon.isVoid(sOldPromotionId)){
												sOldPromotionId="";
											}

											String sCurrentAwardAmount = awardEle.getAttribute("AwardAmount");
											if(YFCCommon.isVoid(sCurrentAwardAmount)){
												sCurrentAwardAmount="";
											}
											String sCurrentAwardApplied = awardEle.getAttribute("AwardApplied");
											if(YFCCommon.isVoid(sCurrentAwardApplied)){
												sCurrentAwardApplied="";
											}
											String sCurrentDescription = awardEle.getAttribute("Description");
											if(YFCCommon.isVoid(sCurrentDescription)){
												sCurrentDescription="";
											}
											String sCurrentPromotionId = awardEle.getAttribute("PromotionId");
											if(YFCCommon.isVoid(sCurrentPromotionId)){
												sCurrentPromotionId="";
											}

											if(sOldAwardAmount.equalsIgnoreCase(sCurrentAwardAmount) && sOldAwardApplied.equalsIgnoreCase(sCurrentAwardApplied)
													&& sOldDescription.equalsIgnoreCase(sCurrentDescription) && sOldPromotionId.equalsIgnoreCase(sCurrentPromotionId)){
												awardsEle.removeChild(eleAward_temp);
												awardsEle.removeChild(awardEle);
												break;
											}
										}
									}
									logger.endTimer("KohlsPoCTVSPrepareUEResponsePsa.XMLDiff");

								  }
								}

							//Based on the Flag value Line Change Element is created.
							double dUnitPrice = Double.parseDouble(orderLineUnitPrice);
							
							if (isOfferApplied){
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.OFFER, lineChargeEle, Math.abs(offerChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(offerChargePerLineDbl);
							}
							if (isTldAmountApplied) {
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.TLD_AMOUNT_OFF, lineChargeEle, Math.abs(tldAmountChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(tldAmountChargePerLineDbl);
							}
							if (isTldPercentApplied) {
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.TLD_PERCENT_OFF, lineChargeEle, Math.abs(tldPercentChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(tldPercentChargePerLineDbl);
							}
							if (isLegacyDollarApplied) {
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.LEGACY_DOLLAR, lineChargeEle, Math.abs(legacyDollarChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(legacyDollarChargePerLineDbl);
							}
							if (isLegacyPercentApplied) {
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.LEGACY_PERCENT, lineChargeEle, Math.abs(legacyPercentChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(legacyPercentChargePerLineDbl);
							}
							if (isKohlsCashApplied) {
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.KOHLS_CASH_DESC, lineChargeEle, Math.abs(kohlsCashChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(kohlsCashChargePerLineDbl);
							}
							if(isSeniorCitizenApplied){
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								setLineChargeValues(KohlsPOCConstant.SENIOR_CITIZEN,lineChargeEle,Math.abs(seniorCitizenChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(seniorCitizenChargePerLineDbl);
							}
							// AssociateDiscount
							if(isAssociateDiscountApplied){
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								setLineChargeValues(KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE,lineChargeEle,Math.abs(associateDiscountChargePerLineDbl));
								dUnitPrice= dUnitPrice+Math.abs(associateDiscountChargePerLineDbl);
							}
							/*//Fix for defect 4086 - Start
							if (isQuickCreditApplied) {
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								this.setLineChargeValues(KohlsPOCConstant.TLD_PERCENT_OFF, lineChargeEle, Math.abs(tldPercentChargePerLineDbl));
							}
							//Fix for defect 4086 - End*/
							 XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE,twoDForm.format(dUnitPrice));
							}
						

						double clearanceAmtCalc = KohlsPOCConstant.ZERO_DBL;
						if(!(YFCCommon.isVoid(skuStatusCode)) && ("30".equals(skuStatusCode))){

							if(nonClearanceAmtDbl > orderLineUnitPriceDbl){
								clearanceAmtCalc = nonClearanceAmtDbl - orderLineUnitPriceDbl;
							}

						}
						totalDiscount = clearanceAmtCalc + offerChargePerLineDbl+ tldAmountChargePerLineDbl + tldPercentChargePerLineDbl
								+ legacyDollarChargePerLineDbl + legacyPercentChargePerLineDbl + kohlsCashChargePerLineDbl + associateDiscountChargePerLineDbl;
						totalSaving = totalSaving + totalDiscount ;

						NodeList awardList = orderLineEle.getElementsByTagName("Award");

						Map<String,Element> voidResetAwardsMap = orderPromoObj.getvoidResetAwardMap();
						Map<String,Element> promoDiscMap = orderPromoObj.getPromoDiscAwardMap();
						Map<String,Element> manualLIDMap = orderPromoObj.getLIDAwardMap();

						logger.debug("voidResetAwardsMap size is"+voidResetAwardsMap.size());
						logger.debug("promoDiscMap size is"+promoDiscMap.size());
						logger.debug("manualLIDMap size is"+manualLIDMap.size());

						logger.debug("Starting setting of awards & line charges for existing promotions");
						double dUnitPrice = KohlsPOCConstant.ZERO_DBL;
						String strUnitPrice = XMLUtil.getAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE);
						if(!YFCCommon.isVoid(strUnitPrice)){
							dUnitPrice = Double.parseDouble(strUnitPrice);
						}else{
						 dUnitPrice = Double.parseDouble(orderLineUnitPrice);
						}
						for(int iterator=0 ; iterator<awardList.getLength(); iterator++){

							Element awardElement = (Element) awardList.item(iterator);
							String awardId = XMLUtil.getAttribute(awardElement, "AwardId");

							if(voidResetAwardsMap.containsKey(awardId)){
								logger.debug(awardId +"presents in voidResetAwardsMap");
								Element promotion = voidResetAwardsMap.get(awardId);
								String promotionType = XMLUtil.getAttribute(promotion, "PromotionType");

								if(KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase( promotionType )){
	                           promotionType =KohlsPOCConstant.TLD_AMOUNT_OFF;
	                     }
								//changes for 3129--Start
                                if(KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase( promotionType )){
                                       promotionType =KohlsPOCConstant.KOHLS_CASH_DESC;
                                      }
                              //changes for 3129--End
                                if(KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase( promotionType )){
                                    promotionType =KohlsPOCConstant.LID_PERCENT_OFF;
                                }   

                        else if(KohlsPOCConstant.LEGACY_COUPON.equalsIgnoreCase( promotionType )){
                           Element extnPromoEle = XMLUtil.getChildElement( promotion, "Extn" );
                           Element extnKohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnPromoEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));

                           NodeList dataEleList = extnKohlsCashResposneEle.getElementsByTagName(KohlsPOCConstant.E_DATA);
                           String legacyDollar = KohlsPOCConstant.BLANK;
                           String legacyPercent = KohlsPOCConstant.BLANK ;

                           if(!YFCCommon.isVoid(dataEleList) && dataEleList.getLength() > KohlsPOCConstant.ZERO_INT){
                              Element dataElement = (Element)dataEleList.item(KohlsPOCConstant.ZERO_INT);
                              legacyDollar = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
                              legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
                           }

                           if(!YFCCommon.isVoid(legacyDollar)){
                              promotionType = KohlsPOCConstant.LEGACY_DOLLAR;
                           }
                       /*    if(!YFCCommon.isVoid(legacyPercent)){
                              promotionType = KohlsPOCConstant.LEGACY_PERCENT;
                           }        */

                        }
                               
								//Changes for Defect 3553 --Start
								XMLUtil.setAttribute(awardElement, "Action"," ");
								String awardAmount = XMLUtil.getAttribute(awardElement, "AwardAmount");
								Element extnAwardEle = XMLUtil.getChildElement(awardElement, "Extn");
								String sExtnNetDelta=extnAwardEle.getAttribute("ExtnNetDelta");
								if(promotionType.equalsIgnoreCase(KohlsPOCConstant.OFFER))
							{
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								setLineChargeValues(promotionType,lineChargeEle,Math.abs(Float.parseFloat(sExtnNetDelta)));
								dUnitPrice = dUnitPrice+Math.abs(Float.parseFloat(sExtnNetDelta));
							}
							else
							{
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								setLineChargeValues(promotionType,lineChargeEle,Math.abs(Float.parseFloat(awardAmount)));
								dUnitPrice = dUnitPrice+Math.abs(Float.parseFloat(awardAmount));
							}
								XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE,twoDForm.format(dUnitPrice));
							}
							else if(promoDiscMap.containsKey(awardId)){
								//CPE -9919 Commented for recalculation from TVS only in PSA and not from original sales
								
								logger.debug(awardId +"presents in promoDiscMap");

								String promotionType = KohlsPOCConstant.SKU;
								XMLUtil.setAttribute(awardElement, "Action"," ");
								//String awardAmount = XMLUtil.getAttribute(awardElement, "AwardAmount");
								Element extnAwardEle = XMLUtil.getChildElement(awardElement, "Extn");
								//PST-3220 - Start
								String sExtnNetDelta=extnAwardEle.getAttribute("ExtnNetDelta");
								String sExtnTaxDelta=extnAwardEle.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DELTA);
								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								//PST-4514 - Start
									if(!YFCCommon.isVoid(sExtnTaxDelta)){
										setLineChargeValues(promotionType,lineChargeEle,Math.abs(Float.parseFloat(sExtnTaxDelta)));
										dUnitPrice = dUnitPrice+Math.abs(Float.parseFloat(sExtnTaxDelta));
										}else{
											setLineChargeValues(promotionType,lineChargeEle,Math.abs(Float.parseFloat(sExtnNetDelta)));
											dUnitPrice = dUnitPrice+Math.abs(Float.parseFloat(sExtnNetDelta));
										}
									XMLUtil.setAttribute(linePrcEle, KohlsPOCConstant.A_UNIT_PRICE,twoDForm.format(dUnitPrice));
								//PST-4514 - End
								//PST-3220 - End
							}
							
							//Changes for Defect 3553 --End
							//Commenting for 4255 - Start
							/*else if(manualLIDMap.containsKey(awardId)){
								logger.debug(awardId +"presents in manualLIDMap");

								Element awardExtn = XMLUtil.getChildElement(awardElement,"Extn");
								String promotionCategory = getPrecedenceLIDCategory(awardExtn);

								XMLUtil.setAttribute(awardElement, "Action"," ");
								String awardAmount = XMLUtil.getAttribute(awardElement, "AwardAmount");

								if (promotionCategory=="PRICE_OVERRIDE" && Float.parseFloat(awardAmount)>0.0)
								{
									promotionCategory="PRICE_OVERRIDE_INCREASED";
								}

								Element lineChargeEle = XMLUtil.createChild(lineChargesEle, KohlsPOCConstant.ELEM_LINE_CHARGE);
								setLineChargeValues(promotionCategory,lineChargeEle,Math.abs(Float.parseFloat(awardAmount)));
							}*/
							//Commenting for 4255 - End

						}
						logger.debug("End of setting of awards & line charges for existing promotions");
						this.groupLineCharges(orderLineEle);
						KohlsPoCPnPUtil.addTaxableAmountInTempElement(orderLineEle);

					}
				}
			}

			Element extnOrder = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
			XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TOTAL_SAVINGS, String.valueOf(totalSaving));

			KohlsPoCTVSGenerateExtnPromoSequence.generateExtnPromoSequencePSA(orderEle, tvsResponseEle);
			logger.endTimer("KohlsPoCTVSPrepareUEResponse.updateUeDocumentFromTVSResponsePSA");
	}

	/**
	 * getPrecedenceLIDCategory() returns what kind of precedence available in award ExtnSalesHubData
	 * @param awardExtnEle
	 * @return
	 */
	private String getPrecedenceLIDCategory(Element awardExtnEle){

		String promotionType = KohlsPOCConstant.BLANK;
		String precedence = KohlsPOCConstant.BLANK;

		String salesHubClob = XMLUtil.getAttribute(awardExtnEle, KohlsPOCConstant.A_EXTN_SALES_HUB_DATA);

		if(!YFCCommon.isVoid(salesHubClob)){
			Element salesHubDataEle = null;
			try {
				salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
			} catch (ParserConfigurationException e) {
				logger.error("ParserConfigurationException at KohlsPoCTVSCaller.getPrecedenceLIDCategory");
			} catch (SAXException e) {
				logger.error("SAXException at KohlsPoCTVSCaller.getPrecedenceLIDCategory");
			} catch (IOException e) {
				logger.error("IOException at KohlsPoCTVSCaller.getPrecedenceLIDCategory");
			}

			if(!YFCCommon.isVoid(salesHubDataEle)){
				precedence = XMLUtil.getAttribute(salesHubDataEle, KohlsPOCConstant.A_PRECEDENCE);
			}
		}

		if(!YFCCommon.isVoid(precedence)){
			if(precedence.equalsIgnoreCase(KohlsPOCConstant.EIGHT)){
				promotionType = KohlsPOCConstant.PRICE_OVERRIDE;
			}
			else if(precedence.equalsIgnoreCase(KohlsPOCConstant.NINE)){
				promotionType = KohlsPOCConstant.LID_AMOUNT_OFF;
			}
			else if(precedence.equalsIgnoreCase(KohlsPOCConstant.TEN)){
				promotionType = KohlsPOCConstant.LID_PERCENT_OFF;
			}
		}
		return promotionType;

	}

	/**
	    *
	    * @param orderLineEle
	    * @throws ParserConfigurationException
	    */
		@SuppressWarnings( "rawtypes" )
		//Updating for fix 4095, 4132, 4255
	   public static void groupLineCharges(Element orderLineEle){

	      Element originalLineCharges = XMLUtil.getChildElement( orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);
	      Element modifiedLineCharges = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);
	      XMLUtil.setAttribute( modifiedLineCharges, KohlsPOCConstant.A_RESET, XMLUtil.getAttribute(originalLineCharges, KohlsPOCConstant.A_RESET));

	      NodeList lineChargesList = orderLineEle.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);

	      Map<String,List<Element>> chargeCategoryMap = new HashMap<String,List<Element>>();

	      for(int i=0; i<lineChargesList.getLength();i++){
	    	  
	    	  Element lineCharge = ((Element)lineChargesList.item(i));
	         String ChargeCategory = XMLUtil.getAttribute( lineCharge, KohlsPOCConstant.ATTR_CHARGE_NAME );
	         if(chargeCategoryMap.containsKey(ChargeCategory)){
	            chargeCategoryMap.get( ChargeCategory ).add( lineCharge );
	         }
	         else{
	            List<Element> tempCategoryList = new ArrayList<Element>();
	            tempCategoryList.add( lineCharge );
	            chargeCategoryMap.put( ChargeCategory, tempCategoryList );
	         }
	      }

	      Iterator entries = chargeCategoryMap.entrySet().iterator();
	      while (entries.hasNext()) {
	          Map.Entry entry = (Map.Entry) entries.next();
	          List<Element> chargeCategoryList = (List<Element>)entry.getValue();
	          double chargeAmount =  KohlsPOCConstant.ZERO_DBL;;

	          for(Element chargeCatgoryElement : chargeCategoryList){
	             String tempChargeAmount = XMLUtil.getAttribute(chargeCatgoryElement, KohlsPOCConstant.A_CHARGE_PER_LINE);
	             chargeAmount+= Math.abs(Double.valueOf(tempChargeAmount));
	          }
	          Element tempLineCharge = (Element) chargeCategoryList.get(0).cloneNode(true);
	          XMLUtil.setAttribute( tempLineCharge, KohlsPOCConstant.A_CHARGE_PER_LINE, chargeAmount+"");
	          modifiedLineCharges.appendChild( tempLineCharge );
	      }
	      XMLUtil.removeChild( orderLineEle, originalLineCharges );
	   }

		private void consolidateLineTaxes(Element eleItem) {

			logger.beginTimer("KohlsPoCTVSPrepareUEResponse.consolidateLineTaxes");
			Element elelineTaxes = XMLUtil.createChild(eleItem, KohlsPOCConstant.ELEM_LINE_TAXES);
			List<Element> nlTax = XMLUtil.getElementsByTagName(eleItem, (KohlsPOCConstant.ELEM_LINE_TAX));
			double totalTaxPerLine = KohlsPOCConstant.ZERO_DBL;
			 double totalTaxRatePerLine = KohlsPOCConstant.ZERO_DBL;
			 double dBasisAmt = 0.00;
			 if(!YFCCommon.isVoid(nlTax))
			 {
				 for(Element eleTax : nlTax)
				 {
					 String sTax = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.SMALL_TAX);
					 String sTaxPercent = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT);
					 if(YFCCommon.isVoid(sTax)){
						sTax = "0.0";
					 }
					 if(YFCCommon.isVoid(sTaxPercent)){
						 sTaxPercent = "0.0";
					 }
					 totalTaxPerLine = totalTaxPerLine + Double.valueOf(sTax);
					 totalTaxRatePerLine = totalTaxRatePerLine + Double.valueOf(sTaxPercent);
					 eleItem.removeChild(eleTax);
					// CPE-213 persisting TaxBasis amt from TVS
					 String sTaxBasis = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.TAX_BASIS);
					 try {
                       if (!YFCCommon.isVoid(sTaxBasis) && Double.parseDouble(sTaxBasis) > dBasisAmt) {
                         dBasisAmt = Double.parseDouble(sTaxBasis);
                       }
                   }catch (Exception e) {
                     logger.error("Error occured while coputing taxBasis amt. Continuing transaction");
                   }
				 }
				 totalTaxPerLine = Math.round(totalTaxPerLine*1000.0)/1000.0;
				 totalTaxRatePerLine = Math.round(totalTaxRatePerLine*1000.0)/1000.0;
				 logger.debug("After Math   totalTaxPerLine "+totalTaxPerLine);
				 logger.debug("After Math totalTaxRatePerLine "+totalTaxRatePerLine);
				 DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
				 twoDForm.setRoundingMode(RoundingMode.CEILING);
				 Element eleTaxNew = XMLUtil.createChild(elelineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
				 XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX, twoDForm.format(totalTaxPerLine));
				 XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, totalTaxRatePerLine+"");
				 logger.debug("After rounding   totalTaxPerLine "+twoDForm.format(totalTaxPerLine));
				 logger.debug("After rounding   totalTaxRatePerLine "+totalTaxRatePerLine);
				 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
				 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
				 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX, twoDForm.format(totalTaxPerLine));
				 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, String.valueOf(totalTaxRatePerLine));
				 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
				 eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
				 dConsolidatedTax = totalTaxRatePerLine;
				 logger.debug ("Consolidated tax rate is:"+dConsolidatedTax);
				 if(dBasisAmt > 0) {
                   Element eleTaxExtn = XMLUtil.createChild(eleTaxNew, KohlsPOCConstant.E_EXTN);
                   eleTaxExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, new DecimalFormat("#0.00").format(dBasisAmt));
                 }
			 }
			 if (logger.isDebugEnabled()) {
					logger.debug("LineTax consolidated:: " + XMLUtil.getElementXMLString(eleItem));
			 }
			 
			 logger.endTimer("KohlsPoCTVSPrepareUEResponse.consolidateLineTaxes");
		}
}
