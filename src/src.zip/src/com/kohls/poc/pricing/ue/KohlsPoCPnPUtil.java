package com.kohls.poc.pricing.ue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoCPnPUtil.java Author : IBM Created : August 27 2013 Modified :
 * August 27 2013 Version : 0.1
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 27/08/2013 IBM First Cut.
 *****************************************************************************
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 * Pricing and Promotion Related util methods are present in this util class.
 * Basically these methods are used in more than one place.
 *
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCPnPUtil {

	private static YFCLogCategory logger;
	private static Document docExclusions, docExclusionsTvs;
	private static String sLAST_EXCLUSION_DFN_CHNG_TS = null;
	private static boolean sendExclusions ;

	static {
		logger = YFCLogCategory.instance(KohlsPoCPnPUtil.class.getName());
		try {
			docExclusions = XMLUtil.createDocument("Exclusions");
			docExclusionsTvs = XMLUtil.createDocument("exclusions");
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Element createElementFromXMLString(String xmlString) throws ParserConfigurationException,
			SAXException, IOException {
		logger.beginTimer("KohlsPoCPnPUtil.createElementFromXMLString");
		/*
		 * DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		 * DocumentBuilder db = dbf.newDocumentBuilder();
		 */
		InputSource is = new InputSource(new ByteArrayInputStream(xmlString.getBytes()));
		is.setEncoding(KohlsPOCConstant.ENCODING_VALUE);
		/*
		 * Document doc = db.parse(is); Element elem = doc.getDocumentElement();
		 */

		logger.endTimer("KohlsPoCPnPUtil.createElementFromXMLString");

		return XMLUtil.getDocument(is).getDocumentElement();

	}

	/**
	 * Before making APE Request call the OrderLine, Award and LineCharge
	 * elements to be reset.
	 *
	 * @param orderLine
	 */
	public static void resetOrderLineDetails(Element orderLine) {
		logger.beginTimer("KohlsPoCPnPUtil.resetOrderLineDetails");

		List<Element> awardEleList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_AWARD);

		if (awardEleList.size() > KohlsPOCConstant.ZERO_INT) {

			for (Element awardEle : awardEleList) {
				
				String rebateResponse = KohlsPOCConstant.EMPTY;
				Element extnEle = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.E_EXTN);

				if (!YFCCommon.isVoid(extnEle)) {
					rebateResponse = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_REBATE_RESPONSE);
				}

				if (YFCCommon.isStringVoid(rebateResponse)) {
					XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.REMOVE);
				}
				
			}
		}

		Element lineChragesEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);

		if (null != lineChragesEle) {
			XMLUtil.removeChild(orderLine, lineChragesEle);
			Element newLineChargesEle = XMLUtil.createChild(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
			XMLUtil.setAttribute(newLineChargesEle, KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
		}
		logger.endTimer("KohlsPoCPnPUtil.resetOrderLineDetails");

	}
	//Fix for defect 1078 - Start, PST-4465 - Adding ExtnPSsaStatus parameter
	public static void resetOrderLineDetailsForTVS(Element orderLine, String sExtnPsaStatus) {
		logger.beginTimer("KohlsPoCPnPUtil.resetOrderLineDetailsForTVS");

		List<Element> awardEleList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_AWARD);

		if (awardEleList.size() > KohlsPOCConstant.ZERO_INT) {
			//PST-4465 - Start
			String awardpromotionId = "";
			String awardAmount = "";
			for (Element awardEle : awardEleList) {
				awardpromotionId = XMLUtil.getAttribute(awardEle, KohlsPOCConstant.PROMOTIONID);
				Element awardExtn = XMLUtil.getChildElement(awardEle, KohlsPOCConstant.A_EXTN);
				awardAmount = XMLUtil.getAttribute(awardExtn, "ExtnNetDelta");
				if(!(("760Q_00001".equalsIgnoreCase(awardpromotionId) || 
						"760K_00001".equalsIgnoreCase(awardpromotionId)) && (KohlsPOCConstant.PSA_VOIDED_STATUS.equalsIgnoreCase(sExtnPsaStatus) || 
						    KohlsPOCConstant.PSA_POSTVOIDED_STATUS.equalsIgnoreCase(sExtnPsaStatus)) 
				    && YFCCommon.isVoid(awardAmount))){
					XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.REMOVE);
				}
				//PST-4465 - End
				
			}
		}

		Element lineChragesEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);

		if (null != lineChragesEle) {
			//PST-4465 - Start
			if(!YFCCommon.isVoid(sExtnPsaStatus) && (sExtnPsaStatus.equalsIgnoreCase(KohlsPOCConstant.PSA_VOIDED_STATUS) || 
					sExtnPsaStatus.equalsIgnoreCase(KohlsPOCConstant.PSA_POSTVOIDED_STATUS))){
				List<Element> lineChargesEle = XMLUtil.getElementsByTagName(orderLine,KohlsPOCConstant.ELEM_LINE_CHARGE);
				Iterator<Element> iter = lineChargesEle.iterator();
				//Element eleLineCharges = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
				logger.debug("The line charges before removing PSA Void scenario : "+ XMLUtil.getElementXMLString(lineChragesEle));
				((Element)orderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGES).item(0)).setAttribute("Reset", "Y");
				if (lineChargesEle.size() > KohlsPOCConstant.ZERO_INT) {
					logger.debug("The size of lineCharges : " + lineChargesEle.size());
					while (iter.hasNext()) {
						Element eleLineCharge = iter.next();
						Element eleLineChargesExtn = XMLUtil.getChildElement(eleLineCharge, "Extn");
						String sDiscountCode = XMLUtil.getAttribute(eleLineChargesExtn, "ExtnDiscountReasonCode") + 
								XMLUtil.getAttribute(eleLineChargesExtn, "ExtnDiscountTypeCode");
						if(YFCCommon.isVoid(sDiscountCode)){sDiscountCode="Null";}
						if (!(sDiscountCode.equalsIgnoreCase("760Q")  
										|| sDiscountCode.equalsIgnoreCase("760K"))) {
							lineChragesEle.removeChild(eleLineCharge);
						}
					}
					logger.debug("The line charges after removing PSA Void scenario : "+ XMLUtil.getElementXMLString(XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES)));

				}
			}else{
				XMLUtil.removeChild(orderLine, lineChragesEle);
				Element newLineChargesEle = XMLUtil.createChild(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
				XMLUtil.setAttribute(newLineChargesEle, KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
			}
			//PST-4465 - End
		}
		logger.endTimer("KohlsPoCPnPUtil.resetOrderLineDetails");

	}

	/**
	 * resetOrderLineDetailsForTVSPSA to reset Awards elements and line charges
	 * @param orderLine
	 */
	public static void resetOrderLineDetailsForTVSPSA(Element orderLine, Element tempOrderEle,KohlsPoCTVSOrderPromotionsCaller orderPromoObj) {
		logger.beginTimer("KohlsPoCPnPUtil.resetOrderLineDetailsForTVSPSA");

		List<Element> awardEleList = XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.E_AWARD);
		
		Element itemElement = XMLUtil.getChildElement(orderLine, "Item");
		String primeLineNo = XMLUtil.getAttribute(orderLine, "PrimeLineNo");
		
		String itemId = XMLUtil.getAttribute(itemElement, "ItemID");
		
		String discountType = KohlsPOCConstant.BLANK;
		
		if (awardEleList.size() > KohlsPOCConstant.ZERO_INT) {
			
			//for each award set the action as remove
			//if award contains the category for baking price add the award to voidResetAwardMap
			//if award contains the category for Promo Discount or Manual LID add the award to voidResetAwardMap
			
			for (Element awardEle : awardEleList) {
				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.REMOVE);
				
				//TBD below for psa
				String awardId = XMLUtil.getAttribute(awardEle, "AwardId");
				String awardpromotionId = XMLUtil.getAttribute(awardEle, "PromotionId");
				Element awardExtnEle = XMLUtil.getChildElement(awardEle, "Extn");
				//Fix for PR-449 - Start
				String strAwardDescription = XMLUtil.getAttribute(awardEle, "Description");
				String strAwardAmout = XMLUtil.getAttribute(awardEle, "AwardAmount");
				if(YFCCommon.isVoid(XMLUtil.getAttribute(awardExtnEle, "ExtnNetDelta"))){
				XMLUtil.setAttribute(awardExtnEle, "ExtnNetDelta", strAwardAmout);
				}
				if(YFCCommon.isVoid(XMLUtil.getAttribute(awardExtnEle, "ExtnRetrnDelta"))){
				XMLUtil.setAttribute(awardExtnEle, "ExtnRetrnDelta", 
						String.valueOf(Math.abs(Double.valueOf(strAwardAmout))));
				}
				//Fix for PR-449 - End
				int awardSequence = 0;
				
				String extnAwardSequence = XMLUtil.getAttribute(awardExtnEle, "ExtnAwardSequence");
				
				if(null!=extnAwardSequence && !YFCCommon.isVoid(extnAwardSequence)){
					int tmpSequence = Integer.parseInt(extnAwardSequence);
					if(tmpSequence > awardSequence){
						awardSequence = tmpSequence;
					}
				}
				
				Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
				List <Element> orderPromotionList = XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
				Element promotionsEle1 = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_PROMOTIONS);
				List <Element> orderPromotionList1 = XMLUtil.getElementsByTagName(promotionsEle1, KohlsPOCConstant.E_PROMOTION);
				String promoId;
				String promoId1;
				String extnPromotionFlag = null;
				String isPSAPromotion = null;
				
				//if award promotion id is not there it may be
				//Fix for defect 4095 - Start
				if(YFCCommon.isVoid(awardpromotionId)){
					//Fix for PR-449 - Start
					String awardType = validate_PromoDisc_ManualLID(awardExtnEle, strAwardDescription);
					//Fix for PR-449 - End
					
					if(awardType.equals("PROMO_DISCOUNT")){
						orderPromoObj.setPromoDiscAwardMap(awardId,awardEle);
					}
					if(awardType.equals("MANUAL_LID")){
						orderPromoObj.setLIDAwardMap(awardId,awardEle);
					}
				
				}
				if (!YFCCommon.isVoid(awardpromotionId))
				{
					for(Element promotion : orderPromotionList1){
						promoId1 = XMLUtil.getAttribute(promotion, "PromotionId");
						if (promoId1.equals(awardpromotionId)){
							
							orderPromoObj.setLIDAwardMap(awardId,awardEle);
							orderPromoObj.setvoidResetAwardMap(awardId, promotion);
						}
						}
						
				}
				//Fix for defect 4095 - End

				
				Map<String,Element> promoDiscMap = orderPromoObj.getPromoDiscAwardMap();
				Map<String,Element> lidDiscMap = orderPromoObj.getLIDAwardMap();
				
				if(!promoDiscMap.containsKey(awardId)&& !lidDiscMap.containsKey(awardId))
				{
				for(Element promotion : orderPromotionList){
					promoId = XMLUtil.getAttribute(promotion, "PromotionId");
					
					if(promoId.equalsIgnoreCase(awardpromotionId)){
						discountType = XMLUtil.getAttribute(promotion, KohlsPOCConstant.A_PROMOTION_TYPE);
						
						Element promotionExtn = XMLUtil.getChildElement(promotion, "Extn");
						extnPromotionFlag = XMLUtil.getAttribute(promotionExtn,"ExtnPromotionFlag"); // check whether offer applied or new
						isPSAPromotion = XMLUtil.getAttribute(promotionExtn,"ExtnIsPsaPromotion");	// check psa promotion applied or new
						
						if((extnPromotionFlag.equalsIgnoreCase(KohlsPOCConstant.BLANK) && isPSAPromotion.equalsIgnoreCase(KohlsPOCConstant.BLANK))
								|| (extnPromotionFlag.equalsIgnoreCase(KohlsPOCConstant.YES) && isPSAPromotion.equalsIgnoreCase(KohlsPOCConstant.YES))){
									continue;
						}
						
						boolean bakingPromotion = validatePromotionType_Baking(discountType,awardExtnEle);
						if(bakingPromotion == false){
							orderPromoObj.setvoidResetAwardMap(awardId, promotion);
						}
					}
				}
			  }
				orderPromoObj.setAwardSequenceMap(primeLineNo, awardSequence);	
			}
		}
		//Fix for defect 4255, 4132 - Start

		/*Element lineChragesEle = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);

		if (null != lineChragesEle) {
			XMLUtil.removeChild(orderLine, lineChragesEle);
			Element newLineChargesEle = XMLUtil.createChild(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
			XMLUtil.setAttribute(newLineChargesEle, KohlsPOCConstant.A_RESET, KohlsPOCConstant.YES);
		}*/
		List<Element> lineChargesEle = XMLUtil.getElementsByTagName(orderLine,KohlsPOCConstant.ELEM_LINE_CHARGE);
		Iterator<Element> iter = lineChargesEle.iterator();
		Element eleLineCharges = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
		logger.debug("The line charges before removing : "+ XMLUtil.getElementXMLString(eleLineCharges));
		((Element)orderLine.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGES).item(0)).setAttribute("Reset", "Y");
		if (lineChargesEle.size() > KohlsPOCConstant.ZERO_INT) {
			logger.debug("The size of lineCharges : " + lineChargesEle.size());
			while (iter.hasNext()) {
				Element eleLineCharge = iter.next();
				String chargeName = XMLUtil.getAttribute(eleLineCharge,	"ChargeName");
				if (!YFCCommon.isVoid(chargeName)
						&& !(chargeName.contains("PriceOverride")
								|| chargeName.contains("LID"))) {
					/*lineChrageEle.setAttribute("ChargeAmount", "0.00");
					lineChrageEle.setAttribute("ChargePerLine", "0.00");
					lineChrageEle.setAttribute("InvoicedChargeAmount", "0.00");
					lineChrageEle.removeAttribute("InvoicedChargePerLine");*/
				  eleLineCharges.removeChild(eleLineCharge);
					//logger.debug("The line charges outside resetting : "+ XMLUtil.getElementXMLString(XMLUtil.getChildElement(orderLine,KohlsPOCConstant.ELEM_LINE_CHARGES)));
				}
			}
			logger.debug("The line charges after removing : "+ XMLUtil.getElementXMLString(XMLUtil.getChildElement(orderLine, KohlsPOCConstant.ELEM_LINE_CHARGES)));

		}
		//Fix for defect 4255, 4132 - End
		logger.endTimer("KohlsPoCPnPUtil.resetOrderLineDetailsForTVSPSA");
	}
	

	/**
	 * validateNonPriceBakingDiscountTypes to decide whether the promotion type is bake price category or not
	 * @param discountType
	 * @param awardExtnEle
	 * @return true if promotion type is not a bake price type
	 * @return false if promotion type is bake price type
	 */
	private static boolean validatePromotionType_Baking(String discountType,Element awardExtnEle){
		
		String precedence = KohlsPOCConstant.BLANK;
		
		if(discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER) || discountType.equalsIgnoreCase(KohlsPOCConstant.LEGACY_COUPON)){
			String salesHubClob = XMLUtil.getAttribute(awardExtnEle, "ExtnSalesHubData");
			
			if(!YFCCommon.isVoid(salesHubClob)){
				Element salesHubDataEle = null;
				try {
					salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
				} catch (ParserConfigurationException e) {
					logger.error("ParserConfigurationException at KohlsPoCTVSCaller.validatePromotionType_Baking");
				} catch (SAXException e) {
					logger.error("SAXException at KohlsPoCTVSCaller.validatePromotionType_Baking");
				} catch (IOException e) {
					logger.error("IOException at KohlsPoCTVSCaller.validatePromotionType_Baking");
				}
				
				if(!YFCCommon.isVoid(salesHubDataEle)){
					precedence = XMLUtil.getAttribute(salesHubDataEle, "Precedence");
				}
			}
		}
		String sDiscountTypeReason = "";
		if(!YFCCommon.isVoid(XMLUtil.getAttribute(awardExtnEle,"ExtnDiscountReasonCode")) && !YFCCommon.isVoid(XMLUtil.getAttribute(awardExtnEle,"ExtnDiscountTypeCode"))) {
			sDiscountTypeReason = XMLUtil.getAttribute(awardExtnEle,"ExtnDiscountReasonCode")+XMLUtil.getAttribute(awardExtnEle,"ExtnDiscountTypeCode");
		}
		
		if(!YFCCommon.isVoid(discountType)){
			if(discountType.equalsIgnoreCase(KohlsPOCConstant.PERCENT_OFF)||
			   			discountType.equalsIgnoreCase(KohlsPOCConstant.SENIOR_DISCOUNT) ||
			   				(discountType.equalsIgnoreCase(KohlsPOCConstant.LEGACY_COUPON)&& precedence.equalsIgnoreCase("40"))||
									discountType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)||
										(discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER) && precedence.equalsIgnoreCase("38"))||
								 			(discountType.equalsIgnoreCase(KohlsPOCConstant.OFFER) && precedence.equalsIgnoreCase("39")) ||
								 			(sDiscountTypeReason.equalsIgnoreCase("760Q")) || (sDiscountTypeReason.equalsIgnoreCase("761I"))
								 			|| KohlsPOCConstant.TAXWARE_FEE.equalsIgnoreCase(discountType)) 
												{
														return true; //true reflects the discount is the category to bake the price
												}
											}
										
				return false; //false reflects the discount is not under baking price category 
	}


	
	
	/**
	 * 
	 * @param awardExtnEle
	 * @return
	 */
	//Fix for PR-449 - Start -  Deciding PromoType based on Award description
		private static String validate_PromoDisc_ManualLID(Element awardExtnEle, String strAwardDescription){
		String precedence = KohlsPOCConstant.BLANK;
		
		String result = KohlsPOCConstant.BLANK;
		
		String salesHubClob = XMLUtil.getAttribute(awardExtnEle, "ExtnSalesHubData");
		
		if(!YFCCommon.isVoid(salesHubClob)){
			Element salesHubDataEle = null;
			try {
				salesHubDataEle = KohlsPoCPnPUtil.createElementFromXMLString(salesHubClob);
			} catch (ParserConfigurationException e) {
				logger.error("ParserConfigurationException at KohlsPoCTVSCaller.validate_PromoDisc_ManualLID");
			} catch (SAXException e) {
				logger.error("SAXException at KohlsPoCTVSCaller.validate_PromoDisc_ManualLID");
			} catch (IOException e) {
				logger.error("IOException at KohlsPoCTVSCaller.validate_PromoDisc_ManualLID");
			}
			
			if(!YFCCommon.isVoid(salesHubDataEle)){
				precedence = XMLUtil.getAttribute(salesHubDataEle, "Precedence");
			}
		
		List<String> promoDisc_List = get_PromoDisc_PrecedenceList();
		List<String> ManualLID_List = get_ManualLID_PrecedenceList();
		
		if(promoDisc_List.contains(precedence)){
			result = "PROMO_DISCOUNT";
		}
		else if(ManualLID_List.contains(precedence)){
			result = "MANUAL_LID";
		}
			}else if(!YFCCommon.isVoid(strAwardDescription)){
				if(strAwardDescription.toLowerCase().contains("offer") || 
						strAwardDescription.toLowerCase().contains("Markdown")){
					result = "MANUAL_LID";
				}else {
					List<String> AwardDesc_List = get_Award_DescriptionList();
					if(AwardDesc_List.contains(strAwardDescription)){
						result = "PROMO_DISCOUNT";
					}
				}
			}
		
		return result; //false reflects the precedence category is not promo discount or Manual LID 
		
	}
		
		private static List<String> get_Award_DescriptionList(){
			List<String> award_Desc_List = new ArrayList<String>();

			award_Desc_List.add(KohlsPOCConstant.STR_BOGO_DISCOUNT_DESC);
			award_Desc_List.add(KohlsPOCConstant.STR_ADDITIONAL_PROMO_DESC);

			return award_Desc_List;
		}
		//Fix for PR-449 - End
		

	private static List<String> get_PromoDisc_PrecedenceList(){
		List<String> precedence_Exclusion_List = new ArrayList<String>();
		
		precedence_Exclusion_List.add(KohlsPOCConstant.TWO);
		precedence_Exclusion_List.add(KohlsPOCConstant.THREE);
		precedence_Exclusion_List.add(KohlsPOCConstant.FIVE);
		precedence_Exclusion_List.add(KohlsPOCConstant.SIX);
		precedence_Exclusion_List.add(KohlsPOCConstant.SEVEN);
		precedence_Exclusion_List.add(KohlsPOCConstant.FIFTEEN);
		precedence_Exclusion_List.add(KohlsPOCConstant.SIXTEEN);
		precedence_Exclusion_List.add(KohlsPOCConstant.TWENTY_THREE);
		precedence_Exclusion_List.add(KohlsPOCConstant.TWENTY_FOUR);
		precedence_Exclusion_List.add(KohlsPOCConstant.TWENTY_FIVE);
		
		return precedence_Exclusion_List;
	}

	private static List<String> get_ManualLID_PrecedenceList(){
		List<String> precedence_Exclusion_List = new ArrayList<String>();

		precedence_Exclusion_List.add(KohlsPOCConstant.EIGHT);
		precedence_Exclusion_List.add(KohlsPOCConstant.NINE);
		precedence_Exclusion_List.add(KohlsPOCConstant.TEN);
		
		return precedence_Exclusion_List;
	}
	//Fix for defect 1078 - End
	/**
	 * This method returns the combination of StartDate and StartTime
	 *
	 * @param startDate
	 * @param startTime
	 * @return
	 * @throws ParseException
	 */
	public static String combinedDateAndTime(String startDate, String startTime) throws ParseException {
		logger.beginTimer("KohlsPoCPnPUtil.combinedDateAndTime");

		SimpleDateFormat dateFormater = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YYYY);
		SimpleDateFormat timeFormater = new SimpleDateFormat(KohlsPOCConstant.HH_MM_SS_SSS);
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YYYY_HH_MM_SS_SSS);

		Date actualStartDate = dateFormater.parse(startDate);
		Date actualStartTime = timeFormater.parse(startTime);

		Calendar cal = Calendar.getInstance();
		Calendar calendarA = Calendar.getInstance();
		calendarA.setTime(actualStartDate);

		Calendar calendarB = Calendar.getInstance();
		calendarB.setTime(actualStartTime);

		calendarA.set(Calendar.HOUR_OF_DAY, calendarB.get(Calendar.HOUR_OF_DAY));
		calendarA.set(Calendar.MINUTE, calendarB.get(Calendar.MINUTE));
		calendarA.set(Calendar.SECOND, calendarB.get(Calendar.SECOND));
		calendarA.set(Calendar.MILLISECOND, calendarB.get(Calendar.MILLISECOND));
		logger.endTimer("KohlsPoCPnPUtil.combinedDateAndTime");

		return sdf.format(calendarA.getTime());
	}

	/**
	 *
	 * Helping to insert the Guid in the passed parameter
	 *
	 * @param parentEle
	 * @param childName
	 * @param attributeName
	 * @return
	 */
	public static String insertGuidAttributeInELement(Element parentEle, String childName, String attributeName) {
		logger.beginTimer("KohlsPoCPnPUtil.insertGuidAttributeInELement");

		String uuidStr = UUID.randomUUID().toString();
		Element childElement = XMLUtil.getChildElement(parentEle, childName, Boolean.TRUE);
		XMLUtil.setAttribute(childElement, attributeName, uuidStr);
		logger.endTimer("KohlsPoCPnPUtil.insertGuidAttributeInELement");

		return uuidStr;
	}

	/**
	 * PLU Reponse is validated. If any ErrorCode and NotInFile value is present
	 * it throws the User Exit Exception
	 *
	 * @param pluResponseEle
	 * @throws YFSUserExitException
	 */
	public static void validatePluResponse(Element pluResponseEle) throws YFSException {
		logger.beginTimer("KohlsPoCPnPUtil.validatePluResponse");

		Element parametersEle = (Element) pluResponseEle.getElementsByTagName(KohlsPOCConstant.E_PARAMETERS).item(0);
		if (!YFCCommon.isVoid(parametersEle)) {
			String errorCodeStr = XMLUtil.getAttribute(parametersEle, KohlsPOCConstant.E_ERRORCODE);
			if (!YFCCommon.isStringVoid(errorCodeStr)) {

				if (KohlsPOCConstant.PLUINVALIDSKU.equalsIgnoreCase(errorCodeStr)) {
					yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUINVALIDSKU));
				}

				if (KohlsPOCConstant.PLUNOSKUDATA.equalsIgnoreCase(errorCodeStr)) {
					yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUNOSKUDATA));
				}

				if (KohlsPOCConstant.PLUNOREFDATA.equalsIgnoreCase(errorCodeStr)) {
					yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUNOREFDATA));
				}

				if (KohlsPOCConstant.PLUINVALIDOFFRID.equalsIgnoreCase(errorCodeStr)) {
					yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUINVALIDOFFRID));
				}

				if (KohlsPOCConstant.PLUINVALIDOFFRNBR.equalsIgnoreCase(errorCodeStr)) {
					yfsException(KohlsPOCConstant.PLUINVOFFRNBR,
							KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUINVOFFRNBR));
				}

				if (KohlsPOCConstant.PLUOFFRNOTFOUND.equalsIgnoreCase(errorCodeStr)) {
					yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUOFFRNOTFOUND));
				}

			}
		}

		Element exceptionEle = (Element) pluResponseEle.getElementsByTagName(KohlsPOCConstant.E_EXCEPTION).item(0);
		if (!YFCCommon.isVoid(exceptionEle)) {
			yfsException(KohlsPOCConstant.PLUSERVDOWN, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUSERVDOWN));
		}

		// Checking for SOAP fault
		if (pluResponseEle.getTagName().equalsIgnoreCase("Errors")) {

			String errorCode = XMLUtil.getChildElement(pluResponseEle, "Error").getAttribute("ErrorCode");
			String errorDescription = XMLUtil.getChildElement(pluResponseEle, "Error").getAttribute("ErrorDescription");

			yfsException(errorCode, errorDescription);

		}
		logger.endTimer("KohlsPoCPnPUtil.validatePluResponse");

	}

	/**
	 * APE Reponse is validated. If any ErrorCode and NotInFile value is present
	 * it throws the User Exit Exception
	 *
	 * @param apeResponseEle
	 * @throws YFSUserExitException
	 */
	public static void validateApeResponse(Element apeResponseEle) throws YFSUserExitException {
		logger.beginTimer("KohlsPoCPnPUtil.validateApeResponse");

		logger.debug("Inside validateApeResponse for SOAP Fault");
		// Checking for SOAP fault
		if (apeResponseEle.getTagName().equalsIgnoreCase("Errors")) {

			String errorCode = XMLUtil.getChildElement(apeResponseEle, "Error").getAttribute("ErrorCode");
			String errorDescription = XMLUtil.getChildElement(apeResponseEle, "Error").getAttribute("ErrorDescription");

			yfsException(errorCode, errorDescription);

		}
		logger.endTimer("KohlsPoCPnPUtil.validateApeResponse");

	}

	/**
	 *
	 * @param errorCode
	 * @param errorDescription
	 * @throws YFSUserExitException
	 */
	public static void yfsException(String errorCode, String errorDescription) throws YFSException {
		logger.beginTimer("KohlsPoCPnPUtil.yfsException");

		YFSException yfsExcep = new YFSException();

		yfsExcep.setErrorCode(errorCode);

		if (!YFCCommon.isStringVoid(errorDescription)) {
			yfsExcep.setErrorDescription(errorDescription);
		}
		logger.endTimer("KohlsPoCPnPUtil.yfsException");

		throw yfsExcep;
	}

	/**
	 * Helping to remove the Temp Element(s) in the OrderDocument.
	 *
	 * @param elementsHM
	 * @throws IOException
	 * @throws SAXException
	 * @throws ParserConfigurationException
	 */
	public static void removeTempElement(Map<String, Element> elementsHM) throws IOException, SAXException,
			ParserConfigurationException {
		logger.beginTimer("KohlsPoCPnPUtil.removeTempElement");

		Element resposneEle = null;
		String promotionResponseString = null;
		String pluPromoResponseString = null;
		for (Map.Entry<String, Element> entry : elementsHM.entrySet()) {
			Element element = entry.getValue();
			removeElement(element, KohlsPOCConstant.E_TEMP);
			Element extnEle = XMLUtil.getChildElement(element, KohlsPOCConstant.E_EXTN);
		//Null Check for associate discount
		if(!YFCCommon.isVoid(extnEle)){
			promotionResponseString = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE);
			pluPromoResponseString = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE);
		}
			if (!YFCCommon.isStringVoid(promotionResponseString)) {
				resposneEle = KohlsPoCPnPUtil.createElementFromXMLString(promotionResponseString);
				List<Element> tempEleList = XMLUtil.getElementsByTagName(resposneEle, KohlsPOCConstant.E_TEMP);
				if (tempEleList.size() > KohlsPOCConstant.ZERO_INT) {
					for (Element tempEle : tempEleList) {
						Element parentEle = (Element) tempEle.getParentNode();
						removeElement(parentEle, KohlsPOCConstant.E_TEMP);
					}
				}
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE,
						XMLUtil.getElementXMLString(resposneEle));
			}

			if (!YFCCommon.isStringVoid(pluPromoResponseString)) {
				resposneEle = KohlsPoCPnPUtil.createElementFromXMLString(pluPromoResponseString);
				List<Element> tempEleList = XMLUtil.getElementsByTagName(resposneEle, KohlsPOCConstant.E_TEMP);
				if (tempEleList.size() > KohlsPOCConstant.ZERO_INT) {
					for (Element tempEle : tempEleList) {
						Element parentEle = (Element) tempEle.getParentNode();
						removeElement(parentEle, KohlsPOCConstant.E_TEMP);
					}
				}
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE,
						XMLUtil.getElementXMLString(resposneEle));
			}
		}
		logger.endTimer("KohlsPoCPnPUtil.removeTempElement");

	}

	/**
	 * Helping to remove the ChildElement
	 *
	 * @param parentEle
	 * @param childElementName
	 */
	public static void removeElement(Element parentEle, String childElementName) {
		logger.beginTimer("KohlsPoCPnPUtil.removeElement");
		Element childElement = XMLUtil.getChildElement(parentEle, childElementName);

		if (null != childElement) {
			XMLUtil.removeChild(parentEle, childElement);
		}
		logger.endTimer("KohlsPoCPnPUtil.removeElement");
	}

	/**
	 * Using to get current date in the String format
	 *
	 * @return
	 */
	public static String getCurrentDateString() {
		logger.beginTimer("KohlsPoCPnPUtil.getCurrentDateString");
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.DATE);
		Calendar cal = Calendar.getInstance();
		String sFormattedTime = sdf.format(cal.getTime());
		logger.endTimer("KohlsPoCPnPUtil.getCurrentDateString");
		return sFormattedTime;
	}

	/**
	 * Get the first digit from the givent string
	 *
	 * @param promotionIdFromGravity
	 * @return
	 */
	public static String getPromotionIdForAPE(String promotionIdFromGravity) {
		logger.beginTimer("KohlsPoCPnPUtil.getPromotionIdForAPE");
		//Manoj 0512 : added for defect 4238 - Begin
		if (YFCCommon.isVoid(promotionIdFromGravity)) {
			promotionIdFromGravity = "00000";

		}
		//Manoj 0512 : added for defect 4238 - End
		
		//CPE 2452 0512 : added for SUPC - Begin
		if(isSUPC(promotionIdFromGravity)){
			return promotionIdFromGravity;
		}
		//CPE 2452 0512 : added for SUPC - End
		
		String sPromoID = new StringBuffer(promotionIdFromGravity).substring(KohlsPOCConstant.ZERO_INT, KohlsPOCConstant.FIVE_INT);
		
		logger.endTimer("KohlsPoCPnPUtil.getPromotionIdForAPE");
		return sPromoID;
	}

	public static String convertDate(String toConvertDate, String toDateFormat) throws ParseException {
		logger.beginTimer("KohlsPoCPnPUtil.convertDate");
		if (YFCCommon.isStringVoid(toDateFormat)) {
			toDateFormat = KohlsPOCConstant.DATE;
		}
		DateFormat fromFormat = new SimpleDateFormat(toDateFormat);
		fromFormat.setLenient(false);
		DateFormat toFormat = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YY);
		toFormat.setLenient(false);
		Date fromDate = fromFormat.parse(toConvertDate);
		String sFormattedDate = toFormat.format(fromDate);
		logger.endTimer("KohlsPoCPnPUtil.convertDate");
		return sFormattedDate;
	}

	/**
	 * Converting Date to the 'MMddyy' format
	 *
	 * @param toConvertDate
	 * @return
	 * @throws ParseException
	 */
	public static String convertDate(String toConvertDate) throws ParseException {
		logger.beginTimer("KohlsPoCPnPUtil.toConvertDate");
		String sConvertedDate = convertDate(toConvertDate, null);
		logger.endTimer("KohlsPoCPnPUtil.toConvertDate");
		return sConvertedDate;
	}

	/**
	 * Used to convert the given value into negative
	 *
	 * @param value
	 * @return The negative value of the given number or "" if the value is not valid
	 */
	public static String convertToNegative(String value) {
        logger.beginTimer("KohlsPoCPnPUtil.convertToNegative");
        // Fix for NumberFormatException (JIRA: PST-39) - START
        double dvalue = 0d;

        try {
            if (value != null) {
                dvalue = Double.parseDouble(value);
                if (dvalue <= 0) {
                    logger.debug("Value returned without negation = " + value);
                    value = String.valueOf(dvalue);
                } else {
                    logger.debug("Value returned with negation = " + value);
                    value = String.valueOf(-1 * dvalue);
                }
            } else {
            	logger.debug("Value is null. Returning 0.00 as output.");
            	value = "0.00";
            }

        } catch (NumberFormatException nfe) {
        	logger.error("Error converting to numeric " + value, nfe);
            value = "0.00";
        }
        // Fix for NumberFormatException (JIRA: PST-39) - END
        logger.endTimer("KohlsPoCPnPUtil.convertToNegative");
        return value;
    }

	/**
	 * Used to get the 'ExtnRequestDateTime' from the Order Element
	 *
	 * @param tempOrderEle
	 * @return
	 */
	public static String getExtnRequestTime(Element tempOrderEle) {
		logger.beginTimer("KohlsPoCPnPUtil.getExtnRequestTime");
		Element extnElement = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
		if (!YFCCommon.isVoid(extnElement)) {
			String sRequestTime = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.EXTN_REQUEST_DATE_TIME);
			logger.endTimer("KohlsPoCPnPUtil.getExtnRequestTime");
			return sRequestTime;
		}
		logger.endTimer("KohlsPoCPnPUtil.getExtnRequestTime");
		return null;
	}

	/**
	 * This method is used, while constructing the APE Request, Sequence number
	 * formation.
	 *
	 * @param promotionElement
	 * @param createtsList
	 * @return
	 */
	public static String getSequenceNumber(Element promotionElement, List createtsList) {
		logger.beginTimer("KohlsPoCPnPUtil.getSequenceNumber");
		String createts = XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_CREATE_TS);
		int sequence = KohlsPOCConstant.ZERO_INT;
		if (YFCCommon.isStringVoid(createts)) {
			sequence = createtsList.size() + KohlsPOCConstant.ONE_INT;
		} else {
			sequence = createtsList.indexOf(createts) + KohlsPOCConstant.ONE_INT;
		}
		logger.endTimer("KohlsPoCPnPUtil.getSequenceNumber");
		return String.valueOf(sequence);
	}

	/**
	 *
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param ruleId
	 * @return
	 * @throws Exception
	 */
	public static Document getRuleListForPOSCaller(YFSEnvironment yfsEnv, Element tempOrderEle, String ruleId)
			throws Exception {
		logger.beginTimer("KohlsPoCPnPUtil.getRuleListForPOSCaller");

		String organizationCode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_ENTERPRISE_CODE);

		Document rule = XMLUtil.createDocument(KohlsPOCConstant.E_RULE);
		Element ruleEle = rule.getDocumentElement();
		XMLUtil.setAttribute(ruleEle, KohlsPOCConstant.A_RULE_ID, ruleId);
		XMLUtil.setAttribute(ruleEle, KohlsPOCConstant.A_ORGANIZATION_CODE, organizationCode);
		XMLUtil.setAttribute(ruleEle, KohlsPOCConstant.RULE_ID_QRY_TYPE, KohlsPOCConstant.FLIKE);

		Document getRuleListForPOSAPIoutDoc = KOHLSBaseApi.invokeAPI(yfsEnv,
				KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, rule);
		logger.endTimer("KohlsPoCPnPUtil.getRuleListForPOSCaller");

		return getRuleListForPOSAPIoutDoc;
	}

	/**
	 *
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @return
	 * @throws Exception
	 */
	public static Document getTillStatusListForPOSCaller(YFSEnvironment yfsEnv, Element tempOrderEle) throws Exception {
		logger.beginTimer("KohlsPoCPnPUtil.getTillStatusListForPOSCaller");

		String terminalId = tempOrderEle.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
		Document tillStatus = XMLUtil.createDocument(KohlsPOCConstant.E_TILL_STATUS);
		Element tillStatusElement = tillStatus.getDocumentElement();
		XMLUtil.setAttribute(tillStatusElement, KohlsPOCConstant.A_ORGANIZATION_CODE,
				tempOrderEle.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE));
		XMLUtil.setAttribute(tillStatusElement, KohlsPOCConstant.A_TERMINAL_ID, terminalId);
		XMLUtil.setAttribute(tillStatusElement, KohlsPOCConstant.A_CURRENT_STATUS, KohlsPOCConstant.OPEN);
		XMLUtil.setAttribute(tillStatusElement, KohlsPOCConstant.A_CURRENT_TILL, KohlsPOCConstant.FLAG_Y );

		Document getTillStatusListForPOSoutDoc = KOHLSBaseApi.invokeAPI(yfsEnv,
				KohlsPOCConstant.API_GET_TILL_STATUS_LIST_FOR_POS, tillStatus);
		/* Added for PR-31 Defect -4244 START */
		if(!YFCCommon.isVoid(getTillStatusListForPOSoutDoc)){
			if( logger.isDebugEnabled() ){
				logger.debug("Input tempOrderElement :: "+XMLUtil.getElementXMLString(tempOrderEle));
			}
			Element elegetTillStatus = getTillStatusListForPOSoutDoc.getDocumentElement();
			String strTotalRecords = elegetTillStatus.getAttribute(KohlsConstant.A_TOTAL_NUMBER_RECORDS);
			if("0".equals(strTotalRecords)){
			String strTransactionNo= XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_TRANSACTION_NO);
			if(!YFCCommon.isVoid(strTransactionNo)){
				if( logger.isDebugEnabled() ){
					logger.debug("Trancastion No : "+strTransactionNo);
				}
				int intTransactionNo = strTransactionNo.length();
					if (intTransactionNo < 16) {
						YFSException yfsException = new YFSException();
						yfsException.setErrorCode("INVAILD_TRANSACTION_NO");
						yfsException.setErrorDescription("Invalid Transaction No");
						throw yfsException;

					}
					else{
						String strOrgCode = strTransactionNo.substring(12, 16);
						strOrgCode = Integer.toString(Integer.parseInt(strOrgCode));
						XMLUtil.setAttribute(tillStatusElement, KohlsPOCConstant.A_ORGANIZATION_CODE,
						strOrgCode);
						getTillStatusListForPOSoutDoc = KOHLSBaseApi.invokeAPI(yfsEnv,
						KohlsPOCConstant.API_GET_TILL_STATUS_LIST_FOR_POS, tillStatus);
					}
			}
			else{
				if( logger.isDebugEnabled() ){
					logger.debug("Trancastion No : "+strTransactionNo);
				}	
			}
			}
		}
		/* Added for PR-31 Defect -4244 END */
		logger.endTimer("KohlsPoCPnPUtil.getTillStatusListForPOSCaller");
		return getTillStatusListForPOSoutDoc;
	}

	public static String prepadStoreNoWithZeros(String storeNo) {
		logger.beginTimer("KohlsPoCPnPUtil.prepadStoreNoWithZeros");

		StringBuilder storeNoStringBuilder = new StringBuilder();

		for (int j = storeNo.length(); j < KohlsPOCConstant.SHIPNODE_LEN; j++) {
			storeNoStringBuilder.append(KohlsPOCConstant.ZERO);
		}
		logger.endTimer("KohlsPoCPnPUtil.prepadStoreNoWithZeros");

		return storeNoStringBuilder.append(storeNo).toString();
	}

	/**
	 * This Method is used to get the Tax Details from the ..../OrderLine/Temp
	 * Element and store the value in HashMap as TaxIndicator and
	 * TaxdetailListElement Pair.
	 *
	 * @param set
	 * @param taxDetailsMap
	 * @param tempEle
	 * @param taxIndicatorsEle
	 * @return
	 * @throws ParserConfigurationException
	 */
	public static String updateTaxDetails(Set<Double> set, Map<String, Element> taxDetailsMap, Element tempEle,
			Element taxIndicatorsEle) throws ParserConfigurationException {
		logger.beginTimer("KohlsPoCPnPUtil.updateTaxDetails");
		if(logger.isDebugEnabled()) {
		  logger.debug("tempEle is: "+XMLUtil.getElementXMLString(tempEle) );
		}

		double totalTaxRatePerLine = convertToDouble(XMLUtil.getAttribute(tempEle,
				KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE));
		logger.debug("updateTaxDetails ---- "+totalTaxRatePerLine);
		double totalTaxPerLine = convertToDouble(XMLUtil.getAttribute(tempEle, KohlsPOCConstant.A_LINE_TOTAL_TAX));
		logger.debug("updateTaxDetails ---- "+totalTaxPerLine);
		double taxableAmount = convertToDouble(XMLUtil.getAttribute(tempEle, KohlsPOCConstant.A_TAXABLE_AMOUNT));
		logger.debug("updateTaxDetails ---- "+taxableAmount);
		int index = getIndex(set, totalTaxRatePerLine);
		
		// int indexInt = getIndex(set, totalTaxRatePerLine);

		String extnTaxIndicator = KohlsPOCConstant.CONST_T + String.valueOf(index);
		logger.debug("updateTaxDetails ---- extnTaxIndicator is "+extnTaxIndicator);
		List<Double> taxDeatilList = new ArrayList<Double>();
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);

		if (taxDetailsMap.containsKey(extnTaxIndicator)) {
			Element taxDetailEle = taxDetailsMap.get(extnTaxIndicator);
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			logger.debug("updateTaxDEtails --- extnTaxIndicator exists in map "+XMLUtil.getElementXMLString(taxDetailEle));
			}
			//Performance improvement changes - End
			taxableAmount = convertToDouble(XMLUtil.getAttribute(taxDetailEle, KohlsPOCConstant.A_TOATL_AMOUNT))
					+ taxableAmount;
			totalTaxPerLine = convertToDouble(XMLUtil.getAttribute(taxDetailEle, KohlsPOCConstant.A_TAX_AMOUNT))
					+ totalTaxPerLine;
			XMLUtil.setAttribute(taxDetailEle, KohlsPOCConstant.A_TOATL_AMOUNT, twoDForm.format(taxableAmount));
			XMLUtil.setAttribute(taxDetailEle, KohlsPOCConstant.A_TAX_AMOUNT, twoDForm.format(totalTaxPerLine));

		} else {
			Element taxDetailEle = XMLUtil.createChild(taxIndicatorsEle, KohlsPOCConstant.E_TAX_DETAIL);
			XMLUtil.setAttribute(taxDetailEle, KohlsPOCConstant.A_TAX_INDICATOR, extnTaxIndicator);
			XMLUtil.setAttribute(taxDetailEle, KohlsPOCConstant.A_TOATL_AMOUNT, twoDForm.format(taxableAmount));
			//Fix for defect # 1789 - Removed twoDForm
			XMLUtil.setAttribute(taxDetailEle, KohlsPOCConstant.A_EFFECTIVE_TAX_RATE,
					totalTaxRatePerLine+"");
			XMLUtil.setAttribute(taxDetailEle, KohlsPOCConstant.A_TAX_AMOUNT, twoDForm.format(totalTaxPerLine));
			
			taxDetailsMap.put(extnTaxIndicator, taxDetailEle);
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			logger.debug("updateTaxDEtails --- extnTaxIndicator does not exists in map --- after loading the attributes"+XMLUtil.getElementXMLString(taxDetailEle));
			}
		//Performance improvement changes - End
			XMLUtil.appendChild(taxIndicatorsEle, taxDetailEle);
		}
		logger.endTimer("KohlsPoCPnPUtil.updateTaxDetails");

		return extnTaxIndicator;
	}

	/**
	 * Summation of TaxRate, TaxAmount and TotalTax stamped in
	 * .../OrderLine/Temp Element. It is used for Prepare the <TaxIndicators>
	 * CLOB xml.
	 *
	 * @param lineTaxesEle
	 * @param tempEle
	 * @param set
	 */
	public static void addTaxDetailsInLineTempElement(Element lineTaxesEle, Element tempEle, Set<Double> set) {
		logger.beginTimer("KohlsPoCPnPUtil.addTaxDetailsInLineTempElement");
		logger.debug("Method Name : addTaxDetailsInLineTempElement   Start ");
		List<Element> lineTaxList = XMLUtil.getElementsByTagName(lineTaxesEle, KohlsPOCConstant.E_LINE_TAX);
		String totalTaxPerLine = KohlsPOCConstant.ZERO_STR;
		String totalTaxRatePerLine = KohlsPOCConstant.ZERO_STR;
		String basisAmt = KohlsPOCConstant.ZERO_STR;
		//Changes for consolidating LineTaxes - Performance - Start
		for (Element lineTaxEle : lineTaxList) {
			/*String sTax = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX);
			String sTaxPercent = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT);
			if(YFCCommon.isVoid(sTax)){
				sTax = "0.0";
			}
			if(YFCCommon.isVoid(sTaxPercent)){
				sTaxPercent = "0.0";
			}*/
			totalTaxPerLine = lineTaxEle.getAttribute(KohlsPOCConstant.ATTR_TAX);
			totalTaxRatePerLine = lineTaxEle.getAttribute(KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE);
			//CPE-213 using Basis amt to print on Receipt 
			Element eleLineTaxExtn = XMLUtil.getChildElement(lineTaxEle, KohlsPOCConstant.E_EXTN);
			if(!YFCCommon.isVoid(eleLineTaxExtn)) {
			  basisAmt = eleLineTaxExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT);
			  String sTotalTax = lineTaxEle.getAttribute("LineTotalTax");
			  if(!YFCCommon.isVoid(basisAmt) && !YFCCommon.isVoid(sTotalTax)) {
				  if(Double.parseDouble(sTotalTax) >0){
					  tempEle.setAttribute(KohlsPOCConstant.A_TAXABLE_AMOUNT, basisAmt);
				  }
			  }
			}
		}
		/*logger.debug("Method Name : addTaxDetailsInLineTempElement   totalTaxPerLine "+totalTaxPerLine);
		logger.debug("Method Name : addTaxDetailsInLineTempElement   totalTaxRatePerLine "+totalTaxRatePerLine);*/
		/*totalTaxPerLine = Math.round(totalTaxPerLine*1000.0)/1000.0;
		totalTaxRatePerLine = Math.round(totalTaxRatePerLine*1000.0)/1000.0;*/
		/*logger.debug("After Math   totalTaxPerLine "+totalTaxPerLine);
		logger.debug("After Math totalTaxRatePerLine "+totalTaxRatePerLine);*/
		/*DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		twoDForm.setRoundingMode(RoundingMode.CEILING);*/
		//Changes for consolidating LineTaxes - Performance - End
		XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_LINE_TOTAL_TAX, totalTaxPerLine);
		//Fix for defect #1789
		//XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, twoDForm.format(totalTaxRatePerLine));
		XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, totalTaxRatePerLine+"");
		logger.debug("After rounding   totalTaxPerLine "+totalTaxPerLine);
		logger.debug("After rounding   totalTaxRatePerLine "+totalTaxRatePerLine);
	//	set.add(Double.valueOf(twoDForm.format(totalTaxRatePerLine)));
		//Fix for defect 4158 - Start
		if(!YFCCommon.isVoid(totalTaxRatePerLine)){
		set.add(convertToDouble(totalTaxRatePerLine));
		}else{
			set.add(Double.valueOf("0.00"));
		}
		//Fix for defect 4158 - End
		logger.endTimer("KohlsPoCPnPUtil.addTaxDetailsInLineTempElement");

	}

	/**
	 * Get the Index Value of TaxRate which is used to for the TaxIndicator
	 *
	 * @param set
	 * @param taxRate
	 * @return
	 */
	public static int getIndex(Set set, Double taxRate) {
		logger.beginTimer("KohlsPoCPnPUtil.getIndex");
		Iterator it = set.iterator();
		int count = KohlsPOCConstant.ONE_INT;

		while (it.hasNext()) {
			Double taxRateFromSet = (Double) it.next();
			if (taxRate.equals(taxRateFromSet)) {
				break;
			}
			count++;
		}
		logger.endTimer("KohlsPoCPnPUtil.getIndex");
		return count;
	}

	/**
	 * Stamping the Taxable Amount in the .../OrderLine/Temp Element
	 *
	 * @param nodeInDocOrderLine
	 * @return
	 */
	public static void addTaxableAmountInTempElement(Node nodeInDocOrderLine) {
		logger.beginTimer("KohlsPoCPnPUtil.addTaxableAmountInTempElement");

		double totalChargePerLine = KohlsPOCConstant.ZERO_DBL;

		NodeList nodeListOrderLineChildren = nodeInDocOrderLine.getChildNodes();

		for (int j = KohlsPOCConstant.ZERO_INT; j < nodeListOrderLineChildren.getLength(); j++) {
			Node nodeOrderLineChild = nodeListOrderLineChildren.item(j);

			if (nodeOrderLineChild.getNodeType() == Node.ELEMENT_NODE
					&& nodeOrderLineChild.getNodeName().equals(KohlsPOCConstant.ELEM_LINE_CHARGES)) {

				NodeList nodeListLineChargesChildren = nodeOrderLineChild.getChildNodes();

				if (null != nodeListLineChargesChildren
						&& nodeListLineChargesChildren.getLength() > KohlsPOCConstant.ZERO_INT) {
					for (int k = KohlsPOCConstant.ZERO_INT; k < nodeListLineChargesChildren.getLength(); k++) {
						Node nodeOrderLineChargesChild = nodeListLineChargesChildren.item(k);

						if (nodeOrderLineChargesChild.getNodeType() == Node.ELEMENT_NODE
								&& nodeOrderLineChargesChild.getNodeName().equals(KohlsPOCConstant.ELEM_LINE_CHARGE)) {
							Element elementLineCharge = (Element) nodeOrderLineChargesChild;

							String isDiscount = elementLineCharge.getAttribute(KohlsPOCConstant.A_IS_DISCOUNT);
							String sChargeCategory = elementLineCharge
									.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY);

							String sChargePerLine = elementLineCharge.getAttribute(KohlsPOCConstant.A_CHARGE_PER_LINE);
							Double dChargePerLine = KohlsPOCConstant.ZERO_DBL;
							if (!(XMLUtil.isVoid(sChargePerLine))) {
								dChargePerLine = Double.parseDouble(sChargePerLine);
							}

							if (!(XMLUtil.isVoid(isDiscount)) && (isDiscount.equalsIgnoreCase(KohlsPOCConstant.YES))) {
								totalChargePerLine += dChargePerLine;
							}
							if (!(XMLUtil.isVoid(sChargeCategory))
									&& sChargeCategory.equalsIgnoreCase(KohlsPOCConstant.PRICE_OVER_RIDE_INCREASE)) {
								totalChargePerLine -= dChargePerLine;
							}

						}
					}
				}
			}
		}

		Element elementLinePriceInfo = XMLUtil.getChildElement((Element) nodeInDocOrderLine,
				KohlsPOCConstant.E_LINE_PRICE_INFO, Boolean.TRUE);
		Element tempEle = XMLUtil.getChildElement((Element) nodeInDocOrderLine, KohlsPOCConstant.E_TEMP, Boolean.TRUE);

		double dUnitPrice = KohlsPOCConstant.ZERO_DBL;
		double taxableAmount = KohlsPOCConstant.ZERO_DBL;

		// Order\OrderLines\OrderLine\LinePriceInfo
		String unitPrice = elementLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);

		if (!(XMLUtil.isVoid(unitPrice))) {
			dUnitPrice = new Double(unitPrice);
			taxableAmount = dUnitPrice - totalChargePerLine;
		}
		DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
		tempEle.setAttribute(KohlsPOCConstant.A_TAXABLE_AMOUNT, twoDForm.format(taxableAmount));
		logger.endTimer("KohlsPoCPnPUtil.addTaxableAmountInTempElement");

	}

	/**
	 * Used to get Total Taxable Amount Business Logic : ( UnitPrice -
	 * TotalChargePerLine)
	 *
	 * @param eleInDocOrderLine
	 * @param totChargePerLine
	 * @return
	 */
	public static double getTaxableAmout(Element eleInDocOrderLine, double totChargePerLine) {
		logger.beginTimer("KohlsPoCPnPUtil.getTaxableAmout");

		double dUnitPrice = KohlsPOCConstant.ZERO_DBL;
		double taxableAmount = KohlsPOCConstant.ZERO_DBL;

		// Order\OrderLines\OrderLine\LinePriceInfo
		Element elementLinePriceInfo = XMLUtil.getChildElement(eleInDocOrderLine, KohlsPOCConstant.E_LINE_PRICE_INFO);
		String unitPrice = elementLinePriceInfo.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);

		if (!(XMLUtil.isVoid(unitPrice))) {
			dUnitPrice = new Double(unitPrice);
			taxableAmount = dUnitPrice - totChargePerLine;
		}
		logger.endTimer("KohlsPoCPnPUtil.getTaxableAmout");

		return taxableAmount;

	}

	/**
	 * Pads the input string with given string upto the given length
	 *
	 * @param sInpString
	 * @param iLength
	 * @param sPrepadString
	 * @return
	 */

	public static String prepadString(String sInpString, int iLength, String sPrepadString) {
		logger.beginTimer("KohlsPoCPnPUtil.prepadString");

		StringBuilder storeNoStringBuilder = new StringBuilder();
		if (sInpString.length() > iLength) {
			return sInpString.substring(sInpString.length() - iLength);
		}

		for (int j = sInpString.length(); j < iLength; j++) {
			storeNoStringBuilder.append(sPrepadString);
		}
		logger.endTimer("KohlsPoCPnPUtil.prepadString");

		return storeNoStringBuilder.append(sInpString).toString();
	}

	private static String substr(String sInpString, int i, int iLength) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * This method compares the ruleID for SeniorCitizen
	 *
	 * @return ruleValue
	 * @param Element
	 *            ResposneEle
	 * @param String
	 *            ruleId
	 */
	public static String ruleIDComparisonCaller(Element ResposneEle, String ruleId) {
		logger.beginTimer("KohlsPoCPnPUtil.ruleIDComparisonCaller");

		logger.debug("Method Name : ruleIDComparisonCaller   and   Status  ");

		List<Element> rulesEleList = XMLUtil.getElementsByTagName(ResposneEle, KohlsPOCConstant.E_RULE);
		String ruleValue = null;
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.YY_MM_DD);
		String strDate = sdf.format(cal.getTime());
		String ruleid = ruleId + KohlsPOCConstant.DOT + strDate;

		// for loop to traverse through the Rule Elements
		for (Element ruleEle : rulesEleList) {
			String ruleID = ruleEle.getAttribute(KohlsPOCConstant.A_RULE_ID);
			if (ruleid.equalsIgnoreCase(ruleID)) {
				ruleValue = ruleEle.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
				break;
			} else if (ruleId.equalsIgnoreCase(ruleID)) {
				ruleValue = ruleEle.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
			}

		}
		logger.debug("Method Name : ruleIDComparisonCaller   and   Status  ");
		logger.endTimer("KohlsPoCPnPUtil.ruleIDComparisonCaller");

		return ruleValue;
	}

	public static Document getItemListOutPut(YFSEnvironment env, String strItemID) throws Exception {
		logger.beginTimer("KohlsPoCPnPUtil.getItemListOutPut");
		Document docGetItemListInput = YFCDocument.createDocument(KohlsPOCConstant.ELEM_ITEM).getDocument();
		Element eleItemInput = docGetItemListInput.getDocumentElement();
		eleItemInput.setAttribute(KohlsPOCConstant.A_ITEM_ID, strItemID);
		Document docGetItemListOut = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.GET_ITEM_LIST, KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);
		logger.endTimer("KohlsPoCPnPUtil.getItemListOutPut");
		return docGetItemListOut;

	}

	public static String getUpcCode(Document docItemListOutput) {
		logger.beginTimer("KohlsPoCPnPUtil.getUpcCode");
		List<Element> itemAliasList = XMLUtil.getElementsByTagName(docItemListOutput.getDocumentElement(),
				KohlsPOCConstant.E_ITEM_ALIAS);
		if (itemAliasList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element itemAliasEle : itemAliasList) {
				String aliasName = XMLUtil.getAttribute(itemAliasEle, KohlsPOCConstant.A_ALIAS_NAME);
				if (aliasName.toUpperCase().contains(KohlsPOCConstant.CONST_UPC)) {
					logger.endTimer("KohlsPoCPnPUtil.getUpcCode");
					return XMLUtil.getAttribute(itemAliasEle, KohlsPOCConstant.A_ALIAS_VALUE);
				}
			}
		}
		logger.endTimer("KohlsPoCPnPUtil.getUpcCode");
		return KohlsPOCConstant.EMPTY;
	}

	public static String getUpcCode(YFSEnvironment env, String strItemID) throws Exception {
		return getUpcCode(getItemListOutPut(env, strItemID));
	}

	// Suresh : Added for Nike Exclusions Sprint 5 : Start

	/**
	 * This method retrieves the list of exclusion rules, which are active
	 *
	 * @return outdocGetExclusionRules
	 * @param YFSEnvironment
	 *            yfsEnv
	 */

	public static Document getExclusions(YFSEnvironment yfsEnv, String sMaxRecords) throws Exception {
		logger.beginTimer("KohlsPoCPnPUtil.getExclusions");

		/*
		 * <ExclusionDefn ExclusionActive="Y">
		 * 	<OrderBy>
		 * 		<Attribute Name="ModifyTS" Desc="Y"/>
		 * 	</OrderBy>
		 * </ExclusionDefn>
		 */

		Document indocExclusionRules = XMLUtil.createDocument(KohlsPOCConstant.E_EXCLUSION_DEFN);

		Element eleExclusionRules = indocExclusionRules.getDocumentElement();
		XMLUtil.setAttribute(eleExclusionRules, KohlsPOCConstant.E_EXCLUSION_ACTIVE, KohlsPOCConstant.YES);
		// Manoj 09/29: Added logic for performance optimization - Begin
		XMLUtil.setAttribute(eleExclusionRules, "MaximumRecords", sMaxRecords);
		Element eleOrderBy = XMLUtil.createChild(eleExclusionRules, "OrderBy");
		Element eleAttribute = XMLUtil.createChild(eleOrderBy, "Attribute");
		eleAttribute.setAttribute("Name", "ModifyTS");
		eleAttribute.setAttribute("Desc", "Y");
		// Manoj 09/29: Added logic for performance optimization - End

		// Currently invoking the extended database api as a service , and
		// cannot provide a output template
		Document outdocGetExclusionRules = KOHLSBaseApi.invokeService(yfsEnv,
				KohlsPOCConstant.API_GET_EXCLUSION_CLASSIFICATION, indocExclusionRules);
		logger.endTimer("KohlsPoCPnPUtil.getExclusions");

		return outdocGetExclusionRules;
	}

	/**
	 * This method returns the date in MMddYYYY format
	 *
	 * @return formattedDate Eg: 08252014
	 * @param String
	 *            toConvertDate
	 * @param String
	 *            toDateFormat
	 */

	public static String convertDateToMMddYYY(String toConvertDate, String toDateFormat) throws ParseException {
		logger.beginTimer("KohlsPoCPnPUtil.convertDateToMMddYYY");
		DateFormat fromFormat = new SimpleDateFormat(toDateFormat);
		fromFormat.setLenient(false);
		DateFormat toFormat = new SimpleDateFormat(KohlsPOCConstant.DATE_FORMAT_MM_dd_yyyy);
		toFormat.setLenient(false);
		Date fromDate = fromFormat.parse(toConvertDate);
		logger.endTimer("KohlsPoCPnPUtil.convertDateToMMddYYY");
		return toFormat.format(fromDate);

	}

	// Suresh : Added for Nike Exclusions Sprint 5 : End

	/**Method constructAPERequestFromExclusionRules
	 * Description This method invokes getExclusionClassification
	 * to retrieve the list of exclusion rules and constructs
	 * APE request accordingly
	 * @param yfsEnv
	 * @param apeRequestEle
	 * @throws Exception
	 * @throws ParseException
	 */
	public static void constructAPERequestFromExclusionRules(YFSEnvironment yfsEnv, Element apeRequestEle)
			throws Exception, ParseException {
		logger.beginTimer("KohlsPoCPnPUtil.constructAPERequestFromExclusionRules");
		// Calling getExclusionClassification for getting Exclusion Rule list
		//Manoj 09/29/2015: Passing Max Records=1 as part of perf tuning
		Document exclusionDefnsOutDoc = KohlsPoCPnPUtil.getExclusions(yfsEnv, "1");
		Element exclusionDefnsOutEle = exclusionDefnsOutDoc.getDocumentElement();
		KohlsPoCPnPUtil pnpUtil = new KohlsPoCPnPUtil();
		// constructing APE request
		pnpUtil.constructAPERequestForExclusions(yfsEnv, exclusionDefnsOutEle, apeRequestEle);
		logger.endTimer("KohlsPoCPnPUtil.constructAPERequestFromExclusionRules");
	}


	/**
	 * Method constructAPERequestForExclusions Description This method
	 * constructs APE request's Exclusion Tag from exclusionRuleOutEle, which is
	 * the output from getExclusionClassificationList API
	 *
	 * @param exclusionRuleOutEle
	 * @param apeRequestEle
	 * @throws Exception
	 */
	private void constructAPERequestForExclusions(YFSEnvironment yfsEnv, Element exclusionDefnsOutEle, Element apeRequestEle)
			throws Exception {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestForExclusions");
		// Manoj 09/29: Added logic for performance optimization by caching the OMS XML for Exclusions - Begin
		Element exclusionsEle = docExclusions.getDocumentElement();
		//Performance improvement changes - Start
		if(logger.isDebugEnabled()){
		logger.debug("The exclusionsEle value is" + XMLUtil.getElementXMLString(exclusionsEle));
		}
		//Performance improvement changes - End
		//Fix for defect 1082 - Start
		boolean isExclusionListPresent = false;
		//Fix for defect 678 - Start
		String sModifyTS = "";
		//Fix for defect 678 - End
		List<Element> exclusionList = XMLUtil.getElementsByTagName(exclusionsEle, KohlsPOCConstant.E_EXCLUSION);
		if (exclusionList.size() > KohlsPOCConstant.ZERO_INT ) {
			logger.debug("The Exclusion list is present");
			isExclusionListPresent = true;
		
		logger.debug("The isExclusionListPresent value is" + isExclusionListPresent);
		//Fix for defect 1082 - End
		sModifyTS = ((Element)exclusionDefnsOutEle.getElementsByTagName("ExclusionDefn").item(0)).getAttribute("ModifyTS");
		//If Last ModifyTS on the Exclusions list is same as Last Cashed date, then, use the cashed xml for exclusions
		// otherwise, prepaere the exclusions xml and cache it.
		logger.debug("LAST_EXCLUSION_DFN_CHNG_TS is: "+sLAST_EXCLUSION_DFN_CHNG_TS+" and ModifyTS is: "+sModifyTS);
		//Fix for defect 1082 - Start
		if(!YFCCommon.isVoid(sModifyTS) && !YFCCommon.isVoid(sLAST_EXCLUSION_DFN_CHNG_TS)
				&& sModifyTS.equalsIgnoreCase(sLAST_EXCLUSION_DFN_CHNG_TS) && (isExclusionListPresent)) 
		//Fix for defect 1082 - End
		{
			logger.debug("#### Exclusions list is not changed. Using the OMS Exclusions xml from cache" );
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			logger.debug("APE Request element with cached Exclusion xml is: "+XMLUtil.getElementXMLString(apeRequestEle));
			}
		//Performance improvement changes - End
		}else{
			logger.debug("The ModifyTs is changed. LAST_EXCLUSION_DFN_CHNG_TS is: "+sLAST_EXCLUSION_DFN_CHNG_TS+" and ModifyTS is: "+sModifyTS);
			sLAST_EXCLUSION_DFN_CHNG_TS = new String (sModifyTS);
			getAPEExclusionsForCache(yfsEnv, sModifyTS, exclusionsEle, exclusionDefnsOutEle);
		}
	}
		else {
			
			//getAPEExclusionsForCache();
			getAPEExclusionsForCache(yfsEnv, sModifyTS, exclusionsEle, exclusionDefnsOutEle);
		}
		Element exclusionsEle_Temp = (Element) apeRequestEle.getOwnerDocument().importNode(exclusionsEle, true);
		apeRequestEle.appendChild(exclusionsEle_Temp);
		//this.logger.debug("Method Name : constructAPERequestForExclusions   and   Status : Start ");
		// Manoj 09/29: Added logic for performance optimization - End
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestForExclusions");

	}
	
	public void getAPEExclusionsForCache(YFSEnvironment yfsEnv, String sModifyTS, Element exclusionsEle, Element exclusionDefnsOutEle) throws Exception{
		

		logger.debug("#### Exclusions list is updated or server is restarted. "
				+ "Building the OMS Exclusions xmls cache" );
		//sLAST_EXCLUSION_DFN_CHNG_TS = new String (sModifyTS);
		SimpleDateFormat exclusionActiveDateFormat= new SimpleDateFormat (KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);
		//Manoj 09/29/2015: calling getSxclusionsListForPOS to get all the exclusions records
		Document exclusionDefnsOutDoc = KohlsPoCPnPUtil.getExclusions(yfsEnv, "");
		exclusionDefnsOutEle = exclusionDefnsOutDoc.getDocumentElement();
		NodeList exclusionRuleEleList = exclusionDefnsOutEle.getElementsByTagName(KohlsPOCConstant.E_EXCLUSION_DEFN);
		// Iterating through the list of exclusion rules from
		// getExclusionClassificationList API response
		if (!YFCCommon.isVoid(exclusionRuleEleList) && exclusionRuleEleList.getLength()>0) {
			sModifyTS = ((Element)exclusionDefnsOutEle.getElementsByTagName("ExclusionDefn").item(0)).getAttribute("ModifyTS");
			sLAST_EXCLUSION_DFN_CHNG_TS = new String (sModifyTS);
			for (int i=0; i<exclusionRuleEleList.getLength(); i++) {
				//Element exclusionTagEle = XMLUtil.createChild(exclusionsEle, KohlsPOCConstant.E_EXCLUSION_TAG);
				Element exclusionTagEle = XMLUtil.createChild(exclusionsEle, "Exclusion");
				Element exclusionRuleEle = (Element)exclusionRuleEleList.item(i);
				// retrieving department, class , subclass and active date
				// information
				String exclusionDept = XMLUtil.getAttribute(exclusionRuleEle, KohlsPOCConstant.E_EXCLUSION_DEPT);
				String exclusionClass = XMLUtil.getAttribute(exclusionRuleEle, KohlsPOCConstant.E_EXCLUSION_CLASS);
				String exclusionSubClass = XMLUtil
						.getAttribute(exclusionRuleEle, KohlsPOCConstant.E_EXCLUSION_SUBCLASS);

				String exclusionActiveDate = XMLUtil.getAttribute(exclusionRuleEle,
						KohlsPOCConstant.E_EXCLUSION_ACTIVE_DATE);

				// Start : Defect fix: 3268 , setting exclusionActiveDate to currentdate if it is coming as blank or null

				if (XMLUtil.isVoid(exclusionActiveDate))
				{

					Date currentDate = new Date( );

					exclusionActiveDate=exclusionActiveDateFormat.format(currentDate);

				}

				// End : Defect fix: 3268 , setting exclusionActiveDate to currentdate if it is coming as blank or null


				// if the date is not null or blank
				if (!XMLUtil.isVoid(exclusionActiveDate)) {

					// converting the date into MMddYYYY format
					String formattedExclusionActiveDate = KohlsPoCPnPUtil.convertDateToMMddYYY(exclusionActiveDate,
							KohlsPOCConstant.HD_DATE_FORMAT);

					// exclusionTagData holds the piped delimited data
					String exclusionTagData = retrieveExclusionData(formattedExclusionActiveDate, exclusionDept,
							exclusionClass, exclusionSubClass);

					// Setting the piped delimited data to the request
					//XMLUtil.setAttribute(exclusionTagEle, KohlsPOCConstant.E_EXCLUSION, exclusionTagData);
					XMLUtil.setNodeValue(exclusionTagEle, exclusionTagData);
				}

			}

		}

	
	}

	/**
	 * Method retrieveExclusionData Description This method will form the piped
	 * delimited data, which is the combination of active date, department,
	 * class and subclass information
	 *
	 * @param formattedExclusionActiveDate
	 * @param exclusionDept
	 * @param exclusionClass
	 * @param exclusionSubClass
	 * @return exclusionTagData
	 */
	private String retrieveExclusionData(String formattedExclusionActiveDate, String exclusionDept,
			String exclusionClass, String exclusionSubClass) {

		logger.beginTimer("KohlsPoCAPECaller.retrieveExclusionData");

		this.logger.debug("Method Name : retrieveExclusionData   and   Status : Start ");

		String exclusionTagData = "";
		String exclusionLevelIndicator = "";

		if (!XMLUtil.isVoid(formattedExclusionActiveDate)) {

			// if subclass, class and department all exist,
			// exclusionlevelindicator would be SCL
			if (!XMLUtil.isVoid(exclusionSubClass) && !XMLUtil.isVoid(exclusionClass) && !XMLUtil.isVoid(exclusionDept)) {

				exclusionLevelIndicator = KohlsPOCConstant.E_SCL;
				exclusionTagData = formattedExclusionActiveDate + KohlsPOCConstant.E_PIPE_SYMBOL
						+ exclusionLevelIndicator + KohlsPOCConstant.E_PIPE_SYMBOL + exclusionDept
						+ KohlsPOCConstant.E_PIPE_SYMBOL + exclusionClass + KohlsPOCConstant.E_PIPE_SYMBOL
						+ exclusionSubClass;

				// if class and department all exist, exclusionlevelindicator
				// would be MCL
			} else if (!XMLUtil.isVoid(exclusionClass) && !XMLUtil.isVoid(exclusionDept)) {

				exclusionLevelIndicator = KohlsPOCConstant.E_MCL;
				exclusionTagData = formattedExclusionActiveDate + KohlsPOCConstant.E_PIPE_SYMBOL
						+ exclusionLevelIndicator + KohlsPOCConstant.E_PIPE_SYMBOL + exclusionDept
						+ KohlsPOCConstant.E_PIPE_SYMBOL + exclusionClass;

				// if alone department exist, exclusionlevelindicator would be
				// DPT

			} else if (!XMLUtil.isVoid(exclusionDept)) {

				exclusionLevelIndicator = KohlsPOCConstant.E_DPT;
				exclusionTagData = formattedExclusionActiveDate + KohlsPOCConstant.E_PIPE_SYMBOL
						+ exclusionLevelIndicator + KohlsPOCConstant.E_PIPE_SYMBOL + exclusionDept;

			}

		}

		this.logger.debug("Method Name : retrieveExclusionData   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.retrieveExclusionData");
		return exclusionTagData;
	}

	// Suresh : Added for Nike Exclusions Sprint 5 : End

	/**Method : prepadAuthTimeWithZeros
	 * This method is used to append Zeros to form AuthTime as 4 digit
	 * Eg: 4 as 0004, 14 as 0014, 214 as 0214
	 * @param authTime
	 * @return
	 */
	public static String prepadAuthTimeWithZeros(String authTime) {
		logger.beginTimer("KohlsPoCPnPUtil.prepadAuthTimeWithZeros");
		logger.verbose("prepadAuthTimeWithZeros() input :::"+authTime);

		StringBuilder authTimeStringBuilder = new StringBuilder();

		if (authTime.length() > 4) {
			return authTime.substring(0, 4);
		} else {
			for (int j = authTime.length(); j < 4 ; j++) {
				authTimeStringBuilder.append(KohlsPOCConstant.ZERO);
			}
			logger.endTimer("KohlsPoCPnPUtil.prepadAuthTimeWithZeros");
		}

		return authTimeStringBuilder.append(authTime).toString();

}

	//Suraj: Changes for Associate and Senior discounts for Sprint 9 - Start
	public static String getDiscountsPercentageForPOSBydate ( YFSEnvironment yfsEnv, Element orderElement, String strRuleID) throws YFSException
	{
		logger.beginTimer("KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate");

		String strCodeShortDescription = null;
		Element eleCommonCode = null;
		Element elemCommonCode = null;
		Element eleDefault = null;
		Document docOutputForGetCommonCodeList = null;

		try
		{
			Document getTillStatusListForPOSoutDoc = getTillStatusListForPOSCaller(yfsEnv, orderElement);
			Element getTillStatusListForPOSoutDocEle = (Element) ((NodeList) getTillStatusListForPOSoutDoc
					.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS)).item(0);
			String strBusinessDayFromTillStatus=getTillStatusListForPOSoutDocEle.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
			logger.debug("The Business Day is: "+strBusinessDayFromTillStatus);
			String [] delimited = strBusinessDayFromTillStatus.split(KohlsPOCConstant.MINUS);
			String strBusinessDate=delimited[1].concat(delimited[2]).concat((delimited[0].substring(2, 4)));
			String strOrganizationCode = orderElement.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);
			logger.debug("The Business Date value is: "+strBusinessDate);
			logger.debug("The Enterprise Code value is: "+strOrganizationCode);

			SimpleDateFormat simpleDateformat = new SimpleDateFormat("MMddyy");
			Date date = simpleDateformat.parse(strBusinessDate);
			SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
			String strBusinessDay = sdf.format(date).toUpperCase();
			logger.debug("Business Day is :: " + strBusinessDay);

			Document docInputForGetCommonCodeList = XMLUtil.createDocument(KohlsConstant.E_COMMON_CODE);
			Element eleInputForGetCommonCodeList = docInputForGetCommonCodeList.getDocumentElement();
			eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_CODE_TYPE,strRuleID);
			eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_ORGANIZATION_CODE,strOrganizationCode);

			docOutputForGetCommonCodeList= KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.API_GET_COMMON_CODE_LIST, docInputForGetCommonCodeList);
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			logger.debug("Output of Common Code API :: " + XMLUtil.getXMLString(docOutputForGetCommonCodeList));
			}
			//Performance improvement changes - End

			NodeList nlCommonCode = docOutputForGetCommonCodeList.getElementsByTagName(KohlsConstant.E_COMMON_CODE);
			for(int i=0;i<nlCommonCode.getLength();i++)
			{
				eleCommonCode = (Element) nlCommonCode.item(i);
				String strCodeValue = eleCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);

				if(strCodeValue.equalsIgnoreCase(strBusinessDate))
				{
					strCodeShortDescription = eleCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
					logger.debug("Code Short Description for given Business Date :: " + strCodeShortDescription);
					return strCodeShortDescription;
				}

			}

			for(int j=0;j<nlCommonCode.getLength();j++)
			{
				elemCommonCode = (Element) nlCommonCode.item(j);
				String strCodeValue = elemCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);

				if(strCodeValue.equalsIgnoreCase(strBusinessDay))
				{
					strCodeShortDescription = elemCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
					logger.debug("Code Short Description for given Business Day :: " + strCodeShortDescription);
					return strCodeShortDescription;
				}

			}

			if(YFCCommon.isStringVoid(strCodeShortDescription))
			{
				eleDefault = (Element) XPathUtil.getNodeList(
						docOutputForGetCommonCodeList,
						"/CommonCodeList/CommonCode[@CodeValue='DEFAULT']").item(0);
				strCodeShortDescription = eleDefault.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
				logger.debug("Code Short Description for Default :: " + strCodeShortDescription);
			}
		}
		catch (ParseException e) {
			e.printStackTrace();
			throw new YFCException(e.getMessage());
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			throw new YFCException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new YFCException(e.getMessage());
		}

		logger.endTimer("KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate");
		return strCodeShortDescription;
	}

	//Suraj: Changes for Associate and Senior discounts for Sprint 9 - End

	//Begin- Changes for 2979
	public static String getDiscountsPercentageForPOSBydatePSA ( YFSEnvironment yfsEnv, Element orderElement, String strRuleID) throws YFSException
	{
		logger.beginTimer("KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydatePSA");

		String strCodeShortDescription = null;
		Element eleCommonCode = null;
		Element elemCommonCode = null;
		Element eleDefault = null;
		Document docOutputForGetCommonCodeList = null;

		try
		{
			/*//Document getTillStatusListForPOSoutDoc = getTillStatusListForPOSCaller(yfsEnv, orderElement);
			Element getTillStatusListForPOSoutDocEle = (Element) ((NodeList) getTillStatusListForPOSoutDoc
					.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS)).item(0);*/
			String strBusinessDayFromSalesOrder=orderElement.getAttribute(KohlsPOCConstant.A_ORDER_DATE);
			String strBusinessDayFromSalesOrdernew= strBusinessDayFromSalesOrder.substring(0,10);
		
			logger.debug("The Business Day is: "+strBusinessDayFromSalesOrder);
			String [] delimited = strBusinessDayFromSalesOrdernew.split(KohlsPOCConstant.MINUS);
			String strBusinessDate=delimited[1].concat(delimited[2]).concat((delimited[0].substring(2, 4)));
			String strOrganizationCode = orderElement.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);
			
			logger.debug("The Business Date value is: "+strBusinessDate);
			logger.debug("The Enterprise Code value is: "+strOrganizationCode);
		
			SimpleDateFormat simpleDateformat = new SimpleDateFormat("MMddyy");
			Date date = simpleDateformat.parse(strBusinessDate);
			SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
			String strBusinessDay = sdf.format(date).toUpperCase();
		
			logger.debug("Business Day is :: " + strBusinessDay);

			Document docInputForGetCommonCodeList = XMLUtil.createDocument(KohlsConstant.E_COMMON_CODE);
			Element eleInputForGetCommonCodeList = docInputForGetCommonCodeList.getDocumentElement();
			eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_CODE_TYPE,strRuleID);
			eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_ORGANIZATION_CODE,strOrganizationCode);
			
			
			docOutputForGetCommonCodeList= KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.API_GET_COMMON_CODE_LIST, docInputForGetCommonCodeList);
			//Performance improvement changes - Start
			if(logger.isDebugEnabled()){
			logger.debug("Output of Common Code API :: " + XMLUtil.getXMLString(docOutputForGetCommonCodeList));
			}
			//Performance improvement changes - End
			NodeList nlCommonCode = docOutputForGetCommonCodeList.getElementsByTagName(KohlsConstant.E_COMMON_CODE);
			for(int i=0;i<nlCommonCode.getLength();i++)
			{
				eleCommonCode = (Element) nlCommonCode.item(i);
				String strCodeValue = eleCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);

				if(strCodeValue.equalsIgnoreCase(strBusinessDate))
				{
					strCodeShortDescription = eleCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
					logger.debug("Code Short Description for given Business Date :: " + strCodeShortDescription);
					return strCodeShortDescription;
				}

			}

			for(int j=0;j<nlCommonCode.getLength();j++)
			{
				elemCommonCode = (Element) nlCommonCode.item(j);
				String strCodeValue = elemCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);

				if(strCodeValue.equalsIgnoreCase(strBusinessDay))
				{
					strCodeShortDescription = elemCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
					logger.debug("Code Short Description for given Business Day :: " + strCodeShortDescription);
					return strCodeShortDescription;
				}

			}

			if(YFCCommon.isStringVoid(strCodeShortDescription))
			{
				eleDefault = (Element) XPathUtil.getNodeList(
						docOutputForGetCommonCodeList,
						"/CommonCodeList/CommonCode[@CodeValue='DEFAULT']").item(0);
				strCodeShortDescription = eleDefault.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
				logger.debug("Code Short Description for Default :: " + strCodeShortDescription);
			}
		}
		catch (ParseException e) {
			e.printStackTrace();
			throw new YFCException(e.getMessage());
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			throw new YFCException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new YFCException(e.getMessage());
		}

		logger.endTimer("KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydatePSA");
		return strCodeShortDescription;
	}
	//End- Changes for 2979
	//new method for TVS -- start

	public static void validateTVSResponse(Element tvsResponseEle) throws YFSException {

		logger.beginTimer("KohlsPoCPnPUtil.validateTVSResponse");


		if (tvsResponseEle.getTagName().equalsIgnoreCase("Errors")) {

			String errorCodeStr = XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorCode");
			String errorDescription = XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorDescription");

			if ("NO_SKU_DATA_FOUND".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.NO_SKU_DATA_FOUND));

			}

			if ("OFFER_NOT_STARTED".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_NOT_STARTED));

			}


			if ("UNKNOWN_STORE_ID".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.UNKNOWN_STORE_ID));

			}

			if ("NO_OFFER_DATA_FOUND".equalsIgnoreCase(errorCodeStr)) {
				String strNoOfferFound = errorDescription.substring(40);
				String[] argsNoOfferFound = {strNoOfferFound};
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.NO_OFFER_DATA_FOUND,argsNoOfferFound));

			}

			if ("OFFER_END_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_END_DATE_PASSED));

			}

			if ("OFFER_OVR_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_OVR_DATE_PASSED));

			}

			if ("OFFER_NOT_STARTED".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_NOT_STARTED));

			}

			if ("OFFER_DUPLICATION".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.OFFER_DUPLICATION));

			}

			if ("SERVICE_UNAVAILABLE".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.SERVICE_UNAVAILABLE));

			}

			if ("INTERNAL_SERVER_ERROR".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INTERNAL_SERVER_ERROR));

			}
			if ("INVALID_REQUEST".equalsIgnoreCase(errorCodeStr)) {
				String strInvalidrequest = errorDescription.substring(24);
				String[] argsInvalidRequest = {strInvalidrequest};
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_REQUEST,argsInvalidRequest));

			}
			if ("MISSING_PARAMETER".equalsIgnoreCase(errorCodeStr)) {
				String strMissingParameter = errorDescription.substring(26);
				String[] argsMisngParameter = {strMissingParameter};

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.MISSING_PARAMETER,argsMisngParameter));


			}
			if ("INVALID_MARK_DOWN_VALUE".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_MARK_DOWN_VALUE));

			}
			if ("INVALID_MARK_DOWN_VALUE".equalsIgnoreCase(errorCodeStr)) {
				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_MARK_DOWN_VALUE));

			}

			if ("TOO_MANY_SKUS".equalsIgnoreCase(errorCodeStr)) {
				String strTooManySkus = errorDescription.substring(46);
				String[] argsTooManySkus = {strTooManySkus};

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TOO_MANY_SKUS,argsTooManySkus));

			}
			if ("INVALID_TIME_RANGE".equalsIgnoreCase(errorCodeStr)) {
				String strInvalidTimeRange = errorDescription.substring(30);
				String[] argsInvalidTimeRange = {strInvalidTimeRange};

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_TIME_RANGE,argsInvalidTimeRange));

			}
			if ("TOO_MANY_PROMO_IDS".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TOO_MANY_PROMO_IDS));

			}
			if ("NO_SUCH_BATCH_ID".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.NO_SUCH_BATCH_ID));

			}
			if ("NO_SUCH_JOB_ID".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.NO_SUCH_JOB_ID));

			}
			if ("NO_PRICE_DATA_FOUND".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.NO_PRICE_DATA_FOUND));

			}
			/*					if ("UNKNOWN_PARAMETER".equalsIgnoreCase(errorCodeStr)) {
				String strUnknownParameter = errorMsgStr.substring(0,4);

				yfsExceptionMessage(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.UNKNOWN_PARAMETER),strUnknownParameter);

			}*/
			if ("INTERNAL_ERROR".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INTERNAL_ERROR));

			}
/*					if ("TOO_MANY_BATCH_REQUESTS".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INTERNAL_ERROR));

			}*/
			if ("TOO_MANY_PRODUCTS".equalsIgnoreCase(errorCodeStr)) {

				String strTooManyProducts = errorDescription.substring(55);
				String[] argsTooManyProducts = {strTooManyProducts};

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TOO_MANY_PRODUCTS,argsTooManyProducts));

			}
			if ("INVALID_DISCOUNT_TYPE".equalsIgnoreCase(errorCodeStr)) {

				yfsException(errorCodeStr, KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALID_DISCOUNT_TYPE));

			}



		}

		logger.endTimer("KohlsPoCPnPUtil.validateTVSResponse");


	}

		//new method for TVS -- end


	// Suresh : Added for Nike Exclusions Sprint 5 : End

		/**Method constructTVSRequestFromExclusionRules
		 * Description This method invokes getExclusionClassification
		 * to retrieve the list of exclusion rules and constructs
		 * APE request accordingly
		 * @param yfsEnv
		 * @param transactionEle
		 * @throws Exception
		 * @throws ParseException
		 */
		public static void constructTVSRequestFromExclusionRules(YFSEnvironment yfsEnv, Element transactionEle)
				throws Exception, ParseException {
			logger.beginTimer("KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules");
			checkExclusions(yfsEnv);
			if(sendExclusions){
			
				// changes for performance : START //
				Document exclusionDefnsOutDoc = KohlsPoCPnPUtil.getExclusions(yfsEnv, "1");
				// changes for performance : END//
				// Calling getExclusionClassification for getting Exclusion Rule list
				//Document exclusionDefnsOutDoc = KohlsPoCPnPUtil.getExclusions(yfsEnv, "");
				Element exclusionDefnsOutEle = exclusionDefnsOutDoc.getDocumentElement();
				KohlsPoCPnPUtil pnpUtil = new KohlsPoCPnPUtil();
				// constructing TVS request
				pnpUtil.constructTVSRequestForExclusions(yfsEnv,exclusionDefnsOutEle, transactionEle);
			}
			logger.endTimer("KohlsPoCPnPUtil.constructTVSRequestFromExclusionRules");
		}
		
		/**
		 * This method reads the Exclusion Flag from the POS Rule List API .
		 * @param yfsEnv
		 * @return
		 * @throws Exception
		 */
		private static void checkExclusions(YFSEnvironment yfsEnv) throws Exception {
			
			String strRuleValue = KohlsPoCCommonAPIUtil.getRuleValue(yfsEnv,  KohlsPOCConstant.RULE_SEND_TVS_EXCLUSIONS, KohlsPOCConstant.KOHLS_RETAIL, KohlsPOCConstant.NO);
			if(KohlsPOCConstant.YES.equalsIgnoreCase(strRuleValue)){
				sendExclusions =  true;
			}else{
				sendExclusions =  false;
			}
						
		}
		/**
		 * Returns the includeExclusionFlag. Used in other classes to manage exclusion element.
		 * @return
		 */
		public static boolean getExclusionsFlag()
		{
			return sendExclusions;
		}
		
		/**
		 * Method constructTVSRequestForExclusions Description This method
		 * constructs APE request's Exclusion Tag from exclusionRuleOutEle, which is
		 * the output from getExclusionClassificationList API
		 *
		 * @param exclusionRuleOutEle
		 * @param transactionEle
		 * @throws Exception
		 */
		private void constructTVSRequestForExclusions(YFSEnvironment yfsEnv,Element exclusionDefnsOutEle, Element transactionEle)
				throws Exception {
			logger.beginTimer("KohlsPoCPnPUtil.constructTVSRequestForExclusions");

			this.logger.debug("Method Name : constructTVSRequestForExclusions   and   Status : Start ");

			// check for performance : START //

			Element exclusionsEle = docExclusionsTvs.getDocumentElement();
			//Fix for defect 929 - Start
			boolean isExclusionListPresent = false;
			//Fix for defect 678 - Start
			String sModifyTS = "";
			//Fix for defect 678 - End
			List<Element> exclusionList = XMLUtil.getElementsByTagName(exclusionsEle, KohlsPOCConstant.ELE_EXCLUSION);
			if (exclusionList.size() > KohlsPOCConstant.ZERO_INT ) {
				logger.debug("The Exclusion list is present");
				isExclusionListPresent = true;
				//Commenting the close brace for defect 678
				//}
				//Fix for defect 929 - End
				sModifyTS = ((Element)exclusionDefnsOutEle.getElementsByTagName("ExclusionDefn").item(0)).getAttribute("ModifyTS");
				//If Last ModifyTS on the Exclusions list is same as Last Cashed date, then, use the cashed xml for exclusions
				// otherwise, prepaere the exclusions xml and cache it.
				logger.debug("LAST_EXCLUSION_DFN_CHNG_TS is: "+sLAST_EXCLUSION_DFN_CHNG_TS+" and ModifyTS is: "+sModifyTS);
				//Fix for defect 929 - Start
				if(!YFCCommon.isVoid(sModifyTS) && !YFCCommon.isVoid(sLAST_EXCLUSION_DFN_CHNG_TS)
						&& sModifyTS.equalsIgnoreCase(sLAST_EXCLUSION_DFN_CHNG_TS) && (isExclusionListPresent))
					//Fix for defect 929 - End
				{
					logger.debug("#### Exclusions list is not changed. Using the OMS Exclusions xml from cache" );
					//Performance improvement changes - Start
					if(logger.isDebugEnabled()){
					logger.debug("TVS Request element with cached Exclusion xml is: "+XMLUtil.getElementXMLString(transactionEle));
					}
					//Performance improvement changes - End
				}else{
					logger.debug("The ModifyTs is changed. LAST_EXCLUSION_DFN_CHNG_TS is: "+sLAST_EXCLUSION_DFN_CHNG_TS+" and ModifyTS is: "+sModifyTS);
					sLAST_EXCLUSION_DFN_CHNG_TS = new String (sModifyTS);
					getTVSExclusionsForCache(yfsEnv, sModifyTS, exclusionsEle, exclusionDefnsOutEle);
				}
				//Adding a close brace for defect 678
			}
			else{
				getTVSExclusionsForCache(yfsEnv, sModifyTS, exclusionsEle, exclusionDefnsOutEle);
			}


			Element exclusionsEleTVS_Temp = (Element) transactionEle.getOwnerDocument().importNode(exclusionsEle, true);
			transactionEle.appendChild(exclusionsEleTVS_Temp);
			this.logger.debug("Method Name : constructTVSRequestForExclusions   and   Status : End ");
			logger.endTimer("KohlsPoCPnPUtil.constructTVSRequestForExclusions");
		}
		
		public void getTVSExclusionsForCache(YFSEnvironment yfsEnv, String sModifyTS, Element exclusionsEle, Element exclusionDefnsOutEle) throws Exception{

			// check for performance : END //
			logger.debug("#### Exclusions list is updated or server is restarted. "
					+ "Building the OMS Exclusions xmls cache" );
			//sLAST_EXCLUSION_DFN_CHNG_TS = new String (sModifyTS);

			Document exclusionDefnsOutDoc = KohlsPoCPnPUtil.getExclusions(yfsEnv, "");
			exclusionDefnsOutEle = exclusionDefnsOutDoc.getDocumentElement();




			SimpleDateFormat exclusionActiveDateFormat= new SimpleDateFormat (KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd);

			NodeList exclusionRuleEleList = exclusionDefnsOutEle.getElementsByTagName(KohlsPOCConstant.E_EXCLUSION_DEFN);
			// Iterating through the list of exclusion rules from
			// getExclusionClassificationList API response
			if (!YFCCommon.isVoid(exclusionRuleEleList) && exclusionRuleEleList.getLength()>0) {
				sModifyTS = ((Element)exclusionDefnsOutEle.getElementsByTagName("ExclusionDefn").item(0)).getAttribute("ModifyTS");
				sLAST_EXCLUSION_DFN_CHNG_TS = new String (sModifyTS);
				for (int i=0; i<exclusionRuleEleList.getLength(); i++) {

					Element exclusionTagEle = XMLUtil.createChild(exclusionsEle,KohlsPOCConstant.E_EXCLUSION_TVS);

					Element exclusionRuleEle = (Element)exclusionRuleEleList.item(i);
					// retrieving department, class , subclass and active date
					// information
					String exclusionDept = XMLUtil.getAttribute(exclusionRuleEle, KohlsPOCConstant.E_EXCLUSION_DEPT);
					String exclusionClass = XMLUtil.getAttribute(exclusionRuleEle, KohlsPOCConstant.E_EXCLUSION_CLASS);
					String exclusionSubClass = XMLUtil
							.getAttribute(exclusionRuleEle, KohlsPOCConstant.E_EXCLUSION_SUBCLASS);

					String exclusionActiveDate = XMLUtil.getAttribute(exclusionRuleEle,
							KohlsPOCConstant.E_EXCLUSION_ACTIVE_DATE);

					// Start : Defect fix: 3268 , setting exclusionActiveDate to currentdate if it is coming as blank or null

					if (XMLUtil.isVoid(exclusionActiveDate))
					{

						Date currentDate = new Date( );

						exclusionActiveDate=exclusionActiveDateFormat.format(currentDate);

					}

					// End : Defect fix: 3268 , setting exclusionActiveDate to currentdate if it is coming as blank or null


					// if the date is not null or blank
					if (!XMLUtil.isVoid(exclusionActiveDate)) {

						// converting the date into MMddYYYY format
						String formattedExclusionActiveDate = KohlsPoCPnPUtil.convertDateToMMddYYY(exclusionActiveDate,
								KohlsPOCConstant.HD_DATE_FORMAT);

						// exclusionTagData holds the piped delimited data
						String exclusionTagData = retrieveExclusionData(formattedExclusionActiveDate, exclusionDept,
								exclusionClass, exclusionSubClass);

						// Setting the piped delimited data to the request
						XMLUtil.setNodeValue(exclusionTagEle, exclusionTagData);

					}

				}
			}


		}

		/**Method updateExtnAttrsOnOrderLineFromItem
		 * Description: This method checks if TVS Gap attributes are
		 * present at OrderLine/Extn and if not present then fetches it
		 * by calling getItemList Api.
		 * @param env
		 * @param inXML
		 * @throws Exception
		 * @throws ParseException
		 */
		public static void updateExtnAttrsOnOrderLineFromItem(YFSEnvironment env, Document inXML)
				throws Exception, ParseException {
			logger.beginTimer("KohlsPoCPnPUtil.updateExtnAttrsOnOrderLineFromItem");
			String sExtnItemDept;
			String sExtnItemSubClass;
			String sExtnItemClass;
			String sExtnTaxProductCode;
			//Commented Out for defect #1096
//			String sExtnMdxTaxCode;
			String sExtnEmpDiscCode;
			String sExtnVendorStyleNo;
			// Looping through each order line to find the extn attributes
			NodeList nlOrderLine = inXML.getElementsByTagName("OrderLine");
			if(nlOrderLine.getLength() >0){
				for(int i=0; i<nlOrderLine.getLength(); i++){
					sExtnItemDept = null;
					sExtnItemSubClass = null;
					sExtnItemClass = null;
					sExtnTaxProductCode = null;
					//sExtnMdxTaxCode = null;
					sExtnEmpDiscCode = null;
					sExtnVendorStyleNo = null;
					Element eleOrderLine = (Element)nlOrderLine.item(i);
					Element eleExtn = null;
					eleExtn = XMLUtil.getChildElement(eleOrderLine, "Extn");
					if(!YFCCommon.isVoid(eleExtn)){
						sExtnItemDept = eleExtn.getAttribute("ExtnItemDept");
						sExtnItemSubClass = eleExtn.getAttribute("ExtnItemSubClass");
						sExtnItemClass = eleExtn.getAttribute("ExtnItemClass");
						sExtnTaxProductCode = eleExtn.getAttribute("ExtnTaxProductCode");
						//sExtnMdxTaxCode = eleExtn.getAttribute("ExtnMdxTaxCode");
						sExtnVendorStyleNo = eleExtn.getAttribute("ExtnVendorStyleNo");
					} else {
						eleExtn = XMLUtil.createChild(eleOrderLine, "Extn");
					}

					Element eleReference = (Element)((NodeList)XPathUtil.getNodeList(eleOrderLine,
							 "References/Reference[@Name='ExtnEmpDiscCode']").item(0));
					logger.debug("eleOrderLine is: "+XMLUtil.getElementXMLString(eleOrderLine));
					if(!YFCCommon.isVoid(eleReference)) {
						sExtnEmpDiscCode = eleReference.getAttribute("Value");
					}
					logger.debug("Values of the attributes are:"+
					" sExtnItemDept: "+sExtnItemDept+
					" sExtnItemSubClass: "+sExtnItemSubClass+
					" sExtnItemClass: "+sExtnItemClass+
					" sExtnTaxProductCode: "+sExtnTaxProductCode+
					" sExtnEmpDiscCode: "+sExtnEmpDiscCode+
					" sExtnVendorStyleNo"+ sExtnVendorStyleNo);
					//if one of the attribute is null then call getItemList API and fetch it
					/*if((null==sExtnItemDept) || (null==sExtnItemSubClass) || (null==sExtnItemClass)
							|| (null==sExtnItemClass) || (null==sExtnMdxTaxCode) || (null==sExtnEmpDiscCode)
							|| (null==sExtnTaxProductCode)) {*/
						if(YFCCommon.isVoid(sExtnItemDept) || YFCCommon.isVoid(sExtnItemSubClass)
								|| YFCCommon.isVoid(sExtnItemClass) || YFCCommon.isVoid(sExtnItemClass)
							   || YFCCommon.isVoid(sExtnEmpDiscCode)
							|| YFCCommon.isVoid(sExtnTaxProductCode)
							|| YFCCommon.isVoid(sExtnVendorStyleNo)) {
							Element eleOrderLineItem = XMLUtil.getChildElement(eleOrderLine, "Item");
							String sItemID = eleOrderLineItem.getAttribute("ItemID");
							String sUnitOfMeasure = eleOrderLineItem.getAttribute("UnitOfMeasure");
							String sCallingOrganizationCode=inXML.getDocumentElement().getAttribute("EnterpriseCode");
							Document docGetItemListInput = XMLUtil.createDocument("Item");
							Element eleItemIn = docGetItemListInput.getDocumentElement();
							eleItemIn.setAttribute("ItemID", sItemID);
							eleItemIn.setAttribute("UnitOfMeasure", sUnitOfMeasure);
							eleItemIn.setAttribute("CallingOrganizationCode", sCallingOrganizationCode);
							String sGetItemListTemplate = "<ItemList><Item ItemID=''><Extn ExtnClass='' ExtnDept='' "
									+ "ExtnEmpDiscCode='' ExtnMerchandiseTaxCode='' ExtnSubClass=''/>"
									+ "<ClassificationCodes TaxProductCode=''/></Item></ItemList>";
							// invoking getItemList API
							//Performance improvement changes - Start
							if(logger.isDebugEnabled()){
							logger.debug("Invoking getItemList API with input as:\n"+
							XMLUtil.getXMLString(docGetItemListInput));
							}
							//Performance improvement changes - End
							logger.debug("Template for getItemList API is:\n"+sGetItemListTemplate);
							Document docGetItemListOutput = KOHLSBaseApi.invokeAPI(env,XMLUtil.getDocument(sGetItemListTemplate),
									KohlsPOCConstant.API_GET_ITEM_LIST, docGetItemListInput);
							logger.debug("getItemList API output is:\n"+XMLUtil.getXMLString(docGetItemListOutput));
							//Fix for defect 5301 - Start
							Element eleItemOut = (Element)docGetItemListOutput.getElementsByTagName("Item").item(0);
							if(!(YFCCommon.isVoid(eleItemOut))){
							//Fix for defect 5301 - End
								Element eleItemExtn = XMLUtil.getChildElement(eleItemOut, "Extn");
								eleExtn.setAttribute("ExtnItemDept", eleItemExtn.getAttribute("ExtnDept"));
							//	eleExtn.setAttribute("ExtnMdxTaxCode", eleItemExtn.getAttribute("ExtnMerchandiseTaxCode"));
								eleExtn.setAttribute("ExtnItemSubClass", eleItemExtn.getAttribute("ExtnSubClass"));
								eleExtn.setAttribute("ExtnItemClass", eleItemExtn.getAttribute("ExtnClass"));
								//eleExtn.setAttribute("ExtnVendorStyleNo", eleItemExtn.getAttribute("ExtnVendorStyleNo") );
                        eleExtn.setAttribute("ExtnVendorStyleNo", "0" );
								if(YFCCommon.isVoid(sExtnEmpDiscCode)) {
									Element eleReferences = null;
									eleReferences = XMLUtil.getChildElement(eleOrderLine, "References");
									if(YFCCommon.isVoid(eleReferences)){
										eleReferences = XMLUtil.createChild(eleOrderLine, "References");
									}
									Element eleOrderLineReference = XMLUtil.createChild(eleReferences, "Reference");
									eleOrderLineReference.setAttribute("Name", "ExtnEmpDiscCode");
									eleOrderLineReference.setAttribute("Value", eleItemExtn.getAttribute("ExtnEmpDiscCode"));
								}
								Element eleClassificationCodes = XMLUtil.getChildElement(eleItemOut, "ClassificationCodes");
								eleExtn.setAttribute("ExtnTaxProductCode", eleClassificationCodes.getAttribute("TaxProductCode"));
							}
						}
					//}
				
				}
			}
			logger.endTimer("KohlsPoCPnPUtil.updateExtnAttrsOnOrderLineFromItem");
		}

		/**Method getStatusCodeFromTVS
		 * Description: This method maps the status code text from TVS response
		 * to the 2 digit numeric code as required by downstream systems.
		 * @param sStatusText
		 * @throws Exception
		 */
		public static String getStatusCodeFromTVS (String sStatusText){
			logger.beginTimer("KohlsPoCPnPUtil.getStatusCodeFromTVS");
			String sStatusCode = "";
			if("Undefined".equalsIgnoreCase(sStatusText)){
				sStatusCode = "0";
			} else if("New".equalsIgnoreCase(sStatusText)){
				sStatusCode = "10";
			}else if("Active".equalsIgnoreCase(sStatusText)){
				sStatusCode = "20";
			}else if("Clearance".equalsIgnoreCase(sStatusText)){
				sStatusCode = "30";
			}else if("SpecialPurchase".equalsIgnoreCase(sStatusText)){
				sStatusCode = "40";
			}else if("Discontinued".equalsIgnoreCase(sStatusText)){
				sStatusCode = "90";
			}else if("Renumbered".equalsIgnoreCase(sStatusText)){
				sStatusCode = "99";
			}
			logger.endTimer("KohlsPoCPnPUtil.getStatusCodeFromTVS");
			return sStatusCode;
		}
		 /**Method getStatusCodeFromTVS
* Description: This method maps the status code text from TVS response
* to the 2 digit numeric code as required by downstream systems.
* @param sStatusText
* @throws Exception
*/
public static String getDiscLevelCodeFromTVS (String sdiscLevelCode){
logger.beginTimer("KohlsPoCPnPUtil.getDiscLevelCodeFromTVS");
String sDiscStatusCode = "";
if("LineItemDiscount".equalsIgnoreCase(sdiscLevelCode)){
sDiscStatusCode = "LID";
} else if("TransactionLevelDiscount".equalsIgnoreCase(sdiscLevelCode)){
sDiscStatusCode = "TLD";
}
logger.endTimer("KohlsPoCPnPUtil.getDiscLevelCodeFromTVS");
return sDiscStatusCode;
}

//Sudina - Change for TVS phase 2 - taxware - Start

/**
 * Summation of TaxRate, TaxAmount and TotalTax stamped in
 * .../OrderLine/Temp Element. It is used for Prepare the <TaxIndicators>
 * CLOB xml.
 *
 * @param lineTaxesEle
 * @param tempEle
 * @param set
 */
public static void addTaxDetailsFromTVSToTempElement(Element lineTaxesEle, Element tempEle, Set<Double> set) {
	logger.beginTimer("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement");
	//Performance improvement changes - Start
	if(logger.isDebugEnabled()){
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement: lineTaxesEle \n"+XMLUtil.getElementXMLString(lineTaxesEle));
	}
	//Performance improvement changes - End
	List<Element> lineTaxList = XMLUtil.getElementsByTagName(lineTaxesEle, KohlsPOCConstant.SMALL_ELEM_LINE_TAX);
	double totalTaxPerLine = KohlsPOCConstant.ZERO_DBL;
	double totalTaxRatePerLine = KohlsPOCConstant.ZERO_DBL;
	for (Element lineTaxEle : lineTaxList) {
		String sTax = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.SMALL_TAX);
		String sTaxPercent = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT);
		if(YFCCommon.isVoid(sTax)){
			sTax = "0.0";
		}
		if(YFCCommon.isVoid(sTaxPercent)){
			sTaxPercent = "0.0";
		}
		totalTaxPerLine = totalTaxPerLine + convertToDouble(sTax);
		totalTaxRatePerLine = totalTaxRatePerLine + convertToDouble(sTaxPercent);
	}
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement:  totalTaxPerLine "+totalTaxPerLine);
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement:  totalTaxRatePerLine "+totalTaxRatePerLine);
	totalTaxPerLine = Math.round(totalTaxPerLine*1000.0)/1000.0;
	totalTaxRatePerLine = Math.round(totalTaxRatePerLine*1000.0)/1000.0;
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement: After Math totalTaxPerLine "+totalTaxPerLine);
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement: After Math totalTaxRatePerLine "+totalTaxRatePerLine);
	DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
	twoDForm.setRoundingMode(RoundingMode.CEILING);
	XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_LINE_TOTAL_TAX, twoDForm.format(totalTaxPerLine));
	XMLUtil.setAttribute(tempEle, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, twoDForm.format(totalTaxRatePerLine));
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement: After rounding   totalTaxPerLine "+twoDForm.format(totalTaxPerLine));
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement: After rounding   totalTaxRatePerLine "+twoDForm.format(totalTaxRatePerLine));
	set.add(Double.valueOf(twoDForm.format(totalTaxRatePerLine)));
	//Performance improvement changes - Start
	if(logger.isDebugEnabled()){
	logger.debug("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement: tempEle at the end of the method \n"+XMLUtil.getElementXMLString(tempEle));
	}
	//Performance improvement changes - End
	logger.endTimer("KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement");
	}
//Sudina - Change for TVS phase 2 - taxware - End

	public static String getDouble(String s){
		DecimalFormat df = new DecimalFormat("####0.00");
		return df.format(Double.parseDouble(s));
	}
	
	//Changes for date ranges R3 Sprint 4 - Start
	 
	public static String getNoOfTLDsToBeAppliedWithDateRange(YFSEnvironment yfsEnv, String transTime) throws Exception
	{
		String strCodeValue = "1";
		Element eleCommonCode = null;
		//String [] delimited = transTime.split(KohlsPOCConstant.MINUS);
		//	String strBusinessDate=delimited[0].concat(delimited[1]).concat(delimited[2].substring(0, 2));
		String [] delimitedT = transTime.split("T");
		String [] delimitedMinus = delimitedT[0].split("-");
		String strTransactionDate = delimitedMinus[0].concat(delimitedMinus[1]).concat(delimitedMinus[2]);
		logger.debug("The Transaction Date value is: "+strTransactionDate);

		Document docInputForGetCommonCodeList = YFCDocument.createDocument(
				KohlsPOCConstant.E_COMMON_CODE).getDocument();
		Element eleInputForGetCommonCodeList = docInputForGetCommonCodeList.getDocumentElement();
		eleInputForGetCommonCodeList.setAttribute(KohlsPOCConstant.A_CODE_TYPE,KohlsPOCConstant.ASSOCIATE_NUM_OFFERS);
		eleInputForGetCommonCodeList.setAttribute(KohlsPOCConstant.A_ORG_CODE,KohlsPOCConstant. A_KOHLS_RETAIL);
		eleInputForGetCommonCodeList.setAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC, strTransactionDate);
		eleInputForGetCommonCodeList.setAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC_QRY_TYPE, KohlsPOCConstant.HD_LE);

		Element eleComplexQuery = XMLUtil.createChild(eleInputForGetCommonCodeList,
				KohlsPOCConstant.E_COMPLEX_QUERY);
		eleComplexQuery.setAttribute(KohlsPOCConstant.A_OPERATOR,KohlsPOCConstant.AND);
		//Internal defect fix for constant change.
		Element eleAnd= XMLUtil.createChild(eleComplexQuery, "And");

		Element CodeLongDescription = XMLUtil.createChild(eleAnd,KohlsPOCConstant.E_EXP);
		CodeLongDescription.setAttribute( KohlsPOCConstant.A_NAME,KohlsPOCConstant.A_CODE_LONG_DESC);
		CodeLongDescription.setAttribute(KohlsPOCConstant.A_QRY_TYPE,KohlsPOCConstant.HD_GE);
		CodeLongDescription.setAttribute(KohlsPOCConstant.A_VALUE , strTransactionDate);

		Document docOutputForGetCommonCodeList= KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.API_GET_COMMON_CODE_LIST, docInputForGetCommonCodeList);
		//Performance improvement changes - Start
		if(logger.isDebugEnabled()){
		logger.debug("Output of Common Code API :: " + XMLUtil.getXMLString(docOutputForGetCommonCodeList));
		}
		//Performance improvement changes - End
		if(!YFCCommon.isVoid(docOutputForGetCommonCodeList))

		{
			NodeList nlCommonCode = docOutputForGetCommonCodeList.getElementsByTagName(KohlsConstant.E_COMMON_CODE);
			if(nlCommonCode.getLength()>0){
				eleCommonCode = (Element) nlCommonCode.item(0);
				strCodeValue = eleCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);
				logger.debug("The No Of TLDs to be applied, returned from Config : "+strCodeValue);
			}else{
			logger.debug("The No Of TLDs to be applied is defaulted to 1");
		}

		}else{
			logger.debug("The No Of TLDs to be applied is defaulted to 1");
		}
		return strCodeValue;
	}
	//Changes for date ranges R3 Sprint 4 - End 
	
	//Fix for defect 3715 and 3722 - Start
	/**Method isLIDOffer
	* Description: This method returns true if the applied offer is LID, 
	* else false in case of TLD offer.
	* @param TVS response and TLD ID
	* @throws Exception
	*/
	public static boolean isLIDOffer (Element tvsResponseEle, String tldID){
	logger.beginTimer("KohlsPoCPnPUtil.isLIDOffer");
	boolean isLIDOffer = false;
	NodeList ndOffers = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_OFFER);
	if(!YFCCommon.isVoid(ndOffers) && ndOffers.getLength() > KohlsPOCConstant.ZERO_INT)
	{
		for(int k=0; k<ndOffers.getLength(); k++)
		{
			Element eleOffer = ((Element)ndOffers.item(k));
		
			if(!YFCCommon.isVoid(eleOffer) && (tldID.equals(eleOffer.getAttribute(KohlsPOCConstant.ATTR_OFFER_ID)))){
				String discountLevel = getDiscLevelCodeFromTVS(XMLUtil.getAttribute(eleOffer, "discountLevelCode"));
				if(!YFCCommon.isVoid(discountLevel) && discountLevel.equalsIgnoreCase("LID")){
					isLIDOffer = true;
				}
			}
		}
	}
	logger.debug("The isLIDOffer value returned is " +isLIDOffer);
	logger.endTimer("KohlsPoCPnPUtil.isLIDOffer");
	return isLIDOffer;
	}
	//Fix for defect 3715 and 3722 - End
	
	//Fix for defect 3715 and 3722 - Start
	public static String getTLDImpactValue(Element tvsResponseEle,
			String offerID) {
		logger.beginTimer("KohlsPoCPnPUtil.getTLDImpactValue");
		// Fix for NumberFormatException (JIRA: PST-39) - START
		NodeList tvsTldList = tvsResponseEle.getElementsByTagName("tld");
		//PDB-654 - Defaulting the value to 0.00
		String tldImpactValueNeg = "0.00";
		if (!YFCCommon.isVoid(tvsTldList) && tvsTldList.getLength() > KohlsPOCConstant.ZERO_INT) {
			for(int j=0; j<tvsTldList.getLength();j++){
				Element tvsTldEle = ((Element)tvsTldList.item(j));
				String tldID = XMLUtil.getAttribute(tvsTldEle, "id");
				if(offerID.equalsIgnoreCase(tldID)){
					String tldImpactValue = XMLUtil.getAttribute(tvsTldEle, "TLDImpact");
					tldImpactValueNeg = convertToNegative(tldImpactValue);
					logger.debug("The getTLDImpactValue value returned is without negative sign: "
					+ tldImpactValue
					+ "\nThe getTLDImpactValue value after converting to negative: "
					+ tldImpactValueNeg);					
				}
			}
		}
		logger.endTimer("KohlsPoCPnPUtil.getTLDImpactValue");
		return tldImpactValueNeg;
		// Fix for NumberFormatException (JIRA: PST-39) - END
	}
		//Fix for defect 3715 and 3722 - End
	

	/**
	 * This method updates the TVS Response document in case
	 * Tiered offers were applied in sale transaction
	 * 
	 * 
	 * @param docTVSInput
	 * @param eleResponseRoot
	 * @param TempOrderEle
	 */
	
	public static Element UpdateTVSResponsePSAForTieredOffers(Document docTVSInput , Element eleResponseRoot , Element TempOrderEle)
	{
		try
		{
			logger.beginTimer("KohlsPoCPnPUtil.UpdateTVSResponsePSAForTieredOffers");
			
			 HashMap<String,Element> M = new HashMap<String,Element>();
			 List<String> lstOfferListKeys = new ArrayList<String>();
			 HashSet<Element> modifierSet = new HashSet<Element>();
			 Element eleRequestRoot = docTVSInput.getDocumentElement();
			 //PST-2549 - Start
			 HashMap<String,Element> unAppliedOffersHM = new HashMap<String,Element>();
			 //PST-2549 - End
			 
			 String strTierLevel = null;
			 int ndllength = 0;
			 
			//Commenting as not required - #3529 - POC Returns Team - Start
			// Element eleBody = XMLUtil.getChildElement(eleRequestRoot, "env:Body");
			if( logger.isDebugEnabled() ) {
				logger.debug("Body element from Request is:::"+XMLUtil.getElementXMLString(eleRequestRoot));
				}
			
			Element eleOffers = (Element) XPathUtil.getNode(eleRequestRoot, "/adjustmentRequest/originalTransaction/offers"); 
                       	if(!YFCCommon.isVoid(eleOffers)){
            if( logger.isDebugEnabled() ) {
				logger.debug("Offer element from Request is ::"+XMLUtil.getElementXMLString(eleOffers));
				}
			
			List <Element> lstExistingOffers  = XMLUtil.getElementsByTagName(eleOffers, KohlsPOCConstant.EXISTING_OFFER);
			if( logger.isDebugEnabled() ) {
			logger.debug("Is the list empty???"+lstExistingOffers.isEmpty());
			}
			
			
			if (!lstExistingOffers.isEmpty()) {
				
				Element eleTLDList = (Element) XPathUtil.getNode(
						eleResponseRoot,
						"/adjustmentResponse/transaction/TLDList");
				if( logger.isDebugEnabled() ) {
				logger.debug("TLD List from Request is ::"
						+ XMLUtil.getElementXMLString(eleTLDList));
						}
				
				List<Element> lstTLD = XMLUtil.getElementsByTagName(eleTLDList,
						"tld");

				for (Element eleTLD : lstTLD) {
					logger.debug("Inside Double for loop for creating Map with matching keys");

					String strTLDId = eleTLD
							.getAttribute(KohlsPOCConstant.ATTR_ID);
					if( logger.isDebugEnabled() ) {
					logger.debug("Current TLD element is ::"
							+ XMLUtil.getElementXMLString(eleTLD));

					logger.debug("Current TLD Id is :::" + strTLDId);
					}

					for (Element eleExistingOffer : lstExistingOffers) {

						Element eleId = XMLUtil.getChildElement(
								eleExistingOffer, KohlsPOCConstant.ATTR_ID);
						if( logger.isDebugEnabled() ) {
						logger.debug("existing offer Element processed is:::"
								+ XMLUtil.getElementXMLString(eleId));
								}

						String strRequestId = XMLUtil.getNodeValue(eleId);
						if( logger.isDebugEnabled() ) {
						logger.debug("Id of the existing offer processed is:::"
								+ strRequestId);

						logger.debug("ExistingOffer from Request to compare is ::"
								+ XMLUtil.getElementXMLString(eleExistingOffer));
								}
						//PST-2549 - Start
						if (strRequestId.equalsIgnoreCase(strTLDId)) {
							logger.debug("Keys match : Entering Data into M Hash Map");
							M.put(strRequestId, eleExistingOffer);
							/*if(!unAppliedOffersHM.isEmpty() && unAppliedOffersHM.containsKey(strRequestId)){
								unAppliedOffersHM.remove(strRequestId);
							}*/
						}else{
							logger.debug("Keys mismatch : Entering Data into unAppliedOffersHM Map");
							/*if(!M.isEmpty() && !(M.containsKey(strRequestId))){
							unAppliedOffersHM.put(strRequestId, eleExistingOffer);
							}else{
								logger.debug("Keys Offer is already added in Map");
							}*/
							unAppliedOffersHM.put(strRequestId, eleExistingOffer);
						}
						
					}
				}
				if(!unAppliedOffersHM.isEmpty()){
					Iterator<Entry<String, Element>> itrUnappliedOffers = unAppliedOffersHM.entrySet().iterator();
					//for(Map.Entry<String, Element> unAppliedOffer : unAppliedOffersHM.entrySet())	
					while(itrUnappliedOffers.hasNext())
					{
						Entry<String, Element> entry = itrUnappliedOffers.next();
						String strKey = entry.getKey();
						if(!M.isEmpty() && (M.containsKey(strKey))) {
							//unAppliedOffersHM.remove(strKey);
							itrUnappliedOffers.remove();
							logger.debug("Inside iteration for creating missing element in Offerlist from unAppliedOffersHM");
						}

						else{
						Element unAppliedOfeferTLD = XMLUtil.createChild(eleTLDList, "tld");
						XMLUtil.setAttribute(unAppliedOfeferTLD, KohlsPOCConstant.ATTR_ID, strKey);
						XMLUtil.setAttribute(unAppliedOfeferTLD, KohlsPOCConstant.TLD_IMPACT, "-0.00");
						if( logger.isDebugEnabled() ) {
							logger.debug("eleTLDList after adding missing TLD is ::" + XMLUtil.getElementXMLString(eleTLDList));
									}
						M.put(strKey, entry.getValue());
						logger.debug("Size of M HashMap" +M.size());
						}
					}
				}
				//PST-2549 - End
			NodeList ndlOffers = XPathUtil.getNodeList(eleResponseRoot,"/adjustmentResponse/transaction/offerList/offer");
			ndllength = ndlOffers.getLength();
			
			Element eleOfferList = (Element) XPathUtil.getNode(eleResponseRoot,"/adjustmentResponse/transaction/offerList");
			if( logger.isDebugEnabled() ) {
				logger.debug("OfferList element from Response is"+XMLUtil.getElementXMLString(eleOfferList));
			}
			
			for(int i = 0 ; i<ndllength;i++)
			{
				logger.debug("Inside iteration for preparing list with ID's of OfferList child elements -- BEGIN");
				Element eleCurrentOffer = (Element) ndlOffers.item(i);
				String strKey = eleCurrentOffer.getAttribute(KohlsPOCConstant.A_ID);
				 lstOfferListKeys.add(i, strKey);
				 if( logger.isDebugEnabled() ) {
				 	logger.debug("Inside iteration for preparing list with ID's of OfferList child elements -- END");
				 }
			}
			
			
			
			NodeList ndlItems = XPathUtil.getNodeList(eleResponseRoot,"/adjustmentResponse/transaction/itemList/item");
			
			if(!YFCCommon.isVoid(ndlItems))
			{
				int no_of_items = ndlItems.getLength();
				
					for(int i=0;i<no_of_items;i++)
						{
							Element eleCurrentItem = (Element) ndlItems.item(i);
							logger.debug("Current Item is "+XMLUtil.getElementXMLString(eleCurrentItem));
							
							NodeList ndlModifiers = XPathUtil.getNodeList(eleCurrentItem,"modifierList/modifier");
							
							if(!YFCCommon.isVoid(ndlModifiers))
							{
								int ndlModifierLength = ndlModifiers.getLength();
								
						for (int j = 0; j < ndlModifierLength; j++) {
							Element eleCurrentModifier = (Element) ndlModifiers
									.item(j);
							if( logger.isDebugEnabled() ) {
							logger.debug("Adding Element in ModifierSet::"
									+ XMLUtil
											.getElementXMLString(eleCurrentModifier));
							}
							modifierSet.add(eleCurrentModifier);

						}
							}
							
							
						}
			}
			
			if( logger.isDebugEnabled() ) {
				logger.debug("Is the set of Unique modifiers empty:::"+modifierSet.isEmpty());	
			}
		
			
			for(Map.Entry<String, Element> map : M.entrySet())	
			{
				if( logger.isDebugEnabled() ) {
					logger.debug("Inside iteration for creating missing element in Offerlist -- BEGIN");
				}
				
				String strKey = map.getKey();
				
				Element elecurrent = map.getValue();
				if( logger.isDebugEnabled() ) {
					logger.debug("Current Element in Map is :::"+XMLUtil.getElementXMLString(elecurrent));
				}
				
				String strSchemeCode = XMLUtil.getNodeValue(XMLUtil.getChildElement(elecurrent, "schemeCode"));
				
				String strOfferId = XMLUtil.getNodeValue(XMLUtil.getChildElement(elecurrent,KohlsPOCConstant.ATTR_ID ));
				
				String PercentOffValue = XMLUtil.getNodeValue(XMLUtil.getChildElement(XMLUtil.getChildElement(elecurrent,KohlsPOCConstant.GET_CRITERIA),KohlsPOCConstant.GET_PERCENT));
								 
				Float getPercentOff = Float.parseFloat(PercentOffValue)/KohlsPOCConstant.HUNDRED_INT;

					
				for(Element eleModifier : modifierSet)
					{
					if( logger.isDebugEnabled() ) {
						logger.debug("Iteration for ModifierSet collection");
					}
						
						String strModiferId = eleModifier.getAttribute("parentDiscountId");
						
						logger.debug("Current Parent Discount Id for Modifier Element is :::"+strModiferId);
						
						if(strModiferId.equalsIgnoreCase(strOfferId))
						{
							strTierLevel = eleModifier.getAttribute("tierLevelAchieved");
							if( logger.isDebugEnabled() ) {
								logger.debug("Value of tierLevelAchieved is ::"+strTierLevel);
							}
						}
					}
				
				
				if(!lstOfferListKeys.contains(strKey))
					{
						
						if( logger.isDebugEnabled() ) {	
							logger.debug("Inside Element creation");
						}
						
						Element eleNewOffer = XMLUtil.createChild(eleOfferList, "offer");
						
						eleNewOffer.setAttribute("discountLevelCode","TransactionLevelDiscount");
						eleNewOffer.setAttribute("offerId",strOfferId);
						eleNewOffer.setAttribute("id",strOfferId);
						eleNewOffer.setAttribute("promoSchemeCode",strSchemeCode);
						eleNewOffer.setAttribute("customerFacingShortDescription","ADJUSTED % OFF OFFER");
						//PR-1048 - Start
						//eleNewOffer.setAttribute("benefitWithPurchaseGetPercentOffPercent",getPercentOff.toString());
						eleNewOffer.setAttribute("benefitWithPurchaseGetPercentOffPercent",PercentOffValue);  
						if(!YFCCommon.isVoid(strTierLevel)){
						eleNewOffer.setAttribute("tierLevelNumber",strTierLevel);
						}
						else{
							eleNewOffer.setAttribute("tierLevelNumber",KohlsPOCConstant.ZERO);
						}
						//PR-1048 - End
						eleNewOffer.setAttribute("benefitWithPurchaseSelectionTypeCode",KohlsPOCConstant.GET);
						//PST-2549 - Start
						if(!unAppliedOffersHM.isEmpty() && unAppliedOffersHM.containsKey(strKey)){
							eleNewOffer.setAttribute("IsSaleOfferNotApplied", KohlsPOCConstant.YES);
						}
						//PST-2549 - End
						if( logger.isDebugEnabled() ) {
							logger.debug("Newly Created Element is ::"+XMLUtil.getElementXMLString(eleNewOffer));
						}
					}
				if( logger.isDebugEnabled() ) {
					logger.debug("Inside iteration for creating missing element in Offerlist -- END");
				}
				
			}
			
			
			logger.endTimer("KohlsPoCPnPUtil.UpdateTVSResponsePSAForTieredOffers");
			
			}	
		}
		}
		catch(Exception e)
		{
			// To be replaced by the verbose of the the logger object 
			logger.error(e);
		}
		return eleResponseRoot;
		
	}

	
	/**
	 * 
	 * @param amount
	 * @return
	 */
	public static double convertToDouble(String amount) {
		
		double convertedAmount = 0.00;
		try {
			convertedAmount= Double.valueOf(amount);
		} catch (Exception e) {
			if( logger.isDebugEnabled() ) {
				logger.debug("@@@@convertToDouble Exception ::"+ amount);
				e.printStackTrace();
			}
		}
		
		return convertedAmount;
	}
	
	/**
	 * This method is to determine if the promotionID is SUPC or not
	 * @param promotionId
	 * @return
	 */
	public static boolean isSUPC(String promoId) {
		boolean isSUPC = false;
		if (promoId != null && promoId.length() == 13) {
			if (StringUtils.isAlphanumeric(promoId))
				isSUPC = true;
		}
		return isSUPC;
	}
	/**
	 * Create By Supradeep * 
	 * @param eleItem
	 */
	public static void consolidateLineTaxes(Element eleItem) {

		logger.beginTimer("KohlsPoCPnPUtil.consolidateLineTaxes");
		// MJ 09/18 Consolidate the taxes only if its not already consolidated..
		if(YFCCommon.isVoid(XMLUtil.getChildElement(eleItem, KohlsPOCConstant.ELEM_LINE_TAXES))){
		  Element elelineTaxes = XMLUtil.createChild(eleItem, KohlsPOCConstant.ELEM_LINE_TAXES);
	        List<Element> nlTax = XMLUtil.getElementsByTagName(eleItem, (KohlsPOCConstant.ELEM_LINE_TAX));
	        double totalTaxPerLine = KohlsPOCConstant.ZERO_DBL;
	         double totalTaxRatePerLine = KohlsPOCConstant.ZERO_DBL;
	         double dBasisAmt = 0.00;
	         if(!YFCCommon.isVoid(nlTax))
	         {
	             for(Element eleTax : nlTax)
	             {
	                 String sTax = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.SMALL_TAX);
	                 String sTaxPercent = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT);
	                 if(YFCCommon.isVoid(sTax)){
	                    sTax = "0.0";
	                 }
	                 if(YFCCommon.isVoid(sTaxPercent)){
	                     sTaxPercent = "0.0";
	                 }
	                 totalTaxPerLine = totalTaxPerLine + Double.valueOf(sTax);
	                 totalTaxRatePerLine = totalTaxRatePerLine + Double.valueOf(sTaxPercent);
	                 eleItem.removeChild(eleTax);
	                 // CPE-213 persisting TaxBasis amt from TVS
	                 String sTaxBasis = XMLUtil.getAttribute(eleTax, KohlsPOCConstant.TAX_BASIS);
	                 try {
    	                 if (!YFCCommon.isVoid(sTaxBasis) && Double.parseDouble(sTaxBasis) > dBasisAmt) {
    	                   dBasisAmt = Double.parseDouble(sTaxBasis);    	                   
    	                 }
	                 }
	                 catch (Exception e) {
	                   logger.error("Error occured while coputing taxBasis amt. Continuing transaction");
	                 }
	             }
	             totalTaxPerLine = Math.round(totalTaxPerLine*1000.0)/1000.0;
	             totalTaxRatePerLine = Math.round(totalTaxRatePerLine*1000.0)/1000.0;
	             logger.debug("After Math   totalTaxPerLine "+totalTaxPerLine);
	             logger.debug("After Math totalTaxRatePerLine "+totalTaxRatePerLine);
	             DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
	             twoDForm.setRoundingMode(RoundingMode.CEILING);
	             Element eleTaxNew = XMLUtil.createChild(elelineTaxes, KohlsPOCConstant.ELEM_LINE_TAX);
	             XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX, twoDForm.format(totalTaxPerLine));
	             XMLUtil.setAttribute(eleTaxNew, KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, totalTaxRatePerLine+"");
	             logger.debug("After rounding   totalTaxPerLine "+twoDForm.format(totalTaxPerLine));
	             logger.debug("After rounding   totalTaxRatePerLine "+totalTaxRatePerLine);
	             eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
	             eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
	             eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX, twoDForm.format(totalTaxPerLine));
	             eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, String.valueOf(totalTaxRatePerLine));
	             eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax");
	             eleTaxNew.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
	             if(dBasisAmt > 0) {
	               Element eleTaxExtn = XMLUtil.createChild(eleTaxNew, KohlsPOCConstant.E_EXTN);
	               eleTaxExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, new DecimalFormat("#0.00").format(dBasisAmt));
	             }
	         }
	         if (logger.isDebugEnabled()) {
	                logger.debug("LineTax consolidated:: " + XMLUtil.getElementXMLString(eleItem));
	         }
		  }
		 logger.endTimer("KohlsPoCPnPUtil.consolidateLineTaxes");
	}
	
	//CPE-6061, 4384, 4385
	public static boolean isSaleTLDPromotion (Element promotionEle){
		logger.beginTimer("KohlsPoCPnPUtil.isSalePromotion");
		boolean isSaleTLDPromo = false;
		Double absOverrideAdjustmentValue = 0.0;
		Element prmotionExtnEle =XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		String overrideAdjustmentValue = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
		String extnIsPSAPromotion = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.ISPSAPROMOTION);
		String extnPromotionFlag = XMLUtil.getAttribute(prmotionExtnEle, KohlsPOCConstant.A_EXTN_PROMOTION_FLAG);
		
		absOverrideAdjustmentValue = Math.abs(Double.valueOf(overrideAdjustmentValue));
		
		logger.debug("The Key attribute value returned is " +overrideAdjustmentValue+","+extnIsPSAPromotion+","+extnPromotionFlag+","+absOverrideAdjustmentValue);
		
		if(!YFCCommon.isVoid(overrideAdjustmentValue) && absOverrideAdjustmentValue > KohlsPOCConstant.ZERO_DBL && 
				!YFCCommon.isVoid(extnPromotionFlag) && YFCCommon.isVoid(extnIsPSAPromotion))
		{
			return isSaleTLDPromo=true;
		}
		logger.debug("The isSaleTLDPromo value returned is " +isSaleTLDPromo);
		logger.endTimer("KohlsPoCPnPUtil.isSalePromotion");
		return isSaleTLDPromo;
		}
	
	
    /**Method constructExclusionsForRefundDeduction
     * Description This method prepares the exclusion list for refund deduction
     * @param yfsEnv
     * @param transactionEle
     * @throws Exception
     * @throws ParseException
     */
    public static void constructExclusionsForRefundDeduction (YFSEnvironment yfsEnv, Element transactionEle)
            throws Exception, ParseException {
        logger.beginTimer("KohlsPoCPnPUtil.constructExclusionsForRefundDeduction");
        Date currentDate = new Date ();
        SimpleDateFormat sdf = new SimpleDateFormat ("MMddyyyy");
        String sFormattedDate = sdf.format(currentDate);
        Element eleExclusions = XMLUtil.createChild(transactionEle, "exclusions");
        NodeList nlItem = transactionEle.getElementsByTagName("item");
        for (int i=0; i<nlItem.getLength(); i++) {
          Element eleItem = (Element)nlItem.item(i);
          Element eleSku = XMLUtil.getChildElement(eleItem, "sku");
          String sSku = eleSku.getTextContent();
          Element eleExclusion = XMLUtil.createChild(eleExclusions, "exclusion");
          eleExclusion.setTextContent(sFormattedDate+"|SKU|"+sSku);
        }
        if(logger.isDebugEnabled()) {
          logger.debug("After exclusion added: "+XMLUtil.getElementXMLString(transactionEle));
        }
        logger.endTimer("KohlsPoCPnPUtil.constructExclusionsForRefundDeduction");
    }
    
    /**Overloading Method constructExclusionsForRefundDeduction to read strTransactionTime from parameters
     * Description This method prepares the exclusion list for refund deduction
     * @param yfsEnv
     * @param transactionEle
     * @param strTransactionTime
     * @throws Exception
     * @throws ParseException
     */
    public static void constructExclusionsForRefundDeduction (YFSEnvironment yfsEnv, Element transactionEle, String strTransactionTime)
    		throws Exception, ParseException {
    	logger.beginTimer("KohlsPoCPnPUtil.constructExclusionsForRefundDeduction");
    	String sFormattedDate = "";
    	SimpleDateFormat sdf = new SimpleDateFormat (KohlsPOCConstant.INV_DATE_FORMAT);
    	SimpleDateFormat sdf1 = new SimpleDateFormat ("MMddyyyy");
    	if(!YFCCommon.isVoid(strTransactionTime)) {
    		sFormattedDate = sdf1.format(sdf.parse(strTransactionTime));
    		logger.debug("sFormattedDate: "+ sFormattedDate);
    	}
    	else {
    		logger.debug("strTransactionTime is empty setting to sysdate ");
    		Date currentDate = new Date ();
    		sFormattedDate = sdf.format(currentDate);
    	}
    	Element eleExclusions = XMLUtil.createChild(transactionEle, "exclusions");
    	NodeList nlItem = transactionEle.getElementsByTagName("item");
    	for (int i=0; i<nlItem.getLength(); i++) {
    		Element eleItem = (Element)nlItem.item(i);
    		Element eleSku = XMLUtil.getChildElement(eleItem, "sku");
    		String sSku = eleSku.getTextContent();
    		Element eleExclusion = XMLUtil.createChild(eleExclusions, "exclusion");
    		eleExclusion.setTextContent(sFormattedDate+"|SKU|"+sSku);
    	}
    	if(logger.isDebugEnabled()) {
    		logger.debug("After exclusion added: "+XMLUtil.getElementXMLString(transactionEle));
    	}
    	logger.endTimer("KohlsPoCPnPUtil.constructExclusionsForRefundDeduction");
    }
    
    
    /**
     * Used to create LineCharge and Award element at OrderLine level for TaxFee details.
     * @param ndFeeList
     * @param orderLineEle
     * @param sign
     * @return
     */
    public static String updateFeeDetails(List<Element> ndFeeList, Element orderLineEle,String sign,HashMap<String,String> sOrigFee, HashMap <String, Double> mapFeePromotion) {
    	logger.beginTimer("KohlsPoCPnPUtil.updateFeeDetails");
    	String strPrimeLineNo = XMLUtil.getAttribute(orderLineEle, KohlsPOCConstant.ATTR_PRIME_LINE_NO);
    	Element eleLineCharges = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES, true);
    	Element eleAwards = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_AWARDS, true);
    	Element eleCustomAttributes = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES, true);
    	String strText11 = "";
    	if(!YFCCommon.isVoid(eleCustomAttributes)){
    		strText11 = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.TEXT11);
    	}
    		
    	double dOrigFee=0;
    	if(YFCCommon.isVoid(sOrigFee)){
    		dOrigFee =-1;
    	}
    	if(YFCCommon.isVoid(eleLineCharges)){
    		eleLineCharges = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_CHARGES);
    	}
    	if(YFCCommon.isVoid(eleAwards)){
    		eleAwards = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.E_AWARDS);
    	}
    	Element eleLineTaxes = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
    	if(YFCCommon.isVoid(eleLineTaxes)){
    		eleLineTaxes = XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
    	}
    	double dTotalTaxAmount=0;
    	double dFeeRate=0;
    	int iSeqno = Integer.parseInt(KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE);
    	if (ndFeeList.size() > KohlsPOCConstant.ZERO_INT) {
    		for (int i=0; i<ndFeeList.size(); i++) {
    			Element eleFees = (Element) ndFeeList.get(i);
    			String sCalcAmount = eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
    			if(sCalcAmount.isEmpty()){
    				sCalcAmount =KohlsPOCConstant.ZERO;
    			}
    			double dCalcAmount = Double.parseDouble(sCalcAmount);
    			if( !YFCCommon.isVoid(sOrigFee) || dCalcAmount>0 ){
    				String sFeeID = XMLUtil.getAttribute(eleFees,KohlsPOCConstant.SMALL_ATTR_FEE_ID);
    				String sRate = XMLUtil.getAttribute(eleFees,KohlsPOCConstant.SMALL_ATTR_RATE_FEE);
    				if(!YFCCommon.isVoid(sRate)){
    					dFeeRate = Double.parseDouble(sRate);
    				}

    				if(sCalcAmount.isEmpty()){
    					sCalcAmount =KohlsPOCConstant.ZERO;
    				}
    				dTotalTaxAmount = dTotalTaxAmount + dCalcAmount;
    				double dChangeFee= Double.parseDouble(eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
    				Element lineChargeEle = XMLUtil.createChild(eleLineCharges, KohlsPOCConstant.ELEM_LINE_CHARGE);
    				XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY,KohlsPOCConstant.CONST_FEE);
    				XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.ATTR_CHARGE_NAME, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
    				XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_CHARGE_PER_LINE, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
    				XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_BILLABLE, KohlsPOCConstant.YES);
    				if(sign.equalsIgnoreCase("-")){
    					XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.NO);
    				} else{
    					XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.A_IS_DISCOUNT, KohlsPOCConstant.YES);
    				}
    				XMLUtil.setAttribute(lineChargeEle, KohlsPOCConstant.Reference, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));

    				Element lineChargeExtnEle = XMLUtil.getChildElement(lineChargeEle, KohlsPOCConstant.E_EXTN, true);
    				XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_FEE_ID, sFeeID);
    				XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_BASIS_AMOUNT));
    				XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_EXEMPT_AMOUNT, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_EXEMPT_AMOUNT));
    				XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_RATE_FEE));
    				XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.ATTR_EXTN_COMPLETION_CODE, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_COMPLETION_CODE));
    				XMLUtil.setAttribute(lineChargeExtnEle, KohlsPOCConstant.Extn_Is_Fee_Taxable, eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_IS_TAXABLE));
    				if(YFCCommon.isVoid(sOrigFee) && !KohlsPOCConstant.A_ELIGIBLE.equalsIgnoreCase(strText11)){
    					XMLUtil.setAttribute(lineChargeExtnEle, "ExtnOrigChgPerLine",eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
    				}
    				Element awardEle = XMLUtil.createChild(eleAwards, KohlsPOCConstant.E_AWARD);
    				Element awardExtEle = XMLUtil.createChild(awardEle, KohlsPOCConstant.E_EXTN);
    				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_ID, UUID.randomUUID().toString());
    				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_APPLIED, KohlsPOCConstant.YES);
    				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.ATTR_CHARGE_CATEGORY,KohlsPOCConstant.CONST_FEE);
    				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.ATTR_CHARGE_NAME, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
    				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_DESCRIPTION, eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
    				XMLUtil.setAttribute(awardEle, KohlsPOCConstant.PROMOTIONID, KohlsPOCConstant.CONST_FEE+"_"+sFeeID);
    				DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
    				if(dOrigFee > -1){
    					String sSaleFee = sOrigFee.get(KohlsPOCConstant.CONST_FEE+"_"+sFeeID);
    					if(YFCCommon.isVoid(sSaleFee)){
    						sSaleFee = KohlsPOCConstant.ZERO;
    					}
    					dOrigFee = Math.abs(Double.parseDouble(sSaleFee));
    					//dChangeFee = dOrigFee - dChangeFee;
    					XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.ATTR_EXTN_SALE_PRICE,twoDForm.format(dOrigFee));
    				}else{
    					XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.ATTR_EXTN_SALE_PRICE,sign+twoDForm.format(dChangeFee));
    				}
    				//XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_NET_DELTA,eleFees.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
    				if(sign.equalsIgnoreCase("-")){
    					XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, twoDForm.format(-1* dChangeFee));
    				} else{
    					XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_AWARD_AMOUNT, twoDForm.format(Math.abs(dChangeFee)));
    				}
    				// Populate the hashmap for PSA Fee promotion
    				if(!YFCCommon.isVoid(mapFeePromotion)) {
                      if(mapFeePromotion.containsKey(KohlsPOCConstant.CONST_FEE+"_"+sFeeID)) {
                        Double dOverrideAdjValue = mapFeePromotion.get(KohlsPOCConstant.CONST_FEE+"_"+sFeeID);
                        mapFeePromotion.put(KohlsPOCConstant.CONST_FEE+"_"+sFeeID, dOverrideAdjValue + dOrigFee - dChangeFee);
                      } else {
                        mapFeePromotion.put(KohlsPOCConstant.CONST_FEE+"_"+sFeeID, dOrigFee - dChangeFee);
                      }
                      XMLUtil.setAttribute(awardEle, KohlsPOCConstant.A_IS_PROMOTION_ON_ORDER, KohlsPOCConstant.YES);
                      XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_TAX_DELTA, twoDForm.format(-1* dChangeFee));
                      XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_NET_DELTA, twoDForm.format(-1* dChangeFee));
                    }
    				XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.EXTN_AWARD_RECEIPT_DESC,eleFees.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION));
    				XMLUtil.setAttribute(awardExtEle, KohlsPOCConstant.A_EXTN_AWARD_SEQUENCE, ""+iSeqno++);
    			}
    		}

    	}
    	logger.endTimer("KohlsPoCPnPUtil.updateFeeDetails");
    	return dTotalTaxAmount+"_"+dFeeRate+"";
    }

    /**
     * Used to create TaxFee promotion for displaying Adj Tax Fee in UI
     * @param tempOrderEle
     * @param strPSAAdjFeeTaxAmt
     * @throws Exception 
     */
    public static void updateFeePromotionDetailsForPSA(Element tempOrderEle, String strPSAAdjFeeTaxAmt, HashMap <String, Double> mapFeePromotion) throws Exception {
    	logger.beginTimer("KohlsPoCPnPUtil.updateFeePromotionDetailsForPSA");
    	Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);

    	NodeList nlPromotion  = promotionsEle.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
    	boolean bPromotionExists = false;
    	if(!YFCCommon.isVoid(mapFeePromotion) && !mapFeePromotion.isEmpty()) {
    	  int loopCounter = 0;
    	  for(String key : mapFeePromotion.keySet()) {
    	    loopCounter++;
    	    String sPromotionID = key;
    	    Element elePromotion = (Element)XPathUtil.getNode(tempOrderEle, "//Order/Promotions/Promotion[@PromotionId='"+sPromotionID+"']");
    	    if(!YFCCommon.isVoid(elePromotion)) {
    	      XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_MODIFY);
              XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, new DecimalFormat("#0.00").format(-1 * mapFeePromotion.get(sPromotionID)));
              XMLUtil.setAttribute(elePromotion, KohlsPOCConstant.A_DESCRIPTION, KohlsPOCConstant.AdjTaxFee);
              Element promotionExtEle = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.E_EXTN, true);
              XMLUtil.setAttribute(elePromotion, "IsExternal", KohlsPOCConstant.YES);
              XMLUtil.setAttribute(elePromotion, "PromotionGroup", "MANUAL");
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_EXTN_PRECEDENCE_NUMBER,KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE);
              XMLUtil.setAttribute(promotionExtEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE, String.valueOf(Integer.parseInt(KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE) + loopCounter));
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE,  String.valueOf(Integer.parseInt(KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE)));
    	    } else {
    	      Element promotionEle =  XMLUtil.createChild(promotionsEle, KohlsPOCConstant.E_PROMOTION);
              Element promotionExtEle = XMLUtil.createChild(promotionEle, KohlsPOCConstant.E_EXTN);
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.ACTION, KohlsPOCConstant.ACTION_CREATE);
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID, sPromotionID);
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.TAXWARE_FEE);
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE, new DecimalFormat("#0.00").format(-1 * mapFeePromotion.get(sPromotionID)));
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_DESCRIPTION, KohlsPOCConstant.AdjTaxFee);
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_AWARD_AMOUNT, new DecimalFormat("#0.00").format(mapFeePromotion.get(sPromotionID)));
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.ISPSAPROMOTION,KohlsPOCConstant.YES);
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_EXTN_PROMO_SEQUENCE, String.valueOf(Integer.parseInt(KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE) + loopCounter));
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE);
              XMLUtil.setAttribute(promotionEle, "IsExternal", KohlsPOCConstant.YES);
              XMLUtil.setAttribute(promotionEle, "PromotionGroup", "MANUAL");
              XMLUtil.setAttribute(promotionExtEle,KohlsPOCConstant.A_EXTN_PROMOTION_FLAG, KohlsPOCConstant.YES);
              XMLUtil.setAttribute(promotionExtEle, KohlsPOCConstant.A_EXTN_PRECEDENCE_NUMBER,KohlsPOCConstant.TAX_FEE_AWARD_SEQUENCE);
    	    }
    	  }
    	}
    	logger.endTimer("KohlsPoCPnPUtil.updateFeePromotionDetailsForPSA");
    }

    /**
     * Used to identify only the Rate Based Fee for PSA
     * @param strLineFeeAmountRate
     * @return dLineFeeAmount
     * @throws NumberFormatException
     */
    public static double getRateBasedLineTaxFeeAmount(String strLineFeeAmountRate){
    	logger.beginTimer("KohlsPoCPnPUtil.getRateBasedLineTaxFeeAmount");
    	double dLineFeeAmount = KohlsPOCConstant.ZERO_DBL;

    	try{
    		if(!YFCCommon.isVoid(strLineFeeAmountRate) && strLineFeeAmountRate.contains(KohlsPOCConstant.UNDERSCORE)){
    			String[] delitUnderScore = strLineFeeAmountRate.split(KohlsPOCConstant.UNDERSCORE);
    			String strLineFeeAmount = delitUnderScore[0];
    			String strLineFeeRate = delitUnderScore[1];
    			if(!YFCCommon.isVoid(strLineFeeAmount) && !YFCCommon.isVoid(strLineFeeRate)){
    				double dblLineFeeRate = Double.valueOf(strLineFeeRate);
    				if(dblLineFeeRate>0){
    					dLineFeeAmount = Double.valueOf(strLineFeeAmount);
    				}
    			}
    		}
    	}catch (Exception e){
    		logger.debug("Exception while getting dLineFeeAmount");
    	}
    	logger.endTimer("KohlsPoCPnPUtil.getRateBasedLineTaxFeeAmount");
    	return dLineFeeAmount;
    }
    /** Updates the Fee details based on KC Deactivation TVS call response
     * @param eleOrderLine
     * @param tvsResponseEle
     * Updated Line Charges and Line Awards from TVS response
     */
    public static void updateKCDTaxFee(Element eleOrderLine, Element tvsResponseItemEle, String tranxType, String sign) {
        logger.beginTimer("KohlsPoCPnPUtil.updateKCDTaxFee");
        Element eleOrderLineCharges = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES, true);
        Element eleOrderLineAwards = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_AWARDS, true);

        //Loops through Fee from TVS output and update LineCharges and Awards
        NodeList nlFee = tvsResponseItemEle.getElementsByTagName(KohlsPOCConstant.SMALL_ATTR_FEES);
        if (!YFCCommon.isVoid(nlFee)) {
            boolean bChargeExists = false;
            for (int index = 0; index < nlFee.getLength(); index++) {
            	Element eleFee = (Element) nlFee.item(index);
            	//Update Line Charges
            	if(!YFCCommon.isVoid(eleOrderLineCharges)){
            		NodeList nlCharges  = eleOrderLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE);
            		if(!YFCCommon.isVoid(nlCharges) && nlCharges.getLength()>0){
            			for (int iCharge = 0; iCharge < nlCharges.getLength(); iCharge++) {
            				Element eleCharge = (Element) nlCharges.item(iCharge);
            				if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))
            						&& eleFee.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION).equalsIgnoreCase(eleCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME))){
            					
            					String sFeeAmt = eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT);
            					Element eleChargeExtn = XMLUtil.getChildElement(eleCharge, KohlsPOCConstant.E_EXTN);
            					if((KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(tranxType) /*|| 
            							KohlsPOCConstant.ATTR_PSA.equalsIgnoreCase(tranxType)*/)&& !YFCCommon.isVoid(sFeeAmt)){
            						DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
            						sFeeAmt = twoDForm.format(Double.parseDouble(eleChargeExtn.getAttribute("ExtnOrigChgPerLine"))- Double.parseDouble(sFeeAmt));
            					
            					}
            					eleChargeExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_BASIS_AMOUNT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_BASIS_AMOUNT));
            					eleChargeExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_EXEMPT_AMOUNT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_EXEMPT_AMOUNT));
            					eleChargeExtn.setAttribute(KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_RATE_FEE));
                				eleCharge.setAttribute( KohlsPOCConstant.A_CHARGE_PER_LINE, sFeeAmt);
            					eleCharge.setAttribute( KohlsPOCConstant.ATTR_CHARGE_AMNT, sFeeAmt);
            					eleCharge.setAttribute( "InvoicedChargeAmount", sFeeAmt);
            					bChargeExists = true;
            				}
            			}
            		}
            	}
            	if(!YFCCommon.isVoid(eleOrderLineAwards)){
            		NodeList nlAwards  = eleOrderLineAwards.getElementsByTagName(KohlsPOCConstant.E_AWARD);
            		if(!YFCCommon.isVoid(nlAwards) && nlAwards.getLength()>0){
            			for (int iAward = 0; iAward < nlAwards.getLength(); iAward++) {
            				Element eleAward = (Element) nlAwards.item(iAward);
            				if(KohlsPOCConstant.CONST_FEE.equalsIgnoreCase(eleAward.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))
            						&& eleFee.getAttribute(KohlsPOCConstant.SMALL_SHORT_DESCRIPTION).equalsIgnoreCase(eleAward.getAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY))){
            					eleAward.setAttribute(KohlsPOCConstant.A_AWARD_AMOUNT, "-"+eleFee.getAttribute(KohlsPOCConstant.SMALL_ATTR_CAL_AMT));
            				}
            			}
            		}
            	}
            	if(!bChargeExists){
            		List<Element> nlCurretnFee = new ArrayList<Element>();
            		nlCurretnFee.add(eleFee);
            		KohlsPoCPnPUtil.updateFeeDetails(nlCurretnFee, eleOrderLine,sign,null, null);
            	}
            }
        }
        logger.endTimer("KohlsPoCPnPUtil.updateKCDTaxFee");
    }
}
