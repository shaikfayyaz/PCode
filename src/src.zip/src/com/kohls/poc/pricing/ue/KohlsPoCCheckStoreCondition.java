package com.kohls.poc.pricing.ue;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.api.KohlsPocInventoryUpdatesToGIV;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;


/**
 * This Class checks whether the Store is TVS or PLU Store, by setting the 
 * "Extn_Is_TVS_Store" attribute as Y or N, respectively, 
 * at order level in the Gravity input document. This is done by calling the 
 * getCommonCodeList with CodeValue as "StoreNumber" and CodeType as "CHECK_STORE".
 * 
 * @param env
 * @param inputDoc
 * @return 
 * @exception Exception
 * 
 */
public class KohlsPoCCheckStoreCondition extends KOHLSBaseApi {
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPocInventoryUpdatesToGIV.class.getName());

	public Document checkStoreForTVS(YFSEnvironment env,
			Document inDoc) throws Exception {


		logger.beginTimer("KohlsPoCCheckStoreCondition.checkStoreForTVS");
		Element tempOrderEle = null;
		Document docOutputForGetCommonCodeList = null;
		String codeValue = null;
		String strOrganizationCode = null;
		try{

			tempOrderEle = inDoc.getDocumentElement();
			codeValue = XMLUtil.getAttribute(tempOrderEle, KohlsConstant.A_SELLER_ORGANIZATION_CODE);
			strOrganizationCode = XMLUtil.getAttribute(tempOrderEle, KohlsConstant.A_ENTERPRISE_CODE);
			logger.debug("The codeValue and strOrganizationCode value are "+ codeValue, strOrganizationCode);
			if(!YFCCommon.isVoid(codeValue) && !(codeValue==null)){
				Document docInputForGetCommonCodeList = XMLUtil.createDocument(KohlsConstant.E_COMMON_CODE);
				Element eleInputForGetCommonCodeList = docInputForGetCommonCodeList.getDocumentElement();
				eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_CODE_TYPE,"CHECK_STORE");
				eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_ORGANIZATION_CODE,strOrganizationCode);
				eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_CODE_VALUE, codeValue);
				
				if(logger.isDebugEnabled())
					logger.debug("Input of Common Code API :: " + XMLUtil.getXMLString(docInputForGetCommonCodeList));
				docOutputForGetCommonCodeList= KOHLSBaseApi.invokeAPI(env, KohlsConstant.API_GET_COMMON_CODE_LIST, docInputForGetCommonCodeList);
				
				if(logger.isDebugEnabled())
					logger.debug("Output of Common Code API :: " + XMLUtil.getXMLString(docOutputForGetCommonCodeList));

				NodeList nlCommonCode = docOutputForGetCommonCodeList.getElementsByTagName(KohlsConstant.E_COMMON_CODE);
				if(nlCommonCode.getLength()>0){
					XMLUtil.setAttribute(tempOrderEle, "Extn_Is_TVS_Store", KohlsPOCConstant.YES);
				}else{
					XMLUtil.setAttribute(tempOrderEle, "Extn_Is_TVS_Store", KohlsPOCConstant.NO);
				}
			}else{
				XMLUtil.setAttribute(tempOrderEle, "Extn_Is_TVS_Store", KohlsPOCConstant.NO);
			}
		}catch (Exception e){

			logger.error(e);
			e.printStackTrace();
			throw e;
		}

		return inDoc;

	}

}
