/*
 * File: KohlsPoCGetOrderPriceForReticket.java Created on Sep 23, 2017 for POC_OMS_IBM_Returns by
 * mrjoshi
 *
 * COPYRIGHT: LICENSED MATERIALS - PROPERTY OF Kohls Stores "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason Date Who Descriptions ------- -------- --- -----------
 */
package com.kohls.poc.pricing.ue;

import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**
 * @author mrjoshi
 *
 */
public class KohlsPoCGetOrderPriceForReticket {

  private static YFCLogCategory logger;

  private Properties props;

  private Double listPrice = KohlsPOCConstant.ZERO_DBL;
  // Changes for ExtendedPrice - Start
  private Double extendedPrice = KohlsPOCConstant.ZERO_DBL;
  // Changes for ExtendedPrice - End

  static {
    logger = YFCLogCategory.instance(KohlsPoCGetOrderPriceUEFromTVS.class.getName());
  }

  public Document getOrderPriceForReticket(YFSEnvironment env, Document doInXML) throws ParserConfigurationException {
    logger.beginTimer("KohlsPoCGetOrderPriceForReticket.getOrderPriceForReticket");
    if (logger.isDebugEnabled()) {
      logger.debug(
          "KohlsPoCGetOrderPriceForReticket.KohlsPoCGetOrderPriceForReticket:\t Input xml is:\n"
              + XMLUtil.getXMLString(doInXML));
    }
    Document docOutXML = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    String strItemId = null;
    String sRegularPrice = "0.00";
    docOutXML.getDocumentElement().setAttribute("RegularPrice", sRegularPrice);
    NodeList nlOrderLineList =
        doInXML.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
    Element eleOrderLine = (Element) nlOrderLineList.item(0);
    if (!YFCCommon.isVoid(eleOrderLine)) {
      strItemId = XMLUtil.getAttribute(eleOrderLine, KohlsPOCConstant.A_ITEM_ID);
      if (!YFCCommon.isVoid(strItemId)
          && !(KohlsPOCConstant.SKU_VOID_TRAN_ZERO_ITEM.equalsIgnoreCase(strItemId))) {
        KohlsPoCGetOrderPriceUEFromTVS objGetOrderPrice = new KohlsPoCGetOrderPriceUEFromTVS();
        // Create request XML for TVS call
        Document docTVSRequest = objGetOrderPrice.constructTVSRequest(env, doInXML);
        // webservice call to TVS system
        Document docTVSResponse;
        try {
          docTVSResponse = KOHLSBaseApi.invokeService(env,
              KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE, docTVSRequest);
        } catch (Exception e) {
          return docOutXML;
        }
        if (!YFCCommon.isVoid(docTVSResponse)) {
          if (logger.isDebugEnabled()) {
            logger.debug("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice:\t Response from TVS:\n"
                + XMLUtil.getXMLString(docTVSResponse));
          }
          Element tvsResponseEle = docTVSResponse.getDocumentElement();
          NodeList nlItem = tvsResponseEle.getElementsByTagName(KohlsPOCConstant.ELEM_SMALL_ITEM);
          if (nlItem.getLength() > KohlsPOCConstant.ZERO_INT) {
            sRegularPrice = ((Element)nlItem.item(0)).getAttribute(KohlsPOCConstant.ATTR_REGULAR_PRICE);
            docOutXML.getDocumentElement().setAttribute("RegularPrice", sRegularPrice);
          }
        }
      }
    }
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCGetOrderPriceUEFromTVS.getOrderPrice:\t Out Document is:\n"
          + XMLUtil.getXMLString(docOutXML));
    }
    
    logger.endTimer("KohlsPoCGetOrderPriceForReticket.getOrderPriceForReticket");
    return docOutXML;
  }

}
