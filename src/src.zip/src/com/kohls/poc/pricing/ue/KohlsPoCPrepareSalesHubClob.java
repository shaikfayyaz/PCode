package com.kohls.poc.pricing.ue;

import java.text.DecimalFormat;
import java.util.List;

import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;

/**************************************************************************
 * File : KohlsPoCPrepareSalesHubClob.java Author : IBM Created : August 27 2013
 * Modified : August 27 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * 
 * This class is used to construct Sales Hub Clob related attributes..
 * 
 * @author IBM India Pvt
 * @version 0.2
 * @version 0.1 changes : Updated Comments section
 * @version 0.2 changes : Updated retrieving GP_RTL_QTY,GP_RTL_AMT,GP_PRIC_ID
 * @version 0.3 changes : Updated RebateInterfaceId, Fixed Discount Percent.
 * @version 0.4 changes : Updated logging information
 */
public class KohlsPoCPrepareSalesHubClob {

	// logger
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCPrepareSalesHubClob.class.getName());

	DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);


	public Element awardExtn;
	public Element eleData;

	// Constructor to initialise the attributes to be set

	public KohlsPoCPrepareSalesHubClob(Element eleData, Element awardExtn) {		
		super();
		logger.beginTimer("KohlsPoCPrepareSalesHubClob.constructor");
		this.awardExtn = awardExtn;

		this.eleData = eleData;

		this.eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_DISCOUNT_PERCENT, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_PROMO_INTERFACE_ID, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_GROUP_PRICE_ID, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_GROUP_RTL_AMOUNT, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_GROUP_RTL_QTY, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_MULTI_PRICE_IND, KohlsPOCConstant.EMPTY);

		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_ID, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_ID, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BUY_ITEM, KohlsPOCConstant.EMPTY);

		this.eleData.setAttribute(KohlsPOCConstant.A_OFFER_RCHD_QTY, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_OFFER_RCHD_AMT, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_DISC_LVL_CODE, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_TIER_QTY_RCHD, KohlsPOCConstant.ZERO_STR);
		this.eleData.setAttribute(KohlsPOCConstant.A_TIER_AMT_RCHD, KohlsPOCConstant.ZERO_STR);

		this.eleData.setAttribute(KohlsPOCConstant.A_PRECEDENCE, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_REBATE_INTFC_ID, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_PROMO_INTERFACE_SUB_ID, KohlsPOCConstant.EMPTY);
		
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_QTY_SH, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_AMT_SH, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_BUY_TOL_AMT_SH, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BUY_CRITERIA_TYPE, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_QTY_SH, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_DOL_OFF_AMT_SH, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT_SH, KohlsPOCConstant.EMPTY);
		this.eleData.setAttribute(KohlsPOCConstant.A_BWP_GET_PRPT_AMT_SH, KohlsPOCConstant.EMPTY);	
		
		this.eleData.setAttribute(KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.EMPTY);
		
		logger.endTimer("KohlsPoCPrepareSalesHubClob.constructor");

	}
	
	public void prepareSalesHubData(Element pluOfferResponseEle, Element modifierEle, Element extnEle,
			Element recordEle, Element pluFileRecordEle, String rebateInterfaceId, String promotionType){
		logger.beginTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");
		prepareSalesHubData(pluOfferResponseEle, modifierEle, extnEle,
				recordEle, pluFileRecordEle, rebateInterfaceId, promotionType,null);
		logger.endTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");
	}

	/**
	 * * Method Name : prepareSalesHubData Description : This method constructs
	 * attributes required to form Sales Hub Clob
	 * 
	 * @param pluOfferResponseEle
	 *            -
	 * @param modifierEle
	 * @param extnEle
	 * @param recordEle
	 * @param promotionType
	 */
	public void prepareSalesHubData(Element pluOfferResponseEle, Element modifierEle, Element extnEle,
			Element recordEle, Element pluFileRecordEle, String rebateInterfaceId, String promotionType,String associateDiscount) {

		logger.beginTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");

		logger.debug("#Method prepareSalesHubData: # Argument PromotionType value: " + promotionType);

		logger.debug("#Method prepareSalesHubData: # Argument rebateInterfaceId value: " + rebateInterfaceId);

		try 
		{

			if (null != pluOfferResponseEle)
				logger.debug("#Method prepareSalesHubData: #Argument pluOfferResponseEle value: " + XMLUtil.getElementXMLString(pluOfferResponseEle));

			if (null != modifierEle)
				logger.debug("#Method prepareSalesHubData: #Argument modifierEle value: " + XMLUtil.getElementXMLString(modifierEle));

			if (null != extnEle)
				logger.debug("#Method prepareSalesHubData: #Argument extnEle value: " + XMLUtil.getElementXMLString(extnEle));

			if (null != recordEle)
				logger.debug("#Method prepareSalesHubData: #Argument recordEle value: " + XMLUtil.getElementXMLString(recordEle));

			if (null != pluFileRecordEle)
				logger.debug("#Method prepareSalesHubData: #Argument pluFileRecordEle value: " + XMLUtil.getElementXMLString(pluFileRecordEle));

			String promoSchemeCode = XMLUtil.getAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME);

			if(YFCCommon.isStringVoid(promoSchemeCode)){
				if(!YFCCommon.isVoid(recordEle)){
					promoSchemeCode = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE);
					XMLUtil.setAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME, promoSchemeCode);
				}else{
					promoSchemeCode = KohlsPOCConstant.EMPTY;
				}
			}

			logger.debug("#Method prepareSalesHubData: #promoSchemeCode value:" + promoSchemeCode);

			if(!XMLUtil.isVoid(rebateInterfaceId)){
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_REBATE_INTFC_ID, rebateInterfaceId);
			}
			logger.debug("#Method prepareSalesHubData: #rebateInterfaceId value:" + rebateInterfaceId);

			if (!XMLUtil.isVoid(promotionType)) {
				if (promotionType.equalsIgnoreCase(KohlsPOCConstant.AMOUNT_OFF)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_AMOUNT_OFF);
				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.PERCENT_OFF)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_PERCENT_OFF);

				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.KOHLS_CASH)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.KOHLS_CASH_DESC);
				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.SENIOR_DISCOUNT)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE);
				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.PROMO)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.E_PROMO);
				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.OFFER)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.E_OFFER);
				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE);
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(associateDiscount))));
				} else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.REBATE)) {
					// DiscountType
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.A_REBATE);
				} // Added for Price Override
				else if (promotionType.equalsIgnoreCase(KohlsPOCConstant.PRICE_OVERRIDE)){
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.PRICE_OVER_RIDE);
				}
			}

			// DiscountPercent - Populates only for Promo and not for offer
			// Rectified Discount Percent, as it should be divided by 1000 from Promo response
			if (!promotionType.equalsIgnoreCase(KohlsPOCConstant.ASSOCIATE_DISCOUNT)) {
				if(!XMLUtil.isVoid(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_PCT))){
					double discountPercentDbl = Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_PCT)) / KohlsPOCConstant.THOUSAND_INT;
					logger.debug("#Method prepareSalesHubData: #discountPercent value:" + discountPercentDbl);
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT,twoDForm.format(Math.abs(Double.valueOf(discountPercentDbl))));
				}else if(YFCCommon.isStringVoid(XMLUtil.getAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT))){
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISCOUNT_PERCENT,
							KohlsPOCConstant.ZERO_STR);
				}
			}

			// PromoInterfaceId and PromoInterfaceSubId - Populates only for Promo and not for offer
			XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_PROMO_INTERFACE_ID,
					XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_ID));
			XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_PROMO_INTERFACE_SUB_ID,
					XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_SUB_ID));



			if (!XMLUtil.isVoid(pluFileRecordEle)) {

				// MultiPriceInd
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_MULTI_PRICE_IND,
						XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_MLT_PRPT_IND));
			}


			// Only when the promoSchemeCode is 0350
			if (!XMLUtil.isVoid(promoSchemeCode)
					&& Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode))) {

				// GroupPriceID
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GROUP_PRICE_ID,
						XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_ID));
			}

			// when the promoSchemeCode is 0350 or 0300
			if (!XMLUtil.isVoid(promoSchemeCode)
					&& (Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode)) || Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PROMO).equals(Integer.valueOf(promoSchemeCode)))) {

				DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);
				String groupRetailAmt = twoDForm.format(Double.valueOf(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT)) / KohlsPOCConstant.HUNDRED_INT);

				// GroupRtlAmount
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GROUP_RTL_AMOUNT,	groupRetailAmt);

				// GroupRtlQty
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GROUP_RTL_QTY,
						XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO));

			}



			String buyQty = "";
			String buyAmt = "";

			if (!XMLUtil.isVoid(pluOfferResponseEle)) {
				List<Element> xstOfrBwpList = XMLUtil
						.getElementsByTagName(pluOfferResponseEle, KohlsPOCConstant.E_XST_OFR_BWP);
				
				if (!XMLUtil.isVoid(xstOfrBwpList) && xstOfrBwpList.size() > KohlsPOCConstant.ZERO_INT) {
					for (Element xstOfferBwpEle : xstOfrBwpList) {
						String bwpSelectionTypeCode = XMLUtil
								.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_SELN_TYP_CDE);
						String tierLelNum =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_TIER_LVL_NBR);
						String tierLevelAchieved = XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_LEVEL_ACHIEVED);
						
						if(YFCCommon.isStringVoid(tierLevelAchieved)){
							tierLevelAchieved = KohlsPOCConstant.ZERO;
						}
						
						 if(!YFCCommon.isStringVoid(tierLelNum) && !YFCCommon.isStringVoid(tierLevelAchieved) ){
							if (tierLelNum.equalsIgnoreCase(tierLevelAchieved) && KohlsPOCConstant.GET.equalsIgnoreCase(bwpSelectionTypeCode)) {
								String bwpGetID = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_OFR_SECT_BWP_ID);
								String getQty = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_QTY);
								String getDoller = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_DOL_OFF_AMT);
								String getPricePoint =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_PRPT_AMT);
								String getPercentOff =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT);
								
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_ID, bwpGetID);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_QTY_SH, getQty);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_DOL_OFF_AMT_SH, getDoller);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT_SH, getPercentOff);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_GET_PRPT_AMT_SH, getPricePoint);
								
								//Setting ExtnGetCriteriaType for Offers in AwardExtn--Start
								if (!YFCCommon.isStringVoid(getQty)  && KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(getPricePoint)) {
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PRICE_POINT);
									XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_PRICE_POINT);
								} else if (!YFCCommon.isStringVoid(getDoller)) {
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_DOLLAR_OFF);
									XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_DOLLAR_OFF);
								} else if (!YFCCommon.isStringVoid(getPercentOff)) {
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PERCENT_OFF);
									XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_PERCENT_OFF);
								} else {
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_GET_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PRICE_POINT);
									XMLUtil.setAttribute(awardExtn,KohlsPOCConstant.A_EXTN_GET_CRITERIA_TYPE,KohlsPOCConstant.A_GET_PRICE_POINT);
								}
								//Setting ExtnGetCriteriaType for Offers in AwardExtn--End
							}
							if (tierLelNum.equalsIgnoreCase(tierLevelAchieved) &&KohlsPOCConstant.BUY.equalsIgnoreCase(bwpSelectionTypeCode)) {
								buyQty = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_BUY_QTY);
								buyAmt = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_BUY_AMT);
								
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_ID, XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_OFR_SECT_BWP_ID));
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_QTY_SH, buyQty);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_AMT_SH, buyAmt);
								XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BWP_BUY_TOL_AMT_SH, XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_BUY_TOL_AMT));
								
								if (!YFCCommon.isStringVoid(buyQty)) {
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BUY_CRITERIA_TYPE, KohlsPOCConstant.A_BUY_QUANTITY);
								} else if (!YFCCommon.isStringVoid(buyAmt)) {
									XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BUY_CRITERIA_TYPE, KohlsPOCConstant.A_BUY_DOLLAR);
								}
							}
						 }
					}
				}
			}

			/*
			 * Offer -
			 * {A_BWP_GET_ID,A_BWP_BUY_ID}---------------{XST_OFR_BWP/@OFR_SECT_BWP_ID
			 * based on XST_OFR_BWP/@BWP_SELN_TYP_CDE} {A_DISC_LVL_CODE
			 * -------------------------{XST_OFR[0]/@DISC_LVL_CDE}
			 * {A_OFFER_RCHD_AMT--------{Modifier/@TierActivationAchieved when
			 * PromoSchemeCode=1009 and buyQty>0}
			 * {A_OFFER_RCHD_QTY--------{Modifier/@TierActivationAchieved when
			 * PromoSchemeCode=1009 and buyAmt>0}
			 */

			// BuyItem - Irrespective of offer/promo will get populated.
			XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_BUY_ITEM,
					XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_BUY_ITEM));

			if (!XMLUtil.isVoid(pluOfferResponseEle)) {
				List<Element> xstOfferEleList = XMLUtil.getElementsByTagName(pluOfferResponseEle, KohlsPOCConstant.E_XST_OFR);

				if (!XMLUtil.isVoid(xstOfferEleList) && xstOfferEleList.size() > KohlsPOCConstant.ZERO_INT) {

					String attrPromoSchemeCode = XMLUtil.getAttribute(xstOfferEleList.get(KohlsPOCConstant.ZERO_INT),
							KohlsPOCConstant.A_PROMO_SCHM_CDE);

					// ExtnPromoScheme from PLU Offer response
					XMLUtil.setAttribute(awardExtn, KohlsPOCConstant.A_EXTN_PROMO_SCHEME, attrPromoSchemeCode);

					// OfferRchdQty

					if (!XMLUtil.isVoid(modifierEle)) {
						if (!XMLUtil.isVoid(buyQty) && !XMLUtil.isVoid(attrPromoSchemeCode)
								&& KohlsPOCConstant.CONST_TIER_OFFER_SCHME_CODE.equals(attrPromoSchemeCode) && Integer.parseInt(buyQty) > KohlsPOCConstant.ZERO_INT) {

							XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_OFFER_RCHD_QTY,
									XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_ACTIVATION_ACHIEVED));
						}

						// OfferRchdAmt
						if (!XMLUtil.isVoid(buyAmt) && !XMLUtil.isVoid(attrPromoSchemeCode)
								&& KohlsPOCConstant.CONST_TIER_OFFER_SCHME_CODE.equals(attrPromoSchemeCode) && Double.parseDouble(buyAmt) > KohlsPOCConstant.ZERO_DBL) {
							XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_OFFER_RCHD_AMT,
									XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_ACTIVATION_ACHIEVED));
						}
					}

					// DiscLvlCode
					XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_DISC_LVL_CODE,
							XMLUtil.getAttribute(xstOfferEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_DISC_LVL_CDE));

				}

			}

			if (!XMLUtil.isVoid(modifierEle)) {
				if(!YFCCommon.isVoid(promoSchemeCode))
				{
					// TierQtyRchd
					if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_QTY_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_TIER_QTY_RCHD,
								XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_ACTIVATION_ACHIEVED));
					}
					// TierAmtRchd
					if (Integer.valueOf(KohlsPOCConstant.PROMO_TIER_BUY_DLR_GET_PERCENT_OFF).equals(Integer.valueOf(promoSchemeCode))){
						XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_TIER_AMT_RCHD,
								XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_TIER_ACTIVATION_ACHIEVED));
					}
				}
				// Precedence
				XMLUtil.setAttribute(eleData, KohlsPOCConstant.A_PRECEDENCE,
						XMLUtil.getAttribute(modifierEle, KohlsPOCConstant.A_PRECEDENCE));

			}
			logger.debug("#Method prepareSalesHubData: #SalesHubClobData value: " + XMLUtil.getElementXMLString(eleData));			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			logger.error(e);
		}

		logger.endTimer("KohlsPoCPrepareSalesHubClob.prepareSalesHubData");
	}
}
