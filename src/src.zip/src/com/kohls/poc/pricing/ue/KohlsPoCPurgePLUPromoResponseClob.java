package com.kohls.poc.pricing.ue;

import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**************************************************************************
 * File : KohlsPoCPurgePLUPromoResponseClob.java Author : IBM Created :
 * September 24 2013 Modified : September 24 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 24/09/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * 
 * This class is used to purge PLUPromoResponse, ExtnPromotionResponse Clob .
 * 
 * @author IBM India Pvt
 * @version 0.1
 * @version 0.2 Updated code to have promotionKey passed with Promotion element, while updating extnPromotionResponse
 */

public class KohlsPoCPurgePLUPromoResponseClob extends KOHLSBaseApi {

	// logger
	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCPurgePLUPromoResponseClob.class
			.getName());

	public void purgePLUPromoResponseClob(YFSEnvironment env, Document inDoc) {

		logger.debug("Method  purgePLUPromoResponseClob : Start");

		logger.debug("input of purgePLUPromoResponseClob::" + XMLUtil.getXMLString(inDoc));
		Document tempDoc = null;

		try {
			Element tempOrderEle = KohlsPoCPnPUtil.createElementFromXMLString(XMLUtil.getXMLString(inDoc));

			tempDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);

			// Order
			Element eleOutDocOrder = tempDoc.getDocumentElement();

			// Retrieving OrderHeaderKey and OrderNo from InDoc , setting it in
			// the temp Doc to changeOrder
			XMLUtil.setAttribute(eleOutDocOrder, KohlsPOCConstant.ATTR_ORD_HDR_KEY,
					tempOrderEle.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
			XMLUtil.setAttribute(eleOutDocOrder, KohlsPOCConstant.ATTR_ORDER_NO,
					tempOrderEle.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO));

			// forming OrderLines in the tempDoc
			Element eleOutDocOrderLines = tempDoc.createElement(KohlsPOCConstant.ELEM_ORDER_LINES);
			eleOutDocOrder.appendChild(eleOutDocOrderLines);

			// Iterating the list of OrderLine
			List<Element> orderLineList = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
			if (!(XMLUtil.isVoid(orderLineList)) && orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
				for (Element orderLine : orderLineList) {
					Element eleOutDocOrderLine = tempDoc.createElement(KohlsPOCConstant.E_ORDER_LINE);

					// Retrieving OrderLineKey and setting it into tempDoc
					XMLUtil.setAttribute(eleOutDocOrderLine, KohlsPOCConstant.ATTR_ORDER_LINE_KEY,
							XMLUtil.getAttribute(orderLine, KohlsPOCConstant.ATTR_ORDER_LINE_KEY));
					Element eleOutDocOrderLineExtn = tempDoc.createElement(KohlsPOCConstant.E_EXTN);
					// Setting
					// Order/OrderLines/OrderLine/Extn/@ExtnPluPromoResponse to
					// blank
					XMLUtil.setAttribute(eleOutDocOrderLineExtn, KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE,
							KohlsPOCConstant.EMPTY);
					eleOutDocOrderLine.appendChild(eleOutDocOrderLineExtn);
					eleOutDocOrderLines.appendChild(eleOutDocOrderLine);

				}
			}

			Element elePromotions = tempDoc.createElement(KohlsPOCConstant.E_PROMOTIONS);
			eleOutDocOrder.appendChild(elePromotions);

			// Iterating the list of Promotions
			Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);

			if (!YFCCommon.isVoid(promotionsEle)) {
				List<Element> promotionList = XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
				if (!(XMLUtil.isVoid(promotionList)) && promotionList.size() > KohlsPOCConstant.ZERO_INT) {
					for (Element promotionElement : promotionList) {

						Element extnEle = XMLUtil.getChildElement(promotionElement, KohlsPOCConstant.E_EXTN);
						if (!XMLUtil.isVoid(extnEle)) {

							Element eleOutDocPromotionEle = tempDoc.createElement(KohlsPOCConstant.E_PROMOTION);

							logger.debug("Promotion Key:"
									+ promotionElement.getAttribute(KohlsPOCConstant.A_PROMOTION_KEY));

							XMLUtil.setAttribute(eleOutDocPromotionEle, KohlsPOCConstant.A_PROMOTION_KEY,
									promotionElement.getAttribute(KohlsPOCConstant.A_PROMOTION_KEY));

							Element eleOutDocPromotionExtn = tempDoc.createElement(KohlsPOCConstant.E_EXTN);
							// Setting
							// Order/Promotions/Promotion/Extn/@ExtnPromotionResponse
							// to blank
							XMLUtil.setAttribute(eleOutDocPromotionExtn, KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE,
									KohlsPOCConstant.EMPTY);
							eleOutDocPromotionEle.appendChild(eleOutDocPromotionExtn);
							elePromotions.appendChild(eleOutDocPromotionEle);
						}

					}
				}
			}

			logger.debug("Input formed to ChangeOrderAPI:" + XMLUtil.getXMLString(tempDoc));

			logger.debug("Invoking changeOrder API");

			KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, tempDoc);

			logger.debug("Invoked changeOrder API");

		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();

		}

		logger.debug("Method  purgePLUPromoResponseClob : End");

	}

}
