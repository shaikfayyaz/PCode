package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.kohlscash.ue.KohlsPoCKohlsCashRedemptionRequestCreator;
import com.kohls.poc.returns.api.KohlsPoCTVSReturnOrderReprice;
import com.kohls.poc.taxware.KohlsPocTaxServiceUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsPoCXMLDiff;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.pos.KohlsCorpPOCConstants;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSOrderRepricingUE;
import com.kohls.poc.pricing.ue.KohlsPoCTVSCaller;

/**************************************************************************
 * File : KohlsPoCTVSOrderRepriceUE.java Author : IBM Created : July 06 2015 Modified : July 06 2015
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 06/07/2015 IBM First Cut.
 ***************************************************************************** 
 * TO DO : *************************************************************************** Copyright @
 * 2015. This document has been prepared and written by IBM Global Services on behalf of Kohls, and
 * is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This class is invoked when changeOrder,createOrder,repriceOrder API gets called. Order level and
 * Order line promotions are handled by invoking their related method.
 * 
 * @author IBM India Pvt
 * @version 0.1
 *****************************************************************************/
public class KohlsPoCTVSOrderRepriceUE extends KOHLSBaseApi implements YFSOrderRepricingUE {

  private static YFCLogCategory logger;
  private Properties props;
  static {
    logger = YFCLogCategory.instance(KohlsPoCTVSOrderRepriceUE.class.getName());
  }
  // Fix for defect 1172 - Start
  private static Element eleDummylineTaxes_TVSTaxExempt = null;
  private List<Element> liPSAPromo = new ArrayList<Element>();
  // Fix for defect 1172 - End
  // XMLDiff changes - Start

  // method- orderReprice
  @Override
  public Document orderReprice(YFSEnvironment yfsEnv, Document inDoc) throws YFSUserExitException {
    logger.beginTimer("KohlsPoCTVSOrderRepriceUE.orderReprice");

    Document docCloneInpTax = (Document) inDoc.cloneNode(true);
    String isPSAChangeOrder = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_PSA_CHANGE_ORDER);
    logger.debug("isPSAChangeOrder value :" + isPSAChangeOrder);


    // Start -- POC Return Changes
    Element returnOrderEle = inDoc.getDocumentElement();
    Element returnOrderExtnEle = XMLUtil.getChildElement(returnOrderEle, KohlsPOCConstant.E_EXTN);
    String strDocType = returnOrderEle.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE);
    String strExtnPOCFeature = returnOrderExtnEle.getAttribute("ExtnPOCFeature");
    //If ExtnPOCFeature exists ie Receipted Return or Non Receipted Return
    if (strDocType.equalsIgnoreCase(KohlsPOCConstant.RET_DOC_TYPE)
        && !YFCCommon.isVoid(strExtnPOCFeature))

    {
    	KohlsPoCTVSReturnOrderReprice oReturnReprice = new KohlsPoCTVSReturnOrderReprice();
    	try {
			return oReturnReprice.orderReprice(yfsEnv, inDoc);
		} catch (YFSException e) {
			// TODO Auto-generated catch block
			throw e;
			
		}
		
    }
    // End -- POC Return Changes

    // Validating the flow is psa
    // if isPSAChangeOrder is "Y" then it it psa flow.
    if (KohlsPOCConstant.YES.equalsIgnoreCase(isPSAChangeOrder)) {
      Document doc = orderRepricePSA(yfsEnv, inDoc);
      return doc;
    }

    // Changes for #1617 - POC Returns Team - Start
    String strIsEvenExchangeOrder = (String) yfsEnv.getTxnObject("IsEvenExchangeOrder");
    logger.debug("IsEvenExchangeOrder value :" + strIsEvenExchangeOrder);
    if (KohlsPOCConstant.YES.equalsIgnoreCase(strIsEvenExchangeOrder)) {
      logger.debug("Order is Exchange :: " + strIsEvenExchangeOrder);
      return inDoc;
    }
    // Since the above logic is not working, trying with another, if works delete above
    try {
      String strIsEEOrder =
          KohlsXPathUtil.getString(inDoc.getDocumentElement(), "/Order/Extn/@ExtnKioskID");
      if (!YFCCommon.isVoid(strIsEEOrder) && "IsEEExg".equalsIgnoreCase(strIsEEOrder)) {
        logger.debug("Order is Exchange :: " + strIsEEOrder);
        return inDoc;
      }
    } catch (Exception e1) {
      logger.error("Exception in retrieving EE DEtails");
    }
    // Changes for #1617 - POC Returns Team - End

    // MidVoid Changes
    String isMidVoidOrder = "N";
    String isPostVoidOrder = "N";

    isMidVoidOrder = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_MID_VOID_ORDER);
    isPostVoidOrder = (String) yfsEnv.getTxnObject(KohlsPOCConstant.IS_MID_POST_ORDER);

    if ("Y".equals(isPostVoidOrder)) {
      isMidVoidOrder = "Y";
      isPostVoidOrder = "N";
    }

    logger.debug("is Mid void Order :" + isMidVoidOrder);
    logger.debug("is Post void Order :" + isPostVoidOrder);

    // midvoid or post void scenario
    if ((!YFCCommon.isVoid(isMidVoidOrder) && KohlsPOCConstant.YES.equalsIgnoreCase(isMidVoidOrder))
        || (!YFCCommon.isVoid(isPostVoidOrder)
            && KohlsPOCConstant.YES.equalsIgnoreCase(isPostVoidOrder))) {
      this.processRequestForVoid(yfsEnv, inDoc);
    }

    Document docOrigInpXML = (Document) inDoc.cloneNode(true);
    // XMLDiff changes - End
    Document tempDoc = null;
    Element tempOrderEle = null;
    Document tvsResponse = null;
    // Fix for defect 733 - Start
    String shipNode = null;
    // String tvsStoreNum = null;
    // Fix for defect 733 - End
    KohlsPoCTVSOrderLinePromotionCaller linePromoObj = new KohlsPoCTVSOrderLinePromotionCaller();
    KohlsPoCTVSOrderPromotionsCaller orderPromoObj = new KohlsPoCTVSOrderPromotionsCaller();

    // void TaxWare will store the boolean Yes/No to allow taxware call to happen
    String voidTaxWare = KohlsPOCConstant.NO;

    // This List holds all the existing Promotion Element's 'CreateTS' attribute value.
    List<String> createtsList = new ArrayList<String>();
		//PST-989 - Temp change - Start
		Document tempTvsRequest = null;
		//PST-989 - Temp change - End

    try {
      if (logger.isDebugEnabled()) {
        logger.debug("Input XML to the method KohlsPoCTVSOrderRepriceUE.orderReprice is: \n"
            + XMLUtil.getXMLString(inDoc));
      }

      // Added for 5301 defect fix -- start
      // replacing XPathUtil by XMLUtil
      List<Element> orderLineEleList =
          XMLUtil.getElementsByTagName(inDoc.getDocumentElement(), "OrderLine");
      for (Element eleOrderLine : orderLineEleList) {
        Element eleFirstItem = XMLUtil.getFirstElementByName(eleOrderLine, "Item");
        if (eleFirstItem.getAttribute("ItemID").equalsIgnoreCase("SKU_VOID_TRAN_ZERO_ITEM")) {

          return inDoc;
        }
      }
      // Added for 5301 defect fix -- end

      // Added for TVS Gap attributes -- Start
      // KohlsPoCPnPUtil.updateExtnAttrsOnOrderLineFromItem(yfsEnv,inDoc);
      // Added for TVS Gap attributes -- End
      tempOrderEle = inDoc.getDocumentElement();

      Element eleExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
      String strSeqNo = XMLUtil.getAttribute(eleExtn, KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO);

      // If the UE in doc has DraftOrderFlag='N', returns UE out Document as '<Order/>'
      // If repriceorder API is invoking this UE , return inDoc
      // If Transaction Object 'IgnoreRepricingUE' value is 'true' , change the 'IgnoreRepricingUE'
      // value as 'false' and return the inDoc
      String draftOrderFlag =
          XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_DRAFT_ORDER_FLAG);

      String isNewOrderFlag = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_IS_NEW_ORDER);
      if ((null != isNewOrderFlag && KohlsPOCConstant.YES.equalsIgnoreCase(isNewOrderFlag))
          || YFCCommon.isStringVoid(strSeqNo)) {
        String posSeqNo = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_POS_SEQUENCE_NO);
        logger.debug("seq no:" + posSeqNo);
        // Element extnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
        XMLUtil.setAttribute(eleExtn, KohlsPOCConstant.A_EXTN_ORIG_POS_SEQUENCE_NO, posSeqNo);

      }
      // MidVoid Changes
    //PST- 3150 start
      String extnPSAStatus = returnOrderExtnEle.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS);
      logger.debug("ExtnPsaStatus ..." + extnPSAStatus);
    	//PST-3150 ends
      if (KohlsPOCConstant.NO.equalsIgnoreCase(draftOrderFlag)
          && (!"Y".equals(isMidVoidOrder) && !"Y".equals(isPostVoidOrder))) {

        /* check for max_order_status */
        String maxOrderStat = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.MAX_ORDER_STATUS);
        if (KohlsPOCConstant.CONST_CANCEL.equalsIgnoreCase(maxOrderStat) && !YFCCommon.isVoid(extnPSAStatus)) {
          List<Element> promotionList =
              XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_PROMOTION);
          if (promotionList.size() > KohlsPOCConstant.ZERO_INT) {
            for (Element promotionElement : promotionList) {
              String promotionApplied =
                  XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_PROMOTION_APPLIED);
              String promotionType =
                  XMLUtil.getAttribute(promotionElement, KohlsPOCConstant.A_PROMOTION_TYPE);
              if (KohlsPOCConstant.YES.equalsIgnoreCase(promotionApplied)
                  && KohlsPOCConstant.KOHLSCASH.equalsIgnoreCase(promotionType)) {
                Element extnEle = XMLUtil.getChildElement(promotionElement, KohlsPOCConstant.E_EXTN,
                    Boolean.TRUE);
                String extnOfflineMode =
                    XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_OFFLINE_MODE);
                if (YFCCommon.isStringVoid(extnOfflineMode)) {
                  KohlsPoCKohlsCashRedemptionRequestCreator inputRequestCreator =
                      new KohlsPoCKohlsCashRedemptionRequestCreator();
                  Document kohlsCashReq = inputRequestCreator
                      .createKohlsCashRedeemInput(tempOrderEle, yfsEnv, promotionElement);
                  Document kohlsCashResp = KOHLSBaseApi.invokeService(yfsEnv,
                      KohlsPOCConstant.KOHLS_POC_KOHLS_CASH_REDEMPTION_WEB_SERVICE, kohlsCashReq);
                  if (logger.isDebugEnabled()) {
                    logger.debug(XMLUtil.getXMLString(kohlsCashResp));
                  }
                }

              }
            }
          }

        }
        logger.debug("Returning from RepriceUE..");
        return XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
      }else if (!YFCCommon.isVoid(yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE))) {
        String ignoreRepricingUE =
            (String) yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE);

        if (KohlsPOCConstant.TRUE.equalsIgnoreCase(ignoreRepricingUE)) {
          yfsEnv.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
          return inDoc;
        }
      }

      // for Associate Disc -- start

      String maxOrderStatus = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.MAX_ORDER_STATUS);
      if (!KohlsPOCConstant.SUSPEND_STATUS.equalsIgnoreCase(maxOrderStatus)) {
        String customerAssociateNo = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN)
            .getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
        if (!YFCCommon.isVoid(customerAssociateNo)) {
          orderPromoObj.createPromotionElemForAssDisc(yfsEnv, tempOrderEle);
        }
      }
      // for Associate Disc -- end


      // For TLD Promotions
      Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);

      if (!YFCCommon.isVoid(promotionsEle)) {
        promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
        List<Element> orderPromotionList =
            XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);

        if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) {

          // Code to bypass UE implementation logic when Kohls Cash is activated
          for (Element promotionEle : orderPromotionList) {
            String promotionType =
                XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
            if (KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase(promotionType)
                && !"Y".equals(isMidVoidOrder)) {
              XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED,
                  KohlsPOCConstant.NO);
              return XMLUtil.getDocumentForElement(tempOrderEle);
            }
          }
          // Order Level Promotions are handled in this method
          orderPromoObj.updateUeDocumentForTLD(orderPromotionList, yfsEnv, tempOrderEle,
              createtsList);
        }
      }

      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }

      // Order Line Level Promotions are handled in this method
      List<Element> orderLineList =
          XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);


      if (orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
        voidTaxWare = linePromoObj.updateUeDocumentForPromo(orderLineList, yfsEnv, tempOrderEle,
            createtsList);
      }

      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }

      // During Suspend , Order Level Promotion is not present , TVS service is not invoked
      if (!linePromoObj.getOrderLineHM().isEmpty() || !orderPromoObj.getOrderTLDHM().isEmpty()) {

        // Fix for defect 733 - Start
        shipNode = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        // Appending zero when store number length is less than 4
        shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
        /*
         * tvsStoreNum = props.getProperty(shipNode); if(YFCCommon.isVoid(tvsStoreNum)){ tvsStoreNum
         * = shipNode; }
         */
        // creating TVS input
        Document tvsRequestDoc = new KohlsPoCTVSCaller().constructTVSRequestDocument(yfsEnv,
            tempOrderEle, orderPromoObj, linePromoObj, createtsList, shipNode);
        // Fix for defect 733 - End
			//PST-989 - Temp change - Start
			tempTvsRequest = (Document) tvsRequestDoc.cloneNode(true);
			//PST-989 - Temp change - End
        if (logger.isDebugEnabled()) {
          this.logger.debug(XMLUtil.getXMLString(tvsRequestDoc));
        }

        tvsResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_TVS_WEB_SERVICE,
            tvsRequestDoc);
        // tvsResponse = KOHLSBaseApi.invokeService(yfsEnv, "readFileFromXPath", tvsRequestDoc);
        Element tvsResponseEle = tvsResponse.getDocumentElement();
        if (logger.isDebugEnabled()) {
          this.logger.debug(XMLUtil.getXMLString(tvsResponse));
        }
        
        // Added logic to handle price for prompt for Price Adjustment
        if("transaction".equalsIgnoreCase(tvsResponseEle.getNodeName()) && 
        		((String)yfsEnv.getTxnObject("ExtnPOCFeature")).equalsIgnoreCase("PriceAdjustment"))
        {
        	NodeList nlerror= tvsResponse.getElementsByTagName("error");
        	for(int i=0;i<nlerror.getLength();i++)
        	{
        		Element eErrorElement=(Element)nlerror.item(i);
        		String errorCodeStr =
        				XMLUtil.getChildElement(eErrorElement, "code").getTextContent();
        		if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr))
        		{
        			String errorDesc =
        					XMLUtil.getChildElement(eErrorElement, "message").getTextContent();
        			int ilen=errorDesc.length();
        			String sPrimeLineNumber= errorDesc.substring(ilen-2, ilen);  

        			//String sPrimeLineNumber=String.valueOf(sid);


        			Element elextn= (Element) XPathUtil.getNode(
        					inDoc.getDocumentElement(),
        					"//OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNumber.trim()
        					+ "']/Extn");

        			if(!YFCCommon.isVoid(elextn))
        			{
        				elextn.setAttribute(KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED, KohlsPOCConstant.YES); 
        			}


        		}
        	}
        }

        // Checking for SOAP fault
        if (tvsResponseEle.getTagName().equalsIgnoreCase("Errors")) {
          YFSException yfsException = new YFSException();
          String errorCodeStr =
              XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorCode");
          String errorDesc =
              XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorDescription");

          if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr)) {
            // Fix for defect 1103 - Start
            yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
            // Fix for defect 1103 - End

            // Commenting for defect 1103 - Start
            /*
             * String strID = errorDesc.substring(52); Map<String, Element> orderLineHM =
             * linePromoObj.getOrderLineHM(); for (final Map.Entry<String, Element> entry :
             * orderLineHM.entrySet()) { String primeLineNo = entry.getKey();
             * if(primeLineNo.equalsIgnoreCase(strID)) { Element orderLineEle = entry.getValue();
             * Element linePriceInfoEle = XMLUtil.getChildElement(orderLineEle, "LinePriceInfo");
             * String unitPriceStr = XMLUtil.getAttribute(linePriceInfoEle,"UnitPrice");
             * if(YFCCommon.isVoid(unitPriceStr)) {
             * yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ); }
             * 
             * } }
             */
            // Commenting for defect 1103 - End
          } else if (KohlsPOCConstant.OFFER_END_DATE_PASSED.equalsIgnoreCase(errorCodeStr)) {
            yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
            if (!YFCCommon
                .isStringVoid(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID))) {
              yfsException.setErrorDescription(
                  KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID));
            }

          } else {
            yfsException.setErrorCode(errorCodeStr);
            yfsException.setErrorDescription(errorDesc);
            logger.error("TVS Response Error ::::" + yfsException.getMessage());
          }
          if (!"OFFER_END_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
            yfsException.setErrorDescription(
                XMLUtil.getChildElement(tvsResponseEle, "Error").getAttribute("ErrorDescription"));
          }
          logger.error("TVS Response Error ::" + tvsResponseEle);
          throw yfsException;
        }

        if (logger.isDebugEnabled()) {
          logger.debug("APE Response Document Formatted : ");
          logger.debug(XMLUtil.getXMLString(tvsResponse));
        }

        new KohlsPoCTVSPrepareUEResponse().updateUeDocumentFromTVSResponse(yfsEnv, tvsResponseEle,
            tempOrderEle, orderPromoObj, linePromoObj);
      }

      else {

        Element extnOrder =
            XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
        XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TOTAL_SAVINGS,
            KohlsPOCConstant.ZERO_STR);
	      XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TAX_DETAILS,
                KohlsPOCConstant.EMPTY);
      }
      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
    } catch (YFSUserExitException e) {
      if (logger.isDebugEnabled()) {
        this.logger.debug("Exception UE here :::" + e.getMessage());
      }
      this.logger.error(e);
      e.printStackTrace();
      throw e;
    } catch (Exception e) {
      if (logger.isDebugEnabled()) {
        this.logger.debug("Exception occur here :::" + e.getMessage());
      }
      e.printStackTrace();
      YFSException uee = new YFSException();
      if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {
        if (logger.isDebugEnabled()) {
          this.logger.debug("Error class Name" + e.getClass().getName());
        }
        YFSException es = (YFSException) e;

        // Connect Exception
        if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
          this.logger.error(e);
        }

        // IO Exception
        else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
          this.logger.error(e);
        }

        // Other Exceptions
        else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
          this.logger.error(e);
        } else if (es.getErrorCode().equalsIgnoreCase("SOAP_EXCEPTION")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
          this.logger.error(e);
        } else {
          uee.setErrorCode(es.getErrorCode());
          uee.setErrorDescription(es.getErrorDescription());
          this.logger.error(e);
          throw uee;
        }
        throw uee;
      } else {
        this.logger.error(e);
        uee.setErrorCode("Unknown Error");
        uee.setErrorDescription(e.getMessage());
        throw uee;
      }

    }

    // Call for Taxware
    // Fix for Taxware call, when item is voided
    try {
      if (KohlsPOCConstant.NO.equalsIgnoreCase(voidTaxWare)) {

        // MJ 03/17 Commenting the strTaxwareCall check as its no more required. It was added
        // initially
        // for interim transition to TVS. Now all store have TVS, we dont need this check.
        // Sudina - Change for TVS phase 2 - taxware - Start
        /*
         * String strTaxwareCall = getProperty(KohlsPOCConstant.TAXWARE_CALL); if
         * (!YFCCommon.isVoid(strTaxwareCall) &&
         * strTaxwareCall.equalsIgnoreCase(KohlsPOCConstant.YES)) {
         */
        // If TVS call is not made for voided items, tax details are ignored.
        if (!(YFCCommon.isVoid(tvsResponse))) {

          Element eleItemList = (Element) (tvsResponse.getDocumentElement()
              .getElementsByTagName(KohlsPOCConstant.ATTR_ITEM_LIST)).item(0);
          List<Element> responseItemList =
              XMLUtil.getElementsByTagName(eleItemList, KohlsPOCConstant.ELEM_SMALL_ITEM);

          if (responseItemList.size() > KohlsPOCConstant.ZERO_INT) {
            this.updateTaxwareDetailsFromTVSToUEDoc(yfsEnv, responseItemList, linePromoObj.getOrderLineHM(),
                tempOrderEle);
          }
        }
        /*
         * } else { // Sudina - Change for TVS phase 2 - taxware - End Document taxWareResponse =
         * KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_TAX_WEB_SERVICE_UTIL,
         * XMLUtil.getDocumentForElement(tempOrderEle)); List<Element> taxwareOrderLineList =
         * XMLUtil.getElementsByTagName( taxWareResponse.getDocumentElement(),
         * KohlsPOCConstant.ELEM_ORDER_LINE); if (taxwareOrderLineList.size() >
         * KohlsPOCConstant.ZERO_INT) { this.updateForUeDocumentFromTaxWare(taxwareOrderLineList,
         * linePromoObj.getOrderLineKeyHM(), linePromoObj.getOrderLineHM(), tempOrderEle); }
         * 
         * }
         */


      }

      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
      removeTempElementFromTempDocument(linePromoObj, orderPromoObj);
      // removeClobAttributeFromPromotions(orderPromoObj);
      // Fix for 3949 - Start
      removeTempElementAssocDiscountPromo(tempOrderEle, orderPromoObj);
      // Fix for 3949 - End
      // CPE-1580 - start
      List<Element> orderLineList =
          XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);
      for (Element orderLine : orderLineList) {
        String orderedQty = orderLine.getAttribute(KohlsXMLLiterals.A_ORDERED_QUANTITY);
        if (0.00D == Double.parseDouble(orderedQty)) {
          Element eleExtn = KohlsXMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_EXTN);
          eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE, KohlsConstant.ZERO_INT);
          eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE, KohlsConstant.ZERO_INT);
          eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_RECPTT_RTN_PRICE, KohlsConstant.ZERO_INT);
        }
						//PST-989 - Temporary changes - Start
						String strEnableTVSLogging = null;
						try{
							strEnableTVSLogging = 	props.getProperty("enableTVSLogging");
						}catch (Exception ex) {
							strEnableTVSLogging = KohlsPOCConstant.NO;
		                }
						if (!(0.00D == Double.parseDouble(orderedQty)) && !YFCCommon.isVoid(strEnableTVSLogging) && 
								KohlsPOCConstant.YES.equalsIgnoreCase(strEnableTVSLogging)) {
							logger.debug("The strEnableTVSLogging Flag Value :" +strEnableTVSLogging);
							Element olTempElement = XMLUtil.getChildElement(orderLine, KohlsPOCConstant.E_TEMP);
							double tax = KohlsPOCConstant.ZERO_DBL;
							double taxableAmount = KohlsPOCConstant.ZERO_DBL;
							double lineTotal = KohlsPOCConstant.ZERO_DBL;

							tax = Double.valueOf(olTempElement.getAttribute("LineTotalTax"));
							taxableAmount = Double.valueOf(olTempElement.getAttribute("TaxableAmount"));
							lineTotal =  tax + taxableAmount ;
							logger.debug("tax , taxableAmount, lineTotal values : " +tax + " " +taxableAmount + " " +lineTotal );
							if(!YFCCommon.isVoid(tempTvsRequest) && !YFCCommon.isVoid(tvsResponse) && (lineTotal<0)){
								XMLUtil.importElement(tempTvsRequest.getDocumentElement(), tvsResponse.getDocumentElement());
								KOHLSBaseApi.invokeService(yfsEnv, "KohlsPoCCaptureTVSReqResponse", tempTvsRequest);
							}
							if(logger.isDebugEnabled()){
								logger.debug("Logic for checking -ve Line Total and capture the TVS Req/Response in YFS_Export table : " 
										+ XMLUtil.getXMLString(tempTvsRequest));
							}
						}
						//PST-989 - Temporary changes - End
      }
      // CPE-1580 - end
					//Shifting these two remove methods below the OrderLine for loop wrt PST-989
					removeTempElementFromTempDocument(linePromoObj,orderPromoObj);
					//removeClobAttributeFromPromotions(orderPromoObj);
					//Fix for 3949 - Start
					removeTempElementAssocDiscountPromo(tempOrderEle, orderPromoObj);
					//Fix for 3949 - End

      tempOrderEle.setAttribute(KohlsPOCConstant.VALIDATE_PROMOTION_AWARD, KohlsPOCConstant.NO);
      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
      tempDoc = XMLUtil.getDocumentForElement(tempOrderEle);
      this.logger.debug("Method Name : orderReprice   and   Status : End ");
    }

    // Changed YFSUserExitException to YFSException as Taxware Service is throwing YFSException
    catch (YFSException UE) {
      YFSUserExitException uee = new YFSUserExitException();
      uee.setErrorCode(UE.getErrorCode());
      uee.setErrorDescription(UE.getErrorDescription());
      throw uee;
    } catch (Exception e) {
      this.logger.error(e);
      e.printStackTrace();
      throw new YFSUserExitException(e.getMessage());
    }

    // MJ 03/21 - Skipping XML Diff for PA - begin
    if (!YFCCommon.isVoid(strExtnPOCFeature)
        && KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equals(strExtnPOCFeature)) {
      return tempDoc;
    }
    // MJ 03/21 - Skipping XML Diff for PA - End
    // XMLDiff changes - Start

    // Manoj 11/30: Added to return only changedOrderLines - Begin
    // String sUseXmlDiff = docOrigInpXML.getDocumentElement().getAttribute("UseXMLDiffInOutput");
    // if(!YFCCommon.isVoid(sUseXmlDiff) && sUseXmlDiff.equalsIgnoreCase("Y")){
    logger.beginTimer("KohlsOrderReprice.DiffXML");
    KohlsPoCXMLDiff xd = new KohlsPoCXMLDiff();
    try {
      Element eleInputOrderLines =
          (Element) docOrigInpXML.getElementsByTagName("OrderLines").item(0);
      Element eleOutOrderLines = (Element) tempDoc.getElementsByTagName("OrderLines").item(0);

      NodeList nlOrderLines = docOrigInpXML.getElementsByTagName("OrderLine");
      if (nlOrderLines.getLength() > 0) {
        for (int i = 0; i < nlOrderLines.getLength(); i++) {
          Element eleOrderLine = (Element) nlOrderLines.item(i);
          String sPrimeLineNo = eleOrderLine.getAttribute("PrimeLineNo");
          Element eleLineCharges = XMLUtil.getChildElement(eleOrderLine, "LineCharges");
          eleOrderLine.removeChild(eleLineCharges);
          Element eleLineCharges_new = XMLUtil.createChild(eleOrderLine, "LineCharges");
          if (!YFCCommon.isVoid(eleLineCharges)) {
            eleLineCharges.setAttribute("Reset", "Y");
            NodeList nlLineCharge = eleLineCharges.getElementsByTagName("LineCharge");



            // replacing XPathUtil by XMLUtil
            Element eleUEOutOrderLine = null;
            List<Element> lOrderLine =
                XMLUtil.getElementsByTagName(tempDoc.getDocumentElement(), "OrderLine");
            for (Element eleTempOrderLine : lOrderLine) {
              if (eleTempOrderLine.getAttribute("PrimeLineNo").equalsIgnoreCase(sPrimeLineNo)) {
                eleUEOutOrderLine = eleTempOrderLine;
                break;
              }
            }


            Element eleUEOutLineCharges = XMLUtil.getChildElement(eleUEOutOrderLine, "LineCharges");
            // if (YFCCommon.isVoid(eleUEOutLineCharges)){
            // eleUEOutLineCharges = XMLUtil.createChild(eleUEOutOrderLine, "LineCharges");
            // }
            NodeList nlUEOutLineCharges = null;
            if (!YFCCommon.isVoid(eleUEOutLineCharges)) {
              nlUEOutLineCharges = eleUEOutLineCharges.getElementsByTagName("LineCharge");
            }


            logger.debug("PrimeLineNo processing is: " + sPrimeLineNo);
            boolean bMatchFound;
            if (nlLineCharge.getLength() > 0) {
              for (int l = 0; l < nlLineCharge.getLength(); l++) {
                Element eleLineCharge = (Element) nlLineCharge.item(l);
                String sChargeName = eleLineCharge.getAttribute("ChargeName");
                logger.debug("ChargeName processing is: " + sChargeName);
                Element eleLineCharge_New = XMLUtil.createChild(eleLineCharges_new, "LineCharge");
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_CHARGE_PER_LINE,
                    eleLineCharge.getAttribute("ChargePerLine"));
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_IS_BILLABLE,
                    KohlsPOCConstant.YES);
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_IS_DISCOUNT,
                    KohlsPOCConstant.YES);
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.ATTR_CHARGE_CATEGORY,
                    eleLineCharge.getAttribute("ChargeCategory"));
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.ATTR_CHARGE_NAME,
                    sChargeName);
                // eleLineCharges.removeChild(eleLineCharge);

                bMatchFound = false;
                // logger.debug("nlUEOutLineCharges length is: "+nlUEOutLineCharges.getLength());
                if (!YFCCommon.isVoid(nlUEOutLineCharges) && nlUEOutLineCharges.getLength() > 0) {
                  for (int m = 0; m < nlUEOutLineCharges.getLength(); m++) {
                    Element eleUEOutLineCharge = (Element) nlUEOutLineCharges.item(m);
                    String sUEOutChargeName = eleUEOutLineCharge.getAttribute("ChargeName");
                    logger.debug("UE Out ChargeName is: " + sUEOutChargeName);
                    if (sUEOutChargeName.equalsIgnoreCase(sChargeName)) {
                      bMatchFound = true;
                      logger.debug("Match found for chargeName.");
                      break;
                    }
                  }
                }
                if (!bMatchFound) {
                  logger.debug(
                      "Match not found for chargeName. So resetting the LineCharges on O/P xml");
                  // if(!YFCCommon.isVoid(eleUEOutLineCharges)){
                  // eleUEOutLineCharges.setAttribute("Reset", "Y");
                  // }
                  break;
                }
              }
            }
          }
          Element elePromotions = XMLUtil.getChildElement(eleOrderLine, "Promotions");
          if (!YFCCommon.isVoid(elePromotions)) {
            elePromotions.setAttribute("Reset", "Y");
          }
          NodeList nlLineTax = eleOrderLine.getElementsByTagName("LineTax");
          if (nlLineTax.getLength() > 0) {
            for (int j = 0; j < nlLineTax.getLength(); j++) {
              Element eleLineTax = (Element) nlLineTax.item(j);
              eleLineTax.removeAttribute("ChargeNameKey");
              eleLineTax.removeAttribute("InvoicedTax");
              eleLineTax.removeAttribute("Reference_2");
              eleLineTax.removeAttribute("Reference_1");
              eleLineTax.removeAttribute("Reference_3");
              eleLineTax.removeAttribute("RemainingTax");
              eleLineTax.removeAttribute("ChargeNameKey");
              Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, "Extn");
              XMLUtil.removeChild(eleLineTax, eleLineTaxExtn);
            }
          }

          //// replacing XPathUtil by XMLUtil
          List nlOutLineTax = null;
          List<Element> lOrderLine =
              XMLUtil.getElementsByTagName(tempDoc.getDocumentElement(), "OrderLine");
          for (Element eleTempOrderLine : lOrderLine) {
            if (eleTempOrderLine.getAttribute("PrimeLineNo").equalsIgnoreCase(sPrimeLineNo)) {
              nlOutLineTax = XMLUtil.getElementsByTagName(eleTempOrderLine, "LineTax");
            }
          }
          if (nlOutLineTax.size() > 0) {
            for (int k = 0; k < nlOutLineTax.size(); k++) {
              Element eleOutLineTax = (Element) nlOutLineTax.get(k);
              eleOutLineTax.removeAttribute("Reference_1");
              String sTaxPercentage = eleOutLineTax.getAttribute("TaxPercentage");
              if ("0.0".equalsIgnoreCase(sTaxPercentage)) {
                eleOutLineTax.setAttribute("TaxPercentage",
                    KohlsPoCPnPUtil.getDouble(sTaxPercentage));
              }
            }
          }
        }
      }

      if (logger.isDebugEnabled()) {
        logger.debug(
            "UE Input XML going for Diff is: \n" + XMLUtil.getElementXMLString(eleInputOrderLines));

        logger.debug(
            "UE Output XML going for Diff is: \n" + XMLUtil.getElementXMLString(eleOutOrderLines));
      }

      Document diffXML = xd.diffXML(XMLUtil.createDocument(eleInputOrderLines),
          XMLUtil.createDocument(eleOutOrderLines));
      if (logger.isDebugEnabled()) {
        logger.debug("Diff XML is: \n" + XMLUtil.getXMLString(diffXML));
      }
      Element changedOrderLines =
          (Element) diffXML.getDocumentElement().getElementsByTagName("OrderLines").item(0);
      if (!YFCCommon.isVoid(changedOrderLines)) {
        tempDoc.getDocumentElement().removeChild(eleOutOrderLines);
        Element eleOrderLinesOut = (Element) tempDoc.importNode(changedOrderLines, true);
        tempDoc.getDocumentElement().appendChild(eleOrderLinesOut);
        if (logger.isDebugEnabled()) {
          logger.debug("Modified XML is: \n" + XMLUtil.getXMLString(tempDoc));
        }
      } else {
        logger.debug("XMLDiff returned null XML. So returning full xml");
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new YFSUserExitException(e.getMessage());
    }
    logger.endTimer("KohlsOrderReprice.DiffXML");
    // }
    // Manoj 11/30: Added to return only changedOrderLines - End
    // XMLDiff changes - End

    logger.endTimer("KohlsPoCTVSOrderRepriceUE.orderReprice");
    // Fix for 2693 - PSA Post Void - POC Returns Team --Start
    if ("Y".equals(isMidVoidOrder) || "Y".equals(isPostVoidOrder)) {
      Document adujustTaxTempDoc = (Document) tempDoc.cloneNode(true);
      try {
        this.adjusttax(yfsEnv, docCloneInpTax, adujustTaxTempDoc);
        removePSAPromotion(liPSAPromo, tempDoc);
      } catch (Exception e) {
        logger.error("Error while calling adjusttax in KohlsPoCTVSOrderRepriceUE.orderRepricePSA");
      }
    }
    // Fix for 2693 - PSA Post Void - POC Returns Team --End
    return tempDoc;
  }


  /**
   * This method is used to remove all the <Temp/> elements before sending the UE Out Doc
   * 
   * @param promoObj
   * @param offerAndKohlsCashObj
   * @throws IOException
   * @throws SAXException
   * @throws ParserConfigurationException
   */
  private void removeTempElementFromTempDocument(KohlsPoCTVSOrderLinePromotionCaller linePromoObj,
      KohlsPoCTVSOrderPromotionsCaller orderPromoObj)
      throws IOException, SAXException, ParserConfigurationException {
    this.logger.debug("Method Name : removeTempElementFromTempDocument   and   Status : Start ");
    KohlsPoCPnPUtil.removeTempElement(linePromoObj.getOrderLineHM());
    KohlsPoCPnPUtil.removeTempElement(linePromoObj.getOrderLineLLDHM());
    KohlsPoCPnPUtil.removeTempElement(orderPromoObj.getOrderTLDHM());
    this.logger.debug("Method Name : removeTempElementFromTempDocument   and   Status : End ");
  }

  // Fix for 3949 - Start
  private void removeTempElementAssocDiscountPromo(Element tempOrderEle,
      KohlsPoCTVSOrderPromotionsCaller orderPromoObj)
      throws IOException, SAXException, ParserConfigurationException {
    this.logger.debug("Method Name : removeTempElementAssocDiscountPromo   and   Status : Start ");
    if (!orderPromoObj.getOrderAssociateHM().isEmpty()) {
      Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);
      // logger.debug("The promotionsEle value is 712 loop: "
      // +XMLUtil.getElementXMLString(promotionsEle));
      NodeList orderPromotionList =
          promotionsEle.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
      if (!YFCCommon.isVoid(orderPromotionList)
          && orderPromotionList.getLength() > KohlsPOCConstant.ZERO_INT) {
        for (int k = 0; k < orderPromotionList.getLength(); k++) {
          Element promtionEle = ((Element) orderPromotionList.item(k));
          // logger.debug("The promo element before removing temp is ssssss : "
          // +XMLUtil.getElementXMLString(promtionEle));
          Element promoTempEle = XMLUtil.getChildElement(promtionEle, "Temp");
          if (!YFCCommon.isVoid(promoTempEle)) {
            XMLUtil.removeChild(promtionEle, promoTempEle);
            // logger.debug("The promo element after removing temp is ssssss : "
            // +XMLUtil.getElementXMLString(promtionEle));
          }
          // logger.debug("The promo element ssss : " +XMLUtil.getElementXMLString(promtionEle));
        }
      }
      if (logger.isDebugEnabled()) {
        logger.debug("The promos element issssss : " + XMLUtil.getElementXMLString(promotionsEle));
      }
    }

    this.logger.debug("Method Name : removeTempElementAssocDiscountPromo   and   Status : End ");
  }
  // Fix for 3949 - End

  /**
   * Updating the UE out document using Taxware details
   * 
   * @param taxwareOrderLineList
   * @param orderLineKeyHM
   * @param orderLineHM
   * @param tempOrderEle
   */
  private void updateForUeDocumentFromTaxWare(List<Element> taxwareOrderLineList,
      Map<String, String> orderLineKeyHM, Map<String, Element> orderLineHM, Element tempOrderEle)
      throws ParserConfigurationException, SAXException, IOException {
    this.logger.debug("Method Name : updateForUeDocumentFromTaxWare   and   Status : Start ");

    Set<Double> set = new TreeSet<Double>(Collections.reverseOrder());
    Map<String, Element> taxDetailsMap = new HashMap<String, Element>();
    // Fix for CR 5462 - Start
    boolean nullifyTaxPercentage = false;
    String sTaxExemptionCert = tempOrderEle.getAttribute("TaxExemptionCertificate");
    Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, "Extn");
    String sExtnTaxExemptCustFlag = eleOrderExtn.getAttribute("ExtnTaxExemptCustFlag");
    // Fix for CR 5462 - End

    for (Element taxwareOLEle : taxwareOrderLineList) {
      String orderLineKey =
          XMLUtil.getAttribute(taxwareOLEle, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
      String guid = orderLineKeyHM.get(orderLineKey);
      // Sprint 9.1 : START - Defect 4354//
      String strExtnRecycleFeeID = null;
      // Sprint 9.1 : END - Defect 4354//
      if (null != guid && orderLineHM.containsKey(guid)) {
        Element orderLineEle = orderLineHM.get(guid);

        Element lineTaxesEle =
            XMLUtil.getChildElement(taxwareOLEle, KohlsPOCConstant.ELEM_LINE_TAXES);
        // Sprint 9.1 : START //
        Element eleExtn = XMLUtil.getChildElement(taxwareOLEle, KohlsPOCConstant.A_EXTN);
        if (!YFCCommon.isVoid(eleExtn)) {
          strExtnRecycleFeeID = eleExtn.getAttribute("ExtnRecycleFeeID");
        }
        // Sprint 9.1 : END //


        if (!YFCCommon.isVoid(lineTaxesEle)) {
          Element lineTaxesEle1 =
              XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);

          // Fix for CR 5462 - Start
          Element linePriceInfo =
              XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
          String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
          if (!YFCCommon.isVoid(sTaxExemptionCert)
              || (!YFCCommon.isVoid(taxableFlag)
                  && ("N".equalsIgnoreCase(taxableFlag) || "O".equalsIgnoreCase(taxableFlag)))
              || (!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
                  && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
            if (!YFCCommon.isVoid(sTaxExemptionCert)) {
              logger.debug(
                  "Order has the Tax Exempt certificate, hence setting the tax percentage as 0");
            } else if ((!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
                && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
              logger.debug("Order has Tax exempt customer, hence setting the tax percentage as 0");
            } else {
              logger.debug("OrderLine has TaxableFlag=N, hence setting the tax percentage as 0");
            }
            nullifyTaxPercentage = true;
          }
          updateTaxableFlag(orderLineEle, lineTaxesEle, nullifyTaxPercentage);
          // Commented below method call since MerchandiseTaxCode is not coming in TVS Response
          // updateTaxableFlag(orderLineEle,lineTaxesEle);
          // Fix for CR 5462 - End

          Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
          KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(lineTaxesEle, tempEle, set);


          // Sprint 9.1 :START //
          if (!YFCCommon.isVoid(strExtnRecycleFeeID)) {

            Element eleOrderLineExtn =
                XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
            eleOrderLineExtn.setAttribute("ExtnRecycleFeeCode", strExtnRecycleFeeID);
            orderLineEle.appendChild(eleOrderLineExtn);
          }
          // Sprint 9.1 : END //
          XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
          XMLUtil.importElement(orderLineEle, lineTaxesEle);
        }
      }
    }

    /**
     * Below statement used form the CLOB xml
     * <TaxIndicators> <TaxIndicator EffectiveTaxRate="" TaxAmount="" TaxRateIndicator=""
     * TotalAmount=""/> </TaxIndicators>
     */

    Document taxIndicatorsDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element taxDetailListEle = taxIndicatorsDoc.getDocumentElement();
    Iterator ite = orderLineHM.keySet().iterator();

    while (ite.hasNext()) {
      String guid = (String) ite.next();
      Element orderLineEle = orderLineHM.get(guid);
      Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
      Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);

      Element linePriceInfoEle =
          XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
      String taxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);

      Element extnOrderEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
      String extnAgencyName = extnOrderEle.getAttribute(KohlsPOCConstant.A_AGENCY_NAME);

      // Fix for defect 26757 - Start
      if (KohlsPOCConstant.YES.equalsIgnoreCase(taxableFlag) || !YFCCommon.isVoid(extnAgencyName))
      // Fix for defect 26757 - End
      {
        if (logger.isDebugEnabled()) {
          logger.debug("----- tempElement beofre updateTaxDetails ----- "
              + XMLUtil.getElementXMLString(tempEle));
        }
        String extnTaxIndicator =
            KohlsPoCPnPUtil.updateTaxDetails(set, taxDetailsMap, tempEle, taxDetailListEle);
        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR, extnTaxIndicator);
      } else {
        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR,
            KohlsPOCConstant.CONST_HASH);
      }
    }

    Element orderExtnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
    orderExtnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
        XMLUtil.getElementXMLString(taxDetailListEle));

    this.logger.debug("Method Name : updateForUeDocumentFromTaxWare   and   Status : End ");
  }



  /**
   * updateTaxableFlag : This method is used to updated taxable flag based on the merchandise tax
   * code and the tax attribute of LineTax from Taxware response
   * 
   * @param orderLineEle
   * @param lineTaxesEle
   * @param nullifyTaxPercentage
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   */
  // Fix for CR 5462 - Start
  private void updateTaxableFlag(Element orderLineEle, Element lineTaxesEle,
      boolean nullifyTaxPercentage)
      // Fix for CR 5462 - End
      throws ParserConfigurationException, SAXException, IOException {
    this.logger.debug("Method Name : updateTaxableFlag   and   Status : Start ");

    // Retrieve MDSE_TX_CDE from PluPromo response
    String mdseTaxCode = KohlsPOCConstant.EMPTY;

    Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);

    // Added for TVS Gap attributes -- Start

    if (!YFCCommon.isVoid(extnEle)) {
      mdseTaxCode = extnEle.getAttribute("ExtnMdxTaxCode");
    }

    // Added for TVS Gap attributes -- End

    boolean isTaxNonZero = Boolean.FALSE;
    List<Element> lineTaxEleList =
        XMLUtil.getElementsByTagName(lineTaxesEle, KohlsPOCConstant.E_LINE_TAX);

    // Iterate through the list of linetax and check for Tax attribute value. If any of the
    // LineTax's Tax attribute value is greater than zero
    // set isTaxNonZero as True
    for (Element lineTaxEle : lineTaxEleList) {
      String tax = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX);
      if (Double.valueOf(tax) > KohlsPOCConstant.ZERO_DBL) {
        isTaxNonZero = Boolean.TRUE;
        break;
      }
      // Fix for CR 5462 - Start
      if (nullifyTaxPercentage) {
        XMLUtil.setAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT,
            KohlsPOCConstant.ZERO_STR);
      }
      // Fix for CR 5462 - End
    }

    Element linePriceInfo =
        XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
    String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);

    logger.debug("mdseTaxCode" + mdseTaxCode);
    // logger.debug("Double.valueOf(mdseTaxCode):"+Double.valueOf(mdseTaxCode));
    logger.debug("TaxableFlag:" + taxableFlag);
    logger.debug("istaxNonZero:" + isTaxNonZero);

    // If isTaxNonZero is false and MDSE_TX_CDE ==0 OR isTaxNonZero is false and TaxableFlag is N or
    // O, set taxable flag as N , else Y

    if ((!isTaxNonZero && !YFCCommon.isStringVoid(mdseTaxCode)
        && (Double.valueOf(mdseTaxCode) == KohlsPOCConstant.ZERO_DBL))
        || (!isTaxNonZero && !YFCCommon.isStringVoid(taxableFlag)
            && ((KohlsPOCConstant.NO.equalsIgnoreCase(taxableFlag))
                || (KohlsPOCConstant.OVERRIDE_TAX_O.equalsIgnoreCase(taxableFlag))))) {
      XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.NO);
      // Manoj : Fix for defect 5479 - Start
      for (Element lineTaxEle : lineTaxEleList) {
        XMLUtil.setAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT,
            KohlsPOCConstant.ZERO_STR);
      }
      // Manoj : Fix for defect 5479 - End
    } else {
      XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.YES);
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Taxable Flag at linepriceInfo is:"
          + linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG));
    }
    logger.debug("Method Name : updateTaxableFlag   and   Status : End ");
  }

  // this method is for remove ExtnPromotionResposne attribute
  private void removeClobAttributeFromPromotions(KohlsPoCTVSOrderPromotionsCaller orderPromoObj)
      throws IOException, SAXException, ParserConfigurationException {

    this.logger.debug("Method Name : removeTempElementFromTempDocument   and   Status : Start ");

    Map<String, Element> ordTLDHM = orderPromoObj.getOrderTLDHM();
    for (final Map.Entry<String, Element> entry : ordTLDHM.entrySet()) {
      Element promotionEle = entry.getValue();
      Element extnEle = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN);
      if (!YFCCommon.isVoid(extnEle)) {
        if (!YFCCommon.isStringVoid(extnEle.getAttribute("ExtnPromotionResponse"))) {
          XMLUtil.removeAttribute(extnEle, "ExtnPromotionResponse");
        }
      }
    }

    this.logger.debug("Method Name : removeTempElementFromTempDocument   and   Status : End ");
  }



  // Sudina - Code changes for TVS phase 2 - Taxware - Start

  /**
   * Updating the UE out document using Taxware details from TVS Response
   * 
   * @param responseItemList
   * @param orderLineKeyHM
   * @param orderLineHM
   * @param tempOrderEle
   */
  private void updateTaxwareDetailsFromTVSToUEDoc(YFSEnvironment yfsEnv, List<Element> responseItemList,
      Map<String, Element> orderLineHM, Element tempOrderEle)
      throws ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDoc");
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDoc:tempOrderEle\n"
          + XMLUtil.getElementXMLString((tempOrderEle)));
    }
    Set<Double> set = new TreeSet<Double>(Collections.reverseOrder());
    Map<String, Element> taxDetailsMap = new HashMap<String, Element>();
    boolean nullifyTaxPercentage = false;
    String sTaxExemptionCert =
        XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);
    Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.A_EXTN);
    String sExtnTaxExemptCustFlag =
        XMLUtil.getAttribute(eleOrderExtn, KohlsPOCConstant.ATTR_EXTN_TAX_EXEMPT_CUST_FLAG);
    if (logger.isDebugEnabled()) {
      logger.debug("sTaxExemptionCert + sExtnTaxExemptCustFlag::::::" + sTaxExemptionCert + "\t"
          + sExtnTaxExemptCustFlag);
    }
    double dTotalFeeTaxAmount=KohlsPOCConstant.ZERO_DBL;
    for (Element eleResponseItem : responseItemList) {
      String strUniqueId = XMLUtil.getAttribute(eleResponseItem, KohlsPOCConstant.ATTR_ID);
      String strExtnRecycleFeeID = null;
      if (null != strUniqueId && orderLineHM.containsKey(strUniqueId)) {
        logger.debug("Unique Id exists in OrderLine HM");
        Element orderLineEle = orderLineHM.get(strUniqueId);
        Element custAttribsEle = XMLUtil.getChildElement(orderLineEle, "CustomAttributes");
        String sOrigPrice = null;
        if(!YFCCommon.isVoid(custAttribsEle))
        {
        		 sOrigPrice = custAttribsEle.getAttribute("Text12");
        }       
        Element linePriceInfo =
            XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
        String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
        if (!YFCCommon.isVoid(sTaxExemptionCert)
            || (!YFCCommon.isVoid(taxableFlag)
                && ("N".equalsIgnoreCase(taxableFlag) || "O".equalsIgnoreCase(taxableFlag)))
            || (!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
                && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
          if (!YFCCommon.isVoid(sTaxExemptionCert)) {
            logger.debug(
                "Order has the Tax Exempt certificate, hence setting the tax percentage as 0");
          } else if ((!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
              && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
            logger.debug("Order has Tax exempt customer, hence setting the tax percentage as 0");
          } else {
            logger.debug("OrderLine has TaxableFlag=N, hence setting the tax percentage as 0");
          }
          nullifyTaxPercentage = true;
        }

        if (!YFCCommon.isVoid(eleResponseItem)) {



          // Element lineTaxesEle = XMLUtil.getChildElement(eleResponseItem,
          // KohlsPOCConstant.SMALL_ELEM_LINE_TAXES);
          Element lineTaxesEle =
              XMLUtil.getChildElement(eleResponseItem, KohlsPOCConstant.ELEM_LINE_TAXES);
          // Fix for defect 966 - Start
          strExtnRecycleFeeID = eleResponseItem.getAttribute("extnRecycleFeeId");
          logger.debug("The strExtnRecycleFeeID value is: " + strExtnRecycleFeeID);
          // Fix for defect 966 - End
          // Fix for defect 1172 - Start
          if (!YFCCommon.isVoid(lineTaxesEle)) {
            if (lineTaxesEle.hasChildNodes()) {
              // logger.debug("Insidde if loop having line tax");
              updateTaxableFlagFromTVS(orderLineEle, lineTaxesEle, nullifyTaxPercentage);
              Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
              KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(lineTaxesEle, tempEle, set);
              /*if (!YFCCommon.isVoid(strExtnRecycleFeeID)) {
                logger.debug(
                    "The strExtnRecycleFeeID value inside if loop is: " + strExtnRecycleFeeID);
                Element eleOrderLineExtn =
                    XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
                if (logger.isDebugEnabled()) {
                  logger.debug("The eleOrderLineExtn value is: "
                      + XMLUtil.getElementXMLString(eleOrderLineExtn));
                }
                eleOrderLineExtn.setAttribute("ExtnRecycleFeeCode", strExtnRecycleFeeID);
                orderLineEle.appendChild(eleOrderLineExtn);
                if (logger.isDebugEnabled()) {
                  logger.debug(
                      "The orderLineEle value is: " + XMLUtil.getElementXMLString(orderLineEle));
                }

              }*/
              // Sprint 9.1 : END //
              Element lineTaxesEle1 =
                  XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
              XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
              XMLUtil.importElement(orderLineEle, lineTaxesEle);
            } else {
              // logger.debug("Insidde else loop having line tax");
              Element lineTaxesEle1 =
                  XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
              XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
              if (YFCCommon.isVoid(eleDummylineTaxes_TVSTaxExempt)) {
                /*
                 * File fXmlLinetaxes = new File(
                 * "/kohls/prop/of/Foundation/extensions/global/template/api/POC/saleshub/LineTaxesForTVSTaxExempt.xml"
                 * ); DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
                 * DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder(); Document
                 * docLineTaxes = dBuilder1.parse(fXmlLinetaxes); eleDummylineTaxes_TVSTaxExempt =
                 * docLineTaxes.getDocumentElement();
                 */
                eleDummylineTaxes_TVSTaxExempt =
                    XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
                /*
                 * KohlsPocTaxServiceUtil.simulateTaxLineTaxesForTVSTaxExempt(
                 * eleDummylineTaxes_TVSTaxExempt);
                 */
                KohlsPocTaxServiceUtil
                    .simulateSingleTaxLineForTVSTaxExempt(eleDummylineTaxes_TVSTaxExempt);
                eleDummylineTaxes_TVSTaxExempt.setAttribute("TaxExemptApplied", "Y");
                if (logger.isDebugEnabled()) {
                  logger.debug(
                      "The file is read. The eleDummylineTaxes_TVSTaxExempt is read for the first time: "
                          + XMLUtil.getElementXMLString(eleDummylineTaxes_TVSTaxExempt));
                }
              } else {
                if (logger.isDebugEnabled()) {
                  logger.debug("The file is read from Static variable: "
                      + XMLUtil.getElementXMLString(eleDummylineTaxes_TVSTaxExempt));
                }
                XMLUtil.importElement(orderLineEle, eleDummylineTaxes_TVSTaxExempt);
              }
              updateTaxableFlagFromTVS(orderLineEle, eleDummylineTaxes_TVSTaxExempt, true);
              
              Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
              KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(eleDummylineTaxes_TVSTaxExempt,
                  tempEle, set);
            }
          }
          // Fix for defect 1172 - End

        }
        List<Element> ndFeeList = XMLUtil.getElementsByTagName(eleResponseItem, KohlsPOCConstant.SMALL_ATTR_FEES);
        if (!YFCCommon.isVoid(ndFeeList) && ndFeeList.size() > KohlsPOCConstant.ZERO_INT) {
        	logger.debug(
        			"KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDoc----- Fee element exists");
        	String storeNumber = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        	boolean updateFeeEligible = false;
        	if( KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE))) {
        		if(!YFCCommon.isVoid(sOrigPrice)){
            		double dOrigPrice = Double.parseDouble(sOrigPrice);
            		if(Double.parseDouble(eleResponseItem.getAttribute("netPrice")) < dOrigPrice){
            			updateFeeEligible = true;
            		}
            	}
        	}else{
        		updateFeeEligible = true;
        	}
        	try {
        		if(updateFeeEligible){
        			String strLineFeeAmountRate = KohlsPoCPnPUtil.updateFeeDetails(ndFeeList, orderLineEle,"",null, null);
        			double dLineFeeAmount = KohlsPoCPnPUtil.getRateBasedLineTaxFeeAmount(strLineFeeAmountRate);
        			if(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE)) 
        					&& (dLineFeeAmount>0 || dLineFeeAmount<0)){
        				Element orderLineExtnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
        				String strExtnReturnPrice = XMLUtil.getAttribute(orderLineExtnEle, KohlsPOCConstant.A_EXTN_RETURN_PRICE);
        				if(!YFCCommon.isVoid(strExtnReturnPrice)){
        					double dblExtnReturnPrice = Double.valueOf(strExtnReturnPrice);
        					double dblPriceIncludingFee = dblExtnReturnPrice /*+ dLineFeeAmount*/;
        					if(!YFCCommon.isVoid(dblPriceIncludingFee)){
        						XMLUtil.setAttribute(orderLineExtnEle, KohlsPOCConstant.A_EXTN_RETURN_PRICE,new DecimalFormat("0.00").format(dblPriceIncludingFee)+"");
        					}
        				}
        			}
        			dTotalFeeTaxAmount = dTotalFeeTaxAmount + dLineFeeAmount;
        		}else{
        			logger.debug("TaxFee details not updated since its ECom Store");
        		}
        	}catch (Exception e) {
        		logger.error("Exception while updating Fee Details: "+e.getMessage());
        	}
        }
      }
    }
    String strTotalFeeTaxAmount = String.valueOf(dTotalFeeTaxAmount);

    Document taxIndicatorsDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element taxDetailListEle = taxIndicatorsDoc.getDocumentElement();
    taxDetailListEle.setAttribute(KohlsPOCConstant.Total_Fee_Tax_Amount, strTotalFeeTaxAmount);
    Iterator ite = orderLineHM.keySet().iterator();

    while (ite.hasNext()) {
      String guid = (String) ite.next();
      if (orderLineHM.containsKey(guid)) {
        Element orderLineEle = orderLineHM.get(guid);
        Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
        Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);

        Element linePriceInfoEle =
            XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
        String taxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);

        Element extnOrderEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
        String extnAgencyName = extnOrderEle.getAttribute(KohlsPOCConstant.A_AGENCY_NAME);

        if (KohlsPOCConstant.YES.equalsIgnoreCase(taxableFlag)
            || !YFCCommon.isVoid(extnAgencyName)) {
          String extnTaxIndicator =
              KohlsPoCPnPUtil.updateTaxDetails(set, taxDetailsMap, tempEle, taxDetailListEle);
              XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR, extnTaxIndicator);
        } else {
          XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR,
              KohlsPOCConstant.CONST_HASH);
        }
      }

      Element orderExtnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
      orderExtnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
          XMLUtil.getElementXMLString(taxDetailListEle));
      if (logger.isDebugEnabled()) {
        logger.endTimer(
            "KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDoc----- taxDetailListEle\n"
                + XMLUtil.getElementXMLString(taxDetailListEle));
      }
      logger.endTimer("KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDoc");
    }

  }



  /**
   * updateTaxableFlagFromTVS : This method is used to updated taxable flag based on the merchandise
   * tax code and the tax attribute of LineTax from TVS response
   * 
   * @param orderLineEle
   * @param lineTaxesEle
   * @param nullifyTaxPercentage
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   */

  private void updateTaxableFlagFromTVS(Element orderLineEle, Element lineTaxesEle,
      boolean nullifyTaxPercentage) throws ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS");

    // String mdseTaxCode = KohlsPOCConstant.EMPTY;
    boolean isTaxNonZero = Boolean.FALSE;

    Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);
    // if(!YFCCommon.isVoid(extnEle))
    // {
    // mdseTaxCode = extnEle.getAttribute(KohlsPOCConstant.A_EXTN_MDX_TAX_CODE);
    // }
    // List<Element> lineTaxEleList = XMLUtil.getElementsByTagName(lineTaxesEle,
    // KohlsPOCConstant.SMALL_ELEM_LINE_TAX);
    List<Element> lineTaxEleList =
        XMLUtil.getElementsByTagName(lineTaxesEle, KohlsPOCConstant.ELEM_LINE_TAX);

    // Iterate through the list of tax and check for Tax attribute value. If any of the Tax's Tax
    // attribute value is greater than zero
    // set isTaxNonZero as True
    // Changes for consolidating LineTaxes - Performance - Start
    Element linePriceInfo =
        XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);  
    String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
    for (Element lineTaxEle : lineTaxEleList) {

      String tax = XMLUtil.getAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX);
      if (Double.valueOf(tax) > KohlsPOCConstant.ZERO_DBL) {
        isTaxNonZero = Boolean.TRUE;
        break;
      }
      if (nullifyTaxPercentage) {
        XMLUtil.setAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT,
            KohlsPOCConstant.ZERO_STR);
      }
      if (!isTaxNonZero && !YFCCommon.isStringVoid(taxableFlag)){
    	  if(KohlsPOCConstant.NO.equalsIgnoreCase(taxableFlag)){
    		  XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.NO);
        	  XMLUtil.setAttribute(lineTaxEle, KohlsPOCConstant.ATTR_TAX_PERCENT, KohlsPOCConstant.ZERO_STR);
    	  }
      }
      else {
        XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG, KohlsPOCConstant.YES);
      }
    }
    logger.debug(
        "KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS : TaxableFlag is \t" + taxableFlag);
    logger.debug(
        "KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS : istaxNonZero is \t" + isTaxNonZero);
    /*
     * Element linePriceInfo = XMLUtil.getChildElement(orderLineEle,
     * KohlsPOCConstant.E_LINE_PRICE_INFO); String taxableFlag =
     * linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
     * 
     * // logger.debug("KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS : mdseTaxCode is \t"
     * +mdseTaxCode); logger.debug(
     * "KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS : TaxableFlag is \t"+taxableFlag);
     * logger.debug("KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS : istaxNonZero is \t"
     * +isTaxNonZero);
     * 
     * // If isTaxNonZero is false and MDSE_TX_CDE ==0 OR isTaxNonZero is false and TaxableFlag is N
     * or O, set taxable flag as N , else Y
     * 
     * if((!isTaxNonZero && !YFCCommon.isStringVoid(taxableFlag) &&
     * ((KohlsPOCConstant.NO.equalsIgnoreCase(taxableFlag)) ||
     * (KohlsPOCConstant.OVERRIDE_TAX_O.equalsIgnoreCase(taxableFlag)))) ){
     * XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG,KohlsPOCConstant.NO);
     * for(Element lineTaxEle : lineTaxEleList){ //XMLUtil.setAttribute(lineTaxEle,
     * KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT,KohlsPOCConstant.ZERO_STR);
     * XMLUtil.setAttribute(lineTaxEle,
     * KohlsPOCConstant.ATTR_TAX_PERCENT,KohlsPOCConstant.ZERO_STR); } }else{
     * XMLUtil.setAttribute(linePriceInfo, KohlsPOCConstant.A_TAXABLE_FLAG,KohlsPOCConstant.YES); }
     */
    // Changes for consolidating LineTaxes - Performance - End
    if (logger.isDebugEnabled()) {
      logger.debug("Taxable Flag at linepriceInfo is:"
          + linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG));
    }
    logger.endTimer("KohlsPoCTVSOrderRepriceUE.updateTaxableFlagFromTVS");
  }

  /**
   * 
   * @param arg0 the properties variable
   * @throws Exception the exception
   */
  public void setProperties(Properties arg0) throws Exception {
    this.props = arg0;
  }
  // Sudina - Code changes for TVS phase 2 - Taxware - End

  // Sudina - Code changes for PIF/PUF requirement - Start

  

  // Sudina - Code changes for PIF/PUF requirement - End

  /**
   * orderRepricePsa() is the entry point for PSA flow - TVS request/response.
   * 
   * @param yfsEnv
   * @param inDoc
   * @param psa to decide API for Post sale adjustment
   * @return
   * @throws YFSUserExitException
   */

  private Document orderRepricePSA(YFSEnvironment yfsEnv, Document inDoc)
      throws YFSUserExitException {

    logger.beginTimer("KohlsPoCTVSOrderRepriceUE.orderRepricePsa");

    Document docOrigInpXML = (Document) inDoc.cloneNode(true);
    Document docCloneInpTax = (Document) inDoc.cloneNode(true);
    Document tempDoc = null;
    Element tempOrderEle = null;
    Document tvsResponse = null;
    String shipNode = null;

    KohlsPoCTVSOrderLinePromotionCaller linePromoObj = new KohlsPoCTVSOrderLinePromotionCaller();
    KohlsPoCTVSOrderPromotionsCaller orderPromoObj = new KohlsPoCTVSOrderPromotionsCaller();

    // void TaxWare will store the boolean Yes/No to allow taxware call to happen
    String voidTaxWare = KohlsPOCConstant.NO;

    // This List holds all the existing Promotion Element's 'CreateTS' attribute value.
    List<String> createtsList = new ArrayList<String>();

    try {
      if (logger.isDebugEnabled()) {
        logger.debug("Input XML to the method KohlsPoCTVSOrderRepriceUE.orderRepricePSA is: \n"
            + XMLUtil.getXMLString(inDoc));
      }
      // if no item is in Cart it will return the input document
      Element eleOrderLine = (Element) KohlsXPathUtil.getNode(inDoc.getDocumentElement(),
          "/Order/OrderLines/OrderLine/Item[@ItemID='SKU_VOID_TRAN_ZERO_ITEM']");

      if (!YFCCommon.isVoid(eleOrderLine)) {
        return inDoc;
      }

      // Added for TVS Gap attributes -- Start
      KohlsPoCPnPUtil.updateExtnAttrsOnOrderLineFromItem(yfsEnv, inDoc);
      // Added for TVS Gap attributes -- End
      tempOrderEle = inDoc.getDocumentElement();

      if (!YFCCommon.isVoid(yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE))) {
        String ignoreRepricingUE =
            (String) yfsEnv.getTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE);

        if (KohlsPOCConstant.TRUE.equalsIgnoreCase(ignoreRepricingUE)) {
          yfsEnv.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.FALSE);
          return inDoc;
        }
      }

      // for Associate Disc -- start --

      String maxOrderStatus = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.MAX_ORDER_STATUS);
      if (!KohlsPOCConstant.SUSPEND_STATUS.equalsIgnoreCase(maxOrderStatus)) {
        String customerAssociateNo = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN)
            .getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
        if (!YFCCommon.isVoid(customerAssociateNo)) {
          orderPromoObj.createPromotionElemForAssDisc(yfsEnv, tempOrderEle);
        }
      }

      // for Associate Disc -- end

      // For TLD Promotions
      Element promotionsEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_PROMOTIONS);

      if (!YFCCommon.isVoid(promotionsEle)) {
        promotionsEle.setAttribute(KohlsPOCConstant.RESET, KohlsPOCConstant.YES);
        List<Element> orderPromotionList =
            XMLUtil.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
        if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) {
          // Code to bypass UE implementation logic when Kohls Cash is activated
          /*
           * for (Element promotionEle : orderPromotionList) { String promotionType =
           * XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
           * 
           * if (KohlsPOCConstant.KOHLS_CASH_AWARD.equalsIgnoreCase(promotionType)) {
           * XMLUtil.setAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_APPLIED,
           * KohlsPOCConstant.NO); return XMLUtil.getDocumentForElement(tempOrderEle); } }
           */
          // Order Level Promotions are handled in this method
          orderPromoObj.updateUeDocumentForTLDPSA(orderPromotionList, yfsEnv, tempOrderEle,
              createtsList);
        }
      }
      if (logger.isDebugEnabled()) {
        logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
      List<Element> orderLineList =
          XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_ORDER_LINE);

      if (orderLineList.size() > KohlsPOCConstant.ZERO_INT) {
        // Order Line Level Promotions are handled in this method
        voidTaxWare = linePromoObj.updateUeDocumentForPromoPSA(orderLineList, yfsEnv, tempOrderEle,
            createtsList, orderPromoObj);
      }
      if (logger.isDebugEnabled()) {
        logger.debug("Void TaxWare" + voidTaxWare);
        logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
      // During Suspend , Order Level Promotion is not present , TVS service is not invoked
      if (!linePromoObj.getOrderLineHM().isEmpty() || !orderPromoObj.getOrderTLDHM().isEmpty()) {

        // Changes for #3862 -- POC Returns Team - Start
        String strStoreNum = (String) yfsEnv.getTxnObject(KohlsXMLLiterals.ATTR_ORGANIZATION_CODE);
        logger.debug("Fetching Org Code");
        if (!YFCCommon.isStringVoid(strStoreNum)) {
          logger.debug("PSA Store is" + strStoreNum);
          shipNode = strStoreNum;
        } else {
          shipNode =
              XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        }
        // Changes for #3862 -- POC Returns Team - End

        // Appending zero when store number length is less than 4
        shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);

        Document tvsRequestDoc = new KohlsPoCTVSCaller().constructTVSRequestDocumentPsa(yfsEnv,
            tempOrderEle, orderPromoObj, linePromoObj, createtsList, shipNode);
        if (logger.isDebugEnabled()) {
          logger.debug("The constructed TVS Request" + XMLUtil.getXMLString(tvsRequestDoc));
        }
        tvsResponse = KOHLSBaseApi.invokeService(yfsEnv, KohlsPOCConstant.KOHLS_POC_PSA_WEB_SERVICE,
            tvsRequestDoc);

        Element tvsResponseEle = tvsResponse.getDocumentElement();
        if (logger.isDebugEnabled()) {
          logger.debug("The TVS Response" + XMLUtil.getXMLString(tvsResponse));
        }
        // Checking for SOAP fault
        if (tvsResponseEle.getTagName().equalsIgnoreCase(KohlsPOCConstant.E_ERRORS)) {
          YFSException yfsException = new YFSException();
          String errorCodeStr = XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
              .getAttribute(KohlsPOCConstant.A_ERROR_CODE);
          String errorDesc = XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
              .getAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION);

          if (KohlsPOCConstant.PROMPT_FOR_PRICE.equalsIgnoreCase(errorCodeStr)) {
            String strID = errorDesc.substring(52);
            Map<String, Element> orderLineHM = linePromoObj.getOrderLineHM();
            for (final Map.Entry<String, Element> entry : orderLineHM.entrySet()) {
              String primeLineNo = entry.getKey();
              if (primeLineNo.equalsIgnoreCase(strID)) {
                Element orderLineEle = entry.getValue();
                Element linePriceInfoEle =
                    XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
                String unitPriceStr =
                    XMLUtil.getAttribute(linePriceInfoEle, KohlsPOCConstant.A_UNIT_PRICE);
                if (YFCCommon.isVoid(unitPriceStr)) {
                  yfsException.setErrorCode(KohlsPOCConstant.PLUPRICEREQ);
                }

              }
            }
          } else if (KohlsPOCConstant.OFFER_END_DATE_PASSED.equalsIgnoreCase(errorCodeStr)) {
            yfsException.setErrorCode(KohlsPOCConstant.PLUMGROVRID);
            if (!YFCCommon
                .isStringVoid(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID))) {
              yfsException.setErrorDescription(
                  KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUMGROVRID));
            }

          } else {
            yfsException.setErrorCode(errorCodeStr);
          }
          if (!"OFFER_END_DATE_PASSED".equalsIgnoreCase(errorCodeStr)) {
            yfsException.setErrorDescription(
                XMLUtil.getChildElement(tvsResponseEle, KohlsPOCConstant.E_ERROR)
                    .getAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION));
          }
          throw yfsException;
        }

        logger.debug("APE Response Document Formatted : ");
        if (logger.isDebugEnabled()) {
          logger.debug(XMLUtil.getXMLString(tvsResponse));
        }
        // Invoking new method for #3529 -- Begin

        tvsResponseEle = KohlsPoCPnPUtil.UpdateTVSResponsePSAForTieredOffers(tvsRequestDoc,
            tvsResponseEle, tempOrderEle);

        // Invoking new method for #3529 -- End

        new KohlsPoCTVSPrepareUEResponse().updateUeDocumentFromTVSResponsePSA(yfsEnv,
            tvsResponseEle, tempOrderEle, orderPromoObj, linePromoObj);
        logger.debug("TVS response update finished");
      } else {
        Element extnOrder =
            XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
        XMLUtil.setAttribute(extnOrder, KohlsPOCConstant.A_EXTN_TOTAL_SAVINGS,
            KohlsPOCConstant.ZERO_STR);
      }
      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
    } catch (YFSUserExitException e) {
      this.logger.error(e);
      e.printStackTrace();
      throw e;
    } catch (Exception e) {
      e.printStackTrace();
      YFSException uee = new YFSException();
      if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {
        if (logger.isDebugEnabled()) {
          this.logger.debug("Error class Name" + e.getClass().getName());
        }
        YFSException es = (YFSException) e;

        // Connect Exception
        if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
        }

        // IO Exception
        else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
        }

        // Other Exceptions
        else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
        } else if (es.getErrorCode().equalsIgnoreCase("SOAP_EXCEPTION")) {
          uee.setErrorCode(KohlsPOCConstant.TVSSERVDOWN);
          uee.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.TVSSERVDOWN));
        } else {
          uee.setErrorCode(es.getErrorCode());
          uee.setErrorDescription(es.getErrorDescription());
          throw uee;
        }
        throw uee;
      } else {
        this.logger.error(e);
        uee.setErrorCode("Unknown Error");
        uee.setErrorDescription(e.getMessage());
        throw uee;
      }

    }

    // Call for Taxware
    // Fix for Taxware call, when item is voided
    try {
      if (KohlsPOCConstant.NO.equalsIgnoreCase(voidTaxWare)) {
        // MJ 03/17 Commenting the strTaxwareCall check as its no more required. It was added
        // initially
        // for interim transition to TVS. Now all store have TVS, we dont need this check.
        /*
         * String strTaxwareCall = getProperty(KohlsPOCConstant.TAXWARE_CALL);
         * 
         * if (!YFCCommon.isVoid(strTaxwareCall) &&
         * strTaxwareCall.equalsIgnoreCase(KohlsPOCConstant.YES)) {
         */
        // If TVS call is not made for voided items, tax details are ignored.
        if (!(YFCCommon.isVoid(tvsResponse))) {

          Element eleItemList = (Element) (tvsResponse.getDocumentElement()
              .getElementsByTagName(KohlsPOCConstant.ATTR_ITEM_LIST)).item(0);
          List<Element> responseItemList =
              XMLUtil.getElementsByTagName(eleItemList, KohlsPOCConstant.ELEM_SMALL_ITEM);

          if (responseItemList.size() > KohlsPOCConstant.ZERO_INT) {
            // this updates the tax Line taxes and order extn ExtnTaxDetails elements.
            this.updateTaxwareDetailsFromTVSToUEDocPSA(yfsEnv,responseItemList,
                linePromoObj.getOrderLineHM(), tempOrderEle);
          }
        }
        /*
         * } else { Document taxWareResponse = KOHLSBaseApi.invokeService(yfsEnv,
         * KohlsPOCConstant.KOHLS_POC_TAX_WEB_SERVICE_UTIL,
         * XMLUtil.getDocumentForElement(tempOrderEle)); List<Element> taxwareOrderLineList =
         * XMLUtil.getElementsByTagName( taxWareResponse.getDocumentElement(),
         * KohlsPOCConstant.ELEM_ORDER_LINE); if (taxwareOrderLineList.size() >
         * KohlsPOCConstant.ZERO_INT) { this.updateForUeDocumentFromTaxWarePSA(taxwareOrderLineList,
         * linePromoObj.getOrderLineKeyHM(), linePromoObj.getOrderLineHM(), tempOrderEle); }
         * 
         * }
         */

      }
      if (logger.isDebugEnabled()) {
        this.logger.debug(XMLUtil.getElementXMLString(tempOrderEle));
      }
      removeTempElementFromTempDocument(linePromoObj, orderPromoObj);
      tempOrderEle.setAttribute(KohlsPOCConstant.VALIDATE_PROMOTION_AWARD, KohlsPOCConstant.NO);
      if (logger.isDebugEnabled()) {
        this.logger.debug("Order Element after removing temp element : \n"
            + XMLUtil.getElementXMLString(tempOrderEle));
      }
      tempDoc = XMLUtil.getDocumentForElement(tempOrderEle);
      this.logger.debug("Method Name : orderReprice   and   Status : End ");
    } catch (YFSException UE) {
      YFSUserExitException uee = new YFSUserExitException();
      uee.setErrorCode(UE.getErrorCode());
      uee.setErrorDescription(UE.getErrorDescription());
      throw uee;
    } catch (Exception e) {
      this.logger.error(e);
      e.printStackTrace();
      throw new YFSUserExitException(e.getMessage());
    }


    logger.beginTimer("KohlsOrderReprice.DiffXML");
    KohlsPoCXMLDiff xd = new KohlsPoCXMLDiff();
    try {
      Element eleInputOrderLines =
          (Element) docOrigInpXML.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES).item(0);
      Element eleOutOrderLines =
          (Element) tempDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINES).item(0);
      NodeList nlOrderLines = docOrigInpXML.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
      if (nlOrderLines.getLength() > 0) {
        for (int i = 0; i < nlOrderLines.getLength(); i++) {
          Element eleOrderLine = (Element) nlOrderLines.item(i);
          String sPrimeLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

          // removing Line charges from input xml
          Element eleLineCharges =
              XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
          eleOrderLine.removeChild(eleLineCharges);

          Element eleLineCharges_new =
              XMLUtil.createChild(eleOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES);
          if (!YFCCommon.isVoid(eleLineCharges)) {
            eleLineCharges.setAttribute("Reset", "Y");
            NodeList nlLineCharge =
                eleLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE); // old line
                                                                                        // charge
                                                                                        // from
                                                                                        // inputxml

            logger.debug(
                "eleUEOutOrderLine - LINE CHARGES for primeLineNo" + sPrimeLineNo + " item 0");
            // orderline with same prime line number from updated orderline tempdoc
            // Element eleUEOutOrderLine =
            // (Element)((NodeList)XPathUtil.getNode(tempDoc.getDocumentElement(),"/Order/OrderLines/OrderLine[@PrimeLineNo='"+sPrimeLineNo+"']")).item(0);
            Element eleUEOutOrderLine =
                (Element) ((NodeList) XPathUtil.getNode(tempDoc.getDocumentElement(),
                    "/Order/OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNo + "']"));

            Element eleUEOutLineCharges = null;
            eleUEOutLineCharges =
                XMLUtil.getChildElement(eleUEOutOrderLine, KohlsPOCConstant.ELEM_LINE_CHARGES); // line
                                                                                                // charges
                                                                                                // of
                                                                                                // updated
                                                                                                // orderline
                                                                                                // element

            NodeList nlUEOutLineCharges = null;
            if (!YFCCommon.isVoid(eleUEOutLineCharges)) {
              nlUEOutLineCharges =
                  eleUEOutLineCharges.getElementsByTagName(KohlsPOCConstant.ELEM_LINE_CHARGE); // line
                                                                                               // charge
                                                                                               // list
                                                                                               // inside
                                                                                               // line
                                                                                               // charges
                                                                                               // of
                                                                                               // updated
                                                                                               // orderline
                                                                                               // element
            }
            logger.debug("PrimeLineNo processing is: " + sPrimeLineNo);
            boolean bMatchFound;

            // for every line charges in input orderline, removing the old line charges
            // and creating the line charges again.

            if (nlLineCharge.getLength() > 0) {
              for (int l = 0; l < nlLineCharge.getLength(); l++) {
                Element eleLineCharge = (Element) nlLineCharge.item(l);
                String sChargeName = eleLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
                logger.debug("ChargeName processing is: " + sChargeName);

                Element eleLineCharge_New =
                    XMLUtil.createChild(eleLineCharges_new, KohlsPOCConstant.ELEM_LINE_CHARGE);
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_CHARGE_PER_LINE,
                    eleLineCharge.getAttribute("ChargePerLine"));
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_IS_BILLABLE,
                    KohlsPOCConstant.YES);
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.A_IS_DISCOUNT,
                    KohlsPOCConstant.YES);
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.ATTR_CHARGE_CATEGORY,
                    eleLineCharge.getAttribute("ChargeCategory"));
                XMLUtil.setAttribute(eleLineCharge_New, KohlsPOCConstant.ATTR_CHARGE_NAME,
                    sChargeName);

                bMatchFound = false;

                if (!YFCCommon.isVoid(nlUEOutLineCharges) && nlUEOutLineCharges.getLength() > 0) {
                  for (int m = 0; m < nlUEOutLineCharges.getLength(); m++) {
                    Element eleUEOutLineCharge = (Element) nlUEOutLineCharges.item(m);
                    String sUEOutChargeName =
                        eleUEOutLineCharge.getAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME);
                    logger.debug("UE Out ChargeName is: " + sUEOutChargeName);
                    if (sUEOutChargeName.equalsIgnoreCase(sChargeName)) {
                      bMatchFound = true;
                      logger.debug("Match found for chargeName.");
                      break;
                    }
                  }
                }
                if (!bMatchFound) {
                  logger.debug(
                      "Match not found for chargeName. So resetting the LineCharges on O/P xml");
                  break;
                }
              }
            }
          }

          Element elePromotions = XMLUtil.getChildElement(eleOrderLine, "Promotions");
          if (!YFCCommon.isVoid(elePromotions)) {
            elePromotions.setAttribute("Reset", "Y");
          }
          NodeList nlLineTax = eleOrderLine.getElementsByTagName("LineTax");
          if (nlLineTax.getLength() > 0) {
            for (int j = 0; j < nlLineTax.getLength(); j++) {
              Element eleLineTax = (Element) nlLineTax.item(j);
              eleLineTax.removeAttribute("ChargeNameKey");
              eleLineTax.removeAttribute("InvoicedTax");
              eleLineTax.removeAttribute("Reference_2");
              eleLineTax.removeAttribute("Reference_1");
              eleLineTax.removeAttribute("Reference_3");
              eleLineTax.removeAttribute("RemainingTax");
              eleLineTax.removeAttribute("ChargeNameKey");
              Element eleLineTaxExtn = XMLUtil.getChildElement(eleLineTax, "Extn");
              XMLUtil.removeChild(eleLineTax, eleLineTaxExtn);
            }
          }

          NodeList nlOutLineTax = ((NodeList) XPathUtil.getNodeList(tempDoc.getDocumentElement(),
              "/Order/OrderLines/OrderLine[@PrimeLineNo='" + sPrimeLineNo
                  + "']/LineTaxes/LineTax"));
          if (nlOutLineTax.getLength() > 0) {
            for (int k = 0; k < nlOutLineTax.getLength(); k++) {
              Element eleOutLineTax = (Element) nlOutLineTax.item(k);
              eleOutLineTax.removeAttribute("Reference_1");
              String sTaxPercentage = eleOutLineTax.getAttribute("TaxPercentage");
              if ("0.0".equalsIgnoreCase(sTaxPercentage)) {
                eleOutLineTax.setAttribute("TaxPercentage",
                    KohlsPoCPnPUtil.getDouble(sTaxPercentage));
              }
            }
          }
        }
      }

      if (logger.isDebugEnabled()) {
        logger.debug(
            "UE Input XML going for Diff is: \n" + XMLUtil.getElementXMLString(eleInputOrderLines));

        logger.debug(
            "UE Output XML going for Diff is: \n" + XMLUtil.getElementXMLString(eleOutOrderLines));
      }

      Document diffXML = xd.diffXML(XMLUtil.createDocument(eleInputOrderLines),
          XMLUtil.createDocument(eleOutOrderLines));
      if (logger.isDebugEnabled()) {
        logger.debug("Diff XML is: \n" + XMLUtil.getXMLString(diffXML));
      }

      Element changedOrderLines =
          (Element) diffXML.getDocumentElement().getElementsByTagName("OrderLines").item(0);
      if (!YFCCommon.isVoid(changedOrderLines)) {
        tempDoc.getDocumentElement().removeChild(eleOutOrderLines);
        Element eleOrderLinesOut = (Element) tempDoc.importNode(changedOrderLines, true);
        tempDoc.getDocumentElement().appendChild(eleOrderLinesOut);
        if (logger.isDebugEnabled()) {
          logger.debug("Modified XML is: \n" + XMLUtil.getXMLString(tempDoc));
        }
      } else {
        logger.debug("XMLDiff returned null XML. So returning full xml");
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new YFSUserExitException(e.getMessage());
    }
    logger.endTimer("KohlsOrderReprice.DiffXML");

    Document adujustTaxTempDoc = (Document) tempDoc.cloneNode(true);
    try {
      this.adjusttax(yfsEnv, docCloneInpTax, adujustTaxTempDoc);
    } catch (Exception e) {
      logger.error("Error while calling adjusttax in KohlsPoCTVSOrderRepriceUE.orderRepricePSA");
    }

    logger.endTimer("KohlsPoCTVSOrderRepriceUE.orderRepricePSA");
    return tempDoc;
  }

  /**
   * processRequestForVoid method will remove all the PSA promotions from order element for mid void
   * | post void scenario
 * @param yfsEnv 
   * 
   * @param midVoidRequestDoc
   */
  private void processRequestForVoid(YFSEnvironment yfsEnv, Document midVoidRequestDoc) {
    logger.beginTimer("KohlsPoCTVSOrderRepriceUE. processRequestForVoid");
    logger.debug("Removing PSA promotions for MidVoid/PostVoid");
    Element tempOrderEle = midVoidRequestDoc.getDocumentElement();

    Element elePromotions =
        XMLUtil.getUniqueSubNode(midVoidRequestDoc.getDocumentElement(), "Promotions");
    List<Element> orderPromotionList =
        XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.E_PROMOTION);
    for (Element promotionEle : orderPromotionList) {
      String promtionId = promotionEle.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
      String isPSAPromotion = "N";
      Element extnElement = XMLUtil.getChildElement(promotionEle, KohlsPOCConstant.E_EXTN);
      if (!YFCCommon.isVoid(extnElement)) {
        isPSAPromotion = XMLUtil.getAttribute(extnElement, KohlsPOCConstant.ISPSAPROMOTION);
      }
      if (KohlsPOCConstant.YES.equalsIgnoreCase(isPSAPromotion)) {
        // Fix for PR-688 - Start
        String promtionType = promotionEle.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE);
        if (KohlsPOCConstant.KOHLS_CASH.equalsIgnoreCase(promtionType)) {
          promotionEle.setAttribute("Action", "MODIFY");
          promotionEle.setAttribute("PromotionApplied", "N");
          XMLUtil.setAttribute(extnElement, KohlsPOCConstant.ISPSAPROMOTION, "V");
          if (logger.isDebugEnabled()) {
            logger.debug("KCS PSA promotions :" + XMLUtil.getElementXMLString(promotionEle));
          }
        } else {
          promotionEle.setAttribute("Action", "REMOVE");
          liPSAPromo.add(promotionEle);
          XMLUtil.removeChild(elePromotions, promotionEle);
        }
        // Fix for PR-688 - End
      } else if (("DUMMY_ID").equalsIgnoreCase(promtionId)) {
        XMLUtil.removeChild(elePromotions, promotionEle);
      }
    }
    
    HashMap<String,Element> hmPSAOrigOrderLines = (HashMap<String,Element>)yfsEnv.getTxnObject("PSA_QALIFIED_LINES");
    if(!YFCCommon.isVoid(hmPSAOrigOrderLines) && !hmPSAOrigOrderLines.isEmpty()){
    	Element eleOrderLines = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.ELEM_ORDER_LINES);
    	List<Element> listOrderLine = XMLUtil.getElementsByTagName(tempOrderEle, KohlsPOCConstant.ELEM_ORDER_LINE);
    	for (Element eleOrderLine : listOrderLine) {
    		String strOrderLineKey = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
    		if(hmPSAOrigOrderLines.containsKey(strOrderLineKey)){
    			Element eleAwards = XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_AWARDS);
    			Element elePSAOrigOrderLine = hmPSAOrigOrderLines.get(strOrderLineKey);
    			Element elePSAOrigOrderLineAwards = XMLUtil.getChildElement(elePSAOrigOrderLine, KohlsPOCConstant.E_AWARDS);
    			if(!YFCCommon.isVoid(eleAwards)){
    				List<Element> listOrderLineAwards = XMLUtil.getElementsByTagName(elePSAOrigOrderLineAwards, KohlsPOCConstant.E_AWARD);
    				for (Element eleOrderLineAward : listOrderLineAwards) {
    					String strChargeType = eleOrderLineAward.getAttribute("ChargeCategory");
    					String strAction = eleOrderLineAward.getAttribute("Action");
    					if("FEE".equalsIgnoreCase(strChargeType) && "CREATE".equalsIgnoreCase(strAction)){
    						eleOrderLineAward.removeAttribute("Action");
    						String strAwardAmount = XMLUtil.getAttribute(eleOrderLineAward, KohlsPOCConstant.A_AWARD_AMOUNT);
    						Element eleOrderLineAwardExtn = XMLUtil.getChildElement(eleOrderLineAward, KohlsPOCConstant.E_EXTN);
    						if(!YFCCommon.isVoid(strAwardAmount)){
    							eleOrderLineAwardExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_SALE_PRICE, strAwardAmount);
    						}
    						SCXmlUtil.importElement(eleAwards, eleOrderLineAward);
    					}
    				}
    			}
    		}
    	}
    }
    
    if (logger.isDebugEnabled()) {
      logger.debug("After Removing PSA promotions :" + XMLUtil.getXMLString(midVoidRequestDoc));
    }
    logger.endTimer("KohlsPoCTVSOrderRepriceUE. processRequestForVoid");
  }

  /**
   * 
   * @param input
   * @param output
   * @return
   * @throws Exception
   */
  public void adjusttax(YFSEnvironment env, Document input, Document tempOutputDoc)
      throws Exception {
    List<Element> ueInputOrdLine =
        XMLUtil.getElementsByTagName(input.getDocumentElement(), "OrderLine");
    Map<String, List<Element>> deltaTaxMap = new HashMap<String, List<Element>>();

    for (Element OrderLinele : ueInputOrdLine) {
      String strPrimeLineNo = XMLUtil.getAttribute(OrderLinele, "PrimeLineNo");
      List<Element> eleInpTaxList = XMLUtil.getElementsByTagName(OrderLinele, "LineTax");

      // Element eleOutOrderLine = (Element)KohlsXPathUtil.getNode(output.getDocumentElement(),
      // "/Order/OrderLines/OrderLine[@PrimeLineNo='"+ strPrimeLineNo + "']");

      for (Element LineTaxele : eleInpTaxList) {
        Double inputTax = Double.parseDouble(XMLUtil.getAttribute(LineTaxele, "Tax"));
        if (logger.isDebugEnabled()) {
          logger.debug("The Sale inputDoc tax is :" + inputTax.toString());
        }
        String TaxName = XMLUtil.getAttribute(LineTaxele, "TaxName");
        Element outTaxEle = (Element) KohlsXPathUtil.getNode(tempOutputDoc.getDocumentElement(),
            "/Order/OrderLines/OrderLine[@PrimeLineNo='" + strPrimeLineNo
                + "']/LineTaxes/LineTax[@TaxName='" + TaxName + "']");
        if (null != outTaxEle) {

          Double outTax = Double.valueOf((XMLUtil.getAttribute(outTaxEle, "Tax")));
          if (logger.isDebugEnabled()) {
            logger.debug("The PSA response tax is :" + inputTax.toString());
          }
          Double diffTax = outTax - inputTax;

          DecimalFormat df = new DecimalFormat("0.00");
          String tempFormatted = df.format(diffTax);
          diffTax = Double.valueOf(tempFormatted);
          if (logger.isDebugEnabled()) {
            logger.debug("The difference in tax is :" + diffTax.toString());
          }
          XMLUtil.setAttribute(outTaxEle, "tax", diffTax.toString());
          XMLUtil.setAttribute(outTaxEle, "Tax", diffTax.toString());
        }
      }

      Element outLineTaxesEle = (Element) KohlsXPathUtil.getNode(tempOutputDoc.getDocumentElement(),
          "/Order/OrderLines/OrderLine[@PrimeLineNo='" + strPrimeLineNo + "']/LineTaxes");
      List<Element> tempList = getNewList();
      tempList.add(outLineTaxesEle);

      String orderLineKey = XMLUtil.getAttribute(OrderLinele, "OrderLineKey");
      if (logger.isDebugEnabled()) {
        logger.debug("OrderLineKey and LineTaxes:" + orderLineKey + " ::: "
            + XMLUtil.getElementXMLString(outLineTaxesEle));
      }
      deltaTaxMap.put(orderLineKey, tempList);
    }
    env.setTxnObject("DeltaTax", deltaTaxMap);
  }

  /**
   * 
   * @return
   */
  private List<Element> getNewList() {
    return new ArrayList<Element>();
  }

  public void removePSAPromotion(List<Element> elePsaPromo, Document inDoc) {
    Element elePromotions = XMLUtil.getUniqueSubNode(inDoc.getDocumentElement(), "Promotions");
    if (elePsaPromo.size() > 0) {
      for (Element elePSAPromotion : elePsaPromo) {
        XMLUtil.importElement(elePromotions, elePSAPromotion);
      }
    }
    if (logger.isDebugEnabled()) {
      logger.debug("Append PSA Promotion for Removal:: " + XMLUtil.getXMLString(inDoc));
    }
  }

  /**
   * Updating the UE out document using Taxware details from TVS Response for PSA
   * 
   * @param responseItemList
   * @param orderLineKeyHM
   * @param orderLineHM
   * @param tempOrderEle
   */
  private void updateTaxwareDetailsFromTVSToUEDocPSA(YFSEnvironment yfsEnv, List<Element> responseItemList,
      Map<String, Element> orderLineHM, Element tempOrderEle)
      throws ParserConfigurationException, SAXException, IOException {
    logger.beginTimer("KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDocPSA");
    if (logger.isDebugEnabled()) {
      logger.debug("KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDocPSA:tempOrderEle\n"
          + XMLUtil.getElementXMLString((tempOrderEle)));
    }
    Set<Double> set = new TreeSet<Double>(Collections.reverseOrder());
    Map<String, Element> taxDetailsMap = new HashMap<String, Element>();
    boolean nullifyTaxPercentage = false;
    String sTaxExemptionCert =
        XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.ATTR_TAX_EXEMPT_CERTIFICATE);
    String sTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle, "TaxExemptFlag");
    Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.A_EXTN);
    String sExtnTaxExemptCustFlag =
        XMLUtil.getAttribute(eleOrderExtn, KohlsPOCConstant.ATTR_EXTN_TAX_EXEMPT_CUST_FLAG);
    if (logger.isDebugEnabled()) {
      logger.debug("sTaxExemptionCert + sExtnTaxExemptCustFlag::::::" + sTaxExemptionCert + "\t"
          + sExtnTaxExemptCustFlag);
    }
    double dPSATotalFeeTaxAmount=KohlsPOCConstant.ZERO_DBL;
    
    HashMap <String, Double> mapFeePromotion = new HashMap<String, Double>();
    
    for (Element eleResponseItem : responseItemList) {
      String strUniqueId = XMLUtil.getAttribute(eleResponseItem, KohlsPOCConstant.ATTR_ID);
      String strExtnRecycleFeeID = null;
      if (null != strUniqueId && orderLineHM.containsKey(strUniqueId)) {
        logger.debug("Unique Id exists in OrderLine HM");
        Element orderLineEle = orderLineHM.get(strUniqueId);
        Element linePriceInfo =
            XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
        String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
        if (!YFCCommon.isVoid(sTaxExemptionCert)
            || ((!YFCCommon.isStringVoid(sTaxExemptFlag))
                && KohlsPOCConstant.YES.equalsIgnoreCase(sTaxExemptFlag))
            || (!YFCCommon.isVoid(taxableFlag)
                && ("N".equalsIgnoreCase(taxableFlag) || "O".equalsIgnoreCase(taxableFlag)))
            || (!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
                && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
          if (!YFCCommon.isVoid(sTaxExemptionCert) || ((!YFCCommon.isStringVoid(sTaxExemptFlag))
              && KohlsPOCConstant.YES.equalsIgnoreCase(sTaxExemptFlag))) {
            logger.debug(
                "Order has the Tax Exempt certificate or TaxExemptFlag is Y, hence setting the tax percentage as 0");
          } else if ((!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
              && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
            logger.debug("Order has Tax exempt customer, hence setting the tax percentage as 0");
          } else {
            logger.debug("OrderLine has TaxableFlag=N, hence setting the tax percentage as 0");
          }
          nullifyTaxPercentage = true;
        }

        if (!YFCCommon.isVoid(eleResponseItem)) {



          // Element lineTaxesEle = XMLUtil.getChildElement(eleResponseItem,
          // KohlsPOCConstant.SMALL_ELEM_LINE_TAXES);
          Element lineTaxesEle =
              XMLUtil.getChildElement(eleResponseItem, KohlsPOCConstant.ELEM_LINE_TAXES);
          // Fix for defect 966 - Start
          strExtnRecycleFeeID = eleResponseItem.getAttribute("extnRecycleFeeId");
          logger.debug("The strExtnRecycleFeeID value is: " + strExtnRecycleFeeID);
          // Fix for defect 966 - End
          // Fix for defect 1172 - Start
          if (!YFCCommon.isVoid(lineTaxesEle)) {
            if (lineTaxesEle.hasChildNodes()) {
              // logger.debug("Insidde if loop having line tax");
              updateTaxableFlagFromTVS(orderLineEle, lineTaxesEle, nullifyTaxPercentage);
              Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
              // KohlsPoCPnPUtil.addTaxDetailsFromTVSToTempElement(lineTaxesEle,tempEle,set);
              KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(lineTaxesEle, tempEle, set);
              if (!YFCCommon.isVoid(strExtnRecycleFeeID)) {
                logger.debug(
                    "The strExtnRecycleFeeID value inside if loop is: " + strExtnRecycleFeeID);
                Element eleOrderLineExtn =
                    XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
                if (logger.isDebugEnabled()) {
                  logger.debug("The eleOrderLineExtn value is: "
                      + XMLUtil.getElementXMLString(eleOrderLineExtn));
                }
                eleOrderLineExtn.setAttribute("ExtnRecycleFeeCode", strExtnRecycleFeeID);
                orderLineEle.appendChild(eleOrderLineExtn);
                if (logger.isDebugEnabled()) {
                  logger.debug(
                      "The orderLineEle value is: " + XMLUtil.getElementXMLString(orderLineEle));
                }

              }
              // Sprint 9.1 : END //
              Element lineTaxesEle1 =
                  XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
              XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
              XMLUtil.importElement(orderLineEle, lineTaxesEle);
            } else {
              // logger.debug("Insidde else loop having line tax");
              Element lineTaxesEle1 =
                  XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
              XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
              if (YFCCommon.isVoid(eleDummylineTaxes_TVSTaxExempt)) {
                /*
                 * File fXmlLinetaxes = new File(
                 * "/kohls/prop/of/Foundation/extensions/global/template/api/POC/saleshub/LineTaxesForTVSTaxExempt.xml"
                 * ); DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
                 * DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder(); Document
                 * docLineTaxes = dBuilder1.parse(fXmlLinetaxes); eleDummylineTaxes_TVSTaxExempt =
                 * docLineTaxes.getDocumentElement();
                 */
                eleDummylineTaxes_TVSTaxExempt =
                    XMLUtil.createChild(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);
                /*
                 * KohlsPocTaxServiceUtil.simulateTaxLineTaxesForTVSTaxExempt(
                 * eleDummylineTaxes_TVSTaxExempt);
                 */
                KohlsPocTaxServiceUtil
                    .simulateSingleTaxLineForTVSTaxExempt(eleDummylineTaxes_TVSTaxExempt);
                eleDummylineTaxes_TVSTaxExempt.setAttribute("TaxExemptApplied", "Y");
                if (logger.isDebugEnabled()) {
                  logger.debug(
                      "The file is read. The eleDummylineTaxes_TVSTaxExempt is read for the first time: "
                          + XMLUtil.getElementXMLString(eleDummylineTaxes_TVSTaxExempt));
                }
              } else {
                if (logger.isDebugEnabled()) {
                  logger.debug("The file is read from Static variable: "
                      + XMLUtil.getElementXMLString(eleDummylineTaxes_TVSTaxExempt));
                }
                XMLUtil.importElement(orderLineEle, eleDummylineTaxes_TVSTaxExempt);
              }
              updateTaxableFlagFromTVS(orderLineEle, eleDummylineTaxes_TVSTaxExempt, true);
              Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
              KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(eleDummylineTaxes_TVSTaxExempt,
                  tempEle, set);
            }
          }
          // Fix for defect 1172 - End

        }
        List<Element> lLineAwards =   XMLUtil.getElementsByTagName(orderLineEle,KohlsPOCConstant.E_AWARD);
        HashMap<String,String> sOrigFee = new HashMap<String,String>(); 
        for (Element eleAward :lLineAwards ){
        	if(eleAward.getAttribute(KohlsPOCConstant.PROMOTIONID).contains(KohlsPOCConstant.CONST_FEE) &&
        			KohlsPOCConstant.REMOVE.equalsIgnoreCase(eleAward.getAttribute(KohlsPOCConstant.ACTION))){
        		Element eAwardExtn = XMLUtil.getChildElement(eleAward, KohlsPOCConstant.E_EXTN,true);
        		String strExtnSalePrice = XMLUtil.getAttribute(eAwardExtn, KohlsPOCConstant.ATTR_EXTN_SALE_PRICE);
        		if(YFCCommon.isVoid(strExtnSalePrice)){
        			strExtnSalePrice = XMLUtil.getAttribute(eleAward, KohlsPOCConstant.A_AWARD_AMOUNT);
        		}
        		sOrigFee.put(eleAward.getAttribute(KohlsPOCConstant.PROMOTIONID), eAwardExtn.getAttribute(KohlsPOCConstant.ATTR_EXTN_SALE_PRICE));
        	}
        }
        List<Element> ndFeeList = XMLUtil.getElementsByTagName(eleResponseItem, KohlsPOCConstant.SMALL_ATTR_FEES);
        if (!YFCCommon.isVoid(ndFeeList) && ndFeeList.size() > KohlsPOCConstant.ZERO_INT) {
        	logger.debug(
        			"KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDoc----- Fee element exists");
        	String storeNumber = XMLUtil.getAttribute(tempOrderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        	Element customAttributesEle = SCXmlUtil.getChildElement(tempOrderEle, KohlsPOCConstant.CUST_ATTRIBUTES);
        	String eComOrderNo = null;
        	if(!YFCCommon.isVoid(customAttributesEle))
        	{
        		eComOrderNo = customAttributesEle.getAttribute(KohlsPOCConstant.TEXT13);
        	}
        
        	try {
        		if(YFCCommon.isVoid(eComOrderNo)){
        			String strLineFeeAmountRate = KohlsPoCPnPUtil.updateFeeDetails(ndFeeList, orderLineEle,"-",sOrigFee, mapFeePromotion);
        			double dLineFeeAmount = KohlsPoCPnPUtil.getRateBasedLineTaxFeeAmount(strLineFeeAmountRate);
        			dPSATotalFeeTaxAmount = dPSATotalFeeTaxAmount + dLineFeeAmount;
        		}else{
        			logger.debug("TaxFee details not updated since its ECom Store");
        		}
        	}catch(Exception e){
        		logger.debug("Exception while updating Fee Details: "+e.getMessage());
        	}
        }
      }
    }
   
    String strExtnTaxDetails = eleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS);
    
    Document dTaxDetails = XMLUtil.getDocument(strExtnTaxDetails) ;
    String strTotalFeeTaxAmount = XMLUtil.getAttribute(dTaxDetails.getDocumentElement(),KohlsPOCConstant.Total_Fee_Tax_Amount);

    try{
    	if(YFCCommon.isVoid(strTotalFeeTaxAmount)){
    		strTotalFeeTaxAmount = KohlsPOCConstant.ZERO_STR;
    	}
    	Double dPSAAdjFeeTaxAmt = KohlsPOCConstant.ZERO_DBL;
    	boolean isPSAAFeePromotionReq = false;
    	if((!YFCCommon.isVoid(strTotalFeeTaxAmount) || !YFCCommon.isVoid(dPSATotalFeeTaxAmount)) && 
    			((!KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(strTotalFeeTaxAmount) && Double.valueOf(strTotalFeeTaxAmount)>0) || dPSATotalFeeTaxAmount>0)){
    		dPSAAdjFeeTaxAmt = Double.valueOf(strTotalFeeTaxAmount) - dPSATotalFeeTaxAmount;
    		if(dPSAAdjFeeTaxAmt<0){
    			dPSAAdjFeeTaxAmt = Math.abs(dPSAAdjFeeTaxAmt);
    			isPSAAFeePromotionReq = true;
    		}else if(dPSAAdjFeeTaxAmt>0){
    			dPSAAdjFeeTaxAmt = 0 - dPSAAdjFeeTaxAmt;
    			isPSAAFeePromotionReq = true;
    		}
    		if(isPSAAFeePromotionReq && !YFCCommon.isVoid(dPSAAdjFeeTaxAmt)){
    			String strPSAAdjFeeTaxAmt = String.valueOf(new DecimalFormat("0.00").format(dPSAAdjFeeTaxAmt));
    			KohlsPoCPnPUtil.updateFeePromotionDetailsForPSA(tempOrderEle, strPSAAdjFeeTaxAmt, mapFeePromotion);
    		}
    	}
    }catch (Exception e){
    	logger.debug("PSA Tax Fee not updated, since TotalFeeTaxAmount is not available in Original Sale Reference");
    }
   
    Document taxIndicatorsDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element taxDetailListEle = taxIndicatorsDoc.getDocumentElement();
    Iterator ite = orderLineHM.keySet().iterator();

    while (ite.hasNext()) {
      String guid = (String) ite.next();
      if (orderLineHM.containsKey(guid)) {
        Element orderLineEle = orderLineHM.get(guid);
        Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
        Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);

        Element linePriceInfoEle =
            XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
        String taxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);

        Element extnOrderEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
        String extnAgencyName = extnOrderEle.getAttribute(KohlsPOCConstant.A_AGENCY_NAME);

        if (KohlsPOCConstant.YES.equalsIgnoreCase(taxableFlag)
            || !YFCCommon.isVoid(extnAgencyName)) {
          String extnTaxIndicator =
              KohlsPoCPnPUtil.updateTaxDetails(set, taxDetailsMap, tempEle, taxDetailListEle);
          XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR, extnTaxIndicator);
        } else {
          XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR,
              KohlsPOCConstant.CONST_HASH);
        }
      }

      Element orderExtnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
      if(!KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(strTotalFeeTaxAmount) && 
    		  !KohlsPOCConstant.ZERO_DOT_ZERO.equalsIgnoreCase(strTotalFeeTaxAmount)){
    	  XMLUtil.setAttribute(taxDetailListEle, KohlsPOCConstant.Total_Fee_Tax_Amount, strTotalFeeTaxAmount);
      }
      orderExtnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
          XMLUtil.getElementXMLString(taxDetailListEle));
      if (logger.isDebugEnabled()) {
        logger.endTimer(
            "KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDocPSA----- taxDetailListEle\n"
                + XMLUtil.getElementXMLString(taxDetailListEle));
      }
      logger.endTimer("KohlsPoCTVSOrderRepriceUE.updateTaxwareDetailsFromTVSToUEDocPSA");
    }

  }

  /**
   * Updating the UE out document using Taxware details
   * 
   * @param taxwareOrderLineList
   * @param orderLineKeyHM
   * @param orderLineHM
   * @param tempOrderEle
   */
  private void updateForUeDocumentFromTaxWarePSA(List<Element> taxwareOrderLineList,
      Map<String, String> orderLineKeyHM, Map<String, Element> orderLineHM, Element tempOrderEle)
      throws ParserConfigurationException, SAXException, IOException {
    this.logger.debug("Method Name : updateForUeDocumentFromTaxWare   and   Status : Start ");

    Set<Double> set = new TreeSet<Double>(Collections.reverseOrder());
    Map<String, Element> taxDetailsMap = new HashMap<String, Element>();
    // Fix for CR 5462 - Start
    boolean nullifyTaxPercentage = false;
    String sTaxExemptionCert = tempOrderEle.getAttribute("TaxExemptionCertificate");

    Element eleOrderExtn = XMLUtil.getChildElement(tempOrderEle, "Extn");
    String sExtnTaxExemptCustFlag = eleOrderExtn.getAttribute("ExtnTaxExemptCustFlag");
    String sTaxExemptFlag = XMLUtil.getAttribute(tempOrderEle, "TaxExemptFlag");
    // Fix for CR 5462 - End

    for (Element taxwareOLEle : taxwareOrderLineList) {
      String orderLineKey =
          XMLUtil.getAttribute(taxwareOLEle, KohlsPOCConstant.ATTR_ORDER_LINE_KEY);
      String guid = orderLineKeyHM.get(orderLineKey);
      // Sprint 9.1 : START - Defect 4354//
      String strExtnRecycleFeeID = null;
      // Sprint 9.1 : END - Defect 4354//
      if (null != guid && orderLineHM.containsKey(guid)) {
        Element orderLineEle = orderLineHM.get(guid);

        Element lineTaxesEle =
            XMLUtil.getChildElement(taxwareOLEle, KohlsPOCConstant.ELEM_LINE_TAXES);
        // Sprint 9.1 : START //
        Element eleExtn = XMLUtil.getChildElement(taxwareOLEle, KohlsPOCConstant.A_EXTN);
        if (!YFCCommon.isVoid(eleExtn)) {
          strExtnRecycleFeeID = eleExtn.getAttribute("ExtnRecycleFeeID");
        }
        // Sprint 9.1 : END //


        if (!YFCCommon.isVoid(lineTaxesEle)) {
          Element lineTaxesEle1 =
              XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.ELEM_LINE_TAXES);

          // Fix for CR 5462 - Start
          Element linePriceInfo =
              XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
          String taxableFlag = linePriceInfo.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);
          if (!YFCCommon.isVoid(sTaxExemptionCert)
              || ((!YFCCommon.isStringVoid(sTaxExemptFlag))
                  && KohlsPOCConstant.YES.equalsIgnoreCase(sTaxExemptFlag))
              || (!YFCCommon.isVoid(taxableFlag)
                  && ("N".equalsIgnoreCase(taxableFlag) || "O".equalsIgnoreCase(taxableFlag)))
              || (!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
                  && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
            if (!YFCCommon.isVoid(sTaxExemptionCert) || ((!YFCCommon.isStringVoid(sTaxExemptFlag))
                && KohlsPOCConstant.YES.equalsIgnoreCase(sTaxExemptFlag))) {
              logger.debug(
                  "Order has the Tax Exempt certificate or TaxExemptFlag is Y, hence setting the tax percentage as 0");
            } else if ((!YFCCommon.isVoid(sExtnTaxExemptCustFlag)
                && "Y".equalsIgnoreCase(sExtnTaxExemptCustFlag))) {
              logger.debug("Order has Tax exempt customer, hence setting the tax percentage as 0");
            } else {
              logger.debug("OrderLine has TaxableFlag=N, hence setting the tax percentage as 0");
            }
            nullifyTaxPercentage = true;
          }
          updateTaxableFlag(orderLineEle, lineTaxesEle, nullifyTaxPercentage);
          // Commented below method call since MerchandiseTaxCode is not coming in TVS Response
          // updateTaxableFlag(orderLineEle,lineTaxesEle);
          // Fix for CR 5462 - End

          Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
          KohlsPoCPnPUtil.addTaxDetailsInLineTempElement(lineTaxesEle, tempEle, set);


          // Sprint 9.1 :START //
          if (!YFCCommon.isVoid(strExtnRecycleFeeID)) {

            Element eleOrderLineExtn =
                XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.A_EXTN);
            eleOrderLineExtn.setAttribute("ExtnRecycleFeeCode", strExtnRecycleFeeID);
            orderLineEle.appendChild(eleOrderLineExtn);
          }
          // Sprint 9.1 : END //
          XMLUtil.removeChild(orderLineEle, lineTaxesEle1);
          XMLUtil.importElement(orderLineEle, lineTaxesEle);
        }
      }
    }

    /**
     * Below statement used form the CLOB xml
     * <TaxIndicators> <TaxIndicator EffectiveTaxRate="" TaxAmount="" TaxRateIndicator=""
     * TotalAmount=""/> </TaxIndicators>
     */

    Document taxIndicatorsDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TAX_DETAIL_LIST);
    Element taxDetailListEle = taxIndicatorsDoc.getDocumentElement();
    Iterator ite = orderLineHM.keySet().iterator();

    while (ite.hasNext()) {
      String guid = (String) ite.next();
      Element orderLineEle = orderLineHM.get(guid);
      Element tempEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_TEMP);
      Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);

      Element linePriceInfoEle =
          XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
      String taxableFlag = linePriceInfoEle.getAttribute(KohlsPOCConstant.A_TAXABLE_FLAG);

      Element extnOrderEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
      String extnAgencyName = extnOrderEle.getAttribute(KohlsPOCConstant.A_AGENCY_NAME);

      // Fix for defect 26757 - Start
      if (KohlsPOCConstant.YES.equalsIgnoreCase(taxableFlag) || !YFCCommon.isVoid(extnAgencyName))
      // Fix for defect 26757 - End
      {
        if (logger.isDebugEnabled()) {
          logger.debug("----- tempElement beofre updateTaxDetails ----- "
              + XMLUtil.getElementXMLString(tempEle));
        }
        String extnTaxIndicator =
            KohlsPoCPnPUtil.updateTaxDetails(set, taxDetailsMap, tempEle, taxDetailListEle);
        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR, extnTaxIndicator);
      } else {
        XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_TAX_INDICATOR,
            KohlsPOCConstant.CONST_HASH);
      }
    }

    Element orderExtnEle = XMLUtil.getChildElement(tempOrderEle, KohlsPOCConstant.E_EXTN);
    orderExtnEle.setAttribute(KohlsPOCConstant.A_EXTN_TAX_DETAILS,
        XMLUtil.getElementXMLString(taxDetailListEle));

    this.logger.debug("Method Name : updateForUeDocumentFromTaxWare   and   Status : End  ");
  }
}
