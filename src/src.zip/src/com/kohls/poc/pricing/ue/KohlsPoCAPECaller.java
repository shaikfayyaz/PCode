package com.kohls.poc.pricing.ue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;



/**************************************************************************
 * File : KohlsPoCAPECaller.java 
 * Author : IBM 
 * Created : August 27 2013 
 * Modified : August 27 2013 
 * Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 27/08/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO : 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 *
 * This class is used to construct APE Request XML using PLU Promo Response, PLU Offer Respose, Kohls Cash Respose
 * and other Order and Order Line Promotions. 
 * 
 * @author IBM India Pvt Ltd
 * @version 0.1
 *****************************************************************************/

public class KohlsPoCAPECaller {

	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCAPECaller.class.getName());
	}

	DecimalFormat twoDForm = new DecimalFormat(KohlsPOCConstant.DECIMAL_FORMAT);


	/**
	 *  
	 *  This is the main method used for construct the APE Request XML using PLU Responses, Gravity Inputs.
	 *  
	 *  	 *  
	 * @param orderEle
	 * @param promoObj
	 * @param offerAndKohlsCashObj
	 * @param createtsList
	 * @param yfsEnv 
	 * @return apeRequestDoc
	 * @throws Exception 
	 */
	public Document constructApeRequestDocument(Element orderEle, KohlsPoCOrderLinePromotionsCaller promoObj, KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj, List<String> createtsList, YFSEnvironment yfsEnv) throws Exception {
		logger.beginTimer("KohlsPoCAPECaller.constructApeRequestDocument");

		this.logger.debug("Method Name : constructApeRequestDocument   and   Status : Start ");

		final Document apeRequestDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TRANSACTION);
		Element apeRequestEle =  apeRequestDoc.getDocumentElement();
		String shipNode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		//Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);
		XMLUtil.setAttribute(apeRequestEle, KohlsPOCConstant.A_STORE_APE, shipNode);
		XMLUtil.setAttribute(apeRequestEle, KohlsPOCConstant.A_TRAN_DATE_TIME_APE, KohlsPoCPnPUtil.getCurrentDateString());

		// Before accessing the Promotion/CreateTS list , it is sorted
		Collections.sort(createtsList);

		Element itemList = XMLUtil.createChild(apeRequestEle, KohlsPOCConstant.E_ITEM_LIST);
		Map<String, Element> orderLineHM = promoObj.getOrderLineHM();
		for (final Map.Entry<String, Element> entry : orderLineHM.entrySet()) {
			this.constructAPERequestFromPromoResponse(entry, itemList, createtsList);
		}

		Map<String, Element> orderPromotionHM = offerAndKohlsCashObj.getOrderCouponHM();
		for (final Map.Entry<String, Element> entry : orderPromotionHM.entrySet()) {
			this.constructAPERequestFromCouponResponse(entry, apeRequestEle, createtsList);
		}

		Map<String, Element> orderManualTldHM = offerAndKohlsCashObj.getOrderManualTldHM();
		for (final Map.Entry<String, Element> entry : orderManualTldHM.entrySet()) {
			this.constructAPERequestFromManualTld(entry, apeRequestEle, createtsList);
		}

		Map<String, Element> orderKohlsCashHM = offerAndKohlsCashObj.getOrderKohlsCashHM();
		for (final Map.Entry<String, Element> entry : orderKohlsCashHM.entrySet()) {
			this.constructAPERequestFromKohlsCashResponse(entry, apeRequestEle, createtsList);
		}

		Map<String, Element> orderSeniorCitizenHM = offerAndKohlsCashObj.getOrderSeniorDiscountHM();
		for (final Map.Entry<String, Element> entry : orderSeniorCitizenHM.entrySet()) {
			this.constructAPERequestFromSeniorCitizenResponse(entry,apeRequestEle,createtsList,orderEle, yfsEnv);
		}

		Map<String, Element> orderOfflineKohlsCashHM = offerAndKohlsCashObj.getOrderOfflineKohlsCashHM();
		for (final Map.Entry<String, Element> entry : orderOfflineKohlsCashHM.entrySet()) {
			this.constructAPERequestFromOfflineKohlsCashResponse(entry,apeRequestEle,createtsList);
		}

		// Commented the below code for Sprint 5
		
		/*String ruleIdBeautyExclusion = KohlsPOCConstant.BEAUTY_DEPARTMENT_LIST;

		//Calling getRuleListForPOS API for Beauty Exclusion
		Document beautyExclusionAPIoutDoc = KohlsPoCPnPUtil.getRuleListForPOSCaller(yfsEnv, orderEle, ruleIdBeautyExclusion);
		Element beautyExclusionAPIOutEle = beautyExclusionAPIoutDoc.getDocumentElement();
		this.constructAPERequestFromBeautyExclusionResponse(beautyExclusionAPIOutEle, apeRequestEle);*/
		
		// Suresh : Added for Nike Exclusions Sprint 5 : Start
		
		// retrieving exclusion rules and forming APE request
		KohlsPoCPnPUtil.constructAPERequestFromExclusionRules(yfsEnv, apeRequestEle);
		
		// Suresh : Added for Nike Exclusions Sprint 5 : End

		
		

		//AssociateDiscount
		String maxOrderStatus = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.MAX_ORDER_STATUS);
		if (!KohlsPOCConstant.SUSPEND_STATUS.equalsIgnoreCase(maxOrderStatus)) {
			String customerAssociateNo = XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_EXTN).getAttribute(KohlsPOCConstant.A_EXTN_CUSTOMER_ASSOCIATE_NO);
			if(!YFCCommon.isVoid(customerAssociateNo)){
				
					//Added for 3945 defect fix --- Start
				Element promotionsEle =  XMLUtil.getChildElement(orderEle, KohlsPOCConstant.E_PROMOTIONS);
				String assocatePromotion = KohlsPOCConstant.NO;
				
				if (!YFCCommon.isVoid(promotionsEle))
				{
					List<Element> orderPromotionList = XMLUtil
							.getElementsByTagName(promotionsEle, KohlsPOCConstant.E_PROMOTION);
					if (orderPromotionList.size() > KohlsPOCConstant.ZERO_INT) 
					{
						for (Element promotionEle : orderPromotionList) 
						{
							String promotonType = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
							String promoID = XMLUtil.getAttribute(promotionEle, KohlsPOCConstant.A_PROMOTION_ID);
							
							//Changed the constant in below line
							if(!promotonType.equals(KohlsPOCConstant.ASSOCIATE_DISCOUNT))
								continue;
							else {
								if(promoID.equals(KohlsPOCConstant.ASSOC_DISC_MANUAL_HARD_LINE))
								{
									XMLUtil.removeChild(promotionsEle, promotionEle);
								}
								else
								{
									assocatePromotion = KohlsPOCConstant.YES;
									Element extnPromotonEle = XMLUtil.getChildElement(promotionEle,KohlsPOCConstant.E_EXTN);								
									String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(promotionEle, createtsList);												
									XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
									String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(promotionEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
									offerAndKohlsCashObj.setOrderAssociateDisHM(guidStr, promotionEle);								
									
									
								}
							}
								
						}
				}
					
					
					
					if(assocatePromotion.equals(KohlsPOCConstant.NO))
					{
						Element promotonEle = XMLUtil.createChild(promotionsEle,KohlsPOCConstant.E_PROMOTION);
						XMLUtil.setAttribute(promotonEle, "IsInternal", KohlsPOCConstant.YES);
						XMLUtil.setAttribute(promotonEle, "PromotionGroup", "MANUAL");
						
						
						XMLUtil.setAttribute(promotonEle, KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT);
						Element extnPromotonEle = XMLUtil.getChildElement(promotonEle,KohlsPOCConstant.E_EXTN,Boolean.TRUE);								
						String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(promotonEle, createtsList);												
						XMLUtil.setAttribute(extnPromotonEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
						String guidStr = KohlsPoCPnPUtil.insertGuidAttributeInELement(promotonEle, KohlsPOCConstant.E_TEMP, KohlsPOCConstant.A_GUID);
						
					/*	//Added for cloning element -- start
						Element newPromotion = (Element)promotonEle.cloneNode(true);						
						offerAndKohlsCashObj.setOrderAssociateDisHM(guidStr,newPromotion);
						//Added for cloning element -- end
						
						//Commented below line
						//*/
						
						//Added for defect 4656 fix - Start
						
						String markdown = KohlsPOCConstant.EMPTY;
						String secondaryMarkdownValue = KohlsPOCConstant.EMPTY;
						String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;
						// call new method by sending the business date, rule id, enterprise code and set the extnDiscountPercent attribute
						String strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,orderEle,ruleId).trim();
						String [] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
						int length1 = delimitedComma[0].length() - 1;
						markdown= String.valueOf(delimitedComma[0].substring(0,length1));
						
						String[] args = {markdown};
						XMLUtil.setAttribute(promotonEle,  KohlsPOCConstant.A_DESCRIPTION,
								KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.ASSOCIATE_DISCOUNT_PROP_KEY, args));
						//Added for defect 4656 fix - End
						
						offerAndKohlsCashObj.setOrderAssociateDisHM(guidStr, promotonEle);
						
						
						
					}
					
				}

					//Added for 3945 defect fix --- End
				constructAPERequestFromAssociateResponse(yfsEnv, orderEle,apeRequestEle,createtsList,offerAndKohlsCashObj);
			}
		}

		this.logger.debug("Method Name : constructApeRequestDocument   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructApeRequestDocument");

		return apeRequestDoc;


	}
	
	/**
	 * This method constructs the APE request for KohlsCash Offline Mode
	 * @param Element apeRequestEle
	 * @param Entry<String, Element> entry
	 * @param List<String> createtsList
	 */ 
	private void constructAPERequestFromOfflineKohlsCashResponse(
			Entry<String, Element> entry, Element apeRequestEle,
			List<String> createtsList) {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromOfflineKohlsCashResponse");
		this.logger.debug("Method Name : constructAPERequestFromOfflineKohlsCashResponse   and   Status : Start ");
		String guidPromotion = entry.getKey();
		Element offlineKohlsCashPromotionElement =  entry.getValue();

		//String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
		//String overrideMaxAdjustment = XMLUtil.getAttribute(offlineKohlsCashPromotionElement, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
		Element tempEle = XMLUtil.getChildElement(offlineKohlsCashPromotionElement, KohlsPOCConstant.E_TEMP,Boolean.TRUE);

		Element extnEle = XMLUtil.getChildElement(offlineKohlsCashPromotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
		String extnCouponAmount = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT);

		/*if(YFCCommon.isStringVoid(extnCouponAmount)){
			if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
				overrideAdjustmentValue = overrideMaxAdjustment;
			} else {
				overrideAdjustmentValue = XMLUtil.getAttribute(offlineKohlsCashPromotionElement, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
			}
			overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,overrideAdjustmentValue);
		}else{
			overrideAdjustmentValue = extnCouponAmount;
		}*/

		Element manualTldEle = null;
		manualTldEle = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_MANUAL_TLD);
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_GUID, guidPromotion);
		
		 // Suresh : Added for TLD pushdown : Start
		
		String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(offlineKohlsCashPromotionElement, createtsList);
		
		XMLUtil.setAttribute(manualTldEle,KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);
		
		
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
		 // Suresh : Added for TLD pushdown : End

		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, extnCouponAmount);
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_DOLLAR_OFF);

		// Fix for Defect 2496 , changed IE Indicator to None, to control <Departments/> in the APE request
		//XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_IE_INDICATOR, KohlsPOCConstant.EXCLUDE);

		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_IE_INDICATOR, "None");

		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_LEGACY_FLAG, KohlsPOCConstant.YES);
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.YES);
		XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.YES);
		//Element departmentsEle = XMLUtil.createChild(manualTldEle,KohlsPOCConstant.E_DEPARTMENTS);

		this.logger.debug("Method Name : constructAPERequestFromOfflineKohlsCashResponse   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromOfflineKohlsCashResponse");


	}
	/**
	 * This method constructs the APE request for KohlsCash Response for LEGACY and KOHLSCASH
	 * @param Element apeRequestEle
	 * @param Entry<String, Element> entry
	 * @param List<String> createtsList
	 * @throws ParserConfigurationException indicates a serious configuration error
	 * @throws SAXException encapsulates a general SAX error or warning
	 * @throws IOException indicates that an I/O exception of some sort has occurred
	 */ 	
	private void constructAPERequestFromKohlsCashResponse(Entry<String, Element> entry, Element apeRequestEle, List<String> createtsList) throws ParserConfigurationException, SAXException, IOException {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromKohlsCashResponse");

		this.logger.debug("Method Name : constructAPERequestFromKohlsCashResponse   and   Status : Start ");

		String guidPromotion = entry.getKey();
		Element kohlsCashPromotionElement =  entry.getValue();

		Element extnEle = XMLUtil.getChildElement(kohlsCashPromotionElement, KohlsPOCConstant.E_EXTN);
		Element tempEle = XMLUtil.getChildElement(kohlsCashPromotionElement, KohlsPOCConstant.E_TEMP,Boolean.TRUE);
		Element kohlsCashResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
		List<Element> dataEleList = XMLUtil.getElementsByTagName(kohlsCashResposneEle, KohlsPOCConstant.E_DATA);
		if(dataEleList.size() > KohlsPOCConstant.ZERO_INT && null != dataEleList.get(KohlsPOCConstant.ZERO_INT)){
			Element dataElement = dataEleList.get(KohlsPOCConstant.ZERO_INT);
			String legacyDoller = dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_DOLLAR);
			String legacyPercent =  dataElement.getAttribute(KohlsPOCConstant.A_LEGACY_PERCENT);
			String couponType =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_TYPE);
			String couponStatus =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_STATUS);
			String couponBalance =  dataElement.getAttribute(KohlsPOCConstant.A_COUPON_BALANCE);
			String authResponseCode =  dataElement.getAttribute(KohlsPOCConstant.A_AUTH_RESPONSE_CODE);
			String includeExcludeFlag = dataElement.getAttribute(KohlsPOCConstant.A_INCLUDE_ENCLUDE_FLAG);
			Element manualTldEle = null;
			if(KohlsPOCConstant.LEGACY.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)){
				manualTldEle = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_MANUAL_TLD);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_GUID, guidPromotion);
				
				
				 // Suresh : Added for TLD pushdown : Start
				String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(kohlsCashPromotionElement, createtsList);
				
				XMLUtil.setAttribute(manualTldEle,KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);
				
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
				 // Suresh : Added for TLD pushdown : End
				
				
				if(!YFCCommon.isStringVoid(legacyDoller)){
					XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, legacyDoller);
					XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_DOLLAR_OFF);
					// Start: Defect 3284 Fix : Suresh, 
					// setting legacyDollar (Actual amount) to ExtnCouponAmount,used to form description
					extnEle = XMLUtil.getChildElement(kohlsCashPromotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,legacyDoller);
					// End :  Defect 3284 Fix : Suresh
					
					
				}else if(!YFCCommon.isStringVoid(legacyPercent)){
					legacyPercent = String.valueOf(Math.abs(Double.valueOf(legacyPercent)/KohlsPOCConstant.HUNDRED_INT));
					XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, legacyPercent);
					XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_PERCENT_OFF);
					extnEle = XMLUtil.getChildElement(kohlsCashPromotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
					XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT,legacyPercent);

				}
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_LEGACY_FLAG, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.NO);
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.NO);
			}else if(KohlsPOCConstant.KOHLSCASHAUTH.equalsIgnoreCase(couponType) && KohlsPOCConstant.ACTIVE_CAPS.equalsIgnoreCase(couponStatus)
					&& KohlsPOCConstant.ZERO.equalsIgnoreCase(authResponseCode) && !YFCCommon.isStringVoid(couponBalance)
					&& Double.valueOf(couponBalance).doubleValue() > KohlsPOCConstant.ZERO_DBL){
				manualTldEle = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_MANUAL_TLD);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_GUID, guidPromotion);
				
				 // Suresh : Added for TLD pushdown : Start
				String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(kohlsCashPromotionElement, createtsList);
				XMLUtil.setAttribute(manualTldEle,KohlsPOCConstant.A_SCANNED_SEQUENCE,sequenceNumber );
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
				 // Suresh : Added for TLD pushdown : End
				
				
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, couponBalance);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_DOLLAR_OFF);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_LEGACY_FLAG, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.YES);
				
				// Start: Defect 3284 Fix : Suresh, 
				// setting couponBalance (Actual amount) to ExtnCouponAmount,used to form description
				extnEle = XMLUtil.getChildElement(kohlsCashPromotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_COUPON_AMOUNT,couponBalance);
				// End :  Defect 3284 Fix : Suresh
			}


			List<Element> eventDeptEleList = XMLUtil.getElementsByTagName(kohlsCashResposneEle, KohlsPOCConstant.E_EVENT_DEPARTMENT);

			if(!YFCCommon.isVoid(manualTldEle)){

				if(eventDeptEleList.size() > KohlsPOCConstant.ZERO_INT){
					if(KohlsPOCConstant.ZERO.equalsIgnoreCase(includeExcludeFlag)){
						XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_IE_INDICATOR, KohlsPOCConstant.EXCLUDE);
					}else if(KohlsPOCConstant.STRING_ONE.equalsIgnoreCase(includeExcludeFlag)){
						XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_IE_INDICATOR, KohlsPOCConstant.INCLUDE);
					}

					for(Element eventDept :  eventDeptEleList){
						Element departmentsEle = XMLUtil.createChild(manualTldEle,KohlsPOCConstant.E_DEPARTMENTS);
						departmentsEle.setAttribute(KohlsPOCConstant.A_DEPT, XMLUtil.getAttribute(eventDept, KohlsPOCConstant.A_EVENT_DEPARTMENT));
					}
					// Defect fix: 2632 , if Departmentlist is empty, IEIndicator should be set as None
				}else{
					XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_IE_INDICATOR, "None");
				}
			}

		}
		this.logger.debug("Method Name : constructAPERequestFromKohlsCashResponse   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromKohlsCashResponse");

	}

	/**
	 * This method is used construct the APE Request for ManualTLD.
	 * 
	 * @param entry
	 * @param apeRequestEle
	 * @param createtsList
	 */
	private void constructAPERequestFromManualTld(Entry<String, Element> entry, Element apeRequestEle, List<String> createtsList) {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromManualTld");

		this.logger.debug("Method Name : constructAPERequestFromManualTld   and   Status : Start ");

		String guidPromotion = entry.getKey();
		Element tldPromotionElement =  entry.getValue();
		Element manualTldEle = XMLUtil.createChild(apeRequestEle, KohlsPOCConstant.E_MANUAL_TLD);
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_GUID, guidPromotion);
		
		 // Suresh : Added for TLD pushdown : Start
		String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(tldPromotionElement, createtsList);		
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);		
		Element extnEle = XMLUtil.getChildElement(tldPromotionElement, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
		 // Suresh : Added for TLD pushdown : End
		
		
		String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;

		String overrideMaxAdjustment = XMLUtil.getAttribute(tldPromotionElement, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);
		Element tempEle = XMLUtil.getChildElement(tldPromotionElement, KohlsPOCConstant.E_TEMP,Boolean.TRUE);


		if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
			overrideAdjustmentValue = overrideMaxAdjustment;
		}

		String promotionType = XMLUtil.getAttribute(tldPromotionElement, KohlsPOCConstant.A_PROMOTION_TYPE);

	
		if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {
			overrideAdjustmentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_AMOUNT);
			overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
			XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_DOLLAR_OFF);

		} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType) || KohlsPOCConstant.QUICK_CREDIT_DISCOUNT.equalsIgnoreCase(promotionType)) {
			overrideAdjustmentValue = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

			overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue) / KohlsPOCConstant.HUNDRED_INT));
			XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.MANUAL_PERCENT_OFF);

		}
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, overrideAdjustmentValue);
		XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.NO);
		XMLUtil.setAttribute(tempEle, KohlsPOCConstant.ATTR_GIFT, KohlsPOCConstant.NO);

		this.logger.debug("Method Name : constructAPERequestFromManualTld   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromManualTld");


	}

	/**
	 * This method is used construct the APE Request for Offer.
	 * 
	 * @param entry
	 * @param apeRequestEle
	 * @param createtsList
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */

	private void constructAPERequestFromCouponResponse(Entry<String, Element> entry, Element apeRequestEle, List<String> createtsList) throws ParserConfigurationException, SAXException, IOException {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromCouponResponse");
		this.logger.debug("Method Name : constructAPERequestFromCouponResponse   and   Status : Start ");
		String guidPromotion = entry.getKey();
		Element couponPromotionElement =  entry.getValue();
		Element offerEle = XMLUtil.createChild(apeRequestEle, KohlsPOCConstant.E_OFFER);
		XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_GUID, guidPromotion);
		final Element extnEle = XMLUtil.getChildElement(couponPromotionElement, KohlsPOCConstant.E_EXTN);
		final Element pluOfferResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));
		
		// Suresh : Added for TLD pushdown : Start
		String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(couponPromotionElement, createtsList);		
		XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_SCANNED_SEQUENCE,sequenceNumber);		
		XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
		 // Suresh : Added for TLD pushdown : End
		
		List<Element> xstOfferEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR);

		if (xstOfferEleList.size() > KohlsPOCConstant.ZERO_INT && null != xstOfferEleList.get(KohlsPOCConstant.ZERO_INT)) {
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_OFFER_ID, KohlsPoCPnPUtil.getPromotionIdForAPE(XMLUtil.getAttribute(couponPromotionElement, KohlsPOCConstant.A_PROMOTION_ID)));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_SCHEME_CODE, XMLUtil.getAttribute(xstOfferEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_PROMO_SCHM_CDE));
			String discLevelCode = XMLUtil.getAttribute(xstOfferEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_DISC_LVL_CDE);
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_DISCOUNT_LEVEL, discLevelCode);
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_APPLICATION_CODE, XMLUtil.getAttribute(xstOfferEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_BWP_ITM_APPL_CDE));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_OFFER_TYPE, XMLUtil.getAttribute(xstOfferEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_EVNT_TYP_CDE));
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_DISC_LVL_CODE, discLevelCode);
		}

		List<Element> xstOfferSelectEleList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_SECT);

		if (xstOfferSelectEleList.size() > KohlsPOCConstant.ZERO_INT && null != xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT)) {
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_BEGIN_DATE, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_EFF_BEG_DTE));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_END_DATE, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_EFF_END_DTE));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_OVERRIDE_DATE, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_REDMN_SUPVR_OVRRID_DTE));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_BUY_DOLLAR, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_BUY_AMT));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_BUY_CRITERIA_OPERATOR, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_BWP_BUY_CNCTR_CDE));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_GET_CRITERIA_OPERATOR, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_BWP_GET_CNCTR_CDE));
			XMLUtil.setAttribute(offerEle, KohlsPOCConstant.A_LIMIT_PER_TRANSACTION, XMLUtil.getAttribute(xstOfferSelectEleList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.A_LMT_PER_TRN_QTY));

		}

		Element buyCriteriaEle = XMLUtil.createChild(offerEle, KohlsPOCConstant.E_BUY_CRITERIA);
		Element getCriteriaEle = XMLUtil.createChild(offerEle, KohlsPOCConstant.E_GET_CRITERIA);
		List<Element> xstOfferBwpList = XMLUtil.getElementsByTagName(pluOfferResposneEle, KohlsPOCConstant.E_XST_OFR_BWP);

		if (xstOfferBwpList.size() > KohlsPOCConstant.ZERO_INT) {
			for (Element xstOfferBwpEle : xstOfferBwpList) {
				String bwpSelectionTypeCode =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_SELN_TYP_CDE);
				Element criteriaEle = null;
				if (KohlsPOCConstant.BUY.equalsIgnoreCase(bwpSelectionTypeCode)) {	
					criteriaEle = XMLUtil.createChild(buyCriteriaEle, KohlsPOCConstant.E_CRITERIA);
				} else if (KohlsPOCConstant.GET.equalsIgnoreCase(bwpSelectionTypeCode)) {
					criteriaEle = XMLUtil.createChild(getCriteriaEle, KohlsPOCConstant.E_CRITERIA);
				}
				XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_TIER_LEVEL, XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_TIER_LVL_NBR));
				if (KohlsPOCConstant.BUY.equalsIgnoreCase(bwpSelectionTypeCode)) {
					String buyQty = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_BUY_QTY);
					String buyAmount = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_BUY_AMT);
					if (null != buyQty && !buyQty.isEmpty()) {
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_CRITERIA_TYPE, KohlsPOCConstant.A_BUY_QUANTITY);
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_BUY_QTY, buyQty);
					} else if (null != buyAmount && !buyAmount.isEmpty()) {
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_CRITERIA_TYPE, KohlsPOCConstant.A_BUY_DOLLAR);
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_BUY_DOLLAR, buyAmount);
					}

					XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_BUY_DOLLAR_TOLERANCE, XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_BUY_TOL_AMT));

				} else if (KohlsPOCConstant.GET.equalsIgnoreCase(bwpSelectionTypeCode)) {
					String getQty = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_QTY);
					String getDoller = XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_DOL_OFF_AMT);
					String getPricePoint =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_PRPT_AMT);
					String getPercentOff =  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_PCT_OFF_PCT);
					if (null != getQty && !getQty.isEmpty() && KohlsPOCConstant.ZERO_STR.equalsIgnoreCase(getPricePoint)) {
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PRICE_POINT);
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_GET_PRICE_POINT, getPricePoint);
					} else if (null != getDoller && !getDoller.isEmpty()) {
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_CRITERIA_TYPE, KohlsPOCConstant.A_GET_DOLLAR_OFF);
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_GET_DOLLAR, getDoller);
					} else if (null != getPercentOff && !getPercentOff.isEmpty()) {
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PERCENT_OFF);
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_GET_PERCENT, getPercentOff);
					} else {
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_CRITERIA_TYPE, KohlsPOCConstant.A_GET_PRICE_POINT);
						XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_GET_PRICE_POINT, getPricePoint);
					}
					XMLUtil.setAttribute(criteriaEle, KohlsPOCConstant.A_GET_QTY,  XMLUtil.getAttribute(xstOfferBwpEle, KohlsPOCConstant.A_BWP_GET_QTY));
				}



				List<Element> recordList = XMLUtil.getElementsByTagName(xstOfferBwpEle, KohlsPOCConstant.E_RECORD);
				if (recordList.size() > KohlsPOCConstant.ZERO_INT) {
					if (KohlsPOCConstant.BUY.equalsIgnoreCase(bwpSelectionTypeCode) || KohlsPOCConstant.GET.equalsIgnoreCase(bwpSelectionTypeCode)) {
						for (Element recordEle : recordList) {
							this.addngMerchandiseSetData(criteriaEle, recordEle);

						}
					}
				}

			}
		}


		this.logger.debug("Method Name : constructAPERequestFromCouponResponse   and   Status : Start ");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromCouponResponse");


	}


	/**
	 * 
	 * This Method is used to construct the APE Request for Pricing, Promo , Manaul TLd, Price Override
	 * 
	 * @param entry
	 * @param itemList
	 * @param createtsList
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParseException
	 */

	private void constructAPERequestFromPromoResponse(Entry<String, Element> entry, Element itemList, List<String> createtsList) throws ParserConfigurationException, SAXException, IOException, ParseException {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromPromoResponse");
		this.logger.debug("Method Name : constructAPERequestFromPromoResponse   and   Status : Start ");
		String guidOrderLine = entry.getKey();
		Element orderLineEle = entry.getValue();
		Element item = XMLUtil.createChild(itemList, KohlsPOCConstant.E_ITEM);
		Element pricingEle = XMLUtil.createChild(item, KohlsPOCConstant.E_PRICING);
		XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_GUID, guidOrderLine);
		final Element extnEle = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_EXTN);
		final Element pluPromoResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PLU_PROMO_RESPONSE));
		final List<Element> pluFileList = XMLUtil.getElementsByTagName(pluPromoResposneEle, KohlsPOCConstant.E_PLU_FILE);
		Element linePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);

		String orderLineUnitPrice = XMLUtil.getAttribute(linePriceInfo, KohlsPOCConstant.A_UNIT_PRICE);
		Element pluFileRecordEle = null;
		if (pluFileList.size() > KohlsPOCConstant.ZERO_INT && null != pluFileList.get(KohlsPOCConstant.ZERO_INT)) {
			pluFileRecordEle = XMLUtil.getChildElement((Element) pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);

			/*the regular price should be populated with Order/OrderLines/OrderLine/LinePriceInfo/@UnitPrice if it not zero or null. else it has to be populated with MESSAGE\Component\PLUFile\RECORD\@UNT_RTL_AMT */
			String extnIsPriceEntered = XMLUtil.getAttribute(extnEle, KohlsPOCConstant.A_EXTN_IS_PRICE_ENTERED);

			String regularPrice = null;
			if (null != orderLineUnitPrice && !orderLineUnitPrice.isEmpty() && KohlsPOCConstant.YES.equalsIgnoreCase(extnIsPriceEntered)) {
				regularPrice = String.valueOf((long)Math.round((Double.valueOf(XMLUtil.getAttribute(linePriceInfo, KohlsPOCConstant.A_UNIT_PRICE)) * KohlsPOCConstant.HUNDRED_INT)));
			} else {
				regularPrice = XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_UNT_RTL_AMT);
			}
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_REGULAR_PRICE, regularPrice);

			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_DEPARTMENT, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_DEPT_NBR));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_MAJOR_CLASS, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_MAJ_CL_NBR));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_SUB_CLASS, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_SUB_CL_NBR));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_VENDOR_STYLE, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_STYL_ID));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_SKU, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_SKU_NBR));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_SKU_STATUS, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_LOC_SKU_STAT_CDE));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_EMP_DISC_CODE, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_EMP_DISC_CDE));
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_NON_DISCOUNTABLE_FLAG, XMLUtil.getAttribute(pluFileRecordEle, KohlsPOCConstant.A_DISC_ELIG_IND));
		}

		final List<Element> promoList = XMLUtil.getElementsByTagName(pluPromoResposneEle, KohlsPOCConstant.E_PROMO);
		if (promoList.size() > KohlsPOCConstant.ZERO_INT) {
			final List<Element> recordList = XMLUtil.getElementsByTagName(promoList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
			if (recordList.size() > KohlsPOCConstant.ZERO_INT) {
				for (Element recordEle : recordList) {
					String promoSchemeCode = XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_SCHM_CDE);
					if (!(Integer.valueOf(KohlsPOCConstant.PROMO_REBATE).equals(Integer.valueOf(promoSchemeCode)))) {
						Element promoEle = XMLUtil.createChild(item, KohlsPOCConstant.E_PROMO);
						Element tempEle = XMLUtil.getChildElement(recordEle, KohlsPOCConstant.E_TEMP);
						XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GUID, XMLUtil.getAttribute(tempEle, KohlsPOCConstant.A_GUID));
						XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_SCHEME, promoSchemeCode);
						XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_CODE, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_ID));
						XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GET_DOLLAR, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT));
						XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_BUY_QTY, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_QTY_PROMO));							
						if (Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode))) {
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_LINKED_PROMO_CODE, KohlsPOCConstant.ZERO);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PRICE_POINT, KohlsPOCConstant.ZERO);	
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_BUY_DOLLAR, KohlsPOCConstant.ZERO);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GET_QTY, KohlsPOCConstant.ZERO);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PERCENT_OFF, KohlsPOCConstant.ZERO);
							SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YYYY_HH_MM_SS_SSS);
							Calendar calendarA = Calendar.getInstance();
							calendarA.add(Calendar.DATE, KohlsPOCConstant.MINUS_ONE);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_START, sdf.format(calendarA.getTime()));
							calendarA.add(Calendar.DATE, KohlsPOCConstant.THREE_INT);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_END, sdf.format(calendarA.getTime()));
						} else {
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_LINKED_PROMO_CODE, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_PROMO_INTFC_SUB_ID));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PRICE_POINT, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_AMT));								
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_BUY_DOLLAR, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_BUY_AMT));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GET_QTY, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_GET_QTY_PROMO));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PERCENT_OFF, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DISC_PCT));
							String promoStartDate = KohlsPoCPnPUtil.combinedDateAndTime(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_STRT_DATE), XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_STRT_TIME));
							String promoEndDate = KohlsPoCPnPUtil.combinedDateAndTime(XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_END_DATE), XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_ACTL_END_TIME));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_START, promoStartDate);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_END, promoEndDate);
						}

					}

				}
			}
		}

		// APE Request Construction for Manual LID and Price Override

		List<Element> linePromotionList = XMLUtil.getElementsByTagName(orderLineEle, KohlsPOCConstant.E_PROMOTION);

		if (linePromotionList.size() > KohlsPOCConstant.ZERO_INT) {

			for (Element linePromotionEle : linePromotionList) {

				String promotionType = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_PROMOTION_TYPE);
				Element tempElement = XMLUtil.getChildElement(linePromotionEle, KohlsPOCConstant.E_TEMP);
				String guidPromotion = XMLUtil.getAttribute(tempElement,  KohlsPOCConstant.A_GUID);
				Element manualLidEle = XMLUtil.createChild(item, KohlsPOCConstant.E_MANUAL_LID);
				XMLUtil.setAttribute(manualLidEle, KohlsPOCConstant.A_GUID, guidPromotion);
				
				 // Suresh : Added for TLD pushdown : Start
				
				String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(linePromotionEle, createtsList);	
				
				XMLUtil.setAttribute(manualLidEle, KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);
			
				XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
				 // Suresh : Added for TLD pushdown : End

				String overrideAdjustmentValue = KohlsPOCConstant.EMPTY;
				String overrideMaxAdjustment = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_OVERRIDE_MAX_ADJUSTMENT);

				if (!YFCCommon.isStringVoid(overrideMaxAdjustment)) {
					overrideAdjustmentValue = overrideMaxAdjustment;
				} else {
					overrideAdjustmentValue = XMLUtil.getAttribute(linePromotionEle, KohlsPOCConstant.A_OVERRIDE_ADJUSTMENT_VALUE);
				}

				if (KohlsPOCConstant.AMOUNT_OFF.equalsIgnoreCase(promotionType)) {

					overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
					XMLUtil.setAttribute(manualLidEle, KohlsPOCConstant.A_DOLLAR_OFF, overrideAdjustmentValue);

				} else if (KohlsPOCConstant.PERCENT_OFF.equalsIgnoreCase(promotionType)) {

					Element promotionExtnEle = XMLUtil.getChildElement(linePromotionEle, KohlsPOCConstant.E_EXTN, Boolean.TRUE);
					String extnDiscountPercent = XMLUtil.getAttribute(promotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT);

					if (!YFCCommon.isStringVoid(extnDiscountPercent)) {
						overrideAdjustmentValue = extnDiscountPercent;
					} else {
						XMLUtil.setAttribute(promotionExtnEle, KohlsPOCConstant.A_EXTN_DISCOUNT_PERCENT, twoDForm.format(Math.abs(Double.valueOf(overrideAdjustmentValue))));
					}
					overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue).intValue()));
					XMLUtil.setAttribute(manualLidEle, KohlsPOCConstant.A_PERCENT_OFF, overrideAdjustmentValue);

				} else if (KohlsPOCConstant.PRICE_OVERRIDE.equalsIgnoreCase(promotionType)) {

					overrideAdjustmentValue = String.valueOf(Math.abs(Double.valueOf(overrideAdjustmentValue)));
					XMLUtil.setAttribute(manualLidEle, KohlsPOCConstant.A_CORRECTED_PRICE, overrideAdjustmentValue);

				}

			}
		}

		this.logger.debug("Method Name : constructAPERequestFromPromoResponse   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromPromoResponse");

	}

	/**
	 * This method is used to add the mercendise data in the APE Request formation. 
	 * 
	 * @param criteriaEle
	 * @param recordEle
	 */
	private void addngMerchandiseSetData(Element criteriaEle, Element recordEle) {
		logger.beginTimer("KohlsPoCAPECaller.addngMerchandiseSetData");

		this.logger.debug("Method Name : addngMerchandiseSetData   and   Status : Start ");
		Element merchandiseSetEle = XMLUtil.createChild(criteriaEle, KohlsPOCConstant.E_MERCHANDISE_SET);
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_HIERARCHY_LEVEL,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_MDSE_HIER_CDE));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_EXCLUDE_FLAG,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_IE_IND));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_DEPARTMENT,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_DEPT_NBR));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_MAJOR_CLASS,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_MAJ_CL_NBR));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_SUB_CLASS,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_SUB_CL_NBR));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_VENDOR_STYLE,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_STYL_ID));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_SKU,  XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_SKU_NBR));
		XMLUtil.setAttribute(merchandiseSetEle, KohlsPOCConstant.A_SKU_STATUS, XMLUtil.getAttribute(recordEle, KohlsPOCConstant.A_TKT_CLOR_CDE));

		this.logger.debug("Method Name : addngMerchandiseSetData   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.addngMerchandiseSetData");

	}


	/**
	 * This method constructs the APE request for BeautyExclusion
	 * @return 
	 * @param Element beautyExclusionAPIOutEle
	 * @param Map<String, Element> orderLineHM
	 * @param Element apeRequestEle
	 */ 
	private void constructAPERequestFromBeautyExclusionResponse(Element beautyExclusionAPIOutEle, Element apeRequestEle)  {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromBeautyExclusionResponse");


		this.logger.debug("Method Name : constructAPERequestFromBeautyExclusionResponse   and   Status : Start ");
		List<Element> rulesEleList = XMLUtil.getElementsByTagName(beautyExclusionAPIOutEle, KohlsPOCConstant.E_RULE);
		if(rulesEleList.size() > KohlsPOCConstant.ZERO_INT && null != rulesEleList.get(KohlsPOCConstant.ZERO_INT)){
			Element rulesElement = rulesEleList.get(KohlsPOCConstant.ZERO_INT);
			String ruleValue = XMLUtil.getAttribute(rulesElement, KohlsPOCConstant.A_RULE_VALUE);


			Element exclusionEle = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_EXCLUSIONS);

			StringTokenizer ruleValueToDept = new StringTokenizer(ruleValue, KohlsPOCConstant.COMMA);
			while (ruleValueToDept.hasMoreElements()) 
			{
				String Dept = (String) ruleValueToDept.nextElement();
				Element departmentsEle = XMLUtil.createChild(exclusionEle,KohlsPOCConstant.E_DEPARTMENTS);
				departmentsEle.setAttribute(KohlsPOCConstant.A_DEPT, Dept);
			}

		}
		this.logger.debug("Method Name : constructAPERequestFromBeautyExclusionResponse   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromBeautyExclusionResponse");

	}

	/**
	 * This method constructs the APE request for SeniorCitizen
	 * @return 
	 * @param Element apeRequestEle
	 * @param Entry<String, Element> entry
	 * @param List<String> createtsList
	 * @throws Exception 
	 */ 
	private void constructAPERequestFromSeniorCitizenResponse(
			Entry<String, Element> entry, Element apeRequestEle, List<String> createtsList, Element orderEle, YFSEnvironment yfsEnv ) throws Exception {
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromSeniorCitizenResponse");

		logger.debug("Entering constructAPERequestFromSeniorCitizenResponse method..");
		String guidPromotion = entry.getKey();
		Element seniorCitizenPromotionElement =  entry.getValue();
		Element extnEle = XMLUtil.getChildElement(seniorCitizenPromotionElement, KohlsPOCConstant.E_EXTN,Boolean.TRUE);
		Element SeniorCitizenResposneEle = KohlsPoCPnPUtil.createElementFromXMLString(extnEle.getAttribute(KohlsPOCConstant.A_EXTN_PROMOTION_RESPONSE));

		List<Element> rulesEleList = XMLUtil.getElementsByTagName(SeniorCitizenResposneEle, KohlsPOCConstant.E_RULE);
		
		//Changes for Sprint 9.1 - Start
		//Commenting for Spring 9.1 - Start
		/*String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_PERCENT;
		String ruleValue = KohlsPoCPnPUtil.ruleIDComparisonCaller(SeniorCitizenResposneEle, ruleId);*/
		//Commenting for Spring 9.1 - End
		
		String ruleId = KohlsPOCConstant.SENIOR_DISCOUNT_CHARGE;
		
		//adding the logic in pnputil class
		/*Document getTillStatusListForPOSoutDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, orderEle);
		Element getTillStatusListForPOSoutDocEle = (Element) ((NodeList) getTillStatusListForPOSoutDoc
				.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS)).item(0);
		String strBusinessDay=getTillStatusListForPOSoutDocEle.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
		logger.debug("The Business Day is: "+strBusinessDay);
		String [] delimited = strBusinessDay.split(KohlsPOCConstant.MINUS);
		String strBusinessDate=delimited[1].concat(delimited[2]).concat((delimited[0].substring(2, 4)));
		String strOrganizationCode = orderEle.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);
		logger.debug("The Business Date value is: "+strBusinessDate);
		logger.debug("The Enterprise Code value is: "+strOrganizationCode);*/
		// call new method by sending the business date, rule id, enterprise code and set the extnDiscountPercent attribute
		String ruleValue = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,orderEle,ruleId);
		//Changes for Sprint 9.1 - End
		String promotionType = XMLUtil.getAttribute(seniorCitizenPromotionElement, KohlsPOCConstant.A_PROMOTION_TYPE);
		Element manualTldEle = null;
		String percentValue = null;

		if(KohlsPOCConstant.SENIOR_DISCOUNT.equalsIgnoreCase(promotionType)){
			manualTldEle = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_MANUAL_TLD);
			XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_GUID, guidPromotion);
			
			 // Suresh : Added for TLD pushdown : Start
			
			String sequenceNumber = KohlsPoCPnPUtil.getSequenceNumber(seniorCitizenPromotionElement, createtsList);
			
			XMLUtil.setAttribute(manualTldEle,KohlsPOCConstant.A_SCANNED_SEQUENCE, sequenceNumber);			
			
			XMLUtil.setAttribute(extnEle, KohlsPOCConstant.A_EXTN_SCANNED_SEQUENCE, sequenceNumber);
			 // Suresh : Added for TLD pushdown : End

			if(!YFCCommon.isVoid(ruleValue) || !rulesEleList.isEmpty()){
				percentValue = String.valueOf(Double.valueOf(ruleValue)/KohlsPOCConstant.HUNDRED_INT);
			} else {
				percentValue = String.valueOf(Double.valueOf(KohlsPOCConstant.DEFAULT_SENIOR_DISCOUNT_PERCENT)/KohlsPOCConstant.HUNDRED_INT);
			}

			XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, percentValue);
			XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.SENIOR_CITIZEN_DISCOUNT);

		}

		logger.debug("Exiting constructAPERequestFromSeniorCitizenResponse method..");
		logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromSeniorCitizenResponse");
	}


	/**
	 * This method constructs APE request
	 * @return Document
	 * @param  Element orderEle
	 * @param  Map<String, Element> orderLineHM
	 * @param  Element pluPromoResponseEle
	 * @throws Exception 
	 */

	public Document constructApeRequestForPriceVerify(Element orderEle , Map<String, Element> orderLineHM ,Element pluPromoResponseEle, YFSEnvironment yfsEnv) throws Exception {
		logger.beginTimer("KohlsPoCAPECaller.constructApeRequestForPriceVerify");

		this.logger.debug("Method Name : constructApeRequestForPriceVerify   and   Status : Start ");
		final Document apeRequestDoc = XMLUtil.createDocument(KohlsPOCConstant.E_TRANSACTION);
		Element apeRequestEle =  apeRequestDoc.getDocumentElement();
		String shipNode = XMLUtil.getAttribute(orderEle, KohlsPOCConstant.A_ORG_CODE);

		//Appending zero when store number length is less than 4
		shipNode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(shipNode);

		XMLUtil.setAttribute(apeRequestEle,KohlsPOCConstant.A_STORE_APE, shipNode);
		XMLUtil.setAttribute(apeRequestEle,KohlsPOCConstant.A_TRAN_DATE_TIME_APE, KohlsPoCPnPUtil.getCurrentDateString());

		Element itemList = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_ITEM_LIST);
		for (final Map.Entry<String, Element> entry : orderLineHM.entrySet()) {
			String guidOrderLine = entry.getKey();
			Element orderLineEle = entry.getValue();
			Element item = XMLUtil.createChild(itemList,KohlsPOCConstant.E_ITEM);
			Element pricingEle = XMLUtil.createChild(item,KohlsPOCConstant.E_PRICING);
			XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_GUID, guidOrderLine);
			final List<Element> pluFileList = XMLUtil.getElementsByTagName(pluPromoResponseEle, KohlsPOCConstant.E_PLU_FILE);
			Element pluFileRecordEle = null;
			if(pluFileList.size() > KohlsPOCConstant.ZERO_INT && null != pluFileList.get(KohlsPOCConstant.ZERO_INT)){
				pluFileRecordEle = XMLUtil.getChildElement((Element)pluFileList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
				Element linePriceInfo = XMLUtil.getChildElement(orderLineEle, KohlsPOCConstant.E_LINE_PRICE_INFO);
				/*Regular price should be populated with Order/OrderLines/OrderLine/LinePriceInfo/@UnitPrice if it IS not zero or null. 
				 * else it has to be populated with MESSAGE/Component/PLUFile/RECORD/@UNT_RTL_AMT */
				String orderLineUnitPrice = XMLUtil.getAttribute(linePriceInfo,KohlsPOCConstant.A_UNIT_PRICE);
				String regularPrice = null;
				if(null != orderLineUnitPrice && !orderLineUnitPrice.isEmpty() && Double.valueOf(orderLineUnitPrice) > KohlsPOCConstant.ZERO_DBL){
					regularPrice = String.valueOf((long)Math.round((Double.valueOf(XMLUtil.getAttribute(linePriceInfo, KohlsPOCConstant.A_UNIT_PRICE)) * KohlsPOCConstant.HUNDRED_INT)));
				}else{
					regularPrice = XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_UNT_RTL_AMT);

				}
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_REGULAR_PRICE,regularPrice);

				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_DEPARTMENT, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_DEPT_NBR));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_MAJOR_CLASS, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_MAJ_CL_NBR));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_SUB_CLASS, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_SUB_CL_NBR));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_VENDOR_STYLE, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_STYL_ID));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_SKU, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_SKU_NBR));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_SKU_STATUS, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_LOC_SKU_STAT_CDE));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_EMP_DISC_CODE, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_EMP_DISC_CDE));
				XMLUtil.setAttribute(pricingEle, KohlsPOCConstant.A_NON_DISCOUNTABLE_FLAG, XMLUtil.getAttribute(pluFileRecordEle,KohlsPOCConstant.A_DISC_ELIG_IND));
			}

			final List<Element> promoList = XMLUtil.getElementsByTagName(pluPromoResponseEle, KohlsPOCConstant.E_PROMO);
			if(promoList.size() > KohlsPOCConstant.ZERO_INT ){
				final List<Element> recordList = XMLUtil.getElementsByTagName(promoList.get(KohlsPOCConstant.ZERO_INT), KohlsPOCConstant.E_RECORD);
				if(recordList.size() > KohlsPOCConstant.ZERO_INT){
					for(Element recordEle : recordList){
						String promoSchemeCode = XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_PROMO_SCHM_CDE);
						if(!(Integer.valueOf(KohlsPOCConstant.PROMO_REBATE).equals(Integer.valueOf(promoSchemeCode)))){
							Element promoEle = XMLUtil.createChild(item,KohlsPOCConstant.E_PROMO);
							Element tempEle = XMLUtil.getChildElement(recordEle, KohlsPOCConstant.E_TEMP);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GUID, XMLUtil.getAttribute(tempEle,KohlsPOCConstant.A_GUID));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_SCHEME, promoSchemeCode);
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_CODE, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_PROMO_INTFC_ID));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GET_DOLLAR, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_AMT));
							XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_BUY_QTY, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_BUY_QTY_PROMO));							
							if(Integer.valueOf(KohlsPOCConstant.PROMO_GROUP_PRICING_PROMO).equals(Integer.valueOf(promoSchemeCode))){
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_LINKED_PROMO_CODE, KohlsPOCConstant.ZERO);
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PRICE_POINT, KohlsPOCConstant.ZERO);	
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_BUY_DOLLAR, KohlsPOCConstant.ZERO);
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GET_QTY, KohlsPOCConstant.ZERO);
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PERCENT_OFF, KohlsPOCConstant.ZERO);
								SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MM_DD_YYYY_HH_MM_SS_SSS);
								Calendar calendarA = Calendar.getInstance();
								calendarA.add(Calendar.DATE, KohlsPOCConstant.MINUS_ONE);
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_START, sdf.format(calendarA.getTime()));
								calendarA.add(Calendar.DATE, KohlsPOCConstant.THREE_INT);
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_END, sdf.format(calendarA.getTime()));
							}else{
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_LINKED_PROMO_CODE, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_PROMO_INTFC_SUB_ID));
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PRICE_POINT, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_AMT));								
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_BUY_DOLLAR, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_BUY_AMT));
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_GET_QTY, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_GET_QTY_PROMO));
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PERCENT_OFF, XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_DISC_PCT));
								String promoStartDate = KohlsPoCPnPUtil.combinedDateAndTime(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_ACTL_STRT_DATE),XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_ACTL_STRT_TIME));
								String promoEndDate = KohlsPoCPnPUtil.combinedDateAndTime(XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_ACTL_END_DATE),XMLUtil.getAttribute(recordEle,KohlsPOCConstant.A_ACTL_END_TIME));
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_START, promoStartDate);
								XMLUtil.setAttribute(promoEle, KohlsPOCConstant.A_PROMO_END, promoEndDate);
							}

						}

					}
				}
			}

		}
		
		// Suresh : Added for Nike Exclusions Sprint 5 : Start
		
		
		// retrieving exclusion rules and forming APE request
		KohlsPoCPnPUtil.constructAPERequestFromExclusionRules(yfsEnv, apeRequestEle);
		
		// Suresh : Added for Nike Exclusions Sprint 5 : End
		
	
		
		
		this.logger.debug("Method Name : constructApeRequestForPriceVerify   and   Status : End ");
		logger.endTimer("KohlsPoCAPECaller.constructApeRequestForPriceVerify");

		return apeRequestDoc;

	}

	/**
	 * This Method is used to construct Associate related APE Request
	 * 
	 * @param yfsEnv
	 * @param tempOrderEle
	 * @param entry
	 * @param apeRequestEle
	 * @param createtsList
	 * @throws Exception
	 */
	private void constructAPERequestFromAssociateResponse(YFSEnvironment yfsEnv,Element tempOrderEle, Element apeRequestEle, List<String> createtsList, KohlsPoCOrderPromotionsCaller offerAndKohlsCashObj) throws Exception {
		
		
		logger.beginTimer("KohlsPoCAPECaller.constructAPERequestFromAssociateResponse");

	//Added for 3945 defect fix --- Start
	//Commented below line for 3945 defect fix
	//String uuidStr = UUID.randomUUID().toString();
	String uuidStr = KohlsPOCConstant.EMPTY;
	Map<String, Element> orderAssociateDisHM = offerAndKohlsCashObj.getOrderAssociateDisHM();
	for (final Map.Entry<String, Element> entry : orderAssociateDisHM.entrySet())
	{
		uuidStr = entry.getKey();
	}
	
	//Added for 3945 defect fix --- End
	
	//Element tldPromotionElement =  entry.getValue();
	Element manualTldEle = XMLUtil.createChild(apeRequestEle,KohlsPOCConstant.E_MANUAL_TLD);
	XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_GUID, uuidStr);
	XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_DISCOUNT_TYPE, KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE);

				//Changes for Sprint 9.1 - Start
		
				// call the KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle) to get the business date value.
				String markdown = KohlsPOCConstant.EMPTY;
				String secondaryMarkdownValue = KohlsPOCConstant.EMPTY;
				String ruleId = KohlsPOCConstant.ASSOCIATE_DISCOUNT_TYPE;
				/*Document getTillStatusListForPOSoutDoc = KohlsPoCPnPUtil.getTillStatusListForPOSCaller(yfsEnv, tempOrderEle);
				Element getTillStatusListForPOSoutDocEle = (Element) ((NodeList) getTillStatusListForPOSoutDoc
						.getElementsByTagName("TillStatus")).item(0);
				String strBusinessDay=getTillStatusListForPOSoutDocEle.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
				String [] delimitedDash = strBusinessDay.split(KohlsPOCConstant.MINUS);
				String strBusinessDate=delimitedDash[1].concat(delimitedDash[2]).concat((delimitedDash[0].substring(2, 4)));
				String strOrganizationCode = tempOrderEle.getAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE);*/
				// call new method by sending the business date, rule id, enterprise code and set the extnDiscountPercent attribute
				String strDiscountValueFromUtil = KohlsPoCPnPUtil.getDiscountsPercentageForPOSBydate(yfsEnv,tempOrderEle,ruleId).trim();
				String [] delimitedComma = strDiscountValueFromUtil.split(KohlsPOCConstant.COMMA);
				int length1 = delimitedComma[0].length() - 1;
				int length2 = delimitedComma[1].length() - 1;
				markdown= String.valueOf(Double.valueOf(delimitedComma[0].substring(0,length1)) / KohlsPOCConstant.HUNDRED_INT);
				secondaryMarkdownValue= String.valueOf(Double.valueOf(delimitedComma[1].substring(0,length2)) / KohlsPOCConstant.HUNDRED_INT);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, markdown);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_SECONDARY_MARK_DOWN_VALUE, secondaryMarkdownValue);
				//Changes for Sprint 9.1 - End
				
				
				// Commenting for Sprint 9.1 Changes - Start
				/*String ruleid = KohlsPOCConstant.KOHLS_SOFT_GOODS_ASSOCIATE_DISCOUNT;
				Document softcalResponseDoc = new KohlsPoCPnPUtil().getRuleListForPOSCaller(yfsEnv, tempOrderEle, ruleid);
				Element softcalResponse = softcalResponseDoc.getDocumentElement();
				List softcallist = XMLUtil.getElementsByTagName(softcalResponse, "Rule");

				String markdown = KohlsPOCConstant.DEFAULT_KOHLS_SOFT_GOODS_ASSOCIATE_DISCOUNT;

				if(!softcallist.isEmpty()){
					String softrulevalue = KohlsPoCPnPUtil.ruleIDComparisonCaller(softcalResponse, ruleid);
					if(!YFCCommon.isVoid(softrulevalue))
						markdown = String.valueOf(Double.valueOf(softrulevalue) / KohlsPOCConstant.HUNDRED_INT);
					else
						markdown = String.valueOf(Double.valueOf(markdown) / KohlsPOCConstant.HUNDRED_INT);
				}else
					markdown = String.valueOf(Double.valueOf(markdown) / KohlsPOCConstant.HUNDRED_INT);

				ruleid = KohlsPOCConstant.KOHLS_HARD_GOODS_ASSOCIATE_DISCOUNT;
				Document hardcalResponseDoc = new KohlsPoCPnPUtil().getRuleListForPOSCaller(yfsEnv, tempOrderEle, ruleid);
				Element hardcalResponse = hardcalResponseDoc.getDocumentElement();

				List hardcallist =  XMLUtil.getElementsByTagName(hardcalResponse, "Rule");

				String secondaryMarkdownValue = KohlsPOCConstant.DEFAULT_KOHLS_HARD_GOODS_ASSOCIATE_DISCOUNT;

				if(!hardcallist.isEmpty()){
					String hardrulevalue = KohlsPoCPnPUtil.ruleIDComparisonCaller(hardcalResponse, ruleid);
					if(!YFCCommon.isVoid(hardrulevalue))
						secondaryMarkdownValue = String.valueOf(Double.valueOf(hardrulevalue) / KohlsPOCConstant.HUNDRED_INT);
					else
						secondaryMarkdownValue = String.valueOf(Double.valueOf(secondaryMarkdownValue) / KohlsPOCConstant.HUNDRED_INT);

				}else
					secondaryMarkdownValue = String.valueOf(Double.valueOf(secondaryMarkdownValue) / KohlsPOCConstant.HUNDRED_INT);

				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_MARK_DOWN_VALUE, markdown);
				XMLUtil.setAttribute(manualTldEle, KohlsPOCConstant.A_SECONDARY_MARK_DOWN_VALUE, secondaryMarkdownValue);*/
				//  Commenting for Sprint 9.1 Changes - End
	
	offerAndKohlsCashObj.setOrderAssociateHM(uuidStr,markdown,secondaryMarkdownValue);
	logger.endTimer("KohlsPoCAPECaller.constructAPERequestFromAssociateResponse");
	
	

	}

}
