package com.kohls.poc.prescreen.ue;
    
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;


/**
 * @author IBM
 *
 */

public class KohlsPoCPreScreenUE extends KOHLSBaseApi {


	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPoCPreScreenUE.class);
	}
	
	/**
	 * The Service Input from Gravity UE is 
	 * <PreScreenRequest OrderHeaderKey="12345678902345" 
	 * CustomerRewardsNo="91112491511" TransactionGrandTotal="199.99"/>
	 *
	 */


	/**
	 * @param env
	 * @param inXml
	 * @return
	 * @throws YFSUserExitException
	 * @throws Exception
	 */
	public Document requestPreScreen(YFSEnvironment env, Document inXml) throws YFSUserExitException, Exception { 
		long beginTime = System.currentTimeMillis();
    	Document preScreenResponse = null;
		Document outDoc = null;
		String storeId  = null; 
		String transactionAmount = null;
		String emailAddress = null;
		String loyaltyId = null;
		String correlationId = null;
		String authTime = null;
		String responseCode = null;
		storeId =  XMLUtil.getAttribute(inXml.getDocumentElement(), KohlsPOCConstant.STORE_ID);
		transactionAmount = XMLUtil.getAttribute(inXml.getDocumentElement(), KohlsPOCConstant.TRANSACTION_GRAND_TOTAL);
		loyaltyId = XMLUtil.getAttribute(inXml.getDocumentElement(), KohlsPOCConstant.CUSTOMER_REWARDS_NO);
		emailAddress = XMLUtil.getAttribute(inXml.getDocumentElement(), KohlsPOCConstant.EMAIL_ADDRESS);
		
		if(YFCCommon.isVoid(transactionAmount) && YFCCommon.isVoid(loyaltyId)){
			try {
				preScreenResponse = XMLUtil.newDocument();
				logger.debug("Transaction ammount or Loyalty Id missing");
			} catch (Exception e) {
				logger.error("Exception creating document");
			}
		}  else{
			try { 
				Document docinPreScreen = XMLUtil.newDocument();
				Element elePreScreenNS = docinPreScreen.createElementNS(KohlsPOCConstant.WEB_NS, KohlsPOCConstant.PRESCREEN_CUSTOMER_QN); 
				docinPreScreen.appendChild(elePreScreenNS);
				Element elePersonLookupNS = docinPreScreen.createElementNS(KohlsPOCConstant.WEB_NS, KohlsPOCConstant.PERSON_LOOKUP_QN); 
				elePreScreenNS.appendChild(elePersonLookupNS);
				Element eleTransactionAmountNS = docinPreScreen.createElementNS(KohlsPOCConstant.LYP_NS, KohlsPOCConstant.TRANSACTION_AMOUNT_QN); 
				elePersonLookupNS.appendChild(eleTransactionAmountNS);
				Element eleStoreIdNS = docinPreScreen.createElementNS(KohlsPOCConstant.LYP_NS, KohlsPOCConstant.STORE_ID_QN); 
				elePersonLookupNS.appendChild(eleStoreIdNS);
				Element elePersonNS = docinPreScreen.createElementNS(KohlsPOCConstant.LYP1_NS, KohlsPOCConstant.PERSON_QN); 
				elePersonLookupNS.appendChild(elePersonNS);
				Element eleLoyaltyNS = docinPreScreen.createElementNS(KohlsPOCConstant.LYP1_NS, KohlsPOCConstant.LOYALTY_QN); 
				elePersonNS.appendChild(eleLoyaltyNS);
				Element eleLoyaltyIdNS = docinPreScreen.createElementNS(KohlsPOCConstant.LYP1_NS, KohlsPOCConstant.LOYALTY_ID_QN); 
				eleLoyaltyNS.appendChild(eleLoyaltyIdNS);
				eleTransactionAmountNS.appendChild(docinPreScreen.createTextNode(transactionAmount));
				eleStoreIdNS.appendChild(docinPreScreen.createTextNode(storeId));
				eleLoyaltyIdNS.appendChild(docinPreScreen.createTextNode(loyaltyId));
				if(!YFCCommon.isVoid(emailAddress))
				{
					Element eleEmailAddressNS = docinPreScreen.createElementNS(KohlsPOCConstant.LYP_NS, KohlsPOCConstant.EMAIL_ADDRESS_QN); 
					elePersonLookupNS.appendChild(eleEmailAddressNS);
					eleEmailAddressNS.appendChild(docinPreScreen.createTextNode(emailAddress));
				}
				
				if(logger.isDebugEnabled())
					logger.debug("docinPreScreen:" + XMLUtil.getXMLString(docinPreScreen));

				if(!YFCCommon.isVoid(loyaltyId)) {

					logger.debug("invoked prescreen service");
					/**
					 * Output XML:
						Example of �Approved� Response:
						<PreScreenResponse ResponseCode="Approved" CorrelationID="1234567890123" AuthTime="00:05"/>
						Example of �Offline� Response:
						<PreScreenResponse ResponseCode="Offline" AuthTime="00:20"/>
					 *
					 */
					beginTime = System.currentTimeMillis();
					logger.verbose("beginTime of service--KohlsPoCPreScreenWebService:::::"+beginTime);
					preScreenResponse = this.invokeService(env, KohlsPOCConstant.KOHLS_POC_PRESCREEN_WEBSERVICE, docinPreScreen);
					
					if(logger.isDebugEnabled())
						logger.debug("docoutPreScree response :" +XMLUtil.getXMLString(preScreenResponse));		
					long endTime = System.currentTimeMillis();
					logger.verbose("endTime of service--PreScreen:::::"+endTime);
					long timeTaken = endTime-beginTime;				
					authTime = formatTime(timeTaken);
					logger.info("OMS Prescreen authorization took " + authTime + "ms");

				}				

				if(preScreenResponse!=null){

					responseCode=XPathUtil.getString(preScreenResponse.getDocumentElement(), KohlsPOCConstant.PRESCREEN_CUSTOMER_RESPONSE_RESULT_XPATH);
					//authTime=XPathUtil.getString(preScreenResponse.getDocumentElement(), "/prescreenCustomerResponse/response/Date_Time/text()");

					if(responseCode!=null && responseCode.equalsIgnoreCase(KohlsPOCConstant.OFFER_RESPONSE_CODE_WS)){
						correlationId=XPathUtil.getString(preScreenResponse.getDocumentElement(), KohlsPOCConstant.PRESCREEN_CUSTOMER_RESPONSE_CORRELATION_ID_XPATH);
					}

					responseCode = setResponseCode(responseCode);

				} 
			} catch (Exception e) {
				   e.printStackTrace();
				// As per the requirement no exception is thrown in this UE
				logger.error("Exception when invoking the Pre Screen service", e);
				YFSException es = (YFSException) e;
				if (es.getErrorCode().equalsIgnoreCase("EXTN_TIMEOUT") || es.getErrorCode().equalsIgnoreCase("EXTN_IO") || e.getCause() instanceof java.net.ConnectException || e.getCause() instanceof java.io.IOException || e.getCause() instanceof java.net.SocketTimeoutException) {
					responseCode = KohlsPOCConstant.TIMEOUT_RESPONSE_CODE;
					logger.error("OMS Prescreen Response Code : " + responseCode);
					e.printStackTrace();
					logger.debug("The error code value in time out is" + es.getErrorCode());
				} else if(es.getErrorCode().equalsIgnoreCase("SOAP_EXCEPTION")){

					logger.debug("The error message in soap exception is  " +es.getMessage() );
					responseCode = KohlsPOCConstant.OFFLINE_RESPONSE_CODE;
					logger.error("OMS Prescreen Response Code : " + responseCode);
				}
				else {
					logger.debug("Printing exception as of from InvodeWebservice" +es.getErrorCode());
					responseCode = KohlsPOCConstant.OFFLINE_RESPONSE_CODE;;
					logger.error("OMS Prescreen Response Code : " + responseCode);
				}		

				long endTime = System.currentTimeMillis();
				logger.verbose("endTime of service--PreScreen:::::"+endTime);
				long timeTaken = endTime-beginTime;
				authTime = formatTime(timeTaken);
				logger.error("OMS Prescreen authorization took " + authTime + "ms");
			}
	
			outDoc = XMLUtil.newDocument();
			Element elePreScreenResponse = outDoc.createElement(KohlsPOCConstant.PRESCREEN_RESPONSE_ELEMENT);
			outDoc.appendChild(elePreScreenResponse);

			elePreScreenResponse.setAttribute(KohlsPOCConstant.RESPONSE_CODE, responseCode);
			elePreScreenResponse.setAttribute(KohlsPOCConstant.AUTH_TIME, authTime);

			if(correlationId!=null){
				elePreScreenResponse.setAttribute(KohlsPOCConstant.CORRELATION_ID, correlationId);
			}
			logger.info("OMS Prescreen CorrelationID : " + (correlationId != null ? correlationId : "not found") + ", Response Code : " + responseCode + ", authorization took " + authTime + "ms");
			if(logger.isDebugEnabled())
				logger.debug("outDoc:" + XMLUtil.getXMLString(outDoc));

		}
		logger.debug("*** End of Pre Screen UE ***");
		return outDoc;
	}


	/**
	 * @param responseCode
	 * @return
	 */
	private String setResponseCode(String responseCode) {
		if(responseCode!=null && responseCode.equalsIgnoreCase(KohlsPOCConstant.OFFER_RESPONSE_CODE_WS)){
			responseCode = KohlsPOCConstant.OFFER_RESPONSE_CODE_WS; 
		}

		if(responseCode!=null && responseCode.equalsIgnoreCase(KohlsPOCConstant.PROCESS_COMPLETE_RESPONSE_CODE_WS)){
			responseCode = KohlsPOCConstant.PROCESS_COMPLETE_RESPONSE_CODE_WS; 
		}

		if(responseCode!=null && (responseCode.equalsIgnoreCase(KohlsPOCConstant.EDIT_ERROR_RESPONSE_CODE_WS) || responseCode.equalsIgnoreCase(KohlsPOCConstant.BAD_RESPONSE_WS))){
			responseCode = KohlsPOCConstant.EDIT_ERROR_RESPONSE_CODE; 	
		}

		if(responseCode!=null && (responseCode.equalsIgnoreCase(KohlsPOCConstant.EXISTING_KOHLS_CHARGE_RESPONSE_CODE_WS) || responseCode.equalsIgnoreCase(KohlsPOCConstant.EXISTING_RESPONSE_CODE_WS))){
			responseCode = KohlsPOCConstant.EXISTING_KOHLS_CHARGE_RESPONSE_CODE; 
		}
		logger.info("OMS Prescreen Response Code : " + responseCode);
		return responseCode;
	}


	/**
	 * @param timeTaken
	 * @return 
	 */
	private String formatTime(long timeTaken) {
		logger.verbose("timeTaken--PreScreen:::::"+timeTaken);
		Date date = new Date(timeTaken);
		DateFormat timeFormat = new SimpleDateFormat(KohlsPOCConstant.AUTH_TIME_FORMAT);
		String timeFormatted = timeFormat.format(date);
		return timeFormatted;
	}

	
}
