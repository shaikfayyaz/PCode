package com.kohls.poc.agent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

@SuppressWarnings("unused")
public class KohlsPoCPSAOrphanOrderAgent extends YCPBaseAgent {

	/**
	 * This custom Agent is used to fetch In Complete PSA Orders that are 
	 * either in STARTED or IN_PROGRESS status (Order/Extn/@ExtnPsaStatus) for 
	 * more than the configured time interval, from the Modifyts.
	 */

	private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCPSAOrphanOrderAgent.class);
	KohlsReprocessRequestUtil requestUtilObj = new KohlsReprocessRequestUtil();
	SimpleDateFormat s1 = new SimpleDateFormat("YYYY-MM-dd'T'hh:mm:ss");
	private static YIFApi api = null;
	static {
		try {
			api = YIFClientFactory.getInstance().getApi();
		} catch (YIFClientCreationException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method will fetch all the records to be processed by executeJobs()
	 */
	@SuppressWarnings("unchecked")
	public List<Document> getJobs(YFSEnvironment env, Document inDoc) {

		List<Document> returnList = new ArrayList<Document>();
		logger.beginTimer("KohlsPoCPSAOrphanOrderAgent.getJobs");
		logger.debug("KohlsPoCPSAOrphanOrderAgent.getJobs --- Input to getJobs" + XMLUtil.getXMLString(inDoc));

		Document outDoc = null;
		try {
			// Call getOrderList for getting PSA IN_PROGRESS and STARTED orders which are ideal for configured hours.

			outDoc = fetchRecordsToProcessFromGetOrderList(env, inDoc);

			List<Element> reprocessReqList = XMLUtil.getElementsByTagName(outDoc.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER);
			if (!YFCCommon.isVoid(outDoc) && reprocessReqList.size() > 0) {
				String strText20 = null;
				for (Element eleReprocessRec : reprocessReqList) {
					Element eleCustomAttributes = XMLUtil.getChildElement(eleReprocessRec, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
					strText20 = XMLUtil.getAttribute(eleCustomAttributes, KohlsPOCConstant.Text20);
					if(YFCCommon.isVoid(strText20)){
						Document docReprocessRec = XMLUtil.getDocumentForElement(eleReprocessRec);
						returnList.add(docReprocessRec);
					}
				}
			} else {
				logger.debug("KohlsPoCPSAOrphanOrderAgent.getJobs ----  No records for executeJob to process");
			}
		} catch (Exception e) {
			logger.debug("KohlsPoCPSAOrphanOrderAgent.getJobs ----  Exception in getJobs");
			e.printStackTrace();
			throw new YFSException(e.getMessage());
		}

		logger.endTimer("KohlsPoCPSAOrphanOrderAgent.getJobs");
		return returnList;
	}

	/**
	 * This method processes each record from getJobs()
	 * @throws Exception 
	 */
	public void executeJob(YFSEnvironment env, Document inDoc) throws Exception {
		logger.beginTimer("KohlsPoCPSAOrphanOrderAgent.executeJob");
		if(logger.isDebugEnabled()){
			logger.debug("KohlsPoCPSAOrphanOrderAgent.executeJob --- Input to executeJob" + XMLUtil.getXMLString(inDoc));
		}

		Element eleReprocessRecOrder = inDoc.getDocumentElement();
		eleReprocessRecOrder.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
		String strMaxOrderStatus = XMLUtil.getAttribute(eleReprocessRecOrder, KohlsPOCConstant.MAX_ORDER_STATUS);
		String strOrderStatus = XMLUtil.getAttribute(eleReprocessRecOrder, KohlsPOCConstant.A_STATUS);
		String strEntryType = XMLUtil.getAttribute(eleReprocessRecOrder, KohlsPOCConstant.ATTR_ENTRY_TYPE);

		if(strOrderStatus.equalsIgnoreCase(KohlsPOCConstant.STORE_ORDER_INVOICED)
				||(KohlsPOCConstant.ENTRY_TYPE_STORE_EDGE.equalsIgnoreCase(strEntryType) 
						&& KohlsPOCConstant.HOLD_CREATED_STATUS.equalsIgnoreCase(strMaxOrderStatus))){
			try {
				String strNewOrganizationCode= XMLUtil.getAttribute(eleReprocessRecOrder, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
				XMLUtil.setAttribute(eleReprocessRecOrder, KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.YES);
				XMLUtil.setAttribute(eleReprocessRecOrder, KohlsPOCConstant.POC_FEATURE, KohlsPOCConstant.MID_VOID_SCENARIO);
				XMLUtil.setAttribute(eleReprocessRecOrder, KohlsPOCConstant.A_ORGANIZATION_CODE, strNewOrganizationCode);
				Element eleReprocessRecOrderExtn = XMLUtil.getChildElement(eleReprocessRecOrder, KohlsPOCConstant.E_EXTN);
				XMLUtil.setAttribute(eleReprocessRecOrderExtn, KohlsPOCConstant.EXTN_PSA_STATUS, "VOIDED");
				//Setting PSA Sytem Void Indicator in Order/CustomAttributes
				Element eleNewOrderCustomAttributes = XMLUtil.getChildElement(eleReprocessRecOrder, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES, true);
				XMLUtil.setAttribute(eleNewOrderCustomAttributes, KohlsPOCConstant.Text20, "PSA Orphan Agent MidVoid Successful");
				//Removing Unwanted attributes for further process
				XMLUtil.removeAttribute(eleReprocessRecOrder, KohlsPOCConstant.MAX_ORDER_STATUS);
				XMLUtil.removeAttribute(eleReprocessRecOrder, KohlsPOCConstant.A_STATUS);
				XMLUtil.removeAttribute(eleReprocessRecOrder, KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
				//Removing PSA Promotions for MidVoid - Start
				Element eleNewOrderPromotions = XMLUtil.getChildElement(eleReprocessRecOrder, KohlsPOCConstant.E_PROMOTIONS);
				if(!YFCCommon.isVoid(eleNewOrderPromotions)){
					NodeList nlNewPromotion = eleNewOrderPromotions.getElementsByTagName( KohlsPOCConstant.E_PROMOTION );
					if ( !YFCCommon.isVoid( nlNewPromotion ) && nlNewPromotion.getLength()>0)
					{
						for ( int i = 0; i < nlNewPromotion.getLength(); i++ )
						{
							Element eleNewPromotion = (Element) nlNewPromotion.item( i );
							Element eleNewPromotionExtn = XMLUtil.getChildElement(eleNewPromotion, KohlsPOCConstant.E_EXTN);
							String strExtnIsPsaPromotion = XMLUtil.getAttribute(eleNewPromotionExtn, KohlsPOCConstant.ISPSAPROMOTION);
							if(KohlsPOCConstant.YES.equalsIgnoreCase(strExtnIsPsaPromotion)){
								XMLUtil.setAttribute(eleNewPromotion, KohlsPOCConstant.A_ACTION, KohlsPOCConstant.REMOVE);
							}else{
								eleNewOrderPromotions.removeChild(eleNewPromotion);
								i--;
							}
						}
					}
				}
				if(logger.isDebugEnabled()){
					logger.debug("Input to callchangeOrder:" + XMLUtil.getXMLString(inDoc));
				}
				//System.out.println("SYSO Input to first callchangeOrder:" + XMLUtil.getXMLString(inDoc));
				//ChangeOrder API to MidVoid Orphan PSA Transaction
				Document changeOrderOutput = KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API,inDoc);

				if(logger.isDebugEnabled()){
					logger.debug("Output to first callchangeOrder: "+ changeOrderOutput);
				}
				//System.out.println("SYSO Output to callchangeOrder:" + XMLUtil.getXMLString(changeOrderOutput));

			} catch (Exception e) {  
				logger.debug("Error while processing the KohlsPoCPSAOrphanOrderAgent.execute job ");
				e.printStackTrace();
				String sCurrentDate = KohlsReprocessRequestUtil.getCurrSysDateAsString();
				logger.debug("Exception Current date time is: "+sCurrentDate);

				createAndSendAlert(env, e, inDoc, sCurrentDate);

				ignoreOrderInNextAgentRun(env, inDoc, KohlsPOCConstant.Text20Value);
			}
		}else{
			logger.debug("Invalid Order Status to Void PSA ");
			ignoreOrderInNextAgentRun(env, inDoc, KohlsPOCConstant.Text20ValueInvalidOrder);
		}

		logger.endTimer("KohlsPoCReprocessAgent.executeJob");
	}

	/**
	 * This method calls changeOrder with below input, to update Order/CustomAttributes/Text20 to mark this order to not get picked in next Agent run.
	 * <Order DocumentType="0001" EnterpriseCode="KOHLS-RETAIL" IgnoreOrdering="Y" IgnoreRepricingUE="Y" 
			OrderHeaderKey="1116091601352026772881" Override="Y" SelectMethod="WAIT" changeOrder="Y">
			<CustomAttributes Text20="Order was Picked and Failed in PSA Orphan Agent Clean Up" />
		</Order>	
	 */
	private void ignoreOrderInNextAgentRun(YFSEnvironment env, Document inDoc, String text20ValueFailed) throws Exception {

		logger.beginTimer("KohlsPoCPSAOrphanOrderAgent.ignoreOrderInNextAgentRun");
		try {
			Element eleInDoc = inDoc.getDocumentElement();
			String strOrderHeaderKey = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			if(!YFCCommon.isVoid(strOrderHeaderKey)){
				Document docChangeOrderInp = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
				Element eleChangeOrderInp = docChangeOrderInp.getDocumentElement();
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.SO_DOCUMENT_TYPE);  
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.A_IGNORE_ORDERING, KohlsPOCConstant.YES);
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.IGNORE_REPRICING_UE, KohlsPOCConstant.YES);
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, strOrderHeaderKey);
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.YES);
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.A_Select_Method, KohlsPOCConstant.SELECT_METHOD_WAIT);
				eleChangeOrderInp.setAttribute(KohlsPOCConstant.API_CHANGE_ORDER, KohlsPOCConstant.YES);

				Element eleCustomAttributes = XMLUtil.createChild(eleChangeOrderInp, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
				eleCustomAttributes.setAttribute(KohlsPOCConstant.Text20, text20ValueFailed);

				if(logger.isDebugEnabled()){
					logger.debug("Input to ignoreOrderInNextAgentRun.changeOrder:" + XMLUtil.getXMLString(docChangeOrderInp));
				}
				//System.out.println("Input to ignoreOrderInNextAgentRun.changeOrder:" + XMLUtil.getXMLString(docChangeOrderInp));

				//ChangeOrder API to MidVoid Orphan PSA Transaction
				Document changeOrderOutput = KOHLSBaseApi.invokeAPI(env, KohlsConstant.CHANGE_ORDER_API,docChangeOrderInp);

				if(logger.isDebugEnabled()){
					logger.debug("Output of ignoreOrderInNextAgentRun.changeOrder: "+ XMLUtil.getXMLString(changeOrderOutput));
				}
				//System.out.println("Output of ignoreOrderInNextAgentRun.changeOrder: "+ XMLUtil.getXMLString(changeOrderOutput));


			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		logger.endTimer("KohlsPoCPSAOrphanOrderAgent.ignoreOrderInNextAgentRun");
	}


	private void createAndSendAlert(YFSEnvironment env, Exception e, Document inDoc, String sCurrentDate) throws Exception {

		logger.beginTimer("KohlsPoCPSAOrphanOrderAgent.createAndSendAlert");
		try {
			Element eleInDoc = inDoc.getDocumentElement();
			String strOrderHeaderKey = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.ATTR_ORD_HDR_KEY);
			//System.out.println("Input doc for createAndSendAlert : " +XMLUtil.getXMLString(inDoc));
			if(!YFCCommon.isVoid(strOrderHeaderKey)){
				String strOrderNo = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.ATTR_ORDER_NO);
				String strSellerOrganizationCode = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
				String strTerminalId = XMLUtil.getAttribute(eleInDoc, KohlsPOCConstant.A_TERMINAL_ID);  
				String errorDescription = "The PSA Orphan Agent failed to MidVoid the Order "+strOrderNo+" of Store "+strSellerOrganizationCode+" and Terminal "+strTerminalId;
				Document docInboxInp = XMLUtil.createDocument(KohlsPOCConstant.E_Inbox);
				Element eleInboxInp = docInboxInp.getDocumentElement();
				eleInboxInp.setAttribute(KohlsPOCConstant.A_Queue_Id, KohlsPOCConstant.KohlsPoCPSAOrphanAgentCustomAlertQueue);
				eleInboxInp.setAttribute(KohlsPOCConstant.RG_PRIORITY, KohlsPOCConstant.STRING_ONE);
				eleInboxInp.setAttribute(KohlsPOCConstant.InboxType, KohlsPOCConstant.PSAOrphanOrderCleanUpAgent);
				eleInboxInp.setAttribute(KohlsPOCConstant.ExceptionType, KohlsPOCConstant.PSAAgentMVException);
				eleInboxInp.setAttribute(KohlsPOCConstant.ErrorType, KohlsPOCConstant.PSAAgentMVException);
				eleInboxInp.setAttribute(KohlsPOCConstant.ErrorReason, KohlsPOCConstant.ErrorReason_Text);
				eleInboxInp.setAttribute(KohlsPOCConstant.EnterpriseKey, KohlsPOCConstant.A_KOHLS_RETAIL);
				eleInboxInp.setAttribute(KohlsPOCConstant.DetailDescription, errorDescription);

				Element eleInboxReferencesList = XMLUtil.createChild(eleInboxInp, KohlsPOCConstant.E_InboxReferencesList);  

				Element eleInboxReferencesException = XMLUtil.createChild(eleInboxReferencesList, KohlsPOCConstant.E_InboxReferences);    
				eleInboxReferencesException.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.STR_EXCEPTION);
				eleInboxReferencesException.setAttribute(KohlsPOCConstant.Value, e.getMessage());
				eleInboxReferencesException.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);  

				Element eleInboxReferencesErrorMessage = XMLUtil.createChild(eleInboxReferencesList, KohlsPOCConstant.E_InboxReferences);    
				eleInboxReferencesErrorMessage.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ErrorMessage);
				eleInboxReferencesErrorMessage.setAttribute(KohlsPOCConstant.Value, errorDescription);
				eleInboxReferencesErrorMessage.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);

				Element eleInboxReferencesAction = XMLUtil.createChild(eleInboxReferencesList, KohlsPOCConstant.E_InboxReferences);    
				eleInboxReferencesAction.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_ACTION);
				eleInboxReferencesAction.setAttribute(KohlsPOCConstant.Value, KohlsPOCConstant.ACTION_TEXT);
				eleInboxReferencesAction.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);

				Element eleInboxReferencesExceptionTime = XMLUtil.createChild(eleInboxReferencesList, KohlsPOCConstant.E_InboxReferences);    
				eleInboxReferencesExceptionTime.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ExceptionTime);
				eleInboxReferencesExceptionTime.setAttribute(KohlsPOCConstant.Value, sCurrentDate);
				eleInboxReferencesExceptionTime.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);

				Element eleInboxReferencesText20_Message = XMLUtil.createChild(eleInboxReferencesList, KohlsPOCConstant.E_InboxReferences);    
				eleInboxReferencesText20_Message.setAttribute(KohlsPOCConstant.Name, KohlsPOCConstant.ATTR_Text20_Message);
				eleInboxReferencesText20_Message.setAttribute(KohlsPOCConstant.Value, KohlsPOCConstant.Text20Value);
				eleInboxReferencesText20_Message.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);

				if(logger.isDebugEnabled()){
					logger.debug("Input to createAndSendAlert.createException:" + XMLUtil.getXMLString(docInboxInp));
				}
				//System.out.println("Input to createAndSendAlert.createException:" + XMLUtil.getXMLString(docInboxInp));
				//CreateException API to create custom Alert with Exception details of the PSA transaction that is being processed.
				Document createExceptionOutput = KOHLSBaseApi.invokeAPI(env, "createException",docInboxInp);

				if(logger.isDebugEnabled()){
					logger.debug("Output of createAndSendAlert.createException: "+ XMLUtil.getXMLString(createExceptionOutput));
				}
				//System.out.println("Output of createAndSendAlert.createException: "+ XMLUtil.getXMLString(createExceptionOutput));


			}
		} catch (Exception exp) {
			exp.printStackTrace();
			throw exp;
		}

		logger.endTimer("KohlsPoCPSAOrphanOrderAgent.createAndSendAlert");
	}

	/**
	 * This method fetches the records to be processed by calling getOrderList with Complex query.
	 * 	<Order DocumentType='0001' EnterpriseCode='KOHLS-RETAIL' Modifyts='2017-04-16T05:46:30-05:00' ModifytsQryType="LE">
		<ComplexQuery Operator="AND">
		<And>
		<Or>
		<Exp Name= "Extn_ExtnPsaStatus" Value="STARTED"/>  
		<Exp Name= "Extn_ExtnPsaStatus" Value="IN_PROGRESS"/>
		</Or>
		</And>
		</ComplexQuery>
		</Order>
	 */
	private Document fetchRecordsToProcessFromGetOrderList(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsPoCPSAOrphanOrderAgent.fetchRecordsToProcessFromGetOrderList");
		Document docGetOrderListOut = null;
		try{
			
			int hoursToSubtract = Integer.valueOf(inDoc.getDocumentElement().getAttribute("PSAIdealTime"));

			String calculatedTime = getInactivePSAOrderTimeFrame(hoursToSubtract);

			// Creating Input to invoke the getOrderList API
			Document docGetOrderListInput = YFCDocument.createDocument(
					KohlsPOCConstant.ELEM_ORDER).getDocument();
			Element eleGetOrderListInput = docGetOrderListInput.getDocumentElement();
			eleGetOrderListInput.setAttribute(KohlsPOCConstant.A_ENTERPRISE_CODE, KohlsPOCConstant.A_KOHLS_RETAIL );
			eleGetOrderListInput.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, KohlsPOCConstant.SO_DOCUMENT_TYPE );
			//Change for PST-928
			eleGetOrderListInput.setAttribute(KohlsPOCConstant.COLONY_ID, inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.COLONY_ID));
			eleGetOrderListInput.setAttribute(KohlsPOCConstant.ATTR_MODIFYTS, calculatedTime );
			eleGetOrderListInput.setAttribute("ModifytsQryType", KohlsPOCConstant.HD_LE );
			//Forming Complex Query for ExtnPSAStatus
			Element eleComplexQuery = XMLUtil.createChild(eleGetOrderListInput, KohlsPOCConstant.E_COMPLEX_QUERY);
			eleComplexQuery.setAttribute(KohlsPOCConstant.A_OPERATOR, KohlsPOCConstant.AND);  
			Element eleAnd = XMLUtil.createChild(eleComplexQuery, "And");
			Element eleOr = XMLUtil.createChild(eleAnd, "Or");

			Element expExtnPSAStatusStarted = XMLUtil.createChild(eleOr, "Exp");
			expExtnPSAStatusStarted.setAttribute("Name", "Extn_ExtnPsaStatus");
			expExtnPSAStatusStarted.setAttribute("Value", "STARTED");

			Element expExtnPSAStatusInProgress = XMLUtil.createChild(eleOr, "Exp");
			expExtnPSAStatusInProgress.setAttribute("Name", "Extn_ExtnPsaStatus");
			expExtnPSAStatusInProgress.setAttribute("Value", "IN_PROGRESS");
			if(logger.isDebugEnabled()){
				logger.debug("Invoking getOrderList API with input xml: \n"+XMLUtil.getXMLString(docGetOrderListInput));
			}
			//System.out.println("SYSO Invoking getOrderList API with input xml: \n"+XMLUtil.getXMLString(docGetOrderListInput));

			docGetOrderListOut = invokeAPI(env, XMLUtil.getDocument(KohlsPOCConstant.GetOrderListTemplateForPSAMidVoid), "getOrderList", docGetOrderListInput);
			if(logger.isDebugEnabled()){
				logger.debug("getOrderDetails For PSA MidVoid output xml: \n"+XMLUtil.getXMLString(docGetOrderListOut));
			}
			//System.out.println("SYSO getOrderDetails For PSA MidVoid output xml: \n"+XMLUtil.getXMLString(docGetOrderListOut));

		}catch(Exception e){
			e.printStackTrace();
			throw new YFSException(e.getMessage(),"00000","Error in KohlsPoCPSAOrphanOrderAgent.fetchRecordsToProcessFromGetOrderList");
		}
		logger.endTimer("KohlsPoCPSAOrphanOrderAgent.fetchRecordsToProcessFromGetOrderList");
		return docGetOrderListOut;
	}

	private String getInactivePSAOrderTimeFrame(int hoursToSubtract) {

		logger.endTimer("KohlsPoCPSAOrphanOrderAgent.getInactivePSAOrderTimeFrame");
		// Get Current system date
		String calculatedTime = null;
		try{
			Calendar c = Calendar.getInstance();
			c.add(Calendar.HOUR, -hoursToSubtract);
			calculatedTime = s1.format(c.getTime());
			if(logger.isDebugEnabled())
				logger.debug("The calculatedTime for PSA Orphan order clearance is :" +calculatedTime);
		}catch(Exception e){
			logger.debug("Exception while getting time in KohlsPoCPSAOrphanOrderAgent.getInactivePSAOrderTimeFrame");
			throw e;
		}
		logger.endTimer("KohlsPoCPSAOrphanOrderAgent.getInactivePSAOrderTimeFrame");
		return calculatedTime;
	}

	/**
	 * Invokes a Sterling API.
	 * @param env Sterling Environment Context.
	 * @param template Output Template that needs to be set
	 * @param apiName Name of API to invoke.
	 * @param inDoc Input Document to be passed to the API.
	 * @throws java.lang.Exception Exception thrown by the API.
	 * @return Output of the API.
	 */

	public static Document invokeAPI(YFSEnvironment env, Document template,
			String apiName, Document inDoc) throws Exception {
		env.setApiTemplate(apiName, template);
		Document returnDoc = api.invoke(env, apiName, inDoc);
		env.clearApiTemplate(apiName);
		return returnDoc;
	}
}
