/*
 * COPYRIGHT:
 * LICENSED MATERIALS - PROPERTY OF Toshiba Global Commerce Solutions, Inc.
 * "RESTRICTED MATERIALS OF Toshiba Global Commerce Solutions, Inc."
 * Copyright (C) 2011, 2017, Toshiba Global Commerce Solutions, Inc. All Rights Reserved.
 */
package com.kohls.poc.agent;

import static com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCVerifonePaymentConsts.CTROUTD;
import static com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCVerifonePaymentConsts.INTRN_SEQ_NUM;
import static com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCVerifonePaymentConsts.LPTOKEN;
import static com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCVerifonePaymentConsts.RESULT_CODE;
import static com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCVerifonePaymentConsts.TRANS_SEQ_NUM;
import static com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.NRSCVerifonePaymentConsts.TROUTD;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSStringUtil;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.ModifiablePSIStatus;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIDocumentsUtilForPOS;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.PSIStatus;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.SAFAgent;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.SAFAgentPSIStatusGenerator;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.VerifonePointIntegrationClient;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.GetCounterRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.msgs.request.StatusRequest;
import com.tgcs.tcx.gravity.nrsc.pos.semi.integrated.pinpad.verifone.userexit.NRSCVerifonePaymentType;
import com.tgcs.tcx.gravity.pos.order.POSOrderConsts;
import com.tgcs.tcx.gravity.pos.payment.PaymentConsts;
import com.tgcs.tcx.gravity.util.StringUtils;
import com.yantra.custom.dbi.KOHLS_Saf_Resp_Records;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.dbclasses.KOHLS_Saf_Resp_RecordsDBHome;
import com.yantra.shared.dbclasses.POS_PSI_DeviceBase;
import com.yantra.shared.dbclasses.POS_PSI_DeviceDBHome;
import com.yantra.shared.dbclasses.POS_PSI_SafBase;
import com.yantra.shared.dbclasses.POS_PSI_SafDBHome;
import com.yantra.shared.dbclasses.POS_PSI_StatusDBHome;
import com.yantra.shared.dbclasses.YFS_PaymentBase;
import com.yantra.shared.dbclasses.YFS_PaymentDBHome;
import com.yantra.shared.dbi.POS_PSI_Device;
import com.yantra.shared.dbi.POS_PSI_Saf;
import com.yantra.shared.dbi.POS_PSI_Status;
import com.yantra.shared.dbi.YFS_Charge_Transaction;
import com.yantra.shared.dbi.YFS_Payment;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.shared.ysc.util.YSCMultiSchemaHelper;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.core.YFCIterable;
import com.yantra.yfc.date.YTimestamp;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dblayer.PLTQueryOperator;
import com.yantra.yfc.dblayer.YFCDBContext;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCSAFAgent extends YCPBaseAgent
{
   private static final String          SAF_ELIGIBLE      = "ELIGIBLE";
   private static final String          SAF_PROCESSED     = "PROCESSED";
   private static final String          SAF_DECLINED      = "DECLINED";
   private static final String          SAF_IN_PROCESS    = "IN_PROCESS";
   private static final String          SAF_NOT_PROCESSED = "NOT_PROCESSED";
   private static final String         NO_SESSION_IDLE   = StatusRequest.SECONDARY_DATA.NO_SESSION_IDLE.getCode();
   private final static YFCLogCategory logger            = YFCLogCategory.instance( KohlsPoCSAFAgent.class );

  
   @Override
   public List<Document> getJobs( YFSEnvironment env, Document criteria, Document lastDocReturned ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.getJobs" ); 
	  String legacySaf = YFSSystem.getProperty("legacy.saf.enabled");
	  
	  if("Y".equalsIgnoreCase(legacySaf))
	  {
		  logger.info("processing getJobs through Toshiba SAF solution");
		  return new SAFAgent().getJobs(env, criteria, lastDocReturned);
	  }
	  
	  if (null != lastDocReturned) {
			 logger.info("lastDocReturned is Not Null. Stop getJobs");
				return null;
		 }
	  Date currentRunTime = new Date();
	  logger.info("****SAF Agent getJobs - Start****** @ "+currentRunTime);
	  // Check if record exists.
	  SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd" );
	  String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
	    int noOfSAFRecords = getNumberOfRecordsToPurge(env,timestamp);
	    if(noOfSAFRecords == 0)
	    {
    	  		logger.info("No Eligible KOHLS_SAF_RESP_RECORDS to purge");
	    }	     
	   if(noOfSAFRecords > 0) {
		   logger.info(noOfSAFRecords+" KOHLS_SAF_RESP_RECORDS to be purged");
		   YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
		   PLTQueryBuilder query3 = new PLTQueryBuilder( true );
		 
		  query3.appendString( "PURGE_DATE", PLTQueryOperator.LT,timestamp);
	      ctx.getPoolResolver().addFact("ColonyId", "STORE_GRP_01");
		  KOHLS_Saf_Resp_RecordsDBHome.getInstance().deleteWithWhere(ctx, query3);			 
		  ctx.commit();
	   }
      List<Document> result = new ArrayList<Document>();
      PLTQueryBuilder query4 = new PLTQueryBuilder( true );
      query4.appendYDate("EXTN_NEXT_AVAILABLE_TS", "<=", YTimestamp.newTimestamp());
      query4.appendOrderBy( "CREATETS DESC" );
      String recordsToBuffer = criteria.getDocumentElement().getAttribute("NumRecordsToBuffer");
      List<POS_PSI_Saf> safRecords = POS_PSI_SafDBHome.getInstance().listWithWhere( (YFCDBContext) env, query4, Integer.parseInt(recordsToBuffer) );
      logger.info("SQL to List eligible POS_PSI_SAF Records ---> "+query4.getReadableWhereClause());
      if(safRecords.size() == 0)
      {
    	  	logger.info("No Eligible POS_PSI_SAF Records to process");
      }
      else
      {
    	  	logger.info(safRecords.size()+" Eligible POS_PSI_SAF Records to process");
      }
      String previousDeviceId = "";
      YFCDocument jobDocument = null;
      for ( POS_PSI_Saf record : safRecords )
      {   
         String currentDeviceId = record.getDevice_Id();
         if ( !currentDeviceId.equals( previousDeviceId ) )
         {
            previousDeviceId = currentDeviceId;
            jobDocument = YFCDocument.createDocument( "SAFEntryList" );          
            jobDocument.getDocumentElement().setAttribute( "DeviceId", currentDeviceId );
            result.add( jobDocument.getDocument() );
         }
         YFCElement safEntryElement = record.getXML( jobDocument, null );
         jobDocument.getDocumentElement().appendChild( safEntryElement );
      }
      logger.info("****SAF Agent getJobs - End****** @ "+currentRunTime);
      logger.endTimer( "KohlsPoCSAFAgent.getJobs" );
      return result;
   }
   
   /**
    * Create By mrjoshi * 
    * @param env
    * @param sDeviceID
    * @param tranNo
    * @param safNum
    * @return
  * @throws Exception 
    */
   private int getNumberOfRecordsToPurge(YFSEnvironment env, String timestamp) throws Exception {
     logger.beginTimer( "KohlsUpdateSAFRecords.getNumberOfRecordsInSAFTable" );
     PLTQueryBuilder query = new PLTQueryBuilder( true );
     query.appendString( "PURGE_DATE", PLTQueryOperator.LT,timestamp);
     YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
     ctx.getPoolResolver().addFact("ColonyId", "STORE_GRP_01");
     logger.info("SQL to purge KOHLS_SAF_RESP_RECORDS ---> "+query.getReadableWhereClause());
     List<KOHLS_Saf_Resp_Records> safRecords = KOHLS_Saf_Resp_RecordsDBHome.getInstance().listWithWhere(ctx, query, 1);
     logger.endTimer( "KohlsUpdateSAFRecords.getNumberOfRecordsInSAFTable" );
     return safRecords.size();
   }

@Override
public void executeJob( YFSEnvironment env, Document inDoc ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.executeJob" );
	  String legacySaf = YFSSystem.getProperty("legacy.saf.enabled");  
	  if("Y".equalsIgnoreCase(legacySaf))
	  {
		 logger.info("processing executeJob through Toshiba SAF solution");
		 new SAFAgent().executeJob(env, inDoc);
	  }
	  else
	  { 
		  YFCDocument jobDocument = YFCDocument.getDocumentFor( inDoc );
	      syncPOSStatusAndPOSDeviceInNewContextBoundary( env, jobDocument.getDocumentElement().getAttribute( "DeviceId" ));
	      boolean retryOthersLater = false;
	      for ( YFCElement safEntryElement : jobDocument.getDocumentElement().getChildren() )
	      {
	    	  	  Date now = new Date();
	    	  	  POS_PSI_Saf safEntry = POS_PSI_SafBase.newInstance();
		     safEntry.setAttributes( safEntryElement );
	        
	         if(retryOthersLater)
	         {	
	        	 		
		        	if(now.after(safEntry.getPurge_Date().getYDate()))
	     	 	{
		        		logger.info( "retryOthersLater = true. SAF record Past Purge date for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
			             		 +safEntry.getOrder_Header_Key());
	     	 		Document responseDoc = SCXmlUtil.createDocument("RESPONSE");
	     	 		handleSAFNotProcessed( env, null, safEntry, responseDoc, true,safEntryElement );
	     	 	}
	     	 	else
	     	 	{
	     	 		logger.info( "retryOthersLater = true. Skipping the SAF record for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		             		 +safEntry.getOrder_Header_Key());
	     	 		updateNextAvailableTS(env,safEntryElement, false,safEntry.getLockid(),safEntry);
	     	 	}
		        	YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
		        	ctx.commit();
	         }	  
	         else
	         {	
	        	 	logger.info( "Processing SAF for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
	             		 +safEntry.getOrder_Header_Key());	
		         retryOthersLater = processSAFEntryInNewContextBoundary( env, safEntry,safEntryElement );
	         }
	      }
	  }
	  logger.endTimer( "KohlsPoCSAFAgent.executeJob" );
   }

   private boolean processSAFEntryInNewContextBoundary( YFSEnvironment env, POS_PSI_Saf safEntry, YFCElement safEntryElement )
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.processSAFEntryInNewContextBoundary" );
      final String classMethodName = "SAFAgent.processSAFEntryInNewContextBoundary";

      Object[] pair = null;
      YFSContext oNewCtx = null;
      boolean retryOthersLater = false;
      try
      {
         pair = YSCMultiSchemaHelper.ConnectionHelper.getNewContext( (YFSContext) env, classMethodName );
         oNewCtx = initNewContext( (YFSContext) env, pair );
         retryOthersLater = processSAFEntry( oNewCtx, safEntry, safEntryElement, false);
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Committing DB context in syncPOSStatusAndPOSDeviceInNewContextBoundaryt" );
         }
         oNewCtx.commit();
      }
      catch ( Exception e )
      {
	    	  if ( oNewCtx != null )
	          {
	             try
	             {
	                oNewCtx.rollback();
	             }
	             catch ( SQLException sqlEx )
	             {
	                logger.error( "Caught an exception, but hit yet another exception attempting to rollback: " + e.getClass().getName() );
	             }
	          }
      }
      finally
      {
         if ( pair != null )
         {
            YSCMultiSchemaHelper.ConnectionHelper.removePartitionFromContext( pair, classMethodName );
            if ( oNewCtx != null )
            {
               oNewCtx.close();
            }
         }
      }
      logger.endTimer( "KohlsPoCSAFAgent.processSAFEntryInNewContextBoundary" );
      return retryOthersLater;
   }

	private boolean processSAFEntry( YFSEnvironment env, POS_PSI_Saf safEntry, YFCElement safEntryElement, boolean forceDisableSAFClient) throws Exception
	{
		logger.beginTimer( "KohlsPoCSAFAgent.processSAFEntry" );
	    boolean bClientSAFEnabled = false;
	  	boolean retryOthersLater = false;
	    String sessionStatus = "";
	    PSIStatus status = null;
	    Document safResponse = null;
	    String sellerOrg = "";
	    String tranNo = "";
		try
		{
    		if(!KOHLSStringUtil.isEmpty(safEntry.getOrder_Header_Key())){
    			
    			 if(forceDisableSAFClient)
             {
             	 logger.info( "Falling back to Legacy logic for Client SAF enabled Store #: "+sellerOrg+" SAF num: "+ safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
  	               		 +safEntry.getOrder_Header_Key()+". SAF Creation date: "+safEntryElement.getAttribute("CreateTS"));
             }
    			  else
    			  {
    	                Document orderListInDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_ORDER);
    	                orderListInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, safEntry.getOrder_Header_Key());
    	                String sGetOrderListTemplate = "<OrderList TotalOrderList=''> <Order VoidIndicator='' SellerOrganizationCode='' TerminalID='' PosSequenceNo=''/> </OrderList>";
    	                Document orderListOutDoc =
    	                		KohlsCommonUtil.invokeAPI(env, XMLUtil.getDocument(sGetOrderListTemplate), KohlsPOCConstant.API_GET_ORDER_LIST , orderListInDoc);
    	                if(! orderListOutDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TOTAL_ORDER_LIST).equals("0")){
    	                    Element eleOrder = (Element) orderListOutDoc.getElementsByTagName(KohlsPOCConstant.E_ORDER).item(0);
    	                    String voidIndicator = null;
    	                    voidIndicator = eleOrder.getAttribute("VoidIndicator");
    	                if(!YFCCommon.isVoid(voidIndicator))
    	                {
    		            		logger.info( "SAF processing Not applicable for Voided order for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
    		                  		 +safEntry.getOrder_Header_Key()+ "Deleting the SAF Record from POS_PSI_SAF table"); 
    		           	     YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
    		           	     // Remove SAF record from database
    		                POS_PSI_SafDBHome.getInstance().delete( (YFCDBContext) env, safEntry );  
    		                ctx.commit();
    		                return retryOthersLater;
    	                }
    	                tranNo = eleOrder.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
    	                sellerOrg =  eleOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
    	                String enableClientSAF = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.KOHLS_ENABLE_CLIENT_SAF, sellerOrg, KohlsPOCConstant.NO);                
    	                if(KohlsPOCConstant.YES.equalsIgnoreCase(enableClientSAF) && !forceDisableSAFClient) {
    	                 	logger.info( "Client SAF enabled for Store #: "+sellerOrg+" SAF num: "+ safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
    	      	               		 +safEntry.getOrder_Header_Key());
    	                  bClientSAFEnabled = true;
    	                } 
    	                else
    	                {
    	                		logger.info( "Client SAF disabled for Store #: "+sellerOrg+" SAF num: "+ safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
    	   	               		 +safEntry.getOrder_Header_Key());
    	                }
    	                    
    	               }
    	            else
    	            {	
    	            		logger.info( "SAF processing Not applicable as order doesn't exist anymore for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
    	                 		 +safEntry.getOrder_Header_Key()+ "Deleting the SAF Record from POS_PSI_SAF table");  
    	           	     YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
    	           	     // Remove SAF record from database
    	                POS_PSI_SafDBHome.getInstance().delete( (YFCDBContext) env, safEntry );  
    	                ctx.commit();
    	                return retryOthersLater;
    	            }
    			  }
         }
    		if( !bClientSAFEnabled) {
    		  PLTQueryBuilder query = new PLTQueryBuilder( true ); 
              query.appendString( "DEVICE_ID", PLTQueryOperator.EQUALS, safEntry.getDevice_Id() );
              final POS_PSI_Device deviceInfo = POS_PSI_DeviceDBHome.getInstance().selectWithWhere( (YFCDBContext) env, query );
              SAFAgentPSIStatusGenerator statusGenerator = new SAFAgentPSIStatusGenerator( deviceInfo );
              status = statusGenerator.generatePSIStatus(); 
              StatusRequest statusRequest = new StatusRequest( status );
              logger.info( "GET STATUS REQUEST for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
	               		 +safEntry.getOrder_Header_Key()+"---->\n"+YFCDocument.getDocumentFor( statusRequest.getDocument() ).toString() );
              Document response = VerifonePointIntegrationClient.send( status, statusRequest );
              logger.info( "GET STATUS RESPONSE for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
	               		 +safEntry.getOrder_Header_Key()+"---->\n"+YFCDocument.getDocumentFor( response ).toString() );
              sessionStatus = PSIDocumentsUtilForPOS.selectFirst( response.getDocumentElement(), "SECONDARY_DATA", "" );              
              if ( NO_SESSION_IDLE.equalsIgnoreCase( sessionStatus ) )
              {
                  GetCounterRequest counterRequest = new GetCounterRequest( status );
                  logger.info( "GET COUNTER REQUEST for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
 	               		 +safEntry.getOrder_Header_Key()+"---->\n"+YFCDocument.getDocumentFor( counterRequest.getDocument() ).toString() );
                  response = VerifonePointIntegrationClient.send( status, counterRequest );
                
                  String ctr = PSIDocumentsUtilForPOS.selectFirst( response.getDocumentElement(), "COUNTER", "" );
                  if ( StringUtils.hasText( ctr ) && status instanceof ModifiablePSIStatus )
                  {
                      ( (ModifiablePSIStatus) status ).overwriteCounter( ctr );
                      safResponse = VerifonePointIntegrationClient.querySAF( status, "", safEntry.getSAF_Num() );
                  }
              }
              else
              {
            	  	logger.info( "PINPAD Busy for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
 	               		 +safEntry.getOrder_Header_Key()+"---->\n"+YFCDocument.getDocumentFor( response ).toString() );
              }
    		} else {
    		  // If client SAF is enabled then fetch the record from custom table.
    		  safResponse = makeSAFRecord(env, safEntry.getSAF_Num(),  safEntry.getDevice_Id(), sellerOrg, tranNo);
    		  if(YFCCommon.isVoid(safResponse))
    		  {
    			  String forceLegacySAFThreshold = KohlsPoCCommonAPIUtil.getRuleValue(env,"FORCE_LEGACY_SAF_THRESHOLD", sellerOrg, KohlsPOCConstant.EMPTY); 
    			  if(!YFCCommon.isVoid(forceLegacySAFThreshold))
    			  {
    				  Date disableSAFClientDate = getForceDisableSAFClientDate(safEntry.getCreateTS().getString(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT), forceLegacySAFThreshold);
    				  Date now = new Date();
    				  if(now.after(disableSAFClientDate))
    				  {
    					  return processSAFEntry( env, safEntry, safEntryElement, true);
    				  }
    			  }	  
    		  }
    		  else
    		  {
    			  logger.info( "Client SAF Record found for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
    	            		 +safEntry.getOrder_Header_Key()+"---->\n"+YFCDocument.getDocumentFor( safResponse ).toString() );
    		  }
    		  safEntryElement.setAttribute("ClientSafRecord", "Y");
    		  safEntryElement.setAttribute("StoreNo", sellerOrg);
    		  safEntryElement.setAttribute("DeviceId", safEntry.getDevice_Id());
    		  safEntryElement.setAttribute("TranNo", tranNo);   		 
    		}
			
			if (!YFCCommon.isVoid(safResponse))
			{
			    logger.info( "QUERY SAF RESPONSE for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
	               		 +safEntry.getOrder_Header_Key()+"---->\n"+YFCDocument.getDocumentFor( safResponse ).toString() );
			    String safStatus = PSIDocumentsUtilForPOS.selectFirst( safResponse.getDocumentElement(), "SAF_STATUS", "" );
				boolean safNotFound = !StringUtils.hasText( safStatus );

				if ( safNotFound || safStatus.equalsIgnoreCase( SAF_NOT_PROCESSED ) )
				{
					logger.info( "Processing as SAF Not found or NOT PROCESSED for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key());
					handleSAFNotProcessed( env, status, safEntry, safResponse, safNotFound,safEntryElement );
				}
				else if ( safStatus.equalsIgnoreCase( SAF_PROCESSED ) )
				{
					logger.info( "Processing as SAF PROCESSED for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key());
					handleSAFProcessed( env, status, safEntry, safResponse,safEntryElement );
				}
				else if ( safStatus.equalsIgnoreCase( SAF_DECLINED ) )
				{
					logger.info( "Processing as SAF DECLINED for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key());
					handleSAFDeclined( env, status, safEntry, safResponse,safEntryElement );
				}
				else if ( safStatus.equalsIgnoreCase( SAF_ELIGIBLE ) )
				{
					logger.info( "Processing as SAF ELIGIBLE for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key());
					handleSAFEligible( env, status, safEntry, safResponse,safEntryElement );
				}
				else if ( safStatus.equalsIgnoreCase( SAF_IN_PROCESS ) )
				{
					logger.info( "Processing as SAF IN PROCESS for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key());
					
					handleSAFInProcess( env, status, safEntry, safResponse,safEntryElement );
				}
			}
			else
			{		  
				Date now = new Date();
				if(now.after( safEntry.getPurge_Date().getYDate()))
				{
					logger.info( "SAF record Past Purge date for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key()+". Processing SAF record as NOT_PROCESSED");
		    	 		Document responseDoc = SCXmlUtil.createDocument("RESPONSE");
		    	 		handleSAFNotProcessed( env, null, safEntry, responseDoc, true,safEntryElement );
		    	 	}
				else
				{
					 logger.info( "SAF Record waiting to be processed for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		               		 +safEntry.getOrder_Header_Key()+".Do Nothing"+". SAF Client Enabled? "+bClientSAFEnabled+". Force Disable SAF Client: "+forceDisableSAFClient);
				}
			}
		}
      catch ( Exception e )
      {

         if ( e instanceof ConnectException || e instanceof SocketTimeoutException || e.toString().contains("NRSCSocketCreationTimeout") )
         { 
        	 	logger.error( "Connectivity Exception while processing SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
            		 +safEntry.getOrder_Header_Key()+".Other records for this device id will be skipped in this run", e );
        	 	retryOthersLater = true;
         }
         else if (!bClientSAFEnabled)
         {
        	 	retryOthersLater = true;
        	 	logger.error( "Non Connectivity Exception while processing SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
               		 +safEntry.getOrder_Header_Key()+".Other records for this device id will be skipped in this run", e );         
        	 }
         else
         {
        	  logger.error( "Exception while processing Client SAF record for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
               		 +safEntry.getOrder_Header_Key()+".Other records for this device id will NOT be skipped in this run", e );  
         }
        
        	Date now = new Date();
    	 	if(now.after( safEntry.getPurge_Date().getYDate()))
    	 	{
    	 		Document responseDoc = SCXmlUtil.createDocument("RESPONSE");
    	 		handleSAFNotProcessed( env, null, safEntry, responseDoc, true,safEntryElement );
    	 	}
    	 	else
    	 	{
    	 		updateNextAvailableTS(env,safEntryElement, false,safEntry.getLockid(),safEntry);
    	 	}           	 	    	 	
      }
	  logger.endTimer( "KohlsPoCSAFAgent.processSAFEntry" );
      return retryOthersLater;
   }

   private static void handleSAFNotProcessed( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, boolean safNotFound, YFCElement safEntryElement ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.handleSAFNotProcessed" );
      processSAFPayment( env, status, safRecord, response, false, safNotFound,safEntryElement );
      logger.endTimer( "KohlsPoCSAFAgent.handleSAFNotProcessed" );
   }
   
   private static void handleSAFDeclined( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, YFCElement safEntryElement ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.handleSAFDeclined" ); 
      processSAFPayment( env, status, safRecord, response, true, safEntryElement );
      logger.endTimer( "KohlsPoCSAFAgent.handleSAFDeclined" ); 
   }

   private static void handleSAFEligible( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, YFCElement safEntryElement ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.handleSAFEligible" ); 
      Date now = new Date();
      if ( now.before( safRecord.getPurge_Date().getYDate() ) )
      {
    	  	 logger.info( "SAF is ELIGBILE and before Purge date. Do nothing for SAF num: " + safRecord.getSAF_Num() + " , device id: " + safRecord.getDevice_Id() + ", orderheaderkey: "
            		 +safRecord.getOrder_Header_Key());
         logger.endTimer( "KohlsPoCSAFAgent.handleSAFEligible" ); 
         return;
      }
      processSAFPayment( env, status, safRecord, response, false, safEntryElement );
      logger.endTimer( "KohlsPoCSAFAgent.handleSAFEligible" ); 
   }

   private static void handleSAFInProcess( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, YFCElement safEntryElement ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.handleSAFInProcess" ); 
      Date now = new Date();
      if ( now.before( safRecord.getPurge_Date().getYDate() ) )
      {
    	  	 logger.info( "SAF is ELIGBILE and before Purge date. Do nothing for SAF num: " + safRecord.getSAF_Num() + " , device id: " + safRecord.getDevice_Id() + ", orderheaderkey: "
         		 +safRecord.getOrder_Header_Key());
         logger.info( "No need to purge the record yet" );
         logger.endTimer( "KohlsPoCSAFAgent.handleSAFInProcess" ); 
         return;
      }
      processSAFPayment( env, status, safRecord, response, false , safEntryElement );
      logger.endTimer( "KohlsPoCSAFAgent.handleSAFInProcess" ); 
   }

   private static void handleSAFProcessed( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, YFCElement safEntryElement ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.handleSAFProcessed" ); 
      processSAFPayment( env, status, safRecord, response, true, safEntryElement );
      logger.endTimer( "KohlsPoCSAFAgent.handleSAFProcessed" ); 
   }

   /**
    * Method to process the SAF Payments
    * 
    * @param env
    * @param status
    * @param safRecord
    * @param response
    * @param processedSAF
    * @param safNotFound
    * @throws Exception
    */
   private static void processSAFPayment( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, boolean processedSAF, boolean safNotFound,YFCElement safEntryElement ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.processSAFPayment" ); 
	  boolean processed = false;
	  try
	  {
		// Find the Payment Method on the order with the specified OrderHeaderKey and the SAF number
	      YFS_Payment payment = getSAFPayment( env, safRecord );

	      final String saf_Num = safRecord.getSAF_Num();

	      processed = processSAFInfo( env, status, payment.getOrder_Header_Key(), payment.getPayment_Key(), payment.getPayment_Type(), saf_Num, response, processedSAF, safNotFound,safEntryElement,safRecord );
	      
	  }
	  catch(Exception e)
	  {
		  logger.error( "Exception in getPayment method for SAF num: " + safRecord.getSAF_Num() + " , device id: " + safRecord.getDevice_Id() + ", orderheaderkey: "
	         		 +safRecord.getOrder_Header_Key(),e); 
		  processed = false;
	  }
      Date now = new Date();
      if(!processed && now.before( safRecord.getPurge_Date().getYDate() ))
      {
    	     logger.info( "SAF Payment (before purge date) not processed for SAF num: " + safRecord.getSAF_Num() + " , device id: " + safRecord.getDevice_Id() + ", orderheaderkey: "
         		 +safRecord.getOrder_Header_Key()); 
    	  	 updateNextAvailableTS(env,safEntryElement, false,safRecord.getLockid(),safRecord);
      }
      else if ( !processed && now.after( safRecord.getPurge_Date().getYDate() ) )
      {
    	    logger.info( "SAF Payment (after purge date) not processed for SAF num: " + safRecord.getSAF_Num() + " , device id: " + safRecord.getDevice_Id() + ", orderheaderkey: "
          		 +safRecord.getOrder_Header_Key()); 
    	  	updateNextAvailableTS(env,safEntryElement, true,safRecord.getLockid(),safRecord);
      }

      // if processed
      if ( processed )
      {
    	     logger.info( "SAF processing completed for SAF num: " + safRecord.getSAF_Num() + " , device id: " + safRecord.getDevice_Id() + ", orderheaderkey: "
           		 +safRecord.getOrder_Header_Key()+ ". Deleting the SAF Record from POS_PSI_SAF table"); 
    	     YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
    	     // Remove SAF record from database
         POS_PSI_SafDBHome.getInstance().delete( (YFCDBContext) env, safRecord );  
         ctx.commit();
      }
      logger.endTimer( "KohlsPoCSAFAgent.processSAFPayment" ); 
   }

/**
    * Method to process the SAF Payments
    * 
    * @param env
    * @param status
    * @param safRecord
    * @param response
    * @param processedSAF
    * @param safNotFound
 * @param safEntryElement 
 * @param safRecord 
    * @throws Exception
    */
   private static boolean processSAFInfo( YFSEnvironment env, PSIStatus status, String orderHeaderKey, String paymentKey, String paymentType, String saf_Num, Document response, boolean processedSAF, boolean safNotFound, YFCElement safEntryElement, POS_PSI_Saf safEntry ) throws Exception
   {
	 boolean paymentProcessed = false;
	logger.beginTimer( "KohlsPoCSAFAgent.processSAFInfo" ); 
     try
      {
      // Get the chargeTransactionDetails with chargeType of CHARGE and not voided with the specified paymentKey
      YFCDocument chargeListResult = getChargeTransactionDetails( (YFSContext) env, orderHeaderKey, paymentKey );
      YFCElement chargeListElem = chargeListResult.getDocumentElement();

    	      // if any payments, process them
          if ( chargeListElem.hasChildNodes() )
          {
             YFCIterable<YFCElement> chargeList = chargeListElem.getChildren();
             YFCElement chargeTransaction = chargeList.next(); // we should ONLY expect 1 chargeTransaction here

             // call recordExternalCharges to create new payment
             recordExternalCharges( (YFSContext) env, chargeTransaction, response.getDocumentElement(), paymentType, processedSAF );

             // call voidChargeTransaction to remove the offline Charge
             removeOfflineChargeTransaction( (YFSContext) env, chargeTransaction );

             // call changeOrder to suspend the offline Payment and resolve hold
             suspendOfflinePaymentMethod( (YFSContext) env, chargeTransaction, response.getDocumentElement(), processedSAF, safNotFound );

             paymentProcessed = true;
          }
      }
      catch (Exception e)
      {
    	  	logger.error( "Exception in processSAFPayment method for SAF num: " + safEntry.getSAF_Num() + " , device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
            		 +safEntry.getOrder_Header_Key(), e );      	  
      }
      logger.endTimer( "KohlsPoCSAFAgent.processSAFInfo" ); 
      return paymentProcessed;
   }

   private static void processSAFPayment( YFSEnvironment env, PSIStatus status, POS_PSI_Saf safRecord, Document response, boolean processedSAF, YFCElement safEntryElement ) throws Exception
   {
      processSAFPayment( env, status, safRecord, response, processedSAF, false, safEntryElement );
   }

   private static YFS_Payment getSAFPayment( YFSEnvironment env, POS_PSI_Saf safRecord )
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.getSAFPayment" ); 
      PLTQueryBuilder query = new PLTQueryBuilder( true );
      query.appendString( "ORDER_HEADER_KEY", PLTQueryOperator.EQUALS, safRecord.getOrder_Header_Key() );
      query.appendAND();
      query.appendString( "EXTN_SAF_NUM", PLTQueryOperator.EQUALS, safRecord.getSAF_Num() );
      YFS_Payment payment = YFS_PaymentDBHome.getInstance().selectWithWhere( (YFCDBContext) env, query );
      logger.endTimer( "KohlsPoCSAFAgent.getSAFPayment" ); 
      return payment;
   }

   private static YFCDocument getChargeTransactionDetails( YFSContext oEnv, String orderHeaderKey, String paymentKey ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.getChargeTransactionDetails" ); 
      Document chargeList = null;

      String apiName = "getChargeTransactionList";

      // create API tempate
      YFCDocument chargeListTemplateDoc = YFCDocument.createDocument( POSOrderConsts.CHARGE_TRANSACTION_DETAILS );
      YFCElement chargeListTemplateElem = chargeListTemplateDoc.getDocumentElement();
      YFCElement chargeTransTemplateElem = chargeListTemplateElem.createChild( POSOrderConsts.CHARGE_TRANSACTION_DETAIL );
      YFCElement paymentMethodElem = chargeTransTemplateElem.createChild( POSOrderConsts.PAYMENT_METHOD_ELEMENT );
      paymentMethodElem.createChild( "Extn" );

      // set API template
      oEnv.setApiTemplate( apiName, chargeListTemplateDoc.getDocument() );

      try
      {
         // first lets get list of payments
         YFCDocument chargeTransDetailDocument = YFCDocument.createDocument( POSOrderConsts.CHARGE_TRANSACTION_DETAIL );
         YFCElement chargeTransDetail = chargeTransDetailDocument.getDocumentElement();

         chargeTransDetail.setAttribute( POSOrderConsts.ORDER_HEADER_KEY, orderHeaderKey );
         chargeTransDetail.setAttribute( YFS_Payment.PAYMENT_KEY, paymentKey );
         chargeTransDetail.setAttribute( POSOrderConsts.OMP_DO_NOT_INCLUDE_ALREADY_VOIDED_OR_REFUNDED, POSOrderConsts.FLAG_TRUE );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Calling getChargeTransactionList with document:" );
            logger.debug( chargeTransDetailDocument.getDocument() );
         }

         YIFApi api = YIFClientFactory.getInstance().getApi();
         chargeList = api.getChargeTransactionList( oEnv, chargeTransDetailDocument.getDocument() );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "getChargeTransactionList output == " );
            logger.debug( chargeList );
         }
      }
      catch ( Exception e )
      {
         // TODO Better error handling
         throw e;
      }
      logger.endTimer( "KohlsPoCSAFAgent.getChargeTransactionDetails" );
      return YFCDocument.getDocumentFor( chargeList );
   }

   private static void removeOfflineChargeTransaction( YFSContext ctx, YFCElement chargeTransaction ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.removeOfflineChargeTransaction" );
      try
      {
         YFCDocument chargeListTemplateDoc = YFCDocument.createDocument( POSOrderConsts.CHARGE_TRANSACTION_DETAILS );
         YFCElement chargeListTemplateElem = chargeListTemplateDoc.getDocumentElement();
         YFCElement chargeTransTemplateElem = chargeListTemplateElem.createChild( POSOrderConsts.CHARGE_TRANSACTION_DETAIL );
         chargeTransTemplateElem.setAttribute( YFS_Charge_Transaction.CHARGE_TRANSACTION_KEY, chargeTransaction.getAttribute( YFS_Charge_Transaction.CHARGE_TRANSACTION_KEY ) );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Calling voidChargeTransaction with document:" );
            logger.debug( chargeListTemplateDoc.getDocument() );
         }

         YIFApi api = YIFClientFactory.getInstance().getApi();
         Document voidOutput = api.voidChargeTransaction( ctx, chargeListTemplateDoc.getDocument() );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "voidChargeTransaction output == " );
            logger.debug( voidOutput );
         }
      }
      catch ( Exception e )
      {
         // TODO Better error handling
         throw e;
      }
      logger.endTimer( "KohlsPoCSAFAgent.removeOfflineChargeTransaction" );
   }

   private static void suspendOfflinePaymentMethod( YFSContext ctx, YFCElement chargeTransaction, Element responseElem, boolean processedSAF, boolean safNotFound ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.suspendOfflinePaymentMethod" );
      try
      {
         // Create inputXML for changeOrder
         YFCDocument coXDoc = YFCDocument.createDocument( POSOrderConsts.ORDER );
         YFCElement coRoot = coXDoc.getDocumentElement();

         coRoot.setAttribute( POSOrderConsts.ORDER_HEADER_KEY, chargeTransaction.getAttribute( POSOrderConsts.ORDER_HEADER_KEY ) );

         // Create PaymentMethod Element
         YFCElement coPMS = coRoot.createChild( PaymentConsts.YFS_PAYMENT_METHODS );
         YFCElement coPM = coPMS.createChild( PaymentConsts.YFS_PAYMENT_METHOD );

         coPM.setAttribute( YFS_Payment.PAYMENT_KEY, chargeTransaction.getAttribute( YFS_Payment.PAYMENT_KEY ) );

         if ( processedSAF )
         {
            // Only suspend the paymentMethod if the SAF was processed. We will be creating a new paymentMethod.
            coPM.setAttribute( POSOrderConsts.CHARGE_SUSPEND_ANY_MORE_CHARGES, "Y" );
         }
         else
         {
            YFCElement paymentMethod = chargeTransaction.getChildElement( POSOrderConsts.PAYMENT_METHOD_ELEMENT );
            YFCElement extn = paymentMethod.getChildElement( "Extn" );
            String safStatus = PSIDocumentsUtilForPOS.selectFirst( responseElem, "SAF_STATUS", extn.getAttribute( "ExtnSAFStatus" ) );

            // Create the Extn Element to update if the SAF was Not Processed. Only changeOrder api can change an existing paymentMethod
            YFCElement coExtn = coPM.createChild( "Extn" );
            coExtn.setAttribute( "ExtnSAFStatus", safNotFound ? SAF_NOT_PROCESSED : safStatus );
            coExtn.setAttribute( "ExtnApprovedAmount", "0.00" );
            coExtn.setAttribute( "ExtnPSIPayment", "Y" );
            coExtn.setAttribute( "ExtnIsOrphaned", "Y" );
            coExtn.setAttribute( "ExtnEmvResponseTags", extn.getAttribute( "ExtnEmvResponseTags" ) );
         }

         // Create OrderHoldTypes Element
         YFCElement coOHTs = coRoot.createChild( "OrderHoldTypes" );
         YFCElement coOHT = coOHTs.createChild( "OrderHoldType" );
         coOHT.setAttribute( "HoldType", "SAF_Hold" );
         coOHT.setAttribute( PaymentConsts.YFS_STATUS, "1300" );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Calling changeOrder with document:" );
            logger.debug( coXDoc.getDocument() );
         }

         YIFApi api = YIFClientFactory.getInstance().getApi();
         Document changeOrderOutput = api.changeOrder( ctx, coXDoc.getDocument() );
         changeOrderOutput = api.changeOrder( ctx, coXDoc.getDocument() );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "changeOrder output == " );
            logger.debug( changeOrderOutput );
         }
      }
      catch ( Exception e )
      {
         // TODO Better error handling
         throw e;
      }
      logger.endTimer( "KohlsPoCSAFAgent.suspendOfflinePaymentMethod" );
   }

   private static void recordExternalCharges( YFSContext ctx, YFCElement chargeTransaction, Element record, String paymentType, boolean processedSAF ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.recordExternalCharges" );
      try
      {
         YFCDocument recExtChargesInDoc = YFCDocument.createDocument( PaymentConsts.PAYMENT_ELEMENT_RECORD_EXTERNAL_CHARGES );
         YFCElement recExtChargesInElem = recExtChargesInDoc.getDocumentElement();
         recExtChargesInElem.setAttribute( POSOrderConsts.ORDER_HEADER_KEY, chargeTransaction.getAttribute( POSOrderConsts.ORDER_HEADER_KEY ) );
         YFCElement paymentMethodOutElem = recExtChargesInElem.createChild( PaymentConsts.YFS_PAYMENT_METHOD );

         // update PaymentMethod with Query Response
         addPaymentDataToResponse( record, paymentMethodOutElem, chargeTransaction, paymentType, processedSAF );

         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Calling recordExternalCharges with document:" );
            logger.debug( recExtChargesInDoc.getDocument() );
         }

         YIFApi api = YIFClientFactory.getInstance().getApi();
         api.recordExternalCharges( ctx, recExtChargesInDoc.getDocument() );
      }
      catch ( Exception e )
      {
         // TODO Better error handling
         throw e;
      }
      logger.endTimer( "KohlsPoCSAFAgent.recordExternalCharges" );
   }

   private static void addPaymentDataToResponse( Element responseElem, YFCElement outPaymentMethod, YFCElement chargeTransaction, String paymentTypeStr, boolean processedSAF )
   {
	  
	  logger.beginTimer( "KohlsPoCSAFAgent.addPaymentDataToResponse" );
      YFCElement paymentMethod = chargeTransaction.getChildElement( POSOrderConsts.PAYMENT_METHOD_ELEMENT );
      YFCElement extn = paymentMethod.getChildElement( "Extn" );

      String paymentType = PSIDocumentsUtilForPOS.selectFirst( responseElem, "PAYMENT_TYPE", "CREDIT" );
      String approvedAmt = PSIDocumentsUtilForPOS.selectFirst( responseElem, "APPROVED_AMOUNT", "0.00" );
      String ctroutd = PSIDocumentsUtilForPOS.selectFirst( responseElem, "CTROUTD", "" );
      String safStatus = PSIDocumentsUtilForPOS.selectFirst( responseElem, "SAF_STATUS", extn.getAttribute( "ExtnSAFStatus" ) );
      String requestAmount = chargeTransaction.getAttribute( POSOrderConsts.YFS_REQ_AMOUNT );

      logger.info( "Payment Type: " + paymentType + ", approvedAmt: " + approvedAmt + " safStatus: " + safStatus + "requestAmount: " + requestAmount );

      // Create the PaymentDetails Element
      YFCElement outPaymentDetailsList = outPaymentMethod.createChild( PaymentConsts.OMP_PAYMENT_DETAILS + "List" );
      YFCElement outPaymentDetails = outPaymentDetailsList.createChild( PaymentConsts.OMP_PAYMENT_DETAILS );
      outPaymentDetails.setAttribute( PaymentConsts.YFS_AUTHORIZATION_ID, PSIDocumentsUtilForPOS.selectFirst( responseElem, "AUTH_CODE", "" ) );
      outPaymentDetails.setAttribute( PaymentConsts.YFS_REQ_AMOUNT, requestAmount );
      outPaymentDetails.setAttribute( "CVVAuthCode", PSIDocumentsUtilForPOS.selectFirst( responseElem, "CVV2_CODE", "" ) );
      outPaymentDetails.setAttribute( PaymentConsts.YFS_IN_PERSON, PaymentConsts.PAYMENT_FLAG_YES );
      outPaymentDetails.setAttribute( PaymentConsts.YFS_CHARGE_TYPE, "CHARGE" );
      outPaymentDetails.setAttribute( "OfflineStatus", "N" );
      // Attributes required to create a credit transaction record
      outPaymentDetails.setAttribute( "InternalReturnCode", "F0" );
      outPaymentDetails.setAttribute( PaymentConsts.YFS_TRAN_REQUEST_TIME, YTimestamp.newTimestamp() );
      outPaymentDetails.setAttribute( PaymentConsts.YFS_AUTH_TIME, YTimestamp.newTimestamp() );

      // In case of partial approval, the order would never complete.
      // Setting ProcessedAmount to requestAmount would resolve this issue.
      // And Sterling will move the chargeTransaction to CLOSED.
      outPaymentDetails.setAttribute( PaymentConsts.OMP_PROCESSED_AMOUNT, requestAmount );

      if ( processedSAF )
      {

         // Create the Extn Element
         YFCElement outExtn = outPaymentMethod.getChildElement( "Extn", true );
         outExtn.setAttribute( "ExtnSAFStatus", safStatus );
         outExtn.setAttribute( "ExtnApprovedAmount", approvedAmt );
         outExtn.setAttribute( "ExtnCtroutd", ctroutd );
         outExtn.setAttribute( "ExtnPSIPayment", "Y" );
         outExtn.setAttribute( "ExtnEmvResponseTags", extn.getAttribute( "ExtnEmvResponseTags" ) );

         // copy over existing attributes
         outPaymentMethod.setAttributes( paymentMethod.getAttributes() );

         // If SAF was processed, then we have the new attributes to fill in
         outPaymentMethod.setAttribute( PaymentConsts.YFS_PAYMENT_TYPE, NRSCVerifonePaymentType.fromEPS( paymentType ).toString() );
         outPaymentMethod.setAttribute( CTROUTD, ctroutd );
         outPaymentMethod.setAttribute( TROUTD, PSIDocumentsUtilForPOS.selectFirst( responseElem, "TROUTD", "" ) );
         outPaymentMethod.setAttribute( TRANS_SEQ_NUM, PSIDocumentsUtilForPOS.selectFirst( responseElem, "TRANS_SEQ_NUM", "" ) );
         outPaymentMethod.setAttribute( INTRN_SEQ_NUM, PSIDocumentsUtilForPOS.selectFirst( responseElem, "INTRN_SEQ_NUM", "" ) );
         outPaymentMethod.setAttribute( LPTOKEN, PSIDocumentsUtilForPOS.selectFirst( responseElem, "LPTOKEN", "" ) );
         outPaymentMethod.setAttribute( "DEBIT".equals( paymentType ) ? YFS_PaymentBase.DEBIT_CARD_NO : PaymentConsts.YFS_CREDIT_CARD_NO, PSIDocumentsUtilForPOS.selectFirst( responseElem, "CARD_TOKEN", "" ) );
         outPaymentMethod.setAttribute( RESULT_CODE, SAF_DECLINED.equalsIgnoreCase( safStatus ) ? VerifonePointIntegrationClient.ADD_PAYMENT_DECLINE_RESPONSE : VerifonePointIntegrationClient.ADD_PAYMENT_SUCCESS_RESPONSE );
         outPaymentMethod.setAttribute( PaymentConsts.YFS_PAYMENT_REFERENCE1, getTimestamp() );
         outPaymentMethod.removeAttribute( YFS_Payment.PAYMENT_KEY ); // remove copied over key to create new PaymentMethod

         // create and populate PersonInfoBillTo Element
         YFCElement cpPIBT = outPaymentMethod.createChild( PaymentConsts.PAYMENT_ELEMENT_PERSON_INFO_BILL_TO );
         cpPIBT.setAttribute( PaymentConsts.YCP_ZIP_CODE, outPaymentMethod.getAttribute( PaymentConsts.YCP_ZIP_CODE ) );
         cpPIBT.setAttribute( PaymentConsts.YCP_FIRST_NAME, outPaymentMethod.getAttribute( PaymentConsts.YCP_FIRST_NAME ) );
         cpPIBT.setAttribute( PaymentConsts.YCP_LAST_NAME, outPaymentMethod.getAttribute( PaymentConsts.YCP_LAST_NAME ) );

         if ( SAF_DECLINED.equalsIgnoreCase( safStatus ) )
         {
            outPaymentMethod.setAttribute( POSOrderConsts.CHARGE_SUSPEND_ANY_MORE_CHARGES, "Y" );
            outPaymentDetails.setAttribute( "VoidTransaction", "S" );
            outExtn.setAttribute( "ExtnApprovedAmount", "0.00" );
            // if SAF status is declined it is possible sometimes for the pinpad to respond without a CARD_TOKEN e.g. with HOST_RESPCODE 93
            // In the above case if the account number is empty set it to the SAF num from the original payment so the record payments can be completed
            if ( ("DEBIT".equals( paymentType ) && !StringUtils.hasText( outPaymentMethod.getAttribute(YFS_PaymentBase.DEBIT_CARD_NO) )) ||
                     ( (! ("DEBIT".equals( paymentType ))) && !StringUtils.hasText( outPaymentMethod.getAttribute(PaymentConsts.YFS_CREDIT_CARD_NO) ))  )
            {   
               outPaymentMethod.setAttribute( "DEBIT".equals( paymentType ) ? YFS_PaymentBase.DEBIT_CARD_NO : PaymentConsts.YFS_CREDIT_CARD_NO, paymentMethod.getAttribute( "DEBIT".equals( paymentType ) ? YFS_PaymentBase.DEBIT_CARD_NO : PaymentConsts.YFS_CREDIT_CARD_NO ));
            }
         }
      }
      else
      {
         // If SAF was not processed, then use the current Payment Method
         String paymentTyp=StringUtils.hasText( paymentTypeStr ) ? paymentTypeStr : NRSCVerifonePaymentType.fromEPS( paymentType ).toString();
         
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "PaymentType for Not processed/Eligible " + paymentTyp);
         }
         
         outPaymentMethod.setAttribute( PaymentConsts.YFS_PAYMENT_TYPE, paymentTyp );
         outPaymentMethod.setAttribute( YFS_Payment.PAYMENT_KEY, paymentMethod.getAttribute( YFS_Payment.PAYMENT_KEY ) );
         outPaymentDetails.setAttribute( "OfflineStatus", "Y" );
      }
      logger.endTimer( "KohlsPoCSAFAgent.addPaymentDataToResponse" );
   }

   private YFSContext initNewContext( YFSContext oOldEnv, Object[] pair )
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.initNewContext" );
      YFSContext newCtx = (YFSContext) pair[0];
      if ( logger.isDebugEnabled() )
      {
         logger.debug( "oOldEnv.getDBDate" + oOldEnv.getDBDate() );
         logger.debug( "oEnv.getDBDate() old " + newCtx.getDBDate() );
      }
      newCtx.setDBTime( oOldEnv.getDBDate() );
      if ( logger.isDebugEnabled() )
      {
         logger.debug( "oEnv.getDBDate() after setting from oOldEnv" + newCtx.getDBDate() );
      }
      logger.endTimer( "KohlsPoCSAFAgent.initNewContext" );
      return newCtx;
   }

   private static String getTimestamp()
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.getTimestamp" );
      GregorianCalendar now = new GregorianCalendar();
      SimpleDateFormat dateFormat = new SimpleDateFormat( "yyyyMMddHHmmss" );
      now.setTime( new Date() );
      logger.endTimer( "KohlsPoCSAFAgent.getTimestamp" );
      return dateFormat.format( now.getTime() );
   }
   
   private static String getNewTimestamp()
   {
      GregorianCalendar now = new GregorianCalendar();
      SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yyyy HH:mm:ss" );
      now.setTime( new Date() );
      return dateFormat.format( now.getTime() );
   }
   
   private static String getNextAvailableTS(boolean forcePush)
   {
	   logger.beginTimer( "KohlsPoCSAFAgent.getNextAvailableTS" );
	   if(forcePush)
	   {
		   String availDate = "2500-01-01T00:00:00";
		   return availDate;
	   }
	   Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		String retryInterval = YFSSystem.getProperty("saf.retry.interval");
		if(YFCCommon.isVoid(retryInterval))
		{
			retryInterval = "30";
		}
		cal.add(Calendar.MINUTE, Integer.parseInt(retryInterval)); 
		SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
		String availDate = sdf.format(cal.getTime());
		logger.endTimer( "KohlsPoCSAFAgent.getNextAvailableTS" );
		return availDate;
   }
   
   
   private static Date getForceDisableSAFClientDate(String createTs, String threshold) throws ParseException
   {
	   logger.beginTimer( "KohlsPoCSAFAgent.getForceDisableSAFClientDate" );
	   SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.MANAGE_SYNC_DB_IMPORT_DATE_FORMAT);
       Date dateInSrverTimezone = sdf.parse(createTs);
       
	   Calendar cal = Calendar.getInstance();
		cal.setTime(dateInSrverTimezone);		
		cal.add(Calendar.DAY_OF_MONTH, Integer.parseInt(threshold)); 
		logger.endTimer( "KohlsPoCSAFAgent.getForceDisableSAFClientDate" );
		return cal.getTime();
   }
   
   
   private static void updateNextAvailableTS( YFSEnvironment env, YFCElement safEntryElement,boolean forcePush,long lockid, POS_PSI_Saf safEntry) throws Exception
   {
	   logger.beginTimer( "KohlsPoCSAFAgent.updateNextAvailableTS" );
	   Document safEntryCloneDoc = SCXmlUtil.createDocument("SAFEntry");
	   safEntryCloneDoc.getDocumentElement().setAttribute("PSISAFKey", safEntryElement.getAttribute("PSISAFKey"));
	   Element extnEle = SCXmlUtil.createChild(safEntryCloneDoc.getDocumentElement(), "Extn");
	   String availableDate = null;
	   String maxAttemptForForcePush = YFSSystem.getProperty("saf.maxattempts.forcepush");
	   if(YFCCommon.isVoid(maxAttemptForForcePush))
	   {
		   maxAttemptForForcePush = "150";
	   }
	  
	   try
	   {
		   if(forcePush || lockid >= Integer.parseInt(maxAttemptForForcePush))
		   {		 
			   availableDate = getNextAvailableTS(true);
			   logger.info( "Moving Next Available date to Highdate " +availableDate+" for SAF num: " + safEntry.getSAF_Num() + ", device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
	             		 +safEntry.getOrder_Header_Key()+" Force push flag: "+forcePush+" current lockid: "+lockid+" max attempt for forcepush: "+maxAttemptForForcePush);
		   }
		   else
		   {		   
			   availableDate = getNextAvailableTS(false);
			   long newLockid = lockid+1;
			   logger.info( "Moving Next Available date to "+availableDate+" for SAF num: " + safEntry.getSAF_Num() + ", device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
		           		 +safEntry.getOrder_Header_Key()+" current lockid: "+lockid+" new lockid: "+newLockid);
		   }
		   extnEle.setAttribute("ExtnNextAvailableTS",availableDate );
		   YIFApi api = YIFClientFactory.getInstance().getApi();
		   api.invoke( env, "manageSAFEntryForPOS", safEntryCloneDoc);
		  
	   }
	   catch (Exception e)
	   {
		   logger.error( "Exception while calling manageSAFEntryForPOS for SAF Num : " + safEntry.getSAF_Num() + "device id: " + safEntry.getDevice_Id() + ", orderheaderkey: "
          		 +safEntry.getOrder_Header_Key(), e );
	   }
	   logger.endTimer( "KohlsPoCSAFAgent.updateNextAvailableTS" );
   }

   
   
   
   private boolean syncPOSStatusAndPOSDeviceInNewContextBoundary( YFSEnvironment env, String deviceID )
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.syncPOSStatusAndPOSDeviceInNewContextBoundary" );
      final String classMethodName = "SAFAgent.syncPOSStatusAndPOSDeviceInNewContextBoundary";
      Object[] pair = null;
      YFSContext oNewCtx = null;

      try
      {
         pair = YSCMultiSchemaHelper.ConnectionHelper.getNewContext( (YFSContext) env, classMethodName );
         oNewCtx = initNewContext( (YFSContext) env, pair );
         syncPOSStatusAndPOSDevice( oNewCtx, deviceID );
         if ( logger.isDebugEnabled() )
         {
            logger.debug( "Committing DB context in syncPOSStatusAndPOSDeviceInNewContextBoundary" );
         }
         oNewCtx.commit();
      }
      catch ( Exception e )
      {
         if ( oNewCtx != null )
         {
            try
            {
               oNewCtx.rollback();
            }
            catch ( SQLException sqlEx )
            {
               logger.error( "Caught an exception, but hit yet another exception attempting to rollback: " + e.getClass().getName() );
            }
         }
      }
      finally
      {
         if ( pair != null )
         {
            YSCMultiSchemaHelper.ConnectionHelper.removePartitionFromContext( pair, classMethodName );
            if ( oNewCtx != null )
            {
               oNewCtx.close();
            }
         }
      }
      logger.endTimer( "KohlsPoCSAFAgent.syncPOSStatusAndPOSDeviceInNewContextBoundary" );
      return false;
   }

   private void syncPOSStatusAndPOSDevice( YFSEnvironment env, String deviceID ) throws Exception
   {
	  logger.beginTimer( "KohlsPoCSAFAgent.syncPOSStatusAndPOSDevice" );
      PLTQueryBuilder query = new PLTQueryBuilder( true );

      query.appendString( "EXT_IP_ADDRESS", PLTQueryOperator.EQUALS, deviceID );
      final POS_PSI_Status statusInfo = POS_PSI_StatusDBHome.getInstance().selectWithWhere( (YFCDBContext) env, query );
      PLTQueryBuilder queryDevice = new PLTQueryBuilder( true );

      queryDevice.appendString( "DEVICE_ID", PLTQueryOperator.EQUALS, deviceID );
      POS_PSI_Device deviceInfo = POS_PSI_DeviceDBHome.getInstance().selectWithWhere( (YFCDBContext) env, queryDevice );
      
      //In case device Info not found in pos_psi_device table, the below code insert a record into pos_psi_device table.
      if(deviceInfo == null)
      {
    	  POS_PSI_DeviceBase deviceObject = POS_PSI_DeviceBase.newInstance();
    	  deviceObject.setDevice_Id(deviceID);
    	  deviceObject.setPrivate_Key(statusInfo.getPSI_Reference_Object_1());
    	  deviceObject.setPublic_Key( statusInfo.getPSI_Reference_Object_2() );
    	  deviceObject.setMAC_KEY( statusInfo.getPSI_Reference_Object_3() );
    	  deviceObject.setMac_Label( statusInfo.getPSI_Reference_Object_5() );
    	  deviceObject.setPrimary_Port("5015");
    	  deviceObject.setSecondary_Port("5016");

    	  POS_PSI_DeviceDBHome.getInstance().insert((YFCDBContext) env, deviceObject);
    	  
      }    
      else if (!deviceInfo.getPrivate_Key().equals( statusInfo.getPSI_Reference_Object_1() ) 
           || !deviceInfo.getPublic_Key().equals( statusInfo.getPSI_Reference_Object_2() ) 
           || !deviceInfo.getMAC_KEY().equals( statusInfo.getPSI_Reference_Object_3() )
           || !deviceInfo.getMac_Label().equals( statusInfo.getPSI_Reference_Object_5() ) )
      {
    	  YTimestamp psiStatModifyTs = statusInfo.getModifyts();
          YTimestamp deviceModifyTs = deviceInfo.getModifyTS();
          
          if(deviceModifyTs.before(psiStatModifyTs))
          {
        	// POS_PSI_DeviceBase deviceBase=new POS_PSI_DeviceBase();
              deviceInfo.setPrivate_Key( statusInfo.getPSI_Reference_Object_1() );
              deviceInfo.setPublic_Key( statusInfo.getPSI_Reference_Object_2() );
              deviceInfo.setMAC_KEY( statusInfo.getPSI_Reference_Object_3() );
              deviceInfo.setMac_Label( statusInfo.getPSI_Reference_Object_5() );

              POS_PSI_DeviceDBHome.getInstance().update( (YFCDBContext) env, deviceInfo );
          }
         
      }
      logger.endTimer( "KohlsPoCSAFAgent.syncPOSStatusAndPOSDevice" );
   }
   /**
    * @param env
    * @param response
    * @param sSafNum
    * Retrieve SAF record form custom table and add to response document.
    * @return response document
    * @throws Exception
    */
   private Document makeSAFRecord(YFSEnvironment env, String sSafNum ,String deviceID, String sellerOrg, String tranNo) throws Exception{
      logger.beginTimer( "KohlsPoCSAFAgent.makeSAFRecord" );
      Document safResponse = null;
      Document docGetSAFRecordInput = XMLUtil.getDocument("<SafRespRecord SafNum='"+sSafNum + "' StoreId='"+sellerOrg+"' DeviceId='" + deviceID +"' Invoice='"+tranNo+"'/>");
      
      Document safRecordsDoc = KohlsCommonUtil.invokeService( env, KohlsPOCConstant.API_GET_SAF_RECORDS_FOR_CORP,  docGetSAFRecordInput);
      NodeList safRecordsList = safRecordsDoc.getElementsByTagName( KohlsPOCConstant.E_SAF_REC );
      if ( safRecordsList.getLength() > 0 )
      {
		   Element eleSafRecord = (Element)safRecordsList.item(0);
		   String safRecord = eleSafRecord.getAttribute(KohlsPOCConstant.ATTR_SAF_RECORD);
		   if(!YFCCommon.isVoid(safRecord)) {
			 String compressSAFResponse = YFSSystem.getProperty("compress.saf.response");
			 if(!YFCCommon.isVoid(compressSAFResponse) && "N".equalsIgnoreCase(compressSAFResponse))
			 {				
				 safResponse = XMLUtil.getDocument(safRecord);
			 }
			 else
			 {
				 String unCompressedSAFRecord = KohlsReprocessRequestUtil.decompressXML(safRecord);
				 safResponse = XMLUtil.getDocument(unCompressedSAFRecord);
			 }
		   }
	  }
      logger.endTimer( "KohlsPoCSAFAgent.makeSAFRecord" );
	   return safResponse;
   }
}
