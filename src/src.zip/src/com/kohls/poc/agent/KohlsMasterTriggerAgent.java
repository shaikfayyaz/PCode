package com.kohls.poc.agent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class KohlsMasterTriggerAgent extends YCPBaseAgent {
	private static YFCLogCategory logger;

	@SuppressWarnings("rawtypes")
	static Map<String, List> triggerDuringDayMap = new HashMap<String, List>();
	static Date refreshDate = Calendar.getInstance().getTime();
	static {
		logger = YFCLogCategory.instance(KohlsMasterTriggerAgent.class.getName());

	}

	@SuppressWarnings("unchecked")
	public List<Document> getJobs(YFSEnvironment env, Document criteria, Document lastMessageCreated) throws Exception {
		logger.beginTimer("KohlsMasterTriggerAgent.getJobs");

		boolean skipDuringRestart = false;
		Element criteriaElement = criteria.getDocumentElement();
		String groupName = criteriaElement.getAttribute(KohlsPOCConstant.RULE_GROUP_NAME);
		String triggerType = criteriaElement.getAttribute(KohlsPOCConstant.TRIGGER_TYPE);
		Document getRuleListInputDoc = XMLUtil.createDocument(KohlsPOCConstant.E_RULE);
		Element getRuleListDocEle = getRuleListInputDoc.getDocumentElement();
		getRuleListDocEle.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, KohlsPOCConstant.A_KOHLS_RETAIL);
		Element ruleMetadataEle = XMLUtil.createChild(getRuleListDocEle, KohlsPOCConstant.RULE_META_DATA);
		ruleMetadataEle.setAttribute(KohlsPOCConstant.GROUP_NAME, groupName);
		getRuleListDocEle.appendChild(ruleMetadataEle);
		
		// Retrieving System time
		Date date = Calendar.getInstance().getTime();
		SimpleDateFormat simpleDateFormatArrivals = new SimpleDateFormat(KohlsPOCConstant.FORMAT_HH_MM);
		long currentTimeMilliSec = simpleDateFormatArrivals.parse(simpleDateFormatArrivals.format(date)).getTime();
		logger.info("***START*** MASTER AGENT TRIGGER @ " + simpleDateFormatArrivals.format(date) + " ***START***");
		// Retrieve Agent Rule List
		Document getRuleListOutputDoc = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(
						"<RuleList> <Rule CallingOrganizationCode='KOHLS-RETAIL' RuleID='' RuleValue=''/> </RuleList>"),
						KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, getRuleListInputDoc);
		if (triggerDuringDayMap.isEmpty()) {
			List<Element> listRestartType = KohlsXMLUtil.getElementListByXpath(getRuleListOutputDoc, KohlsPOCConstant.RESTART_TRGR_TYPE_XPATH);
			Element ruleEle = (Element)listRestartType.get(0);
			String restartType = ruleEle.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
			if(KohlsPOCConstant.YES.equalsIgnoreCase(restartType))
			{
				logger.info("**Agent just starting up. Skip during startup is set to true**");
				skipDuringRestart = true;
			}			
		}		
		if (!YFCObject.isVoid(getRuleListOutputDoc)) {
			Document triggerAgentInputDoc = XMLUtil.getDocument("<TriggerAgent CriteriaId='' />");
			Element getRuleListOutputDocEle = getRuleListOutputDoc.getDocumentElement();
			NodeList agentRuleList = getRuleListOutputDocEle.getElementsByTagName(KohlsPOCConstant.E_RULE);

			SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.V_DATE_FORMAT);
			SimpleDateFormat sdf1 = new SimpleDateFormat(KohlsPOCConstant.DAY_OF_WEEK_FORMAT, Locale.US);
			
			if (!sdf.format(refreshDate).equals(sdf.format(date))) {
				triggerDuringDayMap.clear();
				refreshDate = Calendar.getInstance().getTime();
				logger.info("Clearing previous day trigger memory HashMap on " + Calendar.getInstance().getTime());
			}
			List<String> currentTriggeredList = new ArrayList<String>();
			List<String> skippedTriggerList =  new ArrayList<String>();
			for (int i = 0; i < agentRuleList.getLength(); i++) {
				Element agentRuleEle = (Element) agentRuleList.item(i);
				String criteriaID = agentRuleEle.getAttribute(KohlsPOCConstant.A_RULE_ID);
				if(KohlsPOCConstant.SKIP_TRIGGER_DURING_RESTART.equalsIgnoreCase(criteriaID))
				{
					continue;
				}
				String ruleValue = agentRuleEle.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
				String currentTriggerType = null;
				List<String> ruleValueList = new ArrayList<String>();
				if(KohlsPOCConstant.DO_NOT_TRIGGER.equalsIgnoreCase(ruleValue)) {
					ruleValueList.add(ruleValue);
				}
				else if(KohlsPOCConstant.TRIGGER_TYPE_FORCEALL.equalsIgnoreCase(triggerType))
				{
					ruleValueList.add(KohlsPOCConstant.TRIGGER_TYPE_FORCEALL);
				}
				else if (ruleValue.startsWith(KohlsPOCConstant.STARTS_WITH_D_DASH)) {
					String configuredTimeList = ruleValue.substring(2, ruleValue.length());
					ruleValueList = Arrays.asList(configuredTimeList.split(KohlsPOCConstant.COMMA));
					currentTriggerType = KohlsPOCConstant.DAILY;
				} else if (ruleValue.startsWith(KohlsPOCConstant.STARTS_WITH_W_DASH)) {
					currentTriggerType =  KohlsPOCConstant.WEEKLY;
					String configuredWeekDaysList = ruleValue.substring(2, ruleValue.length());
					List<String> configureDaysList = Arrays.asList(configuredWeekDaysList.split(KohlsPOCConstant.DELIMITED_TILDA));
					for (int k = 0; k < configureDaysList.size(); k++) {
						String configuredDays = (String) configureDaysList.get(k);
						List<String> configuredDayList = Arrays.asList(configuredDays.split(KohlsPOCConstant.DELIMITED_PIPE));
						String configuredDay = (String) configuredDayList.get(0);
						String configuredTimeList = (String) configuredDayList.get(1);
						if (configuredDay.equalsIgnoreCase(sdf1.format(date))) {
							ruleValueList = Arrays.asList(configuredTimeList.split(KohlsPOCConstant.COMMA));
							break;
						} else {
							continue;
						}
					}
					if (ruleValueList.isEmpty()) {
						logger.info(criteriaID + " --> Not configured to run for Today. Configured runs are --> "
								+ configureDaysList);
						continue;
					}
				}
				List<String> triggeredTimeList = null;
				String triggerTime = null;
				try {
					// Iterating through Rule Values list and checking against triggerDuringDayMap
					// to validate if the agent is previously triggered
					boolean addRemainingTriggerTimesToMap = false;
					// Agent was previously triggered on the same day

					for (int k = 0; k < ruleValueList.size(); k++) {
						triggerTime = ruleValueList.get(k);
						if (triggerDuringDayMap.containsKey(criteriaID)) {
							// Agent was previously triggered on the same day
							triggeredTimeList = triggerDuringDayMap.get(criteriaID);
						} else {
							triggeredTimeList = new ArrayList<String>();
						}
						if (KohlsPOCConstant.EMPTY.equalsIgnoreCase(triggerTime)
								|| KohlsPOCConstant.DO_NOT_TRIGGER.equalsIgnoreCase(triggerTime)) {
							if (!triggeredTimeList.contains(triggerTime)) {
								triggeredTimeList.add(triggerTime);
							}
							continue;
						}
						long triggerTimeMilliSec = 0;
						if (KohlsPOCConstant.TRIGGER_TYPE_FORCEALL.equalsIgnoreCase(triggerType)
								&& !currentTriggeredList.contains(criteriaID)) {
							triggerAgentInputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.CRITERIA_ID,
									criteriaID);
							KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_TRIGGER_AGENT, triggerAgentInputDoc);
							currentTriggeredList.add(criteriaID);
						}						
						else {
						 try {
								triggerTimeMilliSec = simpleDateFormatArrivals.parse(triggerTime).getTime();

							} catch (ParseException e) {

								logger.error("ERROR: something wrong with time configured for "+criteriaID+ ". Error is ---> "+e.getMessage());
								continue;
							}
							long timeframeMilliSec = currentTimeMilliSec - triggerTimeMilliSec;
							if (addRemainingTriggerTimesToMap && timeframeMilliSec >= 0) {
								triggeredTimeList.add(triggerTime);
								triggerDuringDayMap.put(criteriaID, triggeredTimeList);
							} else {
								if (timeframeMilliSec >= 0) {
									// Triggering agent if trigger time is in the <= current time
									if (!triggeredTimeList.contains(triggerTime)) {
										if(!skipDuringRestart)
										{
											logger.info(criteriaID + " triggered for " + triggerTime + " @ "
													+ simpleDateFormatArrivals.format(date) + " agent run. configured interval --> "+currentTriggerType);
											triggerAgentInputDoc.getDocumentElement()
													.setAttribute(KohlsPOCConstant.CRITERIA_ID, criteriaID);
											KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_TRIGGER_AGENT,
													triggerAgentInputDoc);
											if (!currentTriggeredList.contains(criteriaID)) {
												currentTriggeredList.add(criteriaID);
											}
											triggeredTimeList.add(triggerTime);
											triggerDuringDayMap.put(criteriaID, triggeredTimeList);
											addRemainingTriggerTimesToMap = true;
										}
										else
										{
											if (!skippedTriggerList.contains(criteriaID)) {
												skippedTriggerList.add(criteriaID);
											}
											triggerDuringDayMap.put(KohlsPOCConstant.SKIPPED, null);
										}										
									}
								}
							}
						}

					}
								
				} catch (Exception e) {
					logger.error("ERROR: something wrong with configuration for criteriaID --> " + criteriaID
							+ "\nThe Exception is \n --> ", e);	
				}
				logger.info(criteriaID + " --> Configured Runs are " + ruleValueList + ". Previous runs are "
						+ triggeredTimeList);
				
			}
			if (!YFCCommon.isVoid(triggerType)) {
				logger.info("Trigger Type passed in the input --> " + triggerType);
			}
			logger.info("Criteria(s) triggered in this run --> " + currentTriggeredList);
			logger.info("Criteria(s) skipped in this run --> " + skippedTriggerList);
		}
		logger.info("***END*** MASTER AGENT TRIGGER @ " + simpleDateFormatArrivals.format(date) + " ***END***");
		logger.endTimer("KohlsMasterTriggerAgent.getJobs");
		return null;
	}

	public void executeJob(YFSEnvironment env, Document inDoc) throws Exception {

		logger.debug("KohlsMasterTriggerAgent: Inside execute jobs");
	}

}
