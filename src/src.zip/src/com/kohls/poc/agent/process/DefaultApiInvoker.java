package com.kohls.poc.agent.process;

import com.kohls.common.util.KOHLSBaseApi;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;

public class DefaultApiInvoker implements ApiInvoker {

    @Override
    public Document invokeApi(YFSEnvironment environment, String template, String apiGetItemList, Document itemDoc) throws Exception {
        return KOHLSBaseApi.invokeAPI(environment, template, apiGetItemList, itemDoc);
    }

    @Override
    public void invokeApi(YFSEnvironment environment, String apiGetItemList, Document itemDoc) throws Exception {
        KOHLSBaseApi.invokeAPI(environment, apiGetItemList, itemDoc);
    }
}
