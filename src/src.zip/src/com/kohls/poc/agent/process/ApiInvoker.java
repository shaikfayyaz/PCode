package com.kohls.poc.agent.process;

import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;

public interface ApiInvoker {
    Document invokeApi(YFSEnvironment environment, String template, String apiGetItemList, Document itemDoc) throws Exception;

    void invokeApi(YFSEnvironment environment, String apiGetItemList, Document itemDoc) throws Exception;
}
