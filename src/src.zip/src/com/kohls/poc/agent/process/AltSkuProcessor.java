package com.kohls.poc.agent.process;

import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import weblogic.osgi.internal.Logger;

public class AltSkuProcessor {
    private static final YFCLogCategory logger = YFCLogCategory.instance(AltSkuProcessor.class);


    private final YFSEnvironment environment;
    private ApiInvoker invoker = new DefaultApiInvoker();

    /**
     * Create a new Instance.
     */
    public AltSkuProcessor(YFSEnvironment environment) {
        this.environment = environment;

    }


    /**
     * Use getItemList and manageItem API calls to insert new data into YFS_ITEM extension column
     */
    public void process(Document sourceDocument) {

        Element documentElement = sourceDocument.getDocumentElement();

        NodeList altSkuMap = documentElement.getElementsByTagName("AltSkuMap");
        for (int i = 0; i < altSkuMap.getLength(); i++) {
            Element item = (Element) altSkuMap.item(i);
            String skuNbr = item.getAttribute(KohlsPOCConstant.A_SKUNBR);
            String vendorUpcNbr = item.getAttribute(KohlsPOCConstant.A_VENDOR_UPC_NBR);

            //Check for the SKU and UPC lengths
            skuNbr = validateSkuNbr(skuNbr);
            vendorUpcNbr = validateUpcNbr(vendorUpcNbr);

            this.insertAlternateSku(skuNbr, vendorUpcNbr);
        }
    }

    /**
     * Create new template for getItemList response to get the ItemKey, ItemID and ExtnAlternateSkus
     * Call manageItem API to update ExtnAlternateSkus with SKU/SKUs for the ItemKey
     *
     * @param skuNbr
     * @param vendorUpcNbr
     */
    private void insertAlternateSku(String skuNbr, String vendorUpcNbr) {

        try {

            // Call getItemList API with ItemAlias for the UPC and check if the Alterante SKUs already exists
            Document itemDoc = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ITEM);
            Element itemElement = itemDoc.getDocumentElement();
            Element aliasList = itemDoc.createElement(KohlsPOCConstant.A_ITEM_ALIAS_LIST);
            itemElement.appendChild(aliasList);

            Element alias = itemDoc.createElement(KohlsPOCConstant.A_ITEM_ALIAS);
            aliasList.appendChild(alias);
            alias.setAttribute(KohlsPOCConstant.A_ALIAS_VALUE, vendorUpcNbr);

            // Call API with template
            String template = KohlsPOCConstant.GET_ITEM_LIST_FOR_ALTERNATE_SKUS;
            Document docGetItemListOut =
                    this.invokeApi(environment, template, KohlsPOCConstant.API_GET_ITEM_LIST, itemDoc);

            logger.debug("AltSku Get Item List Response: " + XMLUtil.getXMLString(docGetItemListOut));

            if (!YFCCommon.isVoid(docGetItemListOut)) {

                Element docElement = docGetItemListOut.getDocumentElement();
                Element item = KohlsXMLUtil.getChildElement(docElement, "Item");

                if (YFCCommon.isVoid(item)) {
                    logger.warn("AltSku Get Item List returned empty list for UPC - " + vendorUpcNbr +" skuNbr - " +skuNbr);
                } else {
                    String existingSkus = "";

                    // add/append the SKU to the existing SKUs
                    Element extn = KohlsXMLUtil.getChildElement(item, "Extn");
                    if (!YFCCommon.isVoid(extn)) {
                        existingSkus = extn.getAttribute("ExtnAlternateSkus");
                    }

                    String newSkus = "";

                    // augment existing  skus.
                    if (XMLUtil.isVoid(existingSkus)) {
                        newSkus = skuNbr;
                    } else if (!existingSkus.contains(skuNbr)) {
                        // has existing skus, doesn't match skuNbr
                        newSkus = existingSkus + "," + skuNbr;
                    } else {
                        logger.debug("AltSku Existing Sku matches new sku : Do nothing.");
                        return;
                    }
                    // else existing skus matches sku number -- do nothing


                    logger.debug("Updating item with alternate sku " + newSkus);

                    String itemKey = item.getAttribute("ItemKey");

                    if (!XMLUtil.isVoid(itemKey)) {
                        this.manageItem(newSkus, itemKey);
                    }
                }
            }

        } catch (Exception e) {
            logger.error("AltSku Exception while processing UPC - " + vendorUpcNbr +" skuNbr - " +skuNbr, e);
        }
    }


    private Document invokeApi(YFSEnvironment environment, String template, String apiGetItemList, Document itemDoc) throws Exception {
        return invoker.invokeApi(environment, template, apiGetItemList, itemDoc);
        //return KOHLSBaseApi.invokeAPI(environment, template, apiGetItemList, itemDoc);
    }

    private void invokeApi(YFSEnvironment environment, String manageItem, Document docIndocmanageItem) throws Exception {
        invoker.invokeApi(environment, manageItem, docIndocmanageItem);
    }


    /**
     * Call the manageItem API to update/insert the alternate SKUS into the extension column
     *
     * @param alternateSkus
     * @param itemKey
     * @throws Exception
     */
    private void manageItem(String alternateSkus, String itemKey) throws Exception {

        Document docIndocmanageItem = XMLUtil.newDocument();
        Element eleItemlist = docIndocmanageItem.createElement("ItemList");
        docIndocmanageItem.appendChild(eleItemlist);

        Element eleItem = docIndocmanageItem.createElement("Item");
        eleItemlist.appendChild(eleItem);

        eleItem.setAttribute("Action", "Manage");
        eleItem.setAttribute("ItemKey", itemKey);

        Element eleExt = docIndocmanageItem.createElement("Extn");
        eleItem.appendChild(eleExt);
        eleExt.setAttribute("ExtnAlternateSkus", alternateSkus);

        if (Logger.isDebugEnabled()) {
            logger.debug("AltSku manageItem API input: " + XMLUtil.getXMLString(docIndocmanageItem));
        }

        this.invokeApi(this.environment, "manageItem", docIndocmanageItem);

    }


//    private Document invokeAPI(YFSEnvironment yfsEnvironment, String template, String apiName, Document docIn) {
//
//        KOHLSBaseApi.invokeAPI(yfsEnvironment, template, apiName, docIn);
//        KOHLSBaseApi.invokeAPI(yfsEnvironment,apiName, docIn);
//    }

    /**
     * Ensure the upd number is 12 digits max
     *
     * @param vendorUpcNbr
     * @return
     */
    private String validateUpcNbr(String vendorUpcNbr) {
        if (vendorUpcNbr.length() > 12) {
            return vendorUpcNbr.substring(vendorUpcNbr.length() - 12);
        }
        return vendorUpcNbr;
    }

    /**
     * Ensure that the SKU is 8-digits zero prepended
     *
     * @param skuNbr
     * @return
     */
    private String validateSkuNbr(String skuNbr) {
        if (skuNbr.length() < 8) {
            return StringUtils.leftPad(skuNbr, 8, "0");
        }
        return skuNbr;
    }

}
