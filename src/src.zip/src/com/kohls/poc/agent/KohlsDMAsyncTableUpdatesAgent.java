package com.kohls.poc.agent;


import java.util.ArrayList;
import java.util.List;



import org.apache.commons.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.google.gson.Gson;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsCallDMAPIWrapper;
import com.kohls.poc.rest.KohlsDMReasonCodeOutJson;
import com.kohls.poc.util.KohlsPoCDMUtil;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsDMAsyncTableUpdatesAgent extends YCPBaseAgent {
	
	
	List<KohlsDMReasonCodeOutJson.DamageCode> listDmgCode = new ArrayList<KohlsDMReasonCodeOutJson.DamageCode>();
	List<KohlsDMReasonCodeOutJson.DamagedReasonCode> listDmgReasonCode = new ArrayList<KohlsDMReasonCodeOutJson.DamagedReasonCode>();
	KohlsDMReasonCodeOutJson responseDMReasonCode = new KohlsDMReasonCodeOutJson();
	KohlsPoCDMUtil dmUtil = new KohlsPoCDMUtil();
	Gson gson1 = new Gson();

	static JSONObject jsonResponse = null;

	Document docDamagedReasonCodes = null;
	Document docGetDamagedReasonCodes = null;

	Element eleDamagedReasonCodes=null;
	Element eleGetDamagedReasonCodes=null;
	
	Element eleDamagedReasonCode=null;
	Element eleGetDamagedReasonCode=null;

	Document docDelDamagedReasonCodes = null;
	Element eleDelDamagedReasonCodes=null;
	
	Element eleDamageCodeDescList=null;
	Element eleDamageCodeDesc=null;
	

	/**
	 * This custom Agent is used to fetch In Complete DM ReasonCodes
	 * 
	 */

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsDMAsyncTableUpdatesAgent.class);
	
	private static KohlsCallDMAPIWrapper dmAPIWrapper = new KohlsCallDMAPIWrapper();
	

	/**
	 * This method will fetch all the records to be processed by executeJobs()
	 * @throws Exception 
	 */
	public List<Document> getJobs(YFSEnvironment env, Document inDoc,Document lastMessageCreated) throws YFSException {
		
		if (null != lastMessageCreated) {
			return null;
		}
		
	 try {
		List<Document> returnList = new ArrayList<Document>();
		logger.beginTimer("DMRefreshDmgReasonCodesAgent.getJobs");
		logger.debug("DMRefreshDmgReasonCodesAgent.getJobs --- Input to getJobs"
				+ XMLUtil.getXMLString(inDoc));
		
		Element messageXmlEle;
		
			messageXmlEle = KohlsXPathUtil.getElementByXpath(inDoc, "/Message/AgentDetails/MessageXml");
		
        if(null == messageXmlEle){
          messageXmlEle = inDoc.getDocumentElement();
        }
        
        String agentCriteria = XMLUtil.getAttribute(messageXmlEle, KohlsPOCConstant.ACTION_GROUP_FLOWNAME);
      

		
			if(!YFCCommon.isVoid(agentCriteria)&& KohlsPOCConstant.A_DMG_RES_CODE.equalsIgnoreCase(agentCriteria)){

						//Prepare inxml to DMAPIWrapper to get reasoncode specific response		
						Document docReqForReasonCode = XMLUtil.createDocument(KohlsPOCConstant.DOC_DM_REASON_CODE_REQ);
						docReqForReasonCode.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DM_SOURCE, KohlsPOCConstant.DM_REASON_CODE);
						
						Document returndoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_CALLTO_DMWRAPPER, docReqForReasonCode);
						if(!YFCCommon.isVoid(returndoc))
						{
							NodeList ndReturnList = returndoc.getElementsByTagName(KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES);
							for (int i=0; i<ndReturnList.getLength();i++){
								((List<Document>) returnList).add(KohlsXMLUtil.getDocumentForElement((Element) ndReturnList.item(i)));
							logger.debug("Damage Reason Code List is"+KohlsXMLUtil.getXMLString(returnList.get(i)));
							
							}
						}
						
			}
			else if(!YFCCommon.isVoid(agentCriteria) && KohlsPOCConstant.A_UI_SLIP_TEXT.equalsIgnoreCase(agentCriteria)) {
				Document docReqForSlipText = XMLUtil.createDocument(KohlsPOCConstant.ELEM_DM_SLIP_TEXT_REQ);
				docReqForSlipText.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DM_SOURCE, KohlsPOCConstant.DM_GET_UI_SLIP_TEXT);
				
				Document returndoc = KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_CALLTO_DMWRAPPER, docReqForSlipText);
				
				NodeList ndReturnList = returndoc.getElementsByTagName(KohlsPOCConstant.ELEM_DM_SLIP_TEXT);
				for (int i=0; i<ndReturnList.getLength();i++){
					((List<Document>) returnList).add(KohlsXMLUtil.getDocumentForElement((Element) ndReturnList.item(i)));
					logger.debug("UI Slip Text List is"+KohlsXMLUtil.getXMLString(returnList.get(i)));
				}
				
			}
			//logger.debug("returnList:"+returnList.toString());
			logger.endTimer("DMRefreshDmgReasonCodesAgent.getJobs");
			return returnList;
		}
		catch (Exception e) 
		{
			
			//logger.debug("DMRefreshDmgReasonCodesAgent.getJobs ----  Exception in getJobs");
			//e.printStackTrace();
			throw new YFCException(e.toString());
		}
		
		
		
	}

	
	/**
	 * This method processes each record from getJobs()
	 * @throws Exception
	 */
	public void executeJob(YFSEnvironment env, Document inDoc) throws YFSException {
		
	try
	{
		
		if(!YFCCommon.isVoid(inDoc))
		{
			NodeList ndReturnList = inDoc.getElementsByTagName(KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES);
			if(ndReturnList.getLength()>0){
				
				
				dmUtil.modifyTable(env, inDoc, KohlsPOCConstant.DM_REASON_CODE);
		        
			}else{
				
		        //Invoke To Insert KohlsCreateDMSlipText
				
				dmUtil.modifyTable(env, inDoc, KohlsPOCConstant.DM_GET_UI_SLIP_TEXT);
			}
			
		}
			
	} catch (Exception e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		throw new YFCException(e.toString());
	}		
        
	}

}
