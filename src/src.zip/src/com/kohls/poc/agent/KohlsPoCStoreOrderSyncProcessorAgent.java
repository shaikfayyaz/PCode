package com.kohls.poc.agent;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.client.ClientPropertiesNotFoundException;
import com.yantra.interop.client.YIFClientProperties;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.core.YCPEntityApi;
import com.yantra.ycp.core.YCPTemplateManager;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

public class KohlsPoCStoreOrderSyncProcessorAgent extends YCPBaseAgent {	
	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsPoCStoreOrderSyncProcessorAgent.class.getName());
	private static YIFApi oApi = null;	
	private static boolean errorFlag = true;
	private final String ORDER_SYNC = "OrderSync";
	private static String API_MANAGE_OFF_TRANS_Q = "manageOfflineTransactionQ";
	private static String EXTN_RETRY_COUNT = "ExtnRetryCount";
	private static String envString = "<env userId='gravity' progId='gravity'/>";
	private static String uniqueID = "";	
	
	// Get the agent criteria
	@Override
	public List<Document> getJobs(YFSEnvironment env, Document inXML, Document docLastMessage) throws Exception {
		log.info("GetJobs is inProgress");
		if (log.isDebugEnabled()) {
			log.debug("GetJobs input is " + SCXmlUtil.getString(inXML));
		}
		String txnSyncRemoteStore = YFSSystem.getProperty(KohlsPOCConstant.TXN_SYNC_ORDER_CREATION_ENABLED);
		String compressedFlag = YFSSystem.getProperty(KohlsPOCConstant.TXN_SYNC_COMPRESSION_ENABLED);
		
		Element eleRoot = inXML.getDocumentElement();
		String bufferedRecords = eleRoot.getAttribute(KohlsPOCConstant.NUM_RECORD_TO_BUFFER);
		String inputTrxStatus = eleRoot.getAttribute(KohlsPOCConstant.TRX_STATUS_IN);
		ArrayList<Document> arrOffTransQs = new ArrayList<Document>();
		Document docExportJobs = YFCDocument.createDocument(KohlsPOCConstant.TRX_STATUS_IN).getDocument();
		Element eleServiceInput = docExportJobs.getDocumentElement();
		eleServiceInput.setAttribute(KohlsPOCConstant.A_DATA_TYPE, ORDER_SYNC);
		
		if (log.isDebugEnabled()) {
			log.debug("docLastMessage is " + SCXmlUtil.getString(docLastMessage));
		}
		Document outDocGetOffTransQListForPOS = null;		
		YFSContext ctx = (YFSContext) env;		
		
		// Create input Document to get list of record through query in order to find first batch of records
		try {
			String StoreID = YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP);
			outDocGetOffTransQListForPOS = getOfflineTransactionQList(env, bufferedRecords, inputTrxStatus);
			if (log.isDebugEnabled()) {
				log.debug("outDocGetOffTransQListForPOS output " + SCXmlUtil.getString(outDocGetOffTransQListForPOS));
			}
			NodeList nlListOffTransQs = outDocGetOffTransQListForPOS.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
			int offlineTranLength = nlListOffTransQs.getLength();
			log.info("No of records to process is " + offlineTranLength);
			if (offlineTranLength > 0) {
				oApi = getDefaultAPI((YFSContext) env, KohlsPOCConstant.V_MOTHERSHIP);
				if (log.isDebugEnabled()) {
					log.debug("Checking the remote call to Corp");
				}
				checkRemoteConnection(env);
				
				// Adding Documents to arrayList for return to executeJob method
				for (int keyCount = 0; keyCount < offlineTranLength; keyCount++) {
					if (log.isDebugEnabled()) {
						log.debug("keyCount is " + keyCount);
					}
					uniqueID = "";
					Document reportOrderDetails = null;
					Element eleOfflineTranQ = (Element) nlListOffTransQs.item(keyCount);
					Element elemExtn = XMLUtil.getChildElement(eleOfflineTranQ, KohlsPOCConstant.E_EXTN);
					int retryCountFromDB = Integer.parseInt(elemExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETRY_COUNT));
					XMLUtil.removeChild(eleOfflineTranQ, elemExtn);

					// it will be empty as initially
					String strOfflineTrxQKey = eleOfflineTranQ.getAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
					if (log.isDebugEnabled()) {
						log.debug("\nEach eleOfflineTranQ before removing key modifyts and local to N \n"
								+ SCXmlUtil.getString(eleOfflineTranQ));
					}
					eleOfflineTranQ.setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.NO);
					eleOfflineTranQ.removeAttribute(KohlsPOCConstant.ATTR_MODIFYTS);
					eleOfflineTranQ.removeAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
					if (log.isDebugEnabled()) {
						log.debug("\nEach eleOfflineTranQ after removal \n" + SCXmlUtil.getString(eleOfflineTranQ));
					}
					// CORP - Converting the element to Document to pass as input
					Document OutDocOfflineTranQ = null;
					Document outDocApi = null;
					Document inDocManageOffTransQPOS = KohlsXMLUtil.getDocumentForElement(eleOfflineTranQ);
					Element inDocManageOffTransQPOSElm = inDocManageOffTransQPOS.getDocumentElement();
					if (log.isDebugEnabled()) {
						log.debug("Each inDocManageOffTransQPOS \n" + SCXmlUtil.getString(inDocManageOffTransQPOS));
					}
					Element eleAdditionalInfo = SCXmlUtil.createChild(inDocManageOffTransQPOSElm, KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
					eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
					if (log.isDebugEnabled()) {
						log.debug("Record update to Corp \n" + SCXmlUtil.getString(inDocManageOffTransQPOS));
					}

					// Order creation START
					String operationInputXML = null;
					String remoteOfflineTrxKey = null;
					boolean bTxnSyncRemoteStoreFailed = false;
					boolean multiApiFlag = false;
					String OrderNoForSyncUpdate = null;
					try {

						if (KohlsPOCConstant.YES.equals(txnSyncRemoteStore)
								&& eleOfflineTranQ.getAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML) != null) {
							String operationID = eleOfflineTranQ.getAttribute(KohlsPOCConstant.A_OPERATION_ID);
							uniqueID = eleOfflineTranQ.getAttribute(KohlsPOCConstant.A_UNIQUE_ID);
							operationInputXML = eleOfflineTranQ.getAttribute(KohlsPOCConstant.A_OPERATION_INPUT_XML);
							if (log.isDebugEnabled()) {
								log.debug("Each operationInputXMLStr \n" + operationInputXML);
							}
							Document blobDocument = SCXmlUtil.createFromString(operationInputXML);
							if (blobDocument == null) {
								throw new Exception("Unable to parse operation input xml");
							}
							Element blobElement = blobDocument.getDocumentElement();
							
							boolean firstChild = true;
							if (operationID.equalsIgnoreCase(KohlsPOCConstant.API_MULTIAPI)) {
								ArrayList<Element> eleAPIs = SCXmlUtil.getChildren(blobElement, KohlsPOCConstant.E_API);
								for (Element eleAPI : eleAPIs) {
									Element eleInput = SCXmlUtil.getChildElement(eleAPI, KohlsPOCConstant.E_INPUT);
									Element eleAPIInput = SCXmlUtil.getFirstChildElement(eleInput);
									String eleAPIName = SCXmlUtil.getAttribute(eleAPI, KohlsPOCConstant.A_NAME);
									if (eleAPIName.equalsIgnoreCase(KohlsPOCConstant.API_LOAD_OFFLINE_ORDER_FOR_POS)) {
										// Removing OrderAudits
										NodeList orderList = eleAPIInput.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
										if (orderList.getLength() > 0) {
											Element orderListElm = (Element) orderList.item(0);
											Element orderAuditsElm = XMLUtil.getChildElement(orderListElm, KohlsPOCConstant.E_ORDER_AUDITS);
											if (!YFCCommon.isVoid(orderAuditsElm)) {
												XMLUtil.removeChild(orderListElm, orderAuditsElm);
											}
											if (firstChild) {
												reportOrderDetails = orderSnyncMonitor(orderListElm, operationID, uniqueID);
												firstChild = false;
											}
										}
										
									}
									if (KohlsPOCConstant.NO.equals(compressedFlag)) {
										eleAdditionalInfo = SCXmlUtil.createChild(eleAPIInput, KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
										eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
									}
								}
								multiApiFlag = true;
							} else {
								if (operationID.equalsIgnoreCase(KohlsPOCConstant.API_LOAD_OFFLINE_ORDER_FOR_POS)) {
									// Removing OrderAudits
									NodeList orderList = blobDocument.getDocumentElement().getElementsByTagName(KohlsPOCConstant.ELEM_ORDER);
									if (orderList.getLength() > 0) {
										Element orderListElm = (Element) orderList.item(0);
										OrderNoForSyncUpdate = orderListElm
												.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);										
										reportOrderDetails = orderSnyncMonitor(orderListElm, operationID, uniqueID);
										Element orderAuditsElm = XMLUtil.getChildElement(orderListElm, KohlsPOCConstant.E_ORDER_AUDITS);
										if (!YFCCommon.isVoid(orderAuditsElm)) {
											XMLUtil.removeChild(orderListElm, orderAuditsElm);
										}
									}
								}

								if (KohlsPOCConstant.NO.equals(compressedFlag)) {
									eleAdditionalInfo = SCXmlUtil.createChild(blobElement, KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
									eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
								}
							}

							if (log.isDebugEnabled()) {
								log.debug("Remote call with blob input \n" + SCXmlUtil.getString(blobDocument));
							}

							// Added Logic for XML input compression
							if (KohlsPOCConstant.YES.equals(compressedFlag)) {
								String strcompressedXML = KohlsReprocessRequestUtil.compressXML(SCXmlUtil.getString(blobDocument));
								if (log.isDebugEnabled()) {
									log.debug("Compressed XML " + strcompressedXML);
								}
								Document compressedBlobDocument = SCXmlUtil.createDocument(KohlsPOCConstant.COMPRESSED_INPUT);
								compressedBlobDocument.getDocumentElement().setAttribute(KohlsPOCConstant.COMPRESSED_BLOB, strcompressedXML);
								compressedBlobDocument.getDocumentElement().setAttribute(KohlsPOCConstant.A_API_NAME, operationID);
								//compressedBlobDocument.getDocumentElement().setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);								
								if (operationID.equalsIgnoreCase(KohlsPOCConstant.API_LOAD_OFFLINE_ORDER_FOR_POS)
										|| operationID.equalsIgnoreCase(KohlsPOCConstant.API_MULTIAPI)) {
									if (!YFCCommon.isVoid(reportOrderDetails)) {
									   Node trxSyncDetailsNode = reportOrderDetails.getDocumentElement().getElementsByTagName(KohlsPOCConstant.TRX_SYNC_DETAILS).item(0);
									   Element trxSyncDetailsElm = (Element) compressedBlobDocument.importNode(trxSyncDetailsNode, true);
									   compressedBlobDocument.getDocumentElement().insertBefore(trxSyncDetailsElm, null);
									   log.info("Transaction sync ISS monitoring details : " + SCXmlUtil.getString((Element)trxSyncDetailsNode));
									} else {
										Element elmBlobOrderDetails = compressedBlobDocument.createElement(KohlsPOCConstant.TRX_SYNC_DETAILS);
										compressedBlobDocument.getDocumentElement().appendChild(elmBlobOrderDetails);
										elmBlobOrderDetails.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);
										log.info("Transaction sync ISS monitoring details : " + SCXmlUtil.getString(elmBlobOrderDetails));
									}
								} else {
									Element elmBlobOrderDetails = compressedBlobDocument.createElement(KohlsPOCConstant.TRX_SYNC_DETAILS);
									compressedBlobDocument.getDocumentElement().appendChild(elmBlobOrderDetails);
									elmBlobOrderDetails.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);
								}

								Element eleAdditionalInfo1 = compressedBlobDocument.createElement(KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
								eleAdditionalInfo1.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
								compressedBlobDocument.getDocumentElement().appendChild(eleAdditionalInfo1);
								if (log.isDebugEnabled()) {
									log.debug("Compressed Document " + SCXmlUtil.getString(compressedBlobDocument));
								}
								YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
								outDocApi = KohlsCommonUtil.invokeService(newEnv, KohlsPOCConstant.KOHLS_TXN_SYNC_DECOMPRESSION_SERVICE, compressedBlobDocument);
							} else {
								if (multiApiFlag) {
									if (log.isDebugEnabled()) {
										log.debug("multiApi input \n" + SCXmlUtil.getString(blobDocument));
									}
									YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
									outDocApi = KohlsCommonUtil.invokeAPI(newEnv, KohlsPOCConstant.API_MULTIAPI, blobDocument);
									multiApiFlag = false;
								} else {
									outDocApi = callApi(env, blobDocument, OutDocOfflineTranQ, operationID);
								}
							}

							if (log.isDebugEnabled()) {
								log.debug("Remote call blob call output \n" + SCXmlUtil.getString(outDocApi));
								log.debug("bTxnSyncRemoteStoreFailed flag before set to " + bTxnSyncRemoteStoreFailed);
							}
							NodeList nodeListCommonCode1 = outDocApi.getElementsByTagName(KohlsPOCConstant.E_ERROR);
							if (nodeListCommonCode1.getLength() > 0) {
								Element eleError1 = (Element) nodeListCommonCode1.item(0);
								eleError1.setAttribute(KohlsPOCConstant.INXML_STORE_ID, StoreID);
								eleError1.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);
								bTxnSyncRemoteStoreFailed = true;
								formatErrorMsg(outDocApi);
							}
						}
					} catch (Exception e) {
						// e.printStackTrace();
						Document errDoc = handleException(e);
						formatErrorMsg(errDoc);
						log.error("Blob call output exception \n" + SCXmlUtil.getString(errDoc));
						bTxnSyncRemoteStoreFailed = true;
					}

					if (log.isDebugEnabled()) {
						log.debug("bTxnSyncRemoteStoreFailed flag set to " + bTxnSyncRemoteStoreFailed);
					}
					if (KohlsPOCConstant.NO.equals(txnSyncRemoteStore) || bTxnSyncRemoteStoreFailed) {
						if (log.isDebugEnabled()) {
							log.debug("Remote call input " + SCXmlUtil.getString(inDocManageOffTransQPOS));
						}
						outDocApi = callApi(env, inDocManageOffTransQPOS, OutDocOfflineTranQ, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS);
						remoteOfflineTrxKey = outDocApi.getDocumentElement().getAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY);
						log.info("Corp offline trx key " + remoteOfflineTrxKey);

						if (log.isDebugEnabled()) {
							log.debug("Remote call output " + SCXmlUtil.getString(outDocApi));
						}
					}
					NodeList nodeListCommonCode = outDocApi.getElementsByTagName(KohlsPOCConstant.E_ERROR);
					Document updateTRXRetry = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
					Element elm = updateTRXRetry.getDocumentElement();
					elm.setAttribute(KohlsPOCConstant.ACTION, KohlsPOCConstant.MANAGE);
					elm.setAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY, strOfflineTrxQKey);

					if (nodeListCommonCode.getLength() > 0
							|| (YFCCommon.isVoid(remoteOfflineTrxKey)) && bTxnSyncRemoteStoreFailed) {
						if (nodeListCommonCode.getLength() > 0) {
							log.error("Call manageOfflineTransactionQForPOS API to corp failed for transactionKey "
									+ strOfflineTrxQKey + ",\n " + SCXmlUtil.getString(outDocApi));
							Element eleRemove = ((Element) nodeListCommonCode.item(0));
							eleRemove.setAttribute(KohlsPOCConstant.INXML_STORE_ID, StoreID);
						} else {
							log.warn("Received remote trx key is empty, Please check the logs in Corp server ");
						}

						log.info("Retry count from DB " + retryCountFromDB);
						formatErrorMsg(outDocApi);
						retryCountFromDB = retryCountFromDB + 1;
						log.info("Retry count updating to " + retryCountFromDB);
						Element extnElm = XMLUtil.createChild(elm, KohlsPOCConstant.A_EXTN);
						extnElm.setAttribute(EXTN_RETRY_COUNT, Integer.toString(retryCountFromDB));
						YFCDocument inpDoc = YFCDocument.getDocumentFor(updateTRXRetry);
						YFCElement templateElem = YCPTemplateManager.getInstance().setEntityTemplate(ctx, KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, inpDoc, API_MANAGE_OFF_TRANS_Q);
						if (!(templateElem.hasAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY))) {
							templateElem.setAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY, "");
						}
						YFCDocument yfcDoc1 = YCPEntityApi.getInstance().invoke(ctx, API_MANAGE_OFF_TRANS_Q, inpDoc, templateElem);
						ctx.commit();
						log.info("Update retry count output is " + XMLUtil.serialize(yfcDoc1.getDocument()));
						if (log.isDebugEnabled()) {
							Document tempDoc = SCXmlUtil.createFromString(
									"<OfflineTransactionQ  OfflineTrxQKey='" + strOfflineTrxQKey + "'/>");
							if (log.isDebugEnabled()) {
								log.debug("Retry updated record input \n" + SCXmlUtil.getString(tempDoc));
							}
							Document tempDocOut = KOHLSBaseApi.invokeAPI(env,
									XMLUtil.getDocument(KohlsPOCConstant.OFFLINE_TRXQ_TEMPLATE),
									KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS, tempDoc);
							if (log.isDebugEnabled()) {
								log.debug("Retry updated record output \n " + SCXmlUtil.getString(tempDocOut));
							}
						}
					} else {
						// STORE - Update the Store DB trx status to 2
						if (!YFCCommon.isVoid(remoteOfflineTrxKey) || !bTxnSyncRemoteStoreFailed) {
							log.info("Store offline trx key " + strOfflineTrxQKey + " set to status 2");

							elm.setAttribute(KohlsPOCConstant.A_TRX_STATUS, KohlsPOCConstant.TO_TRX_STATUS);
							YFCDocument inpDoc = YFCDocument.getDocumentFor(updateTRXRetry);
							YFCElement templateElem = YCPTemplateManager.getInstance().setEntityTemplate(ctx,
									KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, inpDoc,
									API_MANAGE_OFF_TRANS_Q);
							if (!(templateElem.hasAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY))) {
								templateElem.setAttribute(KohlsPOCConstant.OFFLINE_TRXQ_KEY, "");
							}
							if (log.isDebugEnabled()) {
								log.debug("Update to TRX status to 2 input is "
										+ XMLUtil.serialize(inpDoc.getDocument()));
							}
							YFCDocument yfcDoc = YCPEntityApi.getInstance().invoke(ctx, API_MANAGE_OFF_TRANS_Q, inpDoc, templateElem);
							ctx.commit();
							if (log.isDebugEnabled()) {
								log.debug("Update to TRX status to 2 output is " + XMLUtil.serialize(yfcDoc.getDocument()));
							}
							
							//Updating Order Sync Status
							if (log.isDebugEnabled()) {
							   log.debug("Processed OrderNo " + OrderNoForSyncUpdate);
							}
							if (!bTxnSyncRemoteStoreFailed && !YFCCommon.isVoid(OrderNoForSyncUpdate)) {
								Document docUpdateSynchedOrderStatusXML = SCXmlUtil
										.createDocument(KohlsPOCConstant.E_UPDATE_SYNCHED_ORDER_STATUS);
								docUpdateSynchedOrderStatusXML.getDocumentElement()
										.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, StoreID);
								Element eleSynchedOrders = docUpdateSynchedOrderStatusXML
										.createElement(KohlsPOCConstant.E_SYNCHED_ORDERS);
								Element eleSynchedOrder = docUpdateSynchedOrderStatusXML
										.createElement(KohlsPOCConstant.E_SYNCHED_ORDER);

								eleSynchedOrder.setAttribute(KohlsPOCConstant.ATTR_ORDER_NO, OrderNoForSyncUpdate);
								eleSynchedOrders.appendChild(eleSynchedOrder);
								docUpdateSynchedOrderStatusXML.getDocumentElement().appendChild(eleSynchedOrders);
								if (log.isDebugEnabled()) {
									log.debug("updateSynchedOrderStatusForPOS API call input "
											+ SCXmlUtil.getString(docUpdateSynchedOrderStatusXML));
								}
								Document updateSyncOutput = KOHLSBaseApi.invokeAPI(env,
										KohlsPOCConstant.API_UPDATE_SYNCHED_ORDER_STATUS,
										docUpdateSynchedOrderStatusXML);
								if (log.isDebugEnabled()) {
									log.debug("updateSynchedOrderStatusForPOS API call output "
											+ SCXmlUtil.getString(updateSyncOutput));
								}
							}
												
						} else {
							log.error("Remote transaction key is empty, Please check the logs in Corp server " + remoteOfflineTrxKey);
						}
					}
				}								
				arrOffTransQs.add(docExportJobs);
			}
			log.info("Getjobs completed");
		} catch (Exception ex) {
			//ex.printStackTrace();
			log.error("Exception occured in transaction sync " + ex.getMessage());
			Document inDocMsg = handleException(ex);
			if (errorFlag) {
				log.info("errorFlag is " + errorFlag);
				formatErrorMsg(inDocMsg);
			}
			errorFlag = true;
		}
		return arrOffTransQs;
	}

	/**
	 * @param ex
	 * @return
	 * @throws Exception
	 */
	private Document handleException(Exception ex) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		//factory.setValidating(false);
		factory.setNamespaceAware(true);		
		try {
		Document inDocErrMsg = factory.newDocumentBuilder().parse(new InputSource(new StringReader(ex.getMessage().toString().trim())));
		NodeList nodeListCommonCode = inDocErrMsg.getElementsByTagName(KohlsPOCConstant.E_ERROR);
		Element eleRemove = ((Element) nodeListCommonCode.item(0));
		eleRemove.setAttribute(KohlsPOCConstant.INXML_STORE_ID, YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP));
		eleRemove.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);
		return inDocErrMsg;
		}
		catch(Exception e) {
			Document errorDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_ERRORS);
			if (errorFlag) {
				log.debug("errorFlag in handleException is " + errorFlag);
				StringWriter sw = new StringWriter();
				e.printStackTrace(new PrintWriter(sw));
				Element eleError = errorDoc.createElement(KohlsPOCConstant.E_ERROR);
				eleError.setAttribute(KohlsPOCConstant.INXML_STORE_ID,
						YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP));
				eleError.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);
				eleError.setAttribute(KohlsPOCConstant.ErrorMessage, e.getMessage());
				Element eleStack = errorDoc.createElement(KohlsPOCConstant.A_STACK);
				eleStack.setTextContent(sw.toString());
				eleError.appendChild(eleStack);
				errorDoc.getDocumentElement().appendChild(eleError);
				if (log.isDebugEnabled()) {
					log.debug("Constructed error doc " + SCXmlUtil.getString(errorDoc));
				}
			}
			errorFlag = true;
			return errorDoc;
		}
	}
	
	/**
	 * Format the error message
	 * @param inDocMsg
	 * @throws IOException
	 */
	private void formatErrorMsg(Document inDocMsg) throws IOException {
		String timeStamp = new SimpleDateFormat(KohlsPOCConstant.EXPORT_TABLES_DATE_FORMAT)
				.format(new java.util.Date());
		String errFile = KohlsPOCConstant.ZIP_ERROR_STORE + KohlsPOCConstant.BACKWARD_SLASH + timeStamp
				+ KohlsPOCConstant.UNDERSCORE + YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP)
				+ KohlsPOCConstant.DOT + KohlsPOCConstant.LOG_EXTENSION;
		FileWriter writer = new FileWriter(errFile);
		writer.write(SCXmlUtil.getString(inDocMsg));
		log.error("Exceptions written to log file " + SCXmlUtil.getString(inDocMsg));
		writer.close();
	}
	
	@Override
	public void executeJob(YFSEnvironment env, Document inExDoc) throws Exception {
		log.info("Executejob is completed");
	}

	/**
	 * Get the complete list of transactions 
	 * @param env
	 * @param NumRecordsToBuffer
	 * @param trxStatus
	 * @return
	 * @throws Exception
	 */
	private Document getOfflineTransactionQList(YFSEnvironment env, String NumRecordsToBuffer, String trxStatus)
			throws Exception {
		log.info("Get offline transactions list started");
				
		Document inDocGetOffTranQList = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
		inDocGetOffTranQList.getDocumentElement().setAttribute(KohlsPOCConstant.A_TRX_STATUS, trxStatus);
		inDocGetOffTranQList.getDocumentElement().setAttribute(KohlsPOCConstant.A_IS_LOCAL, KohlsPOCConstant.YES);
		inDocGetOffTranQList.getDocumentElement().setAttribute(KohlsPOCConstant.NEED_OPERTION_XML,
				KohlsPOCConstant.YES);
		inDocGetOffTranQList.getDocumentElement().setAttribute(KohlsPOCConstant.A_MAXIMUM_RECORDS, NumRecordsToBuffer);
			
		Element extnRetryCountElem = SCXmlUtil.createChild(inDocGetOffTranQList.getDocumentElement(), KohlsPOCConstant.A_EXTN);
		extnRetryCountElem.setAttribute(KohlsPOCConstant.A_EXTN_RETRY_COUNT, "6");
		extnRetryCountElem.setAttribute(KohlsPOCConstant.A_EXTN_RETRY_COUNT + KohlsPOCConstant.A_QRY_TYPE, KohlsPOCConstant.LESS_THAN);
		Element EleOrderBy = SCXmlUtil.createChild(inDocGetOffTranQList.getDocumentElement(),
				KohlsPOCConstant.E_ORDER_BY);
		Element EleAttribute = SCXmlUtil.createChild(EleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
		EleAttribute.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.OFFLINE_TRXQ_KEY);
		EleAttribute.setAttribute(KohlsPOCConstant.A_DESC, KohlsPOCConstant.NO);

		String outPutTemplate = "<OfflineTransactionQs> <OfflineTransactionQ DATAXML='' IsLocal='' Modifyts='' "
				+ "OfflineTrxQKey='' OperationID='' OperationInputXML='' OperationTS='' StoreID='' "
				+ "TrxStatus='' UniqueID='' ReplicationSeq=''><Extn ExtnRetryCount=''/>	</OfflineTransactionQ>"
				+ "	</OfflineTransactionQs>";
		if (log.isDebugEnabled()) {
			log.debug("getOfflineTransactionQListForPOS input " + SCXmlUtil.getString(inDocGetOffTranQList));
		}
		Document outDocGetOffTransQListForPOS = KOHLSBaseApi.invokeAPI(env, XMLUtil.getDocument(outPutTemplate),
				KohlsPOCConstant.API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS,inDocGetOffTranQList);
		if (log.isDebugEnabled()) {
			log.debug("outDocGetOffTransQListForPOS output " + SCXmlUtil.getString(outDocGetOffTransQListForPOS));
		}
		log.info("Get offline transactions list completed");
		return outDocGetOffTransQListForPOS;
	}
	
	/**
	 * Calling the remote Api
	 * @param env
	 * @param inXML
	 * @param outDoc
	 * @param sApiName
	 * @return
	 * @throws Exception
	 */
	private Document callApi(YFSEnvironment env, Document inXML, Document outDoc, String sApiName)
			throws Exception {
		Document outDocCallApi = null;	
		if (log.isDebugEnabled()) {
			log.debug("Call Api is inProgress");
		}
		YFSEnvironment newEnv = oApi.createEnvironment(YFCDocument.parse(envString).getDocument());
		outDocCallApi = oApi.invoke(newEnv, sApiName, inXML);
		if (log.isDebugEnabled()) {
			log.debug("Remote call output in callApi " + sApiName + "\n " + SCXmlUtil.getString(outDocCallApi));
		}
		return outDocCallApi;
	}

	/**
	 * Assigning the endpoint details
	 * @param env
	 * @param endpoint
	 * @return
	 * @throws YIFClientCreationException
	 * @throws YFSUserExitException
	 */
	private YIFApi getDefaultAPI(YFSContext env, String endpoint)
			throws YIFClientCreationException, YFSUserExitException {
		if (oApi != null) {
			return oApi;
		}
		if (!(YFCCommon.isVoid(endpoint))) {
			if (log.isDebugEnabled()) {
				log.debug("YIFClient using endpoint definition");
			}
			Map<String, String> omap = new HashMap<String, String>();
			try {
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_USERID,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_USERID));
				omap.put(KohlsPOCConstant.YIF_HTTPAPI_PASSWD,
						YIFClientProperties.getInstance().getYIFProperty(KohlsPOCConstant.EDGE_INT_APP_PASSWD));
			} catch (ClientPropertiesNotFoundException e) {
				throw new YFCException(e);
			}
			return YIFClientFactory.getInstance().getApi(endpoint, omap);
		}
		YFSUserExitException oEx = new YFSUserExitException();
		oEx.setErrorCode(KohlsPOCConstant.EDGE_SERVER_ERROR_CODE);
		oEx.setErrorDescription(YFSSystem.getString(env.getYFCLocale(), KohlsPOCConstant.EDGE_SER_NOT_CONFIGURED));
		throw oEx;
	}

	/**
	 * Checking the ISS to CORP connection
	 * @param env
	 * @throws Exception
	 */
	private void checkRemoteConnection(YFSEnvironment env) throws Exception {
		Document getServerStatusForPOSinDoc = SCXmlUtil.createDocument(KohlsPOCConstant.SERVER_STATUS);
		Element elmStoreFallBackStatus = getServerStatusForPOSinDoc.getDocumentElement();
		elmStoreFallBackStatus.setAttribute(KohlsPOCConstant.SERVER_IP, YFSSystem.getProperty(KohlsPOCConstant.STORE_COMMON_IP));
		elmStoreFallBackStatus.setAttribute(KohlsPOCConstant.INXML_STORE_ID,
				YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP));
		Element eleAdditionalInfo = SCXmlUtil.createChild(elmStoreFallBackStatus,
				KohlsPOCConstant.A_YFC_ADDITIONAL_INFO);
		eleAdditionalInfo.setAttribute(KohlsPOCConstant.A_ENDPOINT, KohlsPOCConstant.V_MOTHERSHIP);
		Document getServerStatusForPOSOutDoc = null;
		if (log.isDebugEnabled()) {
			log.debug("Input to get server status from Corp \n" + SCXmlUtil.getString(getServerStatusForPOSinDoc));
		}
		Document outDocApi = callApi(env, getServerStatusForPOSinDoc, getServerStatusForPOSOutDoc,
				KohlsPOCConstant.API_GET_SERVER_STATUS_POS);
		if (log.isDebugEnabled()) {
			log.debug("getServerStatusForPOS remote call output\n" + SCXmlUtil.getString(outDocApi));
		}
		NodeList nodeListCommonCode = outDocApi.getElementsByTagName(KohlsPOCConstant.E_ERROR);
		if (nodeListCommonCode.getLength() > 0) {
			log.error("Call API to corp failed for getServerStatusForPOS " + SCXmlUtil.getString(outDocApi));
			Element eleRemove = ((Element) nodeListCommonCode.item(0));
			eleRemove.setAttribute(KohlsPOCConstant.INXML_STORE_ID,
					YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP));
			formatErrorMsg(outDocApi);	
			errorFlag = false;
			throw new YFCException("Exception in getServerStatusForPOS callApi " + SCXmlUtil.getString(outDocApi));
		}
		log.info("Store to Corp connection is successful");
	}
	
	/**
	 * 
	 * @param orderListElm
	 * @param uniqueID2 
	 * @param operationID 
	 * @return
	 * @throws Exception
	 */
	private Document orderSnyncMonitor(Element orderListElm, String operationID, String uniqueID2) throws Exception {
		Element orderExtnElm = XMLUtil.getChildElement(orderListElm, KohlsPOCConstant.E_EXTN);
		Document trxDetailsDoc = SCXmlUtil.createDocument("OrderMonitorList");
		Element trxDetailsElm = SCXmlUtil.createChild(trxDetailsDoc.getDocumentElement(),
				KohlsPOCConstant.TRX_SYNC_DETAILS);
		trxDetailsElm.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY, orderListElm.getAttribute(KohlsPOCConstant.ATTR_BUSINESS_DAY));
		trxDetailsElm.setAttribute(KohlsPOCConstant.ATTR_DOC_TYPE, orderListElm.getAttribute(KohlsPOCConstant.ATTR_DOC_TYPE));
		trxDetailsElm.setAttribute(KohlsPOCConstant.POST_VOID, orderListElm.getAttribute(KohlsPOCConstant.POST_VOID));
		trxDetailsElm.setAttribute(KohlsPOCConstant.MAX_ORDER_STATUS, orderListElm.getAttribute(KohlsPOCConstant.MAX_ORDER_STATUS));
		trxDetailsElm.setAttribute(KohlsPOCConstant.A_DRAFT_ORDER_FLAG, orderListElm.getAttribute(KohlsPOCConstant.A_DRAFT_ORDER_FLAG));
		trxDetailsElm.setAttribute(KohlsPOCConstant.A_ORDER_DATE, orderListElm.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
		trxDetailsElm.setAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE, orderListElm.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE));
		trxDetailsElm.setAttribute(KohlsPOCConstant.A_EXTN_IS_VOID_DURING, orderExtnElm.getAttribute(KohlsPOCConstant.A_EXTN_IS_VOID_DURING));
		trxDetailsElm.setAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI, orderExtnElm.getAttribute(KohlsPOCConstant.A_EXTN_IS_OMNI)); 
		trxDetailsElm.setAttribute(KohlsPOCConstant.EXTN_POC_FEATURE, orderExtnElm.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE));
		trxDetailsElm.setAttribute(KohlsPOCConstant.ATTR_VOID_INDICATOR, orderListElm.getAttribute(KohlsPOCConstant.ATTR_VOID_INDICATOR));
		trxDetailsElm.setAttribute(KohlsPOCConstant.ATTR_MAX_ORD_STS_DESC, orderListElm.getAttribute(KohlsPOCConstant.ATTR_MAX_ORD_STS_DESC));
		trxDetailsElm.setAttribute(KohlsPOCConstant.ATTR_ORG_TOTAL_AMT, orderListElm.getAttribute(KohlsPOCConstant.ATTR_ORG_TOTAL_AMT));
		trxDetailsElm.setAttribute(KohlsPOCConstant.ATTR_EXTN_IS_CANCELLED, orderExtnElm.getAttribute(KohlsPOCConstant.ATTR_EXTN_IS_CANCELLED));
		trxDetailsElm.setAttribute(KohlsPOCConstant.A_OPERATION_ID, operationID);
		trxDetailsElm.setAttribute(KohlsPOCConstant.A_UNIQUE_ID, uniqueID);
		log.debug("Transaction sync map details " + SCXmlUtil.getString(trxDetailsDoc));
		return trxDetailsDoc;
	}
}
