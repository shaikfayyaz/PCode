package com.kohls.poc.agent;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsCallReturnReasonCode;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsRRCAsyncTableUpdatesAgent extends YCPBaseAgent {

	
	
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsRRCAsyncTableUpdatesAgent.class);
	KohlsCallReturnReasonCode returnReasonCode = new KohlsCallReturnReasonCode();
	Document outDocReturnResonCodeList=null;
	
	/**
	 * This method will fetch all the records to be processed by executeJobs()
	 * 
	 * @throws Exception
	 */
	public List<Document> getJobs(YFSEnvironment env, Document inDoc,
			Document lastMessageCreated) throws YFSException {

		if (null != lastMessageCreated) {
			return null;
		}

		try {
			List<Document> returnList = new ArrayList<Document>();
			logger.beginTimer("KohlsRRCAsyncTableUpdatesAgent.getJobs");
			
			if (logger.isDebugEnabled()) {
			logger.debug("KohlsRRCAsyncTableUpdatesAgent.getJobs --- Input to getJobs"
					+ XMLUtil.getXMLString(inDoc));

			}
			Element messageXmlEle;

			messageXmlEle = KohlsXPathUtil.getElementByXpath(inDoc,
					"/Message/AgentDetails/MessageXml");

			if (null == messageXmlEle) {
				messageXmlEle = inDoc.getDocumentElement();
			}

			String agentCriteria = XMLUtil.getAttribute(messageXmlEle,
					KohlsPOCConstant.ACTION_GROUP_FLOWNAME);

			

			if (!YFCCommon.isVoid(agentCriteria)
					&& KohlsPOCConstant.A_RETURN_REASON_CODE
							.equalsIgnoreCase(agentCriteria)) {

				// Prepare inxml to DMAPIWrapper to get reasoncode specific
				// response
				Document docReqForReasonCode = XMLUtil
						.createDocument(KohlsPOCConstant.KOHLS_RETURN_REASON_CODE);
				docReqForReasonCode.getDocumentElement().setAttribute(
						KohlsPOCConstant.ATTR_DM_SOURCE,
						KohlsPOCConstant.RRC_AGENT);
				docReqForReasonCode.getDocumentElement().setAttribute(
						KohlsPOCConstant.A_DEVICE, KohlsPOCConstant.POC_DEVICE_CODE);

				Document docOutReturnReasonCode = KOHLSBaseApi.invokeService(
						env, KohlsPOCConstant.KOHLS_CALL_TO_RRC,
						docReqForReasonCode);
				

				Document docKohlsReturnReasonCodeList = (Document) env.getTxnObject(KohlsPOCConstant.ENV_RRC_LIST);
						
					returnList=	returnReasonCode.toCheckUpdateOrCreate(env, docKohlsReturnReasonCodeList, docOutReturnReasonCode,KohlsPOCConstant.RRC_AGENT);
			} 
			if (logger.isDebugEnabled()) {
		 logger.debug("returnList:"+returnList.toString());
			}
		 logger.endTimer("KohlsRRCAsyncTableUpdatesAgent.getJobs");
			return returnList;
		} catch (Exception e) {

			// logger.debug("KohlsRRCAsyncTableUpdatesAgent.getJobs ----  Exception in getJobs");
			String sErrorMsg=e.getMessage();
			
				logger.error("KohlsRRCAsyncTableUpdatesAgent get Jobs");
				throw new YFCException(e,"RRC_OTHER",e.getMessage());
			
			
		}

	}

	/**
	 * This method processes each record from getJobs()
	 * 
	 * @throws Exception
	 */
	public void executeJob(YFSEnvironment env, Document inDoc)
			throws YFSException {
		 logger.beginTimer("KohlsRRCAsyncTableUpdatesAgent.executeJob");
		try {

			if (!YFCCommon.isVoid(inDoc)) {
				
				NodeList ndlReturnReascodeList = inDoc
						.getElementsByTagName(KohlsPOCConstant.KOHLS_RETURN_REASON_CODE);
				if (ndlReturnReascodeList.getLength() > 0) {
					returnReasonCode.updateorCreateReturnReasonCode(env, inDoc);
				} 
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			
			logger.error("KohlsRRCAsyncTableUpdatesAgent.executejobs ----  Exception in executejobs");
			throw new YFCException(e,"RRC_OTHER",e.getMessage());
		
		}
		 logger.endTimer("KohlsRRCAsyncTableUpdatesAgent.executeJob");

	}

}
