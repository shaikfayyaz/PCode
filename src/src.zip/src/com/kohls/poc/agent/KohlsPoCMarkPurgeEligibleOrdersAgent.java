package com.kohls.poc.agent;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.tools.entityguru.generator.Attribute;
import com.yantra.tools.entityguru.generator.Entity;
import com.yantra.tools.entityguru.generator.EntityRepository;
import com.yantra.ycp.core.YCPContext;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dblayer.dbi.YFCEntityRepositoryImpl;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.dblaypgm.YFSDBHome;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCMarkPurgeEligibleOrdersAgent extends YCPBaseAgent{
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsPoCMarkPurgeEligibleOrdersAgent.class.getName());
	private static PreparedStatement prepStmt = null;
	private static String tranSchema = "";
	private static Statement stmt = null;

	/**
	 * @param env
	 * @param docInXML
	 * @return
	 * @throws Exception
	 */
	public List<Document> getJobs(YFSEnvironment env, Document docInXML) throws Exception {
		log.info("Getjobs started");
		if (log.isDebugEnabled())
			log.debug("Input to Getjobs \n" + SCXmlUtil.getString(docInXML));
		List<Document> purgeKeyList = new ArrayList<Document>();
		YFCElement eleRoot = YFCDocument.getDocumentFor(docInXML).getDocumentElement();
		String envType = eleRoot.getAttribute(KohlsPOCConstant.ENV_TYPE);
		String retentionDays = eleRoot.getAttribute(KohlsPOCConstant.A_LIVE_RETENTION_DAY);
		String historyRetentionDays = eleRoot.getAttribute(KohlsPOCConstant.A_HISTORY_RETENTION_DAY);
		String  successStatus = eleRoot.getAttribute(KohlsPOCConstant.TRX_SUCCESS);
		String trxStatuses = eleRoot.getAttribute(KohlsPOCConstant.TRX_OTHER_STATUS);
		String recordsToBuffer = eleRoot.getAttribute(KohlsPOCConstant.A_NUM_RECORDS_BUFFER);
		Element eleLastMessage = XMLUtil.getChildElement(docInXML.getDocumentElement(), KohlsPOCConstant.LAST_MESSAGE);
		YFSContext ctx = (YFSContext) env;
		try {			
			if (YFCCommon.isVoid(eleLastMessage)) {
				String corpPrefix = "";
				if (envType.equalsIgnoreCase(KohlsPOCConstant.CORP)) {
					String poolID = getPoolIDForTrxTable(ctx);					
					if (!YFCCommon.isVoid(poolID)) {
						Properties jdbcProperties = loadPropertiesFromAbsoluteLocation(
								YFSSystem.getProperty(KohlsPOCConstant.JDBC_PROPERTIES_PATH));
						tranSchema = jdbcProperties.getProperty(poolID + KohlsPOCConstant.DOT + KohlsPOCConstant.USER)
								+ KohlsPOCConstant.DOT;
						if (log.isDebugEnabled())
							log.debug("Schema retrieved is " + tranSchema);
						
						String colID = eleRoot.getAttribute(KohlsPOCConstant.COLONY_ID);
						corpPrefix = getColonyPrefix(env, colID);
						if (YFCCommon.isVoid(corpPrefix)) {
							throw new YFCException("Exception in getting prefix value");
						}
						log.info("Corp prefix value for ColonyId " + colID + " : " + corpPrefix);
					} else {
						throw new YFCException("Exception in get PoolID, pool is null");
					}
				}
							
				// Purge the table entries before start
				cleanUpPurgeTable(ctx, tranSchema);

				// Populate the purge records
				long totalNumOfPurgeRecords = 0;
				totalNumOfPurgeRecords = populatePurgeTableRecords(ctx, envType, retentionDays, tranSchema,
						successStatus, trxStatuses);

				if (totalNumOfPurgeRecords > 0) {
					// Copy the status 3 records to history table
					copyErrorRecordsToHistory(ctx, envType, tranSchema, corpPrefix);

					// Purging the error records
					purgeErrorRecords(ctx, tranSchema);

					// Get the keys and add it to return doc
					purgeKeyList = fetchRecordsToProcess(ctx, Integer.parseInt(recordsToBuffer),
							totalNumOfPurgeRecords);
					
					// Commit the transaction
					ctx.commit();
				}
			} else {
				String trxSchema = "";
				if (envType.equalsIgnoreCase(KohlsPOCConstant.ATTR_STORE)) {
					trxSchema = "STERLING";
				}else{
					trxSchema = tranSchema.replace(KohlsPOCConstant.DOT, "");
				}				
				String offlineProcedure = "ORSP_DROP_PARTITION('" + trxSchema + "','POS_OFFLINE_TRX_Q','" + retentionDays
						+ "',TRUE)";
				if (log.isDebugEnabled())
					log.debug("offlineProcedure is " + offlineProcedure);
				callOracleProcedure(ctx, offlineProcedure);
				
				String offlineHistoryProcedure = "ORSP_DROP_PARTITION('" + trxSchema + "','KOHLS_POS_OFFLINE_TRX_Q_H','"
						+ historyRetentionDays + "',FALSE)";
				if (log.isDebugEnabled())
					log.debug("offlineHistoryProcedure is " + offlineHistoryProcedure);
				callOracleProcedure(ctx, offlineHistoryProcedure);
			}
		} catch (Exception e) {
			log.error("Exception occured in getJobs");
			throw e;
		} finally {
			YFSDBHome.closeStatement(stmt);
			log.info("GetJobs statement closed");
		}
		log.info("GetJobs completed");
		return purgeKeyList;
	}
	
	
	/**
	 * @param env
	 * @param inXML
	 * @return
	 * @throws Exception
	 */
	@Override
	public void executeJob(YFSEnvironment env, Document inDoc) throws Exception {
		log.info("Execute job started");
		if (log.isDebugEnabled())
			log.debug("Input to execute job \n" + SCXmlUtil.getString(inDoc));
		Element elmKey = inDoc.getDocumentElement();
		String startKey = elmKey.getAttribute(KohlsPOCConstant.A_START_KEY);
		String endKey = elmKey.getAttribute(KohlsPOCConstant.A_END_KEY);
		purgeOfflineRecords(env, tranSchema, startKey, endKey);
		log.info("Execute job completed");
	}
		

	/**
	 * Truncate the purge table used for temporary storage	 * 
	 * @param ctx
	 * @param schema
	 * @throws SQLException
	 */
	private void cleanUpPurgeTable(YFSContext ctx, String schema) throws SQLException { 
		log.info("Truncate the purge table started");
		try {
			PLTQueryBuilder truncRecords = new PLTQueryBuilder(false);
			truncRecords.append("TRUNCATE TABLE " + schema + "KOHLS_POS_OFFLINE_TRXQ_PRG");
			if (log.isDebugEnabled())
				log.debug("Executing the purge offline records query " + truncRecords.getReadableWhereClause());		
			prepStmt = ctx.getConnection().prepareStatement(truncRecords.getReadableWhereClause(true));
			prepStmt.executeUpdate();
			if (log.isDebugEnabled())
				log.debug("Truncate offline records executed");
		} catch (Exception tr) {
			log.error("Exception during cleanup of KOHLS_POS_OFFLINE_TRXQ_PRG table");
			throw tr;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("Truncate offline records prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
		log.info("Truncate the purge table completed");
	}

	/**
	 * Delete the set of records passed to delete statement
	 * @param env
	 * @param trxSchema
	 * @param startkey
	 * @param endKey
	 * @throws Exception 
	 */
	private void purgeOfflineRecords(YFSEnvironment env, String trxSchema, String startkey, String endKey)
			throws Exception {
		log.info("Purging the offline records started");
		YCPContext ctx = (YCPContext) env;
		try {			
			PLTQueryBuilder deleteRecord = new PLTQueryBuilder(false);		
			deleteRecord.append("DELETE FROM " + trxSchema + "POS_OFFLINE_TRX_Q WHERE POS_OFFLINE_TRX_Q.OFFLINE_TRX_Q_KEY IN ");
			deleteRecord.append("(SELECT KOHLS_POS_OFFLINE_TRXQ_PRG.OFFLINE_TRX_Q_KEY FROM " + trxSchema
					+ "KOHLS_POS_OFFLINE_TRXQ_PRG WHERE KOHLS_POS_OFFLINE_TRXQ_PRG.OFFLINE_TRX_Q_KEY BETWEEN '" + startkey	
					+ "' AND '" + endKey + "')");	
			
			if (log.isDebugEnabled())
				log.debug("Executing the purge offline records query " + deleteRecord.getReadableWhereClause());		
			prepStmt = ctx.getConnection().prepareStatement(deleteRecord.getReadableWhereClause(true));
			int delCount = 0;
			delCount = prepStmt.executeUpdate();
			log.info("Purge offline records delete count " + delCount);
		} catch (Exception cl) {
			log.error("Exception during the purge offline records");
			throw cl;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("Purge offline records prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
		log.info("Purge offline records completed");
	}
	
	
	/**
	 * Purge the status 3 records
	 * @param ctx
	 * @param schema
	 * @throws SQLException
	 */
	private void purgeErrorRecords(YFSContext ctx, String schema) throws SQLException {
		log.info("Purging the error records started");
		try {
			PLTQueryBuilder deleteRecord = new PLTQueryBuilder(false);
			deleteRecord.append("DELETE FROM " + schema + "POS_OFFLINE_TRX_Q WHERE OFFLINE_TRX_Q_KEY IN ");
			deleteRecord.append("(SELECT OFFLINE_TRX_Q_KEY FROM " + schema
					+ "KOHLS_POS_OFFLINE_TRXQ_PRG WHERE TRX_STATUS='3')");			
			if (log.isDebugEnabled())
				log.debug("Executing the purgeErrorRecords query " + deleteRecord.getReadableWhereClause());
			prepStmt = ctx.getConnection().prepareStatement(deleteRecord.getReadableWhereClause(true));
			int delCount = 0;
			delCount = prepStmt.executeUpdate();
			log.info("Purge error records count is " + delCount);
		} catch (Exception cl) {
			log.error("Exception during the purging the error records");
			throw cl;
		} finally {		
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("PurgeErrorRecords prepStmt isVoid val " + !YFCObject.isVoid(prepStmt) + ",  isClosed val "
						+ !prepStmt.isClosed());
			}
			prepStmt.close();			
		}		
		log.info("Purging the error records completed");
	}
	
	/**
	 * Copy error records to history table
	 * @param ctx
	 * @param envType
	 * @param schema
	 * @throws Exception
	 */
	private void copyErrorRecordsToHistory(YFSContext ctx, String envType, String schema, String corpPrefix) throws Exception {
		log.info("Copy error records to history started");
		try {
			String columnsList = getTableColumnsList(KohlsPOCConstant.DB_TBL_POSOFFLINE);
			PLTQueryBuilder errorPLT = new PLTQueryBuilder(false);	
			if (envType.equalsIgnoreCase(KohlsPOCConstant.CORP)) {
				errorPLT.append("INSERT INTO " + schema + "KOHLS_POS_OFFLINE_TRX_Q_H (OFFLINE_TRX_Q_KEY" + columnsList + ") ");				
				errorPLT.append("SELECT '" + corpPrefix	+ "'||TO_CHAR(SYSDATE, 'YYMMDDHH24MiSS')||TO_CHAR(SEQ_YFS_TABLE_KEY.NEXTVAL)" + columnsList);
				errorPLT.append(" FROM " + schema + "POS_OFFLINE_TRX_Q WHERE OFFLINE_TRX_Q_KEY IN ");				
				errorPLT.append("(SELECT OFFLINE_TRX_Q_KEY FROM " + schema + "KOHLS_POS_OFFLINE_TRXQ_PRG WHERE TRX_STATUS='3')");
			} else {
				errorPLT.append("INSERT INTO " + schema + "KOHLS_POS_OFFLINE_TRX_Q_H (OFFLINE_TRX_Q_KEY" + columnsList + ") ");
				errorPLT.append("SELECT TO_CHAR(SYSDATE, 'YYMMDDHH24MiSS')||TO_CHAR(SEQ_YFS_TABLE_KEY.NEXTVAL)" + columnsList);								
				errorPLT.append(" FROM " + schema + "POS_OFFLINE_TRX_Q WHERE OFFLINE_TRX_Q_KEY IN ");
				errorPLT.append("(SELECT OFFLINE_TRX_Q_KEY FROM " + schema + "KOHLS_POS_OFFLINE_TRXQ_PRG WHERE TRX_STATUS='3')");
			}
			
			log.info("Executing the insert query " + errorPLT.getReadableWhereClause());			
			prepStmt = ctx.getConnection().prepareStatement(errorPLT.getReadableWhereClause(true));
			int copyCount = 0;
			copyCount = prepStmt.executeUpdate();
			log.info("No of error records inserted " + copyCount);			
		} catch (Exception ce) {
			log.error("Exception during the copyErrorRecordsToHistory");			
			throw ce;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("copyErrorRecordsToHistory prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
		log.info("Copy error records to history completed");
	}
	

	/**
	 * Populate the offline purge table with the primary keys and statuses
	 * @param ctx
	 * @param purgeSource
	 * @param retentionDays
	 * @param trxSchema
	 * @param successStatus
	 * @param trxStatuses
	 * @throws Exception
	 */
	private long populatePurgeTableRecords(YFSContext ctx, String purgeSource, String retentionDays, String trxSchema,
			String successStatus, String trxStatuses) throws Exception {
		log.info("Populate the purge table with records started");
		long euRetVal = 0;
		try {
			PLTQueryBuilder oPLT = new PLTQueryBuilder(false);
			if (purgeSource.equalsIgnoreCase(KohlsPOCConstant.CORP)) {
				oPLT.append("INSERT INTO " + trxSchema + "KOHLS_POS_OFFLINE_TRXQ_PRG (OFFLINE_TRX_Q_KEY,TRX_STATUS) ");
				oPLT.append("SELECT OFFLINE_TRX_Q_KEY,TRX_STATUS FROM " + trxSchema + "POS_OFFLINE_TRX_Q WHERE MODIFYTS<=SYSDATE-");
				oPLT.append(retentionDays + " AND ((TRX_STATUS='" + successStatus + "' AND OPERATION_ID !='loadOfflineOrderForPOS') ");
				oPLT.append("OR (TRX_STATUS IN ('"+ trxStatuses.replaceAll(",","','") +"')))");
			} else {
				oPLT.append("INSERT INTO " + trxSchema + "KOHLS_POS_OFFLINE_TRXQ_PRG (OFFLINE_TRX_Q_KEY,TRX_STATUS) ");
				oPLT.append("SELECT OFFLINE_TRX_Q_KEY,TRX_STATUS FROM " + trxSchema + "POS_OFFLINE_TRX_Q WHERE MODIFYTS<=SYSDATE-");
				oPLT.append(retentionDays + " AND TRX_STATUS IN ('"+ successStatus + "','" + trxStatuses.replaceAll(",","','") +"')");
			}
		
			log.info("Executing the insert query " + oPLT.getReadableWhereClause());
			prepStmt = ctx.getConnection().prepareStatement(oPLT.getReadableWhereClause(true));			
			euRetVal = prepStmt.executeUpdate();
			log.info("No of records inserted " + euRetVal);	
		} catch (Exception ppt) {
			log.error("Exception in populate the purge table with records");			
			throw ppt;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("populatePurgeTableRecords prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
		log.info("Populate the purge table with records completed");
		return euRetVal;
	}

	/**
	 * This method is used to retrieve pool ID for the transaction table
	 * @param env
	 * @return
	 * @throws Exception
	 */
	private String getPoolIDForTrxTable(YFSEnvironment env) throws Exception {
		if (log.isDebugEnabled())
			log.debug("Get PoolID for trx table started");
		String poolID = null;
		Document inDocToGetPoolList = SCXmlUtil.createDocument(KohlsPOCConstant.E_COLONY_POOL);
		inDocToGetPoolList.getDocumentElement().setAttribute(KohlsPOCConstant.TABLE_TYPE,
				KohlsPOCConstant.A_TRANSACTION);
		if (log.isDebugEnabled())
			log.debug("Input to get the colony pool list \n" + SCXmlUtil.getString(inDocToGetPoolList));
		Document outDocToGetPoolList = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_COLONY_POOL_LIST,
				inDocToGetPoolList);
		if (log.isDebugEnabled())
			log.debug("Output from get colony pool list \n" + SCXmlUtil.getString(outDocToGetPoolList));

		if (outDocToGetPoolList.getDocumentElement().hasChildNodes()) {
			Element eleColonyPool = (Element) outDocToGetPoolList.getDocumentElement()
					.getElementsByTagName(KohlsPOCConstant.E_COLONY_POOL).item(0);
			poolID = eleColonyPool.getAttribute(KohlsPOCConstant.A_POOL_ID);
			log.info("Get PoolID is " + poolID);
		}
		if (log.isDebugEnabled())
			log.debug("Get PoolID for trx table completed");
		return poolID;
	}
		
	/**
	 * Add to array list with min and max keys for complete set of records.
	 * @param ctx
	 * @param recordMax
	 * @param totalRowCount
	 * @return
	 * @throws Exception
	 */
	private ArrayList<Document> fetchRecordsToProcess(YFSContext ctx, int recordMax, long totalRowCount)
			throws Exception {
		ResultSet resultMinMaxVal = null;
		String MIN_VAL = "MIN_VAL";
		String MAX_VAL = "MAX_VAL";
		ArrayList<Document> purgeKeyList = new ArrayList<Document>();
		try {
			log.info("Total number of orders to purge is " + totalRowCount);
			if (totalRowCount > 0) {
				String minMaxQry  = "SELECT MAX(OFFLINE_TRX_Q_KEY) AS MAX_VAL, MIN(OFFLINE_TRX_Q_KEY) AS MIN_VAL "
						+ "FROM ( SELECT a.*, rownum rnum " + "FROM ( SELECT OFFLINE_TRX_Q_KEY FROM " + tranSchema
						+ "KOHLS_POS_OFFLINE_TRXQ_PRG ORDER BY KOHLS_POS_OFFLINE_TRXQ_PRG.OFFLINE_TRX_Q_KEY desc ) a "
						+ "WHERE rownum <= ?) WHERE rnum >= ?";
				prepStmt = ctx.getConnection().prepareStatement(minMaxQry);				
				if (totalRowCount > recordMax) {
					long inc = 0;
					long numOfIterations = totalRowCount / recordMax;
					log.info("Getjob iterations is " + numOfIterations);
					long remainOrderKeys = totalRowCount % recordMax;
					long remindRow = totalRowCount - remainOrderKeys + 1;							
					for (int iterate = 0; iterate < numOfIterations; iterate++) {
						long maxRecordInc = inc + recordMax;
						long startRecord = inc + 1;							
						prepStmt.setLong(1, maxRecordInc);
						prepStmt.setLong(2, startRecord);
						resultMinMaxVal = prepStmt.executeQuery();												
						resultMinMaxVal.next();						
						inc = inc + recordMax;
						purgeKeyList.add(purgeKeysDocument(resultMinMaxVal.getString(MIN_VAL).trim(),
								resultMinMaxVal.getString(MAX_VAL).trim()));
						if(log.isDebugEnabled())
							log.debug("Min and max keys are " + resultMinMaxVal.getString(MIN_VAL).trim() +
								resultMinMaxVal.getString(MAX_VAL).trim());
					}
					if (remainOrderKeys != 0) {						
						prepStmt.setLong(1, totalRowCount);
						prepStmt.setLong(2, remindRow);												
						resultMinMaxVal = prepStmt.executeQuery();
						resultMinMaxVal.next();
						purgeKeyList.add(purgeKeysDocument(resultMinMaxVal.getString(MIN_VAL).trim(),
								resultMinMaxVal.getString(MAX_VAL).trim()));
						if(log.isDebugEnabled())
							log.debug("Min and max keys are " + resultMinMaxVal.getString(MIN_VAL).trim() +
								resultMinMaxVal.getString(MAX_VAL).trim());
					}
				} else {					 
					prepStmt.setLong(1, recordMax);
					prepStmt.setLong(2, 1);													
					resultMinMaxVal = prepStmt.executeQuery();
					resultMinMaxVal.next();
					purgeKeyList.add(purgeKeysDocument(resultMinMaxVal.getString(MIN_VAL).trim(),
							resultMinMaxVal.getString(MAX_VAL).trim()));
					if(log.isDebugEnabled())
						log.debug("Min and max keys are " + resultMinMaxVal.getString(MIN_VAL).trim() +
							resultMinMaxVal.getString(MAX_VAL).trim());
				}
				resultMinMaxVal.close();
			}
			if (log.isDebugEnabled())
				log.debug("Size of getJobs list is " + purgeKeyList.size());
			return purgeKeyList;
		} catch (Exception ex) {
			log.error("fetchRecordsToProcess Error occurred in firing select query");
			throw ex;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("fetchrecordsToProcess prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
	}

	/**
	 * Form the document for both start and end keys
	 * @param min
	 * @param max
	 * @return
	 * @throws Exception
	 */	 
	private Document purgeKeysDocument(String min, String max) throws Exception {
		Document inDocKeys = SCXmlUtil.createDocument(KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
		Element eleKeys = inDocKeys.getDocumentElement();
		eleKeys.setAttribute(KohlsPOCConstant.A_START_KEY, min);
		eleKeys.setAttribute(KohlsPOCConstant.A_END_KEY, max);		
		if (log.isDebugEnabled())
			log.debug("Offlinekey min and max keys document is  \n" + SCXmlUtil.getString(inDocKeys));
		return inDocKeys;		
	}
		
	
	/**
	 * Get all the columns and exclude primary key,createts,modifyts, from the list
	 * as comma separated
	 * @param strTableName
	 * @return
	 */
	public String getTableColumnsList(String strTableName) {
		log.info("Trx table is " + strTableName);
		EntityRepository entityRepos = (EntityRepository) YFCEntityRepositoryImpl.getInstance();
		Entity e1 = entityRepos.getEntityFromTableName(strTableName);
		List<Attribute> allAttribs = new ArrayList<Attribute>();
		allAttribs = e1.allAttributes();
		if (log.isDebugEnabled())
			log.debug("Attribute list is " + e1.allAttributes());
		StringBuffer strBuffColumnList = new StringBuffer();
		for (Attribute colName : allAttribs) {
			if (log.isDebugEnabled())
				log.debug("Column name is " + colName.getColumnName());
			if (!(colName.getColumnName().equalsIgnoreCase(KohlsPOCConstant.DB_OFFLINE_TRX_Q_KEY)
					|| colName.getColumnName().equalsIgnoreCase(KohlsPOCConstant.DB_CREATETS)
					|| colName.getColumnName().equalsIgnoreCase(KohlsPOCConstant.DB_MODIFYTS))) {
				if (log.isDebugEnabled())
					log.debug("Adding column " + colName.getColumnName() + " to list with comma separated");
				strBuffColumnList.append("," + colName.getColumnName());
			}
		}
		return strBuffColumnList.toString();
	}
	
	/** 
	 * @param env
	 * @param colonyID
	 * @return
	 * @throws Exception
	 */
	private String getColonyPrefix(YFSEnvironment env, String colonyID) throws Exception{		
		String inputXml = "<Colony ColonyId='" + colonyID + "'/>";
		Document inDoc = SCXmlUtil.createFromString(inputXml);
		if (log.isDebugEnabled())
			log.debug("Input doc to getColonyList " + SCXmlUtil.getString(inDoc));

		Document outDoc = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.GET_COLONY_LIST_API, inDoc);
		if (log.isDebugEnabled())
			log.debug("Output doc from getColonyList " + SCXmlUtil.getString(outDoc));
		Element elmDoc = KohlsXPathUtil.getElementByXpath(outDoc, "/ColonyList/Colony");		
		return   elmDoc.getAttribute(KohlsPOCConstant.A_PKPREFIX);		
	}
	
	/**
	 * Execute the constructed procedure
	 * @param env
	 * @param oracleProcedure
	 * @throws SQLException
	 */	
	private void callOracleProcedure(YFSContext ctx, String procedure) throws SQLException {
		try {
			log.info("Procedure constructed is " + procedure);		
			prepStmt = ctx.getConnection().prepareStatement("{call " + procedure + "}");
			prepStmt.executeQuery();
			log.info("DBA oracle procedure call completed");
		} catch (SQLException e) {
			log.error("Error in callOracleProcedure");
			throw e;
		} finally {
			YFSDBHome.closeStatement(prepStmt);
			if (log.isDebugEnabled()) {
				log.debug("callOracleProcedure prepStmt isVoid val " + !YFCObject.isVoid(prepStmt)
						+ ",  isClosed val " + !prepStmt.isClosed());
			}
			prepStmt.close();
		}
	}
	
	/**
	 * Load the jdbc customer properties
	 * @param propertyFilePath
	 * @return
	 * @throws Exception
	 */
	private Properties loadPropertiesFromAbsoluteLocation(String propertyFilePath) throws Exception {
		log.info("Reading the property file");
		Properties prop = new Properties();
		File file = null;
		FileReader fr = null;
		if (log.isDebugEnabled())
			log.debug("Properties file path  " + propertyFilePath);
		try {
			file = new File(propertyFilePath);
			fr = new FileReader(file);
			if (log.isDebugEnabled())
				log.debug("File Reader initiated successfully");
			prop.load((Reader) fr);
		} catch (Exception e) {
			log.error("Error in loading properties file");
			throw e;
		} finally {
			if (fr != null) {
				fr.close();
			}
			if (file != null) {
				file = null;
			}
		}
		return prop;
	}
}