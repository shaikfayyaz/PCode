package com.kohls.poc.agent;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsStoreOrderPurgeAgent extends YCPBaseAgent {
	static Logger log = Logger.getLogger(KohlsStoreOrderPurgeAgent.class.getName());
	Connection purgeConnect = null;

	// Get the agent criteria	
	@Override
	public List<Document> getJobs(YFSEnvironment env, Document inXML, Document docLastMessage) throws Exception {
		List<Document> orderKeysList = new ArrayList<Document>();
		log.info("Input to getJobs" + XMLUtil.getXMLString(inXML));
		try {
			//Emptying the kohls order purge table
			deletePurgeKeys(env);
			
			if (docLastMessage == null) {
				YFCElement eleRoot = YFCDocument.getDocumentFor(inXML).getDocumentElement();
				int maxRecords = Integer.parseInt(eleRoot.getAttribute(KohlsPOCConstant.A_NUM_RECORDS_BUFFER).toString());
				Calendar cal = Calendar.getInstance();
				Date dtCurrentDate = cal.getTime();
				cal.setTime(dtCurrentDate);
				cal.add(Calendar.DATE, -Integer.parseInt(eleRoot.getAttribute(KohlsPOCConstant.A_RETENTION_DAY)));
				Date dtModifyDate = cal.getTime();
				SimpleDateFormat df = new SimpleDateFormat(KohlsPOCConstant.DD_MM_YYYY);
				String dateAvailable = df.format(dtModifyDate);
				String inputDateToProc = "instEligibleOrdRecordsToTemp('" + dateAvailable + "')";
				YFSContext yctx = (YFSContext) env;
				log.info("Last message is empty ");
				//Populate the records in the temp table
				callOracleProcedure(env, inputDateToProc);
				orderKeysList = fireSqlForOrderPurge(yctx, maxRecords);
			}
			/*if (orderKeysList.size() == 0) {
				log.debug("Size of orderKeysList is " + orderKeysList.size());
				deletePurgeKeys(env);
			}*/
			log.info("Get jobs completed");
		} catch (Exception e) {
			log.error("Exception getJobs is " + e.toString());
			throw e;
		}
		return orderKeysList;
	}

	// Fire the SELECT query based on the recordMax and Last key
	private ArrayList<Document> fireSqlForOrderPurge(YFSContext ctx, int recordMax)
			throws Exception {
		PreparedStatement prepStmt = null;
		//Connection conn = null;
		ResultSet resultMinMaxVal = null;
		long totalRowCount = 0;
		String MIN_VAL = "MIN_VAL";
		String MAX_VAL = "MAX_VAL";
		ArrayList<Document> purgeKeyList = new ArrayList<Document>();
		try {
			purgeConnect = ctx.getConnection();
			Statement stmtForCount = purgeConnect.createStatement();
			ResultSet resultForCount = stmtForCount
					.executeQuery("SELECT COUNT(*) AS OrderHeaderKeys FROM KOHLS_ORDER_PURGE");
			resultForCount.next();
			totalRowCount = Integer.parseInt(resultForCount.getString(KohlsPOCConstant.A_ORDER_HDR_KEYS));
			log.info("Total number of orders to purge is " + totalRowCount);

			if (totalRowCount > 0) {
				if (totalRowCount > recordMax) {
					long inc = 0;
					long numOfIterations = totalRowCount / recordMax;
					log.info("Num of iterations is " + numOfIterations);
					long remainOrderKeys = totalRowCount % recordMax;
					long remindRow = totalRowCount - remainOrderKeys + 1;
					for (int iterate = 0; iterate < numOfIterations; iterate++) {
						long maxRecordInc = inc + recordMax;
						long startRecord = inc + 1;
						prepStmt = purgeConnect.prepareStatement(constQuery(startRecord, maxRecordInc));
						resultMinMaxVal = prepStmt.executeQuery();
						resultMinMaxVal.next();
						inc = inc + recordMax;
						purgeKeyList.add(orderKeyDocument(resultMinMaxVal.getString(MIN_VAL).trim(),
								resultMinMaxVal.getString(MAX_VAL).trim()));
					}
					if (remainOrderKeys != 0) {
						prepStmt = purgeConnect.prepareStatement(constQuery(remindRow, totalRowCount));
						resultMinMaxVal = prepStmt.executeQuery();
						resultMinMaxVal.next();
						purgeKeyList.add(orderKeyDocument(resultMinMaxVal.getString(MIN_VAL).trim(),
								resultMinMaxVal.getString(MAX_VAL).trim()));
					}
				} else {
					prepStmt = purgeConnect.prepareStatement(constQuery(1, recordMax));
					resultMinMaxVal = prepStmt.executeQuery();
					resultMinMaxVal.next();
					purgeKeyList.add(orderKeyDocument(resultMinMaxVal.getString(MIN_VAL).trim(),
							resultMinMaxVal.getString(MAX_VAL).trim()));
				}
				resultMinMaxVal.close();
			}
			resultForCount.close();
			log.info("Size of getJobs list is " + purgeKeyList.size());
			return purgeKeyList;
		} catch (Exception ex) {
			log.error("Error occurred in firing select query");
			throw ex;
		} finally {
			if (!YFCObject.isVoid(prepStmt)) {
				log.info("Closing the db prepStmt");
				prepStmt.close();
			}
		}
	}

	// Creating the document
	public Document orderKeyDocument(String min, String max) throws Exception {
		Document inDoc1 = YFCDocument.createDocument(KohlsPOCConstant.A_ORDER_HDR_KEYS).getDocument();
		Element eleServInput1 = inDoc1.getDocumentElement();
		eleServInput1.setAttribute(KohlsPOCConstant.A_START_KEY, min);
		eleServInput1.setAttribute(KohlsPOCConstant.A_END_KEY, max);
		return inDoc1;
	}

	// Construct the query
	public String constQuery(long startRow, long endRow) throws Exception {
		String selectQry = "SELECT MAX(ORDER_HEADER_KEY) AS MAX_VAL, MIN(ORDER_HEADER_KEY) AS MIN_VAL "
				+ "FROM ( SELECT a.*, rownum rnum " + "FROM ( SELECT * FROM KOHLS_ORDER_PURGE "
				+ "ORDER BY KOHLS_ORDER_PURGE.ORDER_HEADER_KEY desc ) a " + "WHERE rownum <= " + endRow + ") "
				+ "WHERE rnum >= " + startRow;
		log.debug("Query formed is " + selectQry);
		return selectQry;
	}

	// Execute job
	@Override
	public void executeJob(YFSEnvironment env, Document inDoc) throws Exception {
		log.info("Execute job started");
		YFCElement docElement = YFCDocument.getDocumentFor(inDoc).getDocumentElement();
		log.debug("Input to execute job is " + SCXmlUtil.getString(inDoc));
		String orderPurgeProcedure = "INVOKEPURGEORDER (" + docElement.getAttribute(KohlsPOCConstant.A_START_KEY) + ", "
				+ docElement.getAttribute(KohlsPOCConstant.A_END_KEY) + ")";
		log.debug("Input purge procedure is " + orderPurgeProcedure);
		callOracleProcedure(env, orderPurgeProcedure);
		log.info("Execute job completed");
	}

	// Execute the constructed procedure
	public void callOracleProcedure(YFSEnvironment env, String oracleProcedure) throws SQLException {
		try {
			//Connection connection = ((YFSContext) env).getConnection();
			purgeConnect = ((YFSContext) env).getConnection();
			CallableStatement preparedCall;
			log.debug("Procedure constructed is " + oracleProcedure);
			preparedCall = purgeConnect.prepareCall("{call " + oracleProcedure + "}");
			preparedCall.execute();
			log.info("DBA oracle procedure call completed");
		} catch (SQLException e) {
			log.error("Error in callOracleProcedure");
			throw e;
		}
	}

	// Cleanup the records from KOHLS_ORDER_PURGE table
	private void deletePurgeKeys(YFSEnvironment env) throws Exception {
		PreparedStatement delPrepStmt = null;
		//Connection delQueryConn = null;
		YFSContext delContext = (YFSContext) env;
		//String delSqlQuery = "DELETE FROM KOHLS_ORDER_PURGE WHERE STATUS IN ('DELETED')";
		String delSqlQuery = "DELETE FROM KOHLS_ORDER_PURGE";
		log.debug("Delete query being formed is " + delSqlQuery);
		try {
			log.info("Deleting the entries in purge table");
			purgeConnect = delContext.getConnection();
			delPrepStmt = purgeConnect.prepareStatement(delSqlQuery);
			ResultSet delResultSet = delPrepStmt.executeQuery();
			delResultSet.close();
		} catch (Exception ex) {
			log.error("Error occurred in fire delete query");
			throw ex;
		} finally {
			if (!YFCObject.isVoid(delPrepStmt)) {
				log.info("Closing the stmt connection for delete query");
				delPrepStmt.close();
			}
		}
	}
}