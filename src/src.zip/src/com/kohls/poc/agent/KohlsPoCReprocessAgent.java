package com.kohls.poc.agent;

import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.TransformerException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ibm.sterling.Utils;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.yantra.interop.util.YFSContextManager;
import com.yantra.shared.dbclasses.KOHLS_Reprocess_RequestDBHome;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dblayer.PLTQueryBuilder;
import com.yantra.yfc.dblayer.YFCEntity;
import com.yantra.yfc.dblayer.YFCQueryBuilder;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.dom.YFCNodeList;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCReprocessAgent extends YCPBaseAgent {

    /**
   * This custom Agent is used to fetch records from the custom table "KOHLS_REPROCESS_REQUEST". The
   * service name to be invoked and the input xml to the service are fetched from the table and the
   * records are processed asynchronously. 
   * get Jobs
   * <Message FlowName="KOHLS_REPROCESS_REQUEST" TransactionKey="2016091405574517826741">
   *    <AgentDetails> 
   *       <MessageXml Action="Get" ColonyId="STORE_GRP_01" EnterpriseCode="KOHLS-RETAIL"
   *        NumRecordsToBuffer="5000"/> 
   *    </AgentDetails>
   * <AppContextInfo ChangeProjectKey="DEFAULT" ChangeRequestKey="DEFAULT"/> 
   * </Message>
   * executeJob
   * 
   */

    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCReprocessAgent.class);
    private static  int  thresholdDaysForUnprocessedInt = 1200;
    KohlsReprocessRequestUtil requestUtilObj = new KohlsReprocessRequestUtil();
    private static Statement stmt = null;
   // String sCurrentDate = KohlsReprocessRequestUtil.getCurrSysDateAsString();

    /**
     * This method will fetch all the records to be processed by executeJobs()
     */
    @SuppressWarnings("unchecked")
    public List<Document> getJobs(YFSEnvironment env, Document inDoc) {

        List<Document> returnList = new ArrayList<Document>();
        logger.beginTimer("KohlsPoCReprocessAgent.getJobs");
    
        if(logger.isDebugEnabled())
            logger.debug("KohlsPoCReprocessAgent.getJobs --- Input to getJobs"+ XMLUtil.getXMLString(inDoc));

        Document outDoc = null;
        try {
            // Load the Collections for the everytime getJobs() is called
            requestUtilObj.loadPropsFromCommonCode(env,
                    KohlsPOCConstant.COMMON_CODE_FOR_REPROCESS);
            
            if(logger.isDebugEnabled())
                logger.debug("commonCodeProperties after loading ::"+ requestUtilObj.propsFromCommonCode);
            
            Element messageXmlEle = KohlsXPathUtil.getElementByXpath(inDoc, "/Message/AgentDetails/MessageXml");
            if(null == messageXmlEle){
              messageXmlEle = inDoc.getDocumentElement();
            }
            
            String agentCriteria = XMLUtil.getAttribute(messageXmlEle, "ActionFlowName");
            // if it is get taxgeoCode , we will just insert the records for stores to get taxgeo update
            thresholdDaysForUnprocessedInt = getThresholdDaysForMessages(messageXmlEle);
            
            // Fetch the records from the custom table
            if(agentCriteria.equalsIgnoreCase("TAXGEOCODE")){
               outDoc = KOHLSBaseApi.invokeService(env,
                  "TriggerTaxGeoCodeUpdate",
                  inDoc);
                          
            }else if(!YFCCommon.isVoid(agentCriteria)){
              outDoc = fetchRecordsToProcess(env, inDoc, agentCriteria);
            }
            
            List<Element> reprocessReqList = XMLUtil.getElementsByTagName(
                    outDoc.getDocumentElement(), "KohlsReprocessRequest");
            if (!YFCCommon.isVoid(outDoc) && reprocessReqList.size() > 0) {
                for (Element eleReprocessRec : reprocessReqList) {
                  eleReprocessRec.setAttribute("AgentCriteria", agentCriteria);
                    Document docReprocessRec = XMLUtil
                            .getDocumentForElement(eleReprocessRec);
                    returnList.add(docReprocessRec);
                }
            } else {
                logger.debug("KohlsPoCReprocessAgent.getJobs ----  No records for executeJob to process");
            }
        } catch (Exception e) {
            logger.debug("KohlsPoCReprocessAgent.getJobs ----  Exception in getJobs");
            e.printStackTrace();
            throw new YFSException(e.getMessage());
        }

        logger.endTimer("KohlsPoCReprocessAgent.getJobs");
        return returnList;
    }

  /**
   * Create By TKMACJT * 
   * @param inDoc   * @return
   * @throws TransformerException 
   */
  private int getThresholdDaysForMessages(Element messageXmlEle) throws TransformerException {
    
    String thresholdDaysForUnprocessed = null;    
    if(null != messageXmlEle){
      thresholdDaysForUnprocessed = messageXmlEle.getAttribute("ThresholdDaysForUnprocessed");
    }
    
    if(!YFCCommon.isVoid(thresholdDaysForUnprocessed)){
      try{
        thresholdDaysForUnprocessedInt = Integer.parseInt(thresholdDaysForUnprocessed);   
      } catch (NumberFormatException e){
        logger.error(e.getMessage() + "Parameter Passed in KohlsPoCReprocessAgent is not well formatted");
        
      }
    }
    return thresholdDaysForUnprocessedInt;
  }

    /**
     * This method processes each record from getJobs()
     * @throws Exception 
     */
    public void executeJob(YFSEnvironment env, Document inDoc) throws Exception {
        logger.beginTimer("KohlsPoCReprocessAgent.executeJob");
        
        if(logger.isDebugEnabled())
            logger.debug("KohlsPoCReprocessAgent.executeJob --- Input to executeJob"+ XMLUtil.getXMLString(inDoc));
        
        
        Element eleReprocessRec = inDoc.getDocumentElement();
        int errorCount = 0;
        int maxErrorCount = 0;
        String strServiceName = eleReprocessRec.getAttribute("ServiceName");
        String purgeDate = eleReprocessRec.getAttribute("PurgeDate");
        String createts = eleReprocessRec.getAttribute("Createts");        
        String agentCriteria = XMLUtil.getAttribute(eleReprocessRec, "AgentCriteria");
        if (agentCriteria.equalsIgnoreCase("TAXGEOCODE")){
          return;
          
        }
        eleReprocessRec.removeAttribute("AgentCriteria");
        
        if (!YFCCommon.isVoid(eleReprocessRec.getAttribute("RetryCount"))) {
            errorCount = Integer.parseInt(eleReprocessRec
                    .getAttribute("RetryCount"));
        }
        String sIsSuccess = eleReprocessRec.getAttribute("IsSuccess");
        String sReprocessReqKey = eleReprocessRec.getAttribute(KohlsPOCConstant.REPROCESS_REQ_KEY);
        String reprocessRecordsKeepFlag = YFSSystem.getProperty("reprocess.records.keep");
        // load the hashmap if empty
        if(requestUtilObj.propsFromCommonCode.isEmpty()) {
          requestUtilObj.loadPropsFromCommonCode(env,
              KohlsPOCConstant.COMMON_CODE_FOR_REPROCESS);
        }
        
        try {
            if(YFCCommon.isVoid(requestUtilObj.propsFromCommonCode
                    .get(strServiceName + ".MaxErrorCount"))) {
                throw new YFSException("Service "+strServiceName+" does not exist in the common code");
            }else{
                maxErrorCount = Integer.parseInt(requestUtilObj.propsFromCommonCode
                        .get(strServiceName + ".MaxErrorCount"));
            }
            
            logger.debug("Service Name is: "+ strServiceName);
            String currentDate = KohlsReprocessRequestUtil.getCurrSysDateAsString();
            
            logger.debug("Current Date time is: "+currentDate);
      // Add condition to check if the sysdate is greater than purgeDate
      // if purge then delete after checking ... else leave for process
         if(agentCriteria.equalsIgnoreCase("PURGE") ){
              SimpleDateFormat sdf = new SimpleDateFormat(
                  KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
              if ((KohlsReprocessRequestUtil.isAfter(currentDate, purgeDate)    && "Y".equalsIgnoreCase(sIsSuccess)) || !(KohlsReprocessRequestUtil.isAfter(sdf.format(KohlsDateUtil.addToDate(
                  sdf.parse(createts), Calendar.HOUR,
                  (thresholdDaysForUnprocessedInt*24))),currentDate ))) {
                logger.debug("It's time to delete the record " + sReprocessReqKey);
                requestUtilObj.deleteReprocessRecord(env, sReprocessReqKey);
              }
            }else if(agentCriteria.equalsIgnoreCase("PROCESSMSG")){


              if ((errorCount < maxErrorCount) && (sIsSuccess.equalsIgnoreCase("N"))) {
                  
                  Document inputMsg = fetchMessageToProcess(env,inDoc);
                  Element eleReprocessRequestRoot = inputMsg.getDocumentElement();
                  String message = eleReprocessRequestRoot.getAttribute("Message");
                  String isCompressed = eleReprocessRequestRoot.getAttribute("IsCompressed");
                  if(!YFCCommon.isVoid(isCompressed) && Utils.isTrue(isCompressed)) {
                    String uncompressedMessage = KohlsReprocessRequestUtil.decompressXML(message);
                    inputMsg = XMLUtil.getDocument(uncompressedMessage);
                  } else {
                    inputMsg = XMLUtil.getDocument(message);
                  }
                                    
                  if(logger.isDebugEnabled())
                      logger.debug("KohlsPoCReprocessAgent.executeJob --- input message to Service is "+ XMLUtil.getXMLString(inputMsg));
                  
                  if(eleReprocessRec.getAttribute(KohlsPOCConstant.IS_FLOW).equalsIgnoreCase("Y")){
                      logger.debug("Invoke the service for the record");
                      KOHLSBaseApi.invokeService(env, strServiceName, inputMsg);
                      logger.debug("Service invoked successfully. Updating the NextReporocessTS, PurgeDate"
                              + "and IsSucess");
                  }else{
                      logger.debug("Invoking the api for the record ");
                      KOHLSBaseApi.invokeAPI(env, strServiceName, inputMsg);
                      logger.debug("API invoked successfully. Updating the NextReporocessTS, PurgeDate"
                              + "and IsSucess");
                  }
                  if(YFCCommon.isVoid(reprocessRecordsKeepFlag))
                  {
                      requestUtilObj.deleteReprocessRecord(env, sReprocessReqKey);
                  }
                  else
                  {
                  String sNextReprocessTS = requestUtilObj.DEFAULT_DATE;
                      String sPurgeDate = requestUtilObj.calculatePurgeTimestamp(strServiceName);
                      sIsSuccess = "Y";
                      requestUtilObj.updateReprocessRecord(env, sReprocessReqKey, sNextReprocessTS, 
                          sPurgeDate, sIsSuccess, null);
                  }                  
              }else {
                  if(sIsSuccess.equalsIgnoreCase("N")){
                      logger.debug("Updating ReprocessDate to the future date and calculating the purge date");
                      String sPurgeDate = requestUtilObj.calculatePurgeTimestamp(strServiceName);
                      String sNextReprocessTS = requestUtilObj.DEFAULT_DATE;
                      requestUtilObj.updateReprocessRecord(env, sReprocessReqKey, sNextReprocessTS, 
                              sPurgeDate, sIsSuccess, null);
                  }else{
                      String sNextReprocessTS = requestUtilObj.calculateNextReprocessTimestamp(strServiceName);
                      requestUtilObj.updateReprocessRecord(env, sReprocessReqKey, sNextReprocessTS, 
                              null, sIsSuccess, null);
                  }
              }
          
          }

        } catch (Exception e) {
            logger.debug("Error while processing the execute job");
            e.printStackTrace();
            
            String sNextReprocessTS = requestUtilObj.calculateNextReprocessTimestamp(strServiceName);
            String sPurgeDate = requestUtilObj.calculatePurgeTimestamp(strServiceName);
            sIsSuccess = "N";
            int iNewErrorCount = errorCount + 1;
            
            if(iNewErrorCount < maxErrorCount){
                requestUtilObj.updateReprocessRecord(env, sReprocessReqKey, sNextReprocessTS, 
                        null, sIsSuccess, String.valueOf(iNewErrorCount));
            } else {
                sNextReprocessTS = KohlsReprocessRequestUtil.DEFAULT_DATE;
                requestUtilObj.updateReprocessRecord(env, sReprocessReqKey, sNextReprocessTS, 
                        sPurgeDate, sIsSuccess, String.valueOf(iNewErrorCount));
            }
        }

        logger.endTimer("KohlsPoCReprocessAgent.executeJob");
    }

 
    /**
     * @param env
     * @param inDoc
     * @param agentCriteria
     * @return
     * @throws Exception
     */
    public Document fetchRecordsToProcess(YFSEnvironment env, Document inDoc, String agentCriteria)
            throws Exception {
        logger.beginTimer("KohlsPoCReprocessAgent.fetchRecordsToProcess");

        String maxRecords = inDoc.getDocumentElement().getAttribute("NumRecordsToBuffer");
        
        String sColonyId = inDoc.getDocumentElement().getAttribute("ColonyId");
        
        String version = inDoc.getDocumentElement().getAttribute("Version");
        
        if(YFCCommon.isVoid(maxRecords)){
            maxRecords = "5000";
        }
        String sCurrentDate = KohlsReprocessRequestUtil.getCurrSysDateAsString();
        
        Document docServiceInput = YFCDocument.createDocument("KohlsReprocessRequest").getDocument();
        Element eleServiceInput = docServiceInput.getDocumentElement();
        if(!YFCCommon.isVoid(sColonyId)){
            eleServiceInput.setAttribute("ColonyId", sColonyId);
        }
        if(inDoc.getDocumentElement().hasAttribute("ServiceList"))
        {
            setQueryForServiceList(eleServiceInput,inDoc);
        }
        if(!YFCCommon.isVoid(version)){
          eleServiceInput.setAttribute("Version", version);
       } else if(!YFCCommon.isVoid(YFSSystem.getProperty("yfs.rollout.version"))) {
          eleServiceInput.setAttribute("Version", YFSSystem.getProperty("yfs.rollout.version"));
       }
        eleServiceInput.setAttribute("MaximumRecords", maxRecords);
        
        if(agentCriteria.equalsIgnoreCase("PROCESSMSG")){
          setQueryForBackendMessages(eleServiceInput,sCurrentDate);
        }else if(agentCriteria.equalsIgnoreCase("PURGE")){
          setQueryForPurgeRecords(eleServiceInput,sCurrentDate);
        } 
        Element eleLastMessage = XMLUtil.getChildElement(inDoc.getDocumentElement(), "LastMessage");
        if(!YFCCommon.isVoid(eleLastMessage)){
          Element eleLastKohlsReprocessRequest = XMLUtil.getChildElement(eleLastMessage, "KohlsReprocessRequest");
          String sLastReprocessRequestKey = eleLastKohlsReprocessRequest.getAttribute("ReprocessRequestKey");
          if(!YFCCommon.isVoid(sLastReprocessRequestKey)){
            eleServiceInput.setAttribute("ReprocessRequestKey", sLastReprocessRequestKey);
            eleServiceInput.setAttribute("ReprocessRequestKeyQryType", "GT");
          }
        }
        
        // Setting Order by clause
        Element eleOrderBy = XMLUtil.createChild(eleServiceInput, KohlsPOCConstant.E_ORDER_BY);
        Element eleAttribute = XMLUtil.createChild(eleOrderBy, KohlsPOCConstant.A_ATTRIBUTE);
        eleAttribute.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.REPROCESS_REQ_KEY);
        
        // Invoking List with columns - begin
        YFSContext ctx  = YFSContextManager.getInstance().getContextFor(env);
        
        // setting colony id for fact lookup
        if(!YFCCommon.isVoid(sColonyId)) {
          ctx.getPoolResolver().addFact("ColonyId", sColonyId);
        }
        
        PLTQueryBuilder qryBuilder = null;
        YFCElement input = YFCDocument.getDocumentFor(docServiceInput).getDocumentElement();
        KOHLS_Reprocess_RequestDBHome dbHome = KOHLS_Reprocess_RequestDBHome.getInstance();
        YFCQueryBuilder.EntityNode newNode = dbHome.getWhereClauseNodePS(ctx, input);
        
        String orderBy = dbHome.getOrderByClause(ctx, input);
        YFCQueryBuilder qb2 = new YFCQueryBuilder();
        qryBuilder = qb2.getWhereClausePS(newNode);
        List l = new ArrayList();
        YFCDocument listTemplate = YFCDocument.getDocumentFor(KohlsPOCConstant.REPROCESS_REQUEST_GET_JOBS_TEMPLATE);
        Set<String> columns = new HashSet<String>();
        
        // Getting Attributes from template for Select query
        YFCNodeList nlNodes = listTemplate.getDocumentElement().getChildNodes();
        for (int i=0; i<nlNodes.getLength(); i++) {
          YFCElement eleElement = (YFCElement)nlNodes.item(i);
          Map<String, String> templateAttributes = eleElement.getAttributes();
          for (String key : templateAttributes.keySet()) {
            columns.add(key);
          }
        }
        
        //Preparing output document
        YFCDocument outDocument = YFCDocument.createDocument();
        if (outDocument.getDocumentElement() == null) {
          outDocument.appendChild(outDocument.createElement(dbHome.getListXMLName()));
        }
        YFCElement retVal = outDocument.getDocumentElement();
        YFCElement template = null;
        if ((listTemplate != null)) {
              template = listTemplate.getDocumentElement().getChildElement(dbHome.getXMLName());
         }
        // Executing the Query 
        dbHome.listWithWhere(ctx, qryBuilder, orderBy, l, Integer.valueOf(maxRecords), columns);
        
        // Looping through Result set to prepare xml 
        logger.beginTimer("KohlsPoCReprocessAgent - Looping through Result set");
        for (Iterator i = l.iterator(); i.hasNext(); ) {
            YFCEntity entity = (YFCEntity)i.next();
            YFCElement el = entity.getXML(outDocument, template);
            retVal.appendChild(el);
        }
        logger.endTimer("KohlsPoCReprocessAgent - Looping through Result set");
        // Invoking List with columns - end
        
        logger.endTimer("KohlsPoCReprocessAgent.fetchRecordsToProcess");
        return outDocument.getDocument();
    }
    
    /**
     * Create By TKMACJT * 
     * @param eleServiceInput
     */
    private void setQueryForBackendMessages(Element eleServiceInput,String sCurrentDate) {
      eleServiceInput.setAttribute("IsSuccess", "N");
      eleServiceInput.setAttribute("NextReprocessTS", sCurrentDate);
      eleServiceInput.setAttribute("NextReprocessTSQryType", "LE");
    }
    
   /**
    * 
    * @param eleServiceInput
    * @param inputDoc
    */
    private void setQueryForServiceList(Element eleServiceInput,Document inputDoc) {
        logger.beginTimer("KohlsPoCReprocessAgent.setQueryForServiceList");
        String strServiceList = inputDoc.getDocumentElement().getAttribute("ServiceList");      
        if(!YFCCommon.isVoid(strServiceList))
        {
            String []services = strServiceList.split(",");
            if (services.length>1) {
                Element eleComplexQuery = XMLUtil.createChild(eleServiceInput, KohlsPOCConstant.E_COMPLEX_QUERY);
                Element eleAnd = XMLUtil.createChild(eleComplexQuery, KohlsPOCConstant.E_AND);
                eleComplexQuery.setAttribute(KohlsPOCConstant.A_OPERATOR, KohlsPOCConstant.AND);
                Element eleOr = XMLUtil.createChild(eleAnd, KohlsPOCConstant.E_OR);
                for (String serviceName : services) {
                    Element eleExp = XMLUtil.createChild(eleOr, KohlsPOCConstant.E_EXP);
                    eleExp.setAttribute(KohlsPOCConstant.A_NAME, "ServiceName");
                    eleExp.setAttribute(KohlsPOCConstant.A_VALUE, serviceName);
                    eleExp.setAttribute(KohlsPOCConstant.A_QRY_TYPE, KohlsConstants.EQ);
                }
            }
            else
            {
                eleServiceInput.setAttribute("ServiceName", strServiceList);
            }
        }   
        
         if(logger.isDebugEnabled())
         {
             logger.debug("KohlsPoCReprocessAgent.setQueryForServiceList --- output  from  setQueryForServiceList"+ XMLUtil.getElementXMLString(eleServiceInput));
         }
        logger.endTimer("KohlsPoCReprocessAgent.setQueryForServiceList");
    }
    
    /**
     * Create By TKMACJT * 
     * @param eleServiceInput
     * @throws Exception 
     * @throws DOMException 
     */
    private void setQueryForPurgeRecords(Element eleServiceInput,String sCurrentDate) throws DOMException, Exception {      
      eleServiceInput.setAttribute("PurgeDate", sCurrentDate);
      eleServiceInput.setAttribute("PurgeDateQryType", "LT");
      Element eleComplexQuery = XMLUtil.createChild(eleServiceInput,
              "ComplexQuery");
      eleComplexQuery.setAttribute("Operator", "OR");
      Element eleOr = XMLUtil.createChild(eleComplexQuery, "Or");
      Element expPurgeDate = XMLUtil.createChild(eleOr, "Exp");
      expPurgeDate.setAttribute("Name", "Createts");
      expPurgeDate.setAttribute("QryType", "LT");
      SimpleDateFormat sdf = new SimpleDateFormat(
          KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);     
      expPurgeDate.setAttribute("Value", sdf.format(KohlsDateUtil.addToDate(
          sdf.parse(KohlsReprocessRequestUtil.getCurrSysDateAsString()), Calendar.HOUR,
          -(thresholdDaysForUnprocessedInt*24))));
    }
    
    /**
     * Create By Supradeep * 
     * @param env
     * @param inDoc
     * @return
     * @throws Exception
     */
    private Document fetchMessageToProcess(YFSEnvironment env, Document inDoc)
            throws Exception {
        logger.beginTimer("KohlsPoCReprocessAgent.fetchMessageToProcess");
        Document docReprocessRequestInput = XMLUtil.createDocument("KohlsReprocessRequest");
        docReprocessRequestInput.getDocumentElement().setAttribute("ReprocessRequestKey", 
            inDoc.getDocumentElement().getAttribute("ReprocessRequestKey"));
        //Document outDoc = KOHLSBaseApi.invokeService(env, "KohlsGetReprocessRecordsListFromView", docReprocessRequestInput);
        Document outDoc = KOHLSBaseApi.invokeService(env,
                KohlsPOCConstant.SERVICE_GET_CUSTOM_REPROCESS_LIST_REQUEST,
                docReprocessRequestInput);
        Element eleReprocessRec = (Element) outDoc.getDocumentElement()
                .getElementsByTagName("KohlsReprocessRequest").item(0);
        Document docReprocessRec = XMLUtil
                .getDocumentForElement(eleReprocessRec);
        logger.endTimer("KohlsPoCReprocessAgent.fetchMessageToProcess");
        return docReprocessRec;
    }
}
