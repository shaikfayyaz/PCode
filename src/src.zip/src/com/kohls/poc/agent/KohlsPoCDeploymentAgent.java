package com.kohls.poc.agent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsDeploymentUtil;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCDeploymentAgent extends YCPBaseAgent {
	static Logger log = Logger.getLogger(KohlsPoCDeploymentAgent.class.getName());

	private static Statement stmt = null;
	Connection conn = null;
	String actionName = null;

	/*
	 * Get jobs to get list of jobs
	 */
	public List<Document> getJobs(YFSEnvironment env, Document inXML, Document lastMessageCreated) throws Exception {
		log.info("GetJobs started");
		List<Document> lstTask = new ArrayList<Document>();
		log.info("Input to getJobs" + XMLUtil.getXMLString(inXML));
		try {
			YFCElement eleRoot = YFCDocument.getDocumentFor(inXML).getDocumentElement();
			String sDataType = eleRoot.getAttribute(KohlsPOCConstant.A_DATA_TYPE);
			log.info("Action name in getJobs is " + sDataType);
			Document docExportJobs = YFCDocument.createDocument(KohlsPOCConstant.A_KOHLS_GET_JOB).getDocument();
			Element eleServiceInput = docExportJobs.getDocumentElement();
			eleServiceInput.setAttribute(KohlsPOCConstant.A_DATA_TYPE, sDataType);
			log.debug("Input to get getjobs is " + XMLUtil.getXMLString(docExportJobs));
			if (lastMessageCreated == null) {
				lstTask.add(docExportJobs);
			}
		} catch (Exception e) {
			log.error("Exception getJobs is " + e.toString());
			throw e;
		}
		return lstTask;
	}

	/*
	 *Execute jobs for all tasks
	 */
	public void executeJob(YFSEnvironment env, Document indoc) throws Exception {
		try {
			log.info("Input to executeJob" + XMLUtil.getXMLString(indoc));
			Element eleInDoc = indoc.getDocumentElement();
			actionName = eleInDoc.getAttribute(KohlsPOCConstant.A_DATA_TYPE);
			log.info("Action name in executeJob is " + actionName);
			YFSContext context = (YFSContext) env;
			if (actionName.equals(KohlsPOCConstant.A_SQL_LOAD)) {
				executeQuery(env);
				KohlsDeploymentUtil depUtil = new KohlsDeploymentUtil();
				depUtil.callModifyCache(env);
			}/*else if (actionName.equals(KohlsPOCConstant.STORE_OPERATION_TASK)){				
				KohlsStoreForceClose storeForceClose = new KohlsStoreForceClose();
				log.info("in STORE_OPERATION_TASK task");
				storeForceClose.fireQueryForOpenStores(context);
			} */
		} catch (Exception e) {
			YFCException exp = new YFCException(e);
			log.debug("Exception in execute job " + exp.getLastErrorCode() + exp.getContainedException().toString());
			throw e;
		}
	}

	/*
	 * Execute the sql query one by one
	 */
	public void executeQuery(YFSEnvironment env) throws Exception {
		log.info("Starting the Sql query execution");
		try {
			ArrayList<String> queryListFromFile = fileContent(KohlsPOCConstant.QUERY_FILE);
			YFSContext context = (YFSContext) env;
			conn = context.getDBConnection();
			stmt = conn.createStatement();
			for (String sqlQuery : queryListFromFile) {
				String errMsg = "";
				try {
					log.debug("Query being fired is " + sqlQuery);
					stmt.executeQuery(sqlQuery);
				} catch (SQLException ex) {
					errMsg = ex.getMessage();
					String[] er = errMsg.split(":");
					log.warn("Sql ORA code is " + er[0] + " and message is " + errMsg + " , ignored sql : " + sqlQuery);
					if (!(er[0].contains(KohlsPOCConstant.INDEX_ALREADY_EXIST_CODE) || er[0].contains(KohlsPOCConstant.COLUMN_LISTED_ALREADY)
 							|| er[0].contains(KohlsPOCConstant.RESOURCE_BUSY) || er[0].contains(KohlsPOCConstant.INDEX_DOES_NOT_EXIST))) {
						log.error("Query fired is" + sqlQuery);
						throw new YFCException("Exception in Sql queries " + ex);
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception in executeQuery " + e.getMessage());
			throw e;
		} finally {
			stmt.close();
			log.info("Closed the statement execution connection");
		}
	}

	/*
	 * Read the query from the file and return the array list
	 */
	public ArrayList<String> fileContent(String queryPath) throws Exception {
		File fl = new File(queryPath);
		BufferedReader br = new BufferedReader(new FileReader(fl));
		String readLine = "";
		ArrayList<String> queryList = new ArrayList<String>();
		StringBuilder sb = new StringBuilder();
		while ((readLine = br.readLine()) != null) {
			if (!readLine.contentEquals(KohlsPOCConstant.BACKWARD_SLASH)) {
				log.debug("Reading the line is " + readLine);
				sb.append(readLine);
			} else {
				queryList.add(sb.toString());
				log.debug("SQL statement is " + sb);
				// sb = new StringBuilder();
				sb.setLength(0);
				log.debug("SB content after clear is " + sb);
			}
		}
		br.close();
		return queryList;
	}

}
