package com.kohls.poc.agent;

import com.kohls.poc.data.kohlscash.KohlsPocKohlsCashFeedAPI;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.Document;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KohlsCashRestFeedAgent extends YCPBaseAgent {

    private final String RUN = "Run";
    private final String API_SVC_KOHLS_CASH_REST_FEED_SERVICE = "KohlsCashRestFeedService";
    private final String KOHLS_CASH_REST_FEED_START_TIME = "KC_FEED_START_TIME";
    private final String KOHLS_CASH_REST_FEED_END_TIME = "KC_FEED_END_TIME";

    private SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

    @Override
    public List<Document> getJobs(YFSEnvironment env, Document inDoc,
                                  Document lastMessageCreated) throws YFSException {

        Document docDoIt = YFCDocument.createDocument(RUN).getDocument();
        List<Document> docList = new ArrayList<>();
        docList.add(docDoIt);
        return docList;
    }

    @Override
    public void executeJob(YFSEnvironment yfsEnvironment, Document document) throws Exception {
        String startTime = YFSSystem.getProperty(KOHLS_CASH_REST_FEED_START_TIME);
        String endTime = YFSSystem.getProperty(KOHLS_CASH_REST_FEED_END_TIME);

        Date startDateTime = sdf.parse(startTime);
        Date endDateTime = sdf.parse(endTime);

        // The agent is set to run every 20 minutes, but we really only need it to run once a day.
        // We will set up a 21 minute maintenance window in the COP file with a start time and an end time.
        // Format - HH:mm:ss (24 hour)
        // ex: KC_FEED_START_TIME=03:00:00
        //     KC_FEED_END_TIME=03:21:00
        if(areWeInTheMaintenanceWindow(startDateTime, endDateTime)) {
            // The input document that we pass is meaningless, the service will not evaluate it.
            KohlsPocKohlsCashFeedAPI.invokeService(yfsEnvironment, API_SVC_KOHLS_CASH_REST_FEED_SERVICE, document);
        }
    }

    private boolean areWeInTheMaintenanceWindow(Date startTime, Date endTime) throws Exception {
        long start;
        long current;
        long end;

        Date now = new Date();
        String hours = String.valueOf(now.getHours());
        String mins = String.valueOf(now.getMinutes());
        String seconds = String.valueOf(now.getSeconds());
        String nowStr = String.format("%s:%s:%s", hours, mins, seconds);
        Date nowTime = sdf.parse(nowStr);

        // Compare long values to determine if we are before or after
        start = (startTime.getTime());
        current = (nowTime.getTime());
        end = (endTime.getTime());
        boolean isAfterStartTime = (current - start) > 0;
        boolean isBeforeEndTime = (end - current) > 0;

        return isAfterStartTime && isBeforeEndTime;
    }
}
