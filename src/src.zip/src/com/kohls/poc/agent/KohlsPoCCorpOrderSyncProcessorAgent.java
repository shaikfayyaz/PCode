package com.kohls.poc.agent;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCCorpOrderSyncProcessorAgent extends YCPBaseAgent {

	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsPoCCorpOrderSyncProcessorAgent.class.getName());
	public static final String FILE_NOT_FOUND = "File Not Found";
	/*
	 * Read the list of zip files from the server zip directory and iterate through each
	 * zip file to unzip it and place in to unzip directory
	 */

	public List<Document> getJobs(YFSEnvironment env, Document inXML, Document lastMessageCreated) throws Exception {
		ArrayList<Document> lstTask = new ArrayList<Document>();
		log.info("Getjob is inProgress");
		try {
			File dir = new File(KohlsPOCConstant.ZIP_DIR_CORP);
			if (!dir.exists()) {
				throw new YFCException(KohlsPOCConstant.ZIP_NOTEXIST_ERROR_MSG);
			}
			byte[] buffer = new byte[1024];
			FileInputStream fis;
			File[] files = dir.listFiles();
			log.debug("files.length is " + files.length);

			if ((files.length != 0) && (lastMessageCreated == null)) {
				log.debug("lastMessageCreated is null \n");
				for (File zipfile : files) {
					log.debug("File name is " + zipfile.getName());
					fis = new FileInputStream(zipfile);
					ZipInputStream zis = new ZipInputStream(fis);
					ZipEntry ze = zis.getNextEntry();
					log.debug("Unzipping the zip file : " + KohlsPOCConstant.UNZIP_DIR_CORP);
					while (ze != null) {
						Document docExportJobs = YFCDocument.createDocument("ExtractFiles").getDocument();
						Element eleServiceInput = docExportJobs.getDocumentElement();
						String fileName = ze.getName();
						File newFile = new File(KohlsPOCConstant.UNZIP_DIR_CORP + File.separator + fileName);
						log.debug("Unzipping to " + newFile.getAbsolutePath());
						new File(newFile.getParent()).mkdirs();
						FileOutputStream fos = new FileOutputStream(newFile);
						int len;
						while ((len = zis.read(buffer)) > 0) {
							fos.write(buffer, 0, len);
						}
						fos.close();
						zis.closeEntry();
						ze = zis.getNextEntry();

						// Add messages to process in Execute jobs
						eleServiceInput.setAttribute("FileName", fileName);
						eleServiceInput.setAttribute("FilePath", KohlsPOCConstant.UNZIP_DIR_CORP);
						log.debug("docExportJobs document to process XML " + XMLUtil.getXMLString(docExportJobs));
						lstTask.add(docExportJobs);
					}
					zis.closeEntry();
					zis.close();
					fis.close();

					// delete the Zip file after moving to UnZip folder
					zipfile.delete();
				}
			} else {
				log.debug("Zero files to Process");
				if (!YFCCommon.isVoid(lastMessageCreated)) {
					log.debug(
							"lastDocumentMessage when it is not nulls \n" + XMLUtil.getXMLString(lastMessageCreated));
				}
			}
		} catch (IOException e) {
			log.error("Error in unzipping " + e);
			throw e;
		} catch (Exception e) {
			log.error("Error in execute Job " + e.getStackTrace());
			throw e;
		}
		return lstTask;
	}

	/*
	 * Read the each file in unzipped directory and parse in to XML file. manageOfflineTransactionQForPOS
	 * API will be called for each file in the unzip directory
	 */
	public void executeJob(YFSEnvironment env, Document docExportJobs) throws Exception {
		log.info("Executejob is inProgress");
		Document docXMLLoadOfflineTable = null;
		Document docmanageOfflineTransQOutput = null;
		// Read from Files -- Execute jobs
		Element eleInDoc = docExportJobs.getDocumentElement();
		String FilePath = eleInDoc.getAttribute("FilePath");
		String FileName = eleInDoc.getAttribute("FileName");
		log.debug("FilePath and FileName \n" + FilePath + ", " + FileName);
		File f = new File(FilePath + KohlsPOCConstant.BACKWARD_SLASH + FileName);
		try {
			if (!f.exists()) {
				log.debug("File Not Found");
				raiseExceptionforOrderSync(env, f, FILE_NOT_FOUND,"");
			} else {
				log.debug("File Name " + f.getName());
				docXMLLoadOfflineTable = SCXmlUtil.getDocumentBuilder().parse(f);
				log.debug("docXMLLoadOfflineTable input \n" + XMLUtil.getXMLString(docXMLLoadOfflineTable));

				if (!YFCCommon.isVoid(docXMLLoadOfflineTable)) {
					docmanageOfflineTransQOutput = KohlsCommonUtil.invokeAPI(env,
							KohlsPOCConstant.API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS, docXMLLoadOfflineTable);
					log.debug("Input to manageOfflineTransactionQForPOS " + SCXmlUtil.getString(docmanageOfflineTransQOutput));
				}
				/*if (YFCCommon.isVoid(docmanageOfflineTransQOutput)) {
					String errorMessage = KohlsPOCConstant.VOID_ERROR + ":" + f.getName() + ":"
							+ KohlsPOCConstant.ERROR_DIR_CORP	;
					String errorDesc =errorMessage;
					raiseExceptionforOrderSync(env, f, errorMessage,errorDesc);
					
				}
				else {
					logger.debug("docmanageOfflineTransQOutput input \n" + XMLUtil.getXMLString(docmanageOfflineTransQOutput));
				}*/
				// delete the file post completion
				f.delete();
			}
		} catch (Exception ex) {
			log.error("Error in execute Job " + ex.getStackTrace());
			String errorMessage = getExceptionStacktraceToString(ex);
			String errorDesc = ex.getMessage();
			raiseExceptionforOrderSync(env, f, errorMessage,errorDesc);
		}
	}

	/**
	 * 
	 * @param env
	 * @param file
	 * @param errorMessage
	 *            This method will raise an OMS alert,write the error to log
	 *            file,move the culprit file to error directory and generate the
	 *            error log file in error directory
	 * @throws Exception 
	 */
	private void raiseExceptionforOrderSync(YFSEnvironment env, File file, String errorMessage, String errorDesc)
			throws Exception {
		// Move file to error directory
		if (!FILE_NOT_FOUND.equals(errorMessage)) {
			final String Filename = file.getName();
			//String strNewFileName = Filename.substring(0, Filename.lastIndexOf(".") - 1);
			String strNewFileName = Filename.substring(0, Filename.lastIndexOf("."));
			String newErrorDir = KohlsPOCConstant.ERROR_DIR_CORP + KohlsPOCConstant.BACKWARD_SLASH
					+ Filename.substring(0, Filename.lastIndexOf(".")).split("_")[1];
			//String newErrorDir = KohlsPOCConstant.ERROR_DIR_CORP + KohlsPOCConstant.BACKWARD_SLASH + strNewFileName;
			log.info("strNewFileName is " + strNewFileName + " newErrorDir is " + newErrorDir );
			File newFolder = new File(newErrorDir);
			if (!newFolder.exists()) {
				newFolder.mkdirs();
				log.info("Creating the directory " + newFolder.getAbsolutePath());
				newFolder.setExecutable(true);
				newFolder.setReadable(true);
				newFolder.setWritable(true);
			}
				file.renameTo(new File(newErrorDir, file.getName()));
				log.error("Error message is " + errorMessage);
				// Create error log in the error directory
				String finalFileName = newErrorDir + KohlsPOCConstant.BACKWARD_SLASH + strNewFileName
						+ KohlsPOCConstant.DOT + KohlsPOCConstant.LOG_EXTENSION;
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				Document docError = dbf.newDocumentBuilder().newDocument();
				Element eleErrors = docError.createElement(KohlsPOCConstant.E_ERRORS);
				docError.appendChild(eleErrors);
				Element eleError = docError.createElement(KohlsPOCConstant.E_ERROR);
				Element eleStack = docError.createElement(KohlsPOCConstant.A_STACK);
				eleStack.setTextContent(errorMessage);
				eleErrors.appendChild(eleError);
				eleError.appendChild(eleStack);
				// Set the custom error code and error description
				eleError.setAttribute(KohlsPOCConstant.A_ERROR_CODE, "SFTPErr002");
				eleError.setAttribute(KohlsPOCConstant.A_ERROR_DESCRIPTION, errorDesc);
				eleError.setAttribute("ErrorDirPath", KohlsPOCConstant.ERROR_DIR_CORP);
				int index = file.getName().lastIndexOf("_");
				int indexDot = file.getName().lastIndexOf(".");
				log.debug("Error message is " + index + ", " + indexDot );
				//eleError.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, file.getName().substring(index + 1, indexDot - 1));
				eleError.setAttribute(KohlsPOCConstant.ATTR_STORE_ID, file.getName().substring(index + 1, indexDot));
				BufferedWriter bw1 = new BufferedWriter(new FileWriter(finalFileName));
				log.debug("Error message is " + SCXmlUtil.getString(docError) );
				bw1.write(SCXmlUtil.getString(docError));
				bw1.close();
			//}
		}
		// Make Alert
		Document createExceptionInput = SCXmlUtil.createDocument(KohlsPOCConstant.E_Inbox);
		createExceptionInput.getDocumentElement().setAttribute(KohlsPOCConstant.ExceptionType, "ORDER_SYNC_CORP");
		createExceptionInput.getDocumentElement().setAttribute(KohlsPOCConstant.A_Queue_Id, "OrderSyncCorpQ");
		Element EleInboxReferencesList = SCXmlUtil.createChild(createExceptionInput.getDocumentElement(),
				KohlsPOCConstant.E_InboxReferencesList);
		if (!FILE_NOT_FOUND.equals(errorMessage)) {
			Element EleInboxReferences = SCXmlUtil.createChild(EleInboxReferencesList,
					KohlsPOCConstant.E_InboxReferences);
			EleInboxReferences.setAttribute(KohlsPOCConstant.A_NAME, file.getName());
			EleInboxReferences.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);
			EleInboxReferences.setAttribute(KohlsPOCConstant.A_VALUE, KohlsPOCConstant.ERROR_DIR_CORP);
		} else {
			Element EleInboxReferences2 = SCXmlUtil.createChild(EleInboxReferencesList,
					KohlsPOCConstant.E_InboxReferences);
			EleInboxReferences2.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.ErrorMessage);
			EleInboxReferences2.setAttribute(KohlsPOCConstant.ReferenceType, KohlsPOCConstant.TEXT);
			EleInboxReferences2.setAttribute(KohlsPOCConstant.A_VALUE, errorMessage);

		}
		log.debug("createExceptionInput \n" + XMLUtil.getXMLString(createExceptionInput));
		try {
			Document createExceptionOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.CREATE_EXP_API,
					createExceptionInput);
			log.debug("createExceptionOutput \n" + XMLUtil.getXMLString(createExceptionOutput));
		} catch (Exception ex) {
			log.error("Void response While Executing the manageOfflineTransactionQForPOS" + ":"
					+ KohlsPOCConstant.ERROR_DIR_CORP + ":" + file.getName());
			log.error(ex.getMessage());
		}
	}
		/**
		 * @param ex
		 * @return
		 */
	private String getExceptionStacktraceToString(Exception ex) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		ex.printStackTrace(ps);
		String errorMessage = baos.toString();
		ps.close();
		return errorMessage;
	}

}
