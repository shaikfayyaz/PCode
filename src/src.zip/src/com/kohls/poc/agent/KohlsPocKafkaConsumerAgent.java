package com.kohls.poc.agent;

import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.agent.process.AltSkuProcessor;
import com.kohls.poc.util.KohlsPoCKafkaUtil;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.List;

/**
 * Created by tkma36l on 3/10/21.
 */
public class KohlsPocKafkaConsumerAgent extends YCPBaseAgent {

    private static final YFCLogCategory logger = YFCLogCategory.instance(KohlsPocKafkaConsumerAgent.class);
    private static final String DEFAULT_FEED_TYPE = "DELTA";


    /**
     * This method will fetch all the records to be processed by executeJobs()
     *
     * @param env
     * @param inDoc
     * @param lastMessageCreated
     * @return
     * @throws YFSException
     */

    public List<Document> getJobs(YFSEnvironment env, Document inDoc,
                                  Document lastMessageCreated) throws YFSException {

        String processName = null;

        // Get the ProcessName from inDoc and pass it to KohlsPoCKafkaUtil
        // call the runConsumer method in KohlsPoCKafkaUtil
        // return the list of document

        if (null != lastMessageCreated) {
            return null;
        }


        try {

            logger.beginTimer("KohlsPocKafkaConsumerAgent.getJobs");

            logger.info("KohlsPocKafkaConsumerAgent.getJobs--GetJobs started Processing records");

            if (logger.isDebugEnabled()) {
                logger.debug("KohlsPocKafkaConsumerAgent.getJobs --- Input to getJobs"
                        + XMLUtil.getXMLString(inDoc));
            }

            Element messageXmlEle = KohlsXPathUtil.getElementByXpath(inDoc, "/Message/AgentDetails/MessageXml");

            if (messageXmlEle == null) {
                messageXmlEle = inDoc.getDocumentElement();
            }

            processName = XMLUtil.getAttribute(messageXmlEle, "ProcessName");
            if (YFCCommon.isVoid(processName)) {
                logger.error("Configuration error:  No process name was specified in agent criteria");
                return null;
            }

            String feedType = XMLUtil.getAttribute(messageXmlEle, "FeedType");
            if (YFCCommon.isVoid(feedType))
                feedType = DEFAULT_FEED_TYPE;


            KohlsPoCKafkaUtil kohlsPoCKafkaUtil = new KohlsPoCKafkaUtil(processName);

            return kohlsPoCKafkaUtil.runConsumer(feedType);

        } catch (Exception e) {
            logger.error("KohlsPocKafkaConsumerAgent get Jobs", e);
            throw new YFCException(e, "KAFKA_" + processName, e.getMessage());
        } finally {
            logger.info("KohlsPocKafkaConsumerAgent.getJobs-- DONE");
            logger.endTimer("KohlsPocKafkaConsumerAgent.getJobs");
        }
    }

    /**
     * @param yfsEnvironment
     * @param document
     * @throws Exception
     */

    @Override
    public void executeJob(YFSEnvironment yfsEnvironment, Document document) throws Exception {

        //For each Document, loop through the records
        //Check the Document Element for ProcessType like AlternateSkuDataLoad and call the appropriate
        // processor class

        logger.beginTimer("KohlsPocKafkaConsumerAgent.executeJob");
        logger.info("KohlsPocKafkaConsumerAgent.executeJob--Execute Job started");
        try {

            Element documentElement = document.getDocumentElement();
            String tagName = documentElement.getTagName();
            if ("AltSkuMapEntries".equals(tagName)) {

                AltSkuProcessor processor = new AltSkuProcessor(yfsEnvironment);
                processor.process(document);
            }

        } finally {
            logger.info("KohlsPocKafkaConsumerAgent.executeJob--Execute Job ended");
            logger.endTimer("KohlsPocKafkaConsumerAgent.executeJob");
        }

    }

}
