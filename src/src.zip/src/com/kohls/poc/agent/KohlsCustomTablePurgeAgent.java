package com.kohls.poc.agent;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.tgcs.tcx.gravity.util.StringUtils;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

import edu.emory.mathcs.backport.java.util.Collections;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class KohlsCustomTablePurgeAgent extends YCPBaseAgent {
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsCustomTablePurgeAgent.class);
	ArrayList aDocList = new ArrayList();


	static Map<String, Document> lastProcessedMessage = Collections
			.synchronizedMap(new LinkedHashMap<String, Document>());

	public List<Document> getJobs(YFSEnvironment env, Document criteria,
			Document lastMessageCreated) {
		YFCDocument inpCrit = null;
		YFCElement inpCritElem = null;
		YFSContext ctx = null;
		String leadDays = "";
		String rootEle = "";
		String getPurgeJobListServiceName = "";
		String deletePurgeJobListServiceName = "";
		String servPrimaryKey = "";
		String customTableGroupId = "";
		if (logger.isVerboseEnabled()) {
			logger.verbose("getPurgeJobs : Input variables : criteria : "
					+ YFCDocument.getDocumentFor(criteria).getString());
		}

		inpCrit = YFCDocument.getDocumentFor(criteria);

		inpCritElem = inpCrit.getDocumentElement();

		customTableGroupId = StringUtils.hasText(inpCritElem
				.getAttribute("CustomTableGroupId")) ? inpCritElem
				.getAttribute("CustomTableGroupId") : "CustomTableGroupA";

		String[] tablesNames = inpCritElem.getAttribute("TablesName")
				.split(",");

		try {
			ctx = (YFSContext) env;

			String colony = StringUtils.hasText(inpCritElem
					.getAttribute("ColonyId")) ? inpCritElem
					.getAttribute("ColonyId") : "DEFAULT";
			ctx.getPoolResolver().addFact("ColonyId", colony);

			Document commonCodeRetDays = callGetCommonCodeList(env,
					customTableGroupId);

			for (int y = 0; y < tablesNames.length; y++) {

				String tableName = tablesNames[y];

				logger.info("table names" + tableName);
				System.out.println("table names sop" + tableName);
				Element eleCommonCodeOp = commonCodeRetDays
						.getDocumentElement();
				NodeList nlCommonCode = null;
				try {
					nlCommonCode = KohlsXPathUtil.getNodeList(eleCommonCodeOp,
							"//CommonCodeList/CommonCode[@CodeShortDescription='"
									+ tableName + "']");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					throw e;
				}

				if (!YFCCommon.isVoid(nlCommonCode)
						&& nlCommonCode.getLength() > 0) {
					Element eleCommonCode = (Element) nlCommonCode.item(0);
					// Getting value of CodeShortDescription

					String[] longDesc = eleCommonCode.getAttribute(
							KohlsConstant.A_CODE_LONG_DESC).split("-");
					leadDays = longDesc[0];
					rootEle = longDesc[1];
					getPurgeJobListServiceName = longDesc[2];
					deletePurgeJobListServiceName = longDesc[3];
					servPrimaryKey = longDesc[4];

					logger.info("longDesc" + longDesc);
					logger.info("leadDays" + longDesc[0]);
					logger.info("rootEle" + longDesc[1]);
					logger.info("getPurgeJobListServiceName" + longDesc[2]);
					logger.info("deletePurgeJobListServiceName" + longDesc[3]);
					logger.info("servPrimaryKey" + longDesc[4]);

				}

				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DATE, Integer.parseInt("-" + leadDays));
				SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
				String purgeUntilDate = format1.format(cal.getTime());

				aDocList = createPurgeDocumentList(env, purgeUntilDate,
						lastMessageCreated, rootEle,
						getPurgeJobListServiceName,
						deletePurgeJobListServiceName, servPrimaryKey);

			}
		} catch (Exception ex) {
			logger.error("getPurgeJobs : Caught exception : " + ex.getMessage());
		}

		return aDocList;

	}

	private ArrayList createPurgeDocumentList(YFSEnvironment env, String date,
			Document lastMessageCreated, String rootEle,
			String getPurgeJobListServiceName,
			String deletePurgeJobListServiceName, String servPrimaryKey)
			throws Exception {
		Document odoc = XMLUtil.createDocument(rootEle);
		Element ele = odoc.getDocumentElement();
		
		//CPE-8036 - avoiding full table scans for transaction heavy tables
		//PST-6305 - Adding Createts for Purge based on createts.
		if(!YFCCommon.isVoid(servPrimaryKey) &&
				(servPrimaryKey.equalsIgnoreCase("OrderHeaderKey") || servPrimaryKey.equalsIgnoreCase("InboxKey")|| servPrimaryKey.equalsIgnoreCase("Createts"))) {
			ele.setAttribute(servPrimaryKey, date);
			ele.setAttribute(servPrimaryKey+"QryType","LT");
		} else {
		// retain old query  type
			ele.setAttribute("Modifyts", date);
			ele.setAttribute("ModifytsQryType", "LT");
		}
		String lastProcessedKeyValue="";
		if (lastProcessedMessage.get(rootEle) != null) {

			logger.info("lastMessageCreated"
					+ XMLUtil.getXMLString(lastProcessedMessage.get(rootEle)));

			List<Element> lastMessageCreatedList = XMLUtil
					.getElementsByTagName(lastProcessedMessage.get(rootEle)
							.getDocumentElement(), rootEle);
			lastProcessedKeyValue = lastMessageCreatedList.get(
					lastMessageCreatedList.size() - 1).getAttribute(
					servPrimaryKey);
			
			//PST-6305-Start
			if(servPrimaryKey.equalsIgnoreCase("Createts"))
			{
				ele.setAttribute("From" + servPrimaryKey, lastProcessedKeyValue);
				ele.setAttribute("To" + servPrimaryKey, date);
				ele.setAttribute(servPrimaryKey + "QryType", "DATERANGE");
			}
			else
			{
				/**Existing Flow**/
			ele.setAttribute(servPrimaryKey, lastProcessedKeyValue);
			//CPE-11933 : Changing the Query type to LT, else it deletes all the recent records which fall under lead days.
			ele.setAttribute(servPrimaryKey + "QryType", "LT");
			}
			//PST-6305-End
		}

		Element ele1 = XMLUtil.createElement(odoc, "OrderBy", "");
		Element ele2 = XMLUtil.createElement(odoc, "Attribute", "");
		ele2.setAttribute("Name", servPrimaryKey);
		//CPE-11933 : Changing the sort sequence to descending to fetch the next batch of records smaller than the last processed key.
		ele2.setAttribute("Desc", "Y");

		XMLUtil.appendChild(ele1, ele2);
		XMLUtil.appendChild(odoc.getDocumentElement(), ele1);

		logger.info("getPurgeList input" + XMLUtil.getXMLString(odoc));

		Document getDocListPurgeJob = KOHLSBaseApi.invokeService(env,
				getPurgeJobListServiceName, odoc);

		List<Element> executeProcessReqList = XMLUtil.getElementsByTagName(
				getDocListPurgeJob.getDocumentElement(), rootEle);

		
		
		
		logger.info("getPurgeJobs  output ::: "
				+ XMLUtil.getXMLString(getDocListPurgeJob));

		getDocListPurgeJob.getDocumentElement()
				.setAttribute("rootEle", rootEle);
		getDocListPurgeJob.getDocumentElement().setAttribute(
				"deletePurgeJobListServiceName", deletePurgeJobListServiceName);

		
		if (!YFCCommon.isVoid(getDocListPurgeJob)
				&& executeProcessReqList.size() > 0) {
			if(executeProcessReqList.size()==1&&!lastProcessedKeyValue.equals(""))
			{
				String executeProcessedKeyValue = executeProcessReqList.get(0).getAttribute(
						servPrimaryKey);
				if(!executeProcessedKeyValue.equals(lastProcessedKeyValue))
				{
					aDocList.add(getDocListPurgeJob);	
				}
			}
			else
			{
			aDocList.add(getDocListPurgeJob);
			}
		}
		return aDocList;
	}

	@Override
	public void executeJob(YFSEnvironment env, Document executionMessage) {
		logger.info("Begin purge" + XMLUtil.getXMLString(executionMessage));

		if (logger.isVerboseEnabled()) {
			logger.verbose("purge : Input doc is : "
					+ XMLUtil.getXMLString(executionMessage));
		}
		String rootEle = executionMessage.getDocumentElement().getAttribute(
				"rootEle");
		String deletePurgeJobListServiceName = executionMessage
				.getDocumentElement().getAttribute(
						"deletePurgeJobListServiceName");

		rootEle = executionMessage.getDocumentElement().getAttribute("rootEle");
		deletePurgeJobListServiceName = executionMessage.getDocumentElement()
				.getAttribute("deletePurgeJobListServiceName");
		try {

			@SuppressWarnings("unchecked")
			List<Element> eleList = XMLUtil.getElementsByTagName(
					executionMessage.getDocumentElement(), rootEle);

			logger.info("pURGE lIST nAME " + rootEle);

			for (int i = 0; i < eleList.size(); i++) {

				Document deletePurgeDoc = XMLUtil.createDocument(rootEle);
				XMLUtil.copyElement(deletePurgeDoc, eleList.get(i),
						deletePurgeDoc.getDocumentElement());

				try {
					if (i < eleList.size() - 1 || eleList.size() == 1) {
						logger.info("invoke Delete api document "
								+ XMLUtil.getXMLString(deletePurgeDoc)
								+ " deletePurgeJobListServiceName "
								+ deletePurgeJobListServiceName);

						KOHLSBaseApi.invokeService(env,
								deletePurgeJobListServiceName, deletePurgeDoc);
					}

					logger.info("Record Deleted");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					YFSException yfs = new YFSException();
					yfs.setErrorCode("Error During Purge");
					yfs.setErrorDescription("Error During Purge"
							+ e.getMessage());

					logger.info("YFS Exception", yfs);
				}

			}

			lastProcessedMessage.put(rootEle, executionMessage);

		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			YFSException yfs = new YFSException();
			yfs.setErrorCode("Error During Purge");
			yfs.setErrorDescription("Error During Purge" + e.getMessage());
			throw yfs;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			YFSException yfs = new YFSException();
			yfs.setErrorCode("Error During Purge");
			yfs.setErrorDescription("Error During Purge" + e.getMessage());
			throw yfs;
		}

	}

	private Document callGetCommonCodeList(YFSEnvironment env,
			String customTableGroupId) throws Exception {
		Document docOp = null;
		try {
			Document docIp = XMLUtil
					.createDocument(KohlsConstant.E_COMMON_CODE);
			Element eleIp = docIp.getDocumentElement();

			eleIp.setAttribute(KohlsConstant.A_CODE_TYPE, customTableGroupId);

			logger.info("docIp" + XMLUtil.getXMLString(docIp));

			docOp = KOHLSBaseApi.invokeAPI(env, "getCommonCodeList", docIp);
			logger.info("docIp" + XMLUtil.getXMLString(docOp));

		} catch (Exception e) {
			YFSException yfs = new YFSException();
			yfs.setErrorCode("Error During Purge");
			yfs.setErrorDescription("Error During Purge" + e.getMessage());
			throw yfs;
		}

		return docOp;
	}

}
