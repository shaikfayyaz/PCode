package com.kohls.poc.agent;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsFraudDataUtil;
import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCFAsyncTableUpdatesAgent extends YCPBaseAgent {



	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsCFAsyncTableUpdatesAgent.class);
	KohlsFraudDataUtil kohlsFraudDataUtil = new KohlsFraudDataUtil();
	Document outDocReturnResonCodeList=null;
	private String logDir = null;
	private List<Document> returnFraudDataList = new ArrayList<Document>();

	/**
	 * This method will fetch all the records to be processed by executeJobs()
	 * 
	 * @throws Exception
	 */
	public List<Document> getJobs(YFSEnvironment env, Document inDoc,
			Document lastMessageCreated) throws YFSException {

		if (null != lastMessageCreated) {
			return null;
		}

		try {
			logger.beginTimer("KohlsCFAsyncTableUpdatesAgent.getJobs");

			logger.info("KohlsCFAsyncTableUpdatesAgent.getJobs--GetJobs started Processing records");		

			if (logger.isDebugEnabled()) {
				logger.debug("KohlsCFAsyncTableUpdatesAgent.getJobs --- Input to getJobs"
						+ XMLUtil.getXMLString(inDoc));

			}
			Element messageXmlEle;

			messageXmlEle = KohlsXPathUtil.getElementByXpath(inDoc,
					"/Message/AgentDetails/MessageXml");

			if (null == messageXmlEle) {
				messageXmlEle = inDoc.getDocumentElement();
			}

			String agentCriteria = XMLUtil.getAttribute(messageXmlEle,
					KohlsPOCConstant.ACTION_GROUP_FLOWNAME);
			String fetchType = XMLUtil.getAttribute(messageXmlEle,
					KohlsPOCConstant.A_TYPE);
			
			logDir = XMLUtil.getAttribute(messageXmlEle,
					"LogDir");

			if(YFCCommon.isVoid(fetchType))
			{
				fetchType = KohlsPOCConstant.SYNC_DELTA;
			}

			logger.info("KohlsCFAsyncTableUpdatesAgent.getJobs Type of sync is "+fetchType);		
			if (!YFCCommon.isVoid(agentCriteria)
					&& KohlsPOCConstant.A_CF_AGENT
					.equalsIgnoreCase(agentCriteria)) {

				Document inputDoc = SCXmlUtil.createDocument("KohlsDefEdgHighRiskItemList");			
				inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_TYPE, fetchType);	
				inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.E_SOURCE,KohlsPOCConstant.A_CF_AGENT);	
				String topicFromAgentProps = messageXmlEle.getAttribute(
						KohlsPOCConstant.CF_KAFKA_TOPIC_OVERRIDE);
				if(!YFCCommon.isVoid(topicFromAgentProps))
				{
					inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.CF_KAFKA_TOPIC_OVERRIDE,
							topicFromAgentProps);	
				}
				logger.info("KohlsCFAsyncTableUpdatesAgent.getJobs Before calling the mos service to get details");		

				Document outDocFraudData = KOHLSBaseApi.invokeService(
						env, KohlsPOCConstant.A_CF_SERVICE,
						inputDoc);



				if(!YFCCommon.isVoid(outDocFraudData))
				{
					NodeList ndReturnList = outDocFraudData.getElementsByTagName(KohlsPOCConstant.KohlsDefEdgHighRiskItem);
					
					for (int i=0; i<ndReturnList.getLength();i++){
						Element ee = (Element) ndReturnList.item(i);	
						if(!YFCCommon.isVoid(logDir))
						{
							ee.setAttribute("LogDir",logDir);
						}
						((List<Document>) returnFraudDataList).add(KohlsXMLUtil.getDocumentForElement(ee));
						logger.debug("returnFraudDataList List is"+KohlsXMLUtil.getXMLString(returnFraudDataList.get(i)));

					}
				}
			} 

			logger.info("KohlsCFAsyncTableUpdatesAgent.getJobs-- DONE");	
			logger.endTimer("KohlsCFAsyncTableUpdatesAgent.getJobs");
			return returnFraudDataList;
		} catch (Exception e) {
			if(!YFCCommon.isVoid(logDir))
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			    String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
				Path filePath = Paths.get(logDir);
				if (Files.exists(filePath)) {
				String filePrefix = "OtherError_"+timestamp+".txt";
			    restApiutil.writeToFile("Other Error -->\n",e.getMessage(),
						filePrefix, logDir);
				}
			}
			logger.error("KohlsCFAsyncTableUpdatesAgent get Jobs");						
			throw new YFCException(e,"FRAUD_DATA_OTHER",e.getMessage());


		}

	}

	/**
	 * This method processes each record from getJobs()
	 * 
	 * @throws Exception
	 */
	KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
	
	public void executeJob(YFSEnvironment env, Document inDoc)
			throws YFSException {
		logger.beginTimer("KohlsCFAsyncTableUpdatesAgent.executeJob");
		try {
			
			logger.debug("KohlsCFAsyncTableUpdatesAgent.executeJob--Execute Job started");		
			String sDepartment = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_DEPTNBR);
			logDir = inDoc.getDocumentElement().getAttribute("LogDir");
			if (!YFCCommon.isVoid(inDoc)) {
				if(!"CF_KAFKA_OFFSET".equalsIgnoreCase(sDepartment))
				{
					kohlsFraudDataUtil.ValidateJsonData(inDoc)	;	
				}
				else
				{
					logger.info("Done processing all the messages. Updating the Offset.");			
				}

				NodeList ndlFraudDataList = inDoc
						.getElementsByTagName(KohlsPOCConstant.KohlsDefEdgHighRiskItem);
				if (ndlFraudDataList.getLength() > 0) {

					logger.debug("KohlsCFAsyncTableUpdatesAgent.executeJob--Invoking the modifyTable to update the table");		

					kohlsFraudDataUtil.modifyTable(inDoc, env);
				} 
			}

		}
		catch (Exception e) {
			if(!YFCCommon.isVoid(logDir))
			{				
				Path filePath = Paths.get(logDir);
				if (Files.exists(filePath)) {	
					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				    String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
					String sDepartment = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_DEPTNBR);
					String majClass = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_MAJOR_CLASS);
					String subClass = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_SUB_CLASS);
					String riskLevel = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.RISK_LEVEL);
				    String filePrefix = "CFError_"+timestamp+".txt";
				    restApiutil.writeToFile("Error while processing "+sDepartment+"|"+majClass+"|"+subClass+"|"+riskLevel+"--->\n",e.getMessage(),
							filePrefix, logDir);
				}
			}
			logger.error("KohlsCFAsyncTableUpdatesAgent.executejobs ----  Exception in executejobs");
			if (e.getClass().getName()
					.equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {
				
				throw new YFCException(e);

			}
			else{
				throw new YFCException(e,"FRAUD_DATA_OTHER",e.getMessage());

			}
		}
		logger.endTimer("KohlsCFAsyncTableUpdatesAgent.executeJob");

	}

}
