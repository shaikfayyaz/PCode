package com.kohls.poc.agent;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCMosUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsMosAsyncTableUpdatesAgent extends YCPBaseAgent {

	
	
	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsMosAsyncTableUpdatesAgent.class);
	KohlsPoCMosUtil kohlsMosUtil = new KohlsPoCMosUtil();
	Document outDocReturnResonCodeList=null;
	
	/**
	 * This method will fetch all the records to be processed by executeJobs()
	 * 
	 * @throws Exception
	 */
	public List<Document> getJobs(YFSEnvironment env, Document inDoc,
			Document lastMessageCreated) throws YFSException {

		if (null != lastMessageCreated) {
			return null;
		}

		try {
			List<Document> mosDataList = new ArrayList<Document>();
			logger.beginTimer("KohlsMosAsyncTableUpdatesAgent.getJobs");
			
			logger.info("KohlsMosAsyncTableUpdatesAgent.getJobs--GetJobs started Processing records");		

			if (logger.isDebugEnabled()) {
			logger.debug("KohlsMosAsyncTableUpdatesAgent.getJobs --- Input to getJobs"
					+ XMLUtil.getXMLString(inDoc));

			}
			Element messageXmlEle;

			messageXmlEle = KohlsXPathUtil.getElementByXpath(inDoc,
					"/Message/AgentDetails/MessageXml");

			if (null == messageXmlEle) {
				messageXmlEle = inDoc.getDocumentElement();
			}

			String agentCriteria = XMLUtil.getAttribute(messageXmlEle,
					KohlsPOCConstant.ACTION_GROUP_FLOWNAME);
			
			String fetchType = XMLUtil.getAttribute(messageXmlEle,
					KohlsPOCConstant.A_TYPE);
			
			if(YFCCommon.isVoid(fetchType))
			{
				fetchType = KohlsPOCConstant.SYNC_DELTA;
			}

			logger.info("KohlsMosAsyncTableUpdatesAgent.getJobs Type of sync is "+fetchType);		
			if (!YFCCommon.isVoid(agentCriteria)
					&& KohlsPOCConstant.A_KOHLS_MOS_DATA
							.equalsIgnoreCase(agentCriteria)) {
				
				Document inputDoc = SCXmlUtil.createDocument(KohlsPOCConstant.KOHLS_MOS_DATA);			
				inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_TYPE, fetchType);	
				inputDoc.getDocumentElement().setAttribute(KohlsPOCConstant.E_SOURCE,KohlsPOCConstant.A_KOHLS_MOS_DATA);	
				logger.info("KohlsMosAsyncTableUpdatesAgent.getJobs Before calling the mos service to get details");		

				Document ouDocMosData = KOHLSBaseApi.invokeService(
						env, KohlsPOCConstant.MOS_SERVICE,
						inputDoc);
				
				
				if(!YFCCommon.isVoid(ouDocMosData))
				{
					mosDataList=	kohlsMosUtil.toCheckUpdateOrCreate(null,ouDocMosData, env);
						

				}		
				
			} 
			if (logger.isDebugEnabled()) {
				logger.debug("returnList:"+mosDataList.toString());
			}
			logger.info("KohlsMosAsyncTableUpdatesAgent.getJobs-- DONE");	
			logger.endTimer("KohlsMosAsyncTableUpdatesAgent.getJobs");
			return mosDataList;
		} catch (Exception e) {
				logger.error("KohlsMosAsyncTableUpdatesAgent get Jobs");
				throw new YFCException(e,"MOS_OTHER",e.getMessage());
			
			
		}

	}

	/**
	 * This method processes each record from getJobs()
	 * 
	 * @throws Exception
	 */
	public void executeJob(YFSEnvironment env, Document inDoc)
			throws YFSException {
		 logger.beginTimer("KohlsMosAsyncTableUpdatesAgent.executeJob");
		try {
			logger.debug("KohlsMosAsyncTableUpdatesAgent.executeJob--Execute Job started");

			if (!YFCCommon.isVoid(inDoc)) {
				
				NodeList ndlMosDataList = inDoc
						.getElementsByTagName(KohlsPOCConstant.KOHLS_MOS_DATA);
				if (ndlMosDataList.getLength() > 0) {
					Element rootEle = inDoc.getDocumentElement();
					String skuNbr = rootEle.getAttribute(KohlsPOCConstant.A_SKUNBR);
					if(KohlsPOCConstant.MOS_KAFKA_OFFSET.equalsIgnoreCase(skuNbr))
					{
						
						logger.info("Done processing all the messages. Updating the Offset.");			
					}
					logger.debug("KohlsMosAsyncTableUpdatesAgent.executeJob--Invoking the modifyTable to update the table");		

					kohlsMosUtil.modifyTable(env, inDoc);
				} 
			}

		} catch (Exception e) {
			logger.error("KohlsMosAsyncTableUpdatesAgent.executejobs ----  Exception in executejobs");
			throw new YFCException(e,"MOS_OTHER",e.getMessage());
		
		}
		 logger.endTimer("KohlsMosAsyncTableUpdatesAgent.executeJob");

	}

}
