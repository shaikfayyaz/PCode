package com.kohls.poc.DM;

import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsDMAuditHistoryUpdate {
	
	private static YFCLogCategory logger;

	static {
 		logger = YFCLogCategory.instance(KohlsDMAuditHistoryUpdate.class.getName());
	}
	 /**
		 * This method will check the deleted lines from customer service/EE/Returns 
		 *  for DM and form input to DMwrapper class.
		 * 
		 * @param inDoc
		 * @return
		 */
		
		public Document KohlsPrepareInputForDMAH(YFSEnvironment env, Document inDoc) throws Exception{
			logger.debug("KohlsDMAuditHistoryUpdate.KohlsPrepareInputForDMAH ");
			Document outDoc= null;
			boolean callDMWebservice = false;
			String comingFromLoadOffline = null;
			Element eleOrderDtl = null;
			 if (!YFCCommon.isVoid(inDoc)) {
				 Element inEle = inDoc.getDocumentElement();
				 comingFromLoadOffline = inEle.getAttribute("ComingFromLoadOffline");
				 String sInNode  = inEle.getNodeName();
				 
				 outDoc = KohlsXMLUtil.createDocument(KohlsPOCConstant.VOID_DM_AH_LIST);
			     Element eleDMAHList = outDoc.getDocumentElement();
			     eleDMAHList.setAttribute(KohlsPOCConstant.E_SOURCE, KohlsPOCConstant.ELE_VOID_AUDITHISTORY);
				 
			   
				 if(KohlsPOCConstant.ELEM_ORDER.equalsIgnoreCase(sInNode)){
					 
					
					 if("Y".equalsIgnoreCase(comingFromLoadOffline))
				     {
						 eleOrderDtl = inDoc.getDocumentElement();
				     }
					 else
					 {
						 String sOHK = inEle.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY); 
						 eleOrderDtl = callGetOrderList(env,sOHK);
					 } 
					if(!YFCCommon.isVoid(eleOrderDtl))
					{
						 logger.debug("eleOrderDtl "+SCXmlUtil.getString(eleOrderDtl));					
						 String sOrgCode= eleOrderDtl.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
						 String sTerminalID= eleOrderDtl.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
						 String sTranNo= eleOrderDtl.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NO);
						 Element eleOrderExtn = (Element) XMLUtil.getElementsByTagName(eleOrderDtl, KohlsPOCConstant.A_EXTN).get(0);
						 String sVoidDuring= eleOrderExtn.getAttribute(KohlsPOCConstant.A_EXTN_IS_VOID_DURING);
						 @SuppressWarnings("unchecked")
						 List<Element> orderLineList =  XMLUtil.getElementsByTagName(eleOrderDtl, KohlsPOCConstant.E_ORDER_LINE);
						 
						 for (Element orderLine : orderLineList) {
			    	        String orderedQty = orderLine.getAttribute(KohlsXMLLiterals.A_ORDERED_QUANTITY);
			    	        Element eleDMAddnlData = (Element) XPathUtil.getNode(orderLine,
			    	                "Extn/OrderLineAddnlDataList/OrderLineAddnlData[@Name='DispositionDetails']");
			    	        // DM-1373 Max line status coming back as "" for voided items
			    	        Element eleItem = (Element) XMLUtil.getElementsByTagName(orderLine, KohlsPOCConstant.ELEM_ITEM).get(0);
			    	        if ((0.00D == Double.parseDouble(orderedQty) 
			    	        		|| KohlsPOCConstant.YES.equalsIgnoreCase(sVoidDuring) )
			    	        		&& !YFCCommon.isVoid(eleDMAddnlData)) {
			    	        	String value = eleDMAddnlData.getAttribute(KohlsPOCConstant.A_VALUE);
			    	        	Document itemDoc = XMLUtil.getDocument(value);
			    	        	Element itemEle = itemDoc.getDocumentElement();
			    	        	Element eleDM = (Element) XMLUtil.getElementsByTagName(itemEle, KohlsPOCConstant.DISPOSITION_DETAILS).get(0);
			    	        	String sAuditID=  eleDM.getAttribute(KohlsPOCConstant.AUDIT_ID);
			    	        	if(YFCCommon.isVoid(sAuditID))
			    	        	{
			    	        		continue;
			    	        	}
			    	        	String sSKU = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
			    	        	eleDMAHList = createAuditHistoryDocument(eleDMAHList,sAuditID,sOrgCode
			    	        			,sSKU,sTerminalID,sTranNo);
			    	        	callDMWebservice = true;
			    	        }
			    	      }
					}
					 
				 }else if (KohlsPOCConstant.ELE_ADMIN_AUDIT.equalsIgnoreCase(sInNode)){
					 
					 String sAdminAuditKey = inEle.getAttribute(KohlsPOCConstant.ATTR_ADMIN_AUDIT_KEY); 
					 Document adminAuditOut = callGetAdminAuditDetails(env,sAdminAuditKey);
					 
					 if(!YFCCommon.isVoid(adminAuditOut)){
						 logger.debug("adminAuditOut output "+XMLUtil.getXMLString(adminAuditOut));
						 Element adminAuditEle = adminAuditOut.getDocumentElement();
						 String sOrgCode = adminAuditEle.getAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
						 String sTerminalID = adminAuditEle.getAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID);
						 String sTranNo = adminAuditEle.getAttribute(KohlsPOCConstant.A_POS_SEQUENCE_NUMBER);
						 
						 Element eleAddnlData = (Element) XPathUtil.getNode(adminAuditEle,
			    	              "/AdminAudit/AdditionalDataList/AdditionalData[@Name='Summary']");
						 
						 if(!YFCCommon.isVoid(eleAddnlData)){
							 String value = eleAddnlData.getAttribute(KohlsPOCConstant.A_VALUE);
			    	         Document docATran = XMLUtil.getDocument(value);
			    	         logger.debug("docATran ::"+value);
			    	         Element auditTranEle = docATran.getDocumentElement();
			    	         Element eleSummary = (Element) XMLUtil.getElementsByTagName(auditTranEle, KohlsPOCConstant.ELE_SUMMARY).get(0);
			    	         String sAction = eleSummary.getAttribute(KohlsPOCConstant.A_ACTION);
			    	         if(KohlsPOCConstant.ATTR_TAX_A.equalsIgnoreCase(sAction)){
			    	        	 @SuppressWarnings("unchecked")
								List<Element> addtionalDataList =  XMLUtil.getElementsByTagName(adminAuditEle, KohlsPOCConstant.ELE_ADDITIONAL_DATA);
			    				 
			    				 for (Element additionalData : addtionalDataList) {
			    					 String sName = additionalData.getAttribute(KohlsPOCConstant.A_NAME);
			    					 if(!YFCCommon.isVoid(sName) && sName.contains("Item")){
			    						 
			    						 Document docValue = XMLUtil.getDocument(additionalData.getAttribute(KohlsPOCConstant.A_VALUE));
			    						 Element eleValue = docValue.getDocumentElement();
			    						 Element eleDetail = (Element) XMLUtil.getElementsByTagName(eleValue, KohlsPOCConstant.ELE_DETAIL).get(0);
			    						 Element eleDD = (Element) XMLUtil.getElementsByTagName(eleValue, KohlsPOCConstant.DISPOSITION_DETAILS).get(0);
			    		    	        
				    		    	      	String sAuditID=  eleDD.getAttribute(KohlsPOCConstant.AUDIT_ID);
						    	        	if(YFCCommon.isVoid(sAuditID))
						    	        	{
						    	        		continue;
						    	        	}
						    	        	String sSKU = eleDetail.getAttribute(KohlsPOCConstant.SKU);
			    						 eleDMAHList = createAuditHistoryDocument(eleDMAHList,sAuditID,
			    								 sOrgCode,sSKU,sTerminalID,sTranNo);
			    						 callDMWebservice= true;
			    					 }
			    				 }
			    	        }
						 }
					 }		 
				 }
				 			 
			 }
			if(callDMWebservice)
			{
				try
				{
					KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_CALLTO_DMWRAPPER, outDoc);
				}
				catch(Exception e)
				{
					if("Y".equalsIgnoreCase(comingFromLoadOffline))
					{
						// call reprocess request stuff
						Document reprocessDMAHDoc = SCXmlUtil.createDocument("Order");
						reprocessDMAHDoc.getDocumentElement().setAttribute("OrderHeaderKey",eleOrderDtl.getAttribute("OrderHeaderKey"));
						KohlsReprocessRequestUtil requestUtilObj = new KohlsReprocessRequestUtil();
						requestUtilObj.createReprocessRequestWithRetryCount(env, "KohlsPrepareInputForDMAH", reprocessDMAHDoc, "1");
					}
					else
					{
						throw e;
					}
					
				}
					//callDMWrapperClass.callDMAPI(env,outDoc);
			}
					
			logger.debug("final output :: "+XMLUtil.getXMLString(outDoc));
			return outDoc;
			
		}
		
		/**
		 * This method will form final input to DMWrapper 
		 * <UpdateDMAHList Source="AuditHistoryUpdate">
			<UpdateDMAH ItemID="<item id>" StatusCode="<hardcode to 3>" AuditID="<audit id from the order line>"
			 StoreNo="<seler organization code>"/>
			</UpdateDMAHList>
		 * @param eleDMAHList
		 * @param auditID
		 * @param sOrgCode
		 * @param sSKU
		 * @return
		 */
		
		public static Element createAuditHistoryDocument(Element eleDMAHList,String auditID,
				String sOrgCode,String sSKU,String sTerminalID, String sTranNo){
			
			logger.debug("KohlsDMAuditHistoryUpdate.createAuditHistoryDocument");
			Element eleDMAuditHistory = KohlsXMLUtil.createChild(eleDMAHList,KohlsPOCConstant.ELE_VOID_AUDITHISTORY);
	    	eleDMAuditHistory.setAttribute(KohlsPOCConstant.AUDIT_ID, auditID);
	    	eleDMAHList.setAttribute(KohlsPOCConstant.STORE_NO, sOrgCode);
	    	eleDMAHList.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, sTerminalID);
	    	eleDMAHList.setAttribute(KohlsPOCConstant.A_TRANSACTION_NO, sTranNo);
        	eleDMAuditHistory.setAttribute(KohlsPOCConstant.ATTR_ITEMID, sSKU);
        	logger.debug("KohlsDMAuditHistoryUpdate.createAuditHistoryDocument");
	    	return eleDMAHList;
		}
		
		/**
		 * This method is to get the audit details with auditKey
		 * @param sAAK
		 * @return
		 * @throws Exception 
		 */
		
		public static Document callGetAdminAuditDetails(YFSEnvironment env,String sAAK) throws Exception{
			logger.beginTimer("KohlsDMAuditHistoryUpdate.callGetAdminAuditDetails");
			Document outOrderDetails = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELE_ADMIN_AUDIT);
		    Element eleInputOrder = outOrderDetails.getDocumentElement();
		    eleInputOrder.setAttribute(KohlsPOCConstant.ATTR_ADMIN_AUDIT_KEY, sAAK);
		      
		    logger.debug("input to audit details ::"+XMLUtil.getXMLString(outOrderDetails));
		    outOrderDetails = KOHLSBaseApi.invokeAPI(env, 
		    		  KohlsPOCConstant.API_GET_ADMIN_AUDIT_DETAILS, outOrderDetails);
		    logger.endTimer("KohlsDMAuditHistoryUpdate.callGetAdminAuditDetails"); 
			 return outOrderDetails;
		}
		
		/**
		 * This method is to get the orderDetails with OrderHeaderKey
		 * @param sOrderHeaderKey
		 * @return
		 * @throws Exception 
		 */
		
		public static Element callGetOrderList(YFSEnvironment env,String sOrderHeaderKey) throws Exception{
			logger.beginTimer("KohlsDMAuditHistoryUpdate.callGetOrderList");
			Document outOrderList = null;
			Element eleOrderDtl = null;
			outOrderList = KohlsXMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
			Element eleInputOrder = outOrderList.getDocumentElement();
			eleInputOrder.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
			eleInputOrder.setAttribute(KohlsPOCConstant.A_MAXIMUM_RECORDS, KohlsPOCConstant.STRING_ONE);    
			logger.debug("input to getOrder list ::"+XMLUtil.getXMLString(outOrderList));
			if(!YFCCommon.isVoid(sOrderHeaderKey))
			{
				outOrderList = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.ORDERLIST_DM_VOID_HISTORY_TEMPLATE,
			    		  KohlsPOCConstant.API_GET_ORDER_LIST, outOrderList);
				eleOrderDtl = SCXmlUtil.getChildElement(outOrderList.getDocumentElement(),KohlsPOCConstant.E_ORDER);
			}      
			
			logger.endTimer("KohlsDMAuditHistoryUpdate.callGetOrderList");
			return eleOrderDtl;
		}
		

}