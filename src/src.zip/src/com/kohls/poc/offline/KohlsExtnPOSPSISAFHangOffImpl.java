package com.kohls.poc.offline;

import com.tgcs.tcx.gravity.nrsc.kohls.pos.offline.hangoff.impl.KohlsPOSPSISAFHangOffImpl;
import com.tgcs.tcx.gravity.pos.order.POSOrderConsts;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.dom.YFCNode;
import com.yantra.yfc.dom.YFCNodeList;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfs.japi.YFSEnvironment;

 
public class KohlsExtnPOSPSISAFHangOffImpl extends KohlsPOSPSISAFHangOffImpl
{            
   
    private static final YFCLogCategory logger                         = YFCLogCategory.instance( KohlsExtnPOSPSISAFHangOffImpl.class.getName() );
     
      public static final String          GET_ORDER_DETAIL_API_TEMPLATE  = "OrderDetailSAF";
      public static final String          GET_ORDER_DETAIL_API           = "getOrderDetails";
      public static final String          GET_SAF_ENTRY_LIST_FOR_POS_API = "getSAFEntryListForPOS";
      public static final String          STORED_VALUE_LINE_KEY          = "StoredValueLineKey";
      YIFApi                              api                            = null;

      private final static String         MANAGE_SAF_ENTRY_API           = "manageSAFEntryForPOS";
      
      private final static String         SAF_ENTRY_LIST                 = "SAFEntryList";
      private static final String         POS_PSI_SAF_KEY                = "POSPSISAF_Key";
      
      public KohlsExtnPOSPSISAFHangOffImpl()
      {
         try
         {
            api = YIFClientFactory.getInstance().getApi();
            
         }
         catch ( Exception e )
         {
            logger.error( e );
         }
      }  
      
      /**
       * This method reads data from hangoff doc and updates with the new OrderHeaderKey.  It then 
       * invokes manageSAFEntryForPOS API to insert data into POS_PSI_SAF table.
       *  
       * SAF_ENTRY_INSERT_API indoc sample
       * <?xml version="1.0" encoding="UTF-8"?>
       *  <SAFEntry DeviceId="127.0.0.1" Operation="Create"
       *                OrderHeaderKey="2016030311065844971" PurgeDate="2016-04-02"
       *                SAFNum="4" SAFStatus="ELIGIBLE"/>
       */
      @Override   
      public void load( YFCDocument oldOrderDoc, YFCDocument newOrderDoc, YFCDocument hangOffDoc, YFSEnvironment env ) throws Exception
      {
         if ( YFCLogUtil.isDebugEnabled() )
         {
            logger.debug( "KohlsExtnPOSPSISAFHangOffImpl hangOffDoc  = " + hangOffDoc );
            logger.debug("newOrderDoc = " + newOrderDoc);
            logger.debug("oldOrderDoc = " + oldOrderDoc);
         }        
          
         YFCElement safList  = hangOffDoc.getDocumentElement().getChildElement( SAF_ENTRY_LIST ); 
         String new_orderHeaderKey = newOrderDoc.getDocumentElement().getAttribute( POSOrderConsts.ORDER_HEADER_KEY );
               if ( !YFCElement.isNull( safList ) && safList.hasChildNodes() )
               {
                  YFCNodeList<YFCNode> safentrys = safList.getChildNodes(); 
                  for ( YFCNode safeNode : safentrys)
                  {
                     YFCElement safe = (YFCElement) safeNode;
                     YFCDocument apiInpDoc = YFCDocument.createDocument( "SAFEntry" );
                     YFCElement apiInpEle = apiInpDoc.getDocumentElement();
                     apiInpEle.setAttribute( "OrderHeaderKey", new_orderHeaderKey );
                     apiInpEle.setAttribute( "DeviceId", safe.getAttribute( "DeviceId" ) ); 
                     apiInpEle.setAttribute( "Operation", safe.getAttribute( "Operation" ) ); 
                     String purgeDate =  safe.getAttribute( "PurgeDate" );
                     purgeDate = purgeDate.substring(0, purgeDate.lastIndexOf("-"));
                     apiInpEle.setAttribute( "PurgeDate", purgeDate); 
                     apiInpEle.setAttribute( "SAFNum", safe.getAttribute( "SAFNum" ) ); 
                     apiInpEle.setAttribute( "SAFStatus", safe.getAttribute( "SAFStatus" ) ); 
                     
                     if ( YFCLogUtil.isDebugEnabled() )
                     {
                        logger.debug( " apiInpDoc = " + apiInpDoc);
                     }
                     
                     api.invoke( env, MANAGE_SAF_ENTRY_API, apiInpDoc.getDocument() );
                    
                  }
               }  
      }
  
      @Override    
      public YFCDocument extract( YFCDocument inDoc, YFSEnvironment env ) throws Exception
      {         
    	  		return super.extract(inDoc, env);
      }

     
      /**
       * This method purges the POS_PSI_SAF table for the incoming order header key.
       */
      @Override
      public void purge( YFCDocument inDoc, YFSEnvironment env ) throws Exception
      {         
         super.purge(inDoc, env);
      }
     
}


