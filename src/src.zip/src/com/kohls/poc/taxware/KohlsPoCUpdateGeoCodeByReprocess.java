package com.kohls.poc.taxware;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.util.KohlsReprocessRequestUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCUpdateGeoCodeByReprocess extends KOHLSBaseApi {

  private final static YFCLogCategory logger =
      YFCLogCategory.instance(KohlsPoCUpdateGeoCodeByReprocess.class);

  private Properties props;

  /**
   * @throws Exception
   *
   * 
   */
  public Document processGeoCodeUpdate(YFSEnvironment env, Document inputDoc) throws Exception {
    logger.beginTimer("KohlsPoCUpdateGeoCodeByReprocess.processGeoCodeUpdate");


    /*
     * Create service for getOrgaList
     * 
     * <Organization ParentOrganizationCode="KOHLS-RETAIL" IsNode="Y" />
     * 
     * <Organization OrganizationKey="" />
     * 
     * String
     */

    String isMultiApiMode = props.getProperty("MultiApiMode");

    Document getOrganizationHierarchyInput =
        XMLUtil.getDocument("<Organization ParentOrganizationCode='KOHLS-RETAIL' IsNode='Y' />");
    Document getOrganizationHierarchyTemplate = XMLUtil.getDocument(
        "<OrganizationList><Organization OrganizationKey='' AssignedColonyId='' /></OrganizationList>");

    Document getOrganizationListOutput = KOHLSBaseApi.invokeAPI(env,
        getOrganizationHierarchyTemplate, "getOrganizationList", getOrganizationHierarchyInput);
    List<Element> orgList = XMLUtil
        .getElementsByTagName(getOrganizationListOutput.getDocumentElement(), "Organization");

    List excludeList = getExcludeStoresForGeoCodeUpdate(env);
    Document manageorgHierarchy = null;
    boolean callAPI = false;
    Document multiAPIDocForInsertingOrgUpdate = null;

    if ("Y".equalsIgnoreCase(isMultiApiMode)) {
      multiAPIDocForInsertingOrgUpdate = XMLUtil.createDocument("MultiApi");
    }

    for (Element org : orgList) {

      String store = org.getAttribute("OrganizationKey");
      String colony = org.getAttribute("AssignedColonyId");
      if (null != store && !excludeList.contains((String) store)) {
        callAPI = true;
        manageorgHierarchy = XMLUtil.createDocument("Organization");
        XMLUtil.setAttribute(manageorgHierarchy.getDocumentElement(), "OrganizationKey", store);
        if (!"Y".equalsIgnoreCase(isMultiApiMode)) {
          KohlsReprocessRequestUtil kohlsReprocessRequestUtil = new KohlsReprocessRequestUtil();
          kohlsReprocessRequestUtil.createReprocessRequest(env, "KohlsUpdateStoreTaxGeoCodeWS", manageorgHierarchy,
              colony);
        } else {
          Element manageorgHierarchyEle =
              multiAPIDocForInsertingOrgUpdate.createElement("Organization");
          XMLUtil.setAttribute(manageorgHierarchyEle, "OrganizationKey", store);
          Element apiEle = multiAPIDocForInsertingOrgUpdate.createElement("API");
          apiEle.setAttribute("FlowName", "CreateTaxGeoCodeTrigger");
          Element inputEle = multiAPIDocForInsertingOrgUpdate.createElement("Input");
          // XMLUtil.importElement(inputEle, org);
          inputEle.appendChild(manageorgHierarchyEle);
          apiEle.appendChild(inputEle);
          multiAPIDocForInsertingOrgUpdate.getDocumentElement().appendChild(apiEle);
          manageorgHierarchyEle = null;
        }
      }

    }
    if (callAPI && "Y".equalsIgnoreCase(isMultiApiMode)) {
      System.out.println(XMLUtil.getXMLString(multiAPIDocForInsertingOrgUpdate));
      Document multiAPIDocOutput =
          KOHLSBaseApi.invokeAPI(env, "multiApi", multiAPIDocForInsertingOrgUpdate);
    }
    logger.endTimer("KohlsPoCUpdateGeoCodeByReprocess.processGeoCodeUpdate");
    return inputDoc;

  }



  public static List getExcludeStoresForGeoCodeUpdate(YFSEnvironment env) throws YFSException {
    
    List excludeStoreList = new ArrayList();

    String strCodeShortDescription = null;
    Element eleCommonCode = null;
    Element elemCommonCode = null;
    Element eleDefault = null;
    Document docOutputForGetCommonCodeList = null;
    try {
      Document docInputForGetCommonCodeList = XMLUtil.createDocument(KohlsConstant.E_COMMON_CODE);
      Element eleInputForGetCommonCodeList = docInputForGetCommonCodeList.getDocumentElement();
      eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_CODE_TYPE, "ExcludeStoresGeoCode");
      eleInputForGetCommonCodeList.setAttribute(KohlsConstant.A_ORGANIZATION_CODE, "DEFAULT");
      docOutputForGetCommonCodeList = KOHLSBaseApi.invokeAPI(env,
          KohlsConstant.API_GET_COMMON_CODE_LIST, docInputForGetCommonCodeList);
      // Performance improvement changes - Start
      if (logger.isDebugEnabled()) {
        logger.debug(
            "Output of Common Code API :: " + XMLUtil.getXMLString(docOutputForGetCommonCodeList));
      }

      NodeList nlCommonCode =
          docOutputForGetCommonCodeList.getElementsByTagName(KohlsConstant.E_COMMON_CODE);
      for (int i = 0; i < nlCommonCode.getLength(); i++) {
        eleCommonCode = (Element) nlCommonCode.item(i);
        String strCodeValue = eleCommonCode.getAttribute(KohlsConstant.A_CODE_VALUE);
        excludeStoreList.add(strCodeValue);

      }
    } catch (ParseException e) {
      e.printStackTrace();
      throw new YFCException(e.getMessage());
    } catch (ParserConfigurationException e) {
      e.printStackTrace();
      throw new YFCException(e.getMessage());
    } catch (Exception e) {
      e.printStackTrace();
      throw new YFCException(e.getMessage());
    }
    return excludeStoreList;
  }
  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */

  public void setProperties(Properties prop) throws Exception {
    this.props = prop;    
  }
}
