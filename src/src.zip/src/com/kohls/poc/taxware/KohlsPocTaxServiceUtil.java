package com.kohls.poc.taxware;

// java imports
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSResourceUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**
 * ----------------------------------------------------------------------------
 * Class Name : KohlsPocTaxServiceUtil Description : This class is used to
 * construct OMS Taxware input xml using the values of APE response and invokes
 * Taxware service to retrieve the calculated tax information in an XML
 * document. ------------
 * ------------------------------------------------------------------
 * --------------------------------------------------
 * 
 * @author Suresh Midde
 * @version 1.1 changes : Updated Exception Handling block
 * @version 1.2 changes : Code for including Handler for Tax
 * @version 1.3 changes : Retrieving/Setting TaxGeoCode from/to
 *          Order/OrderLines/OrderLine/Shipnode/ShipNodePersonInfo/@TaxGeoCode
 * @version 1.4 changes : Retrieving TaxProductCode from
 *          Order/OrderLines/OrderLine/Extn/@ExtnTaxProductCode
 * @version 1.5 changes : Changing the attribute name to
 *          TaxExemptionCertification according to ICD
 * @version 1.6 changes : Updated the code to throw YFSException and removed unnecessary commented blocks
 * 
 * */
public class KohlsPocTaxServiceUtil extends KOHLSBaseApi {

	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsPocTaxServiceUtil.class.getName());
	
	//Added for Tax Exempt as part of Sprint-9.1.3 -- Start
	private static String taxExemptCertificate = null;
	private String taxFlag = "Y";
	//Added for Tax Exempt as part of Sprint-9.1.3 -- End

	private Properties props;

	// outputDocFromTaxware is the XML document , that contains calculated tax
	// details
	// from Taxware
	// response
	Document outputDocFromTaxware = null;

	// docOutXML is the XML document that is constructed based on
	// the inDoc
	// supplied from APE response
	Document docOutXML = null;

	// simulatedDocOutXML is the xml document, that is a simulated tax response
	Document simulatedDocOutXML = null;

	/**
	 * 
	 * Method Name : generateTaxwareXML Description : This method constructs OMS
	 * Taxware request xml from the indoc supplied and returns an xml document
	 * as a response from the taxware service
	 * 
	 * @param env
	 *            environment
	 * @param docInXML
	 *            APE response from KohlsPocOrderRepriceUserExitImpl
	 * @return outputDocFromTaxware an xml document with tax details
	 * @throws YFSUserExitException
	 * @throws ParserConfigurationException
	 * @throws ParseException
	 */
	public Document generateTaxwareXML(YFSEnvironment env, Document docInXML) throws YFSException,
			ParserConfigurationException, ParseException {

		log.debug(" Start of the method : generateTaxwareXML of KohlsPocTaxServiceUtil");
		if(log.isDebugEnabled()){
			log.debug("input XML to generateTaxwareXML:  " + XMLUtil.getXMLString(docInXML));
		}
		try {

			// reading enableTaxwareCall argument, which is set in the service
			// KohlsPocTaxServiceUtil
			String handle = props.getProperty("enableTaxwareCall");

			log.debug("Handle:" + handle);

			// if handler is enabled, process the xml indoc and sent to taxware
			// for calculated tax details
			if (!XMLUtil.isVoid(handle) && handle.equalsIgnoreCase("Y")) {

				log.debug("enableTaxwareCall Enabled....");

				// Read the inputDoc
				Element eleInDocOrder = docInXML.getDocumentElement();

				// Seetha commnt remove below two lines and add one function
				// createDocument

				// Instantiate inputDocToTaxware
				this.docOutXML = XMLUtil.newDocument();

				// Order
				Element eleOutDocOrder = this.docOutXML.createElement("Order");

				this.prepareOrderHeader(eleInDocOrder, eleOutDocOrder);

				// Order/OrderLines
				Element eleOutDocOrderLines = this.docOutXML.createElement("OrderLines");

				//this.prepareOrderLines(eleInDocOrder, eleOutDocOrder, eleOutDocOrderLines);

				// Order/OrderLines/OrderLine
				List nodeListOutDocOrderLine = XMLUtil.getElementsByTagName(eleInDocOrder, "OrderLine");

				// iterating the orderline
				for (Iterator itr = nodeListOutDocOrderLine.iterator(); itr.hasNext();) {

					Node nodeInDocOrderLine = (Node) itr.next();

					// totChargePerLine stores the consolidated chargePerLine
					// across
					// all line charges in an orderline
					double totChargePerLine = 0.0;

					if (!(YFCCommon.isVoid(nodeInDocOrderLine))
							&& !(YFCCommon.isStringVoid(nodeInDocOrderLine.getNodeName()))
							&& (nodeInDocOrderLine.getNodeName().equals("OrderLine"))) {

						Element eleInDocOrderLine = (Element) nodeInDocOrderLine;
						// 10/04: Changes for Defect 889
						Double dOrderedQty = Double.parseDouble(eleInDocOrderLine.getAttribute("OrderedQty"));
						if(dOrderedQty <= 0.00D){
							continue;
						}
						
						Element eleOutDocOrderLine = this.docOutXML.createElement("OrderLine");
						eleOutDocOrderLines.appendChild(eleOutDocOrderLine);
						// Seetha comment add YFCCommon for null check
						if (!(YFCCommon.isVoid(eleInDocOrderLine))) {
							// prepare OrderLine
							this.prepareOrderLine(eleInDocOrderLine, eleOutDocOrderLine);

							// prepare Item
							this.prepareItem(eleInDocOrderLine, eleOutDocOrderLine);

							// prepare ShipNode, which contains TaxGeoCode
							this.prepareShipNode(eleInDocOrderLine, eleOutDocOrderLine);

							// prepare LinePriceInfo
							this.prepareLinePriceInfo(eleInDocOrderLine, eleOutDocOrderLine);
							
						}

					}

				}
								
				//log.debug("Request xml to Taxware:" + XMLUtil.getXMLString(this.docOutXML));

				// 10/04: Added for defect 889
				// if there are no lines in the taxware input., skip taxware call
				List lTaxWareInOrderLine = XMLUtil.getElementsByTagName(eleOutDocOrderLines, "OrderLine");
				if(lTaxWareInOrderLine.size() >0){
					log.debug("Taxable lines found. Making Tax call" );
					this.prepareOrderLines(eleOutDocOrder, eleOutDocOrderLines, lTaxWareInOrderLine);
					if(log.isDebugEnabled()){
						log.debug("Request xml to Taxware:" + XMLUtil.getXMLString(this.docOutXML));
					}
					this.outputDocFromTaxware = KOHLSBaseApi.invokeService(env, "KohlsPocTaxwareService", this.docOutXML);
				} else{
					log.debug("No taxable lines found. Taxware not called. Responding with simulated response.");
					this.outputDocFromTaxware = simulateTaxwareResponse(docInXML);
				}
				if(log.isDebugEnabled()){
					log.debug("Response xml from Taxware:" + XMLUtil.getXMLString(this.outputDocFromTaxware));
				}
				// Checking for SOAP fault
				if (this.outputDocFromTaxware.getDocumentElement().getTagName().equalsIgnoreCase("Errors")) {

					YFSException yfse = new YFSException();
					yfse.setErrorCode("SOAPFault");
					throw yfse;

				}

				// checking for Taxware errors

				Element eleError = XMLUtil.getChildElement(this.outputDocFromTaxware.getDocumentElement(), "Error");

				if (!(YFCCommon.isVoid(eleError))) {

					String errorCode = eleError.getAttribute("ErrorCode");

					YFSException yfse = new YFSException();

					// Check against a successful completion code 0000
					if (null != errorCode && !errorCode.equals("0000")) {

						// temporarily setting it to Taxware Error, but the
						// actual code is set in the catch block
						yfse.setErrorCode("TaxwareError");
						throw yfse;

					}

				}

				// when enableTaxwareCall is disabled, building taxware response
				// using the indoc supplied to this generateTaxwareXML method
			} else {
				log.debug("enableTaxwareCall Disabled....");
				this.outputDocFromTaxware = simulateTaxwareResponse(docInXML);
			}

		} catch (ParserConfigurationException pe) {
			throw pe;
		} catch (ParseException pexception) {
			throw pexception;
		} catch (YFSException es) {
			log.error(es);

			//if (e.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

				// Changing YFSUserExitException to YFSException as from api we
				// should throw YFSException
				YFSException yfsException = new YFSException();

				/*YFSException es = (YFSException) e;*/

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("EXTN_CONNECT")) {
					yfsException.setErrorCode(KohlsPOCConstant.POC_TAXWARE_DOWN_ERROR_CODE);
					yfsException.setErrorDescription(KohlsPOCConstant.POC_TAXWARE_DOWN_ERROR_MESSAGE);
				}

				// IO Exception
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_IO")) {
					yfsException.setErrorCode(KohlsPOCConstant.POC_TAXWARE_TIMEOUT_ERROR_CODE);
					yfsException.setErrorDescription(KohlsPOCConstant.POC_TAXWARE_TIMEOUT_ERROR_MESSAGE);
				}

				// Other Exceptions
				else if (es.getErrorCode().equalsIgnoreCase("EXTN_OTHER")) {
					yfsException.setErrorCode(KohlsPOCConstant.POC_OTHER_ERROR_CODE);
					yfsException.setErrorDescription(KohlsPOCConstant.POC_OTHER_ERROR_MESSAGE);
				}

				// SOAP Fault exceptions
				else if (es.getErrorCode().equalsIgnoreCase("SOAPFault")) {
					yfsException.setErrorCode(XMLUtil.getChildElement(this.outputDocFromTaxware.getDocumentElement(),
							"Error").getAttribute("ErrorCode"));
					yfsException.setErrorDescription(XMLUtil.getChildElement(
							this.outputDocFromTaxware.getDocumentElement(), "Error").getAttribute("ErrorDescription"));

					// Taxware Error
				} else if (es.getErrorCode().equalsIgnoreCase("TaxwareError")) {
					yfsException.setErrorCode(XMLUtil.getChildElement(this.outputDocFromTaxware.getDocumentElement(),
							"Error").getAttribute("ErrorCode"));
					yfsException.setErrorDescription(XMLUtil.getChildElement(
							this.outputDocFromTaxware.getDocumentElement(), "Error").getAttribute("ErrorDescription"));
				}else {
					log.debug("The error code is :" +es.getErrorCode());
					throw es;
				}

				throw yfsException;
			//}
		}catch(Exception e){
			YFSException yEx = (YFSException) e;
			throw yEx;
		}

		log.debug(" End of the method : generateTaxwareXML of KohlsPocTaxServiceUtil");
		
		return this.outputDocFromTaxware;

	}

	/**
	 * Method Name : prepareOrderHeader Description : This method constructs OMS
	 * Order Header level
	 * 
	 * @return void
	 * @param eleInDocOrder
	 * @param eleOutDocOrder
	 * @throws ParseException
	 */
	private void prepareOrderHeader(Element eleInDocOrder, Element eleOutDocOrder) throws ParseException {

		// Retrieve Order level attributes from the input xml

		String orderNo = eleInDocOrder.getAttribute("OrderNo");
		String documentType = eleInDocOrder.getAttribute("DocumentType");
		String enterpriseCode = eleInDocOrder.getAttribute("EnterpriseCode");
		String orderDate = eleInDocOrder.getAttribute("OrderDate");
		String sellerOrganizationCode = eleInDocOrder.getAttribute("SellerOrganizationCode");
		//Appending zero when store number length is less than 4
		sellerOrganizationCode = KohlsPoCPnPUtil.prepadStoreNoWithZeros(sellerOrganizationCode);
				

		String customerFirstName = eleInDocOrder.getAttribute("CustomerFirstName");
		String customerLastName = eleInDocOrder.getAttribute("CustomerLastName");

		// Concatenating CustomerFirstName and CustomerLastName to form
		// CustomerName
		StringBuffer sb = new StringBuffer();
		sb.append(customerFirstName).append(" ").append(customerLastName);
		String customerName = sb.toString();
		
		
		//Added for Tax Exempt as part of Sprint-9.1.3 -- Start
		taxExemptCertificate = eleInDocOrder.getAttribute("TaxExemptionCertificate");
		if(!(YFCCommon.isStringVoid(taxExemptCertificate)))
		{
			
				taxFlag = "N";
			
		}
		//Added for Tax Exempt as part of Sprint-9.1.3 -- End
		

		// Formatting dateformat to yyyyMMdd as taxware expecting

		String outDate = "";

		if (!(YFCCommon.isStringVoid(orderDate))) {

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date = sdf.parse(orderDate);

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
			outDate = simpleDateFormat.format(date);

		}

		eleOutDocOrder.setAttribute("OrderNo", orderNo);
		eleOutDocOrder.setAttribute("DocumentType", documentType);
		eleOutDocOrder.setAttribute("EnterpriseCode", enterpriseCode);
		eleOutDocOrder.setAttribute("OrderDate", outDate);
		eleOutDocOrder.setAttribute("SellerOrganizationCode", sellerOrganizationCode);
		eleOutDocOrder.setAttribute("CustomerName", customerName);

		this.docOutXML.appendChild(eleOutDocOrder);

	}

	/**
	 * Method Name : prepareOrderLines Description : This method constructs OMS
	 * Order Lines
	 * 
	 * @return void
	 * @param eleInDocOrder
	 * @param eleOutDocOrder
	 * @param eleOutDocOrderLines
	 */
	private void prepareOrderLines(Element eleOutDocOrder, Element eleOutDocOrderLines, List lTaxWareInOrderLine) {
		eleOutDocOrderLines.setAttribute("TotalNumberOfRecords", Integer.toString(lTaxWareInOrderLine.size()));
		eleOutDocOrder.appendChild(eleOutDocOrderLines);
	}

	/**
	 * Method Name : prepareOrderLine Description : This method constructs OMS
	 * Order Line
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 */
	private void prepareOrderLine(Element eleInDocOrderLine, Element eleOutDocOrderLine) {

		String primeLineNo = eleInDocOrderLine.getAttribute("PrimeLineNo");
		String orderedQty = eleInDocOrderLine.getAttribute("OrderedQty");
		String orderLineKey = eleInDocOrderLine.getAttribute("OrderLineKey");

		eleOutDocOrderLine.setAttribute("PrimeLineNo", primeLineNo);
		eleOutDocOrderLine.setAttribute("OrderedQty", orderedQty);
		eleOutDocOrderLine.setAttribute("OrderLineKey", orderLineKey);

	}

	/**
	 * Method Name : prepareItem Description : This method constructs OMS Item
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 */
	private void prepareItem(Element eleInDocOrderLine, Element eleOutDocOrderLine) {

		// Order/OrderLines/OrderLine/Item
		Element elementItem = XMLUtil.getChildElement(eleInDocOrderLine, "Item");

		String itemId = elementItem.getAttribute("ItemID");
		String itemShortDesc = elementItem.getAttribute("ItemShortDesc");

		// Modified on 13-Aug-2013
		// Changing the xpath location of Retrieving TaxProductCode
		// Tax Product code from
		// Order/OrderLines/OrderLine/Extn/@ExtnTaxProductCode
		Element elementExtn = XMLUtil.getChildElement(eleInDocOrderLine, "Extn");
		String taxProductCode = elementExtn.getAttribute("ExtnTaxProductCode");
		// String taxProductCode = elementItem.getAttribute("TaxProductCode");

		Element item = this.docOutXML.createElement("Item");

		item.setAttribute("ItemID", itemId);
		item.setAttribute("ItemShortDesc", itemShortDesc);
		item.setAttribute("TaxProductCode", taxProductCode);

		eleOutDocOrderLine.appendChild(item);

	}

	/**
	 * Method Name : prepareLinePriceInfo Description : This method constructs
	 * OMS LinePriceInfo
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 */
	private void prepareLinePriceInfo(Element eleInDocOrderLine, Element eleOutDocOrderLine) {

		
		// Order\OrderLines\OrderLine\LinePriceInfo
		Element elementLinePriceInfo = XMLUtil.getChildElement(eleInDocOrderLine, "LinePriceInfo");
		Element tempEle = XMLUtil.getChildElement(eleInDocOrderLine, KohlsPOCConstant.E_TEMP,Boolean.TRUE);

		// is this TaxExemptionCertificate or TaxExemptionCertification ?
		String taxExemptionCertificate = elementLinePriceInfo.getAttribute("TaxExemptionCertificate");
		
		//Commented below line for Tax Exempt as part of Sprint-9.1.3
		//String taxableFlag = elementLinePriceInfo.getAttribute("TaxableFlag");
		
		//Added for Tax Exempt as part of Sprint-9.1.3 -- Start
		String taxableFlag = null;
		if(taxFlag.equalsIgnoreCase("Y"))
		{
			taxableFlag = elementLinePriceInfo.getAttribute("TaxableFlag");
		}
		else
		{
			taxableFlag = taxFlag;
		}
		//Added for Tax Exempt as part of Sprint-9.1.3 -- End
		
		String taxableAmount = tempEle.getAttribute("TaxableAmount");

		Element linePriceInfo = this.docOutXML.createElement("LinePriceInfo");

		// Changing this to TaxExemptionCertification according to ICD
		linePriceInfo.setAttribute("TaxExemptionCertification", taxExemptionCertificate);
		linePriceInfo.setAttribute("TaxableFlag", taxableFlag);
		linePriceInfo.setAttribute("TaxableAmount", String.valueOf(taxableAmount));

		eleOutDocOrderLine.appendChild(linePriceInfo);

	}






	/**
	 * Method Name : prepareShipNode Description : This method constructs OMS
	 * ShipNode
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 * @throws Exception 
	 */
	private void prepareShipNode(Element eleInDocOrderLine, Element eleOutDocOrderLine) throws YFSException {

		Element eleShipNode = this.docOutXML.createElement("Shipnode");
		Element shipNodePersonInfo = this.docOutXML.createElement("ShipNodePersonInfo");
		eleShipNode.appendChild(shipNodePersonInfo);

		Element elementShipNode = XMLUtil.getChildElement(eleInDocOrderLine, "Shipnode");

		// Order/OrderLines/OrderLine/Shipnode/ShipNodePersonInfo

		Element elementShipNodePersonInfo = XMLUtil.getChildElement(elementShipNode, "ShipNodePersonInfo");

		String city = elementShipNodePersonInfo.getAttribute("City");
		String country = elementShipNodePersonInfo.getAttribute("Country");
		String state = elementShipNodePersonInfo.getAttribute("State");
		String zipCode = elementShipNodePersonInfo.getAttribute("ZipCode");

		// Retrieving TaxGeoCode
		String taxGeoCode = elementShipNodePersonInfo.getAttribute("TaxGeoCode");

		shipNodePersonInfo.setAttribute("City", city);
		shipNodePersonInfo.setAttribute("Country", country);
		shipNodePersonInfo.setAttribute("State", state);
		shipNodePersonInfo.setAttribute("ZipCode", zipCode);

		//Uncommenting TaxGeoCode for Taxware change - Release1 -  Start
			log.debug("The taxGeoCode value is : "+taxGeoCode);
			if(!YFCCommon.isVoid(taxGeoCode)){
				shipNodePersonInfo.setAttribute("TaxGeoCode", taxGeoCode);
			}else{
				//throw new YFSException();
				YFSException e = new YFSException();
				e.setErrorCode(KohlsPOCConstant.INVALIDGEOCODE);  
				e.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALIDGEOCODE));
				log.debug("The Invalid geocode value from property file is: " +KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.INVALIDGEOCODE));
				//e.setErrorDescription("Invalid GeoCode. Please check the store config settings and try again");
				//e.setErrorDescription(KOHLSResourceUtil.getPropertyValue(KohlsPOCConstant.PLUOFFREXPD));
				throw e;
			}
			
			//Uncommenting TaxGeoCode for Taxware change - Release1 -  End

		eleOutDocOrderLine.appendChild(eleShipNode);

	}

	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {

		this.props = prop;
		this.log.debug("In the set properties method");

	}

	/**
	 * Method Name : simulateTaxwareResponse Description : This method
	 * constructs simulated Taxware response when handled is disabled
	 * 
	 * @param docInXML
	 * @return simulatedDocOutXML
	 * @throws ParserConfigurationException
	 */

	private Document simulateTaxwareResponse(Document docInXML) throws ParserConfigurationException {

		// Read the inputDoc
		Element eleInDocOrder = docInXML.getDocumentElement();

		// Instantiate simulatedDocOutXML
		this.simulatedDocOutXML = XMLUtil.newDocument();

		// Order
		Element eleOutDocOrder = this.simulatedDocOutXML.createElement("Order");

		this.simulateTaxOrderHeader(eleInDocOrder, eleOutDocOrder);

		// Order/OrderLines
		Element eleOutDocOrderLines = this.simulatedDocOutXML.createElement("OrderLines");

		this.simulateTaxOrderLines(eleInDocOrder, eleOutDocOrder, eleOutDocOrderLines);

		// Order/OrderLines/OrderLine
		List nodeListOutDocOrderLine = XMLUtil.getElementsByTagName(eleInDocOrder, "OrderLine");

		// iterating the orderline
		for (Iterator itr = nodeListOutDocOrderLine.iterator(); itr.hasNext();) {

			Node nodeInDocOrderLine = (Node) itr.next();

			if (!(YFCCommon.isVoid(nodeInDocOrderLine)) && !(YFCCommon.isStringVoid(nodeInDocOrderLine.getNodeName()))
					&& (nodeInDocOrderLine.getNodeName().equals("OrderLine"))) {

				Element eleInDocOrderLine = (Element) nodeInDocOrderLine;

				Element eleOutDocOrderLine = this.simulatedDocOutXML.createElement("OrderLine");
				eleOutDocOrderLines.appendChild(eleOutDocOrderLine);

				if (!(YFCCommon.isVoid(eleInDocOrderLine))) {
					// prepare simulated OrderLine
					this.simulateTaxOrderLine(eleInDocOrderLine, eleOutDocOrderLine);

					// prepare simulated Item
					this.simulateTaxItem(eleInDocOrderLine, eleOutDocOrderLine);

					// prepare simulated line taxes

					this.simulateTaxLineTaxes(eleInDocOrderLine, eleOutDocOrderLine);

				}

			}

		}

		return this.simulatedDocOutXML;
	}

	/**
	 * Method: simulateTaxLineTaxes Description : This method constructs OMS
	 * LineTaxes
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 */

	private void simulateTaxLineTaxes(Element eleInDocOrderLine, Element eleOutDocOrderLine) {

		Element eleLineTaxes = this.simulatedDocOutXML.createElement("LineTaxes");
		Element eleLineTax = this.simulatedDocOutXML.createElement("LineTax");
		eleLineTaxes.appendChild(eleLineTax);

		eleLineTax.setAttribute("ChargeCategory", "Price");
		eleLineTax.setAttribute("ChargeName", "Price");
		eleLineTax.setAttribute("Reference_1", "");
		eleLineTax.setAttribute("Tax", "0.0");

		eleLineTax.setAttribute("TaxName", "SalesTax");
		eleLineTax.setAttribute("TaxPercentage", "0.0");

		eleOutDocOrderLine.appendChild(eleLineTaxes);

	}

	/**
	 * Method: simulateTaxItem Description : This method constructs simulated
	 * Tax Item
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 */

	private void simulateTaxItem(Element eleInDocOrderLine, Element eleOutDocOrderLine) {

		// Order/OrderLines/OrderLine/Item
		Element elementItem = XMLUtil.getChildElement(eleInDocOrderLine, "Item");

		String itemId = elementItem.getAttribute("ItemID");

		Element item = this.simulatedDocOutXML.createElement("Item");

		item.setAttribute("ItemID", itemId);

		eleOutDocOrderLine.appendChild(item);

	}

	/**
	 * Method: simulateTaxOrderLine Description : This method constructs
	 * simulated Tax OrderLine
	 * 
	 * @return void
	 * @param eleInDocOrderLine
	 * @param eleOutDocOrderLine
	 */

	private void simulateTaxOrderLine(Element eleInDocOrderLine, Element eleOutDocOrderLine) {

		String primeLineNo = eleInDocOrderLine.getAttribute("PrimeLineNo");

		String orderLineKey = eleInDocOrderLine.getAttribute("OrderLineKey");

		eleOutDocOrderLine.setAttribute("PrimeLineNo", primeLineNo);

		eleOutDocOrderLine.setAttribute("OrderLineKey", orderLineKey);

	}

	/**
	 * Method: simulateTaxOrderLine Description : This method constructs
	 * simulated Tax OrderHeader
	 * 
	 * @return void
	 * @param eleInDocOrder
	 * @param eleOutDocOrder
	 */

	private void simulateTaxOrderHeader(Element eleInDocOrder, Element eleOutDocOrder) {

		// Retrieve Order level attributes from the input xml

		String orderNo = eleInDocOrder.getAttribute("OrderNo");
		String documentType = eleInDocOrder.getAttribute("DocumentType");
		String enterpriseCode = eleInDocOrder.getAttribute("EnterpriseCode");

		eleOutDocOrder.setAttribute("OrderNo", orderNo);
		eleOutDocOrder.setAttribute("DocumentType", documentType);
		eleOutDocOrder.setAttribute("EnterpriseCode", enterpriseCode);

		this.simulatedDocOutXML.appendChild(eleOutDocOrder);

	}

	/**
	 * Method Name : simulateTaxOrderLines Description : This method constructs
	 * Tax Order Lines
	 * 
	 * @return void
	 * @param eleInDocOrder
	 * @param eleOutDocOrder
	 * @param eleOutDocOrderLines
	 */

	private void simulateTaxOrderLines(Element eleInDocOrder, Element eleOutDocOrder, Element eleOutDocOrderLines) {

		// Order/OrderLines
		Element eleOrderLines = XMLUtil.getChildElement(eleInDocOrder, "OrderLines");

		if (!(YFCCommon.isVoid(eleOrderLines))) {
			String totalNumberOfRecords = eleOrderLines.getAttribute("TotalNumberOfRecords");
			eleOutDocOrderLines.setAttribute("TotalNumberOfRecords", totalNumberOfRecords);
		}
		eleOutDocOrder.appendChild(eleOutDocOrderLines);

	}
	
	/**
	 * Method Name : simulateTaxLineTaxesForTVSTaxExempt Description : This method constructs
	 * Tax Order Lines with Zero Tax and TaxPercentage for TVS Order Level Tax Exempt
	 * 
	 * @return void
	 * @param eleInDocOrder
	 * @param eleOutDocOrder
	 * @param eleOutDocOrderLines
	 */
	
	public static void simulateTaxLineTaxesForTVSTaxExempt(Element eleDummylineTaxes_TVSTaxExempt) {

		log.beginTimer("KohlsPocTaxServiceUtil.simulateTaxLineTaxesForTVSTaxExempt");
		//String[] strTaxNames = new String[]{"Federal Tax","State Tax","County Tax","City Tax","SecState Tax","SecCounty Tax","SecCity Tax","District Tax"};
		for(int i=0; i<KohlsPOCConstant.strTaxNames.length;i++){
			Element eleLineTax = XMLUtil.createChild(eleDummylineTaxes_TVSTaxExempt,"LineTax");
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
			eleLineTax.setAttribute(KohlsPOCConstant.SMALL_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
			//eleLineTax.setAttribute("Reference_1", "");
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, KohlsPOCConstant.ZERO_STR);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, KohlsPOCConstant.strTaxNames[i]);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, "0.0");
			eleLineTax.setAttribute(KohlsPOCConstant.SMALL_TAX, KohlsPOCConstant.ZERO_STR);
			eleLineTax.setAttribute(KohlsPOCConstant.SMALL_TAX_NAME, KohlsPOCConstant.strTaxNames[i]);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT, "0.0");
			
			if(KohlsPOCConstant.strTaxNames[i].equalsIgnoreCase("Federal Tax")){
				eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "");
				eleLineTax.setAttribute(KohlsPOCConstant.SMALL_TAX_TYPE, "");
			}
			else if(KohlsPOCConstant.strTaxNames[i].equalsIgnoreCase("SecCounty Tax") || KohlsPOCConstant.strTaxNames[i].equalsIgnoreCase("SecCity Tax")){
				eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Use");
				eleLineTax.setAttribute(KohlsPOCConstant.SMALL_TAX_TYPE, "Use");	
			}
			else{
				eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
				eleLineTax.setAttribute("taxType", "Sales");
			}
		}
		if(log.isDebugEnabled()){
			log.debug("The eleDummylineTaxes_TVSTaxExempt inside simulateTaxLineTaxesForTVSTaxExempt is: " +XMLUtil.getElementXMLString(eleDummylineTaxes_TVSTaxExempt));
		}
		log.endTimer("KohlsPocTaxServiceUtil.simulateTaxLineTaxesForTVSTaxExempt");


	}
	//Changes for consolidating LineTaxes - Performance - Start
	public static void simulateSingleTaxLineForTVSTaxExempt(
			Element eleDummylineTaxes_TVSTaxExempt) {
		log.beginTimer("KohlsPocTaxServiceUtil.simulateSingleTaxLineForTVSTaxExempt");
		//String[] strTaxNames = new String[]{"Federal Tax","State Tax","County Tax","City Tax","SecState Tax","SecCounty Tax","SecCity Tax","District Tax"};
			Element eleLineTax = XMLUtil.createChild(eleDummylineTaxes_TVSTaxExempt,KohlsPOCConstant.ELEM_LINE_TAX);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_CHARGE_NAME, KohlsPOCConstant.CONST_PRICE);
			eleLineTax.setAttribute(KohlsPOCConstant.SMALL_CHARGE_CATEGORY, KohlsPOCConstant.CONST_PRICE);
			//eleLineTax.setAttribute("Reference_1", "");
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX, KohlsPOCConstant.ZERO_STR);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_NAME, "State Tax"/*KohlsPOCConstant.strTaxNames[i]*/);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_PERCENT, "0.0");
			eleLineTax.setAttribute(KohlsPOCConstant.SMALL_TAX, KohlsPOCConstant.ZERO_STR);
			eleLineTax.setAttribute(KohlsPOCConstant.SMALL_TAX_NAME, "State Tax"/*KohlsPOCConstant.strTaxNames[i]*/);
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_SMALL_TAX_PERCENT, "0.0");
			eleLineTax.setAttribute(KohlsPOCConstant.ATTR_TAX_TYPE, "Sales");
			eleLineTax.setAttribute("taxType", "Sales");
			eleLineTax.setAttribute(KohlsPOCConstant.A_LINE_TOTAL_TAX, KohlsPOCConstant.DECIMAL_FORMAT);
			eleLineTax.setAttribute(KohlsPOCConstant.A_LINE_TOTAL_TAX_RATE, KohlsPOCConstant.DECIMAL_FORMAT);
		if(log.isDebugEnabled()){
			log.debug("The eleDummylineTaxes_TVSTaxExempt inside simulateSingleTaxLineForTVSTaxExempt is: " +XMLUtil.getElementXMLString(eleDummylineTaxes_TVSTaxExempt));
		}
		log.endTimer("KohlsPocTaxServiceUtil.simulateSingleTaxLineForTVSTaxExempt");
		
	}
	//Changes for consolidating LineTaxes - Performance - End

}
