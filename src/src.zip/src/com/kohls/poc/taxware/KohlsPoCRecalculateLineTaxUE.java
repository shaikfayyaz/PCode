package com.kohls.poc.taxware;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Element;

import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSExtnLineTaxCalculationInputStruct;
import com.yantra.yfs.japi.YFSExtnTaxBreakup;
import com.yantra.yfs.japi.YFSExtnTaxCalculationOutStruct;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSRecalculateLineTaxUE;
import com.yantra.yfs.japi.YFSExtnTaxBreakup;
import com.kohls.poc.constant.KohlsPOCConstant;

public class KohlsPoCRecalculateLineTaxUE implements YFSRecalculateLineTaxUE {

  private static final YFCLogCategory loggerForRecalculateLineTaxUE =
      YFCLogCategory.instance(KohlsPoCRecalculateLineTaxUE.class.getName());

  public YFSExtnTaxCalculationOutStruct recalculateLineTax(YFSEnvironment env,
      YFSExtnLineTaxCalculationInputStruct inputStruct) throws YFSUserExitException {
    /*
     * for invoice recalculate taxes
     */
    loggerForRecalculateLineTaxUE
        .debug("------ Inside KohlsPoCRecalculateLineTaxUE.recalculateLineTax method ------- ");
    // Defining variables
    YFSExtnTaxCalculationOutStruct outStruct = new YFSExtnTaxCalculationOutStruct();
    String strOrderLineKey = inputStruct.orderLineKey;
    Map<String, List> lineTax = (Map) env.getTxnObject("DeltaTax");
    List<YFSExtnTaxBreakup> taxBreakUpList = new ArrayList<YFSExtnTaxBreakup>();
    YFSExtnTaxBreakup taxBreakup = new YFSExtnTaxBreakup();
    if (lineTax != null && lineTax.size() > 0) {
      if (lineTax.containsKey(strOrderLineKey)) {
        List<Element> liTax = lineTax.get(strOrderLineKey);
        if (liTax.size() > 0) {
          Element eleLineTaxes = liTax.get(0);
          loggerForRecalculateLineTaxUE.debug(
              "The Delta tax stored in txn object  :" + XMLUtil.getElementXMLString(eleLineTaxes));
          List<Element> eleLineTax = XMLUtil.getElementsByTagName(eleLineTaxes, "LineTax");
          for (Element eleTax : eleLineTax) {
            String strtax = eleTax.getAttribute("Tax");
            taxBreakup = new YFSExtnTaxBreakup();
            taxBreakup.tax = Double.parseDouble(strtax);
            taxBreakup.chargeCategory = eleTax.getAttribute(KohlsConstant.ATTR_CHARGE_CATEGORY);
            taxBreakup.chargeName = eleTax.getAttribute(KohlsConstant.ATTR_CHARGE_NAME);
            taxBreakup.taxName = eleTax.getAttribute(KohlsConstant.ATTR_TAX_NAME);
            taxBreakup.taxPercentage =
                Double.parseDouble(eleTax.getAttribute(KohlsConstant.ATTR_TAX_PERCENT));
            taxBreakUpList.add(taxBreakup);
            loggerForRecalculateLineTaxUE.debug("PSA Tax Caculation logic : ");
          }


        }
        outStruct.colTax = taxBreakUpList;
        List outputList = outStruct.colTax;
        Iterator it = outputList.iterator();
        int i = 0;
        while (it.hasNext()) {

          YFSExtnTaxBreakup taxBreakup1 = (YFSExtnTaxBreakup) it.next();
          i++;
          if (YFCLogUtil.isDebugEnabled()) {
            loggerForRecalculateLineTaxUE.debug("Taxes of type : " + i);
            loggerForRecalculateLineTaxUE.debug("taxName : " + taxBreakup1.taxName);
            loggerForRecalculateLineTaxUE.debug("chargeName : " + taxBreakup1.chargeName);
            loggerForRecalculateLineTaxUE.debug("chargeCategory: " + taxBreakup1.chargeCategory);
            loggerForRecalculateLineTaxUE.debug("taxPercentage: " + taxBreakup1.taxPercentage);
            loggerForRecalculateLineTaxUE.debug("tax: " + taxBreakup1.tax);
          }
        }
        return outStruct;
      }
    }

    // Changes for PA - begin
    String sExtnPOCFeature = (String) env.getTxnObject("ExtnPOCFeature");
    if (!YFCCommon.isVoid(sExtnPOCFeature)
        && KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equals(sExtnPOCFeature)) {

      // Getting PA Qualified lines from env

      @SuppressWarnings("unchecked")
      ArrayList<String> arrayPAQualifiedLines =
          (ArrayList<String>) env.getTxnObject("PA_QALIFIED_LINES");
      if (YFCCommon.isVoid(arrayPAQualifiedLines)) {
        arrayPAQualifiedLines = new ArrayList<String>();
      }

      // Looping through each colTax and checking if InvoicedTax > Tax.If yes, then
      // setting Tax=Tax-InvoicedTax
      List colList = inputStruct.colTax;
      Iterator it = colList.iterator();
      int i = 0;
      while (it.hasNext()) {
        YFSExtnTaxBreakup taxBreakup1 = (YFSExtnTaxBreakup) it.next();
        Double dTax = taxBreakup1.tax;
        Double dInvoicedTax = taxBreakup1.invoicedTax;
        if (loggerForRecalculateLineTaxUE.isDebugEnabled()) {
          loggerForRecalculateLineTaxUE.debug("tax: " + taxBreakup1.tax);
          loggerForRecalculateLineTaxUE.debug("invoicedTax: " + taxBreakup1.invoicedTax);
        }
        if (arrayPAQualifiedLines.contains(inputStruct.orderLineKey)) {
          loggerForRecalculateLineTaxUE.debug("PriceAdjustment - Tax difference found: ");
          taxBreakup1.tax = dTax - dInvoicedTax;
          if (loggerForRecalculateLineTaxUE.isDebugEnabled()) {
            loggerForRecalculateLineTaxUE.debug("------- After calculation ------");
            loggerForRecalculateLineTaxUE.debug("tax: " + taxBreakup1.tax);
            loggerForRecalculateLineTaxUE.debug("invoicedTax: " + taxBreakup1.invoicedTax);
          }
        } else {
          loggerForRecalculateLineTaxUE
              .debug("PriceAdjustment - No Tax difference found. So setting tax = 0 ");
          taxBreakup1.tax = 0.00D;
        }
      }
    }
    // Changes for PA - end
    outStruct.tax = inputStruct.tax;
    if (inputStruct.colTax != null) {
      outStruct.colTax = inputStruct.colTax;
    } else {
      outStruct.colTax = new ArrayList();
    }
    loggerForRecalculateLineTaxUE
        .debug("------ Exiting KohlsPoCRecalculateLineTaxUE.recalculateLineTax method ------- ");
    loggerForRecalculateLineTaxUE.debug("OutStruct is: " + outStruct.toString());
    return outStruct;
  }
}
