package com.kohls.poc.constant;

// Start --- CPE - 2910
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
// End --- CPE - 2910
import java.util.Map;

/**
 *
 * Kohls Constant File
 *
 */
public class KohlsPOCConstant {
  public static final String KOHLS_OrganizationCode = "KOHLS.COM";
  public static final String KOHLS_ENTERPRISE_CODE = "KOHLS.COM";
  public static final String SO_ENTERPRISE_CODE = "KOHLS.COM";
  public static final String SO_DOCUMENT_TYPE = "0001";
  public static final String PO_DOCUMENT_TYPE = "0005";
  public static final String YES = "Y";
  public static final String NO = "N";
  public static final String ACTION_CREATE = "CREATE";
  public static final String ACTION_MODIFY = "MODIFY";
  public static final String ACTION_CANCEL = "CANCEL";
  public static final String A_SUB_LINE_NO = "1";
  public static final String REASON_CODE_NO_INV = "NO_INV";
  public static final String REASON_TEXT_NO_INV = "No inventory";
  public static final String PRODUCT_LINE_SA = "SA";
  public static final String PRODUCT_LINE_GW = "GW";
  public static final String PRODUCT_LINE_ST = "ST";
  public static final String PRODUCT_LINE_VGC = "VGC";
  public static final String PRODUCT_CLASS_GOOD = "Good";
  public static final String UNIT_OF_MEASURE = "EACH";
  public static final String ORDER_RELEASE_KEY = "OrderReleaseKey";
  public static final int PICKTICKET_LEN = 10;
  public static final String SHIP_ALONE_QTY = "1";
  public static final String TRAN_ID_SEND_RELEASE_TO_WMOS = "KOHLS_SEND_RELEASE.0001.ex";
  public static final String TRAN_ID_SA_SEND_RELEASE_TO_WMOS = "KOHLS_SA_SEND_RELEASE.0001.ex";
  public static final String TRAN_ID_SCHEDULE_ORDER = "SCHEDULE.0001";
  public static final String TRAN_ID_RELEASE_ORDER = "RELEASE.0001";
  public static final String TRAN_ID_CHAINED_ORDER_CREATE = "CHAINED_ORDER_CREATE";
  public static final String TRAN_ID_KOHLS_CLOSE_ORDER = "KOHLS_CLOSE_ORDER.0001.ex";
  public static final String STATUS_SEND_TO_WMOS = "3200.03";
  public static final String STATUS_RELEASED = "3200";
  public static final String STATUS_MSG_SEND_TO_WMOS = "Sent To WMoS";
  public static final String STATUS_MSG_SEND_SHIP_ALONE_TO_WMOS = "Ship Alone Sent To WMoS";
  public static final String SUPPLY_TYPE = "ONHAND";
  public static final String INTEGRATION_AGENT_SERVER = "IntegrationAgentServer";
  public static final String INV_ADJ_SERVER_CODE_TYPE = "INV_ADJ_SERVERS";
  public static final String EFC1 = "873";
  public static final String EFC2 = "809";
  public static final String SUSPEND = "Suspend";
  public static final String RESUME = "Resume";
  public static final String SHIPMENT_CREATED_STATUS = "1100";
  public static final String HOLD_CREATED_STATUS = "1100";
  public static final String HOLD_REMOVED_STATUS = "1300";
  public static final String ORDER_LINE_SOUR_CNTRL_REASON = "Source Cntrl";
  public static final String ITEM_ORGANIZATION_CODE = "DEFAULT";
  public static final String VIRTUAL_GIFT_CARD = "VGC";
  public static final String PLASTIC_GIFT_CARD = "GC";
  public static final String PLASTIC_GIFT_CARD_LINE_TYPE = "PGC";
  public static final String BLANK = "";
  public static final String GIFT_WRAP = "GW";
  public static final String GIFT_WRAP_QUANTITY = "1";
  public static final String EFC1_SERVER = "InvAdj873IntegServer";
  public static final String EFC2_SERVER = "InvAdj809IntegServer";
  public static final String RG_HAZARDOUS = "Hazardous";
  public static final String RG_POAPO = "POAPO_STANDARD";
  public static final String RG_PRIORITY = "Priority";
  public static final String RG_AK_HI = "AK_HI_STANDARD";
  public static final String RG_STANDARD = "STANDARD";
  public static final String CARRIER_SERVICE_CODE_APO = "APO";
  public static final String CARRIER_SERVICE_CODE_FPO = "FPO";
  public static final String CARRIER_SERVICE_CODE_PRIORITY = "Priority";
  public static final String ADDRESS_LINE_PO = "PO";
  public static final String STATE_AK = "AK";
  public static final String STATE_HI = "HI";
  public static final String EXTN_PICK_TICKET_ERROR = "ExtnPickTicketNo is missing";
  public static final String ORDER_NO_ERROR = "OrderNo is missing";
  public static final String ELEM_ORDER = "Order";
  public static final String ATTR_DOC_TYPE = "DocumentType";
  public static final String ATTR_ENTERPRISE_CODE = "EnterpriseCode";
  public static final String ATTR_ORD_HDR_KEY = "OrderHeaderKey";
  public static final String ATTR_ORDER_NO = "OrderNo";
  public static final String ATTR_MIN_ORD_STATUS = "MinOrderStatus";
  public static final String ELEM_ORDER_LINES = "OrderLines";
  public static final String ELEM_ORDER_LINE = "OrderLine";
  public static final String ATTR_TOT_NO_RECORDS = "TotalNumberOfRecords";
  public static final String ATTR_INVOICED_QUANT = "InvoicedQuantity";
  public static final String ATTR_ORDER_LINE_KEY = "OrderLineKey";
  public static final String ATTR_ORDERED_QTY = "OrderedQty";
  public static final String ATTR_ORIG_ORDERED_QTY = "OriginalOrderedQty";
  public static final String ATTR_PRIME_LINE_NO = "PrimeLineNo";
  public static final String ATTR_RCVD_QTY = "ReceivedQty";
  public static final String ATTR_SHIPPED_QTY = "ShippedQuantity";
  public static final String ATTR_SUB_LINE_NO = "SubLineNo";
  public static final String ELEM_ORD_STATUSES = "OrderStatuses";
  public static final String ELEM_ORDER_STATUS = "OrderStatus";
  public static final String ATTR_RECV_NODE = "ReceivingNode";
  public static final String ATTR_SHIP_NODE = "ShipNode";
  public static final String ATTR_STATUS = "Status";
  public static final String ATTR_STATUS_QTY = "StatusQty";
  public static final String ATTR_TOT_QTY = "TotalQuantity";
  public static final String ELEM_LINE_CHARGES = "LineCharges";
  public static final String ELEM_LINE_CHARGE = "LineCharge";
  public static final String ATTR_CHARGE_AMNT = "ChargeAmount";
  public static final String ATTR_RMNG_CHARGE_AMNT = "RemainingChargeAmount";
  public static final String ATTR_CHARGE_NAME = "ChargeName";
  public static final String ATTR_CHARGE_CATEGORY = "ChargeCategory";
  public static final String ELEM_ITEM = "Item";
  public static final String ELEM_LINE_TAXES = "LineTaxes";
  public static final String ELEM_LINE_TAX = "LineTax";
  public static final String ATTR_TAX_NAME = "TaxName";
  public static final String ATTR_RMNG_TAX = "RemainingTax";
  public static final String ATTR_TAX = "Tax";
  public static final String ATTR_TAX_PERCENT = "TaxPercentage";
  public static final String ATTR_SEC_ORD_HDR_KEY = "SecondaryOrderHeaderKey";
  // Gift Charge related values
  public static final String GiftChargeCategory = "GiftWrap";
  public static final String GiftChargeName = "GiftWrapCharge";
  public static final String GiftTaxCategory = "GiftWrapTax";
  public static final String ShippingChargeCategory = "Shipping";
  public static final String SHIPPING_TAX_CHARGE_CATEGORY = "ShippingTax";
  public static final String ChargeNameSurcharge = "Surcharge";
  // APIs
  public static final String API_GET_ORDER_INVOICE_LIST = "getOrderInvoiceList";
  public static final String API_GET_ORDER_LIST = "getOrderList";
  public static final String API_GET_ITEM_LIST = "getItemList";
  public static final String API_GET_SHIPMENT_LIST = "getShipmentListForOrder";
  public static final String API_GET_SHIPMENT_LINE_LIST = "getShipmentLineList";
  public static final String API_GET_ORDER_RELEASE_DETAILS = "getOrderReleaseDetails";
  public static final String API_GET_SHIPMENT_DETAILS = "getShipmentDetails";
  public static final String API_GET_ORDER_DETAILS = "getOrderDetails";
  public static final String API_GET_ORDER_LINE_DETAILS = "getOrderLineDetails";
  public static final String API_GET_COMMON_CODE_LIST = "getCommonCodeList";
  public static final String API_GET_ORDER_LINE_LIST = "getOrderLineList";
  public static final String API_GET_ITEM_DETAILS = "getItemDetails";
  public static final String API_actual_GET_SHIPMENT_LIST = "getShipmentList";
  public static final String API_GET_DISTRIBUTION_LIST = "getDistributionList";
  public static final String API_GET_INVENTORY_SNAP_SHOT = "getInventorySnapShot";
  // Added SIM Drop 3
  public static final String A_PLACED_QUANTITY = "PlacedQuantity";
  public static final String A_SELLER_ORGANIZATION_CODE = "SellerOrganizationCode";
  public static final String V_AWAITING_PICKLIST_PRINT = "1100.025";
  public static final String A_TRANSACTION_ID = "TransactionId";
  public static final String V_TRANSACTION_ID = "PICK_LIST_PRINT.0001.ex";
  public static final String E_PRINT_PROCESS_SHIPMENT = "PrintProcessShipment";
  // Service
  public static final String SERVICE_KOHLS_SEND_RELEASE_TO_WMOS =
      "KohlsSendReleaseOrderToWMoSSyncService";
  public static final String SERVICE_KOHLS_SEND_RELEASE_STATUS_TO_ECOMM =
      "KohlsSendReleaseStatusToEcommSyncService";
  public static final String SERVICE_KOHLS_SEND_SHIP_ALONE_RELEASE_TO_WMOS =
      "KohlsSendShipAloneOrderToWMoSSyncService";
  public static final String SERVICE_KOHLS_SEND_SHIP_ALONE_STATUS_TO_ECOMM =
      "KohlsSendShipAloneStatusToEcommSyncService";
  public static final String SERVICE_KOHLS_SHIP_CONFIRM_TO_ECOMM =
      "KohlsShipConfirmToEcommDropService";
  public static final String SERVICE_KOHLS_GET_INV_SYNC_TIME = "KohlsGetInvSyncTime";
  public static final String SERVICE_KOHLS_CREATE_INV_SYNC_TIME = "KohlsCreateInvSyncTime";
  public static final String SERVICE_KOHLS_CHANGE_INV_SYNC_TIME = "KohlsChangeInvSyncTime";
  public static final String SERVICE_INV_ADJ_GET_TIME = "InvAdjGetTimeSubService";
  public static final String SERVICE_SHIP_CONFIRM_SYNC_SERV = "ShipConfirmationSyncService";
  public static final String SERVICE_ALT_SHIP_CONFIRM_SYNC_SERV =
      "AltrntShipConfirmEcommSyncService";
  public static final String SERVICE_KOHLS_GET_INV_SNAP_SHOT = "KohlsGetInvSnapShotService";
  public static final String SERVICE_KOHLS_SEND_REGION_SOURCING_RULE =
      "KohlsSourcingRuleDetailsService";
  public static final String SERVICE_KOHLS_PAYMENT_REVERSE_AUTH_FAILURE_ALERT =
      "KohlsReverseAuthorizationFailureAlert";
  public static final String SERVICE_KOHLS_PAYMENT_REVERSE_AUTH_TIME_OUT_ALERT =
      "KohlsReverseAuthorizationTimeOutAlert";
  public static final String SERVICE_KOHLS_PAYMENT_RE_AUTH_FAILURE_ALERT =
      "KohlsReAuthorizationFailureAlert";
  public static final String SERVICE_KOHLS_PAYMENT_RE_AUTH_TIME_OUT_ALERT =
      "KohlsReAuthorizationTimeOutAlert";
  public static final String SERVICE_KOHLS_STORED_VALUE_CARD_REFUND_SERVICE =
      "KohlsStoredValueCardRefundService";
  public static final String SERVICE_KOHLS_CANCEL_MSG_TO_ECOMM = "CancelOrderSyncService";
  public static final String SERVICE_RAISE_KOHLS_CASH_EARNED_EXCEPTION =
      "RaiseKohlsCashEarnedExceptionAlert";


  // SIM Pilot-drop3
  public static final String SERVICE_KOHLS_JASPER_MULTI_SERVICE = "KOHLSJasperMultiPrintService";
  public static final String SERVICE_KOHLS_CHANGE_STATUS_SINGLE_PRINT_SERVICE =
      "KOHLSChangeStatusSinglePrintService";
  public static final String SERVICE_JASPER_SINGLE_PRINT_SERVICE = "KOHLSPickSlipPrintService";
  public static final String SERVICE_JASPER_MULTI_PRINT_SERVICE = "KOHLSPickSlipPrintService";
  public static final String LINE_TYPE_PGC = "PGC";
  public static final String PRODUCT_LINE_BK = "BK";
  public static final String SHIP_VIA_PP = "PP";
  public static final String SHIP_VIA_PM = "PM";
  public static final String SHIP_VIA_PMDC = "PMDC";
  public static final String CARTON_TYPE_ENV = "ENV";
  public static final String CARTON_TYPE_BRK = "BRK";
  public static final String CARTON_TYPE_WRP = "WRP";
  public static final String WRAP_SINGLE_TO_S = "S";
  public static final String WRAP_SINGLE_TO_T = "T";
  // XPATH
  public static final String XPATH_ORDER_EXTN = "/Order/Extn";
  // NetcoolLog
  public static final String NET_LOG_APPENDER = "NetcoolLogger.";
  public static final String LOW = "Low";
  public static final String MEDIUM = "Medium";
  public static final String HIGH = "High";
  // Payment
  public static final String PAYMENT_STATUS_AUTH = "AUTHORIZED";
  public static final String PAYMENT_STATUS_NOT_APPLICABLE = "NOT_APPLICABLE";
  public static final String PAYMENT_STATUS_PAID = "PAID";
  public static final String CHARGE_TYPE_AUTH = "AUTHORIZATION";
  public static final String CHARGE_TYPE_CHARGE = "CHARGE";
  public static final String PAYMENT_CREDIT = "Credit";
  public static final String PAYMENT_DEBIT = "DEBIT";
  public static final String PAYMENT_TYPES = "PAYMENT_TYPES";
  public static final String PAYMENT_CREDIT_PRIVATE_LABEL = "CREDIT|PRIV_LBL";
  public static final String PAYMENT_CREDIT_PRIVATE_LABEL_DEBIT = "CREDIT|PRIV_LBL|DEBIT";
  public static final String PAYMENT_RETURN_CODE_0 = "0";
  public static final String PAYMENT_RETURN_CODE_1 = "1";
  public static final String PAYMENT_RETURN_CODE_2 = "2";
  public static final String PAYMENT_RETURN_CODE_3 = "3";
  public static final String PAYMENT_RETURN_CODE_5 = "5";
  public static final String PAYMENT_RETURN_CODE_6 = "6";
  public static final String PAYMENT_RETURN_CODE_8 = "8";
  public static final String PAYMENT_RETURN_CODE_10 = "10";
  public static final String PAYMENT_RETURN_CODE_14 = "14";
  public static final String PAYMENT_RETURN_MSG_SUCCESSFUL = "SUCCESSFUL";
  public static final String PAYMENT_RETURN_MSG_DECLINED = "DECLINED";
  public static final String PAYMENT_RETURN_MSG_TIMEOUT = "TIMEOUT";
  public static final String RTRN_CODE_APRVD = "RTRN_CODE_APRVD";
  public static final String RTRN_CODE_DECL = "RTRN_CODE_DECL";
  public static final String RTRN_CODE_TIME_OUT = "RTRN_CODE_TO";
  public static final String RESP_101_MSG_FLD = "101_RES_MSG_FLD";
  public static final String AUTHORIZATION_EXPIRATION_DATE = "authorizationExpirationDate";
  public static final String AUTHORIZATION_AMOUNT = "authorizationAmount";
  public static final String AUTHORIZATION_ID = "authorizationId";
  public static final String AUTH_RETURN_CODE = "authReturnCode";
  public static final String DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";
  public static final String CODE_TYPE_RETRY_INTERVAL = "RETRY_INTERVAL";
  public static final String PAYMENT_TYPE_CREDIT_CARD = "Credit Card";
  public static final String PAYMENT_TYPE_3PL_GIFT_CARD = "3PL Gift Card";
  public static final String AUTH_EXP_DAYS = "AUTH_EXP_DAYS";
  public static final String AUTH_ID_DUMMY = "000000";
  public static final String CREDIT_CARD_AMEX = "AMEX";
  public static final String PAYMENT_RULE_NO_AUTH = "KOHLS_NO_AUTH";

  // Receipt ID Related fields
  public static final int REGISTER_LEN = 2;
  public static final int TRANSACTION_LEN = 4;
  public static final int SHIPNODE_LEN = 4;
  public static final int PMLINENO_LEN = 3;
  public static final String RCPT_HDR_LINE_NUM = "000";
  // SSO constants
  public static final String SSO_HEADER_USERNAME = "sso.header.username";
  public static final String CUSTOMER_OVERRIDES_PROPERTIES = "customer_overrides.properties";
  public static final String SSO_LOGGER = "SSOLogger.";
  public static final int REG_TRANS_LEN = 0;
  public static final Object A_UPC_01 = "Upc01";
  // Reprice constants
  public static final String ORDER_SHIPPED = "3700";
  public static final String SHIPMENT_SHIPPED = "1400";
  public static final String INVOICE_HOLD_INDICATOR = "InvoiceHoldIndicator";
  public static final String HOLD_INVOICE = "Hold Invoice";
  public static final String FINAL_SHIPPED = "1400.001";
  public static final String FINAL_SHIPMENT_0001_EX = "Final Shipment.0001.ex";
  public static final String SHIPMENT_CREATED_FOR_NON_SA = "1100.02";
  public static final String CHANGE_SHIPMENT_STATUS_TRAN = "CHANGE_SHMNT_STATUS.0001.ex";
  public static final String PO_INCLUDED_IN_SHIPMENT = "3350.0001";
  public static final String FINAL_SHIPMENT_0005_EX = "Final Shipment.0005.ex";
  public static final String SO_CANCEL = "Cancel";
  public static final int COSA_HT_REPORT_TIME = 3;
  public static final String KOHLS_CASH = "KOHLS_CASH";
  public static final String CREDIT_CARD_TYPE_KOHLS_CASH = "KOHLS CASH";
  public static final String DiscountChargeCategory = "Discount";
  public static final String SELECT_METHOD_WAIT = "WAIT";
  public static final String DIST_GROUP = "DistributionGroup";
  public static final String ALL_ITEM_ID = "ALL";
  public static final String DSV_PRIORITY = "4.00";
  public static final String INV_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
  public static final String DELETE_DIST_GROUP = "Delete";
  public static final String EQUALS = "=";
  public static final String DELIMITER = ";";
  public static final String TRAN_ID_ORDER_INVOICE_0001_EX = "KOHLS_ORDER_INVOICE.0001.ex";
  public static final String TRAN_ID_INCLUDE_INVOICE_0001_EX = "KOHLS_INCLUDE_INVOICE.0001.ex";
  public static final String AWAITING_INVOICE_CREATION = "3700.0003";
  public static final String AWAITING_ORDER_CLOSURE = "3700.0001";
  public static final String INVOICED = "3700.0004";
  public static final String MODIFY = "Modify";
  public static final String DELETE = "Delete";
  public static final String CREDIT_CARD = "Credit Card";
  public static final String GIFT_CARD = "Gift Card";
  public static final String A_SUSPEND_BOTH_PAYMENT_REFUND = "B";
  public static final String PREENC = "Preenc";
  public static final String DSV_NODE_RECEIPT_ID = "873";
  public static final String VGC_SHIP_NODE = "SVC";
  public static final String AUTHORIZATION = "AUTHORIZATION";
  public static final String CASH_ACTIVATION_HOLD = "CashActivationHold";
  public static final String CASH_ACTIVATION_REASON = "KCE Activation Hold";
  public static final String CODE_SHIP_NODES = "SHIP_NODES";
  // Hard Totals
  public static final String HD_DATE_FORMAT = "yyyy-MM-dd";
  public static final String HARD_TOTALS_KEY = "HardTotalsKey";
  public static final String SERVICE_GET_HARD_TOTALS_LIST = "GetHardTotalsListService";
  public static final String HD_GT = "GT";
  public static final String SERVICE_DROP_HARD_TOTALS = "DropHardTotalsService";
  public static final String SERVICE_GET_COSA_REPORT_RUN_LST = "GetCosaReportRunListService";
  public static final String SERVICE_CREATE_COSA_AGENT_RUN_REC = "CreateCosaAgentRunRecordService";
  public static final String SALES_TRANS_CNT_VAL = "1";
  public static final String TRANS_WITH_TAXES_VAL = "1";
  public static final String KMRC = "KMRC";
  public static final String KOHLS_GIFT_CARD = "KL_GIFT_CARD";
  public static final String CREDIT_CARD_VISA = "VISA";
  public static final String CREDIT_CARD_DISCOVER = "DISC";
  public static final String KOHLS_CHARGE_CARD = "KL_CHRG_CARD";
  public static final String CREDIT_CARD_MSTR_CARD = "MSTR_CARD";
  public static final String GIFT_CARD_SKU_ID = "GIFTCARD_SKU_ID";
  public static final String IS_PROCESS_AVAILABILITY_ACTIVE = "PRO_AVAIL_ACTIV";
  public static final String DSV_INV_ADJ_PROCESS_SUB_SERVICE = "DSVInvAdjProcessSubService";
  public static final String CREATE_HARD_TOTALS_SERVICE = "CreateHardTotalsService";
  public static final String HARD_TOTAL_HOUR = "HARD_TOTAL_HOUR";
  public static final String HARD_TOTAL_RECORDS = "HARD_TOTAL_REC";
  public static final String HARD_TOTAL_DAY = "HARD_TOTAL_DAY";
  // RelC Constants
  public static final String INS_TYPE_BOGO = "BOGO";
  public static final String TAX_NAME_SALES_TAX = "SALES_TAX";
  public static final String AWAIT_PAY_INFO = "AWAIT_PAY_INFO";
  public static final String OOB_HOLD = "OMSOutOfBalanceHold";
  public static final String ECOMM_HOLD = "EComOutOfBalanceHold";
  public static final String ECOMM_HOLD_REASON = "EComm Hold";
  public static final String ECOMM_HOLD_RESOLVE_REASON = "Resolving EComm Hold";
  public static final String SERVICE_KOHLS_CASH_TABLE_LIST = "KohlsGetCashTableList";
  // Start --- Added for PMR 54606,379,000 -- OASIS_SUPPORT 14/03/2012
  public static final String SHIP_VIA_VALUES = "SHIP_VIA_VALUES";
  public static final String IS_HAZ_IS_MILITARY = "IS_HAZ_IS_MILITARY";
  // End --- Added for PMR 54606,379,000 -- OASIS_SUPPORT 14/03/2012

  // Start -- added for PMR :05616,379,000 default carton type as "BOX"

  public static final String CARTON_TYPE_BOX = "BOX";

  // End -- added for PMR :05616,379,000 default carton type as "BOX"
  // Start -- Added for 74501,379,000 -- OASIS_SUPPORT 07/08/2012 //
  public static final String SERVICE_KOHLS_POST_AUDIT_MSG = "KohlsPostAuditMsgSyncService";
  public static final String SUPPLY_CORRECTION = "SupplyCorrection";
  public static final String AVAILABILITY_CORRECTION = "AvailabilityCorrection";
  // End -- Added for 74501,379,000 -- OASIS_SUPPORT 07/08/2012 //
  // offshore drop2
  public static final String API_GET_SHIPMENT_LIST_FOR_PACK_SHIPMENT_KEY_TEMPLATE_PATH =
      "global/template/api/getShipmentListForPackShipmentKey_output.xml";
  public static final String API_GET_SHIPMENT_DETAILS_PACK_SHIPMENT_TEMPLATE_PATH =
      "global/template/api/getShipmentDetailsForPackShipment_output.xml";
  public static final String A_SHIPMENT_LINE_KEY = "ShipmentLineKey";
  public static final String A_QUANTITY = "Quantity";
  // public static final String API_GET_SHIPMENT_DETAILS =
  // "getShipmentDetails";
  // public static final String API_GET_SHIPMENT_LIST = "getShipmentList";
  // public static final String API_GET_ITEM_LIST = "getItemList";
  public static final String API_GET_ITEM_LIST_FOR_CONTAINER_TYPE_TEMPLATE_PATH =
      "global/template/api/getItemListForContainerType_output";
  public static final String A_ENTERPRISE_CODE = "EnterpriseCode";
  public static final String A_SHIPMENT_KEY = "ShipmentKey";
  public static final String A_ORGANIZATION_CODE = "OrganizationCode";
  public static final String A_CALLING_ORGANIZATION_CODE = "CallingOrganizationCode";
  public static final String A_ITEM_GROUP_CODE = "ItemGroupCode";
  public static final String V_PROD = "PROD";
  public static final String A_IS_SHIPPING_CONTAINER = "IsShippingCntr";
  public static final String FLAG_Y = "Y";
  public static final String E_ITEM = "Item";
  public static final String E_SHIPMENT = "Shipment";
  public static final String A_CONTAINER_NO = "ContainerNo";
  public static final String E_CONTAINER = "Container";
  public static final String A_IS_PACK_PROCESS_COMPLETE = "IsPackProcessComplete";
  public static final String E_NEW_CONTAINER = "NewContainer";
  public static final String E_CONTAINERS = "Containers";
  public static final String API_CHANGE_SHIPMENT_CONTAINER = "changeShipmentContainer";
  public static final String API_CHANGE_SHIPMENT_CONTAINER_TEMPLATE_PATH =
      "global/template/api/changeShipmentContainer_output";
  public static final String A_SHIPMENT_CONTAINERIZED_FLAG = "ShipmentContainerizedFlag";
  public static final Object V_SHIPMENT_CONTAINERIZED = "03";
  public static final String E_ADDINFO = "AddInfo";
  public static final String A_DcmIntegrationRealTime = "DcmIntegrationRealTime";
  public static final String API_CHANGE_SHIPMENT = "changeShipment";
  public static final String API_CHANGE_SHIPMENT_STATUS = "changeShipmentStatus";
  public static final String API_PACK_SHIPMENT = "packShipment";
  public static final String API_PACK_SHIPMENT_TEMPLATE_PATH =
      "global/template/api/changeShipmentToAddContainer.xml";
  public static final String A_PACK_COMPLETE_TRANSACTION_ID = "PACK_SHIPMENT_COMPLETE";
  public static final String A_PACK_COMPLETE_BASE_DROP_STATUS = "1300";
  public static final String A_Shipment_Pack_In_Progress = "1100.04";
  public static final String A_SHIPMENT_PACK_TRANSACTION_ID = "SHIPMENT_PACK.0001.ex";
  public static final String A_CONTAINERS = "Containers";
  public static final String A_CONTAINER = "Container";
  public static final String A_CONTAINERSCM = "ContainerScm";
  public static final String A_LATEST_CONTAINER_SCM = "LatestContainerScm";
  public static final String V_SHIPMENT_CONTAINERIZED_01 = "01";
  public static final String V_SHIPMENT_CONTAINERIZED_02 = "02";
  public static final String V_SHIPMENT_CONTAINERIZED_03 = "03";
  public static final String V_SHIPMENT_PICK_LIST_PRINTED_STATUS = "1100.03";
  public static final String A_PICK_LIST_PRINT_TRANSACTION_ID = "PICK_LIST_PRINT.0001.ex";
  public static final String A_ACTION = "Action";
  public static final String V_DELETE = "Delete";
  public static final String API_UN_PACK_SHIPMENT = "unpackShipment";
  public static final String A_ACTION_TAKEN = "ActionTaken";
  public static final String V_ACTION_TAKEN_UNPACK = "unpack";
  public static final String V_ACTION_TAKEN_PACK = "pack";
  public static final String A_SHIPMENT_NO = "ShipmentNo";
  public static final String A_SHIP_NODE = "ShipNode";
  public static final String API_GET_SHIPMENT_LIST_FOR_UPDATE_CONTAINER_TRACKING =
      "global/template/api/getShipmentListForUpdateContainerTracking.xml";
  public static final String A_IS_NEW_CONTAINER = "IsNewContainer";
  public static final String SQL_STATEMENT_FOR_SEQ_YFS_CONTAINER_NO =
      "select SEQ_YFS_CONTAINER_NO.nextval as ContainerNo from dual";
  public static final String A_STATUS = "Status";
  public static final String STATUS_SHIPMENT_PICK_LIST_PRINTED = "1100.03";
  public static final String STATUS_SHIPMENT_PACK_IN_PROGRESS = "1100.04";
  public static final Integer V_ZERO = 0;
  public static final String A_ITEM_ID = "ItemID";
  public static final String A_BLANK = "";
  public static final String A_TOTAL_SHIPMENTS = "TotalShipments";
  public static final String A_SHIPMENT_TYPE = "ShipmentType";
  public static final String E_SHIPMENT_LINE = "ShipmentLine";
  public static final String E_SHIPMENT_LINES = "ShipmentLines";
  public static final String A_MAXIMUM_RECORDS = "MaximumRecords";
  public static final String A_PRINTER_ID = "PrinterID";
  public static final String E_ORDER_INVOICE = "OrderInvoice";
  public static final String E_PAYMENT_METHOD = "PaymentMethod";
  public static final String E_SHIPMENTS = "Shipments";
  public static final String API_UNPACK_SHIPMENT_TEMPLATE_PATH =
      "global/template/api/changeShipmentToUnPackContainer.xml";
  public static final String V_PACK = "Pack";
  public static final String V_UNPACK = "unpack";
  public static final String E_BASE_DROP_STATUS = "BaseDropStatus";
  public static final String V_BASE_DROP_STATUS = "1100.03";
  //
  public static final String A_NUMBER = "Number";
  //
  public static final String V_PREFIX = "KOHLS";
  public static final String V_MIDDLE = "SinglePrint";
  public static final String V_SUFFIX = "Service";
  public static final String V_AWAITING_PICKLIST = "Awaiting PickList";
  public static final String V_PRINT_LIST_PRINTED = "Printlist Printed";
  public static final String A_IS_PRINTLIST_PRINTED = "Is PrintList Printed";
  public static final String V_Y = "Y";
  public static final String SERVICE_JASPER_SERVICE1 = "Jasperservice1";
  public static final String A_IS_PICK_LIST_PRINTED = "IsPickListPrinted";
  public static final String A_SHIPMENT_LINES = "ShipmentLines";
  public static final String A_SHIPMENT_LINE = "ShipmentLine";
  public static final String A_UNIT_OF_MEASURE = "UnitOfMeasure";
  public static final String E_ITEM_NODE_DEFN = "ItemNodeDefn";
  public static final String A_ITEM_NODE_DEFN_KEY = "ItemNodeDefnKey";
  public static final String A_NODE = "Node";
  public static final String A_EXTN = "Extn";
  public static final String API_GET_ITEM_NODE_DEFN_DETAILS = "getItemNodeDefnDetails";
  public static final String A_ITEM_DESC = "ItemDesc";
  public static final String A_TOTE_ID = "ToteID";
  public static final String V_TOTE_ID = "1";
  public static final String A_PRIMARY_INFORMATION = "PrimaryInformation";
  public static final String A_LINE = "Line";
  public static final String A_LOCATION = "Location";
  public static final String A_EXTN_LOCATION_ID = "ExtnLocationID";
  public static final String A_EXTN_LINE_NO = "ExtnLineNo";
  public static final String E_EXTN = "Extn";
  public static final String A_TOTEID = "ToteId";
  public static final String E_PRINT_PACK_SHIPMENT = "PrintPackShipment";
  public static final String A_TOTAL_CARTS = "TotalCarts";
  public static final String A_TOTES_PER_CART = "TotesPerCart";
  public static final String KOHLS = "KOHLS";
  public static final String SERVICE_KOHLS_CHANGE_STATUS_MULTI_PRINT =
      "KOHLSChangeStatusMultiPrintService";
  public static final String MULTI_PRINT_SERVICE = "MultiPrintService";
  public static final String V_MIDDLE_PRINT = "PrintPickSlip";
  // added 6/5/12 from Punit Kumar
  public static final String API_GET_ORGANIZATION_LIST = "getOrganizationList";
  public static final String ATTR_SHIPNODESOURCE = "ExtnShipNodeSource";
  public static final String ATTR_RDC = "RDC";
  public static final String ATTR_STORE = "STORE";
  public static final String ATTR_RDC_STORE = "RDC_STORE";
  public static final String ATTR_FULFILLMENT_TYPE = "FulfillmentType";
  public static final String ATTR_GIFT_PRIORITY = "Gift_Priority";
  public static final String ATTR_ASSOCIATION_ACTION = "AssociationAction";
  public static final String ATTR_IS_NODE = "IsNode";
  public static final String ATTR_GIFT = "Gift";
  public static final String ATTR_MULTI = "Multi";
  public static final String ATTR_REGULAR = "Regular";
  public static final String ATTR_SINGLE = "Single";
  // added by puneet on 15th june - start
  public static final String E_SHIP_NODE = "ShipNode";
  public static final String E_MULTI_API = "MultiApi";
  public static final String E_CONTAINER_DETAIL = "ContainerDetail";
  public static final String E_API = "API";
  public static final String A_NAME = "Name";
  public static final String API_MOVE_LOCATION_INVENTORY = "moveLocationInventory";
  public static final String E_INPUT = "Input";
  public static final String E_MOVE_LOCATION_INVENTORY = "MoveLocationInventory";
  public static final String E_SOURCE = "Source";
  public static final String E_DESTINATION = "Destination";
  public static final String E_INVENTORY = "Inventory";
  public static final String E_INVENTORY_ITEM = "InventoryItem";
  public static final String A_PRODUCT_CLASS = "ProductClass";
  public static final String A_LOCATION_ID = "LocationId";
  public static final String V_NODE_DEFAULT_LOCATION = "Receiving";
  public static final String A_CASE_ID = "CaseId";
  public static final String A_Node = "Node";
  public static final String O_CONTAINER_ELEM = "sContainerElem";
  public static final String A_CONTAINER_TYPE = "ContainerType";
  public static final String V_CASE = "Case";
  public static final String SERVICE_POST_MESSAGE_CONFIRM_SHIPMENT =
      "KOHLSPostMessageInQueueForConfirmShipment";
  public static final String API_CONFIRM_CUSTOMER_PICK = "confirmCustomerPick";
  public static final String SERVICE_SOP_PRINT_PICK_TICKET = "KOHLSSopPrintPickTicketService";
  // added by puneet on 15th june - end
  // added by puneet on 16th june-start
  public static final String API_SHIPMENT_DETAIL_PICK_LIST =
      "global/template/api/getShipmentDetailsForPickList_output.xml";
  // added by puneet on 16th june - end
  // added by puneet on 17th june-start
  public static final String A_RECEIPT_ID = "ReceiptId";
  // added by puneet on 17th june - end
  public static final String A_SKU_QTY = "SkuQty";
  // public static final String A_CATALOG_ORG = "KOHLS.COM";
  public static final String A_CATALOG_ORG = "DEFAULT";
  // added by puneet on 20th june start
  public static final String A_CATALOG_ORG_CODE = "CatalogOrgCode";
  public static final String A_FORM_ID = "FormID";

  // added by puneet on 20th june end

  // added by kiran on 21th June
  public static final String V_UPC01 = "Upc01";
  public static final String A_ALIAS_NAME = "AliasName";
  public static final String A_ALIAS_VALUE = "AliasValue";
  public static final String SERVICE_KOHLS_PICK_SLIP_PRINT = "KOHLSPickSlipPrintService";
  public static final String A_ITEM_ALIAS_LIST = "ItemAliasList";
  public static final String A_ITEM_ALIAS = "ItemAlias";
  public static final String SERVICE_PACK_SLIP_PRINT_SERVICE = "KOHLSPackSlipPrintService";
  public static final String A_BARCODE_DATA = "BarCodeData";
  public static final String A_CONTEXTUAL_INFO = "ContextualInfo";
  public static final String A_ITEM_CONTEXTUAL_INFO = "ItemContextualInfo";
  public static final String A_BAR_CODE = "BarCode";
  public static final String A_TRANSLATIONS = "Translations";
  public static final String A_TRANSLATION = "Translation";
  public static final String A_TOTAL_ITEM_LIST = "TotalItemList";
  public static final String A_INVENTORY_UOM = "InventoryUOM";
  // added by puneet 25 june 2012 start
  public static final String V_COMMON_CODE_TYPE_FOR_SHIPNODE_DIR = "SHPNODE_PRT_DIR";
  public static final String E_COMMON_CODE = "CommonCode";
  public static final String A_CODE_TYPE = "CodeType";
  public static final String A_CODE_VALUE = "CodeValue";
  public static final String A_CODE_SHORT_DESC = "CodeShortDescription";
  public static final String V_DATE_TIME_FORMAT = "yyyyMMddHHmmss";

  // added by puneet 25 june 2012 end
  // added by shaila on 26th june
  public static final String A_IGNORE_ORDERING = "IgnoreOrdering";
  public static final String V_N = "N";
  public static final String V_MAXIMUM_RECORDS = "5000";
  public static final String E_ORDER_BY = "OrderBy";
  public static final String A_ATTRIBUTE = "Attribute";
  public static final String API_GET_SHIPMENT_DETAILS_PACK_SHIPMENT_TEMPLATE_PATH_1 =
      "global/template/api/getShipmentDetailsForPackShipment_output.xml";
  public static final String A_AWAITING_PICK_LIST = "1100.025";
  // added by puneet on 30 june 2012- start
  public static final String A_LABEL_PICK_TICKET = "LabelPickTicket";
  public static final String API_GET_SHIPMENT_DETAILS_RE_PRINT_SINGLE_PICK_SHIPMENT_TEMPLATE =
      "global/template/api/getShipmentDetailsForRePrintSinglePickShipment_output.xml";
  public static final String SERVICE_RE_PRINT_SINGLE_PICK_SHIPMENT =
      "KOHLSSinglePickRePrintService";
  public static final String API_CHANGE_SHIPMENT_STATUS_RE_PRINT_SINGLE_PICK_SHIPMENT_TEMPLATE =
      "global/template/api/changeShipmentStatus.xml";
  public static final String E_ORDER_LINE = "OrderLine";

  // added by puneet on 30 june 2012- end

  // added by Kiran on 2 july 2012- Start

  // added by Kiran on 2 july 2012- End
  // added by puneet on 4th july 2012 - start
  public static final String API_REPRINT_PICK_SLIP_SERVICE = "KOHLSSopPrintPickTicketService";
  // added by puneet on 4th july 2012 - end
  public static final String A_NODE_TYPE = "NodeType";
  public static final String V_STORE = "STORE";

  // added by kiran on 5th july 2012 - start

  // added by Saravana on 5 July 2012 - Start
  public static final String E_FRONT_PAGE = "FrontPage";
  public static final String A_SEQ_NO = "SeqNo";
  // added by Saravana on 5 July 2012 - End
  // added by Saravana on 6 July 2012 - Start
  public static final String E_ITEM_INFO = "ItemInformation";
  // added by Saravana on 6 July 2012 - End
  // added by Puneet on 8 July 2012 - Start
  public static final String A_SCAC = "SCAC";
  public static final String A_CARRIER_SERVICE_CODE = "CarrierServiceCode";
  public static final String A_CARRIER_ACCOUNT_NO = "CarrierAccountNo";
  // added by Puneet on 8 July 2012 - End
  // added by Saravana on 9 July 2012 - Start
  public static final String E_LINE_TAX = "LineTax";
  public static final String A_TAX_SYMBOL = "TaxSymbol";
  public static final String TAX_SYMBOL_T = "T";
  public static final String E_POPULATE_TAXES = "PopulateTaxes";
  public static final String E_POPULATE_TAX = "PopulateTax";
  // added by Saravana on 9 July 2012 - End
  // added by puneet on 26 july 2012 - start
  public static final String V_STATUS_LIST = "KOHLSShipmentStatusList";
  // added by puneet on 26 july 2012 - end
  // added by puneet on 09 Aug 2012 - start
  public static final String A_UPC_BARCODE_PICK_TICKET = "UpcBarcodePrint";
  // added by puneet on 09 Aug 2012 - End
  public static final String E_BACK_PAGE = "BackPage";
  public static final String A_DESCRIPTION = "Description";
  public static final String O_ADD_CONTAINER_OUTPUT = "AddContainerOutDoc";
  public static final String O_PRINT_PACK_SLIP = "PrintPackSlip";
  public static final String E_PRINT_PACK_DOC = "PrintPackDoc";

  public static final String A_PRINT_JASPER_REPORT = "PrintJasperReport";
  // Added for Mass Singles Print, Modified by Kiran on 20th Sept
  public static final String E_COMPLEX_QUERY = "ComplexQuery";
  public static final String E_OR = "Or";
  public static final String E_EXP = "Exp";
  public static final String A_VALUE = "Value";
  public static final String SHIP_TYPE_SINGLE_REGULAR = "Single_Regular";
  public static final String SHIP_TYPE_SINGLE_PRIORITY = "Single_Priority";
  public static final String SHIP_TYPE_SINGLE_GIFT = "Single_Gift";
  public static final String DELIMITER_SHIP_HASHMAP = "++";
  public static final String ESC_CHAR_DELIMITER_SHIP_HASHMAP = "\\++";
  public static final String E_PRINT_PACK_SHIPMENTS = "PrintPackShipments";

  public static final String A_AVAILABLE_QTY = "AvailableQuantity";
  public static final String STRING_ONE = "1";
  // Add by Puneet on 19th Sept
  public static final String API_KOHLS_PRINT_PACK_SLIP_SERVICE = "KOHLSProcessPrintPackSlipService";
  public static final String A_PRINT_BATCH_NUMBER = "PrintBatchNo";
  public static final String V_KOHLS_RE_PACKSHIP_JASPER = "/KohlsRePackShip.jasper";
  public static final String SERVICE_GET_MASS_PRINT_SINGLES_LIST_SERVICE =
      "KOHLSGetMassPrintSinglesListService";

  public static final String A_COMMITMENT_CODE = "CommitmentCode";

  public static final String SQL_STATEMENT_FOR_SEQ_YFS_PRINT_BATCH_ID =
      "select SEQ_YFS_PRINT_BATCH_ID.nextval as BatchID from dual";
  public static final String A_BATCH_ID = "BatchID";
  public static final String V_DATE_FORMAT = "yyyyMMdd";
  public static final String A_CART_NUMBER = "CartNo";
  public static final String A_TOTAL_CARTS_AVAILABLE = "TotalCartsAvailable";
  public static final String A_CART_NUMBER_AVAILABLE = "CartNoAvailable";
  public static final String A_PROFILE_ID = "ProfileID";
  public static final String A_EXTN_CART_NUMBER = "ExtnCartNumber";
  public static final String E_ATTRIBUTE = "Attribute";
  public static final String A_DESC = "Desc";
  public static final String A_IS_CONFIRM_SHIPMENT = "IsConfirmShipment";

  public static final String API_CHECK_TRACKING_NO_TEMPLATE_PATH =
      "global/template/api/getShipmentDetailsToCheckTrackingNo.xml";
  public static final String A_CONFIRM_SHIPMENT_STATUS = "1400";
  public static final String SHIP_TYPE_MULTI_REGULAR = "Multi_Regular";
  public static final String SHIP_TYPE_MULTI_PRIORITY = "Multi_Priority";
  public static final String SHIP_TYPE_MULTI_GIFT = "Multi_Gift";
  public static final String A_START_CART_NUMBER = "StartCartNo";
  public static final String A_PRINT_TYPE = "PrintType";
  public static final String V_SINGLE = "SINGLE";
  public static final String a_CONTAINER_NET_WEIGHT = "ContainerNetWeight";
  public static final String V_SERVICE_TYPE_USG = "USG";
  public static final String A_SERVICE_TYPE = "ServiceType";
  public static String V_SERVICE_TYPE_USL = "USL";
  public static String A_EXTN_IS_PO_BOX = "ExtnIsPOBox";

  public static final String A_IS_PRODUCT_FAMILY_SHIPMENT = "isProductFamilyShipment";

  public static final String SERVICE_KOHLS_MULTIAPI_INPUT_SORT_BY_ITEMID_XSL =
      "KOHLSSortMultiApiInputForMoveLocationInventoryByItemID";
  public static final String V_SELLER_ORGANIZATION_CODE = "KOHLS.COM";
  public static final String A_TOTAL_NUMBER_RECORDS = "TotalNumberOfRecords";
  public static final String ATTR_TOTES_PER_CART = "TotesPerCart";
  public static final String E_AVAILABLE_CARTS = "AvailableCarts";
  public static final String A_CARTS_MULTI_REGULAR = "MultiRegular";

  public static final String A_CARTS_MULTI_PRIORITY = "MultiPriority";

  public static final String A_CARTS_MULTI_GIFT = "MultiGift";
  public static final String A_IS_PICKTICKET_PRINTED = "IsPickTicketPrinted";

  // Add by Kiran 17th Dec
  public static final String E_ITEM_NODE_DEFN_LIST = "ItemNodeDefnList";
  public static final String A_EXTN_PRODUCT_FAMILY = "ExtnProductFamily";
  public static final String API_GET_ITEM_NODE_DEFN_LIST = "getItemNodeDefnList";
  public static final String V_MULTI_PRODUCT_FAMILY = "Multi_Product_Family";
  public static final String A_EXTN_SHIPMENT_FAMILY = "ExtnShipmentFamily";
  // Start -- added for central stock transfer issue.
  public static final String WAREHOUSE_TRAN = "WAREHOUSE_TRAN";
  public static final String STATUS_SEND_RELEASE_TO_WMOS = "3200.01";
  public static final String TRAN_ID_SEND_TO_RELEASE_TO_WMOS = "KOHLS_SEND_TO_RELEASE.0006.ex";
  public static final String TO_DOCUMENT_TYPE = "0006";
  public static final String API_GET_ORDER_RELEASE_LIST = "getOrderReleaseList";

  // End -- added for central stock transfer issue.

  // Added for Pricing and Promotions for 7/26 release
  public static final String E_LINE_PRICE_INFO = "LinePriceInfo";
  public static final String A_UNIT_PRICE = "UnitPrice";
  public static final String A_GUID = "Guid";
  public static final String E_MODIFIER = "Modifier";
  public static final String E_PARENT_DISCOUNT_GUID = "ParentDiscountGuid";
  public static final String E_PROMOTION = "Promotion";
  public static final String E_PROMOTIONS = "Promotions";
  public static final String A_EXTN_PLU_OFFER_RESPONSE = "ExtnPluOfferResponse";
  public static final String A_EXTN_PLU_OFFER_RESPONSE_FLAG = "ExtnPluOfferResponseFlag";
  public static final String A_PROMOTION_ID = "PromotionId";
  public static final String A_TYPE_PLU = "type";
  public static final String A_CONTENT = "Content";
  public static final String A_TYPE_REQUEST = "Type";
  public static final String A_FRAME = "Frame";
  public static final String E_COMPONENT = "Component";
  public static final String E_PARAMETERS = "Parameters";
  public static final String A_STORE = "STORE";
  public static final String A_LOOKUPTYPE = "LOOKUPTYPE";
  public static final String A_KEY = "KEY";
  public static final String A_RESET = "Reset";
  public static final String E_PROMO = "Promo";
  public static final String E_RECORD = "RECORD";
  public static final String E_AWARDS = "Awards";
  public static final String A_PRMPT_FOR_PRIC_IND = "PRMPT_FOR_PRIC_IND";

  public static final String A_UNT_RTL_AMT = "UNT_RTL_AMT";
  public static final String E_TEMP = "Temp";
  public static final String A_EXTN_TAXABLE_AMOUNT = "ExtnTaxableAmount";
  public static final String E_GUID = "Guid";
  public static final String E_AWARD = "Award";
  public static final String A_AWARD_APPLIED = "AwardApplied";
  public static final String A_AWARD_AMOUNT = "AwardAmount";
  public static final String E_SELLING_PRICE_DELTA = "SellingPriceDelta";
  public static final String E_PLU_FILE = "PLUFile";
  public static final String A_UPC = "UPC";
  public static final String A_UPC_CODE = "UPCCode";
  public static final String A_SKU_NBR = "SKU_NBR";
  public static final String A_TAX_PRD_CDE = "TAX_PRD_CDE";
  public static final String A_DISC_ELIG_IND = "DISC_ELIG_IND";
  public static final String A_TAX_PRODUCT_CODE = "TaxProductCode";
  public static final String A_EXTN_IS_DISCOUNTABLE = "ExtnIsDiscountable";
  public static final String A_LOC_SKU_STAT_CDE = "LOC_SKU_STAT_CDE";
  public static final String A_EXTN_SKU_STATUS_CODE = "ExtnSkuStatusCode";
  public static final String A_LAST_NCLR_RTL_AMT = "LAST_NCLR_RTL_AMT";
  public static final String A_EXTN_NON_CLEARANCE_AMT = "ExtnNonClearanceAmt";
  // public static final String A_DESCRIPTION = "Description";
  public static final String A_MAX_LINE_STATUS = "MaxLineStatus";
  public static final String A_EXTN_PLU_PROMO_RESPONSE = "ExtnPluPromoResponse";
  public static final String A_EXTN_PLU_PROMO_RESPONSE_FLAG = "ExtnPluPromoResponseFlag";
  public static final String PLU_MESSAGE = "MESSAGE";
  public static final String A_MLT_PRPT_IND = "MLT_PRPT_IND";
  public static final String A_RETAIL_PRICE = "RetailPrice";
  public static final String A_EXTN_SELLING_PRICE = "ExtnSellingPrice";
  public static final String A_EXTN_NET_PRICE = "ExtnNetPrice";
  public static final String A_EXTN_RECPTT_RTN_PRICE = "ExtnRecpttRtnPrice";
  public static final String A_EXTN_BOGO_GPID = "ExtnBogoGPID";
  public static final String A_EXTN_PWP_GROUP_ID = "ExtnPWPGroupID";
  public static final String A_EXTN_BUY_ITEM = "ExtnBuyItem";
  public static final String E_XST_OFR_SECT = "XST_OFR_SECT";
  public static final String A_EFF_END_DTE = "EFF_END_DTE";
  public static final String A_EFF_BEG_DTE = "EFF_BEG_DTE";
  public static final String A_REDMN_SUPVR_OVRRID_DTE = "REDMN_SUPVR_OVRRID_DTE";

  public static final String E_HEADER_TAXES = "HeaderTaxes";
  public static final String A_TAXABLE_FLAG = "TaxableFlag";
  public static final String E_ITEM_LIST = "ItemList";
  public static final String E_PRICING = "Pricing";
  public static final String A_REGULAR_PRICE = "RegularPrice";
  public static final String A_DEPARTMENT = "Department";
  public static final String A_MAJOR_CLASS = "MajorClass";
  public static final String A_SUB_CLASS = "SubClass";
  public static final String A_VENDOR_STYLE = "VendorStyle";
  public static final String A_SKU_STATUS = "SkuStatus";
  public static final String A_SKU = "Sku";
  public static final String A_EXCLUDE_FLAG = "ExcludeFlag";
  public static final String A_HIERARCHY_LEVEL = "HierarchyLevel";
  public static final String E_MERCHANDISE_SET = "MerchandiseSet";
  public static final String A_BWP_GET_QTY = "BWP_GET_QTY";
  public static final String A_BWP_GET_DOL_OFF_AMT = "BWP_GET_DOL_OFF_AMT";
  public static final String A_BWP_GET_PRPT_AMT = "BWP_GET_PRPT_AMT";
  public static final String A_BWP_GET_PCT_OFF_PCT = "BWP_GET_PCT_OFF_PCT";
  public static final String A_MDSE_HIER_CDE = "MDSE_HIER_CDE";
  public static final String A_IE_IND = "IE_IND";
  public static final String A_DEPT_NBR = "DEPT_NBR";
  public static final String A_MAJ_CL_NBR = "MAJ_CL_NBR";
  public static final String A_SUB_CL_NBR = "SUB_CL_NBR";
  public static final String A_STYL_ID = "STYL_ID";
  public static final String A_TKT_CLOR_CDE = "TKT_CLOR_CDE";
  public static final String A_GET_PRICE_POINT = "GetPricePoint";
  public static final String A_GET_DOLLAR = "GetDollar";
  public static final String A_GET_DOLLAR_OFF = "GetDollarOff";
  public static final String A_GET_PERCENT = "GetPercent";
  public static final String A_GET_PERCENT_OFF = "GetPercentOff";

  public static final String A_GET_QTY = "GetQty";
  public static final String BUY = "BUY";
  public static final String GET = "GET";
  public static final String A_EMP_DISC_CODE = "EmpDiscCode";
  public static final String A_NON_DISCOUNTABLE_FLAG = "NonDiscountableFlag";
  public static final String A_TAX_CODE_INDICATOR = "TaxCodeIndicator";
  public static final String A_EMP_DISC_CDE = "EMP_DISC_CDE";
  public static final String A_MDSE_TX_CDE = "MDSE_TX_CDE";
  public static final String A_PROMO_CODE = "PromoCode";
  public static final String A_PROMO_INTFC_ID = "PROMO_INTFC_ID";
  public static final String A_LINKED_PROMO_CODE = "LinkedPromoCode";
  public static final String A_PRICE_POINT = "PricePoint";
  public static final String A_PROMO_SCHEME = "PromoScheme";
  public static final String A_BUY_QTY = "BuyQty";
  public static final String A_BUY_QUANTITY = "BuyQuantity";
  public static final String A_BUY_QTY_PROMO = "BUY_QTY";
  public static final String A_GET_QTY_PROMO = "GET_QTY";
  public static final String A_PERCENT_OFF = "PercentOff";
  public static final String A_PROMO_INTFC_SUB_ID = "PROMO_INTFC_SUB_ID";
  public static final String A_DISC_AMT = "DISC_AMT";
  public static final String A_DISC_PCT = "DISC_PCT";
  public static final String A_ACTL_STRT_DATE = "ACTL_STRT_DATE";

  public static final String A_BEGIN_DATE = "BeginDate";
  public static final String A_END_DATE = "EndDate";
  public static final String A_OVERRIDE_DATE = "OverideDate";
  public static final String A_BUY_DOLLAR = "BuyDollar";
  public static final String A_BUY_CRITERIA_OPERATOR = "BuyCriteriaOperator";
  public static final String A_GET_CRITERIA_OPERATOR = "GetCriteriaOperator";
  public static final String A_LIMIT_PER_TRANSACTION = "LimitPerTransaction";
  public static final String A_BUY_AMT = "BUY_AMT";
  public static final String A_BWP_BUY_CNCTR_CDE = "BWP_BUY_CNCTR_CDE";
  public static final String A_BWP_GET_CNCTR_CDE = "BWP_GET_CNCTR_CDE";
  public static final String A_LMT_PER_TRN_QTY = "LMT_PER_TRN_QTY";

  public static final String A_ACTL_STRT_TIME = "ACTL_STRT_TIME";
  public static final String A_ACTL_END_DATE = "ACTL_END_DATE";
  public static final String A_ACTL_END_TIME = "ACTL_END_TIME";
  public static final String A_PROMO_START = "PromoStart";
  public static final String A_PROMO_END = "PromoEnd";
  public static final String DATE = "MM/dd/yy HH:mm:ss";
  public static final String SKU = "SKU";
  public static final String OFFER = "OFFER";
  public static final String A_CALL_BACK = "CALLBACK";
  public static final String CONST_CANCEL = "9000";
  public static final String A_SELLING_PRICE = "SellingPrice";
  public static final String A_TAXABLE_PRICE = "TaxablePrice";
  public static final String A_NET_PRICE = "NetPrice";
  public static final String A_RECEIPT_RETURN_PRICE = "ReceiptReturnPrice";

  public static final String E_BUY_CRITERIA = "BuyCriteria";
  public static final String E_GET_CRITERIA = "GetCriteria";
  public static final String E_XST_OFR_BWP = "XST_OFR_BWP";
  public static final String A_BWP_SELN_TYP_CDE = "BWP_SELN_TYP_CDE";
  public static final String E_CRITERIA = "Criteria";
  public static final String A_TIER_LEVEL = "TierLevel";
  public static final String A_TIER_LVL_NBR = "TIER_LVL_NBR";
  public static final String A_CRITERIA_TYPE = "CriteriaType";
  public static final String A_BWP_BUY_QTY = "BWP_BUY_QTY";
  public static final String A_BWP_BUY_AMT = "BWP_BUY_AMT";
  public static final String A_BWP_BUY_TOL_AMT = "BWP_BUY_TOL_AMT";
  public static final String A_BOGO_GRP_CODE = "BogoGrpCode";
  public static final String A_BUY_DOLLAR_TOLERANCE = "BuyDollarTolerance";
  public static final String E_OFFER = "Offer";
  public static final String A_SCANNED_SEQUENCE = "ScannedSequence";
  public static final String A_OFFER_ID = "OfferId";
  public static final String E_XST_OFR = "XST_OFR";
  public static final String A_SCHEME_CODE = "SchemeCode";
  public static final String A_DISCOUNT_LEVEL = "DiscountLevel";
  public static final String A_APPLICATION_CODE = "ApplicationCode";
  public static final String A_OFFER_TYPE = "OfferType";
  public static final String A_PROMO_SCHM_CDE = "PROMO_SCHM_CDE";
  public static final String A_DISC_LVL_CDE = "DISC_LVL_CDE";
  public static final String A_BWP_ITM_APPL_CDE = "BWP_ITM_APPL_CDE";
  public static final String A_OFR_USG_TYP_CDE = "OFR_USG_TYP_CDE";

  public static final String A_PWP_GWP_GROUP_CODE = "PwpGwpGroupCode";
  public static final String A_MODIFIER_ACTIVE = "ModifierActive";
  public static final String A_OFR_ID = "OFR_ID";
  public static final String A_CUSTFACG_SHRT_DESC = "CUSTFACG_SHRT_DESC";
  public static final String A_AWARD_ID = "AwardId";
  public static final String A_EXTN_TOTAL_SAVINGS = "ExtnTotalSavings";
  public static final String PLUMGROVRID = "PLUMGROVRID";
  public static final String PLUOFFREXPD = "PLUOFFREXPD";
  public static final String PLUOFFRNOTSTRT = "PLUOFFRNOTSTRT";
  public static final String PLUPRICEREQ = "PLUPRICEREQ";
  public static final String A_RCPT_CMMT_TXT = "RCPT_CMMT_TXT";
  public static final String E_LINE_OVERALL_TOTALS = "LineOverallTotals";
  public static final String E_ERRORCODE = "ERRORCODE";
  public static final String E_NOTONFILE = "NOTONFILE";
  public static final String PLUCALLBACK = "PLUCALLBACK";
  public static final String PLU = "PLU";
  public static final String REQUEST = "Request";
  public static final String A_TRAN_DATE_TIME = "TRANDATETIME";
  public static final String MM_DD_YY = "MMddyy";
  public static final String MM_DD_YYYY = "MM/dd/yyyy";
  public static final String HH_MM_SS_SSS = "HH:mm:ss:SSS";
  public static final String MM_DD_YYYY_HH_MM_SS_SSS = "MM/dd/yyyy HH:mm:ss:SSS";

  public static final String A_TAXABLE_PRICE_DELTA = "TaxablePriceDelta";
  public static final String A_NET_PRICE_DELTA = "NetPriceDelta";
  public static final String A_TIER_ACTIVATION_ACHIEVED = "TierActivationAchieved";
  public static final String A_TIER_PERCENT_ACHIEVED = "TierPercentAchieved";
  public static final String A_TIER_LEVEL_ACHIEVED = "TierLevelAchieved";
  public static final String A_EXTN_TAX_DELTA = "ExtnTaxDelta";
  public static final String A_EXTN_NET_DELTA = "ExtnNetDelta";
  public static final String A_EXTN_TIER_ACT_DELTA = "ExtnTierActDelta";
  public static final String A_EXTN_TIER_PER_DELTA = "ExtnTierPerDelta";
  public static final String A_EXTN_TIER_LVL_ACHVD = "ExtnTierLvlAchvd";
  public static final String PROMO_DISCOUNT = "PromoDiscount";
  public static final String OFFER_DISCOUNT = "OfferDiscount";

  public static final String A_GP_PRIC_ID = "GP_PRIC_ID";
  public static final String A_GP_RTL_AMT = "GP_RTL_AMT";
  public static final String A_GP_RTL_QTY = "GP_RTL_QTY";
  public static final String A_BUY_ITEM = "BuyItem";
  public static final String REMOVE = "REMOVE";
  public static final String A_CHARGE_PER_LINE = "ChargePerLine";
  public static final String ZERO = "0";
  public static final String A_IS_PROMOTION_ON_ORDER_LINE = "IsPromotionOnOrderLine";
  public static final String A_IS_PROMOTION_ON_ORDER = "IsPromotionOnOrder";
  public static final String VALIDATE_PROMOTION_AWARD = "ValidatePromotionAward";
  public static final String A_IS_BILLABLE = "IsBillable";
  public static final String A_IS_DISCOUNT = "IsDiscount";
  public static final double ZERO_DBL = 0.00;
  public static final int ZERO_INT = 0;
  public static final int FIVE_INT = 5;
  public static final int HUNDRED_INT = 100;
  public static final String ZERO_STR = "0.00";
  public static final String ENCODING_VALUE = "ISO-8859-1";
  public static final String A_STORE_APE = "Store";
  public static final String A_EVNT_TYP_CDE = "EVNT_TYP_CDE";
  
  // ended for Pricing and Promotions for 7/26 release

  // Sales Hub Constants
  public static final String GET_ORDER_LIST_OUTPUT =
      "/global/template/api/POC/saleshub/POC_getOrderListForSalesHub.xml";
  public static final String GET_VOID_CHARGE_TRANSACTION_OUTPUT =
      "/global/template/api/POC/saleshub/POC_getVoidTransactionListForSalesHub.xml";
  public static final String GET_ITEM_LIST =
      "global/template/api/POC/saleshub/POC_getItemListForSalesHub.xml";
  public static final String ATTR_LINE_DETAILS = "LineDetails";
  public static final String ATTR_LINE_DETAIL = "LineDetail";
  public static final String ATTR_PAYMENT_KEY = "PaymentKey";
  public static final String API_GET_CHARGE_TRANSACTION_LIST = "getChargeTransactionList";
  public static final String API_GET_SIGN_CAP_LIST_FOR_POS = "getSigCapListForPOS";
  public static final String ATTR_CHARGE_TRANSACTION_DETAIL = "ChargeTransactionDetail";
  public static final String ATTR_VOID_TRANSACTION = "VoidTransaction";
  public static final String ATTR_CHARGE_TRANSACTION_DETAILS = "ChargeTransactionDetails";
  public static final String ATTR_INVOICE_HEADER = "InvoiceHeader";
  public static final String ATTR_ORDER_INVOICE_KEY = "OrderInvoiceKey";
  public static final String ATTR_SIGN_CAP = "SigCap";
  public static final String ATTR_SIGN_CAP_LIST = "SigCapList";
  public static final String STATIC_CONSTANT_VOID = "V";
  public static final String STATIC_CONSTANT_SUBMITTED = "S";
  public static final String ATTR_VOID_TENDER_TRANSACTIONS = "VoidTenderTransactions";
  public static final String STATIC_CONSTANT_VOIDED_TRANSACTION_PROCEDURE_ID = "204";
  public static final String STATIC_CONSTANT_SUSPENDED_TRANSACTION_PROCEDURE_ID = "202";
  public static final String STATIC_CONSTANT_CREATE_TRANSACTION_PROCEDURE_ID = "201";
  public static final String API_GET_TRANSACTION_AUDIT_LIST_FOR_POS =
      "getTransactionAuditListForPOS";
  public static final String API_GET_TRANSACTION_AUDIT_DETAILS_FOR_POS =
      "getTransactionAuditDetailsForPOS";
  public static final String ATTR_TRANSACTION_AUDIT = "TransactionAudit";
  public static final String ATTR_TRANSACTION_AUDITS = "TransactionAudits";
  public static final String ATTR_ORDER_NUMBER = "OrderNumber";
  public static final String ATTR_PROCEDURE_ID = "ProcedureID";
  public static final String ATTR_AMOUNT = "Amount";
  public static final String ATTR_TERMINAL_ID = "TerminalID";
  public static final String ATTR_TRANS_AUDIT_KEY = "TransAuditKey";
  public static final String ATTR_TRANS_NUM = "TransactionNumber";
  public static final String ATTR_ORIGINAL_TRANS_NUM = "OriginalTransactionNumber";
  public static final String ATTR_DATE_TIME = "DateTime";
  public static final String ATTR_AUTH_START_DATE = "AuthStartDate";
  public static final String ATTR_AUTH_END_DATE = "AuthEndDate";
  public static final String ATTR_BUSINESS_DAY = "BusinessDay";
  public static final String ATTR_OPERATOR_ID = "OperatorID";
  public static final String ATTR_LINE_DETAIL_TRAN_QUANTITY = "LineDetailTranQuantity";
  public static final String ATTR_UPC_CODE = "UPCCode";
  public static final String ATTR_TAX_PRODUCT_CODE = "TaxProductCode";
  public static final String ATTR_UNIT_COST = "UnitCost";
  // added for 08/31
  public static final String ATTR_EXTN_SALES_HUB = "ExtnSalesHub";
  public static final String ATTR_IS_PLASTIC_GIFT_CARD = "ExtnIsPlasticGiftCard";
  public static final String ATTR_IS_VIRTUAL_GIFT_CARD = "ExtnIsVirtualGiftCard";
  public static final String ATTR_PRODUCT_LINE = "ProductLine";
  public static final String ATTR_VALUE_CARDS = "ValueCards";
  public static final String ELEM_STORED_VALUE_LINE = "StoredValueLine";
  public static final String API_GET_STORED_VALUE_LINE_LIST_FOR_POS =
      "getStoredValueLineListForPOS";

  // Cosa Feed Constants

  public static final String STRING_ELEVEN = "11";
  public static final String API_GET_STORE_PRODUCT_ACC_LIST_FOR_POS =
      "getStoreProductAccListForPOS";
  public static final String API_GET_ACCOUNT_TOTAL_LIST_FOR_POS = "getAccountTotalListForPOS";
  public static final String ATTR_STORE_PRODUCT_ACC = "StoreProductAcc";
  public static final String ATTR_STORE_ID = "StoreID";
  public static final String ATTR_ACCOUNT_TOTAL = "AccountTotal";
  public static final String ATTR_ENTRY_TYPE = "EntryType";
  public static final String STRING_ACTUAL = "Actual";
  public static final String STRING_EXPECTED = "Expected";
  public static final String ATTR_INVOICE_DETAIL = "InvoiceDetail";
  public static final String ATTR_COSA_FEED = "CosaFeed";
  public static final String ATTR_HARD_TOTALS = "HardTotals";
  public static final String ATTR_SALES_AUDIT_DETAILS = "SalesAuditDetails";
  public static final String ATTR_ACCOUNT = "Account";
  public static final String API_GET_ACCOUNT_LIST_FOR_POS = "getAccountListForPOS";

  // End -- added for central stock transfer issue.

  // Start -- constants added for payments.
  public static final String GET_ORDER_LIST_TEMPLATE =
      "<OrderList><Order OperatorID='' OrderHeaderKey='' PosSequenceNo='' PostVoided='' SellerOrganizationCode=''  TerminalID='' ><Extn ExtnOrigPosSequenceNo='' ExtnDLForSys='' ExtnSuspendSeqNum=''/></Order></OrderList>";
  public static final String A_TERMINAL_ID = "TerminalID";
  public static final String A_STORE_ID = "StoreID";
  public static final String A_POS_SEQUENCE_NO = "PosSequenceNo";
  public static final String CHARGE = "CHARGE";
  public static final String KOHLS_POC_CC_PAYMENT_WEBSERVICE = "KohlsPoCCCPaymentWebService";
  public static final String KOHLS_PAY_DECLINED = "DECLINED";
  public static final String A_PS2000DATA = "PS2000Data";
  public static final String A_SEQUENCE_NUMBER = "SequenceNumber";
  public static final String A_BANK_RESPONSE_CODE = "BankResponseCode";
  public static final String A_POSTING_DATE = "PostingDate";
  public static final String A_RETRIEVAL_REF_NUMBER = "RetrievalRefNumber";
  public static final String A_NETWORK_ID = "NetworkId";
  public static final String A_TRACE_AUDIT_NUMBER = "TraceAuditNumber";
  public static final String A_AMOUNT = "Amount";
  public static final String A_DEPOSIT_DATA = "DepositData";
  public static final String A_APPROVAL_NUMBER = "ApprovalNumber";
  public static final String A_AVS_RESP = "AVSResp";
  public static final String E_PROCESS_TRANS_REQ = "ProcessTransactionRequest";
  public static final String E_TRANSACTION = "Transaction";
  public static final String A_DEBIT_ACK_REQ_MESSAGE = "DebitAckReqMessage";
  public static final String A_DEBIT_ACK = "DebitAck";
  public static final String E_REQUEST = "Request";
  public static final String E_RESPONSE = "Response";
  public static final String E_ACTION_CODE = "ActionCode";
  public static final String A_DEBIT_ACK_RESP_MESSAGE = "DebitAckRespMessage";
  public static final String POC = "PoC";
  public static final String A_CHANNEL = "Channel";
  public static final String E_TOKEN = "Token";
  public static final String A_CARD_NUMBER = "CardNumber";
  public static final String INTERNAL = "internal";
  public static final String PROTEGRITY = "Protegrity";
  public static final String A_TYPE = "Type";
  public static final String A_PROVIDER = "Provider";
  public static final String SALE = "Sale";
  public static final String VOID_SALE = "VoidSale";
  public static final String A_TRANSACTION_REQUEST_TYPE = "TransactionRequestType";
  public static final String A_REVERSAL = "Reversal";
  public static final String A_TRANSACTION_NUMBER = "TransactionNumber";
  public static final String A_REQUEST_TYPE = "RequestType";
  public static final String A_IS_SWIPED = "IsSwiped";
  public static final String TRUE = "true";
  public static final String N_100 = "100";
  public static final String A_CARD_EXPIRATION_DATE = "CardExpirationDate";
  public static final String A_CVVCODE = "CVVCode";
  public static final String A_SWIPEDATA = "SwipeData";
  public static final String A_PAYMENT_TYPE = "PaymentType";
  public static final String A_TRANSACTION_TYPE = "TransactionType";
  public static final String DEBIT_CARD = "DEBIT_CARD";
  public static final String A_PIN_BLOCK = "PinBlock";
  public static final String A_POS_ECHO = "PosEcho";
  public static final String A_ZIP_CODE = "ZipCode";
  public static final String A_DATE_TIME = "DateTime";
  public static final String A_STORE_NUMBER = "StoreNumber";
  public static final String A_TERMINAL_NUMBER = "TerminalNumber";
  public static final String STR_EXCEPTION = "Exception";
  public static final String N_PG_SUCCESS = "0";
  public static final String N_PG_SOFT_REFFERAL = "1";
  public static final String N_PG_EDIT_ERROR = "2";
  public static final String N_PG_INVALID_FUNDS = "3";
  public static final String N_PG_DECLINE = "7";
  public static final String N_PG_INVALID_PIN = "6";
  public static final String N_PG_OFFLINE = "9";
  public static final String N_PG_REFERRAL = "8";
  public static final String N_PG_INVALID = "5";

  // Check Tender response code : START

  public static final String N_PG_DEPENDENCY = "4";

  // Check Tender responses code : END

  // Response to Gravity.
  public static final String N_TCX_CAL_FOR_AUTHORIZATION = "1";
  public static final String N_TCX_DECLINED = "5";
  public static final String N_TCX_REQUEST_FOR_VALID_PIN = "55";
  public static final String N_TCX_CANCELED = "4";
  public static final String N_TCX_SECOND_ID_NEEDED = "81";

  // end of payments

  // Start : added for Taxware
  public static final String POC_TAXWARE_DOWN_ERROR_CODE = "503";
  public static final String POC_TAXWARE_DOWN_ERROR_MESSAGE = "Unable to complete request(TAXWARE)";

  public static final String POC_TAXWARE_TIMEOUT_ERROR_CODE = "TIMEOUT";
  public static final String POC_TAXWARE_TIMEOUT_ERROR_MESSAGE =
      "Unable to complete request(TAXWARE)";
  // End : added for Taxware

  // Start -- added for Customer lookup exceptions
  public static final String POC_MDM_DOWN_ERROR_CODE = "503";
  public static final String POC_MDM_DOWN_ERROR_MESSAGE =
      "SIS/MDM server down, cannot connect to customer system";

  public static final String POC_TIMEOUT_ERROR_CODE = "TIMEOUT";
  public static final String POC_TIMEOUT_ERROR_MESSAGE =
      "Timeout occurred while calling connecting to the customer system, please retry";

  public static final String POC_OTHER_ERROR_CODE = "400";
  public static final String POC_OTHER_ERROR_MESSAGE = "Unable to complete request(TAXWARE)";

  public static final String POC_NO_RECORD_FOUND_ERROR_CODE = "NO_RECORD_FOUND";
  public static final String POC_NO_RECORD_FOUND_ERROR_MESSAGE =
      "No record found matching your search criteria";

  public static final String POC_TOO_MANY_RECORD_FOUND_ERROR_CODE = "TOO_MANY_RECORD_FOUND";
  public static final String POC_TOO_MANY_RECORD_FOUND_ERROR_MESSAGE =
      "Too many records found, please refine your search";
  public static final String KOHLS_POC_PLU_WEB_SERVICE = "KohlsPoCPLUWebService";
  public static final String KOHLS_POC_APE_WEB_SERVICE = "KohlsPoCAPEWebService";
  public static final String KOHLS_POC_TAX_WEB_SERVICE_UTIL = "KohlsPocTaxServiceUtil";
  public static final String A_TRAN_DATE_TIME_APE = "TranDateTime";

  public static final int THOUSAND_INT = 1000;
  public static final String PERCENT_SYMBOL = "%";

  // End -- added for Customer lookup exception

  // Valid Promo scheme Code List
  public static final String PROMO_GROUP_PROMO = "0300";
  public static final String PROMO_TIER_BUY_DLR_GET_PERCENT_OFF = "0400";
  public static final String PROMO_TIER_BUY_QTY_GET_PERCENT_OFF = "0402";
  public static final String PROMO_REBATE = "0700";
  public static final String PROMO_BOGO_GET_ONE_GET_FREE = "0800";
  public static final String PROMO_BOGO_GET_ONE_FOR_PERCENT_OFF = "0801";
  public static final String PROMO_BOGO_GET_ONE_FOR_PRICE_POINT = "0802";

  // Award Description
  public static final String CLEARANCE = "Clearance";
  public static final String FOR_$ = "for $";
  public static final String SPACE = " ";
  public static final String GET_1 = "Get 1";
  public static final String FREE = "Free";
  public static final String A_EXTN_MANAGER_OVERRIDE_PROVIDED = "ExtnMgrOverrideProvided";
  public static final String BUY_BOGO_DESC = "Buy";
  public static final String A_PROMOTION_APPLIED = "PromotionApplied";

  public static final String PROMO_GROUP_PRICING_PROMO = "0350";
  public static final String BUY_QTY_GET_PRICE_POINT_PROMOTION =
      "BUY_QTY_GET_PRICE_POINT_PROMOTION";
  public static final String BUY_QTY_GET_PERCENTAGE_PROMOTION = "BUY_QTY_GET_PERCENTAGE_PROMOTION";
  public static final String BUY_QTY_GET_FREE_PROMOTION = "BUY_QTY_GET_FREE_PROMOTION";
  public static final int ONE_INT = 1;
  public static final int MINUS_ONE = -1;
  public static final int THREE_INT = 3;
  public static final String A_DRAFT_ORDER_FLAG = "DraftOrderFlag";

  public static final String E_EXCEPTION = "EXCEPTION";
  public static final String PLUSERVDOWN = "PLUSERVDOWN";

  public static final String A_EXTN_TAX_PRODUCT_CODE = "ExtnTaxProductCode";
  public static final String EMPTY = "";
  public static final String LEFT_BRACKET = "(";
  public static final String RIGHT_BRACKET = ")";

  // Newly added for 8/31 start
  public static final String EXTN_REQUEST_DATE_TIME = "ExtnRequestDateTime";

  // Sus

  public static final String A_COUPON_TYPE = "CouponType";
  public static final String E_DATA = "Data";
  public static final String A_AUTH_RESPONSE_CODE = "AuthResponseCode";
  public static final String A_ERROR_MESSAGE_TO_DISPLAY = "ErrorMessageToDisplay";
  public static final String A_OPERATOR_ID = "OperatorID";
  public static final String A_ORDER_DATE = "OrderDate";
  public static final String A_EXTN_REQUEST_DATE_TIME = "ExtnRequestDateTime";
  public static final String A_EXTN_ORIGINAL_RECEIPT_ID = "ExtnOriginalReceiptID";
  public static final String A_EXTN_COUPON_SCANNED = "ExtnCouponScanned";
  public static final String A_EXTN_COUPON_PIN = "ExtnCouponPin";
  public static final String E_COUPON_INQUIRY_REQUEST_MSG = "CouponInquiryRequestMsg";
  public static final String E_HEADER = "Header";
  public static final String A_TERMINAL = "Terminal";
  public static final String A_BUSINESS_DATE = "BusinessDate";
  public static final String A_TRAN_START_DATE_TIME = "TranStartDateTime";
  public static final String A_TRAINING_MODE = "TrainingMode";
  public static final String CONST_FALSE = "false";
  public static final String A_HAND_KEYED_COUPON = "HandKeyedCoupon";
  public static final String A_PIN = "Pin";
  public static final String KOHLS_POC_KOHLS_CASH_INQUIRY_WEB_SERVICE =
      "KohlsPoCKohlsCashInquiryWebService";
  public static final String A_COUPON_NUMBER = "CouponNumber";
  public static final String NONE = "NONE";
  public static final String A_ASSOCIATE_ID = "AssociateID";
  // sus end
  public static final String E_UPDATED_EARN_TRACKER_BAL = "ExtnUpdatedEarnTrackerBal";
  public static final String TRAN_KC_AMNT_TO_ACTIVATE = "TransKcAmountToActivateTol";
  public static final String UPDATE_PENDING_BALANCE = "UpdatedPendingBalTol";
  public static final String TLD_DOLLAR_OFF = "TLD_DOLLAR_OFF";
  public static final String TLD_PERCENT_OFF = "TLD_PERCENT_OFF";
  public static final String A_PROMOTION_TYPE = "PromotionType";
  public static final String E_MANUAL_TLD = "ManualTLD";
  public static final String A_MARK_DOWN_VALUE = "MarkdownValue";
  public static final String A_DISCOUNT_TYPE = "DiscountType";
  public static final String A_IE_INDICATOR = "IEIndicator";
  public static final String A_LEGACY_FLAG = "LegacyFlag";
  public static final String E_DEPARTMENTS = "Departments";
  public static final String A_DEPT = "Dept";
  public static final String MANUAL_PERCENT_OFF = "ManualPercentOff";
  public static final String MANUAL_DOLLAR_OFF = "ManualDollarOff";
  public static final String A_OVERRIDE_ADJUSTMENT_VALUE = "OverrideAdjustmentValue";
  public static final String A_OVERRIDE_MAX_ADJUSTMENT = "OverrideMaxAdjustment";
  public static final String A_TLD_IMPACT = "TldImpact";
  public static final String E_TLD = "TLD";
  public static final String DOLLAR_SYMPOL = "$";
  public static final String DOLLAR_MARKDOWN_DESC = "$ Item Markdown ";
  // public static final String PERCENT_MARKDOWN_DESC = "% Item Markdown - ";
  public static final String A_INCLUDE_ENCLUDE_FLAG = "IncludeExcludeFlag";
  public static final String A_LEGACY_DOLLAR = "LegacyDollar";
  public static final String A_LEGACY_PERCENT = "LegacyPercent";
  public static final String E_EVENT_DEPARTMENT = "EventDepartment";
  public static final String A_EVENT_DEPARTMENT = "EventDepartment";
  public static final String LEGACY = "LEGACY";
  public static final String KOHLSCASHAUTH = "KOHLSCASHAUTH";
  public static final String A_COUPON_STATUS = "CouponStatus";
  public static final String A_COUPON_BALANCE = "CouponBalance";
  public static final String ACTIVE_CAPS = "ACTIVE";
  public static final String INCLUDE = "Include";
  public static final String EXCLUDE = "Exclude";

  // Error code for Kohls Cash
  public static final String A_HISTORY_DATA = "HistoryData";
  public static final String CONST_PRE_REDEMPTION = "PREREDEMPTION";
  public static final String CONST_POST_REDEMPTION = "POSTREDEMPTION";
  public static final String CONST_KC_NOT_ACTV_YET = "KC_NOT_ACTV_YET";
  public static final String CONST_KC_EXPIRED = "KC_EXPIRED";
  public static final String CONST_KC_NO_BALANCE = "KC_NO_BALANCE";
  public static final String EIGHT = "8";
  public static final String NINE = "9";
  public static final String TWO = "2";
  public static final String SEVEN = "7";
  public static final String CONST_KC_DUP_REC_FND = "KC_DUP_REC_FND";
  public static final String CONST_KC_NOT_ACTV = "KC_NOT_ACTV";
  public static final String CONST_KC_OFFLINE = "KC_OFFLINE";
  public static final String CONST_KOHLS_CASH_NO_AUTH = "KOHLSCASHNOAUTH";
  public static final String A_TRANSACTION_NO = "TransactionNo";
  public static final String DATE_FORMAT_KOHLS_CASH = "yyyy-MM-dd'T'HH:mm:ss";
  public static final String A_RECEIPT_ID_KOHLS_CASH = "ReceiptID";
  public static final String SUSPEND_STATUS = "1000.9000";
  public static final String MAX_ORDER_STATUS = "MaxOrderStatus";
  public static final String FALSE = "false";
  public static final String MANUAL_TLD = "ManualTLD";
  public static final String TLD_DOLLAR_OFF_LINE_CHARGE = "TLDDollarOff";
  public static final String TLD_PERCENT_OFF_LINE_CHARGE = "TLDPercentOff";

  // Start: Kohls Cash Activation

  public static final String KOHLS_POC_KOHLS_CASH_ACTIVATION_WEB_SERVICE =
      "KohlsPocKohlsCashActivationWebService";

  public static final String E_DETERMINE_KOHLS_CASH_ACTIVATION_REQUEST_MSG =
      "DetermineKohlsCashActivationRequestMsg";


  // Sprint 8 : START

  public static final String PINPAD_MAC_ADDRESS = "PINPadMACAddress";
  public static final String STS_TIME_ZONE = "America/Chicago";

  // Sprint 8 : END

  // CHANGED poc to POC
  public static final String KOHLS_CASH_ACTIVATION_GET_ORDER_LIST_OUTPUT =
      "/global/template/api/POC/kohlscashactivation/POC_getOrderListForKohlsCashActivation.xml";

  public static final String DATEFORMAT_yyyy_MM_dd = "yyyy-MM-dd";
  public static final String DATEFORMAT_yyyy_MM_dd_HH_mm_ss = "yyyy-MM-dd'T'HH:mm:ss";
  public static final String E_DEPT = "Dept";
  public static final String E_NETPRICE = "NetPrice";
  public static final String E_APPROVED_KOHLS_CHARGE_TENDERED = "ApprovedKohlsChargeTendered";
  public static final String E_RECEIPT_ID = "ReceiptID";


  public static final String E_PAYMENT_METHODS = "PaymentMethods";
  public static final String A_PAYMENT_CREDIT_CARD_TYPE = "CreditCardType";
  public static final String KOHL_CHARGE_CARD = "KOHLS_CHARGE_CARD";
  public static final String E_TRANSACTION_NO = "TransactionNo";
  public static final String E_ITEM_DETAILS = "ItemDetails";

  public static final String E_EXTN_DEPT = "ExtnDept";
  public static final String E_LINE_TOTAL = "LineTotal";
  public static final String E_LINE_TOTAL_WITHOUT_TAX = "LineTotalWithoutTax";

  public static final String E_EVENT_ID = "EventID";
  public static final String E_EVENT_NAME = "EventName";
  public static final String E_QUALIFYING_PURCHASE_AMOUNT = "QualifyingPurchaseAmount";
  public static final String E_KOHLS_CASH_AMOUNT = "KohlsCashAmount";
  public static final String E_RECEIPT_MESSAGE_LINE_1 = "ReceiptMessageLine1";
  public static final String E_RECEIPT_MESSAGE_LINE_2 = "ReceiptMessageLine2";
  public static final String E_VALIDATION_CODE = "ValidationCode";

  public static final String E_EXTN_COUPON_EVENT_ID = "ExtnCouponEventID";
  public static final String E_EXTN_COUPON_ALGORITHM = "ExtnCouponAlgorithm";
  public static final String E_EXTN_QUALIFYING_AMOUNT = "ExtnQualifyingAmount";
  public static final String E_EXTN_COUPON_AMOUNT = "ExtnCouponAmount";

  public static final String E_EXTN_RECEIPT_MESSAGE_1 = "ExtnReceiptMessageLine1";
  public static final String E_EXTN_RECEIPT_MESSAGE_2 = "ExtnReceiptMessageLine2";
  public static final String E_EXTN_VALIDATION_CODE = "ExtnValidationCode";

  public static final String KOHLS_CASH_AWARD = "KOHLS_CASH_EARNED";

  public static final String KC_ACTIVATION_NOEVENTS = "KC_ACTIVATION_NOEVENTS";
  public static final String KC_ACTIVATION_NOEVENTS_ERRMSG = "Kohl's Cash no events to activate";

  // End : Kohls Cash Activation

  public static final String A_EXTN_PROMOTION_FLAG = "ExtnPromotionFlag";
  public static final String A_EXTN_PROMOTION_RESPONSE = "ExtnPromotionResponse";
  public static final String RESET = "Reset";
  public static final String IGNORE_REPRICING_UE = "IgnoreRepricingUE";
  public static final String A_EXTN_DISCOUNT_PERCENT = "ExtnDiscountPercent";
  public static final String MINUS = "-";
  public static final String LEGACY_DOLLAR = "LegacyDollar";
  public static final String LEGACY_PERCENT = "LegacyPercent";
  public static final String KOHLS_CASH_DESC = "KohlsCash";
  public static final String KOHLS_CASH_DISCOUNT = "KohlsCashDiscount";
  public static final String REPRICE_ORDER = "repriceOrder";
  public static final String CONDITION_VARIABLE_TWO = "ConditionVariable2";
  public static final String A_CREATE_TS = "Createts";

  // Added for Kohls cash Auth
  public static final String A_EXTN_AUTH_APPROVAL_NUM = "ExtnAuthApprovalNum";
  public static final String A_EXTN_AUTH_RESPONSE_CODE = "ExtnAuthResponseCode";
  public static final String A_AUTH_APPROVAL_NUM = "AuthApprovalNum";
  public static final String A_EXTN_COUPON_BALANCE = "ExtnCouponBalance";
  public static final String A_EXTN_INITIAL_OFFER_AMT = "ExtnInitialOfferAmt";
  public static final String A_EXTN_AUTH_APPROVAL_NUMBER = "ExtnAuthApprovalNumber";
  // End of Kohls cash Auth
  public static final String CANCELLED = "Cancelled";

  // User Feed Constants
  public static final String ACTION_DELETE = "DELETE";
  public static final String ELEM_USER = "User";

  // GC Activation Constant fields.
  public static final String ATTRIBUTE_RESULT_CODE = "ResultCode";
  public static final String ATTRIBUTE_ACTION_CODE = "ActionCode";
  public static final String ATTRIBUTE_RESPONSE_CODE = "ResponseCode";
  public static final String ATTRIBUTE_PROCESSOR_NETWORK_ID = "ProcessorNetworkID";

  // *****************************************************************
  // Added for RELEASE 8/31 on 8/30
  // *****************************************************************
  public static final String DECIMAL_FORMAT = "0.00";
  public static final String AMOUNT_OFF = "AMOUNT_OFF";
  public static final String TLD_AMOUNT_OFF_LINE_CHARGE = "TLDAmountOff";
  public static final String TLD_AMOUNT_OFF = "TLD_AMOUNT_OFF";
  public static final String PRICE_OVERRIDE = "PRICE_OVERRIDE";
  public static final String E_MANUAL_LID = "ManualLID";
  public static final String A_DOLLAR_OFF = "DollarOff";
  public static final String A_CORRECTED_PRICE = "CorrectedPrice";
  public static final String LID_AMOUNT_OFF = "LID_AMOUNT_OFF";
  public static final String LID_PERCENT_OFF = "LID_PERCENT_OFF";
  public static final String MANUAL_LID = "ManualLID";
  public static final String LID_AMOUNT_OFF_LINE_CHARGE = "LIDAmountOff";
  public static final String LID_PERCENT_OFF_LINE_CHARGE = "LIDPercentOff";
  public static final String PRICE_OVER_RIDE = "PriceOverride";
  public static final String PRICE_OVER_RIDE_LINE_CHARGE = "PriceOverrideAmountOff";
  public static final String FORM = "FORM";
  public static final String A_EXTN_REBATE_RESPONSE = "ExtnRebateResp";
  public static final String REBATE_ITEM = "Rebate Item";

  // Sushanta
  public static final String SENIOR_DISCOUNT = "SENIOR_DISCOUNT";
  public static final String E_RULE = "Rule";
  public static final String SENIOR_CITIZEN = "SeniorCitizen";
  public static final String A_RULE_ID = "RuleID";
  public static final String YY_MM_DD = "yyMMdd";
  public static final String SENIOR_DISCOUNT_CHARGE = "SeniorDiscount";
  public static final String SENIOR_CITIZEN_DISCOUNT = "SeniorCitizenDiscount";
  public static final String A_RULE_VALUE = "RuleValue";
  public static final String RULE_ID_QRY_TYPE = "RuleIDQryType";
  public static final String FLIKE = "FLIKE";
  public static final String SENIOR_DISCOUNT_PERCENT = "SENIOR_DISCOUNT_PERCENT";
  public static final String BEAUTY_EXCLUSION = "BEAUTY_EXCLUSION";
  public static final String BEAUTY_EXCLUSION_DESC = "BeautyExclusion";
  public static final String BEAUTY_DISCOUNT = "BeautyDiscount";
  public static final String E_EXCLUSIONS = "Exclusions";
  public static final String E_EXCLUSION_TVS = "exclusion";
  public static final String BEAUTY_DEPARTMENT_LIST = "BEAUTY_DEPARTMENT_LIST";
  public static final String DOT = ".";
  public static final String COMMA = ",";
  // Susanta end

  // price verify
  public static final String A_ORG_CODE = "OrganizationCode";
  public static final String A_CURRENCY = "Currency";
  public static final String A_LINE_PRICE_TOTAL = "LinePriceTotal";
  public static final String A_APPLY_ONLY_ITEM_LEVEL_PRICING_RULES =
      "ApplyOnlyItemLevelPricingRules";
  public static final String A_ENABLE_MANAGER_OVERRIDES = "EnableManagerOverrides";
  public static final String A_LIST_PRICE = "ListPrice";
  public static final String E_LINE_ADJUSTMENTS = "LineAdjustments";
  public static final String E_ADJUSTMENT = "Adjustment";
  public static final String A_ADJUSTMENT_ID = "AdjustmentID";
  public static final String A_ADJUSTMENT_PER_UNIT = "AdjustmentPerUnit";
  public static final String A_LINE_ADJUSTMENT = "LineAdjustment";
  public static final String A_LINE_PRICE = "LinePrice";
  public static final String A_ORDER_TOTAL = "OrderTotal";
  public static final String A_SUB_TOTAL = "Subtotal";
  public static final String A_LINE_TOTAL = "LineTotal";


  // post void
  public static final String A_VOID_ORIG_TRAN_NUMBER = "voidOrigTranNumber";
  public static final String A_DISCOUNT_AMOUNT = "DiscountAmount";
  public static final String E_COUPON_REDEMPTION_REQ_MSG = "CouponRedemptionRequestMsg";
  public static final String KOHLSCASH = "KOHLS_CASH";
  public static final String A_EXTN_CUSTOMER_ASSOCIATE_NO = "ExtnCustomerAssociateNo";

  public static final String KOHLS_SOFT_GOODS_ASSOCIATE_DISCOUNT =
      "KOHLS_SOFT_GOODS_ASSOCIATE_DISCOUNT";
  public static final String KOHLS_HARD_GOODS_ASSOCIATE_DISCOUNT =
      "KOHLS_HARD_GOODS_ASSOCIATE_DISCOUNT";
  public static final String ASSOCIATE_DISCOUNT_TYPE = "AssociateDiscount";
  public static final String A_SECONDARY_MARK_DOWN_VALUE = "SecondaryMarkdownValue";
  public static final String ASSOCIATE_DISCOUNT_CHARGE = "AssociateDiscount";
  public static final String ASSOCIATE = "AssociateDiscount";
  public static final String PERCENT_OFF = "PERCENT_OFF";

  public static final String API_GET_RULE_LIST_FOR_POS = "getRuleListForPOS";

  // Start: sales hub mapping - Suresh
  public static final String A_OFR_SECT_BWP_ID = "OFR_SECT_BWP_ID";
  public static final String A_BWP_BUY_ID = "BWPBuyID";
  public static final String A_BWP_GET_ID = "BWPGetId";
  public static final String A_OFFER_RCHD_QTY = "OfferRchdQty";
  public static final String A_OFFER_RCHD_AMT = "OfferRchdAmt";
  public static final String A_PROMO_INTERFACE_ID = "PromoInterfaceId";
  public static final String A_GROUP_PRICE_ID = "GroupPriceID";
  public static final String A_GROUP_RTL_AMOUNT = "GroupRtlAmount";
  public static final String A_GROUP_RTL_QTY = "GroupRtlQty";
  public static final String A_MULTI_PRICE_IND = "MultiPriceInd";
  public static final String A_DISC_LVL_CODE = "DiscLvlCde";
  public static final String A_EXTN_PROMO_SCHEME = "ExtnPromoScheme";
  public static final String A_TIER_QTY_RCHD = "TierQtyRchd";
  public static final String A_TIER_AMT_RCHD = "TierAmtRchd";
  public static final String A_DISCOUNT_PERCENT = "DiscountPercent";
  public static final String A_PRECEDENCE = "Precedence";
  public static final String A_TLD_DOLLAR_OFF = "TLDDollarOff";
  public static final String A_TLD_PERCENT_OFF = "TLDPercentOff";
  public static final String A_AMOUNT_OFF = "AmountOff";
  public static final String E_MODIFICATION_TYPES = "ModificationTypes";
  public static final String ASSOCIATE_DISCOUNT = "ASSOCIATE_DISCOUNT";
  public static final String PROMO = "PROMO";


  // End: Sales hub mapping - Suresh

  // Start: Kohls Cash Inquiry Added for Description
  public static final String CASH = "CASH";
  public static final String COUPON = "COUPON";
  public static final String SKU_VOID_TRAN_ZERO_ITEM = "SKU_VOID_TRAN_ZERO_ITEM";

  // End:


  // Start: Kohls Cash Redemption
  public static final String ATTR_ACTION = "Action";
  public static final String A_REDEMPTION_RESPONSE_CODE = "ExtnRedemResponseCode";
  // Start : added approval number for kohls cash redemption during sprint 7
  public static final String A_REDEMPTION_AUTH_APPROVAL_NUM = "ExtnRedemAuthApprovalNum";
  // End : added approval number for kohls cash redemption during sprint 7
  public static final String KOHLS_POC_KOHLS_CASH_REDEMPTION_WEB_SERVICE =
      "KohlsPoCKohlsCashRedemptionWebService";

  // Start :added for GiftCardActivation - Anuradha
  public static final String N_TCX_ERROR = "-1";
  // End:GiftCardActivation

  // Start :added for User Feed - Sudina
  public static final String ATTR_LOGIN_ID = "Loginid";
  public static final String ATTR_USERGROUP_ID = "UsergroupId";
  public static final String ELEM_USER_GROUP_LIST = "UserGroupList";
  public static final String API_GET_USER_LIST = "getUserList";
  public static final String ELEM_COMMON_CODE = "CommonCode";
  public static final String ATTR_CODE_TYPE = "CodeType";
  public static final String STRING_CODE_TYPE = "ITIM_ROLE_2_OMS_USER";
  public static final String STRING_TEMP_CODE_TYPE = "POC_TEMP_STORE_ROLES";
  public static final String STRING_CATEGORY_CODE_TYPE = "POC_CAT_HIER_PREFIX";
  public static final String ATTR_CODE_VALUE = "CodeValue";
  public static final String ATTR_CODE_NAME = "CodeName";
  public static final String API_GET_USER_HIERARCHY = "getUserHierarchy";
  public static final String API_CREATE_USER_HIERARCHY = "createUserHierarchy";
  public static final String API_MODIFY_USER_HIERARCHY = "modifyUserHierarchy";
  public static final String API_DELETE_USER_HIERARCHY = "deleteUserHierarchy";
  public static final String API_MANAGE_TEAM = "manageTeam";
  public static final String ATTR_Team = "Team";
  public static final String ATTR_TEAM_KEY = "TeamKey";

  public static final String ATTR_Store = "Store";

  public static final String ATTR_GEN_PASSWORD = "GeneratePassword";
  public static final String ATTR_USER_NAME = "Username";
  public static final String ATTR_FIRST_NAME = "FirstName";
  public static final String ATTR_MIDDLE_NAME = "MiddleName";
  public static final String ATTR_LAST_NAME = "LastName";
  public static final String ATTR_RESET = "Reset";
  public static final String ATTR_TeamId = "TeamId";
  public static final String ATTR_ORGABIZATION_CODE = "OrganizationCode";
  public static final String ATTR_DESCRIPTION = "Description";
  public static final String ATTR_PARENT_TEAM_KEY = "ParentTeamKey";

  public static final String TEMPLATE_MANAGE_TEAM = "<Team Operation='Create' "
      + "EnterpriseAccessMode='02' ShipNodeAccessMode='01' TeamId='' OrganizationCode='' Description='' ParentTeamKey=''>"
      + "<TeamEnterpriseList>"
      + "<TeamEnterprise Operation='Create' EnterpriseOrgCode='KOHLS-RETAIL'/>"
      + "<TeamEnterprise Operation='Create' EnterpriseOrgCode='DEFAULT'/> "
      + "<TeamEnterprise Operation='Create' EnterpriseOrgCode='KOHLS.COM'/> "
      + "</TeamEnterpriseList> </Team>";


  public static final String TEMPLATE_GET_USER_HIERARCHY =
      "/global/template/api/POC/user/POC_getUserHierarchy.xml";
  public static final String TEMPLATE_GET_TEAM_LIST =
      "/global/template/api/POC/user/POC_getTeamList.xml";
  public static final String STRING_NO_OMS_ACCESS = "No OMS Access";
  public static final String ATTR_ACTIVATE_FLAG = "Activateflag";
  public static final String ATTR_ORGANIZATION_KEY = "OrganizationKey";
  public static final String ATTR_DEFAULT_ORGANIZATION_KEY = "DEFAULT";
  // End :User Feed

  // Start Item Feed : Arun

  public static final String CATEGORY_DOMAIN = "KOHLS_RETAIL";
  public static final String E_MANDATORY_FIELDS_MISSING = "YCM0002";
  public static final String STATUS = "3000";
  public static final String IS_CLASSIFICATION = "N";
  public static final String COST_CURRENCY = "USD";
  public static final String CREDIT_WO_RECEIPT = "Y";
  public static final String IS_RETURNABLE = "Y";
  public static final String RETURN_WINDOW = "0";
  public static final String TAXABLE_FLAG = "Y";
  public static final String ALLOW_GIFT_WRAP = "N";
  public static final String IS_HAZMAT = "N";
  public static final String SERIAL_REQD_AT_ORDER_CAPTURE = "N";
  public static final String QUANTITY_REQD_AT_ORDER_CAPTURE = "N";
  public static final String PRICE_REQD_AT_ORDER_CAPTURE = "Y";
  public static final String NOT_FOR_SALE_AT_ORDER_CAPTURE = "N";
  public static final String IS_TEMPLATE_ITEM = "N";
  public static final String UNIT_COST = "0";
  public static final String MINIMUM_AGE_REQD_TO_BUY = "0";
  public static final String SALES_PERSON_ID_REQD_AT_ORDER_CAPTURE = "N";
  public static final String PRICE_OVERRIDE_ALLOWED = "Y";
  public static final String TAX_PRODUCT_CODE = "61000";
  public static final String EXTN_BREAKABLE = "N";
  public static final String EXTN_CAGE_ITEM = "N";
  public static final String EXTN_DIRECT_SHIP_ITEM = "N";
  public static final String EXTN_IS_PLASTIC_GIFT_CARD = "N";
  public static final String EXTN_IS_VIRTUAL_GIFT_CARD = "N";
  public static final String EXTN_SHIP_ALONE = "N";
  public static final String EXTN_BAGGABLE = "N";
  public static final String EXTN_MERCHANDISE_TAX_CODE = "1";
  public static final String ALIAS_NAME = "Upc01";

  // End Item Feed

  public static final String DEFAULT_KOHLS_SOFT_GOODS_ASSOCIATE_DISCOUNT = "15";
  public static final String DEFAULT_KOHLS_HARD_GOODS_ASSOCIATE_DISCOUNT = "15";
  public static final String DEFAULT_SENIOR_DISCOUNT_PERCENT = "10";

  public static final String REBATE = "REBATE";
  public static final String A_REBATE_INTFC_ID = "RebateInterfaceId";
  public static final String A_REBATE = "Rebate";
  public static final String KOHLS_CASH_REDEMPTION_GET_ORDER_LIST_OUTPUT =
      "/global/template/api/POC/kohlscashredemption/POC_getOrderListForKohlsCashRedemption.xml";

  public static final String UPC_WEIGHT = "1313131313131";
  public static final int UPC_MOD = 10;
  public static final int PRODUCT_ADD = 0;

  // Start getTillStatusListForPOS
  public static final String E_TILL_STATUS = "TillStatus";
  public static final String A_CURRENT_STATUS = "CurrentStatus";
  public static final String OPEN = "Open";
  public static final String API_GET_TILL_STATUS_LIST_FOR_POS = "getTillStatusListForPOS";
  public static final String A_BUSINESS_DAY = "BusinessDay";


  public static final String A_IS_NEW_ORDER = "IsNewOrder";
  public static final String A_EXTN_ORIG_POS_SEQUENCE_NO = "ExtnOrigPosSequenceNo";

  // Added for tender referral / offline scenarios
  public static final String GET_CHARGE_TRANSACTION_LIST_TEMPLATE =
      "<ChargeTransactionDetails><ChargeTransactionDetail CallForAuthorizationStatus=''/></ChargeTransactionDetails>";
  public static final String ATTR_CALL_FOR_AUTHORIZATION_STATUS = "CallForAuthorizationStatus";
  public static final String AUTH_CODE_ACQUIRED = "AUTH_CODE_ACQUIRED";


  // Start OffLineMode
  public static final String OFFLINE = "OFFLINE";
  public static final String OFFLINE_KOHLS_CASH = "OfflineKohlsCash";
  public static final String OFFLINE_DISCOUNT = "OfflineDiscount";
  public static final String OFFLINE_KOHLS = "OfflineDiscount";
  public static final String LEGACY_COUPON = "LEGACY_COUPON";
  public static final String A_EXTN_OFFLINE_MODE = "ExtnOfflineMode";

  // Price Override : Price Incresed
  public static final String DOLLAR_MARKUP_DESC = "$ Item Markdown ";

  // Added for User Feed
  public static final String STRING_STORE_LOC_FILTER_CODE_TYPE = "STORE_LOC_FILTER";
  public static final String STRING_KOHLS_CORP_LOC_CODE_TYPE = "KOHLS_CORP_LOCATIONS";

  public static final String A_EXTN_RETURN_PRICE = "ExtnReturnPrice";
  public static final String A_RETURN_PRICE = "ReturnPrice";
  // Added for Error message for KohlsCas
  public static final String BALANCE = " Balance:";

  // Added for Price Override
  public static final String PRICE_OVERRIDE_INCREASED = "PRICE_OVERRIDE_INCREASED";
  public static final String PRICE_OVER_RIDE_INCREASE = "PriceOverrideInc";
  public static final String PRICE_OVER_RIDE_INCREASE_LINE_CHARGE = "PriceOverrideIncreaseAmount";

  public static final String PLUINVALIDSKU = "PLUINVALIDSKU";
  public static final String PLUNOSKUDATA = "PLUNOSKUDATA";
  public static final String PLUNOREFDATA = "PLUNOREFDATA";
  public static final String PLUINVALIDOFFRID = "PLUINVALIDOFFRID";
  public static final String PLUINVOFFRNBR = "PLUINVOFFRNBR";
  public static final String PLUINVALIDOFFRNBR = "PLUINVALIDOFFRNBR";
  public static final String PLUOFFRNOTFOUND = "PLUOFFRNOTFOUND";
  public static final String KC_OFFLINE_NO_AUTH = "KC_OFFLINE_NO_AUTH";

  // Promotions Description Key(s)
  public static final String DOLLAR_TLD_LINE_PROP_KEY = "Dollar_TLD_Line";
  public static final String PERCENT_TLD_LINE_PROP_KEY = "Percent_TLD_Line";
  public static final String DOLLAR_TLD_ORDER_PROP_KEY = "Dollar_TLD_Order";
  public static final String PERCENT_TLD_ORDER_PROP_KEY = "Percent_TLD_Order";
  public static final String SENIOR_DISCOUNT_PROP_KEY = "Senior_Citizen_Discount";
  public static final String ASSOCIATE_DISCOUNT_PROP_KEY = "Associate_Discount";
  public static final String KOHLS_CASH_LINE_PROP_KEY = "Kohls_Cash_Line";
  public static final String LEGCY_$_OFF_LINE_PROP_KEY = "Legacy_Coupon_Dollar_Off_Line";
  public static final String LEGCY_PERCENT_OFF_LINE_PROP_KEY = "Legacy_Coupon_Perceht_Off_Line";
  public static final String KOHLS_CASH_ORDER_PROP_KEY = "Kohls_Cash_Order";
  public static final String LEGCY_$_OFF_ORDER_PROP_KEY = "Legacy_Coupon_Dollar_Off_Order";
  public static final String LEGCY_PERCENT_OFF_ORDER_PROP_KEY = "Legacy_Coupon_Perceht_Off_Order";

  // PLUPromoResponse & ExtnPromotionResponse Clob purge
  public static final String API_CHANGE_ORDER = "changeOrder";
  public static final String A_PROMOTION_KEY = "PromotionKey";

  public static final String DOLLAR_LID_LINE_PROP_KEY = "Dollar_LID_Line";
  public static final String DOLLAR_LID_PROMO_DESC_PROP_KEY = "Dollar_LID_Promotion_Desc";
  public static final String PERCENT_LID_LINE_PROP_KEY = "Percent_LID_Line";
  public static final String PERCENT_LID_PROMO_DESC_PROP_KEY = "Percent_LID_Promotion_Desc";
  public static final String OFFER_LINE = "Offer_Line";
  public static final String OFFER_ORDER = "Offer_Order";
  public static final String OFFER_PERCENT_LINE = "Offer_Percent_Line";
  public static final String OFFER_PERCENT_ORDER = "Offer_Percent_Order";

  public static final String APESERVDOWN = "APESERVDOWN";
  // TaxWare Change for 3rd October
  public static final String OVERRIDE_TAX_O = "O";

  // Added for Gift Card sku Identification for sales hub

  public static final String STRING_RETAILER = "Retailer";
  public static final String STRING_BLACKHAWK = "Blackhawk";
  public static final String STRING_POS_STORED_VALUE_CATEGORY = "POSStoredValueCategory";

  // Added for defect 736
  public static final String ATTR_POST_VOID_CONFIRMED_FLAG = "PostVoidConfirmedFlag";
  public static final String STRING_POST_VOID = "postVoid";
  public static final String GET_ORDER_INVOICE_LIST_OUTPUT =
      "/global/template/api/POC/saleshub/POC_getOrderInvoiceList.xml";
  public static final String INVOICE_PUBLISHED_STATUS = "01";
  public static final String INVOICE_CREATED_STATUS = "00";
  public static final String API_CHANGE_ORDER_INVOICE = "changeOrderInvoice";

  // Added 10th October
  public static final String KOHLS_CASH_DOWN = "KOHLS_CASH_DOWN";
  public static final String OLUSERVDOWN = "OLUSERVDOWN";

  // Added for Tax Indicator Requirement
  public static final String A_EXTN_TAX_INDICATOR = "ExtnTaxIndicator";
  public static final String E_TAX_DETAIL_LIST = "TaxDetailList";
  public static final String E_TAX_DETAIL = "TaxDetail";
  public static final String A_TAX_INDICATOR = "TaxIndicator";
  public static final String A_TOATL_AMOUNT = "TotalAmount";
  public static final String A_TAX_AMOUNT = "TaxAmount";
  public static final String A_EFFECTIVE_TAX_RATE = "EffectiveTaxRate";
  public static final String A_EXTN_TAX_DETAILS = "ExtnTaxDetails";
  public static final String CONST_HASH = "#";
  public static final String A_LINE_TOTAL_TAX_RATE = "LineTotalTaxRate";
  public static final String A_LINE_TOTAL_TAX = "LineTotalTax";
  public static final String CONST_T = "T";
  public static final int TWO_INT = 2;
  public static final String A_TAXABLE_AMOUNT = "TaxableAmount";

  // Bala 10/21
  public static final String ELEM_ORGANIZATION = "Organization";
  public static final String TEMPLATE_GET_ORGANIZATION_HIERARCHY =
      "/global/template/api/POC/user/POC_getOrganizationHierarchy.xml";
  public static final String API_GET_ORGANIZAION_HIERARCHY = "getOrganizationHierarchy";
  public static final String ATTR_LOCALE_CODE = "LocaleCode";

  // New User Design updates 06/18
  public static final String ATTR_DATA_SECURITY_GROUP_ID = "DataSecurityGroupId";
  public static final String ELEM_USER_GROUP_LISTS = "UserGroupLists";


  public static final String A_SYS_OF_REC_ID = "SYS_OF_REC_ID";
  public static final String A_EXTN_SALES_HUB_DATA = "ExtnSalesHubData";

  public static final String A_EXTN_AWARD_SEQUENCE = "ExtnAwardSequence";
  public static final String A_EXTN_COUPON_AMOUNT = "ExtnCouponAmount";
  public static final String PRICEVERIFYPLUPRICEREQ = "PRICEVERIFYPLUPRICEREQ";

  // COSA Non Sale realted constants
  public static final String ATTR_DRAWER_ID = "DrawerID";
  public static final String ATTR_ACCOUNTABLE_TERMINAL_ID = "AccountableTerminalID";
  public static final String ATTR_TILL_ID = "TillID";
  public static final String ATTR_TERMINAL_STATUS = "TerminalStatus";
  public static final String ATTR_ACCOUNT_TOTALS = "AccountTotals";
  // Manoj 11/20: Adding StoreProductAccs Element -- start
  public static final String ATTR_STORE_PRODUCT_ACCS = "StoreProductAccs";
  // Manoj 11/20: Adding StoreProductAccs Element -- End

  // Award description for simple promo
  public static final String SIMPLE_PROMO_HUNDRED = "0100";
  public static final String SIMPLE_PROMO_HUNDRED_ONE = "0101";
  public static final String SIMPLE_PROMO_TWO_HUNDRED = "0200";
  public static final String SIMPLE_PROMO_TWO_HUNDRED_ONE = "0201";
  public static final String SIMPLE_PROMO_TWO_HUNDRED_THREE = "0203";
  public static final String PROMO_DISCOUNT_DESC = "Savings";

  public static final String A_EXTN_PLU_RETAIL_AMT = "ExtnPLURetailAmt";
  public static final String A_EXTN_MDX_TAX_CODE = "ExtnMdxTaxCode";
  public static final String A_EXTN_ITEM_DEPT = "ExtnItemDept";
  public static final String A_EXTN_ITEM_CLASS = "ExtnItemClass";
  public static final String A_EXTN_ITEM_SUB_CLASS = "ExtnItemSubClass";
  public static final String A_PROMO_INTERFACE_SUB_ID = "PromoInterfaceSubId";

  public static final String A_EXTN_DISC_LVL_CODE = "ExtnDiscLevelCode";
  public static final String A_BWP_BUY_QTY_SH = "BWPBuyQty";
  public static final String A_BWP_BUY_AMT_SH = "BWPBuyAmt";
  public static final String A_BWP_BUY_TOL_AMT_SH = "BWPBuyTolAmt";
  public static final String A_BUY_CRITERIA_TYPE = "BuyCriteriaType";
  public static final String A_GET_CRITERIA_TYPE = "GetCriteriaType";
  public static final String A_BWP_GET_QTY_SH = "BWPGetQty";
  public static final String A_BWP_GET_DOL_OFF_AMT_SH = "BWPGetDolOffAmt";
  public static final String A_BWP_GET_PCT_OFF_PCT_SH = "BWPGetPctOff";
  public static final String A_BWP_GET_PRPT_AMT_SH = "BWPGetPrptAmt";
  public static final String CONST_TIER_OFFER_SCHME_CODE = "1009";
  public static final String A_EXTN_SIMPLE_PROMO_PRICE = "ExtnSimplePromoPrice";
  public static final String A_SIMPLE_PROMO_PRICE = "SimplePromoPrice";
  public static final String CONST_SOFT = "_soft";
  public static final String CONST_HARD = "_hard";
  public static final String CONST_S = "S";

  // Adding constants for defect 1649 - Begin
  public static final String ELE_STORE_PRODUCT_MIX_ACC = "StoreProductMixAcc";
  public static final String ATTR_STORE_PRODUCT_MIX_ACCS = "StoreProductMixAccs";
  public static final String API_GET_STORE_PRODUCT_MIX_ACC_DETAILS_FOR_POS =
      "getStoreProductMixAccDetailsForPOS";
  public static final String GET_STORE_PRODUCT_MIX_ACCS_TEMPLATE =
      "/global/template/api/POC/saleshub/POC_getStoreProductMixAccDetails.xml";
  // Adding constants for defect 1649 - BEnd
  public static final String A_EXTN_IS_INTERNAL = "ExtnIsInternal";

  // Added as part of defect 1877
  public static final String GET_ORDER_INVOICE_LIST_TEMPLATE =
      "<OrderInvoiceList><OrderInvoice OrderHeaderKey='' OrderNo='' Modifyts='' OrderInvoiceKey='' DocumentType=''/></OrderInvoiceList>";

  // Adding constants for defect 1909 - Begin
  public static final String A_EXTN_PRICE_POINT_IND = "ExtnPricePointInd";
  // Adding constants for defect 1909 - End

  // Adding constants for defect 1910 - Begin
  public static final String A_EXTN_CALL_BACK_IND = "ExtnCallBackInd";
  // Adding constants for defect 1910 - End

  // Adding constants for defect 1353
  public static final String ATTR_MODIFYTS = "Modifyts";
  public static final String API_GET_STORE_PRODUCT_MIX_ACC_LIST_FOR_POS =
      "getStoreProductMixAccListForPOS";

  // Defect 1055
  public static final String A_EXTN_IS_PRICE_ENTERED = "ExtnIsPriceEntered";

  // Defect 2150
  public static final String A_EXTN_DISCOUNT_AMOUNT = "ExtnDiscountAmount";
  // Colony ID Related fields
  public static final String ATTR_COLONY_ID = "ColonyId";
  public static final String ATTR_ASSIGNED_COLONY_ID = "AssignedColonyId";

  // Added for defect 2275 - Begin
  public static final String ATTR_DELIVERY_CODE = "DeliveryCode";
  public static final String ATTR_TERMS_CODE = "TermsCode";
  public static final String ATTR_CUSTOMER_REWARDS_NO = "CustomerRewardsNo";
  // Added for defect 2275 - end

  // Added for defect 2407 - Begin
  public static final String ELEM_CREDIT_CARD_TRANSACTION = "CreditCardTransaction";
  public static final String ELEM_CREDIT_CARD_TRANSACTIONS = "CreditCardTransactions";
  public static final String ELEM_KOHLS_PAYMENT_EXTENSION = "KohlsPaymentExtension";
  // For Getting UPC Code
  public static final String CONST_UPC = "UPC";
  public static final String E_ITEM_ALIAS = "ItemAlias";

  // PriceVerify :11-Jun-2014
  // public static final String GET_ADMIN_AUDIT_TEMPLATE="<AdminAuditList><AdminAudit BusinessDay=''
  // DateTime='' ItemID='' OperatorID='' OrganizationCode='' ProcedureID='' TerminalID=''
  // TransactionNumber=''/><Extn/></AdminAuditList>";
  // Defect - 5081 : START //
  public static final String GET_ADMIN_AUDIT_TEMPLATE =
      "<AdminAuditList><AdminAudit AdminAuditKey='' Amount='' AccountNumber='' BusinessDay='' CardEntryMethod='' Createprogid='' Createts='' Createuserid='' DateTime='' Error='' ItemID='' Lockid='' ManagerID='' MaskedAccountNumber='' Modifyprogid='' Modifyts='' Modifyuserid='' OperatorID='' OrganizationCode='' POSSequenceNumber='' Price='' ProcedureID='' Quantity='' ReasonCode='' TerminalID='' TillID='' TransactionNumber=''><AdditionalDataList><AdditionalData Name='' Value=''/></AdditionalDataList></AdminAudit></AdminAuditList>";
  // Defect - 5081 : END //
  public static final String ELE_ORDER = "/Order";
  public static final String ELE_ITEM = "/Order/OrderLines/OrderLine/Item";
  public static final String ELE_INVOICE_DETAIL = "InvoiceDetail";
  public static final String ELE_INVOICE_HEADER = "InvoiceHeader";
  public static final String ELE_OVERALLTOTALS = "OverallTotals";
  public static final String ELE_EXTN_POC_STAGING = "ExtnPoCStaging";
  public static final String ATTR_XMLDATA = "XmlData";
  public static final String ATTR_REFERENCE1 = "Reference1";
  public static final String ATTR_REFERENCE2 = "Reference2";
  public static final String ATTR_ITEMID = "ItemID";
  public static final String XPATH_ADMIN_AUDIT = "/AdminAudit";
  public static final String API_GET_EXTN_POC_STAGING_LIST = "KohlsPoCGetExtnPoCStagingList";
  public static final String XPATH_EXTN_POC_STAGING = "/ExtnPoCStagingList/ExtnPoCStaging";
  public static final String ELE_ADMIN_AUDIT_LIST = "/AdminAuditList";
  public static final String XPATH_INVOICE_HEADER = "/InvoiceDetail/InvoiceHeader";
  public static final String ELE_ADMIN_AUDIT = "AdminAudit";
  public static final String STR_106 = "106";
  public static final String STR_GET_ADMIN_AUDIT_LIST_FOR_POS = "getAdminAuditListForPOS";
  public static final String ATTR_POC_STAGING_KEY = "PocStagingKey";
  public static final String API_DELETE_EXTN_POC_STAGING_LIST = "KohlsPoCDeleteExtnPoCStagingList";
  public static final String API_PRICE_VERIFY_SALES_HUB_GEN = "KohlsPoCCreateExtnPoCStagingList";

  // XML Transformation
  public static final String CONST_RES = "RES";
  public static final String CONST_REQ = "REQ";
  public static final String E_ERRORS = "Errors";
  public static final String E_ERROR = "Error";
  public static final String E_DETAIL = "detail";
  public static final String E_CODE = "code";
  public static final String E_MESSAGE = "message";
  public static final String A_ERROR_CODE = "ErrorCode";
  public static final String A_ERROR_DESCRIPTION = "ErrorDescription";
  public static final String REQ_TEM_PLULOOKUP = "tem:PLULookup";
  public static final String REQ_XMLNS_TEM = "xmlns:tem";
  public static final String REQ_NAMESPACE_PLUAPE = "http://tempuri.org/";
  public static final String REQ_TEM_XMLIN = "tem:xmlIn";
  public static final String REQ_TEM_CALCULATEBASKET = "tem:CalculateBasket";

  // xsl changes for taxware
  public static final String GET_TAX_CALCULATION = "getTaxCalculation";
  public static final String TAXWARE_NAMESPACE = "http://NextGenPOS.kohls.com/TaxServiceRequest/";
  public static final String TAXWARE_REQ_PREFIX = "tax:";
  public static final String E_MODIFIER_LIST = "ModifierList";

  public static final String ATTR_ORGANIZATION_FLAG = "OrgCheckFlag";
  // Manoj: Added for sprint4 sales hub feeds - Begin
  public static final String ATTR_ADMIN_AUDIT_KEY = "AdminAuditKey";
  public static final String ATTR_MESSAGE_TYPE = "MessageType";
  public static final String MESSAGE_TYPE_TILL_CONTENT = "TillContent";
  public static final String MESSAGE_TYPE_RECEIPT_REPRINT = "ReceiptReprint";
  public static final String MESSAGE_TYPE_GIFT_RECEIPT_REPRINT = "GiftReceiptReprint";
  public static final String RECEIPT_REPRINT_PROCEDURE_ID = "206";
  public static final String GIFT_RECEIPT_REPRINT_PROCEDURE_ID = "205";
  // Manoj: Added for sprint4 sales hub feeds - End

  // Defect 2689 Changes - Begin
  public static final String E_CHARGE_TRANSACTION_DETAIL = "ChargeTransactionDetail";
  public static final String A_OFFLINE_STATUS = "OfflineStatus";
  public static final String CONST_GIFT_CARD = "GiftCard";
  // Defect 2689 changes - End

  // Manoj: Added for Defect 2873 - Begin
  public static final String GET_STORED_VALUE_LINE_LIST_TEMPLATE =
      "<StoredValueLineList><StoredValueLine Account='' ActionCode='' Amount='' Category='' EntryMethod='' IsDeactivated='' IsPreauthed='' IsRegulated='' IsReload='' IsRetriedOffline='' IsSwipeable='' Issuer='' OperatorId='' OrderHeaderKey='' OrderLineKey='' OrderNo='' PosSequenceNo='' ProcessorNetworkId='' Program='' ResponseCode='' ResultCode='' SequenceNo='' Status='' StoreId='' TerminalId='' TransactionNo=''/></StoredValueLineList>";
  // Manoj: Added for defect 2873 - End

  // Suresh Midde: Added for Sprint5 Nike Exclusions - Start 18th Aug

  public static final String E_EXCLUSION_DEFN = "ExclusionDefn";
  public static final String E_EXCLUSION_ACTIVE = "ExclusionActive";
  // public static final String E_EXCLUSION_RULE = "ExclusionRule";
  public static final String E_EXCLUSION_ACTIVE_DATE = "ExclusionActiveDate";
  public static final String E_EXCLUSION_DEPT = "ExclusionDept";
  public static final String E_EXCLUSION_CLASS = "ExclusionClass";
  public static final String E_EXCLUSION_SUBCLASS = "ExclusionSubClass";
  public static final String E_DPT = "DPT";
  public static final String E_MCL = "MCL";
  public static final String E_SCL = "SCL";
  public static final String API_GET_EXCLUSION_CLASSIFICATION = "KohlsPoCGetExclusionDefnService";
  public static final String DATE_FORMAT_MM_dd_yyyy = "MMddyyyy";
  public static final String E_EXCLUSION = "Exclusion";
  public static final String E_EXCLUSION_TAG = "ExclusionTag";
  public static final String E_EXCLUSION_ITEM = "ExclusionItem";
  public static final String A_EXTN_IS_EXCLUSION_ITEM = "ExtnIsExclusionItem";
  public static final String E_PIPE_SYMBOL = "|";

  // Suresh Midde: Added for Sprint5 Nike Exclusions - End 18th Aug

  // Sathiya : Added for CashOffice feed - begin
  public static final String ATTR_CASH_OFFICE = "CashOffice";
  public static final String ATTR_REGISTER = "Register";
  public static final String GET_TILL_STATUS_LIST_TEMPLATE =
      "<TillStatusList><TillStatus BusinessDay='' OrganizationCode='' TerminalID='' TillID='' /></TillStatusList>";
  public static final String GET_STORE_PRODUCT_ACCS_TEMPLATE =
      "/global/template/api/POC/saleshub/POC_getStoreProductAccListForPOS.xml";
  public static final String REBATE_RECEIPT_REPRINT_PROCEDURE_ID = "208";
  public static final String MESSAGE_TYPE_REBATE_RECEIPT_REPRINT = "RebateReceiptReprint";
  // Sathiya : Added for CashOffice feed - end

  // Suresh : Dec19 Setting offer/promo start and End dates : Start

  public static final String E_EXTN_START_DATE = "ExtnStartDate";
  public static final String E_EXTN_END_DATE = "ExtnEndDate";

  // Suresh : Dec19 Setting offer/promo start and End dates : End

  // Deepika : Added for Setting Offer Redem Supervisor Override Date : Start
  public static final String A_EXTN_REDMN_SUPVR_OVRRID_DATE = "ExtnRedmnSupvrOvrrideDate";
  // Deepika : Added for Setting Offer Redem Supervisor Override Date : End

  // Suresh : Added for TLD pushdown : Start
  public static final String A_EXTN_SCANNED_SEQUENCE = "ExtnScannedSequence";
  public static final String A_EXTN_PROMO_SEQUENCE = "ExtnPromoSequence";

  // Suresh : Added for TLD pushdown : End

  // Suresh : Added for KC Standalone inquiry : Start

  public static final String A_SEQUENCE_NO = "SequenceNo";
  public static final String A_IS_TRAINING = "IsTraining";
  public static final String A_COUPON_RECEIPT_ID = "CouponReceiptID";
  public static final String A_COUPON_PIN = "CouponPIN";
  public static final String A_INQUIRY_TRANSACTION = "InquiryTransaction";

  public static final String A_COUPON_HISTORY = "CouponHistory";
  public static final String A_COUPON_AUTH_RESPONSE = "CouponAuthResponse";
  public static final String A_COUPON_AUTH_REASON = "CouponAuthReason";
  public static final String A_COUPON_AUTH_CODE = "CouponAuthCode";
  public static final String A_AUTH_TIME = "AuthTime";

  // Suresh : Added for KC Standalone inquiry: End

  // Deepika : Added for BR-2549 - Gift Card Balance Inquiry --- Start

  public static final String SV_DATA_SOURCE = "SV_DATA_SOURCE";
  public static final String SV_AUTH_SOURCE = "SV_AUTH_SOURCE";
  public static final String SV_AUTH_CODE_RESPONSE = "SV_AUTH_CODE_RESPONSE";
  public static final String SV_AUTH_CODE = "SV_AUTH_CODE";
  public static final String SV_CARD_BALANCE = "SV_CARD_BALANCE";
  public static final String SV_CARD_AUTH_TIME = "SV_CARD_AUTH_TIME";
  public static final String SV_CARD_TYPE = "SV_CARD_TYPE";
  public static final String SV_ACCOUNT_NUMBER = "SV_ACCOUNT_NUMBER";
  public static final String SV_AUTH_SOURCE_VALUE = "0005";
  public static final String SV_AUTH_SOURCE_OFFLINE = "0000";
  public static final String GET_ADMIN_AUDIT_FOR_GC_KC_TEMPLATE =
      "<AdminAudit AdminAuditKey='' Amount='' AccountNumber='' BusinessDay='' CardEntryMethod='' Createprogid='' Createts='' Createuserid='' DateTime='' Error='' ItemID='' Lockid='' ManagerID='' MaskedAccountNumber='' Modifyprogid='' Modifyts='' Modifyuserid='' OperatorID='' OrganizationCode='' POSSequenceNumber='' Price='' ProcedureID='' Quantity='' ReasonCode='' TerminalID='' TillID='' TransactionNumber=''><AdditionalDataList><AdditionalData Name='' Value=''/></AdditionalDataList></AdminAudit>";
  public static final String MESSAGE_TYPE_GC_BALANCE_INQUIRY = "GCBalanceInquiry";
  public static final String MESSAGE_TYPE_KC_BALANCE_INQUIRY = "KCBalanceInquiry";
  public static final String MESSAGE_TYPE_NO_SALE = "NoSale";

  // Deepika : Added for BR-2549 - Gift Card Balance Inquiry --- End

  // Deepika : Added GetCriteriaType in AwardExtn for Offer--Start
  public static final String A_EXTN_GET_CRITERIA_TYPE = "ExtnGetCriteriaType";
  // Deepika : Added GetCriteriaType in AwardExtn for Offer--End

  // Sudina : Added constants for post sale KCA - Sprint 8 --- Start
  public static final String POST_SALE_KCA_PROCEDUREID = "10102";
  public static final String MESSAGE_TYPE_POST_SALE_KCA = "PostSaleKCActivation";
  public static final String GET_ADMIN_AUDIT_FOR_POS_SALE_KCA_TEMPLATE =
      "<AdminAudit AdminAuditKey='' BusinessDay='' OperatorID='' OrganizationCode='' POSSequenceNumber='' ProcedureID='' TerminalID='' TransactionNumber=''><AdditionalDataList><AdditionalData Name='' Value=''/></AdditionalDataList></AdminAudit>";
  // Sudina : Added constants for post sale KCA - Sprint 8 --- End

  // Deepika : Added for TLD Precedence for Sprint-8 --- Start
  public static final String A_EXTN_PRECEDENCE_NUMBER = "ExtnPrecedenceNumber";
  // Deepika : Added for TLD Precedence for Sprint-8 --- End
  // Deepika : Added for TLD Description for Sprint-8 --- Start
  public static final String TLD_DOLLAR_DESCRIPTION = "$ Tran Disc";
  public static final String SENIOR_DISCOUNT_PROPE_KEY = "Senior_Discount";
  public static final String SENIOR_DISC = "Senior Discount";
  // Deepika : Added for TLD Description for Sprint-8 --- End

  // Deepika : Added for defect 3945 --- Start

  public static final String CONST_H = "H";
  public static final String ASSOC_DISC_MANUAL_HARD_LINE = "ASSOC_DISC_MANUAL_HARD_LINE";
  public static final String ASSOC_DISC_MANUAL_SOFT_LINE = "ASSOC_DISC_MANUAL_SOFT_LINE";
  // Deepika : Added for defect 3945 --- End


  // Bala: Added for InventoryUpdates to GIV ---- Start
  public static final String ELEM_ITEMS = "Items";
  public static final String POST_VOID = "PostVoid";
  public static final String ETA = "ETA";
  public static final String DEFAULT_ETA = "1900-01-01";
  public static final String AVAILABLITY = "Availability";
  public static final String TRACK = "TRACK";
  public static final String ADJUSTMENTTYPE = "AdjustmentType";
  public static final String ADJUSTMENT = "ADJUSTMENT";
  public static final String EXTNSUBCLASS = "ExtnSubClass";
  public static final String OdotO = "0.00";
  public static final String CODE_TYPE_RECYCLEFEESKUS = "RECYCLE_FEE_SKUS";
  public static final String GIV_UPDATE_SHIPPED_QTY_ZERO = "0.00";
  public static final String GET_ORDER_LIST_TEMPLATE_FOR_GIV =
      "global/template/api/POC/giv/POC_getOrderListForGIV.xml";
  // Bala: Added for InventoryUpdates to GIV ---- End
	// Template for Post Void Publish Invoice to Salesh Hub
	//FIX FOR DEFECT 210
	//Updated Template GET PROMOTION TEMPLATE for CPE-5860 to make KohlsChargePayment Void after work in R10
  	//Added purpose attribute as part of CPE-5926
	public static final String GET_PROMOTION_TEMPLATE="<OrderList><Order Purpose='' OrderHeaderKey='' DocumentType='' OriginalTotalAmount='' OrderNo='' OrderDate='' Modifyts='' EntryType='' SellerOrganizationCode='' BusinessDay='' PosSequenceNo=''  TransactionNo=''><References><Reference Name='' Value=''/></References><Promotions><Promotion PromotionType='' PromotionApplied=''><Extn ExtnActivationBarCode=''/></Promotion></Promotions><OrderLines><OrderLine></OrderLine></OrderLines><Extn/><CustomAttributes Text1='' Text12='' Text14=''/></Order></OrderList>";
	public static final String GET_TRANSACTION_AUDIT_TEMPLATE="<TransactionAudits><TransactionAudit OrderNumber='' BusinessDay='' OperatorID='' OrderTotal='' OrganizationCode='' OriginalTransactionNumber='' TerminalID='' TransactionNumber='' Createts='' Modifyts='' DateTime=''/></TransactionAudits>";

  // Sudina: Added for Hard Totals/CashOffice changes with respect to getStoreFinancialAccListForPOS
  // call - Start

  public static final String ELE_STORE_FINANCIAL_ACC = "StoreFinancialAcc";
  public static final String ELE_STORE_FINANCIAL_ACCS = "StoreFinancialAccs";
  public static final String API_GET_STORE_FINANCIAL_ACC_LIST_FOR_POS =
      "getStoreFinancialAccListForPOS";
  public static final String GET_STORE_FINANCIAL_ACC_LIST_FOR_POS_TEMPLATE =
      "/global/template/api/POC/saleshub/POC_getStoreFinancialAccListForPOS.xml";

  // Sudina: Added for Hard Totals/CashOffice changes with respect to getStoreFinancialAccListForPOS
  // call - End


  // Bala: Added for Data security for Sprint 10.2 - Start

  public static final String PROTEGRITY_SERVER_HOST = "PROTEGRITY_SERVER_HOST";
  public static final String POLICY_USER = "POLICY_USER";
  public static final String PROTEGRITY_SERVER_HOST_OMSe = "PROTEGRITY_SERVER_HOST_OMSe";
  public static final String POLICY_USER_OMSe = "POLICY_USER_OMSe";
  public static final String NoOfAttributes = "NoOfAttributes";
  public static final String DelimitedSlash = "\\|";
  public static final String Encrypt = "Encrypt";
  public static final String ExtnTaxExemptCustName = "ExtnTaxExemptCustName";
  public static final String Decrypt = "Decrypt";
  public static final String Name = "Name";
  public static final String Value = "Value";
  public static final String DataElement = "DataElement";
  public static final String Reference = "Reference";
  public static final String DL = "DL";

  // Bala: Added for Data security for Sprint 10.2 - End

  // Added for TVS changes for Sprint 10.3 - Start
  // public static final String PRICE_REQUEST = "PriceRequest";
  // public static final String STORE_NUM="StoreNum";
  // public static final String SELLER_ORGANIZATION_CODE="SellerOrganizationCode";
  // public static final String ATTR_ID ="Id";
  // public static final String ATTR_EMP_DISC_CODE="EmpDiscCode";
  // public static final String ATTR_SCAN_TIME ="ScanTime";
  // public static final String ATTR_PROMO_LIST = "PromoList";
  // public static final String ATTR_PROMO_SCHEME_CODE="PromoSchemeCode";
  // public static final String ATTR_RECEIPT_CMT_TEXT="ReceiptCommentText";
  // public static final String ATTR_DISCOUNT_AMT="DiscountAmount";
  // public static final String ATTR_DISCOUNT_PERCENT="DiscountPercent";
  // public static final String ATTR_INC_BUY_QTY="incentiveBuyQuantity";

  // Added for TVS changes for Sprint 10.3 - End

  // Defect 4873 - Start
  public static final String GET_ORDER_INVOICE_DETAIL_OUTPUT =
      "/global/template/event/SEND_INVOICE.PUBLISH_INVOICE_DETAIL.KOHLS-RETAIL.xml";
  public static final String API_GET_ORDER_INVOICE_DETAILS = "GetOrderInvoiceDetails";
  public static final String E_GET_ORDER_INVOICE_DETAILS = "GetOrderInvoiceDetails";
  public static final String E_INVOICE_KEY = "InvoiceKey";
  public static final String GET_ORDER_DETAILS_OUTPUT =
      "/global/template/api/POC/saleshub/POC_getOrderDetailsForSalesHub.xml";
  // Defect 4873 - End

  // Added for defect 4665 - TenderSignature Issue
  public static final String ATTR_PARENT_TABLE_KEY = "ParentTableKey";
  public static final String ATTR_PARENT_TABLE = "ParentTable";
  public static final String YFS_PAYMENT = "YFS_PAYMENT";

  // TVS -- start
  public static final String KOHLS_POC_TVS_WEB_SERVICE = "KohlsPoCTVSWebService";
  public static final int LLD_ID = 2000;
  public static final int TLD_ID = 1000;
  public static final String A_ID = "Id";
  public static final String E_PARENT_DISCOUNT_ID = "ParentDiscountId";
  public static final String A_PROMO_SCHEME_CODE = "PromoSchemeCode";
  public static final String A_RECPT_CMMT_TXT = "ReceiptCommentText";
  public static final String A_DISCNT_AMT = "DiscountAmount";
  public static final String A_DISCNT_PCT = "DiscountPercent";
  public static final String A_INC_BUY_QTY = "IncentiveBuyQuantity";

  public static final String PRICE_REQUEST = "priceRequest";
  public static final String STORE_NUM = "storeNum";
  public static final String SELLER_ORGANIZATION_CODE = "SellerOrganizationCode";
  public static final String ATTR_ID = "id";
  public static final String ATTR_EMP_DISC_CODE = "empDiscCode";
  public static final String ATTR_SCAN_TIME = "scanTime";
  // public static final String KOHLS_POC_TVS_WEB_SERVICE = "KohlsPoCTVSWebService";
  public static final String ATTR_PROMO_LIST = "promoList";
  public static final String ATTR_PROMO_SCHEME_CODE = "promoSchemeCode";
  public static final String ATTR_RECEIPT_CMT_TEXT = "receiptCommentText";
  public static final String ATTR_DISCOUNT_AMT = "discountAmount";
  public static final String ATTR_DISCOUNT_PERCENT = "discountPercent";
  public static final String ATTR_INC_BUY_QTY = "incentiveBuyQuantity";
  // Updated for defect 5626 - Start
  public static final String ATTR_INC_BUY_AMT = "incentiveBuyAmount";
  // Updated for defect 5626 - End
  public static final String ATTR_TRANSACTION = "transaction";
  public static final String ATTR_ITEM_LIST = "itemList";
  public static final String ELEM_SMALL_ITEM = "item";
  public static final String ATTR_BOGO_GRP_CODE = "bogoGrpCode";
  public static final String ATTR_REGULAR_PRICE = "regularPrice";
  public static final String ATTR_EXCLUSION_ITEM = "exclusionItem";
  public static final String ELEM_MODIFIER = "modifier";
  public static final String ATTR_PARENT_DISCOUNT_GUID = "parentDiscountGuid";
  public static final String ATTR_ADJUSTMENT_ID = "adjustmentID";
  public static final String ATTR_TAXABLE_PRICE_DELTA = "taxablePriceDelta";
  public static final String ATTR_SKU = "sku";
  public static final String ELE_MANUAL_LID = "manualLID";
  public static final String ELE_MANUAL_TLD = "manualTLD";
  public static final String ATTR_DOLLAR_OFF = "dollarOff";
  public static final String ATTR_PERCENT_OFF = "percentOff";
  public static final String ATTR_CORRECTED_PRICE = "correctedPrice";
  public static final String ATTR_SCAN_ORDER = "scanOrder";
  public static final String ATTR_DISCOUNT_TYPE = "discountType";
  public static final String ATTR_MARK_DOWN_VALUE = "markDownValue";
  public static final String ATTR_SECONDARY_MARK_DOWN_VALUE = "secondaryMarkDownValue";
  public static final String ATT_GIFT = "gift";
  public static final String ATTR_LEGACY_FLAG = "legacyFlag";
  public static final String E_TLDS = "TLDs";
  public static final String ELEM_PROMO = "promo";
  public static final String ELEM_OFFER = "offer";
  public static final String ELEM_OFFERS = "offers";
  public static final String ATTR_OFFER_ID = "offerId";
  public static final String ATTR_OVERRIDE_FLAG = "overrideFlag";

  public static final String ELEM_MANUAL_TLD = "manualTLD";
  public static final String ELEM_MANUAL_LID = "manualLID";
  public static final String ATTR_RETURN_PRICE = "returnPrice";
  public static final String ATTR_TAXABLE_PRICE = "taxablePrice";
  public static final String ATTR_SELLING_PRICE = "sellingPrice";
  public static final String ATTR_SIMPLE_PROMO_PRICE = "simplePromoPrice";
  public static final String ATTR_NET_PRICE = "netPrice";
  public static final String ATTR_RECEIPT_RETURN_PRICE = "receiptReturnPrice";
  public static final String ATTR_PWP_GWP_GROUP_CODE = "pwpGwpGroupCode";
  public static final String ATTR_BUY_ITEM = "buyItem";
  public static final String ATTR_DISC_ELG_IND = "discountEligibilityIndicator";
  public static final String ATTR_SKU_STATUS = "skuStatus";
  public static final String ATTR_LAST_NON_CLR_PRI = "lastNonClearancePrice";
  public static final String ATTR_MODIFIER_ACTIVE = "modifierActive";
  public static final String ATTR_NET_PRICE_DELTA = "netPriceDelta";
  public static final String ATTR_TIER_ACTIVATION_ACHIEVED = "tierActivationAchieved";
  public static final String ATTR_TIER_PERCENT_ACHIEVED = "tierPercentAchieved";
  public static final String ATTR_TIER_LEVEL_ACHIEVED = "tierLevelAchieved";
  public static final String ATTR_PRECEDENCE = "precedence";
  public static final String ATTR_PROMO_INTERFACE_ID = "promoInterfaceId";
  public static final String ATTR_PROMO_INTERFACE_SUB_ID = "promoInterfaceSubId";
  public static final String ATTR_DISC_LVL_CODE = "discountLevelCode";

  public static final String ELE_REBATE = "rebate";
  public static final String ELE_EXCLUSIONS = "exclusions";
  public static final String ELE_EXCLUSION_TAG = "exclusionTag";
  public static final String ELE_EXCLUSION = "exclusion";

  public static final String CAPS_STORE_NUM = "StoreNum";
  public static final String STORE_ID_CHECK = "2000";

  public static final String ATTR_PARENT_DISCOUNT_ID = "parentDiscountId";

  public static final String A_REFERENCES = "References";
  public static final String A_REFERENCE = "Reference";

  // TVS Erro Codes : START //

  public static final String NO_SKU_DATA_FOUND = "NO_SKU_DATA_FOUND";
  public static final String UNKNOWN_STORE_ID = "UNKNOWN_STORE_ID";
  public static final String NO_OFFER_DATA_FOUND = "NO_OFFER_DATA_FOUND";
  public static final String OFFER_END_DATE_PASSED = "OFFER_END_DATE_PASSED";
  public static final String OFFER_OVR_DATE_PASSED = "OFFER_OVR_DATE_PASSED";
  public static final String OFFER_NOT_STARTED = "OFFER_NOT_STARTED";
  public static final String OFFER_DUPLICATION = "OFFER_DUPLICATION";
  public static final String SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE";
  public static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
  public static final Integer BAD_REQUEST_400 = 400;
  public static final Integer FORBIDDEN_REQUEST_403 = 403;
  public static final Integer NOT_FOUND_REQUEST_404 = 404;
  public static final String INVALID_REQUEST = "INVALID_REQUEST";
  public static final String MISSING_PARAMETER = "MISSING_PARAMETER";
  public static final String INVALID_MARK_DOWN_VALUE = "INVALID_MARK_DOWN_VALUE";
  public static final String TOO_MANY_SKUS = "TOO_MANY_SKUS";
  public static final String TOO_MANY_PROMO_IDS = "TOO_MANY_PROMO_IDS";
  public static final String NO_SUCH_BATCH_ID = "NO_SUCH_BATCH_ID";
  public static final String NO_SUCH_JOB_ID = "NO_SUCH_JOB_ID";
  public static final String NO_PRICE_DATA_FOUND = "NO_PRICE_DATA_FOUND";
  public static final String UNKNOWN_PARAMETER = "UNKNOWN_PARAMETER";
  public static final String INTERNAL_ERROR = "INTERNAL_ERROR";
  public static final String TOO_MANY_PRODUCTS = "TOO_MANY_PRODUCTS";
  public static final String INVALID_DISCOUNT_TYPE = "INVALID_DISCOUNT_TYPE";
  public static final String TVSSERVDOWN = "TVSSERVDOWN";
  public static final String INVALID_TIME_RANGE = "INVALID_TIME_RANGE";
  public static final String PROMPT_FOR_PRICE = "PROMPT_FOR_PRICE";

  // TVS Erro Codes : END //

  // TVS -- end

  // Rest Api Constants
  public static final String RESTAUTHORIZATION = "Authorization";
  public static final String CONTENT_LENGTH = "Content-Length";
  public static final String CONTENT_TYPE = "Content-Type";
  public static final String ACCEPT = "Accept";
  public static final String X_DEP_DATE = "x-dep-date";
  public static final String X_DEP_REQUEST_ID = "x-dep-request-id";
  public static final String X_DEP_FROM_SYSTEM_CODE = "x-dep-from-system-code";
  public static final String X_DEP_FROM_APP = "x-dep-from-app";
  public static final String X_DEP_FROM_NODE = "x-dep-from-node";
  public static final String X_DEP_IN_REPLY_TO = "x-dep-in-reply-to";
  public static final String CMDM = "CMDM";
  public static final String DKC = "DKC";
  public static final String HMACSHA = "HmacSHA256";

  public static final String NEW_LINE = "\n";
  public static final String COLON = ":";


  public static final String CHARSET_NAME = "UTF8";

  public static final String AUTHID = "DEP1-HMAC-SHA256 ";

  // added for updating Tax details
  public static final String A_AGENCY_NAME = "ExtnTaxExemptAgencyName";

  // Sudina - Change for TVS phase 2 - taxware - Start
  public static final String ORIGINAL_SALES_DATE = "/Order/OrderLines/OrderLine/CustomAttributes";
  public static final String SMALL_ATTR_TRANSACTION_ID = "transactionId";
  public static final String SMALL_ATTR_CITY_NAME = "cityName";
  public static final String SMALL_ATTR_COUNTRY_CODE = "countryCode";
  public static final String SMALL_ATTR_POSTAL_CODE = "postalCode";
  public static final String SMALL_ATTR_STATE_PROV = "stateOrProvince";
  public static final String SMALL_ATTR_GEO_CODE = "geoCode";
  public static final String SMALL_ELEM_STORE_ADDRESS = "storeAddress";
  public static final String ATTR_CITY = "City";
  public static final String ATTR_COUNTRY = "Country";
  public static final String ATTR_STATE = "State";
  public static final String ATTR_TAX_GEO_CODE = "TaxGeoCode";
  public static final String ATTR_EXTN_TAX_EXEMPT_CUST_FLAG = "ExtnTaxExemptCustFlag";
  public static final String ATTR_TAX_EXEMPT_CERTIFICATE = "TaxExemptionCertificate";
  public static final String ATTR_TAX_EXEMPT = "taxExempt";
  public static final String SMALL_ELEM_LINE_TAXES = "lineTaxes";
  public static final String SMALL_ELEM_LINE_TAX = "lineTax";
  public static final String SMALL_TAX = "tax";
  public static final String ATTR_EXTN_RECYCLE_FEE_ID = "ExtnRecycleFeeID";
  public static final String ATTR_SMALL_TAX_PERCENT = "taxPercentage";
  public static final String ATTR_SMALL_LINE_PRICE_INFO = "linePriceInfo";
  public static final String CONST_PRICE = "Price";
  public static final String SMALL_TAX_CODE_INDICATOR = "taxCodeIndicator";
  public static final String TAXWARE_CALL = "taxwareCall";
  public static final String TAX_EXEMPT_FLAG = "TaxExemptFlag";
  public static final String SMALL_CHARGE_CATEGORY = "chargeCategory";
  public static final String SMALL_TAX_NAME = "taxName";
  public static final String SMALL_TAX_TYPE = "taxType";
  public static final String ATTR_TAX_TYPE = "TaxType";
  public static final String ATTR_EXTN_SALE_PRICE = "ExtnSalePrice";
  // Sudina - Change for TVS phase 2 - taxware - End
  public static final String API_GET_TEAM_LIST = "getTeamList";
  // public static final String TEMPLATE_GET_OFFLINE_CUST_REWARD =
  // "<KOHLSCMDMOfflineKC><KOHLSCMDMOfflineRWDList><KOHLSCMDMOfflineRWD LoyAcctNbr=''
  // /></KOHLSCMDMOfflineRWDList></KOHLSCMDMOfflineKC>";
  // public static final String TEMPLATE_GET_OFFLINE_CUST_KC="<KOHLSCMDMOfflineKC KohlsChargeCard=''
  // />";
  public static final String TEMPLATE_GET_OFFLINE_CUST_REWARD =
      "<KOHLSCMDMOfflineRWD LoyAcctNbr=''/>";
  public static final String TEMPLATE_GET_OFFLINE_CUST_KC =
      "<KOHLSCMDMOfflineKC KohlsChargeCard=''/>";
  public static final String CUSTOM_ATRRIBUTES = "OrderLines/OrderLine/CustomAttributes";
  // Sudina - Change for PinPad Pairing to Training Mode - Start

  public static final String TRAINING_MODE_URL = "training_env_interop_servlet_url";
  public static final String ATTR_PSI_STATUS = "PSIStatus";
  public static final String ATTR_CLIENT_ID = "ClientID";
  public static final String STR_STERLING_HTTP_TESTER = "SterlingHttpTester";
  public static final String STR_USER_ID = "UserID";
  public static final String API_GET_PSI_STATUS_LIST_FOR_POS = "getPSIStatusListForPOS";
  public static final String API_MANAGE_PSI_STATUS_FOR_POS = "managePSIStatusForPOS";
  public static final String STR_INTEROP_API_DATA = "InteropApiData";
  public static final String STR_ENV_USERID = "YFSEnvironment.userId";
  public static final String STR_ENV_PASSWORD = "YFSEnvironment.password";
  public static final String STR_ENV_PROGID = "YFSEnvironment.progId";
  public static final String STR_IS_FLOW = "IsFlow";
  public static final String STR_INTEROP_API_NAME = "InteropApiName";
  public static final String STR_ENV_PROGID_VALUE = "InteropServletUpdate";
  // Sudina - Change for PinPad Pairing to Training Mode - End
  // Fix for defect 1172 - Start
  public static final String[] strTaxNames = new String[] {"Federal Tax", "State Tax", "County Tax",
      "City Tax", "SecState Tax", "SecCounty Tax", "SecCity Tax", "District Tax"};
  // Fix for defect 1172 - End

  public static final String SMALL_ATTR_DESCRIPTION = "description";
  public static final String SMALL_ATTR_PERCENTAGE = "percentage";
  public static final String SMALL_ATTR_AMOUNT = "amount";
  public static final String SMALL_ATTR_FEE = "FEE";

  // Added for RebateId change for Release 2 - Start
  public static final String A_EXTN_REBATE_REFERENCE_NO = "ExtnRebateReferenceNo";
  // Added for RebateId change for Release 2 - End
  //Added for ReturnReasonCode of omni auto returns
  public static final String A_EXTN_REASON_CODE = "ExtnReasonCode";
  // Adde for Detokenization

  public static final String API_CREATE_ASYNC_REQUEST = "createAsyncRequest";
  public static final String E_CREATE_ASYNC_REQUEST = "CreateAsyncRequest";

  public static final String A_IS_SERVICE = "IsService";

  public static final String SERVICE_NAME = "ServiceName";

  public static final String API_GET_ASYNC_REQUEST = "getAsyncRequestList";

  public static final String TEMPLATE_INPUT_GET_ASYNC_REQ =
      "<AsyncronousRequest  IsService='Y' ServiceName='' />";

  public static final String TEMPLATE_OUTPUT_GET_ASYNC_REQ =
      "<AsyncronousRequestList><AsyncronousRequest AsyncronousRequestKey='' ErrorCount='' IsService='Y' ServiceName='' Message=''/></AsyncronousRequestList>";

  // Added for InvalidTaxGeoCode changes - Start

  public static final String INVALIDGEOCODE = "INVALIDGEOCODE";

  // Added for InvalidTaxGeoCode changes for Release 1 - End

  // Added for TVS Error Handling changes

  public static final String TAXCODEINDICATORERR = "TAXCODEINDICATORERR";

  // Added for TVS Error Handling changes
  // Added CustomerLookup Error Handling changes
  public static final String NO_RECORD_FOUND = "NO_RECORD_FOUND";
  public static final String NO_RECORD_FOUND_DESC = "Kohl's Yes2You Rewards account not found";
  public static final String BAD_REQUEST = "400";
  public static final String BAD_REQUEST_1 = "500";
  public static final String BAD_REQUEST_DESC = "Kohl's Yes2You Rewards account cannot be added";
  public static final String UNAVAILABLE_DESC = "Kohl's Yes2You Rewards Lookup unavailable";
  public static final String TIMED_OUT = "TIMED_OUT";
  public static final String SERVICE_UNAVAILABLE_503 = "503";
  public static final String BAD_REQUEST_CODE = "BAD_REQUEST";
  // Added CustomerLookup Error Handling changes

  // Added as part of POC-Instore Release 1-- Start

  /*
   * public static final String API_GET_KHOLS_PAYMENT_EXTENSION="getKohlsPaymentExtnList";
   * 
   * public static final String API_CREATE_KHOLS_PAYMENT_EXTENSION="createKohlsPaymentExtn";
   * 
   * public static final String API_DELETE_KHOLS_PAYMENT_EXTENSION="deleteKohlsPaymentExtn";
   */
  public static final String API_GET_KHOLS_PAYMENT_EXTENSION = "KohlsGetPaymentExtnList";

  public static final String API_CREATE_KHOLS_PAYMENT_EXTENSION = "KohlsCreatePaymentExtn";

  public static final String API_DELETE_KHOLS_PAYMENT_EXTENSION = "KohlsDeletePaymentExtn";

  // Added as part of POC-Instore Release 1-- End
  // Added CustomerLookup Error Handling changes


  // Sudina : PIF/PUF changes - Start
  public static final String SMALL_ATTR_FEES = "fees";
  public static final String CONST_FEE = "FEE";
  public static final String SMALL_ATTR_FEE_TYPE = "feeType";
  public static final String SMALL_ATTR_CAL_AMT = "calculatedAmount";
  public static final String SMALL_ATTR_IS_TAXABLE = "isTaxable";
  public static final String SMALL_ATTR_RATE_FEE = "rateFee";
  public static final String ATTR_EXTN_FEE_ID = "ExtnFeeID";
  public static final String EXTN_CHARGE_DESCRIPTION = "ExtnChargeDescription";
  public static final String ATTR_EXTN_COMPLETION_CODE = "ExtnCompletionCode";
  public static final String ATTR_EXTN_COMMENT_CODE = "ExtnCommentCode";
  public static final String ATTR_EXTN_STATUS_CODE = "ExtnStatusCode";
  public static final String ATTR_EXTN_BASIS_AMOUNT = "ExtnBasisAmount";
  public static final String ATTR_EXTN_EXEMPT_AMOUNT = "ExtnExemptAmount";
  public static final String SMALL_ATTR_FEE_ID = "feeId";
  public static final String SMALL_ATTR_COMPLETION_CODE = "completionCode";
  public static final String SMALL_ATTR_COMMENT_CODE = "commentCode";
  public static final String SMALL_ATTR_STATUS_CODE = "statusCode";
  public static final String SMALL_ATTR_BASIS_AMOUNT = "basisAmount";
  public static final String SMALL_ATTR_EXEMPT_AMOUNT = "exemptAmount";
  public static final String SMALL_SHORT_DESCRIPTION = "shortDescription";

  // Sudina : PIF/PUF changes - End

  // Certification Changes R2 - Start

  public static final String STR_LOGIN_PASSWORD = "LoginPassword";
  public static final String STR_KSPath = "KSPath";
  public static final String STR_KSPassword = "KSPassword";


  // Certification Changes R2 - End

  // Fix for defect 1371 - Start
  public static final String ATTR_PLU_PRICE = "pluPrice";

  // Fix for defect 1371 - End


  public static final String QUICK_CREDIT_DISCOUNT = "QUICK_CREDIT_DISCOUNT";

  // Added for event name changes

  public static final String KC_EVENT_NAME = "EventName";

  // Added for QuickCredit - Start



  public static final String MESSAGE_TYPE_QC_OFFLINE = "QCOffline";
  public static final String GET_ADMIN_AUDIT_FOR_QC_OFFLINE_TEMPLATE =
      "<AdminAudit AdminAuditKey='' BusinessDay='' Createprogid='' Createts='' Createuserid='' DateTime='' Lockid='' ManagerID='' Modifyprogid='' Modifyts='' Modifyuserid='' OperatorID='' OrganizationCode='' POSSequenceNumber='' ProcedureID='' TerminalID='' TillID='' TransactionNumber=''><AdditionalDataList><AdditionalData AdditionalDataKey='' Name='' ParentKey='' ParentTable='' Value=''/></AdditionalDataList></AdminAudit>";
  // Added for QuickCredit - End

  // R3 KohlsPreScreen Constants Start
  public static final String STORE_ID = "StoreID";
  public static final String TRANSACTION_GRAND_TOTAL = "TransactionGrandTotal";
  public static final String EMAIL_ADDRESS = "EmailAddress";
  public static final String CUSTOMER_REWARDS_NO = "CustomerRewardsNo";
  public static final String KOHLS_POC_PRESCREEN_WEBSERVICE = "KohlsPoCPreScreenWebService";
  public static final String PRESCREEN_RESPONSE_ELEMENT = "PreScreenResponse";
  public static final String RESPONSE_CODE = "ResponseCode";
  public static final String AUTH_TIME = "AuthTime";
  public static final String CORRELATION_ID = "CorrelationID";
  public static final String AUTH_TIME_FORMAT = "ss.SSS";
  // Namespace
  public static final String WEB_NS = "http://webservice.pz.pp.kohls.com";
  public static final String LYP_NS = "http://www.kohls.com/ep/sh/1.0/LYPersonLookupRequest";
  public static final String LYP1_NS = "http://www.kohls.com/ep/sh/1.0/LYPerson";



  public static final String PRESCREEN_CUSTOMER_QN = "web:prescreenCustomer";
  public static final String PERSON_LOOKUP_QN = "web:personLookup";
  public static final String EMAIL_ADDRESS_QN = "lyp:EmailAddress";
  public static final String TRANSACTION_AMOUNT_QN = "lyp:TransactionAmount";
  public static final String STORE_ID_QN = "lyp:StoreID";
  public static final String PERSON_QN = "lyp1:Person";
  public static final String LOYALTY_QN = "lyp1:Loyalty";
  public static final String LOYALTY_ID_QN = "lyp1:LoyaltyID";
  // XPATH
  public static final String PRESCREEN_CUSTOMER_RESPONSE_RESULT_XPATH =
      "/prescreenCustomerResponse/response/Result/text()";
  public static final String PRESCREEN_CUSTOMER_RESPONSE_CORRELATION_ID_XPATH =
      "/prescreenCustomerResponse/response/CorrelationID/text()";
  // ResponseCode
  public static final String TIMEOUT_RESPONSE_CODE = "Timeout";
  public static final String OFFLINE_RESPONSE_CODE = "Offline";
  public static final String OFFER_RESPONSE_CODE_WS = "Offer";
  public static final String PROCESS_COMPLETE_RESPONSE_CODE_WS = "Process Complete";
  public static final String DECLINE_RESPONSE_CODE = "Decline";
  public static final String EDIT_ERROR_RESPONSE_CODE_WS = "Edit Error";
  public static final String EDIT_ERROR_RESPONSE_CODE = "EditError";
  public static final String EXISTING_KOHLS_CHARGE_RESPONSE_CODE_WS = "Existing Kohl's Charge";
  public static final String EXISTING_KOHLS_CHARGE_RESPONSE_CODE = "ExistingKohlsCharge";
  public static final String EXISTING_RESPONSE_CODE_WS = "Existing";
  public static final String BAD_RESPONSE_WS = "bad response";
  // R3 KohlsPreScreen Constants End

  // Added for #213 - begin
  public static final String ATTR_EXTN_REGISTER_BANK_NUMBER = "ExtnRegisterBankNumber";
  public static final String ATTR_EXTN_REGISTER_LOCATION = "ExtnRegisterLocation";
  public static final String GET_ORDER_LIST_TEMP_FOR_NON_SALE =
      "<OrderList><Order OrderHeaderKey=''><Extn ExtnRegisterBankNumber='' ExtnRegisterLocation=''/></Order></OrderList>";
  // Added for #213 - end

  // Added for R3 - RKC - Begin
  public static final String ATTR_RETURN_PRICE_DELTA = "returnPriceDelta";
  public static final String ATTR_RETURN_PRICE_DELTA_APE = "ReturnPriceDelta";
  public static final String A_EXTN_RETRN_DELTA = "ExtnRetrnDelta";
  // Added for R3 - RKC - End
  // Fix for 2322 and 2333 - Start
  public static final String QUICK_CREDIT_TLD_ORDER_PROP_KEY = "Quick_Credit_TLD_Order";
  // Fix for 2322 and 2333 - End
  public static final String DEPARTMENT = "department";
  // Start ApplePayLoyaltyID - Rest Call DSB Service CR-935 Release 3 Sprint 2

  // ---------------------------------------------------------------
  // Start: Kohls_Returns_Related_Changes_for_EE_and_PSA
  // ---------------------------------------------------------------
  // need to change
  public static final String PSA_ADJUSTMENTS = "psa";
  // added for psapublic static final String TEMPLATE_GET_OFFLINE_CUST_KC="<KOHLSCMDMOfflineKC
  // KohlsChargeCard='' />";
  public static final String ISPSAPROMOTION = "ExtnIsPsaPromotion";
  public static final String ADJUSTMENTMANUALTLD = "adjustmentManualTLD";
  public static final String ADJUSTMENS = "adjustments";
  public static final String ADJUSTMENT_REQUEST = "adjustmentRequest";
  public static final String ORIGINAL_TRANSACTION = "originalTransaction";
  public static final String TRANSACTION_TIME = "transactionTime";
  public static final String LID_OFFER_EXEMPT = "lidOfferExempt";
  public static final String MERCHANDISE_HIRARCHY = "merchandiseHierarchy";
  public static final String EXTN_ITEM_DEPT = "ExtnItemDept";
  public static final String EXTN_ITEM_CLASS = "ExtnItemClass";
  public static final String EXTN_ITEM_SUB_CLASS = "ExtnItemSubClass";
  public static final String EXTN_VENDOR_STYLE_NO = "ExtnVendorStyleNo";

  public static final String MAJOR_CLASS = "majorClass";
  public static final String SUB_CLASS = "subClass";
  public static final String VENDOR_STYLE = "vendorStyle";
  public static final String EXTN_SKU_STATUS_CODE = "ExtnSkuStatusCode";
  public static final String REGULAR_PRICE_STATUS = "regularPriceStatus";
  public static final String EXTN_IS_DISCOUNTABLE = "ExtnIsDiscountable";
  public static final String NON_DISCOUNTABLE_FLAG = "NonDiscountableFlag";

  public static final String EXISTING_OFFER = "existingOffer";
  public static final String ADJUSTMENT_OFFERS = "adjustmentOffers";
  public static final String TRAN_LIMIT = "tranLimit";
  public static final String APPLICATION_CODE = "applicationCode";
  public static final String OFFER_TYPE = "offerType";
  public static final String SCHEME_CODE = "schemeCode";
  public static final String BUY_CRITERIA = "buyCriteria";
  public static final String GET_CRITERIA = "getCriteria";
  public static final String CRITERIA_TYPE = "criteriaType";
  public static final String BUY_DOLLOR = "buyDollar";
  public static final String GET_PERCENT = "getPercent";
  public static final String MDE_SET = "mdseSet";
  public static final String SKU_SMALL = "sku";
  public static final String THREE = "3";
  public static final String FIVE = "5";
  public static final String SIX = "6";
  public static final String TEN = "10";
  public static final String FIFTEEN = "15";
  public static final String SIXTEEN = "16";
  public static final String TWENTY_THREE = "23";
  public static final String TWENTY_FOUR = "24";
  public static final String TWENTY_FIVE = "25";
  public static final String THIRTY_SIX = "36";
  public static final String THIRTY_EIGHT = "38";
  public static final String PROMOTIONID = "PromotionId";
  public static final String KOHLS_POC_PSA_WEB_SERVICE = "KohlsPOCTVSPSAWebService";
  public static final String IS_PSA_CHANGE_ORDER = "IsPSAChangeOrder";
  public static final String PR = "PR";
  public static final String TR = "TR";
  public static final String STRING_THOUSAND_NINE = "1009";
  public static final String STRING_ONE_CENT = "0.01";
  public static final String GET_PERCENT_OFF = "GetPercentOff";
  public static final String THIRTY_NINE = "39";
  public static final String TD = "TD";
  public static final String ONE_THOUSAND_EIGHT = "1008";
  public static final String CHARGE_NAME_KEY = "ChargeNameKey";
  public static final String INVOICED_TAX = "InvoicedTax";
  public static final String REFERENCE_TWO = "Reference_2";
  public static final String REFERENCE_ONE = "Reference_1";
  public static final String REFERENCE_THREE = "Reference_3";
  public static final String REMAINING_TAX = "RemainingTax";
  public static final String TLD = "tld";
  public static final String TLD_IMPACT = "TLDImpact";

  public static final String X_KOHLS_CREATE_DATE_TIME = "X-KOHLS-CreateDateTime";
  public static final String X_KOHLS_MESSAGE_ID = "X-KOHLS-MessageID";
  public static final String X_KOHLS_FROM_SYSTEM_CODE = "X-KOHLS-From-SystemCode";
  public static final String X_KOHLS_FROM_APP = "X-KOHLS-From-App";
  public static final String X_KOHLS_FROM_MODULE = "X-KOHLS-From-Module";
  public static final String X_KOHLS_FROM_NODEID = "X-KOHLS-From-NodeID";
  public static final String X_KOHLS_VERSION = "X-KOHLS-Version";

  public static final String STRING_ACTION = "Action";
  public static final String STRING_VENDOR = "Vendor";
  public static final String STRING_PAYLOADTYPE = "PayloadType";
  public static final String STRING_PAYLOAD = "Payload";
  public static final String STRING_ENCODINGTYPE = "EncodingType";
  public static final String STRING_DESECURE = "DESECURE";
  public static final String STRING_DOT_MONITORED = ".MONITORED";
  public static final String STRING_DOT_BACKUP_ENDPOINT = ".BACKUP_ENDPOINT";
  public static final String STRING_PRIMARY = "PRIMARY";
  public static final String STRING_BACKUP = "BACKUP";
  public static final String STRING_OFFLINE = "OFFLINE";
  public static final String STRING_EXTN_OTHER = "EXTN_OTHER";

  public static final String ATTR_VERSION_XPATH =
      "/Versions/Version[@Name='Sterling Selling and Fulfillment Suite']";
  public static final String API_GETSERVERLIST_NAME = "getServerList";
  public static final String API_GETVERSION_NAME = "getVersionInfoForPOS";
  public static final String ATTR_SERVER_XPATH = "/Servers/Server[@Status='Active']";

  // End ApplePayLoyaltyID - Rest Call DSB Service CR-935 Release 3 Sprint 2

  // R3 Sprint2 Kohls PoC Bopus Constants - Start

  public static final String ACTION = "Action";
  public static final String ORDER_SEARCH_ACTION = "orderSearch";
  public static final String NAME_SEARCH_ACTION = "nameSearch";
  public static final String RECORD_PICKUP_ACTION = "recordPickup";
  public static final String EXTEND_EXPIRATION_ACTION = "extendExpiration";
  public static final String CANCEL_PICKUP_ACTION = "cancelPickup";
  public static final String UPDATE_EXPIRATION_ACTION = "updateExpiration";
  public static final String SHIPNODE = "//Shipment/@ShipNode";
  public static final String ORDERNO = "//Shipment/@OrderNo";
  public static final String BILLTO_FIRSTNAME = "//Shipment/BillToAddress/@FirstNameLc";
  public static final String BILLTO_LASTNAME = "//Shipment/BillToAddress/@LastNameLc";
  public static final String SHIPMENT_KEY = "//Shipment/@ShipmentKey";
  public static final String ORDER_HEADER_KEY = "//Shipment/@OrderHeaderKey";
  public static final String CUSTOMER_NAME = "//Shipment/@CustomerName";
  public static final String STORE_USER_ID = "//Shipment/@StoreUserId";
  public static final String SHIPMENT_LINE_KEY = "//Shipment/@ShipmentLineKey";
  public static final String QUANTITY = "//Shipment/@Quantity";
  public static final String POC_BOPUS_WEBSERVICE = "KohlsPoCBopusWebService";
  public static final String POC_BOPUS_ELEMENT_RETURN = "return";
  public static final String POC_BOPUS_ELEMENT_BOPUS_RESPONSE = "BOPUSResponse";
  public static final String POC_BOPUS_ELEMENT_SHIPMENTS = "Shipments";
  public static final String POC_BOPUS_ELEMENT_INPUT = "input";
  public static final String POC_BOPUS_ELEMENT_ENV = "env";

  public static final String POC_BOPUS_ATTRIBUTE_ACTION = "Action";
  public static final String POC_BOPUS_ATTRIBUTE_SHIPNODE = "ShipNode";
  public static final String POC_BOPUS_ATTRIBUTE_USERID = "userId";
  public static final String POC_BOPUS_ATTRIBUTE_PASSWORD = "password";
  public static final String POC_BOPUS_ATTRIBUTE_FIRSTNAME = "FirstNameLc";
  public static final String POC_BOPUS_ATTRIBUTE_LASTNAME = "LastNameLc";
  public static final String POC_BOPUS_ATTRIBUTE_ORDER_NO = "OrderNo";
  public static final String POC_BOPUS_ATTRIBUTE_ORDER_HEADER_KEY = "OrderHeaderKey";
  public static final String POC_BOPUS_ATTRIBUTE_SHIPMENT_KEY = "ShipmentKey";
  public static final String POC_BOPUS_ATTRIBUTE_SHIPMENT_LINE_KEY = "ShipmentLineKey";
  public static final String POC_BOPUS_ATTRIBUTE_ORDER_LINE_KEY = "OrderLineKey";
  public static final String POC_BOPUS_ATTRIBUTE_EXTNEXPIRATION_DATE = "ExtnExpirationDate";
  public static final String POC_BOPUS_ATTRIBUTE_CUSTOMER_NAME = "CustomerName";
  public static final String POC_BOPUS_ATTRIBUTE_STORE_USER_ID = "StoreUserId";
  public static final String POC_BOPUS_ATTRIBUTE_QUANTITY = "Quantity";
  public static final String POC_BOPUS_WEB_NS = "http://webservices.nativeapp.kohls.com/";
  public static final String POC_BOPUS_ORDERSEARCH_NS =
      "http://webservices.nativeapp.kohls.com/documentation/KohlsGetShipmentsForCustomerWebService/getKohlsShipmentsForCustomerWebService/input";
  public static final String POC_BOPUS_CANCEL_EXTEND_NS =
      "http://webservices.nativeapp.kohls.com/documentation/KohlsUpdateShipmentExpirationDateWebService/updateShipmentExpirationDateWebService/input";
  public static final String POC_BOPUS_RECORD_PICKUP_NS =
      "http://webservices.nativeapp.kohls.com/documentation/KohlsRecordCustomerPickWebService/recordCustomerPickWebService/input";
  public static final String POC_BOPUS_WEB_ORDERSEARCH_QN =
      "web:getKohlsShipmentsForCustomerWebService";
  public static final String POC_BOPUS_INP1_BILL_TO_ADDRESS_QN = "inp1:BillToAddress";
  public static final String POC_BOPUS_INP1_EXTN_STORE_PRE_RECEIPT_ID_QN =
      "inp1:ExtnStorePreencReceiptID";
  public static final String POC_BOPUS_INP1_SHIPMENTLINES_QN = "inp1:ShipmentLines";
  public static final String POC_BOPUS_INP1_SHIPMENTLINE_QN = "inp1:ShipmentLine";
  public static final String POC_BOPUS_WEB_CANCEL_EXTEND_QN =
      "web:updateShipmentExpirationDateWebService";
  public static final String POC_BOPUS_INP1_ORDERLINE_QN = "inp1:OrderLine";
  public static final String POC_BOPUS_INP1_EXTN_QN = "inp1:Extn";
  public static final String POC_BOPUS_WEB_RECORD_PICKUP_QN = "web:recordCustomerPickWebService";
  public static final String POC_BOPUS_EXCEPTION_EXTN_TIMEOUT = "EXTN_TIMEOUT";
  public static final String POC_BOPUS_EXCEPTION_EXTN_IO = "EXTN_IO";
  public static final String POC_BOPUS_EXCEPTION_SOAP_EXCEPTION = "SOAP_EXCEPTION";
  public static final String POC_BOPUS_EX_MESSAGE_SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE";
  public static final String POC_BOPUS_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
  public static final String POC_BOPUS_USER_ID = "PoCBopusWebserviceUserID";
  public static final String POC_BOPUS_PASSWORD = "PoCBopusWebservicePassword";
  public static final String PHONE_NO = "//Shipment/BillToAddress/@DayPhone";
  public static final String ENABLE_HISTORY = "//Shipment/@EnableHistory";
  public static final String POC_BOPUS_ATTRIBUTE_PHONE_NO = "DayPhone";
  public static final String POC_BOPUS_ATTRIBUTE_ENABLE_HISTORY = "EnableHistory";
  // R3 Sprint2 Kohls PoC Bopus Constants - End

  // Added for POC Return GIV
  public static final String ATTR_INVOICE_NO = "InvoiceNo";
  public static final String RO_DOCUMENT_TYPE = "0003";
  public static final String ELEM_INVOICE = "GetOrderInvoiceDetails";
  public static final String SUPPLY_TYPE_EF_ONHAND = "EF_ONHAND.ex";
  public static final String ATTR_SUPPLY_TYPE = "SupplyType";
  // Added for Even Exchange Data collect

  public static final String A_EXTN_SALES_TERMINAL_ID = "ExtnSalesTerminalID";
  public static final String A_EXTN_SALES_TRANSACTION_NO = "ExtnSalesTransactionNo";

  public static final String GET_INVOICE_ORDER_DET = "getOrderInvoiceDetails";
  public static final String GET_ORDER_DETAILS = "getOrderDetails";
  public static final String GET_ORDER_LIST = "getOrderList";
  public static final String DATACOLLECT = "global/template/api/DataCollect_Invoice.xml";
  public static final String DATACOLLECT_ORDER = "global/template/api/DataCollect_Order.xml";
  public static final String DATACOLLECT_ORDER_LIST =
      "global/template/api/DataCollect_Order_List.xml";
  public static final String DATACOLLECT_SALES_ORDER_LIST =
      "global/template/api/DataCollect_Sales_Order_List.xml";
  public static final String DATACOLLECT_LINKED_SOURCE_LIST =
      "global/template/api/DataCollect_Linked_Source_List.xml";
  public static final String EXTN_CALL_BACK_TYPE = "ExtnCallbackTypeCode";

  // Added for Detokenization Async Processing
  public static final String SERVICE_GET_CUSTOM_REPROCESS_LIST_REQUEST =
      "KohlsGetReprocessRecordsList";
  public static final String TEMPLATE_INPUT_GET_CUSTOM_REPROCESS_REQ =
      "<KohlsReprocessRequest ServiceName='' />";
  public static final String SERVICE_CREATE_CUSTOM_REPROCESS_REQUEST = "KohlsCreateReprocessRecord";
  public static final String E_CUSTOM_REPROCESS_REQUEST = "KohlsReprocessRequest";
  public static final String SERVICE_UPDATE_CUSTOM_REPROCESS_REQUEST = "KohlsUpdateReprocessRecord";
  public static final String SERVICE_DELETE_CUSTOM_REPROCESS_REQUEST = "KohlsDeleteReprocessRecord";
  public static final String TEMPLATE_INPUT_DELETE_CUSTOM_REPROCESS_REQ =
      "<KohlsReprocessRequest ReprocessRequestKey='' />";
  public static final String SERVICE = "ServiceName";
  public static final String MESSAGE = "Message";
  public static final String ERROR_COUNT = "RetryCount";
  public static final String IS_SUCCESS_FLAG = "IsSuccess";
  public static final String PURGE_DATE = "PurgeDate";
  public static final String NEXT_REPROCESS_TS = "NextReprocessTS";
  public static final String IS_FLOW = "IsFlow";
  public static final String REPROCESS_REQ_KEY = "ReprocessRequestKey";
  public static final String COMMON_CODE_FOR_REPROCESS = "COMMON_REPROCESS";

  public static final String IS_MID_VOID_ORDER = "IsMidVoidOrder";
  public static final String IS_MID_POST_ORDER = "IsPostVoidOrder";
  public static final String MID_VOID_SCENARIO = "MIDVOID";
  public static final String POST_VOID_SCENARIO = "POSTVOID";
  public static final String POC_FEATURE = "POCFeature";
  public static final String DUMMY_ID = "DUMMY_ID";
  // ---------------------------------------------------------------
  // End: Kohls_Returns_Related_Changes_for_EE_and_PSA
  // ---------------------------------------------------------------
  // Adding for PSA Kohls cash deactivation -START
  public static final String INVALID_GEO_CODE = "InvalidGeoCode";
  public static final String TAXCODE_INDICATOR_ERR = "TaxCodeIndicatorError";
  public static final String XPATH_ITEMLIST = "priceResponse/transaction/itemList";
  // Adding for PSA Kohls cash deactivation - END

  // Added for Kohls Cash redemption- Begin
  public static final String IS_PSA_ORDER = "IsPSAOrder";
  // Added for Kohls Cash redemption- End

  // Added for Tendering - Start
  public static final String ADJUSTMENT_RESPONSE_ITEMLIST =
      "adjustmentResponse/transaction/itemList";
  // Added for Tendering - End
  // R3 Sprint3 Kohls PoC Geo Capture Constants - Start
  public static final String POC_GEO_DOMAIN = "GEO_DOMAIN";
  public static final String POC_GEO_ENDPOINT = "GEO_ENDPOINT";
  public static final String POC_GEO_API_KEY = "GEO_API_KEY";
  public static final String POC_GEO_API_SECRET_KEY = "GEO_API_SECRET_KEY";
  public static final String POC_GEO_READ_TIME_OUT = "CUST_READ_TIME_OUT";
  public static final String POC_GEO_BANK_TOKEN = "GeoCodeBankToken";
  public static final String POC_GEO_CARD_HOLDER_NAME = "CardHolderName";
  public static final String POC_GEO_BANK_TOKEN_JSON = "cardNumberToken";
  public static final String POC_GEO_CARD_HOLDER_NAME_JSON = "cardHolderName";
  public static final String POC_GEO_CUSTOMERS = "customers";
  public static final String POC_GEO_CAPTURE_INDICATOR = "geoCaptureIndicator";
  public static final String POC_ELEMENT_GEO_CAPTURE = "GeoCapture";
  public static final String POC_ATTRIBUTE_GEO_BANK_TOKEN = "GeoCodeBankToken";
  public static final String POC_ATTRIBUTE_GEO_CODE_CAPTURED = "GeoCodeCaptured";
  // R3 Sprint3 Kohls PoC Geo Capture Constants - End


  // R3 Sprint3 rebate constants -Start
  public static final String START_DATE = "startDate";
  public static final String END_DATE = "endDate";
  public static final String ELEM_REBATES = "rebates";
  public static final String KOHLS_POC_TVS_WEB_SERVICE_TEST = "KohlsPoCTVSWebServiceTest";
  // R3 Sprint3 rebate constants -End

  // Changes for ExtendedPrice - Start
  public static final String A_EXTENDED_PRICE = "ExtendedPrice";
  // Changes for ExtendedPrice - End

  // BR914 RKCS Inquiry Change Start
  public static final String A_EXPIRATION_DATE = "ExpirationDate";
  public static final String A_COUPON_EXP_DATE = "CouponExpDate";
  // BR914 RKCS Inquiry Change End

  // Changes for AdjustmentApplied attribute - Start
  public static final String A_ADJUSTMENT_APPLIED = "AdjustmentApplied";
  // Changes for AdjustmentApplied attribute - End

  // Changes for date ranges R3 Sprint 4 - Start
  public static final String ALLOWED_TLD_COUNT = "allowedTLDCount";
  public static final String A_CODE_SHORT_DESC_QRY_TYPE = "CodeShortDescriptionQryType";
  public static final String A_OPERATOR = "Operator";
  public static final String ASSOCIATE_NUM_OFFERS = "ASSOCIATE_NUM_OFFERS";
  public static final String A_KOHLS_RETAIL = "KOHLS-RETAIL";
  public static final String HD_LE = "LE";
  public static final String A_CODE_LONG_DESC = "CodeLongDescription";
  public static final String A_QRY_TYPE = "QryType";
  public static final String HD_GE = "GE";
  public static final String AND = "AND";
  // Changes for date ranges R3 Sprint 4 - End


  // Added for PSA DC - Start
  public static final String X_INV_EXTN = "/InvoiceDetail/InvoiceHeader/Extn";
  public static final String X_INV_OVERALL_TOTALS =
      "/InvoiceDetail/InvoiceHeader/Order/OverallTotals";
  public static final String X_INV_ORDER = "/InvoiceDetail/InvoiceHeader/Order";
  public static final String X_INV_ORDER_EXTN = "/InvoiceDetail/InvoiceHeader/Order/Extn";
  public static final String X_INV_ORDERLINES = "/InvoiceDetail/InvoiceHeader/Order/OrderLines";
  public static final String X_INV_ORDERLINE =
      "/InvoiceDetail/InvoiceHeader/Order/OrderLines/OrderLine";
  public static final String X_INV_COLLECTION_DETAILS =
      "/InvoiceDetail/InvoiceHeader/CollectionDetails";
  public static final String X_INV_PERSON_INFO =
      "/InvoiceDetail/InvoiceHeader/Order/PersonInfoBillTo";
  public static final String X_INV_CHARGE_TRANS_DETAILS =
      "/InvoiceDetail/InvoiceHeader/Order/ChargeTransactionDetails";
  public static final String X_INV_CHARGE_TRANS_DETAIL =
      "/InvoiceDetail/InvoiceHeader/Order/ChargeTransactionDetails/ChargeTransactionDetail";
  public static final String X_INV_PROMOTIONS = "/InvoiceDetail/InvoiceHeader/Order/Promotions";
  public static final String X_INV_PROMOTION =
      "/InvoiceDetail/InvoiceHeader/Order/Promotions/Promotion";
  public static final String X_INV_TAX_DETAIL_LIST =
      "InvoiceDetail/InvoiceHeader/Order/TaxDetailList";
  public static final String X_INV_TAX_DETAIL =
      "/InvoiceDetail/InvoiceHeader/Order/TaxDetailList/TaxDetail";
  public static final String X_INV_COLLECTION_DETAIL =
      "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail";
  public static final String X_INV_COLLECTION_PAYMENT_METHOD =
      "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail/PaymentMethod";
  public static final String X_INV_COLLECTION_PERSON_INFO =
      "/InvoiceDetail/InvoiceHeader/CollectionDetails/CollectionDetail/PaymentMethod/PersonInfoBillTo";
  public static final String X_ORD_PERSON_INFO = "/Order/PersonInfoBillTo";
  public static final String X_ORD_PERSON_INFO_EXTN = "/Order/PersonInfoBillTo/Extn";
  public static final String X_CHARGE_TRANSACTION_DETAILS = "/Order/ChargeTransactionDetails";
  public static final String X_CHARGE_TRANSACTION_DETAIL =
      "/Order/ChargeTransactionDetails/ChargeTransactionDetail";
  public static final String X_KOHLS_SALES_ORDER = "/KOHLSSalesForPsa/Order";
  public static final String X_KOHLS_SALES_ORDER_EXTN = "/KOHLSSalesForPsa/Order/Extn";             
  public static final String X_KOHLS_SALES_ORDERLINE =
      "/KOHLSSalesForPsa/Order/OrderLines/OrderLine";
  public static final String X_KOHLS_SALES_PROMOTION =
      "/KOHLSSalesForPsa/Order/Promotions/Promotion";
  public static final String X_KOHLS_SALES_TAX_DETAIL =
      "/KOHLSSalesForPsa/Order/TaxDetailList/TaxDetail";
  public static final String X_KOHLS_SALES_OVERALL_TOTALS = "/KOHLSSalesForPsa/Order/OverallTotals";
  public static final String X_KOHLS_SALES_AWARD =
      "/KOHLSSalesForPsa/Order/OrderLines/OrderLine/Awards/Award";  

  public static final String X_CREDIT_CARD_TRANS = "CreditCardTransactions";
  public static final String X_CREDIT_CARD_TRAN = "/CreditCardTransactions/CreditCardTransaction";
  public static final String SER_REQUEST_COLLECTION_PSA = "RequestCollectionPSA";
  public static final String SER_EXECUTE_COLLECTION_PSA = "ExecuteCollectionPSA";
  public static final String SER_GET_KOHLS_SALES_DETAILS = "GetKohlsSalesDetails";
  public static final String ATTR_EXECUTE_COLLECTION = "ExecuteCollection";
  public static final String ATTR_KOHLS_SALES_FOR_PSA = "KOHLSSalesForPsa";
  public static final String ATTR_ORIG_SALE_DATA = "OriginalSaleData";
  public static final String ATTR_GRAND_TOTAL = "GrandTotal";
  public static final String ATTR_GRAND_TAX = "GrandTax";
  public static final String ATTR_GRAND_DISCOUNT = "GrandDiscount";
  public static final String ATTR_TOTAL_CHARGED = "TotalCharged";
  public static final String ATTR_TOTAL_DISCOUNT = "TotalDiscount";
  public static final String ATTR_TOTAL_TAX = "TotalTax";
  public static final String ATTR_AMT_COLLECTED = "AmountCollected";
  public static final String ATTR_DRIVERS_LICENSE = "DriversLicense";
  public static final String ATTR_DAY_PHONE = "DayPhone";
  public static final String ATTR_MOBILE_PHONE = "MobilePhone";
  public static final String ATTR_LINE_SEQ_NO = "LineSeqNo";
  public static final String ATTR_CORPORATE_REFUND = "CORPORATE_REFUND";
  public static final String ATTR_PSA = "PSA";
  public static final String ATTR_TAX_1 = "T1";
  public static final String ATTR_TAX_2 = "T2";
  public static final String ATTR_TAX_3 = "T3";
  public static final String ATTR_TAX_4 = "T4";
  public static final String ATTR_TAX_5 = "T5";
  public static final String ATTR_TAX_6 = "T6";
  public static final String ATTR_TAX_A = "A";
  public static final String ATTR_TAX_B = "B";
  public static final String ATTR_TAX_C = "C";
  public static final String ATTR_TAX_D = "D";
  public static final String ATTR_TAX_E = "E";
  public static final String ATTR_TAX_F = "F";
  public static final String ATTR_EXTN_ORDER_DATE = "ExtnOrderDate";
  public static final String ATTR_EXTN_POS_SEQUEN_NO = "ExtnPosSequenceNo";
  public static final String ATTR_EXTN_TERMINAL_ID = "ExtnTerminalID";
  public static final String ATTR_EXTN_SELLER_ORG_CODE = "ExtnSellerOrganisationCode";
  public static final String ATTR_EXTN_SHIP_NODE = "ExtnShipNode";
  public static final String ATTR_EXTN_KCD = "ExtnKohlsCashDeactivated";
  public static final String ATTR_EXTN_CUST_LOYAL_CARD = "ExtnCustomerLoyalCard";
  public static final String ATTR_EXTN_EMAIL_ADDRESS = "ExtnEmailAddress";
  public static final String ATTR_EXTN_REASON_CODE = "ExtnReasonCode";
  public static final String ATTR_EXTN_KCD_COUPON_CODE = "ExtnKCDCouponCode";
  public static final String ATTR_EXTN_KCD_COUPON_EVENT_CODE = "ExtnKCDCouponEventCode";
  public static final String ATTR_EXTN_KCD_COUPON_NUMBER = "ExtnKCDCouponNumber";
  public static final String ATTR_EXTN_KCD_COUPON_RETURN_AMT = "ExtnKCDCouponReturnAmount";
  public static final String ATTR_EXTN_PSA_RESULT_CODE = "ExtnPSAResultCode";
  public static final String ATTR_EXTN_KCD_RETURN_TENDER_AMT = "ExtnKCDReturnTenderAmt";
  public static final String ATTR_EXTN_DRIVERS_LICENSE = "ExtnDriversLicense";
  public static final String TEMP_GET_ORDER_INVOICE_OUT_PSA =
      "<InvoiceDetail><InvoiceHeader><Order><OverallTotals/></Order></InvoiceHeader></InvoiceDetail>";
  public static final String TEMP_GET_ORDER_DETAILS_OUT_PSA =
      "<Order TransactionNo=''><Extn/><PersonInfoBillTo><Extn/></PersonInfoBillTo></Order>";
  // Added for PSA DC - End

  // Added for POC Returns: OMPReturnOrderAssociationUE : START
  public static final String A_DERIVED_FROM_ORDER_LINE_KEY = "DerivedFromOrderLineKey";
  public static final String E_ASSOCIABLE_ORD_LINES = "AssociableOrderLines";
  public static final String IS_RS_ACTIVE = "IS_RS_ACTIVE";
  public static final String EXTN_IS_RS_ACTIVE = "ExtnIsRSActive";
  // Added for POC Returns: OMPReturnOrderAssociationUE : END

  // POC returns

  public static final String SHP_NODE_PER_INFO = "ShipNodePersonInfo";
  public static final String RET_DOC_TYPE = "0003";
  public static final String MES_TYPE = "MessageType";
  public static final String RETURN = "Return";
  public static final String CUST_ATTRIBUTES = "CustomAttributes";
  public static final String TEXT1 = "Text1";
  public static final String TEXT2 = "Text2";
  public static final String TEXT3 = "Text3";
  public static final String EXTN_SO_STORE = "ExtnSalesOrderStore";
  public static final String EXTN_SO_TERMINAL_NO = "ExtnSalesOrderTerminalNo";
  public static final String EXTN_SO_NO = "ExtnSalesOrderNo";
  public static final String TEXT4 = "Text4";
  public static final String TEXT5 = "Text5";
  public static final String TEXT6 = "Text6";

  // Added for Even Exchange #3888 - Begin
  public static final String TEMP_GET_ORDER_LIST_FOR_RET =
      "<OrderList><Order OrderHeaderKey=''><OrderLines><OrderLine OrderLineKey='' DerivedFromOrderHeaderKey='' DerivedFromOrderLineKey=''/></OrderLines></Order></OrderList>";
  public static final String TEMP_GET_ORDER_LIST_FOR_SALE =
      "<OrderList><Order OrderHeaderKey=''><OrderLines><OrderLine OrderLineKey='' PrimeLineNo='' SubLineNo=''/></OrderLines></Order></OrderList>";
  // Added for Even Exchange #3888 - End


  public static final String PLAN_REFUND_AMT = "PlannedRefundAmount";
  public static final String EXTN_POC_FEATURE = "ExtnPOCFeature";
  public static final String CHANGE_DUE = "ChangeDue";
  public static final String RECEIPTED_RET = "ReceiptedReturn";
  public static final String NON_RECEIPTED_RET = "NonReceiptedReturn";
  public static final String POP_FOR_POS = "processOrderPaymentsForPOS";

  public static final String TEXT7 = "Text7";
  public static final String TEXT8 = "Text8";
  public static final String TEXT9 = "Text9";
  public static final String TEXT10 = "Text10";
  public static final String DATE2 = "Date2";
  public static final String TENDER = "Tender";
  public static final String EXTN_SO_TRAN_NO = "ExtnSalesOrderTranNo";
  public static final String EXTN_SO_TRAN_DATE = "ExtnSalesOrderTranDate";
  public static final String EXTN_SO_LINE_NO = "ExtnSalesOrderLineNo";
  public static final String EXTN_AWARD_RECEIPT_DESC = "ExtnAwardRcptDesc";
  public static final String TLD_RECEIPT_DOLLAR_DESCRIPTION = "$ TRAN DISC";
  public static final String TLD_RECEIPT_PERCENT_DESCRIPTION = "% TRAN DISC";
  public static final String TLD_RECEIPT_SENIOR_DISCOUNT_DESCRIPTION = "SENIOR DISC";
  public static final String TLD_RECEIPT_LEGACY_COUPON_DESCRIPTION = "LEGACY";
  public static final String RETURN_RECEIPT_LINE_NUMBER_TYPE = "700";
  public static final String PROCESS_OFFLINE_TENDERING = "ProcessOfflineTendering";
  public static final String DL_REQUIRED = "DLRequired";

  // PR-149 - Start
  public static final String GET_ORDER_INVOICE_LIST_INP_CQ =
      "<OrderInvoice OrderHeaderKey='' ><ComplexQuery Operator='AND'><And><Or><Exp Name='InvoiceType' Value='CREDIT_MEMO' InvoiceTypeQryType='EQ'/><Exp Name='InvoiceType' Value='DEBIT_MEMO' InvoiceTypeQryType='EQ'/></Or></And></ComplexQuery></OrderInvoice>";
  public static final String GET_ORDER_INVOICE_LIST_OUT_TEMP =
      "<OrderInvoiceList TotalOrderInvoiceList='' TotalNumberOfRecords='' LastOrderInvoiceKey=''><OrderInvoice AmountCollected='' LineSubTotal='' TotalCharges='' TotalDiscount='' TotalAmount='' TotalTax='' OrderInvoiceKey='' OrderHeaderKey='' InvoiceType='' InvoiceNo='' /></OrderInvoiceList>";
  public static final String GET_ORDER_INVOICE_DETAIL_OUTPUT_TEMP =
      "<InvoiceDetail><InvoiceHeader><Order OrderHeaderKey=''><OverallTotals><OverallChargeTotals><OverallChargeTotal />"
          + "</OverallChargeTotals></OverallTotals></Order><CollectionDetails><CollectionDetail ><CreditCardTransactions><CreditCardTransaction /></CreditCardTransactions><PaymentMethod>"
          + "<PersonInfoBillTo /></PaymentMethod></CollectionDetail></CollectionDetails></InvoiceHeader></InvoiceDetail>";
  // PR-149 - End

  // Constant added for Fix for NullPointerException (JIRA: PST-40)
  public static final String SERVICE_UNAVAILABLE_500 = "500";

  // Changes for PR-124 - Start
  public static final String E_RETURN_KOHLS_CASH_IND = "ReturnKohlsCashInd";
  // Changes for PR-124 - End



  // PR-98 - Start
  public static final String STR_ADDITIONAL_PROMO_DESC = "Addt'l Savings";
  public static final String STR_BOGO_DISCOUNT_DESC = "BOGO Discount";
  // PR-98 - End



  // Changes for PR-274 - Start
  public static final String A_EXTN_ACTIVATION_BAR_CODE = "ExtnActivationBarCode";
  // Changes for PR-274 - End

  // CAPE-147

  public static final String RETURN_HEADER_KEY = "ReturnHeaderKey";
  public static final String REFUND_OPTIONS = "RefundOptions";
  public static final String KOHLS_CASH_UNEARNED = "KOHLS_CASH_UNEARNED";
  public static final String EXTN_COUPON_SOURCE_CODE = "ExtnCouponSourceCode";
  public static final String KC_BAL = "KohlsCashBalance";
  public static final String EXTN_REASON_CODE = "ExtnReasonCode";
  public static final String EXTN_OFFLINE_MODE = "ExtnOfflineMode";
  public static final String MAX_REFUND = "MaximizeRefund";
  public static final String UNEARNED_KC = "UnearnedKohlsCash";
  public static final String KC_REDUCTION = "KohlsCashReduction";
  public static final String REF_DEDUCTION = "RefundDeduction";
  public static final String REDEMPTION_PERIOD = "RedemptionPeriod";
  public static final String EARNED_AMT = "EarnedAmt";
  public static final String UNEARNED_VALUE = "UnearnedValue";
  public static final String DEACTIVATION_OPTIONS = "DeactivationOptions";
  public static final String AUTH_RES_CODE = "AuthResponseCode";
  public static final String EXTN_KC_OPT_SELECTED = "ExtnKCOptionSelected";

  // Added for CAPE-1568 - begin
  public static final String OPERATION = "Operation";
  public static final String OPERATION_UPDATE_SESSION = "updateSession";
  public static final String A_ORDER_DETAILS_INCLUDED = "OrderDetailsIncluded";
  public static final String API_MANAGE_PSI_ORDER_FOR_POS = "managePSIOrderForPOS";
  // Added for CAPE-1568 - end

  public static final String GET_ITEM_LIST_FOR_ALTERNATE_SKUS = "global/template/api/POC/returns/POC_getItemListForAlternateSku.xml";

  // add constant for item validation
  public static final String GET_ITEM_LIST_FOR_ITEM_VALIDATION =
      "global/template/api/POC/returns/POC_getItemListForItemValidation.xml";
  public static final String GET_ITEM_LIST_FOR_ITEM_VALIDATION_DAMAGE_RETICKET =
	      "global/template/api/POC/returns/POC_getItemListForItemValidationDamageReticket.xml";
  public static final String GET_ORDER_LIST_FOR_ITEM_MATCHING_TEMPLATE =
      "global/template/api/POC/returns/POC_getOrderListForItemMatching.xml";

  public static final String KOHLS_CASH_REISSUE = "KOHLS_CASH_REISSUE";
  // Added for CAPE 1615 - Begin
  public static final String EXTN_ELIGIBILITY_DEUCTION = "ExtnEligibilityDeduction";
  public static final String EXTN_KC_UNEARNED_VALUE = "ExtnKCUnearnedValue";
  public static final String EXTN_REFUND_DEDUCTION = "ExtnRefundDeduction";
  public static final String EXTN_TRAN_UNEARNED_VALUE = "ExtnTranUnearnedValue";
  // Added for CAPE 1615 - End
  // Added for CAPE 1279
  public static final String VAL_KOHLS_SPL_ITEMS_RET = "KOHLS_SPL_ITEMS_RET";
  // CAPE 973 OMS part begin
  public static final String REWARDS_ID = "RewardsID";
  // CAPE 973 OMS part end

  // Added for CAPE-1300 - begin
  public static final String EXTN_ERECEIPT_EMAIL_ID = "ExtnEReceiptEmailID";
  public static final String ATTR_COUPON_NUMBER = "CouponNumber";
  public static final String ATTR_COUPON_AMOUNT = "CouponAmount";
  public static final String ATTR_COUPON_EVENT_ID = "CouponEventID";
  public static final String ATTR_EMAIL_ADDRESS = "EmailAddress";
  public static final String ATTR_QUALIFYING_AMOUNT = "QualifyingAmount";
  public static final String ATTR_RECEIPT_ID = "ReceiptID";
  public static final String ATTR_SEQUENCE_NO = "SequenceNo";
  public static final String ATTR_IS_TRAINING = "isTraining";
  public static final String ATTR_EXTN_RECEIPT_ID = "ExtnReceiptID";
  public static final String GET_ORDER_DETAILS_TEMPLATE_RETURNS =
      "<Order OrderHeaderKey='' OperatorID='' TerminalID=''  "
          + "  OrderDate='' PosSequenceNo='' SellerOrganizationCode=''><PersonInfoBillTo><Extn/></PersonInfoBillTo>"
          + "<Extn ExtnSysApprovalNo='' ExtnSysResponseCde='' ExtnSysApprovalSrcCde='' ExtnSysApprovalTypeCde='' ExtnSysAuthTimeTaken =''  ExtnUniqueID='' ExtnTestCard='' ExtnExpired=''"
          + "    ExtnProcessResult='' ExtnMediaType=''"
          + "    ExtnDLNumberFormat='' ExtnExtendedResultCode='' ExtnIssueDate='' ExtnExpiryDate=''  ExtnIssueJurisdicationAbbr='' ExtnIssueJurisdicationCvt='' ExtnDeclineCode=''/>"
          + "<OrderLines><OrderLine OrderLineKey='' PrimeLineNo='' OrderedQty=''><Item ItemID=''/><CustomAttributes/><Extn ExtnSkuStatusCode=''  ExtnItemDept=''  ExtnNetPrice=''  ExtnReturnPrice=''  ExtnSellingPrice='' />"
          + "<LineTaxes>" + "<LineTax ChargeCategory='' ChargeName=''  Tax='' TaxPercentage=''/>"
          + "</LineTaxes>"
          + "<LinePriceInfo LineTotal='' UnitPrice='' /><LineOverallTotals LineTotalWithoutTax=''/></OrderLine></OrderLines>"
          + "<References><Reference Name='' Value=''/></References><OverallTotals GrandTotal='' GrandTax='' LineSubTotal='' /></Order>";
  public static final String A_OTR_RESPONSE_F0 = "000000F0";
  public static final String A_OTR_RESPONSE_F1 = "000000F1";
  public static final String A_OTR_RESPONSE_F8 = "000000F8";
  public static final String A_OTR_RESPONSE_F9 = "000000F9";
  public static final String A_OTR_RESPONSE_1F0 = "000001F0";

  public static final String CORPORATE_RESASON_CODE_1F0 = "Trans Not Found";
  public static final String CORPORATE_RESASON_CODE_F9 = "Offline to RS";
  public static final String CORPORATE_RESASON_CODE_09 = "Offline to IntelliCheck";


  // CAPE-64
  public static final String A_APPROVAL_NUMBER_SYS = "approvalNumber";
  public static final String KOHLS_SYS_REP_WS = "KohlsSysRepublicWS";
  public static final String KOHLS_NAME_SPACE_REMOVER = "KohlsReturnServiceNameSpaceRemover";
  public static final String REGISTER_ID = "RegisterID";
  public static final String TRANSACTION_ID = "TransactionID";
  public static final String A_RESPONSE_CODE = "responseCode";
  public static final String CHANGE_ORDER_TEMPLATE =
      "<Order OrderHeaderKey=''><PersonInfoBillTo><Extn/></PersonInfoBillTo><Extn/></Order>";
  public static final String A_DRIVERS_LICENSE = "DriversLicense";
  public static final String A_SYS_APPROVAL_SRC_CDE = "SysApprovalSrcCde";
  public static final String A_SYS_APPROVAL_TYPE_CDE = "SysApprovalTypeCde";
  public static final String A_SYS_AUTH_TIME = "ExtnSysAuthTimeTaken ";
  public static final String A_EXTN_SYS_APPROVAL_NO = "ExtnSysApprovalNo";
  public static final String A_EXTN_SYS_REPSONSE_CDE = "ExtnSysResponseCde";
  public static final String A_EXTN_DL_FOR_SYS = "ExtnDLForSys";
  public static final String A_EXTN_SYS_APPROVAL_SRC_CDE = "ExtnSysApprovalSrcCde";
  public static final String A_EXTN_SYS_APPROVAL_TYPE_CDE = "ExtnSysApprovalTypeCde";
  public static final String A_EXTN_SYS_AUTH_TIME = "ExtnSysAuthTimeTaken";
  public static final String CORPORATE_RESASON_CODE = "Corporate Refund from SysRepublic";
  public static final String EXTN_ORIGINAL_TENDER = "ExtnOriginalTender";
  public static final String X_KOHLS_CORRELATION_ID = "X-KOHLS-CorrelationID";
  // CAPE-2093
  // CAPE-78
  public static List<String> RS_BAD_DATA_CODE = Arrays.asList("000001F0", "000102", "000000F9",
      "000101", "000101F1", "200001F2", "700001F7", "700002F7");
  // CAPE-1978
  public static final String ATTR_PRICE_ADJUSTMENT = "PriceAdjustment";

  // Changes for MAD339 EE
  public static final String ENTRY_TYPE_STORE_EDGE = "STORE-EDGE";
  public static final String A_RETURN_ORDER_HEADER_KEY_FOR_EXCHANGE =
      "ReturnOrderHeaderKeyForExchange";
  public static final String E_CUSTOM_ATTRIBUTES = "CustomAttributes";
  public static final String A_TEXT2 = "Text2";

  // MAD 335 constants
  public static final String A_BILL_TO_KEY = "BillToKey";
  public static final String E_ORDER_AUDITS = "OrderAudits";
  public static final String E_ORDER_AUDIT = "OrderAudit";
  public static final String E_ORDER_AUDIT_DETAIL = "OrderAuditDetail";
  public static final String E_ATTRIBUTES = "Attributes";

  // MAD 342 constants
  public static final String E_OFFLINE_TRANSACTION_Q = "OfflineTransactionQ";
  public static final String A_IS_LOCAL = "IsLocal";
  public static final String A_OPERATION_ID = "OperationID";
  public static final String A_OPERATION_TS = "OperationTS";
  public static final String A_TRX_STATUS = "TrxStatus";
  public static final String A_UNIQUE_ID = "UniqueID";
  public static final String A_DATA_XML = "DATAXML";
  public static final String API_REPLAY_RECORD_ORDER_PAYMENT_FOR_POS =
      "replayRecordOrderPaymentForPOS";
  public static final String API_MANAGE_OFFLINE_TRANSACTION_Q_FOR_POS =
      "manageOfflineTransactionQForPOS";
  public static final String A_TOTAL_REFUNDED_AMOUNT = "TotalRefundedAmount";
  public static final String E_REPLAY_RECORD_ORDER_PAYMENT_FOR_POS =
      "ReplayRecordOrderPaymentForPOS";
  public static final String A_REPLAY = "Replay";
  public static final String A_UPDATE_TILL = "UpdateTill";
  public static final String A_SYNC_ID = "SyncID";
  public static final String A_ACCOUNT_TYPE = "AccountType";
  public static final String A_CATEGORY = "Category";
  public static final String A_INFO = "Info";
  public static final String API_GET_CURRENT_TILL_STATUS_FOR_POS = "getCurrentTillStatusForPOS";
  public static final String A_PAYMENT = "Payment";
  public static final String A_EXPECTED = "Expected";

  // MAD 337 constants
  public static final String A_MODIFYPROGID = "Modifyprogid";
  public static final String CONSTANT_LOAD_OFFLINE_TRANSACTION = "LOAD_OFFLINE_TRANSACTION";
  public static final String A_INVOICE_TYPE = "InvoiceType";
  public static final String CONSTANT_ORDER = "ORDER";
  public static final String TXN_POST_VOID_INVOICE_KEY = "POST_VOID_INVOICE_KEY";
  // MAD 336 constants
  public static final String A_ORDER_NAME = "OrderName";
  public static final String CONSTANT_RETURN_WITH_EXCHANGE = "ReturnWithExchange";
  public static final String EXCHANGEORDER_XPATH = "/OrderList/Order/ExchangeOrders/ExchangeOrder";
  public static final String GETORDERLISTFOREXCHANGE_TEMPLATE =
      "<OrderList><Order OrderNo=''><ExchangeOrders><ExchangeOrder OrderHeaderKey='' OrderNo='' /></ExchangeOrders></Order></OrderList>";

  
  // CAPE-78
  public static final String A_PA_HOLD_TYPE = "PAHold";
  public static final String A_PA_INITIATED = "PAInitiated";
  public static final String A_PA_COMPLETED = "Hold resolved when PA is complted";

  // Tender Lookup changes
  public static final String TENDER_TYPE_PRIV_LBL = "PRIV_LBL";
  public static final String PINPAD_PAYMENT_OPERATION = "PAYMENT";
  public static final String PINPAD_CREDIT_OPERATION = "CREDIT";
  public static final String PINPAD_TOKEN_QUERY_OPERATION = "TOKEN_QUERY";
  public static final String ENTRY_METHOD_KEYED = "KEYED";
  public static final String PAYMENT_CREDIT_CARD = "CREDIT_CARD";
  public static final String PAYMENT_CREDIT_LABEL = "CREDIT";
  public static final String TRAINING_MODE = "TRAINING_MODE";
  public static final String PAYMENT_DEBIT_CARD = "DEBIT_CARD";
  public static final String CANCELLED_BY_CUSTOMER = "Cancelled by CUSTOMER";
  public static final String CANCELLED_BY_POS = "Cancelled by POS";
  public static final String CARD_READ_ERROR = "Card Read Error";
  public static final String PINPAD_FAILURE = "FAILURE";

  // CAPE-109
  public static final String SEND_INVOICE_DETAIL_TO_TIBCO =
      "/global/template/api/POC/saleshub/KohlsPocPublishInvoiceDetailToTibco.xml";
  public static final String GET_ORDER_DETAILS_TEMPLATE_VOID =
      "<Order OrderHeaderKey='' OperatorID='' TerminalID='' PosSequenceNo='' SellerOrganizationCode=''>"
          + "<OrderLines><OrderLine OrderLineKey='' PrimeLineNo='' ><Item /><CustomAttributes/><Extn />"
          + "<LineTaxes>" + "<LineTax/>" + "</LineTaxes>" + "<LineCharges>" + "<LineCharge/>"
          + "</LineCharges>" + "<LinePriceInfo ListPrice=''  UnitPrice=''/>" + "<Awards>"
          + "<Award/>" + "</Awards>" + "<Promotions>" + "<Promotion/>" + "</Promotions>"
          + "</OrderLine></OrderLines>"
          + "<PaymentMethods><PaymentMethod PaymentKey='' PaymentReference6=''/></PaymentMethods>"
          + " <Extn /> </Order>";
  // CAPE-64


  // CAPE 2751

  public static final String GET_ORDER_LIST_RETURN =
      "<OrderList><Order  OrderHeaderKey='' ><OrderLines><OrderLine><CustomAttributes Text10=''/></OrderLIne></OrderLines></Order></OrderList>";

  public static final String DERIVED_FROM_EXTERNAL_ORDER = "DerivedFromExternalOrder";
  public static final String IS_RETURNED_ITEM = "IsReturnedItem";

  // CAPE -2751

  // MRR Data collect - begin
  // public static final String GET_ORDER_INVOICE_LIST_TEMPLATE = "<OrderInvoiceList><OrderInvoice
  // OrderHeaderKey='' OrderInvoiceKey=''/></OrderInvoiceList>";
  public static final String API_CREATE_ORDER_INVOICE = "createOrderInvoice";
  public static final String ELE_COLLECTION_DETAIL = "CollectionDetail";
  public static final String ELE_COLLECTION_DETAILS = "CollectionDetails";
  public static final String ATTR_CREDIT_CARD_NO = "CreditCardNo";
  public static final String ATTR_DEBIT_CARD_NO = "DebitCardNo";
  public static final String ATTR_AMOUNT_COLLECTED = "AmountCollected";
  public static final String API_REQUEST_COLLECTION = "requestCollection";
  public static final String VOID_INVOICE_TRAN_RETURN = "VOID_INVOICE.0003.ex";
  public static final String API_VOID_INVOICE = "voidInvoice";
  public static final String ATTR_IGNORE_STATUS_CHECK = "IgnoreStatusCheck";
  // MRR Data collect - end

  // CAPE-2110 - start
  public static final String TEMPLATE_GET_COMMON_CODE_LIST =
      "<CommonCodeList><CommonCode CodeName='' CodeValue=''/></CommonCodeList>";
  public static final String COMMON_CODE_TYPE_EComStores = "EComStores";
  // CAPE-2110 - End
  // CAPE - 2755
  public static final String EXTN_IS_LATEST = "ExtnIsLatest";
  public static final String IMPORT_ORDER_API = "importOrder";
  public static final String IS_LATEST_CALL_OVER = "IS_LATEST_CALL_OVER";
  // CAPE- 2755

  // CAPE-3052: ID Scan - start
  // API XML input constants
  public static final String INXML_DRIVER_LICENSE = "DriverLicense";
  public static final String INXML_LOCATION_ID = "LocationID";
  public static final String INXML_REGISTER_ID = "RegisterID";
  public static final String INXML_ASSOCIATE_ID = "AssociateID";
  public static final String INXML_STORE_ID = "StoreID";
  public static final String INXML_TRANSACTION_ID = "TransactionID";
  public static final String INXML_DATE_TIME = "DateTime";
  public static final String INXML_TRANSACTION_AMOUNT = "TransactionAmount";
  public static final String INXML_CUSTOMER_ID_SOURCE = "CustomerIDSource";
  public static final String INXML_RETURN_ITEM = "ReturnItem";
  public static final String INXML_ITEM_PRICE = "itemPrice";
  public static final String INXML_ITEM_SKU_UPC = "itemSkuUpc";
  public static final String INXML_ITEM_DEPT_NUM = "deptNumber";
  //CPE-10085 - send item sequence number in MASH request
  public static final String INXML_ITEM_LINE_SEQUENCE_NUM = "itemSequenceNumber";

  // API XML output constants
  public static final String OUTXML_DOCUMENT_NAME = "ReturnDLScanResponseData";
  public static final String OUTXML_PROCESS_RESULT = "processResult";
  public static final String OUTXML_EXTENDED_RESULT_CODE = "extendedResultCode";
  public static final String OUTXML_FIRST_NAME = "firstName";
  public static final String OUTXML_MIDDLE_NAME = "middleName";
  public static final String OUTXML_LAST_NAME = "lastName";
  public static final String OUTXML_ADDRESS1 = "address1";
  public static final String OUTXML_ADDRESS2 = "address2";
  public static final String OUTXML_CITY = "city";
  public static final String OUTXML_STATE = "state";
  public static final String OUTXML_POSTAL_CODE = "postalCode";
  public static final String OUTXML_DATE_OF_BIRTH = "dateOfBirth";
  public static final String OUTXML_MEDIA_TYPE = "mediaType";
  public static final String OUTXML_UNIQUEID = "uniqueId";
  public static final String OUTXML_TEST_CARD = "testCard";
  public static final String OUTXML_DL_ID_NUMBER_RAW = "dlidNumberRaw";
  public static final String OUTXML_DL_ID_NUMBER_FORMATTED = "dlidNumberFormatted";
  public static final String OUTXML_EXPIRATION_DATE = "expirationDate";
  public static final String OUTXML_EXPIRED = "expired";
  public static final String OUTXML_ISSUE_DATE = "issueDate";
  public static final String OUTXML_ISSUING_JURISDICTION_ABBR = "issuingJurisdictionAbbrv";
  public static final String OUTXML_ISSUING_JURISDICTION_CVT = "issuingJurisdictionCvt";
  public static final String OUTXML_APPROVAL_NUMBER = "approvalNumber";
  public static final String OUTXML_RESPONSE_CODE = "responseCode";
  public static final String SYS_REPUBLIC_OFFLINE_APPROVAL_NUM = "000001";
  public static final String SYS_REPUBLIC_FORCE_CORP_REFUND_RESPONSE_CODE = "Declined";

  // COP FILE ATTRIBUTES
  public static final String COP_FILE_DOMAIN_ATTRIBUTE = "RETURN_DLSCAN_DOMAIN";
  public static final String COP_FILE_ENDPOINT_CONTEXT_PATH_LESS_ATTRIBUTE =
      "RETURN_DLSCAN_ENDPOINT_CONTEXT_PATH_LESS";
  public static final String COP_FILE_TIMEOUT_ATTRIBUTE = "RETURN_DLSCAN_TIMEOUT";
  public static final String COP_FILE_API_KEY_ATTRIBUTE = "RETURN_DLSCAN_APIKEY";
  public static final String COP_FILE_API_SECRET_ATTRIBUTE = "RETURN_DLSCAN_API_SECRET";

  // HTTP RESPONSE CONSTANTS
  public static final String HTTP_200 = "200";
  public static final String HTTP_206 = "206";

  // JSON RESPONSE CONSTANTS
  public static final String PROCESS_RESULT_DOCUMENT_UNKNOWN = "DocumentUnknown";
  public static final String PROCESS_RESULT_DOCUMENT_PROCESS_OK = "DocumentProcessOK";
  public static final String PROCESS_RESULT_DOCUMENT_PARTIALLY_OK = "DocumentPartiallyOK";
  public static final String EXTENDED_RESULT_CODE_LAW_S = "laws";
  public static final String EXTENDED_RESULT_CODE_LAW_D = "lawd";
  public static final String EXTENDED_RESULT_CODE_LAW_P = "lawp";

  // HTTP HEADER CONSTANTS

  public static final String X_DEP_FROM_APP_VALUE = "POC";
  public static final String X_DEP_FROM_NODE_VALUE = "192.168.1.1";
  public static final String X_DEP_FROM_SYSTEM_CODE_VALUE = "OS";
  public static final String ACCEPT_STRING = "Accept";
  public static final String APPLICATION_JSON_STRING = "application/json";
  public static final String CONTENT_TYPE_STRING = "Content-Type";
  public static final String AUTHORIZATION_STRING = "Authorization";
  public static final String V_YES = "Yes";
  // CAPE-3052: ID Scan - end

  // CAPE-3197 - start
  public static final String ATTR_LINE_SUB_TOTAL = "LineSubTotal";
  // CAPE-3197 - end

  // CAPE - 3311 - Start
  public static final String PA_COMPLETED_DIRTY = "PA_COMPLETED_DIRTY";
  // CAPE - 3311 - End

  
  // Refractoring Start

  public static final String E_ERROR_LIST = "ErrorList";
  public static final String KOHLS_OTR_ORDER_LIST_FLOW = "KohlsPoCGetKohlsOTROrderList";
  public static final String E_KOHLS_OTR_ORDER = "KohlsOTROrder";
  public static final String E_KOHLS_OTR_ORDER_LINE = "KohlsOTROrderLine";
  public static final String A_TRAN_NO = "TranNo";
  public static final String A_IS_RETURNABLE = "IsReturnable";
  public static final String A_BAR_CODE_DATA_LOWER = "BarcodeData";
  public static final String A_SPL_SKU_TYPE = "SpecialSkuType";
  public static final String E_AND = "And";
  public static final String A_CURRENT_STORE_ID = "CurrentStoreID";
  public static final String A_OTR = "OTR";
  public static final String NUM_30 = "30";
  public static final String NUM_10 = "10";
  public static final String A_EXTN_ORG_TAX_AMT = "ExtnOrigTaxAmt";
  public static final String TEXT11 = "Text11";
  public static final String A_ELIGIBLE = "Eligible";
  public static final String KOHLS_ID_SCAN_ENABLED = "ID_SCAN_RETURN_ENABLE";


  // Defect - 864
  public static final String IS_KMC_DECLINED = "IsKMCDeclined";



  //CAPE - 4052 - Start 
  public static final String GET_SKU_INPUT = "GetSKUInput";
	public static final String SKU_LIST = "SKUList";
	public static final String SKU_ATTRIBUTES = "SKUAttributes";
	public static final String SKU_NUMBER = "SKUNumber";
	public static final String ADVANCE_FILTER = "AdvanceFilter";
	public static final String WANT_CHILDREN= "WantChildren";
	public static final String WANT_RLTNSHIP = "WantRelationship";
	public static final String GET_SKU_SERVICE_CALL="KohlsPoCGetSKUServiceCall";
	public static final String RETURN_DISPOSITION_CODE	="ReturnDispositionCode";
	//public static final String KC_MAXIMIZE = "KohlsCashMaximize";
//public static final String ATTR_PSA_KC_DATA = "PSAKCData";
//public static final String SER_KOHLS_MANAGE_SALE_FOR_PSA = "KohlsManageSaleForPSA";
  //CAPE - 4052 - End

    //Changes for Database Dumps
    public static final String KEY_DATA_PUMP_DIR = "DIRECTORY";
    public static final String KEY_TABLES_MASTER = "TABLES_MASTER";
    public static final String KEY_TABLES_CONFIG = "TABLES_CONFIG";
    public static final String KEY_EXPORT_FILE = "EXPORT_FILE";
    public static final String KEY_LOG_FILE = "LOGFILE";
    public static final String PROFILE_LIST = "PROFILE_LIST";
    public static final String SYNC_FULL = "FULL";
    public static final String SYNC_DELTA = "DELTA";
    public static final String IMPORT_CMD = "impdp";
    public static final String EXPORT_CMD = "expdp";
    public static final String REMOVE_CMD = "rm";
    public static final String MOVE_CMD = "mv";
    public static final String LIST_CMD = "ls";
    public static final String FILE_CMD ="-rf";
    public static final String COPY_CMD ="cp";
    public static final String CD_CMD ="cd";
    public static final String ZIP ="zip";
    public static final String UNZIP ="unzip";
    public static final String KEY_TAG = "ISS_DATADUMP";
    public static final String TABLE_TYPE_MASTER= "MASTER";
    public static final String TABLE_TYPE_CONFIG= "CONFIG";
    public static final String TABLE_TYPE_MASTER_CONFIG= "MASTER_CONFIG";
    public static final String A_EXPORTED_MASTER_CONFIG_FROM_DIFFERENT_POOLS = "ExportedMasterAndConfigFromDifferentPool";
    public static final String A_EXPORTED_MASTER_CONFIG_FROM_SAME_POOL = "ExportedMasterAndConfigFromSamePool";
    public static final String A_EXPORTED_MASTER_ONLY = "ExportedMasterOnly";
    public static final String A_EXPORTED_CONFIG_ONLY = "ExportedConfigOnly";
    public static final String API_GET_SYNC_PROFILE_LIST= "getSyncProfileList";
    public static final String API_GET_SYNC_PROFILE_LIST_TEMPLATE_PATH = "global/template/api/getSyncProfileList_output.xml";
    public static final String E_SYNC_PROFILE = "SyncProfile";
    public static final String A_SYNC_PROFILE_ID = "SyncProfileID";
    public static final String A_TABLE_GROUP = "TableGroup";
    public static final String A_EXPORT = "Export";
    public static final String A_IMPORT = "Import";
    public static final String E_SYNC_SUBSCRIPTION = "SyncSubscription";
    public static final String API_GET_SYNC_SUBSCRIPTION_LIST_TEMPLATE_PATH = "global/template/api/getSyncSubscriptionList_output.xml";
    public static final String API_GET_SYNC_SUBSCRIPTION_LIST = "getSyncSubscriptionList";
    public static final String A_SYNC_SUBSCRIPTION_KEY = "SyncSubscriptionKey";
    public static final String A_SYNC_STORE = "SyncStore";
    public static final String A_DEFAULT_ACTION = "DefaultAction";
    public static final String A_ACTION_ADD = "ADD";
    public static final String E_SYNC_TARGET = "SyncTarget";
    public static final String A_OPERATION = "Operation";
    public static final String A_SYNC_TARGET_ID = "SyncTargetID";
    public static final String MANAGE = "Manage";
    public static final String API_MANAGE_SYNC_TARGET = "manageSyncTarget";
    public static final String API_MANAGE_SYNC_TARGET_TEMPLATE_PATH = "global/template/api/manageSyncTarget_output.xml";
    public static final String E_COLONY_POOL = "ColonyPool";
    public static final String TABLE_TYPE = "TableType";
    public static final String E_PROFILE = "Profile";
    public static final String E_SYNC_DB_IMPORT = "SyncDBImport";
    public static final String A_DB_IMPORT_TIME = "DBImportTime";
    public static final String A_PROFILE_ORG_CODE = "ProfileOrganizationCode";
    public static final String STORE_ID_PROP = "store.common.store.store.id";
    public static final String A_SYNC_TYPE = "SyncType";
    public static final String API_MANAGE_SYNC_DB_IMPORT = "manageSyncDBImport";
    public static final String A_YFC_ADDITIONAL_INFO = "yfcAdditionalInfo";
    public static final String A_ENDPOINT = "endpoint";
    public static final String V_MOTHERSHIP = "MOTHERSHIP";
    public static final String V_SYNC_VERSION = "SyncVersion";
    public static final String A_POOL_ID = "PoolId";
    public static final String A_CONFIGURATION= "CONFIGURATION";
    public static final String UNDERSCORE= "_";
    public static final String BACKWARD_SLASH= "/";
    public static final String API_GET_COLONY_POOL_LIST = "getColonyPoolList";
    public static final String E_SYNC_DB_EXPORT = "SyncDBExport";
    public static final String API_GET_SYNC_DB_EXPORT_LIST = "getSyncDBExportList";
    public static final String A_DATA_TYPE = "DataType";
    public static final String E_CACHED_GROUPS = "CachedGroups";
    public static final String E_CACHED_GROUP = "CachedGroup";
    public static final String A_CLEAR = "CLEAR";
    public static final String A_DATABASE = "Database";
    public static final String API_MODIFY_CACHE = "modifyCache";
    public static final String A_DBA_TASKS = "DBA_TASKS";
    public static final String A_SQL_TUNING = "DBA_TASKS_IMP";
    public static final String INSERT = "INSERT";
    public static final String UPDATE = "UPDATE";
    public static final String KOHLS_AGENT_PATH = "//kohls//prop//of//agentserver//runtime";
    public static final String KOHLS_FOUNDATION_PATH = "//kohls//prop//of//Foundation";
    public static final String KOHLS_CDT_SHELL_PATH = KOHLS_AGENT_PATH + "//bin//kohlscdtshellfordatasync.sh";
    public static final String YDK_PREFS_FILE_PATH = KOHLS_FOUNDATION_PATH + "//resources//ydkresources//ydkprefs.xml";
    public static final String BUILD_PROPERTIES_PATH = KOHLS_AGENT_PATH + "//properties//build.properties";
    public static final String SOURCE_DATABASES = "SourceDatabases";
    public static final String TARGET_DATABASES = "TargetDatabases";
    public static final String FOLDER = "folder";
    public static final String STORE_DATA_DMP_PATH = "//store//datapump";
    public static final String DB_DMP_INPGROGRESS_PATH = STORE_DATA_DMP_PATH + "//DBTask//InProgress";
    public static final String DB_DMP_DONE_PATH = STORE_DATA_DMP_PATH + "//DBTask//Done"; 
    public static final String DB_DMP_ARCHIVE_PATH = STORE_DATA_DMP_PATH + "//DBTask//Archive";
    public static final String EXPDAT_LOG = "expdat";
    public static final String EXPDAT_DMP = "expdat.dmp";
    public static final String DATASYNC_PROFLE_FULL = "DATASYNC_PROFLE_FULL";
    public static final String ISS_DATADUMP_IMPORT_DIR = "ISS_DATADUMP_IMPORT_DIRECTORY";
    public static final String P_POD_MIGRATION = "P_POD_MIGRATION";
    public static final String P_INITIAL_ISS_D = "P_INITIAL_ISS_D";
    public static final String TABLE_SPACE = "Tablespace";
    public static final String TABLESPACE_NAME = "TABLESPACE_NAME";
    public static final String A_NAMES = "Names";
    public static final String A_SINGLE_QUOTE = "'";
 
    //DELTA
    public static final String DELTA_INPROGRESS_PATH = STORE_DATA_DMP_PATH + "//Import//Delta//InProgress";   
    public static final String DELTA_DONE_PATH = STORE_DATA_DMP_PATH + "//Import//Delta//Done";
    public static final String DELTA_ERROR_PATH = STORE_DATA_DMP_PATH + "//Import//Delta//Error";
    public static final String DELTA_ARCHIVE_PATH = STORE_DATA_DMP_PATH + "//Import//Delta//Archive/";
    public static final String DB_DELTA_EXPORT = "DeltaExport";
    public static final String DB_DELTA_IMPORT = "DeltaImport";
    public static final String TABLE_NAME_PRIMARY_KEY_NAME_LIST = "TABLE_NAME_PRIMARY_KEY_NAME_LIST";
    public static final String DELTA_STORE_LIST = "Stores.txt";
    public static final String A_SYNC_TARGET_LIST = "SyncTargetList";
    public static final String A_SYNC_TARGET = "SyncTarget";
    public static final String A_SYNC_TARGETID = "SyncTargetID";
    public static final String A_GET_SYNC_TARGET_LIST = "getSyncTargetList";
    public static final String A_TOTAL_NUM_OF_RECORDS = "TotalNumberOfRecords";
    public static final String ONE_CHAR_SPACE = " "; 
    public static final String INPROGRESS_DIRECTORY = "INPROGRESS_DIRECTORY";
    public static final String DONE_DIRECTORY = "DONE_DIRECTORY";    
    public static final String KEY_DATA_PUMP_DONE = "DONEDIR";
    public static final String KEY_DATA_PUMP_ARCHIVE = "ARCHIVEDIR";
    public static final String UPDATE_SYNC_EXPORTED_DATE_FORMAT = "MM-dd-yyyy HH:mm:ss";
    public static final String EXPORT_TABLES_DATE_FORMAT = "yyyyMMddHHmmss";
    public static final String MANAGE_SYNC_DB_IMPORT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String READ_DUMP_FILES_DATE_FORMAT = "yyyyMMddHHmmss";
    public static final String MANAGE_SYNC_DB_UPDATE_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";	
    public static final String KOHLS_RETAIL = "KOHLS-RETAIL";
    public static final String ERROR_RETRY = "ErrorRetry";
    public static final String RETRY_COUNT = "RetryCount";
    public static final String CDT_XML_ZIP_FILE = "CDTXmls";	
    public static final String DMP_EXTENSION = "dmp";
    public static final String TXT = ".txt";
    public static final String CONFIG_IGNORE_LIST = "CONFIG_IGNORE_LIST";
    public static final String CONFIGURATION = "Configuration";
    public static final String FILENAME_SYNC_VERSION = "SyncVersion_";
    public static final String XML_EXTENSION = "xml";
    public static final String LOG_EXTENSION = "log";
    public static final String E_KOHLS_GET_DATA_EXPORT = "KohlsGetDataExport";
    public static final String ONE_DOT_ZERO = "1.0";
    public static final String ZERO_DOT_ZERO = "0.0";
    public static final String DOT_ZERO = ".0";		
    public static final String INSERT_UPDATE = "INSERT_UPDATE";
    public static final String DELETE_UPDATE = "DELETE_UPDATE";	
    public static final String ISS_DATADUMP_IMPORT_DIRECTORY = "ISS_DATADUMP_IMPORT_DIRECTORY";
    public static final String ISS_DATADUMP_DELTA_EXPORT_DIRECTORY = "ISS_DATADUMP_DELTA_EXPORT_DIRECTORY";
    public static final String ISS_DATADUMP_DELTA_EXPORT_DONEDIR = "ISS_DATADUMP_DELTA_EXPORT_DONEDIR";
    public static final String ISS_DATADUMP_DELTA_EXPORT_ARCHIVEDIR = "ISS_DATADUMP_DELTA_EXPORT_ARCHIVEDIR";
    public static final String ISS_DATADUMP_EXPORT_TABLES_MASTER = "ISS_DATADUMP_EXPORT_TABLES_MASTER";
    public static final String YFS_ENTITY_CHANGE = "YFS_ENTITY_CHANGE";
    public static final String DATASYNC_PROFILE = "DATASYNC_PROFILE";
    public static final String QUERY_PAR_FILE = "QUERY_PAR_FILE";
    public static final String KOHLS_DOT_COM = "KOHLS.COM";
    public static final String DEFAULT = "DEFAULT";
    public static final String P_CONFIGURATION_D = "P_CONFIGURATION_D";
    public static final String P_CONFIGURATION_KR = "P_CONFIGURATION_KR";
    public static final String P_CONFIGURATION_KC = "P_CONFIGURATION_KC";
    public static final String ZERO_INS_UPD_DMP = "ZERO_INS_UPD.dmp";
    public static final String ZERO_DEL_UPD_DMP = "ZERO_DEL_UPD.dmp";
    public static final String ZERO_CDT_ZIP = "ZERO_CDT.zip";
    public static final String ORACLE_PROCEDURE = "K_UTIL.K_UAPG_APP_GRAVITY_STERLING.K_UASP_POST_DPLY";
    public static final String JDBC_PROPERTIES_PATH = "JDBC_PROPERTIES_PATH";
    public static final String REGEX_PASSWORD = "/.*?@";
    public static final String REGEX_REPLACEMENT = "/*****";
    public static final String USER = "user";
    public static final String PASSWORD = "password";
    public static final String URL = "url";
    public static final String AT = "@";
    public static final String CDT_FILE = "CDT";
    public static final String P_USER_D = "P_USER_D";
    public static final String P_USER_KR = "P_USER_KR";
    public static final String CHANGE_DATA_MANAGEMENT_RULES = "changeDataManagementRules";
    public static final String E_RULES = "Rules";
    public static final String E_EXCLUDE_FROM_SYNC = "ExcludeFromSync";
    public static final String E_EXCLUDE_LIST = "ExcludeList";
    public static final String ORACLE_QUERY_DATE_FORMAT = "MM-DD-YYYY HH24:MI:SS";
    public static final String DB_SYNC_TYPE = "SYNC_TYPE";
    public static final String ISS_DATADUMP_DELTA_DB_UPDATE_ENABLE = "ISS_DATADUMP_DELTA_DB_UPDATE_ENABLE";
    public static final String ISS_DATADUMP_EXPORT_DONEDIR = "ISS_DATADUMP_EXPORT_DONEDIR";
    public static final String TIMESTAMP = "TIMESTAMP";
    public static final String CORP = "CORP";
    public static final String A_SYNC_PROCESS = "SyncProcess";
    public static final String KOHLS_POS_DATAPUMP_SYNC_PROCESS =  "KOHLS_POS_DATAPUMP_SYNC";
    public static final String TEMP_SYNC_VERSION = "SyncChanges.xml";
    public static final String DATA_PUMP_SYNC_PROCESS = "DataPumpSyncProcess";
    public static final String A_SYNC_SCHEMA_TYPE = "SyncSchemaType";
    public static final String API_GET_DATA_PUMP_SYNC_PROCESS_LIST = "GetDataPumpSyncProcessList";
    public static final String A_SYNC_LAST_TIMESTAMP = "SyncLastTimestamp";
    public static final String API_CREATE_DATA_PUMP_SYNC_PROCESS_LIST = "CreateDataPumpSyncProcess";
    public static final String API_MANAGE_DATA_PUMP_SYNC_PROCESS_LIST = "ManageDataPumpSyncProcess";
    public static final String YFS_SUB_FLOW = "YFS_SUB_FLOW";
    public static final String YFS_BASE_RULES = "YFS_BASE_RULES";
    public static final String YFS_NODE_TYPE = "YFS_NODE_TYPE";
    public static final String YFS_SHIPPING_PREFERENCE = "YFS_SHIPPING_PREFERENCE";
    public static final String YFS_ITEM_NODE_DEFN = "YFS_ITEM_NODE_DEFN";
    public static final String YFS_PERSON_INFO = "YFS_PERSON_INFO";
    public static final String YFS_ATP_RULES = "YFS_ATP_RULES";       
    public static final String A_SHIP_NODE_KEY = "ShipnodeKey";
    public static final String A_ERROR_TYPE= "ErrorType";
    public static final String A_ERR_DESC = "Description";
    public static final String A_DETAIL_DESC = "DetailDescription";
    public static final String A_ACT_FLAG = "ActiveFlag";
    public static final String A_CONSOLIDATE = "Consolidate";
    public static final String A_AUTO_RESOLVE_FLAG = "AutoResolvedFlag";
    public static final String A_KOHLS_DATAPUMP_SYNC = "KOHLS_DATAPUMP_SYNC";
    public static final String ERR_DESC_IMP =  "Delta Pump Sync Import Error" ;
    public static final String ERR_DESC_EXP =  "Delta Pump Sync Export Error" ;
    public static final String CREATE_EXP_API = "createException";
    public static final String NONREPROCESS = "NONREPROCESS";
    public static final String A_DATAPUMP_IMP_DELTA_FAILED = "DATAPUMP_IMPORT_DELTA_FAILED";
    public static final String A_DATAPUMP_EXP_DELTA_FAILED = "DATAPUMP_EXPORT_DELTA_FAILED";
    public static final String ALL_FILES = "ALL";
    public static final String API_GET_SYNC_DB_IMPORT = "getSyncDBImportList";
    
    //Deployment tasks Full And Delta
    public static final String QUERY_FILE = "/store/datapump/SQLLoad/EFrame_UpdateQueries.sql"; 
    public static final String INDEX_ALREADY_EXIST_CODE = "ORA-00955";
    public static final String COLUMN_LISTED_ALREADY = "ORA-01408";
    public static final String INDEX_DOES_NOT_EXIST = "ORA-01418";
    public static final String RESOURCE_BUSY = "ORA-00054";
    public static final String A_KOHLS_GET_JOB = "KohlsGetJob";
    public static final String A_SQL_LOAD = "SqlQuery";
    public static final String STORE_OPERATION_TASK = "StoreOperation";
    public static final String DOT_PAR = ".par";
    public static final String E_SYNC_PROCESS_KEY = "SyncProcessKey";
    public static final String A_ENTITY = "ENTITY";
    public static final String EDGE_INT_APP_USERID = "edge.integration.app.userid";
    public static final String EDGE_INT_APP_PASSWD = "edge.integration.app.password";
    public static final String YIF_HTTPAPI_USERID = "yif.httpapi.userid";
    public static final String YIF_HTTPAPI_PASSWD = "yif.httpapi.password";
    public static final String EDGE_SER_NOT_CONFIGURED = "Edge_Server_Endpoint_Not_Configured";
    public static final String EDGE_SERVER_ERROR_CODE = "OMP922_002";
    public static final String CLOSE = "CLOSE";
    public static final String STORES = "Stores";
    public static final String A_CURRENT_TILL = "CurrentTill";
    public static final String SUCCESS = "Success";
    public static final String A_ACC_PERIOD ="AccountingPeriod";
    public static final String A_OPEN_TIME = "OpenDateTime";
    public static final String GET_TILL_STAT_LIST_POS_TEMPLATE = "<TillStatusList TotalNumberOfRecords=''> <TillStatus OrganizationCode='' BusinessDay='' "
			+ "TerminalID='' DrawerID='' TillID='' /> </TillStatusList>";
    public static final String AUTO = "auto";
    public static final String ADMIN = "admin";
    public static final String MANUAL = "manual";
    public static final String A_OPEN_TYPE = "OpenType";
    public static final String A_CLOSE_TYPE = "CloseType";
    public static final String A_VOID_ORDER = "VoidOrder";
    public static final String E_TILL_STATUS_LIST = "TillStatusList";
    public static final String API_FORCE_CLOSE_TILL_FOR_ACC_POS = "forceCloseTillForAccountingForPOS";
    public static final String E_FORCE_CLOSE_TILl_ACC_POS = "ForceCloseTillForAccountingForPOS";
    public static final String E_STORE_CLOSE_ACC_POS = "StoreCloseForAccountingForPOS";
    public static final String API_STORE_CLOSE_ACC_POS = "storeCloseForAccountingForPOS";
    public static final String API_STORE_OPEN_ACC_POS = "storeOpenForAccountingForPOS";
    public static final String E_STORE_OPEN_ACC_POS = "StoreOpenForAccountingForPOS";
    public static final String A_TILL_STAT_KEY = "TillStatKey";
    public static final String A_TERMINAL_TYPE = "TerminalType";
    public static final String A_INDEX = "Index";
    public static final String TNS_NAMES_ORA = "/srv/prop/orasoft/oracle/network/admin/tnsnames.ora";		
    public static final String OMSR_CORP_HOST = "OMSRCORP.kohls.com";
    public static final String ACC_PERIOD_OUTPUT_TEMPL = "<AccountingPeriodList TotalNumberOfRecords=''> <AccountingPeriod BusinessDay=''/> </AccountingPeriodList>";
    public static final String API_GET_ACC_PERIOD_LIST_POS = "getAccountingPeriodListForPOS";    
    public static final String A_CURRENT_PERIOD = "CurrentPeriod";
    public static final String A_LAST_MSG_KEY = "LastMessageKey"; 
    public static final String A_ORDER_HDR_KEYS = "OrderHeaderKeys";
    public static final String A_ORDER_HEADER_KEY = "ORDER_HEADER_KEY";
    public static final String A_NUM_RECORDS_BUFFER = "NumRecordsToBuffer"; 
    public static final String A_RETENTION_DAY = "RetentionDays";
    public static final String A_START_KEY = "StartKey";
    public static final String A_END_KEY = "EndKey";
    public static final String DD_MM_YYYY = "dd-MM-yyyy";
    public static final String CODE_SHORT_DESC = "CodeShortDescription";
    public static final String CODE_LONG_DESC = "CodeLongDescription";
    public static final String CODE_VALUE = "CodeValue";
    public static final String AUTO_STORE_CLOSE_DATES = "ASC_DATES";
    public static final String AUTO_STORE_CLOSE_LOG = "/store/ASCDateCorrection/logs";
    public static final String SERVICE_MANAGE_STORE_SYNC_SUBS = "ManageStoreSyncSubscriptionService";
    public static final String API_MANAGE_SERVER_STATUS_POS = "manageServerStatusForPOS";
    public static final String SERVICE_MANAGE_FULL_SYNC_COMMCODES = "ManageFullSyncCommonCodes";
    public static final String API_GET_SERVER_STATUS_POS = "getServerStatusForPOS";
    public static final String E_ACC_PERIOD_LIST = "AccountingPeriodList";

    // PST-843
    public static final String A_DATE_INVOICED = "DateInvoiced";
    public static final String API_LOAD_OFFLINE_ORDER_FOR_POS = "loadOfflineOrderForPOS";
    public static final String API_GET_OFFLINE_TRANSACTION_QLIST_FOR_POS = "getOfflineTransactionQListForPOS";
    public static final String GET_OFFLINE_TRANSACTION_QLIST_TEMPLATE = "<OfflineTransactionQs><OfflineTransactionQ  OperationTS='' UniqueID='' /></OfflineTransactionQs>";
    public static final String OFFLINE_TRX_Q_XPATH = "/OfflineTransactionQs/OfflineTransactionQ";
    public static final String TRANSACTION_AUDIT_XPATH = "/InvoiceDetail/InvoiceHeader/TransactionAudits/TransactionAudit";
    public static final String UNIQUE_ID_MULTI_API = "multiApi";
    
    //PR-631 - Begin
    public static final String E_VNDDISPOCODES = "VndDispoCodes";
    public static final String E_VNDDISPOCODE = "VndDispoCode";
    public static final String A_CREATE = "Create";
    public static final String A_STYLEID = "StyleId";
    public static final String A_DEPTNBR = "DeptNbr";
    public static final String A_ENTID = "ENTId";
    public static final String A_SECTION = "Section";
    public static final String A_VENDORSTYLEDISPKEY = "VendorStyleDispKey";
    public static final String API_FLOWNAME = "FlowName";
    public static final String API_CREATEVNDDISPOCODE = "CreateVndDispoCode";
    public static final String API_CHANGEVNDDISPOCODE = "ChangeVndDispoCode";
    public static final String API_DELETEVNDDISPOCODE = "DeleteVndDispoCode";
    public static final String API_GETVNDDISPOCODELIST = "GetVndDispoCodeList";
    //PR-631 - End
	
    //PR-919, 767, 851 - Start
    public static final String GetOrderDetailsTemplateForPSAMidVoid = "<Order EnterpriseCode='' MaxOrderStatus='' OrderHeaderKey='' OrderNo='' SellerOrganizationCode='' "
    		+ "Override='' POCFeature='' POSSequenceNumber='' PosSequenceNo='' Status='' ><Extn ExtnPsaStatus='' ExtnRequestDateTime=''/><Promotions>"
    		+ "<Promotion Description='' PromotionApplied='' PromotionGroup='' PromotionId='' PromotionType=''><Extn ExtnIsPsaPromotion=''/>"
    		+ "</Promotion></Promotions></Order>";
    public static final String STORE_ORDER_INVOICED_STATUS = "1100.0005";
    public static final String EXTN_PSA_STARTED = "STARTED";
    public static final String EXTN_PSA_IN_PROGRESS = "IN_PROGRESS";
    public static final String EXTN_PSA_STATUS = "ExtnPsaStatus";
    public static final String A_OVERRIDE = "Override";
    public static final String A_EXTN_IS_VOID_DURING = "ExtnIsVoidDuring";
    //PR-919, 767, 851 - End
	//PR-943 changes start
	    public static final String KOHLS_PSADATA_ORDER = "/KOHLSSalesForPsa/PSAData/Order";
	    //PR-943 Changes end
	
	// MAD-101
    public static final String A_EXTN_SUSPEND_SEQ_NUM = "ExtnSuspendSeqNum";
    public static final String A_POS_SEQUENCE_NUMBER = "POSSequenceNumber";
	
    // MAD-378
    public static final String PSA_VOIDED_STATUS = "VOIDED";
    public static final String PSA_POSTVOIDED_STATUS = "POSTVOID";
    public static final String A_POST_VOIDED = "PostVoided";
	
	//PR-950 - Start
    	public static final String Text20Value = "Order was Picked and Failed in PSA Orphan Agent Clean Up";
	public static final String Text20 = "Text20";
	public static final String A_Select_Method = "SelectMethod";
	public static final String E_Inbox = "Inbox";
	public static final String A_Queue_Id = "QueueId";
	public static final String KohlsPoCPSAOrphanAgentCustomAlertQueue = "KohlsPoCPSAOrphanAgentCustomAlertQueue";
	public static final String InboxType = "InboxType";
	public static final String PSAOrphanOrderCleanUpAgent = "PSAOrphanOrderCleanUpAgent";
	public static final String ExceptionType = "ExceptionType";
	public static final String PSAAgentMVException = "PSAAgentMVException";
	public static final String ErrorType = "ErrorType";
	public static final String ErrorReason = "ErrorReason";
	public static final String ErrorReason_Text = "Check the Application Server Logs for more Details";
	public static final String EnterpriseKey = "EnterpriseKey";
	public static final String DetailDescription = "DetailDescription";
	public static final String E_InboxReferencesList = "InboxReferencesList";
	public static final String E_InboxReferences = "InboxReferences";
	public static final String ReferenceType = "ReferenceType";
	public static final String TEXT = "TEXT";
	public static final String ErrorMessage = "ErrorMessage";
	public static final String ACTION_TEXT = "Technical Intervention Required";
	public static final String ExceptionTime = "ExceptionTime";
	public static final String ATTR_Text20_Message = "Text20_Message";
	public static final String ATTR_Text20_Message_Text = null;
	public static final String GetOrderListTemplateForPSAMidVoid = "<OrderList><Order EnterpriseCode='' MaxOrderStatus='' OrderHeaderKey='' OrderNo='' SellerOrganizationCode='' TerminalID='' "
    		+ "Override='' POCFeature='' POSSequenceNumber='' PosSequenceNo='' Status='' TransactionNo='' ><Extn ExtnPsaStatus='' ExtnRequestDateTime=''/><Promotions>"
    		+ "<Promotion Description='' PromotionApplied='' PromotionGroup='' PromotionId='' PromotionType=''><Extn ExtnIsPsaPromotion=''/>"
    		+ "</Promotion></Promotions><CustomAttributes Text20='' /></Order></OrderList>";
	public static final String STORE_ORDER_INVOICED = "Store Order Invoiced";
	public static final String Text20ValueInvalidOrder = "Invalid Order Status To do PSA MidVoid";
    	//PR-950 - End
	//MAD-626 Start
	public static final String GET_ORDER_DETAILS_TEMPLATE = "<Order OrderHeaderKey='' SellerOrganizationCode='' OrderNo=''><CustomAttributes /></Order>";
	//MAD-626 end
	
	//MAD-572 Start
	public static final String CTX_ORG_CODE = "ContextOrganizationCode";
	//MAD-572 End
	public static final String LOCALE_CODE_CST = "en_US_CST";
	public static final String TIME_ZONE_CST = "America/Chicago";
	
	// MAD-341
    public static final String PSA_COMPLETED_STATUS = "COMPLETED";
    public static final String TXN_CORP_ORDER_HEADER_KEY = "CorpOrderHeaderKey";
    public static final String TXN_CORP_LINE_KEY_MAP = "CorpLineKeyMap";
    public static final String XPATH_DELTATAX = "DeltaTax";
    public static final String XPATH_DELTALINETAX = "DeltaTax/LineTaxes";
    public static final String TXN_DELTATAX = "DeltaTax";
    public static final String GET_CORP_ORDER_LIST_TEMPLATE = "<OrderList><Order OrderNo='' OrderHeaderKey='' TransactionNo=''><OrderLines><OrderLine OrderLineKey='' PrimeLineNo=''/></OrderLines></Order></OrderList>";
    public static final String GET_ORDER_LIST_STARTED_TEMPLATE = "<OrderList><Order OrderNo='' DocumentType='' EnterpriseCode='' BusinessDay='' DisplayLocalizedFieldInLocale='' IgnoreOrdering='' OperatorID='' OrderHeaderKey=''  SellerOrganizationCode='' POSSequenceNumber='' PosSequenceNo='' TerminalID='' TillID='' TransactionNo=''><Extn ExtnAuthorizedAwards='' ExtnCosaDay='' ExtnCosaMonth='' ExtnCosaTrasCode='' ExtnCosaWeek='' ExtnCosaYear='' ExtnCustNotificationSent='' ExtnPSAResultCode='' ExtnDeductibleOffers='' ExtnEligibilityDeduction='' ExtnGiftReceiptCount='' ExtnHdrGiftReceiptID='' ExtnIsCancelled='' ExtnIsVoidDuring=''  ExtnKCECouponAlgorithm='' ExtnKCECouponAmount='' ExtnKCECouponBalance='' ExtnKCECouponEventID='' ExtnKCECouponNo='' ExtnKioskID='' ExtnPsaStatus='' ExtnKohlsCashDeactivated='' ExtnKohlsCashRefundAmount=''  ExtnKohlsCashUpdateATGTimeStamp='' ExtnOTRResponse='' ExtnOTRResponseType='' ExtnOrigPosSequenceNo='' ExtnReceiptID='' ExtnRedemptionPeriod='' ExtnRequestDateTime='' ExtnTaxDetails='' ExtnTaxExemptCustFlag='' ExtnTextNotificationInd='' ExtnTextPhone='' ExtnTotalSavings='' ExtnUnearnedValue=''/><CustomAttributes Text6=''/></Order></OrderList>";
    public static final String GET_ORDER_LIST_COMPLETED_TEMPLATE = "<OrderList><Order OrderDate='' DisplayLocalizedFieldInLocale='' OrderNo='' DocumentType='' EnterpriseCode='' SellerOrganizationCode='' TransactionNo='' IgnoreOrdering='' OrderHeaderKey=''><Extn ExtnPsaStatus='' ExtnRequestDateTime='' ExtnKCDCouponCode='' ExtnKCDCouponEventCode='' ExtnKCDCouponNumber='' ExtnKCDCouponReturnAmount='' ExtnKCDReturnTenderAmt='' ExtnKCECouponAlgorithm=''  ExtnKCECouponAmount='' ExtnKCECouponBalance=''  ExtnKCECouponEventID='' ExtnKCECouponNo=''  ExtnKioskID='' ExtnKohlsCashDeactivated=''/><CustomAttributes Text14=''/></Order></OrderList>";
    public static final String A_IS_FIRST_CHANGE_ORDER = "IsFirstChangeOrder";
    public static final String SEQ_PSA_REPLICATION_SEQ = "PSAReplicationSeq";
    public static final String E_KOHLS_PSA_OFFLINE_Q = "KOHLSPsaOfflineQ";
    public static final String A_PSA_STATUS = "PsaStatus";
    public static final String A_PSA_OPERATION_XML = "OperationXml";
    public static final String A_PSA_REPLICATION_SEQ = "PsaReplicationSeq";
    public static final String SRVC_CREATE_PSA_OFFLINE_Q = "KohlsCreatePsaOfflineQService";
    public static final String SRVC_GET_PSA_OFFLINE_Q_LIST = "KohlsGetPsaOfflineQListService";
    public static final String A_IS_PROCESSED = "IsProcessed";
    public static final String A_IS_EXTENDED_DB_API = "IsExtendedDbApi";
    public static final String API_CHANGE_PSA_OFFLINE_Q = "changeKOHLSPsaOfflineQ";
    public static final String API_MULTIAPI = "multiApi";
    public static final String SRVC_KOHLS_PSA_ORDER_SYNC_SERVICE = "KohlsPSAOrderSyncService";
    public static final String GET_ORDER_LIST_FOR_PSA_TEMPLATE = "/global/template/api/POC/PSASync/getOrderList_PSA.xml";
    public static final String A_PSA_OFFLINE_Q_KEY = "PsaOfflineQKey";
    public static final String PSA_PAYMENT_SYNC_FLOW= "KohlsPoCPSAPaymentSyncService";
    public static final String GET_ORDER_LIST_VOIDED_TEMPLATE = "<OrderList><Order OrderDate='' OrderNo='' DocumentType='' EnterpriseCode='' BusinessDay='' DisplayLocalizedFieldInLocale='' IgnoreOrdering='' OperatorID='' OrderHeaderKey=''  SellerOrganizationCode='' POSSequenceNumber='' PosSequenceNo='' TerminalID='' TillID='' TransactionNo=''><Extn  ExtnPsaStatus=''  ExtnRequestDateTime='' /><CustomAttributes Text12='' Text14=''/></Order></OrderList>";
    public static final String TXN_TRANSACTION_NO = "TransactionNo";
    public static final String A_SYNCHED = "Synched";
    public static final String TXN_NO_OF_DISCOUNT = "NoOfDiscount";
    public static final String XPATH_PROMOTION = "Promotions/Promotion";
    public static final String V_POSTVOID_P = "P";
    public static final String TXN_REQUEST_COLLECTION_CALLED = "IsRequestCollectionCalled";
    public static final String API_DELETE_PSA_OFFLINE_Q = "deleteKOHLSPsaOfflineQ";
    public static final String GET_ORDER_LIST_SYCHED_TEMPLATE = "<OrderList><Order OrderNo='' MaxOrderStatus='' TransactionNo=''><Extn ExtnPsaStatus=''/></Order></OrderList>";
    public static final String TXN_IS_CHANGEORDER_FOR_RECEIPT_SCAN = "IsChangeOrderForReceiptScan";
    public static final String ENDPOINT_LOCAL = "LOCAL";
    public static final String E_CHARGE_TRANSACTION_DETAILS = "ChargeTransactionDetails";
    public static final String E_UPDATE_SYNCHED_ORDER_STATUS = "UpdateSynchedOrderStatus";
    public static final String E_SYNCHED_ORDERS = "SynchedOrders";
    public static final String E_SYNCHED_ORDER = "SynchedOrder";
    public static final String API_UPDATE_SYNCHED_ORDER_STATUS = "updateSynchedOrderStatusForPOS";
    
    //PR-990 Begin
      public static final String A_TEXT4 = "Text4";
      public static final String EE_ORDERLINE = "EXCHANGE";
      public static final String EMP_DISC_CODE="ExtnEmpDiscCode";
      public static final String GetItemListAPITemplateForEE = "<ItemList><Item ItemID=''><Extn ExtnEmpDiscCode=''/></Item></ItemList>";
      public static final String XPATH_ITEMLIST_EXTN="/ItemList/Item/Extn";
    //PR-990 End
    //MAD-596 Changes start
    public static final String DEDUCTIBLE_OFFERS = "DeductibleOffers";
    public static final String A_KCA_EXTN_COUPON_AMT ="KCA_ExtnCouponAmount";
    public static final String A_KCA_EXTN_QUALIFYING_AMT ="KCA_ExtnQualifyingAmount";
    public static final String A_KCA_EXTN_ACTIVATION_BARCODE ="KCA_ExtnActivationBarCode";
    public static final String A_KCA_EXTN_COUPON_EVENTID ="KCA_ExtnCouponEventID";
    public static final String INITIAL_OFFER_AMT ="InitialOfferAmt";
    public static final String GOBAL_OFFER_ID = "GlobalOfferId";
    public static final String POST_SALE_IND = "PostSaleInd";
    public static final String GET_ORDER_LIST_ENDPOINT_TEMPLATE = "<OrderList><Order OrderNo=''><yfcAdditionalInfo Endpoint=''/></Order></OrderList>";
    //MAD-596 Changes end
	
	//Change for PST-928
    public static final String COLONY_ID = "ColonyId";
	
	    public static final String SELECT_METHOD = "SelectMethod";
	public static final String A_APPLIEDSUPCCODE = "appliedSupcCode";
	public static final String A_NOTAPPLIEDSUPCCODE = "notAppliedSupcCode";
	public static final String A_EXTNCOUPONNO = "ExtnCouponNo";
	public static final String A_EXTNOFFERCOUPONNO = "ExtnOfferCouponNo";
	
		//OmniBag - 2017 Changes - Start
		public static final String  RESV_EXTN_REQUEST_DATE= "/Order/Extn/@ExtnRequestDateTime";
		public static final String  RESV_EXTN_EXPIRATION_DATE= "ExtnExpirationDateTime";
		public static final String  KOHLS_RESERVE_INVENTORY= "KohlsReserveInventory";
		public static final String ELE_RESERVE_ADDHOURS="RESERVE_ADDHOURS";
    	public static final String ELE_DATE_FORMAT="dd/MM/yyyy HH:mm:ss";
		public static final String A_EXTN_IS_ATG_REQ = "ExtnIsATSRequired";
		public static final String A_IS_STORE_PICKUP = "IsStorePickup";
		public static final String A_ONLY_ATS_REQ = "OnlyATSRequired";
		public static final String A_REAL_TIME = "RealTime";
		public static final String A_PROMISE = "Promise";
		public static final String A_INVENTORY_ALERTS = "InventoryAlerts";
		public static final String A_INVENTORY_ALERT = "InventoryAlert";
		public static final String A_ONHAND_AVAILABLE_QTY = "OnhandAvailableQuantity";
		public static final String A_ON_CLEARANCE = "OnClearance";
		public static final String A_MONITOR_ITEM_AVAILABILITY_LIST = "MonitorItemAvailabilityList";
		public static final String A_MONITOR_ITEM_AVAILABILITY = "MonitorItemAvailability";
		public static final String A_GET_AVAILABILITY = "GetAvailability";
		public static final String GIV_LINEID = "GIV_LINEID";
		public static final String ELE_CATEGORY_LIST = "CategoryList";
		public static final String A_ALLOCATION_RULE_ID = "AllocationRuleID";
		public static final String A_SYSTEM = "SYSTEM";
		public static final String A_CHECK_INVENTORY = "CheckInventory";
		public static final String A_OPTIMIZATION_TYPE = "OptimizationType";
		public static final String A_OPTIMIZATION_TYPE_01 = "01";
		public static final String ELE_SUGGESTED_OPTION = "SuggestedOption";
		public static final String ELE_OPTION = "Option";
		public static final String A_HAS_ANY_UNAVAILABLEQTY = "HasAnyUnavailableQty";
		public static final String A_REQUIRED_QTY = "RequiredQty";
		public static final String NINE_DOUBLE = "99999999.00";
		public static final String ELE_ASSIGNMENTS = "Assignments";
		public static final String ELE_ASSIGNMENT = "Assignment";
		public static final String ELE_UNAVAILABLE_LINES = "UnavailableLines";
		public static final String ELE_UNAVAILABLE_LINE = "UnavailableLine";
		public static final String A_UNAVAILABLE_REASON = "UnavailableReason";
		public static final String NOT_ENOUGH_PRODUCT_CHOICES = "NOT_ENOUGH_PRODUCT_CHOICES";
		public static final String JEWELRY_DEPT = "JEWELRY_DEPT";
		public static final String A_EMPTY_ASSIGNMENT_REASON = "EmptyAssignmentReason";
		public static final String A_EXTERNAL_NODE = "ExternalNode";
		public static final String A_PROD_AVAIL_DATE = "ProductAvailDate";
		public static final String A_DELIVERY_DATE = "DeliveryDate";
		public static final String A_DISTANCE_FROM_SHIP_TO_ADDR = "DistanceFromShipToAddress";
		public static final String A_AVAIL_FROM_UNPLANNED_INV = "AvailableFromUnplannedInventory";
		public static final String A_ITEM_PRODUCT_CLASS = "ItemProductClass";
		public static final String OMNI_BIPAAS = "OMNI_BIPAAS";
		public static final String A_CATEGORY_PATH = "CategoryPath";
		public static final String GetItemListAPITemplateForGC = "<ItemList><Item ItemID=''><Extn ExtnDept=''/>" +
			"<CategoryList><Category CategoryID='' CategoryPath=''/></CategoryList></Item></ItemList>";
		public static final String GetItemListAPITemplateForOmni = "<ItemList><Item ItemID=''><PrimaryInformation IsHazmat=''/>" +
			"<Extn ExtnEmpDiscCode='' ExtnDept=''/></Item></ItemList>";
	public static final String STORED_VALUE = "StoredValue";
	public static final String GetOrganizationHierarchyAPITemplateForOmni="<Organization OrganizationCode=''><Node ShipNode=''>" +
			"<ShipNodePersonInfo AddressLine1='' City='' State='' Country='' ZipCode=''/></Node></Organization>";
		public static final String A_EXTN_BOGO_RETURN_TAX = "ExtnBOGOReturnTax";
		public static final String KOHLS_CASH_INQUIRY_RESULT = "KohlsCashInquiryResult";
		public static final String COUPON_INQUIRY_RESPONSE_MSG = "CouponInquiryResponseMsg";
		public static final String INVENTORY_SOURCE_SYSTEM = "InventorySourceSystem";
	public static final String A_OIC = "OIC";
	public static final String A_SIS = "SIS";
	public static final String A_IS_OIC_ENABLED = "IS_OIC_ENABLED";
	public static final String A_SHIPNODE_PERSONINFO_XPATH = "/OrganizationList/Organization/Node/ShipNodePersonInfo";
	public static final String ORDER_LINES_DELMETHOD_XPATH = "/Order/OrderLines/OrderLine[@DeliveryMethod='PICK']";
	public static final String GetOrganizationListAPITemplateForOmni="<OrganizationList><Organization OrganizationCode=''><Node ShipNode=''>" +
			"<ShipNodePersonInfo AddressLine1='' City='' State='' Country='' ZipCode=''/></Node></Organization></OrganizationList>";
	
	//OmniBag - 2017 Changes - End
	//CPE-3121 floating user changes
	public static final String TEMPLATE_MANAGE_EXISTING_TEAM = "<Team Operation='' "
			+ "EnterpriseAccessMode='02' ShipNodeAccessMode='01' TeamId='' OrganizationCode='' Description='' ParentTeamKey=''>"
			+ "<TeamEnterpriseList>"
			+ "<TeamEnterprise Operation='' EnterpriseOrgCode='KOHLS-RETAIL'/>"
			+ "<TeamEnterprise EnterpriseOrgCode='DEFAULT'/> "
			+ "<TeamEnterprise EnterpriseOrgCode='KOHLS.COM'/> "
			+ "</TeamEnterpriseList> </Team>";
	public static final String  TRANSACTION_NO_LENGTH = "22";
	//CPE-3766 changes
		public static final String ATTR_PSA_KC_DATA = "PSAKCData";
		public static final String SER_KOHLS_MANAGE_SALE_FOR_PSA = "KohlsManageSaleForPSA";
		public static final String REFUND_AMT = "RefundAmount";
		public static final String KC_UNEARNED = "KohlsCashUnearned";
		public static final String KC_MAXIMIZE = "KohlsCashMaximize";
		public static final String PROMO_APPLIED = "PromotionApplied";
		public static final String MAX_KC = "MaximizeKohlsCash";
	
	//Constants for CPE - 2281 - Start
	    public static final String ATTR_TRAN_REQUEST_TIME = "TranRequestTime";
	    public static final String ATTR_EXECUTION_DATE = "ExecutionDate";
	    public static final String STRING_STORE_EDGE = "STORE-EDGE";
	    public static final String LOCALE_CODE_PST = "en_US_PST";
	    public static final String ATTR_ORGANIZATION ="Organization";
	    public static final String ATTR_DATE_INVOICED="DateInvoiced";
	    public static final String ATTR_EXTN_EXPIRY_DATE="ExtnExpiryDate";
	    public static final String ATTR_EXTN_ISSUE_DATE="ExtnIssueDate";
	    public static final String ATTR_EXTN_DOB="ExtnDateOfBirth";
	    public static final String STRING_DELIMITER ="/@";
	    public static final String SERVICE_CONVERT_TO_LOCALE_TIME ="KohlsPoCConvertToStoreLocaleTime";
	    public static final String STRING_ORG_CODE_ELEMENT = "OrgCodeElement";
	    public static final String STRING_ORG_CODE_ATTR = "OrgCodeAttr";
	    
	    //Constants for CPE - 2281 - End
	    
	    // CPE-4844 
		public static final String 	DAMAGE_RETICKET					= "damageReticket";
		public static final String 	POC_MERCHANDISE_DESCRIPTION		= "POCMerchandiseDescription";
		
		// Constant for Damage Defective
		public static final String    MESSAGE_TYPE_DAMAGE_RETICKET     = "Reticket";
	        public static final String    MESSAGE_TYPE_DAMAGE_DEFECTIVE     = "DamageDefective";

	    //Constants for CPE - 4718 - start
	    public static final String ATTR_BOOLEAN_1="Boolean1";
	    //Constants for CPE - 4718 - End
		
	//Constants for IE-DCOL - Start
	public static final String GET_ADMIN_AUDIT_LIST_FOR_POS_FOR_SALE="<AdminAuditList><AdminAudit AdminAuditKey=\"\" BusinessDay=\"\" Createprogid=\"\" Createts=\"\" Createuserid=\"\" DateTime=\"\" Lockid=\"\" ManagerID=\"\" Modifyprogid=\"\" Modifyts=\"\" Modifyuserid=\"\" OperatorID=\"\" OrganizationCode=\"\" POSSequenceNumber=\"\" ProcedureID=\"\" TerminalID=\"\" TillID=\"\" TransactionNumber=\"\" isHistory=\"\"><AdditionalDataList><AdditionalData AdditionalDataKey=\"\" Name=\"\" ParentKey=\"\" ParentTable=\"\" Value=\"\"/></AdditionalDataList></AdminAudit></AdminAuditList>";	
	public static final String MESSAGE_TYPE_QC_REGISTRATION = "IERegistration";
	public static final String GET_ADMIN_AUDIT_FOR_QC_REGISTRATION_TEMPLATE ="<AdminAudit AdminAuditKey='' BusinessDay='' Createprogid='' Createts='' Createuserid='' DateTime='' Lockid='' ManagerID='' Modifyprogid='' Modifyts='' Modifyuserid='' OperatorID='' OrganizationCode='' POSSequenceNumber='' ProcedureID='' TerminalID='' TillID='' TransactionNumber='' isHistory=''><AdditionalDataList><AdditionalData AdditionalDataKey='' Name='' ParentKey='' ParentTable='' Value=''/></AdditionalDataList></AdminAudit>";
	//Constants for IE-DCOL - Start	
	public static final String A_EXTN_DISCOUNT_REASON_CODE="ExtnDiscountReasonCode";
		public static final String A_EXTN_DISCOUNT_TYPE_CODE ="ExtnDiscountTypeCode";  
		public static final String V_EXTN_DISCOUNT_REASON_CODE_VALUE_760="760";
		public static final String V_EXTN_DISCOUNT_TYPE_CODE_VALUE_760 ="Q"; 
		public static final String V_EXTN_DISCOUNT_REASON_CODE_VALUE_761="761";
		public static final String V_EXTN_DISCOUNT_TYPE_CODE_VALUE_761 ="I"; 
	
	//ISS Rollout Automation - Start
        public static final String INACTIVE_CAPS = "INACTIVE";
	public static final String API_MANAGE_COMMON_CODE = "manageCommonCode";
	public static final String COMMON_CODE_TYPE = "CommonCodeType";
	public static final String ALL_OTHERS = "ALL_OTHERS";
	public static final String E_PROFILE_LIST = "ProfileList";
	
	public static final String A_PERFORM_VALIDATION = "PerformValidation";
	public static final String A_GRANT_PERMISSION = "GrantPermission";
	public static final String A_GRANT_PERMISSION_VALIDATION = "GrantPermissionValidation";
	public static final String A_ITEM_LOOKUP = "ItemLookUp";
	public static final String A_ITEM_LOOKUP_VALIDATION = "ItemLookUpValidation";
	public static final String A_TRIGGER = "Trigger";
	public static final String A_TRIGGER_AND_VALIDATE = "TriggerNValidate";
	public static final String A_VALIDATE = "Validate";
	
	public static final String SYNC_EXPORT_LEVELS = "SyncExportLevels";
	public static final String DB_EXPORT_TIME = "DBExportTime";
	public static final String A_TASK = "Task";
	
	public static final String API_MANAGE_RULE_FOR_POS = "manageRuleForPOS";
	public static final String A_AUTO_STORE_CLOSE_TIME = "AUTO_STORE_CLOSE_TIME";
	public static final String A_ASC_TIME = "ASCTime";
	public static final String A_SYNC = "SYNC";
	public static final String A_OUT_OF_SYNC = "OUTOFSYNC";
	public static final String DONE_DIR_PATH = "/Import/done/";
	//ISS Rollout Automation - End
	
	//CPE-6104  START
	public static final String ELE_ADDITIONAL_DATA_LIST = "AdditionalDataList";
	public static final String ELE_ADDITIONAL_DATA = "AdditionalData";
	public static final String ATTR_STORE_TIME_ZONE_FOR_EJ = "StoreTimeZoneForEJ";
	public static final String ATTR_ORDER_DATA = "OrderData";
	public static final String ATTR_LOCALE = "Locale";
	public static final String API_MANAGE_ADMIN_AUDIT_FOR_POS = "manageAdminAuditForPOS";
	public static final String API_MANAGE_TRANSACTION_AUDIT_FOR_POS = "manageTransactionAuditForPOS";
	public static final String API_MANAGE_ACCOUNT_FOR_POS="manageAccountForPOS";
	public static final String API_GET_RECEIPT_DATA_LIST_FOR_POS="getReceiptDataListForPOS";
	public static final String API_MANAGE_RECEIPT_DATA_FOR_POS="manageReceiptDataForPOS";
	public static final String API_GET_ADMIN_AUDIT_LIST_FOR_POS="getAdminAuditListForPOS";
	public static final String ELE_ORGANIZATION ="Organization";
	public static final String ATTR_TIME_ZONE="Timezone";
	public static final String API_GET_LOCALE_LIST="getLocaleList";
	public static final String ELE_RECEIPT_DATA ="ReceiptData";
	public static final String ATTR_EJ_LOCALE_CODE = "Localecode";

		//CPE-6104  END
	//PST-3116 start
	public static final String ITEM_LIST_TEMP = "<ItemList><Item><ItemAliasList><ItemAlias/></ItemAliasList></Item></ItemList>";
	//PST-3116 End
	
	//CPE-6420  START	
    public static final String  PARSING_ERROR = "Parsing error while processing the xml file";
    public static final String  VOID_ERROR = "Void response while executing the manageOfflineTransactionQForPOS API";
    public static final String  ZIP_NOTEXIST_ERROR_MSG = "Error :: Zip Folder does not exists on Corp";
	
    public static final String  OFFLINE_TRXQ_KEY = "OfflineTrxQKey";
    public static final String  OFFLINE_TRXQ = "OfflineTrxQKey";
    public static final String  PICK_TRX_STATUS = "1";
    public static final String  TO_TRX_STATUS ="2";
    public static final String  FILE_EXTENSION_TEXT = "txt";
    public static final String  FIRST_POS_OFF_TRX_KEY = "FirstOffLineTranQKey";
    public static final String  LAST_POS_OFF_TRX_KEY = "LastOffLineTranQKey";
    public static final String  KOHLS_POS_OFFLINE_LAST_RECORD = "KOHLSPosOfflineTrxRecord";
    public static final String  KOHLS_POS_OFFLINE_LAST_RECORD_ELE = "KOHLSPosOfflineTrxRecord";
    public static final String  POS_OFF_LAST_KEY = "POSOffTrxRecordKey";
    public static final String  NUM_RECORD_TO_BUFFER = "NumRecordsToBuffer";
    public static final String  NEED_OPERTION_XML = "NeedOperationXML";
    public static final String  TRX_STATUS_IN = "InputTrxStatus";
    public static final String  STOREID = "StoreId";
    public static final String  KOHLS_CREATE_OFFLINE_TRX_RECORD_SERVICE = "KOHLSCreateOfflineTransactionLastRecord";
    public static final String  KOHLS_CHANGE_OFFLINE_TRX_RECORD_SERVICE = "KOHLSChangeOfflineTransactionLastRecord";
    public static final String  KOHLS_GET_OFFLINE_TRX_RECORD_LIST_SERVICE = "KOHLSGetOfflineLastRecordList";
    
    public static final String  ZIP_DIR_CORP = "/store/OrderSyncFileImport/Done";
    public static final String  UNZIP_DIR_CORP = "/store/OrderSyncFileImport/InProgress";
    public static final String  ERROR_DIR_CORP = "/store/OrderSyncFileImport/Error";
    public static final String  ZIP_INPROGRESS_STORE = "/store/OrderSyncFileExport/InProgress";
    public static final String  ZIP_DIR_STORE = "/store/OrderSyncFileExport/Done";
    public static final String  ZIP_ERROR_STORE = "/store/OrderSyncFileExport/Error";
    public static final String  ERROR_DIR_STORE = "/store/OrderSyncFileUpload/Error";
    public static final String  A_STACK = "Stack";     
    //CPE-6420  END
	
	//PST-3294 - Start
	public static final String  PC_For_ZeroPricePrompt_Message = "PC not allowed for ZeroPricePrompt Item";
	public static final String  PC_For_ZeroPricePrompt_Error_Code = "PC_For_ZeroPricePrompt";
	public static final String  PC_For_ZeroPricePrompt_Error_Desc = "PriceCorrection is not valid for $0 "
			+ "PricePrompt Item. Please delete this item and add the item again with Non-Zero Amount";
	public static final String  PC_For_FreeItem__Message = "PC not allowed for FreeItem";
	public static final String  PC_For_FreeItem_Error_Code = "PC_For_FreeItem";
	public static final String  PC_For_FreeItem_Error_Desc = "PriceCorrection is not valid for $0 Free Item.";
	//PST-3294 - End
    //CPD-3938
    public static final String  FORCE_SWITCH_FLAG = "ForceSwitchingFlag";
    public static final String  SERVER_IP = "ServerIp";
    public static final String  STORE_COMMON_IP = "store.common.store.ip";
    public static final String  SERVER_STATUS = "ServerStatus";
    public static final String  A_EXTN_RETRY_COUNT = "ExtnRetryCount";
    public static final String  LESS_THAN = "LT";
    
    // PLYT-567
    public static final String EXTN_LOYALTY_NUMBER = "ExtnLoyaltyNumber";
    public static final String EXTN_EVERYDAY_EARN_KCC = "ExtnEverydayEarnKcc";
    public static final String EXTN_EVERYDAY_EARN_NON_KCC = "ExtnEverydayEarnNonKcc";
    public static final String EXTN_EARN_TRACKER_DELTA = "ExtnEarnTrackerDelta";
    public static final String EXTN_REDEMPTION_PERIOD = "ExtnRedemptionPeriod";
    public static final String EXTN_EARN_TRACKER_STATING_BALANCE = "ExtnEarnTrackerStartingBalance";
    public static final String EXTN_EVENT_COUPON_UNEANRD_AMT = "ExtnEventCouponUnearnedAmt";
    
  // PLYT-2140
  public static final String LOYALTY_STORE_TYPE_RULE = "LY_STORE_TYPE";
  public static final String LOYALTY_STORE_Y2Y = "Y2Y";
  public static final String LOYALTY_STORE_V1_PILOT = "V1PILOT";
  public static final String LOYALTY_STORE_V2_PILOT = "V2PILOT";
  public static final String LOYALTY_STORE_V2_NON_PILOT = "V2NONPILOT";

  //CPD-4125
  public static final String AUTO_STORE_CLOSE = "AutoStoreClose";
  public static final String IS_CORRECTED = "IsCorrected";
  public static final String CORRECTED_TO_DATE = "CorrectedToDate";
  public static final String CORRECTED_FROM_DATE = "CorrectedFromDate";
  public static final String COMMONCODE_DATE_RANGE = "FromCommonCodeDateRange";
  public static final String DOT_LOG = ".log";

  //CPE-7598 & 7599 starts    
    public static final String A_SCHEMA_NAME = "SchemaName";
    public static final String A_TRANSACTION = "TRANSACTION";
    public static final String DOC_DB_POOL = "DBPool";
    public static final String API_GET_DB_POOL_LIST = "getDBPoolList";
    public static final String E_PARAM_LIST = "ParamList";
    public static final String E_PARAM = "Param";
    public static final String A_SCHEMA = "schema";
    public static final String MIN_VAL = "MIN_VAL";
    public static final String MAX_VAL = "MAX_VAL";
    public static final String ENV_TYPE = "EnvType";
    public static final String RETENTION_DAYS = "RetentionDays";
    public static final String DB_MODIFYTS = "MODIFYTS";
    public static final String DB_TRXSTATUS = "TRX_STATUS";
    public static final String DB_EXTN_PURGE_ELIGIBLE = "EXTN_PURGE_ELIGIBLE";
    public static final String TOT_CNT_RECORDS = "TotalCountOfRecords";
    public static final String DB_TBL_POSOFFLINE = "POS_OFFLINE_TRX_Q";
    public static final String DB_OPERATIONID = "OPERATION_ID";
    public static final String DB_OFFLINE_TRX_Q_KEY = "OFFLINE_TRX_Q_KEY";   	
    //CPE-7598 & 7599 starts
   public static final String GET_ORDER_DETAILS_OUTPUT_TEMPLATE="<Order OrderHeaderKey='' DocumentType='' > <Promotions/></Order>";
  public static final String TRAN_DETAILS="TransDetails";
  public static final String ORDER_UNEARN_TEMPLATE =
	      "/global/template/api/POC/kohlscashunearning/POC_orderDetailsForUnearn.xml";
  
  //CPE-7310 - Offline Kohls Cash
  public static final String ELEM_KC_ACTIVATION_EVENT = "KCActivationEvent";
  public static final String ELEM_KC_ACTIVATION_EVENTS = "KCActivationEvents";
  public static final String ELEM_ACTIVATION_EVENT = "ActivationEvent";
  public static final String ATTR_KC_ACTIVATION_DATA = "activationData";
  public static final String ATTR_KC_STORE_ID = "StoreId";
  public static final String ATTR_KC_EVENT_ID = "KCEventId";
  public static final String ATTR_KC_ACTV_FILE_DATE = "KCActvFileDate";
  public static final String ATTR_KC_EVENT_START_DATE = "KCEventStartDate";
  public static final String ATTR_KC_EVENT_END_DATE = "KCEventEndDate";
  public static final String ATTR_KC_TENDER_TYPE_ALLOWED = "TenderTypeAllowed";
  public static final String ATTR_KC_QUALIFICATION_THRESHOLD = "QualificationThreshold";
  public static final String ATTR_KC_QUALIFICATION_TOLERANCE = "QualificationTolerance";
  public static final String ATTR_KC_VALUE = "KCValue";
  public static final String ATTR_KC_DEPT_EXCL_INCL_FLAG = "DeptExclInclFlag";
  public static final String ATTR_KC_DEPARTMENT_NUMBERS = "DepartmentNumbers";
  public static final String ATTR_KC_EVENT_NAME = "EventName";
  public static final String ATTR_KC_RCPT_MESSAGE_LINES = "RcptMessageLines";
  public static final String ATTR_KC_EVENT_KEY = "KCEventKey";
  public static final String API_SVC_CREATE_KOHLS_CASH_ACTIVATION = "CreateKohlsCashActivation";
  public static final String API_SVC_GET_KOHLS_CASH_ACTIVATION_LIST = "GetKohlsCashActivationList";
  public static final String API_SVC_DELETE_KOHLS_CASH_ACTIVATION = "DeleteKohlsCashActivation";
  
  //DM -347 - Disposition Manager - Phase 2 constants
  public static final String ELEM_KOHLS_DAMAGED_REASON_CODES_LIST = "KohlsDamagedReasonCodesList";
  public static final String ELEM_KOHLS_DAMAGED_REASON_CODES = "KohlsDamagedReasonCodes";
  public static final String ELEM_KOHLS_DAMAGED_CODE_DESCIPTION_LIST = "KohlsDamagedCodeDesciptionList";
  public static final String ELEM_KOHLS_DAMAGED_CODE_DESCIPTION ="KohlsDamagedCodeDesciption";
  public static final String ELEM_RULE_LIST="RuleList";
  public static final String ELEM_DM_SLIP_TEXT_REQ="DMSlipTextRequest";
  public static final String ELEM_DM_SLIP_TEXT="KohlsDispositionSlipText";
  public static final String ELEM_DM_SLIP_TEXT_LIST="KohlsDispositionSlipTextList";


  public static final String DOC_DM_REASON_CODE_REQ="DMReasonCodeRequest";
  public static final String ATTR_DM_SOURCE="Source";
  public static final String DM_REASON_CODE="DMReasonCode";
  public static final String DM_GET_DISPOSITION="DMGetDisposition";
  public static final String DM_GET_UI_SLIP_TEXT="DMGetUISlipText";

  public static final String ATTR_BUSINESS_GROUP_NO="BusinessGroupNo";
  public static final String ATTR_CODE_DESC="CodeDescription";
  public static final String ATTR_RESELLABLE="Resellable";
  public static final String ATTR_CONTAMINATED="Contaminated";
  public static final String ATTR_DEPTS="Departments";
  public static final String DM_ACTIVE_TOKEN="DM_ACTIVE_TOKEN";
  public static final String ATTR_STORE_NO="StoreNo";
  public static final String ATTR_DISPOSITION_CODE="DispositionCode";
  //DM-612 - START
  public static final String ONE = "1";
  public static final String ATTR_DISPOSITION_CODE_98="98";
  public static final String ATTR_DISPOSITION_CODE_97="97";
  public static final String ATTR_DISPOSITION_CODE_96="96";
  public static final String ATTR_DISPOSITION_CODE_95="95";
  public static final String ATTR_DISPOSITION_CODE_94="94";  
  // DM-612 - END
  public static final String ATTR_DISPOSITION_CODE_OFFLINE="99";
  public static final String ATTR_DISPOSITION_CODE_TRAINING="15";
  public static final String ATTR_BAR_CODE_TYPE="BarCodeType";
  public static final String ATTR_CODES="Codes";
  public static final String ATTR_POCUITEXT="PocUiText";
  public static final String ATTR_SLIP1="Slip1";
  public static final String ATTR_SLIP2="Slip2";
  public static final String ATTR_SLIP3="Slip3";
  public static final String ATTR_SLIP4="Slip4";

  
  //Service
  public static final String SERVICE_KOHLS_GET_DAMAGE_REASON_CODE_LIST ="KohlsGetDamageReasonCodeList";
  public static final String SERVICE_KOHLS_DELETE_DAMAGE_REASON_CODES ="KohlsDeleteDamageReasonCode";
  public static final String SERVICE_KOHLS_CREATE_DAMAGE_REASON_CODES ="KohlsCreateDamageReasonCode";
  
  public static final String SERVICE_KOHLS_GET_DM_SLIP_TEXT ="KohlsGetDMSlipTextList";
  public static final String SERVICE_KOHLS_DELETE_SLIP_TEXT ="KohlsDeleteDMSlipText";
  public static final String SERVICE_KOHLS_CREATE_DM_SLIP_TEXT ="KohlsCreateDMSlipText";

  public static final String HTTP_401 = "401";
  public static final String A_TRANS_ID="TRANS_ID";
  public static final String A_DMG_RES_CODE="DMG_RES_CODE";
  public static final String A_UI_SLIP_TEXT= "UI_SLIP_TEXT";
  
  public static final String POC_DEVICE_CODE= "POC";
  
  public static final String HTTP_METHOD_GET= "GET";
  public static final String ATTR_DEPT_CAPS="Departments";
  
  public static final String ACCESS_TOKEN = "access_token";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String SCOPE_VALUE = "read write";
	public static final String GRANT_TYPE = "grant_type";
	public static final String GRANT_TYPE_AUTHORIZATION_CODE = "authorization_code";
	public static final String GRANT_TYPE_CLIENT_CREDENTIALS = "client_credentials";
	public static final String SCOPE = "scope";
	public static final String BEARER = "Bearer";
	public static final String BASIC = "Basic";
	public static final String JSON_CONTENT = "application/json";
	public static final String XML_CONTENT = "application/xml";
	public static final String URL_ENCODED_CONTENT = "application/x-www-form-urlencoded";
	
	// PLYT-1213  CMDM Lookup Parameters
	  public static final String CUST_SEARCH_PREFIX = "";
	  public static final String CUST_SEARCH_NON_LOYALTY_PREFIX = "NON_LOYALTY_";
	  public static final String CUST_SEARCH_LOYALTY_RULE_ID = "CMDM_LOYALTY_SEARCH";

	  // Returns UNEARN
	  public static final String LOYALTY_KC_UNEARNED = "LOYALTY_KC_UNEARNED";
	  public static final String POST_SALE_ADJUSTMENT = "PostSaleAdjustment";
	
          //Kohls Misc Setup changes
          public static final String MASHUP_GET_OFFLINE_TXN_Q_LIST = "kohls-getOfflineTxnQList";
	  public static final String MASHUP_MANAGE_ASC_DATES = "common-manageASC_DATES";
          public static final String MASHUP_GET_ASC_DATES = "common-getASC_DATES";
	
	//Start - Added for MPOC CPE-8063.  
	public static final String E_ORDER = "Order";
	public static final String A_RETURN_OHK_FOR_EXCHANGE="ReturnOrderHeaderKeyForExchange";
	public static final String E_RETURN_ORDER_FOR_EXCHANGE="ReturnOrderForExchange";
	public static final String A_IS_DRAFT_ORDER = "IsDraftOrder";
	public static final String A_BYPASS_PRICING = "BypassPricing";
	public static final String E_CONFIRM_DRAFT_ORDER ="ConfirmDraftOrder";
	public static final String API_CONFIRM_DRAFT_ORDER="confirmDraftOrder";
	public static final String API_CREATE_ORDER="createOrder";
	public static final String E_RETURN_ORDER="ReturnOrder";
	public static final String E_SALESORDER="SalesOrder";
	public static final String E_RECEIPT_DATA="ReceiptData";
	public static final String A_ORDER_PURPOSE="OrderPurpose";
	public static final String EXCHANGE="EXCHANGE";
	public static final String A_EXCHANGE_TYPE="ExchangeType";
	public static final String ADVANCED="ADVANCED";
	public static final String STRING_CREATE_ORDER = "createOrder"; 
	public static final String A_ORDER_TYPE="OrderType";
	public static final String A_IS_EXCHANGE_ORDER="IsExchangeOrder";
	public static final String CREATE_PROCEDURE_ID="createOrder";
	public static final String EE_GRAND_TOTAL="0";
	public static final String A_APPEND_RECEIPT_DATA="AppendReceiptData";
	public static final String A_POS_ORIG_SALES_ORDER_NO="POSOriginalSalesOrderNo";
	public static final String A_DERIVED_FRM_ORDER_HDR_KEY="DerivedFromOrderHeaderKey";
	public static final String A_TOTAL_ORDER_LIST="TotalOrderList";
	//End - MPOC CPE-8063.
	 

  public static final String PROTEGRITY_SECURE  =  "Secure";
  public static final String PROTEGRITY_DESECURE  =  "Desecure";
  public static final String PROTEGRITY_TKN_KCASH = "TKN_KCASH";
  
  
 // Added for KohlsCallToLCSWrapper
  
  public static final String DM_DOMAIN = "DM_DOMAIN";
  public static final String DM_API_READTIMEOUT ="DM_API_READTIMEOUT";
  public static final String DM_API_CONNTIMEOUT ="DM_API_CONNTIMEOUT";
  public static final String DM_RETRY_THRESHOLD ="DM_RETRY_THRESHOLD";
  public static final String DM_PROXY_REQUIRED = "DM_PROXY_REQUIRED";
  public static final String DM_PROXY_HOST = "DM_PROXY_HOST";
  public static final String DM_PROXY_PORT = "DM_PROXY_PORT";

 
 public static final String CONTAMINATED_FLAG =  "ContaminatedFlag";
 public static final String DAMAGED_FLAG =  "DamagedFlag";
 public static final String DAMAGED_RESELLABLE_FLAG=  "DamagedResellableFlag";
 public static final String ITEM_STATUS_CODE =  "ItemStatusCode";
 public static final String ITEM_DEPT =  "ItemDept";
 public static final String ITEM_CLASS=  "ItemClass";
 public static final String ITEM_SUB_CLASS =  "ItemSubClass"; 
 public static final String VENDOR_RETURN_DISP_CODE =  "VendorReturnDispCode";
 public static final String CALL_BACK_TYPE_CODE=  "CallbackTypeCode";
 public static final String  CALL_BACK_ID=  "CallbackID";
 public static final String ITEM_STYLE =  "ItemStyle";
 
 public static final String CALL_BACK_ID_SIZE =  "CallbackIDSize";
 public static final String CALL_BACK_START_DATE =  "CallbackStartDate";
 public static final String CALL_BACK_END_DATE=  "CallbackEndDate";
 public static final String HAZ_MATERIAL_FLAG =  "HazMaterialFlag";
 public static final String  MARK_DOWN_PERCENTAGE=  "MarkdownPercentage";
 public static final String  VENDOR_RTV_THRESHOLD_REACHED =  "VendorRTVThresholdReached"; 
 public static final String WEB_EXCLUSIVE_FLAG =  "WebExclusiveFlag";
 public static final String WEB_EXCLUSIVE_DISP_CODE=  "WebExclusiveDispCode";
 public static final String  WEB_EXCLUSIVE_DISP_DESC=  "WebExclusiveDispDesc";
 public static final String DAMAGE_REASON_DESC =  "DamageReasonDesc";
 public static final String AUDIT_ID ="AuditID";
 
 public static final String ATTR_MODULE =  "Module";
 public static final String ATTR_TOKEN_NAME=  "TokenName";
 
 public static final String KOHLS_GET_O_AUTH_TOKEN_LIST ="KohlsGetoAuthTokenList";
 public static final String O_AUTH_ACCESS_TOKEN = "OAUTH_ACCESS_TOKEN";
 public static final String KOHLS_O_AUTH_ACCESS_TOKEN = "KohlsoAuthAccessToken";
 public static final String O_AUTH_ACCESS_TOKEN_KEY = "OAuthAccessTokenKey";
  
 public static final String GET_DISPOSITION_RESP ="GetDispositionResp";
 public static final String IS_OFFLINE ="IsOffline";
 public static final String ATTR_DISPOSITION_TEXT = "DispositionText";
 public static final String VENDOR_RETURN_DISPOSITION_CODE = "VendorReturnDispositionCode";
 public static final String EXPIRY_DATE = "ExpiryDate";   

 public static final String TOKEN_VALUE = "TokenValue";
 public static final String KOHLS_CREATE_O_AUTH_TOKEN = "KohlsCreateoAuthToken";
 public static final String KOHLS_MODIFY_O_AUTH_TOKEN = "KohlsModifyoAuthToken";
 
 public static final String  DM_ENDPOINT_OAUTH ="DM_ENDPOINT_OAUTH";
 public static final String  DM_APIKEY_OAUTH ="DM_APIKEY_OAUTH";
 public static final String DM_ENDPOINT_DISPOSITION = "DM_ENDPOINT_DISPOSITION";
 public static final String DM_ENDPOINT_DAMAGEREASON = "DM_ENDPOINT_DAMAGEREASON";
 public static final String DM_ENDPOINT_UISLIPTEXT = "DM_ENDPOINT_UISLIPTEXT";
 public static final String  DM_APISECRET_OAUTH = "DM_APISECRET_OAUTH";
 public static final String EXPIRY_IN = "expires_in"; 
 
 //KohlsDMAsyncTableUpdatesAgent
 public static final String  ACTION_GROUP_FLOWNAME ="ActionGroupFlowName";
 public static final String  KOHLS_CALLTO_DMWRAPPER ="KohlsCallToDMWrapper";
 
 //Offline Purge start
 public static final String LAST_MESSAGE = "LastMessage"; 
 public static final String TRX_SUCCESS = "TRXSuccessStatus"; 
 public static final String TRX_OTHER_STATUS = "TRXOtherStatuses";
 public static final String DB_CREATETS = "CREATETS";
 public static final String A_PKPREFIX = "PkPrefix";
 public static final String GET_COLONY_LIST_API = "getColonyList";
 //Offline Purge start

 public static final String A_GIFT_REG_ID="GiftRegistryID";
 
 //DM-1100 - START
 public static final String A_CLASS_ATTR = "Class";
 public static final String A_ENV_NAME = "EnvName";
 public static final String A_API_NAME = "APIName";
 public static final String A_CACHED_OBJECT = "CachedObject";
 public static final String A_CLEAR_ATTR = "Clear";
 public static final String A_CLEAR_REASON_CODE = "com.yantra.shared.dbclasses.KL_Damaged_Reason_CodesDBCacheHome";
 public static final String A_CLEAR_REASON_DESC = "com.yantra.shared.dbclasses.KL_Damaged_Code_DescriptionDBCacheHome";
 public static final String A_CLEAR_DISPO_SLIP = "com.yantra.shared.dbclasses.KL_Disposition_Slip_TextDBCacheHome";
 
 
 //DM-1100 - END
	
 //CPE-8861 Kohls Offline Trx History Enhancement start
 public static final String API_GET_OFFLINE_TRANSACTION_Q_FOR_POS = "getOfflineTransactionQForPOS";
 public static final String API_GET_OFFLINE_TRANSACTION_Q_HISTORY_LIST = "KohlsPOSGetOfflineTrxQHistoryList";
 public static final String A_OPERATION_INPUT_XML = "OperationInputXML";
 public static final String E_OFFLINE_TRANSACTION_QS = "OfflineTransactionQs";
 public static final String A_REPLICATION_SEQ="ReplicationSeq";
 public static final String A_CHECK_BOX_HISTORY_SELECTED="CheckBoxHistorySelected"; 
 public static final String E_KOHLS_P0S_OFFLINE_TRXQ_HISTORY="KohlsPosOffflineTrxQHistory";
 //CPE-8861 Kohls Offline Trx History Enhancement start
 
 //Automation POS- Starts
 public static final String REQUEST_DATETIME_FORMAT = "MM/dd/yyyy HH:mm:ss";
 public static final String ATTR_BARCODE_VALUE = "BarcodeValue";
 public static final String ATTR_DELIVERY_METHOD = "DeliveryMethod";
 public static final String ELE_PRICE_INFO = "PriceInfo";
 public static final String ATTR_REQUESTED_AMOUNT = "RequestedAmount";
 public static final String DOC_CONFIRM_DRAFTORDER_INPUT = "ConfirmDraftOrder";
 public static final String ELE_CLASSIFICATION_CODES = "ClassificationCodes";
 public static final String ATTR_DEFAULT_PRODUCT_CLASS = "DefaultProductClass";
 public static final String ATTR_EXTN_CLASS = "ExtnClass";
 public static final String ATTR_EXTN_MERCHANDISE_TAXCODE = "ExtnMerchandiseTaxCode";
 public static final String ATTR_ORDER_AMOUNT = "OrderAmount";
 public static final String API_CREATE_ORDER_FOR_POS = "createOrderForPOS";
 public static final String API_VOID_TRAN_FOR_POS = "voidTransactionForPOS";
 public static final String API_MAKE_PAYMENT_FOR_POS = "makePaymentForPOS";
 public static final String API_GET_OFFLINE_TRANQ_FOR_POS = "getOfflineTransactionQForPOS";
 public static final String API_MANAGE_TILL_STATUS_FOR_POS = "manageTillStatusForPOS";
 public static final String API_CONFIRMDRAFTORDER = "confirmDraftOrder";
 //Automation POS- Ends
 //CPE-9087 AST timezone Constants 
  public static final String AST_TIMEZONE = "AST";
  public static final String AST_DES  = "America/Anguilla";
  public static final String A_HISTORY_RETENTION_DAY = "HistoryRetentionDays"; 
  public static final String A_LIVE_RETENTION_DAY = "LiveRetentionDays";
  public static final String LineSequenceNbr = "LineSequenceNbr";
  public static final String Percent_Transaction_Discount = "% Transaction Discount";
  public static final String Dollar_Transaction_Discount = "$ Transaction Discount";
  public static final String Dollar_Off_Offer = "$ Off Offer";
  public static final String Seq_Number = "SequenceNbr";
  public static final String Underscore_00001 = "_00001";
  public static final String Temp_DisplayOnlyInd = "Temp_DisplayOnlyInd";
    
  // smart sku
  public static final String CURRENT_SMART_SKU					= "CurrentSmartSku";
  public static final String CURRENT_SMART_SKU_PRICE			= "CurrentSmartSkuPrice";
  
  // DM-1201
  public static final String DM_AHVOID_ENDPOINT			=  "DM_AUDITHISTORY_VOID";
  public static final String ELE_VOID_AUDITHISTORY = "VoidDMAuditHistory";
  public static final String SOURCE_VOIDDMAH = "VoidDMAuditHistory";
	
  //DM-976 changes
	public static final String ELE_DM_UPDATE_AH = "UpdateDMAH";
	public static final String VOID_DM_AH_LIST= "VoidDMAuditHistoryList";
	public static final String ATTR_STATUS_CODE = "StatusCode";
	public static final String AUDIT_DATE = "AuditDate";
	public static final String STORE_NO = "StoreNo";
	public static final String DISPOSITION_DETAILS = "DispositionDetails";
	public static final String ELE_SUMMARY = "Summary";
	public static final String ELE_AUDIT_TRAN = "AuditTransaction";
	public static final String ELE_DETAIL = "Detail";
	public static final String ORDERDETAILS_DM_VOID_HISTORY_TEMPLATE =
		      "/global/template/api/getOrderdetailsDMVoidAH.xml";
	public static final String API_GET_ADMIN_AUDIT_DETAILS="getAdminAuditDetailsForPOS";
	
	  //KCS port to OMS - start
	  public static final String E_COUPON_INQUIRY_RESPONSE_MSG = "CouponInquiryResponseMsg";
	  public static final String ELEM_KC_REDEMPTION_EVENT = "KCRedemptionEvent";
	  public static final String ELEM_KC_REDEMPTION_EVENTS = "KCRedemptionEvents";
	  public static final String ELEM_REDEMPTION_EVENT = "RedemptionEvent";
	  public static final String ATTR_KC_REDEMPTION_DATA = "redemptionData";
	  public static final String ATTR_KC_REDM_FILE_DATE = "KCRedmFileDate";
	  public static final String ATTR_KC_R_EVENT_KEY = "KCREventKey";
	  public static final String ATTR_AUTHORIZATION_INDICATOR = "AuthorizationIndicator";
	  public static final String ATTR_KC_DISCOUNT_TYPE = "DiscountType";
	  public static final String ATTR_KC_DISCOUNT_AMOUNT = "DiscountAmount";
	  public static final String API_SVC_CREATE_KOHLS_CASH_REDEMPTION = "CreateKohlsCashRedemption";
	  public static final String API_SVC_GET_KOHLS_CASH_REDEMPTION_LIST = "GetKohlsCashRedemptionList";
	  public static final String API_SVC_DELETE_KOHLS_CASH_REDEMPTION = "DeleteKohlsCashRedemption";
	  public static final String HARD_DECLINE_700002 = "700002";
	  public static final String HARD_DECLINE_700003 = "700003";
	  public static final String HARD_DECLINE_700004 = "700004";
	  public static final String REFERRAL_800001 = "800001";
	  public static final String EVENT_NAME_NONE = "NONE";
	  public static final String F0_NO_BALANCE_ERROR = "Kohl's Cash cannot be redeemed. The balance is currently zero.";
	  public static final String F8_DUPLICATE_ERROR = "Enter receipt ID from back of Kohl's Cash";
	  public static final String F7_700002_INQ_TRANS_DECLINE_ERROR = "Kohl's Cash was not activated. History cannot be viewed.";
	  public static final String F7_700002_DECLINE_ERROR = "Kohl's Cash was not activated and cannot be redeemed.";
	  public static final String F7_700003_INQ_TRANS_DECLINE_ERROR = "Kohl's Cash match was not found. History cannot be viewed.";
	  public static final String F7_700003_DECLINE_ERROR = "Kohl's Cash match was not found and cannot be redeemed.";
	  public static final String F7_700004_INQ_TRANS_DECLINE_ERROR = "Kohl's Cash cannot be redeemed. Activating transaction was voided.";
	  public static final String F7_700004_DECLINE_ERROR = "Kohl's Cash cannot be redeemed. Activating transaction was voided.";
	  public static final String PRE_REDEMP_ERROR = "Kohl's Coupon cannot be redeemed. The redemption period has not started. See Kohl's Coupon for more details";
	  public static final String POST_REDEMP_ERROR = "Kohl's Coupon has expired and cannot be redeemed.";
	  public static final String F9_OFFLINE_ERROR = "Enter validation code Printed on back of the Kohl's Cash|Enter Kohl's Cash balance";
	  public static final String DKC_GENERIC_ERROR = "DKC returned an error. Check DKCErrorCode and DKCErrorDescription for more information.";
	  public static final String SOAP_ENVELOPE = "soapenv:Envelope";
	  public static final String XMLNS = "xmlns";
	  public static final String XMLNS_SOAPENV = "xmlns:soapenv";
	  public static final String XMLNS_DKC = "xmlns:dkc";
	  public static final String SOAP_HEADER = "soapenv:Header";
	  public static final String SOAP_BODY = "soapenv:Body";
	  public static final String SOAP_VERSION = "version";
	  public static final String DKC_MESSAGE_HEADER = "MessageHeader";
	  public static final String DKC_MESSAGE_ID = "MessageID";
	  public static final String DKC_CREATE_DATE_TIME = "CreateDateTime";
	  public static final String DKC_SYSTEM_CODE = "systemCode";
	  public static final String DKC_APP = "app";
	  public static final String DKC_MODULE = "module";
	  public static final String DKC_NODE_ID = "nodeID";
	  public static final String DKC_INQUIRY_REQUEST = "dkc:InquiryRequest";
	  public static final String DKC_REWARD_NUMBER = "RewardNumber";
	  public static final String DKC_TRANSACTION_TIMESTAMP = "TransactionTimestamp";
	  public static final String DKC_STORE_NUMBER = "StoreNumber";
	  public static final String DKC_REGISTER_ID = "RegisterId";
	  public static final String DKC_TRANSACTION_NUMBER = "TransactionNumber";
	  public static final String DKC_SCANNED_INDICATOR = "ScannedIndicator";
	  public static final String DKC_PIN = "Pin";
	  public static final String DKC_MESSAGE_TYPE = "MessageType";
	  public static final String DKC_DOMAIN_PROPERTY = "OMS_KC_DKC_DOMAIN";
	  public static final String DKC_ENDPOINT_PATH_PROPERTY = "OMS_KC_DKC_ENDPOINT";
	  public static final String DKC_TIMEOUT = "OMS_KC_DKC_TIMEOUT";
	  //KCS port to OMS - end
	  //PST-5700
	  public static final String OFFLINE_TRXQ_TEMPLATE = "<OfflineTransactionQs> <OfflineTransactionQ DATAXML='' IsLocal='' "
		  		+ "Modifyts='' OfflineTrxQKey='' OperationID='' OperationInputXML='' OperationTS='' StoreID='' TrxStatus='' "
		  		+ "UniqueID='' ReplicationSeq=''><Extn ExtnRetryCount=''/> </OfflineTransactionQ> </OfflineTransactionQs>";
	  
	  // Start - Added for MPOC CPE-9664.
	  public static final String SOURCE_SYSTEM="SourceSystem";
	  public static final String A_PURPOSE="Purpose";
	  //End - MPOC CPE-9664
	  public static final String E_RETURN_DEBIT_ENABLED_IND = "ReturnDebitEnabledInd";

	  //PST-5731
	  public static final String PRICE_OVERRIDE_MANUAL = "PRICE_OVERRIDE_MANUAL";
	  public static final String AMOUNT_OFF_MANUAL_0000 = "AMOUNT_OFF_MANUAL_0000";
	  //CPE-9614
	  public static final String REPROCESS_REQUEST_GET_JOBS_TEMPLATE = "<KohlsReprocessRequestList><KohlsReprocessRequest  IsFlow='' IsSuccess='' NextReprocessTS='' PurgeDate='' ReprocessRequestKey='' RetryCount='' ServiceName='' Createts='' Version=''/></KohlsReprocessRequestList>";
	  //CPE-9858
	  public static final String ATTR_KC_LIMIT = "Limit";
	  //CPE-9859
	  public static final String API_SVC_UPDATE_KOHLS_CASH_ACTIVATION = "UpdateKohlsCashActivation";
	  public static final String API_SVC_UPDATE_KOHLS_CASH_REDEMPTION = "UpdateKohlsCashRedemption";
	  //CPE-5903
	  public static final String ExtraDetails5 = "ExtraDetails5";
	  public static final String CreditCardName = "CreditCardName";
	  public static final String PINPAD_VOID_OPERATION = "VOID";
	  public static final String CODE_VALUE_QRY_TYPE = "CodeValueQryType";
	  public static final String QRY_TYPE_LIKE = "LIKE";
	  public static final String IS_COMPRESSED = "IsCompressed";
	  
	  public static final String CreditCardExpDate = "CreditCardExpDate";
	  //CPE-10027
	  public static final String TXN_SYNC_ORDER_CREATION_ENABLED = "TXN.SYNC.ORDER.CREATION.ENABLED";
	  //Added for CPE-10055.
	  public static final String  E_ADMIN_AUDIT_LIST="AdminAuditList";
	  //End CPE-10055
	  //Adding Compress decompress logic for CPE-10027
	  public static String KOHLS_TXN_SYNC_DECOMPRESSION_SERVICE = "KohlsTxnSyncDecompress";
	  public static String COMPRESSED_INPUT = "CompressedInput";
	  public static String COMPRESSED_BLOB = "CompressedBlob";
	  public static final String TXN_SYNC_COMPRESSION_ENABLED = "TXN.SYNC.COMPRESSION.ENABLED";
	  //End Compress decompress logic for CPE-10027
	//CPE-10698
	public static final String DB_PASSWORD = "Password";
	public static final String QUERY = "Query";
	public static final String COLUMNS = "Columns";
	public static final String RECORD = "Record";
	public static final String DETAILS = "Details";
	public static final String NAMES = "Names";
	public static final String UTF_8 = "UTF-8";
	public static final String BLOW_FISH = "Blowfish";
	public static final String SELECT = "SELECT";
	public static final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
	public static final String JDBC_APP_FILE = "//kohls//apps//appsrv//of//mc//props//jdbc_customer.properties";
	public static final String DEFAULT_CONFIGURATION = "DEFAULT_CONFIGURATION_921.url";
	  
	//Omni-2 Changes starts
		public static final String API_CONFIRM_DRAFT_ORDER_TEMPLATE_PATH = "global/template/api/getShipmentListForPackShipmentKey_output.xml";

		public static final String API_VOID_CHARGE_TRANSACTION = "voidChargeTransaction";

		public static final String CREATE_INVOICE_TRANSACTION = "CREATE_INVOICE.0001.ex";
		public static final String E_ORDER_STATUS_CHANGE = "OrderStatusChange";
		public static final String TRANSACTION_POS_CHANGE_ORDER_STATUS = "POS_CHANGE_ORDER_STATUS.0001.ex";
		public static final String ATTR_DELIVERY_TYPE_CARRY = "CARRY";
		public static final String ATTR_CHANGE_FOR_ALL_AVAILABLE_QTY = "ChangeForAllAvailableQty";
		public static final String XPATH_CHARGE_TYPE_CHARGE = "/ChargeTransactionDetails/ChargeTransactionDetail";
		public static final String API_CHANGE_ORDER_STATUS = "changeOrderStatus";
		public static final String ATTR_CHARGE_TRANSACTION_KEY = "ChargeTransactionKey";
		public static final String LOCALE_STRING = "en_US";
		public static final String A_IS_EXTERNAL_PAYMENT = "IsExternalPayment";
		public static final String A_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
		public static final String A_AUTH_WINDOW_COMMON_CODE_VALUE = "AUTH_WINDOW";
		public static final String A_OMNI2_ENABLED_COMMON_CODE_VALUE = "OMNI2_ENABLED";
		public static final String A_COMMON_CODE_TYPE_PAYMENT_CONFIG = "OMNI2_CONFIG";
		public static final String A_LIGHT_INVOICE = "LightInvoice";

		public static final String A_DISPLAY_LOCALIZED_FIELD_IN_LOCALE = "DisplayLocalizedFieldInLocale";
		public static final String A_EXTRA_DETAILS_9 = "ExtraDetails9";
		public static final String A_EXTRA_DETAILS_10 = "ExtraDetails10";
		public static final String A_AUTH_RETURN_FLAG = "AuthReturnFlag";
		public static final String A_CVV_AUTH_CODE = "CVVAuthCode";
		public static final String A_PAYMENT_REF_4 = "PaymentReference4";
		public static final String A_PAYMENT_REF_5 = "PaymentReference5";
		public static final String TEMPLATE_GET_CHARGE_TRANSACTION_LIST = "/global/template/api/getChargeTransactionList.xml";
		public static final String A_SERVICE_POP = "KohlsProcessOrderPaymentsAPI";
		public static final String A_SERVICE_REPROCESS_POP = "KohlsReprocessRequestToPOP";
		public static final String A_EXTN_IS_OMNI ="ExtnIsOmni";
		public static final String A_SHIP_TO_ADDR ="shipToAddress";
		public static final String A_SHIP_FROM_ADDR ="shipFromAddress";
		public static final String A_ORIGIN_ADDR ="originAddress";
		public static final String A_ADDR_BOOK ="addressBook";
		public static final String A_CONTACT_INFO="ContactPersonInfo";
		public static final String A_NS_ADDR="ns2:address";
		public static final String A_NS_ID="ns2:id";
		public static final String A_NS_CITY="ns2:cityName";
		public static final String A_NS_CNTY_CODE="ns2:countryCode";
		public static final String A_NS_POST_CODE="ns2:postalCode";
		public static final String A_NS_STATE_PRVNCE="ns2:stateOrProvince";
		public static final String A_NS_GEO_CODE="ns2:geoCode";
		public static final String A_IN_STORE="IN_STORE";
		public static final String A_REQUEST_ID="RequestId";
		public static final String A_AUTH_REF="AuthReference";
		public static final String A_DISTRIBUTED_AMT="DistributedAmount";
		public static final String A_TRAN_AMT="TranAmount";
		public static final String A_DELAY_INVOICE="DELAY_INVOICE";
		public static final String A_VOID_TRAN_Q_TYPE="VoidTransactionQryType";
		public static final String IS_NULL="ISNULL";
		public static final String GET_ORDER_LIST_TEMPLATE_OMNI2_CHK="<OrderList><Order OrderNo='' OrderHeaderKey=''><Extn ExtnIsOmni=''/></Order></OrderList>";
		public static final String CUST_INFO_ERR_CODE="OMNI2_CUST_BILL_INFO_FAILURE";
		public static final String CUST_INFO_ERR_CODE_DESC="Customer BillingInfo capture failed. Please retry capturing the customer billing info";
		public static final String OMNI_PA_ERR_CODE="OMNI_ORDER_PA_NOT_ALLOWED";
		public static final String OMNI_PA_ERR_CODE_DESC="Price Adjustment is not allowed on OMNI orders";
		public static final String OMNI_PSA_ERR_CODE="OMNI_ORDER_PSA_NOT_ALLOWED";
		public static final String OMNI_PSA_ERR_CODE_DESC="Post Sale Adjustment is not allowed on OMNI orders";
		public static final String OPEN_REGISTER_TIME_CONV_SERVICE="KohlsPOCOpenRegisterTimeZoneConversion";
		// Omni-2 Changes Ends
	        public static final String IsPSASyncToCorp = "IsPSASyncToCorp";
	        public static final String GET_ORDER_DETAILS_FOR_PSA_SYNC_TEMPLATE = "/global/template/api/POC/PSASync/getOrderDetails_PSA.xml";
			
		// Adding for CPE-10687
	    public static final String CONSOLIDATE_LINE_TAX = "CONSOLIDATE_LINE_TAX";
	    // End for CPE-10687
	    
	  //For CPE-9964
	  		public static final String A_EXTN_RKC_ACTIVATION_FLAG ="ExtnRKCActivationFlag"; 
	  		public static final String ATTR_ACTIVATION_BARCODE = "ActivationBarCode";
	  		public static final String ATTR_SCAN_INDICATOR = "ScanIndicator";
	  		public static final String ATTR_RKC_ACTIVATION="RKCActivation";		
	  		public static final String ATTR_RKC="RKC Coupon";
	  		public static final String A_TIME_STAMP = "timestamp";
	  		public static final String A_EXTN_ACTIVATION_BARCODE = "ExtnActivationBarcode";
	  		public static final String A_RESULT = "Result";
	  		public static final String A_EXTN_IS_RKC_ACTIVATED = "ExtnIsRKCActivated";
			public static final String ATTR_EXTN_PA_RECEIPT_ID = "ExtnPAReceiptID";
		   public static final String               RKC_API_ENDPOINT                                 = "KOHLS_REALTIME_RKC_ENDPOINT";
		   public static final String               RKC_API_DOMAIN                                 = "KOHLS_REALTIME_RKC_DOMAIN";
		   public static final String               RKC_TIMEOUT                                 = "KOHLS_REALTIME_RKC_TIMEOUT";
		   public static final String               RKC_API_KEY                                 = "KOHLS_REALTIME_RKC_APIKEY";
		   public static final String               RKC_API_SECRET                                 =  "KOHLS_REALTIME_RKC_APISECRET";
		   public static final String               RKC_METHOD_NAME                                 =  "RealtimeRKC";
		   public static final String               FROM_SYSTEM_POC                                 =  "POC";

      // CPE-10590 		   
	   public static final String RT_DKC_ENDPOINT = "KOHLS_REALTIME_DKC_ENDPOINT";
	   public static final String RT_DKC_DOMAIN = "KOHLS_REALTIME_DKC_DOMAIN";
      public static final String RT_DKC_STUB_DOMAIN = "KOHLS_REALTIME_DKC_STUB_DOMAIN";
      public static final String RT_DKC_CONNECT_TIMEOUT = "KOHLS_REALTIME_DKC_CONNECT_TIMEOUT";
      public static final String RT_DKC_READ_TIMEOUT = "KOHLS_REALTIME_DKC_READ_TIMEOUT";
	   public static final String RT_DKC_API_KEY = "KOHLS_REALTIME_DKC_APIKEY";
	   public static final String RT_DKC_API_SECRET =  "KOHLS_REALTIME_DKC_APISECRET";
      public static final String RT_DKC_TYPE = "Deduct";
	
	//CPE-10903
	   public static final String HAZ_MATERIAL_CLASS =  "HazMaterialClass";
	   public static final String HAZ_MATERIAL_SUB_CLASS=  "HazMaterialSubclass";
	   
	   public static final String ATTR_HAZ_MAT_STR1 =  "HazMatInstr1";
	   public static final String ATTR_HAZ_MAT_STR2 =  "HazMatInstr2";
	   
	   public static final String A_PAYMENT_REF_6 =  "PaymentReference6";
	   public static final String A_PAYMENT_REF_7 =  "PaymentReference7";
	   public static final String IS_VOIDED =  "IsVoided";
	//CPE-23 - TaxWare changes
	   public static final String Total_Fee_Tax_Amount = "TotalFeeTaxAmount";
	   public static final String Extn_Is_Fee_Taxable = "ExtnIsFeeTaxable";
	   public static final String TAX_FEE_AWARD_SEQUENCE = "299";
	   public static final String TAXWARE_FEE_ID = "TAXWARE_FEE_ID";
	   public static final String TAXWARE_FEE = "TAXWARE_FEE";
	   public static final String AdjTaxFee = "% FEE ADJ";
	   public static final String TAX_BASIS = "taxBasis";
	   
		//CPE-11057 Auto Store Close PreProcessor changes to correct business date
		public static final String A_TRANS_KEY = "TransactionKey";
		public static final String MANAGE_TASK_QUEUE_API = "manageTaskQueue";
		public static final String GET_TRANS_LIST_API = "getTransactionList";
		public static final String A_TRANID = "Tranid";
		public static final String A_TASK_QUEUE = "TaskQueue";
		public static final String A_DATAKEY= "DataKey";
		public static final String A_AVAILABLE_DATE = "AvailableDate";
		public static final String STORE_BUSS_DATE_CORRECTION= "StoreBusinessDateCorrection";
		public static final String A_LOGTOFILE = "LogToFile";
		public static final String ASC_CLOSE_TIME = "ASC_CLOSE_TIME";
		public static final String ASC_CORRECTION_SERVICE_ENABLED = "ASC_CORRECTION_SERVICE_ENABLED";
		public static final String E_POS_STATUS = "POSStatus";
		
		// PST-6428 - start
		public static final String EXTN_IS_HT_PUBLISHED = "ExtnIsHardTotalsPublished";
		public static final String A_STORE_PROD_KEY = "StoreProductivityKey";
		public static final String API_MANAGE_STOREPRODACC_FOR_POS = "manageStoreProductAccForPOS";
		public static final String API_HT_STORE_PROD_ACC_LIST_TEMPLATE = "/global/template/api/POC/saleshub/POC_HTPublished_getStoreProductAccListForPOS.xml";
		// PST-6428 - start
		
		// CPE-11322
		public static final String TXN_COLONY_ID="STORE_GRP_01";
	
	        // PST-7061 : delta pump changes to enable staged import - start
		public static final String DOT_DMP = ".dmp";
		public static final String DELTA_STAGED_INPRG_PATH = STORE_DATA_DMP_PATH + "//Import//Delta//StagedInProgress";
		public static final String DELTA_STAGED_ERROR_PATH = STORE_DATA_DMP_PATH + "//Import//Delta//StagedError";
		public static final String DELTA_STAGE_START_TIME = "delta.staging.start.time";
		public static final String DELTA_STAGE_END_TIME = "delta.staging.end.time";
		public static final String A_INSTANT = "INSTANT";
		public static final String A_STAGED = "STAGED";
		public static final String A_IMPORT_TYPE = "ImportType";
		// PST-7061 : delta pump changes to enable staged import - end

	   public static  final String A_DEVICE="Device";
	   
	    public static  final String RRC_METHOD="RRC";
	public static final String KOHLS_RETURN_REASON_CODE = "KohlsReturnReasonCode";
		public static final String RRC_AGENT = "RRCRefreshAgent";
		public static final String A_RETURN_REASON_CODE = "RTN_RES_CODE";
		public static final String KOHLS_CALL_TO_RRC = "KohlsPoCCallReturnReasonCode";
		 public static  final String RRC_STANDALONE="RRCStandAlone";
	public static final String KOHLS_RETURN_REASON_CODE_LIST = "/global/template/api/POC/returns/POC_ReturnReasonCodeOutput.xml";

	
	public static final String RRC_DOMAIN = "RRC_DOMAIN";
	
	public static final String RRC_ENDPOINT="RRC_ENDPOINT";
	    public static  final String RRC_CONN_TIMEOUT="RRC_CONN_TIMEOUT";
	    public static  final String RRC_READ_TIMEOUT="RRC_READ_TIMEOUT";
	    public static final String RRC_PROXY_HOST = "RRC_PROXY_HOST";
	    public static final String RRC_PROXY_REQUIRED = "RRC_PROXY_REQUIRED";
	    public static final String RRC_PROXY_PORT = "RRC_PROXY_PORT";
	    
	    //PST-7148 changes 
	    public static final String A_BARCODE_TYPE  = "BarcodeType";
 	    
  public static final String A_UPDATE_FLAG="UpdateFlag";
	    public static final String A_CREATE_FLAG="CreateFlag";
	    public static final String KOHLS_CALL_TO_GET_RRC_LIST= "KohlsPoCGetReturnReasonCodeList";
	    public static final String KOHLS_CALL_TO_CREATE_RRC = "KohlsPoCCreateReturnReasonCode";
	    public static final String KOHLS_CALL_TO_UPDATE_RRC = "KohlsPoCChangeReturnReasonCode";
	    public static final String KOHLS_CALL_TO_GET_RRC = "KohlsPoCGetReturnReasonCode";
	    public static final String A_DEPT_NO="DepartmentNo";
	    public static final String A_UPDATED_DATE="UpdatedDate";
	    public static final String A_CREATED_DATE="CreatedDate";
	    public static final String A_REASON_CODE="ReasonCode";
	    public static final String KOHLS_RRC_LIST = "KohlsReturnReasonCodeList";
	    public static final String ENV_RRC_LIST ="getKohlsReturnReasonCodeList";
	    
	    //CPE-10416
	    public static final String DM_DOMAIN_CLOUD_ENDPOINT="DM_DOMAIN.BACKUP_ENDPOINT";
	    public static final String DM_DOMAIN_CLOUD_PROXY_REQUIRED="DM_DOMAIN.BACKUP.PROXY_REQUIRED";
		 public static String SERVICE_KOHLS_CHANGE_DAMAGE_REASON_CODES="KohlsChangeDamageReasonCode";
		public static String SERVICE_KOHLS_CHANGE_DM_SLIP_TEXT="KohlsChangeDMSlipText";
		public static String A_DELETE_FLAG="DeleteFlag";
	    public static final String DM_STAND_ALONE="StandAlone";
		public static String ORIG_TRANSCTION="OriginalTransaction";
		public static String REASON_TEXT="ReasonText";
	public static String GIV_ENHANCEMENT="GIV_ENHANCEMENT";
		
		
		//PST-6617
		public static final String ORDERLIST_DM_VOID_HISTORY_TEMPLATE = "/global/template/api/getOrderListDMVoidAH.xml";
		 
		 //PST-7425
		 public static final String POST_SALE_VOID_AFTER = "PSA_VoidAfter";
		 public static final String POST_SALE_VOID_DURING = "PSA_VoidDuring";
		 public static final String EVEN_EXCHANGE = "EvenExchange";
		 public static final String EVEN_EXCHANGE_VOID_AFTER = "EE_VoidAfter";
		 
			// CPE-10395 : MOS Salvage
			public static String KOHLS_CREATE_MOS_DATA="KohlsPoCCreateMosData";
			public static final String GET_ITEM_LIST_MOS_OUTPUT =
				      "global/template/api/getItemListForMos_output.xml";
			
		
			public static String KOHLS_CHANGE_MOS_DATA="KohlsPoCChangeMosData";
			
			public static String KOHLS_GET_MOS_DATA_LIST="KohlsPoCGetMosDataList";
			public static String API_MANAGE_ITEM="manageItem";
			public static String A_UOM="UOM";
			public static String KOHLS_MOS_DATA_LIST="KohlsMosDataList";
			public static String ALT_SKU_DATA_LIST="AltSkuMapEntries";
            public static String ALT_SKU_DATA="AltSkuMap";
			public static String KOHLS_MOS_DATA="KohlsMosData";
			public static String A_SKUNBR="SkuNbr";
			public static String A_VENDOR_UPC_NBR="VendorUpcNumber";
			public static String  A_MOS_START_DATE="MosStartDate";
			public static String MOS_STAND_ALONE="MOSStandAlone";
			public static String A_KOHLS_MOS_DATA="MOSAgent";
			public static String KOHLS_GET_MOS_DATA="KohlsPoCGetMosData";
			public static String MOS_KAFKA_SESSION_TIMEOUT = "MOS_KAFKA_SESSION_TIMEOUT";
			public static String MOS_KAFKA_READ_TIMEOUT = "MOS_KAFKA_READ_TIMEOUT";
			public static String MOS_KAFKA_RESET_STRATEGY = "MOS_KAFKA_RESET_STRATEGY";
			public static String MOS_KAFKA_TOPIC = "MOS_KAFKA_TOPIC";
			public static String MOS_KAFKA_BOOTSTRAP_SERVERS = "MOS_KAFKA_BOOTSTRAP_SERVERS";
			public static String MOS_KAFKA_GROUPID = "MOS_KAFKA_GROUPID";
			public static String MOS_KAFKA_RETRY_ATTEMPTS = "MOS_KAFKA_RETRY_ATTEMPTS";
			public static String MOS_KAFKA_POLL_INTERVAL = "MOS_KAFKA_POLL_INTERVAL";
			public static String MOS_TOTAL_FETCHED_RECORDS = "TotalFetchedRecords";
			public static String A_FROM_OFFSET = "FromOffset";
			public static String MOS_SERVICE = "KohlsCallToMOSWrapper";
			public static String MOS_KAFKA_OFFSET="MOS_KAFKA_OFFSET";
			public static String ENABLE_PMDM_RULE = "ENABLE_PMDM";
			public static final String MOS_DATE_FORMAT = "MM-dd-yyyy";
			
			public static String A_EXTN_WEBEX_INDICATOR = "ExtnWebExclusiveIndicator";
			public static String A_EXTN_DC_RETURN_CODE = "ExtnDCReturnCode";
			public static String PMDM_SERVICE_CALL = "KohlsPoCWebExclusiveCall";
			public static String A_EXTN_DC_RETURN_CODE_DESC = "ExtnDCReturnCodeDesc";
	
			//CPE-11854
			public static final String A_NS_STORE_NUMBER="ns2:storeNumber";
			
			//CPE-10396
			public static final String IS_MOS_SALVAGE_ITEM = "IsMOSSalvageItem";
			public static final String SKU_NBR = "SkuNbr";
			public static final String MOS_START_DATE = "MosStartDate";
			public static final String ENABLE_MOS_SALVAGE_CHECK = "ENABLE_MOS_SALVAGE_CHECK";
			public static final String MOS_SALVAGE_FLAG ="MOSSalvageFlag";
			public static final String DM_RULE = "DISPOSITION_MGNT_STORE";
			
			public static final String A_GRAVITY = "gravity";
			public static final String MOS_AGENT_SOURCE = "MOS_AGENT";
			
			//CPE-10781 - SBC ForceOffline Screen changes
			public static final String API_GET_SERVER_STATUS_LIST_POS = "getServerStatusListForPOS";
		 	public static final String TRIGGER_MANUAL_SWITCH = "TriggerManualSwitch";
		 	public static final String ELE_POS_OFFLINE_STATUS = "PosOfflineStatus";
		 	public static final String SERVER_STATUS_KEY = "ServerStatusKey"; 
		 	public static final String API_PERFORM_MANUAL_SWITCH = "performManualSwitchAPIForPOS";
		 	public static final String GET_SERVER_STATUS_TEMPLATE = "<ServerStatus ><Extn /></ServerStatus>";
			public static final String API_LOAD_SERVER_DASHBOARD_FOR_POS = "loadServerDashboardForPOS";
			public static final String API_LOAD_DASHBOARD_SERVER_DETAILS_FOR_POS = "loadDashboardServerDetailsForPOS";
			public static final String E_PROFILES = "Profiles";
			public static final String A_PROFILE_NAME = "ProfileName";
			public static final String A_DATA_SYNC_STATUS =  "DataSyncStatus";
			public static final String STATUS_SYNCHRONIZED = "1000"; 
			public static final String A_FORCE_OFF_REASON_CODE = "ForceOfflineReasonCode";
			public static final String STATUS_INSTANT_SYNCED = "3000.1300.100";
			public static final String STATUS_STAGED_SYNCED = "3000.1300.200";
			public static final String STATUS_PARTIAL_SYNCED = "3000.1300";
			public static final String A_ORDER_SYNC_STATUS="OrderSyncStatus";
			public static final String A_VERSION_MISMATCH="VersionMismatch";
			
			public static final String TEXT13 = "Text13";

			//CPE-11474 - Constanst
		    public static final String OTR_Q = "OTR-Q";
		    public static final String STORE_NAME = "StoreName";
		    public static final String RS_TIME_TAKEN = "RSTimeTaken";
		    public static final String RETURN_PASS_NO = "ReturnPassNo";
		    public static final String RETURN_PASS_ITEMS = "ReturnPassItems";
		    public static final String RETURN_PASS_NUMBER = "ReturnPassNumber";
		    public static final String S_ITEMS = "items";
		    public static final String S_ITEM = "item";
		    public static final String TRANSACTION_KEY = "transactionKey";
		    public static final String LOCATION_NUMBER = "locationNumber";
		    public static final String DEVICE_ID = "deviceId";
		    public static final String TRANSACTION_NUMBER = "transactionNumber";
		    public static final String TRANSACTION_TIME_STAMP = "transactionTimestamp";
		    public static final String ATTR_SKU_NUMBER = "skuNumber";
		    public static final String LINE_SEQUENCE_NUMBER = "lineSequenceNumber";
		    public static final String KOHLS_CALL_RP_WRAPPER = "KohlsCallRPWrapper";
		    public static final String FUNCTION = "Function";
		    public static final String U_ENDPOINT = "_ENDPOINT";
		    public static final String U_UPDATE_STATUS = "_UPDATE_STATUS";
		    public static final String U_API_READTIMEOUT = "_API_READTIMEOUT";
		    public static final String U_API_CONNTIMEOUT = "_API_CONNTIMEOUT";
		    public static final String POST_NOOUTPUT = "POST_NOOUTPUT";
		    public static final String ATTR_RETURN = "RETURN";
			public static final String VOID = "VOID";
			
			
		    public static final Map<String, String> GETOTRRESPONSE;
			public static final String GET_RETURN_PASS_DETAILS = "GetReturnPassDetails";
			public static final String COMPLETE_RETURN_PASS = "CompleteReturnPass";
			public static final String POST_VOID_RETURN_PASS = "PostVoidReturnPass";
			public static final String U_DOMAIN = "_DOMAIN";
			public static final String U_DOMAIN_PROXY_REQUIRED = "_DOMAIN.PROXY_REQUIRED";
			public static final String U_PROXY_REQUIRED = "_PROXY_REQUIRED";
			public static final String CLOUD = "CLOUD";
			public static final String U_RETRY_THRESHOLD = "_RETRY_THRESHOLD";
			public static final String D_PROXY_REQUIRED = ".PROXY_REQUIRED";
			public static final String D_OAUTHNEEDED = ".OAUTHNEEDED";
			public static final String U_PROXY_HOST = "_PROXY_HOST";
			public static final String U_PROXY_PORT = "_PROXY_PORT";
			public static final String CREATED_DATE = "createdDate";
			public static final String REFUND_METHOD = "refundMethod";
			public static final String RETURN_PASS_CODE = "returnPassCode";
			public static final String STATUS_LC = "status";
			public static final String UPDATED_DATE = "updatedDate";
			public static final String ORDER_NUMBER = "orderNumber";
			public static final String ZIP_CODE = "zipCode";
			public static final String RECEIPT_PREFERENCE_METHOD = "receiptPreferenceMethod";
			public static final String RECEIPT_PREFERENCE_EMAIL_ID = "receiptPreferenceEMailID";
			public static final String CUSTOMER_INFO = "customerInfo";
			public static final String EMAIL_ID = "emailID";
			public static final String LOYALTY_ID = "loyaltyID";
			public static final String PROFILE_ID = "profileID";
			public static final String COLOR = "color";
			public static final String IMAGE_URL = "imageURL";
			public static final String PRODUCT_ID = "productID";
			public static final String REASON_CODE = "reasonCode";
			public static final String REASON_DESC = "reasonDesc";
			public static final String SIZE = "size";
			public static final String TITLE = "title";
			public static final String UPC = "upc";
			public static final String RP_GO_TO_CLOUD = "RP_GO_TO_CLOUD";
			public static final String U_PASSCODE_EP = "_PASSCODE_EP";
			public static final String U_UPDATE_STATUS_EP = "_UPDATE_STATUS_EP";
			public static final String SIMPLE_PROMO_THOUSAND_TEN = "1010";
			public static final String CREATED = "CREATED";
			public static final String PARTIAL_USED = "PARTIAL_USED";
			public static final String RECEIPT_ID = "receiptId";
			public static final String STORE_DETAILS = "storeDetails";
			public static final String STORE_ID_LC = "storeId";
			public static final String NAME = "name";
			public static final String ADDR_ONE = "addr1";
			public static final String ADDR_TWO = "addr2";
			public static final String CITY = "city";
			public static final String STATE = "state";
			public static final String PHONE_NUMBER = "phoneNumber";
			public static final String RETURN_PASS_ITEM_SEQ_NO = "ReturnPassItemSeqNo";
			public static final String RETURN_PASS_ITEM_STATUS = "ReturnPassItemStatus";
			public static final String INVALID_RETURN_PASS_STATUS_ERROR_DESC = "ReturnPass scanned is not in valid Status. Current status is  ";
			public static final String RO = "RO";
			public static final String ERROR_PREFIX = "ERROR_";
			
		    // Set OTR Description as Key and Code as Value
		    static
		    {
		       GETOTRRESPONSE = new HashMap<String, String>();
		       GETOTRRESPONSE.put( "Approval", "F0" );
		       GETOTRRESPONSE.put( "CorporateRefundRequired", "F8" );
		       GETOTRRESPONSE.put( "EditError", "F2" );
		       GETOTRRESPONSE.put( "HardDecline", "F7" );
		       GETOTRRESPONSE.put( "Offline", "F9" );
		       GETOTRRESPONSE.put( "RefundAuth", "F1" );
		       GETOTRRESPONSE.put( "Transaction not found", "1F0" );
		       GETOTRRESPONSE.put( "TransactionNotFound", "1F0" );
		       GETOTRRESPONSE.put( "Drivers license lookup error", "F0" );
		       GETOTRRESPONSE.put( "Gift Receipt Threshold lookup error", "F0" );
		       GETOTRRESPONSE.put( "Transaction lookup error", "F0" );
		       GETOTRRESPONSE.put( "Item lookup error gift receipt", "F0" );
		       GETOTRRESPONSE.put( "Line item discount lookup error", "F0" );
		       GETOTRRESPONSE.put( "Employee discount lookup error", "F0" );
		       GETOTRRESPONSE.put( "Tender record lookup error", "F0" );
		       GETOTRRESPONSE.put( "Check auto lookup error", "F0" );
		       GETOTRRESPONSE.put( "Cust ref lookup error for a check", "F0" );
		       GETOTRRESPONSE.put( "Check Tender Ã¢â‚¬Å“DÃ¢â‚¬Â� and NSF=N <=14 days <= $50, Good", "F0" );
		       GETOTRRESPONSE.put( "Suspect Transaction", "F0" );
		       GETOTRRESPONSE.put( "Receipt is older than 3 years", "F1" );
		       GETOTRRESPONSE.put( "Check Tender Ã¢â‚¬Å“DÃ¢â‚¬Â� or Ã¢â‚¬Å“KÃ¢â‚¬Â�,  <= $25.00", "F1" );
		       GETOTRRESPONSE.put( "Gift Receipt was from a voided transaction", "F1" );
		       GETOTRRESPONSE.put( "Check Tender Ã¢â‚¬Å“DÃ¢â‚¬Â� and NSF=Y, <= $25.  Cash", "F1" );
		       GETOTRRESPONSE.put( "Check Tender - Check tender > $75", "F1" );
		       GETOTRRESPONSE.put( "Edit Error Ã¢â‚¬â€œ Bad Data in the authorization", "F2" );
		       GETOTRRESPONSE.put( "Original Transaction was voided", "F7" );
		       GETOTRRESPONSE.put( "Invalid transaction type.  Nothing on this receipt to return", "F7" );
		       GETOTRRESPONSE.put( "Gift Receipt was previously returned", "F8" );
		       GETOTRRESPONSE.put( "OTR amount is 0.00", "F8" );
		       GETOTRRESPONSE.put( "Check Tender Ã¢â‚¬Å“DÃ¢â‚¬Â� or Ã¢â‚¬Å“KÃ¢â‚¬Â� Ã¢â‚¬â€œ Over $25.00", "F8" );
		       GETOTRRESPONSE.put( "Check Tender Ã¢â‚¬Å“GÃ¢â‚¬Â� Ã¢â‚¬â€œ Over $250.00 and under 5 days", "F8" );
		       GETOTRRESPONSE.put( "E-Commerce Return is occurring at theFulfillmentCenter", "F8" );
		       GETOTRRESPONSE.put( "Check Tender Ã¢â‚¬Å“DÃ¢â‚¬Â� and NSF = Y and > $25.  Corporate Refund", "F8" );
		       GETOTRRESPONSE.put( "Otr is zero error", "F8");
		    }
      //CPE-313	
			public static final String ITEM_DATA = "ITEM_DATA";
			public static final String KOHLS_CREATE_DefEdg_HighRiskItem = "KohlsCreateDefEdgHighRiskItem";
			public static final String KOHLS_DELETE_DefEdg_HighRiskItem = "KohlsDeleteDefEdgHighRiskItem";
			public static final String KOHLS_GET_DefEdg_HighRiskItem = "KohlsGetDefEdgHighRiskItem";
			public static final String KOHLS_CHANGE_DefEdg_HighRiskItem = "KohlsChangeDefEdgHighRiskItem";
			public static final String KOHLS_GET_DefEdg_HighRiskItem_LIST = "KohlsGetDefEdgHighRiskItemList";
			public static final String KohlsDefEdgHighRiskItem = "KohlsDefEdgHighRiskItem";
			public static final String FRAUD_RISK_DATA = "FraudRiskData";
			public static final String RISK_LEVEL = "RiskLevel";
			public static final String API_CF_GET_ORDER_DETAILS_TEMPLATE =
				      "global/template/api/CF_GetOrderDetails.xml";
			public static final String CF_STANDALONE = "CFStandAlone";
			public static final String GIFT_CARD_AMT = "GIFT_CARD_AMT";
			public static final String A_CF_AGENT="CFAgent";
			public static final String A_CF_SERVICE="KohlsCallToCFWrapper";
			public static final String CF_TESTDATA = "CF_TESTDATA";
			public static String CF_KAFKA_SESSION_TIMEOUT = "CF_KAFKA_SESSION_TIMEOUT";
			public static String CF_KAFKA_READ_TIMEOUT = "CF_KAFKA_READ_TIMEOUT";
			public static String CF_KAFKA_RESET_STRATEGY = "CF_KAFKA_RESET_STRATEGY";
			public static String CF_KAFKA_TOPIC = "CF_KAFKA_TOPIC";
			public static String CF_KAFKA_BOOTSTRAP_SERVERS = "CF_KAFKA_BOOTSTRAP_SERVERS";
			public static String CF_KAFKA_GROUPID = "CF_KAFKA_GROUPID";
			public static String CF_KAFKA_RETRY_ATTEMPTS = "CF_KAFKA_RETRY_ATTEMPTS";
			public static String CF_KAFKA_POLL_INTERVAL = "CF_KAFKA_POLL_INTERVAL";
			public static String CF_KAFKA_SECURITY_PROTOCOL = "CF_KAFKA_SECURITY_PROTOCOL";
			public static String CF_KAFKA_TOPIC_OVERRIDE = "OverrideTopic";
			public static String CF_KAFKA_SECURITY_PROTOCOL_PROP = "security.protocol";
			public static String CF_KAFKA_TRUST_STORE_PWD ="CF_KAFKA_TRUST_STORE_PWD";
			public static String CF_KAFKA_TRUST_STORE_LOC = "CF_KAFKA_TRUST_STORE_LOC";
			public static String CF_KAFKA_FETCH_MAX_WAIT = "CF_KAFKA_FETCH_MAXWAIT";;
			public static final String CF_PATH = "/logs/apps/of/CreditFraud/input";
			
			public static final String PENDING = "PENDING";
			public static final String RP_RECEIPT_PREF_METHOD = "ReceiptPreferenceMethod";
			public static final String RP_REFUND_PREF_METHOD = "RefundPreferenceMethod";
			public static final String RP_CUSTOMER_EMAIL_ID = "CustomerEmailID";
			public static final String RP_CUSTOMER_LOYALTY_ID = "CustomerLoyaltyID";
			public static final String RP_CUSTOMER_PROFILE_ID = "CustomerProfileID";
			public static final String RP_RECEIPT_PREF_EMAIL_ID = "ReceiptPreferenceEmailID";
			public static final String RP_RETURN_REASON_CODE = "RPReturnReasonCode";
			public static final String RP_RETURN_REASON_DESC = "RPReturnReasonDesc";
			public static final String OL_ADDNL_DATA_LIST = "OrderLineAddnlDataList";
			public static final String OL_ADDNL_DATA = "OrderLineAddnlData";
			public static final String RETURN_PASS_ITEM = "ReturnPassItem";
            public static final String DATEFORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

			//PST-8046 : Enhanced StoreServers Search screen fix - for blank search
			public static final String A_DEPLOYMENT_VERSION="DeployVersionNo";
			public static final String A_SERVER_TYPE="ServerType";
			public static final String EDGE="edge";
	
			//CPE-12109 Enhanced ForceOffline List Screen
			public static final String A_ERRORED_STORES="ErrorStores";
			public static final String A_SPLUNK_LINK="SplunkLink";
			public static final String E_SERVER_STATUS_LIST="ServerStatusList";
			public static final String E_PAGE_DATA="PageData";
			public static final String A_IS_FIRST_PAGE="IsFirstPage";
			public static final String A_IS_LAST_PAGE="IsLastPage";
			public static final String A_IS_VALID_PAGE="IsValidPage";
			public static final String A_PAGE_NUMBER="PageNumber";
			public static final String A_PAGE_SIZE="PageSize";
			public static final String A_START_ROW_NUMBER="StartRowNumber";
			public static final String A_NOOF_PAGES="TotalNumberOfPages";

            public static final String RP_CUSTOM_ERROR = "404_RP_CUSTMGR";
			public static final String SHARED_KCS_ERROR = "Return Pass cannot be processed \nsince multiple transactions share same Kohl's Cash Coupon";
			public static final String RP_UPC_CODE = "RPUPCCode";
			
			//Partition Merge CPE-12579
			public static final String STG_SYNC_VER = "STAGED_SyncVersion";
			public static final String STG_INPRG = "StagedInProgress";
			public static final String STG_ERROR = "StagedError";
			public static final String PARTITION = "Partition";
			public static final String MERGE = "Merge";
			public static final String ATTR_PRIMARY_TABLE = "PrimaryTable";
			public static final String ATTR_PARTITION_TABLE = "PartitionTable";
			public static final String ATTR_PARTITION_NAME = "PartitionName";
			public static final String ATTR_PARTITION_SYNC_XML = "DeltaSynXml";
			public static final String DELTA_PARTITION_TABLE_SIZE = "Delta.Partition.Table.Size";
			public static final String DELTA_PARTITION_FILE_WAIT = "Delta.Partition.File.Wait";
			
			public static final String RP_NO_ELIGIBLE_ITEM_ERROR = "Unable to process. No eligible item(s) in the Return Pass.";
			public static final String RI = "RI";
			public static final String RP_RECEIPT_ID = "RP_RECEIPT_ID";
			public static final String STR_APPROVAL = "Approval";
			public static final String RETURN_PASS_INVALID_RS_RESPONSE = "Return Pass cannot be processed.";
			
			//CPE-12249 
			public static final String TRIGGER_TYPE = "TriggerType";
			public static final String RULE_GROUP_NAME = "RuleGroupName";
			public static final String RULE_META_DATA = "RuleMetadata";
			public static final String GROUP_NAME = "GroupName";
			public static final String FORMAT_HH_MM = "HH:mm";
			public static final String DO_NOT_TRIGGER = "DoNotTrigger";
			public static final String CRITERIA_ID = "CriteriaId";
			public static final String API_TRIGGER_AGENT = "triggerAgent";
      public static final String DAY_OF_WEEK_FORMAT = "EEE";
      public static final String DELIMITED_TILDA = "\\~";
      public static final String DELIMITED_PIPE = "\\|";
      public static final String STARTS_WITH_D_DASH = "D-";
      public static final String STARTS_WITH_W_DASH = "W-";
      public static final String WEEKLY = "Weekly";
      public static final String DAILY = "Daily";
      public static final String SKIP_TRIGGER_DURING_RESTART = "SKIP_TRGR_DURING_RESTART";
      public static final String TRIGGER_TYPE_FORCEALL = "FORCEALL";
      public static final String RESTART_TRGR_TYPE_XPATH = "/RuleList/Rule[@RuleID='SKIP_TRGR_DURING_RESTART']";
      public static final String SKIPPED  = "SKIPPED";
			
			//LCS deactivation
			public static final String CURR_PROCESS_TRANSACTION = "CurrentProcessingTransaction";
      
      //CPE-13293
      public static final String A_VOID_DURING_INVOICE = "VoidDuring";
      public static final String V2_UNEARN = "V2Unearn";
      
      public static final String ASYNC_REFUND_PROCESSING = "ASYNC_REFUND_PROCESSING";
      public static final String ASYNC_TIMEOUT = "ASYNC_TIMEOUT";
      
      //CPE-12225
      public static final String RP_CUSTMGR_IDENTIFIER = "RP_CUSTMGR";
      
      //CPE-13215
  	public static final String RANK_RECORDS_PER_MERGE = "Delta.Rank.Batch.Limit";
  	public static final String ISS_DATADUMP_DELTA_POD_TYPE = "ISS_DATADUMP_DELTA_POD_TYPE";
  	public static final String RANK_BATCH_SIZE_START = "RankBatchSizeStart";
  	public static final String RANK_BATCH_SIZE_END = "RankBatchSizeEnd";

  	public static final String DELTA_EXPORT_PARTITION_ENABLED = "EXPORT.PARTITION.ENABLED";
  	public static final String DELTA_RECORDS_DELETE_ENABLED = "Delta.Records.Delete.Enabled";
  	public static final String ENTITY_CHANGE_EXTN_RANK = "EXTN_RANK";
  	public static final String RANK_ENABLED = "RankEnabled";
  	public static final String A_STG_TABLE_MAP = "STGTableMap";
  	public static final String SALE_WITH_GCINQ = "SaleWithGCInq";
  	public static final String GCINQ_PROCID = "110";
  	
  	public static final String KCBALINQ_PROCID = "10100";
    public static final String A_EXTN_NUMBER_FORMAT = "ExtnDLNumberFormat";
	
	public static final String ELEM_RECORD = "RECORD";
	public static final String E_SAF_REC ="KohlsSafRespRecord";
  	public static final String SAF_NUM = "SAF_NUM";
  	public static final String E_SAF_NUM ="SafNum";
  	public static final String SAF_STATUS = "SAF_STATUS";
  	public static final String E_SAF_STATUS = "SafStatus";
  	public static final String INVOICE = "INVOICE";
  	public static final String E_INVOICE = "Invoice";
  	public static final String TRANS_AMOUNT = "TRANS_AMOUNT";
  	public static final String E_TRANS_AMOUNT = "TransAmount";
  	public static final String APPROVED_AMOUNT = "APPROVED_AMOUNT";
  	public static final String E_APPROVED_AMOUNT = "ApprovedAmount";
  	public static final String PAYMENT_TYPE = "PAYMENT_TYPE";
  	public static final String PAYMENT_MEDIA = "PAYMENT_MEDIA";
  	public static final String E_PAYMENT_MEDIA = "PaymentMedia";
  	public static final String TROUTD = "TROUTD";
  	public static final String E_TROUTD = "TroutId";
  	public static final String CTROUTD = "CTROUTD";
  	public static final String E_CTROUTD = "CtroutId";
  	public static final String AUTH_CODE = "AUTH_CODE";
  	public static final String E_AUTH_CODE = "AuthCode";
  	public static final String CARD_TOKEN = "CARD_TOKEN";
  	public static final String E_CARD_TOKEN = "CardToken";
  	public static final String CVV2_CODE = "CVV2_CODE";
  	public static final String E_CVV2_CODE = "Cvv2Code";
  	public static final String COMMAND = "COMMAND";
  	public static final String E_COMMAND = "Command";
  	public static final String TRANS_DATE = "TRANS_DATE";
  	public static final String E_TRANS_DATE = "TransDate";
  	public static final String TRANS_TIME = "TRANS_TIME";
  	public static final String E_TRANS_TIME = "TransTime";
  	public static final String INTRN_SEQ_NUM = "INTRN_SEQ_NUM";
  	public static final String E_INTRN_SEQ_NUM = "IntrnSeqNum";
  	public static final String E_TRAN_SEQ_NUM = "TransSeqNum";
  	public static final String TRAN_SEQ_NUM = "TRANS_SEQ_NUM";
  	public static final String E_TERMINAL_ID = "TerminalId";
  	public static final String API_CREATE_KOHLS_PROCESSED_SAF_RECORDS = "KohlsCreateProcessedSafRecords";
  	public static final String API_GET_SAF_RECORDS_FOR_CORP = "KohlsGetSafRecordsForCorp";	
  	public static final String KOHLS_ENABLE_CLIENT_SAF = "KOHLS_ENABLE_CLIENT_SAF";
  	public static final String E_RECORDS = "RECORDS";
  	public static final String E_ACCT_NUM = "ACCT_NUM";
  	public static final String E_TRANSAMOUNT = "TRANS_AMOUNT";
  	public static final String E_LANE = "LANE";
  	public static final String E_STORE_NUM = "STORE_NUM";
  	public static final String E_CARD_EXP_MONTH = "CARD_EXP_MONTH";
  	public static final String CARD_EXP_YEAR = "CARD_EXP_YEAR";
  	public static final String CARD_ENTRY_MODE = "CARD_ENTRY_MODE";
  	public static final String ATTR_CARD_TOKEN = "CardToken";
   	public static final String ATTR_CARD_EXP_MONTH = "CardExpiryMonth";
  	public static final String ATTR_CARD_EXP_YEAR = "CardExpiryYear";
  	public static final String ATTR_CARD_ENTRY_MODE = "CardEntryMode";
  	public static final String EXTN_GEO_ZIPCODE = "ExtnGeoCodeZip";
  	public static final String API_DELETE_SAF_RECORDS_FOR_CORP = "KohlsDeleteSafRecordsForCorp";
    public static final String KOHLS_PURGE_CLIENT_SAF = "KOHLS_PURGE_CLIENT_SAF";
   	public static final String CASH_BACK_AMOUNT = "CashBackAmount";
   	public static final String ATTR_PAYMENT_DETAILS = "PaymentDetails";
    public static final String ATTR_REQ_PROCESSED = "RequestProcessed";
  	public static final String ATTR_SAF_RECORD = "SafRespRecord";
   	public static final String ATTR_DATE_9 = "Date9";
   	public static final String DEVICE_ID_PINPAD = "DEVICE_ID";
   	public static final String DEVICE_ID_ATTR = "DeviceId";
   	
   	//CLI Constants - Start
   	public static final String CLI = "CLI";
    public static final String CLI_SRC_ELIGIBLE="CLIEligibilityReq";
    public static final String CLI_SRC_VERIFICATION="CLICustVerfication";
    public static final String CLI_SRC_OFFER_REQ="CLIOfferRequest";
    public static final String CLI_RES_RESPONSE="response";
    public static final String CLI_RES_RESPONSE_CODE="responseCode";
    public static final String CLI_RES_FIRSTNAME="firstName";
    public static final String CLI_RES_LASTNAME="lastName";
    public static final String CLI_RES_MID_NAME="middleInitial";
    public static final String CLI_RES_MSG="message";
    public static final String CLI_RES_INC_AMT="creditLineAmount";
    public static final String CLI_REQ_USER="user";
    public static final String CLI_REQ_SSN="ssn";
    public static final String CLI_REQ_CLIP_CHAN="clipchan";
    public static final String CLI_REQ_TOKEN_NUM="tokenNumber";
    public static final String CLI_REQ_TOKEN_TYPE="tokenType";
    public static final String CLI_REQ_ACCOUNT_ID="accountId";
    public static final String CLI_REQ_EXT_CUST_ID="externalCustomerId";
    public static final String CLI_REQ_PRESENT_ID="presentationId";
    public static final String CLI_REQ_BEHAVIOR_ID="behaviorId";
    public static final String CLI_REQ_ELEMENT="element";
    public static final String CLI_REQ_ELE_ID = "elementId";
    public static final String CLI_REQ_ELE_VAL="elementvalue";
    public static String CLI_PROXY_HOST="CLI_PROXY_HOST";
    public static String CLI_PROXY_PORT="CLI_PROXY_PORT";
    public static String CLI_API_KEY="CLI_API_KEY";
    public static String CLI_API_SECRET_KEY="CLI_API_SECRET_KEY";
    public static String CLI_READ_TIMEOUT="CLI_READ_TIMEOUT";
    public static String CLI_DOMAIN="CLI_DOMAIN";
    public static String CLI_ELIGIBILITY_REQ_ENDPOINT="CLI_ELIGIBILITY_REQ_ENDPOINT";
    public static String CLI_OFFER_REQ_ENDPOINT="CLI_OFFER_REQ_ENDPOINT";
    public static String CLI_CUST_VERIFICATION_ENDPOINT="CLI_CUST_VERIFICATION_ENDPOINT";
    //CLI Constants - End    
    public static String CLI_USER="CLI_USER";
    public static String CLI_KCWEB="KCWEB";
    public static String Element_id="elementId";
    public static String Element_Value="elementValue";
    public static String CLI_ELIGIBILITY="CLIEligibility";    
    public static String CLI_CUST_VERIFY="CLICustomVerify";
    public static String Element="Element";
	public static final String CACHE_CLEAR_FILE = "modifyCache.sh";
	public static final String API_TESTER_PATH = "apitester.path";
	public static final String ATTR_VOID_INDICATOR = "VoidIndicator";
	public static final String ATTR_ORG_TOTAL_AMT = "OriginalTotalAmount";
	public static final String ATTR_EXTN_IS_CANCELLED = "ExtnIsCancelled";
	public static final String ATTR_MAX_ORD_STS_DESC = "MaxOrderStatusDesc";
	public static final String TRX_SYNC_DETAILS = "TransactionSyncDetails";
	
	public static final String KOHLS_ENABLE_MRR_KOHLS_CASH="ENABLE_MRR_KOHLS_CASH";
	public static final String          RP_ITEM_DESC = "RPItemDesc";
	public static final String RULE_SEND_TVS_EXCLUSIONS = "INCLUDE_TVS_EXCLUSIONS";
	
	public static final String PAYMENT_TYPE_GROUP      = "PaymentTypeGroup";
    public static final String STORED_VALUE_CARD       = "STORED_VALUE_CARD";
    public static final String PROCESSED_AMOUNT        = "ProcessedAmount";
    public static final String AWAITING_CHARGE_INTERFACE_AMOUNT = "AwaitingChargeInterfaceAmount";

	// Order audit disabled
	public static final String ORDER_AUDIT_FILE_LOG_PATH = "order.audit.file.log.path";
	public static final String ORDER_AUDIT_FILE_WRITE_ENABLED = "order.audit.file.write.enabled";

	// tk id access
	public static final String SECURITY_AD_URL = "yfs.security.AD.url";
	public static final String SECURITY_AD_DOMAIN = "yfs.security.AD.domain";
	public static final String SECURITY_AD_TIMEOUT = "yfs.security.AD.timeout";
	public static final String SECURITY_AD_AUTH = "yfs.security.AD.auth";
	public static final String SECURITY_AD_FACTORY = "yfs.security.AD.factory";
	public static final String SECURITY_AD_MAX_PWDAGE = "yfs.security.AD.maxPwdAge";
	public static final String SECURITY_AD_PWD_EXP_DAYS= "yfs.security.AD.pwdExpNotificationDays";
	public static final String SECURITY_AD_URL_BACKUP = "yfs.security.AD.url.backup";
	public static final String SECURITY_AD_URL_PRIMARY = "yfs.security.AD.url.primary";
	public static final String SECURITY_AD_FALLBACKAUTH = "yfs.security.AD.fallBackAuth";
	public static final String SECURITY_AD_FALLBACK = "yfs.security.AD.fallBack";
	public static final String SECURITY_AD_CREDENTIALS = "yfs.security.AD.credentials.retry.eLDAP";
	public static final String SECURITY_LDAP_TIMEOUT = "yfs.security.ldap.timeout.property";
	public static final String SECURITY_TK_AD_DOMAIN = "yfs.security.TK.AD.domain";
	public static final String SECURITY_TK_AD_URL = "yfs.security.TK.AD.url";

	// Segment info to TVS - AGC-355
    public static final String CUSTOMER = "customer";
    public static final String SEGMENTS = "segments";
    public static final String SEGMENT = "segment";

 }
