package com.kohls.poc.rest;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.TreeMap;

import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsPoCRPUtil;
import com.kohls.util.webserviceUtil.FailoverUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


public class KohlsCallRPWrapper {
	public String strDomain = "";
	public String strFunction = "";
	public  String strReadTimeOut = "3000";
	public  String strConnectTimeOut = "3000";
	public  String strEndPoint = "";
	public String strQueryParam = "";
	public String strApiKey = "";
	public String strApiSecretKey = "";
	public  String jsonPayload = "";
	public  KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
	public String filePrefix;
	private String sFilePath="";
	private String source ="";
	private Properties props;
	FailoverUtil failoverUtil = FailoverUtil.getInstance();
	private static YFCLogCategory logger;
	private boolean bWriteToFile = true;
	private boolean bProxyRequired = false;
	private boolean bloggerDebugEnabled = false;
	//private String sStandAlone="N";

	private String strProxyHost = "";
	private int iProxyport = 0;
	private boolean boAuthNeeded = true;
	String activeEndpoint = "";
	public static final String RETRUN_RESTRICTION_CALL = "ReturnRestrictionCall";
	public static final String U_RESTRICTION_EP ="_RESTRICTION_EP";

	static {
		logger = YFCLogCategory.instance(KohlsCallRPWrapper.class
				.getName());
	}

	private  String accessToken = null;
	private int maxRetries = 1;
	private int count = 0;
	private boolean gotoCloud = false;
	private static HashMap <String, String> goToCloudMap = new HashMap<String, String>();  
	private KohlsPoCRPUtil rpUtil = new KohlsPoCRPUtil();
	String httpMethod = "";
	public Document callRPAPI(YFSEnvironment env,Document input)
			throws Exception {
		logger.beginTimer("KohlsCallRPWrapper.callRPAPI");
		if(logger.isDebugEnabled()) {
			bloggerDebugEnabled = true;
			logger.debug("KohlsCallRPWrapper.callRPAPI --- Input to callRPAPI" + XMLUtil.getXMLString(input));
		}

		Document output = null;
		boolean overrideMaxRetries = true;
		boolean updateReturnPass = false;
		//Get Key Common params from Input XML
		Element eleInDoc = input.getDocumentElement();
		source = eleInDoc.getAttribute(KohlsPOCConstant.E_SOURCE);
		strFunction = eleInDoc.getAttribute(KohlsPOCConstant.FUNCTION);
		//Check if Quick Return Pass available, else exit
		if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
				KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source))){
			if(!rpUtil.isReturnPassAvailable(eleInDoc)) {
				return input;
			}else{
				updateReturnPass = true;
			}
		}
		String sProxyRequired = KohlsPOCConstant.FALSE;
		String stroAuthNeeded = KohlsPOCConstant.TRUE;
		String terminalNo = eleInDoc.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
		String storeNumber = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_STORE_NO);
		if(YFCCommon.isVoid(storeNumber)){
			storeNumber = eleInDoc.getAttribute(KohlsXMLLiterals.A_STORE_NUMBER);
		}
		if(YFCCommon.isVoid(storeNumber)){
			storeNumber = eleInDoc.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE);
		}
		String strReturnPassNo = eleInDoc.getAttribute(KohlsPOCConstant.RETURN_PASS_NO);
		String transactionNo = null;
		if(!YFCCommon.isVoid(strReturnPassNo) && strReturnPassNo.length()>4){
			transactionNo = strReturnPassNo.substring(strReturnPassNo.length()-4);
		}else{
			transactionNo = eleInDoc.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
			if(YFCCommon.isVoid(transactionNo)){
				transactionNo = eleInDoc.getAttribute(KohlsXMLLiterals.TRANSACTION_NBR);
			}
		}

		strReadTimeOut = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_API_READTIMEOUT);
		strConnectTimeOut = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_API_CONNTIMEOUT);
		//Construct Payload
		if(KohlsPOCConstant.GET_RETURN_PASS_DETAILS.equalsIgnoreCase(source))
		{
			logger.debug("Processing GetReturnPassDetails input ::");
			httpMethod = KohlsPOCConstant.GET;
			String strPassCodeNo = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
			strEndPoint = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_PASSCODE_EP);
			jsonPayload = strPassCodeNo;
		}else if(updateReturnPass) {
			httpMethod = KohlsPOCConstant.POST_NOOUTPUT;
			jsonPayload = rpUtil.processUpdateReturnPassJSonInput(eleInDoc, source); 
			strEndPoint = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_UPDATE_STATUS_EP);
		}
		else if(RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))
		{
			httpMethod = KohlsPOCConstant.GET;
			jsonPayload = ""; 
			SimpleDateFormat sdf1 = new SimpleDateFormat("MMddHHmm");
			transactionNo = sdf1.format(YFCDateUtils.getCurrentDate(true));
			strEndPoint =YFSSystem.getProperty(strFunction+"_AUTH_CONFIG_EP");			
		}
		if(bloggerDebugEnabled) {
			logger.debug("payload is : "+jsonPayload);
		}

		filePrefix = source+"_"+storeNumber+"-"+terminalNo+"-"+transactionNo+".txt";
		try {
			sFilePath = props.getProperty("LogDir");
			restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
		} catch (Exception ex) {
			bWriteToFile = false;
			logger.error("Logger Dir does not exist. So moving on");
		}

		//Decide GoToCloud or not
		if(!failoverUtil.isEndpointMonitored(strFunction+KohlsPOCConstant.U_DOMAIN) || getGoAlwaysToCloudStoreRule(env,storeNumber, strFunction))
		{
			gotoCloud = true;
		}
		if(gotoCloud)
		{
			strDomain = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_DOMAIN+KohlsPOCConstant.STRING_DOT_BACKUP_ENDPOINT);
			if(YFCCommon.isVoid(strDomain))
			{
				strDomain = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_DOMAIN);
			}
			sProxyRequired = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_DOMAIN_PROXY_REQUIRED);
			if(YFCCommon.isVoid(sProxyRequired))
			{
				sProxyRequired = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_PROXY_REQUIRED);
			}
			bProxyRequired = Boolean.valueOf(sProxyRequired);
			activeEndpoint = KohlsPOCConstant.CLOUD;    
			if(overrideMaxRetries)
			{
				String strMaxRetries =  YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_RETRY_THRESHOLD);
				if(YFCCommon.isVoid(strMaxRetries))
				{
					maxRetries = 1;
				}
				else
				{
					maxRetries =Integer.parseInt(strMaxRetries); 
				}
			}
		}

		//Proxy Settings
		if(YFCCommon.isVoid(strDomain)) {
			strDomain = failoverUtil.getActiveEndPoint(strFunction+KohlsPOCConstant.U_DOMAIN);
			if(YFCCommon.isVoid(activeEndpoint)) 
			{
				activeEndpoint = failoverUtil.getCurrentActiveEndpoint(strFunction+KohlsPOCConstant.U_DOMAIN);
			}
			sProxyRequired = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_DOMAIN+"."+activeEndpoint+KohlsPOCConstant.D_PROXY_REQUIRED);
			bProxyRequired = Boolean.valueOf(sProxyRequired);
			stroAuthNeeded = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_DOMAIN+"."+activeEndpoint+KohlsPOCConstant.D_OAUTHNEEDED);
			boAuthNeeded = Boolean.valueOf(stroAuthNeeded);
		} 
		if(bProxyRequired) {
			strProxyHost = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_PROXY_HOST);
			if(YFCCommon.isVoid(strProxyHost)) {
				throw new YFSException ("Proxy is Required but no Proxy host is set");
			}
			String strProxyPort = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+KohlsPOCConstant.U_PROXY_PORT);
			if(YFCCommon.isVoid(strProxyPort)) {
				throw new YFSException ("Proxy is Required but no Proxy Port is set");
			}
			try {
				iProxyport = Integer.valueOf(strProxyPort);               
			} catch (Exception e) {
				logger.error("Incorrect Proxy port set: "+e.getMessage());
				throw new YFSException ("Incorrect Proxy port set");
			}
		}

		String strtempDomain = strDomain + strEndPoint;
		ResponseEntity<String> response = null;

		try {
			count++;

			//Header Creation - Setting Header Content
			TreeMap<String, String> mapHeader = new TreeMap<String, String>();               
			mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");
			if(KohlsPOCConstant.GET_RETURN_PASS_DETAILS.equalsIgnoreCase(source))
 			{
 				mapHeader.put("X-KOHLS-Passcode-Id", jsonPayload);	      
 			}
			//Update Header params
			final TreeMap<String, String> depHeaderMap = updateDepHeaderMap(
					env, storeNumber, terminalNo);

			//Call Rest Service
			response = restApiutil.createConnection(jsonPayload, mapHeader, depHeaderMap, strQueryParam, strtempDomain, strEndPoint, null,
					null,strReadTimeOut,strConnectTimeOut, null, httpMethod, bProxyRequired, strProxyHost, iProxyport);

			if(failoverUtil.isEndpointMonitored(strFunction+KohlsPOCConstant.U_DOMAIN) && !gotoCloud) {
				failoverUtil.resetFailedCounter(strFunction+KohlsPOCConstant.U_DOMAIN, activeEndpoint);
				logger.info("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+failoverUtil.getWsProperties());
				
				if(bWriteToFile)
				{
					try {
					restApiutil.writeToFile("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint,
							failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
				} catch (Exception ex) {
					bWriteToFile = false;
					logger.error("Logger Dir does not exist. So moving on");
				}
				}
			}

			//Process Response JSon to Output XML
			JSONObject json = null;
			if(response!=null) {
				if(response.getStatusCode().toString().equals(KohlsPOCConstant.HTTP_200))
				{
					String responseBody = response.getBody();
					if(!YFCCommon.isVoid(responseBody))
					{
						json = new JSONObject(responseBody);
						if(!YFCCommon.isVoid(json) && !YFCCommon.isVoid(json.toString()))
						{                  
							if(bWriteToFile)
							{
								try {
									restApiutil.writeToFile("Response from "+activeEndpoint+" endpoint is ----> \n",json.toString(),filePrefix,sFilePath);
								} catch (Exception ex) {
									bWriteToFile = false;
									logger.error("Logger Dir does not exist. So moving on");
								}
							}
							if(KohlsPOCConstant.GET_RETURN_PASS_DETAILS.equalsIgnoreCase(source)) {
								output = rpUtil.processGetReturnPassDetailsOutput(json.toString()); 
							}
							else if(KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source)) {
								output = rpUtil.processCompleteReturnPassOutput(json.toString()); 
							}
							else if(KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)) {
								output = rpUtil.processPostVoidReturnPassOutput(json.toString()); 
							}
							else if(RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source)) {
								output = rpUtil.processReturnRestrictionOutput(json.toString()); 
							}
						}
					}

				}              
			} 
		} catch (Exception e) {
			
			String errorCode = "";
			if(e instanceof YFSException) {
				errorCode = ((YFSException) e).getErrorCode();
			}
			if("401".equalsIgnoreCase(errorCode))
			{            	  
				logger.error("No Token in the request. probably a failover scenario");
				Document docAccessToken = XMLUtil.createDocument(KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
				Element eleDocAccessTokenRoot = docAccessToken.getDocumentElement();
				eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_MODULE, source);
				eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TOKEN_NAME, KohlsPOCConstant.O_AUTH_ACCESS_TOKEN);
				eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, storeNumber);
				eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, terminalNo);
				//Invoke Service To Get Access Token from table
				Document docAccessTokenList=KOHLSBaseApi.invokeService(env,KohlsPOCConstant.KOHLS_GET_O_AUTH_TOKEN_LIST, docAccessToken);
				String action =KohlsPOCConstant.A_CREATE;
				if(docAccessTokenList.getDocumentElement().hasChildNodes())
				{ 
					Element oAuthTokenEle = XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(), KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
					String expiryDate = oAuthTokenEle.getAttribute(KohlsPOCConstant.EXPIRY_DATE);
					String currentDate = getCurrSysDateAsString();
					SimpleDateFormat sdf1 = new SimpleDateFormat(
							KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
					if(!isAfter(sdf1.format(sdf1.parse(expiryDate)),currentDate))
					{
						Element oAuthAccessToken =  XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(),KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
						String oAuthAccessTokenKey=
								oAuthAccessToken.getAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY);
						docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY, 
								oAuthAccessTokenKey);
						try
						{                      
							accessToken = fetchAndUpdateAccessToken(env,docAccessToken, null);
						}
						catch (Exception ee)
						{ 
							logger.error("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
							if(bWriteToFile)
							{
								try {
									restApiutil.writeToFile("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint,
											failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
								} catch (Exception ex) {
									bWriteToFile = false;
									logger.error("Logger Dir does not exist. So moving on");
								}
							}
							if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
									KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)
									|| RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))){
								
									return output;
							}
							else
							{
								throw new YFSException(e.getMessage());
							}
						}
					}
					else
					{
						accessToken = oAuthTokenEle.getAttribute(KohlsPOCConstant.TOKEN_VALUE);
						if(bWriteToFile)
						{
							try {
								restApiutil.writeToFile("Token exists ----> \n",accessToken,filePrefix,sFilePath);
							} catch (Exception ex) {
								bWriteToFile = false;
								logger.error("Logger Dir does not exist. So moving on");
							}
						}
						
					}
				}
				else
				{
					try
					{                      
						accessToken = fetchAndUpdateAccessToken(env,docAccessToken, action);
					}
					catch (Exception ee)
					{   
						logger.error("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
						if(bWriteToFile)
						{
							try {
								restApiutil.writeToFile("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint,
										failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
							} catch (Exception ex) {
								bWriteToFile = false;
								logger.error("Logger Dir does not exist. So moving on");
							}
						}
						if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
								KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)
								|| RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))){
							
								return output;
						}
						else
						{
							throw new YFSException(e.getMessage());
						}
					}
				}                             
				output = callRPAPI(env, input);                  
			}
			else
			{
				
				Throwable tmp = e;
				boolean bNeedToRetry = false;
				if(bWriteToFile)
				{
					try {
						restApiutil.writeToFile("Error while calling "+activeEndpoint+" endpoint and the error is ----> \n",e.toString(),filePrefix,sFilePath);
					} catch (Exception ex) {
						bWriteToFile = false;
						logger.error("Logger Dir does not exist. So moving on");
					}	
				}
				if ( !errorFromoAuth && tmp.getCause() instanceof java.io.IOException
						|| tmp.getCause() instanceof java.net.SocketTimeoutException
						|| tmp.getCause() instanceof java.net.ConnectException
						|| tmp.getCause() instanceof java.net.NoRouteToHostException 
						|| tmp.getCause() instanceof java.net.UnknownHostException
						|| tmp.getCause() instanceof java.lang.IllegalArgumentException
						|| "503".equalsIgnoreCase(errorCode)
						|| "500".equalsIgnoreCase(errorCode)
						|| "404".equalsIgnoreCase(errorCode)
						|| "CONNECTERROR".equalsIgnoreCase(errorCode)) {
					logger.error("Exception occured while calling "+KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+" for the source "+source+" and the error is ---> "+e.toString());
					// Failover framework
					if(failoverUtil.isEndpointMonitored(strFunction+KohlsPOCConstant.U_DOMAIN) && !gotoCloud) {
						failoverUtil.compareAndIncrementCounters(strFunction+KohlsPOCConstant.U_DOMAIN, activeEndpoint);
						if ("PRIMARY".equalsIgnoreCase(activeEndpoint)) {
							logger.error("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+failoverUtil.getWsProperties());
							if(bWriteToFile)
							{
								try {
									restApiutil.writeToFile("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint,
											failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
								} catch (Exception ex) {
									bWriteToFile = false;
									logger.error("Logger Dir does not exist. So moving on");
								}
							}
							strDomain = failoverUtil.getBackupEndpoint(strFunction+KohlsPOCConstant.U_DOMAIN);                         
							if(!YFCCommon.isVoid(strDomain)) {
								activeEndpoint = "BACKUP";
								sProxyRequired = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_DOMAIN+"."+activeEndpoint+KohlsPOCConstant.D_PROXY_REQUIRED);
								bProxyRequired = Boolean.valueOf(sProxyRequired);
								stroAuthNeeded = YFSSystem.getProperty(strFunction+KohlsPOCConstant.U_DOMAIN+"."+activeEndpoint+KohlsPOCConstant.D_OAUTHNEEDED);
								boAuthNeeded = Boolean.valueOf(stroAuthNeeded);
								output = callRPAPI(env, input);
							} else {
								if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
										KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)
										|| RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))){
									
										return output;
								}
								else
								{
									throw new YFSException(e.getMessage());
								}
							}
						} else {
							logger.error("KohlsCallRPWrapper.callRPAPII failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
							if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
									KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)
									|| RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))){
								
									return output;
							}
							else
							{
								throw new YFSException(e.getMessage());
							}
						}
					} else {	    
						logger.error("KohlsCallRPWrapper.callRPAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
						if (count != maxRetries) {
							bNeedToRetry = true;
						}
						else
						{
							if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
									KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)
									|| RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))){
								
									return output;
							}
							else
							{
								throw new YFSException(e.getMessage());
							}
						}	
					}
				} else {	   					
					if((KohlsPOCConstant.COMPLETE_RETURN_PASS.equalsIgnoreCase(source) ||
							KohlsPOCConstant.POST_VOID_RETURN_PASS.equalsIgnoreCase(source)
							|| RETRUN_RESTRICTION_CALL.equalsIgnoreCase(source))){
						
							return output;
					}
					else
					{
						throw new YFSException(e.getMessage());
					}
					
				}

				if (bNeedToRetry) {
					logger.error("********** Retrying the RP Request again *********");
					output = callRPAPI(env, input);
				}
			}
		} 
		logger.endTimer("KohlsCallRPWrapper.callRPAPI");
		return output;
	}

	/**
	 * @param env
	 * @param storeNumber
	 * @param terminalNo
	 * @return
	 * @throws Exception
	 */
	public TreeMap<String, String> updateDepHeaderMap(YFSEnvironment env,
			String storeNumber, String terminalNo) throws Exception {
		SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
		final TreeMap<String, String> depHeaderMap = new TreeMap<String, String>();
		depHeaderMap.put("X-KOHLS-CreateDateTime", dateFormatGmt.format(new Date()));
		depHeaderMap.put("X-KOHLS-From-SystemCode", KohlsPOCConstant.POC_DEVICE_CODE);
		depHeaderMap.put("X-KOHLS-MessageID", restApiutil.getUUID());
		depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
		//depHeaderMap.put("X-APP-API-KEY", "AAP_KEY");
		if((!ServerTypeHelper.amIOnTrainingServer() && boAuthNeeded) 
				|| !YFCCommon.isVoid(accessToken))
		{
			depHeaderMap.put("Authorization",
					getAuthorizationHeaderForAccessToken(env,source,storeNumber,terminalNo,accessToken));
		}
		return depHeaderMap;
	}

	public static String getCurrSysDateAsString() {
		logger.beginTimer("KohlsCallRPWrapper.getCurrSysDateAsString");
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
		String str = sdf.format(yfcCurrntDt);
		logger.endTimer("KohlsCallRPWrapper.getCurrSysDateAsString");
		return str;
	}

	/**
	 * Compares 2 dates
	 * 
	 * @returns the flaf
	 */
	public static boolean isAfter(String strDate1, String strDate2) {
		logger.beginTimer("KohlsReprocessRequestUtil.isAfter");
		boolean isBefore = false;
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		Date date1;
		Date date2;
		try {
			date1 = sdf.parse(strDate1);
			date2 = sdf.parse(strDate2);
			if (date1.after(date2)) {
				isBefore = true;
			}
		} catch (Exception e) {
			//e.printStackTrace();
			logger.debug("Inside isAfter - Error while parsing the dates " +e.getMessage());
		}
		logger.endTimer("KohlsReprocessRequestUtil.isAfter");
		return isBefore;
	}

	public String getAuthorizationHeaderForAccessToken(YFSEnvironment env, String source, String storeNumber, String terminalNo, String accessToken) throws Exception {

		if(!YFCCommon.isVoid(accessToken))
		{
			return "Bearer" + " " + accessToken;
		}
		Document docAccessToken = XMLUtil.createDocument(KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
		Element eleDocAccessTokenRoot = docAccessToken.getDocumentElement();
		eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_MODULE, source);

		eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TOKEN_NAME, KohlsPOCConstant.O_AUTH_ACCESS_TOKEN);
		if(!YFCCommon.isVoid(storeNumber))
		{
			eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, storeNumber);
		}
		if(!YFCCommon.isVoid(terminalNo))
		{
			eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, terminalNo);
		}
		//Invoke Service To Get Damage Reason Codes
		Document docAccessTokenList=KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_GET_O_AUTH_TOKEN_LIST, docAccessToken);
		String currentDate = getCurrSysDateAsString();
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		if(!docAccessTokenList.getDocumentElement().hasChildNodes())
		{
			accessToken = fetchAndUpdateAccessToken(env,docAccessToken,KohlsPOCConstant.A_CREATE);
		}
		else
		{
			Element oAuthTokenEle = XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(), KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
			String expiryDate = oAuthTokenEle.getAttribute(KohlsPOCConstant.EXPIRY_DATE);
			if(!isAfter(sdf.format(sdf.parse(expiryDate)),currentDate))
			{
				Element oAuthAccessToken =  XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(),KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
				String oAuthAccessTokenKey=
						oAuthAccessToken.getAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY);
				docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY, 
						oAuthAccessTokenKey);
				accessToken = fetchAndUpdateAccessToken(env,docAccessToken, null);
			}
			else
			{       	 	
				accessToken = oAuthTokenEle.getAttribute(KohlsPOCConstant.TOKEN_VALUE);
				if(bWriteToFile)
				{
					try {
						restApiutil.writeToFile("Token exists ----> \n",accessToken,filePrefix,sFilePath);
					} catch (Exception ex) {
						bWriteToFile = false;
						logger.error("Logger Dir does not exist. So moving on");
					}
				}
			}       

		}

		logger.debug("strTokenValue"+accessToken);
		logger.endTimer("KohlsCallRPWrapper.processDispoManageRespo");
		return "Bearer" + " " + accessToken;
	}

	private void createAccessToken(YFSEnvironment env, Document docAccessToken) throws Exception 
	{
		logger.beginTimer("KohlsCallRPWrapper.createAccessToken");
		KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_CREATE_O_AUTH_TOKEN, docAccessToken);
		logger.endTimer("KohlsCallRPWrapper.createAccessToken");
	}

	private void updateAccessToken(YFSEnvironment env, Document docAccessToken) throws Exception 
	{
		logger.beginTimer("KohlsCallRPWrapper.updateAccessToken");
		KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_MODIFY_O_AUTH_TOKEN, docAccessToken);
		logger.endTimer("KohlsCallRPWrapper.updateAccessToken");
	}

	private String fetchAndUpdateAccessToken(YFSEnvironment env, Document docAccessToken, String action) throws Exception 
	{
		logger.beginTimer("KohlsCallRPWrapper.fetchAndUpdateAccessToken");
		Map accessToken = fetchAccessToken();
		String strAccessToken = (String)accessToken.get(KohlsPOCConstant.ACCESS_TOKEN);
		if(bWriteToFile)
		{
			try {
				restApiutil.writeToFile("New Token fetched ----> \n",strAccessToken,filePrefix,sFilePath);
			} catch (Exception ex) {
				bWriteToFile = false;
				logger.error("Logger Dir does not exist. So moving on");
			}
		}
		String expires_in = (String)accessToken.get(KohlsPOCConstant.EXPIRY_IN);
		docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.TOKEN_VALUE, strAccessToken);
		String currentDate = getCurrSysDateAsString();
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		Date expiryDate = KohlsDateUtil.addToDate(sdf.parse(currentDate), Calendar.SECOND,Integer.valueOf(expires_in));
		docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.EXPIRY_DATE, sdf.format(expiryDate));
		if(KohlsPOCConstant.A_CREATE.equalsIgnoreCase(action))
		{
			createAccessToken(env,docAccessToken);
		}
		else
		{
			updateAccessToken(env,docAccessToken);
		}

		logger.endTimer("KohlsCallRPWrapper.fetchAndUpdateAccessToken");
		return strAccessToken;
	}
	int ouAthCount=0;
	private boolean errorFromoAuth = false;
	private Map fetchAccessToken() throws Exception 
	{
		logger.beginTimer("KohlsCallRPWrapper.fetchAccessToken");
		String strEndPoint = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+"_ENDPOINT_OAUTH");
		String clientID = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+"_APIKEY_OAUTH");
		String enCryptedSecret = YFSSystem.getProperty(KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER+"_APISECRET_OAUTH");
		String grantType = KohlsPOCConstant.GRANT_TYPE_CLIENT_CREDENTIALS;
		String Scope = KohlsPOCConstant.SCOPE_VALUE;
		String oAuthURL = strDomain + strEndPoint;
		try
		{
			ouAthCount++;
			Map accessTokenMap  = restApiutil.getNewAccessToken(oAuthURL, clientID, enCryptedSecret, Scope, grantType,
					strReadTimeOut,strConnectTimeOut,bProxyRequired,strProxyHost,iProxyport, KohlsPOCConstant.RP_CUSTMGR_IDENTIFIER);
			logger.endTimer("KohlsCallRPWrapper.fetchAccessToken");
			return accessTokenMap;
		}
		catch(Exception ee)
		{
			if(bWriteToFile)
			{
				try {
					restApiutil.writeToFile("Error while calling oAuth and the error is ----> \n",ee.toString(),filePrefix,sFilePath);
				} catch (Exception ex) {
					bWriteToFile = false;
					logger.error("Logger Dir does not exist. So moving on");
				}
			}
			errorFromoAuth = true;
			if( ee instanceof org.apache.http.conn.ConnectTimeoutException
					|| ee instanceof java.net.SocketTimeoutException)
			{
				logger.error("Exception while connecting to ReturnsPlatform using "+activeEndpoint+" to fetch access Token and the error is "+ee.toString());
				if(failoverUtil.isEndpointMonitored(strFunction+KohlsPOCConstant.U_DOMAIN) && !gotoCloud) {
					failoverUtil.compareAndIncrementCounters(strFunction+KohlsPOCConstant.U_DOMAIN, activeEndpoint);
				}              
				if(ouAthCount != maxRetries)
				{
					Map accessTokenMap  = fetchAccessToken();
					return accessTokenMap;
				}
				else
				{
					throw ee;
				}	        		
			}
			throw ee;
		}
	}

	/**
	 * Create By ibmadmin * 
	 * @param property
	 * @return
	 */
	public String getPropertyValue(String property) {
		logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
		return propValue;

	}

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}

	public boolean getGoAlwaysToCloudStoreRule(YFSEnvironment env, String storeNumber, String domain) throws Exception {
		logger.beginTimer("KohlsCallRPWrapper.getGoAlwaysToCloudStoreRule");

		boolean goAlwaystoCloud = false;
		String sRuleVal= "";
		if(!YFCCommon.isVoid(storeNumber)){
			storeNumber = Integer.valueOf(storeNumber).toString();
		}
		if(!YFCCommon.isVoid(goToCloudMap) && !goToCloudMap.isEmpty() && goToCloudMap.containsKey(storeNumber)){
			sRuleVal = goToCloudMap.get(storeNumber); 
			if(KohlsPOCConstant.YES.equalsIgnoreCase(sRuleVal))
			{
				goAlwaystoCloud = true;
			}
		}
		else{
			Document docRule = SCXmlUtil.createDocument(KohlsPOCConstant.E_RULE);
			Element eleInput = docRule.getDocumentElement();
			eleInput.setAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE, storeNumber);
			eleInput.setAttribute(KohlsPOCConstant.A_RULE_ID, KohlsPOCConstant.RP_GO_TO_CLOUD);
			Document docOutRule=
					KohlsCommonUtil.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docRule);
			if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(docOutRule)) {
				logger.debug("Rule out put xml : " + SCXmlUtil.getString(docOutRule));
			}
			if (!YFCCommon.isVoid(docOutRule) && docOutRule.getDocumentElement().hasChildNodes()) {
				Element eleRuleval= (Element) docOutRule.getDocumentElement()
						.getElementsByTagName(KohlsPOCConstant.E_RULE).item(0);                   
				if(logger.isDebugEnabled()) {
					logger.debug("KohlsCallRPWrapper.getGoAlwaysToCloudStoreRule ---Element is  "+XMLUtil.getElementXMLString(eleRuleval));
				}
				sRuleVal=eleRuleval.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
				if(logger.isDebugEnabled()) {
					logger.debug("KohlsCallRPWrapper.getGoAlwaysToCloudStoreRule Rule value is "+sRuleVal);
				}
				goToCloudMap.put(storeNumber, sRuleVal);
				if(KohlsPOCConstant.YES.equalsIgnoreCase(sRuleVal))
				{
					goAlwaystoCloud = true;
				}
			}
		}
		logger.endTimer("KohlsCallRPWrapper.getGoAlwaysToCloudStoreRule");
		return goAlwaystoCloud;
	}
}
