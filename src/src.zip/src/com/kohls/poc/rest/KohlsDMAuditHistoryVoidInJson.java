package com.kohls.poc.rest;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;



	public class KohlsDMAuditHistoryVoidInJson {
		
		private String auditDate;
		private String device;
		private Long storeNumber;
		
		public String getauditDate() {
			return auditDate;
		}

		public void setauditDate(String auditDate) {
			this.auditDate = auditDate;
		}
		
		public String getdevice() {
			return device;
		}

		public void setdevice(String device) {
			this.device = device;
		}
		
		public Long getstoreNumber() {
			return storeNumber;
		}

		public void setstoreNumber(Long storeNumber) {
			this.storeNumber = storeNumber;
		}
		
		@SerializedName("bulkSkus")
		@Expose
		private List<BulkSkus> bulkSkus = null;

		public List<BulkSkus> getBulkSkus() {
			return bulkSkus;
		}
		
		public void setBulkSkus(List<BulkSkus> bulkSkus) {
			this.bulkSkus = bulkSkus;
		}

		public class BulkSkus {

			@SerializedName("auditID")
			@Expose
			private String auditID;
			
			@SerializedName("sku")
			@Expose
			private Long sku;
			
			@SerializedName("markdownPercentage")
			@Expose
			private Float markdownPercentage;
			
			@SerializedName("markedDownPrice")
			@Expose
			private Float markedDownPrice;
			
			@SerializedName("originalPrice")
			@Expose
			private Float originalPrice;
			
			public String getauditID() {
				return auditID;
			}

			public void setauditID(String auditID) {
				this.auditID = auditID;
			}
			
			public Long getsku() {
				return sku;
			}

			public void setsku(Long sku) {
				this.sku = sku;
			}
			
			public Float getmarkdownPercentage() {
				return markdownPercentage;
			}

			public void setmarkdownPercentage(Float markdownPercentage) {
				this.markdownPercentage = markdownPercentage;
			}
			
			public Float getmarkedDownPrice() {
				return markedDownPrice;
			}

			public void setmarkedDownPrice(Float markedDownPrice) {
				this.markedDownPrice = markedDownPrice;
			}
			
			public Float getoriginalPrice() {
				return originalPrice;
			}

			public void setoriginalPrice(Float originalPrice) {
				this.originalPrice = originalPrice;
			}

			
		}

	}
