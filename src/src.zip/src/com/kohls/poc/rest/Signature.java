package com.kohls.poc.rest;



//import org.apache.commons.lang3.StringUtils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;



/**
 * @author tkmay02
 * @since 6/3/15
 */
public class Signature {

    private final String requestSignature;
    public KohlsRestAPIUtil restApiUtil= new KohlsRestAPIUtil();
    private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(Signature.class.getName());
	}
	
    public Signature(final Builder builder) {
        this.requestSignature = builder.requestSignature;
    }

    public String getRequestSignature() {
        return requestSignature;
    }
    

    /**
     * Builder class to build and sign Authorization header. Method calls
     * {@link com.kohls.marketing.authentication.commons.HashUtils#createHash(String)} to hash request payload
     *
     */
    public   static class Builder{
        private String apiSecret;
        private String endpoint;
        private String apiKey;
        private String method;
        private String isoDate;
        private String depHeaders;
        private String mediaType;
        private String payload;
        private String queryParams;
        private String requestSignature;

        public Builder apiSecret(final String apiSecret){
            this.apiSecret = apiSecret;
            return this;
        }

        public Builder endpoint(final String endpoint){
            this.endpoint = endpoint;
            return this;
        }

        public Builder apiKey(final String apiKey){
            this.apiKey = apiKey;
            return this;
        }

        public Builder method(final String method){
            this.method = method;
            return this;
        }

        public Builder isoDate(final String isoDate){
            this.isoDate = isoDate;
            return this;
        }

        public Builder depHeaders(final String depHeaders){
            this.depHeaders = depHeaders;
            return this;
        }

        public Builder mediaType(final String mediaType){
            this.mediaType = mediaType;
            return this;
        }

        public Builder payload(final String payload){
            this.payload = payload;
            return this;
        }

        public Builder queryParams(final String queryParams){
            this.queryParams = queryParams;
            return this;
        }

        public Signature buildLCSSignature() throws Exception{
        	
        	
            Assert.hasText(this.apiSecret);
            Assert.hasText(this.endpoint);
            Assert.hasText(this.apiKey);
            Assert.hasText(this.method);
            Assert.hasText(this.isoDate);
           // Assert.hasText(this.depHeaders);
            Assert.hasText(this.mediaType);
            final StringBuilder stringBuffer = new StringBuilder();
            stringBuffer
            .append(KohlsRestAPIUtil.createHash(payload))
            .append(mediaType).append(KohlsPOCConstant.NEW_LINE)
            .append(method).append(KohlsPOCConstant.NEW_LINE)
            .append(endpoint).append(KohlsPOCConstant.NEW_LINE)
            .append(isoDate).append(KohlsPOCConstant.NEW_LINE)
            .append(depHeaders);
            if(StringUtils.isNotEmpty(queryParams)){
                stringBuffer.append(queryParams).append(KohlsPOCConstant.NEW_LINE);
            }
            logger.debug("The signature is : "+stringBuffer.toString());
            logger.debug("The Payload is : "+payload);
            requestSignature = KohlsRestAPIUtil.createSignature(stringBuffer.toString(), apiSecret);
            return new Signature(this);
        }
        


        public Signature build() throws Exception{
        	
        	
            Assert.hasText(this.apiSecret);
            Assert.hasText(this.endpoint);
            Assert.hasText(this.apiKey);
            Assert.hasText(this.method);
            Assert.hasText(this.isoDate);
            Assert.hasText(this.depHeaders);
            Assert.hasText(this.mediaType);
            final StringBuilder stringBuffer = new StringBuilder();
            stringBuffer.append(apiKey).append(KohlsPOCConstant.NEW_LINE)
                    .append(isoDate).append(KohlsPOCConstant.NEW_LINE)
                    .append(method).append(KohlsPOCConstant.NEW_LINE)
                    .append(KohlsRestAPIUtil.createHash(payload))
                    .append(mediaType).append(KohlsPOCConstant.NEW_LINE)
                    .append(depHeaders)
                    .append(endpoint).append(KohlsPOCConstant.NEW_LINE);
            
//                    .append(queryParams).append(KohlsPOCConstant.NEW_LINE);
            if(StringUtils.isNotEmpty(queryParams)){
                stringBuffer.append(queryParams).append(KohlsPOCConstant.NEW_LINE);
            }
           
            logger.debug("The signature is : "+stringBuffer.toString());
            logger.debug("The Payload is : "+payload);
            requestSignature = KohlsRestAPIUtil.createSignature(stringBuffer.toString(), apiSecret);
	logger.debug("The requestSignature is : "+requestSignature.toString());

            return new Signature(this);
        }



    }
}
