package com.kohls.poc.rest;

import com.google.gson.Gson;
import com.kohls.common.util.KOHLSStringUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.net.URL;
import java.util.List;
import java.util.Properties;

import static com.kohls.poc.rest.KohlsCustomerIdentificationTool.decryptSecret;
import static com.kohls.poc.rest.KohlsCustomerIdentificationTool.getResponseWithRetry;

public class KohlsRewardsLookupServiceImpl {
    private static YFCLogCategory logger;

    private static YFCLogCategory getLogger() {
        if (logger == null)
            logger = YFCLogCategory.instance(KohlsRewardsLookupServiceImpl.class.getName());
        return logger;
    }

    /**
     * Get customer list from account services.... lookup all customers based on several different lookup keys
     *
     * @param request The API Input XML
     * @param props   The properties set from OMS
     * @return The API Output XML
     */

    public Document getCustomerList(Document request, Properties props, int maxTries) throws Exception {

        LookupKey lookupKey = this.extractKey(request);
        String body = "{\"value\":\"" + lookupKey.value + "\"}";

        String storeNumber = KohlsCustomerIdentificationTool.extractStoreNumber(request);

        String urlSource = props.getProperty("KR_LOOKUP_BASE_URL") + "?alias=" + lookupKey.alias;
        URL url = new URL(urlSource);
        String path = url.getPath();

        props.setProperty("API_PATH", path + "?alias=" + lookupKey.alias);
        props.setProperty("API_KEY", props.getProperty("KR_LOOKUP_API_KEY"));
        if (props.containsKey("KR_LOOKUP_API_SECRET_DECRYPTED")) {
            props.setProperty("API_SECRET", props.getProperty("KR_LOOKUP_API_SECRET_DECRYPTED"));
        } else {
            String encryptedSecret = props.getProperty("KR_LOOKUP_API_SECRET");
            String decryptedSecret = decryptSecret(encryptedSecret);
            props.setProperty("API_SECRET", decryptedSecret);
        }
        props.setProperty("READ_TIMEOUT", props.getProperty("KR_LOOKUP_TIMEOUT"));
        props.setProperty("CONNECT_TIMEOUT", "4000");

        ResponseEntity<String> response = getResponseWithRetry(props, maxTries, body, storeNumber, urlSource);
        return this.createResponse(response);
    }


    /**
     * Generate the response XML document given the REST response json.
     *
     * @param response The Rest template response
     * @return The API Output XML
     * @throws Exception Any Problem.
     */
    private Document createResponse(ResponseEntity<String> response) throws Exception {
        Gson gson = new Gson();
        ResponseBody responseBody = gson.fromJson(response.getBody(), ResponseBody.class);

        Document document = XMLUtil.createDocument("CustomerList");
        Element customerList = document.getDocumentElement();


        for (CustomerResponse customer : responseBody.customers) {

            // Add customer Element
            Element custElement = XMLUtil.createChild(customerList, "Customer");

            // Customer Attributes
            custElement.setAttribute("PilotMember", customer.pilotStatus ? "Y" : "N");
            if (customer.segments != null) {
                StringBuilder sb = new StringBuilder();
                for (String segment : customer.segments) {
                    sb.append(segment);
                    sb.append(",");
                }
                if (sb.length() > 0)
                    sb.deleteCharAt(sb.length() - 1);
                String segments = sb.toString();

                custElement.setAttribute("Segments", segments);
            }
            custElement.setAttribute("ExistingEarnTrackerBal", customer.existingEarnTrackerBal);

            // add kohls cash elements
            if (customer.kohlsCash != null && customer.kohlsCash.size() > 0) {

                Element cashList = XMLUtil.createChild(custElement, "KohlsCashList");
                for (KohlsCashInfo kohlsCash : customer.kohlsCash) {

                    Element cash = XMLUtil.createChild(cashList, "KohlsCash");
                    cash.setAttribute("Barcode", kohlsCash.barcode);
                    cash.setAttribute("RedemptionStartDate", kohlsCash.redemptionStartDate);
                    cash.setAttribute("RedemptionEndDate", kohlsCash.redemptionEndDate);
                    cash.setAttribute("RemainingValue", kohlsCash.remainingValue);
                    cash.setAttribute("EventTypeCode", kohlsCash.eventTypeCode);
                }
            }

            Element ccListElement = XMLUtil.createChild(custElement, "CustomerContactList");
            Element eleCustomerContact = XMLUtil.createChild(ccListElement, "CustomerContact");

            Element eleExtn = XMLUtil.createChild(eleCustomerContact, "Extn");
            Element addressList = XMLUtil.createChild(eleCustomerContact, "CustomerAdditionalAddressList");
            Element address = XMLUtil.createChild(addressList, "CustomerAdditionalAddress");
            Element elePersonInfo = XMLUtil.createChild(address, "PersonInfo");


            if (customer.loyaltyId != null) {
                custElement.setAttribute("CustomerRewardsNo", customer.loyaltyId);

                if (customer.customerName.loyalty != null) {
                    if (customer.customerName.loyalty.first != null) {
                        eleCustomerContact.setAttribute(
                                "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.first));
                        elePersonInfo.setAttribute(
                                "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.first));
                    }
                    if (customer.customerName.loyalty.last != null) {
                        eleCustomerContact.setAttribute(
                                "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.last));
                        elePersonInfo.setAttribute(
                                "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.last));
                    }
                    if (customer.customerName.loyalty.middle != null) {
                        eleCustomerContact.setAttribute(
                                "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.middle));
                        elePersonInfo.setAttribute(
                                "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.middle));
                    }
                    if (customer.customerName.loyalty.professionalTitle != null) {
                        eleCustomerContact.setAttribute(
                                "jobTitle", customer.customerName.loyalty.professionalTitle);
                        elePersonInfo.setAttribute(
                                "jobTitle", customer.customerName.loyalty.professionalTitle);
                    }
                }
                if (customer.phoneNumber.loyalty != null) {
                    eleCustomerContact.setAttribute("DayPhone", customer.phoneNumber.loyalty);
                }
                if (customer.addressLine1.loyalty != null) {
                    elePersonInfo.setAttribute("AddressLine1", customer.addressLine1.loyalty);
                }
                if (customer.postalCode.loyalty != null) {
                    elePersonInfo.setAttribute("ZipCodeLoyalty", customer.postalCode.loyalty);
                    elePersonInfo.setAttribute("ZipCode", customer.postalCode.loyalty);
                }
                if (customer.postalCode.kohlsCharge != null) {
                    elePersonInfo.setAttribute("ZipCodeKohlsCharge", customer.postalCode.kohlsCharge);
                }
                if (customer.postalCode.ecom != null) {
                    elePersonInfo.setAttribute("ZipCodeEcom", customer.postalCode.ecom);
                }
                if (customer.customerName.kohlsCharge != null
                        && customer.customerName.kohlsCharge.first != null) {
                    eleExtn.setAttribute("ExtnKohlsCharge", "Y");
                } else {
                    eleExtn.setAttribute("ExtnKohlsCharge", "N");
                }

                eleExtn.setAttribute("ExtnNameSource", "R");
                eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
                eleExtn.setAttribute("ExtnRewardsStatus", "Y");
                eleExtn.setAttribute("ExtnLoyaltyPointTotal", "");
                eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
                eleExtn.setAttribute("ExtnMVCStatusSrc", "R");
                eleExtn.setAttribute("ExtnRewardsStatusSrc", "R");

                if (!YFCCommon.isVoid(customer.kohlsCash) && customer.kohlsCash.size() > 0) {

                    for (KohlsCashInfo kohlsCashDetails : customer.kohlsCash) {
                        XMLUtil.createChild(eleExtn, "ExtnKohlsCash");

                        eleExtn.setAttribute("Barcode", kohlsCashDetails.barcode);
                        eleExtn.setAttribute("RedemptionStartDate", kohlsCashDetails.redemptionStartDate);
                        eleExtn.setAttribute("RedemptionEndDate", kohlsCashDetails.redemptionEndDate);
                        eleExtn.setAttribute("RemainingValue", kohlsCashDetails.remainingValue);
                    }
                }
            } else {
                eleExtn.setAttribute("ExtnRewardsStatusSrc", "N");
                eleExtn.setAttribute("ExtnRewardsStatus", "N");

                if (customer.customerName.kohlsCharge != null) {
                    if (customer.customerName.kohlsCharge.first != null) {
                        eleCustomerContact.setAttribute(
                                "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.first));
                        elePersonInfo.setAttribute(
                                "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.first));
                    }
                    if (customer.customerName.kohlsCharge.last != null) {
                        eleCustomerContact.setAttribute(
                                "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.last));
                        elePersonInfo.setAttribute(
                                "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.last));

                    }
                    if (customer.customerName.kohlsCharge.middle != null) {
                        eleCustomerContact.setAttribute(
                                "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.middle));
                        elePersonInfo.setAttribute(
                                "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.middle));
                    }
                    if (customer.customerName.kohlsCharge.professionalTitle != null) {
                        eleCustomerContact.setAttribute(
                                "jobTitle", customer.customerName.kohlsCharge.professionalTitle);
                        elePersonInfo.setAttribute(
                                "jobTitle", customer.customerName.kohlsCharge.professionalTitle);
                    }
                }
                if (customer.phoneNumber.kohlsCharge != null) {
                    eleCustomerContact.setAttribute("DayPhone", customer.phoneNumber.kohlsCharge);
                }
                if (customer.addressLine1.kohlsCharge != null) {
                    elePersonInfo.setAttribute("AddressLine1", customer.addressLine1.kohlsCharge);
                }
                if (customer.postalCode.kohlsCharge != null) {
                    elePersonInfo.setAttribute("ZipCode", customer.postalCode.kohlsCharge);
                }
                eleExtn.setAttribute("ExtnKohlsCharge", "Y");
                eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
                eleExtn.setAttribute("ExtnLoyaltyPointTotal", "");
                eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "K");
                eleExtn.setAttribute("ExtnMVCStatusSrc", "K");
                eleExtn.setAttribute("ExtnNameSource", "K");
            }

            if (customer.kohlsChargeMvcIndicator) {
                eleExtn.setAttribute("ExtnMVCStatus", "Y");
                if (customer.loyaltyId != null) {
                    eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
                    eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "R");
                } else {
                    eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
                    eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
                }
            } else {
                eleExtn.setAttribute("ExtnMVCStatus", "N");
            }
            if (customer.customerName.kohlsCharge != null
                    || customer.addressLine1.kohlsCharge != null
                    || customer.postalCode.kohlsCharge != null
                    || customer.phoneNumber.kohlsCharge != null) {
                eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
                eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "R");
            } else {
                eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
                eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
            }

            if (!YFCCommon.isVoid(customer.associateDiscountID)) {
                custElement.setAttribute("CustomerAssociateNo", customer.associateDiscountID);
                custElement.setAttribute("AssociateId", customer.associateDiscountID);
            } else {
                custElement.setAttribute("CustomerAssociateNo", "");
                custElement.setAttribute("AssociateId", "");
            }
            if (!YFCCommon.isVoid(customer.emailAddress.eReceipt)) {
                eleCustomerContact.setAttribute("EmailID", customer.emailAddress.eReceipt);
            } else if (!YFCCommon.isVoid(customer.emailAddress.ecom)) {
                eleCustomerContact.setAttribute("EmailID", customer.emailAddress.ecom);
            } else if (!YFCCommon.isVoid(customer.emailAddress.kohlsCharge)) {
                eleCustomerContact.setAttribute("EmailID", customer.emailAddress.kohlsCharge);
            } else if (!YFCCommon.isVoid(customer.emailAddress.loyalty)) {
                eleCustomerContact.setAttribute("EmailID", customer.emailAddress.loyalty);
            } else {
                eleCustomerContact.setAttribute("EmailID", "");
            }
            if (!YFCCommon.isVoid(customer.associateDiscountID)) {
                eleExtn.setAttribute("ExtnIsEmployee", "Y");
                eleExtn.setAttribute("ExtnCustomerAssociateNo", customer.associateDiscountID);
            } else {
                eleExtn.setAttribute("ExtnIsEmployee", "N");
                eleExtn.setAttribute("ExtnCustomerAssociateNo", customer.associateDiscountID);
            }


            if (customer.sephora != null) {
                Element sephora = document.createElement("SephoraCustomerDetails");
                sephora.setAttribute("RewardsId", customer.sephora.rewardsId);
                sephora.setAttribute("RewardsEmail", customer.sephora.rewardsEmail);
                String balance = String.valueOf(Math.round(customer.sephora.rewardsPointBalance));
                sephora.setAttribute("RewardsBalance", balance);
                applyOfferList(document, sephora, customer);
                custElement.appendChild(sephora);
            }

        }


        return document;

    }

    /**
     * Apply the offer list from the REST response josn
     *
     * @param document The Document which is used to create new elements
     * @param sephora  The sephora element which the new XML elements will be added to
     * @param customer The rest template response object (deserialized)
     */
    private void applyOfferList(Document document, Element sephora, CustomerResponse customer) {
        if (customer.sephora.offers == null || customer.sephora.offers.size() == 0)
            return;

        Element offerList = document.createElement("OfferList");

        // <Offer OfferId="12345" OfferType="BI_CASH" Name="BI Cash" pointsCost="500"/>
        for (KohlsSephoraLookupServiceImpl.Offer offer : customer.sephora.offers) {
            Element offer1 = document.createElement("Offer");
            offer1.setAttribute("OfferId", offer.id);
            offer1.setAttribute("OfferType", offer.type);
            offer1.setAttribute("Name", offer.name);
            offer1.setAttribute("PointsCost", String.valueOf(offer.pointsCost));
            offerList.appendChild(offer1);
        }

        sephora.appendChild(offerList);
    }


    private LookupKey extractKey(Document inDoc) throws Exception {
        Element doc = inDoc.getDocumentElement();
        String cardNumber = doc.getAttribute("CustomerChargeCardNo");
        if (!YFCCommon.isVoid(cardNumber))
            return new LookupKey("kcc", cardNumber);
        String rewardsNumber = doc.getAttribute("CustomerRewardsNo");
        if (!YFCCommon.isVoid(rewardsNumber))
            return new LookupKey("lyl", rewardsNumber);

        String phone = XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@DayPhone");
        if (!YFCCommon.isVoid(phone))
            return new LookupKey("phn", phone);

        String email = XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@EmailID");
        if (!YFCCommon.isVoid(email))
            return new LookupKey("eml", email);
        throw new Exception("No alias");
    }

    private static class LookupKey {
        public LookupKey(String alias, String value) {
            this.alias = alias;
            this.value = value;
        }

        public String alias;
        public String value;
    }

    private static class ResponseBody {
        public CustomerResponse[] customers;
    }

    private static class CustomerResponse {
        public String associateDiscountID;
        public String loyaltyId;
        public String atgProfileId;
        public String customerId;
        public boolean kohlsChargeMvcIndicator;
        public boolean pilotStatus;
        public String existingEarnTrackerBal;
        public CustomerName customerName;
        public EmailInfo emailAddress;
        public CustomerDatum phoneNumber;
        public CustomerDatum addressLine1;
        public CustomerDatum addressLine2;
        public CustomerDatum addressLine3;
        public CustomerDatum city;
        public CustomerDatum county;
        public CustomerDatum state;
        public CustomerDatum country;
        public CustomerDatum postalCode;
        public SephoraInfo sephora;
        public List<String> segments;
        public List<KohlsCashInfo> kohlsCash;

    }

    private static class KohlsCashInfo {
        public String barcode;
        public String redemptionStartDate;
        public String redemptionEndDate;
        public String remainingValue;
        public String eventTypeCode;
    }

    private static class CustomerDatum {
        public String loyalty;
        public String kohlsCharge;
        public String ecom;
    }

    private static class CustomerName {
        public NameInfo loyalty;
        public NameInfo kohlsCharge;
        public NameInfo ecommerce;
    }

    private static class NameInfo {
        public String first;
        public String middle;
        public String last;
        public String professionalTitle;
    }

    private static class EmailInfo {
        public String eReceipt;
        public String loyalty;
        public String kohlsCharge;
        public String ecom;
    }

    private static class SephoraInfo {
        public String rewardsId;
        public String rewardsEmail;
        public String currentTier;
        public double rewardsPointBalance;
        public List<String> segments;
        public List<KohlsSephoraLookupServiceImpl.Offer> offers;
    }

}
