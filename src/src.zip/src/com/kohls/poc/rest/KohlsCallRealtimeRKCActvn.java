package com.kohls.poc.rest;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


public class KohlsCallRealtimeRKCActvn extends KOHLSBaseApi {

  private final static YFCLogCategory logger = YFCLogCategory.instance(KohlsCallRealtimeRKCActvn.class);

  String eventType;
  String email;
  String receiptNumber;
  String startTime;
  String storeNumber;
  String registerId;
  String transactionNumber;
  String amount;
  String customerOrderNumber;
  String HTTP_METHOD = "POST";
  String CONTENT_TYPE = "application/json";
  String Domain;
  String EndPointPath;
  String ApiKey;
  String ApiSecret;
  String QueryParams;
  String sSource;
  
  String barcode;
  String scanIndicator;
  String qualifiedMerchandiseAmount;
  String messageType;  
  Boolean bScanIndicator;
  Double dQualifiedMerchandiseAmount;
  Element eleDigitalKC;
  String timestamp;
  boolean bWriteToFile = true;
  
  public String strQueryParam = "";
  
  public KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
  private Properties props;


  /**
   * This function sets the attribute from the input xml
   * 
   * @param env
   * @param Document
   * @return Document
   * @exception YFSException
   * 
   */
  public Document invokeRKCService(YFSEnvironment env, Document inputDoc) throws YFSException {
    logger.beginTimer("KohlsPoCRKCService.invokeRKCService");
    logger.debug("KohlsPoCRKCService.invokeRKCService- inputDoc "+com.custom.util.xml.XMLUtil.getXMLString(inputDoc));
    
   
    JSONObject jsonRespose;
    Document docDKC = YFCDocument.createDocument("DigitalKohlsCashActivation").getDocument();
    try {
    	
    		eleDigitalKC = inputDoc.getDocumentElement();
        sSource=eleDigitalKC.getAttribute("Source");
        if(!YFCCommon.isVoid(sSource) &&  sSource.equalsIgnoreCase("RKCActivation"))
        {
        		eventType = eleDigitalKC.getAttribute("EventType");
            email = eleDigitalKC.getAttribute("EmailAddress");
            receiptNumber = eleDigitalKC.getAttribute("ReceiptID");
            if(!YFCCommon.isVoid(sSource) &&  sSource.equalsIgnoreCase("RKCActivation")){
                timestamp = eleDigitalKC.getAttribute("timestamp");
            }else{
            startTime = eleDigitalKC.getAttribute("DateTime");
            }
            storeNumber = eleDigitalKC.getAttribute("Store");
            registerId = eleDigitalKC.getAttribute("TerminalID");
            transactionNumber = eleDigitalKC.getAttribute("SequenceNo");
            amount = eleDigitalKC.getAttribute("CouponAmount");
            customerOrderNumber = eleDigitalKC.getAttribute("OrderNo");
            
            barcode=eleDigitalKC.getAttribute("ActivationBarCode");
            scanIndicator= eleDigitalKC.getAttribute("ScanIndicator");
            qualifiedMerchandiseAmount= eleDigitalKC.getAttribute("QualifyingAmount");
            
            bScanIndicator=Boolean.parseBoolean(scanIndicator);
            dQualifiedMerchandiseAmount= Double.parseDouble(qualifiedMerchandiseAmount);

            ResponseEntity<String> response = null;
           
            TreeMap<String, String> mapHeader = new TreeMap();
            mapHeader.put("Accept-Encoding", "gzip,deflate");
            mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");

            String issodate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
            String strUuid = restApiUtil.getUUID();
            final TreeMap<String, String> depHeaderMap = new TreeMap();
            depHeaderMap.put("X-KOHLS-From-SystemCode", "POC");
            depHeaderMap.put("X-KOHLS-MessageID", strUuid);
            //depHeaderMap.put("X-KOHLS-CorrelationID", "1231");
            
            String sFilePath = "";
            // Create payload  this will change once we have get actual  request from kohls
            GsonBuilder builder = new GsonBuilder();
            Gson gson = builder.create();
            RKCValue rkcReq = new RKCValue();
            
            if (!YFCCommon.isVoid(barcode)) {
                rkcReq.setBarcode(barcode);
              }
              if (!YFCCommon.isVoid(receiptNumber)) {
                  rkcReq.setReceiptNumber(receiptNumber);
                }
              
              if (!YFCCommon.isVoid(timestamp)) {
                  rkcReq.setTimestamp(timestamp);
                }
              
              if (!YFCCommon.isVoid(storeNumber)) {
                  rkcReq.setStoreNumber(storeNumber);
                }
              
              if (!YFCCommon.isVoid(registerId)) {
                  rkcReq.setRegisterID(registerId);
                }
              
              if (!YFCCommon.isVoid(transactionNumber)) {
                  rkcReq.setTransactionNumber(transactionNumber);
                }
              
              if (!YFCCommon.isVoid(amount)) {
                  rkcReq.setAmount(Double.valueOf(amount));
                }
              
              if (!YFCCommon.isVoid(bScanIndicator)) {
                  rkcReq.setScanIndicator(bScanIndicator);
                }
              if (!YFCCommon.isVoid(dQualifiedMerchandiseAmount)) {
                  rkcReq.setQualifiedMerchandiseAmount(dQualifiedMerchandiseAmount);
                } 
              if (!YFCCommon.isVoid(customerOrderNumber)) {
                  rkcReq.setCustomerOrderNumber(customerOrderNumber);
                }  
              rkcReq.setMessageType(KohlsPOCConstant.ATTR_RKC);    
              
              String reqJson = gson.toJson(rkcReq).toString();
              logger.debug("jsonPayload--->" + reqJson);      
              
              SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
              timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
          	String sFileName ="RKCActivation_"+timestamp+"_"+storeNumber+"_"+registerId+"_"+transactionNumber+".txt";
              try {
                sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                restApiUtil.writeToFile("Request is ----> \n", reqJson, sFileName, sFilePath);
              } catch (Exception ex) {
              	 bWriteToFile = false;
                logger.debug("Logger Dir does not exist. So moving on");
              }
                  

          	 String strEndPoint =
          	       props.getProperty(KohlsPOCConstant.RKC_API_ENDPOINT);
          	 String strDomain = props.getProperty(KohlsPOCConstant.RKC_API_DOMAIN);
          	 
          	 String strReadTimeOut = "10000";
          	 
          	 String strtempDomain = strDomain + strEndPoint;
          	 
          	if (!"".equalsIgnoreCase(strQueryParam)) {
                strtempDomain += "?" + strQueryParam;
            }
          	
          	 if (props.getProperty(KohlsPOCConstant.RKC_TIMEOUT) != null) {
          		strReadTimeOut =
          	          props.getProperty(KohlsPOCConstant.RKC_TIMEOUT);
          	      logger.debug("Timeout ##########\n" + strReadTimeOut);
          	    }
              	   
            	depHeaderMap.put("X-KOHLS-From-App", KohlsPOCConstant.FROM_SYSTEM_POC);
                depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
                depHeaderMap.put("X-KOHLS-CreateDateTime",issodate);
                depHeaderMap.put("X-KOHLS-MessageID", strUuid);
            
           	String strApiKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty(KohlsPOCConstant.RKC_API_KEY));
           	String strApiSecretKey =
    	        KohlsRestAPIUtil.getPropertyValue(props.getProperty(KohlsPOCConstant.RKC_API_SECRET));          
            //count++;
            response = restApiUtil.createConnection(reqJson,
                    mapHeader, depHeaderMap, strQueryParam, strtempDomain,
                    strEndPoint, strApiKey,
                    strApiSecretKey,strReadTimeOut,strReadTimeOut,KohlsPOCConstant.RKC_METHOD_NAME, null, false, null, 0);

            if((response!=null)
                    &&(response.getStatusCode().toString().equals("200"))) {
                String responseBody = response.getBody(); 
                
                if(bWriteToFile)
                {
              	  	try {
              	  	  	 sFileName ="RKCActivation_"+timestamp+"_"+storeNumber+"_"+registerId+"_"+transactionNumber+".txt";
                       // sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
              	  		restApiUtil.writeToFile("Response is ----> \n", responseBody, sFileName,
                            sFilePath);
                      } catch (Exception ex) {
                        logger.debug("Logger Dir does not exist. So moving on");
                      }
                }
               
                
                jsonRespose = new JSONObject(responseBody);
                docDKC.getDocumentElement().setAttribute(KohlsPOCConstant.A_RESULT, String.valueOf(jsonRespose.get("result")));
                docDKC.getDocumentElement().setAttribute("CouponNumber", barcode);
            }  
            else
            {
            		docDKC.getDocumentElement().setAttribute(KohlsPOCConstant.A_RESULT, "false");
     	        docDKC.getDocumentElement().setAttribute("CouponNumber", barcode);
            }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
               
        }
        
      
    
    } catch (Exception e) {
    	 	logger.debug("Exception while invoking Rest API Webservice ##########\n" + e);     
    		if(!YFCCommon.isVoid(sSource) &&  sSource.equalsIgnoreCase("RKCActivation")){
    			if(bWriteToFile)
                {
              	  	try {
              	  	  	String sFileName ="RKCActivation_"+timestamp+"_"+storeNumber+"_"+registerId+"_"+transactionNumber+".txt";
                        String sFilePath = getPropertyValue(props.getProperty("LogDir"));
              	  		restApiUtil.writeToFile("Error is ----> \n",e.getMessage(),sFileName,sFilePath);
                      } catch (Exception ex) {
                        logger.debug("Logger Dir does not exist. So moving on");
                      }
                }
    			logger.debug("Digital RKC Error" + e);  
    	       docDKC.getDocumentElement().setAttribute(KohlsPOCConstant.A_RESULT, "false");
    	       docDKC.getDocumentElement().setAttribute("CouponNumber", barcode);
    	      }
    		else
    		{	
    			throw new YFSException(e.getMessage());
    		}
      
    }
    logger.endTimer("KohlsPoCRKCService.invokeRKCService");
    return docDKC;
  }

  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */

  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    // LOG_CAT.debug("In the set properties method");

  }
  
  //CPE -9964- START 
  public String getPropertyValue(String property) {
	    logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
	    String propValue;
	    propValue = YFSSystem.getProperty(property);
	    // Manoj 10/22: updated to use configured property if
	    // customer_overrides.properties does not return any value
	    if (YFCCommon.isVoid(propValue)) {
	      propValue = property;
	    }
	    logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
	    return propValue;

	  }
  //CPE -9964- END 

}
