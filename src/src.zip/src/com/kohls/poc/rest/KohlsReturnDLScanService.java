package com.kohls.poc.rest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.json.JSONException;
import org.apache.commons.json.JSONObject;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsReturnDLScanService extends KOHLSBaseApi {

	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsReturnDLScanService.class);

	// Input fields

	// Can be hand keyed or scanned
	String driverLicense;

	// 2 letter State Code
	String locationId;

	final TreeMap<String, String> depHeaderMap = new TreeMap<String, String>();
	final TreeMap<String, String> headers = new TreeMap<String, String>();

	// Set to ReturnNoReceipt-R for returns
	private static final String clientId = "ReturnNoReceipt-R";

	String registerId;
	String associateId;
	String storeId;
	String transactionId;
	String dateTime;
	String transactionAmount;

	// Possible values are Scanned or KeyEntered
	String customerIdSource;

	private class ItemInfo {

		ItemInfo(String price, String skuUPC, String deptNum, String itemSequenceNumber) {
			currentItemPrice = price;
			currentItemSkuUpc = skuUPC;
			currentDeptNumber = deptNum;
			currentItemSequenceNumber = itemSequenceNumber;
		}

		// Will loop through all items to add in the JSON
		String currentItemPrice;
		String currentItemSkuUpc;
		String currentDeptNumber;
		String currentItemSequenceNumber;
	}

	ArrayList<ItemInfo> itemInfoList = null;

	// Connection Strings
	// String HTTP_METHOD = "POST";
	// String CONTENT_TYPE = APPLICATION_JSON_STRING;

	KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
	private Properties props;

	boolean processViaOfflineFloorLimits = false;
	boolean processViaCorpRefundTender = false;

	JSONObject jsonResponse;

	/**
	 * This function sets the attribute from the input xml
	 * 
	 * @param env
	 * @param Document
	 * @return Document
	 * @exception YFSException
	 * 
	 */
	public Document invokeReturnDLScanService(YFSEnvironment env,
			Document inputDoc) throws YFSException {
		if (logger.isDebugEnabled())
			logger.beginTimer("KohlsReturnDLScanService.invokeReturnDLScanService");

		Element eleReturnDLScan = (Element) inputDoc.getDocumentElement();

		// get all the attribute details from inout xml to frame request
		getAttributesFromInputXML(eleReturnDLScan);

		Document docReturnDLScan = YFCDocument.createDocument(
				KohlsPOCConstant.OUTXML_DOCUMENT_NAME).getDocument();
		try {
			jsonResponse = createMessageAndCallMASH();

			// Set response data
			// Intellicheck fields
			JSONObject driverLicense = null;
			if (jsonResponse.has("driverLicense") && !jsonResponse.isNull("driverLicense")) {
				driverLicense = jsonResponse.getJSONObject("driverLicense");
			}
			prepareResponseFromJSON(docReturnDLScan, driverLicense);

		} catch (Exception e) {
			logger.debug("Exception while invoking Rest API Webservice ##########\n"
					+ e);
			throw new YFSException(e.getMessage());
		}
		if (logger.isDebugEnabled())
			logger.endTimer("KohlsReturnDLScanService.invokeReturnDLScanService");
		return docReturnDLScan;
	}

	private void prepareResponseFromJSON(Document docReturnDLScan,
			JSONObject driverLicense) throws JSONException {

		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_PROCESS_RESULT, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_EXTENDED_RESULT_CODE, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_FIRST_NAME, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_MIDDLE_NAME, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_LAST_NAME, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_ADDRESS1, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_ADDRESS2, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_CITY, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_STATE, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_POSTAL_CODE, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_DATE_OF_BIRTH, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_MEDIA_TYPE, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_UNIQUEID, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_TEST_CARD, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_DL_ID_NUMBER_RAW, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_DL_ID_NUMBER_FORMATTED, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_EXPIRATION_DATE, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_EXPIRED, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_ISSUE_DATE, driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_ISSUING_JURISDICTION_ABBR,
				driverLicense);
		HelpSetJsonResponseAttribute(docReturnDLScan,
				KohlsPOCConstant.OUTXML_ISSUING_JURISDICTION_CVT, driverLicense);

		JSONObject sysRepublic = null;
		if (jsonResponse.has("sysRepublic") && !jsonResponse.isNull("sysRepublic")) {
			sysRepublic = jsonResponse.getJSONObject("sysRepublic");
		}

		// SysRepublic fields
		if (processViaOfflineFloorLimits) {
			docReturnDLScan.getDocumentElement().setAttribute(
					KohlsPOCConstant.OUTXML_APPROVAL_NUMBER,
					KohlsPOCConstant.SYS_REPUBLIC_OFFLINE_APPROVAL_NUM);
			docReturnDLScan.getDocumentElement().setAttribute(
					KohlsPOCConstant.OUTXML_RESPONSE_CODE, "");
		} else if (processViaCorpRefundTender) {
			HelpSetJsonResponseAttribute(docReturnDLScan,
					KohlsPOCConstant.OUTXML_APPROVAL_NUMBER, sysRepublic);
			docReturnDLScan
					.getDocumentElement()
					.setAttribute(
							KohlsPOCConstant.OUTXML_RESPONSE_CODE,
							KohlsPOCConstant.SYS_REPUBLIC_FORCE_CORP_REFUND_RESPONSE_CODE);
		} else {
			HelpSetJsonResponseAttribute(docReturnDLScan,
					KohlsPOCConstant.OUTXML_APPROVAL_NUMBER, sysRepublic);
			HelpSetJsonResponseAttribute(docReturnDLScan,
					KohlsPOCConstant.OUTXML_RESPONSE_CODE, sysRepublic);
		}

	}

	private void getAttributesFromInputXML(Element eleReturnDLScan) {

		driverLicense = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_DRIVER_LICENSE);
		locationId = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_LOCATION_ID);
		registerId = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_REGISTER_ID);
		associateId = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_ASSOCIATE_ID);
		storeId = eleReturnDLScan.getAttribute(KohlsPOCConstant.INXML_STORE_ID);
		transactionId = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_TRANSACTION_ID);
		dateTime = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_DATE_TIME);
		transactionAmount = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_TRANSACTION_AMOUNT);
		customerIdSource = eleReturnDLScan
				.getAttribute(KohlsPOCConstant.INXML_CUSTOMER_ID_SOURCE);

		// Parse through all Items - create ItemInfoList
		itemInfoList = new ArrayList<ItemInfo>();

		NodeList list = eleReturnDLScan
				.getElementsByTagName(KohlsPOCConstant.INXML_RETURN_ITEM);

		for (int i = 0; i < list.getLength(); i++) {
			String itemPrice = ((Element) list.item(i))
					.getAttribute(KohlsPOCConstant.INXML_ITEM_PRICE);
			String itemSkuUPC = ((Element) list.item(i))
					.getAttribute(KohlsPOCConstant.INXML_ITEM_SKU_UPC);
			String deptNumber = ((Element) list.item(i))
					.getAttribute(KohlsPOCConstant.INXML_ITEM_DEPT_NUM);
			String itemSequenceNumber = ((Element) list.item(i))
					.getAttribute(KohlsPOCConstant.INXML_ITEM_LINE_SEQUENCE_NUM);
			
			itemInfoList.add(new ItemInfo(itemPrice, itemSkuUPC, deptNumber, itemSequenceNumber));
		}
	}

	public void HelpSetJsonResponseAttribute(Document outDoc,
			String attributeName, JSONObject jsonResponse) {
		try {
            if (!YFCObject.isVoid(jsonResponse)) {
                if (jsonResponse.has(attributeName) && !jsonResponse.isNull(attributeName))
                    outDoc.getDocumentElement().setAttribute(attributeName,
                            (String) jsonResponse.get(attributeName));
                else
                    outDoc.getDocumentElement().setAttribute(attributeName, "");
            }
            else
                outDoc.getDocumentElement().setAttribute(attributeName, "");
		} catch (Exception e) {
		}
	}

	/**
	 * Following logic is executed based on response from Mash call
	 * 4XX or 5XX: do offline floor limits
	 * HTTP 200 :  	if : processResult = Document Unknown :
	 * 					if: extendedResultCode = LawS/LawD/LawP : process per normal SysRepublic process
	 * 					else: process as corporate refund tender
	 * 				else if : processResult = DocumentProcessOK or DocumentPartiallyOK : process per normal SysRepublic process
	 * 				else : proceed via offline floor limits
	 * HTTP 206 : do offline floor limits
	 * else (Default) : do offline floor limits
	 * 
	 * @return jsonResponse 
	 * @throws Exception
	 */
	public JSONObject createMessageAndCallMASH() throws Exception {
		if (logger.isDebugEnabled()) {
			logger.beginTimer("KohlsReturnDLScanService.createPayLoad");
		}

		JSONObject jsonResponse = null;
		String EndPointPath = KohlsRestAPIUtil
				.getPropertyValue(props
						.getProperty(KohlsPOCConstant.COP_FILE_ENDPOINT_CONTEXT_PATH_LESS_ATTRIBUTE));
		String Domain = KohlsRestAPIUtil
				.getPropertyValue(props
						.getProperty(KohlsPOCConstant.COP_FILE_DOMAIN_ATTRIBUTE));

		String ApiKey = KohlsRestAPIUtil.getPropertyValue(props
				.getProperty(KohlsPOCConstant.COP_FILE_API_KEY_ATTRIBUTE));
		String ApiSecretEncrypted = KohlsRestAPIUtil.getPropertyValue(props
				.getProperty(KohlsPOCConstant.COP_FILE_API_SECRET_ATTRIBUTE));
		String trustCertificate = "";
		String QueryParams = "";
		String enableAuth = this.props.getProperty("IDSCAN_ENABLEAUTH");
		boolean enableRESTAuth = true;
		if (!YFCObject.isVoid(enableAuth)
				&& ("N".trim().equalsIgnoreCase(enableAuth) || "n".trim()
						.equalsIgnoreCase(enableAuth))) {
			enableRESTAuth = false;
		}

		String timeOut = "20000";
		if (KohlsRestAPIUtil.getPropertyValue(props
				.getProperty(KohlsPOCConstant.COP_FILE_TIMEOUT_ATTRIBUTE)) != null) {
			timeOut = KohlsRestAPIUtil.getPropertyValue(props
					.getProperty(KohlsPOCConstant.COP_FILE_TIMEOUT_ATTRIBUTE));
			if (logger.isDebugEnabled()) {
				logger.debug("Timeout ##########\n" + timeOut);
			}
		}

		// create JSON request
		String reqJson = createRequestJSON();
		// create headers
		createHttpHeaders();

		try {

			// call rest
			RestClientWithFailover dsb = new RestClientWithFailover();
			final ResponseEntity<String> response = dsb.executeRESTcall(
					reqJson, headers, depHeaderMap, QueryParams, Domain, EndPointPath,
					ApiKey, ApiSecretEncrypted, timeOut, trustCertificate,
					enableRESTAuth, HttpMethod.POST.name(), "IDSCAN");

			final String responseBody = response.getBody();

			// HTTP Code of 4XX or 5XX
			if (restApiUtil.isError(response.getStatusCode())) {
				if (logger.isDebugEnabled())
					logger.debug("Error ##########\n"
							+ response.getStatusCode());

				// do offline floor limits, send back blank DL # in response to
				// have gravity prompt for hand
				// keyed DL, but DO NOT re-call this API, hand keyed DL # is
				// just for data collect
				processViaOfflineFloorLimits = true;
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("Success");
					logger.debug("Response body ####" + responseBody.toString());
				}
				jsonResponse = new JSONObject(responseBody.toString());

				// parse expired field from json response
				String expiredStatus = "";
				String processResult = "";
				String extendedResultCode = "";
				JSONObject driverLicense = null;

				if (jsonResponse.has("driverLicense") && !jsonResponse.isNull("driverLicense")) {
					driverLicense = jsonResponse.getJSONObject("driverLicense");
				}

				if (!YFCObject.isVoid(driverLicense)) {
					if (!YFCCommon.isVoid(driverLicense.get("expired"))) {
						expiredStatus = (String) driverLicense.get("expired");
					}

					processResult = (String) driverLicense.get("processResult");
					extendedResultCode = (String) driverLicense
							.get("extendedResultCode");

				}
				if (KohlsPOCConstant.V_YES.equals(expiredStatus)) {

					// Force Corporate Refund Tender
					processViaCorpRefundTender = true;
					if (logger.isDebugEnabled())
						logger.debug("Handling Expired DL");
				} else if (KohlsPOCConstant.HTTP_200.equals(response
						.getStatusCode().toString()) || (KohlsPOCConstant.HTTP_206.equals(response
                        .getStatusCode().toString()))) {

					if (KohlsPOCConstant.PROCESS_RESULT_DOCUMENT_UNKNOWN
							.equals(processResult)) {

						if (KohlsPOCConstant.EXTENDED_RESULT_CODE_LAW_S
								.equals(extendedResultCode.toLowerCase())
								|| KohlsPOCConstant.EXTENDED_RESULT_CODE_LAW_D
										.equals(extendedResultCode.toLowerCase())
								|| KohlsPOCConstant.EXTENDED_RESULT_CODE_LAW_P
										.equals(extendedResultCode.toLowerCase())) {

							//If no sysRepublic JSON object, or there is sysRepublic but it's null, process via offline floor limits
                            if (!jsonResponse.has("sysRepublic") || jsonResponse.isNull("sysRepublic"))
                                processViaOfflineFloorLimits = true;
                            else
                            {
                                JSONObject sysRepublic = jsonResponse.getJSONObject("sysRepublic");

                                //If missing either of these 2 fields...default to offline floor limits
                                if ( (!sysRepublic.has(KohlsPOCConstant.OUTXML_APPROVAL_NUMBER) ||
                                        (sysRepublic.isNull(KohlsPOCConstant.OUTXML_APPROVAL_NUMBER))) ||
                                         (!sysRepublic.has(KohlsPOCConstant.OUTXML_RESPONSE_CODE) ||
                                             sysRepublic.isNull(KohlsPOCConstant.OUTXML_RESPONSE_CODE)) )
                                    processViaOfflineFloorLimits = true;
                            }

							if (logger.isDebugEnabled())
								logger.debug("Handling DocumentUnknown extended LawS/LawD or LawP");
						} else {
							// process as corporate refund tender
							processViaCorpRefundTender = true;
						}
					} else if (KohlsPOCConstant.PROCESS_RESULT_DOCUMENT_PROCESS_OK
							.equals(processResult)
							|| KohlsPOCConstant.PROCESS_RESULT_DOCUMENT_PARTIALLY_OK
									.equals(processResult)) {
						// Approval - process per normal SysRepublic process
					} else {

                        //Hand Keyed DL #'s should use what sysRepublic sends back
						if (!customerIdSource.trim().equalsIgnoreCase("KeyEntered"))
    						// proceed via offline floor limits
						    processViaOfflineFloorLimits = true;
					}
				}
				else {

					// do offline floor limits
					processViaOfflineFloorLimits = true;

					if (logger.isDebugEnabled())
						logger.debug("Handling default for http code: "
								+ response.getStatusCode().toString());
				}
			}
		} catch (final Exception e) {
			if (logger.isDebugEnabled())
				logger.debug("Exception while invoking Rest API Webservice ##########\n"
						+ e);
			throw e;
		}
		if (logger.isDebugEnabled())
			logger.endTimer("KohlsReturnDLScanService.createPayLoad");
		return jsonResponse;
	}

	private String createRequestJSON() {

		if (logger.isDebugEnabled()) {
			logger.debug("Request parameters are: " + "\n driverLicense : "
					+ driverLicense + "\n locationId : " + locationId
					+ "\n clientId : " + clientId + "\n registerId : "
					+ registerId + "\n associateId : " + associateId
					+ "\n storeId : " + storeId + "\n transactionId : "
					+ transactionId + "\n dateTime : " + dateTime
					+ "\n transactionAmount : " + transactionAmount
					+ "\n customerIdSource : " + customerIdSource);
		}

		String reqJson = "{ \"driverLicense\":\"" + driverLicense
				+ "\", \"locationId\":\"" + locationId + "\", \"clientId\":\""
				+ "ReturnNoReceipt-R" + "\", \"registerId\":\"" + registerId
				+ "\", \"associateId\":\"" + associateId + "\", \"storeId\":\""
				+ storeId + "\", \"transactionId\":\"" + transactionId
				+ "\", \"dateTime\":\"" + dateTime
				+ "\", \"transactionAmount\":\"" + transactionAmount
				+ "\", \"customerIdSource\":\"" + customerIdSource
				+ "\", \"itemDetails\":[";

		// Loop through item list, adding each item to json request
		int i = 1;
		for (ItemInfo info : itemInfoList) {
			reqJson += "{ \"itemPrice\":\"" + info.currentItemPrice
					+ "\", \"itemSkuUpc\":\"" + info.currentItemSkuUpc
					+ "\", \"deptNumber\":\"" + info.currentDeptNumber
					+ "\", \"itemSequenceNumber\":\"" + info.currentItemSequenceNumber
					+ "\" } ";

			if (i++ != itemInfoList.size()) {
				reqJson += ", ";
			}
		}

		reqJson += "]}";

		if (logger.isDebugEnabled()) {
			logger.debug("Request JSON is:: " + reqJson);
		}

		return reqJson;
	}

	public void createHttpHeaders() throws IOException {
		if (logger.isDebugEnabled())
			logger.beginTimer("KohlsReturnDLScanService.createHttpHeaders");

		// Get current isoDate
		final String isoDate = KohlsRestAPIUtil.getCurrentISODate();

		// create UUID
		final String uuid = restApiUtil.getUUID();

		// Order Map with x-dep header keys and values.

		depHeaderMap.put(KohlsPOCConstant.X_DEP_DATE, isoDate);
		depHeaderMap.put(KohlsPOCConstant.X_DEP_REQUEST_ID, uuid);
		//depHeaderMap.put("X-KOHLS-CreateDateTime", isoDate);

		// per Shabnam
		depHeaderMap.put(KohlsPOCConstant.X_DEP_FROM_APP,
				KohlsPOCConstant.X_DEP_FROM_APP_VALUE);
		depHeaderMap.put(KohlsPOCConstant.X_DEP_FROM_NODE,
				KohlsPOCConstant.X_DEP_FROM_NODE_VALUE);
		depHeaderMap.put(KohlsPOCConstant.X_DEP_FROM_SYSTEM_CODE,
				KohlsPOCConstant.X_DEP_FROM_SYSTEM_CODE_VALUE);

		// Add httpHeaders for request

		headers.put(KohlsPOCConstant.ACCEPT_STRING,
				KohlsPOCConstant.APPLICATION_JSON_STRING);
		headers.put(KohlsPOCConstant.CONTENT_TYPE_STRING,
				KohlsPOCConstant.APPLICATION_JSON_STRING);
		
		if (logger.isDebugEnabled()) {
			logger.endTimer("KohlsReturnDLScanService.createHttpHeaders");
		}

	}

	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		// LOG_CAT.debug("In the set properties method");

	}
}
