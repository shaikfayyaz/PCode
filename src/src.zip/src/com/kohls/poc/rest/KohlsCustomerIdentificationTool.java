package com.kohls.poc.rest;

import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfs.japi.YFSEnvironment;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.Properties;
import java.util.TreeMap;
import java.util.UUID;
import java.util.regex.Pattern;

public class KohlsCustomerIdentificationTool {

    private final static String PROXY_HOST = "proxy.kohls.com";
    private final static int PROXY_PORT = 3128;

    /**
     * gets the store number from the api request xml
     *
     * @param request The Customer XML document
     * @return The store number
     */
    public static String extractStoreNumber(Document request) {
        NodeList customer = request.getElementsByTagName("Customer");
        if (customer.getLength() == 1) {
            String storeNumber = ((Element) customer.item(0)).getAttribute("SellerOrganizationCode");
            if (Pattern.matches("\\d{1,4}", storeNumber))
                return storeNumber;
        }
        return "0000";
    }

    /**
     * Get the number of Retries to perform for loyalty lookups.
     *
     * @param env The environment
     * @return the retry count
     */
    public static int getConfiguredRetryCount(YFSEnvironment env) {
        try {
            // get configured retries.... not less than zero, not more than 10.
            int retries = Integer.parseInt(KohlsPoCCommonAPIUtil.getRuleValuesfromDB(env));
            if (retries < 0)
                retries = 0;
            if (retries > 10)
                retries = 10;
            return retries;
        } catch (Exception ignored) {
            return 1;
        }
    }


    /**
     * builds the map of headers to be sent to the account services REST endpoint
     *
     * @param body        body text
     * @param storeNumber store number
     * @param props       properties must contain API_KEY, API_PATH, API_SECRET
     * @return map of headers
     */
    public static TreeMap<String, String> getHeaders(String body, String storeNumber, Properties props) {

        String method = "POST";
        String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
        System.out.println(timestamp);
        String apiKey = props.getProperty("API_KEY");
        String endpoint = props.getProperty("API_PATH");

        String correlationId = UUID.randomUUID().toString();

        String toSignSource = method + timestamp + apiKey + endpoint + correlationId + body;
        String toSign = toSignSource.replaceAll("\\s", "");
        System.out.println(toSign);

        String apiSecret = props.getProperty("API_SECRET");
        String signature = KohlsAccountServicesUtil.createSignature(apiSecret, toSign);

        TreeMap<String, String> header = new TreeMap<>();
        header.put("Accept", "application/json");
        header.put("Content-Type", "application/json");
        header.put("X-APP-API_TIMESTAMP", timestamp);
        header.put("X-APP-API_KEY", apiKey);
        header.put("correlation-id", correlationId);
        header.put("X-APP-API_SIGNATURE", signature);
        header.put("X-Location-Id", storeNumber);
        header.put("channel", "KOHLS_STORE");
        return header;
    }

    /**
     * Calls a remote service (either kohls rewards or sephora) to identify a customer based on phone/email/lyl/kcc
     *
     * @param props       Properties object which must contain READ_TIMEOUT and CONNECT_TIMEOUT
     * @param body        the request body
     * @param storeNumber The store number which goes in the header
     * @param urlSource   The url endpoint to send the request to
     * @return The RestTemplate response
     * @throws Exception Any Problem
     */
    public static ResponseEntity<String> getStringResponseEntity(Properties props, String body, String storeNumber,
                                                                 String urlSource) throws Exception {
        TreeMap<String, String> headers = KohlsCustomerIdentificationTool.getHeaders(body, storeNumber, props);
        TreeMap<String, String> depHeaders = new TreeMap<>();

        String readTimeout = props.getProperty("READ_TIMEOUT");
        String connectTimeout = props.getProperty("CONNECT_TIMEOUT");

        KohlsRestAPIUtil util = new KohlsRestAPIUtil();
        return util.createConnection(body, headers, depHeaders, null, urlSource, "",
                null, null, readTimeout, connectTimeout, null, "POST", true, PROXY_HOST, PROXY_PORT);
    }

    public static ResponseEntity<String> getResponseWithRetry(Properties props, int maxTries, String body, String storeNumber, String urlSource) throws Exception {
        int retry = 0;
        // send the request... retry once after failure
        while (retry++ < maxTries) {
            try {
                return getStringResponseEntity(props, body, storeNumber, urlSource);
            } catch (Exception exception) {
                if (retry >= maxTries)
                    throw exception;
            }
        }
        throw new Exception("Failed to perform specified retries");
    }

    public static String decryptSecret(String encryptedSecret) throws IOException {
        KohlsRestAPIUtil util = new KohlsRestAPIUtil();
        String salt = util.pwdForDecryption("CMDM");
        return util.decryptString(encryptedSecret, salt);
    }


}
