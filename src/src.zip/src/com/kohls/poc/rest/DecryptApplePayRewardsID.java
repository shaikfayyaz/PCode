package com.kohls.poc.rest;



import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.json.JSONObject;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

import com.kohls.poc.constant.KohlsPOCConstant;

import com.kohls.sbc.orgRules.KohlsPoCOrgRuleUtil;

/**************************************************************************
 * File : DecryptApplePayRewardsID.java Author : RajeshG Created : June 01 2016 Modified :
 * June 01 2016 Version : 1.0
 ***************************************************************************** 
 * ***************************************************************************
 * Copyright @ 2016. This document is in copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Java component is implemented as part of CR 935.It will receive request for decrypt RewardsId.It also prepares and call DSB
 * service that response with clear text of rewardsID
 * 
 * @author Rajesh G
 * @version 1.0
 *****************************************************************************/

public class DecryptApplePayRewardsID extends KOHLSBaseApi {


	public  String strReadTimeOut="";
	public  String endPoint = "";
	public  String trustCertificate = "";
	//Below fields are require if enableAuth is Y
	public  String strQueryParam = "";
	public  String strApiKey = "";
	public  String strApiSecretKey = "";
	public  String enableAuth = "";
	public boolean enableRESTAuth = false;	
	
	
	public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
	private Properties props;
	
	private static YFCLogCategory logger;
	
	static {
		logger = YFCLogCategory.instance(DecryptApplePayRewardsID.class
				.getName());
	}

	/**
	 * This method will be called using IBM SFD framework through UE call from TcxGravity when
	 * Customer taps his/her phone in pinpad
	 * @param env
	 * @param inDoc
	 * @return
	 * @throws Exception
	 */
	public   Document getDecryptApplePayRewardsID(YFSEnvironment env,Document inDoc)  throws Exception {
		
		logger.beginTimer("Start DecryptApplePayRewardsID.getDecryptApplePayRewardsID");
		logger.debug("DecryptApplePayRewardsID.getDecryptApplePayRewardsID InDoc--->"+XMLUtil.getXMLString(inDoc));
		Document decryptApplePayRewardsIDOutDoc = null;
		
		strReadTimeOut = this.props.getProperty("CUST_READ_TIME_OUT");
	    endPoint  = this.props.getProperty("CUST_ENDPOINT");
	    trustCertificate  = this.props.getProperty("CUST_TRUSTCERT");
	    enableAuth  = this.props.getProperty("CUST_ENABLEAUTH");
	    
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();

		RewardsIDDecryptRequest rewardsIDDecryptRequest = parseInputDoc(inDoc);
		
		String jsonPayload = null;
		
		if(rewardsIDDecryptRequest != null){
			
			jsonPayload = gson.toJson(rewardsIDDecryptRequest).toString();
			
		}else{
			raiseInvalidInputException("Input Parsing Error in OMS");
			
		}
		
		logger.debug("jsonPayload for DSB Service--->"+jsonPayload);

		TreeMap<String, String> mapHeader = new TreeMap<String, String>();
		
		mapHeader.put(KohlsPOCConstant.ACCEPT, "application/json");
		mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");
		
		String issodate = KohlsRestAPIUtil.getCurrentISODate();
		String strUuid = restApiutil.getUUID();
		String omsHost = getHostName(env);
		String versionInfo = getVersionInfoForPOC(env);
		
		TreeMap<String, String> depHeaderMap = new TreeMap<String, String>();
		
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_CREATE_DATE_TIME, issodate);
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_MESSAGE_ID, strUuid);
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_SYSTEM_CODE, "OS");
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_APP, "OMSR");
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_MODULE, "APPLEPAYREWARDS");				
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_NODEID, omsHost);	
		//PST-443 Change for CorrelationID
		depHeaderMap.put("x-dep-correlation-id", KohlsPoCCommonAPIUtil.getCorrelationID());
		depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
		depHeaderMap.put(KohlsPOCConstant.X_KOHLS_VERSION, versionInfo);
		
		ResponseEntity<String> response = null;
		
		try {
		
			
		
			if("Y".trim().equalsIgnoreCase(enableAuth) || "y".trim().equalsIgnoreCase(enableAuth)){				
				 enableRESTAuth = true;				
			}

					
			RestClientWithFailover dsb = new RestClientWithFailover();
			response = dsb.executeRESTcall(jsonPayload, mapHeader,
					depHeaderMap, strQueryParam, endPoint, 
					strApiKey, strApiSecretKey,strReadTimeOut,trustCertificate,enableRESTAuth, HttpMethod.POST.name(),"DSB");
					
			if( null != response){
				logger.debug("Response from DSB Service--->"+response.getBody()+"||Header"+response.getHeaders());
			}
						
			if((response!=null) &&(response.getStatusCode().toString().equals("200")))
			{
				String responseBody = response.getBody();
				JSONObject json = new JSONObject(responseBody);				
				decryptApplePayRewardsIDOutDoc = inDoc;
				setDecryptApplePayRewardsID(decryptApplePayRewardsIDOutDoc, json,rewardsIDDecryptRequest.getDataElement());	
			
			}
			
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			if(e instanceof YFSException){
				throw e;
				
			} else{
			  
			   YFSException yfs= new YFSException();
			   
			  if(null != e.getCause()){
				  yfs.setErrorCode(e.getCause().toString());
				  
			  }else{
				  yfs.setErrorCode("UnknownError");
			  }
			  
			  if(null != e.getMessage()){
				  yfs.setErrorDescription(e.getMessage());				  
			  }else{
				  yfs.setErrorDescription("Unknown Error From OMS System");
			  }
			  throw yfs;				
			}

	    }
		logger.endTimer("End DecryptApplePayRewardsID.getDecryptApplePayRewardsID");

		return decryptApplePayRewardsIDOutDoc;

	}

	/**
	 * This method is to validate the input and build the request object for DSB Service
	 * @param inDoc
	 * @return
	 */
	private RewardsIDDecryptRequest parseInputDoc(Document inDoc) {
		String action = null;
		String vendor = null;
		String payLoadType = null;
		String payLoad = null;	
		String encodingType = null;
		

		

		action = XMLUtil.getAttribute(
				inDoc.getDocumentElement(), KohlsPOCConstant.STRING_ACTION);
		
		vendor = XMLUtil.getAttribute(
				inDoc.getDocumentElement(), KohlsPOCConstant.STRING_VENDOR);
		
		payLoadType = XMLUtil.getAttribute(
				inDoc.getDocumentElement(),KohlsPOCConstant.STRING_PAYLOADTYPE);
		
		payLoad = XMLUtil.getAttribute(
				inDoc.getDocumentElement(), KohlsPOCConstant.STRING_PAYLOAD);
		
		encodingType = XMLUtil.getAttribute(
				inDoc.getDocumentElement(), KohlsPOCConstant.STRING_ENCODINGTYPE);

		
		
		RewardsIDDecryptRequest rewardsIDDecryptRequest = new RewardsIDDecryptRequest();
		
		
		if (!YFCCommon.isVoid(action) && KohlsPOCConstant.STRING_DESECURE.equalsIgnoreCase(action)) {

			rewardsIDDecryptRequest.setDataOperation("1");			

		} else {
			
		  	raiseInvalidInputException(KohlsPOCConstant.STRING_ACTION);
		
	    }
	
		
		if (!YFCCommon.isVoid(vendor) && ("Apple Pay".trim().equalsIgnoreCase(vendor.trim()) || "ApplePay".equalsIgnoreCase(vendor.trim())) ) {			

			rewardsIDDecryptRequest.setExternalVendor("Apple");			

		}  else {
			
		  	raiseInvalidInputException(KohlsPOCConstant.STRING_VENDOR);
		
	    }
	
		
		if (!YFCCommon.isVoid(payLoadType)) {

			rewardsIDDecryptRequest.setExternalPayLoadType(payLoadType);			

		}  else {
			
		  	raiseInvalidInputException(KohlsPOCConstant.STRING_PAYLOADTYPE);
		
	    }
	
		
		if (!YFCCommon.isVoid(payLoad)) {

			rewardsIDDecryptRequest.setDataElement(payLoad);
		} else {
			
			  	raiseInvalidInputException(KohlsPOCConstant.STRING_PAYLOAD);
			
		}
		
		rewardsIDDecryptRequest.setRequestingEntity("OMSR");			

		
		
		if (!YFCCommon.isVoid(encodingType)) {

			rewardsIDDecryptRequest.setDataElementEncoding(encodingType);		

		}else{
			
			rewardsIDDecryptRequest.setDataElementEncoding("TEXT");	
		}
		
		return rewardsIDDecryptRequest;
	}

	/**
	 * This method is to process the JSON response from DSB and build the XML 
	 * response for TcxGravity
	 * @param decryptedOutDoc
	 * @param json
	 * @param strValue
	 * @return
	 * @throws Exception
	 */
	private Document setDecryptApplePayRewardsID(Document decryptedOutDoc, JSONObject json,
			String strValue) throws Exception {
		
		logger.debug("Start DecryptApplePayRewardsID.setDecryptApplePayRewardsID");

		String sToParse = "[" + json.toString() + "]";
		Gson outGson = new Gson();
		TranslateDSBResponseJSON[] parsedDSBResponseJSON = outGson.fromJson(sToParse, TranslateDSBResponseJSON[].class); 
		String decryptedRewardsID = null;
		String errorDSBCode = null;
		String errorDSBDesc = null;
		
		logger.debug("JSON from DSB:"+json);		

		for (int j = 0; j < parsedDSBResponseJSON.length; j++) {
			
			decryptedRewardsID = parsedDSBResponseJSON[j].DataElement;
			errorDSBCode = parsedDSBResponseJSON[j].ErrorCode;
			errorDSBDesc = parsedDSBResponseJSON[j].ErrorDescription;
						
			if(null != errorDSBCode && ( !("".trim().equalsIgnoreCase(errorDSBCode.trim()) || ("0".trim().equalsIgnoreCase(errorDSBCode.trim()))) ) ){
				
				raiseYFSException(errorDSBCode,errorDSBDesc);
				
			}else{
				
				if(null == decryptedRewardsID || ("".trim().equalsIgnoreCase(decryptedRewardsID.trim())) ){
					
					raiseYFSException("DecryptApplePayRewardsIDisNULL","Response Received from DSB had DecryptApplePayRewardsID as NULL or empty");
					
				}else{
					decryptedOutDoc.getDocumentElement().setAttribute( KohlsPOCConstant.STRING_PAYLOAD, decryptedRewardsID);
				}				
				
			}
			
				
		}
			
		logger.debug("End DecryptApplePayRewardsID.setDecryptApplePayRewardsID");
		return decryptedOutDoc;
	}

	/**
	 * This is generic method to generate the YFS Exception
	 * with information passed in the parameters
	 * @param errorCode
	 * @param errorDesc
	 */
	private void raiseYFSException(String errorCode,String errorDesc) {
		YFSException yfs= new YFSException();
		yfs.setErrorCode(errorCode);
		yfs.setErrorDescription(errorDesc);
		throw yfs;
	}

	

	
	/* (non-Javadoc)
	 * @see com.kohls.common.util.KOHLSBaseApi#setProperties(java.util.Properties)
	 */
	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		logger.debug("In the set properties method");

	}
	
	/**
	 * This method is to retrieve the OMS server details and it is passed 
	 * as part of REST header details
	 * @param envinUE
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws Exception
	 */
	String getHostName(YFSEnvironment envinUE)
			throws ParserConfigurationException, SAXException, IOException,
			Exception {

		String host = null;

		String getServerListInputXML = "<Servers Type=\"ApplicationServer\" ></Servers>";

		Document getServerListOutputDoc = KOHLSBaseApi.invokeAPI(envinUE,
				"getServerList", XMLUtil.getDocument(getServerListInputXML));
		
		if(null != getServerListOutputDoc){

			List hostList = KohlsXMLUtil.getElementListByXpath(
					getServerListOutputDoc, "/Servers/Server[@Status='Active']");
			
			if( null != hostList && hostList.size() > 0){
	
				Element hostElement = (Element) hostList.get(0);
				if(null != hostElement){
					host = hostElement.getAttribute("Name");
					
				}
		
	
			}			
			
		}
		if (null == host || "".equalsIgnoreCase(host.trim())){
			
			host = "OMSR";
		}
		return host;

	}
	
	/**
	 * This method is to retrieve the OMS version details and it is passed 
	 * as part of REST header details
	 * @param envinUE
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 * @throws Exception
	 */
	String getVersionInfoForPOC(YFSEnvironment envinUE)
			throws ParserConfigurationException, SAXException, IOException,
			Exception {

		String versionInfo = null;

		String getVersionInfoForPOCInputXML = "<Versions></Versions>";

		Document getVersionInfoForPOCOutputDoc = KOHLSBaseApi.invokeAPI(
				envinUE, "getVersionInfoForPOS",
				XMLUtil.getDocument(getVersionInfoForPOCInputXML));
		
				
		if(null != getVersionInfoForPOCOutputDoc){
			
			List versionList = KohlsXMLUtil
					.getElementListByXpath(getVersionInfoForPOCOutputDoc,
							"/Versions/Version[@Prefix='ysc']");
			
			if(null != versionList && versionList.size() == 0){
				versionList = KohlsXMLUtil
						.getElementListByXpath(getVersionInfoForPOCOutputDoc,
								"/Versions/Version[@Prefix='tcxgravity']");
				
			}			
			if( null != versionList && versionList.size() > 0){
	
				Element versionElement = (Element) versionList.get(0);
				
				if( null != versionElement){					
					versionInfo = versionElement.getAttribute("Version");
				}
		
				
			}
		}
		
		if (null == versionInfo || "".equalsIgnoreCase(versionInfo.trim())){
			
			versionInfo = "9.3.0.21";
		}

		return versionInfo;

	}
	
	/**
	 * This is generic method to generate the YFS Exception for invalid input
	 * with information passed in the parameters
	 * @param fieldName
	 */
	void raiseInvalidInputException(String fieldName){
		   YFSException yfs= new YFSException();
		   yfs.setErrorCode("InvalidInput");
		   yfs.setErrorDescription(fieldName+ " Field Received by OMS is empty or null");
		   throw yfs;
	}

	
}

