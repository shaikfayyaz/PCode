package com.kohls.poc.rest;

import com.google.gson.Gson;
import com.yantra.yfc.log.YFCLogCategory;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.net.URL;
import java.util.List;
import java.util.Properties;

import static com.kohls.poc.rest.KohlsCustomerIdentificationTool.decryptSecret;
import static com.kohls.poc.rest.KohlsCustomerIdentificationTool.getResponseWithRetry;

public class KohlsSephoraLookupServiceImpl {
    private static YFCLogCategory logger;

    private static YFCLogCategory getLogger() {
        if (logger == null)
            logger = YFCLogCategory.instance(KohlsSephoraLookupServiceImpl.class.getName());
        return logger;
    }

    public Document getCustomerList(Document request, Properties props, int maxTries) throws Exception {

        String email = this.extractEmail(request);
        String body = "{\"email\":\"" + email + "\"}";

        String storeNumber = KohlsCustomerIdentificationTool.extractStoreNumber(request);

        String urlSource = props.getProperty("SR_LOOKUP_BASE_URL");
        URL url = new URL(urlSource);
        String path = url.getPath();

        props.setProperty("API_PATH", path);
        props.setProperty("API_KEY", props.getProperty("SR_LOOKUP_API_KEY"));
        if (props.containsKey("SR_LOOKUP_API_SECRET_DECRYPTED")) {
            // use for unit testing only
            props.setProperty("API_SECRET", props.getProperty("SR_LOOKUP_API_SECRET_DECRYPTED"));
        } else {
            String encryptedSecret = props.getProperty("SR_LOOKUP_API_SECRET");
            String decryptedSecret = decryptSecret(encryptedSecret);
            props.setProperty("API_SECRET", decryptedSecret);
        }
        props.setProperty("READ_TIMEOUT", props.getProperty("SR_LOOKUP_TIMEOUT"));
        props.setProperty("CONNECT_TIMEOUT", "4000");

        ResponseEntity<String> response = getResponseWithRetry(props, maxTries, body, storeNumber, urlSource);
        return this.createResponse(response);
    }

    /**
     * Create a response Document object given a JSON response string.
     * <CustomerList>
     * <Customer Segments="BI_MEMBER,BI_500_PTS,VIB,SEPHORA_BD_GIFT">
     * <SephoraCustomerDetails RewardsId="8887708723659545" RewardsEmail="abc@abc.com" RewardsBalance="1000">
     * <OfferList>
     * <Offer OfferId="12345" OfferType="BI_CASH" Name="BI Cash" pointsCost="500"/>
     * </OfferList>
     * </SephoraCustomerDetails>
     * </Customer>
     * </CustomerList>
     *
     * @param responseJson The rest template Response
     * @return The API XML output document
     */
    private Document createResponse(ResponseEntity<String> responseJson) throws Exception {

        Gson gson = new Gson();
        ResponseBody responseBody = gson.fromJson(responseJson.getBody(), ResponseBody.class);

        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element customerList = document.createElement("CustomerList");
        document.appendChild(customerList);

        Element customer = document.createElement("Customer");

        if (responseBody.segments != null) {
            StringBuilder sb = new StringBuilder();
            for (String segment : responseBody.segments) {
                sb.append(segment);
                sb.append(",");
            }
            if (sb.length() > 0)
                sb.deleteCharAt(sb.length() - 1);
            String segments = sb.toString();
            customer.setAttribute("Segments", segments);
        }
        customerList.appendChild(customer);

        Element sephora = document.createElement("SephoraCustomerDetails");
        sephora.setAttribute("RewardsId", responseBody.rewardsId);
        sephora.setAttribute("RewardsEmail", responseBody.rewardsEmail);
        String balance = String.valueOf(Math.round(responseBody.rewardsPointBalance));
        sephora.setAttribute("RewardsBalance", balance);

        applyOfferList(document, sephora, responseBody);

        customer.appendChild(sephora);

        return document;
    }

    private void applyOfferList(Document document, Element sephora, ResponseBody responseBody) {
        if (responseBody.offers == null || responseBody.offers.size() == 0)
            return;

        Element offerList = document.createElement("OfferList");

        // <Offer OfferId="12345" OfferType="BI_CASH" Name="BI Cash" pointsCost="500"/>
        for (Offer offer : responseBody.offers) {
            Element offer1 = document.createElement("Offer");
            offer1.setAttribute("OfferId", offer.id);
            offer1.setAttribute("OfferType", offer.type);
            offer1.setAttribute("Name", offer.name);
            offer1.setAttribute("PointsCost", String.valueOf(offer.pointsCost));
            offerList.appendChild(offer1);
        }

        sephora.appendChild(offerList);
    }

    /**
     * returns the email ID from the xpath /Customer/CustomerContactList/CustomerContact/@EmailID
     *
     * @param request The API Input XML
     * @return The email address
     */
    private String extractEmail(Document request) {
        if (request == null)
            return null;
        NodeList nodes = request.getElementsByTagName("CustomerContact");
        if (nodes.getLength() != 1)
            throw new UnsupportedOperationException("Must contain CustomerContact Element with EmailID attribute");
        Element contact = (Element) nodes.item(0);
        return contact.getAttribute("EmailID");
    }

    private static class ResponseBody {
        public String rewardsId;
        public String rewardsEmail;
        public String currentTier;
        public double rewardsPointBalance;
        public List<String> segments;
        public List<Offer> offers;

        // error properties
        public String code;
        public String message;
    }

    static class Offer {
        public String id;
        public String type;
        public String name;
        public int pointsCost;
    }

}
