/**
 * 
 */
package com.kohls.poc.rest;

import java.util.TreeMap;
import java.util.concurrent.Callable;

import org.springframework.http.ResponseEntity;

/**
 * The <code>KohlsRestAPIRequest</code> class provides a Callable implementation that
 * can be invoked in the ExecutorService threadpool. It provides the default
 * factory method <code>newKohlsRestAPIRequest</code> for creating the callable request
 * instance that utilizes the existing <code>KohlsRestAPIUtil</code> for making REST calls.
 * 
 * @author tkmaagk
 */
public abstract class KohlsRestAPICallableRequest implements Callable<ResponseEntity<String>> {

	protected String payload;
	protected TreeMap<String, String> mapHeader;
	protected TreeMap<String, String> depHeaderMap;
	protected String strQueryParam;
	protected String strDomain;
	protected String strEndPoint;
	protected String strApiKey;
	protected String strApiSecretKey;
	protected String strReadTimeOut;
	protected String connectTimeOut;
	protected String strMethod;
	protected String httpMethod;
	protected boolean bProxyRequired;
	protected String strProxyHost;
	protected int iProxyPort;

	public static KohlsRestAPICallableRequest newKohlsRestAPIRequest(String payload, TreeMap<String, String> mapHeader,
			TreeMap<String, String> depHeaderMap, String strQueryParam, String strDomain, String strEndPoint,
			String strApiKey, String strApiSecretKey, String strReadTimeOut, String connectTimeOut, String strMethod,
			String httpMethod, boolean bProxyRequired, String strProxyHost, int iProxyPort) {

		KohlsRestAPICallableRequest req = new KohlsRestAPICallableRequest() {
			@Override
			public ResponseEntity<String> call() throws Exception {
				// TODO Auto-generated method stub
				KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
				return restApiUtil.openConnection(payload, mapHeader, depHeaderMap, strQueryParam, strDomain, strEndPoint,
						strApiKey, strApiSecretKey, strReadTimeOut, connectTimeOut, strMethod, httpMethod, bProxyRequired,
						strProxyHost, iProxyPort);
			}
		};

		req.payload = payload;
		req.mapHeader = mapHeader;
		req.depHeaderMap = depHeaderMap;
		req.strQueryParam = strQueryParam;
		req.strDomain = strDomain;
		req.strEndPoint = strEndPoint;
		req.strApiKey = strApiKey;
		req.strApiSecretKey = strApiSecretKey;
		req.strReadTimeOut = strReadTimeOut;
		req.connectTimeOut = connectTimeOut;
		req.strMethod = strMethod;
		req.httpMethod = httpMethod;
		req.bProxyRequired = bProxyRequired;
		req.strProxyHost = strProxyHost;
		req.iProxyPort = iProxyPort;

		return req;

	}
}
