package com.kohls.poc.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KohlsReturnLCSOutJson {

	private List<ResponseDetail> responseDetails = null;
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public List<ResponseDetail> getResponseDetails() {
		return responseDetails;
	}

	public void setResponseDetails(List<ResponseDetail> responseDetails) {
		this.responseDetails = responseDetails;
	}

	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}


	public class CouponDetail {

		private String barcode;
		private String initialCouponValue;
		private String couponStartingBalance;
		private String unearnedValue;
		private String eventEarnDelta;
		private String eligibleAmountDelta;
		private String redemptionStartDate;
		private String redemptionEndDate;
		private String cpnRefundDeduction;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();
		
		public String getCpnRefundDeduction() {
			return cpnRefundDeduction;
		}

		public void setCpnRefundDeduction(String cpnRefundDeduction) {
			this.cpnRefundDeduction = cpnRefundDeduction;
		}
		public String getBarcode() {
			return barcode;
		}

		public void setBarcode(String barcode) {
			this.barcode = barcode;
		}

		public String getInitialCouponValue() {
			return initialCouponValue;
		}

		public void setInitialCouponValue(String initialCouponValue) {
			this.initialCouponValue = initialCouponValue;
		}

		public String getCouponStartingBalance() {
			return couponStartingBalance;
		}

		public void setCouponStartingBalance(String couponStartingBalance) {
			this.couponStartingBalance = couponStartingBalance;
		}

		public String getUnearnedValue() {
			return unearnedValue;
		}

		public void setUnearnedValue(String unearnedValue) {
			this.unearnedValue = unearnedValue;
		}

		public String getEventEarnDelta() {
			return eventEarnDelta;
		}

		public void setEventEarnDelta(String eventEarnDelta) {
			this.eventEarnDelta = eventEarnDelta;
		}

		public String getEligibleAmountDelta() {
			return eligibleAmountDelta;
		}

		public void setEligibleAmountDelta(String eligibleAmountDelta) {
			this.eligibleAmountDelta = eligibleAmountDelta;
		}

		public String getRedemptionStartDate() {
			return redemptionStartDate;
		}

		public void setRedemptionStartDate(String redemptionStartDate) {
			this.redemptionStartDate = redemptionStartDate;
		}

		public String getRedemptionEndDate() {
			return redemptionEndDate;
		}

		public void setRedemptionEndDate(String redemptionEndDate) {
			this.redemptionEndDate = redemptionEndDate;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}



	public class Product {

		private String lineNumber;
		private String kohlsCashEligible;
		private String department;
		private String sku;
		private String netPrice;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		public String getLineNumber() {
			return lineNumber;
		}

		public void setLineNumber(String lineNumber) {
			this.lineNumber = lineNumber;
		}

		public String getKohlsCashEligible() {
			return kohlsCashEligible;
		}

		public void setKohlsCashEligible(String kohlsCashEligible) {
			this.kohlsCashEligible = kohlsCashEligible;
		}

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		public String getSku() {
			return sku;
		}

		public void setSku(String sku) {
			this.sku = sku;
		}

		public String getNetPrice() {
			return netPrice;
		}

		public void setNetPrice(String netPrice) {
			this.netPrice = netPrice;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}


	public class ResponseDetail {

		private String transactionNumber;
		private String storeNumber;
		private String registerId;
		private String transactionDate;
		private String transactionTime;
		private String orderNumber;
		private String loyaltyId;
		private String earnTrackerStartingBalance;
		private String everydayEarnKccDelta;
		private String everydayEarnNonKccDelta;
		private String earnTrackerDelta;
		private String refundDeduction;
		private List<CouponDetail> couponDetails = null;
		private List<Product> products = null;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		public String getTransactionNumber() {
			return transactionNumber;
		}

		public void setTransactionNumber(String transactionNumber) {
			this.transactionNumber = transactionNumber;
		}

		public String getStoreNumber() {
			return storeNumber;
		}

		public void setStoreNumber(String storeNumber) {
			this.storeNumber = storeNumber;
		}

		public String getRegisterId() {
			return registerId;
		}

		public void setRegisterId(String registerId) {
			this.registerId = registerId;
		}

		public String getTransactionDate() {
			return transactionDate;
		}

		public void setTransactionDate(String transactionDate) {
			this.transactionDate = transactionDate;
		}

		public String getTransactionTime() {
			return transactionTime;
		}

		public void setTransactionTime(String transactionTime) {
			this.transactionTime = transactionTime;
		}

		public String getOrderNumber() {
			return orderNumber;
		}

		public void setOrderNumber(String orderNumber) {
			this.orderNumber = orderNumber;
		}

		public String getLoyaltyId() {
			return loyaltyId;
		}

		public void setLoyaltyId(String loyaltyId) {
			this.loyaltyId = loyaltyId;
		}

		public String getEarnTrackerStartingBalance() {
			return earnTrackerStartingBalance;
		}

		public void setEarnTrackerStartingBalance(String earnTrackerStartingBalance) {
			this.earnTrackerStartingBalance = earnTrackerStartingBalance;
		}

		public String getEverydayEarnKccDelta() {
			return everydayEarnKccDelta;
		}

		public void setEverydayEarnKccDelta(String everydayEarnKccDelta) {
			this.everydayEarnKccDelta = everydayEarnKccDelta;
		}

		public String getEverydayEarnNonKccDelta() {
			return everydayEarnNonKccDelta;
		}

		public void setEverydayEarnNonKccDelta(String everydayEarnNonKccDelta) {
			this.everydayEarnNonKccDelta = everydayEarnNonKccDelta;
		}

		public String getEarnTrackerDelta() {
			return earnTrackerDelta;
		}

		public void setEarnTrackerDelta(String earnTrackerDelta) {
			this.earnTrackerDelta = earnTrackerDelta;
		}

		public String getRefundDeduction() {
			return refundDeduction;
		}

		public void setRefundDeduction(String refundDeduction) {
			this.refundDeduction = refundDeduction;
		}

		public List<CouponDetail> getCouponDetails() {
			return couponDetails;
		}

		public void setCouponDetails(List<CouponDetail> couponDetails) {
			this.couponDetails = couponDetails;
		}

		public List<Product> getProducts() {
			return products;
		}

		public void setProducts(List<Product> products) {
			this.products = products;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}
}