package com.kohls.poc.rest;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.kohls.poc.psa.api.KohlsKCSCallForPSA;
import com.kohls.poc.psa.api.KohlsPSAKohlsCashDeactivation;
import com.kohls.poc.psa.api.KohlsSecondTVSCallForPSA;
import com.kohls.poc.psa.api.KohlsTVSCallForKohlsCashEligibleItems;
import com.kohls.poc.returns.api.KohlsReturnsLCSDeactivation;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.constants.KohlsCorpReturnsConstants;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.ycp.bcsupport.YCPBCTemplateTrimmer;
import com.yantra.yfc.core.YFCObject;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsReturnsLCSCallWrapper {

    
    private static YFCLogCategory logger;
    private static YFCDocument oTemplateDoc = null;
    GsonBuilder builder = new GsonBuilder();
    Gson gson = builder.create();
    static {
        logger = YFCLogCategory.instance(KohlsReturnsLCSCallWrapper.class
                .getName());
    }
    
    public Document processOutputForLCSReturnsPA(YFSEnvironment env, String jsonResponse, Document input, String source) throws Exception{
      logger.beginTimer("KohlsReturnsLCSCallWrapper.processOutputForLCSReturnsPA");
        if(logger.isDebugEnabled()) {
          logger.debug("\n\n jsonResponse is : "+jsonResponse);
          logger.debug("\n\n input xml to KohlsReturnsLCSCallWrapper.processOutputForLCSReturnsPA is : "+XMLUtil.getXMLString(input));
        }
        Element elePromotion=null;
        Element eleExtn=null;
        List<KohlsReturnLCSOutJson.CouponDetail> listCpnDetail = new ArrayList<KohlsReturnLCSOutJson.CouponDetail>();
        List<KohlsReturnLCSOutJson.ResponseDetail> listRespDetail = new ArrayList<KohlsReturnLCSOutJson.ResponseDetail>();
        KohlsReturnsLCSDeactivation objLCSDeactivation = new KohlsReturnsLCSDeactivation() ;
        Document docLCSOutput = null;
        KohlsReturnLCSOutJson returnsLCSPAResp = gson.fromJson(jsonResponse, KohlsReturnLCSOutJson.class);
        
        //Clear all previous LCS Promotions
        
        clearPreviousLCSPromotions(env, input, source);
        
        List lEcommStores = objLCSDeactivation.populateEcommStores(env);
        
        docLCSOutput = objLCSDeactivation.getOrderListDetails(env, input);
        Document docLCSDeactivatedOutput = XMLUtil.createDocument(XMLUtil.getChildElement(docLCSOutput.getDocumentElement(), KohlsXMLLiterals.E_ORDER));
        boolean bDisplayUIPrompt = true;
        Element eleOrder = docLCSDeactivatedOutput.getDocumentElement();
        double dTotalRefund=0.0;
        
        //Clear all previous LCS Promotions
        
       // clearPreviousLCSPromotions(env, docLCSDeactivatedOutput);
        
        String sStoreID = eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
        String sTerminalID = eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        //Getting current businessDate
        Date currentBusinessDay = getCurrentBusinessDay (env, sStoreID, sTerminalID);
        logger.debug("Current business Date is: "+currentBusinessDay);
       
        //check the  mapping and uncomment.
        String pocFeature = input.getDocumentElement().getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE);
        if(KohlsConstants.RECEIPTED_RETURN.equalsIgnoreCase(pocFeature)) {
            // receipted return
            dTotalRefund = Double.parseDouble(input.getDocumentElement().getAttribute(
                KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT));
        } else {
            // price adjustment
            dTotalRefund = Double.parseDouble(input.getDocumentElement().getAttribute(
                    KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT));
            objLCSDeactivation.dRefundAmount = dTotalRefund;
            objLCSDeactivation.dRefundAmount_Temp = dTotalRefund;
        }
        DecimalFormat df = new DecimalFormat("#0.00");
        SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat sdf2 = new SimpleDateFormat("dd");
        //Date currentDate = new Date();
        
        //sNetPrice = df.format(dTempTotal);
        Element elePromotions=XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
        NodeList nlPromotionOrder = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
        int iNoPromotions = nlPromotionOrder.getLength();
        if (returnsLCSPAResp != null) {
            for (KohlsReturnLCSOutJson.ResponseDetail respDetail : returnsLCSPAResp.getResponseDetails()) {
            	iNoPromotions++;
                if(YFCDocument.isVoid(elePromotions)){
                    elePromotions = XMLUtil.createChild(eleOrder,KohlsPOCConstant.E_PROMOTIONS);
                }
                
                if(!YFCCommon.isVoid(respDetail.getRefundDeduction())) {
                    Double dRefundDeduction = Double.parseDouble(respDetail.getRefundDeduction());
                    eleOrder.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION, df.format(dRefundDeduction));
                }
                
                String sCouprSrc="";
                 // check if promotion previously created 
                sCouprSrc="";
                sCouprSrc = respDetail.getStoreNumber();
                sCouprSrc = sCouprSrc+KohlsPOCConstant.MINUS+KohlsPoCPnPUtil.prepadString(respDetail.getRegisterId(), 2, "0");;
                // Pad LCS transaction number if needed
                if (!YFCCommon.isVoid(respDetail.getTransactionNumber()) &&
                        respDetail.getTransactionNumber().length() < 4) {
                    String transactionNumber = respDetail.getTransactionNumber();
                    while (transactionNumber.length() < 4) {
                        transactionNumber = "0" + transactionNumber;
                    }
                    respDetail.setTransactionNumber(transactionNumber);
                }
                sCouprSrc = sCouprSrc+KohlsPOCConstant.MINUS+respDetail.getTransactionNumber();
                NodeList nlPromotion = SCXmlUtil.getXpathNodes(eleOrder, 
                    "//Order/Promotions/Promotion[@PromotionType='"+ KohlsPOCConstant.LOYALTY_KC_UNEARNED + "'][Extn/@ExtnCouponSourceCode='"+sCouprSrc+"']");
                  if(nlPromotion.getLength() == 0) {
                    elePromotion=XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
                  } else {
                    elePromotion = (Element)nlPromotion.item(0);
                  }

                //KohlsPOCConstant.LOYALTY_KC_UNEARNED)
                elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE,KohlsPOCConstant.LOYALTY_KC_UNEARNED);
                elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, respDetail.getLoyaltyId()+KohlsPOCConstant.UNDERSCORE+respDetail.getTransactionNumber()+KohlsPOCConstant.UNDERSCORE+iNoPromotions);
                elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.NO);
                Element elePromotionExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN, true);
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_LOYALTY_NUMBER, respDetail.getLoyaltyId());
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_EVERYDAY_EARN_KCC, respDetail.getEverydayEarnKccDelta());
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_EVERYDAY_EARN_NON_KCC, respDetail.getEverydayEarnNonKccDelta());
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_EARN_TRACKER_DELTA, respDetail.getEarnTrackerDelta());
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_EARN_TRACKER_STATING_BALANCE, respDetail.getEarnTrackerStartingBalance());
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE, sCouprSrc);
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_REASON_CODE, "PREREDEMPTION");
                elePromotionExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
                
                elePromotion.setAttribute("DisplayUIPrompt", "false");
                
                eleOrder.setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dTotalRefund));
                
                logger.debug("Processing Promotion for "+sCouprSrc);
                boolean bPromotionCreated = true;
               if(respDetail.getCouponDetails() != null) {
                 for (KohlsReturnLCSOutJson.CouponDetail cpnDetail : respDetail.getCouponDetails()) {
                   //Reset the flag
                   bDisplayUIPrompt = true;
                   //Processing second coupon.
                   if(!bPromotionCreated) {
                    elePromotion=XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
                    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE,KohlsPOCConstant.LOYALTY_KC_UNEARNED);
                    elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_APPLIED, KohlsPOCConstant.YES);
                    eleExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN, true);
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
                   }
                   //processing first coupon. so using promotion crated before the loop.
                   if (bPromotionCreated) {
                     bPromotionCreated = false;
                   }
                   eleExtn = XMLUtil.getChildElement(elePromotion, KohlsPOCConstant.A_EXTN, true);
                   eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED, "Y");
                   elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, cpnDetail.getBarcode()+KohlsPOCConstant.UNDERSCORE+respDetail.getTransactionNumber());
                   elePromotion.setAttribute(KohlsXMLLiterals.A_EXTN_COUPON_NO, cpnDetail.getBarcode());
                   //Need to check the below one terminal id is not there in the JSONResponse 
                   eleExtn.setAttribute(KohlsPOCConstant.A_EXTNCOUPONNO, cpnDetail.getBarcode());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE, sCouprSrc);
                   eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_INITIAL_OFFER_AMT, df.format(Math.abs(Double.parseDouble(cpnDetail.getInitialCouponValue()))));
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION, df.format(Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction()))));
                   if(!YFCCommon.isVoid(cpnDetail.getEventEarnDelta())) {
                     eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_UNEARNED_VALUE, df.format(Math.abs(Double.parseDouble(cpnDetail.getEventEarnDelta()))));
                     eleExtn.setAttribute(KohlsPOCConstant.EXTN_EVENT_COUPON_UNEANRD_AMT, df.format(Math.abs(Double.parseDouble(cpnDetail.getEventEarnDelta()))));
                   }
                   
                   //eleExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, "");
                   eleExtn.setAttribute(KohlsPOCConstant.E_EXTN_START_DATE, cpnDetail.getRedemptionStartDate());
                   eleExtn.setAttribute(KohlsPOCConstant.E_EXTN_END_DATE, cpnDetail.getRedemptionEndDate());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_LOYALTY_NUMBER, respDetail.getLoyaltyId());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_EVERYDAY_EARN_KCC, respDetail.getEverydayEarnKccDelta());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_EVERYDAY_EARN_NON_KCC, respDetail.getEverydayEarnNonKccDelta());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_EARN_TRACKER_DELTA, respDetail.getEarnTrackerDelta());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_EARN_TRACKER_STATING_BALANCE, respDetail.getEarnTrackerStartingBalance());
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE, df.format(Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue()))));
                   eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE, df.format(Math.abs(Double.parseDouble(cpnDetail.getCouponStartingBalance()))));
                   if (!YFCCommon.isVoid(cpnDetail.getEligibleAmountDelta())) {
                     eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ELIGLEBLE_AMT, df.format(Math.abs(Double.parseDouble(cpnDetail.getEligibleAmountDelta()))));
                     eleExtn.setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, df.format(Math.abs(Double.parseDouble(cpnDetail.getEligibleAmountDelta()))));
                   }
                   Element eleMaximizeRefund  = XMLUtil.createChild(elePromotion, KohlsPOCConstant.MAX_REFUND);
                   eleMaximizeRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(dTotalRefund));
                   if(!YFCCommon.isVoid(cpnDetail.getEventEarnDelta())) {
                     eleMaximizeRefund.setAttribute(KohlsPOCConstant.UNEARNED_KC, df.format(Math.abs(Double.parseDouble(cpnDetail.getEventEarnDelta()))));
                   }
                   eleMaximizeRefund.setAttribute(KohlsPOCConstant.REF_DEDUCTION, df.format(Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction()))));
                   eleExtn.setAttribute(KohlsPOCConstant.EXTN_REDEMPTION_PERIOD, 
                           calculteRedemptionPeriod(cpnDetail.getRedemptionStartDate(), cpnDetail.getRedemptionEndDate()));
                   //Set other attributes on Promotion
                   objLCSDeactivation.updateOutputDocPromotion(env, elePromotion, "Y", df.format(dTotalRefund), "MaximizeRefund", currentBusinessDay);
                   if (Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue())) == 0.00D && Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction())) == 0.00D) {
                     logger.error(pocFeature+": "+sCouprSrc+": Condition 1 satisfied. Hence Prompt will not be displayed. "
                         + "UnearnedValue:"+ cpnDetail.getUnearnedValue()+", CpnRefundDeduction: "+cpnDetail.getCpnRefundDeduction());
                     bDisplayUIPrompt = false;
                     eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, "");
                   }
                   if (Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue())) > 0.00D && Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction())) == 0 
                       && currentBusinessDay.after(sdf1.parse(cpnDetail.getRedemptionEndDate()))) {
                     bDisplayUIPrompt = false;
                     eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
                     logger.error(pocFeature+": "+sCouprSrc+": Condition 2 satisfied. Hence Prompt not displayed. "+
                      "UnearnedValue: "+cpnDetail.getUnearnedValue()+", CpnRefundDeduction: "+cpnDetail.getCpnRefundDeduction()+", currentDate: "+ 
                      currentBusinessDay+", RedemptionEndDate: "+cpnDetail.getRedemptionEndDate());
                   }
                   elePromotion.setAttribute("DisplayUIPrompt", String.valueOf(bDisplayUIPrompt));
                   //listCpnDetail.add(cpnDetail);
                 }
               }
                
                //respDetail.setCouponDetails(listCpnDetail);
                
                //check if no coupon unearned
                if(respDetail.getCouponDetails() != null && respDetail.getCouponDetails().size() == 0) {
                  logger.error(pocFeature+": "+sCouprSrc+": No Coupon details received from LCS. Hence Prompt not displayed.");
                  bDisplayUIPrompt = false;
                  elePromotion.setAttribute("DisplayUIPrompt", String.valueOf(bDisplayUIPrompt));
                }
                
                //Getting each order lines from the input xml
                Element eleOrderLines=XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);
                
                String sRefundDeduction = "0.00";
                if(!YFCCommon.isVoid(respDetail.getRefundDeduction())) {
                  sRefundDeduction = respDetail.getRefundDeduction();
                }
                //Clear LinePrice Map (logic moved from KohlsReturnsLCSDeactivation.addRefundDeductionCharges method)
                if(YFCCommon.isVoid(source)) {
                  objLCSDeactivation.mapLinePrice.clear();
                }
                //if source is V2Unearn - skip this processing - this will be done later
                if(eleOrderLines!=null && respDetail.getCouponDetails() != null && respDetail.getCouponDetails().size() > 0 
                    && Double.parseDouble(sRefundDeduction) > 0.00D){
                    //Getting each order line from the input xml
                    NodeList listOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
                    int ilistLineCount= listOrderLines.getLength();

                    // Extracting each order line from the input xml
                    for (int iOrderLine = 0; iOrderLine < ilistLineCount; iOrderLine++) {

                        Element eleOrderLine = (Element) listOrderLines.item(iOrderLine);           
                        Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_EXTN);
                        //Getting CustomAttributes element from the orderline
                        Element eleCustomAttributes = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
                        String sOrigTranNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
                        String sOrigOrderNo = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT6);
                        String sRegisterId = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
                        String sPrimeLine = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
                        String sText12 = eleCustomAttributes.getAttribute("Text12");
                        String sText11 = eleCustomAttributes.getAttribute("Text11");
                        String sText7 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT7);
                        String sText8 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT8);
                        String sText9 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9);
                        String sText10 = eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT10);
                        String sText13 = eleCustomAttributes.getAttribute("Text13");
                        //Incase of PSA
                        if(YFCCommon.isVoid(eleCustomAttributes.getAttribute(KohlsPOCConstant.TEXT9))){
                        	String sSource[] = sCouprSrc.split("-"); 
                        	sOrigTranNo  = sSource[2];
                        	sRegisterId = sSource[1];
                        }
                        Boolean itemExist =false;
                        String sEligible="";
                        String sLCSNetPrice = "";
                        for (KohlsReturnLCSOutJson.Product prdouct : respDetail.getProducts()) {
                            if( Integer.parseInt(sOrigTranNo) == Integer.parseInt(respDetail.getTransactionNumber())
                                    //&& sOrigOrderNo.equalsIgnoreCase(respDetail.getOrderNumber())
                                    &&  sRegisterId.equalsIgnoreCase(respDetail.getRegisterId()) 
                                    &&  sPrimeLine.equalsIgnoreCase(prdouct.getLineNumber())){
                                itemExist = true;
                                if(YFCCommon.isVoid(source)) {
                                //CPE-12427 changes
                                  if (!YFCCommon.isVoid(sText13)) {
                                    Element eleTax = (Element) eleOrderLine.getElementsByTagName("LineTax").item(0);
                                    objLCSDeactivation.mapOrigtaxRate.put(sText7+"-"+sText8+"-"+sText9+"-"+sText10,
                                        Double.parseDouble(eleTax.getAttribute("TaxPercentage")));
                                  }
                                  //Storing the line Total before refund deduction in map.
                                  if (pocFeature.equalsIgnoreCase(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                                    Element eleLineOverallTotals =
                                        XMLUtil.getChildElement(eleOrderLine, KohlsPOCConstant.E_LINE_OVERALL_TOTALS);
                                    String sNetPrice = eleLineOverallTotals.getAttribute("LineTotalWithoutTax");
                                    if (pocFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                                      Double dText12 = 0.00D;
                                      if (!YFCCommon.isVoid(sText12)) {
                                        dText12 = Double.parseDouble(sText12);
                                      }
                                      sNetPrice = eleOrderLineExtn.getAttribute(KohlsPOCConstant.A_EXTN_RETURN_PRICE);
                                      double dTempTotal = dText12 - Double.parseDouble(sNetPrice);
                                      sNetPrice = df.format(dTempTotal);
                                      Double dDeltaTaxForPA = 0.00;
                                      if (dTempTotal > 0 && sText11.equalsIgnoreCase("Eligible")) {
                                        Element eleOrderLineTax = (Element) eleOrderLine
                                            .getElementsByTagName(KohlsPOCConstant.ELEM_LINE_TAX).item(0);
                                        Element eleOrderLineTaxExtn =
                                            XMLUtil.getChildElement(eleOrderLineTax, KohlsPOCConstant.E_EXTN);
                                        String strCurrentTax =
                                            eleOrderLineTax.getAttribute(KohlsPOCConstant.ATTR_TAX);
                                        String strInitialTax = eleOrderLineTaxExtn.getAttribute("ExtnOrigTaxAmt");
                                        if ((!YFCCommon.isVoid(strCurrentTax))
                                            && (!YFCCommon.isVoid(strInitialTax))) {
                                          dDeltaTaxForPA =
                                              Double.parseDouble(strInitialTax) - Double.parseDouble(strCurrentTax);
                                        }
                                        Double dAdjustedLineTotal = dTempTotal + dDeltaTaxForPA;
                                        objLCSDeactivation.mapLinePrice.put(sPrimeLine, dAdjustedLineTotal);
                                        dDeltaTaxForPA = 0.00;
                                      } 
                                    }
                                  } else {
                                    Element eleLinePriceInfo = (Element) eleOrderLine
                                        .getElementsByTagName(KohlsPOCConstant.E_LINE_PRICE_INFO).item(0);
                                    String sLineTotal = eleLinePriceInfo.getAttribute(KohlsPOCConstant.A_LINE_TOTAL);
                                    objLCSDeactivation.mapLinePrice.put(sPrimeLine, Double.parseDouble(sLineTotal));
                                  }   
                                }                       
                                sEligible = prdouct.getKohlsCashEligible();
                                sLCSNetPrice = new DecimalFormat ("0.00#").format(Math.abs(Double.parseDouble(prdouct.getNetPrice())));
                                break;
                            }
                        }
                        
                        if(itemExist && !YFCObject.isVoid(eleOrderLineExtn) && KohlsPOCConstant.TRUE.equalsIgnoreCase(sEligible)) {
                            eleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE, sEligible);
                            if(!YFCCommon.isVoid(source)) {
                              eleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_NET_PRICE, sLCSNetPrice);
                              eleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_RETURN_PRICE, sLCSNetPrice);
                            }
                        }
                    }
                    eleOrder.setAttribute(KohlsXMLLiterals.A_LAST_RECEIPT_PROCESSED, sCouprSrc);
                    String sRefundWithtax="0.0";
                    
                    docLCSDeactivatedOutput = objLCSDeactivation.deactivateKohlsCash(env, docLCSDeactivatedOutput, currentBusinessDay, source);
                        
                        // commenting out IsProcessed for now
                    NodeList eleProcessPromotions = SCXmlUtil.getXpathNodes(docLCSDeactivatedOutput.getDocumentElement(), 
                        "//Order/Promotions/Promotion[@PromotionType='"+ KohlsPOCConstant.LOYALTY_KC_UNEARNED + "']");
                    for (int i=0; i < eleProcessPromotions.getLength(); i++) {
                      Element currentPromotion = (Element) eleProcessPromotions.item(i);
                      Element currentExtnNode = SCXmlUtil.getChildElement(currentPromotion, KohlsXMLLiterals.E_EXTN);
                      if (sCouprSrc.equalsIgnoreCase(currentExtnNode.getAttribute(KohlsXMLLiterals.A_EXTN_COUPON_SOURCE_CODE))) {
                        // found a match to current LCS promo
                        Element maximizeRefundElement = SCXmlUtil.getChildElement(currentPromotion, KohlsXMLLiterals.E_MAXIMIZE_REFUND);
                        if (maximizeRefundElement != null) {
                          sRefundWithtax = maximizeRefundElement.getAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT);
                          //PLYT-1784 Keeping track if running total
                          Double dTotalRefund_temp = Double.valueOf(df.format(Double.valueOf(sRefundWithtax)));
                          //PLYT-1790 single transaction multiple coupon. Take lowest amt.
                          if(dTotalRefund_temp < dTotalRefund) {
                            dTotalRefund = dTotalRefund_temp;
                            docLCSDeactivatedOutput.getDocumentElement().setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT, df.format(Double.parseDouble(sRefundWithtax)));
                          } else {
                            maximizeRefundElement.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT, df.format(dTotalRefund));
                          }
                        }
                      }
                    }
                }
                
                
                boolean bPromotionAvailableForChangeOrder = false;
                Document docChangeOrder = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
                Element eleChangeOrderRoot = docChangeOrder.getDocumentElement();
                eleChangeOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
                eleChangeOrderRoot.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
                eleChangeOrderRoot.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
                eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_ACTION, KohlsConstant.MODIFY);
                Element eleChangeOrderPromotions = docChangeOrder.createElement(KohlsPOCConstant.E_PROMOTIONS);
                eleChangeOrderRoot.appendChild(eleChangeOrderPromotions);
                
                NodeList eleProcessPromotions = SCXmlUtil.getXpathNodes(docLCSDeactivatedOutput.getDocumentElement(), 
                    "//Order/Promotions/Promotion[@PromotionType='"+ KohlsPOCConstant.LOYALTY_KC_UNEARNED + "'][@DisplayUIPrompt='false']");
                for (int i=0; i < eleProcessPromotions.getLength(); i++) {
                  Element currentPromotion = (Element) eleProcessPromotions.item(i);
                  Element currentExtnNode = SCXmlUtil.getChildElement(currentPromotion, KohlsXMLLiterals.E_EXTN);
                  if (sCouprSrc.equalsIgnoreCase(currentExtnNode.getAttribute(KohlsXMLLiterals.A_EXTN_COUPON_SOURCE_CODE))) {
                      // found a match to current LCS promo
                    XMLUtil.importElement(eleChangeOrderPromotions, currentPromotion);
                    elePromotions.removeChild(currentPromotion);
                    bPromotionAvailableForChangeOrder = true;
                  }
                }
                if(bPromotionAvailableForChangeOrder) {
                  //ISS change - start
                  if (ServerTypeHelper.amIOnEdgeServer()) {
                    String sEndpoint = "";
                    if (!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
                      sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
                    }
                    if (!YFCCommon.isVoid(pocFeature)
                        && pocFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                      Element eleAdditionalInfo =
                          SCXmlUtil.createChild(eleChangeOrderRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
                          KohlsXMLLiterals.V_MOTHERSHIP);
                    } else if (!YFCCommon.isVoid(sEndpoint)) {
                      Element eleAdditionalInfo =
                          SCXmlUtil.createChild(eleChangeOrderRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                      eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
                    }
                  }
                  //ISS change - end
                  Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
                  if(logger.isDebugEnabled()) {
                    logger.debug("KohlsReturnsLCSCallWrapper.processOutputForLCSReturnsPA Input to changeOrder is: "+XMLUtil.getXMLString(docChangeOrder));
                  }
                  env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
                  KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API, docChangeOrder);
                  env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "");
                }
            }
        }
        
        //TrimdocFinalAgainstXsdTemplate(docLCSDeactivatedOutput);
        logger.endTimer("KohlsReturnsLCSCallWrapper.processOutputForLCSReturnsPA");
        return  docLCSDeactivatedOutput;
    }
    
    /**
   * Create By ibmadmin * 
   * @param env
   * @param docLCSOutput
     * @throws Exception 
   */
  private void clearPreviousLCSPromotions(YFSEnvironment env, Document docLCSOutput, String source) throws Exception {
    logger.beginTimer("KohlsReturnsLCSCallWrapper.clearPreviousLCSPromotions");
    String sExtnPOCFeature = "";
    Document docChangeOrder = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
    Element eleChangeOrderRoot = docChangeOrder.getDocumentElement();
    String sOrderHeaderKey = docLCSOutput.getDocumentElement().getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
    eleChangeOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
    eleChangeOrderRoot.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
    eleChangeOrderRoot.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
    eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_ACTION, KohlsConstant.MODIFY);
    Element eleChangeOrderPromotions = docChangeOrder.createElement(KohlsPOCConstant.E_PROMOTIONS);
    eleChangeOrderRoot.appendChild(eleChangeOrderPromotions);
    
    boolean bPromotionPresentForChangeOrder = false;
    
    Element eleOrderExtn = XMLUtil.getChildElement(docLCSOutput.getDocumentElement(), KohlsPOCConstant.E_EXTN);
    if(!YFCCommon.isVoid(eleOrderExtn)) {
      sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
      
      if((!YFCCommon.isVoid(sExtnPOCFeature) && (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sExtnPOCFeature) 
          || KohlsPOCConstant.RECEIPTED_RET.equalsIgnoreCase(sExtnPOCFeature))) || !YFCCommon.isVoid(source)) {
        Element elePromotions = XMLUtil.getChildElement(docLCSOutput.getDocumentElement(), KohlsPOCConstant.E_PROMOTIONS);
        if(!YFCCommon.isVoid(elePromotions)) {
          NodeList nlPromotion = elePromotions.getElementsByTagName(KohlsPOCConstant.E_PROMOTION);
          for (int i=0; i< nlPromotion.getLength(); i++) {
            Element elePromotion = (Element) nlPromotion.item(i);
            String sPromotionType = elePromotion.getAttribute(KohlsCorpReturnsConstants.PROMOTION_TYPE);
            if(KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(sPromotionType)) {
              Element eleChageOrderPomotion = XMLUtil.importElement(eleChangeOrderPromotions, elePromotion);
              eleChageOrderPomotion.setAttribute("Action", "REMOVE");
              bPromotionPresentForChangeOrder = true;
            }
          }
        }
      } else {
        Element eleCustomAttributes = XMLUtil.createChild(eleChangeOrderRoot, KohlsPOCConstant.E_CUSTOM_ATTRIBUTES);
        
        Element eleChangeOrderExtn = XMLUtil.getChildElement(eleChangeOrderRoot, KohlsPOCConstant.E_EXTN, true);
        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_NUMBER, "");
        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE, "");
        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_REFUND_AMOUNT, "");
        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_DEACTIVATED, "");
        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_CPN_RETURN_AMOUNT, "");
        eleChangeOrderExtn.setAttribute("ExtnKCDReturnTenderAmount", "");
        eleChangeOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE, "");
        
        eleCustomAttributes.setAttribute("Decimal1", "0.00");
        eleCustomAttributes.setAttribute("Decimal2", "0.00");
        eleCustomAttributes.setAttribute("Decimal3", "0.00");
        eleCustomAttributes.setAttribute("Decimal4", "0.00");
        eleCustomAttributes.setAttribute("Decimal5", "0.00");
        eleCustomAttributes.setAttribute("Date3", "");
        eleCustomAttributes.setAttribute("Date4", "");
        eleCustomAttributes.setAttribute("Text11", "");
        eleCustomAttributes.setAttribute("Text16", "");
        eleCustomAttributes.setAttribute("Text17", "");
        eleCustomAttributes.setAttribute("Text19", "");
        eleCustomAttributes.setAttribute("Text20", "");
        
        bPromotionPresentForChangeOrder = true;
        
        //Reseting Kohls Cash data in Sale for PSA.
        Document docKohlsSaleForPSA = XMLUtil.getDocument("<Order OrderHeaderKey='"+sOrderHeaderKey+"' PSAKCData=''/>");
        if (ServerTypeHelper.amIOnEdgeServer()) {
          String sEndpoint = "";
          if (!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
            sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
          }
          if (!YFCCommon.isVoid(sEndpoint)) {
            Element eleAdditionalInfo =
                SCXmlUtil.createChild(docKohlsSaleForPSA.getDocumentElement(), KohlsXMLLiterals.E_YFCADDITIONALINFO);
            eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
          }
        }
        KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docKohlsSaleForPSA);
      }
      if (!YFCCommon.isVoid(eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS))) {
        Element changeOrderExtn = XMLUtil.getChildElement(eleChangeOrderRoot, KohlsPOCConstant.E_EXTN, true);
        changeOrderExtn.setAttribute(KohlsPOCConstant.EXTN_PSA_STATUS, 
                eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_PSA_STATUS));
      }
    }
    if(bPromotionPresentForChangeOrder) {
      Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
      
    //ISS change - start
      if (ServerTypeHelper.amIOnEdgeServer()) {
        String sEndpoint = "";
        if (!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
          sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
        }
        if (!YFCCommon.isVoid(sExtnPOCFeature)
            && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
          Element eleAdditionalInfo =
              SCXmlUtil.createChild(eleChangeOrderRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
          eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
              KohlsXMLLiterals.V_MOTHERSHIP);
        } else if (!YFCCommon.isVoid(sEndpoint)) {
          Element eleAdditionalInfo =
              SCXmlUtil.createChild(eleChangeOrderRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
          eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
        }
      }
      //ISS change - end
      
      if(logger.isDebugEnabled()) {
        logger.debug("KohlsReturnsLCSCallWrapper.clearPreviousLCSPromotions Input to changeOrder is: "+XMLUtil.getXMLString(docChangeOrder));
      }
      //env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
      KOHLSBaseApi.invokeAPI(env, docChangeOrderTemplate, KohlsConstant.CHANGE_ORDER_API, docChangeOrder);
      //env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "");
    } else {
      logger.debug("KohlsReturnsLCSCallWrapper.clearPreviousLCSPromotions: Promotion not present to remove. Hence ChangeOrder is not called");
    }
      
    logger.endTimer("KohlsReturnsLCSCallWrapper.clearPreviousLCSPromotions");
    
  }

  /**
   * Create By ibmadmin * 
   * @param env
   * @param jsonResponse
   * @param input
   * @return
   * @throws Exception
   */
  public Document processOutputForPSA(YFSEnvironment env, String jsonResponse, Document input) throws Exception{
        logger.beginTimer("KohlsReturnsLCSCallWrapper.processOutputForPSA");
        if (logger.isDebugEnabled()) {
          logger.debug("Input to processOutputForPSA is: "+ XMLUtil.getXMLString(input));
        }
        Element eleOrder = input.getDocumentElement();
        
        String sIndividualOfferId = eleOrder.getAttribute(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID);
        
        List<KohlsReturnLCSOutJson.CouponDetail> listCpnDetail = new ArrayList<KohlsReturnLCSOutJson.CouponDetail>();
        Element eleCustomAttrbs = (Element) eleOrder.getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);
        Element eleOrderExtn = XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN, true);
        SimpleDateFormat omsFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat lcsFormat = new SimpleDateFormat("MM/dd/yyyy");
        KohlsReturnLCSOutJson returnsLCSPSAResp = gson.fromJson(jsonResponse, KohlsReturnLCSOutJson.class);
        boolean bDisplayUIPrompt = true;
        DecimalFormat df = new DecimalFormat("0.00");
        SimpleDateFormat sdf2 = new SimpleDateFormat("dd");
        //Date currentDate = new Date();
        Element elePromotions=XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_PROMOTIONS);
        if(YFCDocument.isVoid(elePromotions)){
            elePromotions = XMLUtil.createChild(eleOrder,KohlsPOCConstant.E_PROMOTIONS);
        }
        Integer iTotalCouponsUnearned = 0;
        double originalTotalAmount = 0.0d;
        Element overallTotals = SCXmlUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_OVERALL_TOTALS);
        double totalAmount = 0.0d;
        double currentRefundAmount = 0.0d;
        try {
            originalTotalAmount = Double.parseDouble(eleOrder.getAttribute(KohlsXMLLiterals.A_ORIGINAL_TOTAL_AMOUNT));
            totalAmount = Double.parseDouble(overallTotals.getAttribute(KohlsXMLLiterals.A_GRAND_TOTAL));
            currentRefundAmount = originalTotalAmount - totalAmount;
            eleOrder.setAttribute(KohlsPOCConstant.REFUND_AMT, new DecimalFormat("#0.00").format(currentRefundAmount));
        } catch (Exception ex) {
            
        }
        
        //Clear all previous LCS Promotions
        clearPreviousLCSPromotions(env, input, "");
        
        String sStoreID = eleOrder.getAttribute(KohlsPOCConstant.SELLER_ORGANIZATION_CODE);
        String sTerminalID = eleOrder.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        
        Date currentDate = getCurrentBusinessDay (env, sStoreID, sTerminalID);
        logger.debug("Current business Date is: "+currentDate);
        
        Element elePromotionAppend=null;
        // see if we already have a LOYALTY_KC_UNEARNED PROMO
        boolean foundLoyaltyPromotion = false;
        ArrayList<Element> promotionElements = SCXmlUtil.getChildren(elePromotions, KohlsPOCConstant.E_PROMOTION);
        for (Element currentPromotion : promotionElements) {
            if (KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(
                    currentPromotion.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE))) {
                elePromotionAppend = currentPromotion;
                foundLoyaltyPromotion = true;
            }
        }
        if (!foundLoyaltyPromotion) {
            elePromotionAppend =XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
        }
        if (returnsLCSPSAResp != null) {
            for (KohlsReturnLCSOutJson.ResponseDetail respDetail : returnsLCSPSAResp.getResponseDetails()) {
                
                String sCouprSrc="";
                sCouprSrc = respDetail.getStoreNumber();
                sCouprSrc = sCouprSrc+KohlsPOCConstant.MINUS+respDetail.getRegisterId();
                // Pad LCS transaction number if needed
                if (!YFCCommon.isVoid(respDetail.getTransactionNumber()) &&
                     respDetail.getTransactionNumber().length() < 4) {
                    String transactionNumber = respDetail.getTransactionNumber();
                   while (transactionNumber.length() < 4) {
                     transactionNumber = "0" + transactionNumber;
                 }
                   respDetail.setTransactionNumber(transactionNumber);
                }
                sCouprSrc = sCouprSrc+KohlsPOCConstant.MINUS+respDetail.getTransactionNumber();
             
                // Setting lcsResponse level attributes:
                eleOrder.setAttribute(KohlsPOCConstant.ATTR_CUSTOMER_REWARDS_NO, respDetail.getLoyaltyId());
                eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_17, respDetail.getLoyaltyId());
                eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_19, respDetail.getEverydayEarnKccDelta());
                eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_20,respDetail.getEverydayEarnNonKccDelta());
                eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_16,respDetail.getEarnTrackerDelta());
                eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DECIMAL_4, respDetail.getEarnTrackerStartingBalance());
                
                iTotalCouponsUnearned = respDetail.getCouponDetails().size();

                //Persist how many coupons we received
                eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_INTEGER_1, String.valueOf(iTotalCouponsUnearned));
                
                if(iTotalCouponsUnearned > 0){
                  Element eleExtn = XMLUtil.getChildElement(elePromotionAppend, KohlsPOCConstant.A_EXTN, true);
                  
                  //PLYT-1689 if more than 1 coupons received from LCS, process the coupon that came from RS.
                  KohlsReturnLCSOutJson.CouponDetail cpnDetail= null;
                  if(iTotalCouponsUnearned > 1) {
                    for (KohlsReturnLCSOutJson.CouponDetail cpnDetail_Temp : respDetail.getCouponDetails()) {
                      String sBarCode = cpnDetail_Temp.getBarcode();
                      if(!YFCCommon.isVoid(sBarCode) && sBarCode.equalsIgnoreCase(sIndividualOfferId)) {
                        cpnDetail = cpnDetail_Temp;
                        break;
                      }
                    }
                    //if by chance nothing received from RS, then sort by RedemptionEndDate and take earliest one.
                    if(cpnDetail == null) {
                      Date earliestRedemptionEndDate = null;
                      for (KohlsReturnLCSOutJson.CouponDetail cpnDetail_Temp : respDetail.getCouponDetails()) {
                        String sRedemptionEndDate = cpnDetail_Temp.getRedemptionEndDate();
                        if(!YFCCommon.isVoid(sRedemptionEndDate)) {
                          Date dtRedemptionEndDate = lcsFormat.parse(sRedemptionEndDate);
                          if (YFCCommon.isVoid(earliestRedemptionEndDate)) {
                            earliestRedemptionEndDate = dtRedemptionEndDate;
                            cpnDetail = cpnDetail_Temp;
                          } 
                          if(dtRedemptionEndDate.before(earliestRedemptionEndDate)) {
                            earliestRedemptionEndDate = dtRedemptionEndDate;
                            cpnDetail = cpnDetail_Temp;
                          }
                        }
                      }
                    }
                  } else {
                    cpnDetail = (KohlsReturnLCSOutJson.CouponDetail) respDetail.getCouponDetails().get(0);
                  }
                  
                    eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_DETOKENIZED, "Y");
                    eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_NUMBER, cpnDetail.getBarcode());
                    eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE, KohlsXMLLiterals.CONST_MAXIMIZE_REFUND);
                    eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_REFUND_AMOUNT, String.valueOf(Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction()))));
                    eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_DEACTIVATED, String.valueOf(Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue()))));
                    eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_CPN_RETURN_AMOUNT, String.valueOf(Math.abs(Double.parseDouble(cpnDetail.getEligibleAmountDelta()))));
                    eleOrderExtn.setAttribute("ExtnKCDReturnTenderAmount", String.valueOf(Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue()))));
                    String startDate =  cpnDetail.getRedemptionStartDate();
                    String endDate =  cpnDetail.getRedemptionEndDate();
                    String strRedemptionPeriod = "";
                    if(!YFCCommon.isVoid(startDate) && !YFCCommon.isVoid(endDate)) {
                      try {
                          SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                            Date dtStartDate = sdf.parse(startDate);
                            Date dtEndDate = sdf.parse(endDate);
                            if(currentDate.before(dtStartDate)) {
                              strRedemptionPeriod = "PREREDEMPTION";
                            } else if (currentDate.after(dtEndDate)) {
                              strRedemptionPeriod = "POSTREDEMPTION";
                            } else {
                              strRedemptionPeriod = "ACTIVE";
                            }
                          } catch (ParseException e) {
                            e.printStackTrace();
                          }
                    }
                    if (strRedemptionPeriod.equals(KohlsPOCConstant.ACTIVE_CAPS)) {
                      eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE, KohlsXMLLiterals.CONST_ACTIVE);
                    } else if (strRedemptionPeriod.equals(KohlsPOCConstant.CONST_PRE_REDEMPTION)) {
                      eleOrderExtn.setAttribute( KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE, KohlsXMLLiterals.CONST_PREREDEMPTION);
                    } else if (strRedemptionPeriod.equals(KohlsPOCConstant.CONST_POST_REDEMPTION)) {
                      eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_EVENT_CODE, KohlsXMLLiterals.CONST_POSTREDEMPTION);
                    }
                    
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_REASON_CODE, strRedemptionPeriod);
                   
                    //eleCustomAttrbs.setAttribute(KohlsPOCConstant.Text20, cpnDetail.getBarcode());
                    //eleOrderExtn.setAttribute(KohlsPOCConstant.ATTR_EXTN_KCD_COUPON_NUMBER, cpnDetail.getBarcode());
                    eleOrder.setAttribute(KohlsPOCConstant.ATTR_CUSTOMER_REWARDS_NO, respDetail.getLoyaltyId());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DECIMAL_1, cpnDetail.getCouponStartingBalance());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DECIMAL_3, cpnDetail.getCpnRefundDeduction());
                    // deduct refund
                    //currentRefundAmount = currentRefundAmount - Double.parseDouble(cpnDetail.getCpnRefundDeduction());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DECIMAL_2, df.format(Math.abs(Double.parseDouble(cpnDetail.getEventEarnDelta()))));
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DECIMAL_4, respDetail.getEarnTrackerStartingBalance());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DECIMAL_5, cpnDetail.getInitialCouponValue());

                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DATE_3, omsFormat.format(lcsFormat.parse(cpnDetail.getRedemptionStartDate())));
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_DATE_4, omsFormat.format(lcsFormat.parse(cpnDetail.getRedemptionEndDate())));
                    listCpnDetail.add(cpnDetail);
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_11, 
                            calculteRedemptionPeriod(cpnDetail.getRedemptionStartDate(),cpnDetail.getRedemptionEndDate()));
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_17, respDetail.getLoyaltyId());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_19, respDetail.getEverydayEarnKccDelta());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_20, respDetail.getEverydayEarnNonKccDelta());
                    eleCustomAttrbs.setAttribute(KohlsXMLLiterals.A_TEXT_16, respDetail.getEarnTrackerDelta());
                    respDetail.setCouponDetails(listCpnDetail);
                    
                    //KohlsPOCConstant.LOYALTY_KC_UNEARNED)
                    elePromotionAppend.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, KohlsPOCConstant.LOYALTY_KC_UNEARNED);
                    elePromotionAppend.setAttribute(KohlsXMLLiterals.A_PROMOTION_ID, cpnDetail.getBarcode());

                    //Need to check the below one terminal id is not there in the JSONResponse 
                    eleExtn.setAttribute(KohlsPOCConstant.A_EXTNCOUPONNO, cpnDetail.getBarcode());
                   // eleExtn.setAttribute(KohlsPOCConstant.EXTN_COUPON_SOURCE_CODE, sCouprSrc);
                    eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_INITIAL_OFFER_AMT, df.format(Math.abs(Double.parseDouble(cpnDetail.getInitialCouponValue()))));
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_REFUND_DEDUCTION, df.format(Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction()))));
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_UNEARNED_VALUE, df.format(Math.abs(Double.parseDouble(cpnDetail.getEventEarnDelta()))));
                    //eleExtn.setAttribute(KohlsPOCConstant.E_EXTN_QUALIFYING_AMOUNT, "");
                    eleExtn.setAttribute(KohlsPOCConstant.E_EXTN_START_DATE, cpnDetail.getRedemptionStartDate());
                    eleExtn.setAttribute(KohlsPOCConstant.E_EXTN_END_DATE, cpnDetail.getRedemptionEndDate());
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_LOYALTY_NUMBER, respDetail.getLoyaltyId());
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_EVERYDAY_EARN_KCC, respDetail.getEverydayEarnKccDelta());
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_EVERYDAY_EARN_NON_KCC, respDetail.getEverydayEarnNonKccDelta());
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_EARN_TRACKER_DELTA, respDetail.getEarnTrackerDelta());
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_EARN_TRACKER_STATING_BALANCE, respDetail.getEarnTrackerStartingBalance());
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_EVENT_COUPON_UNEANRD_AMT, df.format(Math.abs(Double.parseDouble(cpnDetail.getEventEarnDelta()))));
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_TRAN_UNEARNED_VALUE, df.format(Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue()))));
                    eleExtn.setAttribute(KohlsPOCConstant.A_EXTN_COUPON_BALANCE, df.format(Math.abs(Double.parseDouble(cpnDetail.getCouponStartingBalance()))));
                    eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_ELIGLEBLE_AMT, df.format(Math.abs(Double.parseDouble(cpnDetail.getEligibleAmountDelta()))));
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_ELIGIBILITY_DEUCTION, df.format(Math.abs(Double.parseDouble(cpnDetail.getEligibleAmountDelta()))));
                    Element eleMaximizeRefund  = XMLUtil.createChild(elePromotionAppend, KohlsPOCConstant.MAX_REFUND);
                    eleMaximizeRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, df.format(currentRefundAmount));
                    eleMaximizeRefund.setAttribute(KohlsPOCConstant.UNEARNED_KC, df.format(Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue()))));
                    eleExtn.setAttribute(KohlsPOCConstant.EXTN_REDEMPTION_PERIOD, 
                            calculteRedemptionPeriod(cpnDetail.getRedemptionStartDate(), cpnDetail.getRedemptionEndDate()));
                    if (Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue())) == 0.00D && Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction())) == 0.00D) {
                      logger.error("PSA: "+sCouprSrc+": Condition 1 satisfied. Hence Prompt will not be displayed. "
                          + "UnearnedValue:"+ cpnDetail.getUnearnedValue()+", CpnRefundDeduction: "+cpnDetail.getCpnRefundDeduction());
                      bDisplayUIPrompt = false;
                      eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, "");
                      eleOrderExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_COUPON_CODE, KohlsXMLLiterals.CONST_NO_DEACTIVATION);
                    }
                    if (Math.abs(Double.parseDouble(cpnDetail.getUnearnedValue())) > 0.00D && Math.abs(Double.parseDouble(cpnDetail.getCpnRefundDeduction())) == 0 
                        && currentDate.after(lcsFormat.parse(cpnDetail.getRedemptionEndDate()))) {
                      bDisplayUIPrompt = false;
                      eleExtn.setAttribute(KohlsPOCConstant.EXTN_KC_OPT_SELECTED, KohlsPOCConstant.MAX_REFUND);
                      logger.error("PSA: "+sCouprSrc+": Condition 2 satisfied. Hence Prompt not displayed. "+
                          "UnearnedValue: "+cpnDetail.getUnearnedValue()+", CpnRefundDeduction: "+cpnDetail.getCpnRefundDeduction()+", currentDate: "+ 
                             currentDate+", RedemptionEndDate: "+cpnDetail.getRedemptionEndDate());
                    }
                } else {
                  //no coupon unearned
                  logger.error("PSA: "+sCouprSrc+": No Coupon details received from LCS. Hence Prompt not displayed.");
                  bDisplayUIPrompt = false;
                }
            }
        }
        // remove the payment methods and overal totalsbefore change order
        if(!YFCCommon.isVoid(eleOrder.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS).item(0))) {
          eleOrder.removeChild(eleOrder.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS).item(0));
        }
        if(!YFCCommon.isVoid(eleOrder.getElementsByTagName(KohlsXMLLiterals.E_OVERALL_TOTALS).item(0))) {
          eleOrder.removeChild(eleOrder.getElementsByTagName(KohlsXMLLiterals.E_OVERALL_TOTALS).item(0));
        }
        
        //save by calling change order
        Document docChangeOrderInput = XMLUtil.createDocument("Order");
        Element eleChangeOrderInput = docChangeOrderInput.getDocumentElement();
        eleChangeOrderInput.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
        eleChangeOrderInput.setAttribute(KohlsPOCConstant.A_OVERRIDE, KohlsPOCConstant.FLAG_Y);
        eleChangeOrderInput.setAttribute(KohlsXMLLiterals.A_ACTION, KohlsConstant.MODIFY);
        eleChangeOrderInput.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
        XMLUtil.importElement(eleChangeOrderInput, XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.E_EXTN));
        XMLUtil.importElement(eleChangeOrderInput, XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.CUST_ATTRIBUTES));
        
        //ISS change - start
        if (ServerTypeHelper.amIOnEdgeServer()) {
          String sEndpoint = "";
          if (!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
            sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
          }
          if (!YFCCommon.isVoid(sEndpoint)) {
            Element eleAdditionalInfo =
                SCXmlUtil.createChild(eleChangeOrderInput, KohlsXMLLiterals.E_YFCADDITIONALINFO);
            eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
          }
        }
        //ISS change - end
        
        if(logger.isDebugEnabled()) {
          logger.debug("Input xml to changeOrder is: "+XMLUtil.getXMLString(docChangeOrderInput));
        }
        
        KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_CHANGE_ORDER, docChangeOrderInput);
        
        if (!YFCCommon.isVoid(eleCustomAttrbs.getAttribute(KohlsXMLLiterals.A_DECIMAL_3)) && 
        		Double.parseDouble(eleCustomAttrbs.getAttribute(KohlsXMLLiterals.A_DECIMAL_3)) > 0.0D) {
        //Make returnable list for TVS call
            Document docReturnableList = XMLUtil.createDocument(KohlsXMLLiterals.E_KC_OUTPUT);
            Element rootEle = XMLUtil.createChild(docReturnableList.getDocumentElement(), KohlsXMLLiterals.A_DATA) ;
            Element paretnEle = XMLUtil.createChild(rootEle, KohlsXMLLiterals.E_RETURNABLE_ITEMLIST) ;
            //paretnEle.setTextContent(KohlsXMLLiterals.CONST_TRUE);
            
            //Getting each order lines from the input xml
            Element eleOrderLines=XMLUtil.getChildElement(eleOrder, KohlsPOCConstant.ELEM_ORDER_LINES);

            NodeList listOrderLines = eleOrderLines.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
            int ilistLineCount= listOrderLines.getLength();
            for (int iOrderLine = 0; iOrderLine < ilistLineCount; iOrderLine++) {

                Element eleOrderLine = (Element) listOrderLines.item(iOrderLine);           
                Element eleOrderLineExtn = XMLUtil.getChildElement(eleOrderLine, KohlsXMLLiterals.E_EXTN);
                //Getting CustomAttributes element from the orderline
                String sPrimeLine = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);

                // PSA should only be 1 receipt or 1 request
                List<KohlsReturnLCSOutJson.Product> productList = returnsLCSPSAResp.getResponseDetails().get(0).getProducts();
                for (KohlsReturnLCSOutJson.Product prd : productList) {
                    //check the values from orderline/custom attributes with  jsonresponse value from KohlsReturnLCSOutJson.Requestdetail. If the below condition is true then set the values to 
                    //Orderline/Extn
                    if(sPrimeLine.equalsIgnoreCase(prd.getLineNumber()) && "true".equalsIgnoreCase(prd.getKohlsCashEligible())){
                        if(!YFCObject.isVoid(eleOrderLineExtn)){
                          eleOrderLineExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KOHLS_CASH_ELIGIBLE, prd.getKohlsCashEligible());
                        }
                        Element returnableItemEle = XMLUtil.createChild(paretnEle, KohlsXMLLiterals.E_RETURNABLE_ITEM);
                        Element lineNoEle = XMLUtil.createChild(returnableItemEle, KohlsXMLLiterals.E_LINE_NO);
                        //lineNoEle.setNodeValue(eleOrderLine.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO));
                        lineNoEle.setTextContent(eleOrderLine.getAttribute(KohlsXMLLiterals.A_PRIME_LINE_NO));
                        Element deptEle = XMLUtil.createChild(returnableItemEle, KohlsXMLLiterals.E_DEPT);
                        //deptEle.setNodeValue(eleExtn.getAttribute(KohlsXMLLiterals.A_EXTN_ITEM_DEPT));
                        deptEle.setTextContent(eleOrderLineExtn.getAttribute(KohlsXMLLiterals.A_EXTN_ITEM_DEPT));
                        Element netPriceEle = XMLUtil.createChild(returnableItemEle, KohlsXMLLiterals.E_NET_PRICE);
                       // netPriceEle.setNodeValue(eleExtn.getAttribute(KohlsXMLLiterals.A_EXTN_NET_PRICE));
                        netPriceEle.setTextContent(eleOrderLineExtn.getAttribute(KohlsXMLLiterals.A_EXTN_NET_PRICE));
                        Element KohlsCashEligibleEle = XMLUtil.createChild(returnableItemEle, KohlsXMLLiterals.E_KOHLS_CASH_ELIGIBLE);
                        //KohlsCashEligibleEle.setNodeValue(KohlsPOCConstant.TRUE);
                        KohlsCashEligibleEle.setTextContent(KohlsPOCConstant.TRUE);
                    }
                }
            }
            KohlsTVSCallForKohlsCashEligibleItems firstTVSObj = new KohlsTVSCallForKohlsCashEligibleItems();
            Element eleMRRefundDeduction = null;
            eleMRRefundDeduction = XMLUtil.createChild(eleOrder, KohlsXMLLiterals.E_REFUND_DEDUCTION);
            //eleMRRefundDeduction.setNodeValue(eleCustomAttrbs.getAttribute(KohlsXMLLiterals.A_DECIMAL_2));
            eleMRRefundDeduction.setTextContent (eleCustomAttrbs.getAttribute(KohlsXMLLiterals.A_DECIMAL_3));
            Document firstTVSResponseForMRDoc = firstTVSObj
                    .prepareRequestForFirstTVSCall(env,
                            docReturnableList, eleOrder,
                            eleMRRefundDeduction);
            KohlsPSAKohlsCashDeactivation  objKCDeacticvation = new KohlsPSAKohlsCashDeactivation();
            Boolean bErrorsInTVS = objKCDeacticvation.checkForTVSResponseErrors(firstTVSResponseForMRDoc);
            Document secondTVSResponseForMRDoc = new KohlsSecondTVSCallForPSA().prepareRequestForSecondTVSCall(env, firstTVSResponseForMRDoc, eleOrder);
            bErrorsInTVS = objKCDeacticvation.checkForTVSResponseErrors(secondTVSResponseForMRDoc);
            
            Double dMaxRefRefundReduction = originalTotalAmount - objKCDeacticvation.calculateTempOrderPrice(secondTVSResponseForMRDoc);
            Double finalRefundForMaxRefund = currentRefundAmount - dMaxRefRefundReduction;
            Element eleMaximizeRefund  = XMLUtil.getChildElement(elePromotionAppend, KohlsPOCConstant.MAX_REFUND);
            eleMaximizeRefund.setAttribute(KohlsPOCConstant.REFUND_AMT, new DecimalFormat("#0.00").format(finalRefundForMaxRefund));
            eleOrder.setAttribute(KohlsPOCConstant.REFUND_AMT, new DecimalFormat("#0.00").format(finalRefundForMaxRefund));
            elePromotions = XMLUtil.getChildElement(eleOrder, KohlsXMLLiterals.E_PROMOTIONS);
              
            elePromotions.appendChild(input.importNode(elePromotionAppend, true));
            if (!bErrorsInTVS) {
                objKCDeacticvation.addRefundDeductionCharges(env,firstTVSResponseForMRDoc, input,
                        elePromotionAppend, KohlsPOCConstant.MAX_REFUND, eleOrder);
            }
        }
        
        
        // remove the KC EARNED PROMO
        ArrayList<Element> promotionFilterElements = SCXmlUtil.getChildren(elePromotions, KohlsXMLLiterals.E_PROMOTION);
        for (Element currentFilterPromotion : promotionFilterElements) {
            if (KohlsConstant.KOHLS_CASH.equalsIgnoreCase(currentFilterPromotion.getAttribute(KohlsXMLLiterals.A_PROMOTION_TYPE))) {
                // remove KOHLS_CASH promotion for PSA
                elePromotions.removeChild(currentFilterPromotion);
            }
            // If prompt is not to be displayed then remove the promotion
            if (!bDisplayUIPrompt 
                && KohlsPOCConstant.LOYALTY_KC_UNEARNED.equalsIgnoreCase(currentFilterPromotion.getAttribute(KohlsXMLLiterals.A_PROMOTION_TYPE))) {
              elePromotions.removeChild(currentFilterPromotion);
            }
        }
        //TrimdocFinalAgainstXsdTemplate(input);
        logger.endTimer("KohlsReturnsLCSCallWrapper.processOutputForPSA");
        return input;
    }
    
    /**
     * Create By ibmadmin * 
     * @param env
     * @param inDoc
     * @param loyaltyInfo
     * @param pocFeature
     * @return
     * @throws Exception
     */
    public String prepareInputForReturnsPA(YFSEnvironment env,Document inDoc, HashMap<String, String> loyaltyInfo, String pocFeature) throws Exception{
        logger.beginTimer("KohlsReturnsLCSCallWrapper.prepareInputForReturnsPA");
        KohlsReturnLCSInJson lcsInput = new KohlsReturnLCSInJson();
        List<KohlsReturnLCSInJson.RequestDetail> requestDetails = new ArrayList<KohlsReturnLCSInJson.RequestDetail>();
        lcsInput.setRequestDetails(requestDetails);
        //get Special SKus
        Document docCommonCodeOut = getCommonCodeListForSpecialSKU(env);
        List lSprecialSKU = getSpecialSKU(docCommonCodeOut);
        Element eleInDoc = inDoc.getDocumentElement();
        //Check Loyalty Store Version
        String organizationCode = eleInDoc.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        String loyaltyStore = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, 
            organizationCode, KohlsPOCConstant.EMPTY);
        String sLoyaltyStoreVersion = "";
        if(!YFCCommon.isVoid(loyaltyStore) && loyaltyStore.contains("V2")) {
          sLoyaltyStoreVersion = "V2";
        }
        //Getting each order line from the input xml
        NodeList listOrderLines = eleInDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
        SimpleDateFormat sterlingTimestampFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
        HashMap<String, KohlsReturnLCSInJson.RequestDetail> requestDetailsMap = new HashMap<String, KohlsReturnLCSInJson.RequestDetail>();
        // Extracting each order line from the input xml
        int numberOfSkus = 0;
        for (int iOrderLine = 0; iOrderLine < listOrderLines.getLength(); iOrderLine++) {

            Element eleOrderLine = (Element) listOrderLines.item(iOrderLine);           
            //Getting Extn element from the orderline
            Element eleExtn = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
            String sDepartment = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT);
            String sYourPrice = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE);
            String sLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
            //Getting Item element from the orderline
            Element eleItem = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);          
            String sItemId = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
            String sQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
            double dblQty = Double.parseDouble(sQty);
            if(dblQty < 1){
                continue;
            }
            if(sItemId.endsWith("000")|| lSprecialSKU.contains(sItemId)){
                continue;
            }
            //Getting CustomAttributes from the orderline
            Element eleCustomAttrbs = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.CUST_ATTRIBUTES).item(0);

            String sOrigTranNo = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT9);
            String sOrigOrderNo = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT6);
            String sOrigStoreNo = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT7);
            String sOrigRegisterId = eleCustomAttrbs.getAttribute(KohlsPOCConstant.TEXT8); 
            String sText11 = eleCustomAttrbs.getAttribute("Text11");
            String sText12 = eleCustomAttrbs.getAttribute("Text12");
            
            if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(pocFeature)) {
              Double dText12 = 0.00D;
              if (!YFCCommon.isVoid(sText12)) {
                dText12 = Double.parseDouble(sText12);
              }
              String sNetPrice = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE);
              double dTempTotal = dText12 - Double.parseDouble(sNetPrice);
              if (dTempTotal > 0 && sText11.equalsIgnoreCase("Eligible")) {
                sYourPrice = new DecimalFormat ("#0.00").format(dTempTotal);
              } else {
                continue;
              }
            }
            String requestKey = sOrigTranNo + sOrigOrderNo + sOrigStoreNo + sOrigRegisterId;
            String loyaltyRequestKey = sOrigStoreNo + "|" + sOrigRegisterId + "|" +  sOrigTranNo;
            String loyaltyValue = loyaltyInfo.get(loyaltyRequestKey);
            if(YFCCommon.isVoid(loyaltyValue)) {
              continue;
            }
            StringTokenizer loyaltyTokenzier = new StringTokenizer(loyaltyValue, "|");
            String loyaltyId = loyaltyTokenzier.nextToken();
            String everydayEarnKcc = loyaltyTokenzier.nextToken();
            String everydayEarnNonKcc = loyaltyTokenzier.nextToken();
            String eligibleAmt = loyaltyTokenzier.nextToken();

            KohlsReturnLCSInJson.RequestDetail requestDetail = requestDetailsMap.get(requestKey);
            if (YFCCommon.isVoid(requestDetail)) {
                requestDetail = lcsInput.new RequestDetail();
                ArrayList<KohlsReturnLCSInJson.Product> products = new ArrayList<KohlsReturnLCSInJson.Product>();
                requestDetail.setProducts(products);
                requestDetails.add(requestDetail);
                requestDetailsMap.put(requestKey, requestDetail);
            }

            requestDetail.setLoyaltyId(loyaltyId);
            requestDetail.setEverydayEarnNonKcc(Double.parseDouble(everydayEarnNonKcc));
            requestDetail.setEverydayEarnKcc(Double.parseDouble(everydayEarnKcc));
            
            requestDetail.setTransactionNumber(String.valueOf(Integer.parseInt(sOrigTranNo)));
            requestDetail.setOrderNumber(sOrigOrderNo);
            requestDetail.setStoreNumber(sOrigStoreNo);
            // make sure register id is numeric as well
            requestDetail.setRegisterId(String.valueOf(Integer.parseInt(sOrigRegisterId)));
            // need to format the date to YYYY-MM-DD
            Date orderTransactionDate = sterlingTimestampFormatter.parse(eleCustomAttrbs.getAttribute(KohlsPOCConstant.DATE2));
            requestDetail.setTransactionDate(dateFormatter.format(orderTransactionDate));
            // need to format the time to HH:MM:SS
            requestDetail.setTransactionTime(timeFormatter.format(orderTransactionDate));

            KohlsReturnLCSInJson.Product prd = lcsInput.new Product();
            if(!YFCCommon.isVoid(sDepartment)){
                prd.setDepartment(Integer.parseInt(sDepartment));
            }else{
                prd.setDepartment(0);
            }
            prd.setSku(sItemId);
            prd.setNetPrice(Double.parseDouble(sYourPrice) * -1);
            prd.setLineNumber(Integer.parseInt(sLineNo));
            requestDetail.getProducts().add(prd);
            //If its Loyalty V2 store then dont set eligibleAmount
            if(!"V2".equalsIgnoreCase(sLoyaltyStoreVersion)) {
              requestDetail.setEligibleAmount(Double.parseDouble(eligibleAmt));
            }
            numberOfSkus++;
           
        }

        if (numberOfSkus == 0) {
        	// don't send to LCS
          logger.error("KohlsReturnsLCSCallWrapper.prepareInputForReturnsPA: no skus found. So will not call LCS.");
          logger.endTimer("KohlsReturnsLCSCallWrapper.prepareInputForReturnsPA");
        	return "";
        }
        
        if (requestDetails.size() > 1) {
          Collections.sort(requestDetails);
        }

        String sRequest = gson.toJson(lcsInput).toString();
        
        if(logger.isDebugEnabled()) {
          logger.debug("Request is: "+sRequest);
        }

        logger.endTimer("KohlsReturnsLCSCallWrapper.prepareInputForReturnsPA");
        return sRequest;
    }
    
    /**
     * Create By ibmadmin * 
     * @param env
     * @param inDoc
     * @param loyaltyInfo
     * @return
     * @throws Exception
     */
    public String prepareInputForPSA(YFSEnvironment env, Document inDoc, HashMap<String, String> loyaltyInfo) throws Exception{
        logger.beginTimer("KohlsReturnsLCSCallWrapper.prepareInputForPSA");
        
        //get Special SKus
        KohlsReturnLCSInJson lcsInput = new KohlsReturnLCSInJson();
        List<KohlsReturnLCSInJson.RequestDetail> requestDetails = new ArrayList<KohlsReturnLCSInJson.RequestDetail>();
        lcsInput.setRequestDetails(requestDetails);
        Document docCommonCodeOut = getCommonCodeListForSpecialSKU(env);
        List lSprecialSKU = getSpecialSKU(docCommonCodeOut);
        Element eleInDoc = inDoc.getDocumentElement();

        //Getting each order line from the input xml
        NodeList listOrderLines = eleInDoc.getElementsByTagName(KohlsPOCConstant.ELEM_ORDER_LINE);
        SimpleDateFormat sterlingTimestampFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        SimpleDateFormat sterlingSimpleTimestampFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
        HashMap<String, KohlsReturnLCSInJson.RequestDetail> requestDetailsMap = new HashMap<String, KohlsReturnLCSInJson.RequestDetail>();
        Element promotions = XMLUtil.getChildElement(eleInDoc ,KohlsXMLLiterals.E_PROMOTIONS);
        KohlsKCSCallForPSA kcsForPSA = new KohlsKCSCallForPSA();
        
        // getting original sale  from Kohls_sale_for_psa table to compare the changed awards
        Document docKohlsSaleForPSAIn = XMLUtil.createDocument("KOHLSSalesForPsa");
        Element eleKohlsSaleForPSAInRoot = docKohlsSaleForPSAIn.getDocumentElement();
        eleKohlsSaleForPSAInRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY));
        // ISS changes - start
        if (ServerTypeHelper.amIOnEdgeServer()) {
            String sEndpoint = "";
            if(!YFCCommon.isVoid(env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT))) {
              sEndpoint = (String) env.getTxnObject(KohlsXMLLiterals.A_ENDPOINT);
            }
            if(!YFCCommon.isVoid(sEndpoint)) {
              Element eleAdditionalInfo = SCXmlUtil.createChild(
                  eleKohlsSaleForPSAInRoot, KohlsXMLLiterals.E_YFCADDITIONALINFO);
              eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
            }
        }
        // ISS changes - end
        Document docKohlsSaleForPSAOut = KohlsCommonUtil.invokeService(env,KohlsPOCConstant.SER_KOHLS_MANAGE_SALE_FOR_PSA, docKohlsSaleForPSAIn);
        String sOriginalSaleData = docKohlsSaleForPSAOut.getDocumentElement().getAttribute("OriginalSaleData");
        Element eleOrigOrderLines = null;
        if(!YFCCommon.isVoid(sOriginalSaleData)) {
          Document docOrigSaleData = XMLUtil.getDocument(sOriginalSaleData);
          eleOrigOrderLines = XMLUtil.getChildElement(docOrigSaleData.getDocumentElement(), KohlsPOCConstant.ELEM_ORDER_LINES);
        }
        env.setTxnObject("OriginalOrderLinesForPSA", eleOrigOrderLines);
        // Extracting each order line from the input xml
        int numberOfSkus = 0;
        for (int iOrderLine = 0; iOrderLine < listOrderLines.getLength(); iOrderLine++) {

            Element eleOrderLine = (Element) listOrderLines.item(iOrderLine);           
            //Getting Extn element from the orderline
            Element eleExtn = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);
            String sDepartment = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_ITEM_DEPT);
            //String sYourPrice = eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_NET_PRICE);
            Double dYourPrice = kcsForPSA.calculateItemDeltaPrice(eleOrderLine, promotions, eleOrigOrderLines);
            String sLineNo = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_PRIME_LINE_NO);
            //Getting Item element from the orderline
            Element eleItem = (Element) eleOrderLine.getElementsByTagName(KohlsPOCConstant.ELEM_ITEM).item(0);          
            String sItemId = eleItem.getAttribute(KohlsPOCConstant.A_ITEM_ID);
            String sQty = eleOrderLine.getAttribute(KohlsPOCConstant.ATTR_ORDERED_QTY);
            double dblQty = Double.parseDouble(sQty);
            if(dblQty < 1){
                continue;
            }
            if(sItemId.endsWith("000")|| lSprecialSKU.contains(sItemId)){
                continue;
            }
            // use the loyalty info key to grab txn, store, register
            String loyaltyKey = loyaltyInfo.keySet().iterator().next();
            StringTokenizer loyaltyKeyTokenizer = new StringTokenizer(loyaltyKey, "|");

            String sOrigStoreNo = loyaltyKeyTokenizer.nextToken();
            String sOrigRegisterId = loyaltyKeyTokenizer.nextToken();
            String sOrigTranNo = loyaltyKeyTokenizer.nextToken();
            String sOrigOrderNo = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORDER_NO);
            
            String requestKey = sOrigTranNo + sOrigOrderNo + sOrigStoreNo + sOrigRegisterId;
            // for PSA, only one
            String loyaltyValue = loyaltyInfo.values().iterator().next();
            StringTokenizer loyaltyValueTokenzier = new StringTokenizer(loyaltyValue, "|");
            String loyaltyId = loyaltyValueTokenzier.nextToken();
            String everydayEarnKcc = loyaltyValueTokenzier.nextToken();
            String everydayEarnNonKcc = loyaltyValueTokenzier.nextToken();
            String eligibleAmt = loyaltyValueTokenzier.nextToken();

            KohlsReturnLCSInJson.RequestDetail requestDetail = requestDetailsMap.get(requestKey);
            if (YFCCommon.isVoid(requestDetail)) {
                requestDetail = lcsInput.new RequestDetail();
                ArrayList<KohlsReturnLCSInJson.Product> products = new ArrayList<KohlsReturnLCSInJson.Product>();
                requestDetail.setProducts(products);
                requestDetails.add(requestDetail);
                requestDetailsMap.put(requestKey, requestDetail);
            }

            requestDetail.setLoyaltyId(loyaltyId);
            requestDetail.setEverydayEarnNonKcc(Double.parseDouble(everydayEarnNonKcc));
            requestDetail.setEverydayEarnKcc(Double.parseDouble(everydayEarnKcc));
            
            requestDetail.setTransactionNumber(String.valueOf(Integer.parseInt(sOrigTranNo)));
            requestDetail.setOrderNumber(sOrigOrderNo);
            requestDetail.setStoreNumber(sOrigStoreNo);
            requestDetail.setRegisterId(String.valueOf(Integer.parseInt(sOrigRegisterId)));
            // need to format the date to YYYY-MM-DD
            Date orderTransactionDate = sterlingTimestampFormatter.parse(eleInDoc.getAttribute(KohlsPOCConstant.A_ORDER_DATE));
            Element eleOrderExtn = XMLUtil.getChildElement(eleInDoc, KohlsPOCConstant.E_EXTN);
          	String strOrigReceiptID = XMLUtil.getAttribute(eleOrderExtn, KohlsPOCConstant.ATTR_EXTN_RECEIPT_ID);
          	
          	// Extract the Transaction Date time from receipt id if available
          	if(!YFCCommon.isVoid(strOrigReceiptID)) {
          	  String originalSaleTransactionNo = KohlsPoCCommonAPIUtil.getTransactionIdFromReceiptID(strOrigReceiptID);
              String originalSaleTransactionDateTime = KohlsPoCCommonAPIUtil.getOrderDateFromTransactionNumber( originalSaleTransactionNo );
              if(!YFCCommon.isVoid(originalSaleTransactionDateTime)){
                  orderTransactionDate = sterlingSimpleTimestampFormatter.parse(originalSaleTransactionDateTime);
              }
          	}
            requestDetail.setTransactionDate(dateFormatter.format(orderTransactionDate));
            // need to format the time to HH:MM:SS
            requestDetail.setTransactionTime(timeFormatter.format(orderTransactionDate));
            requestDetail.setEligibleAmount(Double.parseDouble(eligibleAmt));

            KohlsReturnLCSInJson.Product prd = lcsInput.new Product();
            if(!YFCCommon.isVoid(sDepartment)){
                prd.setDepartment(Integer.parseInt(sDepartment));
            }else{
                prd.setDepartment(0);
            }
            prd.setSku(sItemId);
            prd.setNetPrice(dYourPrice * -1);
            prd.setLineNumber(Integer.parseInt(sLineNo));
            requestDetail.getProducts().add(prd);
            numberOfSkus++;
        }
        if (numberOfSkus == 0) {
        	// don't send to LCS
          logger.error("KohlsReturnsLCSCallWrapper.prepareInputForPSA: no skus found. So will not call LCS.");
          logger.endTimer("KohlsReturnsLCSCallWrapper.prepareInputForPSA");
        	return "";
        }
        
        String sRequest  = gson.toJson(lcsInput).toString();
        if(logger.isDebugEnabled()) {
          logger.debug("Request is: "+sRequest);
        }
        logger.endTimer("KohlsReturnsLCSCallWrapper.prepareInputForPSA");
        
        return sRequest;
    }
    
    /**
     * Sterling OOB getCommonCodeList call to get list of special SKUs
     * 
     * @param env
     * @return
     * @throws Exception
     */
    protected Document getCommonCodeListForSpecialSKU(YFSEnvironment env) throws Exception {
        logger.beginTimer("KohlsReturnsLCSDeactivation.getCommonCodeListForSpecialSKU");
        Document docInputgetCommonCodeList = XMLUtil.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
        Element eleCommonCode = docInputgetCommonCodeList.getDocumentElement();
        eleCommonCode.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
                KohlsPOCConstant.VAL_KOHLS_SPL_ITEMS_RET);
        Document docCommonCodeListOuput = KOHLSBaseApi.invokeAPI(env,
                KohlsPOCConstant.API_GET_COMMON_CODE_LIST, docInputgetCommonCodeList);
        logger.endTimer("KohlsReturnsLCSDeactivation.getCommonCodeListForSpecialSKU");
        return docCommonCodeListOuput;
    }

    /**
     * List object preparation which contains special SKUs
     * 
     * @param docCommonCodeListOuput
     * @return
     */
    @SuppressWarnings("rawtypes")
    protected List getSpecialSKU(Document docCommonCodeListOuput) {

        logger.beginTimer("KohlsReturnsLCSDeactivation.getSpecialSKU");
        List<String> specialSKUlist = new ArrayList<String>();
        NodeList commonCodeNL =
                docCommonCodeListOuput.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);
        int commonCodeNLlen = commonCodeNL.getLength();
        for (int i = 0; i < commonCodeNLlen; i++) {

            Element eleCommonCode = (Element) commonCodeNL.item(i);
            specialSKUlist.add(eleCommonCode.getAttribute(KohlsXMLLiterals.A_CODE_VALUE));

        }

        logger.endTimer("KohlsReturnsLCSDeactivation.getSpecialSKU");
        return specialSKUlist;

    }
    /**
     * Create By ibmadmin * 
     * @param strStartDate
     * @param strEndDate
     * @return
     */
    protected String calculteRedemptionPeriod(String strStartDate, String strEndDate){
        //Start - SETTING REDEMPTION PERIOD for LCS section in receipt
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat mmmDD = new SimpleDateFormat("MMM dd, yyyy");
        SimpleDateFormat DDonly = new SimpleDateFormat("dd");
        String strRedemptionReceiptDate ="";
        try {
            Date dStart = sdf.parse(strStartDate);
            Date dEnd = sdf.parse(strEndDate);
            if(!YFCCommon.isVoid(strStartDate) && !YFCCommon.isVoid(strEndDate)){
                strRedemptionReceiptDate  = mmmDD.format(dStart);
                String temp = DDonly.format(dEnd);
                temp = "- "+temp+",";
                strRedemptionReceiptDate.replace(",",temp);
                return strRedemptionReceiptDate;
            }

        } catch (ParseException e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
        }
        return strRedemptionReceiptDate;
    }
    
    
    /**
     * Create By ibmadmin * 
     * @param docFinal
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    private void TrimdocFinalAgainstXsdTemplate(Document docFinal)
              throws ParserConfigurationException, SAXException, IOException {
            logger.beginTimer("TrimdocFinalAgainstXsdTemplate");
            logger.beginTimer("KohlsReturnsLCSCallWrapper.TrimdocFinalAgainstXsdTemplate");
            // Document document1 = XMLUtil.createDocument(docFinal.getElementsByTagName("Order").item(0));
            if (YFCCommon.isVoid(oTemplateDoc)) {
              InputStream fileToReadFrom = KohlsReturnsLCSCallWrapper.class
                  .getResourceAsStream(KohlsPOCConstant.ORDER_UNEARN_TEMPLATE);
              Document docTemplate = XMLUtil.getDocument(fileToReadFrom);
              oTemplateDoc = YFCDocument.getDocumentFor(docTemplate);
            }

            YFCDocument oOutDoc = YFCDocument.getDocumentFor(docFinal);

            YCPBCTemplateTrimmer oTempTrim = new YCPBCTemplateTrimmer();

            oTempTrim.trimTheOutputBasedOnTemplate(oOutDoc.getDocumentElement(),
                oTemplateDoc.getDocumentElement(), false);

            if (logger.isDebugEnabled()) {
              logger.debug("OutputDoc after trimming is --->" + oOutDoc.getDocumentElement());
            }
            logger.endTimer("KohlsReturnsLCSCallWrapper.TrimdocFinalAgainstXsdTemplate");
          }

    /**
     * @param env
     * @param sStoreID
     * @param sTerminalID
     * @return
     */
    public Date getCurrentBusinessDay (YFSEnvironment env, String sStoreID, String sTerminalID) {
      logger.beginTimer("KohlsReturnsLCSCallWrapper.getCurrentBusinessDay");
      Date dCurrentBusinessDate = new Date();
      SimpleDateFormat sdf = new SimpleDateFormat(KohlsPOCConstant.HD_DATE_FORMAT);
      try {
        Document docGetTillStatusListIn = XMLUtil.getDocument("<TillStatus  OrganizationCode='"+sStoreID+"' TerminalID='"+sTerminalID+"' CurrentTill='Y' CurrentStatus='Open'/>");
        Document docGetTillStatusListOut = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_GET_TILL_STATUS_LIST_FOR_POS, docGetTillStatusListIn);
        if(!YFCCommon.isVoid(docGetTillStatusListOut)) {
          Element eleTillStatus = (Element)docGetTillStatusListOut.getElementsByTagName(KohlsPOCConstant.E_TILL_STATUS).item(0);
          if(!YFCCommon.isVoid(eleTillStatus)) {
            String sBusinessDate = eleTillStatus.getAttribute(KohlsPOCConstant.A_BUSINESS_DAY);
            if(!YFCCommon.isVoid(sBusinessDate)) {
              dCurrentBusinessDate = sdf.parse(sBusinessDate);
            }
          }
        }
      } catch (Exception e) {
        logger.error("KohlsReturnsLCSCallWrapper.getCurrentBusinessDay: Error in getting business day");
        e.printStackTrace();
      }
      logger.endTimer("KohlsReturnsLCSCallWrapper.getCurrentBusinessDay");
      return dCurrentBusinessDate;
    }

}