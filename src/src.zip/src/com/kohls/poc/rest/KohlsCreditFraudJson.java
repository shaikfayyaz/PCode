package com.kohls.poc.rest;


public class KohlsCreditFraudJson {


		private String action;
		private String major;
		private String dept;
		private String subcls;
		private String risk_level;
		private String last_update_timestamp;
		private String updated_by;
		private String description;

		public String getAction() {
			return action;
		}

		public void setAction(String action) {
			this.action = action;
		}

		public String getMajorClass() {
			return major;
		}

		public void setMajorClass(String major) {
			this.major = major;
		}

		public String getDept() {
			return dept;
		}

		public void setDept(String dept) {
			this.dept = dept;
		}

		public String getSubClass() {
			return subcls;
		}

		public void setSubClass(String subcls) {
			this.subcls = subcls;
		}
		
		public String getRiskLevel() {
			return risk_level;
		}

		public void setRiskLevel(String risk_level) {
			this.risk_level = risk_level;
		}
		
		public String getLastUpdTS() {
			return last_update_timestamp;
		}
		
		public void setLastUpdTS(String last_update_timestamp) {
			this.last_update_timestamp = last_update_timestamp;
		}
		
		public String getUpdatedBy() {
			return updated_by;
		}
		
		public void setUpdatedBy(String updated_by) {
			this.updated_by = updated_by;
		}
		
		public String getDescription() {
			return description;
		}
		
		public void setDescription(String description) {
			this.description = description;
		}
}