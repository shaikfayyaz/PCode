package com.kohls.poc.rest;

import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import javax.xml.parsers.ParserConfigurationException;
import com.kohls.common.util.XMLUtil;

import com.kohls.poc.util.KohlsPoCMosUtil;

import org.apache.commons.json.JSONException;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCallMOSAPIWrapper {
	
	private final static String TOPIC = YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_TOPIC);
	private final static String BOOTSTRAP_SERVERS = YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_BOOTSTRAP_SERVERS);
	private final static String SESSION_TIMEOUT =  YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_SESSION_TIMEOUT);
	private final static String READ_TIMEOUT =  YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_READ_TIMEOUT);
	private final static String RESET_STRATEGY =  YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_RESET_STRATEGY);
	private final static String GROUP_ID =  YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_GROUPID);
	private final static String RETRY_THRESHOLD =  YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_RETRY_ATTEMPTS);
	private final static String POLL_INTERVAL =  YFSSystem.getProperty(KohlsPOCConstant.MOS_KAFKA_POLL_INTERVAL);
    public  KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
    public String filePrefix;
    private static String source ="";
    private static String type ="";
    private static String fromOffset ="";
    private Properties props;
    private static YFCLogCategory logger;
    static {
            logger = YFCLogCategory.instance(KohlsCallMOSAPIWrapper.class
            .getName());
    }
 
	//private ArrayList mosOutputList = new ArrayList<>()

    public Document callMOSAPI(YFSEnvironment env,Document input)
            throws Exception {
    	
    	logger.beginTimer("KohlsCallMOSAPIWrapper.callMOSAPI");    
    	source =  input.getDocumentElement().getAttribute(KohlsPOCConstant.E_SOURCE);
    	type =  input.getDocumentElement().getAttribute(KohlsPOCConstant.A_TYPE);
    	fromOffset =  input.getDocumentElement().getAttribute(KohlsPOCConstant.A_FROM_OFFSET);
    //	boolean createFlag = true;
    String currentOffsetData =	getMosOffsetData(env);
	/**if(!YFCCommon.isVoid(currentOffsetData))
    	{
		createFlag = false;
    	}**/
    	if(YFCCommon.isVoid(fromOffset) && KohlsPOCConstant.SYNC_DELTA.equalsIgnoreCase(type))
    	{
    		if(KohlsPOCConstant.MOS_STAND_ALONE.equalsIgnoreCase(source))
        	{
    			logger.info("Fetch Type is DELTA, but No offset provided in the input. trying to fetch offset from Database");  
        	}
    		fromOffset = currentOffsetData;
    	}
    	if(YFCCommon.isVoid(fromOffset))
    	{
    		if(KohlsPOCConstant.A_KOHLS_MOS_DATA.equalsIgnoreCase(source))
    		{
    			logger.info("Call is from MOS Agent. No offset found. changing Fetch type to FULL"); 
    		}
    		fromOffset = KohlsPOCConstant.ZERO;
    	}
    	else if (KohlsPOCConstant.ZERO.equalsIgnoreCase(fromOffset))
    	{
    		if(KohlsPOCConstant.A_KOHLS_MOS_DATA.equalsIgnoreCase(source))
    		{
    			logger.info("Call is from MOS Agent. Offset from DB came back as 0. changing Fetch type to FULL"); 
    		}
    	}
    	else
    	{
    		if(KohlsPOCConstant.A_KOHLS_MOS_DATA.equalsIgnoreCase(source))
    		{
    			logger.info("Call is from MOS Agent. Offset from DB came back as "+fromOffset+". Continuing as DELTA Fetch Type"); 
    		}
    	}
    	runConsumer();    	 
    	Document outMosDataOffset =createMosDataOffsetDoc();
	Element eleMosOffData=outMosDataOffset.getDocumentElement();
	eleMosOffData.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,
						KohlsPOCConstant.DEFAULT);
	eleMosOffData.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE,
						KohlsPOCConstant.UNIT_OF_MEASURE);
	if(!YFCCommon.isVoid(mosOutput))
	{
		XMLUtil.importElement(mosOutput.getDocumentElement(), eleMosOffData); 
	}
	else
	{
		mosOutput = SCXmlUtil.createDocument(KohlsPOCConstant.KOHLS_MOS_DATA_LIST);
		XMLUtil.importElement(mosOutput.getDocumentElement(), eleMosOffData); 
	}
    	if(KohlsPOCConstant.MOS_STAND_ALONE.equalsIgnoreCase(source))
    	{
    		if(!YFCCommon.isVoid(mosOutput))
    		{
    			kohlsMosUtil.toCheckUpdateOrCreate(source,mosOutput, env);
    			if (YFCLogUtil.isDebugEnabled()) {
    				logger.debug("Final Output --"+XMLUtil.getXMLString(mosOutput));
    			}
    		}    		
    		mosOutput = SCXmlUtil.createDocument(KohlsPOCConstant.KOHLS_MOS_DATA);
    		mosOutput.getDocumentElement().setAttribute(KohlsPOCConstant.MOS_TOTAL_FETCHED_RECORDS, String.valueOf(fetchedCount));   		
    	}    	
    
    	if(!KohlsPOCConstant.MOS_STAND_ALONE.equalsIgnoreCase(source))
    	{
    		logger.info("Sending the MOS Data list to Agent from KohlsCallMOSAPIWrapper");
    	}
    	logger.endTimer("KohlsCallMOSAPIWrapper.callMOSAPI");
    	return mosOutput;
    	
    }
    
   /* public void callManageRule(YFSEnvironment env) {
        Document inDocApi = null;
        try {
         inDocApi = XmlUtils.createDocument(KohlsPOCConstant.E_RULE);
        Element eleRootInDoc = inDocApi.getDocumentElement();     
        eleRootInDoc.setAttribute("RuleSetFieldName", "MOS_KAFKA_OFFSET");
        eleRootInDoc.setAttribute("RuleSetValue", String.valueOf(finalOffset));
       //eleCacheObject.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR_ATTR);
        KOHLSBaseApi.invokeAPI(env,"manageRule", inDocApi);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            //e.printStackTrace();
        		logger.error("Error while updating the offset value. Ignore and proceed");
        		logger.error("Error is "+e.getMessage());
        }
      }
    
    public String getRuleList(YFSEnvironment env) {
        Document inDocApi = null;
       // long currentOffset = 0; 
        String ruleValue = "0";
        try {
         inDocApi = XmlUtils.createDocument(KohlsPOCConstant.E_RULE);
        Element eleRootInDoc = inDocApi.getDocumentElement();     
        eleRootInDoc.setAttribute("RuleSetFieldName", "MOS_KAFKA_OFFSET");
       eleRootInDoc.setAttribute("MaximumRecords", "1");
       //eleCacheObject.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR_ATTR);
        Document outDoc = KOHLSBaseApi.invokeAPI(env,"getRuleList", inDocApi);
        if(outDoc.getDocumentElement().hasChildNodes())
        {
        		Element ruleEle = SCXmlUtil.getChildElement(outDoc.getDocumentElement(), "Rules");
        		ruleValue = ruleEle.getAttribute("RuleSetValue");
        		
        }
        } catch (Exception e) {
            // TODO Auto-generated catch block
	        	logger.error("Error while fetching the offset value. Ignore and proceed");
	    		logger.error("Error is "+e.getMessage());
        }
        return ruleValue;
      }
    */
    private static Consumer<Long, String> createConsumer() throws InterruptedException, ExecutionException {

    	logger.beginTimer("KohlsCallMOSAPIWrapper.Consumer");
    	
		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				LongDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				StringDeserializer.class.getName());
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, RESET_STRATEGY);
		props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, SESSION_TIMEOUT);
		props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, READ_TIMEOUT);
		final Consumer<Long, String> consumer = new KafkaConsumer<>(props);
		try
		{
			consumer.listTopics();
		}
		catch (Exception e)
		{
			logger.error("Error while connecting to Kafka topic. current system time is"+ new Date ());
			throw e;
		}
		consumer.subscribe(Collections.singletonList(TOPIC));
		
		consumer.subscribe(Arrays.asList(TOPIC), new ConsumerRebalanceListener(){
            public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
            	if (YFCLogUtil.isDebugEnabled()) {
                logger.debug("%s topic-partitions are revoked from this consumer\n", Arrays.toString(partitions.toArray()));
            	}
            }
            public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
            	if (YFCLogUtil.isDebugEnabled()) {
               logger.debug("%s topic-partitions are assigned to this consumer\n", Arrays.toString(partitions.toArray()));
            	}
                Iterator<TopicPartition> topicPartitionIterator = partitions.iterator();
                while(topicPartitionIterator.hasNext()){
                    TopicPartition topicPartition = topicPartitionIterator.next();    
                    consumer.seekToEnd(topicPartition);
                    finalOffset = consumer.position(topicPartition);
                    logger.info("Beginning Offset is: "+fromOffset+" , End Offset is: "+finalOffset);
                    if (YFCLogUtil.isDebugEnabled()) {
                    logger.debug("Current offset is " + consumer.position(topicPartition) + " committed offset is ->" + consumer.committed(topicPartition) );
                    }
	                   if(KohlsPOCConstant.SYNC_FULL.equalsIgnoreCase(type))
	                   {
	                	     consumer.seekToBeginning(topicPartition);
	                   }
	                   else
	                   {	                	    	                	   			                	       
	                	        	consumer.seek(topicPartition, Long.valueOf(fromOffset));   
	                   }                                                        
                    }
                }
            });
		
		logger.endTimer("KohlsCallMOSAPIWrapper.Consumer");
    	
		return consumer;

	}
    KohlsPoCMosUtil kohlsMosUtil = new KohlsPoCMosUtil();
    private  Document mosOutput = null;
    private  Integer fetchedCount = 0;
    private static long finalOffset = 0;
    private void runConsumer() throws InterruptedException, ExecutionException, JSONException, 
    JsonIOException, JsonSyntaxException, FileNotFoundException, ParserConfigurationException {
    	logger.beginTimer("KohlsCallMOSAPIWrapper.runConsumer");
    	
		final Consumer<Long, String> consumer = createConsumer();
		
		int giveUp = Integer.parseInt(RETRY_THRESHOLD);
		int noRecordsCount = 0;
		while (true) {
			//consumer.listTopics();
			final ConsumerRecords<Long, String> consumerRecords = consumer.poll(Integer.parseInt(POLL_INTERVAL));
			if(Long.valueOf(fromOffset) >= finalOffset)
			{				
			logger.info("No new messages to consume from MOS");
			return;
			}
			if (consumerRecords.count() == 0) {
				noRecordsCount++;
				if (noRecordsCount > giveUp)
					break;
				else
					continue;
			}
			
			Iterator<ConsumerRecord<Long, String>>  records = consumerRecords.iterator();
			while(records.hasNext()){
				ConsumerRecord<Long, String> record = records.next();
				 fetchedCount++;
				 SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
				 String sFilePath =  "";
			     String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));		
			     try {
						sFilePath =  props.getProperty("LogDir");
						// String sFilePath = "/home/sterling/sterling93/logs/MOS";
						
						//KohlsRestAPIUtil restAPIUtil = new KohlsRestAPIUtil();
						Long offset = record.offset() + 1;
						String filePrefix = "MOSInfo_"+offset+"_"+timestamp+".txt";
	            			Path filePath = Paths.get(sFilePath);
	                		if(Files.exists(filePath))
	                		{
	                			restApiutil.writeToFile("Value for offset# "+offset+" is --->",record.value(),filePrefix,sFilePath);
	                		}
	                   } catch (Exception ex) {
	                 	  		logger.error("Logger Dir " +sFilePath+ " does not exist.So moving on");
	                   }	
				  mosOutput = kohlsMosUtil.getMosDataListFromJson(mosOutput,record.value());
				 			 
				 record.offset();
			}
			consumer.commitAsync();
		}
		consumer.close();
		logger.info("Done fetching the message from MOS");
	
		logger.endTimer("KohlsCallMOSAPIWrapper.runConsumer");
    	
	}
    
    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
    }
    
   /** public  void callManageMosOffsetData(YFSEnvironment env,boolean createFlag) {
    	logger.beginTimer("KohlsCallMOSAPIWrapper.callManageMosOffsetData");
        Document inDocApi = null;
	try {
        	  inDocApi =createMosDataOffsetDoc();
		Element eleRootInDoc = inDocApi.getDocumentElement(); 
        
        	   if (YFCLogUtil.isDebugEnabled()) {
      				logger.debug("Update Document is --"+XMLUtil.getXMLString(inDocApi));
      			}
        	   if(createFlag)
        	   {
        		   kohlsMosUtil.createMosData(env, inDocApi);
        	   }
        	   else
        	   {
        		   eleRootInDoc.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,  KohlsPOCConstant.DEFAULT);
            	   eleRootInDoc.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, KohlsPOCConstant.UNIT_OF_MEASURE);
        		   kohlsMosUtil.updateMosData(env, inDocApi);
        	   }	  
       //eleCacheObject.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR_ATTR);
       // KOHLSBaseApi.invokeAPI(env,"manageRule", inDocApi);
        } catch (Exception e) {
            // TODO Auto-generated catch block
	        	logger.error("Error while fetching the offset value. Ignore and proceed");
	    		logger.error("Error is "+e.getMessage());
        }
	logger.endTimer("KohlsCallMOSAPIWrapper.callManageMosOffsetData");
	} **/
    public  String getMosOffsetData(YFSEnvironment env) {
    	logger.beginTimer("KohlsCallMOSAPIWrapper.getMosOffsetData");
        Document inDocApi = null;
       // long currentOffset = 0; 
        String sGetOffset = KohlsPOCConstant.ZERO;
        try {
         inDocApi = XmlUtils.createDocument(KohlsPOCConstant.KOHLS_MOS_DATA);
        Element eleRootInDoc = inDocApi.getDocumentElement();     
        eleRootInDoc.setAttribute(KohlsPOCConstant.A_SKUNBR, KohlsPOCConstant.MOS_KAFKA_OFFSET);
        eleRootInDoc.setAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE,KohlsPOCConstant.DEFAULT);
        
        eleRootInDoc.setAttribute(KohlsPOCConstant.A_UNIT_OF_MEASURE, KohlsPOCConstant.UNIT_OF_MEASURE);
        sGetOffset= kohlsMosUtil.getKohlsMosData(env, inDocApi);
	    
        if (YFCLogUtil.isDebugEnabled()) {
				logger.debug("Input Document is --"+XMLUtil.getXMLString(inDocApi));
			}
        if (YFCLogUtil.isDebugEnabled()) {
			logger.debug("Offset Value is "+sGetOffset);
		}
       
       //eleCacheObject.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR_ATTR);
        
        } catch (Exception e) {
            // TODO Auto-generated catch block
	        	logger.error("Error while fetching the offset value. Ignore and proceed");
	    		logger.error("Error is "+e.getMessage());
        }
        logger.endTimer("KohlsCallMOSAPIWrapper.getMosOffsetData");
        return sGetOffset;
      }
    
	
    public Document createMosDataOffsetDoc() throws Exception
    {
    	logger.beginTimer("KohlsCallMOSAPIWrapper.createMosDataOffsetDoc");
    	Document  inDocApi = XmlUtils.createDocument(KohlsPOCConstant.KOHLS_MOS_DATA); 
    	Element eleRootInDoc = inDocApi.getDocumentElement();     
  	   eleRootInDoc.setAttribute(KohlsPOCConstant.A_SKUNBR,  KohlsPOCConstant.MOS_KAFKA_OFFSET);
  	   eleRootInDoc.setAttribute(KohlsPOCConstant.A_MOS_START_DATE,  String.valueOf(finalOffset));
  	   
  	 if (YFCLogUtil.isDebugEnabled()) {
			logger.debug("out Document is --"+XMLUtil.getXMLString(inDocApi));
		}
  	logger.endTimer("KohlsCallMOSAPIWrapper.createMosDataOffsetDoc");
  	   return inDocApi;
    }
    
      
}
