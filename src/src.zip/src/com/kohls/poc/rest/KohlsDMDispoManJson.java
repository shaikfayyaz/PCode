package com.kohls.poc.rest;

import java.util.Date;
import java.util.List;

public class KohlsDMDispoManJson {

	private Long sku;
	
	private Float itemPrice;
	private Long storeNumber;
	private String device;
	private String itemStatusCode;
	private boolean webExclusiveFlag;
	private String webExclusiveDispoCode;
	private boolean damagedFlag;
	private boolean damagedResellableFlag = true;
	private Long upc;
	private String itemDept;
	private String itemClass;
	private String itemSubClass;
	private String itemStyle;
	private String vendorReturnDispCode;
	private String callbackTypeCode;
	private Long callbackID; 
	private String callbackIDSize;
	private String callbackStartDate;
	private String callbackEndDate;
	private boolean hazMatFlag;
	private String hazMaterialClass;
	private String hazMatClass;
	private String hazMaterialSubclass;
	private String hazMatSubClass;
	private String vendorRTVThresholdReached;
	private String webExclusiveDispCode;
	private String webExclusiveDispDesc;
	private String damageReasonDesc;
	private String auditID;
	private boolean contaminatedFlag;
	private int disposition;
	private String dispositionText;
	private Float markdownPercentage;
	private String hazmatHandlingInstruction;
	private boolean mosSalvageFlag;

	public int getDisposition() {
		return disposition;
	}
	
	public void setDisposition(int disposition) {
		this.disposition = disposition;
	}
	
	public boolean gethazMatFlag() {
		return hazMatFlag;
	}
	
	public void sethazMatFlag(boolean hazMatFlag) {
		this.hazMatFlag = hazMatFlag;
	}
	
	
	
	public String gethazmatHandlingInstruction() {
		return hazmatHandlingInstruction;
	}
	
	public void sethazmatHandlingInstruction(String hazmatHandlingInstruction) {
		this.hazmatHandlingInstruction = hazmatHandlingInstruction;
	}


	public String getDispositionText() {
		return dispositionText;
	}
	
	public void setDispositionText(String dispositionText) {
		this.dispositionText = dispositionText;
	}
	
	public Float getMarkdownPercentage() {
		return markdownPercentage;
	}

	public void setMarkdownPercentage(Float markdownPercentage) {
		this.markdownPercentage = markdownPercentage;
	}
	
	public boolean getcontaminatedFlag() {
		return contaminatedFlag;
	}

	public void setcontaminatedFlag(boolean contaminatedFlag) {
		this.contaminatedFlag = contaminatedFlag;
	}
	
	public String getauditID() {
		return auditID;
	}

	public void setauditID(String auditID) {
		this.auditID = auditID;
	}
	
	public String gethazMaterialSubclass() {
		return hazMaterialSubclass;
	}

	public void sethazMaterialSubclass(String hazMaterialSubclass) {
		this.hazMaterialSubclass = hazMaterialSubclass;
	}
	
	public String getvendorRTVThresholdReached() {
		return vendorRTVThresholdReached;
	}

	public void setvendorRTVThresholdReached(String vendorRTVThresholdReached) {
		this.vendorRTVThresholdReached = vendorRTVThresholdReached;
	}
	
	public String getdamageReasonDesc() {
		return damageReasonDesc;
	}

	public void setdamageReasonDesc(String damageReasonDesc) {
		this.damageReasonDesc = damageReasonDesc;
	}
	
	public String getwebExclusiveDispDesc() {
		return webExclusiveDispDesc;
	}

	public void setwebExclusiveDispDesc(String webExclusiveDispDesc) {
		this.webExclusiveDispDesc = webExclusiveDispDesc;
	}

	public String getwebExclusiveDispCode() {
		return webExclusiveDispCode;
	}

	public void setwebExclusiveDispCode(String webExclusiveDispCode) {
		this.webExclusiveDispCode = webExclusiveDispCode;
	}
	
	public String gethazMaterialClass() {
		return hazMaterialClass;
	}

	public void sethazMaterialClass(String hazMaterialClass) {
		this.hazMaterialClass = hazMaterialClass;
	}
	
	public String gethazMatClass() {
		return hazMatClass;
	}

	public void sethazMatClass(String hazMatClass) {
		this.hazMatClass = hazMatClass;
	}
	
	public String gethazMatSubClass() {
		return hazMatSubClass;
	}

	public void sethazMatSubClass(String hazMatSubClass) {
		this.hazMatSubClass = hazMatSubClass;
	}
	
	
	public String getcallbackStartDate() {
		return callbackStartDate;
	}

	public void setcallbackStartDate(String callbackStartDate) {
		this.callbackStartDate = callbackStartDate;
	}
	
	public String getcallbackEndDate() {
		return callbackEndDate;
	}

	public void setcallbackEndDate(String callbackEndDate) {
		this.callbackEndDate = callbackEndDate;
	}
	
	public String getItemDept() {
		return itemDept;
	}

	public void setItemDept(String itemDept) {
		this.itemDept = itemDept;
	}
	
	public String getItemClass() {
		return itemClass;
	}

	public void setItemClass(String itemClass) {
		this.itemClass = itemClass;
	}
	
	public String getItemSubClass() {
		return itemSubClass;
	}

	public void setItemSubClass(String itemSubClass) {
		this.itemSubClass = itemSubClass;
	}
	
	public String getItemStyle() {
		return itemStyle;
	}

	public void setItemStyle(String itemStyle) {
		this.itemStyle = itemStyle;
	}
	

	public String getVendorReturnDispCode() {
		return vendorReturnDispCode;
	}

	public void setVendorReturnDispCode(String vendorReturnDispCode) {
		this.vendorReturnDispCode = vendorReturnDispCode;
	}
	
	public String getCallbackTypeCode() {
		return callbackTypeCode;
	}

	public void setCallbackTypeCode(String callbackTypeCode) {
		this.callbackTypeCode = callbackTypeCode;
	}
	
	public Long getcallbackID() {
		return callbackID;
	}

	public void setcallbackID(Long callbackID) {
		this.callbackID = callbackID;
	}
	
	public String getcallbackIDSize() {
		return callbackIDSize;
	}

	public void setcallbackIDSize(String callbackIDSize) {
		this.callbackIDSize = callbackIDSize;
	}
	
	public Long getSku() {
		return sku;
	}

	public void setSku(Long sku) {
		this.sku = sku;
	}
	
	
	
	public Float getItemPrice() {
		return itemPrice;
	}
	
	public void setItemPrice(Float itemPrice) {
		this.itemPrice = itemPrice;
	}


	public String getDevice() {
		return device;
	}
	
	public void setDevice(String device) {
		this.device = device;
	}
	
	public String getItemStatusCode() {
		return itemStatusCode;
	}

	public void setItemStatusCode(String itemStatusCode) {
		this.itemStatusCode = itemStatusCode;
	}
	
	public boolean getWebExclusiveFlag() {
		return webExclusiveFlag;
	}

	public void setWebExclusiveFlag(boolean webExclusiveFlag) {
		this.webExclusiveFlag = webExclusiveFlag;
	}
	
	public String getWebExDispoCode() {
		return webExclusiveDispoCode;
	}

	public void setWebExDispoCode(String webExclusiveDispoCode) {
		this.webExclusiveDispoCode = webExclusiveDispoCode;
	}
	
	public boolean getDamagedFlag() {
		return damagedFlag;
	}

	public void setDamagedFlag(boolean damagedFlag) {
		this.damagedFlag = damagedFlag;
	}
	
	public void setDamagedResellableFlag(boolean damagedResellableFlag) {
		this.damagedResellableFlag = damagedResellableFlag;
	}
	
	public boolean getDamagedResellableFlag() {
		return damagedResellableFlag;
	}
	
	public Long getUPC() {
		return upc;
	}

	public void setUPC(Long upc) {
		this.upc = upc;
	}


	/**
	 * @return the storeNumber
	 */
	public Long getStoreNumber() {
		return storeNumber;
	}


	/**
	 * @param storeNumber the storeNumber to set
	 */
	public void setStoreNumber(Long storeNumber) {
		this.storeNumber = storeNumber;
	}
	
	public boolean getMosSalvageFlag() {
		return mosSalvageFlag;
	}
	
	public void setMosSalvageFlag(boolean mosSalvageFlag) {
		this.mosSalvageFlag = mosSalvageFlag;
	}
}