package com.kohls.poc.rest;


public class KohlsDMDispoManOutJson {

	private String sku;
	
	private String disposition;
	private String dispositionText;
	private String markdownPercentage;
	private String callbackID;
	private String hazmatHandlingInstructions;
	private boolean hazMatFlag;
	private String hazMatClass;
	private String hazMatSubClass;
	private boolean webExclusiveFlag;
	private String webExclusiveDispCode;
	private String webExclusiveDispDesc;
	private String vendorReturnDispCode;
	//private boolean damagedFlag;


	public String geSku() {
		return sku;
	}
	
	

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public String getDisposition() {
		return disposition;
	}
	
	

	public void setItemPrice(String disposition) {
		this.disposition = disposition;
	}


	public String getDispositionText() {
		return dispositionText;
	}
	
	public void setDispositionText(String dispositionText) {
		this.dispositionText = dispositionText;
	}
	
	public String getMarkdownPercentage() {
		return markdownPercentage;
	}

	public void setMarkdownPercentage(String markdownPercentage) {
		this.markdownPercentage = markdownPercentage;
	}
	
	public String getCallbackID() {
		return callbackID;
	}

	public void setCallbackID(String callbackID) {
		this.callbackID = callbackID;
	}
	
	public String getHazMatHandlInstr() {
		return hazmatHandlingInstructions;
	}

	public void setHazMatHandlInstr(String hazmatHandlingInstructions) {
		this.hazmatHandlingInstructions = hazmatHandlingInstructions;
	}
	
	public boolean getHazMatFlag() {
		return hazMatFlag;
	}

	public void setHazMatFlag(boolean hazMatFlag) {
		this.hazMatFlag = hazMatFlag;
	}
	
	public String getHazMatClass() {
		return hazMatClass;
	}

	public void setHazMatClass(String hazMatClass) {
		this.hazMatClass = hazMatClass;
	}
	
	public String getHazMatSubClass() {
		return hazMatSubClass;
	}

	public void setHazMatSubClass(String hazMatSubClass) {
		this.hazMatSubClass = hazMatSubClass;
	}

	public boolean getWebExclusiveFlag() {
		return webExclusiveFlag;
	}

	public void setWebExclusiveFlag(boolean webExclusiveFlag) {
		this.webExclusiveFlag = webExclusiveFlag;
	}

	public String getWebExclusiveDispCode() {
		return webExclusiveDispCode;
	}

	public void setWebExclusiveDispCode(String webExclusiveDispCode) {
		this.webExclusiveDispCode = webExclusiveDispCode;
	}
	
	public String getWebExclusiveDispDesc() {
		return webExclusiveDispDesc;
	}

	public void setWebExclusiveDispDesc(String webExclusiveDispDesc) {
		this.webExclusiveDispDesc = webExclusiveDispDesc;
	}
	
	public String getVendorReturnDispCode() {
		return vendorReturnDispCode;
	}

	public void setVendorReturnDispCode(String vendorReturnDispCode) {
		this.vendorReturnDispCode = vendorReturnDispCode;
	}
}