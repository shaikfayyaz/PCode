package com.kohls.poc.rest;



import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsPoCXPathUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

/**************************************************************************
 * File : KohlsPoCGenerateSUPCForRedeem.java Author : RajeshG Created : June 01 2016 Modified : June
 * 01 2016 Version : 1.0
 ***************************************************************************** 
 * *************************************************************************** Copyright @ 2016.
 * This document is in copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Java component is implemented as part of SUPC.It gets input from ORDER_CREATED.ON_SUCCESS
 * This will validate if any SUPC promotion/coupon applied if applied then it will collect supc
 * coupons and also validated is it is honoured/applied in the order successfully then it will call
 * TVS to mark it as USED
 * 
 * @author Rajesh G
 * @version 1.0
 *****************************************************************************/

public class KohlsPoCGenerateSUPCForRedeem extends KOHLSBaseApi {

  private Properties props;
  

  public String exactSUPCLength = "0";
  public String isSingleAlphaMust = "N";
  public String allowedChars = "";
  public String transactionIdForTVS = "ExtnOrigPosSequenceNo";
  public String elementTransactionIDForTVS = "/Order/Extn";
  
	public static final String xPath_ORDER = "/Order";
	public static final String xPath_ORDER_PROMOTION = "/Order/Promotions/Promotion";
	public static final String xPath_ORDER_ORDERLINE = "/Order/OrderLines/OrderLine";
	public static final String xPath_PROMOTION ="./Promotions/Promotion";
	public static final String xPath_ORDER_SUPC_REFERENCE ="/Order/References/Reference[@Name='SUPC']";
	public static final String POS_SEQUENCE_NUMBER = "POSSequenceNumber";
	public static final String SELLER_ORGANIZATION_CODE = "SellerOrganizationCode";
	public static final String STORE_NO = "StoreNo";
	public static final String TRANSACTION_ID = "TransactionId";
	public static final String ACTION = "Action";
	public static final String SUPC_LIST = "SupcList";
	public static final String PROMOTION_ID ="PromotionId";
	public static final String PROMOTION_APPLIED = "PromotionApplied";
	public static final String EXTN = "Extn";
	public static final String SUPC_CODE = "SupcCode";
	public static final String SUPC_VALUE = "SupcValue";
	public static final String VALUE = "Value";
	public static final String ACTION_VOID = "VOID";



  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPoCGenerateSUPCForRedeem.class.getName());
  }

  /**
   * This method will be called using IBM SFD framework through UE call from TcxGravity when
   * Customer taps his/her phone in pinpad
   * 
   * @param env
   * @param inDoc
   * @return
   * @throws Exception
   */
  public Document generateSupcCodeForRedeem(YFSEnvironment env, Document inDoc) throws Exception {
    
    logger.beginTimer("Start KohlsPoCGenerateSUPCForRedeem.updateSUPCStatus");
    if(logger.isDebugEnabled()){      
      logger.debug("KohlsPoCGenerateSUPCForRedeem.updateSUPCStatus InDoc--->"
          + XMLUtil.getXMLString(inDoc));
      
    }
    
    exactSUPCLength = this.props.getProperty("EXACT_SUPC_LENGTH");    
    isSingleAlphaMust = this.props.getProperty("IS_SINGLE_ALPHA_MUST");
    allowedChars = this.props.getProperty("ALLOWED_CHARS");
    transactionIdForTVS = this.props.getProperty("TRANSACTIONID_FOR_TVS");
  //  transactionIdForTVS = this.props.getProperty("TRANSACTIONID_FOR_TVS");
    elementTransactionIDForTVS = this.props.getProperty("ELEMENT_TRANSACTIONID_FOR_TVS");
    
    boolean isSingleAlphaRequired = false;
    int lengthOfSUPC = 0;
    String allowedCharsset = "[A-Za-z0-9]+";
    String transIdForTVS ="ExtnOrigPosSequenceNo";
    String elementForTransactionID ="/Order/Extn";
    
    
    if ("Y".trim().equalsIgnoreCase(isSingleAlphaMust)) {    
      isSingleAlphaRequired = true;
    }
    
    if(null != exactSUPCLength && !"".equalsIgnoreCase(exactSUPCLength.trim()) ){
      lengthOfSUPC = Integer.parseInt(exactSUPCLength);
    }
    
    if(null != allowedChars && !"".equalsIgnoreCase(allowedChars.trim()) ){
      allowedCharsset = allowedChars;
    }
    
    if(null != transactionIdForTVS && !"".equalsIgnoreCase(transactionIdForTVS.trim()) ){
      transIdForTVS = transactionIdForTVS;
      if(null != elementTransactionIDForTVS && !"".equalsIgnoreCase(elementTransactionIDForTVS.trim()) ){
        elementForTransactionID = elementTransactionIDForTVS;
      }
    }
   
    Element elemForTransactionID = KohlsPoCXPathUtil.getElementByXPath(inDoc, elementForTransactionID);

    Document outDoc = XMLUtil.createDocument("SupcList");
    String storeNo = XMLUtil.getAttribute(inDoc.getDocumentElement(), "SellerOrganizationCode");
    // TransactionNo
    String tranId = XMLUtil.getAttribute(elemForTransactionID, transIdForTVS);        
    XMLUtil.setAttribute(outDoc.getDocumentElement(), "StoreNo", storeNo);
    XMLUtil.setAttribute(outDoc.getDocumentElement(), "TransactionId", tranId);
    XMLUtil.setAttribute(outDoc.getDocumentElement(), "Action", "redeem");

    try {



      Document KohlsPoCGenerateSUPCForRedeemOutDoc = null;
      Element eleReference =
          (Element) KohlsXPathUtil.getNode(inDoc, "/Order/References/Reference[@Name='SUPC']");
      if (!YFCCommon.isVoid(eleReference) && "Y".equalsIgnoreCase(eleReference.getAttribute("Value"))) {

        ArrayList<String> supcCodeList = new ArrayList();

        // loop through order promotions

        NodeList promotionList =
            ((NodeList) XPathUtil.getNodeList(inDoc.getDocumentElement(),
                "/Order/Promotions/Promotion"));
        Element promotionEle = null;        

        for (int i = 0; i < promotionList.getLength(); i++) {
          
          
          promotionEle = (Element) promotionList.item(i);          

          String promotionId = XMLUtil.getAttribute(promotionEle, "PromotionId");
          String promotionApplied = XMLUtil.getAttribute(promotionEle, "PromotionApplied");
          // PromotionApplied
          if (isSUPCPromo(promotionId,allowedCharsset,isSingleAlphaRequired,lengthOfSUPC) && "Y".equalsIgnoreCase(promotionApplied)) {            
            supcCodeList.add(promotionId);
          }

        }

        // loop through orderline
        List<Element> orderLineList =
            KohlsPoCXPathUtil.getElementListByXpath(inDoc, "/Order/OrderLines/OrderLine");

        
        for (Element orderLineElement : orderLineList) {
          
          NodeList promotionLineList = null;
          promotionLineList =
              ((NodeList) XPathUtil.getNodeList(orderLineElement, "./Promotions/Promotion"));
          Element promotionLineEle = null;
          for (int i = 0; i < promotionLineList.getLength(); i++) {
            logger.debug("Inside for");
            promotionLineEle = (Element) promotionLineList.item(i);
            String promotionLineId = XMLUtil.getAttribute(promotionLineEle, "PromotionId");
            String promotionLineApplied =
                XMLUtil.getAttribute(promotionLineEle, "PromotionApplied");
            if (isSUPCPromo(promotionLineId,allowedCharsset,isSingleAlphaRequired,lengthOfSUPC) && "Y".equalsIgnoreCase(promotionLineApplied)) {
              supcCodeList.add(promotionLineId);
            }

          }
        }
        
        for (String SupcCodevalue : supcCodeList) {

          Element SupcCodeEle = outDoc.createElement("SupcCode");
          XMLUtil.setAttribute(SupcCodeEle, "SupcValue", SupcCodevalue);
          outDoc.getDocumentElement().appendChild(SupcCodeEle);

        }
      }

    } catch (Exception e) {
      logger.error(e);
      System.out.println(e.getMessage());
    }
    if(logger.isDebugEnabled()){ 
      logger.debug("KohlsPoCGenerateSUPCForRedeem.updateSUPCStatus outDoc--->"
          + XMLUtil.getXMLString(outDoc));
    }

    logger.endTimer("End KohlsPoCGenerateSUPCForRedeem.getKohlsPoCGenerateSUPCForRedeem");
 

    return outDoc;

  }

  /*
   * (non-Javadoc)
   * 
   * @see com.kohls.common.util.KOHLSBaseApi#setProperties(java.util.Properties)
   */
  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    logger.debug("In the set properties method");

  }

  boolean isSUPCPromo(String promoId,String allowedChars,boolean oneAlpha,int exactLength) {

    if (promoId.length() != exactLength) {
      return false;
    }
    //if (promoId.matches(".*[a-zA-Z]+.*") && promoId.matches("[A-Za-z0-9]+")) {
    if (promoId.matches(allowedChars)) {      
      if(oneAlpha){
        if(promoId.matches(".*[a-zA-Z]+.*")){
          return true;
        }
        return false;
      }
    
      return true;
    }
    return false;
  }
  
	public Document generateSupcCodeForRedeemPSA(YFSEnvironment env,
			Document inDoc) throws Exception {

		logger.beginTimer("Start KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForRedeemPSA");
		if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForRedeemPSA InDoc--->"
					+ XMLUtil.getXMLString(inDoc));

		}

		String transIdForTVS = "POSSequenceNumber";
		String elementForTransactionID = "/Order";
		Element elemForTransactionID = KohlsPoCXPathUtil.getElementByXPath(
				inDoc, elementForTransactionID);

		Document outDoc = XMLUtil.createDocument("SupcList");
		String storeNo = XMLUtil.getAttribute(inDoc.getDocumentElement(),
				"SellerOrganizationCode");
		// TransactionNo
		String tranId = XMLUtil.getAttribute(elemForTransactionID,
				transIdForTVS);
		XMLUtil.setAttribute(outDoc.getDocumentElement(), "StoreNo", storeNo);
		XMLUtil.setAttribute(outDoc.getDocumentElement(), "TransactionId",
				tranId);
		XMLUtil.setAttribute(outDoc.getDocumentElement(), "Action", "redeem");

		try {
			Document KohlsPoCGenerateSUPCForRedeemOutDoc = null;
			ArrayList<String> supcCodeList = new ArrayList();
			// loop through order promotions

			NodeList promotionList = ((NodeList) XPathUtil.getNodeList(
					inDoc.getDocumentElement(), "/Order/Promotions/Promotion"));
			Element promotionEle = null;
			Element promotionExtnEle = null;
			for (int i = 0; i < promotionList.getLength(); i++) {

				promotionEle = (Element) promotionList.item(i);
				String promotionId = XMLUtil.getAttribute(promotionEle,
						"PromotionId");
				String promotionApplied = XMLUtil.getAttribute(promotionEle,
						"PromotionApplied");
				// PromotionApplied
				promotionExtnEle = (Element) promotionEle.getElementsByTagName(
						"Extn").item(0);
				String isPsaPromotion = promotionExtnEle
						.getAttribute("ExtnIsPsaPromotion");
				if (KohlsPoCPnPUtil.isSUPC(promotionId)
						&& "Y".equalsIgnoreCase(promotionApplied)
						&& "Y".equalsIgnoreCase(isPsaPromotion)) {
					supcCodeList.add(promotionId);
				}

			}
			// loop through orderline
			List<Element> orderLineList = KohlsPoCXPathUtil
					.getElementListByXpath(inDoc, "/Order/OrderLines/OrderLine");

			for (Element orderLineElement : orderLineList) {

				NodeList promotionLineList = null;
				promotionLineList = ((NodeList) XPathUtil.getNodeList(
						orderLineElement, "./Promotions/Promotion"));
				Element promotionLineEle = null;
				for (int i = 0; i < promotionLineList.getLength(); i++) {
					logger.debug("Inside for");
					promotionLineEle = (Element) promotionLineList.item(i);
					String promotionLineId = XMLUtil.getAttribute(
							promotionLineEle, "PromotionId");
					String promotionLineApplied = XMLUtil.getAttribute(
							promotionLineEle, "PromotionApplied");
					promotionExtnEle = (Element) promotionEle
							.getElementsByTagName("Extn").item(0);
					String isPsaLinePromotion = promotionExtnEle
							.getAttribute("ExtnIsPsaPromotion");
					if (KohlsPoCPnPUtil.isSUPC(promotionLineId)
							&& "Y".equalsIgnoreCase(promotionLineApplied)
							&& "Y".equalsIgnoreCase(isPsaLinePromotion)) {
						supcCodeList.add(promotionLineId);
					}

				}
			}

			for (String SupcCodevalue : supcCodeList) {

				Element SupcCodeEle = outDoc.createElement("SupcCode");
				XMLUtil.setAttribute(SupcCodeEle, "SupcValue", SupcCodevalue);
				outDoc.getDocumentElement().appendChild(SupcCodeEle);

			}

		} catch (Exception e) {
			logger.error(e);
			System.out.println(e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCGenerateSUPCForRedeem.getKohlsPoCGenerateSUPCForRedeemPSA outDoc--->"
					+ XMLUtil.getXMLString(outDoc));
		}

		logger.endTimer("End KohlsPoCGenerateSUPCForRedeem.getKohlsPoCGenerateSUPCForRedeemPSA");

		return outDoc;

	}
	
	public Document generateSupcCodeForPostVoidPSA(YFSEnvironment env,
			Document inDoc) throws Exception {

		logger.beginTimer("Start KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidPSA");
		if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidPSA InDoc--->"
					+ XMLUtil.getXMLString(inDoc));

		}

		String transIdForTVS = "POSSequenceNumber";
		String elementForTransactionID = "/Order";
		Element elemForTransactionID = KohlsPoCXPathUtil.getElementByXPath(
				inDoc, elementForTransactionID);

		Document outDoc = XMLUtil.createDocument("SupcList");
		// TransactionNo
		String tranId = XMLUtil.getAttribute(elemForTransactionID,
				transIdForTVS);
		String storeNo = XMLUtil.getAttribute(elemForTransactionID,
				"OrganizationCode");
		XMLUtil.setAttribute(outDoc.getDocumentElement(), "StoreNo", storeNo);
		XMLUtil.setAttribute(outDoc.getDocumentElement(), "TransactionId",
				tranId);
		XMLUtil.setAttribute(outDoc.getDocumentElement(), "Action", "Void");

		try {
			Document KohlsPoCGenerateSUPCForRedeemOutDoc = null;
			ArrayList<String> supcCodeList = new ArrayList();
			// loop through order promotions

			NodeList promotionList = ((NodeList) XPathUtil.getNodeList(
					inDoc.getDocumentElement(), "/Order/Promotions/Promotion"));
			Element promotionEle = null;
			Element promotionExtnEle = null;
			for (int i = 0; i < promotionList.getLength(); i++) {

				promotionEle = (Element) promotionList.item(i);
				String promotionId = XMLUtil.getAttribute(promotionEle,
						"PromotionId");
				String promotionApplied = XMLUtil.getAttribute(promotionEle,
						"PromotionApplied");
				String promotionAction = XMLUtil.getAttribute(promotionEle,
						"Action");
				// PromotionApplied
				if (KohlsPoCPnPUtil.isSUPC(promotionId)
						&& "Y".equalsIgnoreCase(promotionApplied)
						&& "REMOVE".equalsIgnoreCase(promotionAction)) {
					supcCodeList.add(promotionId);
				}

			}
			// loop through orderline
			List<Element> orderLineList = KohlsPoCXPathUtil
					.getElementListByXpath(inDoc, "/Order/OrderLines/OrderLine");

			for (Element orderLineElement : orderLineList) {

				NodeList promotionLineList = null;
				promotionLineList = ((NodeList) XPathUtil.getNodeList(
						orderLineElement, "./Promotions/Promotion"));
				Element promotionLineEle = null;
				for (int i = 0; i < promotionLineList.getLength(); i++) {
					logger.debug("Inside for");
					promotionLineEle = (Element) promotionLineList.item(i);
					String promotionLineId = XMLUtil.getAttribute(
							promotionLineEle, "PromotionId");
					String promotionLineApplied = XMLUtil.getAttribute(
							promotionLineEle, "PromotionApplied");
					String promotionLineAction = XMLUtil.getAttribute(promotionEle,
							"Action");
					if (KohlsPoCPnPUtil.isSUPC(promotionLineId)
							&& "Y".equalsIgnoreCase(promotionLineApplied)
							&& "REMOVE".equalsIgnoreCase(promotionLineAction)) {
						supcCodeList.add(promotionLineId);
					}

				}
			}

			for (String SupcCodevalue : supcCodeList) {

				Element SupcCodeEle = outDoc.createElement("SupcCode");
				XMLUtil.setAttribute(SupcCodeEle, "SupcValue", SupcCodevalue);
				outDoc.getDocumentElement().appendChild(SupcCodeEle);

			}

		} catch (Exception e) {
			logger.error(e);
			System.out.println(e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidPSA outDoc--->"
					+ XMLUtil.getXMLString(outDoc));
		}

		logger.endTimer("End KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidPSA");

		return outDoc;

	}
	//CPE-2456 Begin
	/*****
	 * This API is used to prepare the used SUPC codes to mark as Unused
	 * @param env
	 * @param inDoc
	 * @return Document
	 * @throws Exception
	 */
	public Document generateSupcCodeForPostVoidSales( YFSEnvironment env, Document inDoc ) throws Exception {

		logger.beginTimer("Start KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidSales");
		if ( logger.isDebugEnabled() ) {
			logger.debug( "KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidSales InDoc--->" + XMLUtil.getXMLString( inDoc ) );

		}

        Document outDoc = XMLUtil.createDocument( SUPC_LIST );
		
		Element eleReference = (Element) KohlsXPathUtil.getNode(inDoc, xPath_ORDER_SUPC_REFERENCE );
		
		if ( logger.isDebugEnabled() ) {
			if( eleReference != null ) {
				logger.debug( "KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidSales eleReference--->" + XMLUtil.getElementXMLString( eleReference ) );
			} else {
				logger.debug( "KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidSales eleReference is Null--->" );
			}
		}
		
		if ( !YFCCommon.isVoid(eleReference) && "Y".equalsIgnoreCase(eleReference.getAttribute ( VALUE ) ) ) {

			Element elemetOrder = KohlsPoCXPathUtil.getElementByXPath( inDoc, xPath_ORDER );
			
			String tranId = XMLUtil.getAttribute( elemetOrder, POS_SEQUENCE_NUMBER );  // TransactionNo
			String storeNo = XMLUtil.getAttribute( elemetOrder, SELLER_ORGANIZATION_CODE );
			XMLUtil.setAttribute( outDoc.getDocumentElement(), STORE_NO, storeNo );
			XMLUtil.setAttribute( outDoc.getDocumentElement(), TRANSACTION_ID, tranId );
			XMLUtil.setAttribute( outDoc.getDocumentElement(), ACTION, ACTION_VOID );
	
			try {
				Document KohlsPoCGenerateSUPCForRedeemOutDoc = null;
				ArrayList<String> supcCodeList = new ArrayList<String>();
				// loop through order promotions
	
				NodeList promotionList = ( (NodeList) XPathUtil.getNodeList( inDoc.getDocumentElement(), xPath_ORDER_PROMOTION ) );
				Element promotionEle = null;
				Element promotionExtnEle = null;
				
				if( promotionList != null ) {
					
					for ( int i = 0; i < promotionList.getLength(); i++ ) {
						
						promotionEle = (Element) promotionList.item( i );
						if ( promotionEle != null ) {
							
							String promotionId = XMLUtil.getAttribute( promotionEle, PROMOTION_ID );
							String promotionApplied = XMLUtil.getAttribute( promotionEle, PROMOTION_APPLIED ); 		// PromotionApplied
							promotionExtnEle = (Element) promotionEle.getElementsByTagName( EXTN ).item( 0 );
							if ( "Y".equalsIgnoreCase( promotionApplied )  && KohlsPoCPnPUtil.isSUPC( promotionId )  ) {
								supcCodeList.add(promotionId);
							}
						}
					}
				}
	
				List<Element> orderLineList = KohlsPoCXPathUtil.getElementListByXpath( inDoc, xPath_ORDER_ORDERLINE );
				
				if( orderLineList != null ) {
					for (Element orderLineElement : orderLineList) {
						
						NodeList promotionLineList = null;
						Element promotionLineEle = null;
						
						promotionLineList = ((NodeList) XPathUtil.getNodeList( orderLineElement, xPath_PROMOTION ) );
						if( promotionLineList!= null ) {
							
							for ( int i = 0; i < promotionLineList.getLength(); i++ ) {
								
								promotionLineEle = (Element) promotionLineList.item( i );
								if( promotionLineEle != null ) {
									
									String promotionLineId = XMLUtil.getAttribute( promotionLineEle, PROMOTION_ID );
									String promotionLineApplied = XMLUtil.getAttribute( promotionLineEle, PROMOTION_APPLIED );
									promotionExtnEle = (Element) promotionEle.getElementsByTagName( EXTN ).item( 0 );
									if ( "Y".equalsIgnoreCase( promotionLineApplied ) && KohlsPoCPnPUtil.isSUPC( promotionLineId ) ) {
										supcCodeList.add(promotionLineId);
									}
								}
							}
						}
					}
				}
	
				for (String SupcCodevalue : supcCodeList) {
	
					Element SupcCodeEle = outDoc.createElement(SUPC_CODE);
					XMLUtil.setAttribute( SupcCodeEle, SUPC_VALUE, SupcCodevalue );
					outDoc.getDocumentElement().appendChild( SupcCodeEle );
				}
	
			} catch ( Exception e ) {
				logger.error( "generateSupcCodeForPostVoidSales" + e );
				e.printStackTrace();
			}					
		}
		
		if ( logger.isDebugEnabled() ) {
			logger.debug("KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidSales outDoc--->" + XMLUtil.getXMLString( outDoc ) );
		}
		
		logger.endTimer( "End KohlsPoCGenerateSUPCForRedeem.generateSupcCodeForPostVoidSales" );

		return outDoc;
	}
	//CPE-2456 Begin

}
