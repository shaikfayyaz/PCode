package com.kohls.poc.rest;

import java.util.TreeMap;

import org.apache.commons.json.JSONArray;
import org.apache.commons.json.JSONException;
import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPOSGetGeoCaptureUE extends KOHLSBaseApi {

	public  String strDomian = "";
	public  String strReadTimeOut="";
	public  String strEndPoint = "";
	public  String strQueryParam = "";
	public  String strApiKey = "";
	public  String strApiSecretKey = "";
	public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsPOSGetGeoCaptureUE.class.getName());
	}

	public   Document getGeoCapture(YFSEnvironment env,Document inDoc)  throws Exception {
		Document docoutGetCustomer = null;
		strDomian = YFSSystem.getProperty(KohlsPOCConstant.POC_GEO_DOMAIN);
		strEndPoint = YFSSystem.getProperty(KohlsPOCConstant.POC_GEO_ENDPOINT);
		strApiKey = YFSSystem.getProperty(KohlsPOCConstant.POC_GEO_API_KEY);
		strApiSecretKey = YFSSystem.getProperty(KohlsPOCConstant.POC_GEO_API_SECRET_KEY);			
		strReadTimeOut = YFSSystem.getProperty(KohlsPOCConstant.POC_GEO_READ_TIME_OUT);		
			
		logger.debug("Geo Capture InDoc--->"+XMLUtil.getXMLString(inDoc));

		// Create payload
		String cardHolderName = null;
		String bankCardToken = null;

		cardHolderName = XMLUtil.getAttribute(inDoc.getDocumentElement(), KohlsPOCConstant.POC_GEO_CARD_HOLDER_NAME);
		bankCardToken = XMLUtil.getAttribute(inDoc.getDocumentElement(),KohlsPOCConstant.POC_GEO_BANK_TOKEN);

		JSONObject json = new JSONObject();

		if (!YFCCommon.isVoid(bankCardToken)) {
			//json.put(KohlsPOCConstant.POC_GEO_BANK_TOKEN_JSON, bankCardToken);
			json.put("value", bankCardToken);
		}

			json.put(KohlsPOCConstant.POC_GEO_CARD_HOLDER_NAME_JSON, cardHolderName);

		strQueryParam = "alias=bcn";

		String jsonPayload = json.toString();
		logger.debug("jsonPayload--->"+ jsonPayload);

		TreeMap<String, String> mapHeader = new TreeMap();
		mapHeader.put(KohlsPOCConstant.ACCEPT, "application/json");
		mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");

		String issodate = restApiutil.getCurrentISODate();
		String strUuid = restApiutil.getUUID();
		final TreeMap<String, String> depHeaderMap = new TreeMap();
		depHeaderMap.put(KohlsPOCConstant.X_DEP_DATE, issodate);
		depHeaderMap.put(KohlsPOCConstant.X_DEP_REQUEST_ID, strUuid);
		depHeaderMap.put(KohlsPOCConstant.X_DEP_FROM_SYSTEM_CODE, "MBL");
		depHeaderMap.put(KohlsPOCConstant.X_DEP_FROM_APP, "API");
		//PST-443 Change for CorrelationID
		depHeaderMap.put("x-dep-correlation-id", KohlsPoCCommonAPIUtil.getCorrelationID());
		String strtempDomain = strDomian + strEndPoint + "?" + strQueryParam;
		logger.debug("EndPoint" + strtempDomain); 
		ResponseEntity<String> response = null;

		try {

			response = restApiutil.createConnection(jsonPayload, mapHeader,
					depHeaderMap, strQueryParam, strtempDomain, strEndPoint,
					strApiKey, strApiSecretKey,strReadTimeOut,strReadTimeOut,KohlsPOCConstant.CMDM,null, false, null, 0);
			if((response!=null) && (response.getStatusCode().toString().equals("200")))
			{
				String responseBody = response.getBody();			
				docoutGetCustomer = createGeoCaptureUEOutput(bankCardToken, responseBody);
			}

		} catch (YFSException e) {

			logger.debug("Exception while invoking Geo Capture Service  "+  e);		
			throw e;			
		}		
		return docoutGetCustomer;

	}


	private Document createGeoCaptureUEOutput(String bankCardToken, String responseBody) throws Exception{

		boolean geoCaptureIndicator = false; 
		JSONObject json = new JSONObject(responseBody);
		logger.debug("Geo Capture Response -->" + json.toString()); 

		try {		
			JSONArray customers = json.getJSONArray(KohlsPOCConstant.POC_GEO_CUSTOMERS);

			if(customers.size() > 0){
				JSONObject customer = customers.getJSONObject(0);
				geoCaptureIndicator = customer.getBoolean(KohlsPOCConstant.POC_GEO_CAPTURE_INDICATOR);
			}
		} catch (JSONException e) {

			logger.error("Exception when parsing Geo Capture response ", e);
		}

		Document docoutGetCustomerGeo = XMLUtil.newDocument();
		Element eleGeoCapture = docoutGetCustomerGeo.createElement(KohlsPOCConstant.POC_ELEMENT_GEO_CAPTURE);
		docoutGetCustomerGeo.appendChild(eleGeoCapture);	
		eleGeoCapture.setAttribute(KohlsPOCConstant.POC_ATTRIBUTE_GEO_BANK_TOKEN, bankCardToken);

		if(geoCaptureIndicator){
			eleGeoCapture.setAttribute(KohlsPOCConstant.POC_ATTRIBUTE_GEO_CODE_CAPTURED, "Y");
		} else {
			eleGeoCapture.setAttribute(KohlsPOCConstant.POC_ATTRIBUTE_GEO_CODE_CAPTURED, "N");
		}

		return docoutGetCustomerGeo;
	}
}
