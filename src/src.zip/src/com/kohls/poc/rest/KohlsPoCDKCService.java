package com.kohls.poc.rest;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.util.webserviceUtil.WebServiceCaller;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCDKCService extends KOHLSBaseApi {

	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsPoCDKCService.class);

	String ID, EMAIL_ADDR, RECEIPT_ID, DATETIME, STORE_NUM, REG_ID, TRAN_NUM,
			ACT_AMT, SCAN_IND, QUA_AMT = "";
	String HTTP_METHOD = "POST";
	String CONTENT_TYPE = "application/json";
	String Domain, EndPointPath, ApiKey, ApiSecret, QueryParams;
	KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
	private Properties props;

	/**
	 * This function sets the attribute from the input xml
	 * 
	 * @param env
	 * @param Document
	 * @return Document
	 * @exception YFSException
	 * 
	 */
	public Document invokeDKCService(YFSEnvironment env, Document inputDoc)
			throws YFSException {
		logger.debug("InvokeDKCService ---------- Start");
		Element eleDigitalKC = (Element) inputDoc.getDocumentElement();

		// Sample UE Input
		/*<DigitalKohlsCashActivation CouponEventID="12345" CouponAmount="10" EmailAddress="abc@xyz.com" ReceiptID="11111111111"
		 * DateTime="2015-07-08T00:24:52-05:00" QualifiedAmount="55.34" Store="9954" TerminalID="34" SequenceNo="0387"/> */
		
		ID = eleDigitalKC.getAttribute("CouponEventID");
		EMAIL_ADDR = eleDigitalKC.getAttribute("EmailAddress");
		RECEIPT_ID = eleDigitalKC.getAttribute("ReceiptID");
		DATETIME = eleDigitalKC.getAttribute("DateTime");
		STORE_NUM = eleDigitalKC.getAttribute("Store");
		REG_ID = eleDigitalKC.getAttribute("TerminalID");
		TRAN_NUM = eleDigitalKC.getAttribute("SequenceNo");
		ACT_AMT = eleDigitalKC.getAttribute("CouponAmount");
		SCAN_IND = "false";
		QUA_AMT = eleDigitalKC.getAttribute("QualifyingAmount");
		String outputFromDKCService = "";
		Document docDKC = YFCDocument.createDocument(
				"DigitalKohlsCashActivation").getDocument();
		try {
			outputFromDKCService = createPayLoad();
			docDKC.getDocumentElement().setAttribute("CouponNumber",
					outputFromDKCService);
					
		} catch (Exception e) {
			logger.debug("Exception while invoking Rest API Webservice ##########\n"
					+ e);
			throw new YFSException(e.getMessage());
		}
		logger.debug("InvokeDKCService ---------- End");
		return docDKC;
	}

	public String createPayLoad() throws Exception {
		logger.debug("createPayLoad ---------- Start");
		String strCouponId = null;
		int timeOut = 1000;
		Domain = KohlsRestAPIUtil.getPropertyValue(props.getProperty("KC_DOMAIN"));
		EndPointPath = KohlsRestAPIUtil.getPropertyValue(props.getProperty("KC_ENDPOINT_CONTEXT_PATH_LESS"));
		if(KohlsRestAPIUtil.getPropertyValue(props.getProperty("TIMEOUT")) != null){
			timeOut = Integer.parseInt(KohlsRestAPIUtil.getPropertyValue(props.getProperty("TIMEOUT")));
			logger.debug("Timeout ##########\n"
					+ timeOut);
		}
		
		logger.debug("Request pramaters are: "+
				"\n eventid : "+ID +
				"\n receiptId : "+RECEIPT_ID +
				"\n dateTime : "+DATETIME +
				"\n storeNumber : "+STORE_NUM +
				"\n registerId : "+REG_ID +
				"\n transactionNumber : "+TRAN_NUM +
				"\n activityAmount : "+ACT_AMT +
				"\n scannedIndicator : "+"false" +
				"\n qualifiedAmount : "+QUA_AMT);
		
		String reqJson = "{\"event\":{ \"id\":\"" + ID
				+ "\", \"emailAddress\":\"" + EMAIL_ADDR
				+ "\"},\"transactionDetails\": { \"receiptId\":\"" + RECEIPT_ID
				+ "\", \"dateTime\":\"" + DATETIME + "\", \"storeNumber\":\""
				+ STORE_NUM + "\", \"registerId\":\"" + REG_ID
				+ "\", \"transactionNumber\":\"" + TRAN_NUM
				+ "\", \"activityAmount\":\"" + ACT_AMT
				+ "\", \"scannedIndicator\":\"" + "false"
				+ "\", \"qualifiedAmount\":\"" + QUA_AMT + "\" } }";
		
		HttpHeaders httpHeaders = createHttpHeaders(reqJson);

		final HttpEntity<String> request = new HttpEntity<String>(reqJson,
				httpHeaders);
		logger.debug("Request Rest API Webservice ##########\n"
				+ request.toString());
		try {
			//*****************************
//			RestTemplate restTemplate = new RestTemplate();
			HttpComponentsClientHttpRequestFactory requestFactory=new HttpComponentsClientHttpRequestFactory();
		    requestFactory.setReadTimeout(timeOut);
			RestTemplate restTemplate = new RestTemplate(requestFactory);
			
			//***************************
			final ResponseEntity<String> retryResponse;
			long beginTime = System.currentTimeMillis();
			final ResponseEntity<String> response = restTemplate.exchange(
					Domain + EndPointPath, HttpMethod.POST, request,
					String.class);
			long endTime = System.currentTimeMillis();
			long responseTime = endTime - beginTime;
			logger.info("REST WebService Enpoint - " + EndPointPath + " took " + responseTime + " ms");
			final String responseBody = response.getBody();
			if (restApiUtil.isError(response.getStatusCode())) {
				logger.debug("Error ##########\n" + response.getStatusCode());
				if ("503".equals(response.getStatusCode().toString())) {
					retryResponse = restTemplate.exchange(
							Domain + EndPointPath, HttpMethod.POST, request,
							String.class);
					final String retryResponseBody = retryResponse.getBody();
					if (restApiUtil.isError(retryResponse.getStatusCode())) {
						logger.debug("Error ##########\n"
								+ retryResponse.getStatusCode());
					} else {
						logger.debug("Success");
						logger.debug("retryResposneBody::"
								+ retryResponseBody.toString());
						JSONObject json = new JSONObject(
								retryResponseBody.toString());
						strCouponId = (String) json.get("barcode");
					}
				}
			} else {
				logger.debug("Success");
				logger.debug("Response body ####" + responseBody.toString());
				JSONObject json = new JSONObject(responseBody.toString());
				strCouponId = (String) json.get("barcode");
			}
		} catch (final Exception e) {
			logger.debug("Exception while invoking Rest API Webservice ##########\n"
					+ e);
			throw e;
		}
		logger.debug("createPayLoad ---------- End");
		return strCouponId;
	}

	public HttpHeaders createHttpHeaders(final String payload) throws IOException {
		logger.debug("createHttpHeaders ---------- Start");
		ApiKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty("KC_APIKEY"));
		String ApiSecretEncrypted = KohlsRestAPIUtil.getPropertyValue(props.getProperty("KC_API_SECRET"));
		EndPointPath = KohlsRestAPIUtil.getPropertyValue(props.getProperty("KC_ENDPOINT_CONTEXT_PATH_LESS"));
		QueryParams = "";
		
		//Decrypt the Api secret and Api Key
		String mykey = restApiUtil.pwdForDecryption(KohlsPOCConstant.DKC);
		ApiSecret = restApiUtil.decryptString(ApiSecretEncrypted,mykey);
		//ApiKey = restApiUtil.decryptString(ApiKeyEncrypted,mykey);
		// Get current isoDate
		final String isoDate = restApiUtil.getCurrentISODate();
		// create UUID
		final String uuid = restApiUtil.getUUID();

		// Order Map with x-dep header keys and values.
		final TreeMap<String, String> depHeaderMap = new TreeMap();
		depHeaderMap.put("x-dep-date", isoDate);
		depHeaderMap.put("x-dep-request-id", uuid);
		depHeaderMap.put("x-dep-from-app", "DEP");
		depHeaderMap.put("x-dep-from-node", "192.168.1.1");
		depHeaderMap.put("x-dep-from-system-code", "EP");
		//PST-443 Change for CorrelationID
		depHeaderMap.put("x-dep-correlation-id", KohlsPoCCommonAPIUtil.getCorrelationID());
		
		// Add httpHeaders for request
		final HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json");
		for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
			headers.add(entry.getKey(), entry.getValue());
		}

		// Build signature
		Signature signature;
		try {
			signature = new Signature.Builder()
					.apiSecret(ApiSecret)
					.apiKey(ApiKey)
					.endpoint(EndPointPath)
					.method(HttpMethod.POST.name())
					.isoDate(isoDate)
					// Stringify dep-headers
					.depHeaders(
							restApiUtil
									.concatSingleValueDEPHeaderParams(depHeaderMap))
					.mediaType("application/json").payload(payload)
					.queryParams(QueryParams).build();
 
			// Add Authorization Header
			headers.add("Authorization", KohlsPOCConstant.AUTHID + ApiKey + ":"
					+ signature.getRequestSignature());
		} catch (Exception e) {
			logger.debug("Error in Create HTTP Headers |"+e);
		}
		logger.debug("createHttpHeaders ---------- End");
		return headers;
	}
	
	/**
	 * Sets the properties
	 * @param prop Properties that need to be set
	 * @throws Exception when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		//LOG_CAT.debug("In the set properties method");

	}
}
