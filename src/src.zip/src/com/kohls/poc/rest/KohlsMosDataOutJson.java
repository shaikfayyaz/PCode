package com.kohls.poc.rest;

public class KohlsMosDataOutJson {

	public mosItemDetails [] mosItemDetails;

	public class mosItemDetails{
		
		public String skuNbr;
		public String mosStrtDte;
		
	}
}
