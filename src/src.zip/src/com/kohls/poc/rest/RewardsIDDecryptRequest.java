package com.kohls.poc.rest;


/**
 * @author TKMACJT
 * This is impleted as part of CR 935
 * This class will provide request object for DSB JSON request
 *
 */
public class RewardsIDDecryptRequest {

	private String RequestingEntity;
	private String ExternalVendor;
	private String ExternalPayLoadType;
	private String DataOperation;
	private String DataElement;
	private String DataElementEncoding;
	private String ExtendedDataElement;
	
	



	public String getRequestingEntity() {
		return RequestingEntity;
	}

	public void setRequestingEntity(String RequestingEntity) {
		this.RequestingEntity = RequestingEntity;
	}
	
	public String getExternalVendor() {
		return ExternalVendor;
	}

	public void setExternalVendor(String ExternalVendor) {
		this.ExternalVendor = ExternalVendor;
	}
	
	public String getExternalPayLoadType() {
		return ExternalPayLoadType;
	}

	public void setExternalPayLoadType(String ExternalPayLoadType) {
		this.ExternalPayLoadType = ExternalPayLoadType;
	}
	
	public String getDataOperation() {
		return DataOperation;
	}

	public void setDataOperation(String DataOperation) {
		this.DataOperation = DataOperation;
	}
	
	public String getDataElement() {
		return DataElement;
	}

	public void setDataElement(String DataElement) {
		this.DataElement = DataElement;
	}
	
	
	public String getDataElementEncoding() {
		return DataElementEncoding;
	}

	public void setDataElementEncoding(String DataElementEncoding) {
		this.DataElementEncoding = DataElementEncoding;
	}
	//ExtendedDataElement
	public String getExtendedDataElement() {
		return ExtendedDataElement;
	}

	public void setExtendedDataElement(String ExtendedDataElement) {
		this.ExtendedDataElement = ExtendedDataElement;
	}
	
}
