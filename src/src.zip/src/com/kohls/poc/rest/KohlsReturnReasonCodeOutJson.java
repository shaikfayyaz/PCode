package com.kohls.poc.rest;

public class KohlsReturnReasonCodeOutJson {
	
	public returnReasons[] returnReasons;
	class returnReasons {
		public String device;	
		public String division;	
		public Integer department;	
		public String enable;
		public returnReasonCodes[] returnReasonCodes;
		public String createdDate;	
		public String updatedDate;	
	}
	class returnReasonCodes {
		public Integer code;	//1
		public String description;	//Damaged
	}
}
