package com.kohls.poc.rest;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KohlsReturnLCSInJson {

	private List<RequestDetail> requestDetails = null;
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public List<RequestDetail> getRequestDetails() {
		return requestDetails;
	}

	public void setRequestDetails(List<RequestDetail> requestDetails) {
		this.requestDetails = requestDetails;
	}

	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	public class Product {

		private int lineNumber;
		private int department;
		private String sku;
		private double netPrice;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		public int getLineNumber() {
			return lineNumber;
		}

		public void setLineNumber(int lineNumber) {
			this.lineNumber = lineNumber;
		}

		public int getDepartment() {
			return department;
		}

		public void setDepartment(int department) {
			this.department = department;
		}

		public String getSku() {
			return sku;
		}

		public void setSku(String sku) {
			this.sku = sku;
		}

		public double getNetPrice() {
			return netPrice;
		}

		public void setNetPrice(double netPrice) {
			this.netPrice = netPrice;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}


	public class RequestDetail implements Comparable<RequestDetail>{

		private String loyaltyId;
		private String transactionNumber;
		private String storeNumber;
		private String registerId;
		private String transactionDate;
		private String transactionTime;
		private String orderNumber;
		private double everydayEarnKcc;
		private double everydayEarnNonKcc;
		private double eligibleAmount;
		private List<Product> products = null;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		public String getLoyaltyId() {
			return loyaltyId;
		}

		public void setLoyaltyId(String loyaltyId) {
			this.loyaltyId = loyaltyId;
		}

		public String getTransactionNumber() {
			return transactionNumber;
		}

		public void setTransactionNumber(String transactionNumber) {
			this.transactionNumber = transactionNumber;
		}

		public String getStoreNumber() {
			return storeNumber;
		}

		public void setStoreNumber(String storeNumber) {
			this.storeNumber = storeNumber;
		}

		public String getRegisterId() {
			return registerId;
		}

		public void setRegisterId(String registerId) {
			this.registerId = registerId;
		}

		public String getTransactionDate() {
			return transactionDate;
		}

		public void setTransactionDate(String transactionDate) {
			this.transactionDate = transactionDate;
		}

		public String getTransactionTime() {
			return transactionTime;
		}

		public void setTransactionTime(String transactionTime) {
			this.transactionTime = transactionTime;
		}

		public String getOrderNumber() {
			return orderNumber;
		}

		public void setOrderNumber(String orderNumber) {
			this.orderNumber = orderNumber;
		}

		public double getEverydayEarnKcc() {
			return everydayEarnKcc;
		}

		public void setEverydayEarnKcc(double everydayEarnKcc) {
			this.everydayEarnKcc = everydayEarnKcc;
		}

		public double getEverydayEarnNonKcc() {
			return everydayEarnNonKcc;
		}

		public void setEverydayEarnNonKcc(double everydayEarnNonKcc) {
			this.everydayEarnNonKcc = everydayEarnNonKcc;
		}

		public double getEligibleAmount() {
			return eligibleAmount;
		}

		public void setEligibleAmount(double eligibleAmount) {
			this.eligibleAmount = eligibleAmount;
		}

		public List<Product> getProducts() {
			return products;
		}

		public void setProducts(List<Product> products) {
			this.products = products;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

		/* (non-Javadoc)
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(RequestDetail otherRequestDetail) {
			// incoming format from before
			// SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	        // SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
	        String currentDate = this.getTransactionDate() + " " + this.getTransactionTime();
	        String comparedDate = otherRequestDetail.getTransactionDate() + " " + otherRequestDetail.getTransactionTime();
	        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        // default to 1;
	        int response = 1;
	        try {
	        	response = dateFormatter.parse(currentDate).compareTo(dateFormatter.parse(comparedDate));
	        } catch (Exception ex) {
	        	// couldn't do comparison
	        }
			return response;
		}

	}
}