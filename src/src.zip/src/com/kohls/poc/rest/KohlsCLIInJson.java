package com.kohls.poc.rest;

import java.util.List;

import com.kohls.poc.rest.KohlsPostTenderCartInJson.Product;

public class KohlsCLIInJson
{
   public String         accountId;         // 1234567890
   public String         externalCustomerId; // C12345678901234567890123
   public String         presentationId;    // 123456789012
   public String         behaviorId;        //
   public String         user;              // KCIVR
   private String        tokenNumber;
   private String 		 accountType;
   private List<Element> element = null;

   public List<Element> getElement()
   {
      return element;
   }

   public void setElement( List<Element> elements )
   {
      this.element = elements;
   }

   public String getTokenNumber()
   {
      return tokenNumber;
   }

   public void setTokenNumber( String tokenNumber )
   {
      this.tokenNumber = tokenNumber;
   }

   public String getTokenType()
   {
      return tokenType;
   }

   public void setTokenType( String tokenType )
   {
      this.tokenType = tokenType;
   }

   public String getSsn()
   {
      return ssn;
   }

   public void setSsn( String ssn )
   {
      this.ssn = ssn;
   }

   public String getClipchan()
   {
      return clipchan;
   }

   public void setClipchan( String clipchan )
   {
      this.clipchan = clipchan;
   }

   private String tokenType;
   private String ssn;
   private String clipchan;

   public class Element
   {
      public String elementId;   // IncomeC

      public String elementValue; // 100000

      public String getElementId()
      {
         return elementId;
      }

      public void setElementId( String elementId )
      {
         this.elementId = elementId;
      }

      public String getElementValue()
      {
         return elementValue;
      }

      public void setElementValue( String elementValue )
      {
         this.elementValue = elementValue;
      }
   }

   public String getAccountId()
   {
      return accountId;
   }

   public void setAccountId( String accountId )
   {
      this.accountId = accountId;
   }

   public String getExternalCustomerId()
   {
      return externalCustomerId;
   }

   public void setExternalCustomerId( String externalCustomerId )
   {
      this.externalCustomerId = externalCustomerId;
   }

   public String getPresentationId()
   {
      return presentationId;
   }

   public void setPresentationId( String presentationId )
   {
      this.presentationId = presentationId;
   }

   public String getBehaviorId()
   {
      return behaviorId;
   }

   public void setBehaviorId( String behaviorId )
   {
      this.behaviorId = behaviorId;
   }

   public String getUser()
   {
      return user;
   }

   public void setUser( String user )
   {
      this.user = user;
   }
   public String getAccountType() {
	   return accountType;
   }

   public void setAccountType(String accountType) {
	   this.accountType = accountType;
   }

}