package com.kohls.poc.rest;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import com.kohls.common.util.XMLUtil;

import com.kohls.wsauth.repackaged.apache.commons.codec.binary.Base64;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCallToCFWrapper {

	private static String TOPIC = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_TOPIC);
	private static String BOOTSTRAP_SERVERS = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_BOOTSTRAP_SERVERS);
	private final static String SESSION_TIMEOUT = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_SESSION_TIMEOUT);
	private final static String READ_TIMEOUT = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_READ_TIMEOUT);
	private final static String FETCH_TIMEOUT = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_FETCH_MAX_WAIT);
	private final static String RESET_STRATEGY = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_RESET_STRATEGY);
	private final static String GROUP_ID = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_GROUPID);
	private final static String RETRY_THRESHOLD = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_RETRY_ATTEMPTS);
	private final static String POLL_INTERVAL = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_POLL_INTERVAL);
	private final static String CF_KAFKA_TRUST_STORE_LOC = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_TRUST_STORE_LOC);
	private final static String CF_KAFKA_TRUST_STORE_PWD = new String(Base64.decodeBase64(YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_TRUST_STORE_PWD).getBytes()));
	private final static String CF_KAFKA_SECURITY_PROTOCOL = YFSSystem
			.getProperty(KohlsPOCConstant.CF_KAFKA_SECURITY_PROTOCOL);

	public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
	private static Map<Integer, String> offsetByPartitionMap = new HashMap<>();
	private static Map<Integer, Long> finalOffsetByPartitionMap = new HashMap<>();
	private static String source = "";
	private static String type = "";
	private Properties props;
	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsCallToCFWrapper.class.getName());
	}

	public Document callToCFWrapper(YFSEnvironment env, Document input)
			throws Exception {
		offsetByPartitionMap = new HashMap<>();
		finalOffsetByPartitionMap = new HashMap<>();
		logger.beginTimer("KohlsCallToCFWrapper.callToCFWrapper");
		source = input.getDocumentElement().getAttribute(
				KohlsPOCConstant.E_SOURCE);
		String topicFromAgentProps = input.getDocumentElement().getAttribute(
				KohlsPOCConstant.CF_KAFKA_TOPIC_OVERRIDE);
		if(!YFCCommon.isVoid(topicFromAgentProps))
		{
			TOPIC = topicFromAgentProps;
		}
		type = input.getDocumentElement().getAttribute(KohlsPOCConstant.A_TYPE);
		String fromOffset = input.getDocumentElement().getAttribute(
				KohlsPOCConstant.A_FROM_OFFSET);
		String currentOffsetData = getCFOffsetData(env);
		if(!YFCCommon.isVoid(currentOffsetData))
		{
			populateoffsetByPartitionMap(currentOffsetData);
		}
		else
		{
			type = KohlsPOCConstant.SYNC_FULL;
		}
		if (YFCCommon.isVoid(fromOffset)
				&& KohlsPOCConstant.SYNC_DELTA.equalsIgnoreCase(type)) {
			if (KohlsPOCConstant.CF_STANDALONE.equalsIgnoreCase(source)) {
				logger.info("Fetch Type is DELTA, but No offset provided in the input. trying to fetch offset from Database");
			}
			fromOffset = currentOffsetData;
		}
		if (YFCCommon.isVoid(fromOffset)) {
			if (KohlsPOCConstant.A_CF_AGENT.equalsIgnoreCase(source)) {
				logger.info("Call is from CF Agent. No offset found. changing Fetch type to FULL");
			}
			fromOffset = KohlsPOCConstant.ZERO;
		} else if (KohlsPOCConstant.ZERO.equalsIgnoreCase(fromOffset)) {
			if (KohlsPOCConstant.A_CF_AGENT.equalsIgnoreCase(source)) {
				logger.info("Call is from CF Agent. Offset from DB came back as 0. changing Fetch type to FULL");
			}
		} else {
			if (KohlsPOCConstant.A_CF_AGENT.equalsIgnoreCase(source)) {
				logger.info("Call is from CF Agent. Offset from DB came back as "
						+ fromOffset + ". Continuing as DELTA Fetch Type");
			}
		}
		runConsumer(env);

		  Document outCFDataOffset =createCFOffsetDoc(); 
		  
		  Element eleCFOffData=outCFDataOffset.getDocumentElement();
		  if(!YFCCommon.isVoid(CFOutput)) {
		  XMLUtil.importElement(
				  CFOutput.getDocumentElement(), eleCFOffData);
		  } else { 
			  CFOutput =
		  SCXmlUtil.createDocument("KohlsDefEdgHighRiskItemList");
		  XMLUtil.importElement(CFOutput.getDocumentElement(), eleCFOffData);
		  }
		  
		if (KohlsPOCConstant.CF_STANDALONE.equalsIgnoreCase(source)) {
			if (!YFCCommon.isVoid(CFOutput)) {
				CFOutput.getDocumentElement().setAttribute(KohlsPOCConstant.E_SOURCE,KohlsPOCConstant.CF_STANDALONE);
				kohlsFraudDataUtil.modifyTable(CFOutput, env);
			}
		}

		if (!KohlsPOCConstant.CF_STANDALONE.equalsIgnoreCase(source)) {
			logger.info("Sending the CF Data list to Agent from KohlsCallToCFWrapper");
		}
		logger.endTimer("KohlsCallToCFWrapper.callToCFWrapper");
		return CFOutput;

	}

		private void populateoffsetByPartitionMap(String currentOffsetData) {
			
			String[] offsetValues = currentOffsetData.split("\\|");
			for (String offset: offsetValues) {           
			    //Do your stuff here
			    String[] offsetPartitions = offset.split("_");
			    if(!YFCCommon.isVoid(offsetPartitions))
			    {
			    	offsetByPartitionMap.put(Integer.parseInt(offsetPartitions[0]),offsetPartitions[1]);
			    }
			}
	}

		private static Consumer<Long, String> createConsumer()
			throws InterruptedException, ExecutionException {

		logger.beginTimer("KohlsCallToCFWrapper.Consumer");

		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				StringDeserializer.class.getName());
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, RESET_STRATEGY);
		props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, SESSION_TIMEOUT);
		props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, READ_TIMEOUT);
		props.put(KohlsPOCConstant.CF_KAFKA_SECURITY_PROTOCOL_PROP, CF_KAFKA_SECURITY_PROTOCOL);
		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, CF_KAFKA_TRUST_STORE_LOC);
		props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, CF_KAFKA_TRUST_STORE_PWD);
		props.put(ConsumerConfig.CONNECTIONS_MAX_IDLE_MS_CONFIG, SESSION_TIMEOUT);
		props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, FETCH_TIMEOUT);
		final Consumer<Long, String> consumer = new KafkaConsumer<>(props);
		try {
			consumer.listTopics();
		} catch (Exception e) {
			logger.error("Error while connecting to Kafka topic. current system time is"
					+ new Date());
			throw e;
		}
		consumer.subscribe(Collections.singletonList(TOPIC));

		consumer.subscribe(Arrays.asList(TOPIC),
				new ConsumerRebalanceListener() {
					public void onPartitionsRevoked(
							Collection<TopicPartition> partitions) {
						
						consumer.commitAsync();
						if (YFCLogUtil.isDebugEnabled()) {
							logger.info(
									"%s topic-partitions are revoked from this consumer\n"+
									Arrays.toString(partitions.toArray()));
						}
					}

					public void onPartitionsAssigned(
							Collection<TopicPartition> partitions) {
						if (YFCLogUtil.isDebugEnabled()) {
							logger.info(
									"%s topic-partitions are assigned to this consumer\n"+
									Arrays.toString(partitions.toArray()));
						}
						Iterator<TopicPartition> topicPartitionIterator = partitions
								.iterator();
						while (topicPartitionIterator.hasNext()) {
							TopicPartition topicPartition = topicPartitionIterator
									.next();
							consumer.seekToEnd(topicPartition);
							long finalOffset = consumer.position(topicPartition);
							finalOffsetByPartitionMap.put(topicPartition.partition(), finalOffset);
							
							if (YFCLogUtil.isDebugEnabled()) {
								logger.debug("Current offset is "
										+ consumer.position(topicPartition)
										+ " committed offset is ->"
										+ consumer.committed(topicPartition));
							}
							if (KohlsPOCConstant.SYNC_FULL
									.equalsIgnoreCase(type) || YFCCommon.isVoid(offsetByPartitionMap.get(topicPartition.partition()))) {
								logger.info("Seek from Beginning for the partition # "+topicPartition.partition()
								+" , End Offset is: " + finalOffset);
								consumer.seekToBeginning(topicPartition);
							} else {	
								logger.info("partition # "+topicPartition.partition()+" , Beginning Offset is: " +offsetByPartitionMap.get(topicPartition.partition())
								+ " , End Offset is: " + finalOffset);
								consumer.seek(topicPartition,
										Long.valueOf(offsetByPartitionMap.get(topicPartition.partition())));
							}
						}
					}
				});

		logger.endTimer("KohlsCallToCFWrapper.Consumer");

		return consumer;

	}

	KohlsFraudDataUtil kohlsFraudDataUtil = new KohlsFraudDataUtil();
	private Document CFOutput = null;
	private Integer fetchedCount = 0;
	String sFilePath = "";
	
	/**private static String readFile(String path, Charset encoding) 
			  throws IOException
			{			 
			  byte[] encoded = Files.readAllBytes(Paths.get(path));			  
			  return new String(encoded, encoding);
			}
	 * @throws Exception **/


	private void runConsumer(YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsCallToCFWrapper.runConsumer");
					
		int giveUp = Integer.parseInt(RETRY_THRESHOLD);
		final Consumer<Long, String> consumer = createConsumer();

		int noRecordsCount = 0;
		while (true) {
			final ConsumerRecords<Long, String> consumerRecords = consumer
					.poll(Integer.parseInt(POLL_INTERVAL));
			if (consumerRecords.count() == 0) {
				noRecordsCount++;
				if (noRecordsCount > giveUp)
					break;
				else
					continue;
			}

			Iterator<ConsumerRecord<Long, String>> records = consumerRecords
					.iterator();
			while (records.hasNext()) {
				ConsumerRecord<Long, String> record = records.next();
				fetchedCount++;
				SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
				
				String timestamp = sdf.format(YFCDateUtils
						.getCurrentDate(true));
				try {
					sFilePath = props.getProperty("LogDir");
					Long offset = record.offset() + 1;
					String filePrefix = "CFInfo_" + offset + "_"
							+ timestamp + ".txt";
					Path filePath = Paths.get(sFilePath);
					if (Files.exists(filePath)) {
						restApiutil.writeToFile("Value for offset# "
								+ offset + " is --->", record.value(),
								filePrefix, sFilePath);
					}
				} catch (Exception ex) {
					logger.error("Logger Dir " + sFilePath
							+ " does not exist.So moving on");
				}
				 String value = record.value().trim();
				 value = value.trim().replaceAll("sub_class", "subcls");
				 value = value.trim().replaceAll("class", "major");
				CFOutput = kohlsFraudDataUtil.getXMLfromJson(CFOutput,
						value.trim(),type);

				record.offset();
			}
			consumer.commitAsync();
		}
		consumer.close();
		logger.info("Done fetching the message from CF");

		logger.endTimer("KohlsCallToCFWrapper.runConsumer");

	}
	
	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}

	public  String getCFOffsetData(YFSEnvironment env) {
    	logger.beginTimer("KohlsCallToCFWrapper.getCFOffsetData");
    	 String sGetOffset = KohlsPOCConstant.ZERO;

    Document inDocApi = null;
   
    try {
     inDocApi = XmlUtils.createDocument(KohlsPOCConstant.KohlsDefEdgHighRiskItem);
    Element eleRootInDoc = inDocApi.getDocumentElement();     
    eleRootInDoc.setAttribute(KohlsPOCConstant.A_DEPTNBR,"CF_KAFKA_OFFSET");
    eleRootInDoc.setAttribute(KohlsPOCConstant.A_MAJOR_CLASS,"00");
    eleRootInDoc.setAttribute(KohlsPOCConstant.A_SUB_CLASS,"00");
    sGetOffset= kohlsFraudDataUtil.getCFDescription(env, inDocApi);

    } catch (Exception e) {
        	logger.error("Error while fetching the offset value. Ignore and proceed");
    		logger.error("Error is "+e.getMessage());
    }
    logger.endTimer("KohlsCallToCFWrapper.getCFOffsetData");
       
    	
    	 return sGetOffset;
 }

public Document createCFOffsetDoc() throws Exception {
	logger.beginTimer("KohlsCallToCFWrapper.createCFOffsetDoc");
	Document inDocApi = XmlUtils
			.createDocument(KohlsPOCConstant.KohlsDefEdgHighRiskItem);
	Element eleRootInDoc = inDocApi.getDocumentElement();
    eleRootInDoc.setAttribute(KohlsPOCConstant.A_DEPTNBR,"CF_KAFKA_OFFSET");
    eleRootInDoc.setAttribute(KohlsPOCConstant.A_MAJOR_CLASS,"00");
    eleRootInDoc.setAttribute(KohlsPOCConstant.A_SUB_CLASS,"00");
    String offsetValue = getFinalOffsetValue();
	eleRootInDoc.setAttribute("Description",
			String.valueOf(offsetValue));

	if (YFCLogUtil.isDebugEnabled()) {
		logger.debug("out Document is --" + XMLUtil.getXMLString(inDocApi));
	}
	logger.endTimer("KohlsCallToCFWrapper.createCFOffsetDoc");
	return inDocApi;
}

private String getFinalOffsetValue() {
	// TODO Auto-generated method stub
	String offsetValues = "";
	for (Map.Entry<Integer, Long> entry : finalOffsetByPartitionMap.entrySet())  
	{
		if(YFCCommon.isVoid(offsetValues))
		{
			offsetValues = entry.getKey()+"_"+entry.getValue(); 
		}
		else
		{
			offsetValues = offsetValues + "|"+entry.getKey()+"_"+entry.getValue(); 
		}
	}
	return offsetValues;
}

}
