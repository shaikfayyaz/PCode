package com.kohls.poc.rest;


/**
 * This is implemented as part of CR 935
 * This class object is to translate the JSON object to java object
 * 
 * @author TKMACJT
 *
 */
public class TranslateDSBResponseJSON{


	public String ServiceLocation;
	public String DataElement;
	public String ErrorCode;
	public String ErrorDescription;

}
