package com.kohls.poc.rest;

import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.yantra.yfc.log.YFCLogCategory;

/**
 * This class <code>KohlsRestAPIPooledExecutorService</code> will create a
 * reusable pool of threads that will automatically scale up or down depending
 * the number of incoming requests. Each request will be executed on a separate
 * child thread from the thread pool, and will guarantee to respond back to the
 * caller no longer than the specified hardTimeout.
 * 
 * @author tkmaagk
 */
public class KohlsRestAPIPooledExecutorService {

	private final static YFCLogCategory logger = YFCLogCategory.instance(KohlsRestAPIPooledExecutorService.class);

	public static KohlsRestAPIPooledExecutorService instance = new KohlsRestAPIPooledExecutorService();

	/*
	 * Creates a thread pool that creates new threads as needed, but will reuse
	 * previously constructed threads when they are available. These pools will
	 * typically improve the performance of programs that execute many short-lived
	 * asynchronous tasks. Calls to execute will reuse previously constructed
	 * threads if available. If no existing thread is available, a new thread will
	 * be created and added to the pool. Threads that have not been used for sixty
	 * seconds are terminated and removed from the cache. Thus, a pool that remains
	 * idle for long enough will not consume any resources.
	 */
	private ExecutorService pooledExecutor = Executors.newCachedThreadPool();

	/**
	 * Submit a request to the pool executor which sends the request on a separate
	 * thread. This method blocks until the response comes back or timed out waiting
	 * for the response to come back but exceeded the specified
	 * <code>hardTimeout</code> or other exception thrown back via the executor.
	 * 
	 * @param request the callable request
	 * @return the response
	 * @throws Exception
	 */
	public ResponseEntity<String> blockingCall(Callable<ResponseEntity<String>> request, long hardTimeout,
			String service) throws Exception {
		
		long startTime = System.currentTimeMillis();
		ResponseEntity<String> response = new ResponseEntity<String>(HttpStatus.SERVICE_UNAVAILABLE);
		try {
			response = pooledExecutor.submit(request).get(hardTimeout, TimeUnit.MILLISECONDS);
		} catch (TimeoutException e) {
			response = new ResponseEntity<String>(HttpStatus.GATEWAY_TIMEOUT);
			logger.info("Request execution possible runaway thread.  Time taken > " + hardTimeout
					+ "ms. Return " + response.getStatusCode() + " for Service: " + service);
		} catch (CancellationException e) {
			logger.info("Request execution cancelled. Return " + response.getStatusCode()  + " for Service: " + service);
		} catch (InterruptedException e) {
			logger.info("Request execution interrupted. Return " + response.getStatusCode()  + " for Service: " + service);
		} catch (RejectedExecutionException e) {
			logger.info("Request execution rejected. Return " + response.getStatusCode()  + " for Service: " + service);
		} catch (ExecutionException e) {
			// e should already logged by the REST/SOAP client implementation, eg, KohlsRestAPIUtil
			if (e.getCause() instanceof Exception) {
				throw (Exception)e.getCause();
			}
			else {
				throw new Exception(e.getCause());
			}
		} catch (Exception e) {
			logger.error("Request execution exception: " + e.getMessage() + " Return " + response.getStatusCode()  + " for Service: " + service);
		} finally {
			if (logger.isDebugEnabled()) {
				long endTime = System.currentTimeMillis();
				long timeDiff = endTime - startTime;
				logger.debug("Request execution Time taken - " + timeDiff + "ms. Service: " + service);
			}
		}
		return response;
	}

}
