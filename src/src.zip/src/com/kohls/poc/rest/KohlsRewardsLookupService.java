package com.kohls.poc.rest;

import com.kohls.common.util.KOHLSBaseApi;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;

import java.util.Properties;

/**
 * Entry point to lookup a Kohls Rewards Member (and a linked Sephora Beauty Insider member)
 * Given email/phone/kcc/or bankcard
 * <p>
 * https://confluence.kohls.com:8443/pages/viewpage.action?pageId=253171883
 */
public class KohlsRewardsLookupService extends KOHLSBaseApi {


    public Document getCustomerList(YFSEnvironment env, Document inDoc) throws Exception {
        Properties properties = getProperties();
        String baseUrl = properties.getProperty("KR_LOOKUP_BASE_URL");
        if ("Mock".equalsIgnoreCase(baseUrl))
            return new KohlsRewardsLookupServiceMockImpl().getCustomerList(env, inDoc, properties);

        int maxTries = KohlsCustomerIdentificationTool.getConfiguredRetryCount(env);
        return new KohlsRewardsLookupServiceImpl().getCustomerList(inDoc, properties, maxTries);
    }

}
