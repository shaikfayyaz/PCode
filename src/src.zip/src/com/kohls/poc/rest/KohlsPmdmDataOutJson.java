package com.kohls.poc.rest;

/**
 * Created by tkma36l on 3/11/21.
 */
public class KohlsPmdmDataOutJson {

    public String skuNumber;
    public String upcNumber;
}
