package com.kohls.poc.rest;

import java.io.Serializable;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class KohlsGetReturnPassDetailsOutJson implements Serializable
{

	@SerializedName("returnPassCode")
	@Expose
	private String returnPassCode;
	@SerializedName("orderDetails")
	@Expose
	private OrderDetails orderDetails;
	@SerializedName("receiptId")
	@Expose
	private String receiptId;
	@SerializedName("storeDetails")
	@Expose
	private StoreDetails storeDetails;
	@SerializedName("refundMethod")
	@Expose
	private String refundMethod;
	@SerializedName("receiptPreference")
	@Expose
	private ReceiptPreference receiptPreference;
	@SerializedName("status")
	@Expose
	private String status;
	@SerializedName("items")
	@Expose
	private List<Item> items = null;
	@SerializedName("customerInfo")
	@Expose
	private CustomerInfo customerInfo;
	@SerializedName("createdDate")
	@Expose
	private String createdDate;
	@SerializedName("updatedDate")
	@Expose
	private String updatedDate;
	private final static long serialVersionUID = -5617453091568771539L;

	public String getReturnPassCode() {
		return returnPassCode;
	}

	public void setReturnPassCode(String returnPassCode) {
		this.returnPassCode = returnPassCode;
	}

	public OrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	public String getReceiptId() {
		return receiptId;
	}

	public void setReceiptId(String receiptId) {
		this.receiptId = receiptId;
	}

	public StoreDetails getStoreDetails() {
		return storeDetails;
	}

	public void setStoreDetails(StoreDetails storeDetails) {
		this.storeDetails = storeDetails;
	}

	public String getRefundMethod() {
		return refundMethod;
	}

	public void setRefundMethod(String refundMethod) {
		this.refundMethod = refundMethod;
	}

	public ReceiptPreference getReceiptPreference() {
		return receiptPreference;
	}

	public void setReceiptPreference(ReceiptPreference receiptPreference) {
		this.receiptPreference = receiptPreference;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public CustomerInfo getCustomerInfo() {
		return customerInfo;
	}

	public void setCustomerInfo(CustomerInfo customerInfo) {
		this.customerInfo = customerInfo;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}


	public class OrderDetails implements Serializable
	{

		@SerializedName("orderNumber")
		@Expose
		private String orderNumber;
		@SerializedName("zipCode")
		@Expose
		private String zipCode;
		private final static long serialVersionUID = -6451410106391736037L;

		public String getOrderNumber() {
			return orderNumber;
		}

		public void setOrderNumber(String orderNumber) {
			this.orderNumber = orderNumber;
		}

		public String getZipCode() {
			return zipCode;
		}

		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}

	}

	public class ReceiptPreference implements Serializable
	{

		@SerializedName("method")
		@Expose
		private String method;
		@SerializedName("emailID")
		@Expose
		private Object emailID;
		private final static long serialVersionUID = -3639167986043173297L;

		public String getMethod() {
			return method;
		}

		public void setMethod(String method) {
			this.method = method;
		}

		public Object getEmailId() {
			return emailID;
		}

		public void setEmailId(Object emailID) {
			this.emailID = emailID;
		}

	}

	public class StoreDetails implements Serializable
	{

		@SerializedName("storeId")
		@Expose
		private String storeId;
		@SerializedName("name")
		@Expose
		private String name;
		@SerializedName("addr1")
		@Expose
		private String addr1;
		@SerializedName("addr2")
		@Expose
		private String addr2;
		@SerializedName("city")
		@Expose
		private String city;
		@SerializedName("state")
		@Expose
		private String state;
		@SerializedName("zipCode")
		@Expose
		private String zipCode;
		@SerializedName("phoneNumber")
		@Expose
		private String phoneNumber;
		private final static long serialVersionUID = -1392320317495023953L;

		public String getStoreId() {
			return storeId;
		}

		public void setStoreId(String storeId) {
			this.storeId = storeId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAddr1() {
			return addr1;
		}

		public void setAddr1(String addr1) {
			this.addr1 = addr1;
		}

		public String getAddr2() {
			return addr2;
		}

		public void setAddr2(String addr2) {
			this.addr2 = addr2;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getZipCode() {
			return zipCode;
		}

		public void setZipCode(String zipCode) {
			this.zipCode = zipCode;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

	}

	public class TransactionKey implements Serializable
	{

		@SerializedName("locationNumber")
		@Expose
		private String locationNumber;
		@SerializedName("deviceId")
		@Expose
		private String deviceId;
		@SerializedName("transactionNumber")
		@Expose
		private String transactionNumber;
		@SerializedName("transactionTimestamp")
		@Expose
		private String transactionTimestamp;
		private final static long serialVersionUID = -5345115971851717143L;

		public String getLocationNumber() {
			return locationNumber;
		}

		public void setLocationNumber(String locationNumber) {
			this.locationNumber = locationNumber;
		}

		public String getDeviceId() {
			return deviceId;
		}

		public void setDeviceId(String deviceId) {
			this.deviceId = deviceId;
		}

		public String getTransactionNumber() {
			return transactionNumber;
		}

		public void setTransactionNumber(String transactionNumber) {
			this.transactionNumber = transactionNumber;
		}

		public String getTransactionTimestamp() {
			return transactionTimestamp;
		}

		public void setTransactionTimestamp(String transactionTimestamp) {
			this.transactionTimestamp = transactionTimestamp;
		}

	}

	public class CustomerInfo implements Serializable
	{

		@SerializedName("profileID")
		@Expose
		private String profileID;
		@SerializedName("emailID")
		@Expose
		private String emailID;
		@SerializedName("loyaltyID")
		@Expose
		private String loyaltyID;
		private final static long serialVersionUID = -1202343256260619020L;

		public String getProfileID() {
			return profileID;
		}

		public void setProfileID(String profileID) {
			this.profileID = profileID;
		}

		public String getEmailID() {
			return emailID;
		}

		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}

		public String getLoyaltyID() {
			return loyaltyID;
		}

		public void setLoyaltyID(String loyaltyID) {
			this.loyaltyID = loyaltyID;
		}

	}

	public class Item implements Serializable
	{

		@SerializedName("skuNumber")
		@Expose
		private String skuNumber;
		@SerializedName("lineSequenceNumber")
		@Expose
		private String lineSequenceNumber;
		@SerializedName("reasonCode")
		@Expose
		private String reasonCode;
		@SerializedName("reasonDesc")
		@Expose
		private String reasonDesc;
		@SerializedName("upc")
		@Expose
		private String upc;
		@SerializedName("status")
		@Expose
		private String status;
		@SerializedName("transactionKey")
		@Expose
		private TransactionKey transactionKey;
		@SerializedName("productID")
		@Expose
		private String productID;
		@SerializedName("title")
		@Expose
		private String title;
		@SerializedName("size")
		@Expose
		private String size;
		@SerializedName("color")
		@Expose
		private String color;
		@SerializedName("imageURL")
		@Expose
		private String imageURL;
		private final static long serialVersionUID = 1256942478489344564L;

		public String getSkuNumber() {
			return skuNumber;
		}

		public void setSkuNumber(String skuNumber) {
			this.skuNumber = skuNumber;
		}

		public String getLineSequenceNumber() {
			return lineSequenceNumber;
		}

		public void setLineSequenceNumber(String lineSequenceNumber) {
			this.lineSequenceNumber = lineSequenceNumber;
		}

		public String getReasonCode() {
			return reasonCode;
		}

		public void setReasonCode(String reasonCode) {
			this.reasonCode = reasonCode;
		}

		public String getReasonDesc() {
			return reasonDesc;
		}

		public void setReasonDesc(String reasonDesc) {
			this.reasonDesc = reasonDesc;
		}

		public String getUpc() {
			return upc;
		}

		public void setUpc(String upc) {
			this.upc = upc;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public TransactionKey getTransactionKey() {
			return transactionKey;
		}

		public void setTransactionKey(TransactionKey transactionKey) {
			this.transactionKey = transactionKey;
		}

		public String getProductID() {
			return productID;
		}

		public void setProductID(String productID) {
			this.productID = productID;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getSize() {
			return size;
		}

		public void setSize(String size) {
			this.size = size;
		}

		public String getColor() {
			return color;
		}

		public void setColor(String color) {
			this.color = color;
		}

		public String getImageURL() {
			return imageURL;
		}

		public void setImageURL(String imageURL) {
			this.imageURL = imageURL;
		}

	}
}