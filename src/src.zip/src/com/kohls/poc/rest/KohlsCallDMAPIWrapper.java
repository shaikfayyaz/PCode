package com.kohls.poc.rest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.regex.Matcher;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import com.kohls.poc.util.KohlsPoCDMUtil;

import org.apache.commons.json.JSONObject;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsDateUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.util.webserviceUtil.FailoverUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDate;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


public class KohlsCallDMAPIWrapper {
    public String strDomain = "";
    public  String strReadTimeOut = "3000";
    public  String strConnectTimeOut = "3000";
    public  String strEndPoint = "";
    public String strQueryParam = "";
    public String strApiKey = "";
    public String strApiSecretKey = "";
    public  String jsonPayload = "";
    public  KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
    public String filePrefix;
    private String sFilePath="";
    private String source ="";
    private Properties props;
    FailoverUtil failoverUtil = FailoverUtil.getInstance();
    private static YFCLogCategory logger;
    private boolean bWriteToFile = true;
    private  SimpleDateFormat sdf = null;
    private String timestamp = null;
    private boolean bProxyRequired = false;
    private String sStandAlone="N";

    private String strProxyHost = "";
    private int iProxyport = 0;
    private boolean boAuthNeeded = true;
    String activeEndpoint = "";
 
    static {
            logger = YFCLogCategory.instance(KohlsCallDMAPIWrapper.class
            .getName());
    }
 
    private  String accessToken = null;
    private int maxRetries = 3;
    private int count = 0;
    private boolean gotoCloud = false;
	private KohlsPoCDMUtil dmUtil;  

    public Document callDMAPI(YFSEnvironment env,Document input)
            throws Exception {
        logger.beginTimer("KohlsCallDMAPIWrapper.callDMAPI");
        if(logger.isDebugEnabled()) {
          logger.debug("KohlsCallDMAPIWrapper.callDMAPI --- Input to callDMAPI" + XMLUtil.getXMLString(input));
        }
        
        Document output = null;
        
       sdf = new SimpleDateFormat("ddHHmmss");
      timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));

    Element eleInDoc = input.getDocumentElement();
    source = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_DM_SOURCE);
    if(!YFCCommon.isVoid(eleInDoc.getAttribute(KohlsPOCConstant.DM_STAND_ALONE)))
    {
        sStandAlone=eleInDoc.getAttribute(KohlsPOCConstant.DM_STAND_ALONE);
    }    
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();

        KohlsDMDispoManJson inputJson = new KohlsDMDispoManJson();
        
       
        timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
        
        
        String httpMethod = "";
             
        
        String storeNumber = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_STORE_NO);
        if(!YFCCommon.isVoid(storeNumber) && NumberUtils.isNumber(storeNumber))
        {
                inputJson.setStoreNumber(Long.parseLong(storeNumber));
        }
        boolean overrideMaxRetries = true;
        
        String terminalNo = eleInDoc.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
        String transactioNo = eleInDoc.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);         
        if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source))
        {
            logger.debug("dmGetDispositions ::");
        		if(!failoverUtil.isEndpointMonitored(KohlsPOCConstant.DM_DOMAIN))
            {
                    gotoCloud = true;
            }
        		else if(!gotoCloud)
        		{        			                		               		
            		boolean sValue=goAlwaysToCloudRuleEnabled(env ,storeNumber);
            		 if(logger.isDebugEnabled()) {
           	          logger.debug("KohlsCallDMAPIWrapper.callDMAPI ---the rule value is  "+sValue);
           	        }
            		if(sValue)
            		{           			
        				 if(logger.isDebugEnabled()) {
        	       	          logger.debug("KohlsCallDMAPIWrapper.callDMAPI -- SBC Rule says always go to cloud");
        	       	        }
        				gotoCloud = true;
            		}   	
        		}
            strEndPoint = props.getProperty(KohlsPOCConstant.DM_ENDPOINT_DISPOSITION);
            
            String sku = eleInDoc.getAttribute(KohlsPOCConstant.A_ITEM_ID);
            if(!YFCCommon.isVoid(sku) && NumberUtils.isNumber(sku))
            {
                    inputJson.setSku(Long.parseLong(sku));
            }
            
            String itemPrice = eleInDoc.getAttribute(KohlsPOCConstant.A_UNIT_PRICE);
            if(!YFCCommon.isVoid(itemPrice) && NumberUtils.isNumber(itemPrice))
            inputJson.setItemPrice(Float.parseFloat(itemPrice));
            String contaminatedFlag = eleInDoc.getAttribute(KohlsPOCConstant.CONTAMINATED_FLAG);
            if(!YFCCommon.isVoid(contaminatedFlag))
            {
                inputJson.setcontaminatedFlag(BooleanUtils.toBoolean(contaminatedFlag, KohlsPOCConstant.YES,KohlsPOCConstant.NO));
            }
            String damagedFlag = eleInDoc.getAttribute(KohlsPOCConstant.DAMAGED_FLAG);
            if(!YFCCommon.isVoid(damagedFlag))
            {
                    inputJson.setDamagedFlag(BooleanUtils.toBoolean(damagedFlag, KohlsPOCConstant.YES,KohlsPOCConstant.NO));
            }
          //CPE-10412 - START
            if(YFCCommon.isVoid(damagedFlag) || (!YFCCommon.isVoid(damagedFlag) && !damagedFlag.equalsIgnoreCase(KohlsPOCConstant.YES))){
            	String mosSalvageFlag = eleInDoc.getAttribute(KohlsPOCConstant.MOS_SALVAGE_FLAG);
                if(!YFCCommon.isVoid(mosSalvageFlag))
                {
                        if(!YFCCommon.isVoid(mosSalvageFlag) && mosSalvageFlag.equalsIgnoreCase(KohlsPOCConstant.YES)){
                        	inputJson.setMosSalvageFlag(true);
                        }
                }
            }            
            //CPE-10412 - END
            String damagedResellableFlag = eleInDoc.getAttribute(KohlsPOCConstant.DAMAGED_RESELLABLE_FLAG);
            if(!YFCCommon.isVoid(damagedResellableFlag))
            {
                    inputJson.setDamagedResellableFlag(BooleanUtils.toBoolean(damagedResellableFlag, KohlsPOCConstant.YES,KohlsPOCConstant.NO));
            }
            String uPC = eleInDoc.getAttribute(KohlsPOCConstant.A_UPC);
            if(!YFCCommon.isVoid(uPC) && NumberUtils.isNumber(uPC))
            {
                    inputJson.setUPC(Long.valueOf(uPC));
            }
            String itemStatusCode = eleInDoc.getAttribute(KohlsPOCConstant.ITEM_STATUS_CODE);
            if(!YFCCommon.isVoid(itemStatusCode))
            {
                    inputJson.setItemStatusCode(itemStatusCode);
            }
            String itemDept = eleInDoc.getAttribute(KohlsPOCConstant.ITEM_DEPT);
            if(!YFCCommon.isVoid(itemDept))
            {
                    inputJson.setItemDept(itemDept);
            }
            String itemClass = eleInDoc.getAttribute(KohlsPOCConstant.ITEM_CLASS);
            if(!YFCCommon.isVoid(itemClass))
            {
                    inputJson.setItemClass(itemClass);
            }
            String itemSubClass = eleInDoc.getAttribute(KohlsPOCConstant.ITEM_SUB_CLASS);
            if(!YFCCommon.isVoid(itemSubClass))
            {
                    inputJson.setItemSubClass(itemSubClass);
            }
            String itemStyle = eleInDoc.getAttribute(KohlsPOCConstant.ITEM_STYLE);
            if(!YFCCommon.isVoid(itemStyle))
            {
                    inputJson.setItemStyle(itemStyle);
            }
            String vendorReturnDispCode = eleInDoc.getAttribute(KohlsPOCConstant.VENDOR_RETURN_DISP_CODE);
            if(!YFCCommon.isVoid(vendorReturnDispCode))
            {
                    inputJson.setVendorReturnDispCode(vendorReturnDispCode);
            }
            String callbackTypeCode = eleInDoc.getAttribute(KohlsPOCConstant.CALL_BACK_TYPE_CODE);
            if(!YFCCommon.isVoid(callbackTypeCode))
            {
                    inputJson.setCallbackTypeCode(callbackTypeCode);
            }
            String callbackID = eleInDoc.getAttribute(KohlsPOCConstant.CALL_BACK_ID);
            
            if(!YFCCommon.isVoid(callbackID) && NumberUtils.isNumber(callbackID))
            {
                    inputJson.setcallbackID(Long.parseLong(callbackID));
            }
            
            String callbackStartDate = eleInDoc.getAttribute(KohlsPOCConstant.CALL_BACK_START_DATE);
            if(!YFCCommon.isVoid(callbackStartDate))
            {
                    inputJson.setcallbackStartDate(callbackStartDate);
            }
            String callbackEndDate = eleInDoc.getAttribute(KohlsPOCConstant.CALL_BACK_END_DATE);
            if(!YFCCommon.isVoid(callbackEndDate))
            {
                    inputJson.setcallbackEndDate(callbackEndDate);
            }
            String hazMaterialFlag = eleInDoc.getAttribute(KohlsPOCConstant.HAZ_MATERIAL_FLAG);
            if(!YFCCommon.isVoid(hazMaterialFlag))
            {               
                    inputJson.sethazMatFlag(BooleanUtils.toBoolean(hazMaterialFlag, KohlsPOCConstant.YES,KohlsPOCConstant.NO));
                    if(!gotoCloud && hazMaterialFlag.equalsIgnoreCase(KohlsPOCConstant.YES)){
	         			gotoCloud = true;
	            		}  
            }
            String hazMaterialClass = eleInDoc.getAttribute(KohlsPOCConstant.HAZ_MATERIAL_CLASS);
            if(!YFCCommon.isVoid(hazMaterialClass))
            {
                    inputJson.sethazMaterialClass(hazMaterialClass);
            }
            String hazMaterialSubclass = eleInDoc.getAttribute(KohlsPOCConstant.HAZ_MATERIAL_SUB_CLASS);
            if(!YFCCommon.isVoid(hazMaterialSubclass))
            {
                    inputJson.sethazMaterialSubclass(hazMaterialSubclass);
            }
            String vendorRTVThresholdReached = eleInDoc.getAttribute(KohlsPOCConstant.VENDOR_RTV_THRESHOLD_REACHED);
            if(!YFCCommon.isVoid(vendorRTVThresholdReached))
            {
                    inputJson.setvendorRTVThresholdReached(vendorRTVThresholdReached);
            }
            String webExclusiveFlag = eleInDoc.getAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_FLAG);
            if(!YFCCommon.isVoid(webExclusiveFlag))
            {
                    inputJson.setWebExclusiveFlag(BooleanUtils.toBoolean(webExclusiveFlag, KohlsPOCConstant.YES,KohlsPOCConstant.NO));
            }
            String webExclusiveDispCode = eleInDoc.getAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_DISP_CODE);
            if(!YFCCommon.isVoid(webExclusiveDispCode))
            {
                    inputJson.setwebExclusiveDispCode(webExclusiveDispCode);
            }
            String webExclusiveDispDesc = eleInDoc.getAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_DISP_DESC);
            if(!YFCCommon.isVoid(webExclusiveDispDesc))
            {
                    inputJson.setwebExclusiveDispDesc(webExclusiveDispDesc);
            }
            String damageReasonDesc = eleInDoc.getAttribute(KohlsPOCConstant.DAMAGE_REASON_DESC);
            if(!YFCCommon.isVoid(damageReasonDesc))
            {
                    inputJson.setdamageReasonDesc(damageReasonDesc);
            }
            String auditID = eleInDoc.getAttribute(KohlsPOCConstant.AUDIT_ID);
            if(!YFCCommon.isVoid(auditID))
            {
                    inputJson.setauditID(auditID.toLowerCase());
            }
                        
            inputJson.setDevice(KohlsPOCConstant.POC_DEVICE_CODE);
           
           
            jsonPayload = gson.toJson(inputJson).toString();
            jsonPayload = jsonPayload.replaceAll(",\"disposition\":0", "");
            
            if(!gotoCloud)
	        {
				if (!YFCCommon.isVoid(callbackTypeCode) && (YFCCommon.isVoid(callbackEndDate)
							|| YFCCommon.isVoid(callbackStartDate))) {
							gotoCloud = true;
					}
					else if (!YFCCommon.isVoid(webExclusiveFlag) && 
							KohlsPOCConstant.YES.equalsIgnoreCase(webExclusiveFlag) && 
							YFCCommon.isVoid(webExclusiveDispCode))
					{
							gotoCloud = true;
					}
					else if (YFCCommon.isVoid(itemSubClass)
						|| YFCCommon.isVoid(itemClass)
						|| YFCCommon.isVoid(itemDept)){
							gotoCloud = true;
	
				}
	        }
            if(logger.isDebugEnabled()) {
              logger.debug("jsonPayload request-->"+jsonPayload);
            }
            
            filePrefix = "Disposition_"+storeNumber+"-"+terminalNo+"-"+transactioNo+".txt";
            try {
            		sFilePath = getPropertyValue(props.getProperty("LogDir"));
                restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                  logger.error("Logger Dir does not exist. So moving on");
              }
            
            if(logger.isDebugEnabled()) {
              logger.debug("payload is"+jsonPayload);
            }
        }
        else if (KohlsPOCConstant.SOURCE_VOIDDMAH.equals(source))
        {
                
                logger.debug("audit-history/void ::");
                
                KohlsDMAuditHistoryVoidInJson voidInput = new KohlsDMAuditHistoryVoidInJson();
                storeNumber = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_STORE_NO);
                
                terminalNo = eleInDoc.getAttribute(KohlsPOCConstant.A_TERMINAL_ID);
                transactioNo = eleInDoc.getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
                    
                NodeList nlvoidAuditHist = input.getElementsByTagName(KohlsPOCConstant.ELE_VOID_AUDITHISTORY);//KohlsXMLLiterals.E_EXTN
                List<KohlsDMAuditHistoryVoidInJson.BulkSkus> bulkSkus = new ArrayList<KohlsDMAuditHistoryVoidInJson.BulkSkus>(); 
                
                if(nlvoidAuditHist.getLength()>0){
                    for (int i = 0; i < nlvoidAuditHist.getLength(); i++) 
                    {
                        Element voidAuditHistoryEle = null;
                        voidAuditHistoryEle = (Element) nlvoidAuditHist.item(i);
                        KohlsDMAuditHistoryVoidInJson.BulkSkus bulkSku = voidInput.new BulkSkus();
                        bulkSku.setauditID(voidAuditHistoryEle.getAttribute(KohlsPOCConstant.AUDIT_ID).toLowerCase());
                        String skuid = voidAuditHistoryEle.getAttribute(KohlsPOCConstant.A_ITEM_ID);
                        if(!YFCCommon.isVoid(skuid) 
                                && NumberUtils.isNumber(skuid))
                        {
                            bulkSku.setsku(Long.parseLong(skuid));
                            //voidInput.setstoreNumber(Long.parseLong(storeNumber));
                        }
                        
                        bulkSkus.add(bulkSku);
                    }
                }
                overrideMaxRetries = false;       
                voidInput.setBulkSkus(bulkSkus);
                
                SimpleDateFormat auditDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            String auditDate = auditDateFormat.format(YFCDateUtils.getCurrentDate(true));
                voidInput.setauditDate(auditDate);
                voidInput.setdevice(KohlsPOCConstant.POC_DEVICE_CODE);
                if(!YFCCommon.isVoid(storeNumber) && NumberUtils.isNumber(storeNumber))
            {
                    voidInput.setstoreNumber(Long.parseLong(storeNumber));
            }
                
                
                jsonPayload = gson.toJson(voidInput).toString();
                
                if(logger.isDebugEnabled()) {
                    logger.debug("jsonPayload request-->"+jsonPayload);
                  }
                  
                  filePrefix = "AuditHistoryVoid_"+storeNumber+"-"+terminalNo+"-"+transactioNo+".txt";
                  try {
                      sFilePath = getPropertyValue(props.getProperty("LogDir"));
                      restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
                    } catch (Exception ex) {
                        bWriteToFile = false;
                        logger.error("Logger Dir does not exist. So moving on");
                    } 
                  overrideMaxRetries = false;         
             strEndPoint = props.getProperty(KohlsPOCConstant.DM_AHVOID_ENDPOINT);
             gotoCloud = true;
        }
        else if((KohlsPOCConstant.DM_REASON_CODE).equalsIgnoreCase(source))
        {
                httpMethod = KohlsPOCConstant.HTTP_METHOD_GET;
                filePrefix = "DamageReason_"+timestamp+".txt";
                sFilePath = getPropertyValue(props.getProperty("LogDir"));              
                logger.debug("dmGetDamageReasonCodes ::");
                strEndPoint = props.getProperty(KohlsPOCConstant.DM_ENDPOINT_DAMAGEREASON);
                gotoCloud = true;
                overrideMaxRetries = false;    
        }       
        else if((KohlsPOCConstant.DM_GET_UI_SLIP_TEXT).equalsIgnoreCase(source))
        {
                
                httpMethod = KohlsPOCConstant.HTTP_METHOD_GET;
                filePrefix = "UISlipText_"+timestamp+".txt";
                sFilePath = getPropertyValue(props.getProperty("LogDir"));  
                logger.debug("dmGetUISlipText ::");
                strEndPoint = props.getProperty(KohlsPOCConstant.DM_ENDPOINT_UISLIPTEXT);
            gotoCloud = true;
            overrideMaxRetries = false;    
        }
                       
        String sProxyRequired = "false";
        String stroAuthNeeded = "true";
        if(gotoCloud)
        {
            strDomain = YFSSystem.getProperty(KohlsPOCConstant.DM_DOMAIN_CLOUD_ENDPOINT);
            if(YFCCommon.isVoid(strDomain))
            {
            		strDomain = props.getProperty(KohlsPOCConstant.DM_DOMAIN);
            }
            sProxyRequired = YFSSystem.getProperty(KohlsPOCConstant.DM_DOMAIN_CLOUD_PROXY_REQUIRED);
            if(YFCCommon.isVoid(sProxyRequired))
            {
            		sProxyRequired = YFSSystem.getProperty(KohlsPOCConstant.DM_PROXY_REQUIRED);
            }
            bProxyRequired = Boolean.valueOf(sProxyRequired);
            activeEndpoint = "CORP";    
            if(overrideMaxRetries)
            {
            	 	String strMaxRetries =  props.getProperty(KohlsPOCConstant.DM_RETRY_THRESHOLD);
 	        		if(YFCCommon.isVoid(strMaxRetries))
 	        		{
 	        			maxRetries = 2;
 	        		}
 	        		else
 	        		{
 	        			maxRetries =Integer.parseInt(strMaxRetries); 
 	        		}
            }
        }
               
            try {
                if(YFCCommon.isVoid(strDomain)) {
                
                  strDomain = failoverUtil.getActiveEndPoint("DM_DOMAIN");
                  if(YFCCommon.isVoid(activeEndpoint)) 
                  {
                    activeEndpoint = failoverUtil.getCurrentActiveEndpoint(KohlsPOCConstant.DM_DOMAIN);
                  }
                  sProxyRequired = YFSSystem.getProperty("DM_DOMAIN."+activeEndpoint+".PROXY_REQUIRED");
                  bProxyRequired = Boolean.valueOf(sProxyRequired);
                  stroAuthNeeded = YFSSystem.getProperty("DM_DOMAIN."+activeEndpoint+".OAUTHNEEDED");
                  boAuthNeeded = Boolean.valueOf(stroAuthNeeded);
                } 
              } 
            catch (Exception e) {        
                  if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
                	  	  logger.error("Client DM: Primary and backup down. Sending back offline response. current failover props value: "+failoverUtil.getWsProperties());
                	  	  if(bWriteToFile)
                      {
                        try {
                          restApiutil.writeToFile("DM Service is OFFLINE","",filePrefix,sFilePath);
                        } catch (Exception ex) {
                        	 logger.error("Logger Dir does not exist. So moving on");
                        }
                      }
                    output = getOfflineResponseForDM(source, input, output);
                    //logger.error("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+failoverUtil.getWsProperties());
                    try {
                        restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
                       		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
                      } catch (Exception ex) {
                          bWriteToFile = false;
                            logger.error("Logger Dir does not exist. So moving on");
                      }
                    return output;
                  }
                  else {
                    throw new YFSException("DM System offline"); 
                  }        
         }
           
        strReadTimeOut = YFSSystem.getProperty(KohlsPOCConstant.DM_API_READTIMEOUT);
        strConnectTimeOut = YFSSystem.getProperty(KohlsPOCConstant.DM_API_CONNTIMEOUT);
              
        String strtempDomain = strDomain + strEndPoint;
        
        ResponseEntity<String> response = null;
        
      //logger.info("Proxy required for "+strDomain+" is: "+sProxyRequired);
        if(bProxyRequired) {
           strProxyHost = YFSSystem.getProperty(KohlsPOCConstant.DM_PROXY_HOST);
           if(YFCCommon.isVoid(strProxyHost)) {
             throw new YFSException ("Proxy is Required but no Proxy host is set");
           }
           //logger.info("Proxy Host is: "+strProxyHost);
           String strProxyPort = YFSSystem.getProperty(KohlsPOCConstant.DM_PROXY_PORT);
           if(YFCCommon.isVoid(strProxyPort)) {
             throw new YFSException ("Proxy is Required but no Proxy Port is set");
           }
           //logger.info("Proxy Port is: "+strProxyPort);
           try {
             iProxyport = Integer.valueOf(strProxyPort);               
           } catch (Exception e) {
             logger.error("Incorrect Proxy port set: "+e.getMessage());
             throw new YFSException ("Incorrect Proxy port set");
           }
        }
        
          try {
        	  count++;
            TreeMap<String, String> mapHeader = new TreeMap<String, String>();               
            mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");
            SimpleDateFormat dateFormatGmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            dateFormatGmt.setTimeZone(TimeZone.getTimeZone("GMT"));
            final TreeMap<String, String> depHeaderMap = new TreeMap<String, String>();
            depHeaderMap.put("X-KOHLS-CreateDateTime", dateFormatGmt.format(new Date()));
            depHeaderMap.put("X-KOHLS-From-SystemCode", KohlsPOCConstant.POC_DEVICE_CODE);
            depHeaderMap.put("X-KOHLS-MessageID", restApiutil.getUUID());
            depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
            
            if((!ServerTypeHelper.amIOnTrainingServer() && boAuthNeeded) 
                || !YFCCommon.isVoid(accessToken))
            {
                    depHeaderMap.put("Authorization",
                        getAuthorizationHeaderForAccessToken(env,source,storeNumber,terminalNo,accessToken));
            }
            response = restApiutil.createConnection(jsonPayload,
                mapHeader, depHeaderMap, null, strtempDomain,
                strEndPoint, null,
                null,strReadTimeOut,strConnectTimeOut, null, httpMethod, bProxyRequired, strProxyHost, iProxyport);
            
            if(failoverUtil.isEndpointMonitored(KohlsPOCConstant.DM_DOMAIN) && !gotoCloud) {
              failoverUtil.resetFailedCounter(KohlsPOCConstant.DM_DOMAIN, activeEndpoint);
              logger.debug("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+failoverUtil.getWsProperties());
              try {
                  restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
                 		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
                } catch (Exception ex) {
                    bWriteToFile = false;
                      logger.error("Logger Dir does not exist. So moving on");
                }
            }
            JSONObject json = null;
            if(response!=null) {

              if(response.getStatusCode().toString().equals(KohlsPOCConstant.HTTP_200))
              {
                String responseBody = response.getBody(); 

                json = new JSONObject(responseBody);
                if(!YFCCommon.isVoid(json) && !YFCCommon.isVoid(json.toString()))
                {    
                	 	if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
                	 		logger.info("Disposition Manager: Response received from "+activeEndpoint+" endpoint for "+storeNumber+"/"+terminalNo+"/"+transactioNo);
                	 	}
                    if(bWriteToFile)
                    {
                      try {
                        restApiutil.writeToFile("Response from "+activeEndpoint+" endpoint is ----> \n",json.toString(),filePrefix,sFilePath);
                      } catch (Exception ex) {
                    	  		logger.error("Logger Dir does not exist. So moving on");
                      }
                    }
                    if(KohlsPOCConstant.DM_GET_DISPOSITION.equalsIgnoreCase(source)) {
                      output = processDispoManageRespo(json.toString()); 
                    }
                    else if(KohlsPOCConstant.DM_REASON_CODE.equalsIgnoreCase(source)) {
                      output = processDamageReasonResp(env ,json.toString()); 
                      if(!YFCCommon.isVoid(output) && output.hasChildNodes())
                      {
                    	  dmUtil = new KohlsPoCDMUtil();
                     Document docDamageReasonCodeList= dmUtil.getDamageReasonCodeList( env);
                      Document docOutDamageResonCode=dmUtil.toCheckUpdateOrCreate(output, docDamageReasonCodeList, source, sStandAlone, env);
                      Document docOutConsoliadteReason =dmUtil.toDeleteRecordsFromTable(docOutDamageResonCode, docDamageReasonCodeList, source,sStandAlone,env);
                    		  output=docOutConsoliadteReason;
                      }
                    }
                    else if(KohlsPOCConstant.DM_GET_UI_SLIP_TEXT.equalsIgnoreCase(source)) {
                      output = processDMRespForSlipText(env ,json.toString()); 
                      dmUtil = new KohlsPoCDMUtil();
                      if(!YFCCommon.isVoid(output) && output.hasChildNodes())
                      {
                  	Document docDispoitionSlipTextList= dmUtil.getDispositionSlipTxt( env);
                  	  Document docOutDispositionSlipTxt=dmUtil.toCheckUpdateOrCreate(output, docDispoitionSlipTextList, source, sStandAlone, env);
                        Document docOutConsoliadteReason =dmUtil.toDeleteRecordsFromTable(docOutDispositionSlipTxt, docDispoitionSlipTextList, source,sStandAlone,env);
                      output=docOutConsoliadteReason;
                      }

                    }
                    
                }
              }              

            } 

          } catch (Exception e) {
                                      
              String errorCode = "";
              if(e instanceof YFSException) {
                errorCode = ((YFSException) e).getErrorCode();
              }
              if("401".equalsIgnoreCase(errorCode))
              {            	  
            	    logger.error("No Token in the request. probably a failover scenario");
                Document docAccessToken = XMLUtil.createDocument("KohlsoAuthAccessToken");
                Element eleDocAccessTokenRoot = docAccessToken.getDocumentElement();
                eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_MODULE, source);
                eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TOKEN_NAME, KohlsPOCConstant.O_AUTH_ACCESS_TOKEN);
                eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, storeNumber);
                eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, terminalNo);
                //Invoke Service To Get Damage Reason Codes
                Document docAccessTokenList=KOHLSBaseApi.invokeService(env,KohlsPOCConstant.KOHLS_GET_O_AUTH_TOKEN_LIST, docAccessToken);
                String action =KohlsPOCConstant.A_CREATE;
                if(docAccessTokenList.getDocumentElement().hasChildNodes())
                { 
                    Element oAuthTokenEle = XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(), KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
                    String expiryDate = oAuthTokenEle.getAttribute("ExpiryDate");
                    String currentDate = getCurrSysDateAsString();
                    SimpleDateFormat sdf1 = new SimpleDateFormat(
                            KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
                    if(!isAfter(sdf1.format(sdf1.parse(expiryDate)),currentDate))
                    {
                        Element oAuthAccessToken =  XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(),KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
                        String oAuthAccessTokenKey=
                            oAuthAccessToken.getAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY);
                        docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY, 
                            oAuthAccessTokenKey);
                        try
                        {                      
                        		accessToken = fetchAndUpdateAccessToken(env,docAccessToken, null);
                        }
                        catch (Exception ee)
                        { 
                        	 	logger.error("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
                        	 	 try {
                                     restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
                                    		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
                                   } catch (Exception ex) {
                                       bWriteToFile = false;
                                         logger.error("Logger Dir does not exist. So moving on");
                                   }
                        	 	if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
                                return getOfflineResponseForDM(source, input, output);
                               }
                               else {
                                   throw new YFSException(e.getMessage());
                               }
                        }
                    }
                    else
                    {
                        accessToken = oAuthTokenEle.getAttribute(KohlsPOCConstant.TOKEN_VALUE);
                        try {
                            restApiutil.writeToFile("Token exists ----> \n",accessToken,filePrefix,sFilePath);
                          } catch (Exception ex) {
                              bWriteToFile = false;
                                logger.error("Logger Dir does not exist. So moving on");
                          }
                    }
                }
                else
                {
                		try
                    {                      
                    		accessToken = fetchAndUpdateAccessToken(env,docAccessToken, action);
                    }
                    catch (Exception ee)
                    {   
                    	 	logger.error("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
                    	 	 try {
                                 restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
                                		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
                               } catch (Exception ex) {
                                   bWriteToFile = false;
                                     logger.error("Logger Dir does not exist. So moving on");
                               }
                    	 	if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
                            return getOfflineResponseForDM(source, input, output);
                           }
                           else {
                               throw new YFSException(e.getMessage());
                           }
                    }
                }                             
                output = callDMAPI(env, input);                  
              }
              else
	          {           	  	
	            	      Throwable tmp = e;
	                  boolean bNeedToRetry = false;
	                 
	                      if ( !errorFromoAuth && tmp.getCause() instanceof java.io.IOException
	                            || tmp.getCause() instanceof java.net.SocketTimeoutException
	                            || tmp.getCause() instanceof java.net.ConnectException
	                            || tmp.getCause() instanceof java.net.NoRouteToHostException 
	                            || tmp.getCause() instanceof java.net.UnknownHostException
	                            || tmp.getCause() instanceof java.lang.IllegalArgumentException
	                            || "503".equalsIgnoreCase(errorCode)
	                            || "500".equalsIgnoreCase(errorCode)
	                            || "404".equalsIgnoreCase(errorCode)
	                            || "CONNECTERROR".equalsIgnoreCase(errorCode)) {
	                    	  	  logger.error("Exception occured while calling DM API: "+e.toString());
	                          try {
	                              restApiutil.writeToFile("Error while calling "+activeEndpoint+" endpoint and the error is ----> \n",e.toString(),filePrefix,sFilePath);
	                            } catch (Exception ex) {
	                                bWriteToFile = false;
	                                logger.error("Logger Dir does not exist. So moving on");
	                            }
	                          // Failover framework
	                          if(failoverUtil.isEndpointMonitored("DM_DOMAIN") && !gotoCloud) {
	                            failoverUtil.compareAndIncrementCounters("DM_DOMAIN", activeEndpoint);
	                            if ("PRIMARY".equalsIgnoreCase(activeEndpoint)) {
	                            		 logger.info("Client DM: Primary down. reaching out to backup. current failover props value: "+failoverUtil.getWsProperties());
	                                 //logger.error("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+failoverUtil.getWsProperties());
	                                 try {
	                                     restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
	                                    		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
	                                   } catch (Exception ex) {
	                                       bWriteToFile = false;
	                                         logger.error("Logger Dir does not exist. So moving on");
	                                   }
	                              strDomain = failoverUtil.getBackupEndpoint("DM_DOMAIN");                         
	                              if(!YFCCommon.isVoid(strDomain)) {
	                                activeEndpoint = "BACKUP";
	                                sProxyRequired = YFSSystem.getProperty("DM_DOMAIN."+activeEndpoint+".PROXY_REQUIRED");
	                                bProxyRequired = Boolean.valueOf(sProxyRequired);
	                                stroAuthNeeded = YFSSystem.getProperty("DM_DOMAIN."+activeEndpoint+".OAUTHNEEDED");
	                                boAuthNeeded = Boolean.valueOf(stroAuthNeeded);
	                                output = callDMAPI(env, input);
	                              } else {
	                                  if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
	                                  output = getOfflineResponseForDM(source, input, output);
	                                 
	                              }
	                              else {
	                                    throw new YFSException(e.getMessage());
	                              }
	                                
	                              }
	                              
	                              
	                            } else {
	                                logger.error("KohlsCallDMAPIWrapper.callDMAPII failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
	                                try {
	                                     restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
	                                    		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
	                                   } catch (Exception ex) {
	                                       bWriteToFile = false;
	                                         logger.error("Logger Dir does not exist. So moving on");
	                                   }
	                                if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
	                                    output = getOfflineResponseForDM(source, input, output);
	                                   
	                                  }
	                                  else {
	                                      throw new YFSException(e.getMessage());
	                                  }
	                              
	                            }
	                          } else {	                        	  			                        	  		
	                              logger.error("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
	                              try {
	                                  restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
	                                 		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
	                                } catch (Exception ex) {
	                                    bWriteToFile = false;
	                                      logger.error("Logger Dir does not exist. So moving on");
	                                }
	                              if (count != maxRetries) {
	                                  bNeedToRetry = true;
	                                  
	                                }
	                              else
	                              {
	                            	  	if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
		                                    output = getOfflineResponseForDM(source, input, output);
		                                    
		                                  }
		                                  else {
		                                      throw new YFSException(e.getMessage());
		                                  }
	                              }	                                
	                          }
	                          
	                        } else {	                        		
	                            logger.error("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint+failoverUtil.getWsProperties());
	                            try {
	                                 restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n"+activeEndpoint,
	                                		 failoverUtil.getWsProperties().toString(),filePrefix,sFilePath);
	                               } catch (Exception ex) {
	                                   bWriteToFile = false;
	                                     logger.error("Logger Dir does not exist. So moving on");
	                               }
	                            if((KohlsPOCConstant.DM_GET_DISPOSITION).equalsIgnoreCase(source)){
	                                output = getOfflineResponseForDM(source, input, output);
	                              }
	                              else {
	                                  throw new YFSException(e.getMessage());
	                              }
	                        }
	                      
	                  if (bNeedToRetry) {
	                      logger.error("********** Retrying the DM Request again *********");
	                      output = callDMAPI(env, input);
	                    }
	              }
             
            // logger.debug("The Error message from webservice is Generic. So throwing YFSException");

            // Fix for defect 1380 - End
          } 
          finally {   
        	  	  if(failoverUtil.isEndpointMonitored("DM_DOMAIN") && !gotoCloud)
        	  	  {
        	  		  	//String cffFilePath = "/home/sterling/sterling93/logs/CFF";
        	            String cffFilePath = "/logs/apps/of/CFF"; 
        	    	    		//SimpleDateFormat sdf1 = new SimpleDateFormat("ddHHmmss");
        	    	    		//String timestamp1 = sdf1.format(YFCDateUtils.getCurrentDate(true));
	  	    		  logger.debug("wsProperties at the end::"+failoverUtil.getWsProperties());	  	    		 
	  	    		  restApiutil.writeToFile("\n\n\nCurrent DM Failover Props--->\n",
	      		  failoverUtil.getWsProperties().toString(),"CFF_DM_"+timestamp,cffFilePath);     
        	  	  }
            }
        // Fix for defect 1380 - End
       
        logger.endTimer("KohlsCallDMAPIWrapper.callDMAPI");
        return output;
    }
    
  	public static String getCurrSysDateAsString() {
		logger.beginTimer("KohlsCallDMAPIWrapper.getCurrSysDateAsString");
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		YFCDate yfcCurrntDt = YFCDateUtils.getCurrentDate(true);
		String str = sdf.format(yfcCurrntDt);
		logger.endTimer("KohlsCallDMAPIWrapper.getCurrSysDateAsString");
		return str;
	}
    
    /**
	 * Compares 2 dates
	 * 
	 * @returns the flaf
	 */
	public static boolean isAfter(String strDate1, String strDate2) {
		logger.beginTimer("KohlsReprocessRequestUtil.isAfter");
		boolean isBefore = false;
		SimpleDateFormat sdf = new SimpleDateFormat(
				KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
		Date date1;
		Date date2;
		try {
			date1 = sdf.parse(strDate1);
			date2 = sdf.parse(strDate2);
			if (date1.after(date2)) {
				isBefore = true;
			}
		} catch (Exception e) {
			//e.printStackTrace();
			logger.debug("Inside isAfter - Error while parsing the dates " +e.getMessage());
		}
		logger.endTimer("KohlsReprocessRequestUtil.isAfter");
		return isBefore;
	}
    
    private Document processDispoManageRespo(String sToParse) throws Exception {
        // TODO Auto-generated method stub
        logger.beginTimer("KohlsCallDMAPIWrapper.processDispoManageRespo");
        Gson outGson = new Gson();
        KohlsDMDispoManJson parsedClass = outGson.fromJson(sToParse, KohlsDMDispoManJson.class); // input
        Document    docPreCartResp=XMLUtil.createDocument("GetDispositionResp"); 
        Element eledocPreCartResp = docPreCartResp.getDocumentElement();
        if(!YFCCommon.isVoid(parsedClass.getSku()))
            {
                eledocPreCartResp.setAttribute(KohlsPOCConstant.ATTR_ITEMID,String.valueOf(parsedClass.getSku()));
            }
        
        if(!YFCCommon.isVoid(parsedClass.getDisposition()))
        {
             eledocPreCartResp.setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, String.valueOf(parsedClass.getDisposition()));
        }
        
        if(!YFCCommon.isVoid(parsedClass.getDispositionText()))
        {
             eledocPreCartResp.setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_TEXT, String.valueOf(parsedClass.getDispositionText()));
        }
      
        
       String hazmatHandlineInstruction = parsedClass.gethazmatHandlingInstruction();
       if(!YFCCommon.isVoid(hazmatHandlineInstruction)) 
        {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.ATTR_HAZ_MAT_STR1, hazmatHandlineInstruction);
        }
       
       if(!YFCCommon.isVoid(parsedClass.gethazMatFlag()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.HAZ_MATERIAL_FLAG, BooleanUtils.toString(parsedClass.gethazMatFlag(), KohlsPOCConstant.YES,KohlsPOCConstant.NO));
       }
       if(!YFCCommon.isVoid(parsedClass.getMarkdownPercentage()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.MARK_DOWN_PERCENTAGE, String.valueOf(parsedClass.getMarkdownPercentage()));
       }
       if(!YFCCommon.isVoid(parsedClass.getcallbackID()) && parsedClass.getcallbackID() != 0)
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.CALL_BACK_ID, String.valueOf(parsedClass.getcallbackID()));
       }
       if(!YFCCommon.isVoid(parsedClass.gethazMatClass()))
       {
           eledocPreCartResp.setAttribute(KohlsPOCConstant.HAZ_MATERIAL_CLASS, parsedClass.gethazMatClass());
       }
       if(!YFCCommon.isVoid(parsedClass.gethazMatSubClass()))
       {
           eledocPreCartResp.setAttribute(KohlsPOCConstant.HAZ_MATERIAL_SUB_CLASS, parsedClass.gethazMatSubClass());
       }
       if(!YFCCommon.isVoid(parsedClass.getWebExclusiveFlag()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_FLAG, BooleanUtils.toString(parsedClass.getWebExclusiveFlag(), KohlsPOCConstant.YES,KohlsPOCConstant.NO));
       }
       if(!YFCCommon.isVoid(parsedClass.getWebExDispoCode()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_DISP_CODE, String.valueOf(parsedClass.getWebExDispoCode()));
       }
       if(!YFCCommon.isVoid(parsedClass.getwebExclusiveDispDesc()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_DISP_DESC,parsedClass.getwebExclusiveDispDesc());
       }
       if(!YFCCommon.isVoid(parsedClass.getVendorReturnDispCode()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.VENDOR_RETURN_DISPOSITION_CODE,parsedClass.getVendorReturnDispCode());
       }
       if(!YFCCommon.isVoid(parsedClass.getdamageReasonDesc()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.DAMAGE_REASON_DESC,parsedClass.getdamageReasonDesc());
       }
       if(!YFCCommon.isVoid(parsedClass.getauditID()))
       {
            eledocPreCartResp.setAttribute(KohlsPOCConstant.AUDIT_ID,parsedClass.getauditID());
       }
       return docPreCartResp;
    }

    public String getAuthorizationHeaderForAccessToken(YFSEnvironment env, String source, String storeNumber, String terminalNo, String accessToken) throws Exception {
        
    if(!YFCCommon.isVoid(accessToken))
    {
            return "Bearer" + " " + accessToken;
    }
    Document docAccessToken = XMLUtil.createDocument(KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
    Element eleDocAccessTokenRoot = docAccessToken.getDocumentElement();
    if(KohlsPOCConstant.SOURCE_VOIDDMAH.equals(source))
    {
        eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_MODULE, KohlsPOCConstant.DM_GET_DISPOSITION);
    }
    else
    {
        eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_MODULE, source);
    }
    
    eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TOKEN_NAME, KohlsPOCConstant.O_AUTH_ACCESS_TOKEN);
    if(!YFCCommon.isVoid(storeNumber))
    {
        eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_ORGABIZATION_CODE, storeNumber);
    }
    if(!YFCCommon.isVoid(terminalNo))
    {
        eleDocAccessTokenRoot.setAttribute(KohlsPOCConstant.ATTR_TERMINAL_ID, terminalNo);
    }
    //Invoke Service To Get Damage Reason Codes
    Document docAccessTokenList=KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_GET_O_AUTH_TOKEN_LIST, docAccessToken);
    String currentDate = getCurrSysDateAsString();
    SimpleDateFormat sdf = new SimpleDateFormat(
            KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
    if(!docAccessTokenList.getDocumentElement().hasChildNodes())
    {
        accessToken = fetchAndUpdateAccessToken(env,docAccessToken,KohlsPOCConstant.A_CREATE);
    }
    else
    {
        Element oAuthTokenEle = XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(), KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
        String expiryDate = oAuthTokenEle.getAttribute("ExpiryDate");
        if(!isAfter(sdf.format(sdf.parse(expiryDate)),currentDate))
        {
            Element oAuthAccessToken =  XMLUtil.getChildElement(docAccessTokenList.getDocumentElement(),KohlsPOCConstant.KOHLS_O_AUTH_ACCESS_TOKEN);
                String oAuthAccessTokenKey=
                        oAuthAccessToken.getAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY);
                docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.O_AUTH_ACCESS_TOKEN_KEY, 
                        oAuthAccessTokenKey);
            accessToken = fetchAndUpdateAccessToken(env,docAccessToken, null);
        }
        else
        {       	 	
            accessToken = oAuthTokenEle.getAttribute(KohlsPOCConstant.TOKEN_VALUE);
            try {
                restApiutil.writeToFile("Token exists ----> \n",accessToken,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                  logger.error("Logger Dir does not exist. So moving on");
              }
        }       
        
    }
    
    logger.debug("strTokenValue"+accessToken);
    logger.endTimer("KohlsCallDMAPIWrapper.processDispoManageRespo");
    return "Bearer" + " " + accessToken;
    }
    
    private void createAccessToken(YFSEnvironment env, Document docAccessToken) throws Exception 
    {
        
            KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_CREATE_O_AUTH_TOKEN, docAccessToken);
        
    }
    
    private void updateAccessToken(YFSEnvironment env, Document docAccessToken) throws Exception 
    {
        
            KOHLSBaseApi.invokeService(env, KohlsPOCConstant.KOHLS_MODIFY_O_AUTH_TOKEN, docAccessToken);
        
        // TODO Auto-generated method stub
        
    }
  
    private String fetchAndUpdateAccessToken(YFSEnvironment env, Document docAccessToken, String action) throws Exception 
    {
            logger.beginTimer("KohlsCallDMAPIWrapper.fetchAndUpdateAccessToken");
            Map accessToken = fetchAccessToken();
            String strAccessToken = (String)accessToken.get(KohlsPOCConstant.ACCESS_TOKEN);
            try {
                restApiutil.writeToFile("New Token fetched ----> \n",strAccessToken,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                  logger.error("Logger Dir does not exist. So moving on");
              }
            String expires_in = (String)accessToken.get(KohlsPOCConstant.EXPIRY_IN);
            docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.TOKEN_VALUE, strAccessToken);
            String currentDate = getCurrSysDateAsString();
            SimpleDateFormat sdf = new SimpleDateFormat(
                    KohlsPOCConstant.DATEFORMAT_yyyy_MM_dd_HH_mm_ss);
            Date expiryDate = KohlsDateUtil.addToDate(sdf.parse(currentDate), Calendar.SECOND,Integer.valueOf(expires_in));
            docAccessToken.getDocumentElement().setAttribute(KohlsPOCConstant.EXPIRY_DATE, sdf.format(expiryDate));
            if(KohlsPOCConstant.A_CREATE.equalsIgnoreCase(action))
            {
                createAccessToken(env,docAccessToken);
            }
            else
            {
                updateAccessToken(env,docAccessToken);
            }
            
        logger.endTimer("KohlsCallDMAPIWrapper.fetchAndUpdateAccessToken");
        return strAccessToken;
    }
    int ouAthCount=0;
    private boolean errorFromoAuth = false;
    private Map fetchAccessToken() throws Exception 
    {
        logger.beginTimer("KohlsCallDMAPIWrapper.fetchAccessToken");
        String strEndPoint = props.getProperty(KohlsPOCConstant.DM_ENDPOINT_OAUTH);
        String clientID = props.getProperty(KohlsPOCConstant.DM_APIKEY_OAUTH);
        String enCryptedSecret = props.getProperty(KohlsPOCConstant.DM_APISECRET_OAUTH);
        String grantType = KohlsPOCConstant.GRANT_TYPE_CLIENT_CREDENTIALS;
        String Scope = KohlsPOCConstant.SCOPE_VALUE;
        String oAuthURL = strDomain + strEndPoint;
        try
        {
        		ouAthCount++;
        		Map accessTokenMap  = restApiutil.getNewAccessToken(oAuthURL, clientID, enCryptedSecret, Scope, grantType,
        		strReadTimeOut,strConnectTimeOut,bProxyRequired,strProxyHost,iProxyport,"DM");
            logger.endTimer("KohlsCallDMAPIWrapper.fetchAccessToken");
            return accessTokenMap;
        }
        catch(Exception ee)
        {
        	 	try {
                 restApiutil.writeToFile("Error while calling oAuth and the error is ----> \n",ee.toString(),filePrefix,sFilePath);
               } catch (Exception ex) {
                   bWriteToFile = false;
                   logger.error("Logger Dir does not exist. So moving on");
               }
    			errorFromoAuth = true;
	        	if( ee instanceof java.io.IOException ||
	        			ee instanceof org.apache.http.conn.ConnectTimeoutException
	                    || ee instanceof java.net.SocketTimeoutException)
			{
	        		logger.error("Exception while connecting to DM using "+activeEndpoint+" to fetch access Token and the error is "+ee.toString());
	        		              
	        		if(ouAthCount != maxRetries)
                 {
                 		
                 		Map accessTokenMap  = fetchAccessToken();
                 		return accessTokenMap;
                 }
	        		else
	        		{
	        			if(failoverUtil.isEndpointMonitored("DM_DOMAIN") && !gotoCloud) {
	                          failoverUtil.compareAndIncrementCounters("DM_DOMAIN", activeEndpoint);
		        		}
	        			throw ee;
	        		}	        		
			}
                      
           throw ee;
	        	
        }

    }

    Document processDamageReasonResp(YFSEnvironment env ,String sToParse) throws Exception {
        Gson outGson = new Gson();       
        KohlsDMReasonCodeOutJson parsedClass = outGson.fromJson(sToParse, KohlsDMReasonCodeOutJson.class); // input
        Document docDamageReasonCode = getNewDMDamageReasonCodesList(env, parsedClass);
       /* if(!YFCCommon.isVoid(docDamageReasonCode) && docDamageReasonCode.hasChildNodes())
        {
            
            deleteExistingDamageReasonCodes(env);
        }*/
        return docDamageReasonCode;
    }

    
     private static Document getNewDMDamageReasonCodesList(YFSEnvironment env, KohlsDMReasonCodeOutJson responseDMReasonCode)
            throws DOMException, Exception {
         logger.beginTimer("KohlsCallDMAPIWrapper.getNewDMDamageReasonCodesList");
        Element eleDamagedReasonCodes=null;

        Element eleDamageCodeDescList=null;
        Element eleDamageCodeDesc=null;
        Document docListDamagedReasonCodes = XMLUtil.createDocument(KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES_LIST);
        Element eleListDamagedReasonCodes = docListDamagedReasonCodes.getDocumentElement();
        for (KohlsDMReasonCodeOutJson.DamagedReasonCode dmgReasonCode : responseDMReasonCode.getDamagedReasonCodes()) {
            
            eleDamagedReasonCodes=XMLUtil.createChild(eleListDamagedReasonCodes, KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES);

            eleDamagedReasonCodes.setAttribute(KohlsPOCConstant.ATTR_BUSINESS_GROUP_NO, dmgReasonCode.getBusinessGroupNumber());
                
            //Loop through the DamageCode
            eleDamageCodeDescList = XMLUtil.createChild(eleDamagedReasonCodes, KohlsPOCConstant.ELEM_KOHLS_DAMAGED_CODE_DESCIPTION_LIST);
                    for (KohlsDMReasonCodeOutJson.DamageCode dmgCode : dmgReasonCode.getDamageCodes()) {
                        if (dmgReasonCode.getDamageCodes().size() > 0) {

                        //Need to mention the below string names in constants file.

                            eleDamageCodeDesc = XMLUtil.createChild(eleDamageCodeDescList,KohlsPOCConstant.ELEM_KOHLS_DAMAGED_CODE_DESCIPTION);
                            eleDamageCodeDesc.setAttribute(KohlsPOCConstant.ATTR_CODE_NAME, dmgCode.getCode());
                            eleDamageCodeDesc.setAttribute(KohlsPOCConstant.ATTR_CODE_DESC, dmgCode.getDescription());
                            if(dmgCode.getResellable().equalsIgnoreCase(KohlsPOCConstant.TRUE)){
                                eleDamageCodeDesc.setAttribute(KohlsPOCConstant.ATTR_RESELLABLE, KohlsPOCConstant.YES);
                            }else{
                                eleDamageCodeDesc.setAttribute(KohlsPOCConstant.ATTR_RESELLABLE, KohlsPOCConstant.NO);
                            }
                            
                            if(dmgCode.getContaminated().equalsIgnoreCase(KohlsPOCConstant.TRUE)){
                                eleDamageCodeDesc.setAttribute(KohlsPOCConstant.ATTR_CONTAMINATED, KohlsPOCConstant.YES);
                            }
                            else{
                                eleDamageCodeDesc.setAttribute(KohlsPOCConstant.ATTR_CONTAMINATED, KohlsPOCConstant.NO);
                            }

                    }
                    }
                    if(dmgReasonCode.getDepartments().size()>0) {
                         List lstDepts=new ArrayList();

                        //Looping Departments
                        for(int iDept=0;iDept<dmgReasonCode.getDepartments().size(); iDept++){
                             lstDepts.add(dmgReasonCode.getDepartments().get(iDept));
                             String str = lstDepts.toString();
                             str = str.replaceAll("\\[", ",").replaceAll("\\]",",").replaceAll("\\s","");;
                             eleDamagedReasonCodes.setAttribute(KohlsPOCConstant.ATTR_DEPT_CAPS,str);
                        }

                    }
            
                        
        }
         logger.endTimer("KohlsCallDMAPIWrapper.getNewDMDamageReasonCodesList");
         return docListDamagedReasonCodes;
    }
    

     Document processDMRespForSlipText (YFSEnvironment env ,String sToParse) throws Exception {
        
        
         logger.beginTimer("KohlsCallDMAPIWrapper.processDMRespForSlipText");
        
         Gson outGson = new Gson(); 
        KohlsDMSlipTextOutJson parsedClass = outGson.fromJson(sToParse, KohlsDMSlipTextOutJson.class); // input

        Document docSlipTextData = getNewDMSlipTextData(env,parsedClass);
        
      /*  if(!YFCCommon.isVoid(docSlipTextData) && docSlipTextData.hasChildNodes())
        {
            deleteExistingSlipData(env);
        }*/
         logger.endTimer("KohlsCallDMAPIWrapper.processDMRespForSlipText"); 
         return docSlipTextData;
        
        
     }
     
     
    public void deleteExistingSlipData(YFSEnvironment env) throws Exception 
    {
        logger.beginTimer("KohlsCallDMAPIWrapper.deleteExistingSlipData");
            Document docGetDMSlipText = null;
        Element eleDMSlipTextList= null;
        Element eleSlipText =null;
        Document docDMSlipText= null;       
        
        docDMSlipText = XMLUtil.createDocument(KohlsPOCConstant.ELEM_DM_SLIP_TEXT);



        //Invoke Service To Get Damage Slip Text
        docGetDMSlipText=KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SERVICE_KOHLS_GET_DM_SLIP_TEXT, docDMSlipText);
        eleDMSlipTextList=docGetDMSlipText.getDocumentElement();

        if(!YFCCommon.isVoid(eleDMSlipTextList)){
            NodeList nlGetDMSLipText = docGetDMSlipText.getElementsByTagName(KohlsPOCConstant.ELEM_DM_SLIP_TEXT);//KohlsXMLLiterals.E_EXTN

            if(nlGetDMSLipText.getLength()>0){
                for (int i = 0; i < nlGetDMSLipText.getLength(); i++) {
                    eleSlipText = (Element) nlGetDMSLipText.item(i);

                    //Invoke Service To Delete Damage Reason Codes
                    KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SERVICE_KOHLS_DELETE_SLIP_TEXT, XMLUtil.getDocumentForElement(eleSlipText));

                }
            }
        
        }
        logger.endTimer("KohlsCallDMAPIWrapper.deleteExistingSlipData");
        
    }
    
    public void deleteExistingDamageReasonCodes(YFSEnvironment env) throws Exception 
    {
        logger.beginTimer("KohlsCallDMAPIWrapper.deleteExistingDamageReasonCodes");     
        Document docDamagedReasonCodes= null;
            Document docGetDamagedReasonCodes = null;
            Element eleGetDamagedReasonCodes= null;
            Element eleGetDamagedReasonCode =null;      
        
        docDamagedReasonCodes = XMLUtil.createDocument(KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES);

        
            
            docGetDamagedReasonCodes=KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SERVICE_KOHLS_GET_DAMAGE_REASON_CODE_LIST, docDamagedReasonCodes);
            eleGetDamagedReasonCodes=docGetDamagedReasonCodes.getDocumentElement();

            if(!YFCCommon.isVoid(eleGetDamagedReasonCodes)){
                NodeList nlGetDamagedReasonCode = docGetDamagedReasonCodes.getElementsByTagName(KohlsPOCConstant.ELEM_KOHLS_DAMAGED_REASON_CODES);//KohlsXMLLiterals.E_EXTN

                if(nlGetDamagedReasonCode.getLength()>0){
                    for (int i = 0; i < nlGetDamagedReasonCode.getLength(); i++) {
                        eleGetDamagedReasonCode = (Element) nlGetDamagedReasonCode.item(i);

                        //Invoke Service To Delete Damage Reason Codes
                        KOHLSBaseApi.invokeService(env, KohlsPOCConstant.SERVICE_KOHLS_DELETE_DAMAGE_REASON_CODES, XMLUtil.getDocumentForElement(eleGetDamagedReasonCode));

                    }
                }

            
            }
            logger.endTimer("KohlsCallDMAPIWrapper.deleteExistingDamageReasonCodes");
        
    }

    private  Document getNewDMSlipTextData(YFSEnvironment env,KohlsDMSlipTextOutJson respSlipText)
            throws DOMException, Exception {
        logger.beginTimer("KohlsCallDMAPIWrapper.getNewDMSlipTextData");
        Element eleKohlsDispositionSlipText=null;
        
        Document docListSlipText = XMLUtil.createDocument(KohlsPOCConstant.ELEM_DM_SLIP_TEXT_LIST);
        Element eleListSlipText = docListSlipText.getDocumentElement();

        for (KohlsDMSlipTextOutJson.DispositionUISlipText dispUISlipText : respSlipText.getDispositionUISlipTexts()) {
            
            eleKohlsDispositionSlipText=XMLUtil.createChild(eleListSlipText, KohlsPOCConstant.ELEM_DM_SLIP_TEXT);

            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, dispUISlipText.getDispositionCode());
            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_BAR_CODE_TYPE, dispUISlipText.getBarcodeType());
            
            if(dispUISlipText.getCodes().size()>0) {
                 List lstCodes=new ArrayList();

                //Looping Codes
                for(int iCodes=0;iCodes<dispUISlipText.getCodes().size(); iCodes++){
                    lstCodes.add(dispUISlipText.getCodes().get(iCodes));
                     String strCodes = lstCodes.toString();
                     strCodes = strCodes.replaceAll("\\[", "").replaceAll("\\]","");
                     eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_CODES,strCodes);
                }

            }
            //looping slip texts
            Map<String, Object> hh = dispUISlipText.getSlipText();
            String slip2 = (String)hh.get("slip2");
            slip2 = slip2.replaceAll("\n", Matcher.quoteReplacement("\\n"));
            
            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_POCUITEXT, (String) hh.get("pocUI"));
            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_SLIP1, (String)hh.get("slip1"));
            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_SLIP2, slip2);
            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_SLIP3, (String)hh.get("slip3"));
            eleKohlsDispositionSlipText.setAttribute(KohlsPOCConstant.ATTR_SLIP4, (String)hh.get("slip4"));

            
        }       
        
        logger.endTimer("KohlsCallDMAPIWrapper.getNewDMSlipTextData");
         return docListSlipText;
    }
     
    
    /**
     * Create By ibmadmin * 
     * @param property
     * @return
     */
    public String getPropertyValue(String property) {
        logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        if (YFCCommon.isVoid(propValue)) {
          propValue = property;
        }
        logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
        return propValue;

      }
    /**
     * Create By ibmadmin * 
     * @param property
     * @param input
     * @param output
     * @return
     */
    public Document getOfflineResponseForDM(String property, Document input, Document output) {
        String damagedFlag = "";
        String extnCallbackTypeCode = "";
        String webexFlag = ""; 
      logger.beginTimer("KohlsPOCSysRepublic.getOfflineResponseForDM");
        try {
            output = XMLUtil.createDocument(KohlsPOCConstant.GET_DISPOSITION_RESP);
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        XmlUtils.setAttributes(input.getDocumentElement(), output.getDocumentElement(), false);
        output.getDocumentElement().setAttribute(KohlsPOCConstant.IS_OFFLINE, KohlsPOCConstant.YES);
        //DM-612 _ START
      if(!YFCCommon.isVoid(input.getDocumentElement())){
            damagedFlag = input.getDocumentElement().getAttribute(KohlsPOCConstant.DAMAGED_FLAG);
            extnCallbackTypeCode = input.getDocumentElement().getAttribute(KohlsPOCConstant.CALL_BACK_TYPE_CODE);
            webexFlag = input.getDocumentElement().getAttribute(KohlsPOCConstant.WEB_EXCLUSIVE_FLAG);
            if(!YFCCommon.isVoid(extnCallbackTypeCode) && extnCallbackTypeCode.equalsIgnoreCase(KohlsPOCConstant.TWO)){
                output.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, KohlsPOCConstant.ATTR_DISPOSITION_CODE_94);
            }
            else if(!YFCCommon.isVoid(extnCallbackTypeCode) && extnCallbackTypeCode.equalsIgnoreCase(KohlsPOCConstant.ONE)){
                if(!YFCCommon.isVoid(damagedFlag) && damagedFlag.equalsIgnoreCase(KohlsPOCConstant.YES)){
                    output.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, KohlsPOCConstant.ATTR_DISPOSITION_CODE_95);
                }
                else{
                    output.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, KohlsPOCConstant.ATTR_DISPOSITION_CODE_96);
                }
            }
            else if (!YFCCommon.isVoid(webexFlag) && webexFlag.equalsIgnoreCase(KohlsPOCConstant.YES)){
                if(!YFCCommon.isVoid(damagedFlag) && damagedFlag.equalsIgnoreCase(KohlsPOCConstant.YES)){
                    output.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, KohlsPOCConstant.ATTR_DISPOSITION_CODE_97);
                }
                else{
                    output.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, KohlsPOCConstant.ATTR_DISPOSITION_CODE_98);
                }
            }
            else{
                output.getDocumentElement().setAttribute(KohlsPOCConstant.ATTR_DISPOSITION_CODE, KohlsPOCConstant.ATTR_DISPOSITION_CODE_OFFLINE);
            }
        }  
      //DM-612 - END
        
      logger.endTimer("KohlsPOCSysRepublic.getOfflineResponseForDM");
        return output;

      }
    public void callModifyCacheApi(YFSEnvironment env) {
        Document inDocApi = null;
        try {
            inDocApi = XmlUtils.createDocument(KohlsPOCConstant.E_CACHED_GROUPS);
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (FactoryConfigurationError e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Element eleRootInDoc = inDocApi.getDocumentElement();
        eleRootInDoc.setAttribute(KohlsPOCConstant.A_ENV_NAME, "");
        eleRootInDoc.setAttribute(KohlsPOCConstant.A_API_NAME, KohlsPOCConstant.API_MODIFY_CACHE);
        Element eleCachedGroup = XMLUtil.createChild(eleRootInDoc, KohlsPOCConstant.E_CACHED_GROUP);
        eleCachedGroup.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.A_DATABASE);
        Element eleCacheObject = XMLUtil.createChild(eleCachedGroup, KohlsPOCConstant.A_CACHED_OBJECT);
        eleCacheObject.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR_ATTR);
        if((KohlsPOCConstant.DM_REASON_CODE).equalsIgnoreCase(source)){
            eleCacheObject.setAttribute(KohlsPOCConstant.A_CLASS_ATTR, KohlsPOCConstant.A_CLEAR_REASON_CODE);
            Element eleCacheObject1 = XMLUtil.createChild(eleCachedGroup, KohlsPOCConstant.A_CACHED_OBJECT);
            eleCacheObject1.setAttribute(KohlsPOCConstant.A_ACTION, KohlsPOCConstant.A_CLEAR_ATTR);
            eleCacheObject1.setAttribute(KohlsPOCConstant.A_CLASS_ATTR, KohlsPOCConstant.A_CLEAR_REASON_DESC);
            
        }
        else if((KohlsPOCConstant.DM_GET_UI_SLIP_TEXT).equalsIgnoreCase(source)){
            eleCacheObject.setAttribute(KohlsPOCConstant.A_CLASS_ATTR, KohlsPOCConstant.A_CLEAR_DISPO_SLIP);
        }
        
        try {
            KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_MODIFY_CACHE, inDocApi);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
      }
    
    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
    }
    private boolean goAlwaysToCloudRuleEnabled(YFSEnvironment env, String storeNumber) throws Exception {
  		// TODO Auto-generated method stub
      	  logger.beginTimer("KohlsCallDMAPIWrapper.getRuleValueForDM");

      	  boolean goAlwaystoCloud = false;
      	  Document docRule = SCXmlUtil.createDocument("Rule");
          Element eleInput = docRule.getDocumentElement();
          eleInput.setAttribute("CallingOrganizationCode", storeNumber);
          eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, "DM_GO_TO_CLOUD");
          Document docOutRule=
              KohlsCommonUtil.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docRule);
          if (YFCLogUtil.isDebugEnabled() && !YFCCommon.isVoid(docOutRule)) {
            logger.debug("Rule out put xml : " + SCXmlUtil.getString(docOutRule));
          }
          if (!YFCCommon.isVoid(docOutRule) && docOutRule.getDocumentElement().hasChildNodes()) {
        	  Element eleRuleval= (Element) docOutRule.getDocumentElement()
                .getElementsByTagName("Rule").item(0);                   
            if(logger.isDebugEnabled()) {
    	          logger.debug("KohlsCallDMAPIWrapper.getRuleValueForDM ---Element is  "+XMLUtil.getElementXMLString(eleRuleval));
    	        }
	    	   String sRuleVal=eleRuleval.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
	    	   if(logger.isDebugEnabled()) {
     	          logger.debug("KohlsCallDMAPIWrapper.getRuleValueForDM Rule value is "+sRuleVal);
     	        }
	    	   if("Y".equalsIgnoreCase(sRuleVal))
	    	   {
	    		   goAlwaystoCloud = true;
	    	   }
          }  	
  	      logger.endTimer("KohlsCallDMAPIWrapper.getRuleValueForDM");
          return goAlwaystoCloud;
  	}


}
