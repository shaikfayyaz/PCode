package com.kohls.poc.rest;

public class KohlsCLIResponse {
	private String responseCode;
	private String response;
	private String firstName;
	private String lastName;
	private String middleInitial;
	private String message;
	private String creditLineAmount;
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleInitial() {
		return middleInitial;
	}
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCreditLineAmount() {
		return creditLineAmount;
	}
	public void setCreditLineAmount(String creditLineAmount) {
		this.creditLineAmount = creditLineAmount;
	}
	
	
}