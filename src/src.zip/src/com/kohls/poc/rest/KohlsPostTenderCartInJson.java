package com.kohls.poc.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KohlsPostTenderCartInJson {

	private String loyaltyId;
	private List<Product> products = null;
	private List<Tender> tenders = null;
	private String transactionDate;
	private String storeNbr;
	private String pendingBarcode;
	private String existingPendingBal;
	private String existingEarnTrackerBal;
	private Integer pin;
	
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public String getLoyaltyId() {
		return loyaltyId;
	}
	
	

	public void setLoyaltyId(String loyaltyId) {
		this.loyaltyId = loyaltyId;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public List<Tender> getTenders() {
		return tenders;
	}

	public void setTenders(List<Tender> tenders) {
		this.tenders = tenders;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}




	public class Product {

		private String department;
		private String sku;
		private double yourPrice;
		private double quantity;
		private double netPrice;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		public String getSku() {
			return sku;
		}

		/**
		 * @return the netPrice
		 */
		public double getNetPrice() {
			return netPrice;
		}
		/**
		 * @param d the netPrice to set
		 */
		public void setNetPrice(double netPrice) {
			this.netPrice = netPrice;
		}
		
		public void setSku(String sku) {
			this.sku = sku;
		}

		public double getYourPrice() {
			return yourPrice;
		}

		public void setYourPrice(double yourPrice) {
			this.yourPrice = yourPrice;
		}

		public double getQuantity() {
			return quantity;
		}

		public void setQuantity(double quantity) {
			this.quantity = quantity;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}

	public class Tender {

		private String typeCode;
		private double tenderAmount;
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		public String getTypeCode() {
			return typeCode;
		}

		public void setTypeCode(String typeCode) {
			this.typeCode = typeCode;
		}

		public double getTenderAmount() {
			return tenderAmount;
		}

		public void setTenderAmount(double tenderAmount) {
			this.tenderAmount = tenderAmount;
		}

		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}

	/**
	 * @return the storeNbr
	 */
	public String getStoreNbr() {
		return storeNbr;
	}



	/**
	 * @param storeNumber the storeNumber to set
	 */
	public void setStoreNbr(String storeNumber) {
		this.storeNbr = storeNumber;
	}



	public String getPendingBarcode() {
		return pendingBarcode;
	}



	public void setPendingBarcode(String pendingBarcode) {
		this.pendingBarcode = pendingBarcode;
	}



	public String getExistingPendingBal() {
		return existingPendingBal;
	}



	public void setExistingPendingBal(String existingPendingBal) {
		this.existingPendingBal = existingPendingBal;
	}



	public String getExistingEarnTrackerBal() {
		return existingEarnTrackerBal;
	}



	public void setExistingEarnTrackerBal(String existingEarnTrackerBal) {
		this.existingEarnTrackerBal = existingEarnTrackerBal;
	}



	public Integer getPIN() {
	    return pin;
	}



	public void setPIN(int pin) {
	  this.pin = pin;
	}
}