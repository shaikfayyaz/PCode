package com.kohls.poc.rest;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import java.util.List;



	public class KohlsDMReasonCodeOutJson {
		@SerializedName("damagedReasonCodes")
		@Expose
		private List<DamagedReasonCode> damagedReasonCodes = null;

		public List<DamagedReasonCode> getDamagedReasonCodes() {
			return damagedReasonCodes;
		}

		public void setDamagedReasonCodes(List<DamagedReasonCode> damagedReasonCodes) {
			this.damagedReasonCodes = damagedReasonCodes;
		}

		public class DamageCode {

			@SerializedName("code")
			@Expose
			private String code;
			@SerializedName("description")
			@Expose
			private String description;
			@SerializedName("resellable")
			@Expose
			private String resellable;
			@SerializedName("contaminated")
			@Expose
			private String contaminated;

			public String getCode() {
				return code;
			}

			public void setCode(String code) {
				this.code = code;
			}

			public String getDescription() {
				return description;
			}

			public void setDescription(String description) {
				this.description = description;
			}

			public String getResellable() {
				return resellable;
			}

			public void setResellable(String resellable) {
				this.resellable = resellable;
			}

			public String getContaminated() {
				return contaminated;
			}

			public void setContaminated(String contaminated) {
				this.contaminated = contaminated;
			}

		}

		public class DamagedReasonCode {

			@SerializedName("businessGroupNumber")
			@Expose
			private String businessGroupNumber;
			@SerializedName("departments")
			@Expose
			private List<String> departments = null;
			@SerializedName("damageCodes")
			@Expose
			private List<DamageCode> damageCodes = null;

			public String getBusinessGroupNumber() {
				return businessGroupNumber;
			}

			public void setBusinessGroupNumber(String businessGroupNumber) {
				this.businessGroupNumber = businessGroupNumber;
			}

			public List<String> getDepartments() {
				return departments;
			}

			public void setDepartments(List<String> departments) {
				this.departments = departments;
			}

			public List<DamageCode> getDamageCodes() {
				return damageCodes;
			}

			public void setDamageCodes(List<DamageCode> damageCodes) {
				this.damageCodes = damageCodes;
			}

		}

	}
