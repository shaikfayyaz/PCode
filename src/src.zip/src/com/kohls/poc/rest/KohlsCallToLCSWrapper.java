package com.kohls.poc.rest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;
import java.lang.NumberFormatException;

import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsConstants;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.util.webserviceUtil.FailoverUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.kohls.kohlscorp.pos.KohlsCorpPOCConstants;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;


/* Sample input to user exit : 
 * <KohlsCashActivation SequenceNo="32" AssociateID="1234567" TerminalID="95" Store="9978" BusinessDate="2015-02-18"  ReceiptDate1=""  ReceiptDate2="" /> */
public class KohlsCallToLCSWrapper  {

    public String strDomain = "";
    public String strReadTimeOut = "10000";
    public String strEndPoint = "";
    public String endpoint = "";
    public String strQueryParam = "";
    public String strApiKey = "";
    public String strApiSecretKey = "";
    public String jsonPayload = "";
    public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
    private Properties props;
    public String filePrefix;
    //private String sFilePath = "";
    private String sFilePath="";
    private static YFCLogCategory logger;
    private  SimpleDateFormat sdf = null;
    private String timestamp = null;
    private String source ="";
    KohlsReturnsLCSCallWrapper objReturnLCSUtil = new KohlsReturnsLCSCallWrapper();
    private boolean bWriteToFile = true;
    private static HashMap <String, String> paymentTypeMap = new HashMap<String, String>();
    String activeEndpoint = "";
    private int maxRetries = 1;
    private int count = 0;
    
    static {
        logger = YFCLogCategory.instance(KohlsCallToLCSWrapper.class
                .getName());
        paymentTypeMap.put("02","KMRC");
        paymentTypeMap.put("04","KCC");
        paymentTypeMap.put("05","VISA");
        paymentTypeMap.put("06","MASTERCARD");
        paymentTypeMap.put("07","DISCOVER");
        paymentTypeMap.put("08","AMERICANEXPRESS");
        paymentTypeMap.put("13","GIFTCARD");
        paymentTypeMap.put("19","DEBIT");
        paymentTypeMap.put("VENDOR_CHECK","VENDORCHECK");
        paymentTypeMap.put("PO_VOUCHER","POVOUCHER");
        paymentTypeMap.put("TRAVELERS_CHECK","TRAVELERSCHECK");
        paymentTypeMap.put("CASH","CASH");
        paymentTypeMap.put("CHECK","CHECK");
        paymentTypeMap.put("KCC_KEYED_PSI_TENDER", "KCC");
    }

    /**
     *  Mixed-in class that temporarily holds the LCS Service response,
     *  in order to log additional info for monitoring
     **/
    private static class CallToLCSResponse
    {
        private YFSException yfsException;
        private Document resultDoc;
        private String errorCode;
        private String endpointURL;

        public CallToLCSResponse(YFSException yfsException) 
        {  
            this(yfsException, "", "");
        }

        public CallToLCSResponse(YFSException yfsException, String errorCode, String endpointURL) 
        {
            if (yfsException == null)
            {
                throw new IllegalArgumentException("yfsException null.");
            }
            this.yfsException = yfsException;
            this.errorCode = errorCode;
            this.endpointURL = endpointURL;
        }

        public CallToLCSResponse(Document resultDoc)
        {
            this(resultDoc, "", "");
        }

        public CallToLCSResponse(Document resultDoc, String errorCode, String endpointURL)
        {
            if (resultDoc == null)
            {
                throw new IllegalArgumentException("resultDoc is null.");
            }
            this.resultDoc = resultDoc;
            this.errorCode = errorCode;
            this.endpointURL = endpointURL;
        }
    }

    /** UE method to call LCS via internal callToLCS0 method
     *  - Track  and log LCS service time taken 
     *  - Log LCS service response status
     *  - Returns LCS response to caller on successful call
     *  - Throws cause Exception to caller on error
     **/
    public Document callToLCS(YFSEnvironment env, Document input) throws Exception {
        logger.beginTimer("KohlsCallToLCSWrapper.callToLCS");
        long startTime = System.currentTimeMillis();

        String respStatus = "";
        String endpointURL = ""; 
        CallToLCSResponse callLCSResp = null;
        try 
        {
            callLCSResp = callToLCS0(env, input);           
            if (callLCSResp == null)
            {   // shouldn't happen 
                logger.error("Null Response from LCS.");
            }
            else 
            {
                respStatus = callLCSResp.errorCode;
                endpointURL = callLCSResp.endpointURL;
            }
        }
        catch (Exception e)
        {
            callLCSResp = new CallToLCSResponse(new YFSException(e.getMessage()));
            respStatus = "OTHER_ENV_CFF_ERROR";
        }
        
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        logger.info("LCS Service call took " + duration + "ms." + " Response status: " +  respStatus +
            " Endpoint: " + endpointURL);

        logger.endTimer("KohlsCallToLCSWrapper.callToLCS");
        
        if (callLCSResp == null || (YFCCommon.isVoid(callLCSResp.resultDoc)  && YFCCommon.isVoid(callLCSResp.yfsException)))
        {
            // shouldn't happen 
            throw new YFSException("Null Response from LCS.");
        }
        if (!YFCCommon.isVoid(callLCSResp.yfsException))
        {
            throw callLCSResp.yfsException;
        }
        return callLCSResp.resultDoc;
    }

    /**
     * Internal method to recursively call LCS per CFF 
     * Returns CallToLCSResponse 
     * Throws Exception - Environment or other CFF runtime exception
     **/ 
    private CallToLCSResponse callToLCS0(YFSEnvironment env, Document input) throws Exception {
        sdf = new SimpleDateFormat("ddHHmmss");
        timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
        strApiKey = props.getProperty("LCS_API_KEY");
        strApiSecretKey = props.getProperty("LCS_API_SECRET");
        if(!YFCCommon.isVoid(props.getProperty("LCS_API_SECRET"))) {
          strReadTimeOut = props.getProperty("LCS_READ_TIMEOUT");
        }
        logger.debug("The strEndPoint value is:" + strEndPoint);
        logger.debug("The strDomain value is:" + strDomain);
        
        if(logger.isDebugEnabled()) {
          logger.debug("InDoc--->" + XMLUtil.getXMLString(input));
        }
        Element eleInDoc = input.getDocumentElement();
        source = eleInDoc.getAttribute("Source");
        //If property is defined as Failover then it will get current active endpoint
        FailoverUtil failoverUtil = FailoverUtil.getInstance();
        try {
          if(YFCCommon.isVoid(strDomain)) {
            strDomain = failoverUtil.getActiveEndPoint(resolveLCSDomain(env, input));
          } 
        } catch (Exception e) {
          if(failoverUtil.isEndpointMonitored(resolveLCSDomain(env, input))) {
	        	  if(bWriteToFile)
	  	  		{
		    	  		try {
		    	  		  sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
		    	  		  filePrefix = source+"_"+loyaltyStore+"_"+timestamp+".txt";
		    	  		 String organizationCode = eleInDoc.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
		              restApiutil.writeToFile("LCS is OFFLINE in Store "+organizationCode+" of type "+loyaltyStore+". Waiting for Recovery.","",filePrefix,sFilePath);
		            } catch (Exception ex) {
		                bWriteToFile = false;
		                logger.error("Logger Dir does not exist. So moving on");
		            }
	  	  		}
            logger.error("LCS fail over to Offline. Lets wait for recovery"+e.getMessage());
          } else {
            logger.error("Error in getting LCS_DOMAIN from COP File"+e.getMessage());
          }         
          throw e;
        }

        if(YFCCommon.isVoid(activeEndpoint)) {
          activeEndpoint = failoverUtil.getCurrentActiveEndpoint(resolveLCSDomain(env, input));
        }
        if(YFCCommon.isVoid(activeEndpoint))
        {
        		activeEndpoint="CORP";
        }
        String sPOCFeature ="";
        // Create payload
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();

        KohlsPostTenderCartInJson cart = new KohlsPostTenderCartInJson();
        List<KohlsPostTenderCartInJson.Product> products = new ArrayList<KohlsPostTenderCartInJson.Product>();
        List<KohlsPostTenderCartInJson.Tender> tenders =  new ArrayList<KohlsPostTenderCartInJson.Tender> ();
       
        
        // grab the order lines
        Document inDoc = null;
        HashMap<String, String> loyaltyInfo = null;
        if (!"postSaleKCA".equalsIgnoreCase(source)) {
            // don't need to do this for post sale kca
            Document getOrderDetailsTemplate = XMLUtil.getDocument(KohlsConstants.GET_ORDER_DETAILS_PRESCREEN_TEMPLATE);
            
            String sOrderHeaderKey = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
            String sExtnPOCFeature = "";
            Element eleOrderExtn = XMLUtil.getChildElement(eleInDoc, KohlsPOCConstant.E_EXTN);
            if (!YFCCommon.isVoid(eleOrderExtn)) {
                sExtnPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
            }
            String sEndpoint = eleInDoc.getAttribute(KohlsXMLLiterals.A_ENDPOINT);
            
            // setting endpoint in env object to use it in subsequent calls.
            if(!YFCCommon.isVoid(sEndpoint)) {
              env.setTxnObject(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
            }
            // Forming the input document for getOrderList API Call.
            Document docGetOrderDetailsInput = XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
            Element eleGetOrderDetailsInput = docGetOrderDetailsInput.getDocumentElement();
            eleGetOrderDetailsInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, sOrderHeaderKey);
            
            // ISS changes - start
            if (ServerTypeHelper.amIOnEdgeServer()) {
                if (!YFCCommon.isVoid(sExtnPOCFeature)
                        && sExtnPOCFeature.equals(KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT)) {
                    Element eleAdditionalInfo = SCXmlUtil.createChild(
                        eleGetOrderDetailsInput, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                    eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT,
                            KohlsXMLLiterals.V_MOTHERSHIP);
                } else if(!YFCCommon.isVoid(sEndpoint)) {
                  Element eleAdditionalInfo = SCXmlUtil.createChild(
                      eleGetOrderDetailsInput, KohlsXMLLiterals.E_YFCADDITIONALINFO);
                  eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, sEndpoint);
                }
            }
            // ISS changes - end
            
            inDoc = KOHLSBaseApi.invokeAPI(env, getOrderDetailsTemplate, KohlsConstant.API_GET_ORDER_DETAILS, docGetOrderDetailsInput);
            
            String transactionNo = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_TRANSACTION_NO);
            if(!YFCCommon.isVoid(transactionNo))
            {
            		transactionNo = transactionNo.substring(12, transactionNo.length());
            		timestamp = transactionNo;
            }
            if (!YFCCommon.isVoid(eleInDoc.getAttribute(KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT))) {
            	inDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT, 
            			eleInDoc.getAttribute(KohlsXMLLiterals.A_ORIGINAL_REFUND_AMOUNT));
            }
            
            // see if we have the loyalty id, if so append to input
            Element loyaltyList = SCXmlUtil.getChildElement(input.getDocumentElement(), KohlsXMLLiterals.E_LOYALTY_LIST);
            if (!YFCCommon.isVoid(loyaltyList)) {
            	loyaltyInfo = new HashMap<String, String>();
            	ArrayList<Element> loyaltyIds = SCXmlUtil.getChildren(loyaltyList, KohlsXMLLiterals.E_LOYALTY);
            	for (Element currentLoyaltyId : loyaltyIds) {
            		String key = currentLoyaltyId.getAttribute(KohlsXMLLiterals.A_STORE_ID) + "|" + currentLoyaltyId.getAttribute(KohlsXMLLiterals.A_REGISTER_ID) 
            		 	+ "|" + currentLoyaltyId.getAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER); 
            		String value = currentLoyaltyId.getAttribute(KohlsXMLLiterals.A_LOYALTY_NUMBER) + "|" + currentLoyaltyId.getAttribute(KohlsXMLLiterals.A_EVERYDAY_EARN_KCC)
            			+ "|" + currentLoyaltyId.getAttribute(KohlsXMLLiterals.A_EVERYDAY_EARN_NON_KCC) + "|" + currentLoyaltyId.getAttribute("EligibleAmt");
            				
            		loyaltyInfo.put(key, value);
            		//PLYT-1689 Reading KC Barcode from RS and stamping on order.
            		String sIndividualOfferId = currentLoyaltyId.getAttribute("IndividualOfferId");
            		if(!YFCCommon.isVoid(sIndividualOfferId)) {
            		  inDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.E_INDIVIDUAL_OFFER_ID, sIndividualOfferId);
            		}
            	}
            }
            
            Element orderExtnElement = SCXmlUtil.getChildElement(eleInDoc, KohlsXMLLiterals.E_EXTN);
            if (orderExtnElement != null) {
            	inDoc.getDocumentElement().setAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE, orderExtnElement.getAttribute(
            		KohlsXMLLiterals.A_EXTN_POC_FEATURE));
            }
        }
                    
        if("preTender".equalsIgnoreCase(source))
        {
            strEndPoint = resolveLCSEndpoint(env, input, "LCS_PRE_TENDER_ENDPOINT");
            
            //Getting Root element of the input xml
            Element eleRootInXml = inDoc.getDocumentElement();

            //Getting each order line from the input xml
            NodeList listOrderLines = eleRootInXml.getElementsByTagName("OrderLine");

            int ilistLineCount= listOrderLines.getLength();

            // Extracting each order line from the input xml
            for ( int iOrderLine = 0; iOrderLine < ilistLineCount; iOrderLine++) {

                Element eleOrderLine = (Element) listOrderLines.item(iOrderLine);           
                String strQty = eleOrderLine.getAttribute("OrderedQty");

                //Getting Extn element from the orderline
                Element eleExtn = (Element) eleOrderLine.getElementsByTagName("Extn").item(0);
                String strDepartment = eleExtn.getAttribute("ExtnItemDept");
                String strPrice = eleExtn.getAttribute("ExtnNetPrice");

                //Getting Item element from the orderline
                Element eleItem = (Element) eleOrderLine.getElementsByTagName("Item").item(0);          
                String strItemId = eleItem.getAttribute("ItemID");
                

                KohlsPostTenderCartInJson.Product Prd = cart.new Product();
                Prd.setDepartment(strDepartment);
                Prd.setQuantity(Double.parseDouble(strQty));
                Prd.setSku(strItemId);
                Prd.setNetPrice(Double.parseDouble(strPrice));
                products.add(Prd);
            }
            //cart.setLoyaltyId("CustomerID");
            cart.setProducts(products);
            jsonPayload = gson.toJson(cart).toString();
            
           
            bWriteToFile = true;
            filePrefix = "PreTender_"+loyaltyStore+"_"+timestamp+".txt";
            if(logger.isDebugEnabled()) {
                logger.debug("jsonPayload--->"+jsonPayload);
            }
            try {
                sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                //sFilePath = "/home/sterling/sterling93/logs/LCS";
                restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                    logger.debug("Logger Dir does not exist. So moving on");
              }
        }
        else if("postTender".equalsIgnoreCase(source))
        {
            strEndPoint = resolveLCSEndpoint(env, input, "LCS_POST_TENDER_LEGACY");            
            
            //Getting Root element of the input xml
            Element eleRootInXml = inDoc.getDocumentElement();
            Element customAttributes = SCXmlUtil.getChildElement(eleRootInXml, "CustomAttributes");
            String boolean5 = null;
            if(!YFCCommon.isVoid(customAttributes))
            {
                    boolean5 = customAttributes.getAttribute("Boolean5");
            }
            //Getting each order line from the input xml
            NodeList listOrderLines = eleRootInXml.getElementsByTagName("OrderLine");

            // PLYT-1819 V1: send register business date to LCS
            String tranDate = eleInDoc.getAttribute(KohlsPOCConstant.A_BUSINESS_DATE);

            //PLYT-2209 V2: send locale-based order date to LCS
            String storeId = eleRootInXml.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
            String storeType = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, 
                storeId, KohlsPOCConstant.EMPTY);
            if (logger.isDebugEnabled()) {
                logger.debug("storeId is   :" + storeId);
                logger.debug("storeType is   :" + storeType);
            }
            if (KohlsPOCConstant.LOYALTY_STORE_V2_PILOT.equals(storeType) ||
                KohlsPOCConstant.LOYALTY_STORE_V2_NON_PILOT.equals(storeType)) {

                tranDate = eleInDoc.getAttribute("OrderDate");              
                String localeCode = KohlsPoCCommonAPIUtil.getLocaleCode(env, storeId);
                if (logger.isDebugEnabled()) {
                    logger.debug("orderDate is   :" + tranDate);
                    logger.debug("localeCode is   :" + localeCode);
                }
                if (!KohlsPOCConstant.LOCALE_CODE_CST.equals(localeCode)) {
                  if(logger.isDebugEnabled()) {
                    logger.debug("The store is not in CST");
                  }
                  String timezone = KohlsPoCCommonAPIUtil.getTimeZoneID(env, localeCode);
                  if(logger.isDebugEnabled()) {
                    logger.debug("Timezone is  :" + timezone);
                  }
                  String orderDateBasedOnTimeZone = KohlsPoCCommonAPIUtil.convert(tranDate, timezone);
                  if(logger.isDebugEnabled()) {
                    logger.debug("orderDateBasedOnTimeZone is  :" + orderDateBasedOnTimeZone);
                  }
                  tranDate = orderDateBasedOnTimeZone;
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug("tranDate is   :" + tranDate);
            }
            cart.setTransactionDate(tranDate);

            String pendingBarcode = eleInDoc.getAttribute("pendingBarcode");
            String existingEarnTrackerBal = eleInDoc.getAttribute("existingEarnTrackerBal");;
            String existingPendingBal = eleInDoc.getAttribute("existingPendingBal");;
            String pin = eleInDoc.getAttribute("PIN");

            // V1 (!isVoid), V2 (isVoid)
            if(!YFCCommon.isVoid(pendingBarcode)) {
                cart.setPendingBarcode(pendingBarcode);
            }
            if(!YFCCommon.isVoid(existingEarnTrackerBal)) {
                cart.setExistingEarnTrackerBal(existingEarnTrackerBal);
            }
            if(!YFCCommon.isVoid(existingPendingBal)) {
                cart.setExistingPendingBal(existingPendingBal);
            }
            if(!YFCCommon.isVoid(pin)) {
                cart.setPIN(Integer.parseInt(pin));
            	
            }
            // Extracting each order line from the input xml
            for ( int iOrderLine = 0; iOrderLine < listOrderLines.getLength(); iOrderLine++) {

                Element eleOrderLine = (Element) listOrderLines.item(iOrderLine);           
                String strQty = eleOrderLine.getAttribute("OrderedQty");

                //Getting Extn element from the orderline
                Element eleExtn = (Element) eleOrderLine.getElementsByTagName("Extn").item(0);
                String strDepartment = eleExtn.getAttribute("ExtnItemDept");
                String strYourPrice = eleExtn.getAttribute("ExtnNetPrice");

                //Getting Item element from the orderline
                Element eleItem = (Element) eleOrderLine.getElementsByTagName("Item").item(0);          
                String strItemId = eleItem.getAttribute("ItemID");


                KohlsPostTenderCartInJson.Product Prd = cart.new Product();
                Prd.setDepartment(strDepartment);
                Prd.setQuantity(Double.parseDouble(strQty));
                Prd.setSku(strItemId);
                Prd.setYourPrice(Double.parseDouble(strYourPrice));
                products.add(Prd);
            }

            //Extracting PaymentMethod from the order xml
            NodeList listPaymentMethods = eleRootInXml.getElementsByTagName("PaymentMethod");

            // Extracting each PaymentMethod from the input xml
            for ( int iPaymentMethod = 0; iPaymentMethod < listPaymentMethods.getLength(); iPaymentMethod++) {

                Element elePaymentMethod = (Element) listPaymentMethods.item(iPaymentMethod);           
                String strTenderType = elePaymentMethod.getAttribute("CreditCardType");
                String strPaymentType = elePaymentMethod.getAttribute("PaymentType");
                String strTenderAmount = elePaymentMethod.getAttribute("TotalCharged");         

                String strSuspendAnymoreCharges = elePaymentMethod.getAttribute("SuspendAnyMoreCharges");
                
                // dont pass suspended payment.
                if ("Y".equalsIgnoreCase(strSuspendAnymoreCharges)) {
                  continue;
                }

                KohlsPostTenderCartInJson.Tender tender = cart.new Tender();

                if(paymentTypeMap.containsKey(strTenderType))
                 {
                        tender.setTypeCode(paymentTypeMap.get(strTenderType));
                 } 
                 else if (paymentTypeMap.containsKey(strPaymentType))
                 {
                        tender.setTypeCode(paymentTypeMap.get(strPaymentType));
                 } else {
                  tender.setTypeCode(strPaymentType);
                }
                
                tender.setTenderAmount(Double.parseDouble(strTenderAmount));

                tenders.add(tender);
            }

            String sCutomerId="";
            endpoint = "earn";
            sCutomerId = eleRootInXml.getAttribute("CustomerRewardsNo");
            if(!YFCCommon.isVoid(sCutomerId) && "Y".equalsIgnoreCase(boolean5)){
                strEndPoint = resolveLCSEndpoint(env, input, "LCS_POST_TENDER_ENDPOINT");
                cart.setLoyaltyId(sCutomerId);
            }    

            if (strEndPoint.equalsIgnoreCase(resolveLCSEndpoint(env, input, "LCS_POST_TENDER_LEGACY"))) {
                // set the store id for legacy earn
                cart.setStoreNbr(eleRootInXml.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
                endpoint = "legacy";
            }
            cart.setProducts(products);
            cart.setTenders(tenders);
            if ("earn".equals(endpoint)) {
                cart.setStoreNbr(eleRootInXml.getAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE));
            }
            jsonPayload = gson.toJson(cart).toString();
            bWriteToFile = true;
            //filePrefix = "PreTender_"+timestamp;
            filePrefix = "PostTender_"+endpoint+"_"+loyaltyStore+"_"+timestamp+".txt";
            if(logger.isDebugEnabled()) {
                logger.debug("jsonPayload--->"+jsonPayload);
            }
            try {
                sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                    logger.debug("Logger Dir does not exist. So moving on");
              }
        }
        else if ("postSaleKCA".equalsIgnoreCase(source))
        {
            strEndPoint = resolveLCSEndpoint(env, input, "LCS_POSTSALE_ACT_ENDPOINT");
            
            JSONObject jsonReq = new JSONObject();
            jsonReq.put("storeNumber", eleInDoc.getAttribute("Store"));
            String strReceipt1 = eleInDoc.getAttribute("ReceiptDate1");
            String strReceipt2 = eleInDoc.getAttribute("ReceiptDate2");
            String managerOverride = eleInDoc.getAttribute("managerOverride");

            jsonReq.put("receiptDate1", strReceipt1);
            jsonReq.put("receiptDate2", strReceipt2);
    	    if("Y".equals(managerOverride)) {
    		    jsonReq.put("supervisorOverride", Boolean.parseBoolean("true"));
    	    }
	    
            jsonPayload = gson.toJson(jsonReq).toString();
            bWriteToFile = true;
            //filePrefix = "PreTender_"+timestamp;
            //filePrefix = "PostTender_"+timestamp;
            filePrefix = "PostSaleActv_"+loyaltyStore+"_"+timestamp+".txt";

            if(logger.isDebugEnabled()) {
                logger.debug("jsonPayload--->" + jsonPayload);
            }
            
            try {
                sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
              } catch (Exception ex) {
                bWriteToFile = false;
                    logger.debug("Logger Dir does not exist. So moving on");
              }
        }
        else if ("ReturnLCS".equalsIgnoreCase(source) ||
        		"ReturnLCSUnearn".equalsIgnoreCase(source))
        {

            strEndPoint = resolveLCSEndpoint(env, input, "LCS_RETURNS_UNEARN_ENDPOINT");
            
            eleInDoc = input.getDocumentElement();
            Element eleOrderExtn = XMLUtil.getChildElement(eleInDoc, KohlsXMLLiterals.E_EXTN);
            
            sPOCFeature = eleOrderExtn.getAttribute(KohlsXMLLiterals.A_EXTN_POC_FEATURE);
            
            if(YFCCommon.isVoid(sPOCFeature) || KohlsPOCConstant.POST_SALE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature)) {
                //callPSA function 
            	inDoc.getDocumentElement().setAttribute("Source", source);
                jsonPayload = objReturnLCSUtil.prepareInputForPSA(env, inDoc, loyaltyInfo);
            } else {
                //call Return/PA - handle for MRR
                jsonPayload = objReturnLCSUtil.prepareInputForReturnsPA(env, inDoc, loyaltyInfo, sPOCFeature);
            }
            bWriteToFile = true;
            
            filePrefix = "LCSUnearn_" + sPOCFeature + "_" +loyaltyStore+"_"+timestamp+".txt";

            if(logger.isDebugEnabled()) {
                logger.debug("jsonPayload--->" + jsonPayload);
            }
            
            try {
                sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                restApiutil.writeToFile("Request is ----> \n",jsonPayload,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                    logger.debug("Logger Dir does not exist. So moving on");
              }
            // don't call LCS if we don't have any input
            if (YFCCommon.isVoid(jsonPayload)) {
            	return new CallToLCSResponse(SCXmlUtil.createDocument(KohlsCorpPOCConstants.NONE), "INVALID_PSA_INPUT", strDomain + strEndPoint);
            }
        }
        
        // String
        String strtempDomain = strDomain + strEndPoint;
        if (!"".equalsIgnoreCase(strQueryParam)) {
            strtempDomain += "?" + strQueryParam;
        }
        // PST-444 Changes for CorrelationID
        
        ResponseEntity<String> response = null;
        CallToLCSResponse output = null;

        //int count = 0;
        //int iMaxTries = Integer.parseInt(KohlsPoCCommonAPIUtil.getRuleValuesfromDB(env));
        //while (count <= iMaxTries) {
            try {
                //strISODtae = restApiutil.getCurrentISODate();
                TreeMap<String, String> mapHeader = new TreeMap();
                mapHeader.put("Accept-Encoding", "gzip,deflate");
                mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");

                String issodate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
                String strUuid = restApiutil.getUUID();
                final TreeMap<String, String> depHeaderMap = new TreeMap();
                depHeaderMap.put("X-KOHLS-CreateDateTime", issodate);
                depHeaderMap.put("X-KOHLS-From-SystemCode", "KC");
                depHeaderMap.put("X-KOHLS-MessageID", strUuid);
                depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
                //count++;
                response = restApiutil.createConnection(jsonPayload,
                        mapHeader, depHeaderMap, strQueryParam, strtempDomain,
                        strEndPoint, strApiKey,
                        strApiSecretKey,strReadTimeOut,strReadTimeOut,"LCS", null, false, null, 0);
                if(failoverUtil.isEndpointMonitored(resolveLCSDomain(env, input))) {
                  failoverUtil.resetFailedCounter(resolveLCSDomain(env, input), activeEndpoint);
                }
                JSONObject json = null;

                String respStatus = "UNKNOWN";
                if(response!=null) 
                {
                    respStatus = response.getStatusCode().toString();
                }
                if ("200".equals(respStatus) || "206".equals(respStatus))
                {
                    String responseBody = response.getBody(); 
                    if("postTender".equalsIgnoreCase(source) && "earn".equalsIgnoreCase(endpoint)) {
	                    KohlsPostTenderCartOutJson sample = (new Gson()).fromJson(responseBody, KohlsPostTenderCartOutJson.class);
	                    if (!YFCCommon.isVoid(sample.getEverydayEarnKcc())) {
	                    	sample.setEverydayEarnKcc(Double.valueOf(sample.getEverydayEarnKcc()).toString());
	                    } else {
	                    	sample.setEverydayEarnKcc("0.0");
	                    }
	                    if (!YFCCommon.isVoid(sample.getEverydayEarnNonKcc())) {
	                    	sample.setEverydayEarnNonKcc(Double.valueOf(sample.getEverydayEarnNonKcc()).toString());
	                    } else {
	                    	sample.setEverydayEarnNonKcc("0.0");
	                    }
	        			json = new JSONObject((new Gson()).toJson(sample));
                    } else {
                        json = new JSONObject(responseBody);
                    }
        			if(logger.isDebugEnabled()) {
                        logger.debug("responseBody--->"+responseBody);
                    }
                    if(bWriteToFile)
                    {
                        try {
                            //sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                            restApiutil.writeToFile("Response from "+activeEndpoint+" endpoint is ----> \n",json.toString(),filePrefix,sFilePath);
                          } catch (Exception ex) {
                                logger.debug("Logger Dir does not exist. So moving on");
                          }
                    }
                    
                    if("preTender".equalsIgnoreCase(source)) {
                        output = new CallToLCSResponse(processPreCartResp(json.toString()), respStatus, strtempDomain);
                    } else if("postTender".equalsIgnoreCase(source)) {
                        output = new CallToLCSResponse(processPostCartResp(json.toString()), respStatus, strtempDomain);
                    } else if ("postSaleKCA".equalsIgnoreCase(source)) {
                        output = new CallToLCSResponse(processPostSaleActivationResp(json.toString()), respStatus, strtempDomain);
                    } else if ("ReturnLCS".equalsIgnoreCase(source)) {
                        if(YFCCommon.isVoid(sPOCFeature) || KohlsPOCConstant.POST_SALE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature)) {
                            //callPSA function 
                            output = new CallToLCSResponse(objReturnLCSUtil.processOutputForPSA(env,json.toString(),inDoc), respStatus, strtempDomain);
                        } else {
                            //call Return/PA - handle for MRR
                            output = new CallToLCSResponse(objReturnLCSUtil.processOutputForLCSReturnsPA(env,json.toString(),inDoc,""), respStatus, strtempDomain);
                        }
                    } else if ("ReturnLCSUnearn".equalsIgnoreCase(source)) {
                        //call Return/PA/PSA - handle for MRR
                        output = new CallToLCSResponse(objReturnLCSUtil.processOutputForLCSReturnsPA(env,json.toString(),inDoc,"V2Unearn"), respStatus, strtempDomain);
                    }
                    //break;
                } else {
                    Document outDoc = restApiutil.processErrorCode(json.toString());
                    Element eleDoc = outDoc.getDocumentElement();
                    output = new CallToLCSResponse(outDoc, eleDoc.getAttribute("ErrorCode"), strtempDomain);
                }
            } catch (Exception e) {
                // PST-6766
                logger.error("Exception occurred while calling LCS endpoint: " + strDomain + strEndPoint, e);
                int errorCode = -1;
                String strErrorCode = "";
                if(e instanceof YFSException) {
                    try {
                        strErrorCode = ((YFSException) e).getErrorCode();
                        if (strErrorCode != null) {
                            errorCode = Integer.parseInt(strErrorCode);
                        }
                    }
                    catch (NumberFormatException ignore) {
                    }
                }
                Throwable tmp = e;
                while (tmp != null) {
                    if (tmp.getCause() instanceof java.io.IOException
                        || tmp.getCause() instanceof java.net.SocketTimeoutException
                        || tmp.getCause() instanceof java.net.ConnectException
                        || tmp.getCause() instanceof java.net.NoRouteToHostException 
                        || tmp.getCause() instanceof java.net.UnknownHostException
                        || "CONNECTERROR".equalsIgnoreCase(strErrorCode)
                        || KohlsPOCConstant.INTERNAL_SERVER_ERROR.equalsIgnoreCase(strErrorCode)
                        || KohlsPOCConstant.SERVICE_UNAVAILABLE_503.equalsIgnoreCase(strErrorCode)
                        || "UNKNOWN".equalsIgnoreCase(strErrorCode)
                        || errorCode >= 500) {
                	  
            	  		if(bWriteToFile)
            	  		{
	            	  		try {
	                      restApiutil.writeToFile("Error while calling "+activeEndpoint+" endpoint and the error is ----> \n",e.toString(),filePrefix,sFilePath);
	                    } catch (Exception ex) {
	                        bWriteToFile = false;
	                        logger.error("Logger Dir does not exist. So moving on");
	                    }
            	  		}

                	  // Failover framework
                      if(failoverUtil.isEndpointMonitored(resolveLCSDomain(env, input))) {
                        failoverUtil.compareAndIncrementCounters(resolveLCSDomain(env, input),activeEndpoint);
                        if ("PRIMARY".equalsIgnoreCase(activeEndpoint)) {
                          strDomain = failoverUtil.getBackupEndpoint(resolveLCSDomain(env, input));
                          if(!YFCCommon.isVoid(strDomain)) {
                            activeEndpoint = "BACKUP";
                            logger.error("Failover transaction from PRIMARY to BACKUP - " + strDomain + strEndPoint);
                            output = callToLCS0(env, input);
                          } else {
                            output = new CallToLCSResponse(new YFSException(e.getMessage()), 
                                getRespStatus(tmp, strErrorCode, errorCode), strtempDomain);
                          }
                          
                        } else {
                            output = new CallToLCSResponse(new YFSException(e.getMessage()), 
                                getRespStatus(tmp, strErrorCode, errorCode), strtempDomain);
                        }
                      }
                      //Loyalty V2 Retry Logic for 500
                      else if("ReturnLCSUnearn".equalsIgnoreCase(source) && errorCode == 500 && count<maxRetries){
                    	  logger.error("Retry attempted for source ReturnLCSUnearn : " +count);
                    	  count++;
                    	  output = callToLCS0(env, input);
                      } else {
                        output = new CallToLCSResponse(new YFSException(e.getMessage()), 
                            getRespStatus(tmp, strErrorCode, errorCode), strtempDomain);
                      }  
                      break;                    
                    }
                    // Throw exception on bad response codes such as 400 / 403 / 404 and do not retry
                    else if(errorCode == KohlsPOCConstant.BAD_REQUEST_400
                    		|| errorCode == KohlsPOCConstant.FORBIDDEN_REQUEST_403 
                    		|| errorCode == KohlsPOCConstant.NOT_FOUND_REQUEST_404  )
                    {
                    	 logger.debug("4XX HTTP response from Client .Throwing YFCException");
                    	 throw new YFSException("SOAP_EXCEPTION","SOAP_EXCEPTION","SOAP_EXCEPTION");
                    }

                    tmp = tmp.getCause();
                }
            }
            finally {   
      	  	  if(failoverUtil.isEndpointMonitored(resolveLCSDomain(env, input)))
      	  	  {
      	  		  //String cffFilePath = "/home/sterling/sterling93/logs/CFF";
      	            String cffFilePath = "/logs/apps/of/CFF"; 
      	    	    	 // SimpleDateFormat sdf1 = new SimpleDateFormat("ddHHmmss");
      	    	    	 // String timestamp1 = sdf1.format(YFCDateUtils.getCurrentDate(true));
	  	    		  logger.debug("wsProperties at the end::"+failoverUtil.getWsProperties());	  	    		 
	  	    		  restApiutil.writeToFile("\n\n\nLCS failover Props --->\n",
	      		  failoverUtil.getWsProperties().toString(),"CFF_LCS_"+loyaltyStore+"_"+timestamp,cffFilePath);     
      	  	  }
          }
        //}
        // Fix for defect 1380 - End
        return output;
    }

    /**
     * Returns the response status map in the order of connError, strErrorCode, or errorCode .  
     * connError - connection exception
     * strErrorCode - REST client impl response code
     * errorCode - http code 
     **/
    private String getRespStatus(Throwable connError, String strErrorCode, int errorCode) 
    {
        if (connError.getCause() instanceof java.io.IOException ||
            connError.getCause() instanceof java.net.SocketTimeoutException ||
            connError.getCause() instanceof java.net.ConnectException ||
            connError.getCause() instanceof java.net.NoRouteToHostException  ||
            connError.getCause() instanceof java.net.UnknownHostException ||
            "CONNECTERROR".equalsIgnoreCase(strErrorCode))
        {
            return "CONNECTERROR";
        }
        else if (KohlsPOCConstant.INTERNAL_SERVER_ERROR.equalsIgnoreCase(strErrorCode))
        {
            return KohlsPOCConstant.INTERNAL_SERVER_ERROR;
        }
        else if (KohlsPOCConstant.SERVICE_UNAVAILABLE_503.equalsIgnoreCase(strErrorCode))
        {
            return KohlsPOCConstant.SERVICE_UNAVAILABLE_503;
        }
        else 
        {
            if (errorCode != -1)
            {
                return String.valueOf(errorCode);
            }
            return "UNKNOWN";
        }
    }

    /**
     * Returns the correct properties name by store
     * @param env
     * @param inDoc
     * @param propertyName
     * @return
     * @throws Exception
     */
    private String loyaltyStore = null;
    protected String qualifyPropVersion(YFSEnvironment env, Document inDoc, String propertyName) throws Exception {
        Element eleInDocOrder = inDoc.getDocumentElement();
        String organizationCode = eleInDocOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
        if(YFCCommon.isVoid(loyaltyStore))
        {
        		loyaltyStore = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, 
            organizationCode, KohlsPOCConstant.EMPTY);
        }
        if (KohlsPOCConstant.LOYALTY_STORE_Y2Y.equals(loyaltyStore) || 
            KohlsPOCConstant.LOYALTY_STORE_V1_PILOT.equals(loyaltyStore)) {
            return propertyName + "_V1";
        }
        return propertyName;
    }

    /**
     * Returns correct LCS endpoint url
     * @param env
     * @param inDoc
     * @param propertyName
     * @return
     * @throws Exception
     */
    protected String resolveLCSEndpoint(YFSEnvironment env, Document inDoc, String endpoint) throws Exception {
        return  KohlsRestAPIUtil.getPropertyValue(qualifyPropVersion(env, inDoc, endpoint));
    }

    /**
     * Returns correct LCS domain url
     * @param env
     * @param inDoc
     * @param propertyName
     * @return
     * @throws Exception
     */
    protected String resolveLCSDomain(YFSEnvironment env, Document inDoc) throws Exception {
        return  qualifyPropVersion(env, inDoc, "LCS_DOMAIN");
    }

    /**
     * @param strQueryParam
     * @param json
     * @return
     * @throws Exception
     * 
     *             <KohlsCashActivation EventID="123" CouponAmount="10.00"
     *             CouponNumber="123450408367922" ValidationCode="1232"/>
     */
    Document processPostSaleActivationResp(String jsonString) throws Exception {
        // TODO Auto-generated method stub
        // String sToParse = json.toString();
        Document docPostSaleActivationResp = XMLUtil
                .createDocument("KohlsCashActivation");
        Element eleRootOut = docPostSaleActivationResp.getDocumentElement();

        JsonParser parser = new JsonParser();
        JsonObject rootObj = parser.parse(jsonString).getAsJsonObject();
        String barcode = rootObj.get("barcode").getAsString();
        String eventid = rootObj.get("eventId").getAsString();
        String activationAmount = rootObj.get("activationAmount").getAsString();
        String pin = rootObj.get("pin").getAsString();

        eleRootOut.setAttribute(KohlsPOCConstant.E_EVENT_ID, eventid);
        eleRootOut.setAttribute("CouponAmount", activationAmount);
        eleRootOut.setAttribute(KohlsPOCConstant.A_COUPON_NUMBER, barcode);
        eleRootOut.setAttribute(KohlsPOCConstant.E_VALIDATION_CODE, pin);

        return docPostSaleActivationResp;
    }
    
    Document processPreCartResp(String sToParse) throws Exception {
        // TODO Auto-generated method stub

        Gson outGson = new Gson();
        KohlsPostTenderCartOutJson parsedClass = outGson.fromJson(sToParse, KohlsPostTenderCartOutJson.class); // input
        Document    docPreCartResp=XMLUtil.createDocument("CartPreTenderRepsonse"); 
        Element eledocPreCartResp = docPreCartResp.getDocumentElement();
        // Common && V2
        eledocPreCartResp.setAttribute("EverydayEarnNonKcc", parsedClass.getEverydayEarnNonKcc());
        eledocPreCartResp.setAttribute("EverydayEarnKcc", parsedClass.getEverydayEarnKcc());
        eledocPreCartResp.setAttribute("EverydayKccPercentage", parsedClass.getEverydayKccPercentage());
        eledocPreCartResp.setAttribute("EverydayNonKccPercentage", parsedClass.getEverydayNonKccPercentage());
        // V1
        String eventKohlsCashEarn = parsedClass.getEventKohlsCashEarn();
        if (!YFCCommon.isVoid(eventKohlsCashEarn)) {
            eledocPreCartResp.setAttribute("EventKohlsCashEarn", eventKohlsCashEarn);
        }
        String eventKohlsCashEarnTol = parsedClass.getEventKohlsCashEarnTol();
        if (!YFCCommon.isVoid(eventKohlsCashEarnTol)) {
            eledocPreCartResp.setAttribute("EventKohlsCashEarnTol", eventKohlsCashEarnTol);
        }
        String redemptionStartDate = parsedClass.getRedemptionStartDate();
        if (!YFCCommon.isVoid(redemptionStartDate)) {
            eledocPreCartResp.setAttribute("RedemptionStartDate", redemptionStartDate);
        }
        String redemptionEndDate = parsedClass.getRedemptionEndDate();
        if (!YFCCommon.isVoid(redemptionEndDate)) {
            eledocPreCartResp.setAttribute("RedemptionEndDate", redemptionEndDate);
        }
        String spendAwayEvent = parsedClass.getSpendAwayEvent();
        if (!YFCCommon.isVoid(spendAwayEvent)) {
            eledocPreCartResp.setAttribute("SpendAwayEvent", spendAwayEvent);
        }
        String eventName = parsedClass.getEventName();
        if (!YFCCommon.isVoid(eventName)) {
            eledocPreCartResp.setAttribute("EventName", eventName);
        }
        return docPreCartResp;
    }
    
    private Document processPostCartResp(String sToParse) throws Exception {
        // TODO Auto-generated method stub
        
        Gson outGson = new Gson();
        KohlsPostTenderCartOutJson parsedClass = outGson.fromJson(sToParse, KohlsPostTenderCartOutJson.class); // input
        Document    docPostCartResp=XMLUtil.createDocument("CartPostTenderRepsonse");                                                               // is
        Element eledocPostCartResp = docPostCartResp.getDocumentElement();
        // Common
        eledocPostCartResp.setAttribute("EverydayEarnNonKcc", parsedClass.getEverydayEarnNonKcc());
        eledocPostCartResp.setAttribute("EverydayEarnKcc", parsedClass.getEverydayEarnKcc());
        eledocPostCartResp.setAttribute("SpendAwayEverydayNonKcc", parsedClass.getSpendAwayEverydayNonKcc());
        eledocPostCartResp.setAttribute("SpendAwayEverydayKcc", parsedClass.getSpendAwayEverydayKcc());
        eledocPostCartResp.setAttribute("EverydayKccPercentage", parsedClass.getEverydayKccPercentage());
        eledocPostCartResp.setAttribute("EverydayNonKccPercentage", parsedClass.getEverydayNonKccPercentage());
        eledocPostCartResp.setAttribute("QualifyingPurchaseAmount", parsedClass.getQualifyingPurchaseAmount());
        // V1
        String eventKohlsCashEarn = parsedClass.getEventKohlsCashEarn();
        if (!YFCCommon.isVoid(eventKohlsCashEarn)) {
            eledocPostCartResp.setAttribute("EventKohlsCashEarn", eventKohlsCashEarn);
        }
        String eventKohlsCashEarnTol = parsedClass.getEventKohlsCashEarnTol();
        if (!YFCCommon.isVoid(eventKohlsCashEarnTol)) {
            eledocPostCartResp.setAttribute("EventKohlsCashEarnTol", eventKohlsCashEarnTol);
        }
        String spendAwayEvent = parsedClass.getSpendAwayEvent();
        if (!YFCCommon.isVoid(spendAwayEvent)) {
            eledocPostCartResp.setAttribute("SpendAwayEvent", spendAwayEvent);
        }
        String everydayEarnRem = parsedClass.getEverydayEarnRem();
        if (!YFCCommon.isVoid(everydayEarnRem)) {
            eledocPostCartResp.setAttribute("EverydayEarnRem", everydayEarnRem);
        }
        String existingEarnTrackerBal = parsedClass.getExistingEarnTrackerBal();
        if (!YFCCommon.isVoid(existingEarnTrackerBal)) {
            eledocPostCartResp.setAttribute("ExistingEarnTrackerBal", existingEarnTrackerBal);
        }
        String redemptionStartDate = parsedClass.getRedemptionStartDate();
        if (!YFCCommon.isVoid(redemptionStartDate)) {
            eledocPostCartResp.setAttribute("RedemptionStartDate", redemptionStartDate);
        }
        String redemptionEndDate = parsedClass.getRedemptionEndDate();
        if (!YFCCommon.isVoid(redemptionEndDate)) {
            eledocPostCartResp.setAttribute("RedemptionEndDate", redemptionEndDate);
        }
        String updatedPendingBalTol = parsedClass.getUpdatedPendingBalTol();
        if (!YFCCommon.isVoid(updatedPendingBalTol)) {
            eledocPostCartResp.setAttribute("UpdatedPendingBalTol", updatedPendingBalTol);
        }
        String transKcAmountToActivateTol = parsedClass.getTransKcAmountToActivateTol();
        if (!YFCCommon.isVoid(transKcAmountToActivateTol)) {
            eledocPostCartResp.setAttribute("TransKcAmountToActivateTol", transKcAmountToActivateTol);
        }
        String totalKcAmountToActivate = parsedClass.getTotalKcAmountToActivate();
        if (!YFCCommon.isVoid(totalKcAmountToActivate)) {
            eledocPostCartResp.setAttribute("TotalKcAmountToActivate", totalKcAmountToActivate);
        }
        String eventName = parsedClass.getEventName();
        if (!YFCCommon.isVoid(eventName)) {
            eledocPostCartResp.setAttribute("EventName", eventName);
        }
        String barcode = parsedClass.getBarcode();
        if (!YFCCommon.isVoid(barcode)) {
            eledocPostCartResp.setAttribute("Barcode", barcode);
        }
        String pin = parsedClass.getPin();
        if (!YFCCommon.isVoid(pin)) {
            eledocPostCartResp.setAttribute("Pin", pin);
        }       
        // V2
        String updatedEarnTrackerBal = parsedClass.getUpdatedEarnTrackerBal();
        if (!YFCCommon.isVoid(updatedEarnTrackerBal)) {
            eledocPostCartResp.setAttribute("UpdatedEarnTrackerBal", updatedEarnTrackerBal);
        }
        return docPostCartResp;
    }
    
    public String getDatefromReceipt(String strReceipt1) {
        return strReceipt1;
    }

    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
        // LOG_CAT.debug("In the set properties method");

    }
    public String getPropertyValue(String property) {
        logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        // Manoj 10/22: updated to use configured property if
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
          propValue = property;
        }
        logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
        return propValue;

      }
}