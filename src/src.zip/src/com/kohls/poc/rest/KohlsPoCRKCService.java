package com.kohls.poc.rest;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsPoCRKCService extends KOHLSBaseApi {

  private final static YFCLogCategory logger = YFCLogCategory.instance(KohlsPoCRKCService.class);

  String eventType;
  String email;
  String receiptNumber;
  String startTime;
  String storeNumber;
  String registerId;
  String transactionNumber;
  String amount;
  String customerOrderNumber;
  String HTTP_METHOD = "POST";
  String CONTENT_TYPE = "application/json";
  String Domain;
  String EndPointPath;
  String ApiKey;
  String ApiSecret;
  String QueryParams;
  KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
  private Properties props;

  /**
   * This function sets the attribute from the input xml
   * 
   * @param env
   * @param Document
   * @return Document
   * @exception YFSException
   * 
   */
  public Document invokeRKCService(YFSEnvironment env, Document inputDoc) throws YFSException {
    logger.beginTimer("KohlsPoCRKCService.invokeRKCService");
    Element eleDigitalKC = (Element) inputDoc.getDocumentElement();
    eventType = eleDigitalKC.getAttribute("EventType");
    email = eleDigitalKC.getAttribute("EmailAddress");
    receiptNumber = eleDigitalKC.getAttribute("ReceiptID");
    startTime = eleDigitalKC.getAttribute("DateTime");
    storeNumber = eleDigitalKC.getAttribute("Store");
    registerId = eleDigitalKC.getAttribute("TerminalID");
    transactionNumber = eleDigitalKC.getAttribute("SequenceNo");
    amount = eleDigitalKC.getAttribute("CouponAmount");
    customerOrderNumber = eleDigitalKC.getAttribute("OrderNo");
    JSONObject jsonRespose;
    Document docDKC = YFCDocument.createDocument("DigitalKohlsCashActivation").getDocument();
    try {
      jsonRespose = createPayLoad();
      docDKC.getDocumentElement().setAttribute("CouponNumber", (String) jsonRespose.get("barcode"));
      docDKC.getDocumentElement().setAttribute("EventID", (String) jsonRespose.get("eventId"));

    } catch (Exception e) {
      logger.debug("Exception while invoking Rest API Webservice ##########\n" + e);
      throw new YFSException(e.getMessage());
    }
    logger.endTimer("KohlsPoCRKCService.invokeRKCService");
    return docDKC;
  }

  public JSONObject createPayLoad() throws Exception {
    logger.beginTimer("KohlsPoCRKCService.createPayLoad");
    // String strCouponId = null;
    JSONObject jsonRespose = null;
    int timeOut = 1000;
    Domain = KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_DOMAIN"));
    EndPointPath =
        KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_ENDPOINT_CONTEXT_PATH_LESS"));
    if (KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_TIMEOUT")) != null) {
      timeOut =
          Integer.parseInt(KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_TIMEOUT")));
      logger.debug("Timeout ##########\n" + timeOut);
    }

    logger.debug("Request pramaters are: " + "\n eventType : " + eventType + "\n email : " + email
        + "\n amount : " + amount + "\n receiptNumber : " + receiptNumber + "\n startTime : "
        + startTime + "\n storeNumber : " + storeNumber + "\n registerId : " + registerId
        + "\n transactionNumber : " + transactionNumber + "\n customerOrderNumber : "
        + customerOrderNumber);

    String reqJson = "{ \"eventType\":\"" + eventType + "\", \"email\":\"" + email
        + "\", \"amount\":\"" + amount + "\", \"receiptNumber\":\"" + receiptNumber
        + "\", \"startTime\":\"" + startTime + "\", \"storeNumber\":\"" + storeNumber
        + "\", \"registerId\":\"" + registerId + "\", \"transactionNumber\":\"" + transactionNumber
        + "\", \"customerOrderNumber\":\"" + customerOrderNumber + "\" }";

    HttpHeaders httpHeaders = createHttpHeaders(reqJson);

    final HttpEntity<String> request = new HttpEntity<String>(reqJson, httpHeaders);
    logger.debug("Request Rest API Webservice ##########\n" + request.toString());
    try {
      // *****************************
      // RestTemplate restTemplate = new RestTemplate();
      HttpComponentsClientHttpRequestFactory requestFactory =
          new HttpComponentsClientHttpRequestFactory();
      requestFactory.setReadTimeout(timeOut);
      RestTemplate restTemplate = new RestTemplate(requestFactory);

      // ***************************
      final ResponseEntity<String> retryResponse;
      final ResponseEntity<String> response =
          restTemplate.exchange(Domain + EndPointPath, HttpMethod.POST, request, String.class);
      final String responseBody = response.getBody();
      if (restApiUtil.isError(response.getStatusCode())) {
        logger.debug("Error ##########\n" + response.getStatusCode());
        if ("503".equals(response.getStatusCode().toString())) {
          retryResponse =
              restTemplate.exchange(Domain + EndPointPath, HttpMethod.POST, request, String.class);
          final String retryResponseBody = retryResponse.getBody();
          if (restApiUtil.isError(retryResponse.getStatusCode())) {
            logger.debug("Error ##########\n" + retryResponse.getStatusCode());
          } else {
            logger.debug("Success");
            logger.debug("retryResposneBody::" + retryResponseBody.toString());
            jsonRespose = new JSONObject(retryResponseBody.toString());
            // strCouponId = (String) json.get("barcode");
          }
        }
      } else {
        logger.debug("Success");
        logger.debug("Response body ####" + responseBody.toString());
        jsonRespose = new JSONObject(responseBody.toString());
        // strCouponId = (String) json.get("barcode");
      }
    } catch (final Exception e) {
      logger.debug("Exception while invoking Rest API Webservice ##########\n" + e);
      throw e;
    }
    logger.endTimer("KohlsPoCRKCService.createPayLoad");
    return jsonRespose;
  }

  public HttpHeaders createHttpHeaders(final String payload) throws IOException {
    logger.beginTimer("KohlsPoCRKCService.createHttpHeaders");
    ApiKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_APIKEY"));
    String ApiSecretEncrypted =
        KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_API_SECRET"));
    EndPointPath =
        KohlsRestAPIUtil.getPropertyValue(props.getProperty("RKC_ENDPOINT_CONTEXT_PATH_LESS"));
    QueryParams = "";

    // Decrypt the Api secret and Api Key
    String mykey = restApiUtil.pwdForDecryption(KohlsPOCConstant.DKC);
    ApiSecret = restApiUtil.decryptString(ApiSecretEncrypted, mykey);
    // ApiKey = restApiUtil.decryptString(ApiKeyEncrypted,mykey);
    // Get current isoDate
    final String isoDate = restApiUtil.getCurrentISODate();
    // create UUID
    final String uuid = restApiUtil.getUUID();

    // Order Map with x-dep header keys and values.
    final TreeMap<String, String> depHeaderMap = new TreeMap();
    depHeaderMap.put("x-dep-date", isoDate);
    depHeaderMap.put("x-dep-request-id", uuid);
    depHeaderMap.put("x-dep-from-app", "DEP");
    depHeaderMap.put("x-dep-from-node", "192.168.1.1");
    depHeaderMap.put("x-dep-from-system-code", "EP");

    // Add httpHeaders for request
    final HttpHeaders headers = new HttpHeaders();
    headers.add("Accept", "application/json");
    headers.add("Content-Type", "application/json");
    for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
      headers.add(entry.getKey(), entry.getValue());
    }

    // Build signature
    Signature signature;
    try {
      signature = new Signature.Builder().apiSecret(ApiSecret).apiKey(ApiKey).endpoint(EndPointPath)
          .method(HttpMethod.POST.name()).isoDate(isoDate)
          // Stringify dep-headers
          .depHeaders(restApiUtil.concatSingleValueDEPHeaderParams(depHeaderMap))
          .mediaType("application/json").payload(payload).queryParams(QueryParams).build();

      // Add Authorization Header
      headers.add("Authorization",
          KohlsPOCConstant.AUTHID + ApiKey + ":" + signature.getRequestSignature());
    } catch (Exception e) {
      logger.debug("Error in Create HTTP Headers |" + e);
    }
    logger.endTimer("KohlsPoCRKCService.createHttpHeaders");
    return headers;
  }

  /**
   * Sets the properties
   * 
   * @param prop Properties that need to be set
   * @throws Exception when unable to set the Property
   */

  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    // LOG_CAT.debug("In the set properties method");

  }
}
