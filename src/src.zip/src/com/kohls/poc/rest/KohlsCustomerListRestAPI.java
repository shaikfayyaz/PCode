package com.kohls.poc.rest;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KOHLSStringUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.messaging.v1_0.header.HostIpAddressNodeIdStrategy;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.fromJSON.cls_customers;
import com.kohls.poc.rest.fromJSON.cls_kohlsCash;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.TreeMap;

public class KohlsCustomerListRestAPI extends KOHLSBaseApi {

    public String strDomian = "";
    public String strReadTimeOut = "";
    public String strEndPoint = "";
    public String strQueryParam = "";
    public String strApiKey = "";
    public String strApiSecretKey = "";
    public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
    private Properties props;
    private String sFileName;
    private static YFCLogCategory logger;

    static {
        logger = YFCLogCategory.instance(KohlsCustomerListRestAPI.class
                .getName());
    }

    public Document getCustomerList(YFSEnvironment env, Document inDoc) throws Exception {
        logger.beginTimer("KohlsCustomerListRestAPI.getCustomerList");
        long startTime = System.currentTimeMillis();

        Document docoutGetCustomer = null;

        String strCustDomain = KohlsCustomerLookupRest.qualifyPropVersion(env, inDoc, "CUST_DOMAIN");
        strDomian = KohlsRestAPIUtil.getPropertyValue(props.getProperty(strCustDomain, strCustDomain));
        String strCustEndpoint = KohlsCustomerLookupRest.qualifyPropVersion(env, inDoc, "CUST_ENDPOINT");
        strEndPoint = KohlsRestAPIUtil.getPropertyValue(props.getProperty(strCustEndpoint, strCustEndpoint));
        strApiKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty("CUST_API_KEY"));
        strApiSecretKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty("CUST_API_SECRET_KEY"));
        strReadTimeOut = KohlsRestAPIUtil.getPropertyValue(props.getProperty("CUST_READ_TIME_OUT"));
        logger.debug("The strEndPoint value is:" + strEndPoint);
        logger.debug("The strDomian value is:" + strDomian);
        logger.debug("InDoc--->" + XMLUtil.getXMLString(inDoc));

        // Create payload
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();

        String sDayPhone = null;
        String sEmailID = null;
        if (XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@DayPhone") != null) {
            if (!XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@DayPhone").equals("")) {
                sDayPhone = XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@DayPhone");

            }
        }
        if (XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@EmailID") != null) {
            if (!XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@EmailID").equals("")) {

                sEmailID = XPathUtil.getString(inDoc.getDocumentElement(), "//CustomerContactList/CustomerContact/@EmailID");
            }
        }
        Value v = new Value();
        if (!YFCCommon.isVoid(sDayPhone)) {

            v.setValue(sDayPhone);
            strQueryParam = "alias=phn";

        }

        if (!YFCCommon.isVoid(sEmailID)) {

            v.setValue(sEmailID);
            strQueryParam = "alias=eml";

        }


        String jsonPayload = gson.toJson(v).toString();
        logger.debug("jsonPayload--->" + jsonPayload);

        SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
        String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
        String sFilePath = "";
        boolean bWriteToFile = true;
        sFileName = "CustomerLookup_" + timestamp + ".txt";

        try {
            sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
            restApiutil.writeToFile("Request is ----> \n", jsonPayload, sFileName, sFilePath);
        } catch (Exception ex) {
            bWriteToFile = false;
            logger.debug("Logger Dir does not exist. So moving on");
        }
        //System.out.println(gson.toJson(v).toString());
        //System.out.println("jsonPayload ::" + jsonPayload);


        // String
        // strCan=restApiUtil.concatSingleValueDEPHeaderParams(mapdepHeader);
        String strtempDomain = strDomian + strEndPoint + "?" + strQueryParam;
        //PST-444 Changes for CorrelationID
        //MJ 01/16 commented the correlation id for /v4/CustomerSearch
        //depHeaderMap.put("x-dep-correlation-id", KohlsPoCCommonAPIUtil.getCorrelationID());
        ResponseEntity<String> response = null;

        int count = 0;
        int iMaxTries = 1;
        try {
            iMaxTries = Integer.parseInt(KohlsPoCCommonAPIUtil.getRuleValuesfromDB(env));
        } catch (Exception e) {
            logger.debug("Max retries is set as " + iMaxTries + "time");
        }

        logger.debug("Max retries configured is  " + iMaxTries + "time");
        Exception throwBack = null;
        String respStatus = "503";
        while (count <= iMaxTries) {
            try {
                TreeMap<String, String> mapHeader = new TreeMap();
                mapHeader.put(KohlsPOCConstant.ACCEPT, "application/json");
                mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");

                String issodate = KohlsRestAPIUtil.getCurrentISODate();
                String strUuid = restApiutil.getUUID();
                final TreeMap<String, String> depHeaderMap = new TreeMap();
                depHeaderMap.put("x-dep-date", issodate);
                depHeaderMap.put("X-DEP-Date", issodate);
                depHeaderMap.put(KohlsPOCConstant.X_DEP_REQUEST_ID, strUuid);
                depHeaderMap.put("x-dep-from-system-code", "CH");
                depHeaderMap.put("x-dep-from-node", HostIpAddressNodeIdStrategy.getInstance().getNodeId());
                depHeaderMap.put("x-dep-from-app", "POC");
                count++;
                response = restApiutil.createConnection(jsonPayload, mapHeader,
                        depHeaderMap, strQueryParam, strtempDomain, strEndPoint,
                        strApiKey, strApiSecretKey, strReadTimeOut, strReadTimeOut, KohlsPOCConstant.CMDM, null, false, null, 0);
                if (response != null) {
                    respStatus = response.getStatusCode().toString();
                }
                if ("200".equals(respStatus) || "206".equals(respStatus)) {
                    String responseBody = response.getBody();
                    JSONObject json = new JSONObject(responseBody);
                    logger.debug("responseBody--->" + responseBody);
                    logger.debug("json1-->" + json.toString());

                    // System.out.println("json1-->" + json.toString());
                    if (bWriteToFile) {
                        try {
                            sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                            restApiutil.writeToFile("Response is ----> \n", responseBody, sFileName, sFilePath);
                        } catch (Exception ex) {
                            logger.debug("Logger Dir does not exist. So moving on");
                        }
                    }

                    docoutGetCustomer = setCustomerDetails(strQueryParam, json);
                    break;
                }
                // }
            } catch (YFSException e) {
                //Fix for defect 1380 - Start
                logger.error("Exception occurred while calling endpoint " + strtempDomain + strEndPoint, e);

                logger.debug("In Catch block: ");
                logger.debug("Error Code outside" + e.getErrorCode());
                logger.debug("Error Desc outside" + e.getErrorDescription());
                logger.debug("Error Cause outside" + e.getCause());
                if (count <= iMaxTries) {
                    logger.info("Customer List Lookup: Retry attempt : " + count +
                            ". Endpoint " + strtempDomain + strEndPoint);
                    continue;
                } else {
                    logger.info("Customer List Lookup: Maxed out number of attempts : " + count +
                            ". Endpoint " + strtempDomain + strEndPoint);
                }
                Throwable tmp = e;
                while (tmp != null) {
                    if (e.getErrorCode().equals(KohlsPOCConstant.NO_RECORD_FOUND)) {
                        e.setErrorCode(KohlsPOCConstant.NO_RECORD_FOUND);
                        e.setErrorDescription(KohlsPOCConstant.NO_RECORD_FOUND_DESC);
                        logger.debug("Exception has occured " + e.getErrorDescription());
                        throwBack = e;
                        break;
                    } else if (e.getErrorCode().equals(KohlsPOCConstant.SERVICE_UNAVAILABLE_503)) {
                        e.setErrorCode(KohlsPOCConstant.SERVICE_UNAVAILABLE);
                        e.setErrorDescription(KohlsPOCConstant.UNAVAILABLE_DESC);
                        logger.debug("Exception has occured " + e.getErrorDescription());
                        throwBack = e;
                        break;
                    } else if (e.getErrorCode().equals(KohlsPOCConstant.BAD_REQUEST) || e.getErrorCode().equals(KohlsPOCConstant.BAD_REQUEST_1)) {
                        e.setErrorCode(KohlsPOCConstant.BAD_REQUEST_CODE);
                        e.setErrorDescription(KohlsPOCConstant.BAD_REQUEST_DESC);
                        logger.debug("Exception has occured " + e.getErrorDescription());
                        throwBack = e;
                        break;
                    } else if (tmp.getCause() instanceof java.io.IOException
                            || tmp.getCause() instanceof java.net.SocketTimeoutException || e.getErrorCode().contains("java.net.SocketTimeoutException")) {
                        e.setErrorCode(KohlsPOCConstant.TIMED_OUT);
                        e.setErrorDescription(KohlsPOCConstant.UNAVAILABLE_DESC);
                        logger.debug("Exception has occured " + e.getErrorDescription());
                        throwBack = e;
                        break;
                    } else if (tmp.getCause() instanceof java.net.NoRouteToHostException || e.getErrorCode().contains("NoRouteToHostException")) {
                        logger.debug("Inside No Route");
                        e.setErrorCode(KohlsPOCConstant.TIMED_OUT);
                        e.setErrorDescription(KohlsPOCConstant.UNAVAILABLE_DESC);
                        logger.debug("Exception has occured " + e.getErrorDescription());
                        throwBack = e;
                        break;
                    }
                    tmp = tmp.getCause();

                }
                if (throwBack == null) {
                    logger.debug("The Error message from webservice is Generic. So throwing YFSException");
                    throwBack = e;
                }
                //Fix for defect 1380 - End
            } catch (Exception e) {
                logger.error("Exception occurred while calling endpoint " + strtempDomain + strEndPoint, e);

                if (count <= iMaxTries) {
                    logger.info("Customer List Lookup: Retry attempt : " + count +
                            ". Endpoint " + strtempDomain + strEndPoint);
                    continue;
                } else {
                    logger.info("Customer List Lookup: Maxed out number of attempts : " + count +
                            ". Endpoint " + strtempDomain + strEndPoint);
                }

                Throwable tmp = e;
                YFSException yfs1 = (YFSException) e;
                while (tmp != null) {
                    if (tmp.getCause() instanceof java.io.IOException
                            || tmp.getCause() instanceof java.net.SocketTimeoutException) {
                        logger.debug("The Error message from webservice response is " + tmp.getCause() + " So throwing EXTN_IO");
                        throwBack = new YFSException("java.net.ConnectException", KohlsPOCConstant.TIMED_OUT, KohlsPOCConstant.UNAVAILABLE_DESC);
                        break;
                    } else if (tmp.getCause() instanceof java.net.NoRouteToHostException || yfs1.getErrorCode().contains("NoRouteToHostException")) {
                        logger.debug("The Error message from webservice response is " + tmp.getCause() + "So throwing NO_ROUTE_TO_HOST");
                        throwBack = new YFSException("java.net.NoRouteToHostExceptions", KohlsPOCConstant.TIMED_OUT, KohlsPOCConstant.UNAVAILABLE_DESC);
                        break;
                    }
                    tmp = tmp.getCause();
                }
                if (throwBack == null) {
                    logger.debug("The Error message from webservice is Generic. So throwing YFSException");
                    throwBack = new YFSException(e.getMessage(), e.getCause().toString(), e.getMessage());
                }
            }
        }
        if (throwBack != null) {
            if ((throwBack instanceof YFSException) && !YFCCommon.isVoid(((YFSException) throwBack).getErrorCode())) {
                respStatus = ((YFSException) throwBack).getErrorCode();
            }
        }
        logger.endTimer("KohlsCustomerListRestAPI.getCustomerList");
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        logger.info("Customer List Lookup : getCustomerList took " + duration + "ms." + " Response status: " + respStatus +
                " Endpoint: " + strtempDomain + strEndPoint);
        if (throwBack != null) {
            logger.error("Customer List Lookup: getCustomerList rethrowing error: " + throwBack.getMessage());
            throw throwBack;
        }
        //Fix for defect 1380 - End
        return docoutGetCustomer;

    }

    private Document setCustomerDetails(String strQueryParam,
                                        JSONObject json) throws Exception {
        // TODO: let's extract this function to a new class and write a test for it
        String sToParse = "[" + json.toString() + "]";
        Gson outGson = new Gson();
        cls_customers customer = null;
        fromJSON[] parsedClass = outGson.fromJson(sToParse, fromJSON[].class); // input
        // is
        Document docoutGetCustomer = XMLUtil.newDocument();

        Element eleCustomerList = docoutGetCustomer.createElement("CustomerList");

        logger.debug("QueryParameter--->" + strQueryParam);

        for (int j = 0; j < parsedClass.length; j++) {
            logger.debug("Setting attributes--->");
            if (parsedClass[j].customers.length != 0) {
                for (int i = 0; i < parsedClass[j].customers.length; i++) {
                    Element eleCustomer = docoutGetCustomer.createElement("Customer");
                    Element eleCustomerContactList = docoutGetCustomer
                            .createElement("CustomerContactList");
                    Element eleCustomerContact = docoutGetCustomer
                            .createElement("CustomerContact");
                    Element eleExtn = docoutGetCustomer.createElement("Extn");
                    Element eleCustomerAddresList = docoutGetCustomer
                            .createElement("CustomerAdditionalAddressList");
                    Element eleCustomerAdditionalAddess = docoutGetCustomer
                            .createElement("CustomerAdditionalAddress");
                    Element elePersonInfo = docoutGetCustomer.createElement("PersonInfo");
                    customer = parsedClass[j].customers[i];
                    // set the pilot status
                    if (customer.pilotStatus) {
                        eleCustomer.setAttribute("PilotMember", "Y");
                    } else {
                        // not a pilot member
                        eleCustomer.setAttribute("PilotMember", "N");
                    }

                    if (!YFCCommon.isVoid(customer.existingEarnTrackerBal)) {
                        eleCustomer.setAttribute("ExistingEarnTrackerBal", customer.existingEarnTrackerBal);
                    }

                    if (customer.kohlsCash != null
                            && customer.kohlsCash.size() > 0) {
                        Element kohlsCashList = docoutGetCustomer.createElement("KohlsCashList");
                        for (int k = 0; k < customer.kohlsCash.size(); k++) {
                            Element currentKohlsCash = docoutGetCustomer.createElement("KohlsCash");
                            currentKohlsCash.setAttribute("Barcode", customer.kohlsCash.get(k).barcode);
                            currentKohlsCash.setAttribute("RedemptionStartDate", customer.kohlsCash.get(k).redemptionStartDate);
                            currentKohlsCash.setAttribute("RedemptionEndDate", customer.kohlsCash.get(k).redemptionEndDate);
                            currentKohlsCash.setAttribute("RemainingValue", customer.kohlsCash.get(k).remainingValue);
                            currentKohlsCash.setAttribute("EventTypeCode", customer.kohlsCash.get(k).eventTypeCode);
                            kohlsCashList.appendChild(currentKohlsCash);
                        }
                        eleCustomer.appendChild(kohlsCashList);
                    }

                    if (customer.loyaltyId != null) {
                        eleCustomer.setAttribute("CustomerRewardsNo", customer.loyaltyId);
                        if (customer.customerName.loyalty != null) {
                            if (customer.customerName.loyalty.first != null) {
                                eleCustomerContact.setAttribute(
                                        "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.first));
                                elePersonInfo.setAttribute(
                                        "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.first));
                            }
                            if (customer.customerName.loyalty.last != null) {
                                eleCustomerContact.setAttribute(
                                        "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.last));
                                elePersonInfo.setAttribute(
                                        "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.last));
                            }
                            if (customer.customerName.loyalty.middle != null) {
                                eleCustomerContact.setAttribute(
                                        "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.middle));
                                elePersonInfo.setAttribute(
                                        "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.loyalty.middle));
                            }
                            if (customer.customerName.loyalty.professionalTitle != null) {
                                eleCustomerContact.setAttribute(
                                        "jobTitle", customer.customerName.loyalty.professionalTitle);
                                elePersonInfo.setAttribute(
                                        "jobTitle", customer.customerName.loyalty.professionalTitle);
                            }
                        }
                        if (customer.phoneNumber.loyalty != null) {
                            eleCustomerContact.setAttribute("DayPhone", customer.phoneNumber.loyalty);
                        }
                        if (customer.addressLine1.loyalty != null) {
                            elePersonInfo.setAttribute("AddressLine1", customer.addressLine1.loyalty);
                        }
                        if (customer.postalCode.loyalty != null) {
                            elePersonInfo.setAttribute("ZipCodeLoyalty", customer.postalCode.loyalty);
                            elePersonInfo.setAttribute("ZipCode", customer.postalCode.loyalty);
                        }
                        if (customer.postalCode.kohlsCharge != null) {
                            elePersonInfo.setAttribute("ZipCodeKohlsCharge", customer.postalCode.kohlsCharge);
                        }
                        if (customer.postalCode.ecom != null) {
                            elePersonInfo.setAttribute("ZipCodeEcom", customer.postalCode.ecom);
                        }
                        if (customer.customerName.kohlsCharge != null
                                && customer.customerName.kohlsCharge.first != null) {
                            eleExtn.setAttribute("ExtnKohlsCharge", "Y");
                        } else {
                            eleExtn.setAttribute("ExtnKohlsCharge", "N");
                        }

                        eleExtn.setAttribute("ExtnNameSource", "R");
                        eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
                        eleExtn.setAttribute("ExtnRewardsStatus", "Y");
                        eleExtn.setAttribute("ExtnLoyaltyPointTotal", "");
                        eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
                        eleExtn.setAttribute("ExtnMVCStatusSrc", "R");
                        eleExtn.setAttribute("ExtnRewardsStatusSrc", "R");

                        if (!YFCCommon.isVoid(customer.kohlsCash) && customer.kohlsCash.size() > 0) {

                            for (int k = 0; k < customer.kohlsCash.size(); k++) {
                                XMLUtil.createChild(eleExtn, "ExtnKohlsCash");
                                cls_kohlsCash kohlscashDtls = customer.kohlsCash.get(k);
                                eleExtn.setAttribute("Barcode", kohlscashDtls.barcode);
                                eleExtn.setAttribute("RedemptionStartDate", kohlscashDtls.redemptionStartDate);
                                eleExtn.setAttribute("RedemptionEndDate", kohlscashDtls.redemptionEndDate);
                                eleExtn.setAttribute("RemainingValue", kohlscashDtls.remainingValue);
                            }
                        }
                    } else {
                        if (customer.loyaltyId != null) {
                            eleCustomer.setAttribute("CustomerRewardsNo", customer.loyaltyId);
                            eleExtn.setAttribute("ExtnRewardsStatusSrc", "K");
                            eleExtn.setAttribute("ExtnRewardsStatus", "Y");
                        } else {
                            eleExtn.setAttribute("ExtnRewardsStatusSrc", "N");
                            eleExtn.setAttribute("ExtnRewardsStatus", "N");
                        }
                        if (customer.customerName.kohlsCharge != null) {
                            if (customer.customerName.kohlsCharge.first != null) {
                                eleCustomerContact.setAttribute(
                                        "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.first));
                                elePersonInfo.setAttribute(
                                        "FirstName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.first));
                            }
                            if (customer.customerName.kohlsCharge.last != null) {
                                eleCustomerContact.setAttribute(
                                        "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.last));
                                elePersonInfo.setAttribute(
                                        "LastName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.last));

                            }
                            if (customer.customerName.kohlsCharge.middle != null) {
                                eleCustomerContact.setAttribute(
                                        "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.middle));
                                elePersonInfo.setAttribute(
                                        "MiddleName", KOHLSStringUtil.normalizeStringForPOSPrinter(customer.customerName.kohlsCharge.middle));
                            }
                            if (customer.customerName.kohlsCharge.professionalTitle != null) {
                                eleCustomerContact.setAttribute(
                                        "jobTitle", customer.customerName.kohlsCharge.professionalTitle);
                                elePersonInfo.setAttribute(
                                        "jobTitle", customer.customerName.kohlsCharge.professionalTitle);
                            }
                        }
                        if (customer.phoneNumber.kohlsCharge != null) {
                            eleCustomerContact.setAttribute("DayPhone", customer.phoneNumber.kohlsCharge);
                        }
                        if (customer.addressLine1.kohlsCharge != null) {
                            elePersonInfo.setAttribute("AddressLine1", customer.addressLine1.kohlsCharge);
                        }
                        if (customer.postalCode.kohlsCharge != null) {
                            elePersonInfo.setAttribute("ZipCode", customer.postalCode.kohlsCharge);
                        }
                        eleExtn.setAttribute("ExtnKohlsCharge", "Y");
                        eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
                        eleExtn.setAttribute("ExtnLoyaltyPointTotal", "");
                        eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "K");
                        eleExtn.setAttribute("ExtnMVCStatusSrc", "K");
                        eleExtn.setAttribute("ExtnNameSource", "K");
                    }
                    if (customer.kohlsChargeMvcIndicator) {
                        eleExtn.setAttribute("ExtnMVCStatus", "Y");
                        if (customer.loyaltyId != null) {
                            eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
                            eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "R");
                        } else {
                            eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
                            eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
                        }
                    } else {
                        eleExtn.setAttribute("ExtnMVCStatus", "N");
                    }
                    if (customer.customerName.kohlsCharge != null
                            || customer.addressLine1.kohlsCharge != null
                            || customer.postalCode.kohlsCharge != null
                            || customer.phoneNumber.kohlsCharge != null) {
                        eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
                        eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "R");
                    } else {
                        eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
                        eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
                    }

                    if (customer.associateDiscountID != null) {
                        eleCustomer.setAttribute("CustomerAssociateNo",
                                customer.associateDiscountID);
                        eleCustomer.setAttribute("AssociateId",
                                customer.associateDiscountID);
                    } else {
                        eleCustomer.setAttribute("CustomerAssociateNo", "");
                        eleCustomer.setAttribute("AssociateId", "");
                    }
                    if ((customer.emailAddress.EReceipt != null)
                            && (!customer.emailAddress.EReceipt
                            .equals(""))) {
                        eleCustomerContact.setAttribute(
                                "EmailID", customer.emailAddress.EReceipt);
                    } else if ((customer.emailAddress.ecom != null)
                            && (!customer.emailAddress.ecom
                            .equals(""))) {
                        eleCustomerContact.setAttribute("EmailID",
                                customer.emailAddress.ecom);
                    } else if ((customer.emailAddress.kohlsCharge != null)
                            && (!customer.emailAddress.kohlsCharge
                            .equals(""))) {
                        eleCustomerContact.setAttribute("EmailID",
                                customer.emailAddress.kohlsCharge);
                    } else if ((customer.emailAddress.loyalty != null)
                            && (!customer.emailAddress.loyalty
                            .equals(""))) {
                        eleCustomerContact.setAttribute("EmailID",
                                customer.emailAddress.loyalty);
                    } else {
                        eleCustomerContact.setAttribute("EmailID", "");

                    }
                    if ((customer.associateDiscountID != null)
                            && (!customer.associateDiscountID
                            .equals(""))) {
                        eleExtn.setAttribute("ExtnIsEmployee", "Y");
                        eleExtn.setAttribute("ExtnCustomerAssociateNo", customer.associateDiscountID);
                    } else {
                        eleExtn.setAttribute("ExtnIsEmployee", "N");
                        eleExtn.setAttribute("ExtnCustomerAssociateNo", customer.associateDiscountID);
                    }

                    if ((customer.vip)) {
                        eleExtn.setAttribute("ExtnKohlsChargeVIP", "Y");
                    } else {
                        eleExtn.setAttribute("ExtnKohlsChargeVIP", "N");

                    }
                    eleCustomerList.appendChild(eleCustomer);

                    eleCustomer.appendChild(eleCustomerContactList);
                    eleCustomerContactList.appendChild(eleCustomerContact);
                    eleCustomerContact.appendChild(eleExtn);
                    eleCustomerContact.appendChild(eleCustomerAddresList);
                    eleCustomerAddresList.appendChild(eleCustomerAdditionalAddess);
                    eleCustomerAdditionalAddess.appendChild(elePersonInfo);
                }
                docoutGetCustomer.appendChild(eleCustomerList);
            }
            if (parsedClass[j].customers.length == 0) {
                //System.out.println("in the else section");
                YFSException yfsException = new YFSException();
                yfsException.setErrorCode("NO_RECORD_FOUND");
                yfsException.setErrorDescription(KohlsPOCConstant.NO_RECORD_FOUND_DESC);
                throw yfsException;
            }
        }
        return docoutGetCustomer;
    }

    // probably called by OMS system
    // NOT going to come from COP files
    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
        //LOG_CAT.debug("In the set properties method");
    }

    public String getPropertyValue(String property) {
        logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        // Manoj 10/22: updated to use configured property if
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
        return propValue;
    }
}