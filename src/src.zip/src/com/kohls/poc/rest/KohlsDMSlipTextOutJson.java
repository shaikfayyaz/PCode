package com.kohls.poc.rest;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



	public class KohlsDMSlipTextOutJson {
		@SerializedName("dispositionUISlipTexts")
		@Expose
		private List<DispositionUISlipText> dispositionUISlipTexts = null;
		
		

		public List<DispositionUISlipText> getDispositionUISlipTexts() {
			return dispositionUISlipTexts;
		}

		public void setDispositionUISlipTexts(List<DispositionUISlipText> dispositionUISlipTexts) {
			this.dispositionUISlipTexts = dispositionUISlipTexts;
		}
		
		
		
		
		public class DispositionUISlipText {

			@SerializedName("dispositionCode")
			@Expose
			private String dispositionCode;
			@SerializedName("barcodeType")
			@Expose
			private String barcodeType;
			@SerializedName("codes")
			@Expose
			private List<String> codes = null;
			
			@SerializedName("slipText")
			@Expose
			private Map<String, Object> slipText = new HashMap<String, Object>();
			
			

			public String getDispositionCode() {
				return dispositionCode;
			}

			public void setDispositionCode(String dispositionCode) {
				this.dispositionCode = dispositionCode;
			}
			
			public String getBarcodeType() {
				return barcodeType;
			}

			public void setBarCodeType(String barcodeType) {
				this.barcodeType = barcodeType;
			}

			public List<String> getCodes() {
				return codes;
			}

			public void setCodes(List<String> codes) {
				this.codes = codes;
			}

			public Map<String, Object> getSlipText() {
				return this.slipText;
			}

			public void setSlipText(String name, Object value) {
				this.slipText.put(name, value);
			}
			

		}

		public class SlipText {

			@SerializedName("dispositionCode")
			@Expose
			private String dispositionCode;
			
			@SerializedName("slip1")
			@Expose
			private String slip1;
			
			@SerializedName("slip2")
			@Expose
			private String slip2;
			
			@SerializedName("slip3")
			@Expose
			private String slip3;
			
			@SerializedName("slip4")
			@Expose
			private String slip4;
			
			@SerializedName("pocUI")
			@Expose
			private String pocUI;
			
			@SerializedName("codes")
			@Expose
			private List<String> codes = null;
			

			public String getDispositionCode() {
				return dispositionCode;
			}

			public void setDispositionCode(String dispositionCode) {
				this.dispositionCode = dispositionCode;
			}
			
			public String getSlip1() {
				return slip1;
			}

			public void setSlip1(String slip1) {
				this.slip1 = slip1;
			}
			
			public String getSlip2() {
				return slip2;
			}

			public void setSlip2(String slip2) {
				this.slip2 = slip2;
			}
			
			public String getSlip3() {
				return slip3;
			}

			public void setSlip3(String slip3) {
				this.slip3 = slip3;
			}
			
			public String getSlip4() {
				return slip1;
			}

			public void setSlip4(String slip4) {
				this.slip4 = slip4;
			}
			
			public String getPocUI() {
				return pocUI;
			}

			public void setPocUI(String pocUI) {
				this.pocUI = pocUI;
			}

			
			

		}

	}
