package com.kohls.poc.rest;


import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.util.webserviceUtil.FailoverUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : RestClientWithFailover.java Author : RajeshG Created : June 01 2016 Modified :
 * June 01 2016 Version : 1.0
 ***************************************************************************** 
 * ***************************************************************************
 * Copyright @ 2016. This document is in copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Java component is implemented to make REST call and it can be used 
 * for any functionality that needs to make REST call with fail over mechanism
 * and if fail over mechanism is not needed.It can be used even if fail over is not required.
 * It has flag to specify if REST needs to support auth or not * 
 * @author Rajesh G
 * @version 1.0
 *****************************************************************************/

public class RestClientWithFailover implements YIFCustomApi {

    private static YFCLogCategory LOG_CAT = YFCLogCategory
            .instance(RestClientWithFailover.class);
    FailoverUtil fs = FailoverUtil.getInstance();
    boolean isMonitored = false;
    private  SimpleDateFormat sdf = null;
    private String timestamp = null;
    KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
    boolean isPrimary = false;
    boolean isBackup = false;
    boolean isOffline = false; 
    String activeEndpoint = "";
    String strEndPoint = "";

    /**
     * This represents the constructor for the 
     *  RestClientWithFailover
     * @throws Exception
     */
    public RestClientWithFailover() throws Exception {
        super();
    }


    /**
     * This method is starting point for the REST call.
     * Client that wants to make REST call needs to pass the required parameters  
     * @param payload
     * @param mapHeader
     * @param depHeaderMap
     * @param strQueryParam
     * @param endPoint
     * @param strApiKey
     * @param strApiSecretKey
     * @param strReadTimeOut
     * @param trustCertificate
     * @param enableAuth
     * @param methodName
     * @param module
     * @return
     * @throws Exception 
     */
    public ResponseEntity<String> executeRESTcall(String payload,
            TreeMap<String, String> mapHeader,
            TreeMap<String, String> depHeaderMap, String strQueryParam,
            String endPoint, String strApiKey, String strApiSecretKey,
            String strReadTimeOut, String trustCertificate, boolean enableAuth,String methodName,String module,String appendOnURL) throws Exception {

       LOG_CAT.beginTimer(" Start RestClientWithFailover.executeRESTcall");

       ResponseEntity<String> response = null;
       RestTemplate restTemplate = null;
       HttpEntity<String> request = null;
       boolean buildSignature = enableAuth;

       if(YFCCommon.isVoid(timestamp)){
    	   		sdf = new SimpleDateFormat("ddHHmmss");
           timestamp = sdf.format(YFCDateUtils.getCurrentDate(true)); 
       }
      
       String logfilePath = "/logs/apps/of/"+module;
       if(YFCCommon.isVoid(strEndPoint))
       {
    	   			try
    	   			{
    	   				strEndPoint = fs.getActiveEndPoint(endPoint);
                   if(YFCCommon.isVoid(activeEndpoint)) 
                   {
                	   		activeEndpoint = fs.getCurrentActiveEndpoint(endPoint);
                    
                   }   
    	   			}
               catch(Exception e)
               {
            	   	   activeEndpoint = "OFFLINE";
            	   	   restApiutil.writeToFile(module+" is "+activeEndpoint,
                  		  "",module+"_"+timestamp,logfilePath);
  	   	           String cffFilePath = "/logs/apps/of/CFF"; 
  	   	           String fileNameSuffix = null;
  	   	           if(!YFCCommon.isVoid(module))
  	   	           {
  	   	               fileNameSuffix = module;
  	   	           }
  	   	           else
  	   	           {
  	   	               fileNameSuffix = "RESTCLIENT_";
  	   	           }
  	   	           restApiutil.writeToFile(module+"--->\n",
  	   	           fs.getWsProperties().toString(),"CFF_"+fileNameSuffix+"_"+timestamp,cffFilePath);
                   throw new YFSException("EXTN_OTHER-OFFLINE",
                           KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER);
               }
    	   		   finally {
    	   	          
    	   	       }
       }
       try { 
              
          
           HttpHeaders httpHeaders = createHttpHeadForREST(payload, mapHeader,
                   depHeaderMap, strQueryParam, strEndPoint, strApiKey,
                   strApiSecretKey, buildSignature, methodName,module,appendOnURL);

           request = new HttpEntity<String>(payload, httpHeaders);
           // cert
           HttpComponentsClientHttpRequestFactory requestFactory = null;
           if ("Y".trim().equalsIgnoreCase(trustCertificate)
                   || "y".trim().equalsIgnoreCase(trustCertificate)) {

               TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                   @SuppressWarnings("unused")
                   public boolean isTrusted(X509Certificate[] certificate,
                           String type) {
                       return true;
                   }

               };

               SSLContext sslContext = org.apache.http.ssl.SSLContexts
                       .custom()
                       .loadTrustMaterial(null, acceptingTrustStrategy)
                       .build();

               SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(
                       sslContext);

               CloseableHttpClient httpClient = HttpClients.custom()
                       .setSSLSocketFactory(csf).build();
               
               httpClient.getParams().setIntParameter("http.connection.timeout", Integer.parseInt(strReadTimeOut));

               requestFactory = new HttpComponentsClientHttpRequestFactory();

               requestFactory.setHttpClient(httpClient);
               //requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));
           } else {
               
                   
               requestFactory = new HttpComponentsClientHttpRequestFactory();
               DefaultHttpClient httpClient = new DefaultHttpClient();
               httpClient.getParams().setIntParameter("http.connection.timeout", Integer.parseInt(strReadTimeOut));
               requestFactory.setHttpClient(httpClient);
               requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));
               
           }

           // cert
           if (LOG_CAT.isDebugEnabled() && null != request) {

               LOG_CAT.debug("###### Request is ##### : \n"
                       + "Header Details:" + request.getHeaders()
                       + "Body Content:" + request.getBody());

           }
           
           LOG_CAT.debug("###### End point URL is ##### : " + strEndPoint+appendOnURL);
           if( null != request){
        	   if("TVSSUPCREDEEM".equalsIgnoreCase(module)){
        		   restApiutil.writeToFile(module+" Request to "+activeEndpoint+" for Coupon # --> "+appendOnURL+" is --->\n",
                		   request.getBody().toString()+"\n" ,module+"_"+timestamp,logfilePath);
        	   }
        	   else
        	   {
        		   restApiutil.writeToFile(module+" Request to "+activeEndpoint+" is --->\n",
                		   request.getBody().toString()+"\n" ,module+"_"+timestamp,logfilePath);
        	   }
          
           }
           if (LOG_CAT.isDebugEnabled()) {
               if( null != request){
               LOG_CAT.debug("###### Request to " +module+ " is ##### : \n"
                       + request.getBody());
               
               LOG_CAT.debug("###### Request Headers " +module+ " is ##### : \n"
                       + request.getHeaders());
               }else{
                   LOG_CAT.debug("###### Request " +module+ " is ##### : null request \n");
               }
               
           }
           
           restTemplate = new RestTemplate(requestFactory);
           long beginTime = System.currentTimeMillis();
           if("TVSSUPCREDEEM".equalsIgnoreCase(module)){
             response = restTemplate.exchange(strEndPoint+appendOnURL,HttpMethod.PUT ,
                 request, String.class);
           }else{
             response = restTemplate.exchange(strEndPoint+appendOnURL,HttpMethod.POST ,
                 request, String.class);
           }
           if( null != response){
        	   
        	   	   long endTime = System.currentTimeMillis();
               long responseTime = endTime - beginTime;
               LOG_CAT.info("REST WebService Enpoint - " + strEndPoint+appendOnURL + " took " + responseTime + " ms StatusCode " + response.getStatusCode());
               restApiutil.writeToFile(module+" Response from "+activeEndpoint+" is --->\n",
            		   response.getBody().toString()+"\n" ,module+"_"+timestamp,logfilePath);
               }      
           if (LOG_CAT.isDebugEnabled()) {
               if(null != response){
                   LOG_CAT.debug("###### Response from " +module+ " is ##### : \n"
                           + response.getBody());
                   LOG_CAT.debug("###### Response Headers from " +module+ " is ##### : \n"
                           + response.getHeaders());
               }else{
                   LOG_CAT.debug("###### Response from " +module+ " is ##### : null request \n");
               }

           }

           if (!YFCCommon.isVoid(response) && fs.isEndpointMonitored(endPoint)) {
                   fs.resetFailedCounter(endPoint, activeEndpoint);
           }
           


           if (isError(response.getStatusCode())) {
               LOG_CAT.debug("ERROR | " + response.getStatusCode());
               return response;
           } else {
               return response;
           }

       } catch (Exception e) {
    	     if(!fs.isEndpointMonitored(endPoint))
    	     {
    	    	 	activeEndpoint = "CORP";
    	     }
         LOG_CAT.error("RestClientWithFailover.executeRESTcall error ---> ",e);
         restApiutil.writeToFile(module+" Error from "+activeEndpoint+" is --->\n",
        		   e.toString()+"\n",module+"_"+timestamp,logfilePath);
         Throwable tmp = e;
         if(fs.isEndpointMonitored(endPoint) && (tmp.getCause() instanceof java.io.IOException
                 || tmp.getCause() instanceof java.net.SocketTimeoutException
                 || tmp.getCause() instanceof java.net.ConnectException
                 || tmp.getCause() instanceof java.net.NoRouteToHostException 
                 || tmp.getCause() instanceof java.net.UnknownHostException
                 || tmp.getCause() instanceof java.lang.IllegalArgumentException || e.toString().contains("500") || e.toString().contains("503")))
         {
        	 	                  
             fs.compareAndIncrementCounters(endPoint, activeEndpoint);
               if ("PRIMARY".equalsIgnoreCase(activeEndpoint)) {
                    strEndPoint = fs.getBackupEndpoint(endPoint); 
                    activeEndpoint = "BACKUP";
                       response = executeRESTcall(payload, mapHeader, depHeaderMap,
                                strQueryParam, endPoint, strApiKey, strApiSecretKey,
                                strReadTimeOut, trustCertificate, buildSignature,methodName,module,appendOnURL);
               }
               else
               {
                    if(e instanceof YFSException){
                        throw e;
                        
                    } else{
                      
                       YFSException yfs= new YFSException();
                       
                      if(null != e.getCause()){
                          yfs.setErrorCode(e.getCause().toString());
                          
                      }else{
                          yfs.setErrorCode("UnknownError");
                      }
                      
                      if(null != e.getMessage()){
                          yfs.setErrorDescription(e.getMessage());                
                      }else{
                          yfs.setErrorDescription("Unknown Error From OMS System");
                      }
                      throw yfs;                
                    }
               }
              
         }
         else
         {
             if(e instanceof YFSException){
                 throw e;
                 
             } else{
               
                YFSException yfs= new YFSException();
                
               if(null != e.getCause()){
                   yfs.setErrorCode(e.getCause().toString());
                   
               }else{
                   yfs.setErrorCode("UnknownError");
               }
               
               if(null != e.getMessage()){
                   yfs.setErrorDescription(e.getMessage());                
               }else{
                   yfs.setErrorDescription("Unknown Error From OMS System");
               }
               throw yfs;                
             }
             
         }           
           
       } finally {
           LOG_CAT.debug("Properties at the end::" + fs.getWsProperties());
           String cffFilePath = "/logs/apps/of/CFF"; 
             
           LOG_CAT.debug("wsProperties at the end::"+fs.getWsProperties());
           String fileNameSuffix = null;
           if(!YFCCommon.isVoid(module))
           {
               fileNameSuffix = module;
           }
           else
           {
               fileNameSuffix = "RESTCLIENT_";
           }
           restApiutil.writeToFile(module+"--->\n",
       fs.getWsProperties().toString(),"CFF_"+fileNameSuffix+"_"+timestamp,cffFilePath);
       }
       LOG_CAT.beginTimer(" End RestClientWithFailover.executeRESTcall");
       
       return response;

   
    }
    
    
    
    /**
     * This method is starting point for the REST call.
     * Client that wants to make REST call needs to pass the required parameters
     * @param payload
     * @param mapHeader
     * @param depHeaderMap
     * @param strQueryParam
     * @param endPoint
     * @param strApiKey
     * @param strApiSecretKey
     * @param strReadTimeOut
     * @param trustCertificate
     * @param enableAuth
     * @param methodName
     * @param module
     * @return
     * @throws Exception
     */
    public ResponseEntity<String> executeRESTcall(String payload,
                                                  TreeMap<String, String> mapHeader,
                                                  TreeMap<String, String> depHeaderMap, String strQueryParam,
                                                  String domain, String endPoint, String strApiKey, String strApiSecretKey,
                                                  String strReadTimeOut, String trustCertificate, boolean enableAuth,String methodName,String module) throws Exception {

        LOG_CAT.beginTimer(" Start RestClientWithFailover.executeRESTcall");

        ResponseEntity<String> response = null;
        RestTemplate restTemplate = null;
        HttpEntity<String> request = null;
        boolean buildSignature = enableAuth;

        String strEndPoint = endPoint;
        String strDomain = domain;

        String monitoredURL = YFSSystem.getProperty(strEndPoint + KohlsPOCConstant.STRING_DOT_MONITORED);
        String backupURL = YFSSystem.getProperty(strEndPoint
                + KohlsPOCConstant.STRING_DOT_BACKUP_ENDPOINT);

        try {

            if (!YFCCommon.isVoid(monitoredURL)) {
                isMonitored = true;
            }

            strEndPoint = getEndPoint(endPoint, strEndPoint, backupURL);

            HttpHeaders httpHeaders = createHttpHeadForREST(payload, mapHeader,
                    depHeaderMap, strQueryParam, strEndPoint, strApiKey,
                    strApiSecretKey, buildSignature, methodName,module);

            request = new HttpEntity<String>(payload, httpHeaders);
            HttpStatus statusCode = null;
            // cert
            HttpComponentsClientHttpRequestFactory requestFactory = null;
            if ("Y".trim().equalsIgnoreCase(trustCertificate)
                    || "y".trim().equalsIgnoreCase(trustCertificate)) {

                TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                    @SuppressWarnings("unused")
                    public boolean isTrusted(X509Certificate[] certificate,
                                             String type) {
                        return true;
                    }

                };

                SSLContext sslContext = org.apache.http.ssl.SSLContexts
                        .custom()
                        .loadTrustMaterial(null, acceptingTrustStrategy)
                        .build();

                SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(
                        sslContext);

                CloseableHttpClient httpClient = HttpClients.custom()
                        .setSSLSocketFactory(csf).build();
                
                httpClient.getParams().setIntParameter("http.connection.timeout", Integer.parseInt(strReadTimeOut));

                requestFactory = new HttpComponentsClientHttpRequestFactory();

                requestFactory.setHttpClient(httpClient);
                //requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));
            } else {
                
                    
                requestFactory = new HttpComponentsClientHttpRequestFactory();
                DefaultHttpClient httpClient = new DefaultHttpClient();
                httpClient.getParams().setIntParameter("http.connection.timeout", Integer.parseInt(strReadTimeOut));
                requestFactory.setHttpClient(httpClient);
                requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));
                
            }

            // cert
            if (LOG_CAT.isDebugEnabled() && null != request) {

                LOG_CAT.debug("###### Request is ##### : \n"
                        + "Header Details:" + request.getHeaders()
                        + "Body Content:" + request.getBody());

            }

            LOG_CAT.debug("###### End point URL is ##### : " + strEndPoint);

            if (LOG_CAT.isDebugEnabled()) {
                if( null != request){
                    LOG_CAT.debug("###### Request to DSB is ##### : \n"
                            + request.getBody());
                    LOG_CAT.debug("###### Request Headers to DSB  is ##### : \n"
                            + request.getHeaders());
                }else{
                    LOG_CAT.debug("###### Request to DSB is ##### : null request \n");
                }

            }

            restTemplate = new RestTemplate(requestFactory);
            response = restTemplate.exchange(strDomain+strEndPoint, HttpMethod.POST,
                    request, String.class);

            if (LOG_CAT.isDebugEnabled()) {
                if(null != response){
                    LOG_CAT.debug("###### Response From DSB  is ##### : \n"
                            + response.getBody());
                    LOG_CAT.debug("###### Response Headers From DSB  is ##### : \n"
                            + response.getHeaders());
                }else{
                    LOG_CAT.debug("###### Response from DSB is ##### : null request \n");
                }

            }

            if (!YFCCommon.isVoid(response) && isMonitored) {
                if (isBackup) {
                    fs.resetFailedCounter(endPoint, KohlsPOCConstant.STRING_BACKUP);
                } else {
                    fs.resetFailedCounter(endPoint, KohlsPOCConstant.STRING_PRIMARY);
                }
            }


            String responseBody = response.getBody();
            statusCode = response.getStatusCode();

            if (isError(response.getStatusCode())) {
                LOG_CAT.debug("ERROR | " + response.getStatusCode());
                return response;
            } else {
                return response;
            }

        } catch (Exception e) {

            LOG_CAT.error(e);
            e.printStackTrace();
            if (!isMonitored) {
                LOG_CAT.debug("The Error message from webservice is Generic. So throwing EXTN_OTHER");
                if(e instanceof YFSException){
                    throw e;

                } else{

                    YFSException yfs= new YFSException();

                    if(null != e.getCause()){
                        yfs.setErrorCode(e.getCause().toString());

                    }else{
                        yfs.setErrorCode("UnknownError");
                    }

                    if(null != e.getMessage()){
                        yfs.setErrorDescription(e.getMessage());
                    }else{
                        yfs.setErrorDescription("Unknown Error From OMS System");
                    }
                    throw yfs;
                }

            } else {
                response = validateAndRetryBackup(payload, mapHeader,
                        depHeaderMap, strQueryParam, domain, endPoint, strApiKey,
                        strApiSecretKey, strReadTimeOut, response,
                        backupURL, trustCertificate, buildSignature,methodName,module);
            }

        } finally {
            LOG_CAT.debug("Properties at the end::" + fs.getWsProperties());
        }
        LOG_CAT.beginTimer(" End RestClientWithFailover.executeRESTcall");
        return response;

    }
    
    
    
    
    
    

    /**
     * This method will be used to determine the Endpoint
     * that needs to used for this call.
     * This will use flag to determine if it is primary and uses FailoverUtil
     * to check JRE map values
     * @param endPoint
     * @param strEndPoint
     * @param backupURL
     * @return
     */
    private String getEndPoint(String endPoint, String strEndPoint,
            String backupURL) {
        if (isMonitored) {
            if (!isBackup) {
                strEndPoint = fs.getEndPointToCall(endPoint);
                LOG_CAT.debug("Endpoint to call::" + strEndPoint);
                if (strEndPoint.contains(KohlsPOCConstant.STRING_PRIMARY)) {
                    strEndPoint = this.getPropertyValue(endPoint
                            + KohlsPOCConstant.STRING_DOT_MONITORED);
                    isPrimary = true;
                } else if (strEndPoint.contains(KohlsPOCConstant.STRING_BACKUP)) {
                    strEndPoint = this.getPropertyValue(endPoint
                            + KohlsPOCConstant.STRING_DOT_BACKUP_ENDPOINT);
                    isBackup = true;
                } else if (strEndPoint.contains("OFFLINE")) {
                    isOffline = true;
                    throw new YFSException("EXTN_OTHER-OFFLINE",
                            KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER);
                }
            } else {
                if (!YFCCommon.isVoid(backupURL)) {
                    strEndPoint = this.getPropertyValue(endPoint
                            + KohlsPOCConstant.STRING_DOT_BACKUP_ENDPOINT);
                } else {
                    isOffline = true;
                    throw new YFSException("EXTN_OTHER-OFFLINE",
                            KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER);
                }
            }
        } else {
            strEndPoint = getPropertyValue(strEndPoint);
            LOG_CAT.debug("The strEndPoint value for other urls is "
                    + strEndPoint);
        }
        return strEndPoint;
    }

    
    /**
     * This is method will be called if connecting end point
     * fails to response. It will determine if call needs to be made
     * on secondary server or need to post the connection exception
     * to caller
     * @param payload
     * @param mapHeader
     * @param depHeaderMap
     * @param strQueryParam
     * @param endPoint
     * @param strApiKey
     * @param strApiSecretKey
     * @param strReadTimeOut
     * @param response
     * @param backupURL
     * @param trustCertificate
     * @param buildSignature
     * @param methodName
     * @param module
     * @return
     * @throws Exception
     */
    private ResponseEntity<String> validateAndRetryBackup(String payload,
                                                          TreeMap<String, String> mapHeader,
                                                          TreeMap<String, String> depHeaderMap, String strQueryParam,
                                                          String domain, String endPoint, String strApiKey, String strApiSecretKey,
                                                          String strReadTimeOut, ResponseEntity<String> response,
                                                          String backupURL, String trustCertificate, boolean buildSignature,String methodName,String module) throws Exception {
        LOG_CAT.debug("In Catch");
        LOG_CAT.debug("isMonitored:::" + isMonitored);
        LOG_CAT.debug("offline:::" + isOffline);
        LOG_CAT.debug("backup:::" + isBackup);
        if (isOffline) {
            LOG_CAT.debug("In Offline. The Error message from webservice is Generic. So throwing EXTN_OTHER");
            throw new YFSException("EXTN_OTHER-OFFLINE",KohlsPOCConstant.STRING_EXTN_OTHER,
                    KohlsPOCConstant.STRING_EXTN_OTHER);
        } else if (isBackup) {
            LOG_CAT.debug("No response from Backup. The Error message from webservice is Generic. So throwing EXTN_OTHER");
            fs.incrementFailedCounter(endPoint, KohlsPOCConstant.STRING_BACKUP);
            fs.compareFailedThreshold(endPoint, KohlsPOCConstant.STRING_BACKUP,
                    !YFCCommon.isVoid(backupURL));
            throw new YFSException(KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER);
        } else {

            LOG_CAT.debug("No response from primary");
            fs.incrementFailedCounter(endPoint, KohlsPOCConstant.STRING_PRIMARY);
            fs.compareFailedThreshold(endPoint, KohlsPOCConstant.STRING_PRIMARY,
                    !YFCCommon.isVoid(backupURL));
            isBackup = true;
            response = executeRESTcall(payload, mapHeader, depHeaderMap,
                    strQueryParam, domain, endPoint, strApiKey, strApiSecretKey,
                    strReadTimeOut, trustCertificate, buildSignature,methodName,module);
        }
        return response;
    }
    
    
    

    /* (non-Javadoc)
     * @see com.yantra.interop.japi.YIFCustomApi#setProperties(java.util.Properties)
     */
    public void setProperties(Properties prop) throws Exception {
        LOG_CAT.debug("In the set properties method");

    }
    

    /**
     * This will check the property in COP
     * otherwise it will use the paroperty name passed as
     * value
     * @param property
     * @return
     */
    public String getPropertyValue(String property) {
        LOG_CAT.beginTimer("RestClientWithFailover.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        LOG_CAT.endTimer("RestClientWithFailover.getPropertyValue");
        return propValue;

    }

    /**
     * This method is used to build the request for REST call
     * it also checks the security file to
     * get actual password
     * @param payload
     * @param mapHeader
     * @param depHeaderMap
     * @param strQueryParam
     * @param strEndPoint
     * @param strApiKey
     * @param strApiSecretKey
     * @param buildSignature
     * @param httpMethod
     * @param module
     * @return
     * @throws Exception
     */
    public HttpHeaders createHttpHeadForREST(String payload,
            TreeMap<String, String> mapHeader,
            TreeMap<String, String> depHeaderMap, String strQueryParam,
            String strEndPoint, String strApiKey, String strApiSecretKey,
            boolean buildSignature, String httpMethod,String module,String appendOnURL) throws Exception {
        
        KohlsRestAPIUtil restUtil = new KohlsRestAPIUtil();
        String mykey = null;
        String strDecryptApiSecret = null;
        LOG_CAT.beginTimer("RestClientWithFailover.createHttpHeadForREST Start");
        if (buildSignature) {
            mykey = restUtil.pwdForDecryption(module);
            strDecryptApiSecret = restUtil
                    .decryptString(strApiSecretKey, mykey);
        }

        HttpHeaders headers = new HttpHeaders();

        for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
            headers.add(entry.getKey(), entry.getValue());
        }
        for (Map.Entry<String, String> entry : mapHeader.entrySet()) {
            headers.add(entry.getKey(), entry.getValue());
        }

        if (buildSignature) {
            Signature signature = new Signature.Builder()
                    .apiSecret(strDecryptApiSecret)
                    .apiKey(strApiKey)
                    .endpoint(strEndPoint+appendOnURL)
                    .method(httpMethod)
                    .isoDate(depHeaderMap.get("X-KOHLS-CreateDateTime"))
                    .depHeaders(
                            restUtil.concatSingleValueDEPHeaderParams(depHeaderMap))
                    .mediaType("application/json").queryParams(strQueryParam)
                    .payload(payload).build();

            headers.add("Authorization", KohlsPOCConstant.AUTHID + strApiKey
                    + ":" + signature.getRequestSignature());
        }

        LOG_CAT.beginTimer("RestClientWithFailover.createHttpHeadForREST End");

        return headers;

    }
    
    
    
	/**
	 * This method is used to build the request for REST call
	 * it also checks the security file to
	 * get actual password
	 * @param payload
	 * @param mapHeader
	 * @param depHeaderMap
	 * @param strQueryParam
	 * @param strEndPoint
	 * @param strApiKey
	 * @param strApiSecretKey
	 * @param buildSignature
	 * @param httpMethod
	 * @param module
	 * @return
	 * @throws Exception
	 */
	public HttpHeaders createHttpHeadForREST(String payload,
			TreeMap<String, String> mapHeader,
			TreeMap<String, String> depHeaderMap, String strQueryParam,
			String strEndPoint, String strApiKey, String strApiSecretKey,
			boolean buildSignature, String httpMethod,String module) throws Exception {
		
	    KohlsRestAPIUtil restUtil = new KohlsRestAPIUtil();
	    String mykey = null;
	    String strDecryptApiSecret = null;
	    LOG_CAT.beginTimer("RestClientWithFailover.createHttpHeadForREST Start");
	    if (buildSignature) {
	    mykey = restUtil.pwdForDecryption(module);
	    strDecryptApiSecret = restUtil
	    .decryptString(strApiSecretKey, mykey);
	    }

	    HttpHeaders headers = new HttpHeaders();

	    String isoDate = KohlsRestAPIUtil.getCurrentISODate();

	    for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
	    headers.add(entry.getKey(), entry.getValue());

	    //use same date as set in x-dep-date so we don't get signature mismatch
	    if (entry.getKey().equalsIgnoreCase(KohlsPOCConstant.X_DEP_DATE))
	    {
	    isoDate = entry.getValue();
	    }
	    }
	    for (Map.Entry<String, String> entry : mapHeader.entrySet()) {
	    headers.add(entry.getKey(), entry.getValue());
	    }

	    if (buildSignature) {
	    Signature signature = new Signature.Builder()
	    .apiSecret(strDecryptApiSecret)
	    .apiKey(strApiKey)
	    .endpoint(strEndPoint)
	    .method(httpMethod)
	    .isoDate(isoDate)
	    .depHeaders(
	    restUtil.concatSingleValueDEPHeaderParams(depHeaderMap))
	    .mediaType("application/json").queryParams(strQueryParam)
	    .payload(payload).build();

	    headers.add("Authorization", KohlsPOCConstant.AUTHID + strApiKey
	    + ":" + signature.getRequestSignature());
	    }

	    LOG_CAT.beginTimer("RestClientWithFailover.createHttpHeadForREST End");

	    return headers;

	}
    
    
    
    
    

    /**
     * Checks if response has error
     * @param status
     * @return
     */
    public boolean isError(HttpStatus status) {
        LOG_CAT.beginTimer("KohlsRestAPIUtil.isError");

        HttpStatus.Series series = status.series();

        LOG_CAT.endTimer("KohlsRestAPIUtil.isError");

        return (HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR
                .equals(series));
    }

    /**
     * We can condition if specific exception needs to be considered for 
     * retrying backup server
     * @param e
     * @return
     */
    boolean isRetryBackup(Exception e) {

        boolean retry = false;

        if (null != e && null != e.getMessage()) {
            
            // Check if there is better way rathr than string check

            if (e.getMessage().trim().equalsIgnoreCase("404 Not Found".trim())) {
                retry = true;
            }
        }

        if (null != e && null != e.getCause()) {

            if (e.getCause() instanceof java.net.ConnectException) {
                retry = true;
            }

            if (e.getCause() instanceof java.io.IOException
                    || e.getCause() instanceof java.net.SocketTimeoutException) {
                retry = true;
            }

        }
        return retry;
    }

    /**
     * This method is currently template for extensibility.Place holder if any failures needs to stop checking backup server
     * @param e
     * @return
     */
    boolean isSkipBackupRetry(Exception e) {

        boolean fail = false;
        //TODO: Template for extensibility.Place holder if any failures needs to stop checking backup server
        return fail;

    }
    
    public ResponseEntity<String> executeRESTcall(String payload,
        TreeMap<String, String> mapHeader,
        TreeMap<String, String> depHeaderMap, String strQueryParam,
        String endPoint, String strApiKey, String strApiSecretKey,
        String strReadTimeOut, String trustCertificate, boolean enableAuth,String methodName,String module) throws Exception {
      
      return this.executeRESTcall(payload, mapHeader, depHeaderMap, strQueryParam, endPoint, strApiKey, strApiSecretKey, strReadTimeOut, trustCertificate, enableAuth, methodName, module, "");
    }
    
    


}
