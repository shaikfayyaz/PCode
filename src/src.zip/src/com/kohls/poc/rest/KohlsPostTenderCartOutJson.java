package com.kohls.poc.rest;

import java.util.HashMap;
import java.util.Map;

public class KohlsPostTenderCartOutJson {

	private String everydayEarnNonKcc;
	private String everydayEarnKcc;
	private String eventKohlsCashEarn;
	private String eventKohlsCashEarnTol;
	private String redemptionStartDate;
	private String redemptionEndDate;
	private String existingEarnTrackerBal;
	private String updatedEarnTrackerBal;
	private String updatedPendingBal;
	private String updatedPendingBalTol;
	private String spendAwayEvent;
	private String spendAwayNextKohlsCashEarned;
	private String spendAwayEverydayNonKcc;
	private String spendAwayEverydayKcc;
	private String eventName;
	private String transKcAmountToActivateTol;
	private String everydayKccPercentage;
	private String everydayNonKccPercentage;
	private String everydayEarnRem;
	private String barcode;
	private String pin;
	private String qualifyingPurchaseAmount;
	private String totalKcAmountToActivate;
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public String getEverydayEarnNonKcc() {
		return everydayEarnNonKcc;
	}

	public String getTotalKcAmountToActivate() {
		return totalKcAmountToActivate;
	}

	public void setEverydayEarnNonKcc(String everydayEarnNonKcc) {
		this.everydayEarnNonKcc = everydayEarnNonKcc;
	}
	
	public void setTotalKcAmountToActivate(String totalKcAmountToActivate) {
		this.totalKcAmountToActivate = totalKcAmountToActivate;
	}

	public String getEverydayEarnKcc() {
		return everydayEarnKcc;
	}

	public void setEverydayEarnKcc(String everydayEarnKcc) {
		this.everydayEarnKcc = everydayEarnKcc;
	}

	public String getEventKohlsCashEarnTol() {
		return eventKohlsCashEarnTol;
	}

	public String getEventKohlsCashEarn() {
		return eventKohlsCashEarn;
	}

	public void setEventKohlsCashEarnTol(String eventKohlsCashEarnTol) {
		this.eventKohlsCashEarnTol = eventKohlsCashEarnTol;
	}

	
	public void setEventKohlsCashEarn(String eventKohlsCashEarn) {
		this.eventKohlsCashEarn = eventKohlsCashEarn;
	}

	public String getRedemptionStartDate() {
		return redemptionStartDate;
	}

	public void setRedemptionStartDate(String redemptionStartDate) {
		this.redemptionStartDate = redemptionStartDate;
	}

	public String getRedemptionEndDate() {
		return redemptionEndDate;
	}

	public void setRedemptionEndDate(String redemptionEndDate) {
		this.redemptionEndDate = redemptionEndDate;
	}

	public String getExistingEarnTrackerBal() {
		return existingEarnTrackerBal;
	}

	public void setExistingEarnTrackerBal(String existingEarnTrackerBal) {
		this.existingEarnTrackerBal = existingEarnTrackerBal;
	}

	public String getUpdatedEarnTrackerBal() {
		return updatedEarnTrackerBal;
	}

	public void setUpdatedEarnTrackerBal(String updatedEarnTrackerBal) {
		this.updatedEarnTrackerBal = updatedEarnTrackerBal;
	}

	public String getUpdatedPendingBal() {
		return updatedPendingBal;
	}
	
	public String getUpdatedPendingBalTol() {
		return updatedPendingBalTol;
	}

	public void setUpdatedPendingBal(String updatedPendingBal) {
		this.updatedPendingBal = updatedPendingBal;
	}

	public void setUpdatedPendingBalTol(String updatedPendingBalTol) {
		this.updatedPendingBalTol = updatedPendingBalTol;
	}
	public String getSpendAwayEvent() {
		return spendAwayEvent;
	}

	public void setSpendAwayEvent(String spendAwayEvent) {
		this.spendAwayEvent = spendAwayEvent;
	}

	public String getSpendAwayNextKohlsCashEarned() {
		return spendAwayNextKohlsCashEarned;
	}

	public void setSpendAwayNextKohlsCashEarned(String spendAwayNextKohlsCashEarned) {
		this.spendAwayNextKohlsCashEarned = spendAwayNextKohlsCashEarned;
	}

	public String getSpendAwayEverydayNonKcc() {
		return spendAwayEverydayNonKcc;
	}

	public void setSpendAwayEverydayNonKcc(String spendAwayEverydayNonKcc) {
		this.spendAwayEverydayNonKcc = spendAwayEverydayNonKcc;
	}

	public String getSpendAwayEverydayKcc() {
		return spendAwayEverydayKcc;
	}

	public void setSpendAwayEverydayKcc(String spendAwayEverydayKcc) {
		this.spendAwayEverydayKcc = spendAwayEverydayKcc;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getTransKcAmountToActivateTol() {
		return transKcAmountToActivateTol;
	}

	public void setTransKcAmountToActivateTol(String transKcAmountToActivateTol) {
		this.transKcAmountToActivateTol = transKcAmountToActivateTol;
	}

	public String getEverydayKccPercentage() {
		return everydayKccPercentage;
	}

	public void setEverydayKccPercentage(String everydayKccPercentage) {
		this.everydayKccPercentage = everydayKccPercentage;
	}

	public String getEverydayNonKccPercentage() {
		return everydayNonKccPercentage;
	}

	public void setEverydayNonKccPercentage(String everydayNonKccPercentage) {
		this.everydayNonKccPercentage = everydayNonKccPercentage;
	}

	public String getEverydayEarnRem() {
		return everydayEarnRem;
	}

	public void setEverydayEarnRem(String everydayEarnRem) {
		this.everydayEarnRem = everydayEarnRem;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getQualifyingPurchaseAmount() {
		return qualifyingPurchaseAmount;
	}

	public void setQualifyingPurchaseAmount(String qualifyingPurchaseAmount) {
		this.qualifyingPurchaseAmount = qualifyingPurchaseAmount;
	}

	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}