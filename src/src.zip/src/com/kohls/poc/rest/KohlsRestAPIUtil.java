package com.kohls.poc.rest;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlcPoCWriteToFileUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.common.joda.time.DateTime;
import org.elasticsearch.common.joda.time.DateTimeZone;
import org.elasticsearch.common.joda.time.format.DateTimeFormatter;
import org.elasticsearch.common.joda.time.format.ISODateTimeFormat;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class KohlsRestAPIUtil {
    private Properties yfsproperties;
    private static Map<String, String> myKeys = Collections
            .synchronizedMap(new HashMap<String, String>());
    private final static YFCLogCategory logger = YFCLogCategory
            .instance(KohlsRestAPIUtil.class);

    public static String getPropertyValue(String property) {

        String propValue;
        logger.beginTimer("KohlsRestAPIUtil.getProertyValue");
        propValue = YFSSystem.getProperty(property);
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        logger.endTimer("KohlsRestAPIUtil.getProertyValue");

        return propValue;

    }

    /*
     * public void setProperties(Properties prop) throws Exception {
     * yfsproperties = prop; }
     */
    public String getUUID() {
        return UUID.randomUUID().toString();

        // return uniqueID;
    }

    public int getContentLength(String strContent) {

        return strContent.length();
    }

    public static String createHash(String payload) throws Exception {

        return StringUtils.isNotEmpty(payload) ? DigestUtils.md5Hex(payload)
                + KohlsPOCConstant.NEW_LINE : KohlsPOCConstant.NEW_LINE;

    }

    public static String createSignature(final String messageToSign,
                                         final String secret) {

        byte[] hash = null;
        // String hash = null;
        logger.beginTimer("KohlsRestAPIUtil.createSignature");

        try {
            final Mac sha256_HMAC = Mac.getInstance(KohlsPOCConstant.HMACSHA);
            final SecretKeySpec secret_key = new SecretKeySpec(
                    secret.getBytes(), KohlsPOCConstant.HMACSHA);
            sha256_HMAC.init(secret_key);
            hash = Base64.encodeBase64(sha256_HMAC.doFinal(messageToSign
                    .getBytes(KohlsPOCConstant.CHARSET_NAME)));
        } catch (Exception e) {
            // LOGGER.error("HashUtils through an exception | ", e);
        }
        logger.endTimer("KohlsRestAPIUtil.createSignature");

        return new String(hash);
    }

    /**
     * Returns current dateTime for zone UTC in ISO 8601 format
     *
     * @return - current date
     */
    public static String getCurrentISODate() {
        String date = null;
        logger.beginTimer("KohlsRestAPIUtil.getCurrentISODate");

        try {
            final DateTime dt = new DateTime();
            final DateTimeFormatter fmt = ISODateTimeFormat.dateTime()
                    .withZoneUTC();
            dt.withZone(DateTimeZone.UTC);
            date = dt.toString(fmt);
        } catch (Exception e) {
        }
        logger.endTimer("KohlsRestAPIUtil.getCurrentISODate");

        return date;
    }

    public String concatSingleValueDEPHeaderParams(
            TreeMap<String, String> depHeaderMap) {

        final StringBuilder headerBuffer = new StringBuilder();
        logger.beginTimer("KohlsRestAPIUtil.concatSingleValueDEPHeaderParams");

        for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
            String key = entry.getKey();
            headerBuffer.append(key).append(KohlsPOCConstant.COLON)
                    .append(entry.getValue()).append(KohlsPOCConstant.NEW_LINE);
        }
        logger.endTimer("KohlsRestAPIUtil.concatSingleValueDEPHeaderParams");

        return headerBuffer.toString();
    }

    /**
     * Stringify key multi value header pairs, with multi values ordered
     * lexicographically
     *
     * @param depHeaderMap order TreeMap
     * @return Comma delimited String of all DEP headers
     */
    public String concatMultiValueDEPHeaderParams(
            TreeMap<String, List<String>> depHeaderMap) {
        logger.beginTimer("KohlsRestAPIUtil.concatMultiValueDEPHeaderParams");

        final StringBuilder headerBuffer = new StringBuilder();
        for (Map.Entry<String, List<String>> entry : depHeaderMap.entrySet()) {
            String key = entry.getKey();
            final StringBuilder valueString = new StringBuilder();
            Collections.sort(entry.getValue());
            valueString.append(StringUtils.join(entry.getValue(),
                    KohlsPOCConstant.COMMA));
            headerBuffer.append(key).append(KohlsPOCConstant.COLON)
                    .append(valueString).append(KohlsPOCConstant.NEW_LINE);
        }
        logger.endTimer("KohlsRestAPIUtil.concatMultiValueDEPHeaderParams");

        return headerBuffer.toString();
    }

    public HttpHeaders createHttpHead(final String payload,
                                      TreeMap<String, String> mapHeader,
                                      TreeMap<String, String> depHeaderMap, String strQueryParam,
                                      String strEndPoint, String strApiKey, String strApiSecretKey, String strmethod)
            throws Exception {
        // Get current isoDate
        logger.beginTimer("KohlsRestAPIUtil.createHttpHead");
        // Order Map with x-dep header keys and values.
        String mykey = null;
        String strDecryptApiSecret = null;

        // Add httpHeaders for request
        final HttpHeaders headers = new HttpHeaders();

        for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
            //PST -4127 - Start Geo Capture Call
            if (!"x-dep-date".equals(entry.getKey())) {
                headers.add(entry.getKey(), entry.getValue());
            } else if (payload.contains("cardHolderName") && strQueryParam.equals("alias=bcn")) {
                headers.add(entry.getKey(), entry.getValue());
            }
            //PST -4127 - End Geo Capture Call


        }
        for (Map.Entry<String, String> entry : mapHeader.entrySet()) {
            headers.add(entry.getKey(), entry.getValue());
        }

        if (depHeaderMap.containsKey("X-DEP-Date")) {
            depHeaderMap.remove("X-DEP-Date");
        }

        if ("LCS".equalsIgnoreCase(strmethod) || KohlsPOCConstant.RKC_METHOD_NAME.equalsIgnoreCase(strmethod)) {
            //strDecryptApiSecret = strApiSecretKey;
            if (KohlsPOCConstant.RKC_METHOD_NAME.equalsIgnoreCase(strmethod)) {
                strmethod = KohlsPOCConstant.DKC;
            }
            mykey = pwdForDecryption(strmethod);
            strDecryptApiSecret = decryptString(strApiSecretKey, mykey);
            // Build signature
            final Signature signature = new Signature.Builder().
                    payload(payload)
                    .mediaType("application/json")
                    .method(HttpMethod.POST.name())
                    .endpoint(strEndPoint)
                    .isoDate(depHeaderMap.get("X-KOHLS-CreateDateTime"))
                    .depHeaders(depHeaderMap.get("X-KOHLS-MessageID"))
                    .apiSecret(strDecryptApiSecret).apiKey(strApiKey)
                    .buildLCSSignature();

            // Add Authorization Header
            headers.add("Authorization", "KOHLS1-HMAC-SHA256 " + strApiKey + ":"
                    + signature.getRequestSignature());
        } else if (!YFCCommon.isVoid(strmethod) && (!KohlsPOCConstant.RRC_METHOD.equalsIgnoreCase(strmethod))) {
            mykey = pwdForDecryption(strmethod);
            strDecryptApiSecret = decryptString(strApiSecretKey, mykey);

            // Build signature
            final Signature signature = new Signature.Builder()
                    .apiSecret(strDecryptApiSecret).apiKey(strApiKey)
                    .endpoint(strEndPoint)
                    .method(HttpMethod.POST.name())
                    .isoDate(depHeaderMap.get(KohlsPOCConstant.X_DEP_DATE))
                    // Stringify dep-headers
                    .depHeaders(concatSingleValueDEPHeaderParams(depHeaderMap))
                    .mediaType("application/json").queryParams(strQueryParam)
                    .payload(payload).build();
            // .queryParams("alias='lyl'")

            // Add Authorization Header
            headers.add("Authorization", KohlsPOCConstant.AUTHID + strApiKey + ":"
                    + signature.getRequestSignature());
        }

        logger.endTimer("KohlsRestAPIUtil.createHttpHead");

        return headers;

    }

    public boolean isError(final HttpStatus status) {
        logger.beginTimer("KohlsRestAPIUtil.isError");

        HttpStatus.Series series = status.series();
        logger.endTimer("KohlsRestAPIUtil.isError");

        return (HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR
                .equals(series));
    }


    public Map getNewAccessToken(String oAuthURL, String clientID, String enCryptedSecret, String Scope, String grantType,
                                 String strReadTimeOut, String strConnectTimeOut, boolean bProxyRequired, String strProxyHost, int iProxyport, String strFunction) throws Exception {
        HttpPost post = new HttpPost(oAuthURL);
        //post.addHeader("Content-Type", "application/json");
        String issodate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
        String strUuid = this.getUUID();
        post.addHeader("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
        post.addHeader("X-KOHLS-MessageID", strUuid);
        post.addHeader("X-KOHLS-From-SystemCode", KohlsPOCConstant.POC_DEVICE_CODE);
        post.addHeader("X-KOHLS-CreateDateTime", issodate);
        String mykey = pwdForDecryption(strFunction + "_OAUTH");
        String strDecryptApiSecret = decryptString(enCryptedSecret, mykey);
        post.addHeader(
                "Authorization",
                getBasicAuthorizationHeader(clientID, strDecryptApiSecret));

        List<BasicNameValuePair> parametersBody = new ArrayList<BasicNameValuePair>();
        parametersBody.add(new BasicNameValuePair(KohlsPOCConstant.GRANT_TYPE,
                grantType));
        if (!YFCCommon.isVoid(Scope)) {
            parametersBody.add(new BasicNameValuePair(KohlsPOCConstant.SCOPE,
                    Scope));
        }
        DefaultHttpClient client = new DefaultHttpClient();
        HttpResponse response = null;

        post.setEntity(new UrlEncodedFormEntity(parametersBody, HTTP.UTF_8));
        client.getParams().setIntParameter("http.connection.timeout", Integer.parseInt(strConnectTimeOut));
        client.getParams().setIntParameter("http.socket.timeout", Integer.parseInt(strReadTimeOut));
        if (bProxyRequired) {
            HttpHost proxy = new HttpHost(strProxyHost, iProxyport);
            client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
        }
        long beginTime = System.currentTimeMillis();
        response = client.execute(post);
        long endTime = System.currentTimeMillis();
        long responseTime = endTime - beginTime;
        logger.info("REST WebService Enpoint - " + oAuthURL + " took " + responseTime + " ms StatusCode " + response.getStatusLine().getStatusCode());
        Map<String, String> map = null;
        if (response.getStatusLine().getStatusCode() == 200) {
            map = handleJsonResponse(response);
        } else if (response.getStatusLine().getStatusCode() >= 500) {
            throw new IOException();
        } else {
            throw new Exception();
        }
        //accessToken = map.get(KohlsPOCConstant.ACCESS_TOKEN);

        return map;
    }

    public static String getBasicAuthorizationHeader(String username,
                                                     String password) {
        return "Basic" + " "
                + encodeCredentials(username, password);
    }

    public static String encodeCredentials(String username, String password) {
        String cred = username + ":" + password;
        String encodedValue = null;
        byte[] encodedBytes = Base64.encodeBase64(cred.getBytes());
        encodedValue = new String(encodedBytes);
        return encodedValue;
    }


    public static Map handleJsonResponse(HttpResponse response) {
        Map<String, String> oauthLoginResponse = new HashMap();
        //String contentType = response.getEntity().getContentType().getValue();
        try {

            com.google.gson.JsonParser parser = new JsonParser();
            JsonObject rootObj = parser.parse(EntityUtils.toString(response.getEntity())).getAsJsonObject();
            String status = rootObj.get("access_token").getAsString();
            String expires_in = rootObj.get("expires_in").getAsString();

            oauthLoginResponse.put("access_token", status);
            oauthLoginResponse.put("expires_in", expires_in);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            throw new RuntimeException();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            throw new RuntimeException();
        } catch (RuntimeException e) {
            throw e;
        }

        return oauthLoginResponse;
    }

    /**
     * This <code>createConnection</code> method will reroute all callers to the new
     * KohlsRestAPIPooledExecutorService which will execute the request on a
     * separate thread. The executor will prevent the callers from waiting
     * indefinitely or waiting long enough to cause the ACE/ARR on Gravity.
     * <p>
     * tkmaagk - modified for CPE-15354 .
     */
    public ResponseEntity<String> createConnection(String payload, TreeMap<String, String> mapHeader,
                                                   TreeMap<String, String> depHeaderMap, String strQueryParam, String strDomain, String strEndPoint,
                                                   String strApiKey, String strApiSecretKey, String strReadTimeOut, String connectTimeOut, String strMethod,
                                                   String httpMethod, boolean bProxyRequired, String strProxyHost, int iProxyPort) throws Exception {

        // Get hard timeout value from COP file - default to 20s
        long hardTimeout = 20000;
        try {
            String hardTimeoutStr = YFSSystem.getProperty("KOHLS_REST_API_HARD_TIMEOUT");
            if (!YFCCommon.isVoid(hardTimeoutStr)) {
                hardTimeout = Long.valueOf(hardTimeoutStr);
            }
        } catch (NumberFormatException e) {
            logger.error("KohlsRestAPIUtil.createConnection: unable to parse KOHLS_REST_API_HARD_TIMEOUT. Default to "
                    + hardTimeout);
            logger.error(e);
        }

        KohlsRestAPICallableRequest request = KohlsRestAPICallableRequest.newKohlsRestAPIRequest(payload, mapHeader,
                depHeaderMap, strQueryParam, strDomain, strEndPoint, strApiKey, strApiSecretKey, strReadTimeOut,
                connectTimeOut, strMethod, httpMethod, bProxyRequired, strProxyHost, iProxyPort);
        return KohlsRestAPIPooledExecutorService.instance.blockingCall(request, hardTimeout, strDomain);
    }

    /**
     * Do not call directly <code>openConnection</code> method from wrapper clients.
     * Call <code>createConnection</code> instead to execute the task on a timed
     * thread
     * <p>
     * tkmaagk - modified for CPE-15354
     */
    protected ResponseEntity<String> openConnection(String payload,
                                                    TreeMap<String, String> mapHeader,
                                                    TreeMap<String, String> depHeaderMap, String strQueryParam,
                                                    String strDomain, String strEndPoint, String strApiKey,
                                                    String strApiSecretKey, String strReadTimeOut, String connectTimeOut, String strMethod, String httpMethod, boolean bProxyRequired,
                                                    String strProxyHost, int iProxyPort) throws Exception {
        logger.beginTimer("KohlsRestAPIUtil.createConnection");
        // Create HttpHeaders
        final HttpEntity<String> request;
        // Defaulting timeouts if null.
        if (YFCCommon.isVoid(strReadTimeOut)) {
            strReadTimeOut = "10000";
        }

        if (YFCCommon.isVoid(connectTimeOut)) {
            connectTimeOut = "10000";
        }

        HttpHeaders httpHeaders = createHttpHead(payload, mapHeader,
                depHeaderMap, strQueryParam, strEndPoint, strApiKey,
                strApiSecretKey, strMethod);
        ResponseEntity<String> response = null;

        if (KohlsPOCConstant.RRC_METHOD.equalsIgnoreCase(strMethod)) {
            request = new HttpEntity<String>(httpHeaders);
        } else {

            request = new HttpEntity<String>(payload,
                    httpHeaders);

        }
        HttpStatus statusCode = null;
        long beginTime = System.currentTimeMillis();
        try {
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));
            requestFactory.getHttpClient().getParams().setIntParameter("http.connection.timeout", Integer.parseInt(connectTimeOut));
            RestTemplate restTemplate = new RestTemplate();

            if (bProxyRequired) {
                HttpHost proxy = new HttpHost(strProxyHost, iProxyPort);
                requestFactory.getHttpClient().getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
            }

            restTemplate.setRequestFactory(requestFactory);

            List<HttpMessageConverter<?>> converters = new ArrayList<>();
            StringHttpMessageConverter stringConverter = new StringHttpMessageConverter();
            //MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
            stringConverter.setWriteAcceptCharset(false);
            //converter.setSupportedMediaTypes(Arrays.asList(MediaType.ALL));
            //stringConverter.setSupportedMediaTypes(Arrays.asList(MediaType.ALL));
            //stringConverter.getSupportedMediaTypes();
            converters.add(stringConverter);
            //converters.add(converter);
            restTemplate.setMessageConverters(converters);

            if (logger.isDebugEnabled()) {
                logger.debug("Request for Rest API call Headers:::: " + request.getHeaders());
                logger.debug("Request for Rest API call Body:::: " + request.getBody());
            }
            beginTime = System.currentTimeMillis();
            if (!YFCCommon.isVoid(httpMethod) && httpMethod.equalsIgnoreCase("Get")) {
                response = restTemplate.exchange(strDomain, HttpMethod.GET,
                        request, String.class);
            } else if (!YFCCommon.isVoid(httpMethod) && httpMethod.equalsIgnoreCase("POST_NOOUTPUT")) {
                response = restTemplate.exchange(strDomain, HttpMethod.POST,
                        request, null);
            } else {
                response = restTemplate.exchange(strDomain, HttpMethod.POST,
                        request, String.class);
            }


            logger.debug("Response from Rest API call:::: " + response.toString());
            String responseBody = response.getBody();
            logger.debug("ResponseBody is:::: " + responseBody);
            statusCode = response.getStatusCode();
            long endTime = System.currentTimeMillis();
            long responseTime = endTime - beginTime;
            logger.info("REST WebService Enpoint - " + strDomain + " took " + responseTime + " ms StatusCode " + statusCode);
            if (isError(response.getStatusCode())) {
                logger.debug("ERROR | " + response.getStatusCode());
                logger.endTimer("KohlsRestAPIUtil.createConnection");
                return response;
            } else {
                logger.endTimer("KohlsRestAPIUtil.createConnection");
                return response;
            }
        } catch (final Exception e) {
            long endTime = System.currentTimeMillis();
            long responseTime = endTime - beginTime;

            if (e.getCause() instanceof java.io.IOException
                    || e.getCause() instanceof java.net.SocketTimeoutException) {
                logger.info("REST WebService Enpoint - " + strDomain + " took " + responseTime + " ms StatusCode 504");
                throw e;
            }
            if (e instanceof org.springframework.web.client.ResourceAccessException) {
                logger.info("REST WebService Enpoint - " + strDomain + " took " + responseTime + " ms StatusCode 400");
                YFSException yfs = new YFSException();
                yfs.setErrorCode("CONNECTERROR");
                yfs.setErrorDescription("CONNECTERROR");
                throw yfs;
            }

            // PST-40 fix. Changed condition from HttpClientErrorException to HttpServerErrorException
            // as exceptions with code 5xx is will be an instanceof HttpServerErrorException.
            // HttpClientErrorException indicates that the request is bad

            if (e instanceof org.springframework.web.client.HttpServerErrorException) {
                logger.info("REST WebService Enpoint - " + strDomain + strEndPoint + " took " + responseTime + " ms StatusCode " + ((HttpServerErrorException) e).getStatusCode().toString());
                if (((HttpServerErrorException) e).getStatusCode().toString().equals("503")) {
                    throw new YFSException(e.getMessage(), KohlsPOCConstant.SERVICE_UNAVAILABLE_503, ((org.springframework.web.client.HttpServerErrorException) e).getStatusText());

                } // Fix for NullPointerException (JIRA: PST-40) - START
                else if (((HttpServerErrorException) e).getStatusCode().toString().equals("500")) {
                    logger.error("HttpServerErrorException 500 in KohlsRestAPIUtil.createConnection");
                    YFSException yfse = new YFSException();//Fix for ClassCastException (JIRA: PST-660)
                    yfse.setErrorCode("500");
                    if (!YFCCommon.isVoid(e.getMessage())) {
                        yfse.setErrorDescription(e.getMessage());
                    }
                    throw yfse;
                    // Fix for NullPointerException (JIRA: PST-40) - END
                } else {
                    logger.debug("Unknown exception in KohlsRestAPIUtil.createConnection. Checking JSON object for details...");
                    String str = ((HttpServerErrorException) e).getResponseBodyAsString();
                    logger.debug("ResponseBody from Rest API call:::: " + str);
                    if (!YFCCommon.isVoid(str)) {
                        JSONObject json = new JSONObject(str);
                        JSONObject jsonObj = json.getJSONObject("status");
                        YFSException yfs = new YFSException();
                        yfs.setErrorCode(((HttpServerErrorException) e).getStatusCode().toString());
                        yfs.setErrorDescription(jsonObj.getString("message") + " : " + jsonObj.getString("code"));
                        throw yfs;
                    } else { // Fix for JIRA: PST-40 - START
                        logger.error("JSON object is empty. Unknown exception in KohlsRestAPIUtil.createConnection");
                        YFSException yfs = new YFSException();
                        yfs.setErrorCode("UNKNOWN");
                        yfs.setErrorDescription("UNKNOWN Error");
                        throw yfs;
                    } // Fix for JIRA: PST-40 - END
                }

            } else if (e instanceof HttpClientErrorException) {
                logger.info("REST WebService Enpoint - " + strDomain + strEndPoint + " took " + responseTime + " ms StatusCode " + ((HttpClientErrorException) e).getStatusCode().toString());
                // handle bad response codes such as 400 / 403
                // bad request
                YFSException yfs = new YFSException();
                yfs.setErrorCode(((HttpClientErrorException) e).getStatusCode().toString());
                yfs.setErrorDescription(((HttpClientErrorException) e).getResponseBodyAsString());
                throw yfs;
                // Fix for NullPointerException (JIRA: PST-40) - START
            } else {
                logger.info("REST WebService Enpoint - " + strDomain + strEndPoint + " took " + responseTime + " ms StatusCode UNKNOWN");
                logger.error("Unknown exception in KohlsRestAPIUtil.createConnection");
                YFSException yfs = new YFSException();
                if (!YFCCommon.isVoid(e.getMessage())) {
                    yfs.setErrorDescription(e.getMessage());
                } else {
                    yfs.setErrorDescription("UNKNOWN Error");
                }
                if (!YFCCommon.isVoid(e.getCause())) {
                    yfs.setErrorCode(e.getCause().toString());
                } else {
                    yfs.setErrorCode("UNKNOWN");
                }
                throw yfs;
            }
            // Fix for NullPointerException (JIRA: PST-40) - END
        }

    }

    // Read password from properties file
    public String pwdForDecryption(String strMethod) throws IOException {
        logger.beginTimer("KohlsRestAPIUtil.pwdForDecryption");
        InputStream inStream = null;
        logger.debug("inside the PwdDecryption");
        // Loading the authentication file into the memory
        String strAuthFileLoc = YFSSystem.getProperty("SECURITY_FILE_LOC") + "/"
                + YFSSystem.getProperty("SECURITY_FILE_NAME");
        logger.debug("Authentication file Location is: " + strAuthFileLoc);
        String mykey = null;
        if (YFCCommon.isVoid(myKeys.get(strMethod))) {
            try {
                File file = new File(strAuthFileLoc);
                inStream = new FileInputStream(file);
                logger.debug("**************LOADED PROPERTY FILE::"
                        + inStream.toString());
                Properties propin = new Properties();
                propin.load(inStream);
                String strTemp = strMethod + "_" + "DECRYPT_PASSWORD_SALT";
                mykey = (String) propin.get(strTemp);
                myKeys.put(strMethod, mykey);

            } catch (Exception e) {
                e.getStackTrace();
                logger.debug("Failed to retrieve password from credential file.Password is null or empty.");
                throw new YFCException(e,
                        "Failed to retrieve password from credential file",
                        e.getMessage());
            } finally {
                logger.debug("in the finally");
                inStream.close();
            }
        } else {
            mykey = myKeys.get(strMethod);
        }
        logger.endTimer("KohlsRestAPIUtil.pwdForDecryption");
        return mykey;
    }

    public String decryptString(String strToDecrypt, String mykey)
            throws IOException {
        {
            logger.beginTimer("KohlsRestAPIUtil.decryptString");
            logger.debug("In the DecryptString method");
            StandardPBEStringEncryptor crypt = new StandardPBEStringEncryptor();
            crypt.setPassword(mykey);
            String sDecryptedString = crypt.decrypt(strToDecrypt);

            logger.endTimer("KohlsRestAPIUtil.decryptString");


            return sDecryptedString;

        }

    }

    public void writeToFile(String prefix, String content, String fileName, String sFilePath) {
        String sLogToFile = "Y";


        if (!YFCCommon.isVoid(sLogToFile) && KohlsPOCConstant.YES.equalsIgnoreCase(sLogToFile)) {
            if (!sFilePath.endsWith("/")) {
                sFilePath = sFilePath + "/";
            }
            //SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");


            // String sFileName =sPrefix +timestamp+".txt";
            // logger.debug("########## Logging " +sFileName);
            String sContentToWrite = prefix
                    + content + "\n";
            try {
                KohlcPoCWriteToFileUtil fileUtil = new KohlcPoCWriteToFileUtil(sFilePath + fileName, true);
                if (!YFCCommon.isVoid(fileUtil)) {
                    fileUtil.writeDataToFile(sContentToWrite);
                    fileUtil.closeFile();
                }
            } catch (Exception ex) {
                // problem logging to file
                //ex.printStackTrace();
                logger.debug("########## Exception to write file :" + sFilePath + fileName);
            }
        }
    }

    public Document processErrorCode(String jsonString) throws Exception {
        // TODO Auto-generated method stub
        // String sToParse = json.toString();
        Document docErrorResp = XMLUtil
                .createDocument("ErrorResponse");
        Element eleRootOut = docErrorResp.getDocumentElement();

        JsonParser parser = new JsonParser();
        JsonObject rootObj = parser.parse(jsonString).getAsJsonObject();
        JsonObject status = rootObj.get("status").getAsJsonObject();

        String errorCode = status.get("code").getAsString();
        String errormessage = status.get("message").getAsString();
        eleRootOut.setAttribute("ErrorCode", errorCode);
        eleRootOut.setAttribute("Errormessage", errormessage);

        return docErrorResp;
    }
} 	