package com.kohls.poc.rest;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class KohlsUpdateReturnPassInputJson {

	@SerializedName("action")
	@Expose
	private String action;
	@SerializedName("returnTransactionKey")
	@Expose
	private ReturnTransactionKey returnTransactionKey;
	@SerializedName("passcodeDetails")
	@Expose
	private List<PasscodeDetails> passcodeDetails = null;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public ReturnTransactionKey getReturnTransactionKey() {
		return returnTransactionKey;
	}

	public void setReturnTransactionKey(ReturnTransactionKey returnTransactionKey) {
		this.returnTransactionKey = returnTransactionKey;
	}

	public List<PasscodeDetails> getPasscodeDetails() {
		return passcodeDetails;
	}

	public void setPasscodeDetails(List<PasscodeDetails> passcodeDetails) {
		this.passcodeDetails = passcodeDetails;
	}

	public class Item {

		@SerializedName("skuNumber")
		@Expose
		private String skuNumber;
		@SerializedName("lineSequenceNumber")
		@Expose
		private String lineSequenceNumber;
		@SerializedName("upc")
		@Expose
		private String upc;
		@SerializedName("transactionKey")
		@Expose
		private TransactionKey transactionKey;

		public String getSkuNumber() {
			return skuNumber;
		}

		public void setSkuNumber(String skuNumber) {
			this.skuNumber = skuNumber;
		}

		public String getLineSequenceNumber() {
			return lineSequenceNumber;
		}

		public void setLineSequenceNumber(String lineSequenceNumber) {
			this.lineSequenceNumber = lineSequenceNumber;
		}

		public String getUpc() {
			return upc;
		}

		public void setUpc(String upc) {
			this.upc = upc;
		}

		public TransactionKey getTransactionKey() {
			return transactionKey;
		}

		public void setTransactionKey(TransactionKey transactionKey) {
			this.transactionKey = transactionKey;
		}

	}

	public class PasscodeDetails {

		@SerializedName("returnPassCode")
		@Expose
		private String returnPassCode;
		@SerializedName("items")
		@Expose
		private List<Item> items = null;

		public String getReturnPassCode() {
			return returnPassCode;
		}

		public void setReturnPassCode(String returnPassCode) {
			this.returnPassCode = returnPassCode;
		}

		public List<Item> getItems() {
			return items;
		}

		public void setItems(List<Item> items) {
			this.items = items;
		}

	}

	public class ReturnTransactionKey {

		@SerializedName("locationNumber")
		@Expose
		private String locationNumber;
		@SerializedName("deviceId")
		@Expose
		private String deviceId;
		@SerializedName("transactionNumber")
		@Expose
		private String transactionNumber;
		@SerializedName("transactionTimestamp")
		@Expose
		private String transactionTimestamp;

		public String getLocationNumber() {
			return locationNumber;
		}

		public void setLocationNumber(String locationNumber) {
			this.locationNumber = locationNumber;
		}

		public String getDeviceId() {
			return deviceId;
		}

		public void setDeviceId(String deviceId) {
			this.deviceId = deviceId;
		}

		public String getTransactionNumber() {
			return transactionNumber;
		}

		public void setTransactionNumber(String transactionNumber) {
			this.transactionNumber = transactionNumber;
		}

		public String getTransactionTimestamp() {
			return transactionTimestamp;
		}

		public void setTransactionTimestamp(String transactionTimestamp) {
			this.transactionTimestamp = transactionTimestamp;
		}

	}

	public class TransactionKey
	{

		@SerializedName("locationNumber")
		@Expose
		private String locationNumber;
		@SerializedName("deviceId")
		@Expose
		private String deviceId;
		@SerializedName("transactionNumber")
		@Expose
		private String transactionNumber;
		@SerializedName("transactionTimestamp")
		@Expose
		private String transactionTimestamp;

		public String getLocationNumber() {
			return locationNumber;
		}

		public void setLocationNumber(String locationNumber) {
			this.locationNumber = locationNumber;
		}

		public String getDeviceId() {
			return deviceId;
		}

		public void setDeviceId(String deviceId) {
			this.deviceId = deviceId;
		}

		public String getTransactionNumber() {
			return transactionNumber;
		}

		public void setTransactionNumber(String transactionNumber) {
			this.transactionNumber = transactionNumber;
		}

		public String getTransactionTimestamp() {
			return transactionTimestamp;
		}

		public void setTransactionTimestamp(String transactionTimestamp) {
			this.transactionTimestamp = transactionTimestamp;
		}

	}
}