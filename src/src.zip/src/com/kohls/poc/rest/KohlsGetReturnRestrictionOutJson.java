package com.kohls.poc.rest;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.kohls.poc.rest.KohlsGetReturnPassDetailsOutJson.OrderDetails;

public class KohlsGetReturnRestrictionOutJson {
	
	@SerializedName("restrictedReturnPolicyDate")
	@Expose
	private String restrictedReturnPolicyDate;
	@SerializedName("restrictedReturnPolicyDays")
	@Expose
	private String restrictedReturnPolicyDays;

	public String getReturnPolicyDate() {
		return restrictedReturnPolicyDate;
	}
	
	public void setReturnPolicyDate(String createdDate) {
		this.restrictedReturnPolicyDate = restrictedReturnPolicyDate;
	}

	public String getReturnPolicyDays() {
		return restrictedReturnPolicyDays;
	}
	
	public void setReturnPolicyDays(String createdDate) {
		this.restrictedReturnPolicyDays = restrictedReturnPolicyDays;
	}
	

}
