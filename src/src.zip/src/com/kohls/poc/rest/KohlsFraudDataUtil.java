package com.kohls.poc.rest;

import java.sql.SQLException;
import java.util.regex.Pattern;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsFraudDataUtil {

	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsFraudDataUtil.class);

	
	public Document getRiskItemList(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsFraudDataUtil.getRiskItemList");

		Document outGetHighRiskItemList = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_GET_DefEdg_HighRiskItem_LIST, inDoc);
		if (!YFCCommon.isVoid(outGetHighRiskItemList)) {

			logger.debug(" KohlsFraudDataUtil.getRiskItemList --> Fraud Data xml is "
					+ XMLUtil.getXMLString(outGetHighRiskItemList));
		}
		logger.endTimer("KohlsFraudDataUtil.getRiskItemList");

		return outGetHighRiskItemList;
	}

	public Document getRiskItemDetails(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsFraudDataUtil.getRiskItemDetails");

		Document outGetHighRiskItemList = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_GET_DefEdg_HighRiskItem, inDoc);
		if (!YFCCommon.isVoid(outGetHighRiskItemList)) {

			logger.debug(" KohlsFraudDataUtil.getRiskItemList --> Fraud Data xml is "
					+ XMLUtil.getXMLString(outGetHighRiskItemList));
		}
		logger.endTimer("KohlsFraudDataUtil.getRiskItemDetails");

		return outGetHighRiskItemList;
	}

	public void createRiskItemDetails(YFSEnvironment env, Document inDoc) {
		logger.beginTimer("KohlsFraudDataUtil.createRiskItemDetails");

		Document outCreateHighRiskItem = null;
		Element eleFraudData = inDoc.getDocumentElement();
		String dptNumber = eleFraudData.getAttribute(KohlsPOCConstant.A_DEPTNBR);
		String majorclass = eleFraudData.getAttribute(KohlsPOCConstant.A_MAJOR_CLASS);
		String subclass = eleFraudData.getAttribute(KohlsPOCConstant.A_SUB_CLASS);
		String risklevel = eleFraudData.getAttribute(KohlsPOCConstant.RISK_LEVEL);
		try {
			outCreateHighRiskItem = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.KOHLS_CREATE_DefEdg_HighRiskItem, inDoc);
			if (!YFCCommon.isVoid(outCreateHighRiskItem)) {

				logger.debug(" KohlsFraudDataUtil.createRiskItemDetails --> Fraud Data xml is "
						+ XMLUtil.getXMLString(outCreateHighRiskItem));
			}
		} catch (Exception e) {

			if (e.getClass().getName()
					.equalsIgnoreCase("com.yantra.yfc.dblayer.YFCDBException")) {

				YFSException yfsException = new YFSException();
				YFSException es = (YFSException) e;

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("YDB92_001")) {
					yfsException.setErrorCode("YDB92_001");
					yfsException.setErrorDescription("Invalid Data.Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel+" "
							+ XMLUtil.getXMLString(inDoc));
					logger.error("Invalid Data.Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
				} else {

					yfsException.setErrorCode(es.getErrorCode());
					yfsException.setErrorDescription(es.getErrorDescription()+"Invalid Data.Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
					logger.error(es.getErrorDescription()+"Invalid Data.Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
				}

				throw yfsException;

			} else if (e.getClass().getName()
					.equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

				YFSException yfsException = new YFSException();
				YFSException es = (YFSException) e;
				yfsException.setErrorCode(es.getErrorCode());
				yfsException.setErrorDescription(es.getErrorDescription());
				logger.error(es.getErrorDescription()+" Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
				throw new YFSException(e.getClass().toString(),es.getErrorCode(),es.getErrorDescription()+" Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);

			}

			else if (e instanceof SQLException) {

				YFSException yfsException = new YFSException();
				YFSException es = (YFSException) e;

				yfsException.setErrorCode(es.getErrorCode());
				yfsException.setErrorDescription(es.getErrorDescription()+" Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
				logger.error(es.getErrorDescription()+" Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
				throw yfsException;
			}

		}
		logger.endTimer("KohlsFraudDataUtil.createRiskItemDetails");

	}

	public void modifyRiskItemDetails(YFSEnvironment env, Document inDoc, String syncType) {
		logger.beginTimer("KohlsFraudDataUtil.modifyRiskItemDetails");

		Document outChangeHighRiskItem;
		Element eleFraudData = inDoc.getDocumentElement();
		String dptNumber = eleFraudData.getAttribute(KohlsPOCConstant.A_DEPTNBR);
		String majorclass = eleFraudData.getAttribute(KohlsPOCConstant.A_MAJOR_CLASS);
		String subclass = eleFraudData.getAttribute(KohlsPOCConstant.A_SUB_CLASS);
		String risklevel = eleFraudData.getAttribute(KohlsPOCConstant.RISK_LEVEL);
		try {
			
			outChangeHighRiskItem = KOHLSBaseApi.invokeService(env,
					KohlsPOCConstant.KOHLS_CHANGE_DefEdg_HighRiskItem, inDoc);
			if (!YFCCommon.isVoid(outChangeHighRiskItem)) {

				logger.debug(" KohlsFraudDataUtil.modifyRiskItemDetails --> Fraud Data xml is "
						+ XMLUtil.getXMLString(outChangeHighRiskItem));
			}
		} catch (Exception e) {

			if (e.getClass().getName()
					.equalsIgnoreCase("com.yantra.yfs.japi.YFSException")) {

				YFSException yfsException = new YFSException();
				YFSException es = (YFSException) e;

				// Connect Exception
				if (es.getErrorCode().equalsIgnoreCase("YFC0002")) {
					if(KohlsPOCConstant.SYNC_FULL.equalsIgnoreCase(syncType))
					{					
						createRiskItemDetails(env,
								inDoc);
						return;
					}
					else
					{
						yfsException.setErrorCode("UPDATE_FAILED");
						yfsException.setErrorDescription("Record does not exist in the table for Update");
						logger.error("Record does not exist in the table for Update. Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
					}										
				} else if (es.getErrorCode().equalsIgnoreCase("YDB92_001")) {
					yfsException.setErrorCode("VALIDATION_ERROR");
					yfsException.setErrorDescription("Invalid Data. Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel+" "
							+ XMLUtil.getXMLString(inDoc));
					logger.error("Invalid Data. Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
				} else {
					throw es;
				}

				throw yfsException;

			}

		}

		logger.endTimer("KohlsFraudDataUtil.modifyRiskItemDetails");

	}

	public void deleteRiskItemDetails(YFSEnvironment env, Document inDoc)
			throws Exception {

		logger.beginTimer("KohlsFraudDataUtil.deleteRiskItemDetails");

		Document outDeleteHighRiskItem = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_DELETE_DefEdg_HighRiskItem, inDoc);
		if (!YFCCommon.isVoid(outDeleteHighRiskItem)) {

			logger.debug(" KohlsFraudDataUtil.getRiskItemList --> Fraud Data xml is "
					+ XMLUtil.getXMLString(outDeleteHighRiskItem));
		}
		logger.endTimer("KohlsFraudDataUtil.deleteRiskItemDetails");

	}
	
	public  String   getKohlsRiskLevel(YFSEnvironment env, Document inDoc) throws Exception
	{
		String riskLevel= null;
		Document outHighRiskData = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_GET_DefEdg_HighRiskItem, inDoc);		

		if(!YFCCommon.isVoid(outHighRiskData))
		{
			Element eleKohlsMosData = (Element)outHighRiskData.getElementsByTagName("KohlsDefEdgHighRiskItem").item(0);
			riskLevel=eleKohlsMosData.getAttribute(KohlsPOCConstant.RISK_LEVEL);
		}
		return riskLevel;
		
	}
	
	public  String   getCFDescription(YFSEnvironment env, Document inDoc) throws Exception
	{
		String riskLevel= null;
		Document outHighRiskData = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_GET_DefEdg_HighRiskItem, inDoc);		

		if(!YFCCommon.isVoid(outHighRiskData))
		{
			Element eleKohlsMosData = (Element)outHighRiskData.getElementsByTagName("KohlsDefEdgHighRiskItem").item(0);
			riskLevel=eleKohlsMosData.getAttribute("Description");
		}
		return riskLevel;
		
	}

	public  void ValidateJsonData(Document inDoc)  {
		// TODO Auto-generated method stub
		logger.beginTimer("KohlsFraudDataUtil.ValidateData");

		Pattern pattern = Pattern.compile(".*[^0-9].*");
		String sMessage = "Invalid";
		Element eleDeptDetails = inDoc.getDocumentElement();
		String sDepartment=eleDeptDetails.getAttribute(KohlsPOCConstant.A_DEPTNBR);
		String sMajorClass=eleDeptDetails.getAttribute(KohlsPOCConstant.A_MAJOR_CLASS);
		String sSubClass=eleDeptDetails.getAttribute(KohlsPOCConstant.A_SUB_CLASS);
		String sAction=eleDeptDetails.getAttribute(KohlsPOCConstant.ACTION);
		String sRiskLevel=eleDeptDetails.getAttribute(KohlsPOCConstant.RISK_LEVEL);

		try{
			
		if (YFCCommon.isVoid(sAction)
				|| !(sAction.equals("add")
						|| sAction.equals("del") || sAction
						.equals("upd"))) {

			sMessage = sMessage + (" Action " + sAction);
			logger.error("KohlsFraudDataUtil.ValidateData--" + sMessage);
			throw new YFSException("VALIDATION_ERROR",sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel,inDoc.toString());
		}
			
		if (YFCCommon.isVoid(sDepartment) || sDepartment.length() > 4
				|| pattern.matcher(sDepartment).matches()) {

			sMessage = sMessage + " Department " +sDepartment;
			logger.error("KohlsFraudDataUtil.ValidateData--" + sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel);
			throw new YFSException("VALIDATION_ERROR",sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel,inDoc.toString());
		}
		if (sMajorClass.length() > 3
				|| pattern.matcher(sMajorClass).matches()) {

			sMessage = sMessage + (" Major Class " + sMajorClass);
			logger.error("KohlsFraudDataUtil.ValidateData--" + sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel);
			throw new YFSException("VALIDATION_ERROR",sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel,inDoc.toString());

		}
		
		if (!"00".equalsIgnoreCase(sSubClass)) {
			if ("00".equals(sMajorClass)) {
				sMessage = sMessage + " Major Class for the given Sub Class.";		
				logger.error("KohlsFraudDataUtil.ValidateData--" + sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel);
				throw new YFSException("VALIDATION_ERROR",sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel,inDoc.toString());
			}
			
			
		}

		if (sSubClass.length() > 3
				|| pattern.matcher(sSubClass).matches()) {

			sMessage = sMessage + (" Sub Class" +sSubClass);
			logger.error("KohlsFraudDataUtil.ValidateData--" +sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel);
			throw new YFSException("VALIDATION_ERROR",sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel,inDoc.toString());
		}
		
		if ((YFCCommon.isVoid(sRiskLevel) && !sAction
				.equals("del"))
				|| pattern.matcher(sRiskLevel).matches()) {

			sMessage = sMessage + (" Risk Level " +sRiskLevel);
			logger.error("KohlsFraudDataUtil.ValidateData--" + sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel);
			throw new YFSException("VALIDATION_ERROR",sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel,inDoc.toString());

		}
		logger.endTimer("KohlsFraudDataUtil.ValidateData");
		}
		catch(Exception e)
		{
			YFSException yfsException = new YFSException();
			yfsException.setErrorCode("VALIDATION_ERROR");
			yfsException.setErrorDescription(sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel +"---->"+XMLUtil.getXMLString(inDoc));
			logger.error("KohlsFraudDataUtil.ValidateData--"+sMessage+" Identifier -->"+sDepartment+"|"+sMajorClass+"|"+sSubClass+"|"+sRiskLevel +"--->"+XMLUtil.getXMLString(inDoc));
			throw yfsException;
			
		}
		
	}

	public void modifyTable(Document docFraudDataList, YFSEnvironment env)
			throws Exception {

		logger.beginTimer("KohlsFraudDataUtil.modifyTable");

		NodeList ndlFraudData = docFraudDataList
				.getElementsByTagName(KohlsPOCConstant.KohlsDefEdgHighRiskItem);

		for (int i = 0; i < ndlFraudData.getLength(); i++) {
			
			logger.debug(" KohlsFraudDataUtil.getRiskItemList--> Inside the loop");
			Element eleFraudData = (Element) ndlFraudData.item(i);
			String dptNumber = eleFraudData.getAttribute(KohlsPOCConstant.A_DEPTNBR);
			String majorclass = eleFraudData.getAttribute(KohlsPOCConstant.A_MAJOR_CLASS);
			String subclass = eleFraudData.getAttribute(KohlsPOCConstant.A_SUB_CLASS);
			String risklevel = eleFraudData.getAttribute(KohlsPOCConstant.RISK_LEVEL);
			String syncType = eleFraudData.getAttribute("SyncType");
			if("CF_KAFKA_OFFSET".equalsIgnoreCase(dptNumber))
			{
			     String sGetOffset= getCFDescription(env, SCXmlUtil.createFromString(SCXmlUtil.getString(eleFraudData)));
			     eleFraudData.setAttribute("ActiveFlag", "N");
			     if(YFCCommon.isVoid(sGetOffset))
			     {
			    	 	eleFraudData.setAttribute(KohlsPOCConstant.A_ACTION, 
			    	 			"add");
			     }
			     else
			     {
			    	 eleFraudData.setAttribute(KohlsPOCConstant.A_ACTION, 
			    	 			"upd");
			     }
			}
			
			if (eleFraudData.getAttribute(
					KohlsPOCConstant.A_ACTION).equalsIgnoreCase(
							"add")) {

				logger.debug("KohlsFraudDataUtil.getRiskItemList --> Insert the record");
				if(!"CF_KAFKA_OFFSET".equalsIgnoreCase(dptNumber))
				{
					eleFraudData.setAttribute("ActiveFlag", "Y");
				}				
				createRiskItemDetails(env,
						XMLUtil.getDocumentForElement(eleFraudData));

			} else if (eleFraudData.getAttribute(
					KohlsPOCConstant.A_ACTION).equalsIgnoreCase(
							"del"))

			{
				Document cloneDoc = XMLUtil.getDocumentForElement(eleFraudData);
				cloneDoc.getDocumentElement().removeAttribute("LastUpdatedTS");
				cloneDoc.getDocumentElement().removeAttribute("LastUpdatedBy");
				Document getRiskItemList = getRiskItemList(env,cloneDoc);
				if(!getRiskItemList.getDocumentElement().hasChildNodes())
				{
					if(KohlsPOCConstant.SYNC_FULL.equalsIgnoreCase(syncType))
					{
						eleFraudData.setAttribute("ActiveFlag", "N");
						createRiskItemDetails(env,
								XMLUtil.getDocumentForElement(eleFraudData));
						return;
					}
					else
					{
						logger.error("Record does not exist in the table for Delete.Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel);
						throw new YFSException("Record does not exist in the table for Delete.Identifier --> "+dptNumber+"|"+majorclass+"|"+subclass+"|"+risklevel,"VALIDATION_ERROR",null);
					}
					
				}
				logger.debug("KohlsFraudDataUtil.getRiskItemList --> Delete the record");
				eleFraudData.setAttribute("ActiveFlag", "N");
				modifyRiskItemDetails(env,
						XMLUtil.getDocumentForElement(eleFraudData),syncType);

			} else if (eleFraudData.getAttribute(
					KohlsPOCConstant.A_ACTION).equalsIgnoreCase(
							"upd"))

			{
				logger.debug("KohlsFraudDataUtil.getRiskItemList  --> Modify the record");
				if(!"CF_KAFKA_OFFSET".equalsIgnoreCase(dptNumber))
				{
					eleFraudData.setAttribute("ActiveFlag", "Y");
				}
				modifyRiskItemDetails(env,
						XMLUtil.getDocumentForElement(eleFraudData),syncType);
			}
		}

		logger.endTimer("KohlsFraudDataUtil.modifyTable");

	}
	

	public Document getXMLfromJson(Document inputDoc, String sParseData, String type) {
		logger.beginTimer("KohlsFraudDataUtil.getXMLfromJson");

		//sParseData = sParseData;
		Gson outGson = new Gson();
		KohlsCreditFraudJson records = outGson.fromJson(sParseData,
				KohlsCreditFraudJson.class); // input
		Document docFraudData = null;
		if(YFCCommon.isVoid(inputDoc))
		{
		docFraudData = SCXmlUtil
				.createDocument(KohlsPOCConstant.KOHLS_GET_DefEdg_HighRiskItem_LIST);

		}
		
		
		else{
			
			docFraudData=inputDoc;
		}
		Element eleFraudData = docFraudData
					.createElement(KohlsPOCConstant.KohlsDefEdgHighRiskItem);
			
			if (!YFCCommon.isVoid(records.getDept()))

			{

				eleFraudData.setAttribute(
						KohlsPOCConstant.A_DEPTNBR,
						records.getDept());

			}
			if (!YFCCommon.isVoid(records.getMajorClass())) {
				eleFraudData.setAttribute(
						KohlsPOCConstant.A_MAJOR_CLASS,
						records.getMajorClass());
			}
			else
			{
				eleFraudData.setAttribute(
						KohlsPOCConstant.A_MAJOR_CLASS,"00");
			}

			if (!YFCCommon.isVoid(records.getSubClass())) {
				eleFraudData.setAttribute(
						KohlsPOCConstant.A_SUB_CLASS,
						records.getSubClass());
			}
			else
			{
				eleFraudData.setAttribute(
						KohlsPOCConstant.A_SUB_CLASS,"00");
			}
			eleFraudData.setAttribute("LastUpdatedBy",
					records.getUpdatedBy());
			if(!YFCCommon.isVoid(type))
			{
				eleFraudData.setAttribute("SyncType",
						type);
			}
			
			eleFraudData.setAttribute(KohlsPOCConstant.RISK_LEVEL,
					records.getRiskLevel());
			eleFraudData.setAttribute("LastUpdatedTS",
					records.getLastUpdTS());
			eleFraudData.setAttribute("Description",
					records.getDescription());
			eleFraudData.setAttribute(KohlsPOCConstant.ACTION,
					records.getAction());
			docFraudData.getDocumentElement().appendChild(eleFraudData);
		if (!YFCCommon.isVoid(docFraudData)) {

			logger.debug(" KohlsFraudDataUtil.getRiskItemList --> Fraud Data xml is "
					+ XMLUtil.getXMLString(docFraudData));
		}
		logger.endTimer("KohlsFraudDataUtil.getXMLfromJson");

		return docFraudData;

	}


}
