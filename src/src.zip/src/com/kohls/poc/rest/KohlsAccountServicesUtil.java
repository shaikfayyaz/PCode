package com.kohls.poc.rest;

import com.sterlingcommerce.woodstock.util.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

public class KohlsAccountServicesUtil {
    public static final String HMAC_TYPE = "HmacSHA256";
    public static final String CHARSET_NAME = "UTF8";

    public static String createSignature(String HmacKey, String signatureContent) {

        try {
            Mac mac = Mac.getInstance(HMAC_TYPE);
            SecretKeySpec secretKey = new SecretKeySpec(HmacKey.getBytes(), HMAC_TYPE);
            mac.init(secretKey);


            byte[] encoded = Base64.encode(mac.doFinal(mac.doFinal(signatureContent.getBytes(CHARSET_NAME))));
            return new String(encoded, StandardCharsets.UTF_8);

        } catch (Exception ignored) {
            return null;
        }

    }
}
