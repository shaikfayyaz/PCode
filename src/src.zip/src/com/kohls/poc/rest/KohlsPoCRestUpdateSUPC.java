package com.kohls.poc.rest;



import java.io.IOException;
import java.net.InetAddress;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.json.JSONObject;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsPoCXPathUtil;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

import com.kohls.sbc.orgRules.KohlsPoCOrgRuleUtil;

/**************************************************************************
 * File : KohlsPoCRestUpdateSUPC.java Author : RajeshG Created : June 01 2016 Modified : June 01
 * 2016 Version : 1.0
 ***************************************************************************** 
 * *************************************************************************** Copyright @ 2016.
 * This document is in copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Java component is implemented as part of SUPC.It will make call to TVS for updating SUPC
 * code in the TVS*
 * 
 * @author Rajesh G
 * @version 1.0
 *****************************************************************************/

public class KohlsPoCRestUpdateSUPC extends KOHLSBaseApi {


  public String strReadTimeOut = "";
  public String endPoint = "";
  public String trustCertificate = "";
  // Below fields are require if enableAuth is Y
  public String strQueryParam = "";
  public String strApiKey = "";
  public String strApiSecretKey = "";
  public String enableAuth = "";
  public boolean enableRESTAuth = false;


  public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
  private Properties props;

  private static YFCLogCategory logger;

  static {
    logger = YFCLogCategory.instance(KohlsPoCRestUpdateSUPC.class.getName());
  }

  /**
   * This method will be called using IBM SFD framework through UE call from TcxGravity when
   * Customer taps his/her phone in pinpad
   * 
   * @param env
   * @param inDoc
   * @return
   * @throws Exception
   */
  public Document updateSUPCStatus(YFSEnvironment env, Document inDoc) throws Exception {

    logger.beginTimer("Start KohlsPoCRestUpdateSUPC.updateSUPCStatus");
    if(logger.isDebugEnabled()){  
      logger.debug("KohlsPoCRestUpdateSUPC.updateSUPCStatus InDoc--->" + XMLUtil.getXMLString(inDoc));
    }
    
    List<Element> supcCodeList = KohlsPoCXPathUtil.getElementListByXpath(inDoc, "SupcList/SupcCode");
    
    if( null == supcCodeList || supcCodeList.size() <= 0){    
      return inDoc;
    }

    String store = XMLUtil.getAttribute(inDoc.getDocumentElement(), "StoreNo");
    String transactionId = XMLUtil.getAttribute(inDoc.getDocumentElement(), "TransactionId");
    String action = XMLUtil.getAttribute(inDoc.getDocumentElement(), "Action");
    
    if (store == null || transactionId == null ) {
      logger.info("Store or TransactionId Missing for this SUPC call");
      return inDoc;
    }

    
    strReadTimeOut = this.props.getProperty("CUST_READ_TIME_OUT");
    endPoint = this.props.getProperty("CUST_ENDPOINT");
    trustCertificate = this.props.getProperty("CUST_TRUSTCERT");
    enableAuth = this.props.getProperty("CUST_ENABLEAUTH");
    RestClientWithFailover supcRestClient = null;

    GsonBuilder builder = new GsonBuilder();
    Gson gson = builder.create();


    TreeMap<String, String> mapHeader = new TreeMap<String, String>();

    mapHeader.put(KohlsPOCConstant.ACCEPT, "application/json");
    mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");

    String issodate = KohlsRestAPIUtil.getCurrentISODate();
    String strUuid = restApiutil.getUUID();
    String omsHost =  getHostName(env);
    String versionInfo =  getVersionInfoForPOC(env);

    TreeMap<String, String> depHeaderMap = new TreeMap<String, String>();

    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_CREATE_DATE_TIME, issodate);
    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_MESSAGE_ID, strUuid);
    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_SYSTEM_CODE, "OS");
    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_APP, "OMSR");
    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_MODULE, "TVSSUPCUPDATECALL");
    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_NODEID, omsHost);
    depHeaderMap.put("x-dep-correlation-id", KohlsPoCCommonAPIUtil.getCorrelationID());
    depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());
    depHeaderMap.put(KohlsPOCConstant.X_KOHLS_VERSION, versionInfo);

    ResponseEntity<String> response = null;

    try {
      if ("Y".equalsIgnoreCase(enableAuth) ) {
        enableRESTAuth = true;
      }
      
      for (Element supcElement : supcCodeList) {
        
        String supcCode = XMLUtil.getAttribute(supcElement, "SupcValue");
        KohlsPoCRestUpdateSUPCRequest kohlsPoCRestUpdateSUPCRequest =
            parseInputDoc(supcCode, store, transactionId, action);
        
        String jsonPayload = null;

        jsonPayload = gson.toJson(kohlsPoCRestUpdateSUPCRequest).toString();
        
        if( logger.isDebugEnabled() ) {  
            logger.debug( "JSON Request to SUPC ----->" + jsonPayload );
        }
        // make request and call TVS
        // it is fire and forget
        supcRestClient = new RestClientWithFailover();
        try {

          response =
              supcRestClient.executeRESTcall(jsonPayload, mapHeader, depHeaderMap, strQueryParam, endPoint
                  , strApiKey, strApiSecretKey, strReadTimeOut,
                  trustCertificate, enableRESTAuth, HttpMethod.PUT.name(), "TVSSUPCREDEEM","/" + supcCode + "/");

          if (null != response) {

            logger.debug("Response from SUPC Service--->" + response.getBody() + "||Header"
                + response.getHeaders());
          }

          if ((response != null) && (response.getStatusCode().toString().equals("200"))) {
            String responseBody = response.getBody();
            
            JSONObject json = new JSONObject(responseBody);
            
            if(logger.isDebugEnabled()){  
              logger.debug("Rest responseBody ----->" + responseBody);
            }


          }
        } catch (Exception e) {

          if (e instanceof HttpClientErrorException) {
            HttpClientErrorException ht = (HttpClientErrorException) e;

            logger.error(e.getMessage() + " for SUPC Redeem call " + supcCode
                + ht.getResponseBodyAsString());

          } else {
            logger.error(e.getMessage() + "for SUPC Redeem call" + supcCode);
          }
        }
      }



    } catch (Exception e) {
      logger.error("SUPC Call Failed"+e);     
    }
    logger.endTimer("End KohlsPoCRestUpdateSUPC.getKohlsPoCRestUpdateSUPC");

    return inDoc;

  }

  /**
   * This method is to validate the input and build the request object for SUPC Service
   * 
   * @param inDoc
   * @return
   */
  private KohlsPoCRestUpdateSUPCRequest parseInputDoc(String supcValue, String store,
      String transactionid, String action) {

    KohlsPoCRestUpdateSUPCRequest kohlsPoCRestUpdateSUPCRequest = new KohlsPoCRestUpdateSUPCRequest();

    if (!YFCCommon.isVoid(action)) {
      if ("redeem".equalsIgnoreCase(action.trim())) {
        kohlsPoCRestUpdateSUPCRequest.setstatus("USED");

      } else {
        kohlsPoCRestUpdateSUPCRequest.setstatus("UNUSED");
      }
    }

    if (!YFCCommon.isVoid(store)) {
      kohlsPoCRestUpdateSUPCRequest.setstore(store);
    } else {
      logger.error("store passed to TVS will be null");
    }



    if (!YFCCommon.isVoid(transactionid)) {

      kohlsPoCRestUpdateSUPCRequest.setTransactionId(transactionid);

    } else {

      logger.error("transactionid passed to TVS will be null");
    }



    return kohlsPoCRestUpdateSUPCRequest;
  }

 




  /*
   * (non-Javadoc)
   * 
   * @see com.kohls.common.util.KOHLSBaseApi#setProperties(java.util.Properties)
   */
  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    logger.debug("In the set properties method");

  }

  /**
   * This method is to retrieve the OMS server details and it is passed as part of REST header
   * details
   * 
   * @param envinUE
   * @return
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws Exception
   */
  String getHostName(YFSEnvironment envinUE) throws ParserConfigurationException, SAXException,
      IOException, Exception {

    String host = "OMSR";
    try{
      host = InetAddress.getLocalHost().getCanonicalHostName();
    }catch (Exception e) {
      logger.error(e);     
    }   
    return host;

  }

  /**
   * This method is to retrieve the OMS version details and it is passed as part of REST header
   * details
   * 
   * @param envinUE
   * @return
   * @throws ParserConfigurationException
   * @throws SAXException
   * @throws IOException
   * @throws Exception
   */
  String getVersionInfoForPOC(YFSEnvironment envinUE) throws ParserConfigurationException,
      SAXException, IOException, Exception {

    String versionInfo = null;

    String getVersionInfoForPOCInputXML = "<Versions></Versions>";

    Document getVersionInfoForPOCOutputDoc =
        KOHLSBaseApi.invokeAPI(envinUE, "getVersionInfoForPOS",
            XMLUtil.getDocument(getVersionInfoForPOCInputXML));


    if (null != getVersionInfoForPOCOutputDoc) {

      List versionList =
          KohlsXMLUtil.getElementListByXpath(getVersionInfoForPOCOutputDoc,
              "/Versions/Version[@Prefix='ysc']");

      if (null != versionList && versionList.size() == 0) {
        versionList =
            KohlsXMLUtil.getElementListByXpath(getVersionInfoForPOCOutputDoc,
                "/Versions/Version[@Prefix='tcxgravity']");

      }
      if (null != versionList && versionList.size() > 0) {

        Element versionElement = (Element) versionList.get(0);

        if (null != versionElement) {
          versionInfo = versionElement.getAttribute("Version");
        }


      }
    }

    if (null == versionInfo || "".equalsIgnoreCase(versionInfo.trim())) {

      versionInfo = "9.3.0.21";
    }

    return versionInfo;

  }

  /**
   * This is generic method to generate the YFS Exception for invalid input with information passed
   * in the parameters
   * 
   * @param fieldName
   */
  void raiseInvalidInputException(String fieldName) {
    YFSException yfs = new YFSException();
    yfs.setErrorCode("InvalidInput");
    yfs.setErrorDescription(fieldName + " Field Received by OMS is empty or null");
    throw yfs;
  }


}
