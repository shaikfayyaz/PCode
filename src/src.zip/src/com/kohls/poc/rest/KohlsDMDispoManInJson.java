package com.kohls.poc.rest;


public class KohlsDMDispoManInJson {

	private String sku;
	
	private String itemPrice;
	private String storeNumber;
	private String device;
	private String itemStatusCode;
	private boolean webExclusiveFlag;
	private String webExclusiveDispoCode;
	private boolean damagedFlag;


	public String geSku() {
		return sku;
	}
	
	

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public String getItemPrice() {
		return itemPrice;
	}
	
	

	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}


	public String getDevice() {
		return device;
	}
	
	public void setDevice(String device) {
		this.device = device;
	}
	
	public String getItemStatusCode() {
		return itemStatusCode;
	}

	public void setItemStatusCode(String itemStatusCode) {
		this.itemStatusCode = itemStatusCode;
	}
	
	public boolean getWebExclusiveFlag() {
		return webExclusiveFlag;
	}

	public void setWebExclusiveFlag(boolean webExclusiveFlag) {
		this.webExclusiveFlag = webExclusiveFlag;
	}
	
	public String getWebExDispoCode() {
		return webExclusiveDispoCode;
	}

	public void setWebExDispoCode(String webExclusiveDispoCode) {
		this.webExclusiveDispoCode = webExclusiveDispoCode;
	}
	
	public boolean getDamagedFlag() {
		return damagedFlag;
	}

	public void setDamagedFlag(boolean damagedFlag) {
		this.damagedFlag = damagedFlag;
	}


	/**
	 * @return the storeNumber
	 */
	public String getStoreNumber() {
		return storeNumber;
	}


	/**
	 * @param storeNumber the storeNumber to set
	 */
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}
}