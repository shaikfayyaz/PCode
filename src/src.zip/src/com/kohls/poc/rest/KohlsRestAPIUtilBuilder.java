package com.kohls.poc.rest;

import org.springframework.http.ResponseEntity;

import java.util.TreeMap;

public class KohlsRestAPIUtilBuilder {
    private String payload;
    private TreeMap<String, String> mapHeader;
    private TreeMap<String, String> depHeaderMap;
    private String strQueryParam;
    private String strDomain;
    private String strEndPoint;
    private String strApiKey;
    private String strApiSecretKey;
    private String strReadTimeOut;
    private String connectTimeOut;
    private String strMethod;
    private String httpMethod;
    private boolean bProxyRequired;
    private String strProxyHost;
    private int iProxyPort;

    public KohlsRestAPIUtilBuilder setPayload(String payload) {
        this.payload = payload;
        return this;
    }

    public KohlsRestAPIUtilBuilder setMapHeader(TreeMap<String, String> mapHeader) {
        this.mapHeader = mapHeader;
        return this;
    }

    public KohlsRestAPIUtilBuilder setDepHeaderMap(TreeMap<String, String> depHeaderMap) {
        this.depHeaderMap = depHeaderMap;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrQueryParam(String strQueryParam) {
        this.strQueryParam = strQueryParam;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrDomain(String strDomain) {
        this.strDomain = strDomain;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrEndPoint(String strEndPoint) {
        this.strEndPoint = strEndPoint;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrApiKey(String strApiKey) {
        this.strApiKey = strApiKey;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrApiSecretKey(String strApiSecretKey) {
        this.strApiSecretKey = strApiSecretKey;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrReadTimeOut(String strReadTimeOut) {
        this.strReadTimeOut = strReadTimeOut;
        return this;
    }

    public KohlsRestAPIUtilBuilder setConnectTimeOut(String connectTimeOut) {
        this.connectTimeOut = connectTimeOut;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrMethod(String strMethod) {
        this.strMethod = strMethod;
        return this;
    }

    public KohlsRestAPIUtilBuilder setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
        return this;
    }

    public KohlsRestAPIUtilBuilder setbProxyRequired(boolean bProxyRequired) {
        this.bProxyRequired = bProxyRequired;
        return this;
    }

    public KohlsRestAPIUtilBuilder setStrProxyHost(String strProxyHost) {
        this.strProxyHost = strProxyHost;
        return this;
    }

    public KohlsRestAPIUtilBuilder setiProxyPort(int iProxyPort) {
        this.iProxyPort = iProxyPort;
        return this;
    }

    public ResponseEntity<String> invokeCreateConnection() throws Exception {
        return new KohlsRestAPIUtil().createConnection(payload, mapHeader, depHeaderMap, strQueryParam, strDomain, strEndPoint, strApiKey, strApiSecretKey, strReadTimeOut, connectTimeOut, strMethod, httpMethod, bProxyRequired, strProxyHost, iProxyPort);
    }

}
