package com.kohls.poc.rest;

import java.util.List;

public class KohlsFraudDataOutJson
{

	
	public List<Records> records = null;
	

	public List<Records> getRecords() {
		return records;
	}

	public void setRecords(List<Records> records) {
		this.records = records;
	}




	public class Records 
	{
		

		private String dept;
		private String maj;
		private String sub;
		private String risk;
		private String action;
		

		public String getDept() {
			return dept;
		}

		public void setDept(String dept) {
			this.dept = dept;
		}

		public String getSubClass() {
			return sub;
		}

		public void setSubClass(String sub) {
			this.sub = sub;
		}

		public String getMajorClass() {
			return maj;
		}

		public void setMajorClass(String maj) {
			this.maj = maj;
		}

		public String getRisk() {
			return risk;
		}

		public void setRisk(String risk) {
			this.risk = risk;
		}

		public String getAction() {
			return action;
		}

		public void setAction(String action) {
			this.action = action;
		}

	}
}