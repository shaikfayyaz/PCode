package com.kohls.poc.rest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.*;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.kohls.poc.util.KohlsPoCSecurityUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.tgcs.tcx.gravity.util.ServerTypeHelper;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

/**
 * @author tkmaagk
 */
public class KohlsCallToDKCWrapper extends KOHLSBaseApi {

    private final static YFCLogCategory logger = YFCLogCategory.instance(KohlsCallToDKCWrapper.class);

    String receiptNumber;
    String storeNumber;
    String registerId;
    String transactionNumber;
    String amount;
    String customerOrderNumber;
    String HTTP_METHOD = "POST";
    String CONTENT_TYPE = "application/json";
    String Domain;
    String ApiKey;
    String ApiSecret;
    String QueryParams;
    String barcode;
    String scanIndicator;
    String qualifiedMerchandiseAmount;
    String messageType;
    Boolean bScanIndicator;
    Double dQualifiedMerchandiseAmount;
    String timestamp;
    String dateTimestamp;
    String sOrderHeaderKey;
    String sPOCFeature;
    String strtempDomain;

    boolean bWriteToFile = true;

    public String strQueryParam = "";

    public KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();

    private Properties props;

    /**
     * This function sets the attribute from the input xml
     *
     * @param env
     * @param Document
     * @return Document
     * @throws YFSException
     */
    public Document callToDeactivateKC(YFSEnvironment env, Document inputDoc) throws YFSException {
        logger.beginTimer("KohlsCallToDKCWrapper.callDeactivateKC");
        long startTime = System.currentTimeMillis();

        if (logger.isDebugEnabled()) {
            logger.debug(
                    "KohlsCallToDKCWrapper.callDeactivateKC- inputDoc " + com.custom.util.xml.XMLUtil.getXMLString(inputDoc));
        }

        JSONObject jsonResponse;
        Document docDKC = SCXmlUtil.createDocument("DigitalKohlsCashDeactivation");
        boolean useStubDomain = false;
        HashMap<String, JSONObject> dkcMap = new HashMap<String, JSONObject>();
        try {
            Element eleInOrder = inputDoc.getDocumentElement();
            if (!YFCCommon.isVoid(eleInOrder)) {

                TreeMap<String, String> mapHeader = new TreeMap();
                mapHeader.put("Accept-Encoding", "gzip,deflate");
                mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");

                String issodate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
                String strUuid = restApiUtil.getUUID();
                final TreeMap<String, String> depHeaderMap = new TreeMap();
                depHeaderMap.put("X-KOHLS-MessageID", strUuid);
                depHeaderMap.put("X-KOHLS-CreateDateTime", issodate);
                depHeaderMap.put("X-KOHLS-From-App", KohlsPOCConstant.FROM_SYSTEM_POC);
                depHeaderMap.put("X-KOHLS-From-SystemCode", KohlsPOCConstant.FROM_SYSTEM_POC);
                depHeaderMap.put("X-KOHLS-CorrelationID", KohlsPoCCommonAPIUtil.getCorrelationID());

                String strDomain = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_DOMAIN);
                useStubDomain = isUsingDKCStub(env);
                if (useStubDomain) {
                    strDomain = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_STUB_DOMAIN);
                }

                String strEndPoint = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_ENDPOINT);

                strtempDomain = strDomain + strEndPoint;
                if (logger.isDebugEnabled()) {
                    logger.debug("Domain Endpoint: " + strtempDomain);
                }

                if (!"".equalsIgnoreCase(strQueryParam)) {
                    strtempDomain += "?" + strQueryParam;
                }

                String strReadTimeOut = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_READ_TIMEOUT);
                if (YFCCommon.isVoid(strReadTimeOut) || KohlsPOCConstant.RT_DKC_READ_TIMEOUT.equals(strReadTimeOut)) {
                    strReadTimeOut = "10000";
                }
                if (logger.isDebugEnabled()) {
                    logger.debug("Read Timeout:" + strReadTimeOut);
                }
                String strConnTimeOut = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_CONNECT_TIMEOUT);
                if (YFCCommon.isVoid(strConnTimeOut) || KohlsPOCConstant.RT_DKC_CONNECT_TIMEOUT.equals(strConnTimeOut)) {
                    strConnTimeOut = "10000";
                }
                if (logger.isDebugEnabled()) {
                    logger.debug("Connect Timeout:" + strConnTimeOut);
                }

                String strApiKey = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_API_KEY);
                String strApiSecretKey = KohlsRestAPIUtil.getPropertyValue(KohlsPOCConstant.RT_DKC_API_SECRET);

                sOrderHeaderKey = eleInOrder.getAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY);
                dateTimestamp = eleInOrder.getAttribute("DateTime"); // yyyy-MM-dd'T'HH:mm:ss
                if (YFCCommon.isVoid(dateTimestamp)) {
                    dateTimestamp = issodate;
                }
                storeNumber = eleInOrder.getAttribute("StoreID");
                registerId = eleInOrder.getAttribute("RegisterID");

                Element eleOrderExtn = XMLUtil.getChildElement(eleInOrder, KohlsPOCConstant.E_EXTN);
                if (!YFCCommon.isVoid(eleOrderExtn)) {
                    sPOCFeature = eleOrderExtn.getAttribute(KohlsPOCConstant.EXTN_POC_FEATURE);
                }

                NodeList eleKCList = SCXmlUtil.getXpathNodes(eleInOrder,
                        "//KohlsCashList/KohlsCash[@PromotionType='" + KohlsPOCConstant.KOHLS_CASH_UNEARNED
                                + "' or @PromotionType='" + KohlsPOCConstant.LOYALTY_KC_UNEARNED + "']");

                List<RKCValue> dkcList = new ArrayList<RKCValue>();
                for (int i = 0; i < eleKCList.getLength(); i++) {
                    Element eleKC = (Element) eleKCList.item(i);
                    transactionNumber = eleKC.getAttribute(KohlsPOCConstant.A_TRANSACTION_NUMBER);
                    amount = eleKC.getAttribute(KohlsPOCConstant.UNEARNED_VALUE);
                    barcode = eleKC.getAttribute("Barcode");
                    receiptNumber = eleKC.getAttribute(KohlsConstant.A_RECEIPTID);
                    qualifiedMerchandiseAmount = eleKC.getAttribute("EligibleAmt");
                    dQualifiedMerchandiseAmount = Double.parseDouble(qualifiedMerchandiseAmount);
                    try {
                        // skip KCRD for zero amount
                        if (Double.parseDouble(amount) > 0.0) {
                            dkcList.add(createReqPayload());
                        } else {
                            if (logger.isDebugEnabled()) {
                                logger.debug("Skip KCRD for barcode: " + barcode + " amount: " + amount);
                            }
                        }
                    } catch (Exception e) {
                        // skip KCRD
                        if (logger.isDebugEnabled()) {
                            logger.debug("Skip KCRD for barcode: " + barcode + " amount: " + amount);
                        }
                    }
                    JSONObject jsonObj = new JSONObject();
                    jsonObj.put(KohlsPOCConstant.A_PROMOTION_TYPE, eleKC.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE));
                    jsonObj.put(KohlsPOCConstant.A_PROMOTION_ID, eleKC.getAttribute(KohlsPOCConstant.A_PROMOTION_ID));
                    jsonObj.put(KohlsPOCConstant.A_RESULT, false);
                    dkcMap.put(barcode, jsonObj);
                }

                JSONObject jsonResult = new JSONObject();
                boolean bReadtimedout = false;
                if (dkcList.size() > 0) {
                    GsonBuilder builder = new GsonBuilder();
                    Gson gson = builder.create();
                    String reqJson = gson.toJson(dkcList).toString();
                    if (logger.isDebugEnabled()) {
                        logger.debug("jsonPayload--->" + reqJson);
                    }
                    SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
                    timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));

                    String sFilePath = "";
                    String sFileName = "DKCDeactivation_" + (useStubDomain ? "Stubbed_" : "") + timestamp + "_" + storeNumber
                            + "_" + registerId + "_" + transactionNumber + ".txt";
                    try {
                        sFilePath = KohlsRestAPIUtil.getPropertyValue(this.props.getProperty("LogDir"));
                        restApiUtil.writeToFile("Request is ----> \n", reqJson, sFileName, sFilePath);
                    } catch (Exception ex) {
                        bWriteToFile = false;
                        if (logger.isDebugEnabled()) {
                            logger.debug("Logger Dir does not exist. So moving on");
                        }
                    }

                    try {
                        ResponseEntity<String> response = restApiUtil.createConnection(reqJson, mapHeader, depHeaderMap,
                                strQueryParam, strtempDomain, strEndPoint, strApiKey, strApiSecretKey, strReadTimeOut,
                                strConnTimeOut, KohlsPOCConstant.RKC_METHOD_NAME, null, false, null, 0);
                        if ((response != null) && (response.getStatusCode().toString().equals("200") ||
                                response.getStatusCode().toString().equals("206"))) {
                            String responseBody = response.getBody();

                            if (bWriteToFile) {
                                try {
                                    restApiUtil.writeToFile("Response is ----> \n", responseBody, sFileName, sFilePath);
                                } catch (Exception ex) {
                                    if (logger.isDebugEnabled()) {
                                        logger.debug("Logger Dir does not exist. So moving on");
                                    }
                                }
                            }

                            jsonResponse = new JSONObject(responseBody);
                            if (!YFCCommon.isVoid(jsonResponse)) {
                                jsonResult = jsonResponse;
                            }
                        }
                    } catch (Exception e) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Exception while calling DKC API Deactivation Webservice: " + e);
                        }
                        if (bWriteToFile) {
                            try {
                                restApiUtil.writeToFile("Error is ----> \n", e.getMessage(), sFileName, sFilePath);
                            } catch (Exception ex) {
                                if (logger.isDebugEnabled()) {
                                    logger.debug("Logger Dir does not exist. So moving on");
                                }
                            }
                        }
                        // Check for socket read timedout error
                        Throwable t = e;
                        Pattern p = Pattern.compile("(?i)Read\\s*time.*out");
                        while (!YFCCommon.isVoid(t) && !(bReadtimedout = p.matcher(t.getMessage() == null ? "" : t.getMessage()).find())) {
                            t = t.getCause();
                        }
                    }
                }
                // update insertion result
                int n = 1;
                int count = dkcMap.size();
                for (Iterator<String> i = dkcMap.keySet().iterator(); i.hasNext(); ) {
                    String sBarcode = i.next();
                    JSONObject jsonPromo = dkcMap.get(sBarcode);
                    String sResult = jsonResult.optString(sBarcode);
                    boolean bResult = "Inserted".equalsIgnoreCase(sResult);
                    if (bReadtimedout) {
                        // read timeout is a no response => kc deactivated
                        bResult = true;
                        // tokenize barcode
                        KohlsPoCSecurityUtil obj = new KohlsPoCSecurityUtil();
                        HashMap<String, String> resultSet = obj.encryptDecryptUsingProtegrity(env, storeNumber,
                                KohlsPOCConstant.PROTEGRITY_SECURE, sBarcode, KohlsPOCConstant.PROTEGRITY_TKN_KCASH);
                        if (resultSet != null && ("SUCCESS".equalsIgnoreCase(resultSet.get("Status"))
                                || "NA".equalsIgnoreCase(resultSet.get("Status")))) {
                            sBarcode = resultSet.get("Value");
                        }
                        logger.info("KCRD no response after " + strReadTimeOut + "ms for coupon " + n++ + "/" + count + " " + sBarcode);
                    }
                    jsonPromo.put(KohlsPOCConstant.A_RESULT, bResult);
                }
            }
        } catch (Exception e) {
            if (logger.isDebugEnabled()) {
                logger.debug("Exception reading KohlsCash Deactivation API endpoint info: " + e);
            }
            if (bWriteToFile) {
                try {
                    String sFileName = "DKCDeactivation_" + (useStubDomain ? "Stubbed_" : "") + timestamp + "_" + storeNumber
                            + "_" + registerId + "_" + transactionNumber + ".txt";
                    String sFilePath = KohlsRestAPIUtil.getPropertyValue(props.getProperty("LogDir"));
                    restApiUtil.writeToFile("Error is ----> \n", e.getMessage(), sFileName, sFilePath);
                } catch (Exception ex) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Logger Dir does not exist. So moving on");
                    }
                }
            }
        }

        try {
            // prepare returning xml
            Document docDKCCoupons = XMLUtil.createDocument("KohlsCashCoupons");
            Element eleDKCCouponsRoot = docDKCCoupons.getDocumentElement();
            for (Iterator<String> i = dkcMap.keySet().iterator(); i.hasNext(); ) {
                String sBarcode = i.next();
                JSONObject jsonPromo = dkcMap.get(sBarcode);
                try {
                    Document docCouponStatus = XMLUtil.createDocument(KohlsPOCConstant.A_COUPON_STATUS);
                    Element eleCouponStatus = docCouponStatus.getDocumentElement();
                    eleCouponStatus.setAttribute("CouponNo", sBarcode);
                    eleCouponStatus.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, jsonPromo.getString(KohlsPOCConstant.A_PROMOTION_ID));
                    eleCouponStatus.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, jsonPromo.getString(KohlsPOCConstant.A_PROMOTION_TYPE));
                    eleCouponStatus.setAttribute(KohlsPOCConstant.A_RESULT, jsonPromo.getString(KohlsPOCConstant.A_RESULT));
                    // update order
                    callChangeOrder(env, docCouponStatus);
                    // update out xml
                    eleDKCCouponsRoot.appendChild(docDKCCoupons.importNode(eleCouponStatus, true));
                } catch (Exception e) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Exception while persisting deactivation result. " + e);
                    }
                    if (bWriteToFile) {
                        try {
                            String sFileName = "DKCDeactivation_" + (useStubDomain ? "Stubbed_" : "") + timestamp + "_" + storeNumber
                                    + "_" + registerId + "_" + transactionNumber + ".txt";
                            String sFilePath = KohlsRestAPIUtil.getPropertyValue(props.getProperty("LogDir"));
                            restApiUtil.writeToFile("Error is ----> \n", e.getMessage(), sFileName, sFilePath);
                        } catch (Exception ex) {
                            if (logger.isDebugEnabled()) {
                                logger.debug("Logger Dir does not exist. So moving on");
                            }
                        }
                    }
                }
            }
            // update out xml
            docDKC.getDocumentElement().appendChild(docDKC.importNode(eleDKCCouponsRoot, true));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            if (logger.isDebugEnabled()) {
                logger.debug("Exception persisting deactivation result. " + e);
            }
        }

        logger.endTimer("KohlsCallToDKCWrapper.callDeactivateKC");
        if (logger.isDebugEnabled()) {
            logger.debug(
                    "KohlsCallToDKCWrapper.callDeactivateKC- outputDoc " + com.custom.util.xml.XMLUtil.getXMLString(docDKC));
        }

        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        logger.info("Realtime KohlsCash Deactivation service call took " + duration + "ms." +
                " Endpoint: " + strtempDomain);

        return docDKC;
    }

    private RKCValue createReqPayload() {
        RKCValue rkcReq = new RKCValue();

        if (!YFCCommon.isVoid(barcode)) {
            rkcReq.setBarcode(barcode);
        }
        if (!YFCCommon.isVoid(receiptNumber)) {
            rkcReq.setReceiptNumber(receiptNumber);
        }
        if (!YFCCommon.isVoid(dateTimestamp)) {
            rkcReq.setTimestamp(dateTimestamp);
        }
        if (!YFCCommon.isVoid(storeNumber)) {
            rkcReq.setStoreNumber(storeNumber);
        }
        if (!YFCCommon.isVoid(registerId)) {
            rkcReq.setRegisterID(registerId);
        }
        if (!YFCCommon.isVoid(transactionNumber)) {
            rkcReq.setTransactionNumber(transactionNumber);
        }
        if (!YFCCommon.isVoid(amount)) {
            rkcReq.setAmount(Double.valueOf(amount));
        }
        if (!YFCCommon.isVoid(bScanIndicator)) {
            rkcReq.setScanIndicator(bScanIndicator);
        }
        if (!YFCCommon.isVoid(dQualifiedMerchandiseAmount)) {
            rkcReq.setQualifiedMerchandiseAmount(dQualifiedMerchandiseAmount);
        }
        if (!YFCCommon.isVoid(customerOrderNumber)) {
            rkcReq.setCustomerOrderNumber(customerOrderNumber);
        }
        rkcReq.setMessageType(KohlsPOCConstant.RT_DKC_TYPE);
        rkcReq.setDeductOption("O");
        return rkcReq;
    }

    private void callChangeOrder(YFSEnvironment env, Document docDKCOut) throws Exception {
        logger.beginTimer("KohlsCallToDKCWrapper.callChangeOrder");
        Element eleDKCOutRoot = docDKCOut.getDocumentElement();
        Document docChangeOrderIn = XMLUtil.createDocument(KohlsPOCConstant.ELEM_ORDER);
        Element eleChangeOrderRoot = docChangeOrderIn.getDocumentElement();
        eleChangeOrderRoot.setAttribute(KohlsPOCConstant.ATTR_ORD_HDR_KEY, sOrderHeaderKey);
        eleChangeOrderRoot.setAttribute(KohlsXMLLiterals.A_OVERRIDE, KohlsPOCConstant.YES);
        eleChangeOrderRoot.setAttribute(KohlsPOCConstant.A_ACTION, "Modify");
        Element elePromotions = XMLUtil.createChild(eleChangeOrderRoot, KohlsPOCConstant.E_PROMOTIONS);
        Element elePromotion = XMLUtil.createChild(elePromotions, KohlsPOCConstant.E_PROMOTION);
        String sPromotionID = eleDKCOutRoot.getAttribute(KohlsPOCConstant.A_PROMOTION_ID);
        elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, sPromotionID);
        elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_TYPE, eleDKCOutRoot.getAttribute(KohlsPOCConstant.A_PROMOTION_TYPE));
        Element elePromotionExtn = XMLUtil.createChild(elePromotion, KohlsPOCConstant.E_EXTN);
        // Setting the ExtnIsKCDeactivated flag
        String sResponse = eleDKCOutRoot.getAttribute(KohlsPOCConstant.A_RESULT);
        Boolean bResponse = Boolean.parseBoolean(sResponse);
        if (bResponse) {
            elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_KOHLS_CASH_DEACTIVATED, "Y");
        } else {
            elePromotionExtn.setAttribute(KohlsXMLLiterals.A_EXTN_IS_KOHLS_CASH_DEACTIVATED, "N");
        }
        // Setting minimum template for changeOrder api output
        Document docChangeOrderTemplate = XMLUtil.getDocument("<Order OrderHeaderKey=''/>");
        // Setting env object to ignore the order repricing ue
        env.setTxnObject(KohlsPOCConstant.IGNORE_REPRICING_UE, "true");
        // Setting for ISS
        Element eleAdditionalInfo = XMLUtil.createChild(docChangeOrderIn.getDocumentElement(),
                KohlsXMLLiterals.E_YFCADDITIONALINFO);
        eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, "");
        if (ServerTypeHelper.amIOnEdgeServer()) {
            if (KohlsPOCConstant.ATTR_PRICE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature) ||
                    KohlsPOCConstant.POST_SALE_ADJUSTMENT.equalsIgnoreCase(sPOCFeature)) {
                eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, KohlsXMLLiterals.V_MOTHERSHIP);
                try {
                    String[] promotionIDs = sPromotionID.split("\\s*,\\s*");
                    for (String promotionID : promotionIDs) {
                        elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, promotionID);
                        if (logger.isDebugEnabled()) {
                            logger.debug("Calling changeOrder with input xml on mothership:\n" + XMLUtil.getXMLString(docChangeOrderIn));
                        }
                        invokeAPI(env, docChangeOrderTemplate, KohlsPOCConstant.API_CHANGE_ORDER, docChangeOrderIn);
                    }
                    return;
                } catch (Exception e) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Exception while persisting deactivation value on mothership. " + e);
                    }
                    // try edge
                    eleAdditionalInfo.setAttribute(KohlsXMLLiterals.A_ENDPOINT, "");
                }
            }
        }
        String[] promotionIDs = sPromotionID.split("\\s*,\\s*");
        for (String promotionID : promotionIDs) {
            elePromotion.setAttribute(KohlsPOCConstant.A_PROMOTION_ID, promotionID);
            if (logger.isDebugEnabled()) {
                logger.debug("Calling changeOrder with input xml:\n" + XMLUtil.getXMLString(docChangeOrderIn));
            }
            invokeAPI(env, docChangeOrderTemplate, KohlsPOCConstant.API_CHANGE_ORDER, docChangeOrderIn);
        }
        logger.endTimer("KohlsCallToDKCWrapper.callChangeOrder");
    }

    private boolean isUsingDKCStub(YFSEnvironment env) throws Exception {
        // TODO Auto-generated method stub
        logger.beginTimer("KohlsCallToDKCWrapper.isUsingDKCStub");

        boolean useDKCStub = false;
        Document docRule = SCXmlUtil.createDocument("Rule");
        Element eleInput = docRule.getDocumentElement();
        eleInput.setAttribute("OrganizationCode", !YFCCommon.isVoid(storeNumber) ? storeNumber : KohlsPOCConstant.KOHLS_RETAIL);
        eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, "USE_DKC_API_STUB_DOMAIN");
        Document docOutRule = KohlsCommonUtil.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docRule);
        if (logger.isDebugEnabled() && !YFCCommon.isVoid(docOutRule)) {
            logger.debug("Rule out put xml : " + SCXmlUtil.getString(docOutRule));
        }
        if (!YFCCommon.isVoid(docOutRule) && docOutRule.getDocumentElement().hasChildNodes()) {
            Element eleRuleval = (Element) docOutRule.getDocumentElement().getElementsByTagName("Rule").item(0);
            String sRuleVal = eleRuleval.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
            if ("Y".equalsIgnoreCase(sRuleVal)) {
                useDKCStub = true;
            }
        }
        logger.endTimer("KohlsCallToDKCWrapper.isUsingDKCStub");
        return useDKCStub;
    }

    /**
     * Sets the properties
     *
     * @param prop Properties that need to be set
     * @throws Exception when unable to set the Property
     */

    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
    }

}
