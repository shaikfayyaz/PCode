package com.kohls.poc.rest;


/**
 * @author TKMACJT
 * This is impleted as part of CR 935
 * This class will provide request object for DSB JSON request
 *
 */
public class KohlsPoCRestUpdateSUPCRequest {

	private String supcCode;
	private String status;
	private String store;
	private String offerId;
	private String codeSeqNo;
	private String transactionId;
	private String offerStatus;



	public String getsupcCode() {
		return supcCode;
	}

	public void setsupcCode(String supcCode) {
		this.supcCode = supcCode;
	}
	
	public String getstatus() {
		return status;
	}

	public void setstatus(String status) {
		this.status = status;
	}
	
	public String getstore() {
		return store;
	}

	public void setstore(String store) {
		this.store = store;
	}
	
	public String getofferId() {
		return offerId;
	}

	public void setofferId(String offerId) {
		this.offerId = offerId;
	}
	
	public String getCodeSeqNo() {
		return codeSeqNo;
	}

	public void setCodeSeqNo(String codeSeqNo) {
		this.codeSeqNo = codeSeqNo;
	}
	
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	//ExtendedDataElement
	public String getOfferStatus() {
		return offerStatus;
	}

	public void setOfferStatus(String offerStatus) {
		this.offerStatus = offerStatus;
	}
	
}
