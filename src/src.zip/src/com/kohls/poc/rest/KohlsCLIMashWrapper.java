package com.kohls.poc.rest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.messaging.v1_0.header.HostIpAddressNodeIdStrategy;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.util.webserviceUtil.FailoverUtil;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCLIMashWrapper
{

	public String                 strDomain       = "";
	public String                 strReadTimeOut  = "10000";
	public  String 				 strConnectTimeOut = "10000";
	public String                 strEndPoint     = "";
	public String                 endpoint        = "";
	public String                 strQueryParam   = "";
	public String                 strApiKey       = "";
	public String                 strApiSecretKey = "";
	public String                 strUser="";
	public String                 jsonPayload     = "";
	public KohlsRestAPIUtil       restApiutil     = new KohlsRestAPIUtil();
	private Properties            props;
	public String                 filePrefix;
	private String                sFilePath       = "";
	private static YFCLogCategory logger;
	private String                source          = "";
	private boolean               bWriteToFile    = true;
	String                        activeEndpoint  = "";
	private int                   maxRetries      = 1;
	private int                   count           = 0;
	private boolean               bProxyRequired  = false;
	private String                sProxyRequired  = KohlsPOCConstant.FALSE;
	private String                strProxyHost    = "";
	private int                   iProxyport      = 0;

	static {
		logger = YFCLogCategory.instance(KohlsCLIMashWrapper.class
				.getName());
	}

	public Document callToMASH( YFSEnvironment env, Document input ) throws Exception
	{

		logger.beginTimer( "KohlsCLIMashWrapper.callToMASH");		
		strApiKey =  YFSSystem
				.getProperty(KohlsPOCConstant.CLI_API_KEY);
		strApiSecretKey = YFSSystem
				.getProperty(KohlsPOCConstant.CLI_API_SECRET_KEY );
		if ( !YFCCommon.isVoid(YFSSystem
				.getProperty(KohlsPOCConstant.CLI_READ_TIMEOUT ) ) )
		{
			strReadTimeOut = YFSSystem
					.getProperty(KohlsPOCConstant.CLI_READ_TIMEOUT );
		}
		if ( !YFCCommon.isVoid(YFSSystem
				.getProperty("CLI_CONN_TIMEOUT" ) ) )
		{
			strConnectTimeOut = YFSSystem
					.getProperty("CLI_CONN_TIMEOUT");
		}

		if ( logger.isDebugEnabled() )
		{
			logger.debug( "InDoc--->" + XMLUtil.getXMLString( input ) );
		}

		Element eleInDoc = input.getDocumentElement();
		// If property is defined as Failover then it will get current active endpoint
		source = eleInDoc.getAttribute(KohlsPOCConstant.E_SOURCE);
		strUser = YFSSystem.getProperty( KohlsPOCConstant.CLI_USER );
		FailoverUtil failoverUtil = FailoverUtil.getInstance();
		String threePartKey = "";
		boolean useCliStub = false;
		try
      {
         sFilePath = getPropertyValue(props.getProperty( "LogDir" ) );
         threePartKey = eleInDoc.getAttribute(KohlsPOCConstant.ATTR_STORE_NO)+"-"+eleInDoc.getAttribute( KohlsPOCConstant.ATTR_TERMINAL_ID )+"-"+eleInDoc.getAttribute( KohlsPOCConstant.A_TRANSACTION_NO );
         filePrefix = source + "_"+threePartKey+".txt";
         
      }
      catch ( Exception ex )
      {
         logger.error( "Logger Dir does not exist. So moving on" );
      }
		try
		{
			if ( YFCCommon.isVoid( strDomain ) )
			{
				strDomain = failoverUtil.getActiveEndPoint(KohlsPOCConstant.CLI_DOMAIN );
				useCliStub = useCLIStub(env);
				if(!YFCCommon.isVoid(YFSSystem.getProperty("CLI_STUB_DOMAIN")) && useCliStub)
				{
					logger.info( "CLI processing through stub for ---> "+source+" and Store_Terminal_TranNo --> "+threePartKey);
					strDomain = YFSSystem.getProperty("CLI_STUB_DOMAIN");
				}
			}
		}
		catch ( Exception e )
		{
			if ( failoverUtil.isEndpointMonitored(KohlsPOCConstant.CLI_DOMAIN ) )
			{
				if ( bWriteToFile )
				{
					try
					{
						
						restApiutil.writeToFile( "CLI is OFFLINE. Waiting for Recovery.", "", filePrefix, sFilePath );
					}
					catch ( Exception ex )
					{
						bWriteToFile = false;
						logger.error( "Logger Dir does not exist. So moving on" );
					}
				}
				logger.error( "CLI failover to Offline. Lets wait for recovery" + e.getMessage() );
			}
			else
			{
				logger.error( "Error in getting CLI Domain from COP File" + e.getMessage() );
			}
			throw e;
		}

		if ( YFCCommon.isVoid( activeEndpoint ) )
		{
			activeEndpoint = failoverUtil.getCurrentActiveEndpoint( KohlsPOCConstant.CLI_DOMAIN );
		}
		
		if ( YFCCommon.isVoid( activeEndpoint ) )
		{
			activeEndpoint = "CORP";
		}

		
		fetchEndPoint( source );
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();

		KohlsCLIInJson request = new KohlsCLIInJson();
		
		request = getInputJson( source, input );
		String jsonPayload = gson.toJson( request ).toString();
		String strtempDomain = strDomain + strEndPoint;

		if(bWriteToFile)
		{
		   restApiutil.writeToFile("Request for ---> "+source+", Stub enabled? "+useCliStub+", Store_Terminal_TranNo --> "+threePartKey+"\n", jsonPayload+"\n\n", filePrefix, sFilePath );
		}
		if ( bProxyRequired )
		{
			strProxyHost = YFSSystem.getProperty( KohlsPOCConstant.CLI_PROXY_HOST );
			if ( YFCCommon.isVoid( strProxyHost ) )
			{
				throw new YFSException( "Proxy is Required but no Proxy host is set" );
			}
			String strProxyPort = YFSSystem.getProperty( KohlsPOCConstant.CLI_PROXY_PORT );
			if ( YFCCommon.isVoid( strProxyPort ) )
			{
				throw new YFSException( "Proxy is Required but no Proxy Port is set" );
			}
			try
			{
				iProxyport = Integer.valueOf( strProxyPort );
			}
			catch ( Exception e )
			{
				logger.error( "Incorrect Proxy port set: " + e.getMessage() );
				throw new YFSException( "Incorrect Proxy port set" );
			}
		}
		ResponseEntity<String> response = null;
		Document output = null;

		try
		{
			count++;
			String strMaxRetries =  YFSSystem.getProperty("CLI_RETRY_THRESHOLD");
			if(!YFCCommon.isVoid(strMaxRetries))
			{
				maxRetries =Integer.parseInt(strMaxRetries); 
			}
			TreeMap<String, String> mapHeader = new TreeMap<String, String>();
			mapHeader.put( KohlsPOCConstant.ACCEPT, "application/json" );
			mapHeader.put( KohlsPOCConstant.CONTENT_TYPE, "application/json" );
			String issodate = KohlsRestAPIUtil.getCurrentISODate();
			String strUuid = restApiutil.getUUID();
			final TreeMap<String, String> depHeaderMap = new TreeMap<String, String>();
			depHeaderMap.put( "x-dep-date", issodate );
			depHeaderMap.put( "X-DEP-Date", issodate );
			depHeaderMap.put( KohlsPOCConstant.X_DEP_REQUEST_ID, strUuid );
			depHeaderMap.put( "x-dep-from-system-code", "CH" );
			depHeaderMap.put( "x-dep-from-node", HostIpAddressNodeIdStrategy.getInstance().getNodeId() );
			depHeaderMap.put( "x-dep-from-app", "POC" );

			logger.info( "CLI call made for the source ---> "+source+" and Store_Terminal_TranNo --> "+threePartKey);
			response = restApiutil
					.createConnection( jsonPayload, mapHeader, depHeaderMap, strQueryParam, strtempDomain, strEndPoint, strApiKey, strApiSecretKey, strReadTimeOut,strConnectTimeOut, KohlsPOCConstant.CMDM, null, bProxyRequired, strProxyHost, iProxyport );
			if ( failoverUtil.isEndpointMonitored( KohlsPOCConstant.CLI_DOMAIN ) )
			{
				failoverUtil.resetFailedCounter( KohlsPOCConstant.CLI_DOMAIN, activeEndpoint );
				logger.debug( "KohlsCLIMashWrapper.callToMASH failover props --->\n" + failoverUtil.getWsProperties() );
				try
				{
					restApiutil.writeToFile( "KohlsCLIMashWrapper.callToMASH failover props --->\n" + activeEndpoint, failoverUtil.getWsProperties().toString()+"\n\n", filePrefix, sFilePath );
				}
				catch ( Exception ex )
				{
					bWriteToFile = false;
					logger.error( "Logger Dir does not exist. So moving on" );
				}
			}
			if ( ( response != null ) && ( response.getStatusCode().toString().equals( "200" ) ) )
			{
				String responseBody = response.getBody();
				if(bWriteToFile)
				{
					restApiutil.writeToFile("Response for ---> "+source+", Stub enabled? "+useCliStub+", Store_Terminal_TranNo --> "+threePartKey+"\n", responseBody+"\n\n", filePrefix, sFilePath );
				}
				output = setCLIResponse( null, responseBody );
			}

		}
		catch ( Exception e )
		{
			logger.error( "Exception occured while calling CLI API: " + e.toString() );
			try
			{				
				restApiutil.writeToFile( "Error while calling "+ source+", Stub enabled? "+useCliStub+", Store_Terminal_TranNo --> "+threePartKey+" and the error is ----> \n", e.toString()+"\n\n", filePrefix, sFilePath );
			}
			catch ( Exception ex )
			{
				bWriteToFile = false;
				logger.error( "Logger Dir does not exist. So moving on" );
			}
			String errorCode = "";
			if ( e instanceof YFSException )
			{
				errorCode = ( (YFSException) e ).getErrorCode();
			}
			Throwable tmp = e;
			boolean bNeedToRetry = false;

			if ( tmp.getCause() instanceof java.net.SocketTimeoutException || tmp.getCause() instanceof java.net.ConnectException || tmp.getCause() instanceof java.net.NoRouteToHostException || tmp.getCause() instanceof java.net.UnknownHostException
					|| tmp.getCause() instanceof java.lang.IllegalArgumentException 
					|| "503".equalsIgnoreCase( errorCode ) 
					|| "500".equalsIgnoreCase( errorCode ) 
					|| "CONNECTERROR".equalsIgnoreCase( errorCode ) )
			{
				logger.error( "Connectivity issue with "+source+" for Store_Terminal_TranNo --> "+threePartKey);			
				// Failover framework
				if ( failoverUtil.isEndpointMonitored( KohlsPOCConstant.CLI_DOMAIN ) )
				{
					failoverUtil.compareAndIncrementCounters( KohlsPOCConstant.CLI_DOMAIN, activeEndpoint );
					if ( "PRIMARY".equalsIgnoreCase( activeEndpoint ) )
					{
						logger.info( "CLI: Primary down. reaching out to backup. current failover props value: " + failoverUtil.getWsProperties() );
						try
						{
							restApiutil.writeToFile( "KohlsCLIMashWrapper.callToMASH failover props --->\n" + activeEndpoint, failoverUtil.getWsProperties().toString(), filePrefix, sFilePath );
						}
						catch ( Exception ex )
						{
							bWriteToFile = false;
							logger.error( "Logger Dir does not exist. So moving on" );
						}
						strDomain = failoverUtil.getBackupEndpoint( KohlsPOCConstant.CLI_DOMAIN );
						if ( !YFCCommon.isVoid( strDomain ) )
						{
							activeEndpoint = "BACKUP";
							sProxyRequired = YFSSystem.getProperty( KohlsPOCConstant.CLI_DOMAIN + activeEndpoint + ".PROXY_REQUIRED" );
							bProxyRequired = Boolean.valueOf( sProxyRequired );
							output = callToMASH( env, input );
						}

					}
					else
					{
						throw new YFSException(e.getMessage());

					}
				}
				else
				{					
					if ( count != maxRetries )
					{
						logger.error( "Connectivity issue with "+source+" for Store_Terminal_TranNo --> "+threePartKey);	
						bNeedToRetry = true;
					}
					else
					{
						throw new YFSException(e.getMessage());
					}

				}

			}
			else
			{	
				logger.error( "Non Connectivity issue with "+source+" for Store_Terminal_TranNo --> "+threePartKey);	
				throw new YFSException(e.getMessage());

			}
			if ( bNeedToRetry )
			{
				logger.error( "********** Retrying "+source+" API call again for Store_Terminal_TranNo --> "+threePartKey+" *********" );
				output = callToMASH( env, input );
			}
			//output = setCLIResponse( source, null );

		}

		logger.endTimer( "KohlsCLIMashWrapper. callToMASH");

		return output;
	}
	
	 private boolean useCLIStub(YFSEnvironment env) throws Exception {
	  		// TODO Auto-generated method stub
	      	  logger.beginTimer("KohlsCallDMAPIWrapper.getRuleValueForDM");

	      	  boolean useCLIStub = false;
	      	  Document docRule = SCXmlUtil.createDocument("Rule");
	          Element eleInput = docRule.getDocumentElement();
	          eleInput.setAttribute("OrganizationCode", KohlsPOCConstant.KOHLS_RETAIL);
	          eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, "USE_CLI_STUB");
	          Document docOutRule=
	              KohlsCommonUtil.invokeAPI(env, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docRule);
	          if (logger.isDebugEnabled() && !YFCCommon.isVoid(docOutRule)) {
	            logger.debug("Rule out put xml : " + SCXmlUtil.getString(docOutRule));
	          }
	          if (!YFCCommon.isVoid(docOutRule) && docOutRule.getDocumentElement().hasChildNodes()) {
	        	  Element eleRuleval= (Element) docOutRule.getDocumentElement()
	                .getElementsByTagName("Rule").item(0);                   
	            if(logger.isDebugEnabled()) {
	    	          logger.debug("KohlsCallDMAPIWrapper.getRuleValueForDM ---Element is  "+XMLUtil.getElementXMLString(eleRuleval));
	    	        }
		    	   String sRuleVal=eleRuleval.getAttribute(KohlsPOCConstant.A_RULE_VALUE);
		    	   if(logger.isDebugEnabled()) {
	     	          logger.debug("KohlsCallDMAPIWrapper.getRuleValueForDM Rule value is "+sRuleVal);
	     	        }
		    	   if("Y".equalsIgnoreCase(sRuleVal))
		    	   {
		    		   useCLIStub = true;
		    	   }
	          }  	
	  	      logger.endTimer("KohlsCallDMAPIWrapper.getRuleValueForDM");
	          return useCLIStub;
	  	}

	private void fetchEndPoint( String source )
	{
		logger.beginTimer(  "KohlsCLIMashWrapper. fetchEndPoint");

		// TODO Auto-generated method stub
		if ( KohlsPOCConstant.CLI_SRC_ELIGIBLE.equalsIgnoreCase( source ) )
		{

			strEndPoint =  YFSSystem
					.getProperty(KohlsPOCConstant.CLI_ELIGIBILITY_REQ_ENDPOINT);
		}
		else if ( KohlsPOCConstant.CLI_SRC_OFFER_REQ.equalsIgnoreCase( source ) )
		{

			strEndPoint =  YFSSystem
					.getProperty(KohlsPOCConstant.CLI_OFFER_REQ_ENDPOINT );
		}

		else if ( KohlsPOCConstant.CLI_SRC_VERIFICATION.equalsIgnoreCase( source ) )
		{

			strEndPoint =  YFSSystem
					.getProperty(KohlsPOCConstant.CLI_CUST_VERIFICATION_ENDPOINT );
		}
		logger.endTimer(  "KohlsCLIMashWrapper. fetchEndPoint");

	}

	public void setProperties(Properties prop) throws Exception {
		logger.beginTimer("KohlsCLIMashWrapper.setProperties");
		props = prop;
		logger.debug("In the set properties method");
		logger.endTimer("KohlsCLIMashWrapper.setProperties");
	}

	public String getPropertyValue( String property )
	{
		logger.beginTimer( "KohlsCLIMashWrapper.getPropertyValue" );
		String propValue;
		propValue = YFSSystem.getProperty( property );
		if ( YFCCommon.isVoid( propValue ) )
		{
			propValue = property;
		}
		logger.endTimer( "KohlsCLIMashWrapper.getPropertyValue" );
		return propValue;

	}

	private Document setCLIResponse(File file, String outputString ) throws Exception
	{
		logger.beginTimer(  "KohlsCLIMashWrapper.setCLIResponse");
		
		// File file = new File( "c:/xmls/"+source+".json" )
		Document responseDocument = null;
		if (!YFCCommon.isVoid(outputString))
		{
			responseDocument = getDocumentFromJson( source, outputString );
		}
		else if ( file.exists() )
		{
			if ( !YFCCommon.isVoid( file.getName() ) )
			{
				BufferedReader bufferedReader = new BufferedReader( new FileReader( file.getAbsolutePath() ) );
				String jsonString = null;
				try
				{
					StringBuilder sb = new StringBuilder();
					String line = bufferedReader.readLine();
					while ( line != null )
					{
						sb.append( line.trim() );
						line = bufferedReader.readLine();
					}
					jsonString = sb.toString();
				}
				finally
				{
					bufferedReader.close();
				}
				if ( bWriteToFile )
            {
              
                  
                  restApiutil.writeToFile( "CLI Response-->", jsonString+"\n\n", filePrefix, sFilePath );
              
            }
				responseDocument = getDocumentFromJson( source, jsonString );
			}
		}
		logger.endTimer(  "KohlsCLIMashWrapper. setCLIResponse");

		return responseDocument;
	}

	public Document getDocumentFromJson( String source, String jsonString )
	{
		logger.beginTimer(  "KohlsCLIMashWrapper.getDocumentFromJson");
		Gson gson = new Gson();
		KohlsCLIResponse response = gson.fromJson( jsonString, KohlsCLIResponse.class ); // input

		Document outputDoc = null;
		try
		{
			if ( KohlsPOCConstant.CLI_SRC_ELIGIBLE.equalsIgnoreCase( source ) )
			{
				outputDoc = XMLUtil.createDocument( KohlsPOCConstant.CLI_ELIGIBILITY );
				Element outElement = outputDoc.getDocumentElement();
				outElement.setAttribute( KohlsPOCConstant.CLI_RES_RESPONSE, response.getResponse() );
				outElement.setAttribute( KohlsPOCConstant.CLI_RES_RESPONSE_CODE, response.getResponseCode() );
			}
			else if ( KohlsPOCConstant.CLI_SRC_VERIFICATION.equalsIgnoreCase( source ) )
			{
				outputDoc = XMLUtil.createDocument( KohlsPOCConstant.CLI_CUST_VERIFY );
				Element outElement = outputDoc.getDocumentElement();
				outElement.setAttribute( KohlsPOCConstant.CLI_RES_RESPONSE, response.getResponse() );
				outElement.setAttribute( KohlsPOCConstant.CLI_RES_RESPONSE_CODE, response.getResponseCode() );
            if ( !YFCCommon.isVoid( response.getFirstName() ) )
            {
               outElement.setAttribute( KohlsPOCConstant.CLI_RES_FIRSTNAME, response.getFirstName() );
            }
            if ( !YFCCommon.isVoid( response.getLastName() ) )
            {
               outElement.setAttribute( KohlsPOCConstant.CLI_RES_LASTNAME, response.getLastName() );
            }
            if ( !YFCCommon.isVoid( response.getMiddleInitial() ) )
            {
               outElement.setAttribute( KohlsPOCConstant.CLI_RES_MID_NAME, response.getMiddleInitial() );
            }
			}
			else if ( KohlsPOCConstant.CLI_SRC_OFFER_REQ.equalsIgnoreCase( source ) )
			{
				outputDoc = XMLUtil.createDocument( KohlsPOCConstant.CLI_SRC_OFFER_REQ );
				Element outElement = outputDoc.getDocumentElement();
				if ( !YFCCommon.isVoid( response.getMessage() ) )
            {
				   outElement.setAttribute( KohlsPOCConstant.CLI_RES_MSG, response.getMessage() );
            }
				if ( !YFCCommon.isVoid( response.getCreditLineAmount() ) )
            {
				   outElement.setAttribute( KohlsPOCConstant.CLI_RES_INC_AMT, response.getCreditLineAmount() );
            }
			}
		}
		catch ( Exception e )
		{
			logger.error( "KohlsCLIMashWrapper.getDocumentFromJso-->.Error in parsing output", e );
		}
		logger.debug( "MASH Response: " + XMLUtil.getXMLString( outputDoc ) );
		logger.endTimer(  "KohlsCLIMashWrapper.getDocumentFromJson");

		return outputDoc;
	}

	public KohlsCLIInJson getInputJson( String source, Document inDoc )
	{
		logger.beginTimer(  "KohlsCLIMashWrapper.getInputJson");

		KohlsCLIInJson req = new KohlsCLIInJson();
		List<KohlsCLIInJson.Element> elementList = new ArrayList<KohlsCLIInJson.Element>();

		/* populate request */
		if ( !YFCCommon.isVoid( source ) )
		{
			if ( KohlsPOCConstant.CLI_SRC_ELIGIBLE.equalsIgnoreCase( source ) || KohlsPOCConstant.CLI_SRC_VERIFICATION.equalsIgnoreCase( source ) )
			{

				String tokenNumber = XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_TOKEN_NUM );
				String tokenType = XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_TOKEN_TYPE );
				if(!YFCCommon.isVoid( XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_SSN )))
				{
					String ssn = XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_SSN );
					req.setSsn(ssn);
				}
				if ( KohlsPOCConstant.CLI_SRC_ELIGIBLE.equalsIgnoreCase( source ) )
				{
					String clipchan = XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_CLIP_CHAN );
					req.setClipchan(clipchan);
				}
				req.setTokenNumber(tokenNumber);
				req.setTokenType(tokenType);
				
				req.setUser(strUser);
			}
			else if ( KohlsPOCConstant.CLI_SRC_OFFER_REQ.equalsIgnoreCase( source ) )
			{
				String accountId = XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_ACCOUNT_ID );
				String behaviorId = XMLUtil.getAttribute( inDoc.getDocumentElement(), KohlsPOCConstant.CLI_REQ_BEHAVIOR_ID );
				String accountType = XMLUtil.getAttribute( inDoc.getDocumentElement(), "accountType" );
				NodeList elementNodes = inDoc.getElementsByTagName( KohlsPOCConstant.Element );
				req.setUser( strUser );
				if ( !YFCCommon.isVoid( accountType ) )
				{
					req.setAccountType(accountType);
				}
				if ( !YFCCommon.isVoid( accountId ) )
				{
					req.setAccountId( accountId );
				}
				if ( !YFCCommon.isVoid( behaviorId ) )
				{
					req.setBehaviorId( behaviorId );
				}
				if (elementNodes.getLength() >0 )
				{
					for ( int i = 0; i < elementNodes.getLength(); i++ )
					{
						Element eleElement = (Element) elementNodes.item( i );
						eleElement.getAttribute( KohlsPOCConstant.Element_id );
						KohlsCLIInJson.Element elementObj = req.new Element();
						elementObj.setElementId( eleElement.getAttribute( KohlsPOCConstant.Element_id ) );
						elementObj.setElementValue( eleElement.getAttribute( KohlsPOCConstant.Element_Value) );
						elementList.add( elementObj );

					}

				}
				else
				{
					KohlsCLIInJson.Element elementObj = req.new Element();
					elementObj.setElementId("CLIPCHAN");
					elementObj.setElementValue("C");
					elementList.add( elementObj );

				}
				req.setElement( elementList );

			}
		}
		logger.endTimer(  "KohlsCLIMashWrapper.getInputJson");

		return req;
	}


}