package com.kohls.poc.rest;

import com.kohls.common.util.XMLUtil;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;

import java.util.Properties;

public class KohlsSephoraLookupServiceMockImpl {

    private final static String mockResponse = "<CustomerList>\n" +
            "    <Customer AssociateId=\"\" CustomerAssociateNo=\"\" CustomerRewardsNo=\"\" PilotMember=\"\"\n" +
            "              Segments=\"BI_MEMBER,BI_500_PTS,VIB,SEPHORA_BD_GIFT\">\n" +
            "        <SephoraCustomerDetails RewardsId=\"8887708723659545\" RewardsEmail=\"abc@abc.com\" RewardsBalance=\"1000\">\n" +
            "            <OfferList>\n" +
            "                <Offer OfferId=\"12345\" OfferType=\"BI_CASH\" Name=\"BI Cash\" pointsCost=\"500\"/>\n" +
            "            </OfferList>\n" +
            "        </SephoraCustomerDetails>\n" +
            "    </Customer>\n" +
            "</CustomerList>";


    public Document getCustomerList(YFSEnvironment env, Document inDoc, Properties props) throws Exception {
        return XMLUtil.getDocument(mockResponse);
    }
}
