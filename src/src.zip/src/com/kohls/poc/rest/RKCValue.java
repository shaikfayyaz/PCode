package com.kohls.poc.rest;

public class RKCValue {
	
	private String eventType;
	private String email;
	private String receiptNumber;
	private String timestamp;
	public String getRegisterID() {
		return registerID;
	}
	public void setRegisterID(String registerID) {
		this.registerID = registerID;
	}
	private String storeNumber;
	private String registerID;
	private String transactionNumber;
	private Double amount;
	private String customerOrderNumber;
	
	private String barcode;
	private Boolean scanIndicator;
	private Double qualifiedMerchandiseAmount;
	private String messageType; 	
	private String deductOption;
	
	
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public Boolean getScanIndicator() {
		return scanIndicator;
	}
	public void setScanIndicator(Boolean scanIndicator) {
		this.scanIndicator = scanIndicator;
	}
	public Double getQualifiedMerchandiseAmount() {
		return qualifiedMerchandiseAmount;
	}
	public void setQualifiedMerchandiseAmount(Double qualifiedMerchandiseAmount) {
		this.qualifiedMerchandiseAmount = qualifiedMerchandiseAmount;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getStoreNumber() {
		return storeNumber;
	}
	public void setStoreNumber(String storeNumber) {
		this.storeNumber = storeNumber;
	}
	
	public String getTransactionNumber() {
		return transactionNumber;
	}
	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getCustomerOrderNumber() {
		return customerOrderNumber;
	}
	public void setCustomerOrderNumber(String customerOrderNumber) {
		this.customerOrderNumber = customerOrderNumber;
	}
	/**
	 * @return the deductOption
	 */
	public String getDeductOption() {
		return deductOption;
	}
	/**
	 * @param deductOption the deductOption to set
	 */
	public void setDeductOption(String deductOption) {
		this.deductOption = deductOption;
	}
	
}
