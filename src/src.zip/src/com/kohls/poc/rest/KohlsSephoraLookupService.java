package com.kohls.poc.rest;

import com.kohls.common.util.KOHLSBaseApi;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;

import java.util.Properties;


/**
 * Entry point for OMS sub flow which will lookup a Sephora Beauty Insider given an email address.
 * <p>
 * * https://confluence.kohls.com:8443/pages/viewpage.action?pageId=259818458
 */
public class KohlsSephoraLookupService extends KOHLSBaseApi {
    /**
     * Delegate getting the customer list to the service implementation
     *
     * @param env   The YFS Environment
     * @param inDoc The API input document
     * @return The Response Document
     * @throws Exception For any problem
     */
    public Document getCustomerList(YFSEnvironment env, Document inDoc) throws Exception {
        Properties properties = getProperties();
        String baseUrl = properties.getProperty("SR_LOOKUP_BASE_URL");
        if ("Mock".equalsIgnoreCase(baseUrl))
            return new KohlsSephoraLookupServiceMockImpl().getCustomerList(env, inDoc, properties);

        int maxTries = KohlsCustomerIdentificationTool.getConfiguredRetryCount(env);
        return new KohlsSephoraLookupServiceImpl().getCustomerList(inDoc, properties, maxTries);
    }
}
