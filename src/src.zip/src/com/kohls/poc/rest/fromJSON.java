package com.kohls.poc.rest;

import java.util.List;




public class fromJSON{
	public cls_customers[] customers;
	class cls_customers {
		
		
		public String associateDiscountID;
		public String loyaltyId;	//91112057012
		public boolean pilotStatus;
		public boolean kohlsChargeMvcIndicator;
		public boolean vip;
		public cls_customerName customerName;
		public cls_emailAddress emailAddress;
		public cls_phoneNumber phoneNumber;
		public cls_addressLine1 addressLine1;
		public List<cls_kohlsCash> kohlsCash ;
		public cls_postalCode postalCode;
		public cls_country country;
		public cls_county county;
		public cls_state state;
		public cls_addressLine2 addressLine2;
		public cls_addressLine3 addressLine3;
		public cls_city city;
		public String pendingBarcode;
		public String existingPendingBal;
		public String existingEarnTrackerBal;
		public String PIN;
		
	}
	class cls_kohlsCash {
		public String barcode;
		public String redemptionStartDate;
		public String redemptionEndDate;
		public String remainingValue;
		public String eventTypeCode;
	}
	class cls_customerName {
		public cls_kohlsCharge kohlsCharge;
		public cls_loyalty loyalty;
		public cls_ecommerce ecommerce;
	}
	class cls_kohlsCharge {
		public String first;	//FnPOCTESTERSLNOAAJ
		public String middle;	//MnAAJ
		public String last;	//FnPOCTESTERSLNOAAJ
		public String professionalTitle;	//Mr
	}
	class cls_loyalty {
		public String first;	//FnPOCTESTERSLNOAAJ
		public String middle;	//MnAAJ
		public String last;	//FnPOCTESTERSLNOAAJ
		public String professionalTitle;	//Mr
	}
	class cls_ecommerce {
		public String first;	//FnPOCTESTERSLNOAAJ
		public String middle;	//MnAAJ
		public String last;	//FnPOCTESTERSLNOAAJ
		public String professionalTitle;	//Mr
	}
	class cls_emailAddress {
		public String kohlsCharge;	//POCTESTERSLNOAAJ@GMAIL.COM
		public String loyalty;	//POCTESTERSLNOAAJ@GMAIL.COM
		public String EReceipt;	//POCTESTERSLNOAAJ@GMAIL.COM
		public String ecom;
	}
	
	class cls_phoneNumber {
		public String kohlsCharge;	//8000000066
		public String loyalty;	//8000000066
		public String ecom;
	}
	class cls_addressLine1 {
		public String kohlsCharge;	//1800 SLNOAAJ RD
		public String loyalty;	//1800 SLNOAAJ RD
		//Added for CPE-894 
		public String ecom;
	}
	class cls_postalCode {
		public String kohlsCharge;	//85023
		public String loyalty;	//85023
		//Added for new CMDM field
		public String ecom;
	}
	class cls_country {
		public String kohlsCharge;	
		public String loyalty;		
		public String ecom;
	}
	class cls_county {
		public String kohlsCharge;	
		public String loyalty;		
		public String ecom;
	}
	class cls_state {
		public String kohlsCharge;	
		public String loyalty;		
		public String ecom;
	}
	class cls_city {
		public String kohlsCharge;	
		public String loyalty;		
		public String ecom;
	}
	class cls_addressLine3 {
		public String kohlsCharge;	
		public String loyalty;		
		public String ecom;
	}
	class cls_addressLine2 {
		public String kohlsCharge;	
		public String loyalty;		
		public String ecom;
	}
	
}
