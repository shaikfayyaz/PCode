package com.kohls.poc.rest;

import com.kohls.common.util.XMLUtil;
import com.yantra.yfs.japi.YFSEnvironment;
import org.w3c.dom.Document;

import java.util.Properties;

public class KohlsRewardsLookupServiceMockImpl {

    private static final String WITH_BI_CASH_AND_KOHLS_CASH =
            //language=xml
            "<CustomerList>\n" +
            "    <Customer AssociateId=\"\" CustomerAssociateNo=\"\" CustomerRewardsNo=\"81116235292\" PilotMember=\"Y\"\n" +
                    "              Segments=\"BI_MEMBER,BI_500_PTS,VIB,SEPHORA_BD_GIFT\"\n" +
                    "              ExistingEarnTrackerBal=\"111.00\">\n" +
                    "        <CustomerContactList>\n" +
            "            <CustomerContact DayPhone=\"4145551212\" EmailID=\"COSMO@TEST.COM\" FirstName=\"IsaacSam\" LastName=\"Kramer\">\n" +
            "                <Extn ExtnCustomerAssociateNo=\"\" ExtnIsEmployee=\"N\" ExtnKohlsCharge=\"N\" ExtnKohlsChargeStatus=\"N\"\n" +
            "                      ExtnKohlsChargeStatusSrc=\"N\" ExtnKohlsChargeVIP=\"N\" ExtnLoyaltyPointTotal=\"\" ExtnMVCStatus=\"N\"\n" +
            "                      ExtnMVCStatusSrc=\"R\" ExtnNameSource=\"R\" ExtnRewardsStatus=\"Y\" ExtnRewardsStatusSrc=\"R\"/>\n" +
            "                <CustomerAdditionalAddressList>\n" +
            "                    <CustomerAdditionalAddress>\n" +
            "                        <PersonInfo AddressLine1=\"P O Box 233\" FirstName=\"IsaacSam\" LastName=\"Kramer\" ZipCode=\"53090\"\n" +
            "                                    ZipCodeLoyalty=\"53090\"/>\n" +
            "                    </CustomerAdditionalAddress>\n" +
            "                </CustomerAdditionalAddressList>\n" +
            "            </CustomerContact>\n" +
            "        </CustomerContactList>\n" +
            "        <SephoraCustomerDetails RewardsId=\"8887708723659545\" RewardsEmail=\"abc@abc.com\" RewardsBalance=\"1000\">\n" +
            "            <OfferList>\n" +
            "                <Offer OfferId=\"639210000000007\" OfferType=\"BICASH\" Name=\"BICASH\" pointsCost=\"500\"/>\n" +
            "            </OfferList>\n" +
                    "        </SephoraCustomerDetails>\n" +
                    "        <KohlsCashList>\n" +
                    "            <KohlsCash Barcode=\"639215670245037\"\n" +
                    "                       RedemptionStartDate=\"2021-05-30\"\n" +
                    "                       RedemptionEndDate=\"2021-12-30\"\n" +
                    "                       RemainingValue=\"1.00\"\n" +
                    "                       EventTypeCode=\"2\"/>\n" +
                    "            <KohlsCash Barcode=\"222222222222222\"\n" +
                    "                       RedemptionStartDate=\"2021-05-30\"\n" +
                    "                       RedemptionEndDate=\"2021-12-30\"\n" +
                    "                       RemainingValue=\"10.00\"\n" +
                    "                       EventTypeCode=\"2\"/>\n" +
                    "            <KohlsCash Barcode=\"333333333333333\"\n" +
                    "                       RedemptionStartDate=\"2021-05-30\"\n" +
                    "                       RedemptionEndDate=\"2021-12-30\"\n" +
                    "                       RemainingValue=\"100.00\"\n" +
                    "                       EventTypeCode=\"2\"/>\n" +
                    "        " +
                    "</KohlsCashList>\n" +
                    "    </Customer>\n" +
                    "</CustomerList>";

    private static final String WITH_BI_CASH =
            //language=xml
            "<CustomerList>\n" +
                    "    <Customer AssociateId=\"\" CustomerAssociateNo=\"\" CustomerRewardsNo=\"81116235292\" PilotMember=\"Y\"\n" +
                    "              Segments=\"BI_MEMBER,BI_500_PTS,VIB,SEPHORA_BD_GIFT\"" +
                    ">\n" +
                    "        <CustomerContactList>\n" +
                    "            <CustomerContact DayPhone=\"4145551212\" EmailID=\"COSMO@TEST.COM\" FirstName=\"IsaacSam\" LastName=\"Kramer\">\n" +
                    "                <Extn ExtnCustomerAssociateNo=\"\" ExtnIsEmployee=\"N\" ExtnKohlsCharge=\"N\" ExtnKohlsChargeStatus=\"N\"\n" +
                    "                      ExtnKohlsChargeStatusSrc=\"N\" ExtnKohlsChargeVIP=\"N\" ExtnLoyaltyPointTotal=\"\" ExtnMVCStatus=\"N\"\n" +
                    "                      ExtnMVCStatusSrc=\"R\" ExtnNameSource=\"R\" ExtnRewardsStatus=\"Y\" ExtnRewardsStatusSrc=\"R\"/>\n" +
                    "                <CustomerAdditionalAddressList>\n" +
                    "                    <CustomerAdditionalAddress>\n" +
                    "                        <PersonInfo AddressLine1=\"P O Box 233\" FirstName=\"IsaacSam\" LastName=\"Kramer\" ZipCode=\"53090\"\n" +
                    "                                    ZipCodeLoyalty=\"53090\"/>\n" +
                    "                    </CustomerAdditionalAddress>\n" +
                    "                </CustomerAdditionalAddressList>\n" +
                    "            </CustomerContact>\n" +
                    "        </CustomerContactList>\n" +
                    "        <SephoraCustomerDetails RewardsId=\"8887708723659545\" RewardsEmail=\"abc@abc.com\" RewardsBalance=\"1000\">\n" +
                    "            <OfferList>\n" +
                    "                <Offer OfferId=\"639210000000007\" OfferType=\"BICASH\" Name=\"BICASH\" pointsCost=\"500\"/>\n" +
                    "            </OfferList>\n" +
                    "        </SephoraCustomerDetails>\n" +
                    "    </Customer>\n" +
                    "</CustomerList>";

    private static final String WITH_KOHLS_CASH_ONLY =
            //language=xml
            "<CustomerList>\n" +
                    "    <Customer AssociateId=\"\" CustomerAssociateNo=\"\" CustomerRewardsNo=\"81116235292\" PilotMember=\"Y\"\n" +
                    "              Segments=\"\"\n" +
                    "              ExistingEarnTrackerBal=\"111.00\">\n" +
                    "        <CustomerContactList>\n" +
                    "            <CustomerContact DayPhone=\"4145551212\" EmailID=\"COSMO@TEST.COM\" FirstName=\"IsaacSam\" LastName=\"Kramer\">\n" +
                    "                <Extn ExtnCustomerAssociateNo=\"\" ExtnIsEmployee=\"N\" ExtnKohlsCharge=\"N\" ExtnKohlsChargeStatus=\"N\"\n" +
                    "                      ExtnKohlsChargeStatusSrc=\"N\" ExtnKohlsChargeVIP=\"N\" ExtnLoyaltyPointTotal=\"\" ExtnMVCStatus=\"N\"\n" +
                    "                      ExtnMVCStatusSrc=\"R\" ExtnNameSource=\"R\" ExtnRewardsStatus=\"Y\" ExtnRewardsStatusSrc=\"R\"/>\n" +
                    "                <CustomerAdditionalAddressList>\n" +
                    "                    <CustomerAdditionalAddress>\n" +
                    "                        <PersonInfo AddressLine1=\"P O Box 233\" FirstName=\"IsaacSam\" LastName=\"Kramer\" ZipCode=\"53090\"\n" +
                    "                                    ZipCodeLoyalty=\"53090\"/>\n" +
                    "                    </CustomerAdditionalAddress>\n" +
                    "                </CustomerAdditionalAddressList>\n" +
                    "            </CustomerContact>\n" +
                    "        </CustomerContactList>\n" +
                    "        <KohlsCashList>\n" +
                    "            <KohlsCash Barcode=\"639215670245037\"\n" +
                    "                       RedemptionStartDate=\"2021-05-30\"\n" +
                    "                       RedemptionEndDate=\"2021-12-30\"\n" +
                    "                       RemainingValue=\"1.00\"\n" +
                    "                       EventTypeCode=\"2\"/>\n" +
                    "            <KohlsCash Barcode=\"222222222222222\"\n" +
                    "                       RedemptionStartDate=\"2021-05-30\"\n" +
                    "                       RedemptionEndDate=\"2021-12-30\"\n" +
                    "                       RemainingValue=\"10.00\"\n" +
                    "                       EventTypeCode=\"2\"/>\n" +
                    "            <KohlsCash Barcode=\"333333333333333\"\n" +
                    "                       RedemptionStartDate=\"2021-05-30\"\n" +
                    "                       RedemptionEndDate=\"2021-12-30\"\n" +
                    "                       RemainingValue=\"100.00\"\n" +
                    "                       EventTypeCode=\"2\"/>\n" +
                    "        " +
                    "</KohlsCashList>\n" +
                    "    </Customer>\n" +
                    "</CustomerList>";


    public Document getCustomerList(YFSEnvironment env, Document inDoc, Properties props) throws Exception {
        return XMLUtil.getDocument(WITH_BI_CASH_AND_KOHLS_CASH);
    }

}
