package com.kohls.poc.rest;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.japi.ue.YCPGetCustomerDetailsUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**************************************************************************
 * File : KohlsPoc KohlsCustomerLookupUE.java Author : IBM Created : June 6 2013
 * Modified : July 6 2013 Version : 0.1
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 12/07/2013 IBM First Cut.
 ***************************************************************************** 
 * TO DO :
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file fetches the Customer Details using a synchronous web service call
 * to the Customer MDM Service
 * 
 * @author IBM
 * @version 0.1
 *****************************************************************************/
public class KohlsCustomerDetailsRestUE extends KOHLSBaseApi implements
		YCPGetCustomerDetailsUE {

	private static YFCLogCategory logger;
	static {
		logger = YFCLogCategory.instance(KohlsCustomerDetailsRestUE.class
				.getName());
	}

	/**
	 * This function invokes the Customer webservice to retrieve the Customer
	 * Details
	 * 
	 * @param env
	 *            YFSEnviroment
	 * @param indoc
	 *            input document which contains the details regarding the
	 *            Customer to be fetched
	 * @return outDoc contains the details for the Customer fetched
	 * @exception YFSUserExitException
	 *                thrown when there is SOAPFault and other exceptions
	 */
	public Document getCustomerDetails(YFSEnvironment env, Document indoc)
			throws YFSUserExitException {

		logger.debug("*** Entered into CustomerDetails API ***");

		Document docoutGetCustomer = null;

		String sCustomerChargeCardNo = null;
		String sCustomerRewardsNo = null;

		sCustomerChargeCardNo = XMLUtil.getAttribute(
				indoc.getDocumentElement(), "CustomerChargeCardNo");
		sCustomerRewardsNo = XMLUtil.getAttribute(indoc.getDocumentElement(),
				"CustomerRewardsNo");

		if (YFCCommon.isVoid(sCustomerChargeCardNo)
				&& YFCCommon.isVoid(sCustomerRewardsNo)) {
			try {
				docoutGetCustomer = XMLUtil.newDocument();
			} catch (Exception e) {
				logger.error("in catch exception");
			}

		} else {
			try {
				Document docinGetCustomer = XMLUtil.newDocument();
				logger.debug("docinGetCustomer:"
						+ XMLUtil.getXMLString(docinGetCustomer));
				Element elecustomer = docinGetCustomer
						.createElement("Customer");
				docinGetCustomer.appendChild(elecustomer);
				elecustomer.setAttribute("CustomerChargeCardNo",
						sCustomerChargeCardNo);
				elecustomer.setAttribute("CustomerRewardsNo",
						sCustomerRewardsNo);
				docoutGetCustomer = this.invokeService(env,
						"KohlsCustomerLookupRest", docinGetCustomer);

			} catch (Exception e) {
				logger.error("in catch exception" + e);

			}

		}
		logger.debug("*** End of CustomerDetails API ***");
		logger.debug("docoutGetCustomer:"
				+ XMLUtil.getXMLString(docoutGetCustomer));

		return docoutGetCustomer;
	}

}
