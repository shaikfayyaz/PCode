package com.kohls.poc.rest;

import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.util.webserviceUtil.FailoverUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************

 *****************************************************************************/
public class DSBRestClient implements YIFCustomApi {

	private static YFCLogCategory LOG_CAT = YFCLogCategory
			.instance(DSBRestClient.class);
	private Properties props;
	FailoverUtil fs = FailoverUtil.getInstance();
	boolean isMonitored = false;
	boolean isPrimary = false;
	boolean isBackup = false;
	boolean isOffline = false;

	/**
	 * Default Constructor class
	 * 
	 * @throws Exception
	 *             if anything goes wrong
	 */

	public DSBRestClient() throws Exception {
		super();
	}

	/**
	 * 
	 */
	public ResponseEntity<String> decryptLoyaltyIDByDSB(String payload,
			TreeMap<String, String> mapHeader,
			TreeMap<String, String> depHeaderMap, String strQueryParam,
			String endPoint, String strApiKey, String strApiSecretKey,
			String strReadTimeOut, String trustCertificate, boolean enableAuth) {

		LOG_CAT.beginTimer("DSBRestClient.callDSBRESTService");

		ResponseEntity<String> response = null;
		RestTemplate restTemplate = null;
		HttpEntity<String> request = null;
		boolean buildSignature = enableAuth;

		String strEndPoint = endPoint;

		String monitoredURL = YFSSystem.getProperty(strEndPoint + ".MONITORED");
		String backupURL = YFSSystem.getProperty(strEndPoint
				+ ".BACKUP_ENDPOINT");

		try {

			if (!YFCCommon.isVoid(monitoredURL)) {
				isMonitored = true;
			}

			if (isMonitored) {
				if (!isBackup) {
					strEndPoint = fs.getEndPointToCall(endPoint);
					LOG_CAT.debug("Endpoint to call::" + strEndPoint);
					if (strEndPoint.contains("PRIMARY")) {
						strEndPoint = this.getPropertyValue(endPoint
								+ ".MONITORED");
						isPrimary = true;
					} else if (strEndPoint.contains("BACKUP")) {
						strEndPoint = this.getPropertyValue(endPoint
								+ ".BACKUP_ENDPOINT");
						isBackup = true;
					} else if (strEndPoint.contains("OFFLINE")) {
						isOffline = true;
						throw new YFSException("EXTN_OTHER-OFFLINE",
								"EXTN_OTHER", "EXTN_OTHER");
					}
				} else {
					if (!YFCCommon.isVoid(backupURL)) {
						strEndPoint = this.getPropertyValue(endPoint
								+ ".BACKUP_ENDPOINT");
					} else {
						isOffline = true;
						throw new YFSException("EXTN_OTHER-OFFLINE",
								"EXTN_OTHER", "EXTN_OTHER");
					}
				}
			} else {
				strEndPoint = getPropertyValue(strEndPoint);
				LOG_CAT.debug("The strEndPoint value for other urls is "
						+ strEndPoint);
			}

			HttpHeaders httpHeaders = createHttpHeadForDSB(payload, mapHeader,
					depHeaderMap, strQueryParam, strEndPoint, strApiKey,
					strApiSecretKey, buildSignature, HttpMethod.POST.name());

			request = new HttpEntity<String>(payload, httpHeaders);
			HttpStatus statusCode = null;
			// cert
			HttpComponentsClientHttpRequestFactory requestFactory = null;
			if ("Y".trim().equalsIgnoreCase(trustCertificate)
					|| "y".trim().equalsIgnoreCase(trustCertificate)) {

				TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
					@SuppressWarnings("unused")
					public boolean isTrusted(X509Certificate[] certificate,
							String type) {
						return true;
					}

				};

				SSLContext sslContext = org.apache.http.ssl.SSLContexts
						.custom()
						.loadTrustMaterial(null, acceptingTrustStrategy)
						.build();

				SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(
						sslContext);

				CloseableHttpClient httpClient = HttpClients.custom()
						.setSSLSocketFactory(csf).build();

				requestFactory = new HttpComponentsClientHttpRequestFactory();

				requestFactory.setHttpClient(httpClient);
				// requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));
			} else {
				requestFactory = new HttpComponentsClientHttpRequestFactory();
				requestFactory.setReadTimeout(Integer.parseInt(strReadTimeOut));

			}

			// cert
			if (LOG_CAT.isDebugEnabled() && null != request) {

				LOG_CAT.debug("###### Request is ##### : \n"
						+ "Header Details:" + request.getHeaders()
						+ "Body Content:" + request.getBody());

			}

			LOG_CAT.debug("###### End point URL is ##### : " + strEndPoint);

			restTemplate = new RestTemplate(requestFactory);
			response = restTemplate.exchange(strEndPoint, HttpMethod.POST,
					request, String.class);

			if (!YFCCommon.isVoid(response) && isMonitored) {
				if (isBackup) {
					fs.resetFailedCounter(endPoint, "BACKUP");
				} else {
					fs.resetFailedCounter(endPoint, "PRIMARY");
				}
			}

			if (LOG_CAT.isDebugEnabled()) {
				LOG_CAT.debug("###### Request is ##### : \n"
						+ request.toString());
			}

			String responseBody = response.getBody();
			statusCode = response.getStatusCode();

			if (isError(response.getStatusCode())) {
				LOG_CAT.debug("ERROR | " + response.getStatusCode());
				return response;
			} else {
				return response;
			}

		} catch (Exception e) {

			if (checkToRetryOnBackup(e)) {

				if (!isMonitored) {
					LOG_CAT.debug("The Error message from webservice response is java.net.ConnectException."
							+ " So throwing EXTN_CONNECT");
					throw new YFSException("EXTN_CONNECT", "EXTN_CONNECT",
							"EXTN_CONNECT");
				} else {
					response = validateAndRetryBackup(payload, mapHeader,
							depHeaderMap, strQueryParam, endPoint, strApiKey,
							strApiSecretKey, strReadTimeOut, response,
							backupURL, trustCertificate, buildSignature);
				}
			} else if (validateToFail(e)) {
				LOG_CAT.debug("The Error message from webservice response is "
						+ " So throwing EXTN_IO");
				throw new YFSException("EXTN_IO", "EXTN_IO", "EXTN_IO");
			} else {
				if (!isMonitored) {
					LOG_CAT.debug("The Error message from webservice is Generic. So throwing EXTN_OTHER");
					throw new YFSException("EXTN_OTHER", "EXTN_OTHER",
							"EXTN_OTHER");
				} else {
					response = validateAndRetryBackup(payload, mapHeader,
							depHeaderMap, strQueryParam, endPoint, strApiKey,
							strApiSecretKey, strReadTimeOut, response,
							backupURL, trustCertificate, buildSignature);
				}
			}
		} finally {
			LOG_CAT.debug("wsProperties at the end::" + fs.getWsProperties());
		}
		LOG_CAT.endTimer("InvokeWebService.callEndpoint");
		return response;

	}

	private ResponseEntity<String> validateAndRetryBackup(String payload,
			TreeMap<String, String> mapHeader,
			TreeMap<String, String> depHeaderMap, String strQueryParam,
			String endPoint, String strApiKey, String strApiSecretKey,
			String strReadTimeOut, ResponseEntity<String> response,
			String backupURL, String trustCertificate, boolean buildSignature) {
		LOG_CAT.debug("In Catch");
		LOG_CAT.debug("isMonitored:::" + isMonitored);
		LOG_CAT.debug("offline:::" + isOffline);
		LOG_CAT.debug("backup:::" + isBackup);
		if (isOffline) {
			LOG_CAT.debug("In Offline. The Error message from webservice is Generic. So throwing EXTN_OTHER");
			throw new YFSException("EXTN_OTHER-OFFLINE", "EXTN_OTHER",
					"EXTN_OTHER");
		} else if (isBackup) {
			LOG_CAT.debug("No response from Backup. The Error message from webservice is Generic. So throwing EXTN_OTHER");
			fs.incrementFailedCounter(endPoint, "BACKUP");
			fs.compareFailedThreshold(endPoint, "BACKUP",
					!YFCCommon.isVoid(backupURL));
			throw new YFSException("EXTN_OTHER", "EXTN_OTHER", "EXTN_OTHER");
		} else {

			LOG_CAT.debug("No response from primary");
			fs.incrementFailedCounter(endPoint, "PRIMARY");
			fs.compareFailedThreshold(endPoint, "PRIMARY",
					!YFCCommon.isVoid(backupURL));
			isBackup = true;
			response = decryptLoyaltyIDByDSB(payload, mapHeader, depHeaderMap,
					strQueryParam, endPoint, strApiKey, strApiSecretKey,
					strReadTimeOut, trustCertificate, buildSignature);
		}
		return response;
	}

	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		LOG_CAT.debug("In the set properties method");

	}

	/**
	 * This function is used to get the value for a property
	 * 
	 * @param property
	 *            name in string format
	 * @return String propValue
	 */
	public String getPropertyValue(String property) {
		LOG_CAT.beginTimer("InvokeWebService.getPropertyValue");
		String propValue ;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;			
		}
		LOG_CAT.endTimer("InvokeWebService.getPropertyValue");
		return propValue;

	}

	public HttpHeaders createHttpHeadForDSB(final String payload,
			TreeMap<String, String> mapHeader,
			TreeMap<String, String> depHeaderMap, String strQueryParam,
			String strEndPoint, String strApiKey, String strApiSecretKey,
			boolean buildSignature, String httpMethod) throws Exception {
		KohlsRestAPIUtil restUtil = new KohlsRestAPIUtil();
		String mykey = null;
		String strDecryptApiSecret = null;
		LOG_CAT.beginTimer("KohlsRestAPIUtil.createHttpHeadForDSB Start");
		if (buildSignature) {
			mykey = restUtil.pwdForDecryption("DSB");
			strDecryptApiSecret = restUtil
					.decryptString(strApiSecretKey, mykey);
		}

		final HttpHeaders headers = new HttpHeaders();

		for (Map.Entry<String, String> entry : depHeaderMap.entrySet()) {
			headers.add(entry.getKey(), entry.getValue());
		}
		for (Map.Entry<String, String> entry : mapHeader.entrySet()) {
			headers.add(entry.getKey(), entry.getValue());
		}

		if (buildSignature) {
			final Signature signature = new Signature.Builder()
					.apiSecret(strDecryptApiSecret)
					.apiKey(strApiKey)
					.endpoint(strEndPoint)
					.method(httpMethod)
					.isoDate(depHeaderMap.get("X-KOHLS-CreateDateTime"))
					.depHeaders(
							restUtil.concatSingleValueDEPHeaderParams(depHeaderMap))
					.mediaType("application/json").queryParams(strQueryParam)
					.payload(payload).build();

			headers.add("Authorization", KohlsPOCConstant.AUTHID + strApiKey
					+ ":" + signature.getRequestSignature());
		}

		LOG_CAT.endTimer("KohlsRestAPIUtil.createHttpHeadDSB End");

		return headers;

	}

	public boolean isError(final HttpStatus status) {
		LOG_CAT.beginTimer("KohlsRestAPIUtil.isError");

		HttpStatus.Series series = status.series();

		LOG_CAT.endTimer("KohlsRestAPIUtil.isError");

		return (HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR
				.equals(series));
	}

	boolean checkToRetryOnBackup(Exception e) {

		boolean retry = false;

		if (null != e && null != e.getMessage()) {

			if (e.getMessage().trim().equalsIgnoreCase("404 Not Found".trim())) {
				retry = true;
			}
		}

		if (null != e && null != e.getCause()) {

			if (e.getCause() instanceof java.net.ConnectException) {
				retry = true;
			}

			if (e.getCause() instanceof java.io.IOException
					|| e.getCause() instanceof java.net.SocketTimeoutException) {
				retry = true;
			}

		}
		return retry;
	}

	boolean validateToFail(Exception e) {

		boolean fail = false;

		if (e.getCause() instanceof java.io.IOException
				|| e.getCause() instanceof java.net.SocketTimeoutException) {
			fail = false;
		}
		return fail;

	}

}
