package com.kohls.poc.rest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.custom.util.xml.XMLUtil;
import com.google.gson.Gson;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.KohlsXPathUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sterlingcommerce.framework.utils.SCXmlUtils;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCallReturnReasonCode extends KOHLSBaseApi {

	private final static YFCLogCategory logger = YFCLogCategory
			.instance(KohlsCallReturnReasonCode.class);

	String HTTP_METHOD = "Get";
	String CONTENT_TYPE = "application/json";
	String Domain;
	String EndPointPath;
	String ApiKey;
	String ApiSecret;
	String timestamp;
	boolean bWriteToFile = true;
	public String filePrefix;
	private boolean bProxyRequired = false;
	private String strProxyHost = "";
    private int iProxyport = 0;

	public String strQueryParam = "";

	public KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();
	private Properties props;

	
	/**
	 * This function sets the attribute from the input xml
	 * 
	 * @param env
	 * @param Document
	 * @return Document
	 * @exception YFSException
	 * 
	 */
	public Document  callReturnReasonCodeAPI(YFSEnvironment env,
			Document inputDoc) throws YFSException {
		logger.beginTimer("KohlsCallReturnReasonCode.callReturnReasonCodeAPI");
		if (logger.isDebugEnabled()) {
			logger.debug("KohlsCallReturnReasonCode.callReturnReasonCodeAPI- inputDoc "
					+ com.custom.util.xml.XMLUtil.getXMLString(inputDoc));

		}
		 SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
	        String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
		Document docOutReturnResonCode=null;
		List<Document> docOutKohlsReturnResaonCodeList = new ArrayList<Document>();
		 String sProxyRequired = YFSSystem.getProperty(KohlsPOCConstant.RRC_PROXY_REQUIRED);
	        //sProxyRequired = "false";
	        if(!YFCCommon.isVoid(sProxyRequired)){
	          try {
	            bProxyRequired = Boolean.valueOf(sProxyRequired);
	          } catch (Exception e) {
	            logger.error("Incorrect value set for property DM_PROXY_REQUIRED. Correct values are: true / false");
	            throw new YFSException ("Incorrect value set for property DM_PROXY_REQUIRED. Correct values are: true / false");
	          }
	          //logger.info("Proxy required for "+strDomain+" is: "+sProxyRequired);
	          if(bProxyRequired) {
	             strProxyHost = YFSSystem.getProperty(KohlsPOCConstant.RRC_PROXY_HOST);
	             if(YFCCommon.isVoid(strProxyHost)) {
	               throw new YFSException ("Proxy is Required but no Proxy host is set");
	             }
	             //logger.info("Proxy Host is: "+strProxyHost);
	             String strProxyPort = YFSSystem.getProperty(KohlsPOCConstant.RRC_PROXY_PORT);
	             if(YFCCommon.isVoid(strProxyPort)) {
	               throw new YFSException ("Proxy is Required but no Proxy Port is set");
	             }
	             //logger.info("Proxy Port is: "+strProxyPort);
	             try {
	               iProxyport = Integer.valueOf(strProxyPort);               
	             } catch (Exception e) {
	               logger.error("Incorrect Proxy port set: "+e.getMessage());
	               throw new YFSException ("Incorrect Proxy port set");
	             }
	          }
	        }
		
		JSONObject jsonRespose;
		try {

			String strReadTimeOut = "10000";
			String strConnTimeOut = "10000";
			String sDevice = KohlsPOCConstant.POC_DEVICE_CODE;
			String sDept = "";
			Element eleReasonCode = inputDoc.getDocumentElement();
			ResponseEntity<String> response = null;

			if (!YFCCommon.isVoid(eleReasonCode
					.getAttribute(KohlsPOCConstant.A_DEVICE)))

			{
				sDevice = eleReasonCode.getAttribute(KohlsPOCConstant.A_DEVICE);				
			}
			strQueryParam = KohlsPOCConstant.A_DEVICE.toLowerCase()+"=" + sDevice;
			if (!YFCCommon.isVoid(eleReasonCode
					.getAttribute(KohlsPOCConstant.A_DEPARTMENT)))

			{

				sDept = eleReasonCode.getAttribute(KohlsPOCConstant.A_DEPARTMENT);
				if (!YFCCommon.isVoid(strQueryParam)) {
					if (!YFCCommon.isVoid(sDept))

					{
						strQueryParam = strQueryParam + "&"+KohlsPOCConstant.A_DEPARTMENT.toLowerCase()+"=" + sDept;

					}
				}

			}
			Document docReaturnReasonCodeList = getKohlsReasonCodeList(env,inputDoc);
			env.setTxnObject(KohlsPOCConstant.ENV_RRC_LIST,
					docReaturnReasonCodeList);

			String strEndPoint = (props
					.getProperty(KohlsPOCConstant.RRC_ENDPOINT));
			String strDomain = props.getProperty(KohlsPOCConstant.RRC_DOMAIN); 
			String strtempDomain = strDomain + strEndPoint;
			
			if (!"".equalsIgnoreCase(strQueryParam)) {
				strtempDomain += "?" + strQueryParam;
			}
			String source = eleReasonCode.getAttribute(KohlsPOCConstant.E_SOURCE);
			String sFilePath = "";
            filePrefix =KohlsPOCConstant.RRC_METHOD+"_"+source+"_"+timestamp+".txt";
            if (logger.isDebugEnabled()) {
        		
            logger.debug("KohlsCallReturnReasonCode.callReturnReasonCod---request is --->"+strtempDomain);
            }
            try {
                sFilePath = getPropertyValue(props.getProperty("LogDir"));
                restApiUtil.writeToFile("Request is ----> \n",strtempDomain,filePrefix,sFilePath);
              } catch (Exception ex) {
                  bWriteToFile = false;
                  
                    logger.error("Logger Dir does not exist. So moving on");
              }                       
			if (props.getProperty(KohlsPOCConstant.RRC_READ_TIMEOUT) != null) {

				strReadTimeOut = props
						.getProperty(KohlsPOCConstant.RRC_READ_TIMEOUT);
			}
			
			if (props.getProperty(KohlsPOCConstant.RRC_CONN_TIMEOUT) != null) {

				strConnTimeOut = props
						.getProperty(KohlsPOCConstant.RRC_CONN_TIMEOUT);
			}
			
			TreeMap<String, String> mapHeader = new TreeMap();
			mapHeader.put("Accept-Encoding", "gzip,deflate");
			mapHeader.put(KohlsPOCConstant.CONTENT_TYPE,
					KohlsPOCConstant.APPLICATION_JSON_STRING);
			String issodate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
			.format(new Date());
			String strUuid = restApiUtil.getUUID();
			final TreeMap<String, String> depHeaderMap = new TreeMap();
			depHeaderMap.put(KohlsPOCConstant.X_KOHLS_CORRELATION_ID,
					KohlsPoCCommonAPIUtil.getCorrelationID());
			depHeaderMap.put(KohlsPOCConstant.X_KOHLS_CREATE_DATE_TIME,
					issodate);
			depHeaderMap.put(KohlsPOCConstant.X_KOHLS_MESSAGE_ID, strUuid);
			depHeaderMap.put(KohlsPOCConstant.X_KOHLS_FROM_SYSTEM_CODE,
					KohlsPOCConstant.POC_DEVICE_CODE);
			response = restApiUtil.createConnection("", mapHeader,
					depHeaderMap, strQueryParam, strtempDomain, strEndPoint,
					KohlsPOCConstant.EMPTY, KohlsPOCConstant.EMPTY, strReadTimeOut, strConnTimeOut,
					KohlsPOCConstant.RRC_METHOD, HTTP_METHOD, bProxyRequired, strProxyHost, iProxyport);

			if ((response != null)
					&& (response.getStatusCode().toString().equals(KohlsPOCConstant.HTTP_200))) {
				String responseBody = response.getBody();

				jsonRespose = new JSONObject(responseBody);
				 docOutReturnResonCode = getReturnReasonCode(jsonRespose);
				 
				if (logger.isDebugEnabled()) {

					logger.debug("KohlsCallReturnReasonCode.callReturnReasonCode ---Response payload  " + jsonRespose.toString());

				}
                if(bWriteToFile)
                {
                    try {
                        sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                        restApiUtil.writeToFile("Response is ----> \n",jsonRespose.toString(),filePrefix,sFilePath);
                      } catch (Exception ex) {
                            logger.error("Logger Dir does not exist. So moving on");
                      }
                }
				if (KohlsPOCConstant.RRC_STANDALONE.equalsIgnoreCase(
						source)) {
					docOutKohlsReturnResaonCodeList =toCheckUpdateOrCreate(env,docReaturnReasonCodeList,docOutReturnResonCode,KohlsPOCConstant.RRC_STANDALONE);	
				}
			}
		}

		catch (Exception e) {
			
				logger.error("Exception while invoking Rest API Webservice ##########\n"
						+ e);
			
			throw new YFSException(e.getMessage());

		}

		logger.endTimer("KohlsCallReturnReasonCode.callReturnReasonCode");
		return docOutReturnResonCode;
	}

	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		 logger.beginTimer("KohlsCallReturnReasonCode.setProperties");
		this.props = prop;
		 logger.endTimer("KohlsCallReturnReasonCode.setProperties");
		// LOG_CAT.debug("In the set properties method");

	}

	
	public String getPropertyValue(String property) {
		logger.beginTimer("KohlsCallReturnReasonCode.getPropertyValue");
		String propValue;
		propValue = YFSSystem.getProperty(property);
		// Manoj 10/22: updated to use configured property if
		// customer_overrides.properties does not return any value
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		logger.endTimer("KohlsCallReturnReasonCode.getPropertyValue");
		return propValue;

	}

	
 public List<Document> toCheckUpdateOrCreate(YFSEnvironment env,Document docKohlsReturnReasonCodeList, Document docReturnReasonCode, String rrcStandalone) throws Exception
 {
	 logger.beginTimer("KohlsCallReturnReasonCode.toCheckUpdateOrCreate");
	
	 List<Document> returnList = new ArrayList<Document>();

		NodeList ndlReturReasonCodeList = docReturnReasonCode
				.getElementsByTagName(KohlsPOCConstant.KOHLS_RETURN_REASON_CODE);
		Long lUpdatedDate = null;
		for (int i = 0; i < ndlReturReasonCodeList.getLength(); i++) {

			Element eleReturnReasonCode = (Element) ndlReturReasonCodeList
					.item(i);

			if (!YFCCommon.isVoid(eleReturnReasonCode
					.getAttribute("DepartmentNo"))) {

				Element eleKohlsReturnReasonCode = KohlsXPathUtil
						.getElementByXpath(
								docKohlsReturnReasonCodeList,
								"//KohlsReturnReasonCode[@DepartmentNo='"
										+ eleReturnReasonCode
												.getAttribute(KohlsPOCConstant.A_DEPT_NO)
										+ "']");
				if (!YFCCommon.isVoid(eleKohlsReturnReasonCode)) {
					if (!YFCCommon.isVoid(eleKohlsReturnReasonCode
							.getAttribute(KohlsPOCConstant.A_UPDATED_DATE))) {

						lUpdatedDate = Long.parseLong(eleKohlsReturnReasonCode
								.getAttribute(KohlsPOCConstant.A_UPDATED_DATE));
					}

					if (!YFCCommon.isVoid(eleKohlsReturnReasonCode
							.getAttribute(KohlsPOCConstant.A_DEPT_NO))) {

						if (!YFCCommon.isVoid(eleReturnReasonCode
								.getAttribute(KohlsPOCConstant.A_UPDATED_DATE))) {

							Long lRRCUpadtedDate = Long
									.parseLong(eleReturnReasonCode
											.getAttribute(KohlsPOCConstant.A_UPDATED_DATE));
							if (!YFCCommon.isVoid(lUpdatedDate)) {
								int result = Long.compare(
										lRRCUpadtedDate,lUpdatedDate);

								if (result > 0) {

									eleReturnReasonCode.setAttribute(
											KohlsPOCConstant.A_UPDATE_FLAG, "Y");
									((List<Document>) returnList)
											.add(KohlsXMLUtil
													.getDocumentForElement((Element) eleReturnReasonCode));
									
								}
							}
						}
					} else {

						eleReturnReasonCode.setAttribute(KohlsPOCConstant.A_CREATE_FLAG, KohlsPOCConstant.FLAG_Y);

						((List<Document>) returnList)
								.add(KohlsXMLUtil
										.getDocumentForElement((Element) eleReturnReasonCode));
					}
				}

				else {
					eleReturnReasonCode.setAttribute(KohlsPOCConstant.A_CREATE_FLAG, KohlsPOCConstant.FLAG_Y);

					((List<Document>) returnList)
							.add(KohlsXMLUtil
									.getDocumentForElement((Element) eleReturnReasonCode));
				}
				if (KohlsPOCConstant.RRC_STANDALONE.equalsIgnoreCase(rrcStandalone)) {
					updateorCreateReturnReasonCode(env, KohlsXMLUtil
						.getDocumentForElement((Element) eleReturnReasonCode));
				}
			}
		}
		logger.endTimer("KohlsCallReturnReasonCode.toCheckUpdateOrCreate");

		return returnList;
	}
	public String getDeptAndUpdatedDate(String sDept, YFSEnvironment env)
			throws Exception {
		logger.beginTimer("KohlsCallReturnReasonCode.getDeptAndUpdatedDate");

		Document docReturnReasonCode = XMLUtil.newDocument();
		;
		Element eleReturnReason = docReturnReasonCode
				.createElement(KohlsPOCConstant.KOHLS_RETURN_REASON_CODE);
		eleReturnReason.setAttribute(KohlsPOCConstant.A_DEPT_NO, sDept);
		docReturnReasonCode.appendChild(eleReturnReason);
		Document docGetReturnReasonCode = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_CALL_TO_GET_RRC, docReturnReasonCode);

		String sDeptAndDate = "";
		if (!YFCCommon.isVoid(docGetReturnReasonCode)) {
			if (!YFCCommon.isVoid(docGetReturnReasonCode.getDocumentElement()
					.getAttribute(KohlsPOCConstant.A_DEPT_NO))) {
				if (logger.isDebugEnabled()) {

					logger.debug("KohlsCallReturnReasonCode.getDeptAndUpdatedDate---Department existing  ");
				}
				sDeptAndDate = docGetReturnReasonCode.getDocumentElement()
						.getAttribute("DepartmentNo");
				if (logger.isDebugEnabled()) {

					logger.debug("KohlsCallReturnReasonCode.getDeptAndUpdatedDate---Concatenated department and updateddate"
							+ sDeptAndDate);
				}

			}
			if (!YFCCommon.isVoid(docGetReturnReasonCode.getDocumentElement()
					.getAttribute(KohlsPOCConstant.A_UPDATED_DATE))) {

				sDeptAndDate = sDeptAndDate
						+ "-"
						+ docGetReturnReasonCode.getDocumentElement()
						.getAttribute(KohlsPOCConstant.A_UPDATED_DATE);

			}
		}
		logger.endTimer("KohlsCallReturnReasonCode.getDeptAndUpdatedDate");

		return sDeptAndDate;
	}

	public void createReturnReasonCode(Document eleReturnReasonCode,
			YFSEnvironment env) throws Exception {
		logger.beginTimer("KohlsCallReturnReasonCode.createReturnReasonCode");

		Document docGetReturnReasonCode = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_CALL_TO_CREATE_RRC, eleReturnReasonCode);
		if (logger.isDebugEnabled()) {

			logger.debug("KohlsCallReturnReasonCode.createReturnReasonCode----After creating reason code "
					+ SCXmlUtils.getString(docGetReturnReasonCode));
		}
		logger.endTimer("KohlsCallReturnReasonCode.createReturnReasonCode");

	}

	public void updateReturnReasonCode(YFSEnvironment env,
			Document docReturnReasonCode) throws Exception {

		logger.beginTimer("KohlsCallReturnReasonCode.updateReturnReasonCode");

		Document docGetReturnReasonCode = KOHLSBaseApi.invokeService(env,
				KohlsPOCConstant.KOHLS_CALL_TO_UPDATE_RRC, docReturnReasonCode);
		if (logger.isDebugEnabled()) {

			logger.debug("KohlsCallReturnReasonCode.updateReturnReasonCode---After Updating  reason code "
					+ SCXmlUtils.getString(docGetReturnReasonCode));
		}
		logger.endTimer("KohlsCallReturnReasonCode.updateReturnReasonCode");

	}

	public Document getReturnReasonCode(JSONObject reasonCodeJson)
			throws ParserConfigurationException

	{
		logger.beginTimer("KohlsCallReturnReasonCode.getReturnReasonCode");

		String sToParse = "[" + reasonCodeJson.toString() + "]";
		Gson outGson = new Gson();
		KohlsReturnReasonCodeOutJson[] parsedClass = outGson.fromJson(sToParse,
				KohlsReturnReasonCodeOutJson[].class); // input
		// is
		Document docReturnReasonCode = XMLUtil.newDocument();

		Element eleReturnReasonCodelist = docReturnReasonCode
				.createElement(KohlsPOCConstant.KOHLS_RRC_LIST);

		for (int j = 0; j < parsedClass.length; j++) {
			if (logger.isDebugEnabled()) {

				logger.debug("KohlsCallReturnReasonCode.getReturnReasonCode ---Setting attributes--->");
			}
			if (parsedClass[j].returnReasons.length != 0) {
				for (int i = 0; i < parsedClass[j].returnReasons.length; i++) {
					Element eleReturnReason = docReturnReasonCode
							.createElement(KohlsPOCConstant.KOHLS_RETURN_REASON_CODE);
					eleReturnReason.setAttribute(KohlsPOCConstant.A_DEPT_NO,
							parsedClass[j].returnReasons[i].department
							.toString());
					eleReturnReason.setAttribute("Enable",
							parsedClass[j].returnReasons[i].enable.toString());
					eleReturnReason.setAttribute(KohlsPOCConstant.A_CREATED_DATE,
							parsedClass[j].returnReasons[i].createdDate
							.toString());

					eleReturnReason.setAttribute(KohlsPOCConstant.A_UPDATED_DATE,
							parsedClass[j].returnReasons[i].updatedDate
							.toString());

					for (int k = 0; k < parsedClass[j].returnReasons[j].returnReasonCodes.length; k++) {

						if (!YFCCommon
								.isVoid(parsedClass[j].returnReasons[i].returnReasonCodes[k].code
										.toString())) {
							eleReturnReason
							.setAttribute(
									KohlsPOCConstant.A_REASON_CODE
											+ parsedClass[j].returnReasons[i].returnReasonCodes[k].code
											.toString(),
											parsedClass[j].returnReasons[i].returnReasonCodes[k].description
											.toString());

						}
					}
					eleReturnReasonCodelist.appendChild(eleReturnReason);

				}
			}

			docReturnReasonCode.appendChild(eleReturnReasonCodelist);

			if (logger.isDebugEnabled()) {

				logger.debug("KohlsCallReturnReasonCode.getReturnReasonCode--- Return Reason Code is "
						+ XMLUtil.getElementXMLString(eleReturnReasonCodelist));
			}

		}
		if (logger.isDebugEnabled()) {

			logger.debug(" KohlsCallReturnReasonCode.getReturnReasonCode---List of return reason Code  "
					+ XMLUtil.getElementXMLString(docReturnReasonCode
							.getDocumentElement()));
		}
		logger.endTimer("KohlsCallReturnReasonCode.getReturnReasonCode");

		return docReturnReasonCode;

	}

	public Document getKohlsReasonCodeList(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.beginTimer("KohlsCallReturnReasonCode.getKohlsReasonCodeList");

		Document docReturnReasonCodeList = KOHLSBaseApi.invokeService(env,
				
				KohlsPOCConstant.KOHLS_CALL_TO_GET_RRC_LIST, inDoc);
		logger.endTimer("KohlsCallReturnReasonCode.getKohlsReasonCodeList");

		return docReturnReasonCodeList;

	}

	public void updateorCreateReturnReasonCode(YFSEnvironment env,
			Document docReturnResonCode) throws Exception {
		logger.beginTimer("KohlsCallReturnReasonCode.updateorCreateReturnReasonCode");

		Element eleReturnResonCode= docReturnResonCode.getDocumentElement();
		
		if(!YFCCommon.isVoid(eleReturnResonCode))
		{
			
			if(eleReturnResonCode.getAttribute(KohlsPOCConstant.A_CREATE_FLAG).equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
				
				
			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsCallReturnReasonCode.updateorCreateReturnReasonCode--.CREATE record");
				}
				
				createReturnReasonCode(XMLUtil.getDocumentForElement(eleReturnResonCode), env);
			}
			else if(eleReturnResonCode.getAttribute(KohlsPOCConstant.A_UPDATE_FLAG).equalsIgnoreCase(KohlsPOCConstant.FLAG_Y))
				
			{
				if (logger.isDebugEnabled()) {
					logger.debug("KohlsCallReturnReasonCode.updateorCreateReturnReasonCode---UPDATE Record");
				}
				updateReturnReasonCode(env, XMLUtil.getDocumentForElement(eleReturnResonCode));
			}
			
			}
		logger.endTimer("KohlsCallReturnReasonCode.updateorCreateReturnReasonCode");

		}
		// TODO Auto-generated method stub
		
	


}																																		
