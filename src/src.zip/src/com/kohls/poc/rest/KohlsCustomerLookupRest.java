package com.kohls.poc.rest;



import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.KOHLSStringUtil;
import com.kohls.messaging.v1_0.header.HostIpAddressNodeIdStrategy;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.fromJSON.cls_kohlsCash;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsCustomerLookupRest extends KOHLSBaseApi {

  public String strDomian = "";
  public String strReadTimeOut = "";
  public String strEndPoint = "";
  public String strQueryParam = "";
  public String strApiKey = "";
  public String strApiSecretKey = "";
  public KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
  private Properties props;
  private static YFCLogCategory logger;
  static {
    logger = YFCLogCategory.instance(KohlsCustomerLookupRest.class.getName());
  }

  /**
  * Returns the correct properties name by store
  * @param env
  * @param inDoc
  * @param propertyName
  * @return
  * @throws Exception
  */
  protected static String qualifyPropVersion(YFSEnvironment env, Document inDoc, String propertyName) throws Exception {
      Element eleInDocOrder = inDoc.getDocumentElement();
      String organizationCode = eleInDocOrder.getAttribute(KohlsPOCConstant.A_SELLER_ORGANIZATION_CODE);
      String loyaltyStore = KohlsPoCCommonAPIUtil.getRuleValue(env, KohlsPOCConstant.LOYALTY_STORE_TYPE_RULE, 
          organizationCode, KohlsPOCConstant.EMPTY);
      if (KohlsPOCConstant.LOYALTY_STORE_Y2Y.equals(loyaltyStore) || 
          KohlsPOCConstant.LOYALTY_STORE_V1_PILOT.equals(loyaltyStore)) {
          return propertyName + "_V4";
      }
      return propertyName;
  }

  public Document getCustomerDetails(YFSEnvironment env, Document inDoc) throws Exception {
    logger.beginTimer("KohlsCustomerLookupRest.getCustomerDetails");
    long startTime = System.currentTimeMillis();
    Document docoutGetCustomer = null;
    String strCustDomain = qualifyPropVersion(env, inDoc, "CUST_DOMAIN");
    strDomian = KohlsRestAPIUtil.getPropertyValue(props.getProperty(strCustDomain, strCustDomain));
    String strCustEndpoint = qualifyPropVersion(env, inDoc, "CUST_ENDPOINT");
    strEndPoint = KohlsRestAPIUtil.getPropertyValue(props.getProperty(strCustEndpoint, strCustEndpoint));
    strApiKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty("CUST_API_KEY"));
    strApiSecretKey = KohlsRestAPIUtil.getPropertyValue(props.getProperty("CUST_API_SECRET_KEY"));
    strReadTimeOut = KohlsRestAPIUtil.getPropertyValue(props.getProperty("CUST_READ_TIME_OUT"));

    logger.debug("InDoc--->" + XMLUtil.getXMLString(inDoc));
    String strISODtae = restApiutil.getCurrentISODate();
    // Create payload
    GsonBuilder builder = new GsonBuilder();
    Gson gson = builder.create();

    String sCustomerChargeCardNo = null;
    String sCustomerRewardsNo = null;

    sCustomerChargeCardNo =
        XMLUtil.getAttribute(inDoc.getDocumentElement(), "CustomerChargeCardNo");
    sCustomerRewardsNo = XMLUtil.getAttribute(inDoc.getDocumentElement(), "CustomerRewardsNo");
    Value v = new Value();
    if (!YFCCommon.isVoid(sCustomerChargeCardNo)) {

      v.setValue(sCustomerChargeCardNo);
      strQueryParam = "alias=kcc";

    }

    if (!YFCCommon.isVoid(sCustomerRewardsNo)) {
      v.setValue(sCustomerRewardsNo);
      strQueryParam = "alias=lyl";
    }

    String jsonPayload = gson.toJson(v).toString();
    logger.debug("jsonPayload--->" + jsonPayload);
    SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
    String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));
    String sFilePath = "";
    boolean bWriteToFile = true;
	String sFileName ="CustomerLookup_"+timestamp+".txt";
    try {
      sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
      restApiutil.writeToFile("Request is ----> \n", jsonPayload, sFileName, sFilePath);
    } catch (Exception ex) {
    	 bWriteToFile = false;
      logger.debug("Logger Dir does not exist. So moving on");
    }
    // System.out.println(gson.toJson(v).toString());
    // System.out.println("jsonPayload ::" + jsonPayload);

    // String
    // strCan=restApiUtil.concatSingleValueDEPHeaderParams(mapdepHeader);
    String strtempDomain = strDomian + strEndPoint + "?" + strQueryParam;
    // PST-444 Changes for CorrelationID
    // MJ 01/16 commented the correlation id for /v4/CustomerSearch
    // depHeaderMap.put("x-dep-correlation-id", KohlsPoCCommonAPIUtil.getCorrelationID());
    ResponseEntity<String> response = null;

    int count = 0;
    int iMaxTries = 1;
    try {
      iMaxTries = Integer.parseInt(KohlsPoCCommonAPIUtil.getRuleValuesfromDB(env));
    } catch (Exception e) {
      logger.debug("Max retries is set as " + iMaxTries + "time");
    }
    logger.debug("Max retries configured is  " + iMaxTries + "time");

    String respStatus = "503";
    while (count <= iMaxTries) {
      try {
        TreeMap<String, String> mapHeader = new TreeMap();
        mapHeader.put(KohlsPOCConstant.ACCEPT, "application/json");
        mapHeader.put(KohlsPOCConstant.CONTENT_TYPE, "application/json");
        String issodate = restApiutil.getCurrentISODate();
        String strUuid = restApiutil.getUUID();
        final TreeMap<String, String> depHeaderMap = new TreeMap();
        depHeaderMap.put("x-dep-date", issodate);
        depHeaderMap.put("X-DEP-Date", issodate);
        depHeaderMap.put(KohlsPOCConstant.X_DEP_REQUEST_ID, strUuid);
        depHeaderMap.put("x-dep-from-system-code", "CH");
        depHeaderMap.put("x-dep-from-node", HostIpAddressNodeIdStrategy.getInstance().getNodeId());
        depHeaderMap.put("x-dep-from-app", "POC");

        count++;
        response = restApiutil.createConnection(jsonPayload, mapHeader, depHeaderMap, strQueryParam,
            strtempDomain, strEndPoint, strApiKey, strApiSecretKey, strReadTimeOut,strReadTimeOut,
            KohlsPOCConstant.CMDM,null, false, null, 0);
        if (response != null) 
        {
          respStatus = response.getStatusCode().toString();
        }
        if ("200".equals(respStatus) || "206".equals(respStatus)) 
        {
          String responseBody = response.getBody();
          logger.debug("responseBody--->" + responseBody);
          JSONObject json = new JSONObject(responseBody);
          // System.out.println("json1-->" + json.toString());
          if(bWriteToFile)
          {
        	  	try {
                 // sFilePath = getPropertyValue(this.props.getProperty("LogDir"));
                  restApiutil.writeToFile("Response is ----> \n", responseBody, sFileName,
                      sFilePath);
                } catch (Exception ex) {
                  logger.debug("Logger Dir does not exist. So moving on");
                }
          }
          

          docoutGetCustomer = setCustomerDetails(strQueryParam, json, v.getValue());
          break;
        }
        // }
      } catch (final Exception e) {
        // System.out.println("in the exception "+e);
        if (e instanceof YFSException)
        {
          respStatus = ((YFSException)e).getErrorCode();
        }
        logger.error("Exception occurred while calling endpoint " + strtempDomain + strEndPoint, e);
        if (count <= iMaxTries) {
          logger.info("Customer Lookup: Retry attempt : " + count + 
            ". Endpoint " + strtempDomain + strEndPoint );
          continue;
        }
        else {
          logger.info("Customer Lookup: Maxed out number of attempts : " + count + 
            ". Endpoint " + strtempDomain + strEndPoint );
        }
        // Manoj 03/16: Changes for defect 1655 - begin
        // CPE-1480 -- Removed "else" condition
        Document inOfflineDoc = null;
        docoutGetCustomer = createCustomerUEOutput();

        Element eleExtn =
            (Element) docoutGetCustomer.getDocumentElement().getElementsByTagName("Extn").item(0);
        // Manoj 03/21: Changes for defect 1664 - Begin
        if (!YFCCommon.isVoid(sCustomerRewardsNo)) {

          inOfflineDoc = XMLUtil.getDocument(KohlsPOCConstant.TEMPLATE_GET_OFFLINE_CUST_REWARD);
          Element eleReward = inOfflineDoc.getDocumentElement();
          eleReward.setAttribute("LoyAcctNbr",
              inDoc.getDocumentElement().getAttribute("CustomerRewardsNo"));
          docoutGetCustomer.getDocumentElement().setAttribute("CustomerRewardsNo",
              inDoc.getDocumentElement().getAttribute("CustomerRewardsNo"));
          // CPE-1480 -- Start --
          if (e instanceof YFSException && ((YFSException) e).getErrorDescription()
              .contains(KohlsPOCConstant.NO_RECORD_FOUND_DESC)) {
            eleExtn.setAttribute("ExtnRewardsStatus", "7");
            logger.info("Customer Lookup: Rewards number does not exist: " + 
              (sCustomerRewardsNo.length() > 4 ? "x" + sCustomerRewardsNo.substring(sCustomerRewardsNo.length() - 4) : "xxxx"));
          } else {
            eleExtn.setAttribute("ExtnRewardsStatus", "9");
            // CPE - 1610 fix
            docoutGetCustomer.getDocumentElement().setAttribute("ExtnServiceOffline", "Y");
            logger.info("Customer Lookup: Service Offline while looking up Rewards number: " + 
              (sCustomerRewardsNo.length() > 4 ? "x" + sCustomerRewardsNo.substring(sCustomerRewardsNo.length() - 4) : "xxxx"));

          }
          // CPE-1480 -- End --
          eleExtn.setAttribute("ExtnRewardsStatusSrc", "R");
          Document outOfflineDoc =
              KOHLSBaseApi.invokeService(env, "GetKOHLSCMDMOfflineRWDList", inOfflineDoc);
          if (!YFCCommon.isVoid(outOfflineDoc)) {
            Element eleKOHLSCMDMOfflineRWD = (Element) outOfflineDoc.getDocumentElement()
                .getElementsByTagName("KOHLSCMDMOfflineRWD").item(0);
            if (!YFCCommon.isVoid(eleKOHLSCMDMOfflineRWD)) {
              String sAssocId = eleKOHLSCMDMOfflineRWD.getAttribute("AssocId");
              if (!YFCCommon.isVoid(sAssocId)) {
                logger.debug("Associate id is " + sAssocId);
                docoutGetCustomer.getDocumentElement().setAttribute("AssociateId", sAssocId);
                if (!YFCCommon.isVoid(eleExtn.getAttribute("ExtnRewardsStatus"))
                    && "9".equalsIgnoreCase(eleExtn.getAttribute("ExtnRewardsStatus"))) {
                  eleExtn.setAttribute("ExtnRewardsStatus", "0");
                }
              }
            }
          }


          if (!YFCCommon.isVoid(sCustomerChargeCardNo)) {
            inOfflineDoc = XMLUtil.getDocument(KohlsPOCConstant.TEMPLATE_GET_OFFLINE_CUST_KC);
            inOfflineDoc.getDocumentElement().setAttribute("KohlsChargeCard",
                inDoc.getDocumentElement().getAttribute("CustomerChargeCardNo"));
            docoutGetCustomer.getDocumentElement().setAttribute("CustomerChargeCardNo",
                inDoc.getDocumentElement().getAttribute("CustomerChargeCardNo"));
            eleExtn.setAttribute("ExtnKohlsChargeStatus", "O");
            eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "K");
            outOfflineDoc =
                KOHLSBaseApi.invokeService(env, "GetKOHLSCMDMOfflineKCList", inOfflineDoc);
            if (!YFCCommon.isVoid(outOfflineDoc)) {
              Element eleKOHLSCMDMOfflineKC = (Element) outOfflineDoc.getDocumentElement()
                  .getElementsByTagName("KOHLSCMDMOfflineKC").item(0);
              if (!YFCCommon.isVoid(eleKOHLSCMDMOfflineKC)) {
                String sAssocId = eleKOHLSCMDMOfflineKC.getAttribute("AssocId");
                if (!YFCCommon.isVoid(sAssocId)) {
                  logger.debug("Associate id is " + sAssocId);
                  docoutGetCustomer.getDocumentElement().setAttribute("AssociateId", sAssocId);
                }
              }
            }

          }
          /*
           * logger.debug("the offline input is "+XMLUtil.getElementXMLString(inOfflineDoc.
           * getDocumentElement())); Document outOfflineDoc= KOHLSBaseApi.invokeService(env,
           * "KohlsCMDMOffline", inOfflineDoc); if(outOfflineDoc!=null) { Element
           * eleKohlsCmdmdOfflineKc=(Element)outOfflineDoc.getDocumentElement().getElementsByTagName
           * ("KOHLSCMDMOfflineKC").item(0); if(eleKohlsCmdmdOfflineKc!=null){ String sAssocId =
           * eleKohlsCmdmdOfflineKc.getAttribute("AssocId"); if(!YFCCommon.isVoid(sAssocId)){
           * logger.debug("Associate id is "+sAssocId);
           * docoutGetCustomer.getDocumentElement().setAttribute("AssociateId",sAssocId); String
           * strRewardNo=XPathUtil.getString(outOfflineDoc.getDocumentElement(),
           * "//KOHLSCMDMOfflineKC/KOHLSCMDMOfflineRWDList/KOHLSCMDMOfflineRWD/@LoyAcctNbr"); String
           * strKohlsChargeCard=XPathUtil.getString(outOfflineDoc.getDocumentElement(),
           * "//KOHLSCMDMOfflineKC/@KohlsChargeCard");
           * 
           * if(!YFCCommon.isVoid(strRewardNo) && !YFCCommon.isVoid(sCustomerRewardsNo)){
           * eleExtn.setAttribute("ExtnRewardsStatus", "O");
           * eleExtn.setAttribute("ExtnRewardsStatusSrc", "R"); }
           * 
           * if(!YFCCommon.isVoid(strKohlsChargeCard) && !YFCCommon.isVoid(sCustomerChargeCardNo)){
           * eleExtn.setAttribute("ExtnKohlsChargeStatus", "O");
           * eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "K"); } } } }
           */
        }
      }
      // Manoj 03/21: Changes for defect 1664 - End
      // Manoj 03/16: Changes for defect 1655 - End
    }
    logger.endTimer("KohlsCustomerLookupRest.getCustomerDetails");
    long endTime = System.currentTimeMillis();
    long duration = endTime - startTime;
    logger.info("Customer Lookup : getCustomerDetails took " + duration + "ms." + " Response status: " + respStatus +
      " Endpoint: " + strtempDomain + strEndPoint);

    return docoutGetCustomer;

  }

  private Document setCustomerDetails(String strQueryParam, JSONObject json, String strValue)
      throws Exception {
    logger.beginTimer("KohlsCustomerLookupRest.setCustomerDetails");
    Document docoutGetCustomer = XMLUtil.newDocument();

    Element elecustomer = docoutGetCustomer.createElement("Customer");

    Element eleCustomerContactList = docoutGetCustomer.createElement("CustomerContactList");
    Element eleCustomerContact = docoutGetCustomer.createElement("CustomerContact");
    Element eleExtn = docoutGetCustomer.createElement("Extn");
    Element eleCustomerAddresList =
        docoutGetCustomer.createElement("CustomerAdditionalAddressList");
    Element eleCustomerAdditionalAddess =
        docoutGetCustomer.createElement("CustomerAdditionalAddress");
    Element elePersonInfo = docoutGetCustomer.createElement("PersonInfo");

    docoutGetCustomer.appendChild(elecustomer);
    elecustomer.appendChild(eleCustomerContactList);
    eleCustomerContactList.appendChild(eleCustomerContact);
    eleCustomerContact.appendChild(eleExtn);
    eleCustomerContact.appendChild(eleCustomerAddresList);
    eleCustomerAddresList.appendChild(eleCustomerAdditionalAddess);
    eleCustomerAdditionalAddess.appendChild(elePersonInfo);

    elecustomer.setAttribute("ExtnServiceOffline", "N");

    String sToParse = "[" + json.toString() + "]";
    Gson outGson = new Gson();
    fromJSON[] parsedClass = outGson.fromJson(sToParse, fromJSON[].class); // input
                                                                           // is
                                                                           // your
                                                                           // String
    if (strQueryParam.contains("lyl")) {
      String str = "loylatId";

      logger.debug("Loyalty--->" + strQueryParam);

      for (int j = 0; j < parsedClass.length; j++) {

        logger.debug("Loyalty setting attributes--->");
        if (parsedClass[j].customers.length != 0) {
          elecustomer.setAttribute("CustomerRewardsNo", parsedClass[j].customers[j].loyaltyId);
          if (parsedClass[j].customers[j].pilotStatus) {
        	  elecustomer.setAttribute("PilotMember", "Y");
          } else {
        	  elecustomer.setAttribute("PilotMember", "N");
          }
          if (!YFCCommon.isVoid(parsedClass[j].customers[j].existingEarnTrackerBal)) {
            elecustomer.setAttribute("ExistingEarnTrackerBal", parsedClass[j].customers[j].existingEarnTrackerBal);
          }
          if(!YFCCommon.isVoid(parsedClass[j].customers[j].kohlsCash ) 
					&& parsedClass[j].customers[j].kohlsCash.size() > 0 ) {
				Element kohlsCashList = docoutGetCustomer.createElement("KohlsCashList");
				for(int k =0; k < parsedClass[j].customers[j].kohlsCash.size() ;k++) {
					Element currentKohlsCash = docoutGetCustomer.createElement("KohlsCash");
					currentKohlsCash.setAttribute("Barcode", parsedClass[j].customers[j].kohlsCash.get(k).barcode);
					currentKohlsCash.setAttribute("RedemptionStartDate", parsedClass[j].customers[j].kohlsCash.get(k).redemptionStartDate);
					currentKohlsCash.setAttribute("RedemptionEndDate", parsedClass[j].customers[j].kohlsCash.get(k).redemptionEndDate);
					currentKohlsCash.setAttribute("RemainingValue", parsedClass[j].customers[j].kohlsCash.get(k).remainingValue);
          currentKohlsCash.setAttribute("EventTypeCode" , parsedClass[j].customers[j].kohlsCash.get(k).eventTypeCode);
					kohlsCashList.appendChild(currentKohlsCash);
				}
				elecustomer.appendChild(kohlsCashList);
			}
          
          if (!YFCCommon.isVoid(parsedClass[j].customers[j].associateDiscountID)) {
            elecustomer.setAttribute("CustomerAssociateNo",
                parsedClass[j].customers[j].associateDiscountID);
            elecustomer.setAttribute("AssociateId",
                parsedClass[j].customers[j].associateDiscountID);
          }
          else {
            elecustomer.setAttribute("CustomerAssociateNo", "");
            elecustomer.setAttribute("AssociateId", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].customerName) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].customerName.loyalty)) {
            eleCustomerContact.setAttribute("FirstName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.loyalty.first));
            eleCustomerContact.setAttribute("LastName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.loyalty.last));
            eleCustomerContact.setAttribute("MiddleName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.loyalty.middle));
            eleCustomerContact.setAttribute("jobTitle",
                parsedClass[j].customers[j].customerName.loyalty.professionalTitle);
          }
          else {
            eleCustomerContact.setAttribute("FirstName", "");
            eleCustomerContact.setAttribute("LastName", "");
            eleCustomerContact.setAttribute("MiddleName", "");
            eleCustomerContact.setAttribute("jobTitle", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress)
             && !YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.EReceipt)
              && (!parsedClass[j].customers[j].emailAddress.EReceipt.equals("")))
          {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.EReceipt);
          } else if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.ecom ))
              && (!parsedClass[j].customers[j].emailAddress.ecom.equals(""))) {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.ecom);

          } else if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.kohlsCharge ))
              && (!parsedClass[j].customers[j].emailAddress.kohlsCharge.equals(""))) {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.kohlsCharge);
          } else if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.loyalty ))
              && (!parsedClass[j].customers[j].emailAddress.loyalty.equals(""))) {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.loyalty);

          } else {
            eleCustomerContact.setAttribute("EmailID", "");

          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].customerName) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].customerName.loyalty)) {
            elePersonInfo.setAttribute("FirstName",
              KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.loyalty.first));
            elePersonInfo.setAttribute("LastName",
              KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.loyalty.last));
            elePersonInfo.setAttribute("MiddleName",
              KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.loyalty.middle));
            elePersonInfo.setAttribute("jobTitle",
              parsedClass[j].customers[j].customerName.loyalty.professionalTitle);
          }
          else {
            elePersonInfo.setAttribute("FirstName", "");
            elePersonInfo.setAttribute("LastName", "");
            elePersonInfo.setAttribute("MiddleName", "");
            elePersonInfo.setAttribute("jobTitle", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].phoneNumber)) {
            eleCustomerContact.setAttribute("DayPhone",
              parsedClass[j].customers[j].phoneNumber.loyalty);
          }
          else {
            eleCustomerContact.setAttribute("DayPhone", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].addressLine1) && 
            !YFCCommon.isVoid(parsedClass[j].customers[j].addressLine1.loyalty)) {
            elePersonInfo.setAttribute("AddressLine1",
              parsedClass[j].customers[j].addressLine1.loyalty);
          }
          else {
            elePersonInfo.setAttribute("AddressLine1", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].postalCode) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].postalCode.loyalty)) {
            elePersonInfo.setAttribute("ZipCode", parsedClass[j].customers[j].postalCode.loyalty);
          }
          else {
            elePersonInfo.setAttribute("ZipCode", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].associateDiscountID)
              && (!parsedClass[j].customers[j].associateDiscountID.equals(""))) {
            eleExtn.setAttribute("ExtnIsEmployee", "Y");
            eleExtn.setAttribute("ExtnCustomerAssociateNo",
                parsedClass[j].customers[j].associateDiscountID);

          } 
          else {
            eleExtn.setAttribute("ExtnIsEmployee", "N");
            eleExtn.setAttribute("ExtnCustomerAssociateNo",
                parsedClass[j].customers[j].associateDiscountID);

          }
          
          if (!YFCCommon.isVoid(parsedClass[j].customers[j].customerName)
              && !YFCCommon.isVoid(parsedClass[j].customers[j].customerName.kohlsCharge) 
        		  && !YFCCommon.isVoid(parsedClass[j].customers[j].customerName.kohlsCharge.first)) {
        	  eleExtn.setAttribute("ExtnKohlsCharge", "Y");
          } 
          else {
        	  eleExtn.setAttribute("ExtnKohlsCharge", "N");
          }
          
          eleExtn.setAttribute("ExtnNameSource", "R");


          if ((parsedClass[j].customers[j].vip)) {
            eleExtn.setAttribute("ExtnKohlsChargeVIP", "Y");
          } 
          else {
            eleExtn.setAttribute("ExtnKohlsChargeVIP", "N");

          }
          eleExtn.setAttribute("ExtnLoyaltyPointTotal", "");

          eleExtn.setAttribute("ExtnMVCStatusSrc", "R");

          eleExtn.setAttribute("ExtnRewardsStatusSrc", "R");

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].kohlsChargeMvcIndicator)
            && parsedClass[j].customers[j].kohlsChargeMvcIndicator) {
            eleExtn.setAttribute("ExtnMVCStatus", "Y");
            eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
            eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "R");
          } else {
            eleExtn.setAttribute("ExtnMVCStatus", "N");
            eleExtn.setAttribute("ExtnKohlsChargeStatus", "N");
            eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "N");
          }
          if (!YFCCommon.isVoid(parsedClass[j].customers[j].customerName.kohlsCharge )
              || !YFCCommon.isVoid(parsedClass[j].customers[j].addressLine1.kohlsCharge )
              || !YFCCommon.isVoid(parsedClass[j].customers[j].postalCode.kohlsCharge )
              || !YFCCommon.isVoid(parsedClass[j].customers[j].phoneNumber.kohlsCharge )) {
            eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
            eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "R");
          }

          eleExtn.setAttribute("ExtnRewardsStatus", "0");

        }
        if (parsedClass[j].customers.length == 0) {

          // System.out.println("in the else section");
          YFSException yfsException = new YFSException();
          yfsException.setErrorCode("NO_RECORD_FOUND");
          yfsException.setErrorDescription(KohlsPOCConstant.NO_RECORD_FOUND_DESC);
          throw yfsException;

        }

      }
    }
    if (strQueryParam.contains("kcc"))

    {
      for (int j = 0; j < parsedClass.length; j++) {
        if (parsedClass[j].customers.length != 0) {
          elecustomer.setAttribute("CustomerChargeCardNo", strValue);
          if (!YFCCommon.isVoid(parsedClass[j].customers[j].loyaltyId )) {
            elecustomer.setAttribute("CustomerRewardsNo", parsedClass[j].customers[j].loyaltyId);
            eleExtn.setAttribute("ExtnRewardsStatusSrc", "K");
            eleExtn.setAttribute("ExtnRewardsStatus", "Y");
          } 
          else {
            elecustomer.setAttribute("CustomerRewardsNo", "");
            eleExtn.setAttribute("ExtnRewardsStatusSrc", "N");
            eleExtn.setAttribute("ExtnRewardsStatus", "N");
          }

          if (parsedClass[j].customers[j].pilotStatus) {
        	  elecustomer.setAttribute("PilotMember", "Y");
          } 
          else {
        	  elecustomer.setAttribute("PilotMember", "N");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].associateDiscountID )) {
            elecustomer.setAttribute("CustomerAssociateNo",
                parsedClass[j].customers[j].associateDiscountID);
            elecustomer.setAttribute("AssociateId",
                parsedClass[j].customers[j].associateDiscountID);
          }
          else {
            elecustomer.setAttribute("CustomerAssociateNo", "");
            elecustomer.setAttribute("AssociateId", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].customerName ) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].customerName.kohlsCharge )) {
            eleCustomerContact.setAttribute("FirstName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.kohlsCharge.first));
            eleCustomerContact.setAttribute("LastName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.kohlsCharge.last));
            eleCustomerContact.setAttribute("MiddleName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.kohlsCharge.middle));
            eleCustomerContact.setAttribute("jobTitle",
                parsedClass[j].customers[j].customerName.kohlsCharge.professionalTitle);
          }
          else {
            eleCustomerContact.setAttribute("FirstName", "");
            eleCustomerContact.setAttribute("LastName", "");
            eleCustomerContact.setAttribute("MiddleName", "");            
            eleCustomerContact.setAttribute("jobTitle", "");
          }

          if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.EReceipt ))
              && (!parsedClass[j].customers[j].emailAddress.EReceipt.equals("")))

          {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.EReceipt);
          } else if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.ecom ))
              && (!parsedClass[j].customers[j].emailAddress.ecom.equals(""))) {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.ecom);

          } else if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.kohlsCharge ))
              && (!parsedClass[j].customers[j].emailAddress.kohlsCharge.equals(""))) {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.kohlsCharge);
          } else if ((!YFCCommon.isVoid(parsedClass[j].customers[j].emailAddress.loyalty ))
              && (!parsedClass[j].customers[j].emailAddress.loyalty.equals(""))) {
            eleCustomerContact.setAttribute("EmailID",
                parsedClass[j].customers[j].emailAddress.loyalty);

          } else {
            eleCustomerContact.setAttribute("EmailID", "");

          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].phoneNumber ) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].phoneNumber.kohlsCharge )) {
            eleCustomerContact.setAttribute("DayPhone",
              parsedClass[j].customers[j].phoneNumber.kohlsCharge);
          }
          else {
            eleCustomerContact.setAttribute("DayPhone", "");
          }
          
          if (!YFCCommon.isVoid(parsedClass[j].customers[j].customerName ) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].customerName.kohlsCharge )) {
            elePersonInfo.setAttribute("FirstName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.kohlsCharge.first));
            elePersonInfo.setAttribute("LastName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.kohlsCharge.last));
            elePersonInfo.setAttribute("MiddleName",
                KOHLSStringUtil.normalizeStringForPOSPrinter(parsedClass[j].customers[j].customerName.kohlsCharge.middle));
            elePersonInfo.setAttribute("jobTitle",
                parsedClass[j].customers[j].customerName.kohlsCharge.professionalTitle);
          }
          else {
            elePersonInfo.setAttribute("FirstName", "");
            elePersonInfo.setAttribute("LastName", "");
            elePersonInfo.setAttribute("MiddleName", "");
            elePersonInfo.setAttribute("jobTitle", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].addressLine1 ) &&
            !YFCCommon.isVoid(parsedClass[j].customers[j].addressLine1.kohlsCharge )) {
            elePersonInfo.setAttribute("AddressLine1",
              parsedClass[j].customers[j].addressLine1.kohlsCharge);
          }
          else {
            elePersonInfo.setAttribute("AddressLine1", "");
          }

          if (!YFCCommon.isVoid(parsedClass[j].customers[j].postalCode )) {
            elePersonInfo.setAttribute("ZipCode", parsedClass[j].customers[j].postalCode.kohlsCharge);
          }
          else {
            elePersonInfo.setAttribute("ZipCode", ""); 
          }

          if ((!YFCCommon.isVoid(parsedClass[j].customers[j].associateDiscountID ))
              && (!parsedClass[j].customers[j].associateDiscountID.equals(""))) {
            eleExtn.setAttribute("ExtnIsEmployee", "Y");
            eleExtn.setAttribute("ExtnCustomerAssociateNo",
                parsedClass[j].customers[j].associateDiscountID);

          } else {
            eleExtn.setAttribute("ExtnIsEmployee", "N");
            eleExtn.setAttribute("ExtnCustomerAssociateNo",
                parsedClass[j].customers[j].associateDiscountID);

          }
          eleExtn.setAttribute("ExtnKohlsCharge", "Y");
          eleExtn.setAttribute("ExtnKohlsChargeStatus", "Y");
          if ((parsedClass[j].customers[j].vip)) {
            eleExtn.setAttribute("ExtnKohlsChargeVIP", "Y");

          } else {
            eleExtn.setAttribute("ExtnKohlsChargeVIP", "N");

          }
          eleExtn.setAttribute("ExtnLoyaltyPointTotal", "");
          eleExtn.setAttribute("ExtnKohlsChargeStatusSrc", "K");
          eleExtn.setAttribute("ExtnMVCStatusSrc", "K");
          eleExtn.setAttribute("ExtnNameSource", "K");
          if (parsedClass[j].customers[j].kohlsChargeMvcIndicator) {
            eleExtn.setAttribute("ExtnMVCStatus", "Y");

          } else {
            eleExtn.setAttribute("ExtnMVCStatus", "N");
          }
          
          if(!YFCCommon.isVoid(parsedClass[j].customers[j].kohlsCash ) 
					&& parsedClass[j].customers[j].kohlsCash.size() > 0 ) {
				Element kohlsCashList = docoutGetCustomer.createElement("KohlsCashList");
				for(int k =0; k < parsedClass[j].customers[j].kohlsCash.size() ;k++) {
					Element currentKohlsCash = docoutGetCustomer.createElement("KohlsCash");
					currentKohlsCash.setAttribute("Barcode", parsedClass[j].customers[j].kohlsCash.get(k).barcode);
					currentKohlsCash.setAttribute("RedemptionStartDate", parsedClass[j].customers[j].kohlsCash.get(k).redemptionStartDate);
					currentKohlsCash.setAttribute("RedemptionEndDate", parsedClass[j].customers[j].kohlsCash.get(k).redemptionEndDate);
					currentKohlsCash.setAttribute("RemainingValue", parsedClass[j].customers[j].kohlsCash.get(k).remainingValue);
					kohlsCashList.appendChild(currentKohlsCash);
				}
				elecustomer.appendChild(kohlsCashList);
			}
    } else {
          // String statusCode="504";
          YFSException yfsException = new YFSException();
          yfsException.setErrorCode("NO_RECORD_FOUND");
          yfsException.setErrorDescription(KohlsPOCConstant.NO_RECORD_FOUND_DESC);
          throw yfsException;

        }

      }

    }
    logger.endTimer("KohlsCustomerLookupRest.setCustomerDetails");
    return docoutGetCustomer;
  }


  private Document createCustomerUEOutput() throws Exception {
    logger.beginTimer("KohlsCustomerLookupRest.createCustomerUEOutput");
    Document docoutGetCustomer = XMLUtil.newDocument();

    Element elecustomer = docoutGetCustomer.createElement("Customer");

    Element eleCustomerContactList = docoutGetCustomer.createElement("CustomerContactList");
    Element eleCustomerContact = docoutGetCustomer.createElement("CustomerContact");
    Element eleExtn = docoutGetCustomer.createElement("Extn");
    Element eleCustomerAddresList =
        docoutGetCustomer.createElement("CustomerAdditionalAddressList");
    Element eleCustomerAdditionalAddess =
        docoutGetCustomer.createElement("CustomerAdditionalAddress");
    Element elePersonInfo = docoutGetCustomer.createElement("PersonInfo");

    docoutGetCustomer.appendChild(elecustomer);
    elecustomer.appendChild(eleCustomerContactList);
    eleCustomerContactList.appendChild(eleCustomerContact);
    eleCustomerContact.appendChild(eleExtn);
    eleCustomerContact.appendChild(eleCustomerAddresList);
    eleCustomerAddresList.appendChild(eleCustomerAdditionalAddess);
    eleCustomerAdditionalAddess.appendChild(elePersonInfo);
    logger.endTimer("KohlsCustomerLookupRest.createCustomerUEOutput");
    return docoutGetCustomer;
  }

  public void setProperties(Properties prop) throws Exception {
    this.props = prop;
    // LOG_CAT.debug("In the set properties method");

  }

  public String getPropertyValue(String property) {
    logger.beginTimer("KohlsPOCSysRepublic.getPropertyValue");
    String propValue;
    propValue = YFSSystem.getProperty(property);
    // Manoj 10/22: updated to use configured property if
    // customer_overrides.properties does not return any value
    if (YFCCommon.isVoid(propValue)) {
      propValue = property;
    }
    logger.endTimer("KohlsPOCSysRepublic.getPropertyValue");
    return propValue;

  }
}
