package com.kohls.poc.sbc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsLoadDashboardServerDetailsForPOS implements YIFCustomApi {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsLoadDashboardServerDetailsForPOS.class.getName());
	private static ArrayList<String> storeList = new ArrayList<String>();
	ArrayList<Element> serverStatusList =  new ArrayList<Element>();
	private static HashMap <String,String> profileImportTypeMap = new HashMap <String,String>();
	private static HashSet<Element> nonMatchingStoresSet = new HashSet<>();
	private static String deploymentVersion = YFSSystem.getProperty("yfs.rollout.version");
	
	
	public Document loadDashboardServerDetails(YFSEnvironment env, Document inDoc) throws Exception {
		
		log.info("Force_Offline - Input doc to KohlsLoadDashboardServerDetailsForPOS " + SCXmlUtil.getString(inDoc));
		inDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_DEPLOYMENT_VERSION, deploymentVersion);
		inDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_SERVER_TYPE, KohlsPOCConstant.EDGE);
		log.info("Force_Offline - Input doc to KohlsLoadDashboardServerDetailsForPOS After adding deployVersion and ServerType" + SCXmlUtil.getString(inDoc));

		String strStores = "", strDataSyncStatus="", strReasonCode="";
		Document outDoc = null;
		Element eleInDoc = inDoc.getDocumentElement();
		strStores = eleInDoc.getAttribute(KohlsPOCConstant.STORE_ID);
		strDataSyncStatus = eleInDoc.getAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS);
		strReasonCode = eleInDoc.getAttribute(KohlsPOCConstant.A_FORCE_OFF_REASON_CODE);
		log.info("Force_Offline - stores provided for offline status change are " + strStores);
		
		setProfileImportTypeMap(env);
		
		if(eleInDoc.hasAttribute(KohlsPOCConstant.SERVER_IP) && !YFCCommon.isStringVoid(eleInDoc.getAttribute(KohlsPOCConstant.SERVER_IP))) {
			//Input format: <ServerStatus ServerIp="isx9916h.st.ad.kohls.com">
			log.info("Force_Offline - Handle for details page and refresh button");
			outDoc = loadDashBoardServerDetailsForPOS(env, inDoc);
			Element eleServerStatus = SCXmlUtil.getChildElement(outDoc.getDocumentElement(), KohlsPOCConstant.SERVER_STATUS);
			ArrayList<String> outOfSyncImportTypeList = getOutOfSyncImportTypeList(env, eleServerStatus);
			if(outOfSyncImportTypeList.contains(KohlsPOCConstant.A_INSTANT) && !outOfSyncImportTypeList.contains(KohlsPOCConstant.A_STAGED)){
				eleServerStatus.setAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS, KohlsPOCConstant.STATUS_STAGED_SYNCED);
			}else if(outOfSyncImportTypeList.contains(KohlsPOCConstant.A_STAGED) && !outOfSyncImportTypeList.contains(KohlsPOCConstant.A_INSTANT)) {
				eleServerStatus.setAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS, KohlsPOCConstant.STATUS_INSTANT_SYNCED);
			}
		}
		
		else {
					
			//Input format <ServerStatus StoreId="9916"/DataSyncStatus="3000.1300"/ForceOfflineReasonCode="DB Down"/> 
			log.info("Force_Offline - Handle for search and list screen");
			if (strStores != null && !strStores.equalsIgnoreCase("")) {
				Element eleComplex = prepareComplexQuery(eleInDoc, strStores);
				inDoc.getDocumentElement().appendChild(eleComplex);
				inDoc.getDocumentElement().removeAttribute(KohlsPOCConstant.STORE_ID);
				inDoc.getDocumentElement().removeAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
			}

			log.info("Force_Offline - Delta Sync status input to service " + strDataSyncStatus);
			if(strDataSyncStatus.equalsIgnoreCase(KohlsPOCConstant.STATUS_INSTANT_SYNCED) 
					|| strDataSyncStatus.equalsIgnoreCase(KohlsPOCConstant.STATUS_STAGED_SYNCED)) {
				eleInDoc.setAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS, KohlsPOCConstant.STATUS_PARTIAL_SYNCED);
				
			}

			log.debug("Force_Offline - Input doc to loadServerDashboardForPOS API \n" + SCXmlUtil.getString(inDoc));
			outDoc = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_LOAD_SERVER_DASHBOARD_FOR_POS, inDoc);
			log.debug("Force_Offline - Output doc from loadServerDashboardForPOS API \n"+ SCXmlUtil.getString(outDoc));

			serverStatusList = SCXmlUtil.getChildren(outDoc.getDocumentElement(), KohlsPOCConstant.SERVER_STATUS);
			
			for (Element eleStoreStatus : serverStatusList) {
				Document inDocForServerDetails = SCXmlUtil.createFromString(SCXmlUtil.getString(eleStoreStatus));
				Document outDocForServerDetails = loadDashBoardServerDetailsForPOS(env, inDocForServerDetails);
				Element eleServerStatus = SCXmlUtil.getChildElement(outDocForServerDetails.getDocumentElement(),KohlsPOCConstant.SERVER_STATUS);
				
				//Setting datasync status
				ArrayList<String> outOfSyncImportTypeList = getOutOfSyncImportTypeList(env, eleServerStatus);
				if(outOfSyncImportTypeList.contains(KohlsPOCConstant.A_INSTANT) && !outOfSyncImportTypeList.contains(KohlsPOCConstant.A_STAGED)){
					eleStoreStatus.setAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS, KohlsPOCConstant.STATUS_STAGED_SYNCED);
				}else if(outOfSyncImportTypeList.contains(KohlsPOCConstant.A_STAGED) && !outOfSyncImportTypeList.contains(KohlsPOCConstant.A_INSTANT)) {
					eleStoreStatus.setAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS, KohlsPOCConstant.STATUS_INSTANT_SYNCED);
				}
				
				//Setting offline reasons
				setForceOfflineReasonForStore(env, eleStoreStatus, strReasonCode);
				
				//Forming Non-Matching deploy version store array - Removing this as we are handling Deployment Version in input itself
				/*if(KohlsPOCConstant.YES.equals(eleStoreStatus.getAttribute(KohlsPOCConstant.A_VERSION_MISMATCH))){
					nonMatchingStoresSet.add(eleStoreStatus);
				}*/
				
				//Forming Non-Matching Sync status
				if(!YFCCommon.isStringVoid(strDataSyncStatus) 
						&& !strDataSyncStatus.equalsIgnoreCase(eleStoreStatus.getAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS))) {			
					nonMatchingStoresSet.add(eleStoreStatus);
				}
			}

			//Trim output for Deploy Version, Sync status and reason mismatch
			removeUnmatchingNodes(outDoc);

		}
			log.debug("Force_Offline - Return output doc to KohlsLoadDashboardServerDetailsForPOS \n"+ SCXmlUtil.getString(outDoc));
			
		return outDoc;
	}


	private void removeUnmatchingNodes(Document outDoc) {
		if(!nonMatchingStoresSet.isEmpty()) {
			log.debug("Force_Offline - Output doc to service before removing non-matching element \n"+ SCXmlUtil.getString(outDoc));
			for(Element eleRemove : nonMatchingStoresSet) {
				log.debug("Force_Offline - Removing element " + SCXmlUtil.getString(eleRemove));
				outDoc.getDocumentElement().removeChild(eleRemove);
			}
			log.debug("Force_Offline - Output doc to service after removing non-matching element \n"+ SCXmlUtil.getString(outDoc));
			nonMatchingStoresSet.clear();
		}
	}
	
	
	private void setForceOfflineReasonForStore(YFSEnvironment env, Element eleStoreStatus, String strReasonCode) throws Exception {
		Document getServerStatusInput= SCXmlUtil.createDocument(KohlsPOCConstant.SERVER_STATUS);
		getServerStatusInput.getDocumentElement().setAttribute(KohlsPOCConstant.SERVER_IP, eleStoreStatus.getAttribute(KohlsPOCConstant.SERVER_IP));
		env.setApiTemplate(KohlsPOCConstant.API_GET_SERVER_STATUS_POS, SCXmlUtil.createFromString(KohlsPOCConstant.GET_SERVER_STATUS_TEMPLATE));
		Document getServerStatusOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SERVER_STATUS_POS, getServerStatusInput);
		Element eleExtn =(Element) getServerStatusOutput.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);		
		eleStoreStatus.setAttribute(KohlsPOCConstant.A_FORCE_OFF_REASON_CODE,eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE));
		
			if(!YFCCommon.isStringVoid(strReasonCode) 
					&& !((eleExtn.getAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE)).equalsIgnoreCase(strReasonCode))) 
			{
				nonMatchingStoresSet.add(eleStoreStatus);
			}
	}


/*
 * This method will return importTypes list that are out of sync
 */
	private ArrayList<String> getOutOfSyncImportTypeList(YFSEnvironment env, Element eleServerStatus) throws Exception {
		ArrayList<String> outOfSyncImportTypeList = new ArrayList<String>();
		
			Element eleProfles = SCXmlUtil.getChildElement(eleServerStatus, KohlsPOCConstant.E_PROFILES);
			ArrayList<Element> profileList = SCXmlUtil.getChildren(eleProfles, KohlsPOCConstant.E_PROFILE);

			String strImportType = "", strProfileName = "";
			for (Element eleProfile : profileList) {
				strProfileName = eleProfile.getAttribute(KohlsPOCConstant.A_PROFILE_NAME);
				log.info("Force_Offline - eleProfile " + SCXmlUtil.getString(eleProfile));
				strImportType = profileImportTypeMap.get(strProfileName);

				if (!(eleProfile.getAttribute(KohlsPOCConstant.A_DATA_SYNC_STATUS)).startsWith(KohlsPOCConstant.STATUS_SYNCHRONIZED)
						&& !outOfSyncImportTypeList.contains(strImportType) && !YFCCommon.isStringVoid(strImportType)) { //If either of STAGED or INSTANT out of sync, avoid check for others
					outOfSyncImportTypeList.add(strImportType);
					log.info("Force_Offline - ImportType " + strImportType + " is " + KohlsPOCConstant.A_OUT_OF_SYNC);
				}
		}
			log.info("Force_Offline - outOfSyncImportTypeList " + outOfSyncImportTypeList);
		return outOfSyncImportTypeList;
	}

	private Document loadDashBoardServerDetailsForPOS(YFSEnvironment env, Document inDocForServerDetails)
			throws Exception {
		// Remove below attributes before calling loadDashboardServerDetailsForPOS as it results in empty output <ServerStatusList/>
		inDocForServerDetails.getDocumentElement().removeAttribute(KohlsPOCConstant.SERVER_STATUS);
		inDocForServerDetails.getDocumentElement().removeAttribute(KohlsPOCConstant.A_ORDER_SYNC_STATUS);
		log.debug("Force_Offline - Input to loadDashboardServerDetailsForPOS API \n" + SCXmlUtil.getString(inDocForServerDetails));
		Document outDocForServerDetails = KOHLSBaseApi.invokeAPI(env, KohlsPOCConstant.API_LOAD_DASHBOARD_SERVER_DETAILS_FOR_POS, inDocForServerDetails);
		log.debug("Force_Offline - Output of loadDashboardServerDetailsForPOS API \n" + SCXmlUtil.getString(outDocForServerDetails));
		return outDocForServerDetails;
	}
	
	//Profile,ImportType map
	private void setProfileImportTypeMap(YFSEnvironment env) throws Exception {
		// Input to GetDataPumpSyncProcessList: <DataPumpSyncProcess SyncProcess="Export" SyncTargetID="CORP" SyncSchemaType="MASTER"/>
		log.info("Force_Offline - Checking the time stamp in Master");
		Document datapumpProcessListOutdoc = SCXmlUtil.createDocument(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
		Element lastFullElm = datapumpProcessListOutdoc.getDocumentElement();
		lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_PROCESS, KohlsPOCConstant.A_EXPORT);
		lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_TARGET_ID, KohlsPOCConstant.CORP);
		lastFullElm.setAttribute(KohlsPOCConstant.A_SYNC_SCHEMA_TYPE, KohlsPOCConstant.TABLE_TYPE_MASTER);
		log.info("Force_Offline - Input to full last sync date call \n" + XMLUtil.getXMLString(datapumpProcessListOutdoc));
		Document lastFullDeltaSynOutDoc = KohlsCommonUtil.invokeService(env,
				KohlsPOCConstant.API_GET_DATA_PUMP_SYNC_PROCESS_LIST, datapumpProcessListOutdoc);
		log.info("Force_Offline - Output to last sync date call is \n" + XMLUtil.getXMLString(lastFullDeltaSynOutDoc));
		Element elmDatapumpProcessListOutdoc = lastFullDeltaSynOutDoc.getDocumentElement();
		NodeList nodeListDatapumpProcessListOutdoc = elmDatapumpProcessListOutdoc
				.getElementsByTagName(KohlsPOCConstant.DATA_PUMP_SYNC_PROCESS);
		
		profileImportTypeMap.clear();
		for (int il = 0; il < nodeListDatapumpProcessListOutdoc.getLength(); il++) {
			Element eleFullDelta = ((Element) nodeListDatapumpProcessListOutdoc.item(il));
			if (eleFullDelta.getAttribute(KohlsPOCConstant.A_SYNC_TYPE).equals(KohlsPOCConstant.SYNC_DELTA)) {
				profileImportTypeMap.put(eleFullDelta.getAttribute(KohlsPOCConstant.E_SYNC_PROFILE),
						eleFullDelta.getAttribute(KohlsPOCConstant.A_IMPORT_TYPE));
			}
			log.info("Force_Offline - ProfileImportTypeMap is " + profileImportTypeMap);
		}
	}
		
	private Element prepareComplexQuery(Element eleInDoc, String strStores) {
		Element eleComplexQry = SCXmlUtil.createChild(eleInDoc, KohlsPOCConstant.E_COMPLEX_QUERY);
		Element eleOr = SCXmlUtil.createChild(eleComplexQry, KohlsPOCConstant.E_OR);

		String storeIds[];
		storeIds = strStores.split(KohlsPOCConstant.COMMA);
		for (String strStore : storeIds) {
			storeList.add(strStore);
			Element eleExp = SCXmlUtil.createChild(eleOr, KohlsPOCConstant.E_EXP);
			eleExp.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.STORE_ID);
			eleExp.setAttribute(KohlsPOCConstant.A_VALUE, strStore);
		}

		return eleComplexQry;
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
		
	}

}
