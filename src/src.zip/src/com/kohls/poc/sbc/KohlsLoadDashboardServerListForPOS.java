package com.kohls.poc.sbc;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsLoadDashboardServerListForPOS implements YIFCustomApi {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsLoadDashboardServerListForPOS.class.getName());
	private static ArrayList<String> storeList = new ArrayList<String>();
	ArrayList<Element> serverStatusList =  new ArrayList<Element>();
	private static final String A_DATA_SYNC_STATUS =  "DataSyncStatus";
	private static final String SERVER_STATUS="ServerStatus";
	public static final String GET_SERVER_STATUS_TEMPLATE = "<ServerStatus ><Extn /></ServerStatus>";
	public static final String API_LOAD_SERVER_DASHBOARD_FOR_POS = "loadServerDashboardForPOS";
	public static final String API_GET_SERVER_STATUS_FOR_POS = "getServerStatusForPOS";
	public static final String API_LOAD_DASHBOARD_SERVER_DETAILS_FOR_POS = "loadDashboardServerDetailsForPOS";
	int errorCount = 0;
	ArrayList<String> erroredStores = new ArrayList<String>();
	ArrayList<String> successStores = new ArrayList<String>();


	public Document loadDashboardServerDetails(YFSEnvironment env, Document inDoc) {
		log.info("Input doc to KohlsLoadDashboardServerListForPOS " + SCXmlUtil.getString(inDoc));

		String strStores = "";
		Element eleInDoc = inDoc.getDocumentElement();
		strStores = eleInDoc.getAttribute(KohlsPOCConstant.STORE_ID);
		eleInDoc.getAttribute(A_DATA_SYNC_STATUS);
		log.info("stores provided for offline status change are: " + strStores);
		Document outDoc=null;

			try {
				
				String storeList = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.STORE_ID);
				String reasonCode = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_FORCE_OFF_REASON_CODE);
				String forceSwitchingFlag = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG);
				List<String> stores = Arrays.asList(storeList.split(","));
				
				log.info("KohlsLoadDashboardServerListForPOS: Store List " +storeList);
				log.info("KohlsLoadDashboardServerListForPOS: reasonCode " +reasonCode);
				log.info("KohlsLoadDashboardServerListForPOS: forceSwitchingFlag " +forceSwitchingFlag);

				if (((!storeList.isEmpty() && !reasonCode.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.YES))
						|| (!storeList.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.NO))
						|| (!storeList.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.NO)) && reasonCode.isEmpty())
						&& (!stores.isEmpty())) {

					for (String strStore : stores) {
						log.info("Force_Offline - Store Id " + strStore);
						try {
							strStore = removePrependedZeroes(strStore);
							ArrayList<Element> serverStatusList = new ArrayList<>();

							Document docVerifyServer = SCXmlUtil.createDocument(KohlsPOCConstant.SERVER_STATUS);
							docVerifyServer.getDocumentElement().setAttribute(KohlsPOCConstant.STORE_ID, strStore);
							Document getServerListForPOSOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SERVER_STATUS_LIST_POS, docVerifyServer);
							serverStatusList = SCXmlUtil.getChildren(getServerListForPOSOutput.getDocumentElement(), KohlsPOCConstant.SERVER_STATUS);
							errorMap(strStore, getServerListForPOSOutput);

							if (serverStatusList.size() != 1) {
								log.error("Force_Offline - Entry not found for store " + strStore + " in POS_SERVER_STATUS");
								errorCount++;
								erroredStores.add(strStore);
							} 
							else {
								if (log.isDebugEnabled()) {
									log.debug("Force_Offline - Entry found for store " + strStore + " in POS_SERVER_STATUS");
								}
								successStores.add(strStore);
								Document performManualSwitchAPIForPOSInput = SCXmlUtil.createDocument(KohlsPOCConstant.TRIGGER_MANUAL_SWITCH);
								performManualSwitchAPIForPOSInput.getDocumentElement().setAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG, forceSwitchingFlag);
								Element elePerformManualSwitchAPIForPOS = performManualSwitchAPIForPOSInput.createElement(KohlsPOCConstant.ELE_POS_OFFLINE_STATUS);
								elePerformManualSwitchAPIForPOS.setAttribute(KohlsPOCConstant.SERVER_IP, serverStatusList.get(0).getAttribute(KohlsPOCConstant.SERVER_IP));
								elePerformManualSwitchAPIForPOS.setAttribute(KohlsPOCConstant.STORE_ID, serverStatusList.get(0).getAttribute(KohlsPOCConstant.STORE_ID));
								elePerformManualSwitchAPIForPOS.setAttribute(KohlsPOCConstant.SERVER_STATUS_KEY, serverStatusList.get(0).getAttribute(KohlsPOCConstant.SERVER_STATUS_KEY));
								performManualSwitchAPIForPOSInput.getDocumentElement().appendChild(elePerformManualSwitchAPIForPOS);

								if (log.isDebugEnabled()) {
									log.debug("Force_Offline - performManualSwitchAPIForPOS API call Input \n"
											+ SCXmlUtil.getString(performManualSwitchAPIForPOSInput));
								}  

								Document performManualSwitchAPIForPOSOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_PERFORM_MANUAL_SWITCH, performManualSwitchAPIForPOSInput);
								if (log.isDebugEnabled()) {
									log.debug("Force_Offline - performManualSwitchAPIForPOS API call Output \n" 
											+ SCXmlUtil.getString(performManualSwitchAPIForPOSOutput));
								}
								errorMap(strStore, performManualSwitchAPIForPOSOutput);	

								//Calling manageServerStatus API
								Document manageServerStatusForPOSInput = SCXmlUtil.createFromString(SCXmlUtil.getString(serverStatusList.get(0)));
								manageServerStatusForPOSInput.getDocumentElement().setAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG, forceSwitchingFlag);
								Element extnElement = manageServerStatusForPOSInput.createElement(KohlsPOCConstant.E_EXTN);
								if (forceSwitchingFlag.equals(KohlsPOCConstant.YES)) {
									extnElement.setAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE, reasonCode);
								} else {
									extnElement.setAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE, " ");
								}
								manageServerStatusForPOSInput.getDocumentElement().appendChild(extnElement);
								if (log.isDebugEnabled()) {
									log.debug("Force_Offline - manageServerStatusForPOS API call Input \n" 
											+ SCXmlUtil.getString(manageServerStatusForPOSInput));
								}

								Document docUpdateStoreForceOfflineStatus = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MANAGE_SERVER_STATUS_POS, manageServerStatusForPOSInput);
								if (log.isDebugEnabled()) {
									log.debug("Force_Offline - manageServerStatusForPOS API call Output \n" + SCXmlUtil.getString(docUpdateStoreForceOfflineStatus));
								}		
								errorMap(strStore, docUpdateStoreForceOfflineStatus);
							}
						}
						catch(Exception e) {
							log.error("Force_Offline - Store "+ strStore + " errored out due to " + e.getMessage());
							errorCount++;
							erroredStores.add(strStore);					
						}
					}
					
					try {
						StringBuffer sf= new StringBuffer();
						for (String strStore : successStores) {
							sf.append(strStore);
							sf.append(",");
						}
						
						String storevalues=sf.toString();
						
						if(storevalues.isEmpty()) {
							log.error("No Valid stores found in the given StoresList");
							outDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
							Element pageEle=outDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
							pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
							pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
							pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
							pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
							pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
							pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
							pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
							
							outDoc.getDocumentElement().appendChild(pageEle);
							log.error("Dummy OutputDoc formed in no sucess stores scenario: "+ SCXmlUtil.getString(outDoc));

						}
						else {
							
						Element eleComplex = prepareComplexQuery(eleInDoc, storevalues);
						inDoc.getDocumentElement().appendChild(eleComplex);
						inDoc.getDocumentElement().removeAttribute(KohlsPOCConstant.STORE_ID);
						inDoc.getDocumentElement().removeAttribute(KohlsPOCConstant.A_ORGANIZATION_CODE);
						
							if (log.isDebugEnabled()) {
								log.debug("Input doc to KohlsLoadDashboardServerDetailsForPOS before API call" + SCXmlUtil.getString(inDoc));
							}
						outDoc = KOHLSBaseApi.invokeAPI(env, API_LOAD_SERVER_DASHBOARD_FOR_POS, inDoc);
							if (log.isDebugEnabled()) {
								log.debug("Output doc to KohlsLoadDashboardServerListForPOS before modification "+ SCXmlUtil.getString(outDoc));
							}
						serverStatusList = SCXmlUtil.getChildren(outDoc.getDocumentElement(), SERVER_STATUS);
							for (Element eleStoreStatus : serverStatusList) {
									setForceOfflineReasonForStore(env, eleStoreStatus);
							}
							
							if (log.isDebugEnabled()) {
								log.debug("Output doc to KohlsLoadDashboardServerListForPOS Before appending Error Stores "+ SCXmlUtil.getString(outDoc));
							}
						}
						
						if (errorCount > 0) {
							StringBuffer sfe= new StringBuffer();
							for (String strEStore : erroredStores) {
								sfe.append(strEStore);
								sfe.append(",");
							}
							
							String ErrorStoresList= sfe.toString();
							String ErrorStores=ErrorStoresList.substring(0, ErrorStoresList.length()-1);

							String splunkLink = "\n Splunk search index: \nPROD--- index=kohls_prod_logistics_omsr \"Force_Offline -\" "
									+ ", \nLLE--- index=kohls_lle_logistics_omsr \"Force_Offline -\"";
							
							log.error("splunkLink Store details::" + splunkLink);
							String ErrorStoresWithSplunk="Errored Stores "+"["+ErrorStores+"]";
							log.error("final Errored Store details::" + ErrorStoresWithSplunk);
							outDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ERRORED_STORES, ErrorStoresWithSplunk);
							outDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_SPLUNK_LINK, splunkLink);
								
						}else {
							outDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ERRORED_STORES,"Errored Stores : NA");
							outDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_SPLUNK_LINK," ");

							if (log.isDebugEnabled()) {
								log.debug("Final Output doc to KohlsLoadDashboardServerListForPOS After appending Error Stores "+ SCXmlUtil.getString(outDoc));
							}
					}
						return outDoc;
						
					} catch (Exception e) {
						log.error("Exception in loadDashboardServerDetails method ");
					}
					
					
				} else {
					if (storeList.isEmpty() && forceSwitchingFlag.isEmpty() && reasonCode.isEmpty()) {
						log.error("Force_Offline - Missing stores, reason code and ForceOffline flag in SBC UI Input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_ERRORED_STORES, "StoreList,ReasonCode and ForceOffline Flag is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));

						return ExceptionDoc;
						
					} else if ((!storeList.isEmpty()) && forceSwitchingFlag.isEmpty() && reasonCode.isEmpty()) {
						log.error("Force_Offline - Missing ForceOffline Flag and ReasonCode in SBC UI input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "ForceOffline and Reason Code is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						
						return ExceptionDoc;
						
					}else if ((!storeList.isEmpty()) && forceSwitchingFlag.isEmpty() && (!reasonCode.isEmpty())) {
						log.error("Force_Offline - Missing ForceOffline Flag in SBC UI input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "ForceOffline Flag is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						
						return ExceptionDoc;
						
					}else if ((storeList.isEmpty()) && forceSwitchingFlag.equals(KohlsPOCConstant.YES) && (!reasonCode.isEmpty())) {
						log.error("Force_Offline - Missing stores in SBC UI input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "StoreList is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						
						return ExceptionDoc;
						
					} else if ((!storeList.isEmpty()) && forceSwitchingFlag.equals(KohlsPOCConstant.YES) && reasonCode.isEmpty()) {
						log.error("Force_Offline - Missing Reason Code in SBC UI input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "Reason Code is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						return ExceptionDoc;
						
					}else if (storeList.isEmpty() && (!reasonCode.isEmpty()) && forceSwitchingFlag.isEmpty()) {
						log.error("Force_Offline - Missing Stores and ForceOffline Flag in SBC UI Input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "StoreList and ForceOffline Flag is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						return ExceptionDoc;
						
					}else if (storeList.isEmpty() && reasonCode.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.YES)) {
						log.error("Force_Offline - Missing Stores and Reason Code in SBC UI Input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "StoreList and ReasonCode is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						return ExceptionDoc;
						
					}else if (storeList.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.NO)) {
						log.error("Force_Offline - Missing Stores in SBC UI Input");
						
						Document ExceptionDoc = SCXmlUtil.createDocument(KohlsPOCConstant.E_SERVER_STATUS_LIST);
						ExceptionDoc.getDocumentElement().setAttribute("ErrorStores", "StoreList is missing");
						Element pageEle=ExceptionDoc.createElement(KohlsPOCConstant.E_PAGE_DATA);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_FIRST_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_LAST_PAGE,KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_IS_VALID_PAGE, KohlsPOCConstant.YES);
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_NUMBER, "1");
						pageEle.setAttribute(KohlsPOCConstant.A_PAGE_SIZE, "15");
						pageEle.setAttribute(KohlsPOCConstant.A_START_ROW_NUMBER, "0");
						pageEle.setAttribute(KohlsPOCConstant.A_NOOF_PAGES, "1");
						
						ExceptionDoc.getDocumentElement().appendChild(pageEle);
						log.error("Exception Output"+ SCXmlUtil.getString(ExceptionDoc));
						return ExceptionDoc;
						
					}
					YFSException ex = new YFSException();
					log.error("Force_Offline - Invalid Stores provided in UI"+ stores);
					ex.setErrorDescription("Invalid Stores "+ stores);
					throw ex;
				}
			} 
			//Avoiding main catch as it will consume the error and constructed display error can not be thrown to SBC screen
			finally {
				YFSContext ctx = (YFSContext) env;
				try {
					ctx.commit();
				} catch (SQLException e) {
					log.error("Exception while committing the context.");
				}
			}
			return outDoc;
	}

	
	private void setForceOfflineReasonForStore(YFSEnvironment env, Element eleStoreStatus) throws Exception {
		Document getServerStatusInput= SCXmlUtil.createDocument(KohlsPOCConstant.SERVER_STATUS);
		getServerStatusInput.getDocumentElement().setAttribute(KohlsPOCConstant.SERVER_IP, eleStoreStatus.getAttribute(KohlsPOCConstant.SERVER_IP));
		env.setApiTemplate(API_GET_SERVER_STATUS_FOR_POS, SCXmlUtil.createFromString(GET_SERVER_STATUS_TEMPLATE));
		Document getServerStatusOutput = KohlsCommonUtil.invokeAPI(env,API_GET_SERVER_STATUS_FOR_POS, getServerStatusInput);
		Element eleExtn =(Element) getServerStatusOutput.getElementsByTagName(KohlsPOCConstant.A_EXTN).item(0);		
		eleStoreStatus.setAttribute(KohlsPOCConstant.A_FORCE_OFF_REASON_CODE,eleExtn.getAttribute(KohlsPOCConstant.EXTN_REASON_CODE));
	}

			
	private Element prepareComplexQuery(Element eleInDoc, String strStores) {
		Element eleComplexQry = SCXmlUtil.createChild(eleInDoc, KohlsPOCConstant.E_COMPLEX_QUERY);
		Element eleOr = SCXmlUtil.createChild(eleComplexQry, KohlsPOCConstant.E_OR);

		String storeIds[];
		storeIds = strStores.split(KohlsPOCConstant.COMMA);
		for (String strStore : storeIds) {
			storeList.add(strStore);
			Element eleExp = SCXmlUtil.createChild(eleOr, KohlsPOCConstant.E_EXP);
			eleExp.setAttribute(KohlsPOCConstant.A_NAME, KohlsPOCConstant.STORE_ID);
			eleExp.setAttribute(KohlsPOCConstant.A_VALUE, strStore);
		}

		return eleComplexQry;
	}
	
	private String removePrependedZeroes(String strStore) {
		if (strStore.startsWith(KohlsPOCConstant.ZERO)) {
			strStore = strStore.replaceFirst(KohlsPOCConstant.ZERO, "");
		}
		if (strStore.startsWith(KohlsPOCConstant.ZERO)) {
			strStore = strStore.replaceFirst(KohlsPOCConstant.ZERO, "");
		}
		if (strStore.startsWith(KohlsPOCConstant.ZERO)) {
			strStore = strStore.replaceFirst(KohlsPOCConstant.ZERO, "");
		}
		return strStore;
	}
	
	private void errorMap(String strStore, Document outDoc) {
		if(outDoc!=null) {
			NodeList nlError = outDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_ERROR);
			if (nlError!=null && nlError.getLength() > 0) {
				log.error("Force_Offline - Adding store " + strStore + " to error list");
				errorCount++;
				erroredStores.add(strStore);
			}
		}
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
	}
}
