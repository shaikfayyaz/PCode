package com.kohls.poc.sbc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KohlsCommonUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.util.KohlsTxnSyncDecompression;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.shared.ycp.YFSContext;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsManageStoreOfflineStatus implements YIFCustomApi {

	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsTxnSyncDecompression.class.getName());
	ArrayList<String> erroredStores = new ArrayList<String>();
	int errorCount = 0;

	/*
	 * Sample input doc for this method: <Stores ForceSwitchingFlag="Y"
	 * ExtnReasonCode="DBA Issue" Stores="0778,1024"/>
	 */
	public Document changeStoreOfflineStatus(YFSEnvironment env, Document inDoc) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("Force_Offline - In KohlsManageStoreOfflineStatus changeStoreOfflineStatus method with input \n"
				+ SCXmlUtil.getString(inDoc));
		}

		try {
			
			if(inDoc.getDocumentElement().getNodeName().equalsIgnoreCase(KohlsPOCConstant.TRIGGER_MANUAL_SWITCH))
			{
				StringBuilder inputStores= new StringBuilder();
				String ForceOfflineFlag=inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG);

				if (log.isDebugEnabled()) {
					log.debug("Force_Offline - ForceOfflineFlag value from TriggerManualSwitch input " + ForceOfflineFlag);
				}

				ArrayList<Element> child= SCXmlUtil.getChildren(inDoc.getDocumentElement(), KohlsPOCConstant.ELE_POS_OFFLINE_STATUS);
				for (Element eleStore : child) {
					inputStores.append(eleStore.getAttribute(KohlsPOCConstant.ATTR_STORE_ID));
					inputStores.append(",");
				}

				Document modInDoc= SCXmlUtil.createDocument(KohlsPOCConstant.STORES);
				modInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG, ForceOfflineFlag);
				if (ForceOfflineFlag.equals(KohlsPOCConstant.NO)) {
					modInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE, " ");
				}
				else {
					modInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE, 
							inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.EXTN_REASON_CODE));
				}

				modInDoc.getDocumentElement().setAttribute(KohlsPOCConstant.STORES, inputStores.toString().substring(0, inputStores.length()-1));

				if (log.isDebugEnabled()) {
					log.debug("Force_Offline - inDoc before Modification \n" + SCXmlUtil.getString(inDoc));
				}

				inDoc=modInDoc;

				if (log.isDebugEnabled()) {
					log.debug("Force_Offline - inDoc after Modification \n" + SCXmlUtil.getString(inDoc));
				}
			}
					
			String storeList = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.STORES);
			String reasonCode = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.A_EXTN_REASON_CODE);
			String forceSwitchingFlag = inDoc.getDocumentElement().getAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG);
			List<String> stores = Arrays.asList(storeList.split(","));

			if (((!storeList.isEmpty() && !reasonCode.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.YES))
					|| (!storeList.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.NO))
					|| (!storeList.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.NO)) && reasonCode.isEmpty())
					&& (!stores.isEmpty())) {

				for (String strStore : stores) {
					log.info("Force_Offline - Store Id " + strStore);
					try {
						strStore = removePrependedZeroes(strStore);
						ArrayList<Element> serverStatusList = new ArrayList<>();

						Document docVerifyServer = SCXmlUtil.createDocument(KohlsPOCConstant.SERVER_STATUS);
						docVerifyServer.getDocumentElement().setAttribute(KohlsPOCConstant.STORE_ID, strStore);
						Document getServerListForPOSOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_GET_SERVER_STATUS_LIST_POS, docVerifyServer);
						serverStatusList = SCXmlUtil.getChildren(getServerListForPOSOutput.getDocumentElement(), KohlsPOCConstant.SERVER_STATUS);
						errorMap(strStore, getServerListForPOSOutput);

						if (serverStatusList.size() != 1) {
							if (log.isDebugEnabled()) {
								log.debug("Force_Offline - Entry not found for store " + strStore + " in POS_SERVER_STATUS");
							}
							errorCount++;
							erroredStores.add(strStore);
						} 
						else {
							if (log.isDebugEnabled()) {
								log.debug("Force_Offline - Entry found for store " + strStore + " in POS_SERVER_STATUS");
							}
							Document performManualSwitchAPIForPOSInput = SCXmlUtil.createDocument(KohlsPOCConstant.TRIGGER_MANUAL_SWITCH);
							performManualSwitchAPIForPOSInput.getDocumentElement().setAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG, forceSwitchingFlag);
							Element elePerformManualSwitchAPIForPOS = performManualSwitchAPIForPOSInput.createElement(KohlsPOCConstant.ELE_POS_OFFLINE_STATUS);
							elePerformManualSwitchAPIForPOS.setAttribute(KohlsPOCConstant.SERVER_IP, serverStatusList.get(0).getAttribute(KohlsPOCConstant.SERVER_IP));
							elePerformManualSwitchAPIForPOS.setAttribute(KohlsPOCConstant.STORE_ID, serverStatusList.get(0).getAttribute(KohlsPOCConstant.STORE_ID));
							elePerformManualSwitchAPIForPOS.setAttribute(KohlsPOCConstant.SERVER_STATUS_KEY, serverStatusList.get(0).getAttribute(KohlsPOCConstant.SERVER_STATUS_KEY));
							performManualSwitchAPIForPOSInput.getDocumentElement().appendChild(elePerformManualSwitchAPIForPOS);

							if (log.isDebugEnabled()) {
								log.debug("Force_Offline - performManualSwitchAPIForPOS API call Input \n"
										+ SCXmlUtil.getString(performManualSwitchAPIForPOSInput));
							}  

							Document performManualSwitchAPIForPOSOutput = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_PERFORM_MANUAL_SWITCH, performManualSwitchAPIForPOSInput);
							if (log.isDebugEnabled()) {
								log.debug("Force_Offline - performManualSwitchAPIForPOS API call Output \n" 
										+ SCXmlUtil.getString(performManualSwitchAPIForPOSOutput));
							}
							errorMap(strStore, performManualSwitchAPIForPOSOutput);	

							//Calling manageServerStatus API
							Document manageServerStatusForPOSInput = SCXmlUtil.createFromString(SCXmlUtil.getString(serverStatusList.get(0)));
							manageServerStatusForPOSInput.getDocumentElement().setAttribute(KohlsPOCConstant.FORCE_SWITCH_FLAG, forceSwitchingFlag);
							Element extnElement = manageServerStatusForPOSInput.createElement(KohlsPOCConstant.E_EXTN);
							if (forceSwitchingFlag.equals(KohlsPOCConstant.YES)) {
								extnElement.setAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE, reasonCode);
							} else {
								extnElement.setAttribute(KohlsPOCConstant.ATTR_EXTN_REASON_CODE, " ");
							}
							manageServerStatusForPOSInput.getDocumentElement().appendChild(extnElement);
							if (log.isDebugEnabled()) {
								log.debug("Force_Offline - manageServerStatusForPOS API call Input \n" 
										+ SCXmlUtil.getString(manageServerStatusForPOSInput));
							}

							Document docUpdateStoreForceOfflineStatus = KohlsCommonUtil.invokeAPI(env, KohlsPOCConstant.API_MANAGE_SERVER_STATUS_POS, manageServerStatusForPOSInput);
							if (log.isDebugEnabled()) {
								log.debug("Force_Offline - manageServerStatusForPOS API call Output \n" + SCXmlUtil.getString(docUpdateStoreForceOfflineStatus));
							}		
							errorMap(strStore, docUpdateStoreForceOfflineStatus);
						}
					}
					catch(Exception e) {
						log.info("Force_Offline - Store "+ strStore + " errored out due to " + e.getMessage());
						errorCount++;
						erroredStores.add(strStore);					
					}
				}
			} else {
				if (storeList.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.YES) && reasonCode.isEmpty()) {
					log.error("Force_Offline - stores and reason code is not provided");
					YFSException ex = new YFSException();
					ex.setErrorDescription("StoreList and ReasonCode is missing");
					throw ex;
				} else if (storeList == null || storeList.isEmpty()) {
					log.error("Force_Offline - missing stores in SBC UI input");
					YFSException ex = new YFSException();
					ex.setErrorDescription("StoreList is missing");
					throw ex;
				} else if (reasonCode.isEmpty() && forceSwitchingFlag.equals(KohlsPOCConstant.YES)) {
					log.error("Force_Offline - reason code is missing in SBC UI for stores "+ stores);
					YFSException ex = new YFSException();
					ex.setErrorDescription("ReasonCode is missing " + "\n");
					throw ex;
				}
				YFSException ex = new YFSException();
				log.error("Force_Offline - Invalid Stores provided in UI"+ stores);
				ex.setErrorDescription("Invalid Stores "+ stores);
				throw ex;
			}
		} 
		//Avoiding main catch as it will consume the error and constructed display error can not be thrown to SBC screen
		finally {
			YFSContext ctx = (YFSContext) env;
			ctx.commit();
			YFSException ex = new YFSException();
			log.info("Force_Offline - Errored out stores " + erroredStores);
			if (errorCount > 0) {
				StringBuilder sbError = new StringBuilder();
				sbError.append("Errored stores "+erroredStores +",\n");
				String splunkLink = "Splunk search index \nPROD--- index=kohls_prod_logistics_omsr \"Force_Offline -\" "
						+ ", \nLLE--- index=kohls_lle_logistics_omsr \"Force_Offline -\"";	
				sbError.append(splunkLink);
				log.info("Force_Offline - constructed error message for display\n"+sbError.toString());
				ex.setErrorDescription(sbError.toString());
				throw ex;
			}
		}		
		return inDoc;
	}

	
	private void errorMap(String strStore, Document outDoc) {
		if(outDoc!=null) {
			NodeList nlError = outDoc.getDocumentElement().getElementsByTagName(KohlsPOCConstant.E_ERROR);
			if (nlError!=null && nlError.getLength() > 0) {
				log.info("Force_Offline - Adding store " + strStore + " to error list");
				errorCount++;
				erroredStores.add(strStore);
			}
		}
	}

	
	private String removePrependedZeroes(String strStore) {
		if (strStore.startsWith(KohlsPOCConstant.ZERO)) {
			strStore = strStore.replaceFirst(KohlsPOCConstant.ZERO, "");
		}
		if (strStore.startsWith(KohlsPOCConstant.ZERO)) {
			strStore = strStore.replaceFirst(KohlsPOCConstant.ZERO, "");
		}
		if (strStore.startsWith(KohlsPOCConstant.ZERO)) {
			strStore = strStore.replaceFirst(KohlsPOCConstant.ZERO, "");
		}
		return strStore;
	}
	 
	@Override
	public void setProperties(Properties arg0) throws Exception {

	}

}
