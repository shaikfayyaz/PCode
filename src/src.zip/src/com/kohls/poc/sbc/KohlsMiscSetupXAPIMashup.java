package com.kohls.poc.sbc;

import java.util.ArrayList;

import org.w3c.dom.Element;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.ui.web.framework.context.SCUIContext;
import com.sterlingcommerce.ui.web.framework.mashup.SCUIMashupMetaData;
import com.sterlingcommerce.ui.web.platform.mashup.SCUIXAPIMashup;
import com.yantra.yfc.log.YFCLogCategory;

public class KohlsMiscSetupXAPIMashup extends SCUIXAPIMashup{
	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsMiscSetupXAPIMashup.class.getName());
	
	public Element massageInput(Element inputEl,
			SCUIMashupMetaData mashupMetaData, SCUIContext uiContext) {

		String strMashupId = mashupMetaData.getMashupId();
		log.info("Input to massageInput for " + strMashupId);
		switch(strMashupId) {
		   case KohlsPOCConstant.MASHUP_MANAGE_ASC_DATES :
			log.debug("Input to massageInput before modification manageASC_DATES" + SCXmlUtil.getString(inputEl));
			String strCodeValue  = inputEl.getAttribute(KohlsPOCConstant.CODE_VALUE).replaceAll("-", "");
			String strCodeShortDesc = inputEl.getAttribute(KohlsPOCConstant.CODE_SHORT_DESC).replaceAll("-", "");
			String strCodeLongDesc= inputEl.getAttribute(KohlsPOCConstant.CODE_LONG_DESC).replaceAll("-", "");
			inputEl.setAttribute(KohlsPOCConstant.CODE_VALUE, strCodeValue);
			inputEl.setAttribute(KohlsPOCConstant.CODE_SHORT_DESC, strCodeShortDesc);
			inputEl.setAttribute(KohlsPOCConstant.CODE_LONG_DESC, strCodeLongDesc);
			log.info("Input to massageInput after modification manageASC_DATES" + SCXmlUtil.getString(inputEl));
			return super.massageInput(inputEl,mashupMetaData, uiContext);
		}
		return inputEl;
		
	}
	
	
	public Element massageOutput(Element inputEl,
			SCUIMashupMetaData mashupMetaData, SCUIContext uiContext) {
		String strMashupId = mashupMetaData.getMashupId();
		log.info("Input to massageOutput for " + strMashupId);
		 
		switch(strMashupId) {
		case  KohlsPOCConstant.MASHUP_GET_ASC_DATES:
			log.debug("Input to massageOutput before modification common-getASC_DATES " + SCXmlUtil.getString(inputEl));
			ArrayList<Element> commonCodeList = SCXmlUtil.getChildren(inputEl,
					KohlsPOCConstant.E_COMMON_CODE);
			for(Element eleCommonCode : commonCodeList){
				String strCodeValue  = convertToDateWithHiphen(eleCommonCode.getAttribute(KohlsPOCConstant.CODE_VALUE));
				String strCodeShortDesc = convertToDateWithHiphen(eleCommonCode.getAttribute(KohlsPOCConstant.CODE_SHORT_DESC));
				String strCodeLongDesc= convertToDateWithHiphen(eleCommonCode.getAttribute(KohlsPOCConstant.CODE_LONG_DESC));
				eleCommonCode.setAttribute(KohlsPOCConstant.CODE_VALUE, strCodeValue);
				eleCommonCode.setAttribute(KohlsPOCConstant.CODE_SHORT_DESC, strCodeShortDesc);
				eleCommonCode.setAttribute(KohlsPOCConstant.CODE_LONG_DESC, strCodeLongDesc);
			}
			log.info("Input to massageOutput after modification common-getASC_DATES " + SCXmlUtil.getString(inputEl));
			return super.massageOutput(inputEl,mashupMetaData, uiContext);
		}
		return inputEl;
	}


	private String convertToDateWithHiphen(String strCodeValue) {
			StringBuffer strBuffer = new StringBuffer(strCodeValue);
			if(strBuffer.length()==8){
				strBuffer = strBuffer.insert(4, "-");
				strBuffer = strBuffer.insert(7, "-");
			}
			log.debug("after modification from convertToDateWithHiphen " + strBuffer.toString());
			return strBuffer.toString();
	}	
}
