package com.kohls.poc.sbc;

import org.w3c.dom.Element;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.sterlingcommerce.ui.web.framework.context.SCUIContext;
import com.sterlingcommerce.ui.web.framework.mashup.SCUIMashupMetaData;
import com.sterlingcommerce.ui.web.platform.mashup.SCUIPaginatedXAPIMashup;
import com.yantra.yfc.log.YFCLogCategory;

public class KohlsMiscSetupPaginatedXAPIMashup extends SCUIPaginatedXAPIMashup{
	private static final YFCLogCategory log = YFCLogCategory
			.instance(KohlsMiscSetupPaginatedXAPIMashup.class.getName());
	
	public Element massageInput(Element inputEl,
			SCUIMashupMetaData mashupMetaData, SCUIContext uiContext) {
		
		String strMashupId = mashupMetaData.getMashupId();
		log.info("Input to massageInput for " + strMashupId);
		switch(strMashupId) {
		   case KohlsPOCConstant.MASHUP_GET_OFFLINE_TXN_Q_LIST :
				Element eleAPI = SCXmlUtil.getChildElement(inputEl, KohlsPOCConstant.E_API);
				Element eleInput = SCXmlUtil.getChildElement(eleAPI, KohlsPOCConstant.E_INPUT);
				Element eleOfflineTrxQ = SCXmlUtil.getChildElement(eleInput, KohlsPOCConstant.E_OFFLINE_TRANSACTION_Q);
				inputEl.setAttribute(KohlsPOCConstant.CTX_ORG_CODE, eleOfflineTrxQ.getAttribute(KohlsPOCConstant.A_STORE_ID));
				log.info("Input to massageInput after modification kohls-getOfflineTxnQList " + SCXmlUtil.getString(inputEl));
				return super.massageInput(inputEl,mashupMetaData, uiContext);
				
		}
		return inputEl;
		
	}
}
