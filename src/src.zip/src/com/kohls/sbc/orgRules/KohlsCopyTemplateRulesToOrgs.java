package com.kohls.sbc.orgRules;

import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsXMLUtil;
import com.kohls.common.util.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsCopyTemplateRulesToOrgs extends KOHLSBaseApi {

	private static final YFCLogCategory logger = YFCLogCategory
			.instance(KohlsCopyTemplateRulesToOrgs.class);
	private Properties props;
	String customOrgCode = null;
	Document manageRuleInputDoc = null;
	Element manageRuleInputEle = null;
	Document docRuleListForTemplateOrg = null;
	Element eleRuleListForTemplateOrg = null;

	public void copyTemplateRules(YFSEnvironment env, Document inDoc)
			throws Exception {
		logger.debug("Inside KohlsCopyTemplateRulesToOrgs");
		if (!YFCCommon.isVoid(props.getProperty("customTemplateOrg")))
			customOrgCode = props.getProperty("customTemplateOrg");
		docRuleListForTemplateOrg = getRulesForOrg(env, customOrgCode);
		eleRuleListForTemplateOrg = docRuleListForTemplateOrg
				.getDocumentElement();
		logger.debug("Get RUles for CUSTOM org: " + KohlsXMLUtil.getElementXMLString(eleRuleListForTemplateOrg));
		Element eleOrgList = inDoc.getDocumentElement();
		logger.debug("Indoc: " + KohlsXMLUtil.getElementXMLString(eleOrgList));
		Element eleSelectedOrg = null;
		if (!YFCCommon.isVoid(eleOrgList)) {
			NodeList nlOrgList = eleOrgList
					.getElementsByTagName(KohlsPOCConstant.ELEM_ORGANIZATION);
			int length = nlOrgList.getLength();
			manageRuleInputDoc = XMLUtil.createDocument("RuleList");
			manageRuleInputEle = manageRuleInputDoc.getDocumentElement();
			for (int i = 0; i < length; i++) {
				eleSelectedOrg = (Element) nlOrgList.item(i);
				manageRuleInputEle = rulesToDeleteFromOrg(env,
						manageRuleInputEle,
						eleSelectedOrg.getAttribute("OrganizationCode"));
				manageRuleInputEle = rulesToInsertInOrg(manageRuleInputEle,
						eleSelectedOrg.getAttribute("OrganizationCode"),
						eleRuleListForTemplateOrg);
			}
			manageRuleInputEle = rulesToDeleteFromTemplateOrg(env,
					manageRuleInputEle);
			logger.debug("Indoc for ManageRuleFORPOS: " + KohlsXMLUtil.getElementXMLString(manageRuleInputEle));
			manageRuleForPOS(env);
			
		}
	}

	/**
	 *
	 * @param eleRuleListForTemplateOrg
	 * @param manageRuleInputEle
	 * @param organizationCode
	 * @return
	 * @throws Exception
	 */
	public Element rulesToInsertInOrg(Element manageRuleInputEle,
			String organizationCode, Element eleRuleListForTemplateOrg)
			throws Exception {
		NodeList nlRules = eleRuleListForTemplateOrg
				.getElementsByTagName("Rule");
		Element ruleEle = null;
		if (!YFCCommon.isVoid(eleRuleListForTemplateOrg)) {
			for (int j = 0; j < nlRules.getLength(); j++) {
				ruleEle = XMLUtil.createChild(manageRuleInputEle, "Rule");
				ruleEle.setAttribute("OrganizationCode", organizationCode);
				ruleEle.setAttribute("RuleID",
						((Element) nlRules.item(j)).getAttribute("RuleID"));
				ruleEle.setAttribute("RuleValue",
						((Element) nlRules.item(j)).getAttribute("RuleValue"));
			}
		}
		return manageRuleInputEle;
	}

	/**
	 *
	 * @param yfsEnv
	 * @param manageRuleInputEle
	 * @param organizationCode
	 * @return
	 * @throws Exception
	 */
	public Element rulesToDeleteFromOrg(YFSEnvironment yfsEnv,
			Element manageRuleInputEle, String organizationCode)
			throws Exception {
		Document docRuleListForSelectedOrg = null;
		Element eleRuleListForSelectedOrg = null;
		Element ruleEle = null;
		docRuleListForSelectedOrg = getRulesForOrg(yfsEnv, organizationCode);
		eleRuleListForSelectedOrg = docRuleListForSelectedOrg
				.getDocumentElement();
		NodeList nlRules = eleRuleListForSelectedOrg
				.getElementsByTagName("Rule");
		if (!YFCCommon.isVoid(docRuleListForSelectedOrg)) {
			for (int j = 0; j < nlRules.getLength(); j++) {
				ruleEle = XMLUtil.createChild(manageRuleInputEle, "Rule");
				ruleEle.setAttribute("OrganizationCode", organizationCode);
				ruleEle.setAttribute("Action", "Delete");
				ruleEle.setAttribute("RuleID",
						((Element) nlRules.item(j)).getAttribute("RuleID"));
			}

		}
		return manageRuleInputEle;
	}

	/**
	 *
	 * @param yfsEnv
	 * @param manageRuleInputEle
	 * @param organizationCode
	 * @return
	 * @throws Exception
	 */
	public Element rulesToDeleteFromTemplateOrg(YFSEnvironment yfsEnv,
			Element manageRuleInputEle)
			throws Exception {
		NodeList nlRules = eleRuleListForTemplateOrg
				.getElementsByTagName("Rule");
		Element ruleEle = null;
		if (!YFCCommon.isVoid(eleRuleListForTemplateOrg)) {
			for (int j = 0; j < nlRules.getLength(); j++) {
				ruleEle = XMLUtil.createChild(manageRuleInputEle, "Rule");
				ruleEle.setAttribute("OrganizationCode", customOrgCode);
				ruleEle.setAttribute("Action", "Delete");
				ruleEle.setAttribute("RuleID",
						((Element) nlRules.item(j)).getAttribute("RuleID"));
			}

		}
		return manageRuleInputEle;
	}
	/**
	 *
	 * @param yfsEnv
	 * @param organizationCode
	 * @return
	 * @throws Exception
	 */
	public Document getRulesForOrg(YFSEnvironment yfsEnv,
			String organizationCode) throws Exception {
		logger.beginTimer("getRulesForCustomTemplateOrg");
		Document rule = XMLUtil.createDocument(KohlsPOCConstant.E_RULE);
		Element ruleEle = rule.getDocumentElement();
		XMLUtil.setAttribute(ruleEle, KohlsPOCConstant.A_ORGANIZATION_CODE,
				organizationCode);
		String sGetRuleListTemplate = "<RuleList><Rule RuleID='' RuleValue='' RuleKey='' OrganizationCode=''/></RuleList>";
		Document getRuleListForPOSAPIoutDoc = KOHLSBaseApi.invokeAPI(yfsEnv,
				XMLUtil.getDocument(sGetRuleListTemplate),
				KohlsPOCConstant.API_GET_RULE_LIST_FOR_POS, rule);
		logger.endTimer("getRulesForCustomTemplateOrg");
		return getRuleListForPOSAPIoutDoc;
	}

	/**
	 *
	 * @param yfsEnv
	 * @return
	 * @throws Exception
	 */
	public void manageRuleForPOS(YFSEnvironment yfsEnv) throws Exception {
		logger.beginTimer("manageRuleForPOS");
		KOHLSBaseApi.invokeAPI(yfsEnv,
					"manageRuleForPOS", manageRuleInputDoc);
		logger.endTimer("manageRuleForPOS");
	}

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}
}
