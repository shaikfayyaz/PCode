package com.kohls.sbc.orgRules;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;



public class KohlsPoCOrgRuleUtil {
	private static YFCLogCategory logger;

	static {
		logger = YFCLogCategory.instance(KohlsPoCOrgRuleUtil.class.getName());
	}

	/**
	 * Returns the result document of calling the getRuleListForPOS API
	 * @param yfsEnv
	 * @param strOrgCode
	 * @param ruleID
	 * @return
	 * @throws DOMException
	 * @throws Exception
	 */
	public static Document callGetRuleListForPOSByRuleID (YFSEnvironment yfsEnv,
			String strOrgCode, String ruleID) throws DOMException, Exception {
		
		logger.beginTimer("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByRuleID -- Begin");
		// Remove leading Zeros if present 
		strOrgCode = strOrgCode.replaceFirst("^0+(?!$)", "");
		Document docRuleListForPOSOutput = null;
		// Prepare Input to call getRuleListForPOS API
					Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE)
							.getDocument();
					Element eleInput = docInput.getDocumentElement();
					eleInput.setAttribute("CallingOrganizationCode",
							strOrgCode);
					eleInput.setAttribute(KohlsXMLLiterals.A_RULE_ID, 
							ruleID);
		try
		{
				
			// calling getRuleListForPOS API
			docRuleListForPOSOutput = KOHLSBaseApi.invokeAPI(yfsEnv,
					KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
			
			if (logger.isDebugEnabled())
			{
				logger.debug("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByRuleID docInput="+
					XMLUtil.getXMLString(docInput));
				logger.debug("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByRuleID docRuleListForPOSOutput="+
						XMLUtil.getXMLString(docRuleListForPOSOutput));
			}
			logger.endTimer("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByRuleID -- End");	
		}
		catch(Exception e)
		{
			// remove calling organization code.
			eleInput.removeAttribute(KohlsPOCConstant.A_CALLING_ORGANIZATION_CODE);
			// fall back to organization code. 
			eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE,
					strOrgCode);
			
			// calling getRuleListForPOS API
			docRuleListForPOSOutput = KOHLSBaseApi.invokeAPI(yfsEnv,
								KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);
		}
		
		return docRuleListForPOSOutput;
	}
	
	/**
	 * Returns the rule value for the specified rule ID or the default value if none exist
	 * @param yfsEnv
	 * @param strOrgCode
	 * @param ruleID
	 * @param defaultValue
	 * @return
	 * @throws DOMException
	 * @throws Exception
	 */
	public static String getRuleValueForPOSByRuleID (YFSEnvironment yfsEnv,
			String strOrgCode, String ruleID, String defaultValue) throws DOMException, Exception {

		String retValue = null;
		Document docRuleListForPOSOutput = callGetRuleListForPOSByRuleID(yfsEnv, strOrgCode, ruleID);
        if (!YFCCommon.isVoid(docRuleListForPOSOutput)) {
        		Element eleRuleList = docRuleListForPOSOutput.getDocumentElement();
        		if (!YFCCommon.isVoid(eleRuleList)) {
        			Element eleRule =
        					(Element) eleRuleList.getElementsByTagName(KohlsXMLLiterals.E_RULE).item(0);
        			if (!YFCCommon.isVoid(eleRule)) {
        				String strRuleValue = eleRule.getAttribute(KohlsXMLLiterals.A_RULE_VALUE);
        				if (!YFCCommon.isVoid(strRuleValue)) {
        					retValue = strRuleValue;
        				}
        				else {
                			logger.debug("KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID null strRuleValue");
                		}
        			}
        			else {
            			logger.debug("KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID null eleRule");
            		}
        		}
        		else {
        			logger.debug("KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID null eleRuleList");
        		}
        }
        else {
        		logger.debug("KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID null docRuleListForPOSOutput");
        }
        if (retValue == null) {
    			retValue = defaultValue;
        		logger.debug("KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID returning default value " + retValue);
        }
        logger.debug("KohlsPoCOrgRuleUtil.getRuleValueForPOSByRuleID returning " + retValue);
        return retValue;
	}
	
	/**
	 * Returns the result document of calling the getRuleListForPOS API
	 * @param yfsEnv
	 * @param strOrgCode
	 * @param groupName
	 * @return
	 * @throws DOMException
	 * @throws Exception
	 */
	public static Document callGetRuleListForPOSByGroupName(YFSEnvironment yfsEnv,
			String strOrgCode, String groupName) throws DOMException, Exception {
	    logger.beginTimer("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByGroupName -- Begin");
	    Document docRuleListForPOSOutput = null;

	    // Prepare Input to call getRuleListForPOS API
	    Document docInput = YFCDocument.createDocument(KohlsXMLLiterals.E_RULE).getDocument();
	    Element eleInput = docInput.getDocumentElement();
	    eleInput.setAttribute(KohlsXMLLiterals.A_ORGANIZATION_CODE, strOrgCode);
	    Element eleRuleMetadata = docInput.createElement("RuleMetadata");
	    eleRuleMetadata.setAttribute("GroupName", groupName);
	    eleInput.appendChild(eleRuleMetadata);
	    // calling getRuleListForPOS API
	    docRuleListForPOSOutput =
	        KOHLSBaseApi.invokeAPI(yfsEnv, KohlsConstant.API_GET_RULE_LIST_FOR_POS, docInput);

		if(logger.isDebugEnabled()) {
		    logger.debug("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByGroupName docInput="
		        + XMLUtil.getXMLString(docInput));
		    logger.debug("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByGroupName docRuleListForPOSOutput="
		        + XMLUtil.getXMLString(docRuleListForPOSOutput));
		   
		}
		logger.endTimer("KohlsPoCOrgRuleUtil.callGetRuleListForPOSByGroupName -- End"); 
		return docRuleListForPOSOutput;
		    
	  }
}
