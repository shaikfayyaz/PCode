package com.kohls.util.webserviceUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.MDC;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.messaging.v1_0.header.MessageHeaderCreator;
import com.kohls.messaging.v1_0.header.MessageHeaderException;
import com.kohls.messaging.v1_0.header.MessageSenderNodeInfo;
import com.kohls.messaging.v1_0.header.jaxb.MessageHeader;
//import com.kohls.messaging.v1_0.header.handler.MessageHeaderProcessorImpl;
//import com.kohls.messaging.v1_0.header.soap.SoapMessageUtil;
import com.kohls.messaging.v1_0.header.util.SoapMessageUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

/**************************************************************************
 * File : KohlsPoc WebServiceCaller.java Author : IBM Created : June 6
 * 2013 Modified : July 27 2013 Version : 0.2
 ***************************************************************************** 
 * HISTORY
 ***************************************************************************** 
 * V0.1 12/07/2013 IBM First Cut.
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This file is a webservice client that invokes the webservice end point and
 * processes the response
 * 
 * @author Naveen Yalamanchili
 * @version 0.2
 *****************************************************************************/
public class WebServiceCaller implements YIFCustomApi {

	private static YFCLogCategory LOG_CAT = YFCLogCategory.instance(WebServiceCaller.class);

	private Properties props;

	//added this static variable for holding webservice timetaken value
	public static long timeTakenLong ;
	/**
	 * Default Constructor class
	 * @throws Exception if anything goes wrong
	 */
/*	public WebServiceCaller() throws Exception {
		super();
	} */


	/**
	 * This function
	 * 1.Prepares the SOAP Request
	 * 2.Invokes the webservice endpoint
	 * 3.Returns the SOAP response as a Document
	 * @param env environment variable
	 * @param requestDoc request Document
	 * @return Document
	 * @throws Exception to handle any abnormal behavior
	 */
	public Document invokeWS(YFSEnvironment env, Document requestDoc)
			throws Exception {

	    LOG_CAT.beginTimer("WebServiceCaller.invokeWS");
	    
		//LOG_CAT.debug("in call method of webservice JAVA");

		//LOG_CAT.debug("call to createSoapMessage");
		SOAPMessage request = this.createSoapRequest(requestDoc);

		//LOG_CAT.debug("call to add Header to the SoapMessage");
		this.addHeader(request, props);

		//Added for BR-2549 - Setting Time taken for WebService response---Start
		
				long beginTime = System.currentTimeMillis();
				LOG_CAT.verbose("beginTime of service--WebServiceCaller:::::"+beginTime);
				
				//LOG_CAT.debug("Call the end point");
				SOAPMessage response = this.callEndpoint(request);
				
				long endTime = System.currentTimeMillis();
				LOG_CAT.verbose("endTime of service--WebServiceCaller:::::"+endTime);
				
			timeTakenLong = endTime-beginTime;
				
				
				
				
				//Added for BR-2549 - Setting Time taken for WebService response---End

		//LOG_CAT.debug("Get the SoapBody from the response");
		SOAPBody responseBody = response.getSOAPBody();

		//LOG_CAT.debug("Check whether the response is having any fault in the body");
		if (responseBody.hasFault()) {
			this.logSoapFault(responseBody);
			if(getPropertyValue(this.props.getProperty("appName")).compareToIgnoreCase("PAYMENTS")!=0)
				responseBody = this.getFaultformated(responseBody);

		}

		LOG_CAT.endTimer("WebServiceCaller.invokeWS");
		
		//LOG_CAT.debug("return the soapbody");
		return responseBody.extractContentAsDocument();
	}


	/**
	 * This method handles all soap fault message body
	 * @param responseBody which contain SAOPFault
	 * @return SOAPBody in well formated manner
	 * @throws Exception to handle any abnormal behavior
	 */

	public SOAPBody getFaultformated(SOAPBody responseBody) throws Exception { 

		String faultcode = responseBody.getFault().getFaultCode();
		String faultstring = responseBody.getFault().getFaultString();

		String code = null;
		String msg = null;
		Detail soapDetail = responseBody.getFault().getDetail();

		if (!YFCCommon.isVoid(soapDetail)) {

			code = XPathUtil.getString(soapDetail, "code");

			msg = XPathUtil.getString(soapDetail, "message");

		}

		if (YFCCommon.isVoid(code)) {
			code = faultstring;
		}

		if (YFCCommon.isVoid(msg)) {
			msg = "Undetermined error description";
		}

		
		System.setProperty("javax.xml.soap.MessageFactory",
				"weblogic.xml.saaj.MessageFactoryImpl");

		
		MessageFactory mf = MessageFactory.newInstance();
		SOAPMessage faultresponse = mf.createMessage();
		SOAPPart soapPart = faultresponse.getSOAPPart();

		SOAPEnvelope env = soapPart.getEnvelope();
		SOAPBody soapBody = env.getBody();

		SOAPFault fault = soapBody.addFault();

		fault.addNamespaceDeclaration("S", "http://schemas.xmlsoap.org/soap/envelope/");
		fault.addNamespaceDeclaration(soapBody.getPrefix(), "http://schemas.xmlsoap.org/soap/envelope/");

		fault.setFaultCode(faultcode);
		fault.setFaultString(faultstring);

		Detail myDetail = fault.addDetail();

		QName entryName = new QName("code");
		DetailEntry entry = myDetail.addDetailEntry(entryName);
		entry.addTextNode(code);

		QName entryName2 = new QName("message");
		DetailEntry entry2 = myDetail.addDetailEntry(entryName2);
		entry2.addTextNode(msg);

		return faultresponse.getSOAPBody();
	}

	/**
	 * This function is used for creating a SOAPRequest with requestDoc added to the SOAPBody 
	 * @param requestDoc Input Document using which we need to prepare a SOAPMessage.
	 * @return SOAPMessage
	 * @throws SOAPException when there is a SOAPException occur
	 */
	public static SOAPMessage createSoapRequest(Document requestDoc)
			throws SOAPException {

		//LOG_CAT.debug("In createSoapMessage method in the webservice");

		LOG_CAT.beginTimer("WebServiceCaller.createSoapRequest");
	    
		System.setProperty("javax.xml.soap.MessageFactory",
				"weblogic.xml.saaj.MessageFactoryImpl");
		

		MessageFactory mf = MessageFactory.newInstance();
		SOAPMessage request = mf.createMessage();
		SOAPPart soapPart = request.getSOAPPart();

		SOAPEnvelope env = soapPart.getEnvelope();
		SOAPBody soapBody = env.getBody();
		soapBody.addDocument(requestDoc);
		
		LOG_CAT.endTimer("WebServiceCaller.createSoapRequest");

		return request;
	}

	/**
	 * This public method is used for logging the SOAPFault 
	 * @param responseBody of the response we got from the Soap call
	 */
	public void logSoapFault(SOAPBody responseBody) {
		//LOG_CAT.debug("In the call soap fault method in webservice");
		SOAPFault fault = responseBody.getFault();
		String msg = "Encountered SOAP Fault " + fault.getFaultCode()
				+ " while calling endpoint";
		//LOG_CAT.error(msg);
	}

	/**
	 * This function is used for calling the endpoint and fetching SOAP Response from it 
	 * @param request Using which we will call the endpoint
	 * @return SOAPMessage response from the endpoint after the call
	 * @exception Exception throws a specific exception depending upon the exception arrived
	 */
	public SOAPMessage callEndpoint(SOAPMessage request) throws Exception {
	    
		long beginTime = System.currentTimeMillis();
	    LOG_CAT.beginTimer("WebServiceCaller.callEndpoint");
	    
		SOAPConnection connection = null;
		SOAPMessage response = null;        
		try {
			//LOG_CAT.debug("In callendpoint method in the webservice");

			connection = this.createSOAPConnection();

			//Seetha 12/13 Changes for ReadTimeout --START
			/*Map<String, Object> requestCtx = ((BindingProvider) port).getRequestContext();
             requestCtx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
             props.getProperty("END_POINT_URL"));

             String connectTimeout = props.getProperty("CONNECT_TIMEOUT");

             if (connectTimeout != null&& !connectTimeout.isEmpty())
                 requestCtx.put("com.sun.xml.ws.connect.timeout",Integer.parseInt(connectTimeout));

             String requestTimeout = props.getProperty("REQUEST_TIMEOUT");

             if (requestTimeout != null&& !requestTimeout.isEmpty())
                 requestCtx.put("com.sun.xml.ws.request.timeout",Integer.parseInt(requestTimeout));*/

			QName serviceName = new QName("SterlingServices");
			QName portName = new QName("SterlingServicesSOAP");

			String soapAction = "";
			if (!YFCCommon.isVoid(WebServiceCaller.getPropertyValue(this.props
					.getProperty("soapAction")))) {
				soapAction = WebServiceCaller.getPropertyValue(this.props
						.getProperty("soapAction"));
			}

			Service service = Service.create(serviceName);
			service.addPort(portName, SOAPBinding.SOAP11HTTP_BINDING, getPropertyValue(this.props.getProperty("endPoint")));



			Dispatch<SOAPMessage> dispatch = service.createDispatch(portName, SOAPMessage.class, Service.Mode.MESSAGE);
			Map<String, Object>  map = dispatch.getRequestContext();

			map.put(BindingProvider.SOAPACTION_USE_PROPERTY, Boolean.TRUE);
			map.put(BindingProvider.SOAPACTION_URI_PROPERTY,  soapAction);
			//added on  06/01/2014.
			if (!YFCCommon.isVoid(getPropertyValue(props.getProperty("timeOut")))){

				map.put("com.sun.xml.ws.connect.timeout",Integer.parseInt(getPropertyValue(props.getProperty("timeOut")))); 
				map.put("com.sun.xml.ws.request.timeout",Integer.parseInt(getPropertyValue(props.getProperty("timeOut"))));
				//  map.put("com.sun.xml.ws.read.timeout", Integer.parseInt(getPropertyValue(props.getProperty("timeOut"))));

			}

			
			if(LOG_CAT.isDebugEnabled()){
				ByteArrayOutputStream req = new ByteArrayOutputStream();
				request.writeTo(req);
				LOG_CAT.debug("###### Request is ##### : \n"+XMLUtil.getXMLString(XMLUtil.getDocument(req.toString())));
				req.flush();
			}
			/*URL endpointURL=null;
            if(getPropertyValue(this.props.getProperty("appName")).compareToIgnoreCase("PAYMENTS")==0){
            String spec=getPropertyValue(this.props.getProperty("endPoint"));
            endpointURL = new URL(null,spec,new URLStreamHandler() {
                       @Override
                       protected URLConnection openConnection(URL url) throws IOException {
                          URL clone_url = new URL(url.toString());
                          HttpURLConnection clone_urlconnection =  (HttpURLConnection)clone_url.openConnection();
                          clone_urlconnection.setConnectTimeout(10000);
                          clone_urlconnection.setReadTimeout(10000);
                          return(clone_urlconnection); 
                       }
                });*/
			//LOG_CAT.beginTimer("Webservice Call");  
			LOG_CAT.beginTimer("###### End point URL is ##### : "+getPropertyValue(this.props.getProperty("endPoint")));
			
			response=dispatch.invoke(request);

			//Seetha 12/13 Changes for ReadTimeout -- END


			LOG_CAT.endTimer("###### End point URL is ##### : "+getPropertyValue(this.props.getProperty("endPoint")));		
			
			if(LOG_CAT.isDebugEnabled()){
				ByteArrayOutputStream resp = new ByteArrayOutputStream();
				response.writeTo(resp);
				LOG_CAT.debug("###### response is ##### : \n"+XMLUtil.getXMLString(XMLUtil.getDocument(resp.toString())));
				resp.flush();
			}

		} catch (Exception e) { 

			// Temporary statement
			e.printStackTrace();			
			Throwable tmp = e;
			while(tmp != null){
				LOG_CAT.debug("In While loop block: "+tmp.getCause());
				if (tmp.getCause() instanceof java.net.ConnectException) { 
					LOG_CAT.debug("The Error message from webservice response is java.net.ConnectException."
							+ " So throwing EXTN_CONNECT");
					throw new YFSException("java.net.ConnectException","EXTN_CONNECT","EXTN_CONNECT");
				} else if (tmp.getCause() instanceof java.io.IOException
						|| tmp.getCause() instanceof java.net.SocketTimeoutException) {
					LOG_CAT.debug("The Error message from webservice response is "+tmp.getCause()
								+" So throwing EXTN_IO");
					throw new YFSException("java.net.SocketTimeoutException","EXTN_IO","EXTN_IO");
				}
		        tmp = tmp.getCause();
		    }
			LOG_CAT.debug("The Error message from webservice is Generic. So throwing EXTN_OTHER");
			throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
		} finally {
			if(!YFCCommon.isVoid(System.getProperty("sun.net.client.defaultReadTimeout"))){
				System.clearProperty("sun.net.client.defaultReadTimeout");
			}
			//connection.close();           
		}

		LOG_CAT.endTimer("WebServiceCaller.callEndpoint");
		long endTime = System.currentTimeMillis();
		long responseTime = endTime-beginTime;
		String endPoint = this.props.getProperty("endPoint");
		LOG_CAT.info("SOAP WebService Enpoint - " + endPoint + " took " + responseTime + " ms");
		
		return response;
	}

	/**
	 * This function is used for creating a SOAPConnection
	 * @return SOAPConnection connection 
	 */
	public SOAPConnection createSOAPConnection() {

		//LOG_CAT.debug("In the createSoapConnection method in webservice");
		System.setProperty("javax.xml.soap.SOAPConnectionFactory",
				"weblogic.wsee.saaj.SOAPConnectionFactoryImpl");
		System.setProperty("sun.net.client.defaultConnectTimeout",
				getPropertyValue(this.props.getProperty("timeOut")));


		/*if(!YFCCommon.isVoid(this.props.getProperty("readTimeOut"))){
            System.setProperty("sun.net.client.defaultReadTimeout",getPropertyValue(this.props.getProperty("readTimeOut")));           
        }*/
		SOAPConnection connection = null;
		try {
			//LOG_CAT.debug("Create Soap Connection");
			connection =  SOAPConnectionFactory.newInstance().createConnection();
		} catch (SOAPException e) {
			//LOG_CAT.debug("SOAPException in the creation of SOAPConnection");
		} 

		return connection;
	}

	/**
	 * This function is used for adding Header based on Kohls standards to the SOAPMessage 
	 * Message ID and Node ID will be added to the header using the createRequestMessageHeader() function
	 * @param request to which MessageHeader is added
	 * @throws SOAPException 
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 */
	@SuppressWarnings("rawtypes")
	public static void addHeader(SOAPMessage request, Properties sysProperties) throws SOAPException, ParserConfigurationException, SAXException, IOException {

	    LOG_CAT.beginTimer("WebServiceCaller.addHeader");
	    
		try {
			
			/*if (!YFCCommon.isVoid(sysProperties)){
				props= sysProperties;
			}*/
			//LOG_CAT.debug("In call to addHeader method in webservice");
			//Fix for defect 1999 - Start
			//MessageHeaderProcessorImpl headprocessorimpl = new MessageHeaderProcessorImpl();
			MessageHeaderCreator headerCreator = new com.kohls.messaging.v1_0.header.MessageHeaderCreator();
			MessageSenderNodeInfo msgsendernodeinfo = new com.kohls.messaging.v1_0.header.MessageSenderNodeInfo();

			//LOG_CAT.debug("Set message header details");
			msgsendernodeinfo.setSystemCode(getPropertyValue(sysProperties.getProperty("systemCode")));
			msgsendernodeinfo.setModule(getPropertyValue(sysProperties.getProperty("module")));
			msgsendernodeinfo.setAppName(getPropertyValue(sysProperties.getProperty("appName")));
			
			//LOG_CAT.debug("Set message sender node info");
			//headprocessorimpl.setMessageHeaderCreator(msgsendernodeinfo);
			headerCreator.setMessageSenderNodeInfo(msgsendernodeinfo);
			
			//LOG_CAT.debug("Add SOAPAction");
			MimeHeaders hd = request.getMimeHeaders();
						if(getPropertyValue(sysProperties.getProperty("appName")).equalsIgnoreCase("AssignGeoTax")){
			    String geoTaxUser = getPropertyValue(sysProperties.getProperty("geoTaxUser"));
			    String getTaxPwd = getPropertyValue(sysProperties.getProperty("geoTaxPassword"));
			    String geoTaxEncryptKey = getPropertyValue(sysProperties.getProperty("geoTaxEncryptKey"));
			    KohlsRestAPIUtil restApiUtil = new KohlsRestAPIUtil();			    
				String loginPassword = restApiUtil.decryptString(geoTaxUser, geoTaxEncryptKey)+":"+restApiUtil.decryptString(getTaxPwd, geoTaxEncryptKey);
				hd.addHeader("Authorization", "Basic " + new String(Base64.encodeBase64(loginPassword.getBytes())));
			}
		      
		      
			if (!YFCCommon.isVoid(sysProperties.getProperty("soapAction"))) {
				hd.addHeader("SOAPAction", getPropertyValue(sysProperties.getProperty("soapAction")));
			}
			
			//LOG_CAT.debug("call to create Request Message Header");
			//MessageHeader header = headprocessorimpl.createRequestMessageHeader();
			MessageHeader header = headerCreator.createMessageHeader();
			
			// Added for PST-443 - Start
			//Below is added for correlationid For the TVS. TVS is expecting it X-KOHLS-CorrelationID at MIME header
			
			if (!YFCCommon.isVoid(sysProperties.getProperty("X_KOHLS_CORRELATION_ID"))
					&& !YFCCommon.isVoid(getPropertyValue(sysProperties
							.getProperty("X_KOHLS_CORRELATION_ID"))))
							 {
				hd.addHeader(getPropertyValue(sysProperties
						.getProperty("X_KOHLS_CORRELATION_ID")),
						KohlsPoCCommonAPIUtil.getCorrelationID());
			} 
			// Below is added for standard Kohls SOAP util provision for adding correlatonID
			header.setCorrelationID(KohlsPoCCommonAPIUtil
						.getCorrelationID());			
			// Added for PST-443 - End
			
			XMLGregorianCalendar dDateTime = header.getCreateDateTime();
			LOG_CAT.debug("CreateDateTime for Module "+getPropertyValue(sysProperties.getProperty("module"))
					+"is: "+dDateTime);
			
			//Fix for defect 1999 - End
			
			//LOG_CAT.debug("Add Version");
			if (!YFCCommon.isVoid(sysProperties.getProperty("hdrVersion"))) {
				header.setVersion(getPropertyValue(sysProperties.getProperty("hdrVersion")));
			}

			//LOG_CAT.debug("Add Action");
			if (!YFCCommon.isVoid(sysProperties.getProperty("action"))) {
				header.setAction(getPropertyValue(sysProperties.getProperty("action")));
			}

			//LOG_CAT.debug("Put header to the soap message");
			SoapMessageUtil.putMessageHeader(request, header);
			
			//Manoj 07/08: Changes for 2732 Begin
			if(dDateTime.getMillisecond() % 10 == 0) {
				LOG_CAT.debug("********Enterd in special logic********");
				SOAPHeader header1 =  request.getSOAPPart().getEnvelope().getHeader();	          
				Iterator hdrIterator = header1.getChildElements(new QName("urn:kohls:xml:schemas:message-header:v1_0", "MessageHeader"));
	           while (hdrIterator.hasNext()) {
	        	   javax.xml.soap.Node headerElement = (javax.xml.soap.Node)hdrIterator.next();
				   if(headerElement.getNodeName().contains("MessageHeader")){
					   LOG_CAT.debug("*********Found MessageHeader*********");
						NodeList nodeIterator = headerElement.getChildNodes();
						for(int i=0; i<nodeIterator.getLength(); i++){
							javax.xml.soap.Node childElement = (Node) nodeIterator.item(i);
							if(childElement.getNodeName().equalsIgnoreCase("CreateDateTime")){
								LOG_CAT.debug("*********Found CreateDateTime*********");
								LOG_CAT.debug("Current value of CreateDateTime is: "+childElement.getValue());
								LOG_CAT.debug("Setting CreateDateTime as "+dDateTime.toString());
								childElement.setValue(dDateTime.toString());
							}
						}
					}
	            }
	            
			}
			//Manoj 07/08: Changes for 2732 End
			
		} catch (MessageHeaderException e) {
			LOG_CAT.debug("MessageHeaderException in the calladdHeader method in the webservice");
		}
		
		LOG_CAT.endTimer("WebServiceCaller.addHeader");

	}

	/**
	 * Sets the properties
	 * @param prop Properties that need to be set
	 * @throws Exception when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		//LOG_CAT.debug("In the set properties method");

	}

	/**
	 * This function is used to get the value for a property
	 * @param property name in string format
	 * @return String propValue
	 */
	public static String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		//Manoj 10/22: updated to use configured property if 
		// customer_overrides.properties does not return any value
		if(YFCCommon.isVoid(propValue)){
			propValue = property;
		}
		return propValue;

	}

	 public static String getSOAPMessageAsString(SOAPMessage soapMessage) {
	      try {

	         TransformerFactory tff = TransformerFactory.newInstance();
	         Transformer tf = tff.newTransformer();

	         // Set formatting
	
	         tf.setOutputProperty(OutputKeys.INDENT, "yes");
	         tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount",
	               "2");
	         
	         Source sc = soapMessage.getSOAPPart().getContent();

	         ByteArrayOutputStream streamOut = new ByteArrayOutputStream();
	         StreamResult result = new StreamResult(streamOut);
	         tf.transform(sc, result);

	         String strMessage = streamOut.toString();
	         return strMessage;
	      } catch (Exception e) {
	         System.out.println("Exception in getSOAPMessageAsString "
	               + e.getMessage());
	         return null;
	      }

	 }
	 
}
