package com.kohls.util.webserviceUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

import javax.xml.namespace.QName;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Node;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.XMLUtil;
import com.kohls.messaging.v1_0.header.HostIpAddressNodeIdStrategy;
import com.kohls.poc.rest.KohlsRestAPIUtil;
import com.kohls.poc.util.KohlsPoCCommonAPIUtil;
import com.sun.xml.messaging.saaj.client.p2p.HttpSOAPConnectionFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCDateUtils;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**************************************************************************
 * File : InvokeWebService.java Author : IBM Created : July 7 2014 Modified :
 * July 07 2014 Version : 0.1
 ***************************************************************************** 
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 * 
 ***************************************************************************** 
 ***************************************************************************** 
 * This Java file provides an interface to invoke the webservice end point with
 * the supplied request and then processes the response. This code is slight
 * modification to WebServiceCaller.java file to use the soap message factory
 * from axis jars and not has no dependency on Weblogic jars. *
 * 
 * @author Jyothi P
 * @version 0.1
 *****************************************************************************/
public class InvokeWebService implements YIFCustomApi {

    private static YFCLogCategory LOG_CAT = YFCLogCategory
            .instance(InvokeWebService.class);
    private Properties props;
    FailoverUtil fs =  FailoverUtil.getInstance();
    static KohlsRestAPIUtil restApiutil = new KohlsRestAPIUtil();
    boolean isMonitored = false;
    boolean isPrimary = false;
    boolean isBackup = false;
    boolean isOffline = false;
    Set<String> respElements = new HashSet<String>();

    
    /**
     * Default Constructor class
     * 
     * @throws Exception
     *             if anything goes wrong
     */
    public InvokeWebService() throws Exception {
        super();
    }

    /**
     * This function 1.Prepares the SOAP Request 2.Invokes the webservice
     * endpoint 3.Returns the SOAP response as a Document
     * 
     * @param env
     *            environment variable
     * @param requestDoc
     *            request Document
     * @return Document
     * @throws Exception
     *             to handle any abnormal behavior
     */
    public Document invokeWS(YFSEnvironment env, Document requestDoc)
            throws Exception {
        LOG_CAT.beginTimer("InvokeWebService.invokeWS");
        LOG_CAT.verbose("The WebService Object instance creation start: " + System.currentTimeMillis()); //log for PST-4305
        WebServiceCaller oKohlsWSUtl = new WebServiceCaller();
        LOG_CAT.verbose("The WebService Object instance creation end : " + System.currentTimeMillis()); //log for PST-4305

        LOG_CAT.debug("call to createSoapMessage");
        LOG_CAT.verbose("The WebService call to createSoapMessage start: " + System.currentTimeMillis()); //log for PST-4305
        SOAPMessage request = WebServiceCaller.createSoapRequest(requestDoc);
        LOG_CAT.verbose("The WebService call to createSoapMessage end: " + System.currentTimeMillis()); //log for PST-4305

        
        LOG_CAT.debug("call to add Header to the SoapMessage");
        LOG_CAT.verbose("Read appName from property file start: " + System.currentTimeMillis()); //log for PST-4305
        //Changes for CAPE-4052 start
        if (!YFCCommon.isVoid(this.props.getProperty("appName")) &&
           "SKUSVC".equalsIgnoreCase(getPropertyValue(this.props.getProperty("appName")))){
          addTibcoHeader(request, props);
        } else {
          WebServiceCaller.addHeader(request, props);
        }
      //Changes for CAPE-4052 end
        LOG_CAT.verbose("Read appName from property file end: " + System.currentTimeMillis()); //log for PST-4305
        
        
        // Changes for adding namespace attribute in SOAP request for SVC call
        // for release 2 - Start
        //Fix for defect 1793 - Start
        /*if (this.getPropertyValue(this.props.getProperty("appName"))
                .compareToIgnoreCase("PaymentGateway") != 0) {
            SOAPElement eleMessageHeader = (SOAPElement) request
                    .getSOAPHeader().getFirstChild();
            eleMessageHeader.setAttribute("xmlns",
                    "urn:kohls:xml:schemas:message-header:v1_0");
        }*/ 
        //Fix for defect 1793 - End
        // Changes for adding namespace attribute in SOAP request for SVC call
        // for Release 2 - End
        //Fix for defect 3846 - Start
        String sAppName = this.props.getProperty("appName");
        LOG_CAT.debug("*******appName********"+sAppName); 
        if ((!YFCCommon.isVoid(this.props.getProperty("appName"))) &&
                (sAppName.equalsIgnoreCase("SVCAPPNAME")) ){
            
        LOG_CAT.debug("*******inside SVC condition********");   
        SOAPHeader header1 =  request.getSOAPPart().getEnvelope().getHeader();            
        Iterator<?> hdrIterator = header1.getChildElements(new QName("urn:kohls:xml:schemas:message-header:v1_0", "MessageHeader"));
        LOG_CAT.debug("The iterator size :" +hdrIterator.hasNext());
        while (hdrIterator.hasNext()) {
           javax.xml.soap.Node headerElement = (javax.xml.soap.Node)hdrIterator.next();
           if(headerElement.getNodeName().contains("MessageHeader")){
               LOG_CAT.debug("The message header is adding new xmlns attribute");
               SOAPElement hElement = (SOAPElement)headerElement;
           	   hElement.setAttribute("xmlns", "urn:kohls:xml:schemas:message-header:v1_0");
               LOG_CAT.debug("The new header value is :" +XMLUtil.getElementXMLString(hElement));
               NodeList nodeHeaderList = headerElement.getChildNodes();
                for(int i=0; i<nodeHeaderList.getLength(); i++){
                    SOAPElement childElement = (SOAPElement) nodeHeaderList.item(i);
                    childElement.setAttribute("xmlns", "urn:kohls:xml:schemas:message-header:v1_0");
                    
                }
           }
        }
        }
       //Fix for defect 3846 - End
        LOG_CAT.debug("Call the end point callEndpoint method start" + System.currentTimeMillis()); //log for PST-4305
        //fs.loadPropValues();
        SOAPMessage response = this.callEndpoint(request);
        LOG_CAT.debug("Call the end point callEndpoint method end" + System.currentTimeMillis()); //log for PST-4305

        // Changes for adding namespace attribute in SOAP request for SVC call
        // for release 2 - Start
        String nodeId = "";
        SOAPBody responseBody = null;
        try {
            SOAPHeader sH = response.getSOAPHeader();
            if(!YFCCommon.isVoid(sH) && !YFCCommon.isVoid((String) ((Element) sH.getElementsByTagName("From")
                    .item(0)).getAttribute("nodeID"))){
            nodeId = (String) ((Element) sH.getElementsByTagName("From")
                    .item(0)).getAttribute("nodeID");
            LOG_CAT.debug("The nodeId value to be stamped in the response body is :"
                    + nodeId);
            }
            LOG_CAT.verbose("Get the SoapBody from the response");
            responseBody = response.getSOAPBody();
            
            LOG_CAT.verbose("handle SVC response when MQ Timeout.");
            this.handleSVCRespMQTimeOut(responseBody);

            LOG_CAT.verbose("Check whether the response is having any fault in the body");
            if (responseBody.hasFault()) {
                oKohlsWSUtl.logSoapFault(responseBody);
                if (this.getPropertyValue(this.props.getProperty("appName"))
                        .compareToIgnoreCase("PAYMENTS") != 0 )
                    responseBody = oKohlsWSUtl.getFaultformated(responseBody);

            }
        }catch (Exception e) {
            
            if(e.getCause() instanceof javax.xml.soap.SOAPException || e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException){
                LOG_CAT.debug("Error while processing fault code");
            }else{
                LOG_CAT.debug("Error while getting Node Id value:");
            }
        }

        Document docResponseBody = responseBody.extractContentAsDocument();

        docResponseBody.getDocumentElement().setAttribute("NodeId", nodeId);
        //Fix for PR-359 - Start
        if(!YFCCommon.isVoid(docResponseBody) && (!YFCCommon.isVoid(this.props.getProperty("appName"))) &&
                (this.props.getProperty("appName").equalsIgnoreCase("KOHLSCASHDEACTIVATIONAPPNAME")) &&
                !YFCCommon.isVoid(XMLUtil.getChildElement(docResponseBody.getDocumentElement(), "faultcode"))){
            docResponseBody.getDocumentElement().setAttribute("xmlns:s", "http://schemas.xmlsoap.org/soap/envelope/");
        }
        //Fix for PR-359 - End
        LOG_CAT.debug("The docResponseBody value is :"
                + XMLUtil.getXMLString(docResponseBody));

        LOG_CAT.endTimer("InvokeWebService.invokeWS");
        return docResponseBody;
        // Changes for adding namespace attribute in SOAP request for SVC call
        // for Release 2 - End
    }
    
    /**
     * Handle the SVC Response, when OMS makes call to SVG service and SVG service returns back with Offline response and SOAP fault code. This is in case, 
     * MQ timeout/error between SVG service and MainFrame.
     * @param responseBody
     * @throws SOAPException
     */
	public void handleSVCRespMQTimeOut(SOAPBody responseBody)
			throws SOAPException {
		
		if ((!YFCCommon.isVoid(this.props.getProperty("appName")))
		        && (this.props.getProperty("appName").equalsIgnoreCase("SVCAPPNAME"))) {
			
		    SOAPElement paymentResponse = this.getPaymentResponseNode(responseBody);
		    LOG_CAT.debug("PaymentResponse with available nodes :"+ respElements);
		    if (!respElements.isEmpty()
		            && !respElements.contains("approvedAmount")) {
		    	
		    	LOG_CAT.debug("*******inside : handleSVCRespMQTimeOut ********");
		    	
		    	LOG_CAT.debug("SVG: Offline response and SOAP fault code. This is in case, MQ timeout/error between SVG service and MainFrame.");
		    	
		    	LOG_CAT.debug("SVG: Update the response body with missing attributes ");
		        
		        SOAPElement approvedAmount = paymentResponse.addChildElement("approvedAmount");
		        approvedAmount.addTextNode("0.00");
		        
		        if (!respElements.contains("remainingBalance")) {
		            paymentResponse.addChildElement("remainingBalance");
		        }
		        LOG_CAT.debug("SVG: OFFLINE - paymentResponse with new nodes :"+ respElements);
		    }
		}
	}

    /**
     * This function is used for calling the endpoint and fetching SOAP Response
     * from it
     * 
     * @param request
     *            Using which we will call the endpoint
     * @return SOAPMessage response from the endpoint after the call
     * @exception Exception
     *                throws a specific exception depending upon the exception
     *                arrived
     */
    public SOAPMessage callEndpoint(SOAPMessage request) throws Exception {

        long beginTime = System.currentTimeMillis();
        LOG_CAT.beginTimer("InvokeWebService.callEndpoint");
        SOAPConnection connection = null;
        SOAPMessage response = null;
        LOG_CAT.verbose("InvokeWebService.callEndpoint propety files read start" + System.currentTimeMillis()); //log for PST-4305

        String strEndPoint = this.props.getProperty("endPoint");
        String monitoredURL = YFSSystem.getProperty(strEndPoint
                + ".MONITORED");
        String backupURL = YFSSystem.getProperty(strEndPoint
                + ".BACKUP_ENDPOINT");
        LOG_CAT.verbose("InvokeWebService.callEndpoint propety files read end" + System.currentTimeMillis()); //log for PST-4305

        try {
             // Changes for 4305  start
		beginTime = System.currentTimeMillis();
             // Changes for 4305  end
		LOG_CAT.verbose("CreateSOAPConnection object connection start" + System.currentTimeMillis()); //log for PST-4305
        	connection = createSOAPConnection();
                LOG_CAT.verbose("CreateSOAPConnection object connection end" + System.currentTimeMillis()); //log for PST-4305

        	if (!YFCCommon.isVoid(monitoredURL)) {
                isMonitored = true;
            }
            if(isMonitored){
            if (!isBackup) {
                LOG_CAT.verbose("InvokeWebservice Failover util call to set endpoint for Primary start" + System.currentTimeMillis()); //log for PST-4305
           
                strEndPoint = fs.getEndPointToCall(this.props
                                .getProperty("endPoint"));
                LOG_CAT.verbose("InvokeWebservice Failover util call to set endpoint for Primary end" + System.currentTimeMillis()); //log for PST-4305
            	LOG_CAT.debug("Endpoint to call ::" + strEndPoint);
                    if (strEndPoint.contains("PRIMARY")) {
                        strEndPoint = this.getPropertyValue(this.props
                                .getProperty("endPoint") + ".MONITORED");
                        isPrimary = true;
                    } else if (strEndPoint.contains("BACKUP")) {
                        strEndPoint = this.getPropertyValue(this.props
                                .getProperty("endPoint") + ".BACKUP_ENDPOINT");
                        isBackup = true;
                    } else if (strEndPoint.contains("OFFLINE")) {
                        isOffline = true;	
                        throw new YFSException("EXTN_OTHER-OFFLINE","EXTN_OTHER","EXTN_OTHER");
                    }
                    LOG_CAT.verbose("Endpoint to call:: Property file setting end" + System.currentTimeMillis()); //log for PST-4305

            }else{
                    if (!YFCCommon.isVoid(backupURL)) {
                        strEndPoint = this.getPropertyValue(this.props
                                .getProperty("endPoint") + ".BACKUP_ENDPOINT");
                    } else {
                        isOffline = true;
                        throw new YFSException("EXTN_OTHER-OFFLINE","EXTN_OTHER","EXTN_OTHER");
                    }
                }
            }else{
                strEndPoint = getPropertyValue(strEndPoint);
                LOG_CAT.debug("The strEndPoint value for other urls is " +strEndPoint);
            }
            URL endpoint = new URL(null, strEndPoint,
                    new URLStreamHandler() {
                        @Override
                        protected URLConnection openConnection(URL url)
                                throws IOException {
                            URL clone_url = new URL(url.toString());
                            HttpURLConnection clone_urlconnection = (HttpURLConnection) clone_url
                                    .openConnection();
                            // TimeOut settings
                            clone_urlconnection.setConnectTimeout(Integer
                                    .parseInt(getPropertyValue(props
                                            .getProperty("timeOut"))));
                            clone_urlconnection.setReadTimeout(Integer
                                    .parseInt(getPropertyValue(props
                                            .getProperty("timeOut"))));
                            return (clone_urlconnection);
                        }
                    });
            if (LOG_CAT.isDebugEnabled()) {
                ByteArrayOutputStream req = new ByteArrayOutputStream();
                request.writeTo(req);
                LOG_CAT.debug("###### Request is ##### : \n"
                        + XMLUtil.getXMLString(XMLUtil.getDocument(req
                                .toString())));
                req.flush();
            }

            LOG_CAT.beginTimer("###### End point URL is ##### : "+ strEndPoint);
            response = connection.call(request, endpoint);
            LOG_CAT.endTimer("###### End point URL is ##### : "+ strEndPoint);
            // Changes for 4305  start
            long endTime = System.currentTimeMillis();
            long responseTime = endTime - beginTime;
            LOG_CAT.info("SOAP WebService Endpoint - " + strEndPoint + " took " + responseTime + " ms");
            // Changes for 4305  end
            // Changes for PST-3561 Start
            /* Handle the TVS Response, when OMS makes call to TVS service and TVS service returns back Internal Server Error. */
        	if ((!YFCCommon.isVoid(this.props.getProperty("appName")))
        	        && (this.props.getProperty("appName").equalsIgnoreCase("TVSAPPNAME"))) {
        		SOAPBody responseBody = response.getSOAPBody();
        		Set<String> OMSrespElements = getOMSResponseNode(responseBody);
        		String omstag = OMSrespElements.toString();
        	     LOG_CAT.debug("OMS Response :"+ OMSrespElements); 
        	     if (!OMSrespElements.isEmpty() 
        	    		 && (omstag.toUpperCase().contains("INTERNAL_ERROR"))||
        	    		 			(omstag.toUpperCase().contains("INTERNAL_SERVER_ERROR"))) {
        	    	         LOG_CAT.debug("The Error message from webservice"
                                    + " So throwing INTERNAL_ERROR");
                            throw new YFSException("INTERNAL_ERROR", "TVSAPPNAME", "INTERNAL_SERVER_ERROR");
                        
        	    }
        	}
        	 // Changes for PST-3561 End         
            
            
            if (!YFCCommon.isVoid(response) && isMonitored) {
                if(isBackup){
                    fs.resetFailedCounter(this.props.getProperty("endPoint"),
                            "BACKUP");
                }else {
                    fs.resetFailedCounter(this.props.getProperty("endPoint"),
                            "PRIMARY");
                }
            }

            if (LOG_CAT.isDebugEnabled()) {
                ByteArrayOutputStream resp = new ByteArrayOutputStream();
                response.writeTo(resp);
                LOG_CAT.debug("###### response is ##### : \n"
                        + XMLUtil.getXMLString(XMLUtil.getDocument(resp
                                .toString())));
                resp.flush();
            }

        } //Replacing YFCException with YFSException for defect 1380
        catch (Exception e) { 
            e.printStackTrace();
            // Changes for 4305  start
            long endTime = System.currentTimeMillis();
            long responseTime = endTime - beginTime;
            LOG_CAT.info("SOAP failure WebService Endpoint - " + strEndPoint + " took " + responseTime + " ms");

            LOG_CAT.debug("wsProperties at the end::"+fs.getWsProperties());
            // Changes for 4305 end
            if (e.getCause() instanceof java.net.ConnectException) {
                if(!isMonitored){
                    LOG_CAT.debug("The Error message from webservice response is java.net.ConnectException."
                            + " So throwing EXTN_CONNECT");
                    throw new YFSException("EXTN_CONNECT","EXTN_CONNECT","EXTN_CONNECT");
                }else {
                    LOG_CAT.debug("In Catch");
                    LOG_CAT.debug("isMonitored:::"+isMonitored);
                    LOG_CAT.debug("offline:::"+isOffline);
                    LOG_CAT.debug("backup:::"+isBackup);
                     if (isOffline) {
                            LOG_CAT.debug("In Offline. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                            throw new YFSException("EXTN_OTHER-OFFLINE","EXTN_OTHER","EXTN_OTHER");
                    }else if (isBackup) {
                        LOG_CAT.debug("No response from Backup. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "BACKUP");
                       // fs.incrementFailedCounter(this.props.getProperty("endPoint"),
                         //   "BACKUP");
                       // fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                           //     "BACKUP",!YFCCommon.isVoid(backupURL));
                        throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                    }else {
                        LOG_CAT.debug("No response from primary");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "PRIMARY");
                        //fs.incrementFailedCounter(
                              //  this.props.getProperty("endPoint"), "PRIMARY");
                        //fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                               // "PRIMARY",!YFCCommon.isVoid(backupURL));
                        isBackup = true;
                        response = this.callEndpoint(request);
                    }
                }
            } else if (e.getCause() instanceof java.io.IOException
                    || e.getCause() instanceof java.net.SocketTimeoutException) {
                if(!isMonitored){
                    LOG_CAT.debug("The Error message from webservice response is "
                            +" So throwing EXTN_IO");
                    throw new YFSException("EXTN_IO","EXTN_IO","EXTN_IO");
                }else {
                    LOG_CAT.debug("In Catch");
                    LOG_CAT.debug("isMonitored:::"+isMonitored);
                    LOG_CAT.debug("offline:::"+isOffline);
                    LOG_CAT.debug("backup:::"+isBackup);
                     if (isOffline) {
                            LOG_CAT.debug("In Offline. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                            throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                    }else if (isBackup) {
                        LOG_CAT.debug("No response from Backup. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "BACKUP");
                        //fs.incrementFailedCounter(this.props.getProperty("endPoint"),
                           // "BACKUP");
                        //fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                                //"BACKUP",!YFCCommon.isVoid(backupURL));
                        throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                    }else {
                        LOG_CAT.debug("No response from primary");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "PRIMARY");
                        //fs.incrementFailedCounter(
                                //this.props.getProperty("endPoint"), "PRIMARY");
                        //fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                               // "PRIMARY",!YFCCommon.isVoid(backupURL));
                        isBackup = true;
                        response = this.callEndpoint(request);
                    }
                }
            } else if (e.getCause() instanceof javax.xml.soap.SOAPException
                    || e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
                if(!isMonitored || e.getMessage().contains("400")){
                    throw new YFSException("SOAP_EXCEPTION","SOAP_EXCEPTION","SOAP_EXCEPTION");
                }else {
                    LOG_CAT.debug("In Catch");
                    LOG_CAT.debug("isMonitored:::"+isMonitored);
                    LOG_CAT.debug("offline:::"+isOffline);
                    LOG_CAT.debug("backup:::"+isBackup);
                     if (isOffline) {
                            LOG_CAT.debug("In Offline. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                            throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                    }else if (isBackup) {
                        LOG_CAT.debug("No response from Backup. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "BACKUP");
                        //fs.incrementFailedCounter(this.props.getProperty("endPoint"),
                           // "BACKUP");
                       // fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                               // "BACKUP",!YFCCommon.isVoid(backupURL));
                        throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                    }else {
                        LOG_CAT.debug("No response from primary");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "PRIMARY");
                        //fs.incrementFailedCounter(
                                //this.props.getProperty("endPoint"), "PRIMARY");
                        //fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                               // "PRIMARY",!YFCCommon.isVoid(backupURL));
                        isBackup = true;
                        response = this.callEndpoint(request);
                    }
                }
            } else {
                if(!isMonitored){
                    LOG_CAT.debug("The Error message from webservice is Generic. So throwing EXTN_OTHER");
                    throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                }else {
                    LOG_CAT.debug("In Catch");
                    LOG_CAT.debug("isMonitored:::"+isMonitored);
                    LOG_CAT.debug("offline:::"+isOffline);
                    LOG_CAT.debug("backup:::"+isBackup);
                     if (isOffline) {
                            LOG_CAT.debug("In Offline. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                            throw new YFSException("EXTN_OTHER-Offline","EXTN_OTHER","EXTN_OTHER");
                    }else if (isBackup) {
                        LOG_CAT.debug("No response from Backup. The Error message from webservice is Generic. So throwing EXTN_OTHER");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "BACKUP");
                        //fs.incrementFailedCounter(this.props.getProperty("endPoint"),
                           // "BACKUP");
                        //fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                               // "BACKUP",!YFCCommon.isVoid(backupURL));
                        throw new YFSException("EXTN_OTHER","EXTN_OTHER","EXTN_OTHER");
                    }else {
                        LOG_CAT.debug("No response from primary");
                        fs.compareAndIncrementCounters(this.props.getProperty("endPoint"),
                                "PRIMARY");
                        //fs.incrementFailedCounter(
                              //  this.props.getProperty("endPoint"), "PRIMARY");
                       //fs.compareFailedThreshold(this.props.getProperty("endPoint"),
                                //"PRIMARY",!YFCCommon.isVoid(backupURL));
                        isBackup = true;
                        response = this.callEndpoint(request);
                    }
                }
            }
        } finally {
            long endTime = System.currentTimeMillis();
            long responseTime = endTime - beginTime;
            //String cffFilePath = "/home/sterling/sterling93/logs/CFF";
           String cffFilePath = "/logs/apps/of/CFF"; 
    	    		SimpleDateFormat sdf = new SimpleDateFormat("ddHHmmss");
    	    		String timestamp = sdf.format(YFCDateUtils.getCurrentDate(true));	
    	    		LOG_CAT.debug("wsProperties at the end::"+fs.getWsProperties());
    	    		String fileNameSuffix = null;
    	    		if(!YFCCommon.isVoid(this.props.getProperty("appName")))
    	    		{
    	    			fileNameSuffix = this.props.getProperty("appName")+"_";
    	    		}
    	    		else
    	    		{
    	    			fileNameSuffix = "SOAP_";
    	    		}
    	    		restApiutil.writeToFile("KohlsCallDMAPIWrapper.callDMAPI failover Props --->\n",
        		fs.getWsProperties().toString(),"CFF_"+fileNameSuffix+timestamp,cffFilePath);
         // Changes for 4305 start
          if (connection != null){
         // Changes for 4305 end
            connection.close();
	 // Changes for 4305 start
	    LOG_CAT.debug("Connection closing timing - " + strEndPoint + " took " + responseTime + " ms");
          }
         // Changes for 4305 end
        }
        LOG_CAT.endTimer("InvokeWebService.callEndpoint");

        return response;
    }

    /**
     * This function is used for creating a SOAPConnection
     * 
     * @return SOAPConnection connection
     */
    public SOAPConnection createSOAPConnection() {
        LOG_CAT.beginTimer("InvokeWebService.createSOAPConnection");

        SOAPConnection connection = null;
        HttpSOAPConnectionFactory factoryInst = new HttpSOAPConnectionFactory();

        try {
            LOG_CAT.debug("Creating Soap Connection");
            connection = factoryInst.createConnection();

        } catch (Exception e) {
            LOG_CAT.debug("SOAPException in the creation of SOAPConnection");
            throw new YFSException("SOAPException in the creation of SOAPConnection","EXTN_CONNECT","EXTN_CONNECT");
        }
        LOG_CAT.endTimer("InvokeWebService.createSOAPConnection");
        return connection;
    }

    /**
     * Sets the properties
     * 
     * @param prop
     *            Properties that need to be set
     * @throws Exception
     *             when unable to set the Property
     */

    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
        LOG_CAT.debug("In the set properties method");

    }

    /**
     * This function is used to get the value for a property
     * 
     * @param property
     *            name in string format
     * @return String propValue
     */
    public String getPropertyValue(String property) {
        LOG_CAT.beginTimer("InvokeWebService.getPropertyValue");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        // Manoj 10/22: updated to use configured property if
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        LOG_CAT.endTimer("InvokeWebService.getPropertyValue");
        return propValue;

    }
    
    private SOAPElement getPaymentResponseNode(SOAPBody body) {

      LOG_CAT.debug("*******inside SVC condition: getPaymentResponseNode ********"); 
      
      SOAPElement element = null;
      if (body != null) {
          Iterator<?> it = body.getChildElements();
          while (it.hasNext()) {
              Object o = it.next();
              if (o instanceof SOAPElement) {
                  element = (SOAPElement) o;
              }
          }
      }
      
      if (element != null) {
          NodeList nodes = element.getChildNodes();
          for (int i = 0; i < nodes.getLength(); i++) {
              Node current = (Node) nodes.item(i);
              respElements.add(current.getNodeName());
          }
      }
      return element;
  }
   
    //Changes for PST-3561 start
    /**
     * This function is used to get all XMl nodes into a hashmap
     * 
     * @param SoapBody body
     *            name in string format
     * @return SOAPElement element
     */    
    private Set<String> getOMSResponseNode(SOAPBody body) {

        LOG_CAT.debug("*******inside getOMSResponseNode Message ********"); 
        //changes for PST-3561 start
        Set<String> OMSrespElements = new HashSet<String>(); 
        //changes for PST-3561 end
        
        SOAPElement element = null;
        if (body != null) {
            Iterator<?> it = body.getChildElements();
            while (it.hasNext()) {
                Object o = it.next();
                if (o instanceof SOAPElement) {
                    element = (SOAPElement) o;
                }
            }
        }
        
        if (element != null) {
            NodeList nodes = element.getChildNodes();
            for (int i = 0; i < nodes.getLength(); i++) {
                Node current = (Node) nodes.item(i);
                OMSrespElements.add(current.getNodeName() + " : " + current.getNodeValue() 
                		+ " : " + current.getTextContent());
            }
        }
        return OMSrespElements;
    }
    
    //Changes for PST-3561 end
    
  /**
   * Create By mrjoshi *
   * 
   * @param request
   * @param props
   */
  //Changes for CAPE-4052 start
  public static void addTibcoHeader(SOAPMessage request, Properties props) throws Exception{
   
      SOAPHeader soapHeader = request.getSOAPHeader();

      SOAPElement messageHeaderElement = soapHeader.addChildElement(
          new QName("http://www.tibco.com/schemas/urn:kohls:xml:schemas:message-header:v1_0.xsd",
              "MessageHeader"));
      // MessageID
      SOAPElement messageIdElement = messageHeaderElement.addChildElement("MessageID");
      messageIdElement.addTextNode(UUID.randomUUID().toString());
      // CreateDateTime
      SOAPElement createDateTimeElement = messageHeaderElement.addChildElement("CreateDateTime");
      createDateTimeElement.addTextNode(
          new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(Calendar.getInstance().getTime()));
      // From app="SKUSVC" module="GetSKU" nodeID="192.168.1.9" systemCode="SKUSVC"
      SOAPElement fromElement = messageHeaderElement.addChildElement("From");
      if (!YFCCommon.isVoid(WebServiceCaller.getPropertyValue(props.getProperty("appName")))) {
        fromElement.setAttribute("app",
            WebServiceCaller.getPropertyValue(props.getProperty("appName")));
      }

      if (!YFCCommon.isVoid(WebServiceCaller.getPropertyValue(props.getProperty("module")))) {
        fromElement.setAttribute("module",
            WebServiceCaller.getPropertyValue(props.getProperty("module")));
      }

      //InetAddress localhost = InetAddress.getLocalHost();
      String mIpAddress = HostIpAddressNodeIdStrategy.getInstance().getNodeId();
      if (!YFCCommon.isVoid(mIpAddress)) {
        fromElement.setAttribute("nodeID", mIpAddress);
      }
      if (!YFCCommon.isVoid(WebServiceCaller.getPropertyValue(props.getProperty("systemCode")))) {
        fromElement.setAttribute("systemCode",
            WebServiceCaller.getPropertyValue(props.getProperty("systemCode")));
      }
      // CorrelationID
      SOAPElement correlationIdElement = messageHeaderElement.addChildElement("CorrelationID");
      correlationIdElement.addTextNode(KohlsPoCCommonAPIUtil.getCorrelationID());

      MimeHeaders hd = request.getMimeHeaders();
      if (!YFCCommon.isVoid(WebServiceCaller.getPropertyValue(props.getProperty("Operation")))) {
        hd.addHeader("Operation",
            WebServiceCaller.getPropertyValue(props.getProperty("Operation")));
      }

      if (!YFCCommon.isVoid(WebServiceCaller.getPropertyValue(props.getProperty("SOAPAction")))) {
        hd.addHeader("Operation",
            WebServiceCaller.getPropertyValue(props.getProperty("SOAPAction")));
      }
      hd.addHeader("SOAPAction",
          "/BusinessServices/Interfaces/SKU/GetSKUService.serviceagent/HTTPConnection/GetSKUOperation");
  
  }
//Changes for CAPE-4052 end
}
