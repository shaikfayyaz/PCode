package com.kohls.util.webserviceUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.Document;

import com.kohls.common.util.XMLUtil;
import com.sun.xml.messaging.saaj.client.p2p.HttpSOAPConnectionFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCInvokeWebService implements YIFCustomApi {

	private static YFCLogCategory logger = YFCLogCategory
			.instance(InvokeWebService.class);
	private Properties props;

	// Failover Code - Start
	static Map<String, Object> wsProperties;
	public static int RETRY_COUNT = 0;

	static {
		logger.debug("Inside Static Block");
		wsProperties = Collections
				.synchronizedMap(new HashMap<String, Object>());
	}

	// Failover Code - End

	/**
	 * Default Constructor class
	 * 
	 * @throws Exception
	 *             if anything goes wrong
	 */
	public KohlsPoCInvokeWebService() throws Exception {
		super();
	}

	/**
	 * This function 1.Prepares the SOAP Request 2.Invokes the webservice
	 * endpoint 3.Returns the SOAP response as a Document
	 * 
	 * @param env
	 *            environment variable
	 * @param requestDoc
	 *            request Document
	 * @return Document
	 * @throws Exception
	 *             to handle any abnormal behavior
	 */
	public Document invokeWS(YFSEnvironment env, Document requestDoc)
			throws Exception {
		logger.beginTimer("InvokeWebService.invokeWS");

		WebServiceCaller oKohlsWSUtl = new WebServiceCaller();

		logger.debug("call to createSoapMessage");
		SOAPMessage request = WebServiceCaller.createSoapRequest(requestDoc);

		logger.debug("call to add Header to the SoapMessage");
		WebServiceCaller.addHeader(request, props);

		// FailOver Code - Start
		// Declare the variables
		URL endPoint = null;
		URL secondaryEndpoint = null;
		SOAPBody responseBody = null;
		SOAPMessage response = null;
		SOAPMessage responseSecondary = null;
		int failureCounter = 0;
		Date date;
		String endPointProperty = this.props.getProperty("endPoint");
		int failureCounterProp = Integer.parseInt(this
				.getPropertyValue(endPointProperty
						+ ".FAILOVER_COUNT_THRESHOLD"));
		logger.debug("endPointProperty" + endPointProperty);
		logger.debug("wsProperties Initial ::" + wsProperties);

		// Load the Collections for the first time call
		if (!YFCCommon.isVoid(wsProperties)
				&& YFCCommon.isVoid(wsProperties.get(endPointProperty
						+ ".ACTIVE_ENDPOINT"))) {
			loadPropValues(endPointProperty);
			logger.debug("wsProperties after loading ::" + wsProperties);
		}

		// Configure the Retry Strategy with number of retries and time to wait
		RetryOnExceptionStrategy retry = new RetryOnExceptionStrategy(
				Integer.parseInt(this.getPropertyValue(endPointProperty
						+ ".RETRY_THRESHOLD")), 20);

		// If Collections is not empty
		if (!YFCCommon.isVoid(wsProperties)
				&& !YFCCommon.isVoid(wsProperties.get(endPointProperty
						+ ".ACTIVE_ENDPOINT"))) {

			logger.debug("Collections is not empty");
			failureCounter = (Integer) wsProperties.get(endPointProperty
					+ ".FAILURE_COUNTER");

			// Check the failureCounter and failureTimelapse against the
			// threshold
			if ((wsProperties.get(endPointProperty + ".ACTIVE_ENDPOINT"))
					.toString().contains("BACKUP")
					&& ((failureCounter > failureCounterProp) || compareTimestamp(endPointProperty))) {
				logger.debug("Failure Threshold elapsed..Connecting to Primary");
				while (retry.shouldRetry()) {
					endPoint = formURL(this.getPropertyValue(endPointProperty
							+ ".MONITORED"));
					try {
						response = this.callEndpoint(request, endPoint);
						if (!YFCCommon.isVoid(response)) {
							wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
									"PRIMARY");
							retry.resetRetries();
						}
					} catch (Exception e) {
						e.printStackTrace();
						if (e.getCause() instanceof java.net.ConnectException) {
							logger.debug("In Catch");
							RETRY_COUNT--;
							retry.errorOccured();
							if (RETRY_COUNT == 0) {
								secondaryEndpoint = formURL(this
										.getPropertyValue(endPointProperty
												+ ".BACKUP_ENDPOINT"));
								responseSecondary = this.callEndpoint(request,
										secondaryEndpoint);
								if (!YFCCommon.isVoid(responseSecondary)) {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "BACKUP");
									date = new Date();
									wsProperties.put(endPointProperty
											+ ".LAST_FAILOVER_TS",
											new Timestamp(date.getTime()));
									wsProperties.put(endPointProperty
											+ ".FAILURE_COUNTER", failureCounter++);

								} else {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "");
								}
							}
							throw new YFCException("EXTN_CONNECT");
						} else if (e.getCause() instanceof java.io.IOException
								|| e.getCause() instanceof java.net.SocketTimeoutException) {
							throw new YFCException("EXTN_IO");
						} else if (e.getCause() instanceof javax.xml.soap.SOAPException
								|| e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
							throw new YFCException("SOAP_EXCEPTION");
						} else {
							logger.debug("In Catch");
							retry.errorOccured();
							RETRY_COUNT--;
							if (RETRY_COUNT == 0) {
								logger.debug("In Retry count 0");
								secondaryEndpoint = formURL(this
										.getPropertyValue(endPointProperty
												+ ".BACKUP_ENDPOINT"));
								responseSecondary = this.callEndpoint(request,
										secondaryEndpoint);
								if (!YFCCommon.isVoid(responseSecondary)) {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "BACKUP");
									date = new Date();
									wsProperties.put(endPointProperty
											+ ".LAST_FAILOVER_TS",
											new Timestamp(date.getTime()));
									wsProperties.put(endPointProperty
											+ ".FAILURE_COUNTER", failureCounter++);

								} else {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "");
								}
								throw new YFCException("EXTN_OTHER");
							}
						}
					}
				}

			} else if (wsProperties.get(endPointProperty + ".ACTIVE_ENDPOINT")
					.toString().contains("PRIMARY")) {
				logger.debug("Connecting to Primary");
				while (retry.shouldRetry()) {
					endPoint = formURL(this.getPropertyValue(endPointProperty
							+ ".MONITORED"));
					try {
						response = this.callEndpoint(request, endPoint);
						if (!YFCCommon.isVoid(response)) {
							wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
									"PRIMARY");
							retry.resetRetries();
						}
					} catch (Exception e) {
						e.printStackTrace();
						if (e.getCause() instanceof java.net.ConnectException) {
							logger.debug("In Catch");
							RETRY_COUNT--;
							retry.errorOccured();
							if (RETRY_COUNT == 0) {
								secondaryEndpoint = formURL(this
										.getPropertyValue(endPointProperty
												+ ".BACKUP_ENDPOINT"));
								responseSecondary = this.callEndpoint(request,
										secondaryEndpoint);
								if (!YFCCommon.isVoid(responseSecondary)) {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "BACKUP");
									date = new Date();
									wsProperties.put(endPointProperty
											+ ".LAST_FAILOVER_TS",
											new Timestamp(date.getTime()));
									wsProperties.put(endPointProperty
											+ ".FAILURE_COUNTER", 1);

								} else {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "");
								}
							}
							throw new YFCException("EXTN_CONNECT");
						} else if (e.getCause() instanceof java.io.IOException
								|| e.getCause() instanceof java.net.SocketTimeoutException) {
							throw new YFCException("EXTN_IO");
						} else if (e.getCause() instanceof javax.xml.soap.SOAPException
								|| e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
							throw new YFCException("SOAP_EXCEPTION");
						} else {
							logger.debug("In Catch");
							retry.errorOccured();
							RETRY_COUNT--;
							if (RETRY_COUNT == 0) {
								logger.debug("In Retry count 0");
								secondaryEndpoint = formURL(this
										.getPropertyValue(endPointProperty
												+ ".BACKUP_ENDPOINT"));
								responseSecondary = this.callEndpoint(request,
										secondaryEndpoint);
								if (!YFCCommon.isVoid(responseSecondary)) {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "BACKUP");
									date = new Date();
									wsProperties.put(endPointProperty
											+ ".LAST_FAILOVER_TS",
											new Timestamp(date.getTime()));
									wsProperties.put(endPointProperty
											+ ".FAILURE_COUNTER", 1);

								} else {
									wsProperties.put(endPointProperty
											+ ".ACTIVE_ENDPOINT", "");
								}
								throw new YFCException("EXTN_OTHER");
							}
						}
					}
				}
			} else {
				logger.debug("Connecting to backup");
				while (retry.shouldRetry()) {
					endPoint = formURL(this.getPropertyValue(endPointProperty
							+ ".BACKUP_ENDPOINT"));
					try {
						response = this.callEndpoint(request, endPoint);
					} catch (Exception e) {
						e.printStackTrace();
						if (e.getCause() instanceof java.net.ConnectException) {
							throw new YFCException("EXTN_CONNECT");
						} else if (e.getCause() instanceof java.io.IOException
								|| e.getCause() instanceof java.net.SocketTimeoutException) {
							throw new YFCException("EXTN_IO");
						} else if (e.getCause() instanceof javax.xml.soap.SOAPException
								|| e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
							throw new YFCException("SOAP_EXCEPTION");
						} else {
							throw new YFCException("EXTN_OTHER");
						}
					}
				}
				wsProperties.put(endPointProperty + ".FAILURE_COUNTER",
						failureCounter++);
			}
		} else {
			logger.debug("Active Endpoint is not available in collection");
			logger.debug("Call the Primary end point");
			while (retry.shouldRetry()) {
				endPoint = formURL(this.getPropertyValue(endPointProperty
						+ ".MONITORED"));
				logger.debug("Call the end point");
				try {
					response = this.callEndpoint(request, endPoint);
					if (!YFCCommon.isVoid(response)) {
						wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
								"PRIMARY");
						retry.resetRetries();
					}
				} catch (Exception e) {
					e.printStackTrace();
					if (e.getCause() instanceof java.net.ConnectException) {
						logger.debug("In Catch");
						RETRY_COUNT--;
						retry.errorOccured();
						if (RETRY_COUNT == 0) {
							secondaryEndpoint = formURL(this
									.getPropertyValue(endPointProperty
											+ ".BACKUP_ENDPOINT"));
							responseSecondary = this.callEndpoint(request,
									secondaryEndpoint);
							if (!YFCCommon.isVoid(responseSecondary)) {
								wsProperties.put(endPointProperty
										+ ".ACTIVE_ENDPOINT", "BACKUP");
								date = new Date();
								wsProperties.put(endPointProperty
										+ ".LAST_FAILOVER_TS", new Timestamp(
										date.getTime()));
								wsProperties.put(endPointProperty
										+ ".FAILURE_COUNTER", 1);

							} else {
								wsProperties.put(endPointProperty
										+ ".ACTIVE_ENDPOINT", "");
							}
						}
						throw new YFCException("EXTN_CONNECT");
					} else if (e.getCause() instanceof java.io.IOException
							|| e.getCause() instanceof java.net.SocketTimeoutException) {
						retry.errorOccured();
						throw new YFCException("EXTN_IO");
					} else if (e.getCause() instanceof javax.xml.soap.SOAPException
							|| e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
						throw new YFCException("SOAP_EXCEPTION");
					} else {
						logger.debug("In Catch");
						retry.errorOccured();
						RETRY_COUNT--;
						if (RETRY_COUNT == 0) {
							logger.debug("In Retry count 0");
							secondaryEndpoint = formURL(this
									.getPropertyValue(endPointProperty
											+ ".BACKUP_ENDPOINT"));
							responseSecondary = this.callEndpoint(request,
									secondaryEndpoint);
							if (!YFCCommon.isVoid(responseSecondary)) {
								wsProperties.put(endPointProperty
										+ ".ACTIVE_ENDPOINT", "BACKUP");
								date = new Date();
								wsProperties.put(endPointProperty
										+ ".LAST_FAILOVER_TS", new Timestamp(
										date.getTime()));
								wsProperties.put(endPointProperty
										+ ".FAILURE_COUNTER", 1);

							} else {
								wsProperties.put(endPointProperty
										+ ".ACTIVE_ENDPOINT", "");
							}
							throw new YFCException("EXTN_OTHER");
						}

					}
				}
			}
		}

		logger.debug("Get the SoapBody from the response");
		responseBody = response.getSOAPBody();

		logger.debug("Check whether the response is having any fault in the body");
		if (responseBody.hasFault()) {
			oKohlsWSUtl.logSoapFault(responseBody);
			if (this.getPropertyValue(this.props.getProperty("appName"))
					.compareToIgnoreCase("PAYMENTS") != 0)
				responseBody = oKohlsWSUtl.getFaultformated(responseBody);

		}
		logger.endTimer("InvokeWebService.invokeWS");

		return responseBody.extractContentAsDocument();
	}

	/**
	 * This function is used for calling the endpoint and fetching SOAP Response
	 * from it
	 * 
	 * @param request
	 *            Using which we will call the endpoint
	 * @return SOAPMessage response from the endpoint after the call
	 * @exception Exception
	 *                throws a specific exception depending upon the exception
	 *                arrived
	 */
	public SOAPMessage callEndpoint(SOAPMessage request, URL endPoint)
			throws Exception {

		logger.beginTimer("InvokeWebService.callEndpoint");
		SOAPConnection connection = null;
		SOAPMessage response = null;
		try {
			connection = createSOAPConnection();

			if (logger.isDebugEnabled()) {
				ByteArrayOutputStream req = new ByteArrayOutputStream();
				request.writeTo(req);
				logger.debug("###### Request is ##### : \n"
						+ XMLUtil.getXMLString(XMLUtil.getDocument(req
								.toString())));
				req.flush();
			}

			logger.beginTimer("###### End point URL is ##### : " + endPoint);

			response = connection.call(request, endPoint);

			if (logger.isDebugEnabled()) {
				ByteArrayOutputStream resp = new ByteArrayOutputStream();
				response.writeTo(resp);
				logger.debug("###### response is ##### : \n"
						+ XMLUtil.getXMLString(XMLUtil.getDocument(resp
								.toString())));
				resp.flush();
			}

		} catch (Exception e) {
			e.printStackTrace();

			if (e.getCause() instanceof java.net.ConnectException) {
				throw new YFCException("EXTN_CONNECT");
			} else if (e.getCause() instanceof java.io.IOException
					|| e.getCause() instanceof java.net.SocketTimeoutException) {
				throw new YFCException("EXTN_IO");
			} else if (e.getCause() instanceof javax.xml.soap.SOAPException
					|| e.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
				throw new YFCException("SOAP_EXCEPTION");
			} else {
				throw new YFCException("EXTN_OTHER");
			}
		} finally {
			connection.close();
		}

		logger.endTimer("InvokeWebService.callEndpoint");
		return response;
	}

	/**
	 * This function is used for creating a SOAPConnection
	 * 
	 * @return SOAPConnection connection
	 */
	public SOAPConnection createSOAPConnection() {
		logger.beginTimer("InvokeWebService.createSOAPConnection");
		// System.setProperty("javax.xml.soap.SOAPConnectionFactory","com.sun.xml.messaging.saaj.client.p2pl.HttpSOAPConnectionFactory");

		SOAPConnection connection = null;
		HttpSOAPConnectionFactory factoryInst = new HttpSOAPConnectionFactory();

		try {
			logger.debug("Creating Soap Connection");
			connection = factoryInst.createConnection();

		} catch (Exception e) {
			logger.debug("SOAPException in the creation of SOAPConnection");
			throw new YFCException((Exception) e.getCause());
		}
		logger.endTimer("InvokeWebService.createSOAPConnection");
		return connection;
	}

	/**
	 * Sets the properties
	 * 
	 * @param prop
	 *            Properties that need to be set
	 * @throws Exception
	 *             when unable to set the Property
	 */

	public void setProperties(Properties prop) throws Exception {
		this.props = prop;
		logger.debug("In the set properties method");

	}

	/**
	 * This function is used to get the value for a property
	 * 
	 * @param property
	 *            name in string format
	 * @return String propValue
	 */
	public String getPropertyValue(String property) {
		String propValue;
		propValue = YFSSystem.getProperty(property);
		// Manoj 10/22: updated to use configured property if
		// customer_overrides.properties does not return any value
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		logger.debug("Property Name" + property);
		logger.debug("Property Value" + propValue);
		return propValue;

	}

	/**
	 * Loads all the properties from customer_overrides.properties into the
	 * collection
	 * 
	 * @return Properties
	 * @throws IOException
	 */
	public Map<String, Object> loadPropValues(String endPointProperty)
			throws IOException {
		logger.debug("Inside loadPropValues");
		wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT", null);
		wsProperties.put(endPointProperty + ".FAILURE_COUNTER", 0);
		wsProperties.put(endPointProperty + ".LAST_FAILOVER_TS", null);
		return wsProperties;
	}

	/**
	 * Create URL
	 * 
	 * @return URL
	 * @throws IOException
	 */
	public URL formURL(String endPoint) throws IOException {
		logger.debug("Create the URL");
		URL urlToConnect = new URL(null, endPoint, new URLStreamHandler() {
			@Override
			protected URLConnection openConnection(URL url) throws IOException {
				URL clone_url = new URL(url.toString());
				HttpURLConnection clone_urlconnection = (HttpURLConnection) clone_url
						.openConnection();
				// TimeOut settings
				clone_urlconnection.setConnectTimeout(Integer
						.parseInt(getPropertyValue(props.getProperty("timeOut"))));
				clone_urlconnection.setReadTimeout(Integer
						.parseInt(getPropertyValue(props.getProperty("timeOut"))));
				return (clone_urlconnection);
			}
		});
		return urlToConnect;
	}

	private boolean compareTimestamp(String endPointProperty) {
		Date date = new Date();
		long time = date.getTime();
		long timeLapseThreshold = Long.parseLong(this
				.getPropertyValue(endPointProperty
						+ "FAILOVER_TIMELAPSE_THRESHOLD"));
		Timestamp currentTime = new Timestamp(time);
		Timestamp lastFailoverTs = Timestamp.valueOf(wsProperties.get(
				endPointProperty + ".LAST_FAILOVER_TS").toString());
		if ((currentTime.getTime() - lastFailoverTs.getTime()) > timeLapseThreshold) {
			return true;
		}
		return false;
	}

	public static class RetryOnExceptionStrategy {

		private int numberOfTriesLeft;
		private long timeToWait;

		public RetryOnExceptionStrategy(int numberOfRetries, long timeToWait) {
			numberOfTriesLeft = numberOfRetries;
			this.timeToWait = timeToWait;
			RETRY_COUNT = numberOfTriesLeft;
			System.out.println("InumberOfRetries On Initial"+numberOfRetries);
		}

		/**
		 * @return true if there are tries left
		 */
		public boolean shouldRetry() {
			System.out.println("Inside ShouldRetry");
			return numberOfTriesLeft > 0;
		}

		public void errorOccured() throws Exception {
			numberOfTriesLeft--;
			waitUntilNextTry();
		}
		
		public void resetRetries() throws Exception {
			numberOfTriesLeft = 0;
		}

		public long getTimeToWait() {
			return timeToWait;
		}

		private void waitUntilNextTry() {
			try {
				Thread.sleep(getTimeToWait());
			} catch (InterruptedException ignored) {
			}
		}
	}
}
