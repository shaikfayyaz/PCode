package com.kohls.util.webserviceUtil;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSException;

public class FailoverUtil implements YIFCustomApi {

    private static YFCLogCategory logger = YFCLogCategory
            .instance(InvokeWebService.class);
    static private Properties props;
    private Map<String, Object> wsProperties;
    private static FailoverUtil instance = null;


    /**
     * @return the wsProperties
     */
    public Map<String, Object> getWsProperties() {
      return wsProperties;
    }

    
    
    public FailoverUtil() {
      if (wsProperties == null || wsProperties.isEmpty()) {
        wsProperties = Collections.synchronizedMap(new HashMap<String, Object>());
        try {
          logger.debug("Initialising HashMap with default values" + wsProperties);
          loadPropValues();
        } catch (IOException ex) {
          logger.error("Error in loading hashmap");
        }
      }
    }
    
    public static synchronized FailoverUtil getInstance() {
      if (null == instance) {
          instance = new FailoverUtil();
       }
       return instance;
    }

    /**
     * Sets the properties
     * 
     * @param prop
     *            Properties that need to be set
     * @throws Exception
     *             when unable to set the Property
     */

    public void setProperties(Properties prop) throws Exception {
        logger.debug("Inside setProperties method");
        this.props = prop;
    }

    /**
     * This function is used to get the value for a property
     * 
     * @param property
     *            name in string format
     * @return String propValue
     */
    public static String getPropertyValue(String property) {
        logger.debug("Inside getPropertyValue method");
        String propValue;
        propValue = YFSSystem.getProperty(property);
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        return propValue;

    }

    /**
     * Loads the monitored URL properties from customer_overrides.properties
     * into the collection
     * 
     * @return Properties
     * @throws IOException
     */
    public Map<String, Object> loadPropValues() throws IOException {
        logger.debug("Inside LoadPropValues");
        props = loadCOPValues();
        String endPointProperty;
        Set<Object> keys = getAllKeys();
        Date date = new Date();
        long time;
        Timestamp currentTime;
        for (Object k : keys) {
            if (((String) k).contains(".MONITORED")) {           		
                endPointProperty = ((String) k).substring(0,
                        ((String) k).indexOf(".MONITORED"));
                logger.debug("EndPointProperty ::" + endPointProperty);
                time = date.getTime();
                currentTime = new Timestamp(time);
                // Initialize the collection
                wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
                        "PRIMARY");
                String failoverRecoveryThreshold = props.getProperty(endPointProperty+".FAILOVER_RECOVERY_THRESHOLD");
                if(!YFCCommon.isVoid(failoverRecoveryThreshold))
                	{
                	 	wsProperties.put(endPointProperty + ".FAILOVER_RECOVERY_COUNTER", 0);
                	}
                else
                {
                	 	wsProperties.put(endPointProperty + ".RECOVERY_COUNTER", 0);
                }
                String offlineRecoveryThreshold = props.getProperty(endPointProperty+".OFFLINE_RECOVERY_THRESHOLD");
                if(!YFCCommon.isVoid(offlineRecoveryThreshold))
                	{
                	 	wsProperties.put(endPointProperty + ".OFFLINE_RECOVERY_COUNTER", 0);
                	}               
                wsProperties.put(endPointProperty + ".PRIMARY_FAILED_COUNTER",
                        0);
                wsProperties
                        .put(endPointProperty + ".BACKUP_FAILED_COUNTER", 0);
                wsProperties.put(endPointProperty + ".LAST_FAILOVER_TS",
                        currentTime);                
            }           
        }
        return wsProperties;
    }

    /**
     * Gets all the keys from Properties
     * 
     * @return Set
     */
    public static Set<Object> getAllKeys() {
        Set<Object> keys = props.keySet();
        return keys;
    }

    /**
     * This method checks if the Failover_timelapse_threshold configured has
     * elapsed or not
     * 
     * @return boolean
     */
    private boolean compareTimestamp(String endPointProperty) {
        logger.debug("Inside compareTimestamp");
        Date date = new Date();
        long time = date.getTime();
        String currentActiveEndPoint = getCurrentActiveEndpoint(endPointProperty);
        long timeLapseThreshold = 0;
        if("BACKUP".equalsIgnoreCase(currentActiveEndPoint) || YFCCommon.isVoid(YFSSystem.getProperty(endPointProperty
                + ".OFFLINE_TIMELAPSE_THRESHOLD")))
        {
        		 timeLapseThreshold = Long.parseLong(getPropertyValue(endPointProperty
                    + ".FAILOVER_TIMELAPSE_THRESHOLD"));
        }
        else
        {
        		 timeLapseThreshold = Long.parseLong(getPropertyValue(endPointProperty
                    + ".OFFLINE_TIMELAPSE_THRESHOLD"));
        } 
        logger.debug("timeLapseThreshold:::"+timeLapseThreshold);
        Timestamp currentTime = new Timestamp(time);
        Timestamp lastFailoverTs = Timestamp.valueOf(wsProperties.get(
                endPointProperty + ".LAST_FAILOVER_TS").toString());
        logger.debug("currentTime:::"+currentTime.getTime());
        logger.debug("lastFailoverTs:::"+lastFailoverTs.getTime());
        if ((currentTime.getTime() - lastFailoverTs.getTime()) > timeLapseThreshold) {
            return true;
        }
        return false;
    }

    /**
     * Loads all the properties from customer_overrides.properties into
     * properties object
     * 
     * @return Properties
     * @throws IOException
     */
    public static Properties loadCOPValues() throws IOException {
        logger.debug("Load props from cop file");
        Properties props1 = new Properties();
        props1 = YFSSystem.getProperties();
        return props1;
    }

	/**
	 * This method returns the endpoint to call and also checks if the threshold
	 * is crossed
	 * 
	 * @return String
	 */
	public String getEndPointToCall(String endPointProperty) {
		logger.debug("Inside getEndPointToCall");
		String endPointToCall = "PRIMARY";
		int recoveryThresholdProp = 0;
		int recoveryCounter = 0;
		String endPointInCollection = wsProperties.get(
				endPointProperty + ".ACTIVE_ENDPOINT").toString();
		
		if(endPointInCollection.contains("BACKUP"))
		{
			if(wsProperties.containsKey(endPointProperty
					+ ".FAILOVER_RECOVERY_COUNTER"))
			{
				recoveryCounter = (Integer) wsProperties.get(endPointProperty
						+ ".FAILOVER_RECOVERY_COUNTER");
				recoveryThresholdProp = Integer.parseInt(getPropertyValue(endPointProperty + ".FAILOVER_RECOVERY_THRESHOLD"));
			}	
			else
			{
				recoveryCounter = (Integer) wsProperties.get(endPointProperty
						+ ".RECOVERY_COUNTER");
				recoveryThresholdProp = Integer.parseInt(getPropertyValue(endPointProperty + ".RECOVERY_THRESHOLD"));
			}
		}
		if(endPointInCollection.contains("OFFLINE"))
		{
			if(wsProperties.containsKey(endPointProperty
					+ ".OFFLINE_RECOVERY_COUNTER"))
			{
				recoveryCounter = (Integer) wsProperties.get(endPointProperty
						+ ".OFFLINE_RECOVERY_COUNTER");
				recoveryThresholdProp = Integer.parseInt(getPropertyValue(endPointProperty + ".OFFLINE_RECOVERY_THRESHOLD"));
			}
			else
			{
				recoveryCounter = (Integer) wsProperties.get(endPointProperty
						+ ".RECOVERY_COUNTER");
				recoveryThresholdProp = Integer.parseInt(getPropertyValue(endPointProperty + ".RECOVERY_THRESHOLD"));
			}
			
		}
		
		if (endPointInCollection.contains("PRIMARY")){
			logger.debug("Primary Active...Connecting to Primary");
			endPointToCall = "PRIMARY";
		} else if ((endPointInCollection.contains("BACKUP") || endPointInCollection
				.contains("OFFLINE"))
				&& ((recoveryCounter >= recoveryThresholdProp) || compareTimestamp(endPointProperty))) {
			if((recoveryCounter >= recoveryThresholdProp))
			{
				logger.error("Failure Threshold counter elapsed..Connecting to Primary");
			}
			else
			{
				logger.error("Failure Threshold time elapsed..Connecting to Primary");
			}
			endPointToCall = "PRIMARY";
			wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT", "PRIMARY");
			wsProperties.put(endPointProperty + ".RECOVERY_COUNTER", 0);
			if(wsProperties.containsKey(endPointProperty
					+ ".FAILOVER_RECOVERY_COUNTER"))
			{
				wsProperties.put(endPointProperty + ".FAILOVER_RECOVERY_COUNTER", 0);
			}
			if(wsProperties.containsKey(endPointProperty
					+ ".OFFLINE_RECOVERY_COUNTER"))
			{
				wsProperties.put(endPointProperty + ".OFFLINE_RECOVERY_COUNTER", 0);
			}
			logger.error("Failover back for " + endPointProperty
					+ " from " + endPointInCollection + " to PRIMARY ");
			wsProperties.put(endPointProperty + ".BACKUP_FAILED_COUNTER", 0);
		} else if (endPointInCollection.contains("BACKUP")) {
			logger.error("Primary down. Connecting to backup");
			endPointToCall = "BACKUP";
			recoveryCounter++;
			if(wsProperties.containsKey(endPointProperty
					+ ".FAILOVER_RECOVERY_COUNTER"))
			{
				wsProperties.put(endPointProperty + ".FAILOVER_RECOVERY_COUNTER",
						recoveryCounter);
			}
			else
			{
				wsProperties.put(endPointProperty + ".RECOVERY_COUNTER",
						recoveryCounter);
			}			
		} else if (endPointInCollection.contains("OFFLINE")) {
			logger.error("Primary and Backup down. Connecting to Offline");
			endPointToCall = "OFFLINE";
			recoveryCounter++;
			if(wsProperties.containsKey(endPointProperty
					+ ".OFFLINE_RECOVERY_COUNTER"))
			{
				wsProperties.put(endPointProperty + ".OFFLINE_RECOVERY_COUNTER",
						recoveryCounter);
			}
			else
			{
				wsProperties.put(endPointProperty + ".RECOVERY_COUNTER",
						recoveryCounter);
			}
		} 
		return endPointToCall;
    }

    /**
     * This method resets the failed counter values in the hashmap to zero
     * 
     * @return Void
     */
    public void resetFailedCounter(String endPointProperty, String endPoint) {
        logger.debug("Inside resetFailedCounter");
        logger.debug("Response received from " + endPoint + ". Hence, resetting the failed counter");
        if (endPoint.equalsIgnoreCase("PRIMARY")) {
          wsProperties.put(endPointProperty + ".PRIMARY_FAILED_COUNTER", 0);
        } else if (endPoint.equalsIgnoreCase("BACKUP")) {
          wsProperties.put(endPointProperty + ".BACKUP_FAILED_COUNTER", 0);
        }
    }

    /**
     * This method increments the failed counter values in the hashmap
     * 
     * @return Void
     */
    public void incrementFailedCounter(String endPointProperty, String endPoint) {
        logger.debug("Inside incrementFailedCounter");
        logger.debug("No Response/Timeout from " + endPoint +". Hence, increasing the failed counter");
        int failedCounter = 0;
        if (endPoint.equalsIgnoreCase("PRIMARY") && "PRIMARY".equalsIgnoreCase(getCurrentActiveEndpoint(endPointProperty))) {
            failedCounter = (Integer) wsProperties.get(endPointProperty
                    + ".PRIMARY_FAILED_COUNTER");
            failedCounter++;
            wsProperties.put(endPointProperty + ".PRIMARY_FAILED_COUNTER",
                    failedCounter);
        } else if (endPoint.equalsIgnoreCase("BACKUP") && "BACKUP".equalsIgnoreCase(getCurrentActiveEndpoint(endPointProperty))) {
            failedCounter = (Integer) wsProperties.get(endPointProperty
                    + ".BACKUP_FAILED_COUNTER");
            failedCounter++;
            wsProperties.put(endPointProperty + ".BACKUP_FAILED_COUNTER",
                    failedCounter);
        }
    }

	/**
	 * This method compares the Primary/Backup failed counters along with the
	 * values configured in COP
	 * 
	 * @return void
	 */
	public void compareFailedThreshold(String endPointProperty, String endPoint, boolean isBackupURLPresent) {
		logger.debug("Inside compareFailedThreshold");
		logger.debug("Compare Threshold for endPoint :" + endPoint);
		int failedCounter = 0;
		int failedCounterProp = 0;
		int recoveryCounter = 0;
		
		String endPointInCollection = wsProperties.get(
				endPointProperty + ".ACTIVE_ENDPOINT").toString();
		
		Date date = new Date();
		if (endPoint.equalsIgnoreCase("PRIMARY") && "PRIMARY".equalsIgnoreCase(endPointInCollection)) {
			
			if(wsProperties.containsKey(endPointProperty
					+ ".FAILOVER_RECOVERY_COUNTER"))
			{
				recoveryCounter = (Integer) wsProperties.get(endPointProperty
						+ ".FAILOVER_RECOVERY_COUNTER");
			}
			else
			{
				recoveryCounter = (Integer) wsProperties.get(endPointProperty
						+ ".RECOVERY_COUNTER");
			}
			failedCounter = (Integer) wsProperties.get(endPointProperty
					+ ".PRIMARY_FAILED_COUNTER");
			failedCounterProp = Integer.parseInt(getPropertyValue(endPointProperty
							+ ".PRIMARY_RETRY_THRESHOLD"));
			if (failedCounter > failedCounterProp) {
				if(isBackupURLPresent){
				  wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
							"BACKUP");
					logger.error("Failover for " + endPointProperty
							+ " from " + endPoint + " - " + getPrimaryEndpoint(endPointProperty) + " to BACKUP" + " - " + getBackupEndpoint(endPointProperty));
				}
				else{
				  wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
							"OFFLINE");
					logger.error("Failover for " + endPointProperty
							+ " from " + endPoint + " - " + getPrimaryEndpoint(endPointProperty) + " to OFFLINE ");
				}
				wsProperties.put(endPointProperty + ".PRIMARY_FAILED_COUNTER",
						0);
				wsProperties.put(endPointProperty + ".LAST_FAILOVER_TS",
						new Timestamp(date.getTime()));
				recoveryCounter++;
				if(wsProperties.containsKey(endPointProperty
						+ ".FAILOVER_RECOVERY_COUNTER"))
				{
					wsProperties.put(endPointProperty + ".FAILOVER_RECOVERY_COUNTER",
							recoveryCounter);
				}
				else
				{
					
					wsProperties.put(endPointProperty + ".RECOVERY_COUNTER",
							recoveryCounter);
				}
				
				
			}
		} else if (endPoint.equalsIgnoreCase("BACKUP") && "BACKUP".equalsIgnoreCase(endPointInCollection)) {
			failedCounter = (Integer) wsProperties.get(endPointProperty
					+ ".BACKUP_FAILED_COUNTER");
			failedCounterProp = Integer.parseInt(getPropertyValue(endPointProperty
							+ ".BACKUP_RETRY_THRESHOLD"));
			if (failedCounter > failedCounterProp) {
			  wsProperties.put(endPointProperty + ".ACTIVE_ENDPOINT",
						"OFFLINE");
				logger.error("Failover for " + endPointProperty
						+ " from " + endPoint + " - " + getBackupEndpoint(endPointProperty) + " to OFFLINE ");
				recoveryCounter++;
				if(wsProperties.containsKey(endPointProperty
						+ ".FAILOVER_RECOVERY_COUNTER"))
				{
					wsProperties.put(endPointProperty + ".FAILOVER_RECOVERY_COUNTER",
							0);
					wsProperties.put(endPointProperty + ".OFFLINE_RECOVERY_COUNTER",
							recoveryCounter);
				}
				else
				{
					
					wsProperties.put(endPointProperty + ".RECOVERY_COUNTER",
							recoveryCounter);
				}
				wsProperties
						.put(endPointProperty + ".BACKUP_FAILED_COUNTER", 0);
				wsProperties.put(endPointProperty + ".LAST_FAILOVER_TS",
						new Timestamp(date.getTime()));
			}
		}
	}
	
	 /**
     * This method will be used to determine the Endpoint
     * that needs to used for this call.
     * This will use flag to determine if it is primary and uses FailoverUtil
     * to check JRE map values
     * @param endPointProperty
     * @param activeEndPoint
     * @return
     */
    public String getActiveEndPoint(String endPointProperty) {
        logger.beginTimer("FailoverUtil.getActiveEndPoint");
        String activeEndPoint = "";
        String propertValue = "";
        if (isEndpointMonitored(endPointProperty)) {
        		activeEndPoint	= getEndPointToCall(endPointProperty);
            if (!"BACKUP".equalsIgnoreCase(activeEndPoint)) {            
                if (activeEndPoint.contains(KohlsPOCConstant.STRING_PRIMARY)) {
                  propertValue = getPrimaryEndpoint(endPointProperty);
                } else if (activeEndPoint.contains(KohlsPOCConstant.STRING_BACKUP)) {
                  propertValue = getBackupEndpoint(endPointProperty);
                } else if (activeEndPoint.contains("OFFLINE")) {
	               /** 	if(wsProperties.containsKey(endPointProperty
	    						+ ".OFFLINE_RECOVERY_COUNTER"))
	    				{
	                		int recoveryCounter = (Integer) wsProperties.get(endPointProperty
	        						+ ".OFFLINE_RECOVERY_COUNTER");
	                		recoveryCounter++;
	    					wsProperties.put(endPointProperty + ".OFFLINE_RECOVERY_COUNTER",
	    							recoveryCounter);
	    				} **/
                    throw new YFSException("EXTN_OTHER-OFFLINE",
                            KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER);
                }
            } else {
                String backupURL = getBackupEndpoint(endPointProperty);
                if (!YFCCommon.isVoid(backupURL)) {
                  propertValue = backupURL;
                } else {
                    throw new YFSException("EXTN_OTHER-OFFLINE",
                            KohlsPOCConstant.STRING_EXTN_OTHER,KohlsPOCConstant.STRING_EXTN_OTHER);
                }
            }
         
        } else {
          propertValue = getPropertyValue(endPointProperty);
        }
        
        logger.info("The current active endpoint / domain for "+ endPointProperty +" is: "
            + activeEndPoint+" and value is: "+propertValue);
        
        logger.endTimer("FailoverUtil.getActiveEndPoint");
        return propertValue;
    }
    /**
     * checks whether property is monitored or not
     * 
     * @return isMonitored
     */
    public boolean isEndpointMonitored(String endPointProperty) {
        logger.beginTimer("FailoverUtil.isEndpointMonitored");
        boolean isMonitored = false;
        if(wsProperties.containsKey(endPointProperty+".ACTIVE_ENDPOINT")) {
          isMonitored = true;
        }
        logger.endTimer("FailoverUtil.isEndpointMonitored");
        return isMonitored;
    }
    
    /**
     * Create By ibmadmin * 
     * @param endPointProperty
     * @return
     */
    public String getPrimaryEndpoint (String endPointProperty) {
      logger.beginTimer("FailoverUtil.getPrimaryEndpoint");
      String endpointValue = getPropertyValue(endPointProperty + KohlsPOCConstant.STRING_DOT_MONITORED);
      logger.endTimer("FailoverUtil.getPrimaryEndpoint");
      return endpointValue;
    }
    
    /**
     * Create By ibmadmin * 
     * @param endPointProperty
     * @return
     */
    public String getBackupEndpoint (String endPointProperty) {
      logger.beginTimer("FailoverUtil.getBackupEndpoint");
      String endpointValue = getPropertyValue(endPointProperty + KohlsPOCConstant.STRING_DOT_BACKUP_ENDPOINT);
      logger.endTimer("FailoverUtil.getBackupEndpoint");
      return endpointValue;
    }
    
    /**
     * Create By ibmadmin * 
     * @param endPointProperty
     * @return
     */
    public String getCurrentActiveEndpoint (String endPointProperty) {
      logger.beginTimer("FailoverUtil.getCurrentActiveEndpoint");
      String activeEndpoint = (String) wsProperties.get(endPointProperty + ".ACTIVE_ENDPOINT");
      logger.endTimer("FailoverUtil.getCurrentActiveEndpoint");
      return activeEndpoint;
    }
    
    // PST-6766
    /** 
     * Calling using implicit this currentActiveEndpoint
     * @param endPointProperty
     * @return
     */
    public void compareAndIncrementCounters (String endPointProperty) {
        this.compareAndIncrementCounters(endPointProperty, this.getCurrentActiveEndpoint(endPointProperty));
    }

    /**
     * Create By ibmadmin * 
     * @param endPointProperty
     */
    public void compareAndIncrementCounters (String endPointProperty, String currentActiveEndpoint) {
      logger.beginTimer("FailoverUtil.compareAndIncrementCounters");
      boolean isEndpointMonitored = isEndpointMonitored(endPointProperty);
      if(isEndpointMonitored) {
        boolean isBackupURLPresent = false;
        if(!YFCCommon.isVoid(getBackupEndpoint(endPointProperty))) {
          isBackupURLPresent = true;
        }
        if(YFCCommon.isVoid(currentActiveEndpoint)) {
          currentActiveEndpoint = getCurrentActiveEndpoint(endPointProperty);
        }
        incrementFailedCounter(endPointProperty, currentActiveEndpoint);
        compareFailedThreshold(endPointProperty, currentActiveEndpoint, isBackupURLPresent);
      }
      logger.endTimer("FailoverUtil.compareAndIncrementCounters");
    }
    
    /**
     * Create By mrjoshi * 
     * @param name
     * @return
     */
    public String getPropertyValueFromMap(String propertyName) {
      logger.beginTimer("FailoverUtil.getPropertyValueFromMap");
      String value = (String) wsProperties.get(propertyName);
      logger.endTimer("FailoverUtil.getPropertyValueFromMap");
      return wsProperties.toString();
    }
    
    /**
     * Create By mrjoshi * 
     * @param name
     * @return
     */
    public void managePropertyValueInMap(String propertyName, String propertyValue) {
      logger.beginTimer("FailoverUtil.managePropertyValueInMap");
      wsProperties.put(propertyName, propertyValue);
      logger.endTimer("FailoverUtil.managePropertyValueInMap");
    }
    
}
