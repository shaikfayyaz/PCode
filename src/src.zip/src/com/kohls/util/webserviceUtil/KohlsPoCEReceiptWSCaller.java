package com.kohls.util.webserviceUtil;

import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.messaging.v1_0.header.MessageHeaderCreator;
import com.kohls.messaging.v1_0.header.MessageHeaderException;
import com.kohls.messaging.v1_0.header.MessageSenderNodeInfo;
import com.kohls.messaging.v1_0.header.jaxb.MessageHeader;
import com.kohls.messaging.v1_0.header.util.SoapMessageUtil;
import com.sun.xml.messaging.saaj.client.p2p.HttpSOAPConnectionFactory;
import com.sun.xml.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import org.w3c.dom.CDATASection;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;

import javax.xml.namespace.QName;
import javax.xml.soap.*;
import javax.xml.ws.soap.SOAPFaultException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.util.Properties;

/**************************************************************************
 * File : KohlsPoc WebServiceCaller.java Author : IBM Created : June 6
 * 2013 Modified : July 27 2013 Version : 0.2
 *****************************************************************************
 * HISTORY
 *****************************************************************************
 * V0.1 12/07/2013 IBM First Cut.
 * ***************************************************************************
 * Copyright @ 2013. This document has been prepared and written by IBM Global
 * Services on behalf of Kohls, and is copyright of Kohls
 *
 *****************************************************************************
 *****************************************************************************
 * This file is a webservice client that invokes the webservice end point and
 * processes the response
 *
 * @author IBM
 * @version 0.2
 *****************************************************************************/
public class KohlsPoCEReceiptWSCaller implements YIFCustomApi {
    private final YFCLogCategory LOG_CAT = YFCLogCategory.instance(KohlsPoCEReceiptWSCaller.class);
    public static final String CC_NAMESPACE = "http://webservice.services.cc.ch.kohls.com";
    private Properties props;

    /**
     * Default Constructor class
     *
     * @throws Exception if anything goes wrong
     */
    public KohlsPoCEReceiptWSCaller() throws Exception {
        super();
    }


    /**
     * This function
     * 1.Prepares the SOAP Request
     * 2.Invokes the webservice endpoint
     * 3.Returns the SOAP response as a Document
     *
     * @param env        environment variable
     * @param requestDoc request Document
     * @return Document
     * @throws Exception to handle any abnormal behavior
     */
    public Document invokeWS(YFSEnvironment env, Document requestDoc)
            throws Exception {

        this.LOG_CAT.debug("in call method of webservice JAVA");

        this.LOG_CAT.debug("call to createSoapMessage");
        SOAPMessage request = this.createCCSSoapRequest(requestDoc);

        this.LOG_CAT.debug("call to add Header to the SoapMessage");
        this.addHeader(request);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        request.writeTo(out);
        String strMsg = out.toString();

        LOG_CAT.verbose("input value" + strMsg);
        SOAPMessage response = this.callEndpoint(request);

        this.LOG_CAT.debug("Get the SoapBody from the response");
        SOAPBody responseBody = response.getSOAPBody();

        this.LOG_CAT.debug("Check whether the response is having any fault in the body");
        if (responseBody.hasFault()) {
            SOAPFaultException fe = new SOAPFaultException(responseBody.getFault());
            this.LOG_CAT.error("Fault occurred while sending EReceipt.", fe);
            throw fe;
        }

        this.LOG_CAT.debug("return the soap body");
        return responseBody.extractContentAsDocument();
    }


    /**
     * This method handles all soap fault message body
     *
     * @param responseBody which contain SAOPFault
     * @return SOAPBody in well formated manner
     * @throws Exception to handle any abnormal behavior
     */

    public SOAPBody getFaultformated(SOAPBody responseBody) throws Exception {

        String code = null;
        String msg = null;

        String faultcode = responseBody.getFault().getFaultCode();
        String faultstring = responseBody.getFault().getFaultString();

        if (YFCCommon.isVoid(faultcode)) {
            faultcode = "INCORRECT_SOAP_REQUEST";
            faultstring = "INCORRECT_SOAP";
        }

        Detail soapDetail = responseBody.getFault().getDetail();

        if (!YFCCommon.isVoid(soapDetail)) {
            code = XPathUtil.getString(soapDetail, "code");
            msg = XPathUtil.getString(soapDetail, "message");
        }

        if (YFCCommon.isVoid(code)) {
            code = faultstring;
        }

        if (YFCCommon.isVoid(msg)) {
            msg = "Undetermined error description";
        }

        System.setProperty("javax.xml.soap.MessageFactory", "com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");

        MessageFactory mf = MessageFactory.newInstance();
        SOAPMessage faultresponse = mf.createMessage();
        SOAPPart soapPart = faultresponse.getSOAPPart();

        SOAPEnvelope env = soapPart.getEnvelope();
        SOAPBody soapBody = env.getBody();
        SOAPFault fault = soapBody.getFault();
        fault.setFaultCode(faultcode);
        fault.setFaultString(faultstring);

        Detail myDetail = fault.addDetail();
        QName entryName = new QName("code");
        DetailEntry entry = myDetail.addDetailEntry(entryName);
        entry.addTextNode(code);

        QName entryName2 = new QName("message");
        DetailEntry entry2 = myDetail.addDetailEntry(entryName2);
        entry2.addTextNode(msg);

        return faultresponse.getSOAPBody();
    }

    /**
     * This function is used for creating a SOAPRequest with requestDoc added to the SOAPBody
     *
     * @param requestDoc Input Document using which we need to prepare a SOAPMessage.
     * @return SOAPMessage
     * @throws Exception
     * @throws DOMException
     */
    public SOAPMessage createSoapRequest(Document requestDoc)
            throws DOMException, Exception {
        this.LOG_CAT.debug("In createSoapMessage method in the webservice");

        String emailID = requestDoc.getDocumentElement().getAttribute("Email");
        String emailContent = requestDoc.getDocumentElement().getAttribute("ReceiptData");
        System.setProperty("javax.xml.soap.MessageFactory", "com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");

        MessageFactory mf = SOAPMessageFactory1_2Impl.newInstance();
        SOAPMessage request = mf.createMessage();
        SOAPPart soapPart = request.getSOAPPart();
        SOAPEnvelope env = soapPart.getEnvelope();
        SOAPBody soapBody = env.getBody();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        request.writeTo(out);
        String strMsg = new String(out.toByteArray());
        LOG_CAT.verbose("Output is:" + strMsg);

        QName rootEle = new QName("http://tempuri.org/emailEReceipt/definitions", "emailEReceipt", "def");
        SOAPBodyElement s1 = soapBody.addBodyElement(rootEle);
        s1.addNamespaceDeclaration("ema", "http://www.kohls.com/xs/co/1.0/EMail");

        QName argEle = new QName("arg0");
        SOAPElement s2 = s1.addChildElement(argEle);

        QName messageEle = new QName("http://www.kohls.com/xs/co/1.0/EMail", "MessageId", "ema");
        SOAPElement s3 = s2.addChildElement(messageEle);
        s3.setTextContent("EReceipt");

        QName toAddEle = new QName("http://www.kohls.com/xs/co/1.0/EMail", "ToAddresses", "ema");
        SOAPElement s4 = s2.addChildElement(toAddEle);

        QName toEle = new QName("http://www.kohls.com/xs/co/1.0/EMail", "To", "ema");
        SOAPElement s5 = s4.addChildElement(toEle);
        s5.setTextContent(emailID);

        QName parsEle = new QName("http://www.kohls.com/xs/co/1.0/EMail", "Parameters", "ema");
        SOAPElement s6 = s2.addChildElement(parsEle);
        s6.setPrefix("ema");

        QName parEle = new QName("http://www.kohls.com/xs/co/1.0/EMail", "Parameter", "ema");
        QName attrParam = new QName("Name");
        SOAPElement s7 = s6.addChildElement(parEle);
        s7.addAttribute(env.createName("Name"), "API_BODY");

        CDATASection cdata = soapPart.createCDATASection(emailContent);
        s7.appendChild(cdata);

        SOAPElement dumele = s7.addAttribute(attrParam, "API_BODY");

        ByteArrayOutputStream out1 = new ByteArrayOutputStream();
        request.writeTo(out1);

        String strMsg1 = new String(out1.toByteArray());
        LOG_CAT.verbose("Output is:" + strMsg1);
        return request;
    }

    public SOAPMessage createCCSSoapRequest(Document requestDoc) throws SOAPException, IOException {
        this.LOG_CAT.debug("In createSoapMessage method in the webservice");

        String emailID = requestDoc.getDocumentElement().getAttribute("Email");
        String emailContent = requestDoc.getDocumentElement().getAttribute("ReceiptData");
        emailContent = "<![CDATA[" + emailContent + "]]>";
        System.setProperty("javax.xml.soap.SOAPFactory", "org.apache.axis2.saaj.SOAPFactoryImpl");
        System.setProperty("javax.xml.soap.SOAPConnectionFactory", "org.apache.axis2.saaj.SOAPConnectionFactoryImpl");
        System.setProperty("javax.xml.soap.MessageFactory", "weblogic.xml.saaj.MessageFactoryImpl");
        MessageFactory mf = MessageFactory.newInstance();
        SOAPMessage request = mf.createMessage();
        SOAPPart soapPart = request.getSOAPPart();
        SOAPEnvelope env = soapPart.getEnvelope();
        SOAPBody soapBody = env.getBody();
        request.getMimeHeaders().addHeader("SOAPAction", "Receipt");
        request.getMimeHeaders().addHeader("Content-Type", "text/html");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        request.writeTo(out);
        String strMsg = new String(out.toByteArray());
        LOG_CAT.verbose("Output is:" + strMsg);

        QName rootEle = new QName("http://com/kohls/ch/cc/services/webservice/notification/receipt", "ReceiptRequest", "ns28");
        SOAPBodyElement s1 = soapBody.addBodyElement(rootEle);
        QName triggerCampaignMessageEle = new QName("http://com/kohls/ch/cc/services/webservice/notification/receipt", "triggerCampaignMessage", "ns28");
        SOAPElement sTriggerMessage = s1.addChildElement(triggerCampaignMessageEle);
        QName qncampaign = new QName(CC_NAMESPACE, "campaign");

        SOAPElement soapCampaign = sTriggerMessage.addChildElement(qncampaign);
        SOAPElement sFolderName = soapCampaign.addChildElement(new QName(CC_NAMESPACE, "folderName"));
        sFolderName.setValue("EReceipt");
        soapCampaign.addChildElement(new QName(CC_NAMESPACE, "objectName")).setValue("EReceipt");
        QName qnrecipientData = new QName(CC_NAMESPACE, "recipientData");
        SOAPElement soaprecipientData = sTriggerMessage.addChildElement(qnrecipientData);

        SOAPElement soapReceiptient = soaprecipientData.addChildElement(new QName(CC_NAMESPACE, "recipient"));
        SOAPElement soapListName = soapReceiptient.addChildElement(new QName(CC_NAMESPACE, "listName"));
        soapListName.addChildElement(new QName(CC_NAMESPACE, "folderName")).setValue("!MasterData");
        soapListName.addChildElement(new QName(CC_NAMESPACE, "objectName")).setValue("CONTACTS_LIST");
        soapReceiptient.addChildElement(new QName(CC_NAMESPACE, "emailAddress")).setValue(emailID);
        soapReceiptient.addChildElement(new QName(CC_NAMESPACE, "emailFormat"));

        SOAPElement soapoptionalData = soaprecipientData.addChildElement(new QName(CC_NAMESPACE, "optionalData"));
        soapoptionalData.addChildElement(new QName(CC_NAMESPACE, "name")).setValue("API_BODY");
        soapoptionalData.addChildElement(new QName(CC_NAMESPACE, "value")).setValue(emailContent);
        QName qPriorityLevel = new QName(CC_NAMESPACE, "priorityLevel");
        sTriggerMessage.addChildElement(qPriorityLevel).setValue("3");
        return request;
    }

    /**
     * This public method is used for logging the SOAPFault
     *
     * @param responseBody of the response we got from the Soap call
     */
    public void logSoapFault(SOAPBody responseBody) {
        this.LOG_CAT.debug("In the call soap fault method in webservice");
        SOAPFault fault = responseBody.getFault();
        String msg = "Encountered SOAP Fault " + fault.getFaultCode()
                + " while calling endpoint";
        this.LOG_CAT.error(msg);
    }

    /**
     * This function is used for calling the endpoint and fetching SOAP Response from it
     *
     * @param request Using which we will call the endpoint
     * @return SOAPMessage response from the endpoint after the call
     * @throws Exception throws a specific exception depending upon the exception arrived
     */
    public SOAPMessage callEndpoint(SOAPMessage request) throws Exception {

        long beginTime = System.currentTimeMillis();
        SOAPMessage response = null;
        try {
            this.LOG_CAT.debug("In callendpoint method in the webservice");

            String soapAction = "";
            SOAPConnection connection = this.createSOAPConnection();
			/*System.setProperty("sun.net.client.defaultConnectTimeout","10000");
			System.setProperty("sun.rmi.transport.proxy.connectTimeout","10000");
			System.setProperty("com.sun.xml.internal.ws.connect.timeout","10000");
			System.setProperty("com.sun.xml.internal.ws.request.timeout","10000");
			System.setProperty("javax.xml.ws.client.connectionTimeout","10000");
			System.setProperty("javax.xml.ws.client.receiveTimeout","10000");*/

            String endPointString = this.getPropertyValue(this.props.getProperty("endPoint"));
            URL endpoint = new URL(null, endPointString,
                    new URLStreamHandler() {
                        @Override
                        protected URLConnection openConnection(URL url) throws IOException {
                            URL clone_url = new URL(url.toString());
                            HttpURLConnection clone_urlconnection = (HttpURLConnection) clone_url.openConnection();
                            // TimeOut settings
                            clone_urlconnection.setConnectTimeout(Integer.parseInt(getPropertyValue(props.getProperty("timeOut"))));
                            clone_urlconnection.setReadTimeout(Integer.parseInt(getPropertyValue(props.getProperty("timeOut"))));
                            return (clone_urlconnection);
                        }
                    });

            if (LOG_CAT.isDebugEnabled()) {
                ByteArrayOutputStream req = new ByteArrayOutputStream();
                request.writeTo(req);
                LOG_CAT.debug("###### Request is ##### : \n" + XMLUtil.getXMLString(XMLUtil.getDocument(req.toString())));
                req.flush();
            }

            LOG_CAT.beginTimer("###### End point URL is ##### : " + endPointString);
            response = connection.call(request, endpoint);
            LOG_CAT.endTimer("###### End point URL is ##### : " + endPointString);
            connection.close();

            ByteArrayOutputStream resp = new ByteArrayOutputStream();
            response.writeTo(resp);
            LOG_CAT.info("###### EReceipt response is ##### : \n" + XMLUtil.getXMLString(XMLUtil.getDocument(resp.toString())));
            resp.flush();

        } catch (Exception e) {

            e.printStackTrace();

            Exception tempExcep = (Exception) e.getCause();
            while (tempExcep != null) {
                if (tempExcep instanceof java.net.ConnectException) {

                    throw new YFSException("CONNECTException", "EXTN_CONNECT", "CONNECTException");
                } else if (tempExcep instanceof java.io.IOException) {

                    throw new YFSException("IOException", "EXTN_IO", "IOException");
                } else if (tempExcep instanceof java.net.SocketTimeoutException) {

                    throw new YFSException("SocketTimeoutException", "EXTN_SOCKET_TIMEOUT", "SocketTimeoutException");
                } else {
                    tempExcep = (Exception) tempExcep.getCause();
                }
            }
            if (tempExcep == null) {
                throw new YFSException(e.getMessage(), "EXTN_UNKNOWN", "UNKNOWN_EXCEPTION");
            }
        }
        long endTime = System.currentTimeMillis();
        long responseTime = endTime - beginTime;
        String endPoint = this.props.getProperty("endPoint");
        LOG_CAT.info("EReceipt SOAP WebService Endpoint - " + endPoint + " took " + responseTime + " ms");

        return response;
    }

    /**
     * This function is used for creating a SOAPConnection
     *
     * @return SOAPConnection connection
     */
    public SOAPConnection createSOAPConnection() {
        this.LOG_CAT.debug("In the createSoapConnection method in webservice");
        System.setProperty("javax.xml.soap.SOAPConnectionFactory", "com.sun.xml.messaging.saaj.client.p2pl.HttpSOAPConnectionFactory");

        SOAPConnection connection = null;
        HttpSOAPConnectionFactory factoryInst = new HttpSOAPConnectionFactory();

        try {
            this.LOG_CAT.debug("Creating Soap Connection");
            connection = factoryInst.createConnection();


        } catch (SOAPException e) {
            this.LOG_CAT.debug("SOAPException in the creation of SOAPConnection");
        }
        return connection;
    }

    /**
     * This function is used for adding Header based on Kohls standards to the SOAPMessage
     * Message ID and Node ID will be added to the header using the createRequestMessageHeader() function
     *
     * @param request to which MessageHeader is added
     */
    public void addHeader(SOAPMessage request) {

        try {
            this.LOG_CAT.debug("In call to addHeader method in webservice");
            //Fix for defect 1999 - Start
            //MessageHeaderProcessorImpl headprocessorimpl = new MessageHeaderProcessorImpl();
            MessageHeaderCreator headerCreator = new MessageHeaderCreator();
            MessageSenderNodeInfo msgsendernodeinfo = new MessageSenderNodeInfo();

            this.LOG_CAT.debug("Set message header details");
            msgsendernodeinfo.setSystemCode(this.getPropertyValue(this.props.getProperty("systemCode")));
            msgsendernodeinfo.setModule(this.getPropertyValue(this.props.getProperty("module")));
            msgsendernodeinfo.setAppName(this.getPropertyValue(this.props.getProperty("appName")));

            this.LOG_CAT.debug("Set message sender node info");
            headerCreator.setMessageSenderNodeInfo(msgsendernodeinfo);

            this.LOG_CAT.debug("Add SOAPAction");
            MimeHeaders hd = request.getMimeHeaders();
            if (!YFCCommon.isVoid(this.props.getProperty("soapAction"))) {
                hd.addHeader("SOAPAction", this.getPropertyValue(this.props.getProperty("soapAction")));
            }

            this.LOG_CAT.debug("call to create Request Message Header");
            //MessageHeader header = headprocessorimpl.createRequestMessageHeader();
            MessageHeader header = headerCreator.createMessageHeader();
            //Fix for defect 1999 - End
            this.LOG_CAT.debug("Add Version");
            if (!YFCCommon.isVoid(this.props.getProperty("hdrVersion"))) {
                header.setVersion(this.getPropertyValue(this.props.getProperty("hdrVersion")));
            }
            this.LOG_CAT.debug("Put header to the soap message");

            SoapMessageUtil.putMessageHeader(request, header);

        } catch (MessageHeaderException e) {
            this.LOG_CAT.debug("MessageHeaderException in the calladdHeader method in the webservice");
        }

    }

    /**
     * Sets the properties
     *
     * @param prop Properties that need to be set
     * @throws Exception when unable to set the Property
     */

    public void setProperties(Properties prop) throws Exception {
        this.props = prop;
        this.LOG_CAT.debug("In the set properties method");

    }

    /**
     * This function is used to get the value for a property
     *
     * @param property name in string format
     * @return String propValue
     */
    public String getPropertyValue(String property) {


        String propValue;
        propValue = YFSSystem.getProperty(property);

        //updated to use configured property if
        // customer_overrides.properties does not return any value
        if (YFCCommon.isVoid(propValue)) {
            propValue = property;
        }
        return propValue;

    }

}
