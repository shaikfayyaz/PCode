package com.kohls.oms.agent;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.ycp.japi.util.YCPBaseAgent;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
/**
 * This class is called by PROCESS_CREATE_INVOICE agent.
 * It creates invoices at order level, groups invoices by EFCS(PO grouped under 873)
 * @author Priyadarshini
 *
 */
public class KohlsProcessInvoiceAgent extends YCPBaseAgent{

	
	private YIFApi api;
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsProcessInvoiceAgent.class.getName());
	public KohlsProcessInvoiceAgent() throws YIFClientCreationException {
		api = YIFClientFactory.getInstance().getLocalApi();
	}

	

	@Override
	/**
	 * gets taks Q list in 'awaiting invoice creation' state for creating invoice
	 */
	public List<Document> getJobs(YFSEnvironment env, Document InXML,
			Document lastMessageCreated) throws Exception {
		if (null != lastMessageCreated) {
			return null;
		}
		List<Document> lstTask = new ArrayList<Document>();
		YFCElement eleRoot = YFCDocument.getDocumentFor(InXML).getDocumentElement();
		String sMaxRecord = eleRoot.getAttribute(KohlsXMLLiterals.A_MAX_RECS);
		String sTaskQInterval = eleRoot.getAttribute(KohlsXMLLiterals.A_NEXT_TASK_Q_INTERVAL);
		if(YFCLogUtil.isDebugEnabled()){
			log.debug("######### MaxRecord ##########"+ sMaxRecord);
		}
		String strLastTaskQKey = "";
		// fetches first sMaxRecord number of records
		Document docGetTask = getTaskQDataList(env, sMaxRecord, strLastTaskQKey);
		NodeList nlTaskQ = docGetTask.getElementsByTagName(KohlsXMLLiterals.E_TASK_Q);
		// fetches all eligible records by looping,  sMaxRecord number in an iteration
		while(nlTaskQ != null && nlTaskQ.getLength()!=0){				
			Element eleTaskQ = null;
			for (int i = 0; i < nlTaskQ.getLength(); i++) {
				eleTaskQ = (Element) nlTaskQ.item(i);
				eleTaskQ.setAttribute(KohlsXMLLiterals.A_NEXT_TASK_Q_INTERVAL, sTaskQInterval);
				Document doc = XMLUtil.getDocumentForElement(eleTaskQ);
				if(YFCLogUtil.isDebugEnabled()){
					log.debug("######### record added  ##########"+ KohlsUtil.extractStringFromNode(doc));
				}
				lstTask.add(doc);
			}
			strLastTaskQKey = eleTaskQ.getAttribute(KohlsXMLLiterals.A_TASK_Q_KEY);
			docGetTask = getTaskQDataList(env, sMaxRecord, strLastTaskQKey);
			nlTaskQ = docGetTask.getElementsByTagName(KohlsXMLLiterals.E_TASK_Q);
		}
		
		return lstTask;
	}



	private Document getTaskQDataList(YFSEnvironment env, String sMaxRecord, String strLastTaskQKey)
			throws Exception {
		YFCDocument yfcDocGetTask = YFCDocument
				.createDocument(KohlsXMLLiterals.E_GET_TASK_Q_DATA_INPUT);
		YFCElement yfcEleGetTask = yfcDocGetTask.getDocumentElement();
		yfcEleGetTask.setAttribute(KohlsXMLLiterals.A_MAX_RECS, sMaxRecord);
		yfcEleGetTask.setAttribute(KohlsXMLLiterals.A_LAST_TASK_Q_KEY, strLastTaskQKey);
		yfcEleGetTask.setAttribute(KohlsXMLLiterals.A_TRANSACTIONID,
				KohlsConstant.TRAN_ID_ORDER_INVOICE_0001_EX);		
		Document docGetTask = api.getTaskQueueDataList(env,
				yfcDocGetTask.getDocument());
		return docGetTask;
	}


	/**
	 * Creates Invoices at Order level, grouped by EFCs(PO under 873)
	 */
	@Override
	public void executeJob(YFSEnvironment env, Document InXML)
			throws  Exception {
		processInvoice(env, InXML);
		// delete task Q record after creating invoice
		Element elemRoot = InXML.getDocumentElement();
		elemRoot.setAttribute(KohlsXMLLiterals.A_OPERATION,
				KohlsConstant.DELETE);
		manageTaskQ(env, InXML);
	}



	private void manageTaskQ(YFSEnvironment env, Document InXML) {
		try {
			api.manageTaskQueue(env, InXML);
		} catch (YFSException e1) {
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("####### Exception in manageTaskQueue #######"+ e1.getMessage());
			}
		} catch (RemoteException e1) {
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("####### Exception in manageTaskQueue #######"+ e1.getMessage());
			}
		}
	}



	private void processInvoice(YFSEnvironment env, Document InXML)
			throws RemoteException, TransformerException, YFSException, YIFClientCreationException {
		// get all the EFCs in the system
		Set<String> setEFCs = KohlsUtil.getEFCList(env);
		
		String strOrderHeaderKey = InXML.getDocumentElement().getAttribute(KohlsXMLLiterals.A_DATA_KEY);
		log.debug("**** orderheaderkey ******  " + strOrderHeaderKey);
		Map<String, Document> mapEFCInvoiceXML = new HashMap<String, Document>();	
		
		// get Order Details
		Document docOrderDetails = getOrderDetails(env, strOrderHeaderKey);	
		log.debug("***** Order Details XML is *****  " + XMLUtil.getXMLString(docOrderDetails));
		Element elemOrderStatuses = (Element)docOrderDetails.getElementsByTagName(KohlsXMLLiterals.E_ORDER_STATUSES).item(0);
		NodeList nlOrderStatus = elemOrderStatuses.getElementsByTagName(KohlsXMLLiterals.E_ORDER_STATUS);
		for(int i=0; i < nlOrderStatus.getLength(); i++){
			Element elemOrderStatus = (Element)nlOrderStatus.item(i);
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("######### elemOrderStatus ##########"+ KohlsUtil.extractStringFromNode(elemOrderStatus));
			}
			// if status is  canceled continue 
			if(!elemOrderStatus.getAttribute(KohlsXMLLiterals.A_STATUS).equals(KohlsConstant.AWAITING_INVOICE_CREATION)){
				continue;
			}
			String strShipNode = elemOrderStatus.getAttribute(KohlsXMLLiterals.A_SHIPNODE);
			log.debug("**** Ship Node on the Order Status element is ******" + strShipNode);
			
			String sNodeType = KohlsUtil.getNodeType(strShipNode, env);
			
			log.debug("***** Node Type obtained is *****" + sNodeType);
			
			boolean isnodeRDC = false;
			isnodeRDC = KohlsConstant.ATTR_RDC.equals(sNodeType) || KohlsConstant.ATTR_RDC_STORE.equals(sNodeType);
			
			log.debug("***** Is this node a RDC *****" + isnodeRDC);
			
			//Punit: changed for Omni Pilot, else condition to send 873 instead of actual store.
			if("DSV".equals(sNodeType)){
				strShipNode = KohlsConstant.EFC1;
			}
			else if(KohlsConstant.ATTR_STORE.equals(sNodeType)){
				log.debug("***** Node Type is STORE *****"+sNodeType);
				//fixed for drop2 : settlement - Start
				//strShipNode = KohlsUtil.getEFCForStore(strShipNode, env);
				//log.debug("**** Ship Node is ******" + strShipNode);
				//fixed for drop2 : settlement - End
			}else if(isnodeRDC){
				log.debug("***** Node Type is RDC *****");
				strShipNode = KohlsUtil.getEFCForStore(strShipNode, env);
				log.debug("**** Ship Node is ******" + strShipNode);
			}else if(isDSVShipment(setEFCs, strShipNode)){
				// for PO, group  invoice by node 873
				strShipNode = KohlsConstant.EFC1;
			} 
			Document docInvoiceXML = mapEFCInvoiceXML.get(strShipNode);
			if(docInvoiceXML == null){
				docInvoiceXML = getCreateOrderInvoiceInputXML(strOrderHeaderKey);
				docInvoiceXML.getDocumentElement().setAttribute("ShipNode", strShipNode);
				mapEFCInvoiceXML.put(strShipNode, docInvoiceXML);
				log.debug("***document getting formed*****" + XMLUtil.getXMLString(docInvoiceXML));
			}
			// update create invoice XML with order line key and qty
			updateInvoiceXML(docInvoiceXML, elemOrderStatus);					
			
		}		
		// create all the invoices at order level
		createNChangeOrderInvoices(env, mapEFCInvoiceXML);
		// update Order Status to 'Invoiced'  
		changeOrderStatusToInvoiced(env, strOrderHeaderKey);
	}

	
	private void changeOrderStatusToInvoiced(YFSEnvironment env, String strOrderHeaderKey) throws YFSException, RemoteException {
		// change Order Status to 'Invoiced'
		api.changeOrderStatus(env, getChangeOrderStatusInpt(strOrderHeaderKey));
		
	}



	private Document getChangeOrderStatusInpt(String strOrderHeaderKey) {		
		YFCDocument yfcDocChangeOrderStatus = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER_STATUS_CHANGE);
		YFCElement yfcEleChangeOrderStatus = yfcDocChangeOrderStatus.getDocumentElement();
		yfcEleChangeOrderStatus.setAttribute(KohlsXMLLiterals.A_TRANSACTIONID, KohlsConstant.TRAN_ID_ORDER_INVOICE_0001_EX);
		yfcEleChangeOrderStatus.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
		yfcEleChangeOrderStatus.setAttribute(KohlsXMLLiterals.A_BASE_DROP_STATUS, KohlsConstant.INVOICED);

		return yfcDocChangeOrderStatus.getDocument();
	}



	private void createNChangeOrderInvoices(YFSEnvironment env,
			Map<String, Document> mapEFCInvoiceXML) throws YFSException, RemoteException, TransformerException {
		Set<String> setShipNode = mapEFCInvoiceXML.keySet();
		 Iterator<String> it = setShipNode.iterator();
		    while (it.hasNext()) {
		      log.debug("****ShipNode is******" + it.next());
		    }
		    
		for(String sShipNode : setShipNode){
			if(YFCLogUtil.isDebugEnabled()){
				log.debug("######### in createOrderInvoices  ##########"+ 
						KohlsUtil.extractStringFromNode(mapEFCInvoiceXML.get(sShipNode)));
			}
			// create Invoice per EFC
			Document docOrderInvoiceOutput = api.createOrderInvoice(env, mapEFCInvoiceXML.get(sShipNode));
			Element elemInvoice = (Element)docOrderInvoiceOutput.getElementsByTagName(KohlsXMLLiterals.E_ORDER_INVOICE).item(0);
			String sOrderInvoiceKey = elemInvoice.getAttribute(KohlsXMLLiterals.A_ORDER_INVOICE_KEY);
			// store corresponding EFC value in yfs_order_invoice 
			String  strShipNode = mapEFCInvoiceXML.get(sShipNode).getDocumentElement().getAttribute("ShipNode");
			//api.changeOrderInvoice(env, getChangeOrderInvoiceInpt(sOrderInvoiceKey,sShipNode ));
			api.changeOrderInvoice(env, getChangeOrderInvoiceInpt(sOrderInvoiceKey,strShipNode ));
		}
		
	}



	private Document getChangeOrderInvoiceInpt(String strOrderInvoiceKey,
			String sShipNode) {
		YFCDocument yfcDocChangeOrderInvoice = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER_INVOICE);
		YFCElement yfcElemChangeOrderInvoice =  yfcDocChangeOrderInvoice.getDocumentElement();
		yfcElemChangeOrderInvoice.setAttribute(KohlsXMLLiterals.A_ORDER_INVOICE_KEY, strOrderInvoiceKey);
		YFCElement yfcElemExtn = yfcElemChangeOrderInvoice.createChild(KohlsXMLLiterals.E_EXTN);
		yfcElemExtn.setAttribute(KohlsXMLLiterals.A_EXTN_SHIP_NODE, sShipNode);		
		return yfcDocChangeOrderInvoice.getDocument();
	}




	private void updateInvoiceXML(Document docInvoiceXML,
			Element elemOrderStatus) {
		Element elemExistingOrderLines = (Element)docInvoiceXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINES).item(0);
		NodeList nlExisitngOrderLine = docInvoiceXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER_LINE);
		// create a map of already existing orderlinekey and its OrderLine 
		Map<String, Element> mapExisitngOrderLinekeys = new HashMap<String, Element>();
		for(int i = 0; i< nlExisitngOrderLine.getLength(); i++){
			Element elemExisitingOrderLine  = (Element) nlExisitngOrderLine.item(i);
			mapExisitngOrderLinekeys.put(elemExisitingOrderLine.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY),
										 elemExisitingOrderLine);
		}
		Set<String> setExistingOrderLineKeys = mapExisitngOrderLinekeys.keySet();
		String sInpOrderLineKey = elemOrderStatus.getAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY);
		String sInpQuantity = elemOrderStatus.getAttribute(KohlsXMLLiterals.A_STATUS_QTY);
		// check if input orderlinekey already exists, if yes, add its quantity to the existing 
		if(setExistingOrderLineKeys.contains(sInpOrderLineKey)){
			Element eleExistOrderLine = mapExisitngOrderLinekeys.get(sInpOrderLineKey);
			String sExisitngQuantity = eleExistOrderLine.getAttribute(KohlsXMLLiterals.A_QUANTITY);
			double dExisitngQuantity =  Double.parseDouble(sExisitngQuantity);
			double dInpQuantity =  Double.parseDouble(sInpQuantity);
			eleExistOrderLine.setAttribute(KohlsXMLLiterals.A_QUANTITY, 
					Double.toString(dExisitngQuantity+dInpQuantity));
			
		}else{
			// else create a new orderline
			Element elemOrderLine = docInvoiceXML.createElement(KohlsXMLLiterals.E_ORDER_LINE);
			elemExistingOrderLines.appendChild(elemOrderLine);
			elemOrderLine.setAttribute(KohlsXMLLiterals.A_QUANTITY, 
					sInpQuantity);
			elemOrderLine.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, 
					sInpOrderLineKey);
		}
	}

	private boolean isDSVShipment(Set<String> lstEFCs, String strShipNode) {
		return !lstEFCs.contains(strShipNode);		
	}

	
	private Document getCreateOrderInvoiceInputXML(String strOrderHeaderKey) {
		YFCDocument yfcDocOrder = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER);
		YFCElement yfcElemOrder = yfcDocOrder.getDocumentElement();
		yfcElemOrder.setAttribute(
				KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
		yfcElemOrder.setAttribute(
				KohlsXMLLiterals.A_IGNORE_STATUS_CHECK, KohlsConstant.YES);
		yfcElemOrder.setAttribute(
				KohlsXMLLiterals.A_TRANSACTIONID, KohlsConstant.TRAN_ID_ORDER_INVOICE_0001_EX);
		yfcElemOrder.createChild(KohlsXMLLiterals.E_ORDER_LINES);		
		return yfcDocOrder.getDocument();
	}

	private Document getOrderDetails(YFSEnvironment env,
			String strOrderHeaderKey) throws YFSException, RemoteException {
		env.setApiTemplate(KohlsConstant.API_GET_ORDER_DETAILS, getOrderDetailsTemplate());
		Document docOrderDetials = api.getOrderDetails(env, getOrderDetailsInput(strOrderHeaderKey));
		env.clearApiTemplate(KohlsConstant.API_GET_ORDER_DETAILS);		
		return docOrderDetials;		
	}



	private Document getOrderDetailsInput(String strOrderHeaderKey) {
		YFCDocument yfcDocOrder = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER);
		yfcDocOrder.getDocumentElement().setAttribute(
				KohlsXMLLiterals.A_ORDER_HEADER_KEY, strOrderHeaderKey);
		return yfcDocOrder.getDocument();
	}

	private Document getOrderDetailsTemplate() {
		YFCDocument yfcDocGetOrderDetailsTemp = YFCDocument
				.createDocument(KohlsXMLLiterals.E_ORDER);
		YFCElement yfcElemOrderDetailsTemp = yfcDocGetOrderDetailsTemp.getDocumentElement();
		yfcElemOrderDetailsTemp.setAttribute(KohlsXMLLiterals.A_ORDERNO, "");
		YFCElement yfcElemOrdereStatuses = yfcElemOrderDetailsTemp.createChild(KohlsXMLLiterals.E_ORDER_STATUSES);
		YFCElement yfcElemOrdereStatus = yfcElemOrdereStatuses.createChild(KohlsXMLLiterals.E_ORDER_STATUS);
		yfcElemOrdereStatus.setAttribute(KohlsXMLLiterals.A_ORDER_LINE_KEY, ""); 
		yfcElemOrdereStatus.setAttribute(KohlsXMLLiterals.A_STATUS, ""); 
		yfcElemOrdereStatus.setAttribute(KohlsXMLLiterals.A_STATUS_QTY, ""); 
		yfcElemOrdereStatus.setAttribute(KohlsXMLLiterals.A_SHIPNODE, "");
		return yfcDocGetOrderDetailsTemp.getDocument();
	}	

}
