package com.kohls.oms.api;

import java.util.Properties;

import org.w3c.dom.Document;

import com.tgcs.tcx.gravity.pos.auditsupport.CaptureOfflineAuditEntryForPOS;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.japi.YFSEnvironment;



/**
 * This class is a wrapper for the OfflineAuditEntry . It catches the xception caused by Double Queueing error.
 * @author tkmam5t
 *
 */
public class KohlsCaptureOfflineAuditEntryForPOSWrapper implements YIFCustomApi{

	private static final YFCLogCategory log = YFCLogCategory.instance(
			KohlsCaptureOfflineAuditEntryForPOSWrapper.class.getName());
	 

	
	public Document init(YFSEnvironment env, Document inDoc) throws YIFClientCreationException{
		Document outDoc = null;
		CaptureOfflineAuditEntryForPOS offlineAudit = new CaptureOfflineAuditEntryForPOS();
		try{
			outDoc = offlineAudit.init(env, inDoc);
		} catch ( Exception e )
	      {
			log.error( "KohlsCaptureOfflineAuditEntryForPOSWrapper.init() :Double Queuing error : Error while storing the AUDIT to POS_OFFLINE_TRX_Q table."+e.getMessage());
	      }

		return outDoc;
		
	}

	@Override
	public void setProperties(Properties arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
}