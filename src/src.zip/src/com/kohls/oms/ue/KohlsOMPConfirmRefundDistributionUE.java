package com.kohls.oms.ue;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.Map.Entry;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KohlsXMLLiterals;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.OMPConfirmRefundDistributionUE;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.kohls.common.util.KohlsConstant;
import com.kohls.poc.payments.ue.KohlsPoCGiftCardActivationUE;
import com.kohls.poc.pricing.ue.KohlsPoCPnPUtil;
/**
 * This class is called when requestionCollection API is invoked to 
 * 1) Check if the gift card no and value are in the env map
 * 2) Assign the refund amount to the SVC card as per the reprice XML
 * @author OASIS 2/25/2013 PMR 04158,999,000
 *
 */
public class KohlsOMPConfirmRefundDistributionUE implements OMPConfirmRefundDistributionUE{
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsOMPConfirmRefundDistributionUE.class.getName());
	@Override
	public Document confirmRefundDistribution(YFSEnvironment env, Document inXML)
			throws YFSUserExitException {
		
		YFCDocument yfsOutputXML = null;
		//Added as a part for PSA Tendering
		Document docPSAOutput=null;
		Element elemOrder = (Element)inXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
		String strOrderNo = elemOrder.getAttribute(KohlsXMLLiterals.A_ORDERNO);	
		Element elemPaymentMethods = (Element) elemOrder.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS).item(0);
		NodeList nlPaymentMethod = elemPaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
		log.debug(">>>>>confirmRefundDistribution InXML>>>>"+XMLUtil.getXMLString(inXML));
		//get the object from the env
		Map<String, String> mapScvProcessedAmount=(Map<String, String>)env.getTxnObject(("GiftCardAmount"+strOrderNo));
		Element elemRefundPaymentMethods = (Element)elemOrder.getElementsByTagName("RefundPaymentMethods").item(0);
		NodeList nlRefundPaymentMethod = elemRefundPaymentMethods.getElementsByTagName("RefundPaymentMethod");
		/**
		 * START :: Added as a part of PSA Tendering
		 */
		//get the PSA transaction object from env.
		Document docTxnOrder= (Document) env.getTxnObject("PSAFinalRefundTypes");
		Element eleTxnOrder=docTxnOrder.getDocumentElement();
		log.debug(" Txn Object PSAFinalRefund::"+env.getTxnObject("PSAFinalRefund").toString());
		
		//Call finalPSARefund If PSA transaction object is not null.
		if(!YFCCommon.isVoid(eleTxnOrder)){
			docPSAOutput=finalPSARefund(env,inXML, eleTxnOrder);
			return docPSAOutput;
		}
		/**
		 * END :: Added as a part of PSA Tendering.
		 */		
		
		yfsOutputXML = YFCDocument.createDocument("Order");
		YFCElement yfsOutputElement = yfsOutputXML.getDocumentElement();
		yfsOutputElement.setAttribute("DocumentType", "0001");
		yfsOutputElement.setAttribute("EnterpriseCode", "KOHLS.COM");
		yfsOutputElement.setAttribute("OrderNo", strOrderNo);
		YFCElement yfcRefundPaymentMethods = yfsOutputElement.createChild("RefundPaymentMethods");
		yfcRefundPaymentMethods.setAttribute("RefundAmountWithAssignments",elemRefundPaymentMethods.getAttribute("RefundAmountWithAssignments"));
		yfcRefundPaymentMethods.setAttribute("RefundAmountWithoutAssignments",elemRefundPaymentMethods.getAttribute("RefundAmountWithoutAssignments"));
		yfcRefundPaymentMethods.setAttribute("TotalAmountToBeRefunded",elemRefundPaymentMethods.getAttribute("TotalAmountToBeRefunded"));
		yfcRefundPaymentMethods.setAttribute("TotalTransferredOut",elemRefundPaymentMethods.getAttribute("TotalTransferredOut"));
		if(mapScvProcessedAmount!=null){			
			for(Entry<String, String> entry : mapScvProcessedAmount.entrySet())
		    {
					            
		           String SVCno=entry.getKey();
		           log.debug(">>>>>SVCno"+SVCno);
		           String amount=entry.getValue();
		           log.debug(">>>>>Amount"+amount);
		           //replace - from the amount
		           Double sProcessedAmount= Double.valueOf( amount.replaceFirst("-","" ));
		           for(int i=0;i<nlPaymentMethod.getLength();i++){
		            	DecimalFormat df= new DecimalFormat("#.##");
		            	Element elemPaymentMethod=(Element)nlPaymentMethod.item(i);
		            	String giftno=elemPaymentMethod.getAttribute("SvcNo");
		            	if(!giftno.equalsIgnoreCase(SVCno)){
			            		continue;
		            	}else
			            	{		
		            			//set the amount from the env to output XML
					            YFCElement yfcRefundPaymentMethod = yfcRefundPaymentMethods.createChild("RefundPaymentMethod");
								yfcRefundPaymentMethod.setAttribute("CheckNo",elemPaymentMethod.getAttribute("CheckNo"));
								yfcRefundPaymentMethod.setAttribute("CheckReference",elemPaymentMethod.getAttribute("CheckReference"));
								yfcRefundPaymentMethod.setAttribute("CreditCardExpDate",elemPaymentMethod.getAttribute("CreditCardExpDate"));
								yfcRefundPaymentMethod.setAttribute("CreditCardName",elemPaymentMethod.getAttribute("CreditCardName"));
								yfcRefundPaymentMethod.setAttribute("CreditCardNo",elemPaymentMethod.getAttribute("CreditCardNo"));
								yfcRefundPaymentMethod.setAttribute("CreditCardType",elemPaymentMethod.getAttribute("CreditCardType"));
								yfcRefundPaymentMethod.setAttribute("CustomerAccountNo",elemPaymentMethod.getAttribute("CustomerAccountNo"));
								yfcRefundPaymentMethod.setAttribute("CustomerPONo",elemPaymentMethod.getAttribute("CustomerPONo"));
								yfcRefundPaymentMethod.setAttribute("DisplayCreditCardNo",elemPaymentMethod.getAttribute("DisplayCreditCardNo"));
								yfcRefundPaymentMethod.setAttribute("DisplayCustomerAccountNo",elemPaymentMethod.getAttribute("DisplayCustomerAccountNo"));
								yfcRefundPaymentMethod.setAttribute("DisplayPaymentReference1",elemPaymentMethod.getAttribute("DisplayPaymentReference1"));
								yfcRefundPaymentMethod.setAttribute("DisplaySvcNo",elemPaymentMethod.getAttribute("DisplaySvcNo"));
								yfcRefundPaymentMethod.setAttribute("FundsAvailable",elemPaymentMethod.getAttribute("FundsAvailable"));
								yfcRefundPaymentMethod.setAttribute("GetFundsAvailableUserExitInvoked",elemPaymentMethod.getAttribute("GetFundsAvailableUserExitInvoked"));
								yfcRefundPaymentMethod.setAttribute("PaymentKey",elemPaymentMethod.getAttribute("PaymentKey"));
								yfcRefundPaymentMethod.setAttribute("PaymentReference1",elemPaymentMethod.getAttribute("PaymentReference1"));
								yfcRefundPaymentMethod.setAttribute("PaymentReference2",elemPaymentMethod.getAttribute("PaymentReference2"));
								yfcRefundPaymentMethod.setAttribute("PaymentReference3",elemPaymentMethod.getAttribute("PaymentReference3"));
								yfcRefundPaymentMethod.setAttribute("PaymentType",elemPaymentMethod.getAttribute("PaymentType"));
								yfcRefundPaymentMethod.setAttribute("RefundAmount",df.format(sProcessedAmount));
								yfcRefundPaymentMethod.setAttribute("SvcNo",elemPaymentMethod.getAttribute("SvcNo"));
								yfcRefundPaymentMethods.appendChild(yfcRefundPaymentMethod);
					        }
				      	}
				      }			
					            
				     
		}else{
			//if env map null, return input XML 
			for(int i=0;i<nlRefundPaymentMethod.getLength();i++){
				Element elemRefundPaymentMethod=(Element)nlRefundPaymentMethod.item(i);
				YFCElement yfcRefundPaymentMethod = yfcRefundPaymentMethods.createChild("RefundPaymentMethod");
				yfcRefundPaymentMethod.setAttribute("CheckNo",elemRefundPaymentMethod.getAttribute("CheckNo"));
				yfcRefundPaymentMethod.setAttribute("CheckReference",elemRefundPaymentMethod.getAttribute("CheckReference"));
				yfcRefundPaymentMethod.setAttribute("CreditCardExpDate",elemRefundPaymentMethod.getAttribute("CreditCardExpDate"));
				yfcRefundPaymentMethod.setAttribute("CreditCardName",elemRefundPaymentMethod.getAttribute("CreditCardName"));
				yfcRefundPaymentMethod.setAttribute("CreditCardNo",elemRefundPaymentMethod.getAttribute("CreditCardNo"));
				yfcRefundPaymentMethod.setAttribute("CreditCardType",elemRefundPaymentMethod.getAttribute("CreditCardType"));
				yfcRefundPaymentMethod.setAttribute("CustomerAccountNo",elemRefundPaymentMethod.getAttribute("CustomerAccountNo"));
				yfcRefundPaymentMethod.setAttribute("CustomerPONo",elemRefundPaymentMethod.getAttribute("CustomerPONo"));
				yfcRefundPaymentMethod.setAttribute("DisplayCreditCardNo",elemRefundPaymentMethod.getAttribute("DisplayCreditCardNo"));
				yfcRefundPaymentMethod.setAttribute("DisplayCustomerAccountNo",elemRefundPaymentMethod.getAttribute("DisplayCustomerAccountNo"));
				yfcRefundPaymentMethod.setAttribute("DisplayPaymentReference1",elemRefundPaymentMethod.getAttribute("DisplayPaymentReference1"));
				yfcRefundPaymentMethod.setAttribute("DisplaySvcNo",elemRefundPaymentMethod.getAttribute("DisplaySvcNo"));
				yfcRefundPaymentMethod.setAttribute("FundsAvailable",elemRefundPaymentMethod.getAttribute("FundsAvailable"));
				yfcRefundPaymentMethod.setAttribute("GetFundsAvailableUserExitInvoked",elemRefundPaymentMethod.getAttribute("GetFundsAvailableUserExitInvoked"));
				yfcRefundPaymentMethod.setAttribute("PaymentKey",elemRefundPaymentMethod.getAttribute("PaymentKey"));
				yfcRefundPaymentMethod.setAttribute("PaymentReference1",elemRefundPaymentMethod.getAttribute("PaymentReference1"));
				yfcRefundPaymentMethod.setAttribute("PaymentReference2",elemRefundPaymentMethod.getAttribute("PaymentReference2"));
				yfcRefundPaymentMethod.setAttribute("PaymentReference3",elemRefundPaymentMethod.getAttribute("PaymentReference3"));
				yfcRefundPaymentMethod.setAttribute("PaymentType",elemRefundPaymentMethod.getAttribute("PaymentType"));
				yfcRefundPaymentMethod.setAttribute("RefundAmount",elemRefundPaymentMethod.getAttribute("RefundAmount"));
				yfcRefundPaymentMethod.setAttribute("SvcNo",elemRefundPaymentMethod.getAttribute("SvcNo"));
				yfcRefundPaymentMethods.appendChild(yfcRefundPaymentMethod);
			}
			
		}
		
					yfsOutputElement.appendChild(yfcRefundPaymentMethods);
					
					log.debug(">>>> After confirmRefund Output XML>>>>"+XMLUtil.getXMLString(yfsOutputXML.getDocument()));
			return yfsOutputXML.getDocument();
		}
	/**
	 * START :: Added as a part of PSA Tendering.
	 * @param env
	 * @param inXML
	 * @param eleTxnOrder
	 * @return Document
	 * @throws YFSUserExitException
	 */
	private Document finalPSARefund(YFSEnvironment env,Document inXML, Element eleTxnOrder)throws YFSUserExitException {

		log.debug("Input to Method finalPSARefund ::"+XMLUtil.getXMLString(inXML));
		Document docOutputXML=null;

		Element eleOrder = (Element)inXML.getElementsByTagName(KohlsXMLLiterals.E_ORDER).item(0);
		String strOrderNo = eleOrder.getAttribute(KohlsXMLLiterals.A_ORDERNO);	
		Element elePaymentMethods = (Element) eleOrder.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS).item(0);
		NodeList nlPaymentMethod = elePaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);

		// Prepare the Output document.
		docOutputXML = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER).getDocument();
		Element eleOutputXMl=docOutputXML.getDocumentElement();
		eleOutputXMl.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE,KohlsConstant.SO_DOCUMENT_TYPE);
		eleOutputXMl.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE,KohlsConstant.KOHLS_ENTERPRISE_CODE);
		eleOutputXMl.setAttribute(KohlsXMLLiterals.A_ORDERNO, strOrderNo);
		Element eleRefundPaymentMethods=docOutputXML.createElement(KohlsXMLLiterals.E_REFUND_PAYMENT_METHODS);
		eleOutputXMl.appendChild(eleRefundPaymentMethods);

		if(!YFCCommon.isVoid(eleTxnOrder)){
			Element eleTxnPaymentMethods=(Element)eleTxnOrder.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS).item(0);
			if(!YFCCommon.isVoid(eleTxnPaymentMethods)){
				NodeList nlTxnPaymentMethod=eleTxnPaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
				for(int iTxn=0;iTxn< nlTxnPaymentMethod.getLength();iTxn++)
				{
					Element eleTxnPaymentMethod=(Element)nlTxnPaymentMethod.item(iTxn);
					if(!YFCCommon.isVoid(eleTxnPaymentMethod)){
						Element eleRefundPaymentMethod=docOutputXML.createElement(KohlsXMLLiterals.E_REFUND_PAYMENT_METHOD);
						eleRefundPaymentMethods.appendChild(eleRefundPaymentMethod);
						String strTxnPaymentType=eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
						if(!YFCCommon.isVoid(strTxnPaymentType)){
							if(KohlsConstant.PAYMENT_TYPE_CORPORATE_REFUND.equalsIgnoreCase(strTxnPaymentType)){
								eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,KohlsConstant.PAYMENT_TYPE_CHECK);
							}
							eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,strTxnPaymentType);
						}

						eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_REFUND_AMOUNT,eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));

						for(int i=0;i<nlPaymentMethod.getLength();i++){
							Element elemPaymentMethod=(Element)nlPaymentMethod.item(i);	
							if(!YFCCommon.isVoid(elemPaymentMethod)){
								String strPaymenttye=elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE);
								if(!YFCCommon.isVoid(strPaymenttye)&& strPaymenttye.equals(strTxnPaymentType)){
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CHECK_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CHECK_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CHECK_REF,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CHECK_REF));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_DATE));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_NAME,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_EXP_NAME));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CREDIT_CARD_TYPE));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CUSTOMER_ACC_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CUSTOMER_ACC_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_CUSTOMER_PO_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_CUSTOMER_PO_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_DISP_CREDIT_CARD_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_DISP_CREDIT_CARD_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_DISPLAY_CUSTOMER_ACC_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_DISPLAY_CUSTOMER_ACC_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_DISP_PAYMENT_REF_1,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_DISP_PAYMENT_REF_1));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_DISPLAY_SVC_NO,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_DISPLAY_SVC_NO));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_FUNDS_AVAILABLE,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_FUNDS_AVAILABLE));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_GET_FUNDS_AVAILABLE_UE_INVOKED,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_GET_FUNDS_AVAILABLE_UE_INVOKED));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_KEY,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_1));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_2));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_3,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_REF_3));
									eleRefundPaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6,KohlsConstant.PSA);

									if(!YFCCommon.isVoid(strTxnPaymentType) && KohlsConstant.KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT.equals(strTxnPaymentType)){

										Document docInputToGCActivation=formInputToGCActivation(env,eleTxnPaymentMethod,elemPaymentMethod);

										// Calling web service KohlsPoCSVCPaymentWebService
										KohlsPoCGiftCardActivationUE objGCActivation=new KohlsPoCGiftCardActivationUE();
										objGCActivation.processStoredValue(env,docInputToGCActivation);
									}
								}
							}
						}														
					}
				}					
			}															
		}
		log.debug("Output of Method finalPSARefund ::"+XMLUtil.getXMLString(docOutputXML));
		return docOutputXML;					
	}

	/**
	 * 
	 * @param env
	 * @param eleTxnPaymentMethod
	 * @param elemPaymentMethod
	 * @return Document 
	 * @throws YFSUserExitException
	 */
	private Document formInputToGCActivation(YFSEnvironment env,Element eleTxnPaymentMethod, Element elemPaymentMethod)
			throws YFSUserExitException {

		// forming input to web service KohlsPoCSVCPaymentWebService
		Document docInputToWebService = YFCDocument.createDocument(KohlsConstant.PAYMENT_REQUEST).getDocument();
		Element elePmntReq = docInputToWebService.getDocumentElement();
		Element eleTran = docInputToWebService.createElement(KohlsXMLLiterals.E_TRANSACTION);
		XMLUtil.appendChild(elePmntReq, eleTran);

		// Setting the attributes in the input xml.
		Double dAmount = new Double(eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
		eleTran.setAttribute(KohlsXMLLiterals.A_TENDER_AMOUNT,Double.toString(Math.abs(dAmount.doubleValue())));

		String sRequest = elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_REQUEST_TYPE);
		if (KohlsConstant.PRE_AUTH.equalsIgnoreCase(sRequest)) {
			eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,KohlsConstant.INQUIRY);
		} 
		else if ((KohlsConstant.PRE_AUTH_COMPLETE.equalsIgnoreCase(sRequest))){
			eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,KohlsConstant.ACTIVATION);
		}
		else if((KohlsConstant.DEACTIVATE.equalsIgnoreCase(sRequest))){
			eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,KohlsConstant.ACTIVATION_REVERSAL);
		}
		else if(KohlsConstant.PRE_AUTH_VOID.equalsIgnoreCase(sRequest)){
			eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,KohlsConstant.INQUIRY);
		}

		eleTran.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE));
		String sEntryMethod = eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_Entry_Method);
		if (KohlsConstant.KEYED.equalsIgnoreCase(sEntryMethod)){
			eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,KohlsConstant.KEYED);
		}else{
			eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,KohlsConstant.BARCODE);
		}
		//eleTran.setAttribute("Protected", props.getProperty("Protected"));
		String storeNo=eleTxnPaymentMethod.getAttribute(KohlsConstant.STORE_ID_PARAMETER);
		String prepadStroNo=KohlsPoCPnPUtil.prepadStoreNoWithZeros(storeNo);
		eleTran.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER,prepadStroNo);
		eleTran.setAttribute(KohlsXMLLiterals.A_REGISTER_NUMBER,elemPaymentMethod.getAttribute(KohlsConstant.TERMINAL_ID));
		eleTran.setAttribute(KohlsXMLLiterals.A_SVCNO, eleTxnPaymentMethod.getAttribute(KohlsConstant.ACCOUNT));
		eleTran.setAttribute(KohlsXMLLiterals.A_OPERATOR_ID,elemPaymentMethod.getAttribute(KohlsXMLLiterals.A_OPERATOR_ID));
		eleTran.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,elemPaymentMethod.getAttribute(KohlsConstant.POS_SEQUENCE_NO));
		
		log.debug("Output of Method formInputToGCActivation ::"+XMLUtil.getXMLString(docInputToWebService));
		return docInputToWebService;
	}
	/**
	 * END :: Added as a part of PSA Tendering.
	 */

}