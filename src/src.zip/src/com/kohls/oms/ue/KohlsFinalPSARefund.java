package com.kohls.oms.ue;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.kohls.common.util.KOHLSBaseApi;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.kohls.common.util.XMLUtil;
import com.kohls.common.util.XPathUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;
import com.yantra.yfs.japi.YFSUserExitException;

/**
 * 
 * @author 
 * 
 * Sample Input XML
 * <Order OrderHeaderKey="20151101114124296514">
 * <PaymentMethods>
 * <PaymentMethod  Amount="20" PaymentType="KOHLS_CASH"/>
 * <PaymentMethod  Amount="30" PaymentType="CASH"/>
 * <PaymentMethod  Amount="20" PaymentType="CREDIT_CARD"/>
 * <PaymentMethod  Amount="40" PaymentType="KOHLS_CHARGE_CARD"/>
 * <PaymentMethod  Amount="10" PaymentType="KMC" SVCNo="" entryMethod="" storeNumber=""/>
 * <PaymentMethod  Amount="10" PaymentType="CORPORATE_REFUND" FirstName="" LastName=""
 *	StreetAddress="" City="" State="" ZipCode="" DriversLicense="" PhoneNo="" Reason=""
 *  EMailID="" LoyalityCardNo=""/>                  
 * </PaymentMethods>          
 * </Order>                                                                                           
 *                              
 *
 */
public class KohlsFinalPSARefund {

	private static YFCLogCategory logger;
	String strReason = null;
	static {
		logger = YFCLogCategory.instance(KohlsFinalPSARefund.class.getName());
	}

	/**
	 * This Method is called to save the input in the transaction object.
	 * The transaction object is later retrieved in the userexit OMPConfirmRefundDistributionUE of requestCollection API.
	 * @param env
	 * @param inXML
	 * @throws DOMException 
	 * @throws ParserConfigurationException 
	 * @throws YFSUserExitException 
	 */
	public Document setFinalPSARefundTypes(YFSEnvironment env, Document inXML) throws DOMException, ParserConfigurationException,YFSUserExitException{

		logger .debug("InputDocument:"+ XMLUtil.getXMLString(inXML));

		Document docOutput=null;
		Document docGetOrderListOuput=null;
		Element elemOrder=null;
	

		env.setTxnObject("PSARefund",inXML);
		Element eleInXML= inXML.getDocumentElement();
		String strOrderHeaderkey=eleInXML.getAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY);

		// Forming the input document for getOrderList API Call.
		Document docGetOrderListInput=XMLUtil.createDocument("Order");
		Element eleOrderInput=docGetOrderListInput.getDocumentElement();
		if(!YFCCommon.isVoid(strOrderHeaderkey)){
			eleOrderInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);
			try {	
				docGetOrderListOuput = KOHLSBaseApi.invokeService(env,KohlsConstant.PSA_GET_ORDER_LIST,docGetOrderListInput);				

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				logger.error( "Exception in KohlsFinalPSARefund. when calling PSAgetOrderList service"+ e1.getMessage());
			}
		}
		
		if(!YFCCommon.isVoid(docGetOrderListOuput)){
			Element eleOrderList=docGetOrderListOuput.getDocumentElement();
			if(!YFCCommon.isVoid(eleOrderList)){
				elemOrder=(Element)eleOrderList.getElementsByTagName("Order").item(0);
			}
		}
		//Added For PSA Data Collect- START
		Element eleKohlsCashPaymentMethod=SCXmlUtil.getXpathElement(eleInXML, "PaymentMethods/PaymentMethod[@PaymentType='KOHLS_CASH']");
		if(!YFCCommon.isVoid(eleKohlsCashPaymentMethod)){
			Document docChangeOrderInputForKohlsCashPayment=formInputToChangeOrderKohlsCashPayment(env, strOrderHeaderkey, eleKohlsCashPaymentMethod);
			callChangeOrderForPSA(env, docChangeOrderInputForKohlsCashPayment);
		}
		//Added For PSA Data Collect- END
		Element eleCorporatePaymentMethod=SCXmlUtil.getXpathElement(eleInXML, "PaymentMethods/PaymentMethod[@PaymentType='CORPORATE_REFUND']");
		if (!YFCCommon.isVoid(eleCorporatePaymentMethod)){
			Document docChangeOrderInput=formInputToChangeOrder(env, strOrderHeaderkey, eleCorporatePaymentMethod);
			callChangeOrderForPSA(env, docChangeOrderInput);	
		}	

		Element eleKMCPaymentMethod=SCXmlUtil.getXpathElement(eleInXML, "PaymentMethods/PaymentMethod[@PaymentType='KMC']");
		if (!YFCCommon.isVoid(eleKMCPaymentMethod)){

			// Calling web service KohlsPoCSVCPaymentWebService
			try {
				Document docGCActivationOutput=createPSAGCActivationRequest(env,eleKMCPaymentMethod,elemOrder);
				Document docGCFinalOutput=createResponseDocumentfromWS(docGCActivationOutput);
				

				Element eleStoredValueRequestResult = docGCFinalOutput.getElementById("StoredValueRequestResult");
				if((!(YFCCommon.isVoid(eleStoredValueRequestResult)) && (eleStoredValueRequestResult.getAttribute("ResultCode").equalsIgnoreCase("ErrorDeclined") ) )){
				Document docError = XMLUtil.createDocument("Errors");
				Element eleErrors = docError.getDocumentElement();
				Element eleError = XMLUtil.createChild(eleErrors, "Error");
				eleError.setAttribute("ErrorCode", eleStoredValueRequestResult.getAttribute("ResultCode"));
				eleError.setAttribute("ErrorActionCode",eleStoredValueRequestResult.getAttribute("ActionCode") );
				eleError.setAttribute("ErrorResponseCode", eleStoredValueRequestResult.getAttribute("ResponseCode"));
				eleError.setAttribute("ErrorProcessorNetworkID", eleStoredValueRequestResult.getAttribute("ProcessorNetworkID"));
				eleError.setAttribute("ErrorDescription", "Card is Declined or Connect Timed Out");
				return docError;
				}
			} catch (YFSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}	

		// Prepare Input to call requestCollection API.
		Document docAPIInput=YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER).getDocument();
		Element eleAPIInput=docAPIInput.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)){
			eleAPIInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);

			// Call requestCollection API 
			try {
				docOutput=KOHLSBaseApi.invokeAPI(env,KohlsConstant.API_REQUEST_COLLECTION,docAPIInput);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.error("Exception occurred while calling requestCollection API:"+e.getStackTrace());
			}			
		}	
		//Processing the output of requestCollection
		if(YFCCommon.isVoid(docOutput)){
			Document docError = XMLUtil.createDocument("Errors");
			Element eleErrors = docError.getDocumentElement();
			Element eleError = XMLUtil.createChild(eleErrors, "Error");
			eleError.setAttribute("ErrorDescription", "Exception while calling requestCollection API");
			return docError;
		}else if((KohlsXMLLiterals.E_ORDER).equalsIgnoreCase(docOutput.getDocumentElement().getNodeName())){
			// requestCollection API is successful, update PaymentReference6.
			Document docInputToChangeOrder=formInputToUpdatePaymentRef(env, strOrderHeaderkey, eleInXML, elemOrder);
			callChangeOrderForPSA(env, docInputToChangeOrder);
			
			docGetOrderListInput=XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			eleOrderInput=docGetOrderListInput.getDocumentElement();
			if(!YFCCommon.isVoid(strOrderHeaderkey)){
				eleOrderInput.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);
			
			try {	
				Document docGetOrderListOutput = KOHLSBaseApi.invokeService(env,KohlsConstant.PSA_GET_ORDER_LIST,docGetOrderListInput);		
				Element eleGetOrderOutputElement = XMLUtil.getChildElement(docGetOrderListOutput.getDocumentElement(), "Order");
				return XMLUtil.getDocumentForElement(eleGetOrderOutputElement);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				logger.error( "Exception in KohlsPSAOMPConfirmRefundDistributionUE.finalPSARefund, when calling PSAgetOrderList service"+ e1.getMessage());
			}
			
		}
		}else if(("ApiSuccess").equalsIgnoreCase(docOutput.getDocumentElement().getNodeName())){
			Document docOrder=XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
			Element eleOrd=docOrder.getDocumentElement();
			eleOrd.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);
			return docOrder;
		}
		return docOutput;
	}

	/**
	 * @param env
	 * @param strOrderHeaderkey
	 * @param eleInXML
	 * @throws ParserConfigurationException
	 * @throws DOMException
	 */
	public Document formInputToUpdatePaymentRef(YFSEnvironment env,
			String strOrderHeaderkey, Element eleInXML, Element elemOrder)
					throws ParserConfigurationException, DOMException {
		// Creating Input document to call changeOrder API.
		Document docChangeOrderInput=XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleOrder=docChangeOrderInput.getDocumentElement();
		eleOrder.setAttribute(KohlsXMLLiterals.A_ACTION,KohlsConstant.MODIFY);
		if (!YFCCommon.isVoid(strOrderHeaderkey)){
			eleOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);				
		}
		Element elePaymentMethods=docChangeOrderInput.createElement(KohlsXMLLiterals.E_PAYMENT_METHODS);
		eleOrder.appendChild(elePaymentMethods);

		Element eleInputPaymentMethods=(Element)eleInXML.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHODS).item(0);
		if(!YFCCommon.isVoid(eleInputPaymentMethods)){
			NodeList nlInputPaymentMethod=eleInputPaymentMethods.getElementsByTagName(KohlsXMLLiterals.E_PAYMENT_METHOD);
			for(int i=0;i< nlInputPaymentMethod.getLength();i++)
			{
				Element eleInputPaymentMethod=(Element)nlInputPaymentMethod.item(i);

				//Create PaymentMethod in the Output document.
				Element elePaymentMethod=docChangeOrderInput.createElement(KohlsXMLLiterals.E_PAYMENT_METHOD);
				elePaymentMethods.appendChild(elePaymentMethod);
				Element eleOrdPaymentMethod=SCXmlUtil.getXpathElement(elemOrder, "PaymentMethods/PaymentMethod[@PaymentType='"+eleInputPaymentMethod.getAttribute("PaymentType")+"']");				
				if(!YFCCommon.isVoid(eleOrdPaymentMethod)){
				elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_KEY, eleOrdPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_KEY));
				}
				elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_REF_6,KohlsConstant.PSA);
				elePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,eleInputPaymentMethod.getAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE));
			}
		}
		return docChangeOrderInput;
	}

	/**
	 * This method is called to update KCDReturnTenderAmount in db.
	 * @param env
	 * @param strOrderHeaderkey
	 * @param eleKohlsCashPaymentMethod
	 * @return
	 * @throws ParserConfigurationException
	 * @throws DOMException
	 */
	public Document formInputToChangeOrderKohlsCashPayment(YFSEnvironment env, String strOrderHeaderkey, Element eleKohlsCashPaymentMethod)
			throws ParserConfigurationException, DOMException {
		// Creating Input document to call changeOrder API.
		Document docChangeOrderInput=XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleOrder=docChangeOrderInput.getDocumentElement();
		if (!YFCCommon.isVoid(strOrderHeaderkey)){
			eleOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);
			eleOrder.setAttribute(KohlsXMLLiterals.A_ACTION,KohlsConstant.MODIFY);
			Element eleExtn=docChangeOrderInput.createElement(KohlsXMLLiterals.E_EXTN);
			eleOrder.appendChild(eleExtn);
			//set KohlsCash Amount
			String strKohlsCashAmount=eleKohlsCashPaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT);
			if(!YFCCommon.isVoid(strKohlsCashAmount)){
				eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_KCD_RETURN_TENDER_AMOUNT, strKohlsCashAmount);
			}
		}
		eleOrder.setAttribute(KohlsConstant.SELECT_METHOD, KohlsConstant.SELECT_METHOD_WAIT);
		return docChangeOrderInput;
	}
	
	private void callChangeOrderForPSA(YFSEnvironment env,
			Document docChangeOrderInput) {
		//Call changeOrder API to update the details of PaymentMehod Corporate refund on the Order.
		try {
			KOHLSBaseApi.invokeAPI(env,KohlsConstant.CHANGE_ORDER_API,docChangeOrderInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error( "Exception in the Method callChangeOrderForPSA of KohlsPSARefund"+ e.getMessage());
		}
	}	
	
	
	public Document formInputToChangeOrder(YFSEnvironment env, String strOrderHeaderkey,
			Element eleCorporatePaymentMethod)
			throws ParserConfigurationException, DOMException {
		
		// Creating Input document to call changeOrder API.
		Document docChangeOrderInput=XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);
		Element eleOrder=docChangeOrderInput.getDocumentElement();
		
		if (!YFCCommon.isVoid(strOrderHeaderkey)){
			eleOrder.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY,strOrderHeaderkey);
			eleOrder.setAttribute(KohlsXMLLiterals.A_ACTION,KohlsConstant.MODIFY);
			Element eleExtn=docChangeOrderInput.createElement(KohlsXMLLiterals.E_EXTN);
			eleOrder.appendChild(eleExtn);
					
			//set Email ID in the changeOrder Input
			String strEmailID=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_EMAIL_ID);
			if (!YFCCommon.isVoid(strEmailID)){
				eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_EMAIL_ADDRESS, strEmailID);
			}

			// set LoyalityCardNo in the changeOrder Input
			String strLoyalityCardNo=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_LOYALITY_CARD_NO);
			if (!YFCCommon.isVoid(strOrderHeaderkey)){
				//Change Required
				//if (!YFCCommon.isVoid(strLoyalityCardNo)){
				eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_CUSTOMER_LOYALCARD, strLoyalityCardNo);
			}

			// set ReasonCode in the changeOrder Input
			
			// Changes to set Reason Code Value instead of Reason Code Description -- 7/1/16 -- Begin 
			
				strReason=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_REASON);
			if (!YFCCommon.isVoid(strReason)){
				// Preparing input document for API call to GetCommonCodeList
				logger.debug("Setting Reason code");

				Document docInputToCommonCodeAPI = YFCDocument.createDocument(
						KohlsPOCConstant.E_COMMON_CODE).getDocument();
				Element eleRootCommonCode = docInputToCommonCodeAPI
						.getDocumentElement();
				eleRootCommonCode.setAttribute(KohlsPOCConstant.A_CODE_TYPE,
						"CORP_REASON_CODE");

				logger.debug("API Input to getCommonCodeList is ::"
						+ XMLUtil.getXMLString(docInputToCommonCodeAPI));

				/* Method Call to fetch CommonCodeValue corresponding to Reason
				 provided by Gravity*/
				
				Document docOutput = UpdateExtnReasonCode(env,
						docInputToCommonCodeAPI);

				String strCodeValue = docOutput.getDocumentElement()
						.getAttribute(KohlsXMLLiterals.A_EXTN_REASON_CODE);
				if (YFCCommon.isStringVoid(strCodeValue)) {
					eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_REASON_CODE,
							KohlsPOCConstant.BLANK);
				} else {
					eleExtn.setAttribute(KohlsXMLLiterals.A_EXTN_REASON_CODE,
							strCodeValue);
				}
			}
							
			
			// Changes to set Reason Code Value instead of Reason Code Description -- 7/1/16 -- End 
							
			Element elePersonInfo=docChangeOrderInput.createElement(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
			eleOrder.appendChild(elePersonInfo);				
			
			// set FirstName in the changeOrder Input
			String strFirstName=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_FIRST_NAME);
			if (!YFCCommon.isVoid(strFirstName)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_FIRST_NAME,strFirstName);					
			}
			
			// set LastName in the changeOrder Input
			String strLastName=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_LAST_NAME);
			if (!YFCCommon.isVoid(strLastName)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_LAST_NAME,strLastName);					
			}
			
			// set StreetAddress in the changeOrder Input
			String strStreetAddress=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_STREET_ADDRESS);
			if (!YFCCommon.isVoid(strStreetAddress)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_ADD_LINE_1,strStreetAddress);					
			}
			
			// set City in the changeOrder Input
			String strCity=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_CITY);
			if (!YFCCommon.isVoid(strCity)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_CITY,strCity);					
			}
			
			// set State in the changeOrder Input
			String strState=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_STATE);
			if (!YFCCommon.isVoid(strState)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_STATE,strState);					
			}
			
			// set ZipCode in the changeOrder Input
			String strZipCode=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_ZIP_CODE);
			if (!YFCCommon.isVoid(strZipCode)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_ZIP_CODE,strZipCode);					
			}
			
			// set PhoneNo in the changeOrder Input
			String strPhoneNo=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_PHONE_NO);
			if (!YFCCommon.isVoid(strPhoneNo)){
				elePersonInfo.setAttribute(KohlsXMLLiterals.A_DAY_PHONE,strPhoneNo);					
			}
			
			Element eleExtnPersonInfo=docChangeOrderInput.createElement(KohlsXMLLiterals.E_EXTN);
			elePersonInfo.appendChild(eleExtnPersonInfo);
			
			// set DriversLicense in the changeOrder Input
			String strDriversLicense=eleCorporatePaymentMethod.getAttribute(KohlsXMLLiterals.A_DRIVERS_LICENSE);
			if (!YFCCommon.isVoid(strDriversLicense)){
				eleExtnPersonInfo.setAttribute(KohlsXMLLiterals.A_EXTN_DRIVERS_LICENSE,strDriversLicense);					
			}
		}
		return docChangeOrderInput;		
	}
	public Document createPSAGCActivationRequest(YFSEnvironment env,Element eleTxnPaymentMethod, Element elemOrder)
			throws YFSUserExitException {

		Document docGCActivationOutput =null;
		// forming input to web service KohlsPoCSVCPaymentWebService
		Document docInputToWebService = YFCDocument.createDocument(KohlsConstant.PAYMENT_REQUEST).getDocument();
		Element elePmntReq = docInputToWebService.getDocumentElement();
		Element eleTran = docInputToWebService.createElement(KohlsXMLLiterals.E_TRANSACTION);
		XMLUtil.appendChild(elePmntReq, eleTran);

		// Setting the attributes in the input xml.
		Double dAmount = new Double(eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_AMOUNT));
		eleTran.setAttribute(KohlsXMLLiterals.A_TENDER_AMOUNT,Double.toString(Math.abs(dAmount.doubleValue())));
		eleTran.setAttribute(KohlsXMLLiterals.A_REQUEST_TYPE,KohlsConstant.ACTIVATION);
		
		eleTran.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE,"MerchandiseReturnCredit");
		String sEntryMethod = eleTxnPaymentMethod.getAttribute(KohlsXMLLiterals.A_Entry_Method);
		if (KohlsConstant.KEYED.equalsIgnoreCase(sEntryMethod)){
			eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,KohlsConstant.KEYED);
		}else{
			eleTran.setAttribute(KohlsXMLLiterals.A_Entry_Method,KohlsConstant.BARCODE);
		}
		//eleTran.setAttribute("Protected", props.getProperty("Protected"));
		String storeNo=eleTxnPaymentMethod.getAttribute("storeNumber");
		//String prepadStroNo=KohlsPoCPnPUtil.prepadStoreNoWithZeros(storeNo);
		eleTran.setAttribute(KohlsXMLLiterals.A_STORE_NUMBER,storeNo);
		eleTran.setAttribute(KohlsXMLLiterals.A_REGISTER_NUMBER,elemOrder.getAttribute(KohlsXMLLiterals.A_TERMINAL_ID));
		eleTran.setAttribute(KohlsXMLLiterals.A_SVCNO, eleTxnPaymentMethod.getAttribute("SVCNo"));
		eleTran.setAttribute(KohlsPOCConstant.A_OPERATOR_ID,elemOrder.getAttribute(KohlsPOCConstant.A_OPERATOR_ID));
		eleTran.setAttribute(KohlsXMLLiterals.A_TRANSACTION_NUMBER,elemOrder.getAttribute(KohlsConstant.POS_SEQUENCE_NO));
							
		logger.debug("Input to call KohlsPoCSVCPaymentWebService::"+XMLUtil.getXMLString(docInputToWebService));		
			try {
			docGCActivationOutput = KOHLSBaseApi.invokeService(env,"KohlsPoCSVCPaymentWebService", docInputToWebService);
			} catch (Exception e) {
				// TODO Auto-generated catch block
			logger.error("Exception while calling PSA KohlsPoCSVCPaymentWebService"+e.getMessage());
			}												
		return docGCActivationOutput;
		}
	
	public Document createResponseDocumentfromWS(Document docGCActRequestOutput )throws YFCException, ParserConfigurationException {

		Document docStoredValueRequest=XMLUtil.createDocument("StoredValueRequest");
		Element eleStoredValueRequest = docStoredValueRequest.getDocumentElement();
		Element eleStoredValueRequestResult = docStoredValueRequest.createElement("StoredValueRequestResult");
		XMLUtil.appendChild(eleStoredValueRequest, eleStoredValueRequestResult);
		Element sExtn = docStoredValueRequest.createElement("Extn");
		XMLUtil.appendChild(eleStoredValueRequestResult,sExtn);

		Element paymentResponse = docGCActRequestOutput.getDocumentElement();		
		String sResultCode = paymentResponse.getAttribute("ApprovalNumber");
		String sAuthSource=paymentResponse.getAttribute("AuthSource");
		String sExtnAuthSourceNode = paymentResponse.getAttribute("NodeId");


		if(sExtnAuthSourceNode.startsWith("ISP"))
		{	
			sExtn.setAttribute("ExtnAuthSourceNode","STORE");
	}	
		else
		{
			sExtn.setAttribute("ExtnAuthSourceNode","CORP");
		}
		if(KohlsPOCConstant.N_PG_REFERRAL.equals(sResultCode)){
			eleStoredValueRequestResult.setAttribute("ResultCode", "Success");
			eleStoredValueRequestResult.setAttribute("ActionCode", "Authorized");
			eleStoredValueRequestResult.setAttribute("ResponseCode", sResultCode);
			eleStoredValueRequestResult.setAttribute("ProcessorNetworkID", sAuthSource);
		}
		else {
			eleStoredValueRequestResult.setAttribute("ResultCode", "ErrorDeclined");
			eleStoredValueRequestResult.setAttribute("ActionCode", "Declined");
			eleStoredValueRequestResult.setAttribute("ResponseCode", sResultCode);
			eleStoredValueRequestResult.setAttribute("ProcessorNetworkID", sAuthSource);
		}
		logger.debug("Create OutPut XML:"+ XMLUtil.getXMLString(docStoredValueRequest));

		return docStoredValueRequest;
	}

	
	/**
	 * This method fetches the Reason Code Value from the CommonCodeList 
	 * according to the Reason Code provided by Gravity for Corporate Refund
	 * in PSA
	 * @param env
	 * @param inputDoc
	 * @return docOrderInput
	 * @throws Exception
	 */

	public Document UpdateExtnReasonCode(YFSEnvironment env,Document inputDoc)
	{
		Document docOrderInput = null;
		try{
			logger.beginTimer("UpdateExtnReasonCode -- Begin ");
			
			
				Document docOutputFromCommonCodeAPI = KOHLSBaseApi.invokeAPI(
						env, KohlsConstant.API_GET_COMMON_CODE_LIST,
						inputDoc);
				logger.debug("API Output is :::"+XMLUtil.getXMLString(docOutputFromCommonCodeAPI));
				
				docOrderInput=XMLUtil.createDocument(KohlsXMLLiterals.E_ORDER);				
				Element eleRoot=docOrderInput.getDocumentElement();

				
				if (!YFCCommon.isVoid(docOutputFromCommonCodeAPI)) {
					NodeList ndlCommonCode = XPathUtil.getNodeList(
							docOutputFromCommonCodeAPI,
							"CommonCodeList/CommonCode");
					for (int n = 0; n < ndlCommonCode.getLength(); n++) {
						Element elecurrentelement = (Element) ndlCommonCode
								.item(n);
						logger.debug("Current Element in Nodelist is ::"+XMLUtil.getElementXMLString(elecurrentelement));
						
						String strCodeDesc = elecurrentelement
								.getAttribute(KohlsPOCConstant.A_CODE_SHORT_DESC);
						logger.debug("CommonCode Description in input is ::"+strCodeDesc);
						logger.debug("Reason attribute from Gravity:::"+strReason);
						
						if (strReason.equalsIgnoreCase(strCodeDesc)) {
							logger.debug("Inside if block for matching reason");
							String strCodeValue = elecurrentelement
									.getAttribute(KohlsPOCConstant.ATTR_CODE_VALUE);
							logger.debug("Corresponding Code Value is ::"+strCodeValue);
							eleRoot.setAttribute(
									KohlsXMLLiterals.A_EXTN_REASON_CODE,
									strCodeValue);
							logger.debug("Document to be returned is:::"+XMLUtil.getXMLString(docOrderInput));
							return docOrderInput;
						} 

					}
				
				
				}
				logger.endTimer("UpdateExtnReasonCode -- End");
			}		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return docOrderInput;
	}
	
	
}
