package com.kohls.oms.ue;

import java.rmi.RemoteException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.custom.util.xml.XMLUtil;
import com.kohls.common.util.KohlsConstant;
import com.kohls.common.util.KohlsXMLLiterals;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionInputStruct;
import com.yantra.yfs.japi.YFSExtnPaymentCollectionOutputStruct;
import com.yantra.yfs.japi.YFSUserExitException;
import com.yantra.yfs.japi.ue.YFSCollectionStoredValueCardUE;

public class KohlsCollectionStoredValueCardUE implements YFSCollectionStoredValueCardUE{

	private YIFApi api;
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsCollectionStoredValueCardUE.class.getName());
	public KohlsCollectionStoredValueCardUE() throws YIFClientCreationException{
		api = YIFClientFactory.getInstance().getApi();
	}
	@Override
	public YFSExtnPaymentCollectionOutputStruct collectionStoredValueCard(
			YFSEnvironment env, YFSExtnPaymentCollectionInputStruct inputStruct)
	throws YFSUserExitException {
		if(YFCLogUtil.isDebugEnabled()){
			log.debug("<----------- Begining of KohlsCollectionStoredValueCardUE ----------->");
		}
		YFSExtnPaymentCollectionOutputStruct outputStruct = null;
		try{
			outputStruct = new YFSExtnPaymentCollectionOutputStruct();
			// TODO Auto-generated method stub
			if(0 > inputStruct.requestAmount){

				if(YFCLogUtil.isDebugEnabled()){
					log.debug("Request Amount : " + String.valueOf(inputStruct.requestAmount));
				}

				YFCDocument yfcDocOrderDetails = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER);
				YFCElement yfcEleOrderDetails = yfcDocOrderDetails.getDocumentElement();
				yfcEleOrderDetails.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, inputStruct.orderHeaderKey);

				if(YFCLogUtil.isDebugEnabled()){
					log.debug("Input to getOrderDetails : " + XMLUtil.getXMLString(yfcDocOrderDetails.getDocument()));
				}

				env.setApiTemplate(KohlsConstant.API_GET_ORDER_DETAILS, getOrderDetailsTemp());
				Document docGetOrderDetails = api.getOrderDetails(env, yfcDocOrderDetails.getDocument());
				env.clearApiTemplate(KohlsConstant.API_GET_ORDER_DETAILS);

				if(YFCLogUtil.isDebugEnabled()){
					log.debug("Output to getOrderDetails : " + XMLUtil.getXMLString(docGetOrderDetails));
				}

				Element eleChargeDetails = (Element)docGetOrderDetails.getElementsByTagName(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAILS).item(0);
				eleChargeDetails.setAttribute(KohlsXMLLiterals.A_TOTAL_CREDITS, "");
				NodeList ndlstChargeDetails = docGetOrderDetails.getElementsByTagName(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);

				for(int i=0;i<ndlstChargeDetails.getLength();i++){

					Element eleChargeDetail = (Element)ndlstChargeDetails.item(i);
					String sChargeTransactionKey = eleChargeDetail.getAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY);
					if(!inputStruct.chargeTransactionKey.equals(sChargeTransactionKey)){

						eleChargeDetails.removeChild(ndlstChargeDetails.item(i));
					}


				}

				if(YFCLogUtil.isDebugEnabled()){
					log.debug("Kohls Stored Value Card Refund Message : " + XMLUtil.getXMLString(docGetOrderDetails));
				}
				// Start -- Added for 04158,999,000 -- OASIS_SUPPORT 25/02/2013 //
				//Commented this logic
				//api.executeFlow(env, KohlsConstant.SERVICE_KOHLS_STORED_VALUE_CARD_REFUND_SERVICE, docGetOrderDetails);
				// End -- Added for 04158,999,000 -- OASIS_SUPPORT 25/02/2013 //
			}	


		}catch(RemoteException e){
			e.printStackTrace();
		}
		
		outputStruct.authorizationAmount = inputStruct.requestAmount;
		outputStruct.SvcNo = inputStruct.svcNo;
		outputStruct.tranAmount = inputStruct.requestAmount;
		return outputStruct;

	}
	
	
	private Document getOrderDetailsTemp(){

		YFCDocument yfcDocGetOrderDetails = YFCDocument.createDocument(KohlsXMLLiterals.E_ORDER);
		YFCElement yfcEleGetOrderDetails = yfcDocGetOrderDetails.getDocumentElement();
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_CARRIER_SERVICE_CODE, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_DOCUMENTTYPE, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_ENTERPRISE_CODE, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_ORDERNO, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_PAYMENT_STATUS, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_SELLER_ORGANIZATION_CODE, "");
		yfcEleGetOrderDetails.setAttribute(KohlsXMLLiterals.A_STATUS, "");


		YFCElement yfcElePaymentMethods = yfcDocGetOrderDetails.createElement(KohlsXMLLiterals.E_PAYMENT_METHODS);
		YFCElement yfcElePaymentMethod = yfcDocGetOrderDetails.createElement(KohlsXMLLiterals.E_PAYMENT_METHOD);
		yfcElePaymentMethod.setAttribute(KohlsXMLLiterals.A_SVC_NO, "");
		yfcElePaymentMethod.setAttribute(KohlsXMLLiterals.A_PAYMENT_TYPE, "");
		yfcElePaymentMethod.setAttribute(KohlsXMLLiterals.A_MAX_CHARGE_LIMIT, "");
		yfcElePaymentMethod.setAttribute(KohlsXMLLiterals.A_UNLIMITED_CHARGES, "");
		yfcElePaymentMethod.setAttribute(KohlsXMLLiterals.A_TOTAL_CHARGED, "");
		yfcElePaymentMethods.appendChild(yfcElePaymentMethod);
		yfcEleGetOrderDetails.appendChild(yfcElePaymentMethods);

		YFCElement yfcEleChargeTranDtls = yfcDocGetOrderDetails.createElement(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAILS);
		YFCElement yfcEleChargeTranDtl = yfcDocGetOrderDetails.createElement(KohlsXMLLiterals.E_CHARGE_TRANSACTION_DETAIL);
		yfcEleChargeTranDtl.setAttribute(KohlsXMLLiterals.A_CHARGE_TRANSACTION_KEY, "");
		yfcEleChargeTranDtl.setAttribute(KohlsXMLLiterals.A_CHARGE_TYPE, "");
		yfcEleChargeTranDtl.setAttribute(KohlsXMLLiterals.A_ORDER_HEADER_KEY, "");
		yfcEleChargeTranDtl.setAttribute(KohlsXMLLiterals.A_REQUEST_AMOUNT, "");
		yfcEleChargeTranDtl.setAttribute(KohlsXMLLiterals.A_CREDIT_AMOUNT, "");
		yfcEleChargeTranDtl.setAttribute(KohlsXMLLiterals.A_BOOK_AMOUNT, "");
		yfcEleChargeTranDtls.appendChild(yfcEleChargeTranDtl);
		yfcEleGetOrderDetails.appendChild(yfcEleChargeTranDtls);


		if(YFCLogUtil.isDebugEnabled()){

			log.debug("getOrderDetails output Template \n" + XMLUtil.getXMLString(yfcDocGetOrderDetails.getDocument()));
		}

		return yfcDocGetOrderDetails.getDocument();
	}
}


