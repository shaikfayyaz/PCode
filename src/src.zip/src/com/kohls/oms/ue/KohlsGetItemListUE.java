/**
 * 
 */
package com.kohls.oms.ue;

import org.w3c.dom.Document;

import com.yantra.ycm.japi.ue.YCMGetItemListUE;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSUserExitException;

/**
 * @author ibmadmin
 *
 */
public class KohlsGetItemListUE implements YCMGetItemListUE {

	/**
	 * 
	 */
	public KohlsGetItemListUE() {
	}

	/* (non-Javadoc)
	 * @see com.yantra.ycm.japi.ue.YCMGetItemListUE#getItemList(com.yantra.yfs.japi.YFSEnvironment, org.w3c.dom.Document)
	 */
	@Override
	public Document getItemList(YFSEnvironment environment, Document input)
			throws YFSUserExitException {
		System.out.println("placeholder");
		return input;
	}

}
