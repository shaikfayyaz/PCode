package com.kohls.common.util;


import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;

/**
 * Encrypt/decrypt utility.
 */
public class AESEncryptionUtil
{

   private static YFCLogCategory      logger           = YFCLogCategory.instance( AESEncryptionUtil.class.getName() );

   private static final String        SECRET_KEY       = YFSSystem.getProperty( "kohls.sso.secretKey" );

   private static final String        SECURITY_CIPHER  = YFSSystem.getProperty( "kohls.sso.algorithm" );

   private static final String        DEFAULT_ENCODING = "UTF-8";

   private static final SecretKeySpec keySpec          = new SecretKeySpec( SECRET_KEY.getBytes(), SECURITY_CIPHER );

   /**
    * Encrypt provided string
    * 
    * @param strToEncrypt
    * @param secretKey
    * @return encrypted string
    * @throws Exception
    */
   public static String encrypt( String strToEncrypt ) throws Exception
   {
      String finalEncryptedString = null;
      try
      {
         Cipher cipher = Cipher.getInstance( SECURITY_CIPHER );
         
         if ( cipher != null && StringUtils.isNotEmpty( SECRET_KEY ) && StringUtils.isNotEmpty( strToEncrypt ) )
         {
            cipher.init( Cipher.ENCRYPT_MODE, keySpec );

            byte[] encryptedData = cipher.doFinal( strToEncrypt.getBytes() );

            finalEncryptedString = new String( Base64.encodeBase64( encryptedData ), DEFAULT_ENCODING );
         }
         else
         {
        	 logger.warn( " Unable to process encryption due to missing properties. ");	 
         }
      }
      catch ( InvalidKeyException e )
      {
         logger.error( " Invalid key : " + SECRET_KEY);
         throw e;
      }
      catch ( NoSuchAlgorithmException e )
      {
         logger.error( " No such algorithm found : "+ SECURITY_CIPHER );
         throw e;
      }
      catch( NoSuchPaddingException e )
      {
    	  logger.error(SECURITY_CIPHER + " found, but padding not available: " + e.getMessage());
    	  throw e;
      } catch (Exception ex) {
    	  logger.error("unexpected exception caught while encrypting " + ex.getMessage());
    	  throw ex;
      }

      return finalEncryptedString;
   }

   /**
    * Decrypt provided encrypted string
    * 
    * @param strToDecrypt
    * @param secretKey
    * @return decrypted text
    * @throws Exception
    */
   public static String decrypt( String strToDecrypt ) throws Exception
   {

      String finalDecryptedString = null;

      try
      {
    	 Cipher cipher = Cipher.getInstance( SECURITY_CIPHER );
    	 
         if ( cipher!=null && StringUtils.isNotEmpty(SECRET_KEY ) && StringUtils.isNotEmpty( strToDecrypt ) )
         {
            cipher.init( Cipher.DECRYPT_MODE, keySpec );

            byte[] valueToDecrypt = Base64.decodeBase64( strToDecrypt.getBytes( DEFAULT_ENCODING ) );
            byte[] decryptedText = cipher.doFinal( valueToDecrypt );

            finalDecryptedString = new String( decryptedText, DEFAULT_ENCODING );
         }
         else
         {
        	 logger.warn( " Unable to process decryption due to missing properties. ");
         }
      }
      catch ( InvalidKeyException e )
      {
         logger.error( "Invalid key : " + SECRET_KEY);
         throw e;
      }
      catch ( NoSuchAlgorithmException e )
      {
         logger.error( "No such algorithm found : " + SECURITY_CIPHER);
         throw e;
      }
      catch( NoSuchPaddingException e )
      {
    	  logger.error(SECURITY_CIPHER + " found, but padding not available: " + e.getMessage());
    	  throw e;
      } catch (Exception ex) {
    	  logger.error("unexpected exception caught while decrypting " + ex.getMessage());
    	  throw ex;
      }

      return finalDecryptedString;
   }
}
