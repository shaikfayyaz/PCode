
package com.kohls.common.util;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * This class is used to initialize the resources pool.
 * 
 * @param <T>
 */
public abstract class KohlsResourcePool<T> {
	/**
	 * The queue which contains all of the given resources.
	 */
	private volatile BlockingQueue<T> queue = null;

	/**
	 * The Current Capacity.
	 */
	private int queueCapacity = 0;

	/**
	 * The Maximum Capacity.
	 */
	private int queueMaxCapacity = 0;

	/**
	 * The Minimum Capacity.
	 */
	private int queueMinCapacity = 0;

	/**
	 * Closes the old resouce.
	 * 
	 * @param resource  The resource to close.
	 *           
	 * @throws Exception 
	 */
	protected abstract void closeOldResource(T resource) throws Exception;

	/**
	 * Creates a new resource of the given type.
	 * 
	 * @return A new resource of the given type.
	 * @throws Exception 
	 */
	protected abstract T createNewResource() throws Exception;

	/**
	 * This method attempts to increment the size of the pool by 1.
	 * 
	 * @return The new resource, or NULL if the pool is already the MAX.
	 * @throws Exception 
	 */
	private synchronized T incrementPoolSize() throws Exception {
		T resource = null;
		if (this.queueMaxCapacity > this.queueCapacity) {
			resource = this.createNewResource();
			this.queueCapacity++;
		} 
		return resource;
	}

	/**
	 * Initializes the pool with the minimum amount of resources and also sets
	 * the maximum size to which the pool can grow.
	 * 
	 * @param minSize
	 *            The minimum number of resources to add to the pool.
	 * @param maxSize
	 *            The maximum number of resources the pool can grow to.
	 * @throws Exception Exception
	 */
	public final synchronized void initialize(final int minSize,
			final int maxSize) throws Exception {
		
		if (this.queue == null) {
			if (minSize > maxSize) {
				throw new Exception(
						"The min size is greater than the max size for "
								+ this.getClass().getSimpleName());
			}
			
			this.queue = new LinkedBlockingQueue<T>(maxSize);
			for (short i = 0; i < minSize - this.queueCapacity; i++) {
				this.queue.offer(this.createNewResource());
			}
			this.queueCapacity = minSize;
			this.queueMinCapacity = minSize;
			this.queueMaxCapacity = maxSize;
		} 
	}

	/**
	 * Returns a resource to the pool.
	 * 
	 * @param resource
	 *            The resource to return to the pool.
	 * @throws Exception 
	 */
	public final void returnResource(final T resource) throws Exception {
		synchronized (this) {
			if (this.queue.size() < this.queueMinCapacity) {
				this.queue.offer(resource);
			} else {
				// Assume peak period is over, and Throw object away
				this.queueCapacity--;
				this.closeOldResource(resource);
			}
		}
	}

	/**
	 * Tries to get a resource from the pool. This method will wait the given
	 * amount of time for a resource to become available. If nothing becomes
	 * available during this time, then a new instance is created and returned.
	 * 
	 * @param maxWaitTime
	 *            The max amount of time(ms) to wait for a resource to become
	 *            available.
	 * @return An instance of the resource.
	 * @throws Exception Exception
	 */
	public final T tryGet(final long maxWaitTime) throws Exception {
		T resource = null;
		if (this.queue != null) {
			// Try geting the resource without waiting
			resource = this.queue.poll();
			if (resource == null) {
				// Try geting the resource after waiting
				
				try {
					resource = this.queue.poll(maxWaitTime,
							TimeUnit.MILLISECONDS);
				} catch (InterruptedException e) {
					e = null;
				}
			}
			if (resource == null) {
				// Try to increase the pool size.
				
				resource = this.incrementPoolSize();
			}
			if (resource == null) {
				throw new Exception(
						"No resources became available in the given time period. "
								+ this.getClass().getSimpleName());
			}
			return resource;
		}
		throw new Exception(
				"ce pool is not initialized and therefore "
						+ "no resources are available. "
						+ this.getClass().getSimpleName());
	}

	/**
	 * Get the current size of the pool.
	 * 
	 * @return The current size of the pool.
	 */
	public int size() {
		return queue.size();
	}
	
}