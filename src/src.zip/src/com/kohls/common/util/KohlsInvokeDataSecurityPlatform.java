package com.kohls.common.util;

import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;

import com.protegrity.common.XCException;
import com.protegrity.xcclient.XCAPI;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;

/******************************************************************************************
 * File Name      : KohlsInvokeDataSecurityPlatform.java
 *
 * Description    : This class will return encrypt or decrypt value for given parameter as input and it will connect to server to get return value.
 * Needed input parameters for get encrypt or decrypt vaues are serverHost,dataElement and policyUser.
 *
 * Modification Log :
 * ----------------------------------------------------------------------------------------
 * Ver #   Date          Author            Modification
 * ----------------------------------------------------------------------------------------
 * 0.01    15-05-2015    IBM 		   Initial Version

 * --------------------------------------------------------------------------------------
 *****************************************************************************************/ 
public class KohlsInvokeDataSecurityPlatform {

	/**
	 *  sHostXC to save host details.
	 */
	private static String sHostXC      = null;
	/**
	 * dataElement to save dataElement value.
	 */
	private static  String dataElement  = null;
	/**
	 * policyUser is to save userName.
	 */
	private static String policyUser = null;
	
	/**
	 * declaring reference for XCAPI.
	 */
	// making as nonstatic to support multithreading.
	private XCAPI xc = null;

	/**
	 * LOG variable for logging. 
	 */
	private static final YFCLogCategory LOG = YFCLogCategory.instance(KohlsInvokeDataSecurityPlatform.class.getName());
  
 
/**
 * @param host host
 * @param data data
 * @param user user
 * @throws XCException XCException
 * This method will prepare XCAPI reference and it will opensession to connect server with parameters sHostXC,dataElement and policyUser.
 */
public  void run(String host, String data, String user) throws XCException {
	sHostXC        =	host;
	dataElement   = data;
	policyUser    = user;
    xc = new XCAPI();
    xc.openSession(policyUser, null, sHostXC);
  }

/**
 * @throws XCException
 * This method will responsible for close session which is opend with XCAPI.
 */
public  void closeSession() throws XCException {
	xc.closeSession();
}

/**
 * @param sData sData
 * @return encryptedValue
 * @throws XCException XCException
 * @throws UnsupportedEncodingException
 * This method will return encrypted value for given input parameter. 
 */
public String returnEncryptedValue(String sData) throws XCException, UnsupportedEncodingException {
	if (YFCLogUtil.isDebugEnabled()) {
	      LOG.debug("sData::::::returnEncryptedValue:::::::::::" + sData);
	}
          byte[] policyUserB = policyUser.getBytes(KohlsConstant.XC_CHARSET);
          byte[] dataElementB = dataElement.getBytes(KohlsConstant.XC_CHARSET);
	      byte[] dataB = sData.getBytes(KohlsConstant.XC_CHARSET);
	      byte[] resultBytes = xc.encrypt(KohlsConstant.ENCRYPT_VALUE, policyUserB, dataElementB, dataB); 
	      String encryptedValue = new String(Base64.encodeBase64(resultBytes), KohlsConstant.XC_CHARSET);
	      if (YFCLogUtil.isDebugEnabled()) {
	      LOG.endTimer("KohlsInvokeDataSecurityPlatform :: returnEncryptedValue() --->encryptedValue" + encryptedValue);
	      }
	    return encryptedValue;
	  }
  
  /**
 * @param sData sData
 * @return decrypt value.
 * @throws UnsupportedEncodingException exception
 * @throws XCException
 * This method will responsible for return decrypt value to given input parameter.
 */
public String returnDecryptedValue(String sData) throws UnsupportedEncodingException, XCException {
		if (YFCLogUtil.isDebugEnabled()) {
		      LOG.debug("sData:::::::returnDecryptedValue::::::::::" + sData);
		}
		  
		  byte[] policyUserB = policyUser.getBytes(KohlsConstant.XC_CHARSET);
		  byte[] dataElementB = dataElement.getBytes(KohlsConstant.XC_CHARSET);
		  byte[] dataB = Base64.decodeBase64(sData.getBytes(KohlsConstant.XC_CHARSET));
		  byte[] resultBytes = xc.decrypt(KohlsConstant.DECRYPT_VALUE, policyUserB, dataElementB, dataB); 
	      if (YFCLogUtil.isDebugEnabled()) {
	      LOG.debug("resultBytes:::::::::::::::::" + new String(resultBytes, KohlsConstant.XC_CHARSET));
	      }
	    return new String(resultBytes, KohlsConstant.XC_CHARSET);
  }
  
  
}