
package com.kohls.common.util;

/**
 * This class used to open sessions to the PEP server for the XC JAVA.
 * implementation for Protegrity solution.
 * 
 */
public class KohlsProtegrityConnectionPool extends KohlsResourcePool<KohlsInvokeDataSecurityPlatform> {

	/**
	 * The singleton instnace.
	 */
	private static final KohlsProtegrityConnectionPool POOL = new KohlsProtegrityConnectionPool();

	/**
	 * The user id needed for encryption/decryption rights.
	 */
	private String user = null;

	/**
	 * The URL for the PEP server.
	 */
	private String url = null;
	
	/**
	 * The URL for the PEP server.
	 */
	private String dataElement = null;
	
	

	/**
	 * Initialization of XcJavaSessionPool.
	 */
	private KohlsProtegrityConnectionPool() {
		super();
	}

	/**
	 * Retruns the singleton instance.
	 * 
	 * @return The singleton instance.
	 */
	public static KohlsProtegrityConnectionPool getInstance() {
		return KohlsProtegrityConnectionPool.POOL;
	}

	/*
	 * Create user session.
	 * 
	 * @return The user session.
	 */
	@Override
	protected KohlsInvokeDataSecurityPlatform createNewResource() throws Exception {
		final KohlsInvokeDataSecurityPlatform dataSecurityPlatform = new KohlsInvokeDataSecurityPlatform();
		try {
			dataSecurityPlatform.run(this.url, this.dataElement, this.user);
		} catch (Exception e) {
			
			throw new Exception(e.getLocalizedMessage(), e);
		} 
		return dataSecurityPlatform;
	}

	/**
	 * Sets the URL for the PEP server.
	 * 
	 * @param url
	 *            The URL for the PEP server.
	 */
	public void setUrl(final String url) {
		this.url = url;
	}
	/**
	 * Sets the dataElement needed for encryption/decryption rights.
	 * 
	 * @param dataElement dataElement
	 *            
	 */
	public void setDataElement(String dataElement) {
		this.dataElement = dataElement;
	}

	/**
	 * Sets the user id needed for encryption/decryption rights.
	 * 
	 * @param user
	 *            The user id needed for encryption/decryption rights.
	 */
	public void setUser(final String user) {
		this.user = user;
	}
	

	@Override
	protected void closeOldResource(KohlsInvokeDataSecurityPlatform resource)
			throws Exception {
		resource.closeSession();
	}
}