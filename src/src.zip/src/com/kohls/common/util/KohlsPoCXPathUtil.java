package com.kohls.common.util;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.xpath.CachedXPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * A helper class providing methods for XML document processing.
 * All methods are static, object of this class cannot be created.
 *
 */
public class KohlsPoCXPathUtil   {
    /**
     *	Avoid instantiating an object
     */
  
  private KohlsPoCXPathUtil() {  }    
    	
	/**
	 *	 
	 * Create By TKMACJT * 
	 * @param inXML
	 * @param XPath
	 * samples
	 * inXML <Order/>
	 * Xpath /OrderList/Order
	 * @return
	 * @throws TransformerException
	 */
	
    public static Element getElementByXPath(Document inXML, String XPath)
        throws TransformerException
        {
            Node node = null;
            Element eleNode = null;
            Element eleRoot = null;
            eleRoot = inXML.getDocumentElement();
            CachedXPathAPI oCachedXPathAPI = new CachedXPathAPI();
            node = oCachedXPathAPI.selectSingleNode(inXML, XPath);
            eleNode = (Element)node;
            return eleNode;
  }
    
    public static List getElementListByXpath(Document inXML, String XPath)
        throws ParserConfigurationException, TransformerException
        {
            NodeList nodeList = null;            
            List elementList = new ArrayList();
            CachedXPathAPI aCachedXPathAPI = new CachedXPathAPI();
            nodeList = aCachedXPathAPI.selectNodeList(inXML, XPath);
            int iNodeLength = nodeList.getLength();
            for(int iCount = 0; iCount < iNodeLength; iCount++)
            {
                Node node = nodeList.item(iCount);
                elementList.add(node);
            }

            return elementList;
        }


}
