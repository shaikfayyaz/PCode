package com.kohls.common.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.w3c.dom.NodeList;

import com.kohls.common.util.XPathUtil;

import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

public class KohlsSplitXML extends KOHLSBaseApi{
	
	String strXPath = null;
	String strMergeOutput = null;	  
	String sAPIName = null;
	private  Properties props;
	
	private static final YFCLogCategory	logger = YFCLogCategory.instance(KohlsSplitXML.class.getName());
	
	public  Document splitXML(YFSEnvironment env,Document inXML) throws Exception{		
		// Document docXML = null;
		    Document outXML = null;
		    Document validateXML = null;
		    logger.debug("SplitXML.splitXML -- Begin");
		    try
		    {
		      validateXML = validateParameters(env, inXML);
		      outXML = doSplit(env, validateXML);
		    }
		    catch (YFSException exp)
		    {
		    	if (exp.getClass().getName().equalsIgnoreCase("com.yantra.yfs.japi.YFSException")){		    		
		    		if (exp.getCause() instanceof java.net.ConnectException) { 
						throw new YFCException("EXTN_CONNECT");
					} else if (exp.getCause() instanceof java.io.IOException) {
						throw new YFCException("EXTN_IO");
					} else if (exp.getCause() instanceof javax.xml.soap.SOAPException ||
							exp.getCause() instanceof javax.xml.ws.soap.SOAPFaultException) {
						throw new YFCException("SOAP_EXCEPTION");
					} else {
						throw new YFCException("EXTN_OTHER");
					}
		    	}
		    	
		    	else{
		    		exp.setErrorCode("INVALID_ARGS");
		    	    exp.setErrorDescription("ArgumentsNotDefined");
		    		throw exp;
		    	}
		    	
		    }
		    
		outXML = updateEmailID(env, outXML);
		logger.endTimer("KohlsSplitXML.splitXML");
		return outXML;
	}

	private  Document doSplit(YFSEnvironment env, Document validateXML)throws Exception  {
		// TODO Auto-generated method stub
		Element outEle=null;
		
		try {
			NodeList nl=XPathUtil.getNodeList(validateXML.getDocumentElement(), strXPath);
			for (int i = 0; i <nl.getLength(); i++)
		      {
				logger.debug("Inside For Loop " +i);
				boolean isNullOutPut=false;
				Element tempEle=(Element)nl.item(i);
				Document inDoc=XMLUtil.createDocument(tempEle);
				Document outXML=null;
				if(!YFCCommon.isVoid(sAPIName)){
					outXML=invokeService(env,sAPIName,inDoc);
					}
				if (YFCCommon.isVoid(outXML))
		        {
					isNullOutPut = true;
		        }
				//Commented to make merge output
				if ((strMergeOutput.trim().equalsIgnoreCase("Y"))){
					Element eleMergedOutEle = validateXML.createElement("Output");					
					tempEle.appendChild(eleMergedOutEle);
					if(!(isNullOutPut)){
						Node nodeFromOutput = validateXML.importNode(outXML.getDocumentElement(), true);
						eleMergedOutEle.appendChild(nodeFromOutput);
					}					
				}				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}		
		
		return  validateXML;
	}

	private  Document validateParameters(YFSEnvironment env,
			Document inXML) {
		
		Document validateXML = null;
	    validateXML = inXML;
	    
		// TODO Auto-generated method stub
		if(!YFCCommon.isVoid(props.getProperty("XPATH")))
		{
		strXPath=props.getProperty("XPATH");
		}
		else 
			throw new YFSException("InvalidArguments");
		
		if(!YFCCommon.isVoid(props.getProperty("API_NAME"))||!YFCCommon.isVoid(props.getProperty("SERVICE_NAME")))
		{
			if(!YFCCommon.isVoid(props.getProperty("SERVICE_NAME")))
				sAPIName=props.getProperty("SERVICE_NAME");
			else 
				sAPIName=props.getProperty("API_NAME");
		}
		else 
			throw new YFSException("InvalidArguments");		
		
		if(!YFCCommon.isVoid(props.getProperty("MERGE_OUTPUT")))
		{
			strMergeOutput=props.getProperty("MERGE_OUTPUT");
		}
		else 
			throw new YFSException("InvalidArguments");
		
		if ((!(strMergeOutput.trim().equalsIgnoreCase("Y"))) && (!(strMergeOutput.trim().equalsIgnoreCase("N"))) )
	    {
			throw new YFSException("InvalidArguments");
	    }		
		return validateXML;
	}
		
	public  void setProperties(Properties prop) throws Exception {
		this.props = prop;
	}

	// Method to fetch the referernce code based on the Precedence
	public Document getReferenceCode(YFSEnvironment env) throws Exception {

		String inDoc = "<CommonCode CodeType='POC_ERECEIPTEMAILID' OrganizationCode='KOHLS-RETAIL'> "
				+ "<OrderBy> <Attribute Name='CodeValue' />"
	+               "</OrderBy>" 
+ "</CommonCode>";

		Document outDoc = invokeAPI(env, "getCommonCodeList",
				XMLUtil.getDocument(inDoc));

		return outDoc;

	}

	// Method to update the emial id based on the precedence of reference code

	public Document updateEmailID(YFSEnvironment env, Document inDoc)
			throws Exception

	{
		logger.beginTimer("KohlsSplitXML.updateEmailID");

		NodeList ndlFindMatch = inDoc.getElementsByTagName("ser:findMatch");
		Document docCommonCode = getReferenceCode(env);

		NodeList ndlCustomer = inDoc.getElementsByTagName("ns2:Customer");
		for (int l = 0; l < ndlCustomer.getLength(); l++) {

			Element eleCustomer = (Element) ndlCustomer.item(l);

			NodeList ndlOtherContact = eleCustomer
					.getElementsByTagName("ns2:OtherContact");
			String strEmailID = null;
			Map mapProfileCategoryCode = new HashMap();

			for (int j = 0; j < ndlOtherContact.getLength(); j++) {
				Element eleOtherContact = (Element) ndlOtherContact.item(j);

				NodeList ndlProfileCategoryCode = eleOtherContact
						.getElementsByTagName("ns2:ProfileCategoryCode");

				Element eleProfileCategoryCode = (Element) ndlProfileCategoryCode
						.item(0);
				logger.debug("the profile category code "
						+ eleProfileCategoryCode.getAttribute("referenceCode"));
				NodeList ndlCategoryCode = eleOtherContact
						.getElementsByTagName("ns2:CategoryCode");

				Element eleCategoryCode = (Element) ndlCategoryCode.item(0);
				if (eleCategoryCode != null) {
					if (eleCategoryCode.getAttribute("referenceCode") != null
							&& eleCategoryCode.getAttribute("referenceCode")
									.equals("EML")) {
						logger.debug("the profile category code"
								+ eleProfileCategoryCode
										.getAttribute("referenceCode"));

						NodeList ndlValue = eleOtherContact
								.getElementsByTagName("ns2:Value");

						Element eleValue = (Element) ndlValue.item(0);
						logger.debug("the contains email"
								+ eleValue.getTextContent());
						mapProfileCategoryCode.put(eleProfileCategoryCode
								.getAttribute("referenceCode"), eleValue
								.getTextContent());

					}

				}
			}

			NodeList ndlCommonCode = docCommonCode
					.getElementsByTagName("CommonCode");
			for (int m = 0; m < ndlCommonCode.getLength(); m++) {
				Element eleCommonCode = (Element) ndlCommonCode.item(m);
				logger.debug("the Common Code Value is "
						+ eleCommonCode.getAttribute("CodeShortDescription"));

				if (mapProfileCategoryCode.containsKey(eleCommonCode
						.getAttribute("CodeShortDescription"))) {

					strEmailID = mapProfileCategoryCode.get(
							eleCommonCode.getAttribute("CodeShortDescription"))
							.toString();
					logger.debug("the Email ID is "
							+ mapProfileCategoryCode.get(eleCommonCode
									.getAttribute("CodeShortDescription")));
					Element eleEmailID = inDoc.createElement("ns2:EmailID");
					eleEmailID.setTextContent(strEmailID);
					XMLUtil.appendChild(eleCustomer, eleEmailID);

					break;
				}

			}
			
			if(strEmailID==null || strEmailID.equals("")){
							
							Element eleEmailID = inDoc.createElement("ns2:EmailID");
							 eleEmailID.setTextContent(strEmailID);
								XMLUtil.appendChild(eleCustomer, eleEmailID);
			}
		}
		logger.endTimer("KohlsSplitXML.updateEmailID");

		return inDoc;

	}
}
