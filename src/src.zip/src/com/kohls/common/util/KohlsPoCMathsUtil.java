package com.kohls.common.util;


/**
 *  <B>Important Note:It is strongly recommended to use XPathWrapper instead of this class</B>
 *  An utility class to use the Xpath to access the nodes in a xml document.
 */
public class KohlsPoCMathsUtil {


  /**
   * Calculate9s complement.
   * 
   * @param id the id
   * @return the string
   * @throws Exception the exception
   */
  protected static final String calculate9sComplement( final String id ) throws Exception
  {

     // allowable characters within identifier
     String validChars = "0123456789";
     StringBuffer _9sComplementAsStringBuffer = new StringBuffer( "" );

     int[] _9sComplementArray = new int[id.length()];

     // loop through digits from right to left
     for ( int i = 0; i < id.length(); i++ )
     {

        // set ch to "current" character to be processed
        char ch = id.charAt( id.length() - i - 1 );

        // skip invalid characters
        if ( validChars.indexOf( ch ) == -1 )
        {
           System.out.println( "\"" + ch + "\" is an invalid character" );
           throw new Exception( "\"" + ch + "\" is an invalid character in 9s Complement Checker" );
        }

        // our "digit" is calculated using ASCII value - 48
        int digit = ch - 48;
        _9sComplementArray[id.length() - i - 1] = 9 - digit;
     }

     for ( int x : _9sComplementArray )
     {
        _9sComplementAsStringBuffer.append( x );
     }

     return _9sComplementAsStringBuffer.toString();
  }
  
  /**
   * 
   * @param id the id
   * @return the string
   * @throws Exception the exception
   */
  protected static final String calculate10sComplement( String id ) throws Exception
  {      
     // Validate to make sure there are no special characters
     validateAllDigits( id );
     
     id = id.trim();

     int[] complementArray = new int[id.length()];

     boolean carry = true;

     // loop through digits from right to left
     for ( int i = 0; i < id.length(); i++ )
     {
        // set ch to "current" character to be processed
        int idx = id.length() - i - 1;
        char ch = id.charAt( idx );

        // our "digit" is calculated using ASCII value - 48
        int digit = ch - 48;
        
        int compDigit = 0;

        if ( carry )
        {
           if ( digit != 0 )
           {
              carry = false;
              compDigit = 10 - digit;
           }
        }
        else
        {
           compDigit = 9 - digit;
        }
        
        complementArray[idx] = compDigit;
     }

     StringBuffer buffer = new StringBuffer( "" );

     if ( carry ) // If we were all zeros
        buffer.append( "1" );

     for ( int x : complementArray )
     {
        buffer.append( x );
     }
     return buffer.toString();

  }
  
  private static void validateAllDigits( final String id ) throws Exception
  {
     String trimmedId = id.trim();
     // allowable characters within identifier
     String validChars = "0123456789";

     // loop through digits from right to left
     for ( int i = 0; i < trimmedId.length(); i++ )
     {

        // set ch to "current" character to be processed
        char ch = trimmedId.charAt( trimmedId.length() - i - 1 );

        // skip invalid characters
        if ( validChars.indexOf( ch ) == -1 )
        {
           
           throw new Exception( "\"" + ch + "\" is an invalid character when checking for 10's Complement for \"" + id + "\"" );
        }
     }
  }
  
  protected static int calculateMod10CheckDigit( final String id ) throws Exception
  {

     // allowable characters within identifier
     String validChars = "0123456789";

     // this will be a running total
     int checkSum = 0;

     // loop through digits from right to left
     for ( int i = 0; i < id.length(); i++ )
     {

        // set ch to "current" character to be processed
        char ch = id.charAt( id.length() - i - 1 );

        // throw exception for invalid characters
        if ( validChars.indexOf( ch ) == -1 )
        {
           System.out.println( "\"" + ch + "\" is an invalid character" );
           throw new Exception( "\"" + ch + "\" is an invalid character in Mod 10 Checker" );
        }

        // our "digit" is calculated using ASCII value - 48
        int digit = ch - 48;

        // weight will be the current digit's contribution to
        // the running total
        int weight;
        if ( i % 2 == 0 )
        {
           // for alternating digits starting with the rightmost, we
           // use our formula this is the same as multiplying x 2 and
           // adding digits together for values 0 to 9.
           weight = ( 2 * digit ) - ( digit / 5 ) * 9;

        }
        else
        {
           // even-positioned digits just contribute their ascii
           // value minus 48
           weight = digit;
        }

        // keep a running total of weights
        checkSum += weight;

     }

     // avoid sum less than 10 (if characters below "0" allowed,
     // this could happen)
     checkSum = Math.abs( checkSum ) + 10;

     // check digit is amount needed to reach next number
     // divisible by ten
     return ( 10 - ( checkSum % 10 ) ) % 10;

  }
  
  
  /**
   * Finds the 10's complement of a given number in String format.
   * @param id
   * @return 10's complement is java.lang.String format
   * @throws Exception
   */
  public static final String _10sComplement( final String id ) throws Exception{
     return calculate10sComplement( id );
  }

  /**
   * Finds the 9's complement of a given number in String format.
   * 
   * @param id
   * @return 9's complement is java.lang.String format
   * @throws Exception
   */
  public static final String _9sComplement( final String id ) throws Exception
  {
     return calculate9sComplement( id );
  }

  /**
   * This method will calculate the check digit which is necessary to take the check sum up to a number divisible by ten.
   * 
   * @param idWithoutCheckdigit the id without checkdigit
   * @return the check digit, is the amount necessary to make the resulting check sum (calculated using LUHN or Mod10 Algorithm) up to a number divisible by ten.
   * @throws Exception the exception
   */
  public static final int calculateMod10CheckDigitMod10( final String idWithoutCheckdigit ) throws Exception
  {
     // check digit is amount needed to reach next number
     // divisible by ten
     return calculateMod10CheckDigit( idWithoutCheckdigit );
  }



  /**
   * Validates a single digit to see if it is a Mod10 Check digit. 
   * If the check digit is the last digit in the String then use validateForMod10 API instead
   * 
   * @param checkDigit the check digit
   * @param idWithoutCheckdigit the id without checkdigit
   * @return true, if successful
   * @throws Exception the exception
   */
  public static final boolean validateDigitForMod10( final int checkDigit, final String idWithoutCheckdigit ) throws Exception
  {
     return ( checkDigit == calculateMod10CheckDigit( idWithoutCheckdigit ) );
  }

  /**
   * Validates a given number against LUHN 10 or Mod 10 Algorithm
   * 
   * @param id
   * @return true if "id" passes, else false
   * @throws Exception
   */
  public static final boolean validateForMod10( final String id ) throws Exception
  {
     int idx = id.length() - 1;
     return String.valueOf( calculateMod10CheckDigit( id.substring( 0, idx ) ) ).equalsIgnoreCase( id.substring( idx ) );
  }
  
  public static String generateUPCwithCheckDigit(final String upcWithoutCheckDigit)
  {
       //declare variables
      char char1;
      char char2;
      char char3;
      char char4;
      char char5;
      char char6;
      char char7;
      char char8;
      char char9;
      char char10;
      char char11;
      int num1;
      int num2;
      int num3;
      int num4;
      int num5;
      int num6;
      int num7;
      int num8;
      int num9;
      int num10;
      int num11;
      int step1;
      int step2;
      int step3;
      int step4;
      int step5;
      int step6;
 
      
      //initialize variables
      char1 = upcWithoutCheckDigit.charAt(0);
      num1 = Character.getNumericValue(char1); 
      char2 = upcWithoutCheckDigit.charAt(1);
      num2 = Character.getNumericValue(char2); 
      char3 = upcWithoutCheckDigit.charAt(2);
      num3 = Character.getNumericValue(char3); 
      char4 = upcWithoutCheckDigit.charAt(3);
      num4 = Character.getNumericValue(char4); 
      char5 = upcWithoutCheckDigit.charAt(4);
      num5 = Character.getNumericValue(char5); 
      char6 = upcWithoutCheckDigit.charAt(5);
      num6 = Character.getNumericValue(char6); 
      char7 = upcWithoutCheckDigit.charAt(6);
      num7 = Character.getNumericValue(char7); 
      char8 = upcWithoutCheckDigit.charAt(7);
      num8 = Character.getNumericValue(char8); 
      char9 = upcWithoutCheckDigit.charAt(8);
      num9 = Character.getNumericValue(char9); 
      char10 = upcWithoutCheckDigit.charAt(9);
      num10 = Character.getNumericValue(char10); 
      char11 = upcWithoutCheckDigit.charAt(10);
      num11 = Character.getNumericValue(char11); 
      
      //STEP 1:  add numbers in the odd positions
      step1 = (num1 + num3 + num5 + num7 + num9 + num11);
      
      //STEP 2:  multiply the sum of step 1 by 3
      step2 = (step1 * 3);
      
      
      //STEP 3:  add numbers in the even positions
      step3 = (num2 + num4 + num6 + num8 + num10);
     
      
      //STEP 4:  add the product in step 2 and the sum of step 3
      step4 = (step2 + step3);
      
      //STEP 5:  determine the remainder of step4 / 10
      step5 = (step4 % 10);
      
      //STEP 6:  determine check digit
      step6 = (10 - step5);
 
      return upcWithoutCheckDigit + step6;
	  
  }

  
}
