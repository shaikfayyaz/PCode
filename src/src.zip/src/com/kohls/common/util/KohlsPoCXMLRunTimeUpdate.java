package com.kohls.common.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsPoCXMLRunTimeUpdate implements YIFCustomApi{

   private Properties properties;

   private static YFCLogCategory logger;
   private YIFApi api;


   /**
    * constructor to initialize api
    *
    * @throws YIFClientCreationException
    *
    */
   public KohlsPoCXMLRunTimeUpdate() throws YIFClientCreationException {

      this.api = YIFClientFactory.getInstance().getLocalApi();
   }

   static {
      logger = YFCLogCategory.instance(KohlsPoCXMLRunTimeUpdate.class
            .getName());
   }


   /**
    * @param args
    * @throws Exception
    * @throws IllegalArgumentException
    */
   public static void main(String[] args) throws IllegalArgumentException,
         Exception {



   }

   public Document addDaysToXMLDate(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         String strXpath = properties.getProperty("Xpath");
         String strNoOfDays = properties.getProperty("NumberOfDays");
//       String strXpath = "//OrderLine/OrderStatuses/OrderStatus/Details/@ExpectedShipmentDate";
//       String strNoOfDays = "2";

         NodeList ndList = XPathAPI.selectNodeList(inXML, strXpath);

         for(int i=0; i<ndList.getLength(); i++){
            Node ndNode = ndList.item(i);
            String strNewDate = addDays(ndNode, Integer.parseInt(strNoOfDays));
            ndNode.setNodeValue(strNewDate);

         }//END LOOP -

      } catch (Exception Ex) {
         throw Ex;
      }

      return inXML;

   }// END METHOD addDaysToXMLDate()


   private String addDays(Node ndNode, int iNumberOfDays) throws IllegalArgumentException, Exception {

      String strDate = ndNode.getNodeValue();
      strDate = strDate.replaceAll(":", "");
      logger.debug("Input Date: " + strDate);

      Date dateObject = KohlsDateUtil.convertDate(strDate, "yyyy-MM-dd'T'HHmmssZ");

      Calendar calendar = new GregorianCalendar();
      calendar.setTime(dateObject);

      //Add number of days
      calendar.add(Calendar.DAY_OF_MONTH, iNumberOfDays);
      SimpleDateFormat sdf = new SimpleDateFormat(KohlsConstant.TIMESTAMP_DATEFORMAT1);
      strDate = sdf.format(calendar.getTime());
      logger.debug("New Time is: " + strDate);

      return strDate;

   }

   public Document removeAttributeFromXpath(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         Set setList = (Set) properties.keySet();
         Iterator<String> listIterator = setList.iterator();

         while (listIterator.hasNext()) {
            String strXpath = listIterator.next();
//          String strXpath = "Order/OrderLines/OrderLine/LineCharges/LineCharge/Extn[@ExtnTaxInclusiveUnitPrice]";

            strXpath = properties.getProperty(strXpath);
            String strAttributeName = strXpath.substring(strXpath.lastIndexOf("@")+1, strXpath.lastIndexOf("]"));

            NodeList ndList = XPathAPI.selectNodeList(inXML, strXpath);
            for(int i=0; i<ndList.getLength(); i++){
               Element eleTmp = (Element) ndList.item(i);
               eleTmp.removeAttribute(strAttributeName);
            }//END - NodeList
         }//END While LOOP
      } catch (Exception Ex) {
         throw Ex;
      }

      return inXML;

   }// END METHOD addDaysToXMLDate()




   public Document removeElementFromXPath(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         Set setList = (Set) properties.keySet();
         Iterator<String> listIterator = setList.iterator();

         while (listIterator.hasNext()) {
//          String strXpath = "InvoiceDetail/XrefData";

            String strXpath = listIterator.next();
            strXpath = properties.getProperty(strXpath);
            NodeList ndList = XPathAPI.selectNodeList(inXML, strXpath);
            for(int i=0; i<ndList.getLength(); i++){
               Element eleTmp = (Element) ndList.item(i);
               eleTmp.getParentNode().removeChild(eleTmp);

            }//END - NodeList
         }//END LOOP

      } catch(Exception Ex) {
         throw Ex;
      }

      return inXML;

   }//END METHOD - removeElementFromXPath()


   /** This method will store the input Document into Environment object.
    *
    * @param env
    * @param inXML
    * @return
    * @throws Exception
    */
   public Document putIntoEnvObject(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         String strObjectName = properties.getProperty("ENV_OBJECT_NAME");
         env.setTxnObject(strObjectName, inXML);

      } catch(Exception Ex) {
         throw Ex;
      }

      return inXML;

   }//END METHOD - removeElementFromXPath()


   /** This method wil extract Document object from ENV_OBJECT_NAME.
    * It will fetch NodeList matching ENV_MERGE_XPATH from above document and merge it
    * into INPUT_MERGE_XPATH of input document.
    *
    * @param env
    * @param inXML
    * @return
    * @throws Exception
    */
   public Document mergeEnvObject(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         String strObjectName = properties.getProperty("ENV_OBJECT_NAME");
         Object obj = env.getTxnObject(strObjectName);

         if(obj != null ){

            String strInputMergeXpath = properties.getProperty("INPUT_MERGE_XPATH");
            String strEnvMergeXpath = properties.getProperty("ENV_MERGE_XPATH");

            Document docEnvObject = (Document) obj;
            Node ndParent = XPathAPI.selectSingleNode(inXML, strInputMergeXpath);
            NodeList nlList = XPathAPI.selectNodeList(docEnvObject, strEnvMergeXpath);

            for(int i=0; i<nlList.getLength(); i++){
               Node ndtmp = inXML.importNode(nlList.item(i), true);
               ndParent.appendChild(ndtmp);

            }//END LOOP
         }//END IF -

      } catch(Exception Ex) {
         throw Ex;
      }

      return inXML;

   }//END METHOD - removeElementFromXPath()





   /** This method will rename the Element and/or Attribute name and return updated XML.
    *
    * Usage: Set API Argument Name/value pair as below
    *        properties.setProperty("Path_03", "InvoiceDetail/InvoiceHeader/LineDetails/LineDetail/OrderLine  --> NewOrderLine");
    properties.setProperty("Path_01", "InvoiceDetail/InvoiceHeader/LineDetails/LineDetail/@Charges --> Charges_New");
    properties.setProperty("Path_02", "InvoiceDetail/InvoiceHeader/LineDetails/LineDetail/@ExtendedPrice --> ExtendedPrice_New");

    * @param env
    * @param inXML
    * @return
    * @throws Exception
    */
   public Document renameXpathElementOrAttribute(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         Set setList = (Set) properties.keySet();
         Iterator<String> listIterator = setList.iterator();

         while (listIterator.hasNext()) {
            String strXpath = listIterator.next();
            strXpath = properties.getProperty(strXpath);

            logger.debug("strXpath: " + strXpath);
            String strXpathLevel = strXpath.substring(0, strXpath.indexOf("-->")).trim();
            String strNewName = strXpath.substring(strXpath.indexOf("-->") + 3).trim();

            logger.debug("strXpathLevel: " + strXpathLevel);

            NodeList ndList = XPathAPI.selectNodeList(inXML, strXpathLevel);
            for(int i=0; i<ndList.getLength(); i++){

               Node ndTmp = ndList.item(i);
               logger.debug("Renaming " + ndTmp.getNodeName());

               inXML.renameNode(ndTmp, ndTmp.getNamespaceURI(), strNewName);

            }//END - NodeList
         }//END While LOOP
      } catch (Exception Ex) {
         throw Ex;
      }

      return inXML;

   }// END METHOD renameXpathElementOrAttribute()


   public Document addRootToXML(
         YFSEnvironment env,
         Document inXML) throws Exception {
      try {

         String strXpath = properties.getProperty("newroot");
         if(!YFCCommon.isVoid(strXpath)){

            String docXMLString ="<"+strXpath+">"+ XMLUtil.getElementXMLString(inXML.getDocumentElement())+"</"+strXpath+">";
            inXML = XMLUtil.getDocument(docXMLString);

         }


      } catch (Exception Ex) {
         throw Ex;
      }


      return inXML;

   }//END METHOD - addRootToXML()


   public Document updateAttributeFromAttribute(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

         Set setList = (Set) properties.keySet();
         Iterator<String> listIterator = setList.iterator();

         while (listIterator.hasNext()) {
            String strXpathDest = listIterator.next();
            // sample property
            //OrderRelease[@ShipNode]=/OrderRelease/Order/OrderLineRelationships/OrderLineRelationship/OrderReleaseList/OrderRelease[@ShipNode]
            String strDestAttributeName = strXpathDest.substring(strXpathDest.lastIndexOf("@")+1, strXpathDest.lastIndexOf("]"));

            String strXpathSrc = properties.getProperty(strXpathDest);
            String strSrcAttributeName = strXpathSrc.substring(strXpathSrc.lastIndexOf("@")+1, strXpathSrc.lastIndexOf("]"));

            NodeList ndDestList = XPathAPI.selectNodeList(inXML, strXpathDest);
            NodeList ndSrcList = XPathAPI.selectNodeList(inXML, strXpathSrc);
            if(ndDestList.getLength() != ndSrcList.getLength()){
               for(int i=0; i<ndDestList.getLength(); i++){
                  Element eleTmp = (Element) ndDestList.item(i);
                  Element srcTmp = (Element) ndSrcList.item(0);
                  eleTmp.setAttribute(strDestAttributeName,srcTmp.getAttribute(strSrcAttributeName));
               }

            }else{
               for(int i=0; i<ndDestList.getLength(); i++){
                  Element eleTmp = (Element) ndDestList.item(i);
                  Element srcTmp = (Element) ndSrcList.item(i);
                  eleTmp.setAttribute(strDestAttributeName,srcTmp.getAttribute(strSrcAttributeName));
               }
            }

         }//END While LOOP
      } catch (Exception Ex) {
         throw Ex;
      }

      return inXML;

   }// END METHOD updateAttributeFromAttribute()

   /** This method will copy Attribute or Element from source XML level to TARGET. Return updated XML.
    *
    * Usage: Set API Argument Name/value pair as below
    *        properties.setProperty("SOURCE", "OrderRelease/OrderLine/LinePackListPriceInfo/LineCharges/LineCharge/@IsDiscount");
    properties.setProperty("TARGET", "../../LineTaxes/LineTax[CONDITION_1]");
    properties.setProperty("CONDITION_1", "@ChargeCategory='MATCH_CHARGE_CAT' and @ChargeName='MATCH_CHARGE_NAME'");
    properties.setProperty("MATCH_CHARGE_CAT", "@ChargeCategory");
    properties.setProperty("MATCH_CHARGE_NAME", "@ChargeName");

    1) TARGET Xpath is relative to SOURCE Xpath
    2) CONDITION and MATCH is optional and should be used only if conditional matching needs to be performed.
    3) This method currently supports Atribute copy only. It does not support Element copy.

    * @param env
    * @param inXML
    * @return
    * @throws Exception
    */
   public Document copyXPathAttributeOrElement(
         YFSEnvironment env,
         Document inXML) throws Exception {

      try {

//       properties = new Properties();
//       properties.setProperty("SOURCE", "OrderRelease/OrderLine/LinePackListPriceInfo/LineCharges/LineCharge/@IsDiscount");
//       properties.setProperty("TARGET", "../../LineTaxes/LineTax[CONDITION_1]");
//       properties.setProperty("CONDITION_1", "@ChargeCategory='MATCH_CHARGE_CAT' and @ChargeName='MATCH_CHARGE_NAME'");
//       properties.setProperty("MATCH_CHARGE_CAT", "@ChargeCategory");
//       properties.setProperty("MATCH_CHARGE_NAME", "@ChargeName");

         String strSourceXpath = properties.getProperty("SOURCE");
         String strTargetXpath = properties.getProperty("TARGET");

         NodeList ndSourceList = XPathAPI.selectNodeList(inXML, strSourceXpath);
         logger.debug("Fetching source node list " + ndSourceList.getLength());

         for(int iSourceCounter=0; iSourceCounter<ndSourceList.getLength(); iSourceCounter++){

            Node ndTmp = ndSourceList.item(iSourceCounter);

            String strSourceFieldName = ndTmp.getNodeName();
            String strSourceFieldValue = ndTmp.getNodeValue();
            logger.debug("Field To Copy::" + strSourceFieldName + "=" + strSourceFieldValue);

            Node ndParentNode_Source = ((Attr) ndTmp).getOwnerElement();


            strTargetXpath = applyConditionsToTargetXpath(strTargetXpath, (Element) ndParentNode_Source);
            logger.debug("Final strTargetXpath: " + strTargetXpath);

            NodeList ndTargetList = XPathAPI.selectNodeList(ndParentNode_Source, strTargetXpath);
            logger.debug("Fetching Destination node list " + ndSourceList.getLength());

            for(int iTargetCounter=0; iTargetCounter<ndTargetList.getLength(); iTargetCounter++){
               Element eleTmp_Target = (Element) ndTargetList.item(iTargetCounter);
               eleTmp_Target.setAttribute(strSourceFieldName, strSourceFieldValue);

            }//END - TARGET NodeList
         }//END Loop - SOURCE NodeList

      } catch (Exception Ex) {
         throw Ex;
      }

      return inXML;

   }// END METHOD copyXPathAttributeOrElement()


   /**
    * @param strTargetXpath
    * @return
    * @throws TransformerException
    */
   private String applyConditionsToTargetXpath(
         String strTargetXpath,
         Element eleInput) throws TransformerException {

      Set setList = (Set) properties.keySet();

      HashMap<String, String> alMatchList = new HashMap<String, String>();
      HashMap<String, String> alConditionList = new HashMap<String, String>();

      alMatchList = processLoop(setList.iterator(), null, eleInput, "MATCH", false);
      logger.debug("alMatchList: " + alMatchList);

      if(alMatchList.size() > 0) {
         logger.debug("Process Conditions");
         alConditionList = processLoop(setList.iterator(), alMatchList, eleInput, "CONDITION", true);
         logger.debug("alConditionList: " + alConditionList);

      }

      if(alConditionList.size() > 0 || alMatchList.size() > 0) {

         if(alConditionList.size() < 1) {
            alConditionList = alMatchList;
         }

         logger.debug("Process Target");
         HashMap<String, String> alTARGETList = processLoop(setList.iterator(), alConditionList, eleInput, "TARGET", true);
         logger.debug("alTARGETList: " + alTARGETList);

         strTargetXpath = alTARGETList.get("TARGET");

      }

      return strTargetXpath;
   }



   /**
    * @param alInputList
    * @param eleInput
    * @throws TransformerException
    */
   private HashMap<String, String> processLoop(
         Iterator<String> listIterator,
         HashMap<String, String> alInputList,
         Element eleInput,
         String strMatchString,
         boolean bReplaceFlag) throws TransformerException {

      HashMap<String, String> alOutputList = new HashMap<String, String>();

      while (listIterator.hasNext()) {

         String strName = listIterator.next();
         logger.debug("* Processing ArgumentName: " + strName );

         if(strName.startsWith(strMatchString)) {

            String strValue = properties.getProperty(strName);
            logger.debug("** Processing Name: " + strName + " Value: " + strValue);

            if (!bReplaceFlag) {
               Node ndtmp = XPathAPI.selectSingleNode(eleInput, strValue);

               if (ndtmp != null){
                  strValue = ndtmp.getNodeValue();

               } else {
                  strValue = "";
               }

            } else {
               //Replace value

               Set setList = (Set) alInputList.keySet();
               Iterator<String> tmpIterator = setList.iterator();

               while (tmpIterator.hasNext()) {
                  String strName_1 = tmpIterator.next();
                  String strValue_1 = alInputList.get(strName_1);
                  logger.debug("** Replacing strName_1: " + strName_1 + " with strValue_1: " + strValue_1);

                  strValue = strValue.replaceAll(strName_1, strValue_1);

               }
            }

            alOutputList.put(strName, strValue);

         }//END Loop - MATCH

      }//END LOOP - Process MATCH Records.

      return alOutputList;

   }



   // US-1603 Start
   /**
    * @Description Put an attribute at the root level of the xml, using the
    *              property for the name, and the environment for the value.
    * @param env
    * @param inXML
    * @return Document
    * @throws Exception
    */
   public Document setAttrbFromEnvObj(YFSEnvironment env, Document inXML)
         throws Exception {

      Set setList = (Set) properties.keySet();
      Iterator<String> listIterator = setList.iterator();
      Element elmtRoot = inXML.getDocumentElement();
      Object objEnv;

      // Go through all of the properties
      while (listIterator.hasNext()) {

         // Get the property name
         String strEnvArg = listIterator.next();

         // Get the property value
         strEnvArg = properties.getProperty(strEnvArg);

         // Get the environment value based on the property value
         objEnv = env.getTxnObject(strEnvArg);

         // Check if that environment key even existed
         if (!YFCCommon.isVoid(objEnv)) {

            // Set the root attribute with the property value and
            // environment value.
            elmtRoot.setAttribute(strEnvArg, (String) objEnv);
         }

      }
      return inXML;
   }
   // US-1603 End


   public void setProperties(Properties arg0) throws Exception {
      properties = arg0;

   }


   /**Private method to split the attribute names based on "," character
    *
    * @param attributeName
    * @param delimetedAttributeNames
    * @return
    */
   private String[] getDelimitedAttributes(String attributeName, String[] delimetedAttributeNames) {
      if(attributeName.contains(",")){
         delimetedAttributeNames = attributeName.split(",");
      }else{
         delimetedAttributeNames[0]=attributeName;
      }
      return delimetedAttributeNames;
   }

   /**
    * Private method to remove all the matching modification types.
    *
    * @param modTypeQualifiers
    * @param inDoc
    * @throws ParserConfigurationException
    * @throws TransformerException
    * @throws DOMException
    */
   private void removeMatchingModificationTypes(
         List<String> modTypeQualifiers, Document inDoc)
         throws ParserConfigurationException, TransformerException,
         DOMException {
      if(!modTypeQualifiers.isEmpty()){
         Iterator<String> modTypeItr = modTypeQualifiers.iterator();
         while(modTypeItr.hasNext()){
            String modType = modTypeItr.next();
            List<Element> modTypesList =KohlsPoCXPathUtil.getElementListByXpath(inDoc,
                  "//OrderAuditLevel/ModificationTypes/ModificationType[@Name="+"'"+modType+"']");
            for(Element toDelEle:modTypesList){
               if(toDelEle != null){
                  toDelEle.getParentNode().removeChild(toDelEle);
               }
            }
         }
      }
   }

   /**
    * Private method to delete empty elements.
    * Elements of type Node having no children.
    *
    * @param parentElement
    */
   private void removeEmptyChildElements(Element parentElement) {
      List<Element> toRemove = new ArrayList<Element>();
      NodeList children = parentElement.getChildNodes();
      int childrenCount = children.getLength();
      for (int i = 0; i < childrenCount; i++) {
         Node child = children.item(i);
         if (child != null){
            if(child.getNodeType() == Node.ELEMENT_NODE) {
               Element childElement = (Element) child;
               removeEmptyChildElements(childElement);
               if (isEmptyTextNodes(childElement)) {
                  toRemove.add(childElement);
               }
            }
         }
      }
      for (Element element: toRemove) {
         element.getParentNode().removeChild(element);
      }
   }
   /**
    * Private method to check for empty text nodes.
    *
    * @param element
    * @return
    */
   private boolean isEmptyTextNodes(Element element) {
      boolean canDeleteparent = true;
      if (element.hasAttributes())  return false;
      if (!element.hasChildNodes()) return true;
      NodeList children = element.getChildNodes();
      for(int i=0;i<children.getLength();i++){
         Node child = children.item(i);
         if(child.getNodeType() != Node.TEXT_NODE){
            canDeleteparent = canDeleteparent  & false;
         }else{
            canDeleteparent = canDeleteparent & true;
         }
      }
      return canDeleteparent;
   }

   /**
    * Public method to remove special characters from the input
    *
    * @param env
    * @param docIp
    * @return Document
    */

   public Document removeSpecialChars(YFSEnvironment env, Document docIp) {

      Set propsSet = properties.keySet();
      Iterator itr = propsSet.iterator();
      String strSplCharsRem = "";
      /*
       * Below while loop is to iterate through set of properties configured
       * as argument for this custom api, get corresponding values and invoke
       * method in KohlsRemoveUtil class to replace special characters in
       * different elements or attribute
       */
      String strCodeValue = properties.getProperty("CommonCodeToCall");
      // Calling getCommonCodeList to get special characters corresponding to
      // element or attribute specified in strAttributeToBeCorrected argument
      String strNotSplChars = callGetCommonCodeList(strCodeValue, env);

      if (!YFCCommon.isVoid(strNotSplChars)) {

         strSplCharsRem = prepareRegExp(strNotSplChars);
         logger.debug("Regular expression prepared is:" + strSplCharsRem);
      }
      while (itr.hasNext()) {
         String strAttributeName = null;
         String strXPath = null;
         String strPropName = (String) itr.next();
         if (!YFCCommon.isVoid(strPropName)) {
            String propValue = properties.getProperty(strPropName);
            logger.debug(":Property name is:" + strPropName
                  + ":Property value is:" + propValue);
            if (strPropName.contains(KohlsConstant.A_ATTRIBUTE)) {
               String propValueArr[] = propValue.split(KohlsConstant.TILD);
               int iArrLength = 0;
               if (!YFCCommon.isVoid(propValueArr)) {
                  iArrLength = propValueArr.length;
               }
               strCodeValue = strPropName;
               if (iArrLength == 2) {
                  strAttributeName = propValueArr[0];
                  strXPath = propValueArr[1];
               }
            }
         }
         logger.debug(":Attribute name is:" + strAttributeName
               + ":Code Value is:" + strCodeValue + ":xpath is:"
               + strXPath);
         removeSpecialCharacters(strAttributeName, strSplCharsRem, strXPath,
               docIp);
      }
      logger.debug("docIp in RemoveSpecialCharacters is:"
            + KohlsXMLUtil.getXMLString(docIp));
      return docIp;
   }

   /**
    * Method that prepares Regular expression based on short description
    * obtained for corresponding common code value and returns it
    *
    * @param strArr
    * @return String
    */
   private String prepareRegExp(String strArr) {
      String strSplCharsRem = "";
      strSplCharsRem += KohlsConstant.OPEN_SQ_BRACKET + KohlsConstant.CARET + KohlsConstant.STR_SPACE;
         String strSplCharsArr[] = strArr.split(KohlsConstant.COMMA);
         for (String strChar : strSplCharsArr) {
               strSplCharsRem += KohlsConstant.CARET;

            if (KohlsConstant.DBL_QUOTE.equals(strChar)) {
               strSplCharsRem += KohlsConstant.SGL_BACK_SLASH;
            }

            strSplCharsRem += strChar;
         }

      strSplCharsRem += KohlsConstant.CLOSE_SQ_BRACKET;
      return strSplCharsRem;
   }

   /**
    * Method to remove special characters, When special chars needs to be
    * removed from argument then third argument of this method will have xpath
    * to repeatable element and Fourth argument will have name of actual
    * element on which attribute needs to be updated
    *
    * @param strAttributeToBeCorrected
    * @param strXpathWhrAttrCorrected
    * @param docIp
    *
    */
   private void removeSpecialCharacters(String strAttributeToBeCorrected,
                               String strSplCharsRem, String strXpathWhrAttrCorrected,
                               Document docIp) {
      Element eleIp = docIp.getDocumentElement();
      String strToBeCorrected = "";
      if (!YFCCommon.isVoid(strAttributeToBeCorrected)) {
         // If element that needs to be corrected is a particular
         // element(which is not repeatable element) at a certain xpath then
         // below logic gets executed
         if (!YFCCommon.isVoid(strXpathWhrAttrCorrected)) {
            try {
               Element eleToBeCorrected = KohlsXMLUtil.getElementByXpath(
                     docIp, strXpathWhrAttrCorrected);
               if(!YFCCommon.isVoid(eleToBeCorrected)) {
                  strToBeCorrected = eleToBeCorrected
                        .getAttribute(strAttributeToBeCorrected);
               }
               if(!YFCCommon.isVoid(strToBeCorrected)) {
                  String strCorrected = identifyNReplaceSpecialCharsInString(
                        strSplCharsRem, strToBeCorrected);
                  eleToBeCorrected.setAttribute(strAttributeToBeCorrected,
                        strCorrected);
               }
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      }

   }

   /**
    * Method to identify and replace any special characters in given String
    *
    * @param strSplCharsRem
    * @param strToBeCorrected
    * @return String
    */
   private String identifyNReplaceSpecialCharsInString(String strSplCharsRem,
                                          String strToBeCorrected) {
      Matcher m = matchingLogic(strSplCharsRem, strToBeCorrected);
      String strSplCharsSlashApp = "*+?/";
      while (m.find()) {
         String strChar = m.group();
         if (strSplCharsSlashApp.contains(strChar)) {
            String strToBeReplaced = KohlsConstant.DBL_SLASH + strChar;
            strToBeCorrected = strToBeCorrected.replaceAll(strToBeReplaced,
                  KohlsConstant.BLANK_SPACE);
         } else {
            strToBeCorrected = strToBeCorrected.replaceAll(strChar,
                  KohlsConstant.BLANK_SPACE);
         }
      }
      return strToBeCorrected;
   }

   /**
    * Using pattern matching it will identify all the instances in which
    * special characters are present
    *
    * @param strRegex
    * @param strLine
    * @return Matcher
    */
   private static Matcher matchingLogic(String strRegex, String strLine) {
      Pattern pat = Pattern.compile(strRegex);
      Matcher match = pat.matcher(strLine);
      return match;
   }

   /**
    * Method to prepare input xml and call getCommonCodeList and return
    * required attribute
    *
    * @param strCodeValue
    * @param env
    * @return String
    */
   private String callGetCommonCodeList(String strCodeValue, YFSEnvironment env) {
      Document docOp = null;
      String strCodeVal = null;
      try {
         Document docIp = KohlsXMLUtil
               .createDocument(KohlsConstant.E_COMMON_CODE);
         Element eleIp = docIp.getDocumentElement();

         eleIp.setAttribute(KohlsConstant.A_CODE_VALUE, strCodeValue);
         docOp = api.getCommonCodeList(env, docIp);

         Element eleCommonCodeOp = docOp.getDocumentElement();
         NodeList nlCommonCode = KohlsXPathUtil.getNodeList(eleCommonCodeOp,
               "//CommonCodeList/CommonCode[@CodeValue='" + strCodeValue
                     + "']");

         if (!YFCCommon.isVoid(nlCommonCode) && nlCommonCode.getLength() > 0) {
            Element eleCommonCode = (Element) nlCommonCode.item(0);
            // Getting value of CodeShortDescription
            strCodeVal = eleCommonCode
                  .getAttribute(KohlsConstant.A_CODE_LONG_DESC);

         }
      } catch (Exception e) {
         e.printStackTrace();
      }

      return strCodeVal;
   }

}// END CLASS
