/*
 * File: KohlsPOCXMLMergeByAPI.java  Created on Jun 15, 2017 for OMSR3 by TKMACJT
 *
 * COPYRIGHT:
 * LICENSED MATERIALS - PROPERTY OF Kohls Stores
 * "RESTRICTED MATERIALS OF Kohls Stores"
 *
 * Change Activity Log
 * 
 * Reason  		Date     		Who Descriptions
 * ------- 		-------- 		--- -----------
 */
package com.kohls.common.util;

/**
 * @author TKMACJT
 *
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;


import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * This API will merge the input document with the input args document set
 * during the service definition and call the Standard API passed as an input in
 * the args and append the output passed Element
 * 
 * @author 
 */

public class KohlsPOCXMLMergeByAPI implements YIFCustomApi
{

    private final String API_NAME      = "APIName";//OOB API
    private final String APPEND        = "Append"; // The value of APPEND can be A/CR/R
    private final String OUTPUT_XPATH  = "OutputXPath"; //The level at which the output of OOB API should be appended   
    private final String INPUT_XPATH   = "InputXPath";//This will provide the XPath to the OOB API/ Service input.  
    private final String SERVICE_NAME  = "ServiceName"; // Configured Service Name 
    private final String API_TEMPLATE  = "APITemplate";// Template Name of calling API with relative path.
    
    private final String IS_APPEND_VALUE_REPLACE          = "R";// R = Replace
    private final String IS_APPEND_VALUE_COMPLETE_REPLACE = "CR";// CR = Complete Replace
    private final String IS_APPEND_VALUE_APPEND           = "A";// A = Append Only
    
    private Properties props;
    private static YFCLogCategory logger;

    static {
      logger = YFCLogCategory.instance(KohlsPOCXMLMergeByAPI.class.getName());
    }




    public void setProperties(Properties props) throws Exception
    {
        this.props = props;
    }

    public final Document invoke(final YFSEnvironment env, final Document inXMLDoc) throws Exception
    {

        logger.beginTimer("KohlsXMLMerge :: invoke :: Begin");
        logger.debug("KohlsXMLMerge :: invoke :: Input Document\n", XMLUtil.getXMLString(inXMLDoc));
        
        Document inDoc = inXMLDoc;
        
        String sAPIName = this.props.getProperty(API_NAME);
        String sServiceName = this.props.getProperty(SERVICE_NAME);
        String sAppend = this.props.getProperty(APPEND);
        String sOutputXPath = this.props.getProperty(OUTPUT_XPATH);     
        String sInputXPath = this.props.getProperty(INPUT_XPATH);
        String sAPITemplate = this.props.getProperty(API_TEMPLATE);

        logger.debug("KohlsXMLMerge :: Input Args ==> apiName = " + sAPIName + ";serviceName = " 
                + sServiceName + "; isAppend = " + sAppend + " ; " + "sOutputXPath = "
                + sOutputXPath + " ; inputXPath = " + sInputXPath);

        if(YFCCommon.isVoid(sAPIName) && YFCCommon.isVoid(sServiceName))
        {
          raiseInvalidInputException("ServicenName Or Api");       
        }
        
        if(YFCCommon.isVoid(sAppend) || !(sAppend.equals(IS_APPEND_VALUE_APPEND) || 
                sAppend.equals(IS_APPEND_VALUE_COMPLETE_REPLACE) || sAppend.equals(IS_APPEND_VALUE_REPLACE) ) )
        {
          raiseInvalidInputException("ServicenName Or Api");
        }
        
        if(YFCCommon.isVoid(sInputXPath)){           
          raiseInvalidInputException("ServicenName Or Api");
        }

        List<Document> listOfInputDocs = createListofInDocForInputXPath(inDoc, sInputXPath);

        List<Document> listOfOutputDocs = new ArrayList<Document>();
        Document apiOutputDoc = null;

        for (Document inputApiDoc : listOfInputDocs)
        {
            if (!YFCCommon.isVoid(sAPIName))
            {
                //calling configured OOB API
                logger.debug("KohlsXMLMerge :: invoke <=> API name ==> " + sAPIName + " Input doc is ==>"
                        + KohlsXMLUtil.getXMLString(inputApiDoc));
                if(YFCCommon.isVoid(sAPITemplate))
                {
                    //calling OOB API without template
                    apiOutputDoc = KOHLSBaseApi.invokeAPI(env, sAPIName, inputApiDoc);
                }
                
                else
                {
                    //calling OOB API with template
                    apiOutputDoc = KOHLSBaseApi.invokeAPI(env, sAPITemplate,sAPIName,inputApiDoc);
                }
                
                logger.debug("KohlsXMLMerge :: invoke <=>  Output doc is ==>" + KohlsXMLUtil.getXMLString(apiOutputDoc));
            }

            else if(!YFCCommon.isVoid(sServiceName))
            {
                //calling configured Service
                logger.debug("KohlsXMLMerge :: invokeService <=> Service name ==> " + sServiceName + " Input doc is ==>"
                        + KohlsXMLUtil.getXMLString(inputApiDoc));
                apiOutputDoc = KOHLSBaseApi.invokeService(env, sServiceName, inputApiDoc);
                //US - 7802 -UPS Flex returns
                if(!YFCCommon.isVoid(apiOutputDoc))
                    logger.debug("KohlsXMLMerge :: invokeService <=> Output doc is ==>" + KohlsXMLUtil.getXMLString(apiOutputDoc));
            }
            //US - 7802 -UPS Flex returns
            if(!YFCCommon.isVoid(apiOutputDoc))
                listOfOutputDocs.add(apiOutputDoc);
        }//end of For

        Document finalOutputDoc = inDoc;
        if (listOfOutputDocs.size() > 0) 
        {
            finalOutputDoc = appendElementToXPathElement(inDoc, sOutputXPath, listOfOutputDocs, sAppend, sInputXPath);
        }

        logger.debug("KohlsXMLMerge :: invoke <=> Final output doc is ==>" + KohlsXMLUtil.getXMLString(finalOutputDoc));
        logger.endTimer("KohlsXMLMerge :: invoke :: End");
        return finalOutputDoc;

    }

    /**
     * Returns the list of new document of InputXPath element 
     * @param inDoc
     * @param inputXPath
     * @return listOfDocumentObj
     * @throws Exception
     */

    private List<Document> createListofInDocForInputXPath(Document inDoc, String inputXPath) throws Exception
    {
        
        List<Element> listOfElms = KohlsXMLUtil.getElementListByXpath(inDoc, inputXPath);
        List<Document> listOfDocumentObj = new ArrayList<Document>();

        Document docInputXPath = KohlsXMLUtil.newDocument();
        
        for (Element eleInputXPath : listOfElms) 
        {
            if (eleInputXPath != null) 
            {
                logger.debug("KohlsXMLMerge :: createListofInDocForInputXPath :: outputElement\n "+KohlsXMLUtil.getElementXMLString(eleInputXPath));
                docInputXPath = KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(eleInputXPath));
                
                logger.debug("KohlsXMLMerge :: createListofInDocForInputXPath :: outputDoc",KohlsXMLUtil.getXMLString(docInputXPath));
                
                listOfDocumentObj.add(docInputXPath);
            }
        }
        
        return listOfDocumentObj;
    }

    /**
     * Append the API/Service output based on configured values of "Append" and "OutputXPath" arguments
     * @param inDoc
     * @param sOutputXPath
     * @param listOfSourceDocs
     * @param sAppend
     * @param sInputXPath 
     * @return inDoc
     * @throws Exception
     */

    private Document appendElementToXPathElement(Document inDoc, String sOutputXPath, 
            List<Document> listOfSourceDocs, String sAppend, String sInputXPath)throws Exception
    {   
        logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: Input Document" + inDoc);
        Element eleRoot = inDoc.getDocumentElement();
        String nodeName = eleRoot.getNodeName();

        Node node = null;
        
        if(IS_APPEND_VALUE_APPEND.equals(sAppend)){ 
            //If the Value of Apppend is A
            logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: First IF");
            if (YFCCommon.isVoid(sOutputXPath)){
                // If the value of OutputXPath is not configured then append in the parent of input XML of API/Service
                node = XPathAPI.selectSingleNode(inDoc, sInputXPath);
                Node nodeParent = node.getParentNode();
                if(!YFCCommon.isVoid(nodeParent) && !nodeParent.getNodeName().equals("#document"))
                {
                    node = nodeParent;
                }
            }
            else{
                //Assign the value of node to OutputXPath
                node = XPathAPI.selectSingleNode(inDoc, sOutputXPath);
            }
        }
        else if (IS_APPEND_VALUE_COMPLETE_REPLACE.equals(sAppend)) {
            //If the Value of Apppend is CR
            logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: Second IF");         
            inDoc = null;
            inDoc = KohlsXMLUtil.createDocument(nodeName);
            node = inDoc.getDocumentElement();
        }
        
        else if(IS_APPEND_VALUE_REPLACE.equals(sAppend))
        {
            //If the Value of Apppend is R
            logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: Third IF");
            Element eleToRemove = KohlsPoCXPathUtil.getElementByXPath(inDoc, sInputXPath);
            Element eleParentNode = (Element) eleToRemove.getParentNode();
            eleParentNode.removeChild(eleToRemove);
            node = eleParentNode;
        }
        
        for (Document srcDoc : listOfSourceDocs) 
        {
            logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: srcDoc\n",KohlsXMLUtil.getXMLString(srcDoc));
            logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: outDoc\n",KohlsXMLUtil.getXMLString(inDoc));
            logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: node name :: "+node.getNodeName());
            Node nodeToAppend = inDoc.importNode(srcDoc.getDocumentElement(), true);                        
            node.appendChild(nodeToAppend);
        }
        logger.debug("KohlsXMLMerge :: appendElementToXPathElement :: Output Document" + inDoc);
        return inDoc;
    }
    
    
    public final Document invokeByElement(final YFSEnvironment env, final Document inDoc) throws Exception
    {

        
        
        String sAPIName = this.props.getProperty(API_NAME);
        String sServiceName = this.props.getProperty(SERVICE_NAME);
        String sAppend = this.props.getProperty(APPEND);
        String sOutputXPath = this.props.getProperty(OUTPUT_XPATH);     
        String sInputXPath = this.props.getProperty(INPUT_XPATH);
        String sAPITemplate = this.props.getProperty(API_TEMPLATE);
        
        
        if(YFCCommon.isVoid(sAPIName) && YFCCommon.isVoid(sServiceName))
        {
          raiseInvalidInputException("ServicenName Or Api");   
        }
        
        if(YFCCommon.isVoid(sAppend) || !(sAppend.equals(IS_APPEND_VALUE_APPEND) || 
                sAppend.equals(IS_APPEND_VALUE_COMPLETE_REPLACE) || sAppend.equals(IS_APPEND_VALUE_REPLACE) ) )
        {
          raiseInvalidInputException("ServicenName Or Api");        
        }
        
        if(YFCCommon.isVoid(sInputXPath)){           
          raiseInvalidInputException("ServicenName Or Api");
        }
        //List<Document> listOfInputDocs = createListofInDocForInputXPath(inDoc, sInputXPath);
        List<Element> listOfInputElements = KohlsXMLUtil.getElementListByXpath(inDoc,
                sInputXPath);

        
        Document apiOutputDoc = null;

        for (Element inputApiEle : listOfInputElements)
        {
            if (!YFCCommon.isVoid(sAPIName))
            {
                //calling configured OOB API
                logger.debug("KohlsXMLMerge :: invoke <=> API name ==> " + sAPIName + " Input doc is ==>"
                        + KohlsXMLUtil.getXMLString(  KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(inputApiEle))));
                if(YFCCommon.isVoid(sAPITemplate))
                {
                    //calling OOB API without template
                    apiOutputDoc = KOHLSBaseApi.invokeAPI(env, sAPIName,  KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(inputApiEle)));
                    //KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(inputApiEle))
                }
                
                else
                {
                    //calling OOB API with template
                    apiOutputDoc = KOHLSBaseApi.invokeAPI(env,sAPITemplate,sAPIName,  KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(inputApiEle)));
                }
                
                logger.debug("KohlsXMLMerge :: invoke <=>  Output doc is ==>" + KohlsXMLUtil.getXMLString(apiOutputDoc));
                
                Element eleParentNode = (Element) inputApiEle.getParentNode();
                eleParentNode.removeChild(inputApiEle);
                Node nodeToAppend = inDoc.importNode(apiOutputDoc.getDocumentElement(), true);
                eleParentNode.appendChild(nodeToAppend);
            }

            else if(!YFCCommon.isVoid(sServiceName))
            {
                //calling configured Service
                logger.debug("KohlsXMLMerge :: invokeService <=> Service name ==> " + sServiceName + " Input doc is ==>"
                        + KohlsXMLUtil.getXMLString(KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(inputApiEle))));
                apiOutputDoc = KOHLSBaseApi.invokeService(env, sServiceName, KohlsXMLUtil.getDocument(KohlsXMLUtil.getElementXMLString(inputApiEle)));
                logger.debug("KohlsXMLMerge :: invokeService <=> Output doc is ==>" + KohlsXMLUtil.getXMLString(apiOutputDoc));
                
                Element eleParentNode = (Element) inputApiEle.getParentNode();
                eleParentNode.removeChild(inputApiEle);
                Node nodeToAppend = inDoc.importNode(apiOutputDoc.getDocumentElement(), true);
                eleParentNode.appendChild(nodeToAppend);
            }

            
        }//end of For

        logger.debug("KohlsXMLMerge :: invoke <=> Final output doc is ==>" + KohlsXMLUtil.getXMLString(inDoc));
        return inDoc;
        
        
    }
    
    void raiseInvalidInputException(String fieldName) {
      YFSException yfs = new YFSException();
      yfs.setErrorCode("InvalidInput");
      yfs.setErrorDescription(fieldName + " Field Received by OMS is empty or null");
      throw yfs;
    }    


}
