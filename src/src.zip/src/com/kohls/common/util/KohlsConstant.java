package com.kohls.common.util;
/**
 *
 *  Kohls Constant File
 *
 */
public class KohlsConstant {
	public static final String KOHLS_OrganizationCode = "KOHLS.COM";
	public static final String KOHLS_ENTERPRISE_CODE = "KOHLS.COM";
	public static final String SO_ENTERPRISE_CODE = "KOHLS.COM";
	public static final String SO_DOCUMENT_TYPE = "0001";
	public static final String PO_DOCUMENT_TYPE = "0005";
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String ACTION_CREATE = "CREATE";
	public static final String ACTION_MODIFY = "MODIFY";
	public static final String ACTION_CANCEL = "CANCEL";
	public static final String A_SUB_LINE_NO = "1";
	public static final String REASON_CODE_NO_INV = "NO_INV";
	public static final String REASON_TEXT_NO_INV = "No inventory";
	public static final String PRODUCT_LINE_SA = "SA";
	public static final String PRODUCT_LINE_GW = "GW";
	public static final String PRODUCT_LINE_ST = "ST";
	public static final String PRODUCT_LINE_VGC = "VGC";
	public static final String PRODUCT_CLASS_GOOD = "Good";
	public static final String UNIT_OF_MEASURE = "EACH";
	public static final String ORDER_RELEASE_KEY = "OrderReleaseKey";
	public static final int PICKTICKET_LEN = 10;
	public static final String SHIP_ALONE_QTY = "1";
	public static final String TRAN_ID_SEND_RELEASE_TO_WMOS = "KOHLS_SEND_RELEASE.0001.ex";
	public static final String TRAN_ID_SA_SEND_RELEASE_TO_WMOS = "KOHLS_SA_SEND_RELEASE.0001.ex";
	public static final String TRAN_ID_SCHEDULE_ORDER = "SCHEDULE.0001";
	public static final String TRAN_ID_RELEASE_ORDER = "RELEASE.0001";
	public static final String TRAN_ID_CHAINED_ORDER_CREATE = "CHAINED_ORDER_CREATE";
	public static final String TRAN_ID_KOHLS_CLOSE_ORDER = "KOHLS_CLOSE_ORDER.0001.ex";
	public static final String STATUS_SEND_TO_WMOS = "3200.03";
	public static final String STATUS_RELEASED = "3200";
	public static final String STATUS_MSG_SEND_TO_WMOS = "Sent To WMoS";
	public static final String STATUS_MSG_SEND_SHIP_ALONE_TO_WMOS = "Ship Alone Sent To WMoS";
	public static final String SUPPLY_TYPE = "ONHAND";
	public static final String INTEGRATION_AGENT_SERVER = "IntegrationAgentServer";
	public static final String INV_ADJ_SERVER_CODE_TYPE = "INV_ADJ_SERVERS";
	public static final String EFC1 = "873";
	public static final String EFC2 = "809";
	public static final String EFC4 = "829";
	public static final String SUSPEND = "Suspend";
	public static final String RESUME = "Resume";
	public static final String SHIPMENT_CREATED_STATUS = "1100";
	public static final String HOLD_CREATED_STATUS = "1100";
	public static final String HOLD_REMOVED_STATUS = "1300";
	public static final String ORDER_LINE_SOUR_CNTRL_REASON = "Source Cntrl";
	public static final String ITEM_ORGANIZATION_CODE = "DEFAULT";
	public static final String VIRTUAL_GIFT_CARD = "VGC";
	public static final String PLASTIC_GIFT_CARD = "GC";
	public static final String PLASTIC_GIFT_CARD_LINE_TYPE = "PGC";
	public static final String BLANK = "";
	public static final String GIFT_WRAP = "GW";
	public static final String GIFT_WRAP_QUANTITY = "1";
	public static final String EFC1_SERVER = "InvAdj873IntegServer";
	public static final String EFC2_SERVER = "InvAdj809IntegServer";
	public static final String RG_HAZARDOUS = "Hazardous";
	public static final String RG_POAPO = "POAPO_STANDARD";
	public static final String RG_PRIORITY = "Priority";
	public static final String RG_AK_HI = "AK_HI_STANDARD";
	public static final String RG_STANDARD = "STANDARD";
	public static final String CARRIER_SERVICE_CODE_APO = "APO";
	public static final String CARRIER_SERVICE_CODE_FPO = "FPO";
	public static final String CARRIER_SERVICE_CODE_PRIORITY = "Priority";
	public static final String ADDRESS_LINE_PO = "PO";
	public static final String STATE_AK = "AK";
	public static final String STATE_HI = "HI";
	public static final String EXTN_PICK_TICKET_ERROR = "ExtnPickTicketNo is missing";
	public static final String ORDER_NO_ERROR = "OrderNo is missing";
	public static final String ELEM_ORDER = "Order";
	public static final String ATTR_DOC_TYPE = "DocumentType";
	public static final String ATTR_ENTERPRISE_CODE = "EnterpriseCode";
	public static final String ATTR_ORD_HDR_KEY = "OrderHeaderKey";
	public static final String ATTR_ORDER_NO = "OrderNo";
	public static final String ATTR_MIN_ORD_STATUS = "MinOrderStatus";
	public static final String ELEM_ORDER_LINES = "OrderLines";
	public static final String ELEM_ORDER_LINE = "OrderLine";
	public static final String ATTR_TOT_NO_RECORDS = "TotalNumberOfRecords";
	public static final String ATTR_INVOICED_QUANT = "InvoicedQuantity";
	public static final String ATTR_ORDER_LINE_KEY = "OrderLineKey";
	public static final String ATTR_ORDERED_QTY = "OrderedQty";
	public static final String ATTR_ORIG_ORDERED_QTY = "OriginalOrderedQty";
	public static final String ATTR_PRIME_LINE_NO = "PrimeLineNo";
	public static final String ATTR_RCVD_QTY = "ReceivedQty";
	public static final String ATTR_SHIPPED_QTY = "ShippedQuantity";
	public static final String ATTR_SUB_LINE_NO = "SubLineNo";
	public static final String ELEM_ORD_STATUSES = "OrderStatuses";
	public static final String ELEM_ORDER_STATUS = "OrderStatus";
	public static final String ATTR_RECV_NODE = "ReceivingNode";
	public static final String ATTR_SHIP_NODE = "ShipNode";
	public static final String ATTR_STATUS = "Status";
	public static final String ATTR_STATUS_QTY = "StatusQty";
	public static final String ATTR_TOT_QTY = "TotalQuantity";
	public static final String ELEM_LINE_CHARGES = "LineCharges";
	public static final String ELEM_LINE_CHARGE = "LineCharge";
	public static final String ATTR_CHARGE_AMNT = "ChargeAmount";
	public static final String ATTR_RMNG_CHARGE_AMNT = "RemainingChargeAmount";
	public static final String ATTR_CHARGE_NAME = "ChargeName";
	public static final String ATTR_CHARGE_CATEGORY = "ChargeCategory";
	public static final String ELEM_ITEM = "Item";
	public static final String ELEM_LINE_TAXES = "LineTaxes";
	public static final String ELEM_LINE_TAX = "LineTax";
	public static final String ATTR_TAX_NAME = "TaxName";
	public static final String ATTR_RMNG_TAX = "RemainingTax";
	public static final String ATTR_TAX = "Tax";
	public static final String ATTR_TAX_PERCENT = "TaxPercentage";
	// Gift Charge related values
	public static final String GiftChargeCategory = "GiftWrap";
	public static final String GiftChargeName = "GiftWrapCharge";
	public static final String GiftTaxCategory = "GiftWrapTax";
	public static final String ShippingChargeCategory = "Shipping";
	public static final String SHIPPING_TAX_CHARGE_CATEGORY = "ShippingTax";
	public static final String ChargeNameSurcharge = "Surcharge";
	// APIs
	public static final String API_GET_ORDER_INVOICE_LIST = "getOrderInvoiceList";
	public static final String API_GET_ORDER_LIST = "getOrderList";
	public static final String API_GET_ITEM_LIST = "getItemList";
	public static final String API_GET_SHIPMENT_LIST = "getShipmentListForOrder";
	public static final String API_GET_SHIPMENT_LINE_LIST = "getShipmentLineList";
	public static final String API_GET_ORDER_RELEASE_DETAILS = "getOrderReleaseDetails";
	public static final String API_GET_SHIPMENT_DETAILS = "getShipmentDetails";
	public static final String API_GET_ORDER_DETAILS = "getOrderDetails";
	public static final String API_GET_ORDER_LINE_DETAILS = "getOrderLineDetails";
	public static final String API_GET_COMMON_CODE_LIST = "getCommonCodeList";
	public static final String API_GET_ORDER_LINE_LIST = "getOrderLineList";
	public static final String API_GET_ITEM_DETAILS = "getItemDetails";
	public static final String API_actual_GET_SHIPMENT_LIST = "getShipmentList";
	public static final String API_GET_DISTRIBUTION_LIST = "getDistributionList";
	public static final String API_GET_INVENTORY_SNAP_SHOT = "getInventorySnapShot";
	// Added SIM Drop 3
	public static final String A_PLACED_QUANTITY = "PlacedQuantity";
	public static final String A_SELLER_ORGANIZATION_CODE = "SellerOrganizationCode";
	public static final String V_AWAITING_PICKLIST_PRINT = "1100.025";
	public static final String A_TRANSACTION_ID = "TransactionId";
	public static final String V_TRANSACTION_ID = "PICK_LIST_PRINT.0001.ex";
	public static final String E_PRINT_PROCESS_SHIPMENT = "PrintProcessShipment";
	// Service
	public static final String SERVICE_KOHLS_SEND_RELEASE_TO_WMOS = "KohlsSendReleaseOrderToWMoSSyncService";
	public static final String SERVICE_KOHLS_SEND_RELEASE_STATUS_TO_ECOMM = "KohlsSendReleaseStatusToEcommSyncService";
	public static final String SERVICE_KOHLS_SEND_SHIP_ALONE_RELEASE_TO_WMOS = "KohlsSendShipAloneOrderToWMoSSyncService";
	public static final String SERVICE_KOHLS_SEND_SHIP_ALONE_STATUS_TO_ECOMM = "KohlsSendShipAloneStatusToEcommSyncService";
	public static final String SERVICE_KOHLS_SHIP_CONFIRM_TO_ECOMM = "KohlsShipConfirmToEcommDropService";
	public static final String SERVICE_KOHLS_GET_INV_SYNC_TIME = "KohlsGetInvSyncTime";
	public static final String SERVICE_KOHLS_CREATE_INV_SYNC_TIME = "KohlsCreateInvSyncTime";
	public static final String SERVICE_KOHLS_CHANGE_INV_SYNC_TIME = "KohlsChangeInvSyncTime";
	public static final String SERVICE_INV_ADJ_GET_TIME = "InvAdjGetTimeSubService";
	public static final String SERVICE_SHIP_CONFIRM_SYNC_SERV = "ShipConfirmationSyncService";
	public static final String SERVICE_ALT_SHIP_CONFIRM_SYNC_SERV = "AltrntShipConfirmEcommSyncService";
	public static final String SERVICE_KOHLS_GET_INV_SNAP_SHOT = "KohlsGetInvSnapShotService";
	public static final String SERVICE_KOHLS_SEND_REGION_SOURCING_RULE = "KohlsSourcingRuleDetailsService";
	public static final String SERVICE_KOHLS_PAYMENT_REVERSE_AUTH_FAILURE_ALERT = "KohlsReverseAuthorizationFailureAlert";
	public static final String SERVICE_KOHLS_PAYMENT_REVERSE_AUTH_TIME_OUT_ALERT = "KohlsReverseAuthorizationTimeOutAlert";
	public static final String SERVICE_KOHLS_PAYMENT_RE_AUTH_FAILURE_ALERT = "KohlsReAuthorizationFailureAlert";
	public static final String SERVICE_KOHLS_PAYMENT_RE_AUTH_TIME_OUT_ALERT = "KohlsReAuthorizationTimeOutAlert";
	public static final String SERVICE_KOHLS_STORED_VALUE_CARD_REFUND_SERVICE = "KohlsStoredValueCardRefundService";
	public static final String SERVICE_KOHLS_CANCEL_MSG_TO_ECOMM = "CancelOrderSyncService";
	public static final String SERVICE_RAISE_KOHLS_CASH_EARNED_EXCEPTION = "RaiseKohlsCashEarnedExceptionAlert";
	//For Drop2 Batch print Begin
	public static final String SERVICE_KOHLS_SORT_SHIPMENT_BY_KEY="KohlsSortShipmentByKey";
	public static final String SERVICE_KOHLS_EXTRACT_SELECTED_SHIPMENTS="KohlsExtractSelectedShipments";
	public static final String SERVICE_KOHLS_MAKE_GIV_STORE_LOCATION_INPUT ="KohlsMakeGIVStoreLocationInput";
	public static final String SERVICE_KOHLS_GIV_LOCATION_SIMULATOR="KohlsGIVLocationSimulator";
	public static final String SERVICE_KOHLS_GIV_LOCATION_INVENROTY_SUPPLY_WEBSERVICE="KohlsGIVLocationInventorySupplyWebservice";
	public static final String SERVICE_KOHLS_ADD_KEYS_TO_LINELIST ="KohlsAddKeysToLineList";
	public static final String SERVICE_KOHLS_DETERMINE_ITEM_LOCATION ="KohlsDetermineItemLocation";
	public static final String SERVICE_KOHLS_RECREATE_SHIPMENT ="KohlsRecreateShipmentList";
	public static final String SERVICE_KOHLS_GROUP_AND_TOTAL="KohlsGroupAndTotal";
	public static final String SERVICE_KOHLS_DATA_FOR_PACK_SLIP_FORMAT="KohlsConvertToPackSlipFormat";


	// SIM Pilot-drop3
	public static final String SERVICE_KOHLS_JASPER_MULTI_SERVICE = "KOHLSJasperMultiPrintService";
	public static final String SERVICE_KOHLS_CHANGE_STATUS_SINGLE_PRINT_SERVICE = "KOHLSChangeStatusSinglePrintService";
	public static final String SERVICE_JASPER_SINGLE_PRINT_SERVICE = "KOHLSPickSlipPrintService";
	public static final String SERVICE_JASPER_MULTI_PRINT_SERVICE = "KOHLSPickSlipPrintService";
	public static final String LINE_TYPE_PGC = "PGC";
	public static final String PRODUCT_LINE_BK = "BK";
	public static final String SHIP_VIA_PP = "PP";
	public static final String SHIP_VIA_PM = "PM";
	public static final String SHIP_VIA_PMDC = "PMDC";
	public static final String CARTON_TYPE_ENV = "ENV";
	public static final String CARTON_TYPE_BRK = "BRK";
	public static final String CARTON_TYPE_WRP = "WRP";
	public static final String WRAP_SINGLE_TO_S = "S";
	public static final String WRAP_SINGLE_TO_T = "T";
	// XPATH
	public static final String XPATH_ORDER_EXTN = "/Order/Extn";
	// NetcoolLog
	public static final String NET_LOG_APPENDER = "NetcoolLogger.";
	public static final String LOW = "Low";
	public static final String MEDIUM = "Medium";
	public static final String HIGH = "High";
	// Payment
	public static final String PAYMENT_STATUS_AUTH = "AUTHORIZED";
	public static final String PAYMENT_STATUS_NOT_APPLICABLE = "NOT_APPLICABLE";
	public static final String PAYMENT_STATUS_PAID = "PAID";
	public static final String CHARGE_TYPE_AUTH = "AUTHORIZATION";
	public static final String CHARGE_TYPE_CHARGE = "CHARGE";
	public static final String PAYMENT_CREDIT = "Credit";
	public static final String PAYMENT_RETURN_CODE_0 = "0";
	public static final String PAYMENT_RETURN_CODE_1 = "1";
	public static final String PAYMENT_RETURN_CODE_2 = "2";
	public static final String PAYMENT_RETURN_CODE_3 = "3";
	public static final String PAYMENT_RETURN_CODE_5 = "5";
	public static final String PAYMENT_RETURN_CODE_6 = "6";
	public static final String PAYMENT_RETURN_CODE_8 = "8";
	public static final String PAYMENT_RETURN_CODE_10 = "10";
	public static final String PAYMENT_RETURN_CODE_14 = "14";
	public static final String PAYMENT_RETURN_MSG_SUCCESSFUL = "SUCCESSFUL";
	public static final String PAYMENT_RETURN_MSG_DECLINED = "DECLINED";
	public static final String PAYMENT_RETURN_MSG_TIMEOUT = "TIMEOUT";
	public static final String RTRN_CODE_APRVD = "RTRN_CODE_APRVD";
	public static final String RTRN_CODE_DECL = "RTRN_CODE_DECL";
	public static final String RTRN_CODE_TIME_OUT = "RTRN_CODE_TO";
	public static final String RESP_101_MSG_FLD = "101_RES_MSG_FLD";
	public static final String AUTHORIZATION_EXPIRATION_DATE = "authorizationExpirationDate";
	public static final String AUTHORIZATION_AMOUNT = "authorizationAmount";
	public static final String AUTHORIZATION_ID = "authorizationId";
	public static final String AUTH_RETURN_CODE = "authReturnCode";
	public static final String DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";
	public static final String CODE_TYPE_RETRY_INTERVAL = "RETRY_INTERVAL";
	public static final String PAYMENT_TYPE_CREDIT_CARD = "Credit Card";
	public static final String PAYMENT_TYPE_CREDIT_AUTH = "credit";
	public static final String PAYMENT_TYPE_AUTH_TRAN_TYPE = "Credit";
	public static final String PAYMENT_TYPE_3PL_GIFT_CARD = "3PL Gift Card";
	public static final String AUTH_EXP_DAYS = "AUTH_EXP_DAYS";
	public static final String AUTH_ID_DUMMY = "000000";
	public static final String DUMMY_SETTLEMENT_MSG = "DUMMY_SETTLEMENT";
	public static final String CREDIT_CARD_AMEX = "AMEX";
	public static final String PAYMENT_RULE_NO_AUTH = "KOHLS_NO_AUTH";
	// Receipt ID Related fields
	public static final int REGISTER_LEN = 2;
	public static final int TRANSACTION_LEN = 4;
	public static final int SHIPNODE_LEN = 4;
	public static final int PMLINENO_LEN = 3;
	public static final String RCPT_HDR_LINE_NUM = "000";
	// SSO constants
	public static final String SSO_HEADER_USERNAME = "sso.header.username";
	public static final String CUSTOMER_OVERRIDES_PROPERTIES = "customer_overrides.properties";
	public static final String SSO_LOGGER = "SSOLogger.";
	public static final int REG_TRANS_LEN = 0;
	public static final Object A_UPC_01 = "Upc01";
	// Reprice constants
	public static final String ORDER_SHIPPED = "3700";
	public static final String SHIPMENT_SHIPPED = "1400";
	public static final String INVOICE_HOLD_INDICATOR = "InvoiceHoldIndicator";
	public static final String HOLD_INVOICE = "Hold Invoice";
	public static final String FINAL_SHIPPED = "1400.001";
	public static final String FINAL_SHIPMENT_0001_EX = "Final Shipment.0001.ex";
	public static final String SHIPMENT_CREATED_FOR_NON_SA = "1100.02";
	public static final String CHANGE_SHIPMENT_STATUS_TRAN = "CHANGE_SHMNT_STATUS.0001.ex";
	public static final String PO_INCLUDED_IN_SHIPMENT = "3350.0001";
	public static final String FINAL_SHIPMENT_0005_EX = "Final Shipment.0005.ex";
	public static final String SO_CANCEL = "Cancel";
	public static final int COSA_HT_REPORT_TIME = 3;
	public static final String KOHLS_CASH = "KOHLS_CASH";
	public static final String CREDIT_CARD_TYPE_KOHLS_CASH = "KOHLS CASH";
	public static final String DiscountChargeCategory = "Discount";
	public static final String SELECT_METHOD_WAIT = "WAIT";
	public static final String DIST_GROUP = "DistributionGroup";
	public static final String ALL_ITEM_ID = "ALL";
	public static final String DSV_PRIORITY = "4.00";
	public static final String INV_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String DELETE_DIST_GROUP = "Delete";
	public static final String EQUALS = "=";
	public static final String DELIMITER = ";";
	public static final String TRAN_ID_ORDER_INVOICE_0001_EX = "KOHLS_ORDER_INVOICE.0001.ex";
	public static final String TRAN_ID_INCLUDE_INVOICE_0001_EX = "KOHLS_INCLUDE_INVOICE.0001.ex";
	public static final String AWAITING_INVOICE_CREATION = "3700.0003";
	public static final String AWAITING_ORDER_CLOSURE = "3700.0001";
	public static final String INVOICED = "3700.0004";
	public static final String MODIFY = "Modify";
	public static final String DELETE = "Delete";
	public static final String CREDIT_CARD = "Credit Card";
	public static final String GIFT_CARD = "Gift Card";
	public static final String A_SUSPEND_BOTH_PAYMENT_REFUND = "B";
	public static final String PREENC = "Preenc";
	public static final String DSV_NODE_RECEIPT_ID = "873";
	public static final String VGC_SHIP_NODE = "SVC";
	public static final String AUTHORIZATION = "AUTHORIZATION";
	public static final String CASH_ACTIVATION_HOLD = "CashActivationHold";
	public static final String CASH_ACTIVATION_REASON = "KCE Activation Hold";
	public static final String CODE_SHIP_NODES = "SHIP_NODES";
	// Hard Totals
	public static final String HD_DATE_FORMAT = "yyyy-MM-dd";
	public static final String HARD_TOTALS_KEY = "HardTotalsKey";
	public static final String SERVICE_GET_HARD_TOTALS_LIST = "GetHardTotalsListService";
	public static final String HD_GT = "GT";
	public static final String SERVICE_DROP_HARD_TOTALS = "DropHardTotalsService";
	public static final String SERVICE_GET_COSA_REPORT_RUN_LST = "GetCosaReportRunListService";
	public static final String SERVICE_CREATE_COSA_AGENT_RUN_REC = "CreateCosaAgentRunRecordService";
	public static final String SALES_TRANS_CNT_VAL = "1";
	public static final String TRANS_WITH_TAXES_VAL = "1";
	public static final String KMRC = "KMRC";
	public static final String KOHLS_GIFT_CARD = "KL_GIFT_CARD";
	public static final String CREDIT_CARD_VISA = "VISA";
	public static final String CREDIT_CARD_DISCOVER = "DISC";
	public static final String KOHLS_CHARGE_CARD = "KL_CHRG_CARD";
	public static final String CREDIT_CARD_MSTR_CARD = "MSTR_CARD";
	public static final String GIFT_CARD_SKU_ID = "GIFTCARD_SKU_ID";
	public static final String IS_PROCESS_AVAILABILITY_ACTIVE = "PRO_AVAIL_ACTIV";
	public static final String DSV_INV_ADJ_PROCESS_SUB_SERVICE = "DSVInvAdjProcessSubService";
	public static final String CREATE_HARD_TOTALS_SERVICE = "CreateHardTotalsService";
	public static final String HARD_TOTAL_HOUR = "HARD_TOTAL_HOUR";
	public static final String HARD_TOTAL_RECORDS = "HARD_TOTAL_REC";
	public static final String HARD_TOTAL_DAY = "HARD_TOTAL_DAY";
	// RelC Constants
	public static final String INS_TYPE_BOGO = "BOGO";
	public static final String TAX_NAME_SALES_TAX = "SALES_TAX";
	public static final String AWAIT_PAY_INFO = "AWAIT_PAY_INFO";
	public static final String OOB_HOLD = "OMSOutOfBalanceHold";
	public static final String ECOMM_HOLD = "EComOutOfBalanceHold";
	public static final String ECOMM_HOLD_REASON = "EComm Hold";
	public static final String ECOMM_HOLD_RESOLVE_REASON = "Resolving EComm Hold";
	public static final String SERVICE_KOHLS_CASH_TABLE_LIST = "KohlsGetCashTableList";
	// Start --- Added for PMR 54606,379,000 -- OASIS_SUPPORT 14/03/2012
	public static final String SHIP_VIA_VALUES = "SHIP_VIA_VALUES";
	public static final String IS_HAZ_IS_MILITARY = "IS_HAZ_IS_MILITARY";
	// End --- Added for PMR 54606,379,000 -- OASIS_SUPPORT 14/03/2012

//Start -- added for PMR :05616,379,000 default carton type as "BOX"

	public static final String CARTON_TYPE_BOX = "BOX";

   //End -- added for PMR :05616,379,000 default carton type as "BOX"
	// Start -- Added for 74501,379,000 -- OASIS_SUPPORT 07/08/2012 //
	public static final String SERVICE_KOHLS_POST_AUDIT_MSG = "KohlsPostAuditMsgSyncService";
	public static final String SUPPLY_CORRECTION="SupplyCorrection";
	public static final String AVAILABILITY_CORRECTION="AvailabilityCorrection";
	// End -- Added for 74501,379,000 -- OASIS_SUPPORT 07/08/2012 //
	// offshore drop2
	public static final String API_GET_SHIPMENT_LIST_FOR_PACK_SHIPMENT_KEY_TEMPLATE_PATH = "global/template/api/getShipmentListForPackShipmentKey_output.xml";
	public static final String API_GET_SHIPMENT_DETAILS_PACK_SHIPMENT_TEMPLATE_PATH = "global/template/api/getShipmentDetailsForPackShipment_output.xml";
	public static final String A_SHIPMENT_LINE_KEY = "ShipmentLineKey";
	public static final String A_QUANTITY = "Quantity";
	// public static final String API_GET_SHIPMENT_DETAILS =
	// "getShipmentDetails";
	// public static final String API_GET_SHIPMENT_LIST = "getShipmentList";
	// public static final String API_GET_ITEM_LIST = "getItemList";
	public static final String API_GET_ITEM_LIST_FOR_CONTAINER_TYPE_TEMPLATE_PATH = "global/template/api/getItemListForContainerType_output.xml";
	public static final String API_GET_ITEM_LIST_FOR_TRANSLATE_BARCODE_TEMPLATE_PATH = "global/template/api/getItemListForTranslateBarcode_output.xml";
	public static final String A_ENTERPRISE_CODE = "EnterpriseCode";
	public static final String A_SHIPMENT_KEY = "ShipmentKey";
	public static final String A_ORGANIZATION_CODE = "OrganizationCode";
	public static final String A_CALLING_ORGANIZATION_CODE = "CallingOrganizationCode";
	public static final String A_ITEM_GROUP_CODE = "ItemGroupCode";
	public static final String V_PROD = "PROD";
	public static final String A_IS_SHIPPING_CONTAINER = "IsShippingCntr";
	public static final String FLAG_Y = "Y";
	public static final String E_ITEM = "Item";
	public static final String E_SHIPMENT = "Shipment";
	public static final String A_CONTAINER_NO = "ContainerNo";
	public static final String E_CONTAINER = "Container";
	public static final String A_IS_PACK_PROCESS_COMPLETE = "IsPackProcessComplete";
	public static final String E_NEW_CONTAINER = "NewContainer";
	public static final String E_CONTAINERS = "Containers";
	public static final String API_CHANGE_SHIPMENT_CONTAINER = "changeShipmentContainer";
	public static final String API_CHANGE_SHIPMENT_CONTAINER_TEMPLATE_PATH = "global/template/api/changeShipmentContainer_output";
	public static final String A_SHIPMENT_CONTAINERIZED_FLAG = "ShipmentContainerizedFlag";
	public static final Object V_SHIPMENT_CONTAINERIZED = "03";
	public static final String E_ADDINFO = "AddInfo";
	public static final String A_DcmIntegrationRealTime = "DcmIntegrationRealTime";
	public static final String API_CHANGE_SHIPMENT = "changeShipment";
	public static final String API_CHANGE_SHIPMENT_STATUS = "changeShipmentStatus";
	public static final String API_PACK_SHIPMENT = "packShipment";
	public static final String API_PACK_SHIPMENT_TEMPLATE_PATH = "global/template/api/changeShipmentToAddContainer.xml";
	public static final String A_PACK_COMPLETE_TRANSACTION_ID = "PACK_SHIPMENT_COMPLETE";
	public static final String A_PACK_COMPLETE_BASE_DROP_STATUS = "1300";
	public static final String A_Shipment_Pack_In_Progress = "1100.04";
	public static final String A_SHIPMENT_PACK_TRANSACTION_ID = "SHIPMENT_PACK.0001.ex";
	public static final String A_CONTAINERS = "Containers";
	public static final String A_CONTAINER = "Container";
	public static final String A_CONTAINERSCM = "ContainerScm";
	public static final String A_LATEST_CONTAINER_SCM = "LatestContainerScm";
	public static final String V_SHIPMENT_CONTAINERIZED_01 = "01";
	public static final String V_SHIPMENT_CONTAINERIZED_02 = "02";
	public static final String V_SHIPMENT_CONTAINERIZED_03 = "03";
	public static final String V_SHIPMENT_PICK_LIST_PRINTED_STATUS = "1100.03";
	public static final String A_PICK_LIST_PRINT_TRANSACTION_ID = "PICK_LIST_PRINT.0001.ex";
	public static final String A_ACTION = "Action";
	public static final String V_DELETE = "Delete";
	public static final String API_UN_PACK_SHIPMENT = "unpackShipment";
	public static final String A_ACTION_TAKEN = "ActionTaken";
	public static final String V_ACTION_TAKEN_UNPACK = "unpack";
	public static final String V_ACTION_TAKEN_PACK = "pack";
	public static final String A_SHIPMENT_NO = "ShipmentNo";
	public static final String A_SHIP_NODE = "ShipNode";
	public static final String API_GET_SHIPMENT_LIST_FOR_UPDATE_CONTAINER_TRACKING = "global/template/api/getShipmentListForUpdateContainerTracking.xml";
	public static final String A_IS_NEW_CONTAINER = "IsNewContainer";
	public static final String SQL_STATEMENT_FOR_SEQ_YFS_CONTAINER_NO = "select SEQ_YFS_CONTAINER_NO.nextval as ContainerNo from dual";
	public static final String A_STATUS = "Status";
	public static final String STATUS_SHIPMENT_PICK_LIST_PRINTED = "1100.03";
	public static final String STATUS_SHIPMENT_PACK_IN_PROGRESS = "1100.04";
	public static final Integer V_ZERO = 0;
	public static final String A_ITEM_ID = "ItemID";
	public static final String A_BLANK = "";
	public static final String A_TOTAL_SHIPMENTS = "TotalShipments";
	public static final String A_SHIPMENT_TYPE = "ShipmentType";
	public static final String E_SHIPMENT_LINE = "ShipmentLine";
	public static final String E_SHIPMENT_LINES = "ShipmentLines";
	public static final String A_MAXIMUM_RECORDS = "MaximumRecords";
	public static final String A_PRINTER_ID = "PrinterID";
	public static final String E_ORDER_INVOICE = "OrderInvoice";
	public static final String E_PAYMENT_METHOD = "PaymentMethod";
	public static final String E_SHIPMENTS = "Shipments";
	public static final String API_UNPACK_SHIPMENT_TEMPLATE_PATH = "global/template/api/changeShipmentToUnPackContainer.xml";
	public static final String V_PACK = "Pack";
	public static final String V_UNPACK = "unpack";
	public static final String E_BASE_DROP_STATUS = "BaseDropStatus";
	public static final String V_BASE_DROP_STATUS = "1100.03";
	//
	public static final String A_NUMBER = "Number";
	//
	public static final String V_PREFIX = "KOHLS";
	public static final String V_MIDDLE = "SinglePrint";
	public static final String V_SUFFIX = "Service";
	public static final String V_AWAITING_PICKLIST = "Awaiting PickList";
	public static final String V_PRINT_LIST_PRINTED = "Printlist Printed";
	public static final String A_IS_PRINTLIST_PRINTED = "Is PrintList Printed";
	public static final String V_Y = "Y";
	public static final String V_NULL = "null";
	public static final String V_ORDER = "ORDER";
	public static final String SERVICE_JASPER_SERVICE1 = "Jasperservice1";
	public static final String A_IS_PICK_LIST_PRINTED = "IsPickListPrinted";
	public static final String A_SHIPMENT_LINES = "ShipmentLines";
	public static final String A_SHIPMENT_LINE = "ShipmentLine";
	public static final String A_UNIT_OF_MEASURE = "UnitOfMeasure";
	public static final String E_ITEM_NODE_DEFN = "ItemNodeDefn";
	public static final String A_ITEM_NODE_DEFN_KEY = "ItemNodeDefnKey";
	public static final String A_NODE = "Node";
	public static final String A_EXTN = "Extn";
	public static final String API_GET_ITEM_NODE_DEFN_DETAILS = "getItemNodeDefnDetails";
	public static final String A_ITEM_DESC = "ItemDesc";
	public static final String A_TOTE_ID = "ToteID";
	public static final String V_TOTE_ID = "1";
	public static final String A_PRIMARY_INFORMATION = "PrimaryInformation";
	public static final String A_LINE = "Line";
	public static final String A_LOCATION = "Location";
	public static final String A_EXTN_LOCATION_ID = "ExtnLocationID";
	public static final String A_EXTN_LINE_NO = "ExtnLineNo";
	public static final String E_EXTN = "Extn";
	public static final String A_TOTEID = "ToteId";
	public static final String E_PRINT_PACK_SHIPMENT = "PrintPackShipment";
	public static final String A_TOTAL_CARTS = "TotalCarts";
	public static final String A_TOTES_PER_CART = "TotesPerCart";
	public static final String KOHLS = "KOHLS";
	public static final String SERVICE_KOHLS_CHANGE_STATUS_MULTI_PRINT = "KOHLSChangeStatusMultiPrintService";
	public static final String MULTI_PRINT_SERVICE = "MultiPrintService";
	public static final String V_MIDDLE_PRINT = "PrintPickSlip";
	// added 6/5/12 from Punit Kumar
	public static final String API_GET_ORGANIZATION_LIST = "getOrganizationList";
	public static final String ATTR_SHIPNODESOURCE = "ExtnShipNodeSource";
	public static final String ATTR_RDC = "RDC";
	public static final String ATTR_STORE = "STORE";
	public static final String ATTR_RDC_STORE = "RDC_STORE";
	public static final String ATTR_FULFILLMENT_TYPE = "FulfillmentType";
	public static final String ATTR_GIFT_PRIORITY = "Gift_Priority";
	public static final String ATTR_ASSOCIATION_ACTION = "AssociationAction";
	public static final String ATTR_IS_NODE = "IsNode";
	public static final String ATTR_GIFT = "Gift";
	public static final String ATTR_MULTI = "Multi";
	public static final String ATTR_REGULAR = "Regular";
	public static final String ATTR_SINGLE = "Single";
	// added by puneet on 15th june - start
	public static final String E_SHIP_NODE = "ShipNode";
	public static final String E_MULTI_API = "MultiApi";
	public static final String E_CONTAINER_DETAIL = "ContainerDetail";
	public static final String E_API = "API";
	public static final String A_NAME = "Name";
	public static final String API_MOVE_LOCATION_INVENTORY = "moveLocationInventory";
	public static final String E_INPUT = "Input";
	public static final String E_MOVE_LOCATION_INVENTORY = "MoveLocationInventory";
	public static final String E_SOURCE = "Source";
	public static final String E_DESTINATION = "Destination";
	public static final String E_INVENTORY = "Inventory";
	public static final String E_INVENTORY_ITEM = "InventoryItem";
	public static final String A_PRODUCT_CLASS = "ProductClass";
	public static final String A_LOCATION_ID = "LocationId";
	public static final String A_LOCATION_TYPE = "LocationType";
	public static final String A_LOCATION_CONTEXT = "LocationContext";
	public static final String V_NODE_DEFAULT_LOCATION = "Receiving";
	public static final String A_CASE_ID = "CaseId";
	public static final String A_Node = "Node";
	public static final String O_CONTAINER_ELEM = "sContainerElem";
	public static final String A_CONTAINER_TYPE = "ContainerType";
	public static final String V_CASE = "Case";
	public static final String SERVICE_POST_MESSAGE_CONFIRM_SHIPMENT = "KOHLSPostMessageInQueueForConfirmShipment";
	public static final String API_CONFIRM_CUSTOMER_PICK = "confirmCustomerPick";
	public static final String SERVICE_SOP_PRINT_PICK_TICKET = "KOHLSSopPrintPickTicketService";
	// added by puneet on 15th june - end
	// added by puneet on 16th june-start
	public static final String API_SHIPMENT_DETAIL_PICK_LIST = "global/template/api/getShipmentDetailsForPickList_output.xml";
	// added by puneet on 16th june - end
	// added by puneet on 17th june-start
	public static final String A_RECEIPT_ID = "ReceiptId";
	// added by puneet on 17th june - end
	public static final String A_SKU_QTY = "SkuQty";
	// public static final String A_CATALOG_ORG = "KOHLS.COM";
	public static final String A_CATALOG_ORG = "DEFAULT";
	// added by puneet on 20th june start
	public static final String A_CATALOG_ORG_CODE = "CatalogOrgCode";
	public static final String A_FORM_ID = "FormID";

//	 added by puneet on 20th june end

	//added by kiran on 21th June
	public static final String V_UPC01 = "Upc01";
	public static final String A_ALIAS_NAME = "AliasName";
	public static final String A_ALIAS_VALUE = "AliasValue";
	public static final String SERVICE_KOHLS_PICK_SLIP_PRINT = "KOHLSPickSlipPrintService";
	public static final String A_ITEM_ALIAS_LIST = "ItemAliasList";
	public static final String A_ITEM_ALIAS = "ItemAlias";
	public static final String SERVICE_PACK_SLIP_PRINT_SERVICE = "KOHLSPackSlipPrintService";
public static final String A_BARCODE_DATA = "BarCodeData";
public static final String A_CONTEXTUAL_INFO = "ContextualInfo";
	public static final String A_ITEM_CONTEXTUAL_INFO = "ItemContextualInfo";
	public static final String A_BAR_CODE = "BarCode";
	public static final String A_TRANSLATIONS = "Translations";
	public static final String A_TRANSLATION = "Translation";
public static final String A_TOTAL_ITEM_LIST = "TotalItemList";
	public static final String A_INVENTORY_UOM = "InventoryUOM";
	//added by puneet 25 june 2012 start
	public static final String V_COMMON_CODE_TYPE_FOR_SHIPNODE_DIR = "SHPNODE_PRT_DIR";
	public static final String E_COMMON_CODE = "CommonCode";
	public static final String A_CODE_TYPE = "CodeType";
	public static final String A_CODE_VALUE = "CodeValue";
	public static final String A_CODE_SHORT_DESC = "CodeShortDescription";
	public static final String V_DATE_TIME_FORMAT = "yyyyMMddHHmmss" ;

	//added by puneet 25 june 2012 end
//added by shaila on 26th june
public static final String A_IGNORE_ORDERING = "IgnoreOrdering";
	public static final String V_N = "N";
	public static final String V_MAXIMUM_RECORDS = "5000";
	public static final String E_ORDER_BY = "OrderBy";
	public static final String A_ATTRIBUTE = "Attribute";
	public static final String API_GET_SHIPMENT_DETAILS_PACK_SHIPMENT_TEMPLATE_PATH_1 = "global/template/api/getShipmentDetailsForPackShipment_output.xml";
	public static final String A_AWAITING_PICK_LIST = "1100.025";
	// added by puneet on 30 june 2012- start
	public static final String A_LABEL_PICK_TICKET = "LabelPickTicket";
	public static final String API_GET_SHIPMENT_DETAILS_RE_PRINT_SINGLE_PICK_SHIPMENT_TEMPLATE = "global/template/api/getShipmentDetailsForRePrintSinglePickShipment_output.xml";
	public static final String SERVICE_RE_PRINT_SINGLE_PICK_SHIPMENT = "KOHLSSinglePickRePrintService";
	public static final String API_CHANGE_SHIPMENT_STATUS_RE_PRINT_SINGLE_PICK_SHIPMENT_TEMPLATE = "global/template/api/changeShipmentStatus.xml";
	public static final String E_ORDER_LINE = "OrderLine";
	public static final String V_KL_MAX_SHP_PRINT = "KL_MAX_SHIP_PRINT";


	// added by puneet on 30 june 2012- end

	//added by Kiran on 2 july 2012- Start

	//added by Kiran on 2 july 2012- End
	//added by puneet on 4th july 2012 - start
	public static final String API_REPRINT_PICK_SLIP_SERVICE = "KOHLSSopPrintPickTicketService";
	//added by puneet on 4th july 2012 - end
	public static final String A_NODE_TYPE = "NodeType";
	public static final String V_STORE = "STORE";

//	added by kiran on 5th july 2012 - start


	//added by Saravana on 5 July 2012 - Start
	public static final String E_FRONT_PAGE = "FrontPage";
	public static final String A_SEQ_NO = "SeqNo";
	//added by Saravana on 5 July 2012 - End
	      //added by Saravana on 6 July 2012 - Start
      public static final String E_ITEM_INFO = "ItemInformation";
      //added by Saravana on 6 July 2012 - End
	//added by Puneet on 8 July 2012 - Start
	public static final String A_SCAC = "SCAC";
	public static final String A_CARRIER_SERVICE_CODE = "CarrierServiceCode";
	public static final String A_CARRIER_ACCOUNT_NO = "CarrierAccountNo";
	//added by Puneet on 8 July 2012 - End
	//added by Saravana on 9 July 2012 - Start
	public static final String E_LINE_TAX = "LineTax";
	public static final String A_TAX_SYMBOL = "TaxSymbol";
	public static final String TAX_SYMBOL_T = "T";
	public static final String E_POPULATE_TAXES = "PopulateTaxes";
	public static final String E_POPULATE_TAX = "PopulateTax";
	//added by Saravana on 9 July 2012 - End
	//added by puneet on 26 july 2012 - start
	public static final String V_STATUS_LIST = "KOHLSShipmentStatusList";
	//added by puneet on 26 july 2012 - end
    //added by puneet on 09 Aug 2012 - start
	public static final String A_UPC_BARCODE_PICK_TICKET = "UpcBarcodePrint";
	//added by puneet on 09 Aug 2012 - End
	public static final String E_BACK_PAGE = "BackPage";
	public static final String A_DESCRIPTION = "Description";
	public static final String O_ADD_CONTAINER_OUTPUT = "AddContainerOutDoc";
	public static final String O_PRINT_PACK_SLIP = "PrintPackSlip";
	public static final String E_PRINT_PACK_DOC = "PrintPackDoc";

	public static final String A_PRINT_JASPER_REPORT = "PrintJasperReport";
		//Added for Mass Singles Print, Modified by Kiran on 20th Sept
	public static final String E_COMPLEX_QUERY = "ComplexQuery";
	public static final String E_OR = "Or";
	public static final String E_EXP = "Exp";
	public static final String A_VALUE = "Value";
	public static final String SHIP_TYPE_SINGLE_REGULAR = "Single_Regular";
	public static final String SHIP_TYPE_SINGLE_PRIORITY = "Single_Priority";
	public static final String SHIP_TYPE_SINGLE_GIFT = "Single_Gift";
	public static final String DELIMITER_SHIP_HASHMAP = "++";
	public static final String ESC_CHAR_DELIMITER_SHIP_HASHMAP = "\\++";
	public static final String E_PRINT_PACK_SHIPMENTS = "PrintPackShipments";

	public static final String A_AVAILABLE_QTY = "AvailableQuantity";
	public static final String STRING_ONE = "1";
	//Add by Puneet on 19th Sept
	public static final String API_KOHLS_PRINT_PACK_SLIP_SERVICE = "KOHLSProcessPrintPackSlipService";
	public static final String A_PRINT_BATCH_NUMBER = "PrintBatchNo";
	public static final String V_KOHLS_RE_PACKSHIP_JASPER = "/KohlsRePackShip.jasper";
	public static final String SERVICE_GET_MASS_PRINT_SINGLES_LIST_SERVICE = "KOHLSGetMassPrintSinglesListService";

	 public static final String A_COMMITMENT_CODE = "CommitmentCode";

	 public static final String SQL_STATEMENT_FOR_SEQ_YFS_PRINT_BATCH_ID= "select SEQ_YFS_PRINT_BATCH_ID.nextval as BatchID from dual";
	 public static final String A_BATCH_ID = "BatchID";
	public static final String V_DATE_FORMAT = "yyyyMMdd";
	public static final String A_CART_NUMBER = "CartNo";
	public static final String A_TOTAL_CARTS_AVAILABLE = "TotalCartsAvailable";
	public static final String A_CART_NUMBER_AVAILABLE = "CartNoAvailable";
	public static final String A_PROFILE_ID = "ProfileID";
	public static final String A_EXTN_CART_NUMBER = "ExtnCartNumber";
	public static final String E_ATTRIBUTE = "Attribute";
	public static final String A_DESC = "Desc";
	public static final String A_IS_CONFIRM_SHIPMENT = "IsConfirmShipment";

	public static final String API_CHECK_TRACKING_NO_TEMPLATE_PATH = "global/template/api/getShipmentDetailsToCheckTrackingNo.xml";
	public static final String A_CONFIRM_SHIPMENT_STATUS = "1400";
	public static final String SHIP_TYPE_MULTI_REGULAR = "Multi_Regular";
	public static final String SHIP_TYPE_MULTI_PRIORITY = "Multi_Priority";
	public static final String SHIP_TYPE_MULTI_GIFT = "Multi_Gift";
	public static final String A_START_CART_NUMBER = "StartCartNo";
	public static final String A_PRINT_TYPE ="PrintType";
	public static final String V_SINGLE = "SINGLE";
	public static final String a_CONTAINER_NET_WEIGHT = "ContainerNetWeight";
	public static final String V_SERVICE_TYPE_USG = "USG";
	public static final String A_SERVICE_TYPE = "ServiceType";
	public static String V_SERVICE_TYPE_USL = "USL";
	public static String A_EXTN_IS_PO_BOX = "ExtnIsPOBox";

	public static final String A_IS_PRODUCT_FAMILY_SHIPMENT = "isProductFamilyShipment";

	public static final String SERVICE_KOHLS_MULTIAPI_INPUT_SORT_BY_ITEMID_XSL = "KOHLSSortMultiApiInputForMoveLocationInventoryByItemID";
	public static final String V_SELLER_ORGANIZATION_CODE = "KOHLS.COM";
	public static final String A_TOTAL_NUMBER_RECORDS = "TotalNumberOfRecords";
	public static final String ATTR_TOTES_PER_CART = "TotesPerCart";
	public static final String E_AVAILABLE_CARTS = "AvailableCarts";
	public static final String A_CARTS_MULTI_REGULAR = "MultiRegular";

	public static final String A_CARTS_MULTI_PRIORITY = "MultiPriority";

	public static final String A_CARTS_MULTI_GIFT = "MultiGift";
	public static final String A_IS_PICKTICKET_PRINTED = "IsPickTicketPrinted";
	//Add by Kiran 17th Dec
	public static final String E_ITEM_NODE_DEFN_LIST = "ItemNodeDefnList";
	public static final String A_EXTN_PRODUCT_FAMILY = "ExtnProductFamily";
	public static final String API_GET_ITEM_NODE_DEFN_LIST = "getItemNodeDefnList";
	public static final String V_MULTI_PRODUCT_FAMILY = "Multi_Product_Family";
	public static final String A_EXTN_SHIPMENT_FAMILY = "ExtnShipmentFamily";
		//Start -- added for central stock transfer issue.
	public static final String WAREHOUSE_TRAN = "WAREHOUSE_TRAN";
	public static final String STATUS_SEND_RELEASE_TO_WMOS = "3200.01";
	public static final String TRAN_ID_SEND_TO_RELEASE_TO_WMOS = "KOHLS_SEND_TO_RELEASE.0006.ex";
	public static final String TO_DOCUMENT_TYPE = "0006";
	public static final String API_GET_ORDER_RELEASE_LIST = "getOrderReleaseList";
	public static final String TEMLATE_GET_SHIPMENT_LIST_TO_STAMP_BATCH_NO = "global/template/api/getShipmentListToStampBatchNo.xml";
	public static final String A_BATCH_NO = "BatchNo";
	public static final String V_AWAITING_PICK_LIST_PRINT = "1100.025";
	public static final String TEMLATE_GET_SHIPMENT_DETAILS_FOR_SHIPMENT_STATUS = "global/template/api/getShipmentDetailsForShipmentStatusOfBulkPrint.xml";
	public static final String A_SELECT_METHOD = "SelectMethod";
	public static final String V_NO_WAIT = "NO_WAIT";
	public static final String E_BATCH_PRINT = "BatchPrint";
	public static final String A_REPRINT_FLAG = "ReprintFlag";
	public static final String A_NO_OF_SHIPMENTS = "NoOfShipments";
	public static final String V_AWAITING_PRINT = "Awaiting Printing";
	public static final String A_USER = "User";
	public static final String A_BASE_DROP_STATUS = "BaseDropStatus";
	public static final String A_EXTN_BATCH_NO = "ExtnBatchNo";
	public static final String A_QTY_TO_PRINT = "QtyToPrint";
	public static final String E_BATCH_SHIPMENT = "BatchShipment";

	public static final String MAX_NUMBER_OF_CARTS = "200";
	//End -- added for central stock transfer issue.

	//Batch Print Drop 2/3 Begin
	public static final String A_NO_OF_SHIPMENT ="noOfShipment";
	public static final String A_FROM_CART_NO ="FromCartNo";
	public static final String A_TO_CART_NO ="ToCartNo";
	public static final String A_FROM ="From";
	public static final String A_TO ="To";
	public static final String A_PICKSLIP ="Pickslip";
	public static final String A_PRIMARY_SUPPLIER="PrimarySupplier";
	public static final String A_VENDOR="Vendor";
	public static final String A_ITEM_DESCRIPTION="ItemDescription";
	public static final String A_SHORT_DESCRIPTION="ShortDescription";
	public static final String A_DEPT="Department";
	public static final String A_ORGANIZATION="Organization";
	public static final String A_ORG_LIST="OrganizationList";
	public static final String A_ORG_NAME="OrganizationName";
	public static final String A_ORDER_DATE="OrderDate";
	public static final String A_UNIT_PRICE="UnitPrice";
	public static final String A_LINE_PRICE_INFO="LinePriceInfo";
	public static final String A_NOTE="Note";
	public static final String A_REASON_CODE="ReasonCode";
	public static final String A_NOTE_TEXT="NoteText";
	public static final String A_RECEIPTID="ReceiptID";
	public static final String A_STORE="Store";
	public static final String A_TABLE_KEY="TableKey";
	public static final String A_SEQUENCE_KEY="SequenceNo";
	public static final String A_SINGLES_PRINT="SINGLES_PRINT";
	public static final String KOHLS_SINGLE_BATCH_PRINT_SERVICE = "KOHLSSingleBatchPrintService";
	public static final String A_MULTI_PRINT="MULTI_PRINT";
	public static final String SERVICE_JASPER_BATCH_MULTI_PRINT_SERVICE = "KOHLSRDCMultiPickSlipPrintService";
	public static final String A_USER_ID="userId";
	public static final String A_PASSWORD="password";
	public static final String END_POINT_USER_GIV_LOC_INV_SUPPLY="END_POINT_USER_GIV_LOC_INV_SUPPLY";
	public static final String END_POINT_PWD_GIV_LOC_INV_SUPPLY="END_POINT_PWD_GIV_LOC_INV_SUPPLY";
	public static final String A_GET_LOCATION_NS3="ns3:getLocationInventorySupplyResponse";
	public static final String A_NS3="xmlns:ns3";
	public static final String A_NS3_VALUE="http://webservices.inventory.giv.kohls.com/";
	public static final String A_NS4="xmlns:ns4";
	public static final String A_NS4_VALUE="http://webservices.inventory.giv.kohls.com/documentation/GetLocationInventorySupply/getLocationInventorySupply/output";
	public static final String A_INP_INV_SUPPLY="inp:InventorySupply";
	public static final String A_NS4_ITEM="ns4:Item";
	public static final String A_NS4_SUPPLIES="ns4:Supplies";
	public static final String A_NS4_INV_SUPPLY="ns4:InventorySupply";
	public static final String A_SUPPLY_TYPE="SupplyType";
	public static final String A_STOCK_ROOM_EX="STOCK_ROOM.ex";
	public static final String A_SALES_FLOOR_EX="SALES_FLOOR.ex";
	public static final String A_RETURN="return";

	// BOPUS GIV namespaces
	public static final String BOPUS_GIV_MESSAGE_PREFIX_PROPERTY="SOAPACTIONURIPREFIX_GIV_VALUE";
	public static final String BOPUS_GIV_INPUT_PREFIX_PROPERTY="PROSHIPDATACONTRACTPREFIX_GIV_VALUE";
	public static final String BOPUS_GIV_ENV_ELEMENT_PROPERTY="SOAPENVIRONMENT_VALUE";
	public static final String BOPUS_GIV_INPUT_ELEMENT_PROPERTY="SOAPINPUT_VALUE";
	public static final String BOPUS_GIV_MESSAGE_ELEMENT_PROPERTY = "SOAPACTIONOPERATIONPARAM_GIV_VALUE";
	public static final String BOPUS_DEFAULT_PRODUCT_CLASS_PROPERTY = "DEFAULT_PRODUCT_CLASS";
	public static final String BOPUS_TRANSLATION_ORG_PREFIX = "TRANSLATION_ORG_";
	public static final String BOPUS_TRANSLATION_ITEM_PREFIX = "TRANSLATION_ITEM_";
	public static final String BOPUS_GIV_RESPONSE_NAMESPACE_PROPERTY = "GIVRESPONSE_OUTPUT_NAMESPACE";


	//Batch Print Drop 2/3 Begin

	public static final String A_SHIPMENT_CONTAINER_KEY = "ShipmentContainerKey";
	public static final String API_GET_SHIPMENT_CONTAINER_DETAILS = "getShipmentContainerDetails";
	public static final String API_GET_SHIPMENT_CONTAINER_DETAILS_FOR_PROSHIP_TEMPLATE_PATH = "global/template/api/getShipmentContainerDetailsForShip_Output.xml";
	public static final String A_CODE_LONG_DESC = "CodeLongDescription";
	public static final String A_EXTN_LBL_PRINT_FORMAT = "ExtnLblPrintFormat";
	public static final String API_SHIP_SYNC_WEB_SERVICE  = "KohlsShipSyncWebService";
	public static final String A_BASIC_FREIGHT_CHARGE = "BasicFreightCharge";
	public static final String A_TRACKING_NO = "TrackingNo";
	public static final String A_VOID_LABEL_ID = "ExtnVoidLabelId";
	public static final String API_LABEL_PRINT_SERVICE = "KOHLSLabelPrinterService";
	public static final String A_EXTN_PRINT_FORMAT = "EXTN_LBL_PRT_FORMAT";
	public static final String A_EXTN_PNG_PRINT_FORMAT = "EXTN_PNG_PRINT_FORMAT";
	public static final String PROSHIP_ERROR = "ProShip Error";

	public static final String SERVICE_KOHLS_CHANGE_STATUS_MULTI_PRINT_DROP2 = "KOHLSChangeStatusMultiPrintService_Drop2";
	//For Void Label Flow:
	public static final String API_PACK_SHIPMENT_TEMPLATE_VOID_LABEL_PATH="global/template/api/changeShipmentStatus_VoidLabel.xml";
	public static final String MERGED_DOCUMENT = "MergedDocument";
	public static final String INPUT_DOCUMENT = "InputDocument";
	public static final String PROSHIP_DOCUMENT = "ProShipDocument";
	public static final String PROSHIP_RESPONSE = "PROSHIP_RESPONSE";
	public static final String A_ACTUAL_FREIGHT_CHARGE = "ActualFreightCharge";
	public static final String A_EXTN_VOID_LABEL_ID = "ExtnVoidLabelId";
	public static final String A_SHIPMENT_STATUS_AUDIT = "ShipmentStatusAudit";
	//for shipment Monitor
	public static final String A_SHIPMENT_PACKED_STATUS = "1300";
	public static final String A_STATUS_DATE_QRY_TYPE ="StatusDateQryType";
	public static final String A_LESS_THAN ="LT";
	public static final String A_SHIPMENT_CLOSED_FLAG="ShipmentClosedFlag";
	public static final String A_STATUS_DATE="StatusDate";
	public static final String A_SHIP_MONITOR_MAX_RECS = "500";
	public static final String SERVICE_KOHLS_SORT_PICK_SLIP_BY_SHIPMENT_KEY = "KohlsSortPickSlipByShipmentKey";
    public static final String ONE = "1";
    public static final String READY_FOR_CUSTOMER_PICKUP = "1100.70.06.30";
	public static final String STATUS_AWAITING_STORE_PICK = "1100.70.06.10";
	public static final String STATUS_PICKING_IN_PROGRESS = "1100.70.06.20";
	public static final String STATUS_STORE_PICK_COMPLETED = "1100.70.06.50.2";
	//Added for Returns
	public static final String STATUS_EXPIRED_RETURN = "1400.2";

	// Added for Order Capture drop 2 - Juned S
	public static final String STORE_PICKUP= "STORE_PICKUP";
	public static final String BPS= "BPS";
	public static final String PICK= "PICK";

	// Added for Order Modification drop 2 - Juned S
	public static final String RESOLVE_HOLD_STATUS= "1300";
	public static final String ADD_HOLD_STATUS= "1100";
	public static final String ECOM_CHNG_ORDR_HOLD= "EComChngOrdrHold";
	public static final String ECOM_CHNG_ORDR_HOLD_REASON_TXT= "ECommerce Change Order Hold";
	public static final String CHANGE_ORDER_INP_TMPLT= "global/template/api/extn/changeOrder_input.xml";
	public static final String KOHLS_ECOMORDRREPIRCE_WEBSERVICE= "KOHLS_EComOrderReprice_WebService";

	// Added for Order Status changes drop 2 - Juned S
	public static final String ORDER_STATUS_SENT_TO_ECOMM = "ORDER_STATUS_SENT_TO_ECOMM";
	public static final String KOHLS_GETORDERLIST_TEMPLATE= "global/template/api/extn/KohlsGetOrderList_output.xml";

	// Added for Order Modification changes drop 2 - Juned S
	public static final String BPS_MODIFICATN_TYPE = "BPS_MODIFICATN_TYPE";
	// Added by Baijayanta
	public static final String KOHLS_ORDER_STATUS = "KOHLS_ORDER_STATUS";

	//Oasis SFS RTAM HTTP issue
    public static final String URL="URL";
    public static final String UserId="UserId";
    public static final String Admin="admin";
    public static final String PSWD="password";

    public static final String Password="Password";
    public static final String ApiName="ApiName";
	public static final String IsAPI = "IsAPI";

	//OASIS - PMR-24186379000-Start - Added constants for Inv Sync Validation
	public static final String ATTR_YANTR_MSG_GRP_ID = "YantraMessageGroupID";
	public static final String BY_PASS_SYNC = "ByPassSync";
	public static final String EFC_SYNC_CODE_VAL = "ValidateEFCSync";
	public static final String MIN_SKU_PERCENT = "MIN_SKU_PERCENT";
	//End - Constants for Inv Sync Validation

	public static final String TILD = "~";
	public static final String COMMA = ",";
	public static final String CARET = "^";
	public static final String OPEN_SQ_BRACKET = "[";
	public static final String CLOSE_SQ_BRACKET = "]";
	public static final String SPL_CHARS = "SLASH_APP_SPL_CHARS";
	public static final String DBL_SLASH = "\\";
	public static final String DBL_QUOTE = "\"";
	public static final String SGL_BACK_SLASH = "\\";
	public static final String PARENT_NODE_NAME = "#document";
	public static final String STR_SPACE = "\\s";
	public static final String FWD_SLASH = "/";
	public static final String FWD_DBL_SLASH = "//";


	//Start -- Added for 08071,379,000 -- OASIS_SUPPORT 03/26/2014//
	public static final String CHARGE_NAME_YES_WE_CAN="Yes_We_Can";
	//End -- Added for 08071,379,000 -- OASIS_SUPPORT 03/26/2014//
	//Added for Inventory Updates drop 2 - Ashalatha
	public static final String HOLD_AREA= "HOLD_AREA.ex";
	public static final String ADJUSTMENT="ADJUSTMENT";
	public static final String ONHAND="ONHAND";
	public static final String SALES_FLOOR= "SALES_FLOOR.ex";
	public static final String TEMLATE_GET_SHIPMENT_LINE_LIST="global/template/api/extn_getShipmentLineList.xml";

	public static final String AWAIT_AUTH = "AWAIT_AUTH";
	 public static final String ZERO_INT = "0";
	 public static final String ONE_INT = "1";
	 public static final String NINE_INT = "999999";
	 public static final String THIRTEEN_INT = "13";
	 public static final String ZERO_TWO_INT= "02";
	 public static final String KOHLS_EXP_INTERVAL = "KOHLS_EXP_INTERVAL";
	 public static final String PPROCESS_TRANS_REQ = "ProcessTransactionRequest";
	 public static final String TYPE_CREDIT_CARD = "CREDIT_CARD";
	 public static final String HUNDRED_INT = "100";
	 public static final String SALE = "Sale";
	 public static final String VOID_SALE = "VoidSale";
	 public static final String INTERNAL = "internal";
	 public static final String PROTEGRITY =  "Protegrity";
	 public static final String DT_FORMAT_1 = "yyyyMMdd'T'HH:mm:ss";
	 public static final String DT_FORMAT_2 = "yyyy-MM-dd'T'HH:mm:ss.sss'Z'";
	 public static final String TYPE_DEBIT_CARD = "DEBIT_CARD";
	 public static final String PAYMENT_TYPE_DEBIT_CARD = "Debit Card";
	 public static final String PAYMENT_REQUEST = "PaymentRequest";
	 public static final String TENDER = "Tender";
	 public static final String DECIMAL_FORMAT = "0.00";
	 public static final String KEYED = "KEYED";
	 public static final String MERCHANDISE_RETURN_CREDIT = "MerchandiseReturnCredit";
	 public static final String STORE_873 = "873";
	 public static final String BOPUS_KOHLS_CHARGE_CARD ="KOHLS_CHARGE_CARD";
	 public static final String FALSE = "false";
	 public static final String KOHLS_CRD_VISA_EXP = "KOHLS_CRD_VISA_EXP";
	 public static final String	KOHLS_CRD_DISCVR_EXP = "KOHLS_CRD_DISCVR_EXP";
	 public static final String	KOHLS_CRD_MSTCRD_EXP = "KOHLS_CRD_MSTCRD_EXP";
	 public static final String	KOHLS_CRD_AMX_EXP = "KOHLS_CRD_AMX_EXP";
	 public static final String	KOHLS_CHARGE_EXP = "KOHLS_CHARGE_EXP";
	 public static final String	KOHLS_DEBIT_EXP = "KOHLS_DEBIT_EXP";
	 public static final String	KOHLS_STORE_VAL_EXP = "KOHLS_STORE_VAL_EXP";
	 public static final String KOHLS_DEFAULT_EXP = "KOHLS_DEFAULT_EXP";

	//Added for BOPUS Invoice drop 3 - Sudhakar P
	public static final String TRAN_ID_BOPUS_ORDER_INVOICE_0001_EX = "KOHLS_BOPUS_INVOICE.0001.ex";
	public static final String PLACED_IN_HOLD_LOCATION = "3350.14";
	public static final String API_GET_SHIPMENT_LIST_BOPUS_CONFIRM_SHIPMENT_TEMPLATE = "global/template/api/getShipmentListforBOPUSConfirmShipment_output.xml";

	//Added for EOD_Settelment drop 3 - Ashalatha

	public static final String AND_OPERATOR = "AND";

	public static final String GT_OPERATOR = "GT";
	public static final String LE_OPERATOR="LE";
	public static final String zero="0.00";

	public static final String TIMESTAMP_DATEFORMAT= "yyyy-MM-dd'T'kk:mm:ss";
	public static final String STATUS_VAL = "Awaiting Store Pick";
	public static final String ORDER_STATUS_AWAITING_STORE_PICK = "3350.12";

	 // Added for Alerts drop 4 - Juned S
	 public static final String CLOSED = "CLOSED";
 	 public static final String GETEXCEPTIONLIST_API = "getExceptionList";
 	 public static final String MULTIAPI_API = "multiApi";
	 public static final String SMTP_HOST_PROPERTY = "mail.smtp.host";
	 public static final String TIER3_EMAIL_TIMING = "TIER3_EMAIL_TIMING";
	 public static final String FROM_EMAIL_ID = "FROM_EMAIL_ID";
	 public static final String TO_EMAIL_ID_E3_PREFIX = "TO_EMAIL_ID_E3_PREFIX";
	 public static final String TO_EMAIL_ID_E3_SUFFIX = "TO_EMAIL_ID_E3_SUFFIX";
	 public static final String TO_EMAIL_ID_ALL_MANAGER_PREFIX = "TO_EMAIL_ID_ALL_MANAGER_PREFIX";
	 public static final String TO_EMAIL_ID_ALL_MANAGER_SUFFIX = "TO_EMAIL_ID_ALL_MANAGER_SUFFIX";
	 public static final String TO_EMAIL_ID_BYPASS = "TO_EMAIL_ID_BYPASS";
	 public static final String TO_EMAIL_ID_BYPASS_VALUE = "TO_EMAIL_ID_BYPASS_VALUE";
	 public static final String USE_TO_EMAIL_ID_BYPASS_VALUE = "USE_TO_EMAIL_ID_BYPASS_VALUE";
	 public static final String EMAIL_SUBJECT_TIER1= "EMAIL_SUBJECT_TIER1";
	 public static final String EMAIL_TIER1_MESSAGE_PART1 = "EMAIL_TIER1_MESSAGE_PART1";
	 public static final String EMAIL_TIER1_MESSAGE_PART2 = "EMAIL_TIER1_MESSAGE_PART2";
	 public static final String EMAIL_TIER1_MESSAGE_PART3 = "EMAIL_TIER1_MESSAGE_PART3";
	 public static final String EMAIL_SUBJECT_TIER3_PART1 = "EMAIL_SUBJECT_TIER3_PART1";
	 public static final String EMAIL_SUBJECT_TIER3_PART2 = "EMAIL_SUBJECT_TIER3_PART2";
	 public static final String EMAIL_SUBJECT_TIER3_PART3 = "EMAIL_SUBJECT_TIER3_PART3";
	 public static final String EMAIL_SUBJECT_TIER3_PART4 = "EMAIL_SUBJECT_TIER3_PART4";
	 public static final String EMAIL_TIER3_MESSAGE_PART1 = "EMAIL_TIER3_MESSAGE_PART1";
	 public static final String EMAIL_TIER3_MESSAGE_PART2 = "EMAIL_TIER3_MESSAGE_PART2";
	 public static final String EMAIL_TIER3_MESSAGE_PART3 = "EMAIL_TIER3_MESSAGE_PART3";
	 public static final String EMAIL_TIER3_MESSAGE_PART4 = "EMAIL_TIER3_MESSAGE_PART4";
	 public static final String EMAIL_TIER3_MESSAGE_PART5 = "EMAIL_TIER3_MESSAGE_PART5";
	 public static final String SEND_ALERT_EMAILS = "SEND_ALERT_EMAILS";
	 public static final String EMAIL_HOST = "EMAIL_HOST";
	 public static final String KOHLS_STORE_MANAGER_QUEUE ="KOHLS_STORE_MANAGER_QUEUE";
	 public static final String KOHLS_STORE_ASSOCIATE_QUEUE ="KOHLS_STORE_ASSOCIATE_QUEUE";

	 // default properties for alert emails
	 public static final String DEFAULT_EMAIL_HOST = "lnmail01.kohls.com";
	 public static final String DEFAULT_FROM_EMAIL_ID = "pickupinstore_order_alerts@kohls.com";
	 public static final String DEFAULT_TO_EMAIL_ID = "robert.fea@kohls.com";
	 public static final String DEFAULT_EMAIL_SUBJECT = "Shipment ready for pick";

	 // Added drop 4 - Asha
	 public static final String GET_SHIPMENT_LIST_API = "getShipmentList";
	 public static final String TRAN_ID_CUSTOMER_PICK_0001_EX = "Customer Pick.0001.ex";
	 public static final String STATUS_PLACED_IN_HOLD_AREA = "1100.70.06.50.4";
	 public static final String SHIPMENT_READY_FOR_CUSTOMER_PICK_UP = "3350.035";

	 // Constants for LocationFeed Implementation.
	 public static final String ADJUSTMENT_TYPE = "AdjustmentType";
	 public static final String REASON_CODE = "ReasonCode";
	 public static final String REF_3 = "Reference_3";

	 // Constants added for creating new YFSEnvironment object.
	 public static final String USER_ID = "userId";
	 public static final String PROG_ID = "progId";
	 public static String GET_PROP_ELEMENT = "GetProperty";
	 public static String PROP_NAME_ATT = "PropertyName";
	 public static String GET_PROP_API = "getProperty";
	 public static String PROP_VALUE_ATT = "PropertyValue";

	 public static final String ADJUST_INV_API = "adjustInventory";
	 // Constants for NetCool logger implementation.
	 public static final String NET_COOL_ERR_MSG = "Input XML to NetCool logger is empty or null";

	 // Constants for LocationFeed Implementation.
	 public static final String XPATH_FOR_ORGANIZATION = "/LocationFeed/Organization/@OrganizationCode";
	 //public static final String XPATH_FOR_ORGANIZATION = "LocationFeed/Organization";
	 public static final String XPATH_FOR_CALENDAR = "/LocationFeed/Calendars/Calendar/@CalendarId";
	 //public static final String XPATH_FOR_CALENDAR = "LocationFeed/Calendars/Calendar";
	 public static final String MANAGE_ORGANIZATION_HIERARCHY_API = "manageOrganizationHierarchy";
	 public static final String CHANGE_CALENDAR_API = "changeCalendar";
	 public static final String CREATE_CALENDAR_API = "createCalendar";
	 public static final String GET_CALENDAR_LIST_API = "getCalendarList";
	 public static final String GET_DISTRIBUTION_LIST_API = "getDistributionList";
	 public static final String CREATE_DISTRIBUTION_API = "createDistribution";
	 public static final String DG_NAME_PROPERTY = "DG_NAME";
	 public static final String OWNER_KEY_PROPERTY = "OWNER_KEY";
	 public static final String ITEM_SHIP_NODE_XML = "<ItemShipNode ActiveFlag=\'Y\' ItemId=\'ALL\' />";
	 public static final String ERROR_CODE_ATTRIBUTE = "ErrorCode";
	 public static final String ERROR_RELATED_MORE_INFO_ATTRIBUTE = "ErrorRelatedMoreInfo";
	 public static final String ERROR_DESCRIPTION = "ErrorDescription";
	 public static final String ERROR_CODE_EXTN000001 = "EXTN000001";
	 public static final String ERROR_CODE_EXTN000001_DESCRIPTION = "Organization already is associated to a Calendar";
	 public static final String CONST_ = "_";

	 //Added by Naveen for BOPUS Status Updates
	 public static final String KOHLS_GETORDERLIST_STATUSUPDATE_TEMPLATE= "global/template/api/extn/KohlsBOPUSGetOrderList_StatusUpdate.xml";
	 public static final String KOHLS_GETSHIPLIST_STATUSUPDATE_TEMPLATE= "global/template/api/extn/KohlsBOPUSGetShipmentList_StatusUpdate.xml";
	 public static final String KOHLS_GET_SHIPMENT_STORE_EVENTS = "getKohlsShipmentStoreEventsList";
	 public static final String KOHLS_SEND_SHIPMENT_STATUS_TO_ECOMM = "KohlsSendShipmentStatusToEcommSyncService";
	 public static final String KOHLS_GETORDERLIST_EXP_STATUSUPDATE_TEMPLATE= "global/template/api/extn/KohlsBOPUSGetOrderList_ExpiredStatusUpdate.xml";


	 //public static final String API_GET_SHIPMENT_LIST_BOPUS_CONFIRM_SHIPMENT_TEMPLATE = "global/template/api/getShipmentListforBOPUSConfirmShipment_output.xml";

	 //PickedUp Confirm notification - Baijayanta
	 public static final String KOHLS_BPS_PICKEDUP_SYNC= "KohlsBpsPickedUpMsgToMrktng";
	 public static final String PICKUP_CONFIRMED = "CUSTOMER_PICKEDUP";


	 // Added for Customer Notification drop 4 - Juned S
	 public static final String ORDER_READY_FOR_PICK = "ORDER_READY_FOR_PICK";
	 public static final String KOHLS_READY_FOR_CUST_MSG_TO_MRKTNG = "KohlsBpsReadyForCustMsgToMrktng";

	 // Added for Customer Notification drop 4 - Ravi
	 public static final String API_SHIPMENT_CONSOLIDATION_ORDER_LIST = "global/template/api/extn/KohlsShipConsolGetOrderList_output.xml";;

	// Added for Customer Notification drop 5 - Juned S
	 public static final String KOHLS_ORDER_DELAY_MSG_TO_MRKTNG = "KohlsBpsOrdrDelayMsgToMrktng";
	 public static final String CHANGE_ORDER_API = "changeOrder";
	 public static final String API_GET_ORDER_LIST_BOPUS_CONSOL_TEMPLATE = "global/template/api/extn/KohlsShipConsolGetOrderList_output.xml";
	 public static final String API_GET_SHIPMENT_LIST_BOPUS_CONSOL_TEMPLATE = "global/template/api/extn/KohlsShipConsolGetShipmentList_output.xml";
	 public static final String API_GET_SHIPMENT_LIST_STATUS_TEMPLATE = "global/template/api/extn/KohlsCheckShipmentStatus_output.xml";
	 public static final String KOHLS_BPS_ORDR_MOD_CUST_MSG= "KohlsOrderModification";


	 // Added for Customer Notification drop 5 - Ravi
	 public static final String A_EXTN_CUST_NOTIFICATION_SENT = "ExtnCustNotificationSent";
	 public static final String SERVICE_SHIPMENT_STORE_EVENTS = "KOHLS_ShipmentStoreEvents";
	 public static final String API_CREATE_ASYNC_REQUEST = "createAsyncRequest";

	 //Added for Stop demand update to GIV on create Order for BOPUS Lines
	 public static final String BOPUS_LINES = "BOPUS_LINES";

	 //Added for Drop 4 - Customer Notification
	 public static final String STATUS_READY_FOR_CUSTOMER = "1100.70.06.30";
	 public static final String PICKUP_REMINDER_DAYS = "pickupReminderDays";
	 public static final String FINAL_PICKUP_REMINDER_DAYS = "FinalPickupReminderDays";
	 public static final String PICKUP_REMINDER = "PICKUP_REMINDER";
	 public static final String FINAL_PICKUP_REMINDER = "FINAL_PICKUP_REMINDER";

	 public static final String A_SHIPMENT_LINE_NO = "ShipmentLineNo";

	public static final String PPROCESS_TRANS_RESP = "ProcessTransactionResponse";
	public static final String A_UPDATE_LOCATION_ITEMS="KohlsUpdateLocationItems";
	public static final String TEMPLATE_SHIPMENTS_PICK_PROCESS="global/template/api/getShipmentList_PickingProcess.xml";
	public static final String TEMPLATE_CHANGE_SHIPMENTS_PICK_PROCESS="global/template/api/changeShipment_PickingProcess.xml";
	public static final String TEMPLATE_GET_SHIPMENT_LINE_LIST_PICK_PROCESS ="global/template/api/getShipmentLineList_PickingProcess.xml";

	 //GetOrderDetails Audit
 	 public static final String API_SHIPMENT_STORE_EVENTS = "getShipmentStoreEventsList";
 	 public static final String V_SHORT_PICK = "ShortPick";
 	 public static final String API_GET_SHIPMENT_LIST_FOR_ORDER = "getShipmentListForOrder";
 	 public static final String V_KOHLS_COM = "KOHLS.COM";
 	 public static final String V_CANCEL = "CANCEL";
 	 public static final String API_GET_ORDER_LIST_BOPUS_TEMPLATE = "global/template/api/extn/KohlsBOPUSGetOrderList_output.xml";
 	 public static final Object V_PICK = "PICK";
 	 public static final String V_CANCEL_STATUS = "9000";

	//Added MLS Integration
	public static final String GET_SHIPMENT_LINE_LIST_API = "getShipmentLineList";
	public static final String V_PROCESS_BACK_ROOM_PICK = "Process Backroom Pick.0001.ex";

	public static final String CONFIRM_SHIPMENT = "confirmShipment";
	public static final String CHANGE_SHIPMENT_STATUS = "changeShipmentStatus";
	public static final String CHANGE_TO_EXPIRED = "changeToExpired";


	public static final String API_GET_ORDER_AUDIT_LIST = "getOrderAuditList";
	public static final String GET_ORDER_AUDIT_LIST_OUTPUT_TMPLT = "global/template/api/extn/KohlsGetOrderAuditList_output.xml";
	public static final String ORDER_LINE = "ORDER_LINE";
	public static final String ORDER = "ORDER";

	public static final String YANTRA_HTTP_TESTER = "YantraHttpTester";
	public static final String YFSENV_PROG_ID= "YFSEnvironment.progId";
	public static final String INTEROP_API_NAME= "InteropApiName";
	public static final String IS_FLOW= "IsFlow";
	public static final String INTEROP_API_DATA= "InteropApiData";
	public static final String TEMPLATE_DATA= "TemplateData";
	public static final String YFSENV_USERID= "YFSEnvironment.userId";
	public static final String YFSENV_PWD= "YFSEnvironment.password";
	public static final String HTTP = "http";
	public static final String TRUE = "true";
	//public static final String EACH = "EACH";
	public static final String STOCK_ROOM= "STOCK_ROOM.ex";

	public static final String MIXED = "MIXED";
	public static final String BACK_ORDERED = "1300";
	public static final String V_OPEN_API_HEADER_KEY_PARAM = "X-APP-API_KEY";
	public static final String V_BYPASS_OPEN_API= "BYPASS_OPEN_API";
	public static final String V_BYPASS_OPEN_API_PICKUP= "BYPASS_OPEN_API_PICKUP";
	public static final String V_OPEN_API_RESPONSE = "OPEN_API_RESPONSE";
	public static final String V_OPEN_API_ALT_TEXT = "OPEN_API_ALT_TEXT";
	public static final String V_OPEN_API_PROXY_HOST = "OPEN_API_PROXY_HOST";
	public static final String V_OPEN_API_PROXY_PORT = "OPEN_API_PROXY_PORT";

	public static final String CHANGE_SHIPMENT_API = "changeShipment";

	public static final String V_ITEM_BEING_PICKED = "StorePick";
	public static final String V_SHORT_PICKED = "ShortPick";
	public static final String V_PICK_COMPLETED = "StorePick";

	//public static final String GET_SHIPMENT_LINE_LIST_API = "getShipmentLineList";
	// public static final String V_PROCESS_BACK_ROOM_PICK = "Process Backroom Pick.0001.ex";
	 public static final String API_GET_SHIPMENT_LIST_MLS_TEMPLATE = "global/template/api/extn/KohlsMLSGetShipmentList.xml";
	 public static final String API_GET_SHIPMENT_LINE_LIST_BARCODE_TEMPLATE = "global/template/api/getShipmentLineList_barcodeLookup.xml";

	 public static final String V_PICKING_IN_PROGRESS = "StorePick";
	 public static final String V_ITEM_IS_BEING_PICKED = "StorePick";
	 //public static final String V_SHORT_PICKED = "ShortPick";
	 public static final String V_PICKING_SUSPENDED = "StorePickSuspend";
	 public static final String V_PICKING_RESUMED = "StorePickResume";
	 public static final String V_UNDO_PICKING = "StorePick";
	 public static final String V_PICKING_COMPLETED = "StorePick";
	 public static final String V_PLACED_IN_HOLD_AREA = "StorePick";
	 public static final String V_READY_FOR_CUSTOMER_PICKUP = "StorePick";
	 public static final String SERVICE_CRTE_PUB_SHIP_STR_EVNTS = "KOHLSCreateStoreEvents";
	 public static final String V_MIXED = "MIXED";
	 public static final String V_SRO = "SRO";
	 public static final String V_SFO = "SFO";
	 //public static final String STOCK_ROOM= "STOCK_ROOM.ex";
	 public static final String EACH = "EACH";
	 public static final String WS_MLS_INPUT_XSL = "global/template/xsl/KohlsInputForMLSGetItemLocationWS.xsl";

	 //public static final String SFO = "SFO";
	 //public static final String SRO = "SRO";
	 //public static final String MIXED = "MIXED";
	 //public static final String BACK_ORDERED = "1300";

	 public static final String CANCELLED  = "Cancelled";
	 public static final String KOHLS_BPS_ORDR_CANCEL_CUST_MSG ="KohlaBpsOrdrCnclCustMsgToMrktng";
	 public static final String REASON_CODE_CUST_INITIATED_MODIFICATION = "CUST_INITIATED_MODIFICATION";
	 public static final String ORDER_CANCELLATION_CUST_NOTIFICATION = "ORDER_CANCELLATION";
		 public static final String CALENDAR_GET_ORGANIZATION_HIERARCHY_TEMPLATE="global/template/api/extn/kohlsBOPUSGetOrganizationHierarchy_Output.xml";


		 //Drop 8
		 public static final String KOHLS_SHP_STATUS_GET_SHIPMENT_LIST_OUTPUT_TMPLT = "global/template/api/extn/KohlsBOPUSShpStatusGetShipmentList_output.xml";
		 public static final String KOHLS_GET_SHIPMENT_STORE_EVENTS_LIST_SERVICE = "KohlsGetShipmentStoreEventsListForShipStatus";
		 public static final String ACTION_Create ="Create";

		 public static final String A_REQUESTED_SHIPMENT_DATE = "RequestedShipmentDate";
		 public static final String A_EARLIEST_SHIFT_START_TIME = "EarliestShiftStartTime";
		 public static final String A_LAST_SHIFT_END_TIME = "LastShiftEndTime";

		 public static final String A_FROM_DATE = "FromDate";
		 public static final String A_TO_DATE = "ToDate";

		  //Added MLS Integration


		 public static final String SERVICE_GET_INV_STOREPICK_WS = "KohlsGetInvDetailsforStorePickWebservice";
		 public static final String SERVICE_GET_ITEM_LOC_STOREPICK_WS = "KohlsGetItemLocationForStorePickService";

		 //MLS Web service caller callEndpointMLS method in WebServiceCaller.java
		 public static final String V_SERVICENAME = "SterlingServices";
		 public static final String V_PORTNAME = "SterlingServicesSOAP";
		 public static final String V_SOAPACTION = "soapAction";
		 public static final String V_ENDPOINT = "endPoint";
	public static final String MAX_VALUE="15";
	public static final String SHPMT_STATUS_UNITS_VAL="SHPMT_STATUS_UNITS";
	public static final String MAX_LIMIT_VAL="MaxLimit";
	public static final String AGED_LIMIT_VAL="AgedLimit";
	public static final String A_AGED_ORDER_COUNT="AgedOrderCount";
	public static final String A_AGED_ORDER_UNIT_COUNT="AgedOrderUnitCount";
	public static final String ATTR_FROM_SHIPMENT_KEY="FromShipmentKey";
	public static final String ATTR_TO_SHIPMENT_KEY="ToShipmentKey";
	public static final String ATTR_SHIPMENT_QUERY_TYPE="ShipmentKeyQryType";
	public static final String ATTR_SHIPMENT_BETWEEN_QUERY_TYPE="BETWEEN";
	public static final String ATTR_OPERATOR="Operator";
	public static final String ATTR_AND_VAL="And";
	public static final String E_AND="And";
	public static final String ATTR_NAME="Name";
	public static final String A_SHIPMENT_COUNT="ShipmentCount";
	public static final String A_UNIT_COUNT="UnitCount";
	public static final String A_ERROR_CODE="ErrorCode";
	public static final String A_ERROR_CODE_DESC="ErrorDescription";
	public static final String A_MESSAGE="Message";
	public static final String A_EXTN_PICK_SEQUENCE_NO = "ExtnPickSequenceNo";
	public static final String IS_GIV_FAILURE = "IsGIVFailure";
	public static final String EXTN_IS_GIV_FAILURE = "ExtnIsGIVFailure";
	public static final String EXTN_GIV_SR = "ExtnGIVStockRoom";
	public static final String EXTN_GIV_SF = "ExtnGIVFloor";
	public static final String EXTN_FROM_SR = "ExtnFromStockRoom";
	public static final String EXTN_FROM_SF = "ExtnFromFloor";
	public static final String MIXED_SHIPMENTS = "MixedShipments";
	public static final String ITEM_COUNT = "ItemCount";
	public static final String ITEM_COUNT_STOCKROOM = "StockRoom";
	public static final String ITEM_COUNT_FLOOR = "SalesFloor";
		 public static final String V_TIMEOUT = "timeOut";
		 public static final String V_ENDPOINTURL = "endPointURL";
		 public static final String MLS_USE_DEFAULT_STORE = "MLS_USE_DEFAULT_STORE";
		 public static final String MLS_DEFAULT_STORE_LOOKUP = "MLS_DEFAULT_STORE_LOOKUP";
		 public static final String MLS_ENDPOINT_URL_PREFIX = "MLS_ENDPOINT_URL_PREFIX";
		 public static final String MLS_ENDPOINT_URL_SUFFIX = "MLS_ENDPOINT_URL_SUFFIX";
		 public static final String MLSSOAPACTIONURL_PROPERTY = "MLSSOAPACTIONURL";
		 public static final String MLSSOAPACTION_GETITEMLOCATIONS = "MLSSOAPACTION_GETITEMLOCATIONS";
		 public static final String MLSSOAPACTION_GETLOCATIONDETAILS = "MLSSOAPACTION_GETLOCATIONDETAILS";
		 public static final String MLSSOAPACTION_UPDATELOCATIONITEMS = "MLSSOAPACTION_UPDATELOCATIONITEMS";

		 public static final String MLSSOAPACTION_PUTAWAYINVENTORYITEMS = "MLSSOAPACTION_PUTAWAYINVENTORYITEM";

		  //SFS July for MLS
		 public static final String END_POINT_USER_MLS="END_POINT_USER_MLS";
		 public static final String END_POINT_PWD_MLS="END_POINT_PWD_MLS";
		 public static final String V_END_POINT_USER = "endPointUser";
	         public static final String V_END_POINT_PWD = "endPointPassword";
	         public static final String A_UPDATE_LOCATION_ITMES="KohlsUpdateLocationItems";


		 // Open API Image Web service call - Ravi
		 public static final String V_OPEN_API_BASEURL = "OpenAPI_BaseURL";
		 public static final String V_OPEN_API_KEY = "OpenAPI_Key";
		 //Start changes for MP-EmailCR - OMS Team
		 public static final String V_OPEN_MPAPI_KEY = "OpenMPAPI_Key";
		//End changes for MP-EmailCR - OMS Team
		 //public static final String V_OPEN_API_HEADER_KEY_PARAM = "X-APP-API_KEY";
		 public static final String V_SKU_DETAIL = "skuDetail";
		 //public static final String V_BYPASS_OPEN_API= "BYPASS_OPEN_API";
		 //public static final String V_OPEN_API_RESPONSE = "OPEN_API_RESPONSE";
		 public static final String V_CONNECTION_TIMEOUT = "connectionTimeout";
		 public static final String V_CONNECTION_READ_TIMEOUT = "connectionReadTimeout";

		 //Location Details Desc stamping at Shipment header - Ravi
		 public static final String API_GET_SHIPMENT_LIST_MLSLOCDESC_TEMPLATE = "global/template/api/extn/KohlsMLSLocationDescGetShipmentList.xml";
		 public static final String SERVICE_WS_MLS_LOC_DESC = "KohlsBOPUSGetLocationDetailsWS";
		 public static final String SERVICE_WS_MLS_UPD_PICK = "KohlsBOPUSUpdatePicking";

		 public static final String GET_ORGANIZATION_HIERARCHY_API = "getOrganizationHierarchy";
		 public static final String API_GET_CALENDAR_DAY_DETAILS_API="getCalendarDayDetails";

	     public static final String SHIPMENT = "Shipment";
	   	 public static final String PICKING_SUSPENDED ="Picking_Suspended";
	   	 public static final String SHIPMENT_SUSPEND_HOLD ="Shipment suspend hold";
	   	 public static final String SUSPEND_STATUS="1100";
	   	 public static final String RESUME_STATUS = "1300";
	   	 public static final String SFO = "SalesFloor";
	   	 public static final String SRO = "Stockroom";

		 public static final String V_SHIPPED_STATUS = "Shipped";
		 public static String _JEW = "_JEW";
	   	 public static String JEW = "JEW";

		 	public static final String V_ITEM_LEGAL_CALLBACK = "Item legal callback";
			public static final String PLU_MESSAGE = "MESSAGE";
			public static final String PLU = "PLU";
			public static final String REQUEST = "Request";
			public static final String DATE = "MM/dd/yy HH:mm:ss";

			public static final String TRAN_CONFIRM_SHIPMENT = "CONFIRM_SHIPMENT";
			public static final String TRAN_PROCESS_PENDING_RET = "PROCESSPENDINGRETURN.0001.ex";
			public static final String API_CONFIRM_SHIPMENT = "confirmShipment";
	//Common Code
	 public static final String CODE_TYPE_ORD = "ORDER";
	 public static final String CODE_TYPE_SHP = "SHIPMENT";
	 public static final String V_CODE_TYPE_ORD = "BOPUS_ORD_STATUS";
	 public static final String V_CODE_TYPE_SHP = "BOPUS_SHPMNT_STATUS";

	 public static final String API_GET_COMMON_CODE_LIST_TEMPLATE = "global/template/api/extn/KohlsGetCommonCodeList.xml";

	 public static final String CC_DESC_SHIPMENT_CREATED = "Shipment_Created";
	 public static final String CC_DESC_AWAITING_STORE_PICK = "Awaiting_Store_Pick";
	 public static final String CC_DESC_PICKING_IN_PROGRESS = "Picking_In_Progress";
	 public static final String CC_DESC_STORE_PICK_COMPLETED = "Store_Pick_Completed";
	 public static final String CC_DESC_PLACED_IN_HOLD_LOCATION = "Placed_In_Hold_Location";
	 public static final String CC_DESC_READY_FOR_CUSTOMER = "Ready_For_Customer";
	 public static final String CC_DESC_SHIPMENT_SHIPPED = "Shipment_Shipped";
	 public static final String CC_DESC_CUSTOMER_PICKED_UP = "Customer_Picked_Up";
	 public static final String CC_DESC_EXPIRED_PICK_UP = "Expired_Pick_Up";
	 public static final String CC_DESC_RETURNED = "Returned";
	 public static final String CC_DESC_PENDING_EXPIRED_RETURN = "Pending_Expired_Return";
	 public static final String CC_DESC_SHIPMENT_CANCELLED = "Shipment_Cancelled";

	 public static final String CC_DESC_DRAFT_ORD_CREATED = "Draft_Order_Created";
	 public static final String CC_DESC_DRAFT_ORD_RESERVED = "Draft_Order_Reserved";
	 public static final String CC_DESC_CREATED = "Created";
	 public static final String CC_DESC_UNSCHEDULED = "UnScheduled";
	 public static final String CC_DESC_BACK_ORDERED = "Back_Ordered";
	 public static final String CC_DESC_SCHEDULED = "Scheduled";
	 public static final String CC_DESC_RELEASED = "Released";
	 public static final String CC_DESC_INCLUDED_IN_SHIPMENT = "Included_In_Shipment";
	 public static final String CC_DESC_PICK_UP_EXCEPTION = "Pick_Up_Exception";
	 public static final String CC_DESC_AWAITING_ORDER_CLOSURE = "Awating_Order_Closure";
	 public static final String CC_DESC_AWAITING_INVOICE_CREATION = "Awaiting_Invoice_Creation";
	 public static final String CC_DESC_INVOICED = "Invoiced";
	 public static final String CC_DESC_CANCELLED = "Cancelled";
	 public static final String CC_DESC_STORE_PICK_IN_PROGRESS = "Store_Pick_In_Progress";
	 public static final String CC_DESC_STORE_SHIPPED = "Shipped";



	 public static final String TMP_TIER_FLAG = "TierFlag";
	 public static final String V_TIER2 = "TIER2";
	 public static final String V_TIER3 = "TIER3";
	 public static final String V_TIER0 = "";

	 // constants for create order agent
	 public static final String API_CREATE_ORDER = "createOrder";

	 // Order Modifications Hold Check

	 public static final String API_GET_ORDER_HOLDS_TEMPLATE =  "global/template/api/extn/modOrderHoldCheck_output.xml" ;
	 public static final String API_GET_SHP_HOLDS_TEMPLATE = "global/template/api/extn/modShpHoldCheck_output.xml";
	 public static final String V_HOLD_CONFIRM_SHPMNT = "HOLD_CFRM_SHPMT";
	 public static final String API_SHPMNT_LIST_FOR_ORDR_TEMPLATE = "global/template/api/extn/shpmntListForOrder_output.xml";
	 public static final String ORDER_HOLD_TYPE = "EComChngOrdrHold";
	 public static final String SHPMNT_HOLD_TYPE = "HOLD_CFRM_SHPMT";

//GIV Short Pick At Store
	public static final String KOHLS_MANAGE_INVENTORY_NODE_CONTROL_SERVICE = "Kohls_manageInventoryNodeControl";

//Sourcing- ATP Call
	 public static final String GET_ORDER_LIST_TEMPLATE="global/template/api/getOrderListTemplate.xml";
	 public static final String PROMISE_ELEMENT = "Promise";
	 public static final String CALLING_API_ATTRIBUTE= "CallingAPI";
	 public static final String RESERVATION_ELEMENT = "Reservation";
	 public static final String API_GET_ITEM_LIST_WITH_EXTN_FIELDS_TEMPLATE_PATH = "global/template/api/getItemListForExtnFields_output.xml";

	 //Sourcing - Transfer Order
	public static final String A_DEMAND_CHANGES = "DemandChanges";
      public static final String A_COST_REFERENCE = "CostReference";
      public static final String TRANSFER_ORDER = "TransferOrder";
      public static final String ALLOCATED = "ALLOCATED";
      public static final String DISCARD_MSG = "DiscardMessage";


//RDC shipment
   public static final String E_CREATE_LPN = "CreateLPN";
   public static final String E_LPN = "LPN";
   public static final String E_LPN_LOCATION = "LPNLocation";
   public static final String E_DELETE_LPN = "DeleteLPN";

 //Start -- Added as part of 3PL Project..
 	public static final String STATUS_SENT_TO_3PL = "3200.04";
 	public static final String SERVICE_KOHLS_SEND_RELEASE_TO_3PL = "KohlsSendReleaseOrderTo3PLSyncService";
 	public static final String NODES_FOR_3PL = "3PL_NODES";
 	public static final String ORGANIZATION_CODE_DEFAULT = "DEFAULT";
 	public static final String STATUS_SHIP_ALONE_SENT_TO_3PL = "1100.015";
 	public static final String STATUS_SHIP_ALONE_SENT_TO_WMOS = "1100.01";
 	public static final String SERVICE_KOHLS_SEND_SHIP_ALONE_RELEASE_TO_3PL = "KohlsSendShipAloneOrderTo3PLSyncService";
 	//End -- Added as part of 3PL Project..

//	Start -- Added as part of SCS Project
	public static final String SCS_DEL_DATE_SHIP_LEAD_DAYS_CODE_TYPE = "SHIP_LEAD_DAYS";
	public static final String A_CANCELLATION = "Cancellation";
	public static final String API_GET_KOHLS_CUSTOMER_NOTIFICATION_LIST = "getKohlsCustomerNotificationListService";
	public static final String API_CREATE_KOHLS_CUSTOMER_NOTIFICATION_LIST = "createKohlsCustomerNotificationService";
	public static final String API_UPDATE_KOHLS_CUSTOMER_NOTIFICATION_LIST = "changeKohlsCustomerNotificationService";
	public static final String API_DELETE_KOHLS_CUSTOMER_NOTIFICATION_LIST = "deleteKohlsCustomerNotificationService";
	public static final String A_PICK = "PICK";
	public static final String A_BOPUS = "BPS";
	public static final String ATTR_CHANGE_IN_ORDERED_QTY = "ChangeInOrderedQty";
	public static final String GET_ORDER_LIST_FOR_FULL_CANCELLATION="global/template/api/getOrderListForFullCancellation.xml";
	public static final String ITEM_UNAVAILABLE ="Item Unavailable";
//	public static final String API_FULL_CANCELLATION_TEST = "FullCancellationTestService";
    public static final String ASYNC_AGENT = "ASYNC_REQ_PROCESSOR_SCS";
    public static final String ROOT_NODE_FOR_COMPLETE_CANCELLATION = "oms:OrderCancellationOMSRequest";
    public static final String ROOT_NODE_FOR_COMPLETE_SHIPMENT = "com:CompleteShipmentOMSRequest";
    public static final String ROOT_NODE_FOR_PARTIAL_CANCELLATION = "oms:OrderModificationOMSRequest";
    public static final String ROOT_NODE_FOR_PARTIAL_SHIPMENT = "par:PartialShipmentOMSRequest";
    public static final String IS_CCS_DOWN = "isCCSDown";
    public static final String KOHLS_SEND_MSG_FOR_ASYNC_REQ_SERVICE = "KohlsSendMsgForAsyncReqToQ";
	public static final String KOHLS_CALL_PARTIAL_CANCEL_ASYNC_REQ_SERVICE = "KohlsCallPartialCancelAsyncReqService";
    public static final String KOHLS_FULL_CANCELLATION_ASYNC_REQ_SERVICE = "KohlsFullCancellationAsyncReqService";
    public static final String KOHLS_CALL_PARTIAL_SHIPPED_ASYNC_SERVICE = "KohlsCallPartialShippedAsyncReqService";
    public static final String KOHLS_FULL_SHIPMENT_ASYNC_REQ_SERVICE = "KohlsFullShipmentAsyncReqService";
	public static final String API_CALL_PARTIAL_MAIL_WEBSERVICE = "KohlsCallPartialEmaillWebServiceSync";

	public static final String A_MODIFICATION_MESSAGE_TYPE = "Modification";
	public static final String A_MODIFICATION_LINE_CHANGE = "Line Change";
	public static final String A_MODIFICATION_LINE_CANCEL = "Line Cancel";
	public static final String MODIFICATION_REASON_CODE = "MOD_REASON_CODE";
	public static final String SERVICE_KOHLS_SCS_GET_ORDER_LIST_PRUNE = "KohlsSCSGetOrderListPrune";

	public static final String A_DISCOUNT_CHARGE_TLD = "TLD";
	public static final String A_PROMOTION_TYPE_TLD = "TLD";
	public static final String A_DISCOUNT_CHARGE_NAME_BOGO = "BOGO";
	public static final String A_DISCOUNT_CHARGE_NAME_GWP = "Gift_With_Purchase";
	public static final String A_DISCOUNT_CHARGE_NAME_PWP = "Purchase_with_purchase";

	public static final String GET_ORDER_LIST_FOR_BEFORE_CHANGE_ORDER_UE="global/template/api/getOrderListForBeforeChangeOrderUE.xml";
	public static final String SERVICE_PRUNE_PARTIAL_CANCEL_EMAIL_OUTPUT = "KohlsSCSTransformPartialCancelEmailMessageService";

	public static final String A_SHIPMENT_MESSAGE_TYPE = "Shipment";
	public static final double ORDER_SHIPPED_STATUS = 3700;
	public static final double AWAITING_INVOICE_CREATION_STATUS = 3700.0003;
	public static final String COMPLETE_SHIPMENT = "CompleteShipment";
	public static final String PARTIAL_SHIPMENT = "PartialShipment";
	public static final double ORDER_LINE_SHIPPED_STATUS = 3700;
	public static final double ORDER_LINE_NOT_YET_SHIPPED_STATUS = 3200.03;
	public static final double ORDER_LINE_BACKORDERED_FROM_NODE_STATUS = 1400;
	public static final double SHIPMENT_CANCELLED_STATUS = 9000;
	public static final String SCS_SKIP_ORDERLINE_STATUS_LIST = "SCS_SKIP_OL_STAT_LST";
	public static final String SCS_SKIP_SHIPMENT_STATUS_LIST = "SCS_SKIP_SHP_STATUS";
	public static final String PAYMENT_TYPE_GIFT_CARD = "Gift Card";

	public static final String  KOHLS_EXECUTE_PARTIAL_SHIP_CONFIRM_EMAIL_SERVICE = "KohlsExecutePartialShipConfirmEmail";
	public static final String  KOHLS_EXECUTE_PARTIAL_SHIP_CONFIRM_EMAIL_SYNC_SERVICE = "KohlsExecutePartialShipConfirmEmailSync";
	public static final String  KOHLS_SEND_PARTIAL_SHIP_EMAIL_SYNC_SVC = "KohlsSendPartialShipmentEmailSyncService";
	public static final String  KOHLS_EXECUTE_PARTIAL_CANCEL_EMAIL_SERVICE = "KohlsExecutePartialCancelEmail";
	public static final String  KOHLS_SEND_COMPLETE_SHIPMENT_EMAIL_XML_TO_Q_SERVICE = "KohlsSendCompleteShipmentEmailXMLToQ";
	public static final String  KOHLS_SEND_COMPLETE_SHIPMENT_EMAIL_SYNC_SERVICE = "KohlsSendCompleteShipmentEmailSyncService";
	public static final String KOHLS_CALL_PARTIAL_CANCEL_WEBSERVICE_SYNC = "KohlsCallPartialCancelWebServiceSync";
	public static final String KOHLS_CALL_CMPLT_CANCEL_WEBSERVICE_SYNC = "KohlsCallCompleteCancelWebServiceSync";
	public static final String TRIGGER_COMPLETE_SHIPMENT_EMAIL="TriggerCompleteShipmentEmail";
	public static final String KOHLS_POST_DUMMY_SHP_CMPLT_TO_Q="KohlsPostDummyCmpltShpConfToQ";
	public static final String API_KOHLS_INVOKE_OFFERS_ENGINE_WEB_SERVICE = "KohlsSCSInvokeOffersEngineWebServiceAPI";

	//Added for estimated delivery date calculation
	public static final String SHIP_LEAD_DAYS = "SHP_LEAD_DAYS";
	public static final String KOHLS_FIXED_MESSAGE = "KOHLS_FIXED_MSG";
	public static final String KOHLS_HOLIDAY_CALENDAR = "KOHLS_HOLIDAY_CAL";
	public static final String GET_CALENDAR_DETAILS_API = "getCalendarDetails";

	// Added for defect fix # 6353
	public static final String A_RECEIPT_ID_BARCODE_VALUE = "ITF";

	public static final String A_DEFAULT_OFFER_NAME = "Order Discount";
	public static final String A_RESPONSE_NO_DATA_FOUND = "No data found";

	public static final String A_MODIFICATION_ADDITIONAL_ITEM = "Additional Item";
	public static final String A_MODIFICATION_PREVIOUS_CANCEL = "Previous Line Cancel";
	public static final String A_MODIFICATION_PREVIOUS_CHANGE = "Previous Line Change";
	public static final String DELIMITER_ADDRESSGROUP_MAP = "::~::";

	public static final String SERVICE_NAME = "ServiceName";
	public static final String DOCUMENT_NAME = "DocumentName";
	public static final String MESSAGE_TYPE = "MessageType";
	public static final String API_KOHLS_TEST_WEB_SERVICE_CALL = "KohlsTestWebServiceAPI";
    public static final String KOHLS_CASH_CREATEPROGID_INT_SERVER = "JMSCreateOrderIntegServer";
    // Added for defect fix # 6448
    public static final String TIMESTAMP_T = "T";
	public static final String TIMESTAMP_0 = "T00:00:00";

	// Added for defect fix # 6553
    public static final String TIMESTAMP_FORMAT = "HH:mm:ss";
	public static final String CUT_OFF_TIMESTAMP = "13:00:00";

	// Added for defect fix # 6486
	public static final double CUSTOMER_PICKED_STATUS = 3700.2;

	// Added for defect fix # 6517 - Start
	public static final String A_FIXED_MESSAGE = "FixedMessage";
	// Added for defect fix # 6517 - End


	// Added for Order Delay email - Oct - R1 - Start
	public static final String API_GET_ORDER_LIST_FOR_DELAY_EMAIL_TEMPLATE_PATH = "global/template/api/getOrderListForDelayEmail.xml";
	public static final String KOHLS_SHIP_DATE = "KOHLS_SHIP_DATE";

	public static final String KOHLS_SCS_GET_IMAGE_URL_SYNC = "KohlsSCSGetImageURLSync";

	// Order delay - Stamping Order Notes - Oct R2 -- Start
	public static final String ORDER_NOTES_ORDER_DELAY_EMAIL = "OrderDelayEmail";
	public static final String ORDER_NOTES_ITEM_ID = "Item ID";
	public static final String ORDER_NOTES_ITEM_DESC = "Item Description";
	public static final String ORDER_NOTES_ORDERED_QTY = "Ordered Quantity";
	public static final String KOHLS_SEND_CHANGE_ORDER_MSG_Q = "KohlsSendMsgToChangeOrderQ";
	// Order delay - Stamping Order Notes - Oct R2 -- End
	// Added for Order Delay email - Oct - R1 - End

	// Oct 2014 R1 Release - Offer cache logic - Start
	public static final String API_GET_PRICELISTHEADER_LIST = "getPricelistHeaderList";
	public static final String API_MANAGE_PRICELISTHEADER = "managePricelistHeader";
	public static final String PRICING_STATUS_ACTIVE = "ACTIVE";
	public static final String PRICING_STATUS_INACTIVE = "INACTIVE";
	public static final String DEFAULT_CURRENCY = "USD";
	public static final String CREATE_ACTION = "Create";
	public static final String MODIFY_ACTION = "Modify";
	// Oct 2014 R1 Release - Offer cache logic - End

	// Oct R1 - fetch item description from open API
	public static final String NOT_FOUND = "not found";

	// Added for defect fix # 6561 - Start
	public static final String READ_FROM_HISTORY = "B";
	// Added for defect fix # 6561 - End
	// Added to resolve the namespace prefix issue with OMS - CCS integration : 02/19/2015



	//End -- Added as part of SCS Project


	//End -- Added as part of SCS Project

	//GIV Specific properties
	public static final String B_TOTAL_DEMAND="TotalDemand";
     public static final String OPEN_ORDER="OPEN_ORDER";
     public static final String DEMAND_TYPE="DemandType";
     public static final String B_QUANTITY="Quantity";
     public static final String ZERO_QUANTITY="0.00";

	//RePricing CR Constants Starts Here
 	public static final String CHARGE_STATUS_CHECKED = "CHECKED";
 	public static final String TRAN_ID_BOPUS_OR_PAYMENT_UPDATE_0001_EX = "PAYMENT_UPDATE.0001.ex";
 	public static final String KOHLS_SERVICE_FAILURE_INPUT_PATH = "/KOHLSServiceFailureInputList/KOHLSServiceFailureInput";
 	public static final String ATG_PAYMENT_UPDATE="ATG_PAYMENT_UPDATE";
 	public static final String REPRICE_MAX_FAILURE_COUNT = "MAX_FAILURE_COUNT";
 	public static final String SERVICE_KOHLS_GET_SERVICE_INPUT_DETAILS = "GetFailedServiceDetails";
 	public static final String SERVICE_KOHLS_CREATE_SERVICE_INPUT_DETAILS = "CreateFailedServiceDetails";
 	public static final String SERVICE_KOHLS_UPDATE_SERVICE_INPUT_DETAILS = "UpdateFailedServiceDetails";
 	public static final String SERVICE_KOHLS_DELETE_SERVICE_INPUT_DETAILS = "DeleteFailedServiceDetails";
 	public static final String API_REQUEST_COLLECTION = "requestCollection";
 	public static final String API_EXECUTE_COLLECTION = "executeCollection";
 	public static final String PAYMENT_UPDATE_RESPONSE_ERROR = "error";
 	public static final String PAYMENT_UPDATE_RESPONSE_FALSE = "false";
 	public static final String PAYMENT_UPDATE_RESPONSE_TRUE = "true";
 	public static final String SERVICE_KOHLS_SEND_REPRICE_INPUT_TO_REPROCESS_QUEUE = "KohlsBopusSendRepriceDetailsToReprocessQueue";
 	public static final String SERVICE_KOHLS_PAYMENT_UPDATE_OMS_RESPONSE  = "KohlsBopusGetPaymentUpdateResponseAsPlainXML";
 	public static final String SERVICE_KOHLS_PAYMENT_UPDATE_REQUEST  = "KohlsBopusUpdateRePriceStatusToEcomm";
	public static final String STORETOEFCRLTN = "StoreToEFCRltn";
	//RePricing CR Constants Ends Here

	public static final String KOHLS_SHIPMENT_LINE_PATH = "/Shipment/ShipmentLines/ShipmentLine";
	public static final String PROCESS_ORDER_PAYMENT_API = "processOrderPayments";
	  //Start : SFS: Aug Releases : Auto-Cancel Changes
		 public static final String A_BATCH_STATUS="BatchStatus";
		 public static final String V_PRINT_FAILED = "Print Failed";
		 public static final String A_CODETYPE_AUTOCANCEL_REQ = "SFS_AUTOCANCEL_REQD";
		 public static final String A_AUTOCANCEL_TRIGGER_BATCH = "BATCH";
		 public static final String A_AUTOCANCEL_TRIGGER_SINGLE = "SINGLE";
		 public static final String A_AUTOCANCEL_LEVEL = "CANCEL_SHIPMENT";
		 public static final String E_SHIPMENT_STATUS_AUDIT = "ShipmentStatusAudit";
		 public static final String AUTO_CANCEL_REASON_CODE = "Auto-Cancel At Print";
		 public static final String A_REASON_TEXT = "ReasonText";
		 public static final String AUTO_CANCEL_REASON_TEXT = "Shipment got cancelled due to inventory unavailability.";
	//End : SFS: Aug Releases : Auto-Cancel Changes

	// Start OASIS 07/10/2014 - for having different Fulfillment Type for Priority order line and Gift Wrap order line
	public static final String FT_GIFT_WRAP="Gift_Wrap";
	public static final String FT_PRIORITY_ORDER="Priority_Order";

	// End OASIS 07/10/2014 - for having different Fulfillment Type for Priority order line and Gift Wrap order line
	//Added template for invoking getOrderDetails while applying Out of the Balance hold START
       //Added template for invoking getOrderDetails while applying Out of the Balance hold END


 	// Begin -- Added as part of View Pack Slip Functionality

 	public static final String API_GET_SHIPMENT_CONTAINER_LIST = "getShipmentContainerList";
 	public static final String API_VIEW_PACK_SLIP_TAXPACK_SVC = "KohlsPopulateTaxSymbolPackSlip";

 	public static final String EXTN_EMAILID_ERROR = "EMailID is missing in the input";
 	public static final String EXTN_TRACKING_NO_ERROR = "TrackingNo is missing in the input";
 	public static final String EXTN_MANDATORY_PARAMS_MISSING_ERROR = "Mandatory parameters are missing in the input";
 	public static final String EXTN_ORDER_NUMBER_MISMATCH = "The order number and tracking number in the request don't match.";
 	public static final String EXTN_INVALID_TRACKING_NUMBER = "The tracking number provided in the input is invalid.";

 	public static final String EXTN_EMAILID_ERROR_CODE = "KOHLS-VPS-001";
 	public static final String EXTN_TRACKING_NO_ERROR_CODE = "KOHLS-VPS-003";
 	public static final String EXTN_MANDATORY_PARAMS_MISSING_ERROR_CODE = "KOHLS-VPS-004";
 	public static final String EXTN_ORDER_NUMBER_MISMATCH_CODE = "KOHLS-VPS-005";
 	public static final String EXTN_INVALID_TRACKING_NUMBER_CODE = "KOHLS-VPS-006";
 	public static final String EXTN_GENERIC_ERROR_CODE = "KOHLS-GEN-001";
 	public static final String ORDER_NO_ERROR_CODE = "KOHLS-VPS-002";
 	public static String INVALID_CREDS_ERROR_CODE = "KOHLS-VPS-007";
	public static String INVALID_CREDS_ERROR_DESC = "Invalid login credentials";

	public static final String MESSAGE_HEADER_VALUE = "urn:kohls:xml:schemas:message-header:v1_0";
	public static final String VERSION_VALUE = "1.0";

	public static final String DATE_FORMAT_WS = "yyyy-MM-dd'T'HH:mm:ss";
	public static final String SYSTEM_CODE_VALUE = "OMS";

	public static final String ROOT_NODE_FOR_ORDER_DELAY = "oms:OrderDelayOMSRequest";
 	// End -- Added as part of View Pack Slip Functionality


     //Added for Offers -Start--*********Sep R2
     public static final String GIFT_WITH_PURCHASE="GWP";
     public static final String PURCHASE_WITH_PURCHASE="PWP";
     public static final String BOGO_INSTRUCTION = "BUY ONE, GET ONE";
     //Added for Offers -End--*********Sep R2


 	//OASIS-773 - ISSUE
 	public static final String SUPPRESS_SOURCING_ON = "SUPPRESS_SOURCING_ON";
 	public static final String SUPPRESS_SOURCING_ATTR = "SuppressSourcingStampingOn";
 	public static final String SHIP_NODE_LIST = "ShipNodeList";
 	public static final String API_GET_SHIP_NODE_LIST = "getShipNodeList";
 	public static final String STR_DC = "DC";
 	//END-OASIS-773-CONSTANTS FOR ISSUE

 	//OASIS-70226,379,000
 	public static final String DIRTY_NODE_DUR_STORE = "DIRTY_NODE_DUR_STORE";
 	//OASIS-70226,379,000-End

	// End OASIS 07/10/2014 - for having different Fulfillment Type for Priority order line and Gift Wrap order line
	//Added template for invoking getOrderDetails while applying Out of the Balance hold START
    public static final String API_GET_ORDER_DETAILS_FOR_OOB_HOLD_TEMPLATE_PATH = "global/template/api/BOPUS/getOrderDetailsForOOBHold_output.xml";
    //Added template for invoking getOrderDetails while applying Out of the Balance hold END

    public static final String RESERVED= "RESERVED";
	//Added as part of reprice functionality
	public static final String TIMEZONE = "-05:00";

	public static final String API_RECORD_CUSTOMER_PICK = "recordCustomerPick";
	public static final String TRANSLATION_SHIP_NODE_PLU = "TRANSLATION_SHIP_NODE_PLU";
	public static final String USE_TEST_SHIP_NODE = "USE_TEST_SHIP_NODE";
	public static final String API_PUTAWAY_INVENTORY_ITEMS_MLS = "KohlsPutawayInventoryItems";
	//Added for Returns
	public static final String TXN_PUTAWAY_STARTED = "PutAwayStarted.0001.ex";
	//Added for Returns
	public static final String TXN_PUTAWAY_COMPLETED = "PutAwayCompleted.0001.ex";

	 //Adding for applying BOPUSOOB hold from KohlsOOBHoldApi START
	 public static final String BOPUS_OOB_HOLD = "BOPUSOOBHold";
	 //Adding for applying BOPUSOOB hold from KohlsOOBHoldApi END

	 //Adding for customer notifications START
	 public static final String STATUS_CODE_CUSTOMER_PICKEDUP = "1400.1";
	 public static final String STATUS_PENDING_EXPIRED_RETURN = "1400.4";
	 public static final String STATUS_EXPIRED_PICKUP = "1400.2";
	 //Added for Returns
	 public static final String STATUS_PUTAWAY_STARTED = "1400.5";
	//Added for Returns
	 public static final String STATUS_PUTAWAY_COMPLETED = "1400.6";

	 public static final String GET_ORDER_LIST_CUST_NOTIFY_TEMPLATE="global/template/api/getOrderListCustNotifyTemplate.xml";
	 //Adding for customer notifications END

	 //Defect 692
	 public static final String YCD_CUSTOMER_VERIFICATION = "YCD_CUSTOMER_VERIFICATION";
	 public static final String PROCESS_PENDING_RETURN_SERVICE = "PROCESS_PENDING_RETURN_SERVICE";
	 //Defect 692
	public static final String API_CHANGE_EXCEPTION = "changeException";
	public static final String API_GET_EXCEPTION_LIST = "getExceptionList";

	public static final String BOPUS_ALERT_TYPE_1 = "KOHLS_SHIPMENT_READY_FOR_STORE_PICK";
	public static final String BOPUS_ALERT_TYPE_2 = "KOHLS_SHIPMENT_NOT_PICKED";
	public static final String BOPUS_ALERT_TYPE_3 = "KOHLS_SHIPMENT_NOT_PICKED_TIER2";
	public static final String BOPUS_ALERT_TYPE_4 = "KOHLS_PUTAWAY_NOT_COMPLETED";


	 // Added for MP create Order-- Start
     public static final String LINE_TYPE_MARKETPLACE="MP";
     public static final String SHIP_NODE_WAYFAIR="WYF";
     public static final String MP_ITEMID_CODE_TYPE = "MP_DUMMY_SKU";
     public static final String ERROR_CODE_KL_MP_001="KL_MP_001";
     public static final String ERROR_DESCRIPTION_KL_MP_001="ExtnCommissionPerc for Marketplace line is missing";
     public static final String XPATH_DEMAND_TO_GIV="/Items/Item/TotalDemand/Demand";
     // Added for MP create Order-- End

     //Add for MP Return Order -- Start
     public static final String TEMLATE_GET_ORDER_DETAILS_FOR_PO="global/template/api/extn_getOrderDetails_For_PO.xml";
     public static final String TEMLATE_GET_ORDER_DETAILS_FOR_SO="global/template/api/extn_getOrderDetails_For_SO.xml";
     public static final String TEMLATE_GET_ORDER_LIST_FOR_SO="global/template/api/extn_getOrderList_For_SO.xml";
     public static final String TEMLATE_GET_ORDER_RELEASE_LIST="global/template/api/extn_getOrderReleaseList.xml";
     //End for MP Return Order - End

	  //Email Start
     public static final String MESSAGE_HEADER = "MessageHeader";
     public static final String MESSAGE_DETAIL = "MessageDetail";
     public static final String FROM_ADDRESS ="FromAddress";
     public static final String MAIL_HOST = "MailHost";
     public static final String MAIL_PORT = "MailPort";
     public static final String MAIL_PROTOCOL = "MailProtocol";
     public static final String TO_ADDRESSES ="ToAddresses";
     public static final String TEMPLATE_FILE ="TemplateFile";
     public static final String SUBJECT_TEXT ="SubjectText";
     public static final String SEND_MAIL_API = "sendMail";
     public static final String CC_ADDRESSES ="CCAddresses";
     public static final String CC_ADDRESS ="CCAddress";
     public static final String MSG_BODY ="MessageDetailBody";
     public static final String EMAIL_ID ="EmailID";
     public static final String SEND_MAIL = "SendMail";
     public static final String TO_ADDRESS = "ToAddress";
     public static final String A_VENDOR_NAME = "VendorName";
     public static final String A_VENDOR_ID = "VendorId";

     public static final String A_FROM_ADDR = "Marketplace-OMS@kohls.com" ;
     public static final String A_TO_ADDR = "QCoE_OMS_Marketplace@kohls.com" ;
     public static final String A_CC_ADDR = "harsha.basawara@kohls.com" ;
     public static final String A_EMAIL_TEMP_FILE_PATH = "global/template/email/kohls_MP_Return_Email_To_CSC.xsl" ;
     public static final String A_EMAIL_SUB_TEXT = "EMAIL_SUB_TEXT" ;

	 public static final String CSC_RET_SHPMT_CHRGSL="CSC_RET_SHPMT_CHRGS";
     public static final String A_SALES_OHK= "SalesOHK";
     public static final String VENDOR_NAME = "Wayfair";
     public static final String A_VALUE_YES = "Yes";
     public static final String A_VALUE_NO = "No";

     public static final String A_HOST_NAME = "EMAIL_HOST_NAME";
     public static final String A_PORT_NO = "EMAIL_PORT_NO";
     public static final String A_MAIL_PROTOCOL = "EMAIL_MAIL_PROTOCOL";

     //Email End

  // Added for MP create Invoice-- Start
     public static final String EXTN_LINE_REF_MAP="ExtnLineRefMap";
  // Added for MP create Invoice-- End
  //Added for MP Oct-2014
	 public static final String TEMPLATE_GET_RETURN_ITEM_DETAILS="global/template/api/extn/getReturnItemDetails.xml";

	 public static final String TEMPLATE_Get_Order_List_For_MP_Extn_Attr="global/template/api/extn/getOrderListFoMPExtnAttr.xml";
	 public static final String TEMPLATE_Get_Ship_Node_List="global/template/api/extn/getShipNodeList.xml";






	//OASIS-Fix for CashActivation
    public static final String ELE_ORDER_LIST = "OrderList";
    public static final String ELE_CREATE_ASYNC_REQ = "CreateAsyncRequest";
    public static final String ATTR_IS_SERVICE = "IsService";
    public static final String CASH_ACTIV_SERVICE = "KohlsCashEarnedActivationSyncService";
    public static final String IS_REC_IN_ASYNC_REQ_TABLE = "IsRecordInAsyncReqTable";
    //End-OASIS-Fix for CashActivation

    public static final String KOHLS_ORDER_REPRICE_ALERT_Q ="KOHLS_ORDER_REPRICE_ALERT_Q";
         public static final String KOHLS_BPS_ORDER_REPRICE_ALERT_Q ="KOHLS_BPS_ORDER_REPRICE_ALERT_Q";
         public static final String KOHLS_OOB_HOLD_ALERT_Q ="KOHLS_OOB_HOLD_ALERT_Q";
         public static final String KOHLS_BPS_OOB_HOLD_ALERT_Q ="KOHLS_BPS_OOB_HOLD_ALERT_Q";
         public static final String KOHLS_ORDER_REPRICE_ALERTSERVICE ="KohlsOrderRepriceAlertService";
         public static final String KOHLS_BPS_ORDER_REPRICE_ALERTSERVICE ="KohlsBPSOrderRepriceAlertService";
         public static final String KOHLS_OOB_HOLD_ALERTSERVICE ="KohlsOOBHoldAlertService";
         public static final String KOHLS_BPS_OOB_HOLD_ALERTSERVICE ="KohlsBPSOOBHoldAlertService";
         public static final String KOHLS_ORDER_REPRICE_EXCEPTION = "KohlsOrder Reprice Exception";
         public static final String KOHLS_BPS_ORDER_REPRICE_EXCEPTION ="Kohls BPS Order Reprice Exception";
         public static final String KOHLS_OOB_HOLD_EXCEPTION = "Kohls OOBHold Exception";
         public static final String KOHLS_BPS_OOB_HOLD_EXCEPTION = "Kohls BPSOOB Hold Exception";
         public static final String API_GET_LOCALE_LIST = "getLocaleList";

      // Added for CarrierDelay
     	public static final String TEMPLATE_GET_SHIPMENT_LIST_CARRIER_DELAY ="global/template/api/getShipmentList_CarrierDelayMail.xml";
     	public static final String MISSING_TRACKING_NO = "TrackingNo is missing in the input";
     	public static final String MISSING_RESCHEDULED_DEL_DATE = "RescheduledDeliveryDate is missing in the input";
     	public static final String A_CARRIER_DELAY = "CarrierDelay";
     	public static final String ROOT_NODE_FOR_CARRIER_DELAY = "ord:CarrierDelayRequest";
     	public static final String CARRIER_DELAY_ORDER_NOTE_TXT_PART_1 = "Carrier Delay email has been triggered for Tracking No.";
     	public static final String CARRIER_DELAY_ORDER_NOTE_TXT_PART_2 = "with rescheduled delivery date: ";
     	public static final String CARRIER_DELAY_ORDER_NOTE_TXT_PART_3 = "having RequestID: ";
     	public static final String CARRIER_DELAY_ORDER_NOTE_TXT_PART_4 = "and RequestTS: ";
     	public static final String SERVICE_GET_ORDER_LIST_FOR_CARRIER_DELAY="KohlsGetOrderListForCarrierDelay";
     	public static final String SERVICE_KOHLS_EXECUTE_CARRIER_DELAY = "KohlsExecuteCarrierDelay";
     	public static final String SERVICE_KOHLS_CALL_CARRIER_DELAY_WEBSERVICE_SYNC = "KohlsCallCarrierDelayWebServiceSync";
     	public static final String CARRIER_DELAY_EMAIL_SENT_MSG = "Email Sent for TrackingNo.";
     	public static final String KOHLS_CALL_CARRIER_DELAY_ASYNC_REQ_SERVICE = "KohlsCallCarrierDelayAsyncReqService";
     	public static final String KOHLS_POST_CARRIER_DELAY_MSG_TO_Q="KohlsPostCarrierDelayMessageToQ";
     	public static final String API_GET_KOHLS_CUSTOMER_NOTIFICATION_DETAIL = "getKohlsCustomerNotificationService";
     	public static final String TEXT = "TEXT";
     	public static final String XML = "XML";
     	  	//Fix for defect# 6651 -- updated the constant 'KOHLS_CARRIER_DELAY_ALERTS' value from 'Kohls Carrier Delay Alerts' to 'Kohls Carrier Status Alerts'.
     		public static final String KOHLS_CARRIER_DELAY_ALERTS = "Kohls Carrier Status Alerts";
     	public static final String CARRIER_DELAY_FEED_ERROR = "Carrier Delay Feed Error";
     	public static final String ALERT = "Alert";

     	// Added for stamping Request ID and Request Timestamp for Carrier Delay Emails
     	public static final String CARRIER_DELAY_UNIQUE_ID_PROCESS_TYPE = "CD";
//		 Start -- Added as part of DSV Ecosystem Project
		// Prod Issue - 12 Feb 2015 - OOM Performance issue - template change -- Start
     	public static final String API_GET_KOHLS_OFT_INT_PO_HEADER_LIST_PRUNED = "KohlsGetInternPOHeaderListPrunedService";
     	// Prod Issue - 12 Feb 2015 - OOM Performance issue - template change -- End

     	// Prod Issue - 12 Feb 2015 - Multi threading issue -- Start
     	public static final String NUM_FIFTY = "50";
     	public static final String EXTN_DSV_NULL_PO_HEADER_DURING_UPDATE = "KOHLS-DSV_ECO-002";
     	public static final String A_ERR_MSG_PO_HEADER_UNAVAILABLE = "Unexpected error occurred during processing. Please retry again..";
     	// Prod Issue - 12 Feb 2015 - Multi threading issue -- End

     	// Prod Issue - 12 Feb 2015 - Blank vendor number and department -- Start
     	public static final String KOHLS_DSV_ORD_LINE_SKIP_LIST = "DSVECO_SKIP_LN_TYPE";
     	public static final String A_SKIP_LINE_TYPE_LIST = "SKIP_LINE_TYPE_LIST";
     	public static final String A_ERR_MSG_VENDOR_UNAVAILABLE = "Vendor/ Primary supplier is not available for the item or in the shipment. Please correct the data and reprocess the exception";
     	public static final String A_ERR_MSG_DEPT_UNAVAILABLE = "Department is not available for the item. Please correct the data and reprocess the exception";
     	public static final String DSV_ECO_ITEM_RECONSOLIDATION="::DSV Eco Item Reconsolidation Failure:: ";
     	public static final String EXTN_DSV_NULL_VENDOR_DEPT_ERROR_CODE = "KOHLS-DSV_ECO-001";
     	public static final String A_FOR_ITEM_ID = " for ItemID ";
     	// Prod Issue - 12 Feb 2015 - Blank vendor number and department -- End

     	public static final String API_GET_KOHLS_OFT_INT_PO_HEADER_LIST = "KohlsGetInternalPOHeaderListService";
	public static final String API_CREATE_KOHLS_OFT_INT_PO_HEADER = "KohlsCreateInternalPOHeaderService";
	public static final String API_UPDATE_KOHLS_OFT_INT_PO_HEADER = "KohlsChangeInternalPOHeaderService";
	public static final String API_DELETE_KOHLS_OFT_INT_PO_HEADER = "KohlsDeleteInternalPOHeaderService";
	public static final String API_GET_KOHLS_OFT_INT_PO_HEADER = "KohlsGetInternalPOHeaderService";
	public static final String API_GET_KOHLS_OFT_INT_PO_LINE_LIST = "KohlsGetInternalPOLineListService";
	public static final String API_CREATE_KOHLS_OFT_INT_PO_LINE = "KohlsCreateInternalPOLineService";
	public static final String API_UPDATE_KOHLS_OFT_INT_PO_LINE = "KohlsChangeInternalPOLineService";
	public static final String API_DELETE_KOHLS_OFT_INT_PO_LINE = "KohlsDeleteInternalPOLineService";

	public static final String A_DSV_LINE_TYPE = "DSV";


	public static final String KOHLS_RES_INT_PO_IN_RMS_SYNC_SERVICE="KohlsReserveInternalPOInRMSSync";
	public static final String KOHLS_CREATE_INT_PO_IN_RMS_SYNC_SERVICE="KohlsCreateInternalPOInRMSSync";
	public static final String KOHLS_GET_ORDER_LIST_FOR_DSV_RES_PO_SERVICE="KohlsGetOrderListForDSVEcoReservePOService";

	public static final String QUERY_TYPE="QryType";
	public static final String NOT_NULL="NOTNULL";
	public static final String A_OPERATOR="Operator";
	public static final String A_GREATER_THAN_OR_EQUAL_TO="GE";
	public static final String A_AND="And";

	public static final String CREATE_MODIFY_ACTION = "Create-Modify";
	public static final String A_REPLACE="Replace";

	public static final String KOHLS_EXECUTE_INT_PO_CREATE_REQUEST_SERVICE = "KohlsExecuteInternalPOCreateRequest";
	public static final String KOHLS_EXECUTE_INT_PO_PUBLISH_REQUEST_SERVICE = "KohlsExecuteInternalPOPublishRequest";
	public static final String KOHLS_INT_PO_STATUS = "DSV_ECO_PO_STAT_LIST";
	public static final String MAX_PO_LINES_IN_PO_DSV_ECO = "DSV_ECO_MAX_PO_LINES";

	public static final String E_ORDERBY="OrderBy";
	public static final String V_SUCCESS_RESPONSE="SUCCESS";

	public static final String V_PO_INITIATED="1000";
	public static final String V_PO_RESERVE_REQUESTED="1100";
	public static final String V_PO_RESERVED="1200";
	public static final String V_RESERVATION_FAILED="1300";
	public static final String V_PO_CREATE_REQUESTED = "1400";
	public static final String V_PO_CREATED = "1500";
	public static final String V_PO_CREATE_FAILED = "1600";
	public static final String V_PO_PUBLISHED = "1700";
	public static final String V_PO_INVOICE_PUBLISHED = "1800";

	public static final String V_PO_SEQUENCE="POSequence";
	public static final String INT_MAX_RECORD="999";

	public static final String ROOT_NODE_FOR_CREATE_PO_RESPONSE = "POCreationResponse";
	public static final String V_GET_COMMONCODE_LIST="GET_COMMON_CODE";

	public static final String ERROR_CODE_UPDATE_SHIPMENT_LINE_INTPO ="Exception during PO Details update on Shipment Line";
	public static final String ERROR_UPDATE_SHIPMENT_LINE_INTPO="Exception during PO Details update on Shipment Line";
	public static final String V_CREATE_PO_LINE="CreatePOLine";

	//temp
	public static final String API_UPDATE_KOHLS_OFT_INT_PO_HEADER_TEMP="KohlsChangeInternalPOHeaderServiceTemp";
	public static final String KOHLS_ASYNC_REQUEST_RES_PO_REQ_SERVICE= "KohlsExecuteInternalPOAsyncResRequest";

	public static final String ERROR_PO_CREATE_REQ_FAILED="PO Create Request Failed";
	public static final String ERROR_CODE_PO_CREATE_REQ_FAILED="ERR_PO_CR_01";


	public static final String KOHLS_PRO_CONFIRM_SHIP_SYCN_SERVICE="KohlsProcessConfirmShipmentMsgSync";
	public static final String KOHLS_PUBLISH_TO_REC_SYNC_SERVICE="KohlsPublishPOToReceiverSync";
	public static final String ROOT_NODE_FOR_RESERVE_PO_REQUEST = "POReservationRequest";

	public static final String KOHLS_DSV_ALERT="Kohls DSV Eco Alerts";
	public static final String REPROCESS="REPROCESS";
	public static final String ERROR_MESSAGE="ErrorMessage";
	public static final String API_CREATE_EXCEPTION="createException";
	public static final String API_GET_QUEUE_LIST="getQueueList";
	public static final String INPUT_XML="InputXML";
	public static final String DSV_ECO_RESERVE_RESPONSE="::DSV Eco Reserve Response Failure:: ";
	public static final String DSV_ECO_CREATE_RESPONSE="::DSV Eco Create Response Failure:: ";
	public static final String DSV_ECO_RESERVE_REQUEST="::DSV Eco Reserve Request Failure:: ";
	public static final String DSV_ECO_CREATE_REQUEST="::DSV Eco Create Request Failure:: ";
	public static final String DSV_ECO_PUBLISH_REQUEST="::DSV Eco Publish Request:: ";
	public static final String DSV_ECO_INVOICE_PUBLISH_REQUEST="::DSV Eco Invoice Publish Request:: ";
	public static final String ERROR_CODE_UPDATE_POHEADER ="Exception during Updating PO Header";
	public static final String ERROR_UPDATE_PO_HEADER="Exception during Updating PO Header";
	/*public static final String ERROR_CODE_REQUEST_RESPONSE ="Exception in Request response";
	public static final String ERROR_REQUEST_RESPONSE="Exception in Request response";*/

	public static final String ERROR_CODE_RESERVE_REQUEST ="Exc_Res_Req";
	public static final String ERROR_DESC_RESERVE_REQUEST="Exception in Reserve Request";
	public static final String GET_SHIPMENT_LIST_TEMPLATE="global/template/api/getShipmentListForDSvEcoTemplate.xml";
	public static final String V_UPDATE_PO_LINE="UpdatePOLine";
	public static final String V_DSV_ECO_STORE_MAP="DSV_ECO_STORE_MAP";
	public static final String NON_REPROCESS ="NONREPROCESS";

		//DSV Eco- Publish Invoice start
    public static final String STERLING_DATE_FORMAT_PUBLISH_INV = "yyMMdd";
    public static final String STERLING_TS_FORMAT_PUBLISH_INV = "hhmm";
    public static final String KOHLS_PUBLISH_PO_INVOICE_TO_AP_SYNC_SERVICE="KohlsPublishInternalPOInvoiceToAPSync";
    public static final String KOHLS_EXECUTE_INT_PO_INVOICE_PUBLISH_REQUEST_SERVICE = "KohlsExecuteInternalPOInvoicePublishRequest";
    public static final String A_OVERRIDE_MODIFICATION_RULES="OverrideModificationRules";
    public static final String A_EXTN_FRIEGHT_INCL_ON_INT_PO="ExtnFreightChargeIncludedOnIntPO";
    public static final String A_GROSS_INVOICE_AMOUNT="GrossInvoiceAmount";
    public static final String A_QUANTITY_SHIPPED="QuantityShipped";
    public static final String A_EXTN_DSV_INVOICE_NUMBER="ExtnDSVInvoiceNumber";
    public static final String API_GET_SHIPMENT_LIST_FOR_DSV_PUBLISH_INVOICE_TO_AP="global/template/api/getShipmentListForDSVPublishInvoiceToAP.xml";
    public static final String KOHLS_DSV_EXCEPTION_TYPE="Kohls DSV Eco Alerts";

		//DSV Eco- Publish Invoice End

    //	27 Feb 2015 - Prod Issue - For deadlock issue -- Start
    public static final String A_DSV_ASYNC_FLAG = "A_DSV_ASYNC_FLAG";
    public static final String SERVICE_KOHLS_GET_SHIPMENT_INTPO_LIST = "KohlsGetDSVShipmentIntPOListService";
    public static final String A_RECORD_ALREADY_EXISTS_ERR_CODE="YFC0001";
    public static final String API_GET_INTEGRATION_ERROR_LIST="getIntegrationErrorList";
    public static final String A_INITIAL_STATUS="Initial";
    public static final String API_IGNORE_INTEGRATION_ERROR="ignoreIntegrationError";
    public static final String KOHLS_PRO_CONFIRM_SHIP_ASYCN_SERVICE="KohlsProcessConfirmShipmentMsgAsync";
    //  27 Feb 2015 - Prod Issue - For deadlock issue -- End
		// End -- Added as part of DSV Ecosystem Project

		// Start -- Added as part of Email Pack Slip
		public static final String PACK_SLIP = "Packslip";
		public static final String EXTN_EMAILPACKSLIP_ERROR_CODE = "KOHLS-VPS-008";
		public static final String EXTN_EMAILPACKSLIP_ERROR_DESC = "The EmailPackSlip flag must be 'Y'";
		public static final String ROOT_NODE_FOR_EMAIL_PACKSLIP="pac:PackSlipRequest";
		public static final String KOHLS_CALL_EMAIL_PACK_SLIP_ASYNC_REQ_SERVICE="KohlsCallEmailPackslipAsyncReqService";
		public static final String PACK_SLIP_EMAIL_ORDER_NOTE_TXT_PART_1 = "Packslip Email has been triggered for Tracking No.";
		public static final String PACK_SLIP_EMAIL_ORDER_NOTE_TXT_PART_2=" with Request ID ";
		public static final String PACK_SLIP_EMAIL_ORDER_NOTE_TXT_PART_3=" and Request TS ";
		public static final String KOHLS_CALL_EMAIL_PACKSLIP_WEBSERVICE_SYNC = "KohlsCallEmailPackslipWebServiceSync";
		// Added for stamping Request ID and Request Timestamp for Email Packslip
		public static final String EMAIL_PACK_SLIP_UNIQUE_ID_PROCESS_TYPE="EP";
		public static final String DEFAULT_REQUEST_ID="DEFAULT_REQUEST_ID";
		public static final String API_GET_SHIPMENT_LIST_FOR_PACK_SLIP_TEMPLATE_PATH = "global/template/api/getShipmentListTemplateForPackSlip.xml";
		public static final String API_GET_ORDER_LIST_FOR_PACK_SLIP_TEMPLATE_PATH = "global/template/api/getOrderListTemplateForPackSlip.xml";

	    // End -- Added as part of Email Pack Slip


         //Start changes for Market place
         public static final String V_OPEN_MP_API_BASEURL = "OpenMPAPI_BaseURL";
         public static final String V_SKU_MP_DETAIL = "skuMPDetail";

         //End changes for Market Place

		 // Added for MP create Invoice-- Start
         public static final String ROUNDOFF_CODETYPE="COMM_AMT_ROUNDOFF";
      // Added for MP create Invoice-- End

         //Start:Duplicate Carrier Delay Email prevention
         public static final String TEMPLATE_GET_NOTE_LIST_CARRIER_DELAY ="global/template/api/getNoteListForCarrierDelayMail.xml";
         public static final String API_GET_NOTE_LIST = "getNoteList";
         //End:Duplicate Carrier Delay Email prevention

         //DSV EES: added to restrict the msg send to Ecom with internalPO changeshipment call--start
         public static final String V_DSV_ECO_CHANGE_SHIPMENT="DSVEcoChangeShipment";
         //DSV EES: added to restrict the msg send to Ecom with internalPO changeshipment call--start
		// Reconsolidation logic -- Start
        public static final String EQUALS_QUERY_TYPE="EQ";
        public static final String API_GET_ITEM_LIST_FOR_DSV_CREATE_PO_IN_RMS = "global/template/api/getItemListAPIForDSVIntPOCreate.xml";
        public static final String SERVICE_KOHLS_CREATE_DSV_SHIPMENT_INT_PO = "KohlsCreateDSVShipmentIntPOService";

      //1st Jan Start //     Reconsolidation logic -- Start
       public static final String TEMPLATE_GET_ITEMLIST_FOR_DEPT ="global/template/api/getItemList_DSVEco_Dept_Check.xml";
       public static final String A_PO_LINE_RECONSOLIDATION_REQD ="POReconsolidationRequired";
     ////new agent
      public static final String A_EQUAL_TO ="EQ";
      public static final String KOHLS_EXECUTE_ITEM_RECONSOLIDATION_SERVICE="KohlsExecuteItemReconsolidationService";


      public static final String SERVICE_KOHLS_GET_DSV_SHIPMENT_INT_PO = "KohlsGetDSVShipmentIntPOService";
      public static final String SERVICE_KOHLS_UPDATE_DSV_SHIPMENT_INT_PO = "KohlsChangeDSVShipmentIntPOService";

    //1st Jan End // Reconsolidation logic -- End
    // Reconsolidation logic -- End

    //BOPUS Email Redesign --> Start
      public static final String API_GET_ORDER_INVOICE_DETAIL_LIST = "getOrderInvoiceDetailList";
      public static final String GET_ORDER_INVOICE_DETAIL_LIST_TEMPLATE="global/template/api/extn/KohlsGetOrderInvoiceDetailList_output.xml";
      public static final String API_GET_SHIPMENT_LIST_FOR_AUTO_REFUND_EMAIL_TEMPLATE = "global/template/api/extn/KohlsGetShipmentListForAutoRefundEmail.xml";
      public static final String AUTO_REFUND_NOTE_TEXT_INTERNAL_USE = "This note is for internal use. AutoRefund email message formed for ShipNode-";
      public static final String ROOT_NODE_FOR_AUTO_REFUND = "exp:OrderExpiredRefundRequest";
      public static final String AUTO_REFUND_UNIQUE_ID_PROCESS_TYPE = "AF";
     // public static final String DEFAULT_REQUEST_ID="DEFAULT_REQUEST_ID";
      public static final String AUTO_REFUND_ORDER_NOTE_TEXT_PART1 = "AutoRefund email has been triggered for Shipment No.: ";
      public static final String AUTO_REFUND_ORDER_NOTE_TEXT_PART2 = "having RequestID:  ";
      public static final String AUTO_REFUND_ORDER_NOTE_TEXT_PART3 = "and RequestTS: ";

      public static final String READY_FOR_PICK_UP  = "Ready For Customer Pick Up";
   	 public static final String API_GET_ORDER_INVOICE_LIST_TEMPLATE_PATH = "global/template/api/getOrderInvoiceDetailList_output.xml";
   	public static final String KOHLS_PACK_LIST_NON_JEW="NON_JEW";
   	public static final String KOHLS_PACK_LIST_JEW="JEW";
   	public static final String KOHLS_PACK_LIST_BOTH="BOTH";
   	public static final String KOHLS_PACK_LIST_J="_JEW";
   	public static final String STATUS_AWAITING_STORE_PICKUP="3350.11";
	public static final String STATUS_CREATED="1100";
   	public static final String STATUS_SCHEDULED="1500";
     public static final String API_GET_SHIPMENT_LIST__TEMPLATE_PATH="global/template/api/getShipmentListTemplateForOrderDelay.xml";
     public static final String ROOT_NODE_FOR_BOPUS_ORDER_DELAY="del:OrderDelayRequest";
     public static final String ROOT_NODE_FOR_BOPUS_READY_FOR_PICK_UP ="read:OrderReadyForPickupRequest";
     public static final String ROOT_NODE_FOR_BOPUS_PICKED_UP_CONFIRMATION ="conf:OrderPickedUpConfirmationRequest";

     public static final String NEED_OPEN_API_CALL="NeedOpenAPICall";
     public static final String CONSTANT_YES="YES";
     public static final String BOPUS_EMAIL_SWITCH="BOPUS_EMAIL_SWITCH";

     public static final String MULTIPLE = "MULTIPLE";
 	public static final String SINGLE = "SINGLE";
 	public static final String JEWELERY="JEWELRY";
 	public static final String NON_JEWELERY="NON_JEWELERY";
 	public static final String BOTH="BOTH";

 	  public static final String BOPUS_ORDR_DELAY_UNIQUE_ID_PROCESS_TYPE="BOD";
 	 public static final String BPS_ORDR_DELAY_ORDER_NOTE_1=  "OrderDelay Email has been triggered for  Shipment No: ";
     public static final String BPS_ORDR_DELAY_ORDER_NOTE_2= " with Request ID ";
     public static final String BPS_ORDR_DELAY_ORDER_NOTE_3=  " and Request TS ";
     public static final String BPS_ORDR_DELAY_ORDER_NOTE_5 = "for the store ";

  	public static final String BOPUS_EMAILS_ROOTNODE = "stor:StoreOrderNotificationRequest";
 	public static final String BOPUS_STORE_ORDER_NOTIFICATION_TYPE = "stor:storeOrderNotificationType";
 	public static final String BOPUS_EMAIL_IDENTIFIER_FOR_AUTO_REFUND = "CUSTOMER_CANCELLED_ORDER";
 	public static final String BOPUS_EMAIL_IDENTIFIER_FOR_ORDER_DELAY = "ORDER_DELAY";
 	public static final String BOPUS_EMAIL_IDENTIFIER_FOR_ORDER_PICKEDUP = "ORDER_PICKED_UP";
 	public static final String BOPUS_EMAIL_IDENTIFIER_FOR_READY_FOR_PICKUP = "READY_FOR_PICKUP";
 	public static final String BOPUS_EMAIL_IDENTIFIER_FOR_INITIAL_PICKUP_REMINDER = "READY_FOR_PICKUP_REMINDER";
 	public static final String BOPUS_EMAIL_IDENTIFIER_FOR_FINAL_PICKUP_REMINDER = "READY_FOR_PICKUP_FINAL_REMINDER";

    public static final String CUSTOMER_SERVICE="CUSTOMER_SERVICE";
    public static final String READY_FOR_CUSTOMER_UNIQUE_ID_PROCESS_TYPE = "RFC";
    public static final String READY_FOR_CUSTOMER_NOTE_TEXT_PART1 ="Ready For Customer Pickup Email has been triggered for Shipment No: ";
    public static final String READY_FOR_CUSTOMER_NOTE_TEXT_PART2 =" having RequestID: ";
    public static final String READY_FOR_CUSTOMER_NOTE_TEXT_PART3 = "and RequestTS: ";

    public static final String PICKEDUP_UNIQUE_ID_PROCESS_TYPE = "CP";
    public static final String CUSTOMER_PICKED_UP_ORDER_NOTE_TEXT_PART1 = "Customer PickedUp Email has been triggered for Shipment No: ";
    public static final String CUSTOMER_PICKED_UP_ORDER_NOTE_TEXT_PART2 = "having RequestID:  ";
    public static final String CUSTOMER_PICKED_UP_ORDER_NOTE_TEXT_PART3 = "and RequestTS: ";
    public static final String CUSTOMER_PICKED_UP_NOTE_TEXT_INTERNAL_USE = "This note is for internal use. CustomerPickedUp Email message formed for ShipNode-";

    public static final String CREDIT_CARD_TYPE="CREDIT_CARD_TYPE";
    public static final String KOHLS_PAYMENT_TYPE_MERCHANDISE_CREDIT = "KMC";
 	public static final String KOHLS_PAYMENT_TYPE_GIFT_CARD = "GIFT_CARD";


 	public static final String INITIAL_PICK_UP_FINAL_REMINDER_UNIQUE_ID_PROCESS_TYPE = "FPR";
 	  public static final String PICKUP_FINAL_REMAINDER_ORDER_NOTE_TXT_PART_1 = "Final Pick Up Reminder Email has been triggered for Shipment No:";
 	    public static final String PICKUP_FINAL_REMAINDER_ORDER_NOTE_TXT_PART_2 = " having RequestID: ";
 	   	public static final String PICKUP_FINAL_REMAINDER_ORDER_NOTE_TXT_PART_3 = "and RequestTS: ";

 	   public static final String INITIAL_PICK_UP_REMINDER_UNIQUE_ID_PROCESS_TYPE = "IPR";
 	   	public static final String PICKUP_INITIAL_REMAINDER_ORDER_NOTE_TXT_PART_1 = "Initial Pick Up Reminder Email has been triggered for Shipment No: ";
 	    public static final String PICKUP_INITIAL_REMAINDER_ORDER_NOTE_TXT_PART_2 = " having RequestID: ";
 	   	public static final String PICKUP_INITIAL_REMAINDER_ORDER_NOTE_TXT_PART_3 = "and RequestTS: ";

 	  public static final String API_GET_SHIPMENT_LIST_FOR_CUSTOMER_PICKEDUP_TEMPLATE = "global/template/api/getShipmentListForCustomerPickedUp.xml";
  	  public static final String SERVICE_KOHLS_BOPUS_PICKED_UP_NOTIFICATION = "KohlsBopusPickedUpNotification";
  	  public static final String CHECK_FOR_REQ_CANCEL_DATE = "CheckForReqCancelDate";

		public static final String YES_WE_CAN="Yes_We_Can";
	  public static final String TLD="TLD";
	  public static final String API_GET_SHIPMENT_DETAILS_TEMPLATE="global/template/api/extn/KohlsGetShipmentDetails_output.xml";
  	  //BOPUS Email Redesign --> End

 	   public static final String KOHLS_NAMESPACE_REMOVER = "KohlsNameSpaceRemover";




         // Payment Sync Updates START
         public static final String INT_PAYMENT_UPDATE_FAILURE_Q = "INT_PAYMENT_UPDATE_FAILURE_Q";
         public static final String REPRICE_PAYMENT_UPDATE_EXCEPTION_TYPE = "KohlsPaymentUpdateToATGFailureAlert";
         public static final String STATUS_OPEN = "OPEN";
         // Payment Sync Updates END

         //Adding the constants for learn env automation start
		public static final String MESSAGE_XML = "MessageXml";
		public static final String V_BACK_ROOM_PROCESS_PICK = "Backroom Pick in process.0001.ex";
		public static final String V_PLACED_IN_HOLD_LOCATION = "Hold Location.0001.ex";
		public static final String V_CODE_TYPE_HOLD_LOCATION = "BOPUS_HOLD_LOCATION";
		public static final String CUSTOMER = "cust";
		//Adding the constants for learn env automation end

		//added for user feed - start
        public static final String ATTR_LOGIN_ID = "Loginid";
        public static final String ATTR_USERGROUP_ID = "UsergroupId";
        public static final String ELEM_USER_GROUP_LIST = "UserGroupList";
        public static final String API_GET_USER_LIST = "getUserList";
        public static final String ATTR_ORGANIZATION_KEY = "OrganizationKey";
        public static final String ATTR_DEFAULT_ORGANIZATION_KEY = "DEFAULT";
        public static final String ATTR_ORGANIZATION_FLAG="OrgCheckFlag";
        public static final String ACTION_DELETE = "DELETE";
        public static final String ELEM_USER = "User";
        public static final String API_CREATE_USER_HIERARCHY = "createUserHierarchy";
        public static final String API_MODIFY_USER_HIERARCHY = "modifyUserHierarchy";
        public static final String API_DELETE_USER_HIERARCHY = "deleteUserHierarchy";
        public static final String TEMPLATE_GET_USER_HIERARCHY = "/global/template/api/extn/getUserHierarchy.xml";
        public static final String ATTR_GEN_PASSWORD = "GeneratePassword";
        public static final String ATTR_USER_NAME = "Username";
        public static final String ATTR_FIRST_NAME = "FirstName";
        public static final String ATTR_MIDDLE_NAME = "MiddleName";
        public static final String ATTR_LAST_NAME = "LastName";
        public static final String ATTR_ACTIVATE_FLAG = "Activateflag";
        public static final String ATTR_DATA_SECURITY_GROUP_ID = "DataSecurityGroupId";
        public static final String ATTR_LOCALE_CODE = "LocaleCode";
        public static final String ELEM_ORGANIZATION = "Organization";
        public static final String TEMPLATE_GET_ORGANIZATION_HIERARCHY = "/global/template/api/extn/getOrganizationHierarchy.xml";
        public static final String API_GET_ORGANIZAION_HIERARCHY = "getOrganizationHierarchy";
        public static final String ATTR_RESET = "Reset";
        public static final String STRING_TEMP_CODE_TYPE = "POC_TEMP_STORE_ROLES";
        public static final String ATTR_CODE_VALUE = "CodeValue";
        public static final String ATTR_CODE_NAME = "CodeName";
        public static final String ELEM_USER_GROUP_LISTS = "UserGroupLists";
        public static final String ELEM_COMMON_CODE = "CommonCode";
        public static final String ATTR_CODE_TYPE = "CodeType";
        public static final String STRING_STORE_LOC_FILTER_CODE_TYPE = "STORE_LOC_FILTER";
        public static final String STRING_KOHLS_CORP_LOC_CODE_TYPE = "KOHLS_CORP_LOCATIONS";
        //added for user feed - end

        public static final String LEARN_IMAGES = "LEARN_IMAGES";
		public static final String LEARN_DEFAULT_IMAGE = "LEARN_DEFAULT_IMAGE";
		public static final String LEARN_DEFAULT_ALT_TEXT = "LEARN_DEFAULT_ALT_TEXT";


		// BOPUS Email Redesign 2015 - Order Mod/ Cancel Email -- Start
		public static final String A_MIXED_ORDER = "MIXED";
		public static final String A_BOPUS_ORDER = "BOPUS";
		public static final String A_NON_BOPUS_ORDER = "NON_BOPUS";
		public static final Object READY_FOR_CUST_PICKUP_NOTIF_TYPE = "ORDER_READY_FOR_PICK";
		public static final String API_GET_ORDERLIST_FOR_BOPUS_ORDER_MOD_TEMPLATE_PATH = "global/template/api/getOrderListForBopusOrderMod.xml";
		public static final String ORDR_CANCEL_UNIQUE_ID_PROCESS_TYPE = "OC";
		public static final String ORDR_MOD_UNIQUE_ID_PROCESS_TYPE = "OM";
		//fix for the defect ER-481 --> Adding the logic to process OrderMod/Cancel messages as well for raising Alert
		public static final String ORDER_MOD = "ORDER_MOD";
		public static final String ORDER_CANCEL = "ORDER_CANCEL";
		// BOPUS Email Redesign 2015 - Order Mod/ Cancel Email -- End
		public static final String READY = "READY";
		public static final String IN_PROCESS = "IN_PROCESS";
		public static final String SHIP_NODE = "Shipnode";
		//added for EDW enhancements
		public static final String TIMESTAMP_DATEFORMAT1="yyyy-MM-dd'T'HH:mm:ssZ";
		// for edw

//Start changes for SFS-2015- OMS team

      public static final String A_TOTALS_CARTS = "TotalCarts";
      public static final String A_BATCH_SHMPT_COMPLT_FLAG= "BatchShpmtCmpltFlag";
      public static final String V_BATCH_CREATION_IN_PRROGRESS = "Batch in Process";

	  public static final String INV_SEARCH_FROM_SIM="InvSrchFromSIM";

      public static final String DEF_PRODUCT_CLASS="DEF_PRODUCT_CLASS";
      //End changes for SFS-2015- OMS team

	    //OASIS-79652,379,000 manageInventoryNodeControl call for auto cancel scenarios
        public static final String ELE_ITM_DETAILS = "ItemDetails";
        public static final String REPLACE = "Replace";
        //Added by OASIS-79652,379,000-CommonCode based manageInventoryNodeControl call
        public static final String DIRN_BAT_AUTO_CAN_ON = "DIRN_BAT_AUTO_CAN_ON";
        //End

//Device notification  -- Start
		 public static final String CODE_TYPE_INPROG = "INPROGRESS";
		 public static final String V_CODE_TYPE_INPROG = "IN_PROGRESS";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION = "Action";
		 public static final String BOPUS_DEVICE_NOTIFICATION_DEFAULT_ACTION = "BOPUS_DEVICE_NOTIFICATION_DEFAULT_ACTION";
		 public static final String BOPUS_STORE_ID_PREFIX="StoreId_x003D_";
	 	 public static final String BOPUS_SHIPMENT_ID_PREFIX="ShipmentKey_x003D_";
	 	 public static final String BOPUS_USER_ID_PREFIX="userId_x003D_";
		 public static final String BOPUS_SHIPMENT_HEADER_PREFIX="ShipmentHeaderKey_x003D_";
		 public static final String BOPUS_DEVICE_NOTIFICATION_URL="BOPUS_DEVICE_NOTIFICATION_URL";
		 public static final String BOPUS_URL_POST_URL="BOPUS_URL_POST_URL";
		 public static final String BOUPS_DEVICE_TASK_Q_TRAN_ID="KohlsDeviceTaskQRetry.0001.ex";
		 public static final String MANAGE_TASK_Q_API="manageTaskQueue";
		 public static final String DEVICE_NOTIFICATION_WS = "KohlsDeviceSendNotificationService";
		 public static final String SEND_DEVICE_NOTIFICATION_WS = "KohlsSendDeviceNotificationService";
		 public static final String DEVICE_NOTIFICATION_HEADER_SERVICE = "KohlsSendNotificationHeaderService";
		 public static final String BOPUS_DEVICE_NOTIFICATION_PRIORITY = "Priority";
		 public static final String BOPUS_DEVICE_NOTIFICATION_PRIORITY_TITLE_PREFIX = "DN_PRIORITY_TITLE_";
		 public static final String BOPUS_DEVICE_NOTIFICATION_STATUS_AWAITING_STORE_PICK = "DN_STATUS_AWAITING_STORE_PICK";
		 public static final String BOPUS_DEVICE_NOTIFICATION_STATUS_STORE_PICK_IN_PROGRESS = "DN_STATUS_STORE_PICK_IN_PROGRESS";
		 public static final String BOPUS_DEVICE_NOTIFICATION_STATUS_STORE_PICK_COMPLETED = "DN_STATUS_STORE_PICK_COMPLETED";
		 public static final String BOPUS_DEVICE_NOTIFICATION_STATUS_PLACED_IN_HOLD_LOCATION= "DN_STATUS_PLACED_IN_HOLD_LOCATION";
		 public static final String BOPUS_DEVICE_NOTIFICATION_STATUS_EXPIRED_PICKUP = "DN_STATUS_EXPIRED_PICKUP";
		 public static final String BOPUS_DEVICE_NOTIFICATION_STATUS_PUTAWAY_STARTED = "DN_STATUS_PUTAWAY_STARTED";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION_NEEDED_RETURN ="DN_ACTION_NEEDED_RETURNED";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION_NEEDED_P1 ="DN_ACTION_NEEDED_P1";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION_NEEDED_P1_COMPLETED = "DN_ACTION_NEEDED_P1_PICK_COMPLETED";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION_NEEDED_P2 ="DN_ACTION_NEEDED_P2";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION_NEEDED_P2_COMPLETED = "DN_ACTION_NEEDED_P2_PICK_COMPLETED";
		 public static final String BOPUS_DEVICE_NOTIFICATION_ACTION_NEEDED_P3 ="DN_ACTION_NEEDED_P3";
		 public static final String BOPUS_DEVICE_SEND_NOTIFICATION_SERVICE="KohlsDeviceSendNotificationService";
		 public static final String BOPUS_DEVICE_NOTIFICATION_MAP ="DEVICE_NOTIFICATION_MAP";

		 // used for device notification, but in case webservice messages need soap headers
		 // while calling KohlsInvokeSOAPWebserviceUtil, this will be the service name
		 // that is called to generate the headers
		 public static final String HEADER_TEMPLATE_SERVICE = "HEADER_TEMPLATE_SERVICE";
		 public static final String HEADER_TEMPLATE_INPUT = "HEADER_TEMPLATE_INPUT";

		  //1st Jan End // Reconsolidation logic -- End
    // Reconsolidation logic -- End
      //OASIS-80569,379,000-LargeOrder scheduling issue
      public static final String STR_LARGE_ORD_OL_COUNT = "LARGE_ORD_OL_COUNT";
      public static final String STR_LARGE_ORD_SCHED_WA = "LARGE_ORD_SCHED_WA";
      public static final String STR_COUNT = "Count";
      public static final String STR_APPROACH = "Approach";
      public static final String ELE_ORD_HOLD_TYPES = "OrderHoldTypes";
      public static final String ELE_ORD_HOLD_TYPE = "OrderHoldType";
      public static final String OOB_SCHEDULE_HOLD = "OOB_SCHEDULE_HOLD";
      public static final String LARGE_ORD_MANUAL_RESOLVE_HOLD = "LAR_ORD_MAN_RES_HOLD";
      public static final String RELEASE_HOLD = "RELEASE_HOLD";
      public static final String HOLD_TYPE = "HoldType";
      public static final String ORDER_TYPE = "OrderType";
      public static final String LARGE_ORD_MAN_RES = "LAR_ORDER_MAN_RES";
      public static final String ATTR_OVERRIDE = "Override";
      public static final String ELE_HOLD_TYPES_TO_PROCESS = "HoldTypesToProcess";
      public static final String ELE_PROCESSED_HOLD_TYPES = "ProcessedHoldTypes";
      public static final String STR_CONSOLE = "Console";
      public static final String API_SCHEDULE_ORDER = "scheduleOrder";
      //End-OASIS-80569,379,000

      //MDM Service call
      public static final String MDM_SERVICE = "KohlsInvokeMDMService";
      public static final String MDM_GET_SKU_SERVICE = "InvokeMDMGetSKUWebService";
      public static final String MDM_GET_CC_SERVICE = "InvokeMDMGetCCWebService";

      /** The Constant MDM_CALL_REQD. Common code Name. Represent MDM call requred or not*/
      public static final String MDM_CALL_REQD = "IS_MDM_REQD";
	  /** The gollowing constants are arguments of mdm webservice **/
	  public static final String MDM_MHVERSION  ="mhversion";
      public static final String MDM_FRAPP ="frapp";
      public static final String MDM_FRMODULE ="frmodule";
      public static final String MDM_FRNODEID ="frnodeID";
      public static final String MDM_FRSYSTEMCODE ="frsystemCode";
      public static final String MDM_AFWANTCHILDREN ="afWantChildren";
      public static final String MDM_AFWantRelationship ="afWantRelationship";
      public static final String MDM_NSSOAPENV ="nsSoapEnv";
      public static final String MDM_NSSOAPENVURI ="nsSoapEnvURI";
      public static final String MDM_NSURN ="nsUrn";
      public static final String MDM_NSURNURI ="nsUrnURI";
      public static final String MDM_NSV1 ="nsV1";
      public static final String MDM_NSV1URI ="nsV1URI";
      public static final String MDM_NSV11 ="nsV11";
      public static final String MDM_NSV11URI ="nsV11URI";
      public static final String MDM_NSV12 ="nsV12";
      public static final String MDM_NSV12URI ="nsV12URI";
      public static final String MDM_XMLNS ="xmlns";
      public static final String PATH= "http://www.w3.org/2000/xmlns/";
      public static final String MSGID_TEXT="test";
      public static final String MDM_NSV1PREFIX="nsV11Prefix";
      public static final String SHOEBOXIDENTIFIER="ShoeBoxIdentifier";
	  public static final String MESSAGEID = "messageID";

      /** The Constant MDM_NO_ITEMS. Common code Name. Represent No of Items to be split*/
      public static final String MDM_NO_ITEMS="MDM_NO_OF_ITEMS";

      //End MDM Serice call

      //SFS Mobile Changes
      /** The Constant PACK_ALLOWED_LIMIT. It's a common code name*/
      public static final String PACK_ALLOWED_LIMIT = "PACK_ALLOWED_LIMIT";

      /** The Constant PACK_BY_BIN. It's a common code name */
      public static final String PACK_BY_BIN = "PACK_BY_BIN";

      /** The Constant INT_ONE. */
      public static final int INT_ONE = 1;
      //End Mobile Changes}

      //End-OASIS-80569,379,000
    //for Kohls Bopus Return

    		public static final String CREATE_ORDER_INVOICE_API = "createOrderInvoice";
    		//For XML Transformation
    		public static final String REQ_COLLECTION_API = "requestCollection";
    		//For XML Transformation
    		public static final String EXE_COLLECTION_API = "executeCollection";
    		//For XML Transformation
    		public static final String CHANGE_ORDER_STAT_API = "changeOrderStatus";
    		//For XML Transformation
    		public static final String ORDER_STAT_CHANGE_ROOT_ELE = "OrderStatusChange";
    		//For XML Transformation
    		public static final String RECEIVE_ORDER_TRANS_ID = "RECEIVE_ORDER.0003";
    		//For XML Transformation
    		public static final String RECEIVE_ORDER_DROP_STAT = "3900";
    		//For XML Transformation
    		public static final String REMOVE_NAMESPACE_FROM_NODES = "RemoveNodePrefixesFromXml";
    		//For XML Transformation
    		public static final String GET_ORDER_DETAILS_FOR_RETURN_TEMP = "global/template/api/getOrderDetailsForReturnProcess.xml";
    		//For XML Transformation
    		public static final String GET_SHIPMENT_LIST_TEMP = "global/template/api/getShipmentList.xml";
    		//For XML Transformation
    		public static final String PARTIALLY_RETURNED = "Partially Returned";
    		//For XML Transformation
    		public static final String RETURN_CREDIT_CARDS = "RETURN_CREDIT_CARDS";
    		//For XML Transformation
    		public static final String REGULAR_RETAIL_AMT = "RegularRetailAmt";
    		//For XML Transformation
    		public static final String SALES_TAX = "SALES_TAX";
    		//For XML Transformation
    		public static final String CHARGE_CATEGORY = "CHARGE_CATEGORY";
    		//For XML Transformation
    		public static final String RETURN_TAXES = "RETURN_TAXES";
    		//For XML Transformation
    		public static final String CORPORATE_REFUND = "CORPORATE_REFUND";
    		//For XML Transformation
    		public static final String OTR_ALERT_SERVICE = "RaiseAlertForOTRResponseIsOffline";

    		//BOPUS RETURNS
    		public static final String CREATE_ORDER_INVOICE_TEMP = "global/template/api/extn/createOrderInvoice_BOPUSReturn.xml";
    		//BOPUS RETURNS
    		public static final String SENDINVOICE_TRANS_ID = "SEND_INVOICE.0003";
    		//BOPUS RETURNS
    		public static final String CREATE_ORDER_INVOICE_TRANS_ID = "CREATE_ORDER_INVOICE.0003";

    		 //For Invoice POsting

            public static final String TEMPLATE_ORDER_LIST = "global/template/api/getOrderList_BOPUSReturns.xml";
            public static final String TEMPLATE_SO_RETURNS = "global/template/api/getOrderList_SO.xml";

            //For Invoice POsting
            public static final String GET_ITEM_LIST_TEMP = "global/template/api/getItemListTemplate_BOPUSReturns.xml";


            //For XML Transformation

    	public static final String E_PARAMETERS = "Parameters";
    	//For XML Transformation
    	public static final String E_ERRORS = "Errors";
    	//For XML Transformation
    	public static final int ZERO = 0;
    	//For XML Transformation
    	public static final String E_RECORD = "RECORD";
    	//For XML Transformation
    	public static final String E_XST_OFR = "XST_OFR";
    	//For XML Transformation
    	public static final String E_XST_OFR_SECT = "XST_OFR_SECT";
    	//For XML Transformation
    	public static final String E_XST_OFR_BWP = "XST_OFR_BWP";
    	//For XML Transformation
    	public static final String CONST_RES = "RES";
    	//For XML Transformation
    	public static final String E_DETAIL = "detail";
    	//For XML Transformation
    	public static final String E_ERROR = "Error";
    	//For XML Transformation
        public static final String E_CODE = "code";
      //For XML Transformation
        public static final String E_MESSAGE = "message";
      //For XML Transformation
        public static final String A_ERROR_DESCRIPTION = "ErrorDescription";
      //For XML Transformation
        public static final String REQ_TEM_PLULOOKUP = "tem:PLULookup";
      //For XML Transformation
        public static final String REQ_XMLNS_TEM = "xmlns:tem";
      //For XML Transformation
        public static final String REQ_NAMESPACE_PLUAPE = "http://tempuri.org/";
      //For XML Transformation
        public static final String REQ_TEM_XMLIN = "tem:xmlIn";
      //For XML Transformation
        public static final String REQ_TEM_CALCULATEBASKET = "tem:CalculateBasket";
      //For XML Transformation
    	public static final String A_GUID = "Guid";
    	//For XML Transformation
    	public static final String E_MODIFIER = "Modifier";
    	//For XML Transformation
        public static final String CONST_REQ = "REQ";
      //For XML Transformation
        public static final String E_TLD = "TLD";
      //For XML Transformation
        public static final String E_PROMO = "Promo";
      //For XML Transformation
        public static final String E_PRICING = "Pricing";
      //For XML Transformation
        public static final String E_OFFER = "Offer";
      //For XML Transformation
        public static final String E_CRITERIA = "Criteria";
      //For XML Transformation
        public static final String E_MERCHANDISE_SET = "MerchandiseSet";
      //For XML Transformation
        public static final String E_MANUAL_LID = "ManualLID";
      //For XML Transformation
        public static final String E_EXCLUSIONS = "Exclusions";
      //For XML Transformation
        public static final String E_EXCLUSION_TAG = "ExclusionTag";
      //For XML Transformation
        public static final String TLD_DOLLAR_OFF = "TLD_DOLLAR_OFF";
      //For XML Transformation
    	public static final String TLD_PERCENT_OFF = "TLD_PERCENT_OFF";
    	//For XML Transformation
    	public static final String A_PROMOTION_TYPE = "PromotionType";
    	//For XML Transformation
    	public static final String E_MANUAL_TLD = "ManualTLD";
    	//For XML Transformation
    	public static final String A_MARK_DOWN_VALUE = "MarkdownValue";
    	//For XML Transformation
    	public static final String A_DISCOUNT_TYPE = "DiscountType";
    	//For XML Transformation
    	public static final String A_IE_INDICATOR = "IEIndicator";
    	//For XML Transformation
    	public static final String A_LEGACY_FLAG = "LegacyFlag";
    	//For XML Transformation
    	public static final String E_DEPARTMENTS = "Departments";
    	//For XML Transformation
        public static final String GET_TAX_CALCULATION = "getTaxCalculation";
      //For XML Transformation
        public static final String TAXWARE_NAMESPACE = "http://NextGenPOS.kohls.com/TaxServiceRequest/";
      //For XML Transformation
        public static final String TAXWARE_REQ_PREFIX = "tax:";
      //For XML Transformation
        public static final String E_MODIFIER_LIST = "ModifierList";


    //proration
            public static final String  KOHLS_APE_WEB_CALL = "KohlsBopusAPEWebservice";
          //proration
            public static final String  KOHLS_POST_TO_POP_Q = "KohlsPostToPOPQueue";

			//SDD
            public static final String SDD = "SDD";
            public static final String CC_DESC_READY_FOR_CARRIER = "Ready_For_Carrier";
            public static final String CC_DESC_READY_FOR_PACK = "Ready_For_Packing";
            public static final String SDD_DEVICE_NOTIFICATION_PRIORITY_TITLE_PREFIX = "DN_PRIORITY_TITLE_SDD_";
            public static final String SDD_DEVICE_NOTIFICATION_STATUS_READY_FOR_CARRIER_PICKUP = "DN_STATUS_READY_FOR_CARRIER_PICKUP";
            public static final String SDD_DEVICE_NOTIFICATION_STATUS_READY_FOR_PACKING = "DN_STATUS_READY_FOR_PACKING";
            public static final String STATUS_READY_FOR_CARRIER_PICKUP = "1100.70.06.40";
            public static final String STATUS_CARRIER_PICKED_UP = "1400.10";
            public static final String STATUS_READY_FOR_PACKING = "3350.15";
            public static final String STATUS_ORD_READY_FOR_CARRIER_PICKUP = "3350.25";
            public static final String STATUS_ORD_CARRIER_PICKED_IP = "3700.10";
            public static final String CODE_TYPE_SDD_NODES = "SDD_NODES";
            public static final String TRAN_ID_SDD_ORDER_INVOICE_0001_EX = "SDD_ORDER_CREATE_INVOICE.0001.ex";
            public static final String TRAN_ID_SDD_CARRIER_PICKED_UP_EX = "PROCESS_CARRIER_PICKUP.0001.ex";
            public static final String FT_KOHLS_SAME_DAY = "KOHLS_SAME_DAY";
            public static final String SERVICE_KOHLS_SEND_STATUS_TO_EDW = "KohlsOrderStatusUpdateToEDW";
            public static final String CODE_TYPE_SDD_ORDER_STATUS = "SDD_ORDER_STATUS";
            public static final String CODE_TYPE_SDD_EDW_ORDER_STATUS = "SDD_EDW_ORDER_STATUS";
            public static final String TRAN_ID_READY_PACK_SD_0001_EX = "READY_FOR_SDD_PACK.0001.ex";
            public static final String CODE_TYPE_SDD_SHP_MONTR_STATUS = "SDD_SHP_MONTR_STATUS";
            public static final String STATUS_READY_FOR_PACKING_SHIP = "1100.70.06.50";
            public static final String SDD_PICKUP_TIME = "PICKUP_TIME";
            public static final String SDD_PICKUP_STATUS_LIST = "STATUS_LIST";
            public static final int SDD_DUE_TIME = 11;
            public static final String SFS_API_TEMPLATE_GET_SHIPMENT_LIST_FOR_APA = "KohlsGetShipmentListForAPA_getShipmentList";
            public static final String SFS_API_TEMPLATE_GET_SHIPMENT_LIST_COUNT_FOR_APA ="KohlsGetShipmentListForAPA_getShipmentCount";
            public static final String SFS_API_TEMPLATE_GET_SHIPNODE_LIST_FOR_APA = "KohlsGetShipmentListForAPA_getShipNodeList";
            public static final String SFS_STATUS_AWAITING_PICK_LIST_PRINT = "1100.025";
            public static final String SDD_HOLD_LOCATION_CONT="SD";
            public static final String SDD_MESSAGE_FOR_DELAY_CARRIER_PICKUP="DN_MESSAGE_FOR_CARRIER_PICKUP";
            public static final String ORDER_DELIVERY_ORDER_NOTE_TXT_SDD_PART_1 = "Order Delivery Email has been triggered for Shipment No:";
            public static final String E_ITEMS_DELIVERING = "ItemsDelivering";
            public static final String SDD_ODR_MOD_EML_SERVICE = "KohlsSDDSendOrderModEmails";

            //Added Newly for Bopus Returns
    	 	public static final String API_GET_ORDER_DETAILS_BOPUS_TEMPLATE = "global/template/api/extn/KohlsBOPUSGetOrderDetails_output.xml";
    	 	public static final String R_STATUS = "1100.70.06.30";
    	 	public static final String RO_DOCUMENT_TYPE = "0003";
    	 	public static final String MONITOR_EVENT_SERVICE = "KohlsBopusProcessPendingReturnService";
    	 	public static final String REFUND_REQUIRED = "CorporateRefundRequired";
    	 	public static final String EDIT_ERROR = "EditError";
    	 	public static final String HARD_DECLINE = "HardDecline";
    	 	public static final String REFUND_AUTH = "RefundAuth";
    	 	public static final String TRANSACTION_NOT_FOUND = "TransactionNotFound";
    	 	public static final String OFFLINE = "Offline";
    	 	public static final String SALES_ORDER_DETAILS = "SALES_ORDER_DETAILS";
    	 	public static final String RETURN_RESPONSE = "RETURN_RESPONSE";
    	 	public static final String RETURN_SERVICE = "getBopusReturnsResponseService";
    	 	public static final String RECEIPTID_MAX = "999999999999999999999999999";
    	 	public static final String RETURN_SEQUENCE= "SELECT SEQ_AUTH_REG_TRANS_NO_STORE.NEXTVAL from DUAL";
    	 	public static final String SHIPMENT_LIST = "shipment_list";




    	 	// for KohlsCash webservice
    		public static final String KOHLS_CASH_ID = "KohlsCashID";
    		public static final String KOHLS_CASH_EVENT_ID = "KohlsCashEventID";
    		public static final String HEADER = "Header";
    		public static final String STORE = "Store";
    		public static final String TERMINAL = "Terminal";
    		public static final String TRANS_NUM = "TransactionNumber";
    		public static final String BUSINESS_DATE = "BusinessDate";
    		public static final String ASSO_ID = "AssociateID";
    		public static final String TRAN_START_DATE = "TranStartDateTime";
    		public static final String TRAINING_MODE = "TrainingMode";
    		public static final String DATA = "Data";
    		public static final String RECEIPT_ID = "ReceiptID";
    		public static final String KOHLS_CASH_WEB_CALL = "KohlsCallKohlsCashService";
    		public static final String REFUND_REDUCTION  = "RefundDeduction";
    		public static final String KOHLS_CASH_REDUCTION  = "KohlsCashReduction";
    		public static final String EXTN_KOHLS_CASH_REDUCTION = "ExtnKohlsCashReduction";
    		public static final String SUB_LINE_NO = "SubLineNo";
    		public static final String LINE_TOT = "LineTotal";
    		public static final String LINE_PRICE_INFO = "LinePriceInfo";
    		public static final String CHARGE_PER_LINE = "ChargePerLine";
    		public static final String CHANGE_TO_EXPIRED_TRANSACION_ID = "Change To Expired.0001.ex";

    		//Added for Returns
			public static final int NUMBER_19 = 19;
			//Added for Returns
			public static final int NUMBER_25 = 25;
			//Added for Returns
			public static final int NUMBER_4 = 4 ;
			//Added for Returns
			public static final int NUMBER_27 = 27;
			//Added for Returns
			public static final int NUMBER_100 = 100;
			public static final String MESSAGE_TYPE_RETURNS = "Returns";


			//Added for Returns Hard Totals
			public static final int CORP_REFUND_ISSUED_COUNT = 1;


			//returns


			public static final String KC_RES = "KOHLSCASH_RESPONCE";
			public static final String Converted_OTR = "Converted_OTR";
			public static final String REFUND_TAX = "REFUND_TAX";
			public static final String RETURN_PRORATION = "RETURN_PRORATION";
			public static final String PRO_VALUE = "ProratedValue";
			public static final String SHIP_LIST = "shipment_list";
			public static final String KOHLS_POP = "KohlsProcessOrderPayments";
			public static final String CORP_CARD = "CorporateCard";
			//For XML Transformation
			 public static final String T = "T";
				//Added for common code name for RED item consolidation
				public static final String V_PACKLISTTYPE_RELEASE =  "PACKLISTTYPE_RELEASE";

			//Defect# 1925
			public static final String ACTION_REMOVE =  "REMOVE";

			//June 2015 Release - create order changes - Start
		    public static final String A_DISCOUNT_CHARGE_NAME_LID="LID";
		    //June 2015 Release - create order changes - End

		    //June 2015 Release - Added for order delivery email - Changes start here
			public static final String TEMPLATE_GET_SHIPMENT_LIST_ORDER_DELIVERY ="global/template/api/getShipmentList_OrderDelivery.xml";
			public static final String TEMPLATE_GET_SHIPMENT_LIST_FOR_ORDER_DELIVERY ="global/template/api/getShipmentListForOrder_OrderDelivery.xml";
			public static final String ORDER_DELIVERY_ORDER_NOTE_TXT_PART_1 = "Order Delivery Email has been triggered for Tracking No:";
	     	public static final String ORDER_DELIVERY_ORDER_NOTE_TXT_PART_2 = "having RequestID: ";
	     	public static final String ORDER_DELIVERY_ORDER_NOTE_TXT_PART_3 = "and RequestTS: ";
	     	public static final String ORDER_DELIVERY_UNIQUE_ID_PROCESS_TYPE = "OD";
	     	public static final String ORDER_DELIVERY_GET_ORDER_LIST_API_TEMPLATE = "global/template/api/getOrderList_OrderDelivery.xml";
	     	public static final String ORDER_DELIVERY_GET_ORDER_LINE_LIST_API_TEMPLATE = "global/template/api/getOrderLineList_OrderDelivery.xml";
	     	public static final String E_ITEMS_DELIVERED = "ItemsDelivered";
	     	public static final String E_ADDITIONAL_ITEMS = "AdditionalItems";
	     	public static final String A_ORDER_DELIVERY = "OrderDelivery";
	    	public static final String API_CREATE_KOHLS_CARRIER_NOTIFICATION_LIST = "createKohlsCarrierNotificationService";
	    	public static final String DELIVERY_STATUS_EXPIRED_PICKED = "3700.11";
	    	public static final String ROOT_NODE_FOR_ORDER_DELIVERY = "oms:OrderDeliveredOMSRequest";

	    	public static final String OD_STATUS_SKIP_LST = "OD_STATUS_SKIP_LST";
	    	public static final String CUSTOMER_PICKEDUP_STATUS = "3700.2";
			//June 2015 Release - Added for order delivery email - Changes End here

	    	//June 2015 Release - ER-138 Start
			public static final String TEMPLATE_GET_ORDER_LIST_CARRIER_DELAY ="global/template/api/getOrderListTemplateForCarrierDelayMail.xml";
	        public static final String CARRIER_DELAY_ORDER_NOTE_TXT_PART_5 ="Carrier Delay Notification obtained for";
	        public static final String SIMPLE_DATE_FORMAT2 = "yyyy-MM-dd'T'HH:mm:ss";
	        public static final String ORDER_DATES = "OrderDates";
	        public static final String ORDER_DATE = "OrderDate";
	        public static final String DATETYPEID="DateTypeId";
	        public static final String REQUESTEDDATE="RequestedDate";
			//June 2015 Release - ER-138 End
	  	  //E3 Notification
	  	  public static final String CODE_TYPE_SFS_DUE_IN_DAYS = "SFS_DUE_IN_DAYS";
	  	  public static final String CODE_TYPE_SFS_DUE_IN_TIME = "SFS_DUE_IN_TIME";
		  public static final String CODE_TYPE_RDC_DUE_IN_DAYS = "RDC_DUE_IN_DAYS";
	  	  public static final String CODE_TYPE_RDC_DUE_IN_TIME = "RDC_DUE_IN_TIME";
	  	  public static final int FORWARD_DAY_COUNT = 20;
	  	  public static final String SDD_SAME_DAY_CS = "Same Day";
	  	  public static final String SFS_SHP_DEL_METHOD = "SHP";
		  public static final String A_CARRIER_SERVICECODE_QRY_TYPE ="CarrierServiceCodeQryType";
	  	  public static final String CARRIER_SERVICECODE_TYPE = "NE";
	  	  public static final int complexQryLength=3;

		  //Stub for Proship Webservice
	      public static final String STUB_PROSHIP_WS = "STUB_PROSHIP_WS";
	    //Performance POC for SFS Batching
	      public static final String SFS_PERFORM = "SFS_PERFORM";

		  public static final int DEFAULT_APA_HOME_MAX_SHIPMENTS_TO_DISPLAY = 5;
          public static final long DEFAULT_APA_HOME_MAX_ALERTS_TO_DISPLAY =10;
          public static final String APA_HOME_MAX_SHIPMENTS_CODE_NAME = "APA_MAX_SHIPMENTS";
          public static final String APA_HOME_MAX_ALERTS_CODE_NAME = "APA_MAX_ALERTS";
          public static final String APA_HOME_COMMON_CODE_MASHUP_ID = "getMaxRecordsCommonCode";
          public static final String APA_HOME_PUTAWAYSHIPMENT_COUNT_MASHUP_ID = "putawayInProgressPortlet_getShipmentListCount";
		  public static final String API_GET_ORDER_DETAILS_FOR_KC_OOB_HOLD_TEMPLATE_PATH = "global/template/api/BOPUS/getOrderDetailsForKCOOBHold_output.xml";


		//Kohls Security Remediation Module Constants.	- START
		/**
		 * Adding Constant variable for Zipcode.
		 */
		public static final String ZIPCODE = "zipcode";
		/**
		 * Adding Constant variable for LastName.
		 */
		public static final String LAST_NAME = "lastname";
		/**
		 * Adding Constant variable for FirstName.
		 */
		public static final String FIRST_NAME = "firstname";
		/**
		 * Adding Constant variable for emailid.
		 */
		public static final String EMAILID = "emailid";
		/**
		 * Adding Constant variable for Encryption.
		 */
		public static final String ENCRYPTION = "Encryption";
		/**
		 * Adding Constant variable for Decryption.
		 */
		public static final String DECRYPTION = "Decryption";
		/**
		 * Adding Constant variable for XC_CHARSET.
		 */
		public static final String XC_CHARSET = "UTF-8";
		/**
		 * Adding Constant variable for HOST.
		 */
		public static final String PROTEGRITY_SERVER_HOST = "HOST";
		/**
		 * Adding Constant variable for DATA_ELEMENT.
		 */
		public static final String DATA_ELEMENT = "DATA_ELEMENT";
		/**
		 * Adding Constant variable for POLICY_USER.
		 */
		public static final String POLICY_USER = "POLICY_USER";
		/**
         * Adding Constant variable for SECURE_SERVER_HOST.
         */
        public static final String SECURE_SERVER_HOST = "SECURE_SERVER_HOST";
        /**
         * Adding Constant variable for SECURE_DATA_ELEMENT.
         */
        public static final String SECURE_DATA_ELEMENT = "SECURE_DATA_ELEMENT";
        /**
         * Adding Constant variable for SECURE_POLICY_USER.
         */
        public static final String SECURE_POLICY_USER = "SECURE_POLICY_USER";
		/**
		 * Adding Constant variable for PROTEGRITY TYPE.
		 */
		public static final String PROTEGRITY_TYPE = "protegrityType";
		/**
		 * Adding Constant variable for ZIPCODE_ELEMENTSLIST.
		 */
		public static final String ZIPCODE_ELEMENTSLIST = "Zipcode_ElementsList";
		/**
		 * Adding Constant variable for ZIPCODE_ELEMENTSLIST.
		 */
		public static final String SECURITY_ATTRIBUTES = "SECURITY_ATTRIBUTES";
		/**
		 * Adding Constant variable for ENCRYPT_ARGUMENT.
		 */
		public static final int ENCRYPT_VALUE = 0;
		/**
		 * Adding Constant variable for DECRYPT_ARGUMENT.
		 */
		public static final int DECRYPT_VALUE = 1;
		/**
		 * Adding Constant variable for Zipcode_Elements.
		 */
		public static final String PREVENT_ZIPCODE_ELEMENTS = "Zipcode_Elements";
		/**
		 * Adding Constant variable for ENABLE_MESSAGE_HEADER.
		 */
		public static final String ENABLE_MESSAGE_HEADER = "ENABLE_MESSAGEHEADER";
		/**
		 * Adding Constant variable for invoice Xml modification.
		 */
		public static final String EXTN_ELEMENT_PATH = "/InvoiceDetail/InvoiceHeader/Extn";
		/**
		 * Adding Constant variable for release Xml modification.
		 */
		public static final String EMail_ID = "EMailID";

		/**
		 * Adding Constant variable for WAIT_TIME
		 */
		public static final String WAIT_TIME = "WAIT_TIME";

		/**
		 * Adding Constant variable for release Xml modification.
		 */
		public static final String MESSAGE_HEADER_FLAG = "IncludeCAMessageHeaderFlag";

		public static final String SEND_AGED_E3_EMAIL = "SEND_AGED_E3_EMAIL";

		/**
		 * Adding Constant variable for SYSTEM_CODE
		 */
		public static final String SYSTEM_CODE = "systemCode";

		/**
		 * Adding Constant variable for MODULE
		 */
		public static final String MODULE = "module";

		/**
		 * Adding Constant variable for APP_NAME.
		 */
		public static final String APP_NAME = "appName";
		/**
		 * Adding Constant variable for HDR_VERSION.
		 */

		public static final String HDR_VERSION = "hdrVersion";
		/**
		 * Adding Constant variable for QUEUE_MAX_SIZE.
		 */

		public static final String QUEUE_MAX_SIZE = "QUEUE_MAX_SIZE";
		/**
		 * Adding Constant variable for QUEUE_MIN_SIZE.
		 */
		public static final String QUEUE_MIN_SIZE = "QUEUE_MIN_SIZE";
		/**
		 * Adding Constant variable for API_GET_KOHLS_CUSTOMER_NOTIFICATION_FILTERED_LIST.
		 */
		public static final String API_GET_KOHLS_CUSTOMER_NOTIFICATION_FILTERED_LIST = "getKohlsCustomerNotificationFilteredList";

		public static final String WAIT_TIME_VALUE = "1000";


		//Kohls Security Remediation Module Constants. - END

		//Constant Variable Added for ESO -- Start
		public static final String ONE_DAY_DELIVERY = "1BUSDAY";
		public static final String TWO_DAY_DELIVERY = "2BUSDAY";
		public static final String NEXT_DAY = "NextDay";
		public static final String TWO_DAY = "TwoDay";
		//Constant Variable Added for ESO -- Start
		//SR sprint7
        public static final String BLANK_SPACE = " ";
        public static final String ATTR_CUST_NAME = "CustomerName";
        public static final String ATTR_DEST_CON_NAME = "DestinationContactName";
        public static final String ATTR_BILL_TO_NAME = "BillToName";
        public static final String ATTR_BILL_TO_POSTCODE = "BillToPostalCode";
        public static final String ATTR_ZIPCODE = "ZipCode";
        public static final int CUSTOMER_NAME_LENGTH = 91;
        public static final int DESTINATION_CONTACT_NAME_LENGTH = 50;
        public static final int BILL_TO_POSTAL_CODE_LENGTH = 10;

        //Apple Pay -- Start
        public static final String PAYMENT_TYPE_APPLE_PAY = "Apple Pay";
        //Apple Pay -- End.

        //public static final String SEND_AGED_E3_EMAIL = "SEND_AGED_E3_EMAIL";
        //WIP
        public static final String TOTAL_IN_PROGRESS ="Total In Progress";

		public static final String PUTAWAY_ALERT_SERVICE = "KohlsBOPUSPutAwayAlert";

		public static final String PUTAWAY_ALERT_GETSHIPMENTLIST_TEMPLATE = "getShipmentListForPutawayAlert";
		  /*Start:Create Order Aug Release*/

		public static final String V_GWP="GWP";
		public static final String V_PWP="PWP";
		public static final String A_EXTN_OFFER_PRODUCT_TYPE="ExtnOfferProductType";
		public static final String V_PWP_GWP_GET="_GET";
		public static final String V_PWP_GWP_BUY="_BUY";
		public static final String V_BUY="BUY";
		public static final String V_GET="GET";

		/*End:Create Order Aug Release*/

		public static final int THIRTEEN = 13;

	    public static final String NEXTDAY_CS = "1BUSDAY";
	    //PrePeak Begin
	    public static final String NO_OF_DAYS_EXTEND="NO_OF_DAYS_EXTEND";
	    public static final String TOTAL_NO_DAYS_EXTEND="TOTAL_NO_DAYS_EXTEND";
	    public static final String EXTENSION_DAYS="ExtensionDays";
	    public static final String CUSTOMER_PICKED_UP="1400.1";
	    public static final String GET_SHIPMENT_LIST_OUTPUT_TEMPLATE="global/template/api/KohlsGetShipmentListCancelExtendPick_output.xml";
	    public static final String CHANGE_SHIPMENT_TEMPLATE="global/template/api/KohlsChangeShipment.output.xml";
		//Modification Code Review Comments Start
        public static final String  EXTEND_PICKUP_ENABLE="EXTEND_PICKUP_ENABLE";
        //Modification Code Review Comments End
        //PrePeak Perf/624 - start
        public static final String REFUND_PICKUP_ENABLE="REFUND_PICKUP_ENABLE";
        public static final String REFUND_PICKUP_COMMONCODE_MASHUP="extn_getCommonCodeList_turnOnOff";
        public static final String EXTEND_PICKUP_MASHUP="extn_extend_pick_mashup";
      //PrePeak Perf/624 - end

	    //PrePeak End
		public static final String TWODAY_CS = "2BUSDAY";

		public static final String SHIP_TYPE_MULTI_NEXTDAY = "Multi_NextDay";

		public static final String SHIP_TYPE_MULTI_TWODAY = "Multi_TwoDay";

		public static final String SHIP_TYPE_SINGLE_NEXTDAY = "Single_NextDay";

		public static final String SHIP_TYPE_SINGLE_TWODAY = "Single_TwoDay";
		public static final String SIMPLE_DATE_FORMAT3 ="MM/dd/yyyy";

		public static final String RDC_DUE_CUT_OFF_TIME = "RDC_DUE_CUT_OFF_TIME";

		public static final String SFS_DUE_CUT_OFF_TIME = "SFS_DUE_CUT_OFF_TIME";

		public static final String PRIORITY_CS = "Priority";

		//Added for SDD and BOPUS invoice process enhancement - R22
		public static final String SERVICE_KOHLS_CREATE_ASYNC_REQ_FOR_ECOM_BOPUS = "KohlsCreateAsyncReqForECOMForBPS";

		//Hold Location constants -- Maseeh Sabir
		public static final String GET_SHIPMENT_DETAILS_TEMPLATE = "<Shipment ShipmentKey = \"\" ShipNode=\"\" OrderNo=\"\" Status=\"\" Createts=\"\"><BillToAddress FirstName=\"\" LastName=\"\"/>"
					+ "<ShipmentLines><ShipmentLine Quantity=\"\"><OrderLine OrderHeaderKey=\"\">"
					+ "<ItemDetails ImageURL=\"\"><PrimaryInformation ShortDescription=\"\"/>"
					+ "<ItemAliasList><ItemAlias ItemAlias=\"\"/></ItemAliasList>"
					+ "</ItemDetails></OrderLine></ShipmentLine></ShipmentLines>"
					+ "<Extn ExtnHoldLocationID=\"\" ExtnHoldLocationDesc=\"\" ExtnShipmentIndicator=\"\"/></Shipment>";
		public static final String HLD_GET_SHIPMENT_LIST_TEMPLATE = "<Shipments TotalNumberOfRecords=\"\">"
					+ "<Shipment ShipmentKey=\"\">"
					+ "<Extn ExtnHoldLocationID=\"\" ExtnHoldLocationDesc=\"\"/>"
					+ "</Shipment></Shipments>";

		//Fix for 415 -- Maseeh Sabir -- 9/10/15
		public static final String HLD_GET_STATUS_CODES_INPUT = "<CommonCode CodeType=\"HLD_LOCATION_CODES\"/>";
		public static final String HLD_GET_STATUS_CODES_TEMPLATE = "<CommonCodeList><CommonCode CodeValue=\"\"/></CommonCodeList>";
		// End of 415
		// Mark dirty node for SDD and BPS -- begin
		public static final String ENABLE_BPS = "ENABLE_BPS";
		public static final String ENABLE_SDD = "ENABLE_SDD";
		public static final String EXTN_OCF = "ExtnOCF";
		public static final String DIRTY_NODE_BATCH_AUTO_CANCEL = "DirtyNodeBatchAutoCancel";
		// Mark dirty node for SDD and BPS -- end

		/*Start:Create Order Sep Release*/
        public static final String A_COMPLETE_SHIPMENT = "Complete Shipment";
        public static final String A_PARTIAL_SHIPMENT = "Partial Shipment";
        public static final String A_OMS_ORDER_DELAY = "OMS Order Delay";
        public static final String A_PACK_SLIP = "Packslip";
        /*End:Create Order Sep Release*/


		// AugustRelease as part of ER-487---Start
        public static final String COMPLETE_SHIPMENT_UNIQUE_ID_PROCESS_TYPE = "CS";
        public static final String PARTIAL_SHIPMENT_UNIQUE_ID_PROCESS_TYPE = "PS";
        public static final String NONBOPUS_ORDER_DELAY_UNIQUE_ID_PROCESS_TYPE = "NBOD";
        public static final String SHIPMENT_ORDER_NOTE_TXT_PART_1 = "with Request ID ";
        public static final String SHIPMENT_ORDER_NOTE_TXT_PART_2 = "and Request TS ";
        // AugustRelease as part of ER-487---End

		 //SFS Bopus POC
		 public static final String A_DELIVERY_METHOD = "DeliveryMethod";
		 public static final String V_SHIP = "SHP";
		 public static final String V_AWAITING_STORE_PICK = "1100.70.06.10";
		 public static final String TEMLATE_GET_SHIPMENT_LIST_TO_STAMP_BATCH_NO_BOPUS = "global/template/api/getShipmentListToStampBatchNoBopus.xml";
		 public static final String A_EXTN_USERNAME = "ExtnUsername";
		 public static final String A_ASSIGNED_TO_USER_ID = "AssignedToUserId";
		 public static final String API_GET_USER_HIERARCY = "getUserHierarchy";
		 public static final String A_LOGINID = "Loginid";
		 public static final String A_USERNAME = "Username";
		 public static final String V_BOPUS_DROP_STATUS = "1100.70.06.20";
		 public static final String V_BOPUS_TRANSACTION_ID = "Process Backroom Pick.0001.ex";
		 public static final String A_BATCH_TYPE = "BatchType";
		 public static final String V_SFS = "SFS";
		 public static final String V_BOPUS = "BOPUS";
		 public static final String A_COLONY_ID = "ColonyId";
		 public static final String V_DEFAULT = "DEFAULT";

		//SFS MDM constant
		public static final String A_NUMBER_OF_RECORDS = "NumberOfRecords";

		// Protegrity Return Invoice Encryption changes
		public static final String NO_OF_ATTRIBUTES = "NoOfAttributes";
		public static final String DELIMITED_SLASH = "\\|";
		public static final String A_DL = "DL";
		public static final String DATAELEMENT = "DataElement";

		//defect 460
		public static final String HLD_LOCATION_STATUS_CODES = "<CommonCode CodeType=\"HLD_LOCATION_STATUS\"/>";

		public static final String isService = "N";
		public static final String API_GET_USER_LIST_VALIDATE_STOREUSER_TEMPLATE = "global/template/api/getUserListTemplate_StoreUserValidation.xml";
		public static final String HTTP_API_USER="tkmaz96";
		public static final String HTTP_API_PWD="a$$UNIQUE_PASSWORD";
		// single sign on constants
		public static final String JWT_PARAMETER = "Jwt";
		public static final String JWT_VERIFIED_PARAMETER = "Verified";
		public static final String JWT_VERSION = "ver";
		public static final String JWT_AUDIENCE = "aud";
		public static final String JWT_ISSUER = "iss";
		public static final String JWT_EXPIRATION = "exp";
		public static final String STORE_ID_PARAMETER = "StoreId";
		public static final String SSO_POS = "POS";
		public static final String SSO_KEYID_MOBILE = "SSO_KEYID_MOBILE";
		public static final String SSO_KEYID_POS = "SSO_KEYID_POS";
		public static final String SSO_JWT_VERSION = "SSO_JWT_VERSION";
		public static final String SSO_ISSUER_MOBILE = "SSO_ISSUER_MOBILE";
		public static final String SSO_ISSUER_POS = "SSO_ISSUER_POS";
		public static final String SSO_AUDIENCE_MOBILE = "SSO_AUDIENCE_MOBILE";
		public static final String SSO_AUDIENCE_POS = "SSO_AUDIENCE_POS";
		public static final String SSO_PUB_KEY_PATH = "SSO_PUB_KEY_PATH";
		public static final String SSO_KEY_FILE_SUFFIX = ".dpkpublic";
		public static final String MODULUS = "Modulus";
		public static final String EXPONENT = "Exponent";
		// redirect constants
		public static final String LOAD_BALANCER_A = "LoadBalancerA";
		public static final String LOAD_BALANCER_B = "LoadBalancerB";

		public static final String EXTN_INVALID_ORDER_NUMBER = "The Order number provided in the input is invalid.";
     		public static final String EXTN_INVALID_ORDER_NUMBER_CODE = "KOHLS-VPS-008";
     		public static final String JWT = "JWT";
     		public static final String PERCENTAGE_VAL = "PercentageValue";

     	// LDAP Prod Fix - R23.1
        public static final String AUTHENTICATE_PROPERTY_FILE_PATH = "yfs.authenticate.properties.path";
        public static final String WSUSERS_PROPERTY = "yfs.ws.users";

        //Added for Return service integration begin
        
        public static final String TRN_CENTENARY = "20";
      	 public static final String DATE_SPLIT = "-";
      	 public static final String DAY_START_TIME = " 00:00:00";
      	 public static final String GRAVITY_IN_REQ = "gravityInReq";
      	 public static final String EMPTY_SPACE = " "; 
      	 public static final String COLON = ":";	
      	 public static final String STRELING_SERVICES = "SterlingServices";
      	 public static final String PORT_NAME = "17302";
      	 public static final String END_POINT_URL = "endPointURL";
      	 public static final String TIME_OUT = "timeOut";
      	 public static final String TIME_OUT_PACKAGE = "com.sun.xml.ws.request.timeout";
      	 
      	 public static final String EXTN_CONNECT= "EXTN_CONNECT";
      	 public static final String EXTN_IO ="EXTN_IO";
      	 public static final String SOAP_EXCEPTION="SOAP_EXCEPTION";
      	 public static final String WEB_SERVICE_EXCEPTION="WEB_SERVICE_EXCEPTION";
      	 public static final String EXTN_OTHER="EXTN_OTHER";
      	 public static final String DEFAULT_READ_TIMEOOUT_PACKAGE= "sun.net.client.defaultReadTimeout";
      	 public static final String CODE = "code";
      	 public static final String MESSAGE ="message";
      	 public static final String MESSAGE_FACTORY_PACKAGE = "javax.xml.soap.MessageFactory";
      	 public static final String MESSAGE_FACTORY_IMPL_PACKAGE = "weblogic.xml.saaj.MessageFactoryImpl";
      	 public static final String PATH_SOAP_ENVELOPE = "http://schemas.xmlsoap.org/soap/envelope/";
      	 public static final String MESSAGE_SOAP_FAULT = "Encountered SOAP Fault ";
      	 public static final String MESSAGE_CALLING_END_POINT = " while calling endpoint";
      	 
      	 public static final String WEBSERVICE_CALL_RS = "WebserviceCallToRS";
      	 public static final String Name_SPACE_REMOVER = "KohlsReturnServiceNameSpaceRemover";
      	 public static final String KOHLS_RESPONSE_ORDER_FORMAT = "KohlsParseRSReponseToOrderFormat";
      	 public static final String CHEKCK_MERGE_RS_RESPONSE = "CheckAndMergeRSResponse";
      	 public static final String REGION_AU = "au";
      	 public static final String KOHLS_URL_AU = "http://www.kohls.com/ep/au";
      	 public static final String SOAP_ACTION = "soapAction";
      	 public static final String ACTION = "action";
      	 public static final String GET_OPEN_RETURN = "GetOpenToReturn";
      	 public static final String PATH_GET_ORDER_DETAILS="C:/temp/getOrderDetails.xml";
      	 public static final String PATH_GET_ORDER_DETAILS_RS_RESPONSE = "/global/template/api/getOrderDetailsWithRSResponse.xml";
           
   	   	 public static final int SCANNED_RECIEPT_LENGTH_26 = 26;
   	   	 public static final int SCANNED_RECIEPT_LENGTH_17 = 17;
   	   	 
   	   	 public static final int INDEX_0 = 0;
   	   	 public static final int INDEX_2 = 2;
   	   	 public static final int INDEX_4 = 4;
   	   	 public static final int INDEX_6 = 6;
   	   	 public static final int INDEX_8 = 8;
   	   	 public static final int INDEX_10 = 10;
   	   	 public static final int INDEX_12 = 12;
   	   	 public static final int INDEX_13 = 13;	 
   	   	 public static final int INDEX_16 = 16;
   	   	 public static final int INDEX_17 = 17;
   	   	 public static final int INDEX_18 = 18;
   	   	 public static final int INDEX_22 = 22;
   	   	 //Added for Return service integration end
		 
		 //Added For PSA tendering - START.
		public static final String PSA="PSA";
		public static final String PAYMENT_TYPE_CASH="CASH";
		public static final String PAYMENT_TYPE_CHECK="CHECK";
		public static final String PAYMENT_TYPE_VENDOR_CHECK="VENDOR_CHECK";
		public static final String PAYMENT_TYPE_PREPAID_CREDIT_CARD="PREPAID_CREDIT_CARD";
		public static final String PAYMENT_TYPE_TRAVELERS_CHECK="TRAVELERS_CHECK";
		public static final String PAYMENTTYPE_DEBIT_CARD = "DEBIT_CARD";
		public static final String PAYMENTTYPE_CREDIT_CARD = "CREDIT_CARD";
		public static final String PAYMENT_TYPE_KOHLS_CHARGE="KOHLS_CHARGE_CARD";
		public static final String PAYMENT_TYPE_CORPORATE_REFUND="CORPORATE_REFUND";
		public static final String PAYMENT_METHOD_CASH="PaymentMethod[@RefundTenderType='CASH']";
		public static final String COMMON_CODE_KMC_RETURNTENDER_LIMIT="KMCReturnTenderLimit";
		public static final String PRE_AUTH="PreAuth";
		public static final String PRE_AUTH_COMPLETE="PreAuthComplete";
		public static final String DEACTIVATE="Deactivate";
		public static final String PRE_AUTH_VOID="PreAuthVoid";
		public static final String INQUIRY="Inquiry";
		public static final String ACTIVATION="Activation";
		public static final String ACTIVATION_REVERSAL="ActivationReversal";
		public static final String TERMINAL_ID="TerminalId";
		public static final String ACCOUNT="Account";
		public static final String POS_SEQUENCE_NO="PosSequenceNo";
		public static final String BARCODE="BARCODE";
		//Added For PSA tendering - END.
			
		// Added For KohlsCash Deactivation - START
		public static final String PSA_GET_ORDER_LIST="PSAgetOrderList";
		public static final String KOHLS_RETAIL = "KOHLS-RETAIL";
		public static final String KOHLS_CASH_DEACTIVATION_WEB_SERVICE = "KohlsPOCKohlsCashDeactivationWebService";
		public static final String KOHLS_CASH_ACTIVE_RKC_WEB_SERVICE ="KohlsPOCGetAtiveRKCEvent";
		// Added For KohlsCash Deactivation - END
		
		//Added For POC Returns - START
		public static final String KMC_RETURN_TENDER_LIMIT_RULEID="POST_SALE_ADJUSTMENT_KMC_REFUND_LIMIT";
		public static final String API_GET_RULE_LIST_FOR_POS="getRuleListForPOS";
		//Added For POC Returns - END
		
		//Added For PSA CreditCards - START
		public static final String PSA_VISA="VISA";
		public static final String PSA_MASTERCARD = "MASTERCARD";
		public static final String PSA_DISCOVER = "DISCOVER";
		public static final String PSA_AMEX = "AMEX";
		public static final String VISA_05="05";
		public static final String MASTERCARD_06 = "06";
		public static final String DISCOVER_07 = "07";
		public static final String AMEX_08 = "08";
		//Added For PSA CreditCards - END
		
		
		//Added For Return CreditCards - START
		public static final String POC_VISA="VISA";
		public static final String POC_MASTERCARD = "MASTERCARD";
		public static final String POC_DISCOVER = "DISCOVER";
		public static final String POC_AMEX = "AMEX";
		//Added For KMC Deactivation - START
		public static final String PSA_DRIVERS_LICENSE_NUM="41444A5553544d454E54";
		//Added For KMC Deactivation - END
		
		//Added For Extn Attributes-START
		public static final String A_EXTN_RETURN_PRICE = "ExtnReturnPrice";
		public static final String A_EXTN_TAXABLE_AMOUNT = "ExtnTaxableAmount";
		//Added For Extn Attributes-END
		
		 //Updating the OMSe code for OmniBag
		 public static final int HOURS_24 = 24;
		    public static final int NUMBER_60 = 60;
		    public static final int NUMBER_240 = 240;
		    public static final char HYPHEN = '-';
		    public static final int NUMBER_1 = 1;
		    public static final int NUMBER_10 = 10;
		    public static final int NUMBER_2 = 2;
		    public static final int NUMBER_3 = 3;
		    public static final int NUMBER_6 = 6;
		    public static final int NUMBER_5 = 5;
		    public static final int NUMBER_0 = 0;
		    public static final int NUMBER_9 = 9;
		    public static final int NUMBER_24 = 24;
		    public static final int NUMBER_22 = 22;
		    public static final int NUMBER_20 = 20;
		    public static final int NUMBER_90 = 90;
		    public static final String EXTN_GENERIC_ERROR_MESSAGE = "Generic Exception Occurred. Please contact your System Administrator";
		    public static final String SORT_ENABLED = "SORT_ENABLED";
			public static final String ENBL_RED_PCK = "ENBL_RED_PCK";
			public static final String PUT_ATG_DESC_ON_LINE = "PUT_ATG_DESC_ON_LINE";
			public static final String ERROR_DESC_PRB_ADDING_BUFFER_TIME = "Problem adding buffer time, defaulting to 60 minutes";	
			public static final String ITEM_TYPE_DS = "DS";
			public static final String DARK_MODE_STAT = "DARK_MODE_STATUS";
			public static final String SDD_CUTOFF = "SDD_CUTOFF";
			public static final int NUMBER_11 = 11;
			public static final int NUMBER_13 = 13;
			public static final int NUMBER_16 = 16;
			public static final String SHIFT_HOURS_OUTPUT = "strLastShiftEndTime ";
			public static final String STORE_HOURS_ORGANIZATION_TEMPLATE = "global/template/api/getOrganizationListStoreKeys.xml";
			public static final String GET_STORE_INFO_FROM_GIV_SERVICE = "KohlsGetStoreInfoFromGIV";
			public static final String GIV_DEFAULT_USER_ID = "simUser";
			public static final String TIME_ZONE_COMPARE_FORMAT = "yyyy-MM-dd HH:mm:ss";
			public static final String CODE_TYPE_FULFILLMENT_TIME = "FULFILLMENT_TIME";
			public static final String STORE_HOURS_CACHE = "StoreHoursCache";
			public static final String INT_KC_UPDATE_FAILURE_Q = "INT_KC_UPDATE_FAILURE_Q";
		    public static final String SERVICE_KC_WEBSERVICE_FOR_VOID_AND_REDEEM = "KohlsCashWebserviceForVoidAndRedemption";
		    public static final String KC_UPDATE_EXCEPTION_TYPE = "KC_UPDATE_EXCEPTION_TYPE";
		    public static final String TIME_ZONE_UTC = "UTC";
		    public static final String A_BATCH_METHOD = "BatchMethod";
		    	public static final String CNST_TRAILER_MANIFEST = "TRAILER_MANIFEST";
	public static final String ENTERPRISE_KOHLS_OUTLET = "KOHLS-OUTLET";
	public static final String IS_RKC_CALL_COMPLETE = "IS_RKC_CALL_COMPLETE";
			public static final Double ZERO_DOUBLE = 0.0;
			public static final String METHOD_GET_REVR_AUTH_STATUS = ".getReverseAuthStatus";
			public static final String PROG_ID_API_TESTER = "SterlingHttpTester";
			public static final String EXTN_APA_GENERIC_ERROR_CODE = "KOHLS-APA-ERR-002";
			public static final String EXTN_APA_GENERIC_ERROR_MESSAGE = "Generic Exception Occurred. Please contact your System Administrator";
			public static final String RESP_CODE_ASSIGN_USER_FAILURE = "KOHLS-APA-002";
			public static final String RESP_MSG_ASSIGN_USER_FAILURE = "Assignment failed";
			public static final String RKC_AUTO_RETURNS_SERVICE = "KohlsRKCRestAPIAutoReturns";
			public static final String RKC_NOTE_TEXT = "New RKC Issued. RKC Coupon ID: %s. Coupon Amount: %s.";
			public static final String PROCESS_RKC_HOLD = "PROCESS_RKC_HOLD";
			
			public static final String ERROR = "ERROR";
			public static final String PAYMENT_ERROR_STRING_PREFIX = "Input doc to alert service:";
			public static final String ALERT_LEVEL_INFO = "Info";
			public static final String KOHLS_RAISE_ALERT_ON_FIRST_FAILURE = "KohlsRaiseAlertOnFirstFailure";
			public static final String A_EXTN_IS_OMNI = "ExtnIsOmni";
			public static final String V_CARRY = "CARRY";
			public static final String KOHLS_RETAIL_PREFIX = "11";
	      //Updating the OMSe code for OmniBag
	      public static final String BO_CSC_EXPIRY_TIME_CODE_TYPE = "BO_CSC_EXPIRY_TIME";
	      public static final String LDAP_TIMEOUT_PROPERTY = "com.sun.jndi.ldap.read.timeout";
	      public static final String LDAP_TIMEOUT_VALUE = "5000";
	      //CAPE-1977
	      public static final String EXTN_PA_NOT_ALLOWED="EXTN_PA_NOT_ALLOWED";
	      public static final String SELECT_METHOD = "SelectMethod";
	      
	      public static final String EXTN_DL_FOR_SYS = "ExtnDLForSys";
	      public static final String EXTN_DL_NUMBER_FORMAT = "ExtnDLNumberFormat";
	}
