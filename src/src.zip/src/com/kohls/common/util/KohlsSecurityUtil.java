package com.kohls.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.custom.util.xml.XMLUtil;
import com.kohls.poc.constant.KohlsPOCConstant;
import com.sterlingcommerce.baseutil.SCXmlUtil;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.dom.YFCElement;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfc.log.YFCLogUtil;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.core.YFSSystem;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/******************************************************************************************
 * File Name : KohlsSecurityUtil.java
 * 
 * Description : This Class used to Encrypt or decrypt PII data i.e
 * FirstName,LastName,emailId,ZipCode. This Class used to remove PII
 * Atributes(FirstName,LastName,EmailId,Zipcode) from Input Xml This class used
 * to modify invoice XML. Modification Log : Ver # Date Author Modification-
 * 0.03 # 03-09-2015 IBM updated Version
 * ----------------------------------------------------------------------------
 *****************************************************************************************/

public class KohlsSecurityUtil {
	/** LOG variable for logging. */
	private static final YFCLogCategory LOG = YFCLogCategory
			.instance(KohlsSecurityUtil.class.getName());
	/**
	 * properties reference to read configured arguments.
	 */
	private List<String> lstelezipcode = new ArrayList<>();

	/**
	 * properties reference to read configured arguments.
	 */
	private List<String> protegrityElementsList = new ArrayList<>();

	/**
	 * properties reference to read configured arguments.
	 */
	private List<String> clearElementList = new ArrayList<>();

	/**
	 * properties reference to read configured arguments.
	 */
	private Properties props = null;

	/**
	 * securtiyPlatform .
	 */
	private KohlsInvokeDataSecurityPlatform securityPlatform = null;

	/** The highest depth. */
	private int highestDepth = 0;

	/** The is empty element. */
	private boolean isEmptyElement = false;

	static {

		try {
			//Refactoring the condition for Sonarqube - ILLUMT-2905
			if ((YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST) != null)
					&& (YFSSystem.getProperty(KohlsConstant.POLICY_USER) != null)
					&& (YFSSystem.getProperty(KohlsConstant.DATA_ELEMENT) != null)
					&& checkRequiredSizeParameters()) {
				final KohlsProtegrityConnectionPool protegrityConnectionPool = KohlsProtegrityConnectionPool
						.getInstance();
				protegrityConnectionPool.setUrl(YFSSystem
						.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST));
				protegrityConnectionPool.setUser(YFSSystem
						.getProperty(KohlsConstant.POLICY_USER));
				protegrityConnectionPool.setDataElement(YFSSystem
						.getProperty(KohlsConstant.DATA_ELEMENT));
				protegrityConnectionPool.initialize(Integer.parseInt(YFSSystem
						.getProperty(KohlsConstant.QUEUE_MAX_SIZE)), Integer
						.parseInt(YFSSystem
								.getProperty(KohlsConstant.QUEUE_MAX_SIZE)));
			}
		} catch (Exception e) {
			LOG.error("Mandatory protegrity connection parameters missing" + e);
		}
	}

	private static Boolean checkRequiredSizeParameters() {
		Boolean flag = false;
		if ((YFSSystem.getProperty(KohlsConstant.QUEUE_MAX_SIZE) != null)
				&& (YFSSystem.getProperty(KohlsConstant.QUEUE_MIN_SIZE) != null)) {
			flag = true;
		}
		return flag;
	}

	/**
	 * @param env
	 *            env
	 * @param inXML
	 *            inXML
	 * @return inXML this method calls getElementListFromCommonCode() to get
	 *         list of elements then removes firstName,LastName, EmailID,
	 *         ZipCode if list of elements doesn't contain
	 *         ShipTo,ToAddess,PersonInfoShipTo else removes firstName,LastName,
	 *         EmailID
	 *//*
	public Document removePIIData(YFSEnvironment env, Document inXML) {
		if (YFCLogUtil.isDebugEnabled()) {
			LOG.beginTimer("removePIIData Method Input XML : "
					+ SCXmlUtil.getString(inXML));
		}
		try {
			Element rootElement = inXML.getDocumentElement();
			lstelezipcode = getElementListFromCommonCode(env,
					KohlsConstant.PREVENT_ZIPCODE_ELEMENTS);
			searchAndRemoveInElementLevel(rootElement);
			parseAllElements(env, rootElement);
		} catch (Exception e) {
			LOG.error("----------Exception in removePIIData()---------------"
					+ e);
		}
		return inXML;
	}*/

	/**
	 * @param env
	 *            env
	 * @param element
	 *            element
	 */
	public void parseAllElements(YFSEnvironment env, Element element) {
		if (YFCLogUtil.isDebugEnabled()) {
			LOG.beginTimer("KohlsSecurity :: parseAllElements() --->Start");
		}
		try {
			List<Element> elementList = SCXmlUtil.getChildrenList(element);
			for (Element elementObj : elementList) {
				searchAndRemoveInElementLevel(elementObj);
				if (elementObj.getNodeType() == Node.ELEMENT_NODE) {
					parseAllElements(env, elementObj);
				}
			}
		} catch (Exception e) {
			LOG.error("----------Exception in parseAllElements()---------------"
					+ e);
		}
	}

	/**
	 * @param element
	 *            element this method checks element name and checks list of
	 *            element from commomn code removes firstName,LastName, EmailID,
	 *            ZipCode if list of elements doesn't contain
	 *            ShipTo,ToAddess,PersonInfoShipTo else removes
	 *            firstName,LastName, EmailID
	 */
	public void searchAndRemoveInElementLevel(Element element) {
		LOG.beginTimer("KohlsSecurity :: searchAndRemoveInElementLevel() --->Start");
		try {
			Node childNode;
			NamedNodeMap attributesMap = element.getAttributes();
			String elementName = element.getNodeName();
			// get the list from common code where type "NotToRemoveZipCode" and
			// give value = element name
			// get the o/p doc of commoncode list
			int i = 0;
			//Refactoring the code for Sonarqube - ILLUMT-2905-Changed to while loop instead of for
			while (i < attributesMap.getLength()) {
				childNode = attributesMap.item(i);
				String strchildNode = childNode.getNodeName().toLowerCase();
				if (strchildNode.contains(KohlsConstant.FIRST_NAME)
						|| strchildNode.contains(KohlsConstant.EMAILID)
						|| childNode.getNodeName().toLowerCase()
								.contains(KohlsConstant.LAST_NAME)) {
					element.removeAttribute(childNode.getNodeName());
					i--;
				} else if (strchildNode.contains(KohlsConstant.ZIPCODE)) {
					if (!lstelezipcode.contains(elementName)) {
						element.removeAttribute(childNode.getNodeName());
						i--;
					}
				}
				++i;
			}
		} catch (Exception e) {
			LOG.error("----------Exception in searchAndRemoveInElementLevel()---------------"
					+ e);
		}
		LOG.endTimer("KohlsSecurity :: searchAndRemoveInElementLevel() --->End");

	}

	/**
	 * @return uuidStr This method will return unique id for messageId.
	 */
	public static String generateUuid() {
		//Refactoring the code for Sonarqube - ILLUMT-2905
		return UUID.randomUUID().toString();
	}

	/**
	 * This method will return o/p of getCommonCodeList where
	 * codeType="Zipcode_Elements".
	 * 
	 * @param env
	 *            env.
	 * @param codeType
	 *            codeType.
	 * @return List<String>
	 * 
	 */

	public List<String> getElementListFromCommonCode(YFSEnvironment env,
			String codeType) {
		List<String> preventZipCodeEle = new ArrayList<>();
		try {
			Document getCommonCodeInputXml = KohlsXMLUtil
					.createDocument(KohlsXMLLiterals.E_COMMON_CODE);
			Element commonCodeElement = getCommonCodeInputXml
					.getDocumentElement();
			commonCodeElement.setAttribute(
					KohlsXMLLiterals.A_ORGANIZATION_CODE,
					KohlsConstant.ITEM_ORGANIZATION_CODE);
			commonCodeElement.setAttribute(KohlsXMLLiterals.A_CODE_TYPE,
					codeType);

			Document getCommonCodeList = KohlsCommonUtil.invokeAPI(env,
					KohlsConstant.API_GET_COMMON_CODE_LIST,
					getCommonCodeInputXml);
			NodeList eleNodeList = getCommonCodeList
					.getElementsByTagName(KohlsXMLLiterals.E_COMMON_CODE);

			for (int i = 0; i < eleNodeList.getLength(); i++) {
				Element eleCommonCode = (Element) eleNodeList.item(i);
				String strCodeValue = eleCommonCode
						.getAttribute(KohlsXMLLiterals.A_CODE_VALUE);
				preventZipCodeEle.add(strCodeValue);
			}

		} catch (Exception e) {
			LOG.error("----------Exception in getElementListFromCommonCode()---------------"
					+ e);
		}
		return preventZipCodeEle;
	}

	/**
	 * This method will remove FirstName,LastName in billTo and shipTo Elements
	 * and Zipcode attribute from BillTo element. it will set ExtnPIIVersion=1.1
	 * in Extn element level.
	 * 
	 * @param inputXML
	 *            XML
	 * @return InXml xml
	 * 
	 */
	public static Document modifyInvoiceXml(Document inputXML) {
		if (YFCLogUtil.isDebugEnabled()) {
			LOG.beginTimer("KohlsSecurityUtil :: modifyInvoiceXml() --->Start"
					+ SCXmlUtil.getString(inputXML));
		}

		try {
			Element rootElement = inputXML.getDocumentElement();
			NodeList nodeBillToList = rootElement
					.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO);
			for (int i = 0; i < nodeBillToList.getLength(); i++) {
				Element billToElement = (Element) nodeBillToList.item(i);
				billToElement.removeAttribute(KohlsXMLLiterals.A_LAST_NAME);
				billToElement.removeAttribute(KohlsXMLLiterals.A_FIRST_NAME);
				billToElement.removeAttribute(KohlsXMLLiterals.A_ZIP_CODE);
			}
			NodeList nodeShipToList = rootElement
					.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_SHIP_TO);
			for (int i = 0; i < nodeShipToList.getLength(); i++) {
				Element shipToElement = (Element) nodeShipToList.item(i);
				shipToElement.removeAttribute(KohlsXMLLiterals.A_LAST_NAME);
				shipToElement.removeAttribute(KohlsXMLLiterals.A_FIRST_NAME);
			}
			NodeList billToNodeList = rootElement
					.getElementsByTagName(KohlsXMLLiterals.E_BILL_TO);
			for (int i = 0; i < billToNodeList.getLength(); i++) {
				Element billToElement = (Element) billToNodeList.item(i);
				billToElement.removeAttribute(KohlsXMLLiterals.A_LAST_NAME);
				billToElement.removeAttribute(KohlsXMLLiterals.A_FIRST_NAME);
				billToElement.removeAttribute(KohlsXMLLiterals.A_ZIP_CODE);
			}
			NodeList shipToNodeList = rootElement
					.getElementsByTagName(KohlsXMLLiterals.E_SHIP_TO);
			for (int i = 0; i < shipToNodeList.getLength(); i++) {
				Element shipToElement = (Element) shipToNodeList.item(i);
				shipToElement.removeAttribute(KohlsXMLLiterals.A_LAST_NAME);
				shipToElement.removeAttribute(KohlsXMLLiterals.A_FIRST_NAME);
			}
			if (rootElement.getNodeName().equalsIgnoreCase(
					KohlsXMLLiterals.E_INVOICE_DETAIL)) {
				Element extnElement = (Element) KohlsXPathUtil.getNode(
						rootElement, KohlsConstant.EXTN_ELEMENT_PATH);
				if (extnElement == null) {
					Element extnElementObj = inputXML
							.createElement(KohlsXMLLiterals.E_EXTN);
					extnElementObj.setAttribute(
							KohlsXMLLiterals.A_EXTN_PIIVERSION,
							KohlsXMLLiterals.A_EXTN_PIIVERSION_VAL);
					Element invoiceHeader = (Element) rootElement
							.getElementsByTagName(
									KohlsXMLLiterals.E_INVOICE_HEADER).item(0);
					invoiceHeader.appendChild(extnElementObj);
				} else {
					extnElement.setAttribute(
							KohlsXMLLiterals.A_EXTN_PIIVERSION,
							KohlsXMLLiterals.A_EXTN_PIIVERSION_VAL);
				}
			} else if (rootElement.getNodeName().equalsIgnoreCase(
					KohlsXMLLiterals.E_SHIPMENT_ADVICES)) {
				Element extnElement = inputXML
						.createElement(KohlsXMLLiterals.E_EXTN);
				extnElement.setAttribute(KohlsXMLLiterals.A_EXTN_PIIVERSION,
						KohlsXMLLiterals.A_EXTN_PIIVERSION_VAL);
				Element shipmentAdvice = (Element) rootElement
						.getElementsByTagName(
								KohlsXMLLiterals.E_SHIPMENT_ADVICE).item(0);
				shipmentAdvice.appendChild(extnElement);
			}
			if (YFCLogUtil.isDebugEnabled()) {
				LOG.endTimer("KohlsSecurityUtil :: modifyInvoiceXml-->End"
						+ SCXmlUtil.getString(inputXML));
			}

		} catch (Exception e) {
			LOG.error("----------Exception in removePIIData()---------------");
			if (YFCLogUtil.isDebugEnabled()) {
				LOG.error(e);
			}

		}
		return inputXML;
	}

	/**
	 * This method will read sHostXC,dataElement and policyUser from customer
	 * override properties file. This method will read PROTEGRITY_TYPE from
	 * configuration arguments. find FirstName,LastName, EmailId and ZipCode in
	 * XML and replace attribute value with encrypted or decrypted.Except For
	 * zipcode in PersonInfoShipTo element level is clear text. value based on
	 * protegrityType
	 * 
	 * @param env
	 *            env
	 * @param inXml
	 *            inXml
	 * @return Document
	 * 
	 */
	public Document encryptDecryptXML(YFSEnvironment env, Document inXml) {
		String dataElement = props.getProperty("DATA_ELEMENT");
		String queueMinSize = props.getProperty("QUEUE_MIN_SIZE");
		String queueMaxSize = props.getProperty("QUEUE_MAX_SIZE");
		
		try {
			//Refactoring the condition for Sonarqube - ILLUMT-2905
			if ((YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST_OMSe) != null) && (YFSSystem.getProperty(KohlsPOCConstant.POLICY_USER_OMSe) != null)
					&& !YFCCommon.isVoid(dataElement) && !YFCCommon.isVoid(queueMaxSize) && !YFCCommon.isVoid(queueMinSize)) {
				final KohlsProtegrityConnectionPool protegrityConnectionPool = KohlsProtegrityConnectionPool.getInstance();
				protegrityConnectionPool.setUrl(YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST_OMSe));
				protegrityConnectionPool.setUser(YFSSystem.getProperty(KohlsPOCConstant.POLICY_USER_OMSe));
				protegrityConnectionPool.setDataElement(dataElement);
				protegrityConnectionPool.initialize(Integer.parseInt(queueMaxSize), Integer.parseInt(queueMaxSize));
			}
		} catch (Exception e) {
			LOG.error("Mandatory protegrity connection parameters missing" + e);
		}
		
		if (YFCLogUtil.isDebugEnabled()) {
			LOG.beginTimer("encryptDecryptXML Method Input XML : "+ SCXmlUtil.getString(inXml));
		}

		KohlsInvokeDataSecurityPlatform securtiyPlatform = null;
		Node childNode = null;
		String nodeValue = null;
		String waitTime = null;
		Map<String, String> attributesDataMap = new HashMap<>();
		
		if (props.getProperty(KohlsConstant.WAIT_TIME).equals(KohlsConstant.WAIT_TIME)) {
			waitTime = KohlsConstant.WAIT_TIME_VALUE;
		} else {
			waitTime = props.getProperty(KohlsConstant.WAIT_TIME);
		}
		try {
			waitTime = "1000";
			String conversionType = this.getPropertyValue(this.props.getProperty(KohlsConstant.PROTEGRITY_TYPE));
			/*
			 * Updated As Defect D1522 (PII Encryption issue) Fix for
			 * ZIPCODE_ELEMENTSLIST to PREVENT_ZIPCODE_ELEMENTS
			 */
			clearElementList = getElementListFromCommonCode(env, KohlsConstant.PREVENT_ZIPCODE_ELEMENTS);
			protegrityElementsList = getElementListFromCommonCode(env, KohlsConstant.SECURITY_ATTRIBUTES);
			securtiyPlatform = KohlsProtegrityConnectionPool.getInstance().tryGet(Long.parseLong(waitTime));
			NodeList entries = inXml.getElementsByTagName("*");
			
			for (int val = 0; val < entries.getLength(); val++) {
				Element element = (Element) entries.item(val);
				NamedNodeMap attributesMap = element.getAttributes();
				for (int i = 0; i < attributesMap.getLength(); ++i) {
					childNode = attributesMap.item(i);
					String nodeName = childNode.getNodeName().toLowerCase();
					for (String attributName : protegrityElementsList) {
						if (nodeName.contains(attributName)) {
							if (nodeName.contains(KohlsConstant.ZIPCODE)) {
								if (!clearElementList.contains(element.getNodeName())) {
									nodeValue = childNode.getNodeValue().trim();
									if (!nodeValue.isEmpty()) {
										if (attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()) == null) {
											if (YFCLogUtil.isDebugEnabled()) {
												LOG.debug("childNode.getNodeName()+childNode.getNodeValue()......."+ childNode.getNodeName()+ childNode.getNodeValue());
											}
											if (conversionType.equalsIgnoreCase(KohlsConstant.ENCRYPTION)) {
												String encryptedVal = securtiyPlatform.returnEncryptedValue(childNode.getNodeValue());
												attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),encryptedVal);
											} else if (conversionType
													.equalsIgnoreCase(KohlsConstant.DECRYPTION)) {
												String decryptedVal = securtiyPlatform.returnDecryptedValue(childNode.getNodeValue());
												attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),decryptedVal);
											}
										}
										if (YFCLogUtil.isDebugEnabled()) {
											LOG.debug("KohlsProcessMessageForSecurity :: searchAndReplaceInElementLevel() --->NodeValue"+ attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
										}
										childNode.setNodeValue(attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
									}
								}
							} else {
								nodeValue = childNode.getNodeValue().trim();
								if (!nodeValue.isEmpty()) {
									if (attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()) == null) {
										if (YFCLogUtil.isDebugEnabled()) {
											LOG.debug("childNode.getNodeName()+childNode.getNodeValue()......."+ childNode.getNodeName()+ childNode.getNodeValue());
										}
										if (conversionType.equalsIgnoreCase(KohlsConstant.ENCRYPTION)) {
											String encryptedVal = securtiyPlatform.returnEncryptedValue(childNode.getNodeValue());
											attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),encryptedVal);

										} else if (conversionType.equalsIgnoreCase(KohlsConstant.DECRYPTION)) {
											String decryptedVal = securtiyPlatform.returnDecryptedValue(childNode.getNodeValue());
											attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),decryptedVal);
										}
									}
									if (YFCLogUtil.isDebugEnabled()) {
										LOG.debug("KohlsProcessMessageForSecurity :: searchAndReplaceInElementLevel() --->NodeValue"+ attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
									}
									childNode.setNodeValue(attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Error in encryptDecryptXML method......" + e);
			throw new YFSException("Encrypt Decrypt Exception" + e.getMessage());
		} finally {
			if (securtiyPlatform != null) {
				try {
					KohlsProtegrityConnectionPool.getInstance().returnResource(securtiyPlatform);
				} catch (Exception e) {
					LOG.error(" Error while returning the resource object.."+ e);
				}
			}
		}

		if (YFCLogUtil.isDebugEnabled()) {
			LOG.endTimer("encryptDecryptXML :: parseAllElements() --->End"+ SCXmlUtil.getString(inXml));
		}
		return inXml;
	}

	/**
	 * Encrytpt and remove redundant attr from xml.
	 * 
	 * @param env
	 *            the env
	 * @param inDoc
	 *            the in doc
	 * @return the document
	 */
	public Document encrytptAndRemoveRedundantAttrFromXML(YFSEnvironment env, Document inDoc) {
		
		try {
			//Refactoring the condition for Sonarqube - ILLUMT-2905
			if ((YFSSystem.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST) != null)
					&& (YFSSystem.getProperty(KohlsConstant.POLICY_USER) != null)
					&& (YFSSystem.getProperty(KohlsConstant.DATA_ELEMENT) != null)
					&& checkRequiredSizeParameters()) {
				final KohlsProtegrityConnectionPool protegrityConnectionPool = KohlsProtegrityConnectionPool
						.getInstance();
				protegrityConnectionPool.setUrl(YFSSystem
						.getProperty(KohlsPOCConstant.PROTEGRITY_SERVER_HOST));
				protegrityConnectionPool.setUser(YFSSystem
						.getProperty(KohlsConstant.POLICY_USER));
				protegrityConnectionPool.setDataElement(YFSSystem
						.getProperty(KohlsConstant.DATA_ELEMENT));
				protegrityConnectionPool.initialize(Integer.parseInt(YFSSystem
						.getProperty(KohlsConstant.QUEUE_MAX_SIZE)), Integer
						.parseInt(YFSSystem
								.getProperty(KohlsConstant.QUEUE_MAX_SIZE)));
			}
		} catch (Exception e) {
			LOG.error("Mandatory protegrity connection parameters missing" + e);
		}
		/*KohlsLoggerUtil.debug(LOG,"encrytptAndRemoveRedundantAttrFromXML Method Input XML : ",inDoc);*/
		Document inXml = null;
		KohlsInvokeDataSecurityPlatform securtiyPlatform = null;
		Node childNode = null;
		String nodeValue = null;
		String waitTime = null;
		Map<String, String> attributesDataMap = new HashMap<>();
		//Map<String, String> mapMandatoryAttr = new HashMap<>();
		//String strMandatoryAttribute = props.getProperty(KohlsConstants.NON_REMOVE_ATTR);
		//String[] arrMandatoryAttribute = strMandatoryAttribute.split(",");
		if (this.getPropertyValue(KohlsConstant.WAIT_TIME).equals(KohlsConstant.WAIT_TIME)) {
			waitTime = KohlsConstant.WAIT_TIME_VALUE;
		} else {
			waitTime = this.getPropertyValue(KohlsConstant.WAIT_TIME);
		}
		try {
			waitTime = "1000";
			inXml = KohlsXMLUtil.newDocument();
			Node copiedInEle = inXml.importNode(inDoc.getDocumentElement(),true);
			inXml.appendChild(copiedInEle);

			String conversionType = this.getPropertyValue(this.props.getProperty(KohlsConstant.PROTEGRITY_TYPE));
			
			 /** Updated As Defect D1522 (PII Encryption issue) Fix for
			 * ZIPCODE_ELEMENTSLIST to PREVENT_ZIPCODE_ELEMENTS*/
			 
			//clearElementList = getElementListFromCommonCode(env,KohlsConstant.PREVENT_ZIPCODE_ELEMENTS);
			protegrityElementsList = getElementListFromCommonCode(env,KohlsConstant.SECURITY_ATTRIBUTES);
			securtiyPlatform = KohlsProtegrityConnectionPool.getInstance().tryGet(Long.parseLong(waitTime));
			NodeList entries = inXml.getElementsByTagName("*");
			//List<String> nodesToBeDeleted;
			Element element = null;
			NamedNodeMap attributesMap = null;
			String nodeName = "";
			for (int val = 0; val < entries.getLength(); val++) {
				element = (Element) entries.item(val);
				attributesMap = element.getAttributes();
				//nodesToBeDeleted = new ArrayList<>();
				nodeName = "";
				for (int i = 0; i < attributesMap.getLength(); ++i) {
					childNode = attributesMap.item(i);
					nodeName = childNode.getNodeName().toLowerCase();

					if (protegrityElementsList.contains(nodeName)) {
						// which goes here will be encrypted.
						if (nodeName.contains(KohlsConstant.ZIPCODE)) {
							//if (!clearElementList.contains(element.getNodeName())) {
								nodeValue = childNode.getNodeValue().trim();

								if (!nodeValue.isEmpty()) {
									if (attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()) == null) {
										if (YFCLogUtil.isDebugEnabled()) {
											LOG.debug("childNode.getNodeName()_+childNode.getNodeValue()......."+ childNode.getNodeName()+ childNode.getNodeValue());
										}
										if (conversionType.equalsIgnoreCase(KohlsConstant.ENCRYPTION)) {
											String encryptedVal = securtiyPlatform.returnEncryptedValue(childNode.getNodeValue());
											attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),encryptedVal);
										} else if (conversionType.equalsIgnoreCase(KohlsConstant.DECRYPTION)) {
											String decryptedVal = securtiyPlatform.returnDecryptedValue(childNode.getNodeValue());
											attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),decryptedVal);
										}
									}
									if (YFCLogUtil.isDebugEnabled()) {
										LOG.debug("KohlsProcessMessageForSecurity_ :: searchAndReplaceInElementLevel() --->NodeValue"+ attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
									}
									childNode.setNodeValue(attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
								}
							/*} else {
								nodesToBeDeleted.add(childNode.getNodeName());
							}*/
						} else {
							nodeValue = childNode.getNodeValue().trim();

							if (!nodeValue.isEmpty()) {
								if (attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()) == null) {
									if (YFCLogUtil.isDebugEnabled()) {
										LOG.debug("childNode.getNodeName()*+childNode.getNodeValue()......."+ childNode.getNodeName()+ childNode.getNodeValue());
									}
									if (conversionType.equalsIgnoreCase(KohlsConstant.ENCRYPTION)) {
										String encryptedVal = securtiyPlatform.returnEncryptedValue(childNode.getNodeValue());
										attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),encryptedVal);
									} else if (conversionType.equalsIgnoreCase(KohlsConstant.DECRYPTION)) {
										String decryptedVal = securtiyPlatform.returnDecryptedValue(childNode.getNodeValue());
										attributesDataMap.put(childNode.getNodeName()+ childNode.getNodeValue(),decryptedVal);
									}
								}
								if (YFCLogUtil.isDebugEnabled()) {
									LOG.debug("KohlsProcessMessageForSecurity :*: searchAndReplaceInElementLevel() --->NodeValue"+ attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
								}
								childNode.setNodeValue(attributesDataMap.get(childNode.getNodeName()+ childNode.getNodeValue()));
							}
						}
						// end of encryption.
					}/* else {
						nodesToBeDeleted.add(childNode.getNodeName());
					}*/
				}
				
				/*String nodeNameToRemove = "";
				for (int i = attributesMap.getLength() - 1; i >= 0; i--) {
					childNode = attributesMap.item(i);
					nodeNameToRemove = childNode.getNodeName();
					boolean removeAttr = true;
					for (int arrMandSize = 0; arrMandSize < arrMandatoryAttribute.length; arrMandSize++) {
						if (arrMandatoryAttribute[arrMandSize].equalsIgnoreCase(nodeNameToRemove) && !mapMandatoryAttr.containsValue(element.getAttribute(arrMandatoryAttribute[arrMandSize]))) {
							LOG.debug("Setting_Flag_TRUE: "+ arrMandatoryAttribute[arrMandSize]);
							mapMandatoryAttr.put(arrMandatoryAttribute[arrMandSize],element.getAttribute(arrMandatoryAttribute[arrMandSize]));
							removeAttr = false;
						}
					}
					if (nodesToBeDeleted.contains(nodeNameToRemove) && removeAttr) {
						element.removeAttribute(nodeNameToRemove);
					}
				}*/
			}
			/*KohlsLoggerUtil.debug(LOG, "After removing attributes: ", inXml);*/
			//inXml = removeAllEmptyElements(inXml);
			/*KohlsLoggerUtil.debug(LOG, "After removing empty elements: ", inXml);*/
		} catch (Exception e) {
			LOG.error("Error in encryptDecryptXML method......" + e);
			throw KohlsCommonUtil.convertToYFSException(e, "ERROR_ENCRYPTIONS",e.getMessage());
		} finally {
			if (securtiyPlatform != null) {
				try {
					KohlsProtegrityConnectionPool.getInstance().returnResource(securtiyPlatform);
				} catch (Exception e) {
					LOG.error(" Error while returning the resource object.."+ e);
				}
			}
		}
		/*KohlsLoggerUtil.debug(LOG, "Returned xml : ", inXml);*/
		return inXml;
	}

	/**
	 * Removes the all empty elements.
	 * 
	 * @param document
	 *            the document
	 * @return the document
	 */
	public Document removeAllEmptyElements(Document document) {
		highestDepth = 1;
		calculateHighestDepth(document.getChildNodes());
		//Refactoring the code for sonarqube - ILLUMT-2905
		Document documentObj = document;
		for (int i = 0; i < highestDepth; i++) {
			isEmptyElement = false;
			documentObj = removeLastLevelEmptyElement(document);
			if (!isEmptyElement) {
				break;
			}
		}
		return documentObj;
	}

	/**
	 * Calculate highest depth.
	 * 
	 * @param topNodeList
	 *            the top node list
	 */
	private void calculateHighestDepth(NodeList topNodeList) {
		if (topNodeList != null && topNodeList.getLength() > 0) {
			for (int i = 0; i < topNodeList.getLength(); i++) {
				Node n = topNodeList.item(i);
				calculateHighestDepth(n.getChildNodes());
			}
			highestDepth++;
		} else {
			return;
		}
	}

	/**
	 * Removes the last level empty element.
	 * 
	 * @param document
	 *            the document
	 * @return the document
	 */
	public Document removeLastLevelEmptyElement(Document document) {
		NodeList nodeList = document.getElementsByTagName("*");
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			//Refactoring the condition for sonarqube - ILLUMT-2905
			if (node.getNodeType() == Node.ELEMENT_NODE
					&& !hasChildElement(node) && !node.hasAttributes()) {
				Node parentNode = node.getParentNode();
				if (parentNode != null) {
					parentNode.removeChild(node);
					isEmptyElement = true;
				}
			}
		}
		return document;
	}

	/**
	 * Checks for child element.
	 * 
	 * @param node
	 *            the node
	 * @return true, if successful
	 */
	private boolean hasChildElement(Node node) {
		boolean flag = false;
		NodeList nodeList = node.getChildNodes();
		for (int ii = 0; ii < nodeList.getLength(); ii++) {
			Node currentNodex = nodeList.item(ii);
			if (currentNodex.getNodeType() == Node.ELEMENT_NODE) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * @param env
	 *            env
	 * @param inXml
	 *            inXml
	 * @return Document
	 */
	public Document encryptDecryptReturnInvoiceXML(YFSEnvironment env,
			Document inXml) throws Exception {

		if (YFCLogUtil.isDebugEnabled()) {
			LOG.debug("encryptDecryptReturnInvoiceXML Method Input XML : "
					+ SCXmlUtil.getString(inXml));
		}
		try {
			String attribute;
			String attributePart1;
			String attributePart2;
			String[] delimitedSlash;
			String cryptingAttribute;
			String xPath;
			String attributeNo;
			int noOfAttributes = Integer.parseInt(this.props
					.getProperty(KohlsConstant.NO_OF_ATTRIBUTES));
			String sHostXC = this
					.getPropertyValue(KohlsConstant.PROTEGRITY_SERVER_HOST);
			String policyUser = this
					.getPropertyValue(KohlsConstant.POLICY_USER);

			String waitTime = this.getPropertyValue(KohlsConstant.WAIT_TIME);

			// Opening Session to connect to Protegrity server with parameters
			// sHostXC,dataElement and policyUser.
			securityPlatform = KohlsProtegrityConnectionPool.getInstance()
					.tryGet(Long.parseLong(waitTime));

			LOG.debug("The noOfAttributes value is : " + noOfAttributes);

			for (int i = 0; i < noOfAttributes; i++) {

				attributeNo = "Attribute" + (i + 1);

				LOG.debug("The attribute No is : " + attributeNo);
				attributePart1 = this.props.getProperty(attributeNo + "_1");
				attributePart2 = this.props.getProperty(attributeNo + "_2");
				if (attributePart2 == null) {

					attributePart2 = " ";
				}

				LOG.debug("The attribute value is : " + attributePart1);
				LOG.debug("The attribute value is : " + attributePart2);
				attribute = attributePart1.concat(attributePart2).trim();
				delimitedSlash = attribute.split(KohlsConstant.DELIMITED_SLASH);
				xPath = delimitedSlash[2];
				//Refactoring the code for sonarqube - ILLUMT-2905
				cryptingAttribute = delimitedSlash[KohlsConstant.NUMBER_3];
				String dataElement = delimitedSlash[1];

				LOG.debug("The sHostXC value is : " + sHostXC);
				LOG.debug("The dataElement value is : " + dataElement);
				LOG.debug("The policyUser value is : " + policyUser);
				securityPlatform.run(sHostXC, dataElement, policyUser);

				searchAndReplaceByGenericXPath(inXml, cryptingAttribute,
						dataElement, xPath, securityPlatform);
			}
		} catch (Exception ex) {
			// log the exception
			LOG.error(ex);
		} finally {
			if (securityPlatform != null) {
				KohlsProtegrityConnectionPool.getInstance().returnResource(
						securityPlatform);
			}
		}

		if (YFCLogUtil.isDebugEnabled()) {
			LOG.debug("encryptDecryptXML :: parseAllElements() --->End"
					+ SCXmlUtil.getString(inXml));
			LOG.debug("Output XML from KohlsSecurityUtil.encryptDecryptReturnInvoiceXML is: "
					+ XMLUtil.getXMLString(inXml));
			LOG.debug("KohlsSecurityUtil.encryptDecryptReturnInvoiceXML");
		}

		return inXml;

	}

	/**
	 * @param inXml
	 *            xml.
	 * @param cryptingAttribute
	 *            cryptingAttribute
	 * @param dataElement
	 *            dataElement
	 * @param xPath
	 *            path
	 * @param securityPlatform
	 *            securityPlatform
	 */
	public void searchAndReplaceByGenericXPath(Document inXml,
			String cryptingAttribute, String dataElement, String xPath,
			KohlsInvokeDataSecurityPlatform securityPlatform) {
		LOG.beginTimer("KohlsSecurityUtil.searchAndReplaceByGenericXPath");
		String cryptingAttributeValue;
		//Refactoring the code for sonarqube - ILLUMT-2905 - added try, catch
		try {
			NodeList baseElementList = XPathUtil.getNodeList(
					inXml.getDocumentElement(), xPath);
			for (int i = 0; i < baseElementList.getLength(); i++) {
				Element baseElement = (Element) baseElementList.item(i);
				cryptingAttributeValue = baseElement
						.getAttribute(cryptingAttribute);
				if (!(cryptingAttributeValue == null)) {

					if (cryptingAttribute
							.equalsIgnoreCase(KohlsConstant.A_VALUE)) {
						if (baseElement.getAttribute(KohlsConstant.A_NAME)
								.contains(KohlsConstant.A_DL)) {
							baseElement
									.setAttribute(
											cryptingAttribute,
											securityPlatform
													.returnEncryptedValue(cryptingAttributeValue));
							baseElement.setAttribute(cryptingAttribute
									.concat(KohlsConstant.DATAELEMENT),
									dataElement);
						}
					} else {
						String sCryptingAttributeValue = baseElement
								.getAttribute(cryptingAttribute);
						if (!YFCCommon.isVoid(sCryptingAttributeValue)) {
							baseElement
									.setAttribute(
											cryptingAttribute,
											securityPlatform
													.returnEncryptedValue(cryptingAttributeValue));
							baseElement.setAttribute(cryptingAttribute
									.concat(KohlsConstant.DATAELEMENT),
									dataElement);
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("Error in searchAndReplaceByGenericXPath:" + e);

		}
		LOG.endTimer("KohlsPoCSecurityUtil.searchAndReplaceByGenericXPath");
	}

	/**
	 * @param prop
	 *            prop
	 */

	public void setProperties(Properties prop) {
		this.props = prop;
	}

	/**
	 * This function is used to get the value for a property.
	 * 
	 * @param property
	 *            property
	 * @return String propValue
	 */
	public String getPropertyValue(String property) {

		String propValue;
		propValue = YFSSystem.getProperty(property);
		if (YFCCommon.isVoid(propValue)) {
			propValue = property;
		}
		return propValue;

	}

	/**
	 * As part of SR Sprint 7 this function to add 4 new attributes to Release
	 * XML such as
	 * CustomerName,DestinationContactName,BillToName,BillToPostalCode.
	 * 
	 * @param indoc
	 *            indoc.
	 * @return Document indoc.
	 */

	public static Document appendCustomAttributes(Document indoc) {

		Element eleInfoShipToFromWMOSOrderRelease = (Element) indoc
				.getDocumentElement()
				.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_SHIP_TO)
				.item(0);
		eleInfoShipToFromWMOSOrderRelease
				.removeAttribute(KohlsXMLLiterals.A_EMAIL_ID);
		String shipToFirstName = eleInfoShipToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_FIRST_NAME);
		String shipToLastName = eleInfoShipToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_LAST_NAME);
		String customerName = KohlsConstant.BLANK;
		String destinationContactName = KohlsConstant.BLANK;
		if (!YFCCommon.isVoid(shipToLastName)
				&& !YFCCommon.isVoid(shipToFirstName)) {
			shipToFirstName = shipToFirstName.trim();
			shipToLastName = shipToLastName.trim();
			customerName = shipToFirstName + KohlsConstant.BLANK_SPACE
					+ shipToLastName;
			destinationContactName = shipToFirstName
					+ KohlsConstant.BLANK_SPACE + shipToLastName;
		} else if (!YFCCommon.isVoid(shipToLastName)) {
			shipToLastName = shipToLastName.trim();
			customerName = shipToLastName;
			destinationContactName = shipToLastName;
		} else if (!YFCCommon.isVoid(shipToFirstName)) {
			shipToFirstName = shipToFirstName.trim();
			customerName = shipToFirstName;
			destinationContactName = shipToFirstName;
		}
		if (!YFCCommon.isVoid(customerName)) {
			int lenCustName = customerName.length();
			if (lenCustName > KohlsConstant.CUSTOMER_NAME_LENGTH) {
				customerName = customerName.substring(KohlsConstant.V_ZERO,
						KohlsConstant.CUSTOMER_NAME_LENGTH);
			}
		}
		if (!YFCCommon.isVoid(destinationContactName)) {
			int lensdestinationContactName = destinationContactName.length();
			if (lensdestinationContactName > KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH) {
				destinationContactName = destinationContactName.substring(
						KohlsConstant.V_ZERO,
						KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH);
			}
		}
		eleInfoShipToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_CUST_NAME, customerName);
		eleInfoShipToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_DEST_CON_NAME, destinationContactName);

		Element eleInfoBillToFromWMOSOrderRelease = (Element) indoc
				.getDocumentElement()
				.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO)
				.item(0);
		String billToFirstName = eleInfoBillToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_FIRST_NAME);
		String billToLastName = eleInfoBillToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_LAST_NAME);
		String zipCode = eleInfoBillToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_ZIPCODE);
		String billToName = KohlsConstant.BLANK;
		String billToPostalCode = KohlsConstant.BLANK;
		if (!YFCCommon.isVoid(billToFirstName)
				&& !YFCCommon.isVoid(billToLastName)) {
			billToFirstName = billToFirstName.trim();
			billToLastName = billToLastName.trim();
			billToName = billToFirstName + KohlsConstant.BLANK_SPACE
					+ billToLastName;
		} else if (!YFCCommon.isVoid(billToLastName)) {
			billToLastName = billToLastName.trim();
			billToName = billToLastName;
		} else if (!YFCCommon.isVoid(billToFirstName)) {
			billToName = billToFirstName;
		}
		if (!YFCCommon.isVoid(billToName)) {
			int lenBillToName = billToName.length();
			if (lenBillToName > KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH) {
				billToName = billToName.substring(KohlsConstant.V_ZERO,
						KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH);
			}
		}
		if (!YFCCommon.isVoid(zipCode)) {
			billToPostalCode = zipCode.trim();
			int lenBillToPostalCode = billToPostalCode.length();
			if (lenBillToPostalCode > KohlsConstant.BILL_TO_POSTAL_CODE_LENGTH) {
				billToPostalCode = billToPostalCode.substring(
						KohlsConstant.V_ZERO,
						KohlsConstant.BILL_TO_POSTAL_CODE_LENGTH);
			}
		}
		eleInfoBillToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_BILL_TO_NAME, billToName);
		eleInfoBillToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_BILL_TO_POSTCODE, billToPostalCode);
		// remove first and last name from Order Release as part of Sprint 8
		eleInfoShipToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_FIRST_NAME);
		eleInfoShipToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_LAST_NAME);
		eleInfoBillToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_FIRST_NAME);
		eleInfoBillToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_LAST_NAME);
		eleInfoBillToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_ZIPCODE);

		return indoc;

	}

	/**
	 * As part of SR Sprint 7 this function to add 4 new attributes to Release
	 * XML such as
	 * CustomerName,DestinationContactName,BillToName,BillToPostalCode.
	 * 
	 * @param yfcindoc
	 *            yfcindoc.
	 * @return Document yfcindoc.
	 */

	public static YFCDocument appendCustomAttributesForSA(YFCDocument yfcindoc) {
		YFCElement yfceleInfoShipToFromWMOSOrderRelease = (YFCElement) yfcindoc
				.getDocumentElement()
				.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_SHIP_TO)
				.item(0);
		yfceleInfoShipToFromWMOSOrderRelease
				.removeAttribute(KohlsXMLLiterals.A_EMAIL_ID);
		String shipToFirstName = yfceleInfoShipToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_FIRST_NAME);
		String shipToLastName = yfceleInfoShipToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_LAST_NAME);
		String customerName = KohlsConstant.BLANK;
		String destinationContactName = KohlsConstant.BLANK;
		if (!YFCCommon.isVoid(shipToLastName)
				&& !YFCCommon.isVoid(shipToFirstName)) {
			shipToFirstName = shipToFirstName.trim();
			shipToLastName = shipToLastName.trim();
			customerName = shipToFirstName + KohlsConstant.BLANK_SPACE
					+ shipToLastName;
			destinationContactName = shipToFirstName
					+ KohlsConstant.BLANK_SPACE + shipToLastName;
		} else if (!YFCCommon.isVoid(shipToLastName)) {
			shipToLastName = shipToLastName.trim();
			customerName = shipToLastName;
			destinationContactName = shipToLastName;
		} else if (!YFCCommon.isVoid(shipToFirstName)) {
			shipToFirstName = shipToFirstName.trim();
			customerName = shipToFirstName;
			destinationContactName = shipToFirstName;
		}
		if (!YFCCommon.isVoid(customerName)) {
			int lenCustName = customerName.length();
			if (lenCustName > KohlsConstant.CUSTOMER_NAME_LENGTH) {
				customerName = customerName.substring(KohlsConstant.V_ZERO,
						KohlsConstant.CUSTOMER_NAME_LENGTH);
			}
		}
		if (!YFCCommon.isVoid(destinationContactName)) {
			int lensdestinationContactName = destinationContactName.length();
			if (lensdestinationContactName > KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH) {
				destinationContactName = destinationContactName.substring(
						KohlsConstant.V_ZERO,
						KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH);
			}
		}
		yfceleInfoShipToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_CUST_NAME, customerName);
		yfceleInfoShipToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_DEST_CON_NAME, destinationContactName);

		YFCElement yfceleInfoBillToFromWMOSOrderRelease = (YFCElement) yfcindoc
				.getDocumentElement()
				.getElementsByTagName(KohlsXMLLiterals.E_PERSON_INFO_BILL_TO)
				.item(0);
		String billToFirstName = yfceleInfoBillToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_FIRST_NAME);
		String billToLastName = yfceleInfoBillToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_LAST_NAME);
		String billToName = KohlsConstant.BLANK;
		String billToPostalCode = KohlsConstant.BLANK;
		if (!YFCCommon.isVoid(billToFirstName)
				&& !YFCCommon.isVoid(billToLastName)) {
			billToFirstName = billToFirstName.trim();
			billToLastName = billToLastName.trim();
			billToName = billToFirstName + KohlsConstant.BLANK_SPACE
					+ billToLastName;
		} else if (!YFCCommon.isVoid(billToLastName)) {
			billToLastName = billToLastName.trim();
			billToName = billToLastName;
		} else if (!YFCCommon.isVoid(billToFirstName)) {
			billToName = billToFirstName;
		}
		if (!YFCCommon.isVoid(billToName)) {
			int lenBillToName = billToName.length();
			if (lenBillToName > KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH) {
				billToName = billToName.substring(KohlsConstant.V_ZERO,
						KohlsConstant.DESTINATION_CONTACT_NAME_LENGTH);
			}
		}
		String zipCode = yfceleInfoBillToFromWMOSOrderRelease
				.getAttribute(KohlsConstant.ATTR_ZIPCODE);
		if (!YFCCommon.isVoid(zipCode)) {
			billToPostalCode = zipCode.trim();
			int lenBillToPostalCode = billToPostalCode.length();
			if (lenBillToPostalCode > KohlsConstant.BILL_TO_POSTAL_CODE_LENGTH) {
				billToPostalCode = billToPostalCode.substring(
						KohlsConstant.V_ZERO,
						KohlsConstant.BILL_TO_POSTAL_CODE_LENGTH);
			}
		}
		yfceleInfoBillToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_BILL_TO_NAME, billToName);
		yfceleInfoBillToFromWMOSOrderRelease.setAttribute(
				KohlsConstant.ATTR_BILL_TO_POSTCODE, billToPostalCode);
		// remove first and last name from Order Release as part of Sprint 8
		yfceleInfoShipToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_FIRST_NAME);
		yfceleInfoShipToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_LAST_NAME);
		yfceleInfoBillToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_FIRST_NAME);
		yfceleInfoBillToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_LAST_NAME);
		yfceleInfoBillToFromWMOSOrderRelease
				.removeAttribute(KohlsConstant.ATTR_ZIPCODE);

		return yfcindoc;
	}
}
