package com.kohls.common.util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.transform.TransformerException;

import org.apache.xpath.CachedXPathAPI;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.custom.util.log.Logger;
import com.kohls.common.util.vo.KohlsSpecialCharRemovalVO;

import com.sterlingcommerce.tools.datavalidator.XmlUtils;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.interop.japi.YIFCustomApi;
import com.yantra.yfc.util.YFCCommon;
import com.yantra.yfs.japi.YFSEnvironment;

public class KohlsRemoveUtil implements YIFCustomApi {
	private Properties oProperties = new Properties();
	private Logger log = new Logger(KohlsRemoveUtil.class.getName());
	private YIFApi api;
	
	/**
	 * constructor to initialize api
	 * 
	 * @throws YIFClientCreationException
	 *             
	 */
	public KohlsRemoveUtil() throws YIFClientCreationException {

		this.api = YIFClientFactory.getInstance().getLocalApi();
	}

	public Document removeUtil(YFSEnvironment env, Document docIn) throws TransformerException{
		Enumeration enumCondition = oProperties.propertyNames();
		String sXpathCount="0";
		String sAttrCount="0";

		while(enumCondition.hasMoreElements()){
			String sName = enumCondition.nextElement().toString();
			if ("XPATHCOUNT".equalsIgnoreCase(sName)){
				sXpathCount=oProperties.getProperty(sName);
			}else if("ATTRCOUNT".equalsIgnoreCase(sName)){
				sAttrCount = oProperties.getProperty(sName);
			}

		}
		
		//Element Removal
		
		for (int iIndex=1; iIndex<=Integer.parseInt(sXpathCount);iIndex++){
			
			String sXpath=oProperties.getProperty("XPATH_"+iIndex);
			CachedXPathAPI aCachedXPathAPI = new CachedXPathAPI();
		    NodeList nodeList = aCachedXPathAPI.selectNodeList(docIn, sXpath);
		    for (int i=0; i<nodeList.getLength();i++){
		    	Element ele = (Element)nodeList.item(i);
		    	(ele.getParentNode()).removeChild(ele);
		    }
		}
		
		//Attribute Removal
		for (int iIndex=1; iIndex<=Integer.parseInt(sAttrCount);iIndex++){
			
			String sAttrXpath=oProperties.getProperty("ATTR_"+iIndex);
			int AttrPosition = sAttrXpath.lastIndexOf("@");
			String sXpath=sAttrXpath.substring(0, AttrPosition - 1);
			String sAttr=sAttrXpath.substring(AttrPosition + 1);
			
			CachedXPathAPI aCachedXPathAPI = new CachedXPathAPI();
		    NodeList nodeList = aCachedXPathAPI.selectNodeList(docIn, sXpath);
		    for (int i=0; i<nodeList.getLength();i++){
		    	Element ele = (Element)nodeList.item(i);
		    	 ele.removeAttribute(sAttr);
		    }
		}

		return docIn;
	}
	
	//Start-Code below added by OASIS to support functionality of removing special characters in xml input to different api
	/**
	 * Method that gets called from KohlsRemoveSpecialChars with a hashmap containing required values of elements or attributes from which special characters needs to be 
	 * removed
	 */
	public void callremoveSpecialCharacters(HashMap<String, KohlsSpecialCharRemovalVO> hmReplaceSplChars, Document docIp, YFSEnvironment env)
	{
		Set<String> codeValSet = hmReplaceSplChars.keySet();
		Iterator<String> itr = codeValSet.iterator();
		while(itr.hasNext())
		{
			String strCodeVal = itr.next();
			KohlsSpecialCharRemovalVO splCharsRemVO = hmReplaceSplChars.get(strCodeVal);
			String strEleOrAttrNameToBeCorrected=null;
			String strCommonCodeValue=null;
			String strXpathWhrEleOrAttrCorrected=null;
			String strEleNameAttrPresent=null;
			boolean isElement = false; 
			if(!YFCCommon.isVoid(splCharsRemVO))
			{
				strEleOrAttrNameToBeCorrected = splCharsRemVO.getStrElementName();
				strCommonCodeValue = strCodeVal;
				strXpathWhrEleOrAttrCorrected = splCharsRemVO.getStrXPath();
				strEleNameAttrPresent = splCharsRemVO.getStrEleAtAttrPresent();
				isElement = splCharsRemVO.isElement();
				removeSpecialCharacters(strEleOrAttrNameToBeCorrected, strCommonCodeValue, strXpathWhrEleOrAttrCorrected,strEleNameAttrPresent, docIp, isElement, env);
			}
			
		}
	}
	
	
	/**
	 * Method to remove special characters, When special chars needs to be removed from argument then 
	 * third argument of this method will have xpath to repeatable element and Fourth argument will have name of actual element on which attribute needs to be
	 * updated 
	 * @param strEleOrAttrNameToBeCorrected
	 * @param strXpathWhrEleOrAttrCorrected
	 * @param docIp
	 * @param isElement
	 * @param env
	 */
	public void removeSpecialCharacters(String strEleOrAttrNameToBeCorrected, String strCommonCodeValue, String strXpathWhrEleOrAttrCorrected, 
			String strEleNameAttrPresent, Document docIp, boolean isElement, YFSEnvironment env)
	{
		Element eleIp = docIp.getDocumentElement();
		if(!YFCCommon.isVoid(strEleOrAttrNameToBeCorrected))
		{
			//Calling getCommonCodeList to get special characters corresponding to element or attribute specified in strEleOrAttrNameToBeCorrected argument
			String strSplChars = callGetCommonCodeList(strCommonCodeValue, env);
			if(!YFCCommon.isVoid(strSplChars))
			{
				boolean bTildPresent = strSplChars.contains(KohlsConstant.TILD);
				String strNotSplChars[] = strSplChars.split(KohlsConstant.TILD);
				
				Element eleToBeCorrected = null;
				
				String strSplCharsRem = "";
				strSplCharsRem = prepareRegExp(bTildPresent, strNotSplChars);
				log.debug("Regular expression prepared is:"+strSplCharsRem);
				//If element that needs to be corrected is a particular element(which is not repeatable element) at a certain xpath then below logic gets executed
				if(!YFCCommon.isVoid(strXpathWhrEleOrAttrCorrected))
				{
					try
					{
						//Control comes into below if condition if its an attribute
						if(isElement == false)
						{
							List<Element> al = KohlsXMLUtil.getElementListByXpath(docIp, strXpathWhrEleOrAttrCorrected);
							NodeList nlChild = null;
							int iRepeatLength = al.size();
								for(int j=0;j<iRepeatLength;j++)
								{
									Element eleRepeat = al.get(j);
									if(!YFCCommon.isVoid(strEleNameAttrPresent))
									{
										nlChild = eleRepeat.getElementsByTagName(strEleNameAttrPresent);
										int iChildLength = nlChild.getLength();
										for(int i=0;i<iChildLength;i++)
										{
											Element eleChild = (Element)nlChild.item(i);
											String strAttrVal = eleChild.getAttribute(strEleOrAttrNameToBeCorrected);
											if(!YFCCommon.isVoid(strAttrVal))
											{
												replaceSpecialCharsNPrepProperDoc(docIp, eleChild, isElement, strSplCharsRem, strEleOrAttrNameToBeCorrected, env);
											}
										}
									}
									else
									{
										replaceSpecialCharsNPrepProperDoc(docIp, eleRepeat, isElement, strSplCharsRem, strEleOrAttrNameToBeCorrected, env);
									}
								}
							
						}
						//Control comes into else if its an element which may or may not be repeatable and present at a particular xpath
						else
						{
							log.debug("Control came inside where element at xpath which may or may not be repeatable needs to be modified");
							NodeList nlElement = null;
							if(!YFCCommon.isVoid(strEleNameAttrPresent))
							{
								strXpathWhrEleOrAttrCorrected = KohlsConstant.FWD_DBL_SLASH+strXpathWhrEleOrAttrCorrected;
								log.debug("xpath generated is:"+strXpathWhrEleOrAttrCorrected);
								nlElement = KohlsXPathUtil.getNodeList(eleIp, strXpathWhrEleOrAttrCorrected);
								int iLength = nlElement.getLength();
								for(int i=0;i<iLength;i++)
								{
									eleToBeCorrected = (Element)nlElement.item(i);
									NodeList nlChild = eleToBeCorrected.getElementsByTagName(strEleNameAttrPresent);
									int iLengthChild = nlChild.getLength();
									for(int j=0;j<iLengthChild;j++)
									{
										
										Element eleChildToBeCorrected = (Element)nlChild.item(j);
										replaceSpecialCharsNPrepProperDoc(docIp, eleChildToBeCorrected, isElement, strSplCharsRem, strEleOrAttrNameToBeCorrected, env);
									}
									
								}
							}
							else
							{
								eleToBeCorrected = KohlsXMLUtil.getElementByXpath(docIp, strXpathWhrEleOrAttrCorrected);
								replaceSpecialCharsNPrepProperDoc(docIp, eleToBeCorrected, isElement, strSplCharsRem, strEleOrAttrNameToBeCorrected, env);
							}
							
						}
						
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
				//If xpath is null, then special characters needs to be replaced in all elements having this name 
				else 
				{
					NodeList nlElement = eleIp.getElementsByTagName(strEleOrAttrNameToBeCorrected);
					int iLength = 0;
					if(!YFCCommon.isVoid(nlElement))
					{
						iLength = nlElement.getLength();
					}
					log.debug(":Number of elements in nodelist is:"+iLength);
					//If the element name that is specified is that of root node then control comes into below if condition
					if(eleIp.getNodeName().equals(strEleOrAttrNameToBeCorrected) && iLength == 0)
					{
						log.debug(":Root element needs to be corrected:");
						replaceSpecialCharsNPrepProperDoc(docIp, eleIp, isElement, strSplCharsRem, strEleOrAttrNameToBeCorrected, env);
						log.debug("docIp in removeSpecialCharacters is:"+KohlsXMLUtil.getXMLString(docIp));
					}
					else
					{
						for(int i=0;i<iLength;i++)
						{
							//Below logic until replaceSpecialCharsNPrepProperDoc call is to determine the element that needs to be picked for next correction 
							eleToBeCorrected = (Element)nlElement.item(i);
							log.debug(":Element to be corrected is:"+KohlsXMLUtil.getElementXMLString(eleToBeCorrected));
							replaceSpecialCharsNPrepProperDoc(docIp, eleToBeCorrected, isElement, strSplCharsRem, strEleOrAttrNameToBeCorrected, env);
							log.debug(":Document after correction is:"+KohlsXMLUtil.getXMLString(docIp));
						}
					}
				}
			}
				
		}
	}
	
	/**
	 * Method that prepares Regular expression based on short description obtained for corresponding common code value and returns it
	 * @param bTildPresent
	 * @param strArr
	 * @return String
	 */
	private String prepareRegExp(boolean bTildPresent, String strArr[])
	{
		String strSplCharsRem="";
		strSplCharsRem+=KohlsConstant.OPEN_SQ_BRACKET;
		int iLength = strArr.length;
		if(bTildPresent == true)
		{
			strSplCharsRem+=KohlsConstant.CARET+KohlsConstant.STR_SPACE;
		}
		for(int i=0;i<iLength;i++)
		{
			String strSplCharsArr[] = strArr[i].split(KohlsConstant.COMMA);
			for(String strChar:strSplCharsArr)
			{
				if(bTildPresent == true)
				{
					strSplCharsRem+=KohlsConstant.CARET;
				}
				if(KohlsConstant.DBL_QUOTE.equals(strChar))
				{
					strSplCharsRem+=KohlsConstant.SGL_BACK_SLASH;
				}
				strSplCharsRem+=strChar;
			}
			bTildPresent = false;
		}
		strSplCharsRem+=KohlsConstant.CLOSE_SQ_BRACKET;
		return strSplCharsRem;
	}
	
	/**
	 * Method to replace special characters in corresponding element or attribute and then add it to the xml at proper place
	 * @param docIp
	 * @param eleToBeCorrected
	 * @param isElement
	 * @param strSplCharsRem
	 * @param strEleOrAttrNameToBeCorrected
	 */
	private void replaceSpecialCharsNPrepProperDoc(Document docIp,  Element eleToBeCorrected, boolean isElement, String strSplCharsRem, String strEleOrAttrNameToBeCorrected, YFSEnvironment env)
	{
		String strToBeCorrected = null;
		String strCorrected  = null;
		Element eleIp = docIp.getDocumentElement();
		Element eleParent = null;
		int iParentHashCode = 0;
		//If its an element within which special characters needs to be removed then control comes into if condition
		if(isElement == true)
		{
			strToBeCorrected = KohlsXMLUtil.getElementXMLString(eleToBeCorrected);
			strCorrected = identifyNReplaceSpecialCharsInString(strSplCharsRem, strToBeCorrected, env);
			Document docNew = null;
			Element eleNewCrct = null;
			try
			{
				docNew = XmlUtils.createFromString(strCorrected);
				eleNewCrct = docNew.getDocumentElement();
				log.debug("docNew is:"+KohlsXMLUtil.getXMLString(docNew));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			//Control comes into below if condition if its not a root node that needs to be corrected
			if(!eleToBeCorrected.getParentNode().getNodeName().equals(KohlsConstant.PARENT_NODE_NAME))
			{
				alterElementWithCorrectedAttrNChild(eleToBeCorrected, eleNewCrct);
			}
			//Control comes into below if condition if its a root node that needs to be corrected
			else
			{
				alterElementWithCorrectedAttrNChild(eleIp, eleNewCrct);
			}
		}
		//If its an attribute within which special characters needs to be removed then control comes into else 
		else
		{
			strToBeCorrected = eleToBeCorrected.getAttribute(strEleOrAttrNameToBeCorrected);
			strCorrected = identifyNReplaceSpecialCharsInString(strSplCharsRem, strToBeCorrected, env);
			eleToBeCorrected.setAttribute(strEleOrAttrNameToBeCorrected, strCorrected);
		}
		
	}
	
	/**
	 * Method which removes attributes and child nodes and replaces them with corrected attributes and child nodes
	 * @param eleIp
	 * @param eleNewCrct
	 */
	private void alterElementWithCorrectedAttrNChild(Element eleIp, Element eleNewCrct)
	{
		NodeList nlChild = eleIp.getChildNodes();
		processChildNodes(nlChild, true, eleIp);
		NodeList nlChildrenNew = eleNewCrct.getChildNodes();
		processChildNodes(nlChildrenNew, false, eleIp);
		NamedNodeMap nMapAttrNew = eleNewCrct.getAttributes();
		log.debug(":Number of attributes are:"+nMapAttrNew.getLength());
		setChildAttributes(nMapAttrNew,eleNewCrct, eleIp);
		
	}
	
	/**
	 * Method for removing/appending child nodes within and element
	 * @param nlChild
	 * @param isRemove
	 * @param eleIp
	 */
	private void processChildNodes(NodeList nlChild, boolean isRemove, Element eleIp)
	{
		//Below logic is for removing or appending child nodes in an element 
		if(!YFCCommon.isVoid(nlChild))
		{
			int iLength = nlChild.getLength();
			for(int i=0;i<iLength;i++)
			{
				if(isRemove == true)
				{
					Node ndChild = nlChild.item(0);
					eleIp.removeChild(ndChild);
				}
				else
				{
					Node ndChild = nlChild.item(i);
					Node ndNewInIp = eleIp.getOwnerDocument().importNode(ndChild, true);
					eleIp.appendChild(ndNewInIp);
				}
			}
		}
	}
	
	/**
	 * Method for setting attributes within an element from another element
	 * @param nMapAttrs
	 * @param isRemove
	 * @param eleIp
	 */
	private void setChildAttributes(NamedNodeMap nMapAttrs, Element eleNew, Element eleIp)
	{
		//Below logic is for setting all attributes at root node
		int iLengthAttrs = 0;
		if(!YFCCommon.isVoid(nMapAttrs))
		{
			iLengthAttrs = nMapAttrs.getLength();
			for(int j=0;j<iLengthAttrs;j++)
			{
				Attr attrChild = (Attr)nMapAttrs.item(j);
				String strVal = eleNew.getAttribute(attrChild.getName());
				eleIp.setAttribute(attrChild.getName(), strVal);
			}
		}
	}
	
	/**
	 * Method to identify and replace any special characters in given String
	 * @param strSplCharsRem
	 * @param strToBeCorrected
	 * @return String
	 */
	private String identifyNReplaceSpecialCharsInString(String strSplCharsRem, String strToBeCorrected, YFSEnvironment env)
	{
		Matcher m = matchingLogic(strSplCharsRem, strToBeCorrected);
		String strSplCharsSlashApp = callGetCommonCodeList(KohlsConstant.SPL_CHARS, env);
		while(m.find())
		{
			String strChar = m.group();
	         if(strSplCharsSlashApp.contains(strChar))
	        {
	        	String strToBeReplaced = KohlsConstant.DBL_SLASH+strChar;
	        	strToBeCorrected = strToBeCorrected.replaceAll(strToBeReplaced,"");
	        }
	        else
	        {
	        	strToBeCorrected = strToBeCorrected.replaceAll(strChar,"");
	        }
	    }
		return strToBeCorrected;
	}
	
	/**
	 * Using pattern matching it will identify all the instances in which special characters are present
	 * @param strRegex
	 * @param strLine
	 * @return Matcher
	 */
	private  static Matcher matchingLogic(String strRegex, String strLine)
	{
		Pattern pat = Pattern.compile(strRegex);
		Matcher match = pat.matcher(strLine);
		return match;
	}

	/**
	 * Method to prepare input xml and call getCommonCodeList and return required attribute
	 * @param strCodeValue
	 * @param env
	 * @return String
	 */
	private String callGetCommonCodeList(String strCodeValue, YFSEnvironment env)
	{
		Document docOp = null;
		String strCodeVal = null;
		try
		{
			Document docIp = KohlsXMLUtil.createDocument(KohlsConstant.E_COMMON_CODE);
			Element eleIp = docIp.getDocumentElement();
			
			eleIp.setAttribute(KohlsConstant.A_CODE_VALUE, strCodeValue);
			docOp = api.getCommonCodeList(env, docIp);
			
			Element eleCommonCodeOp = docOp.getDocumentElement();
			NodeList nlCommonCode = KohlsXPathUtil.getNodeList(eleCommonCodeOp, "//CommonCodeList/CommonCode[@CodeValue='"+strCodeValue+"']");
			
			if(!YFCCommon.isVoid(nlCommonCode) && nlCommonCode.getLength() > 0)
			{
				Element eleCommonCode = (Element)nlCommonCode.item(0);
				//Getting value of CodeShortDescription
				strCodeVal = eleCommonCode.getAttribute(KohlsConstant.A_CODE_SHORT_DESC);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return strCodeVal;
	}
	//End-Code above added by OASIS to support functionality of removing special characters in xml input to different api
	
	@Override
	public void setProperties(Properties properties) throws Exception {
		// TODO Auto-generated method stub
		if (properties != null) {
			this.oProperties = properties;
		}
	}

}
