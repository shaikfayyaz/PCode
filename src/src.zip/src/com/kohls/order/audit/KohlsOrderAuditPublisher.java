package com.kohls.order.audit;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;

import com.kohls.poc.constant.KohlsPOCConstant;
import com.yantra.ycp.core.IDataPublishListener;
import com.yantra.yfc.dom.YFCDocument;
import com.yantra.yfc.log.YFCLogCategory;
import com.yantra.yfs.core.YFSSystem;

public class KohlsOrderAuditPublisher implements IDataPublishListener {
	private static final YFCLogCategory log = YFCLogCategory.instance(KohlsOrderAuditPublisher.class.getName());

	/*
	 * Reads the file write flag from cop file, if Y it writes to log file ,
	 * otherwise it ignores.
	 */
	public void onPublish(YFCDocument auditXml) {
		FileWriter writer = null;
		try {
			String auditLogToFileEnabled = YFSSystem.getProperty(KohlsPOCConstant.ORDER_AUDIT_FILE_WRITE_ENABLED);
			log.beginTimer("Order audit message start " + auditLogToFileEnabled);
			log.debug("Order audit message " + auditXml.toString());

			if (auditLogToFileEnabled.equalsIgnoreCase(KohlsPOCConstant.NO)) {
				log.debug("Order audit message is ignored");
			} else if (auditLogToFileEnabled.equalsIgnoreCase(KohlsPOCConstant.YES)) {
				String xmlString = auditXml.toString();
				String timeStamp = new SimpleDateFormat(KohlsPOCConstant.EXPORT_TABLES_DATE_FORMAT)
						.format(new java.util.Date());
				String auditLogFileName = YFSSystem.getProperty(KohlsPOCConstant.ORDER_AUDIT_FILE_LOG_PATH)
						+ KohlsPOCConstant.BACKWARD_SLASH + YFSSystem.getProperty(KohlsPOCConstant.STORE_ID_PROP)
						+ KohlsPOCConstant.UNDERSCORE + timeStamp + KohlsPOCConstant.DOT_LOG;
				writer = new FileWriter(auditLogFileName);
				writer.write(xmlString);
				log.debug("Order audit message written to file " + auditLogFileName);
			}
			log.endTimer("Order audit message end ");
		} catch (Exception ordExp) {
			log.error("Order audit message exception ", ordExp);
		}finally {
			log.debug("Order audit message checking for filewriter value");
			if (writer != null) {
				try {
					writer.close();
					log.debug("Order audit message closed the file");
				} catch (IOException e) {
					log.error("Order audit message exception while closing file ", e);
				}
			}
		}
	}
}